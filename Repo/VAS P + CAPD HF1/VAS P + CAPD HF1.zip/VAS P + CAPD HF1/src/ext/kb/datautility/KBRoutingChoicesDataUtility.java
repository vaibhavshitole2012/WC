package ext.kb.datautility;

import org.apache.log4j.Logger;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.dataUtilities.AbstractAttributeDataUtility;
import com.ptc.windchill.enterprise.workitem.dataUtilities.WorkItemDataUtility;

import ext.kb.workflow.WFUtils;
import wt.util.WTException;
import wt.workflow.engine.WfActivity;

public class KBRoutingChoicesDataUtility extends AbstractAttributeDataUtility {

	private static final Logger LOG = Logger.getLogger(KBRoutingChoicesDataUtility.class);

	// Activities with a special logic to set the default routing option.
	private static final String ANALZYE_CHANGE_REQUEST = "Analyze Change Request";
	private static final String RELEASE_STANDARD_PART = "Release Standard Part";
	
	private WorkItemDataUtility datautility = null;

	public KBRoutingChoicesDataUtility() {
		datautility = new WorkItemDataUtility();
	}

	@Override
	public Object getDataValue(String paramString, Object paramObject, ModelContext paramModelContext) throws WTException {
		WfActivity activity = WFUtils.getWfActivity(paramObject);
		String activityName = activity.getName();
        LOG.debug("Activity name is '"+activityName+"'");
		KBRoutingChoiceStrategy strategy = null;
		Object result = datautility.getDataValue(paramString,paramObject,paramModelContext);
		
	    // Instantiate the correct strategy to determine the routing options.
		if (activityName.equals(ANALZYE_CHANGE_REQUEST)) {
			strategy = new KBAnalyzeChangeRequestRoutingChoiceStrategy(activity, result);
		} else if (activityName.equals(RELEASE_STANDARD_PART)) {
			strategy = new KBReleaseStandardPartRequestRoutingChoiceStrategy(activity, result);
		}

        if (strategy != null) {
        	return strategy.getRoutingChoice();
        } else {
        	return result;
        }
	}

	@Override
	public String getLabel(String paramString, ModelContext paramModelContext) throws WTException {
		return datautility.getLabel(paramString, paramModelContext);
	}
}
