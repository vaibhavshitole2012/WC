package ext.kb.datautility;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ptc.core.components.util.OidHelper;
import org.apache.log4j.Logger;

import com.ptc.core.components.descriptor.ComponentDescriptor;
import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.dataUtilities.AttributeDataUtilityHelper;
import com.ptc.core.components.factory.dataUtilities.DefaultDataUtility;
import com.ptc.core.components.rendering.PickerRenderConfigs;
import com.ptc.core.components.rendering.guicomponents.AttributeGuiComponent;
import com.ptc.core.components.rendering.guicomponents.PickerInputComponent;
import com.ptc.core.components.rendering.guicomponents.TextDisplayComponent;
import com.ptc.core.lwc.common.view.AttributeDefinitionReadView;
import com.ptc.core.lwc.common.view.ConstraintDefinitionReadView;
import com.ptc.core.lwc.common.view.ConstraintRuleDefinitionReadView;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.container.common.impl.ValueRequiredConstraint;

import ext.kb.dynamiclist.naming.CoatingCatalogueEnumerationInfoProvider;
import ext.kb.util.IBAHelper;
import ext.kb.util.KBConstants;
import ext.kb.util.KBTeamUtils;
import ext.kb.util.KBTypeIdProvider;
import ext.kb.util.KBUtils;
import wt.fc.Persistable;
import wt.iba.value.IBAHolder;
import wt.inf.container.WTContained;
import wt.inf.team.ContainerTeamManaged;
import wt.lifecycle.LifeCycleManaged;
import wt.org.WTPrincipal;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.util.WTInvalidParameterException;

public class KBCoatingDataUtility extends EditArticleAttributesDataUtility {

	private static final Logger LOGGER = Logger.getLogger(KBCoatingDataUtility.class);

	public static final String BASE_WHERE_CLAUSE_VALUE = "(state.state='1050')";
	public static final String PICKED_ATTRIBUTES_VALUE = "name,number";
	public static final String SEARCH_RESULTS_VIEW_ID_VALUE = "com.ptc.KBCoating.coatingTableView";

	protected static final String PICKER_PROPERTY = "wt.part.coatingDynamicListPicker";
	protected static final String DELIMITER_PROPERTY = "wt.part.multivalueListPicker.delimiter";
	protected static final String DEFAULT_DELIMITER = ";";
	protected static final List<String> ROLES_NOT_ELIGIBLE_TO_EDIT_ATTRIBUTE =
			Arrays.asList("PRODUCT MANAGER", "DOCUMENT MANAGEMENT", "ATTRIBUTE MANAGER", "COST-EDITOR", "PRODUCTION PLANNER");
	protected static final List<String> DESIGNERS = 
			Arrays.asList("CAD-DESIGNER", "DESIGNER-LIMITED");
	public static final String DELIMITER;
	private CoatingCatalogueEnumerationInfoProvider suggestionProvider = new CoatingCatalogueEnumerationInfoProvider();

	static {
		String delimiter = DataUtilityHelper.getProperty(DELIMITER_PROPERTY);
		if (KBUtils.isEmpty(delimiter)) {
			DELIMITER = DEFAULT_DELIMITER;
			LOGGER.error("Property '" + DELIMITER_PROPERTY + " is empty or does not exist. Default delimiter '"
					+ DEFAULT_DELIMITER + "' has been set.");
		} else {
			DELIMITER = delimiter;
			LOGGER.debug("Delimiter for multivalue picker: " + DELIMITER);
		}
	}

	@Override
	public Object getDataValueInternal(String paramString, Object paramObject, ModelContext paramModelContext)
			throws WTException {

		Object uiComponent = new DefaultDataUtility().getDataValue(paramString, paramObject, paramModelContext);
		LOGGER.debug("uiComponent: " + uiComponent);

		if (uiComponent instanceof AttributeGuiComponent) {

			AttributeGuiComponent defaultComponent = (AttributeGuiComponent) uiComponent;
			String dynamicListItemPickers = DataUtilityHelper.getProperty(PICKER_PROPERTY);

			TypeIdentifier targetType = wt.type.TypedUtilityServiceHelper.service.getTypeIdentifier(paramObject);
			boolean isArticle = targetType.isDescendedFrom(KBTypeIdProvider.getType("ARTICLE"));
			boolean isCadDoc = targetType.isDescendedFrom(KBTypeIdProvider.getType("CADDOC"));
			boolean isKbDocument = targetType.isDescendedFrom(KBTypeIdProvider.getType("KBDOC"));
			boolean isRefdoc = targetType.isDescendedFrom(KBTypeIdProvider.getType("REFDOC"));

			if (isArticle || isCadDoc || isKbDocument || isRefdoc) {
				if (paramModelContext.getDescriptorMode() == com.ptc.core.ui.resources.ComponentMode.VIEW) {
					return displayNameInsteadOfKey(paramString, paramObject);
				} else {
					if (KBUtils.isEmpty(dynamicListItemPickers)) {
						return TextDisplayComponent.NBSP;
					}
					String[] dynamicPickers = dynamicListItemPickers.split(",");
					AttributeDefinitionReadView rv = IBAHelper.getAttributeDefinitionReadView(targetType.getTypename(),
							KBConstants.KBCOATING_IBA);
					Collection<ConstraintDefinitionReadView> rest = rv.getAllConstraints();
					boolean required = false;
					for (ConstraintDefinitionReadView v : rest) {
						ConstraintRuleDefinitionReadView rule = v.getRule();
						if (ValueRequiredConstraint.class.getName().equals(rule.getRuleClassname())) {
							required = true;
							break;
						}
					}

					PickerInputComponent field = new PickerInputComponent(defaultComponent.getColumnName(), "",
							getPickerConfigs(dynamicPickers[0], dynamicPickers[1], required));
					field.setRequired(required);
					field.setColumnName(defaultComponent.getColumnName());
					if (paramModelContext.getDescriptorMode() == com.ptc.core.ui.resources.ComponentMode.EDIT) {
						Object refObject = paramModelContext.getNmCommandBean().getPageOid().getRefObject();
						String ibaId = IBAHelper.getStringIBAValue((IBAHolder) refObject, KBConstants.KBCOATING_IBA);
						if (ibaId == null) {
							if (isCadDoc) {
								ibaId = getValueForEdit(paramObject, "CADDOC", KBConstants.KBCOATING_IBA);
							} else if (isArticle) {
								ibaId = getValueForEdit(paramObject, "ARTICLE", KBConstants.KBCOATING_IBA);
							} else if (isKbDocument) {
								ibaId = getValueForEdit(paramObject, "KBDOC", KBConstants.KBCOATING_IBA);
							} else {
								ibaId = getValueForEdit(paramObject, "REFDOC", KBConstants.KBCOATING_IBA);
							}
						}
						if (ibaId != null) {
							String translationValue = getNames(ibaId);
							Map<String, String> configs = getPickerConfigs(dynamicPickers[0], dynamicPickers[1],
									required);
							;
							configs.put(PickerRenderConfigs.DEFAULT_VALUE, translationValue);
							configs.put(PickerRenderConfigs.DEFAULT_HIDDEN_VALUE, ibaId);
							field = new PickerInputComponent(defaultComponent.getColumnName(), "", configs);
							field.setRequired(required);
							field.setColumnName(defaultComponent.getColumnName());
						}
						field.setMultiValued(true);
						Persistable persistable = OidHelper.getPersistable(paramObject);
						boolean shouldBeEditable = DataUtilityHelper.shouldBeEditableOnPart(persistable, paramString);
						field.setEditable(shouldBeEditable);
					}
					defaultComponent = field;
				}
			}
			return defaultComponent;
		} else {
			return uiComponent;

		}

	}

	@Override
	public Object getPlainDataValue(String paramString, Object paramObject, ModelContext paramModelContext)
			throws WTException {
		Object defaultComponent = new DefaultDataUtility().getDataValue(paramString, paramObject, paramModelContext);
		if (defaultComponent instanceof AttributeGuiComponent) {

			TypeIdentifier targetType = wt.type.TypedUtilityServiceHelper.service.getTypeIdentifier(paramObject);
			boolean isArticle = targetType.isDescendedFrom(KBTypeIdProvider.getType("ARTICLE"));
			boolean isCadDoc = targetType.isDescendedFrom(KBTypeIdProvider.getType("CADDOC"));
			boolean isKbDocument = targetType.isDescendedFrom(KBTypeIdProvider.getType("KBDOC"));
			boolean isRefdoc = targetType.isDescendedFrom(KBTypeIdProvider.getType("REFDOC"));

			if (isArticle || isCadDoc || isKbDocument || isRefdoc) {
				return displayNameInsteadOfKey(paramString, paramObject);
			}
		}
		return defaultComponent;
	}

	public Object displayNameInsteadOfKey(String paramString, Object paramObject) throws WTException {
		String id = IBAHelper.getStringIBAValue((IBAHolder) paramObject, KBConstants.KBCOATING_IBA);
		LOGGER.debug("displayNameInsteadOfKey - id:" + String.valueOf(id) + " paramObject :" + paramObject);
		StringBuilder displayValue = new StringBuilder();
		if (!KBUtils.isEmpty(id)) {
			List<String> keyList = getKeyList(id);
			for (String key : keyList) {
				String name = suggestionProvider.getNameByKey(key);
				if (KBUtils.isEmpty(name)) {
					LOGGER.error("There is no entry with a key: " + key);
					displayValue.append(key).append("\n");
				} else {
					displayValue.append(name).append("\n");
				}
			}
		}
		LOGGER.debug("returning:" + String.valueOf(displayValue));
		return displayValue.toString();
	}

	@Override
	public Object getDataValue(String paramString, Object paramObject, ModelContext paramModelContext)
			throws WTException {
		return getDataValueInternal(paramString, paramObject, paramModelContext);
	}

	private String getNames(String ibaId) {
		suggestionProvider.loadCatalogue();

		StringBuilder names = new StringBuilder();
		List<String> listOfIds = Arrays.asList(ibaId.split(DELIMITER));
		for (String id : listOfIds) {
			names.append(suggestionProvider.getNameByKey(id));
			names.append(DELIMITER);
		}
		if (!KBUtils.isEmpty(names.toString())) {
			names.setLength(names.length() - 1);
			return names.toString();
		}

		return "";
	}

	private List<String> getKeyList(String id) {
		String[] idArray = id.split(DELIMITER);
		return Arrays.asList(idArray);
	}

	protected static Map<String, String> getPickerConfigs(String id, String objectType, boolean isRequired) {
	        String dynamicListItemPickers = DataUtilityHelper.getProperty(PICKER_PROPERTY);
	        String[] dynamicPickers = dynamicListItemPickers.split(",");
	        Map<Object, Object> map = new HashMap<Object, Object>();
			PickerRenderConfigs.setDefaultPickerProperty( map , PickerRenderConfigs.PICKER_ID, id );
	        PickerRenderConfigs.setDefaultPickerProperty( map, PickerRenderConfigs.OBJECT_TYPE, dynamicPickers[1]);
	        PickerRenderConfigs.setDefaultPickerProperty( map, PickerRenderConfigs.PICKER_TITLE, "Coating");
	        PickerRenderConfigs.setDefaultPickerProperty( map, PickerRenderConfigs.IS_MULTIVALUED, "TRUE" );
	        PickerRenderConfigs.setDefaultPickerProperty( map, "multiSelect", "true");
	        PickerRenderConfigs.setDefaultPickerProperty(map, PickerRenderConfigs.COMPONENT_ID, "smaPickerId");
	        PickerRenderConfigs.setDefaultPickerProperty(map, "includeTypeInstanceId", "true");
	        PickerRenderConfigs.setDefaultPickerProperty(map, "pickerCallback", "coatingPickerCallback");
	        PickerRenderConfigs.setDefaultPickerProperty(map, "pickedAttributes", "name,number");

			PickerRenderConfigs.setDefaultPickerProperty(map, PickerRenderConfigs.PICKER_TYPE, "search" );
	        PickerRenderConfigs.setDefaultPickerProperty(map, PickerRenderConfigs.SHOW_SUGGESTION, Boolean.TRUE.toString());
	        PickerRenderConfigs.setDefaultPickerProperty(map, PickerRenderConfigs.SUGGEST_MIN_CHARS, "2");
	        PickerRenderConfigs.setDefaultPickerProperty(map, PickerRenderConfigs.SUGGEST_SERVICE_KEY, "coatingEntryPicker");
	        PickerRenderConfigs.setDefaultPickerProperty(map, PickerRenderConfigs.DISPLAY_ATT, "name");
	        PickerRenderConfigs.setDefaultPickerProperty(map, PickerRenderConfigs.BASE_WHERE_CLAUSE, BASE_WHERE_CLAUSE_VALUE);
	        PickerRenderConfigs.setDefaultPickerProperty(map, "width", "40");
	        if (isRequired){
	        	PickerRenderConfigs.setDefaultPickerProperty(map, "required", Boolean.TRUE.toString());
			} else {
				PickerRenderConfigs.setDefaultPickerProperty(map, "required", Boolean.FALSE.toString());
			}
	        PickerRenderConfigs.setDefaultPickerProperty(map, "searchResultsViewId", SEARCH_RESULTS_VIEW_ID_VALUE);
	        return PickerRenderConfigs.getPickerConfigs(map);
	}
}
