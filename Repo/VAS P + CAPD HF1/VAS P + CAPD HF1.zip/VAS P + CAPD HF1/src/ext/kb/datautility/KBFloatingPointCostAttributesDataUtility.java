package ext.kb.datautility;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.NumberFormat;

import org.apache.log4j.Logger;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.dataUtilities.DefaultDataUtility;
import com.ptc.core.components.rendering.guicomponents.AttributeDisplayCompositeComponent;
import com.ptc.core.components.rendering.guicomponents.AttributeInputComponent;
import com.ptc.core.components.rendering.guicomponents.AttributeInputCompositeComponent;
import com.ptc.core.components.rendering.guicomponents.NumericDisplayComponent;
import com.ptc.core.components.rendering.guicomponents.TextDisplayComponent;
import com.ptc.core.ui.resources.ComponentMode;

import ext.kb.ui.validation.KBFloatingPointAttributesProcessorDelegate;
import ext.kb.util.KBUtils;
import wt.log4j.LogR;
import wt.session.SessionHelper;
import wt.util.WTException;

public class KBFloatingPointCostAttributesDataUtility extends EditArticleAttributesDataUtility {
	
	/** The Constant CLASSNAME. */
    private static final String CLASSNAME = KBFloatingPointCostAttributesDataUtility.class.getName();

    /** The Constant LOGGER. */
    protected static final Logger LOGGER = LogR.getLogger(CLASSNAME);
    
	private static final String KB_EST_MAT_COST_PREF = "KB_EST_MAT_COST_PREF";
	private static final String KB_EST_MAT_COST_LOCAL = "KB_EST_MAT_COST_LOCAL";
	private static final String KB_MAT_COST_PREF = "KB_MAT_COST_PREF";
	private static final String KB_MAT_COST_LOCAL = "KB_MAT_COST_LOCAL";
	private static final String[] CURRENCIES = {"EUR", "AUD", "CNY", "USS"};
	
	@Override
	public Object getDataValueInternal(String paramString, Object paramObject, ModelContext paramModelContext) throws WTException {
		
		Object mainComponent = new DefaultDataUtility().getDataValue(paramString, paramObject, paramModelContext);

		try {
			String compContext = paramModelContext.getNmCommandBean().getCompContext();
			
			if ((compContext != null && compContext.contains("search")) || KBUtils.isDataUtilityRunInOrganization(paramModelContext, KBUtils.HVAC_ORG_NAME)  || KBUtils.isDataUtilityRunInOrganization(paramModelContext, KBUtils.KB_ORG_NAME)) {
				ComponentMode componentMode = paramModelContext.getDescriptorMode();
				if (KBUtils.isCreateMode(componentMode) || KBUtils.isEditMode(componentMode)) {
					AttributeInputCompositeComponent attributeInputCompositeComponent = (AttributeInputCompositeComponent) mainComponent;

					AttributeInputComponent attributeInputComponent = attributeInputCompositeComponent.getValueInputComponent();

					if (attributeInputComponent != null)
						attributeInputComponent.addHiddenField("FormProcessorDelegate", KBFloatingPointAttributesProcessorDelegate.class.getName());
				} else if (KBUtils.isViewMode(componentMode)) {
					
					if (mainComponent instanceof String) {
						String stringComponent = (String) mainComponent;
						mainComponent = transformStringCostFormat(stringComponent);
					} else if (mainComponent instanceof AttributeDisplayCompositeComponent) {
						AttributeDisplayCompositeComponent attributeDisplayCompositeComponent = (AttributeDisplayCompositeComponent) mainComponent;

						if (attributeDisplayCompositeComponent.getValueDisplayComponent() instanceof NumericDisplayComponent) {
							NumericDisplayComponent numericDisplayComponent = (NumericDisplayComponent) attributeDisplayCompositeComponent.getValueDisplayComponent();
	
							KBNumericDisplayComponent kbNumericDisplayComponent = new KBNumericDisplayComponent(numericDisplayComponent);
							attributeDisplayCompositeComponent.setValueDisplayComponent(kbNumericDisplayComponent);
						}
					}
				}
			}
			if (isKbMatCostColumn(paramString)) {
				if (mainComponent instanceof String) {
					String stringComponent = (String) mainComponent;
					mainComponent = transformStringCostFormat(stringComponent);
				} else if (mainComponent instanceof AttributeDisplayCompositeComponent) {
					AttributeDisplayCompositeComponent attributeDisplayCompositeComponent = (AttributeDisplayCompositeComponent) mainComponent;
					if (attributeDisplayCompositeComponent.getValueDisplayComponent() instanceof TextDisplayComponent) {
						TextDisplayComponent textDisplayComponent = (TextDisplayComponent) attributeDisplayCompositeComponent.getValueDisplayComponent();
						
						KBTextDisplayComponent kbTextDisplayComponent = new KBTextDisplayComponent(textDisplayComponent);
						attributeDisplayCompositeComponent.setValueDisplayComponent(kbTextDisplayComponent);
					}
				}
			}
		} catch (Exception exception) {
			exception.printStackTrace();
			LOGGER.error(exception.getMessage(), exception);
		}

		return mainComponent;
	}

	private static boolean isKbMatCostColumn(String pColumnName) {
		return pColumnName.equals(KB_MAT_COST_LOCAL)
				|| pColumnName.equals(KB_MAT_COST_PREF)
				|| pColumnName.equals(KB_EST_MAT_COST_LOCAL)
				|| pColumnName.equals(KB_EST_MAT_COST_PREF);
	}
	
	private static String transformStringCostFormat(String value) {
		if (value == null) {
			return " ";
		}
		for (String currency : CURRENCIES) {
			if (value.contains(currency)) {
				value = value.trim();
				value = value.replaceAll(currency, "");
				StringBuilder newValueBuilder = new StringBuilder();
				newValueBuilder
						.append(value)
						.append(" ")
						.append(currency);
				return newValueBuilder.toString();
			}
		}
		return value;
	}

	static class KBNumericDisplayComponent extends NumericDisplayComponent {
		private static final long serialVersionUID = 1L;

		public KBNumericDisplayComponent(NumericDisplayComponent numericDisplayComponent) {
			super(numericDisplayComponent.getLabel(), numericDisplayComponent.getUnitOfMeasure());
			setValue(numericDisplayComponent.getValue());
		}

		@Override
		public String getDisplayValue() {
			String displayValue;
			if (getValue() != null) {
				try {
					displayValue = truncateDecimal(getValue().doubleValue(), 2);
				} catch (WTException exception) {
					exception.printStackTrace();

					displayValue = " ";
				}
				if (getUnitOfMeasure() != null)
					displayValue = displayValue + " " + getUnitOfMeasure().toString();
			} else {
				displayValue = " ";
			}
			return displayValue;
		}

		public static String truncateDecimal(Double number, int numberofDecimals) throws WTException {
			DecimalFormat decimalFormat = (DecimalFormat) NumberFormat.getNumberInstance(SessionHelper.getLocale());
			decimalFormat.setMinimumFractionDigits(numberofDecimals);
			decimalFormat.setMaximumFractionDigits(numberofDecimals);

			if (number > 0)
				decimalFormat.setRoundingMode(RoundingMode.HALF_UP);
			else
				decimalFormat.setRoundingMode(RoundingMode.CEILING);

			return decimalFormat.format(number);
		}

	}

	static class KBTextDisplayComponent extends TextDisplayComponent {
		private static final long serialVersionUID = 1L;

		public KBTextDisplayComponent(TextDisplayComponent textDisplayComponent) {
			super(textDisplayComponent.getLabel());
			setValue(transformStringCostFormat(textDisplayComponent.getValue()));
		}

	}
		
}
