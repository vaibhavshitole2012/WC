package ext.kb.datautility;

import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import wt.doc.WTDocument;
import wt.doc.WTDocumentMaster;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.log4j.LogR;
import wt.pds.StatementSpec;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.dataUtilities.DefaultDataUtility;
import com.ptc.core.components.rendering.guicomponents.TextDisplayComponent;
import com.ptc.core.lwc.common.view.EnumerationEntryReadView;
import com.ptc.core.lwc.common.view.PropertyValueReadView;
import com.ptc.core.ui.resources.ComponentMode;
import com.ptc.generic.iba.AttributeService;

import ext.kb.util.KBConstants;
import ext.kb.util.KBDocumentUtils;
import ext.kb.util.KBUtils;

public class KBSourceLanguageDataUtility extends DefaultDataUtility {
	
	private static final String CLASSNAME = KBSourceLanguageDataUtility.class.getName();
	protected static final Logger LOGGER = LogR.getLogger(CLASSNAME);

	@Override
	public Object getDataValue(String paramString, Object paramObject, ModelContext paramModelContext) throws WTException {
		if (LOGGER.isDebugEnabled()){
			LOGGER.debug("datautility starts... " + paramString + "-" + paramModelContext.getDescriptorMode().toString());
		}
		Object mainComponent = super.getDataValue(paramString, paramObject, paramModelContext);
        WTDocument doc = null;
        WTDocument docFirstIter = null;
        String languages = "";
        Object paramObj = paramModelContext.getNmCommandBean().getPrimaryOid().getRefObject();
        String revision;
        int iteration;
        String number;
        
		if (paramObj instanceof WTDocument) {
		    doc = (WTDocument) paramObj;
		    iteration = Integer.parseInt(doc.getIterationInfo().getIdentifier().getValue());
		    if (iteration > 0) {
			    revision = doc.getVersionInfo().getIdentifier().getValue();
			    number = (doc.getNumber().substring(0, doc.getNumber().length() - 3) + "000");
			    docFirstIter =	(WTDocument) getDocFirstIter(revision, number);
			    Object tmpValue = AttributeService.getAttribute(docFirstIter, KBConstants.KBLANGUAGE_IBA);
			    if (tmpValue instanceof Object[]){
			    	for (Object l : (Object[]) tmpValue) {
			      		if (!languages.isEmpty()){
			      			languages = languages.concat("/");
			      		}
							languages = languages.concat(l.toString());
						}
			    } else {
			    	languages = (String)tmpValue;
			    }
			 }
		    else {
		    	 Object tmpValue = AttributeService.getAttribute(doc, KBConstants.KBLANGUAGE_IBA);
				    if (tmpValue instanceof Object[]){
				    	for (Object l : (Object[]) tmpValue) {
				      		if (!languages.isEmpty()){
				      			languages = languages.concat("/");
				      		}
								languages = languages.concat(l.toString());
							}
				    } else {
				    	languages = (String)tmpValue;
				    }
		    }
		}
		
        if (LOGGER.isDebugEnabled()){
        	LOGGER.debug("mode: " + paramModelContext.getDescriptorMode().toString() + " languages: " + languages);
        }
       
        if (KBUtils.isDataUtilityRunInOrganization(paramModelContext, KBUtils.HVAC_ORG_NAME)) {
        	//can be mapped with Enumerated values
        	Map<String, EnumerationEntryReadView> globalEnum = KBDocumentUtils.getGlobalEnumeration(KBConstants.DOC_LANGUAGES_ENUMERATION);
        	boolean isValidLanguageValue = isValidLanguageValue(globalEnum, languages);
        	if(!isValidLanguageValue){
        		return mainComponent;
        	}
            if (ComponentMode.VIEW.equals(paramModelContext.getDescriptorMode()) || ComponentMode.EDIT.equals(paramModelContext.getDescriptorMode())) {
            	TextDisplayComponent langComponent = new TextDisplayComponent(paramString);
            	StringBuilder sb = new StringBuilder();
            	if (!StringUtils.isEmpty(languages)){
	            	
	            	for (String value : languages.split("\\/")) {
	            		EnumerationEntryReadView enumValue = globalEnum.get(value);
	            		PropertyValueReadView displayName = enumValue.getPropertyValueByName("displayName");
	            		String displayNameString = displayName.getValueAsString();
						if (sb.length()>0){
							sb.append(", ");
						}
						sb.append(displayNameString);
					}
            	}
            	langComponent.setValue(sb.toString());
            	return langComponent;
            }
        }
        return mainComponent;
	}
		
	private boolean isValidLanguageValue(Map<String, EnumerationEntryReadView> globalEnum, String languages){
    	boolean result = true;
    
    	if(StringUtils.isNotEmpty(languages)){
    		for (String value : languages.split("\\/")) {
        		EnumerationEntryReadView enumValue = globalEnum.get(value);
        		if(enumValue == null){
        			return false;
        		}
        		PropertyValueReadView displayName = enumValue.getPropertyValueByName("displayName");
        		if(displayName == null){
        			return false;
        		}
			}
    	
    	}
    	return result;
    }
	
	private Object getDocFirstIter(String revision, String number) throws WTException{
    	WTDocument docFirstIter = null;
    
    	QuerySpec querySpec = new QuerySpec();
		int indexWTDocument = querySpec.appendClassList(WTDocument.class, true);
		int indexWTDocumentMaster = querySpec.appendClassList(WTDocumentMaster.class, false);
		querySpec.appendWhere(new SearchCondition(WTDocumentMaster.class,"thePersistInfo.theObjectIdentifier.id",WTDocument.class,"masterReference.key.id"),new int[]{indexWTDocumentMaster,indexWTDocument});
		querySpec.appendAnd();
		querySpec.appendWhere(new SearchCondition(WTDocument.class,"versionInfo.identifier.versionId", SearchCondition.EQUAL, revision),new int[]{indexWTDocument});
		querySpec.appendAnd();
		querySpec.appendWhere(new SearchCondition(WTDocument.class,"iterationInfo.identifier.iterationId", SearchCondition.EQUAL, "0"),new int[]{indexWTDocument});
		querySpec.appendAnd();
		querySpec.appendWhere(new SearchCondition(WTDocumentMaster.class,"number", SearchCondition.EQUAL, number),new int[]{indexWTDocumentMaster});
		
		QueryResult queryResult = PersistenceHelper.manager.find((StatementSpec)querySpec);
		
		
		if(queryResult.hasMoreElements()){
			Object[] o = (Object[])queryResult.nextElement();
			docFirstIter = (WTDocument)o[indexWTDocument];
		}
			
    	return docFirstIter;
    }
	
}
