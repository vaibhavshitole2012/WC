package ext.kb.datautility;

import java.util.Iterator;

import org.apache.log4j.Logger;

import wt.doc.WTDocument;
import wt.fc.ObjectReference;
import wt.fc.collections.WTCollection;
import wt.log4j.LogR;
import wt.part.WTPart;
import wt.util.WTException;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.dataUtilities.DefaultDataUtility;
import com.ptc.core.components.rendering.guicomponents.AttributeDisplayCompositeComponent;
import com.ptc.core.components.rendering.guicomponents.NumericDisplayComponent;
import com.ptc.core.components.rendering.guicomponents.TextDisplayComponent;
import com.ptc.generic.dependency.WTCollectorUtilities;
import com.ptc.generic.iba.AttributeService;

public class KBCriticalCharacteristicDataUtility extends DefaultDataUtility {
	
	private static final String CLASSNAME = KBCriticalCharacteristicDataUtility.class.getName();
	protected static final Logger LOGGER = LogR.getLogger(CLASSNAME);

		@Override
		public Object getDataValue(String paramString, Object paramObject,
				ModelContext paramModelContext) throws WTException {
			if (LOGGER.isDebugEnabled()){
				LOGGER.debug("datautility starts... " + paramString + "-" + paramModelContext.getDescriptorMode().toString());
			}
			Object result = super.getDataValue(paramString, paramObject, paramModelContext);
			
			WTCollection docs = WTCollectorUtilities.getWTDocumentsByDescribeLink((WTPart)paramObject);
			if (docs.size()==0){
				return result;
			}
			AttributeDisplayCompositeComponent displComponent = (AttributeDisplayCompositeComponent)  result;
			NumericDisplayComponent vDisplComp = (NumericDisplayComponent) displComponent.getValueDisplayComponent();
			Number maxValue = null;
			
			Iterator docIterator = docs.iterator();
			while(docIterator.hasNext()){
				WTDocument d = (WTDocument)((ObjectReference) docIterator.next()).getObject();
				Object cccValue = AttributeService.getAttribute(d, "KB_NUM_OF_CC");
				if (cccValue != null){
					Long ccc = Long.parseLong(cccValue.toString());
					if (maxValue == null){
						maxValue = Long.parseLong(ccc.toString());
					}
					if (maxValue.longValue() < ccc){
						maxValue = ccc;
					}
				}
			}
			if (maxValue != null){
				vDisplComp.setValue(maxValue);
				displComponent.setValueDisplayComponent(vDisplComp);
			}
			if (LOGGER.isDebugEnabled()){
				LOGGER.debug("datautility ended");
			}
			return result;
		}
	
}
