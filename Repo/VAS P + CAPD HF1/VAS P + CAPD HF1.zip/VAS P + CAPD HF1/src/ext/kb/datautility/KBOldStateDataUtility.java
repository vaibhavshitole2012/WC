package ext.kb.datautility;

import java.util.Set;

import com.ptc.core.components.beans.FormDataHolder;
import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.rendering.AbstractGuiComponent;
import com.ptc.core.components.rendering.guicomponents.TextDisplayComponent;
import com.ptc.core.ui.resources.ComponentMode;
import com.ptc.generic.iba.AttributeService;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import com.ptc.windchill.enterprise.change2.ChangeLinkAttributeHelper;
import com.ptc.windchill.enterprise.change2.beans.ChangeLinkAttributeBean;
import com.ptc.windchill.enterprise.change2.dataUtilities.ChangeLinkAttributeDataUtility;

import ext.kb.workflow.ChangeTaskUtils;
import wt.change2.AffectedActivityData;
import wt.change2.WTChangeActivity2;
import wt.fc.Persistable;
import wt.lifecycle.LifeCycleManaged;
import wt.util.WTException;

public class KBOldStateDataUtility extends ChangeLinkAttributeDataUtility {
	
	@Override
	public Object getDataValue(String componentId, Object datum, ModelContext mc) throws WTException {
		
		if (componentId != null && componentId.endsWith(ChangeLinkAttributeHelper.DATA_POSTFIX)) {
            return super.getDataValue(componentId, datum, mc);
		}
		
		AbstractGuiComponent guiComponent = null;
		WTChangeActivity2 changeActivity = null;
		AffectedActivityData link = null;
		String oldState = null;
		
		ChangeLinkAttributeBean linkBean = ChangeLinkAttributeHelper.getChangeLinkAttributeBean();
		FormDataHolder formData = linkBean.getFormData();
		if (ComponentMode.CREATE.equals(linkBean.getMode()) && datum instanceof LifeCycleManaged) {
			LifeCycleManaged lcManaged = (LifeCycleManaged) datum;
			oldState = lcManaged.getState().getState().getDisplay();
			guiComponent = new TextDisplayComponent(componentId);
			((TextDisplayComponent) guiComponent).setValue(oldState);
			
		} else {
			Persistable object = ((NmCommandBean) formData).getPageOid().getWtRef().getObject();
			
			if (object instanceof WTChangeActivity2) {
				changeActivity = (WTChangeActivity2) object;
			}
			
			if (changeActivity != null) {
				link = getAffectedActivityData(datum, changeActivity);
			}
			
			if (link != null) {
				oldState = AttributeService.getAttribute(link, componentId);
			}
			
			if (ComponentMode.VIEW.equals(linkBean.getMode())) {
				guiComponent = new TextDisplayComponent(componentId);
				((TextDisplayComponent) guiComponent).setValue(oldState);
			}
		}

		if (guiComponent != null) {
			String refCompId = super.getGUIComponentId(componentId, linkBean.getObjectReference(datum));
			guiComponent.setId(refCompId);
			guiComponent.setName(refCompId);
			return guiComponent;
		} else {
			return super.getDataValue(componentId, datum, mc);
		}
	}

	private AffectedActivityData getAffectedActivityData(Object datum, WTChangeActivity2 changeActivity) {
		AffectedActivityData link = null;
		Set<Object> affectedObjects = ChangeTaskUtils.getAffectedObjects(changeActivity, false);
		for (Object o : affectedObjects) {
			AffectedActivityData affected = (AffectedActivityData) o;
			if (affected.getChangeable2().equals(datum)) {
				link = affected;
				break;
			}
		}
		return link;
	}

}
