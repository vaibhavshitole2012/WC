package ext.kb.datautility;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.infoengine.object.factory.Att;
import org.apache.log4j.Logger;

import com.infoengine.object.factory.Element;
import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.dataUtilities.DefaultDataUtility;
import com.ptc.core.components.rendering.guicomponents.AttributeGuiComponent;
import com.ptc.core.components.rendering.guicomponents.PickerInputComponent;
import com.ptc.core.components.rendering.guicomponents.TextDisplayComponent;
import com.ptc.core.lwc.common.view.AttributeDefinitionReadView;
import com.ptc.core.lwc.common.view.ConstraintDefinitionReadView;
import com.ptc.core.lwc.common.view.ConstraintRuleDefinitionReadView;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.container.common.impl.ValueRequiredConstraint;

import ext.kb.dynamiclist.CatalogueContainer;
import ext.kb.dynamiclist.naming.MaterialCatalogueEnumerationInfoProvider;
import ext.kb.util.IBAHelper;
import ext.kb.util.KBConstants;
import ext.kb.util.KBTypeIdProvider;
import ext.kb.util.KBUtils;
import wt.iba.value.IBAHolder;
import wt.util.WTException;

public class KBMaterialDataUtility extends EditArticleAttributesDataUtility {

	private static final Logger LOGGER = Logger.getLogger(KBMaterialDataUtility.class);
	public static final String BASE_WHERE_CLAUSE_VALUE = "((state.state='1050')|(state.state='1080'))";
	public static final String TYPE_COMPONENT_ID_VALUE = "Foundation.materialPickerComponentId";
	public static final String PICKED_ATTRIBUTES_VALUE = "name,number";
	public static final String SEARCH_RESULTS_VIEW_ID_VALUE = "com.ptc.KBMaterial.materialTableView";

	protected static final String PICKER_PROPERTY = "wt.part.materialDynamicListPicker";

	private MaterialCatalogueEnumerationInfoProvider suggestionProvider = new MaterialCatalogueEnumerationInfoProvider();
	private static final String NUMBER = "number";

	@Override
	public Object getDataValueInternal(String paramString, Object paramObject, ModelContext paramModelContext)
			throws WTException {

		Object uiComponent = new DefaultDataUtility().getDataValue(paramString, paramObject, paramModelContext);
		LOGGER.debug("uiComponent: " + uiComponent);

		if (uiComponent instanceof AttributeGuiComponent) {

			AttributeGuiComponent defaultComponent = (AttributeGuiComponent) uiComponent;
			String dynamicListItemPickers = DataUtilityHelper.getProperty(PICKER_PROPERTY);

			TypeIdentifier targetType = wt.type.TypedUtilityServiceHelper.service.getTypeIdentifier(paramObject);
			boolean isArticle = targetType.isDescendedFrom(KBTypeIdProvider.getType("ARTICLE"));
			boolean isCadDoc = targetType.isDescendedFrom(KBTypeIdProvider.getType("CADDOC"));
			boolean isKbDocument = targetType.isDescendedFrom(KBTypeIdProvider.getType("KBDOC"));
			boolean isRefdoc = targetType.isDescendedFrom(KBTypeIdProvider.getType("REFDOC"));

			if (isArticle || isCadDoc || isKbDocument || isRefdoc) {
				if (paramModelContext.getDescriptorMode() == com.ptc.core.ui.resources.ComponentMode.VIEW) {
					return displayNameInsteadOfKey(paramString, paramObject);
				} else {
					if (KBUtils.isEmpty(dynamicListItemPickers)) {
						return TextDisplayComponent.NBSP;
					}
					String[] dynamicPickers = dynamicListItemPickers.split(",");
					AttributeDefinitionReadView rv = IBAHelper.getAttributeDefinitionReadView(targetType.getTypename(),
							KBConstants.KBMATERIAL_IBA);
					Collection<ConstraintDefinitionReadView> rest = rv.getAllConstraints();
					boolean required = false;
					for (ConstraintDefinitionReadView v : rest) {
						ConstraintRuleDefinitionReadView rule = v.getRule();
						if (ValueRequiredConstraint.class.getName().equals(rule.getRuleClassname())) {
							required = true;
							break;
						}
					}

					PickerInputComponent field = new PickerInputComponent(defaultComponent.getColumnName(), "",
							getPickerConfigs(dynamicPickers[0], dynamicPickers[1], required));
					field.setRequired(required);
					field.setColumnName(defaultComponent.getColumnName());
					if (paramModelContext.getDescriptorMode() == com.ptc.core.ui.resources.ComponentMode.EDIT) {
						Object refObject = paramModelContext.getNmCommandBean().getPageOid().getRefObject();
						String ibaId = IBAHelper.getStringIBAValue((IBAHolder) refObject, KBConstants.KBMATERIAL_IBA);
						if (ibaId == null) {
							if (isCadDoc) {
								ibaId = getValueForEdit(paramObject, "CADDOC", KBConstants.KBMATERIAL_IBA);
							} else if (isArticle) {
								ibaId = getValueForEdit(paramObject, "ARTICLE", KBConstants.KBMATERIAL_IBA);
							} else if (isKbDocument) {
								ibaId = getValueForEdit(paramObject, "KBDOC", KBConstants.KBMATERIAL_IBA);
							} else {
								ibaId = getValueForEdit(paramObject, "REFDOC", KBConstants.KBMATERIAL_IBA);
							}
						}
						if (ibaId != null) {
							String translationValue = suggestionProvider.getMaterialNameByKey(ibaId);
							Map<String, String> configs = getPickerConfigs(dynamicPickers[0], dynamicPickers[1],
									required);
							configs.put("defaultValue", translationValue);
							configs.put("defaultHiddenValue", ibaId);
							field = new PickerInputComponent(defaultComponent.getColumnName(), "", configs);
							field.setRequired(required);
							field.setColumnName(defaultComponent.getColumnName());
						}
					}
					defaultComponent = field;
				}
			}
			return defaultComponent;
		} else {
			return uiComponent;

		}

	}

	protected static Map<String, String> getPickerConfigs(String id, String objectType, boolean isRequired) {
		Map<String, String> configs = new HashMap<String, String>();
		configs.put("pickerType", "search");
		if (isRequired)
			configs.put("required", Boolean.TRUE.toString());
		else
			configs.put("required", Boolean.FALSE.toString());
		configs.put("width", "40");
		configs.put("showSuggestion", Boolean.TRUE.toString());
		configs.put("suggestMinChars", "2");
		configs.put("typeComponentId", TYPE_COMPONENT_ID_VALUE);
		configs.put("componentId", "materialPicker");
		configs.put("suggestServiceKey", "materialEntryPicker");
		configs.put("pickerCallback", "materialPickerCallback");
		configs.put("displayAttribute", NUMBER);
		configs.put("pickedAttributes", PICKED_ATTRIBUTES_VALUE);
		configs.put("baseWhereClause", BASE_WHERE_CLAUSE_VALUE);
		configs.put("searchResultsViewId", SEARCH_RESULTS_VIEW_ID_VALUE);
		configs.put("objectType", objectType);
		configs.put("pickerId", id);
		return configs;
	}

	@Override
	public Object getPlainDataValue(String paramString, Object paramObject, ModelContext paramModelContext)
			throws WTException {
		Object defaultComponent = new DefaultDataUtility().getDataValue(paramString, paramObject, paramModelContext);
		if (defaultComponent instanceof AttributeGuiComponent) {

			TypeIdentifier targetType = wt.type.TypedUtilityServiceHelper.service.getTypeIdentifier(paramObject);
			boolean isArticle = targetType.isDescendedFrom(KBTypeIdProvider.getType("ARTICLE"));
			boolean isCadDoc = targetType.isDescendedFrom(KBTypeIdProvider.getType("CADDOC"));
			boolean isKbDocument = targetType.isDescendedFrom(KBTypeIdProvider.getType("KBDOC"));
			boolean isRefdoc = targetType.isDescendedFrom(KBTypeIdProvider.getType("REFDOC"));

			if (isArticle || isCadDoc || isKbDocument || isRefdoc) {
				return displayNameInsteadOfKey(paramString, paramObject);
			}
		}
		return defaultComponent;
	}

	/**
	 * Access was changed from private to public to be reused for Task 209443,
	 * Incident 208809 in
	 * ext.kb.reports.change.KBBrakesDoorsSummaryReportService#updateDisplayValues(wt.fc.Persistable,
	 * java.util.Map)
	 * 
	 * @param paramString
	 * @param paramObject
	 * @return
	 * @throws WTException
	 */
	public Object displayNameInsteadOfKey(String paramString, Object paramObject) throws WTException {
		String materialId = getMaterialId(paramObject);
		String displayValue = materialId;
		if (!KBUtils.isEmpty(materialId)) {
			List<CatalogueContainer> entries = suggestionProvider.loadCatalogue();
			for (CatalogueContainer cont : entries) {
				String key = cont.getKey();
				if (materialId.equals(key)) {
					displayValue = cont.getEn();
					break;
				}
			}
		} else {
			return new TextDisplayComponent("");
		}
		return new TextDisplayComponent(paramString, displayValue);
	}
	
	private String getMaterialId(Object paramObject) throws WTException{
		String ibaValue;
		if (paramObject instanceof Element){
			ibaValue = KBUtils.getStringValueFromElement((Element) paramObject, KBConstants.KBMATERIAL_IBA);
		} else {
			ibaValue = IBAHelper.getStringIBAValue((IBAHolder) paramObject, KBConstants.KBMATERIAL_IBA);
		}
		LOGGER.debug("KB_MATERIAL value: " + ibaValue);
		return ibaValue != null ? ibaValue : "";
	}
}
