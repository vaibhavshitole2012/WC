package ext.kb.datautility;

import com.ptc.core.components.util.OidHelper;
import ext.kb.util.KBConstants;
import org.apache.log4j.Logger;

import wt.doc.WTDocument;
import wt.iba.value.IBAHolder;
import wt.inf.container.WTContainer;
import wt.util.WTException;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.dataUtilities.DefaultDataUtility;
import com.ptc.core.components.rendering.guicomponents.AttributeInputCompositeComponent;
import com.ptc.core.components.rendering.guicomponents.StringInputComponent;
import com.ptc.core.ui.resources.ComponentMode;

import ext.kb.util.IBAHelper;
import ext.kb.util.KBTypeIdProvider;

public class KBProjectIdDataUtility extends DefaultDataUtility {
	private static final Logger LOG = Logger.getLogger(KBProjectIdDataUtility.class);
	
	@Override
	public Object getDataValue(String paramString, Object paramObject,
			ModelContext paramModelContext) throws WTException {
		if (LOG.isDebugEnabled()){
			LOG.debug("datautility starts... " + paramString + "-" + paramModelContext.getDescriptorMode().toString());
		}
		Object result = super.getDataValue(paramString, paramObject, paramModelContext);
		
		if (KBTypeIdProvider.isDescendant(paramObject, KBConstants.KB_DOCUMENT_TYPE) &&
				paramModelContext.getDescriptorMode().equals(ComponentMode.CREATE)){
			AttributeInputCompositeComponent inputComponent = (AttributeInputCompositeComponent)  result;
			StringInputComponent vInputComp = (StringInputComponent) inputComponent.getValueInputComponent();
			String projectId = null;
			WTContainer c = paramModelContext.getNmCommandBean().getContainer();
	        try{ 
	        	projectId = IBAHelper.getStringIBAValue((IBAHolder) c, "KB_PROJECT_ID");
	        	if (LOG.isDebugEnabled()){
	        		LOG.debug("container KB_PROJECT_ID: " + projectId);
	        	}
	        } catch (Exception e){
	        	LOG.error("Cannot get KB_PROJECT_ID of container", e);
	        	throw e;
	        }
			if (projectId != null && projectId.length() > 8){
				projectId = projectId.substring(0, 8);
			}
			if (LOG.isDebugEnabled()){
				LOG.debug("datautility projectId=" + projectId);
			}
			vInputComp.setDefaultValue(projectId);
			inputComponent.setValueInputComponent(vInputComp);
			if (LOG.isDebugEnabled()){
				LOG.debug("datautility defaultValue is set to " + inputComponent.getValueInputComponent().getDefaultValue());
			}
		} else if (KBTypeIdProvider.isDescendant(paramObject, KBConstants.KB_DOCUMENT_TYPE) &&
				paramModelContext.getDescriptorMode().equals(ComponentMode.EDIT)) {
			setEditable(paramObject, result);
		}
		if (LOG.isDebugEnabled()){
			LOG.debug("datautility ended");
		}
		return result;
	}

	private void setEditable(Object paramObject, Object result) throws WTException {
		WTDocument document = (WTDocument) OidHelper.getPersistable(paramObject);
		boolean isAttributeEditable = DataUtilityHelper.shouldBeEditableOnDocument(document);
		DataUtilityHelper.setEditableFieldOnComponent(result, isAttributeEditable);
	}

}
