/**
 * 
 */
package ext.kb.datautility;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.dataUtilities.DefaultDataUtility;
import com.ptc.core.components.rendering.guicomponents.AttributeDisplayCompositeComponent;
import com.ptc.core.components.rendering.guicomponents.AttributeGuiComponent;
import com.ptc.core.components.rendering.guicomponents.AttributeInputComponent;
import com.ptc.core.components.rendering.guicomponents.AttributeInputCompositeComponent;
import com.ptc.core.components.rendering.guicomponents.NumericDisplayComponent;
import com.ptc.core.components.rendering.guicomponents.StringInputComponent;
import com.ptc.core.ui.resources.ComponentMode;

import ext.kb.datautility.KBFloatingPointAttributesDataUtility.KBNumericDisplayComponent;
import ext.kb.ui.validation.KBFloatingPointAttributesProcessorDelegate;
import ext.kb.util.KBUtils;
import wt.session.SessionHelper;
import wt.util.WTException;

/**
 * @author bankowskie
 *
 */
public class KBIREVFillerDataUtility extends EditArticleAttributesDataUtility{
	
	final List<String> HVAC_IREV_VALUES = Arrays.asList(new String[]{"-","000","001","002","003","004","005","006","007","008","009","010","011","012","013","014","015","016","017","018","019","020","021","022","023","024","025","026","027","028","029","030"}); 
	final List<String> OTHER_IREV_VALUES = Arrays.asList(new String[]{"-","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O"}); 
	
	@Override
	public Object getDataValueInternal(String paramString, Object paramObject, ModelContext paramModelContext) throws WTException {
		Object mainComponent = new DefaultDataUtility().getDataValue(paramString, paramObject, paramModelContext);
		ArrayList<String> values = new ArrayList<String>();
		if (KBUtils.isDataUtilityRunInOrganization(paramModelContext, KBUtils.HVAC_ORG_NAME)) {
			values.addAll(HVAC_IREV_VALUES);
		}else{
			values.addAll(OTHER_IREV_VALUES);
		}
		ComponentMode componentMode = paramModelContext.getDescriptorMode();
		if (KBUtils.isCreateMode(componentMode) || KBUtils.isEditMode(componentMode)) {
			AttributeInputCompositeComponent defaultComponent = (AttributeInputCompositeComponent) mainComponent;
			StringInputComponent inputComponent = (StringInputComponent) defaultComponent.getValueInputComponent();
			StringInputComponent outputComponent = new StringInputComponent(inputComponent.getLabel(), values, values);
			outputComponent.setColumnName(inputComponent.getColumnName());
			outputComponent.setComponentHidden(inputComponent.isComponentHidden());
			outputComponent.setDefaultValue(inputComponent.getDefaultValue());
			defaultComponent.setValueInputComponent(outputComponent);
			mainComponent = defaultComponent;
		}
		return mainComponent;
	}
	
}

