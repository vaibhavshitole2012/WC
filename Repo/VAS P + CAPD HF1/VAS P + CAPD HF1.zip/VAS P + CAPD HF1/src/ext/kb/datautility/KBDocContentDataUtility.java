package ext.kb.datautility;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.util.OidHelper;
import ext.kb.util.KBConstants;
import ext.kb.util.KBTypeIdProvider;
import ext.kb.util.KBUtils;
import org.apache.log4j.Logger;
import wt.doc.WTDocument;
import wt.log4j.LogR;
import wt.util.WTException;

public class KBDocContentDataUtility extends AbstractCadDocumentDataUtility{

	private static final String DEFAULT_DOC_CONTENT_FOR_CAD_DRAWING = "ext.kb.cad.document.hvac.default.doc.content.type";
	private static final Logger LOG = LogR.getLogger(KBDocContentDataUtility.class.getName());

	@Override
	public Object getDataValue(String paramString, Object paramObject, ModelContext paramModelContext)
			throws WTException {

		Object customValue = getDataValueInternal(paramString, paramObject, paramModelContext);
		boolean isKBDocument = KBTypeIdProvider.isDescendant(paramObject, KBConstants.KB_DOCUMENT_TYPE);
		boolean isRefDoc = KBTypeIdProvider.isDescendant(paramObject, KBConstants.REFERENCE_DOCUMENT_TYPE);
		boolean isEditMode = KBUtils.isEditMode(paramModelContext.getDescriptorMode());

		if ((isKBDocument || isRefDoc) && isEditMode) {
			WTDocument document = (WTDocument) OidHelper.getPersistable(paramObject);
			boolean isAttributeEditable = DataUtilityHelper.shouldBeEditableOnDocument(document);
			DataUtilityHelper.setEditableFieldOnComponent(customValue, isAttributeEditable);
			LOG.debug(paramString + " on " + document +" can be edited.");
		}

		return customValue;
	}

	@Override
	protected void executeSpecific(Object parentResult, String propertyToSet) {
		//NO need to execute specific logic here
	}

	@Override
	protected String getPropertyNameToLoad() {
		
		return DEFAULT_DOC_CONTENT_FOR_CAD_DRAWING;
	}

	@Override
	protected boolean isDefaultExecutionSufficient() {
	
		return true;
	}

	protected Object getDataValueInternal(String paramString, Object paramObject, ModelContext paramModelContext)
			throws WTException {
		return super.getDataValueInternal(paramString, paramObject, paramModelContext, false);
	}

}
