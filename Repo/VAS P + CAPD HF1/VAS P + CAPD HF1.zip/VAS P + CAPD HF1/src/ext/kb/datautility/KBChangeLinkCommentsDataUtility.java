package ext.kb.datautility;

import wt.util.WTException;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.rendering.guicomponents.TextArea;
import com.ptc.windchill.enterprise.change2.dataUtilities.ChangeLinkAttributeDataUtility;

public class KBChangeLinkCommentsDataUtility extends ChangeLinkAttributeDataUtility {
	@Override
	public Object getDataValue(String name, Object data, ModelContext modelcontext) throws WTException {
		Object dataValue = super.getDataValue(name, data, modelcontext);

		if (dataValue instanceof TextArea) {
			TextArea textArea = (TextArea) dataValue;
			textArea.setHeight(1);
		}

		return dataValue;
	}
}