package ext.kb.datautility;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.ui.resources.ComponentMode;
import com.ptc.windchill.enterprise.change2.ChangeLinkAttributeHelper;
import com.ptc.windchill.enterprise.change2.beans.ChangeLinkAttributeBean;
import com.ptc.windchill.enterprise.change2.dataUtilities.ChangeTransitionDataUtility;
import org.apache.log4j.Logger;
import wt.change2.ChangeRecord2;
import wt.fc.Persistable;
import wt.lifecycle.Transition;
import wt.util.WTException;
import java.util.List;

public class KBChangeTransitionDataUtility extends ChangeTransitionDataUtility {

	private static final Logger logger = Logger.getLogger(KBChangeTransitionDataUtility.class);

	/**
	 * Re-Initializes the map <code>transitionMap</code> holding the resulting
	 * object to change management transitions.
	 *
	 * {@inheritDoc}
	 */
	@Override
	public void setModelData(String componentId, List<?> objects, ModelContext mc) throws WTException {
		super.setModelData(componentId, objects, mc);
		ChangeLinkAttributeBean linkBean = ChangeLinkAttributeHelper.getChangeLinkAttributeBean();
		KBChangeTransitionHelper.updateObjectTransitions(linkBean);
	}

	/**
	 * Required specially for
	 * 1. edit mode after invalid transition was previously saved
	 * 2. create/edit mode after "Set Release Target" action
	 * @param component_id
	 * @param datum
	 * @param linkBean
	 * @return
	 * @throws WTException
	 */
	@Override
	protected Transition getDefaultTransition(String component_id, Object datum, ChangeLinkAttributeBean linkBean) throws WTException {
		Transition defaultTransition = super.getDefaultTransition(component_id, datum, linkBean);
		if (ComponentMode.CREATE.equals(linkBean.getMode()) || ComponentMode.EDIT.equals(linkBean.getMode())) {
			if(datum instanceof ChangeRecord2) {
				ChangeRecord2 cr = (ChangeRecord2)datum;
				datum = (Persistable)cr.getRoleBObject();
			}
			if (!KBChangeTransitionHelper.isValidTransition(defaultTransition, (Persistable) datum, linkBean)) {
				defaultTransition = null;
			}
		}
		return defaultTransition;
	}
}
