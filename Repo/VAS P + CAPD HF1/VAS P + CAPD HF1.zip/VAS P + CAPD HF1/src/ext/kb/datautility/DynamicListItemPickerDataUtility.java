package ext.kb.datautility;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.infoengine.object.factory.Att;
import com.infoengine.object.factory.Element;
import org.apache.log4j.Logger;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.dataUtilities.DefaultDataUtility;
import com.ptc.core.components.rendering.guicomponents.AttributeGuiComponent;
import com.ptc.core.components.rendering.guicomponents.PickerInputComponent;
import com.ptc.core.components.rendering.guicomponents.TextDisplayComponent;
import com.ptc.core.lwc.common.view.AttributeDefinitionReadView;
import com.ptc.core.lwc.common.view.ConstraintDefinitionReadView;
import com.ptc.core.lwc.common.view.ConstraintRuleDefinitionReadView;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.container.common.impl.ValueRequiredConstraint;

import ext.kb.util.IBAHelper;
import ext.kb.util.KBConstants;
import ext.kb.util.KBTypeIdProvider;
import ext.kb.util.KBUtils;
import wt.iba.value.IBAHolder;
import wt.log4j.LogR;
import wt.util.WTException;

public class DynamicListItemPickerDataUtility extends EditArticleAttributesDataUtility {


    protected static final Logger LOGGER = LogR.getLogger(DynamicListItemPickerDataUtility.class.getName());
    
	public static final String BASE_WHERE_CLAUSE_VALUE = "(state.state='1050')";
	public static final String TYPE_COMPONENT_ID_VALUE = "Foundation.geklaPickerComponentId";
	public static final String PICKED_ATTRIBUTES_VALUE = "number";
	public static final String SEARCH_RESULTS_VIEW_ID_VALUE = "com.ptc.KBGeKla.geklaTableView";
    
    protected static final String PICKER_PROPERTY = "wt.part.dynamicListPicker";

    private static final String NUMBER = "number";
//    private static String CONTAINER_REF;
//
//    public DynamicListItemPickerDataUtility() {
//        super();
//        try {
//            ObjectIdentifier oi = (ObjectIdentifier) DBUtils.getCorporateStandardsLibrary().getKey();
//            CONTAINER_REF = oi.getStringValue();
//        } catch (WTException e) {
//            LOGGER.error("Caught exception while setting library reference", e);
//        }
//    }

    @Override
    public Object getDataValueInternal(String paramString, Object paramObject, ModelContext paramModelContext) throws WTException {
        
        Object uiComponent= new DefaultDataUtility().getDataValue(paramString, paramObject, paramModelContext);
        
        LOGGER.debug("uiComponent: "+uiComponent);
        
        if (uiComponent instanceof AttributeGuiComponent){
        
			        AttributeGuiComponent defaultComponent = (AttributeGuiComponent) uiComponent;
			        String dynamicListItemPickers = DataUtilityHelper.getProperty(PICKER_PROPERTY);
			
			        TypeIdentifier targetType = wt.type.TypedUtilityServiceHelper.service.getTypeIdentifier(paramObject);
			        boolean isArticle = targetType.isDescendedFrom(KBTypeIdProvider.getType("ARTICLE"));
			        boolean isNPR = "WCTYPE|com.ptc.windchill.suma.npi.WTPartRequest|com.ptc.KBNPR".equals(targetType.toString());
			        boolean isCadDoc = targetType.isDescendedFrom(KBTypeIdProvider.getType("CADDOC"));
			        if (isArticle || isCadDoc || isNPR) {
			
			            if (paramModelContext.getDescriptorMode() == com.ptc.core.ui.resources.ComponentMode.VIEW) {
			            	String ibaValue = getIbaValue(paramObject);
			                return new TextDisplayComponent(paramString, ibaValue);
			            } else {
			                if (KBUtils.isEmpty(dynamicListItemPickers)) {
			                    return TextDisplayComponent.NBSP;
			                }
			                String[] dynamicPickers = dynamicListItemPickers.split(",");
			                AttributeDefinitionReadView rv = IBAHelper.getAttributeDefinitionReadView(targetType.getTypename(),
			                        KBConstants.GEKLA_IBA);
			                Collection<ConstraintDefinitionReadView> rest = rv.getAllConstraints();
			                boolean required = false;
			                for (ConstraintDefinitionReadView v : rest) {
			                    ConstraintRuleDefinitionReadView rule = v.getRule();
			                    if (ValueRequiredConstraint.class.getName().equals(rule.getRuleClassname())) {
			                        required = true;
			                        break;
			                    }
			                }
			                PickerInputComponent field = new PickerInputComponent(defaultComponent.getColumnName(), "",
			                        getPickerConfigs(dynamicPickers[0], dynamicPickers[1], required));
			                field.setRequired(required);
			                field.setColumnName(defaultComponent.getColumnName());
			                if (paramModelContext.getDescriptorMode() == com.ptc.core.ui.resources.ComponentMode.EDIT) {
			                	if (isCadDoc) {
			                		field.setValue(getValueForEdit(paramObject, "CADDOC", KBConstants.GEKLA_IBA));
			                    } else {
			                    	field.setValue(getValueForEdit(paramObject, "ARTICLE", KBConstants.GEKLA_IBA));
			                    }
			                }

			                defaultComponent = field;
			            }
			        }
			        if (isNPR){
			        	defaultComponent.setLabel("GeKla");	
			        }
			        return defaultComponent;
			      } else {
			      	 return uiComponent;
			      }
    }

    protected static Map<String, String> getPickerConfigs(String id, String objectType, boolean isRequired) {
        Map<String, String> configs = new HashMap<String, String>();
        // default settings
        configs.put("pickerType", "search");
        if (isRequired)
            configs.put("required", Boolean.TRUE.toString());
        else
            configs.put("required", Boolean.FALSE.toString());
        configs.put("width", "40");
        configs.put("showSuggestion", Boolean.TRUE.toString());
        configs.put("suggestMinChars", "2");
        // mapping to mapping settings
        configs.put("typeComponentId", TYPE_COMPONENT_ID_VALUE);
        configs.put("componentId", "gekLaPicker");
        configs.put("suggestServiceKey", "geklaPicker");
        configs.put("pickerCallback", "geklaPickerCallback");
        configs.put("displayAttribute", NUMBER);
        configs.put("pickedAttributes", PICKED_ATTRIBUTES_VALUE);
//        configs.put("containerRef", CONTAINER_REF); some geklas are adhoc acl controlled, providing container will not work.
        configs.put("baseWhereClause", BASE_WHERE_CLAUSE_VALUE);
        configs.put("searchResultsViewId", SEARCH_RESULTS_VIEW_ID_VALUE); 
        // parameter based settings
        configs.put("objectType", objectType);
        configs.put("pickerId", id);
        return configs;
    }

	private String getIbaValue(Object paramObject) throws WTException {
		String ibaValue;
		if (paramObject instanceof Element){
			ibaValue = KBUtils.getStringValueFromElement((Element) paramObject, KBConstants.GEKLA_IBA);
		} else {
			ibaValue = IBAHelper.getStringIBAValue((IBAHolder)paramObject, KBConstants.GEKLA_IBA);
		}
		LOGGER.debug("KB_GEKLA value: " + ibaValue);
		return ibaValue != null ? ibaValue : "";
	}
}
