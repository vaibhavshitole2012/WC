package ext.kb.datautility;

import java.util.List;

import org.apache.commons.lang.StringUtils;

import wt.util.WTException;
import wt.vc.VersionControlHelper;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.dataUtilities.DefaultDataUtility;
import com.ptc.core.ui.resources.ComponentMode;
import com.ptc.netmarkets.util.misc.NmAction;
import com.ptc.windchill.suma.npi.WTPartRequest;

public class KBNPRDataUtility extends DefaultDataUtility {
	
	public Object getDataValue(String paramString, Object paramObject, ModelContext paramModelContext) throws WTException {
		Object result = super.getDataValue(paramString, paramObject, paramModelContext);
		if (ComponentMode.VIEW.equals(paramModelContext.getDescriptorMode())){
			if (result != null && result instanceof List){
				List c = (List) result;
				NmAction selectedAction = null;
				if (c.size() > 0){
					 selectedAction = (NmAction) c.remove(0);
					 while (c.size()>0){
						 NmAction action = (NmAction) c.remove(0);
						 WTPartRequest tmpPartRequest = (WTPartRequest) action.getContextObject().getRefObject();
						 WTPartRequest selectedPartRequest = (WTPartRequest) selectedAction.getContextObject().getRefObject();
						 int versionCompare = tmpPartRequest.getVersionIdentifier().getValue().compareTo(selectedPartRequest.getVersionIdentifier().getValue());
						 int iterationCompare = tmpPartRequest.getIterationIdentifier().getValue().compareTo(selectedPartRequest.getIterationIdentifier().getValue());
						 if (versionCompare>0 ){
							 selectedAction = action;
						 } else {
							 if (versionCompare == 0 && iterationCompare>0 ){
									selectedAction = action;
							 }
						 }
					 }
					 c.add(selectedAction);
				}
			}
		}
		return result;
	}
}

