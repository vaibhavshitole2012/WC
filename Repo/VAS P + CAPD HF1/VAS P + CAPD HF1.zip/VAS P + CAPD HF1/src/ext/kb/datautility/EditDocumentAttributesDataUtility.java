package ext.kb.datautility;

import org.apache.log4j.Logger;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.dataUtilities.DefaultDataUtility;
import com.ptc.core.components.util.OidHelper;

import ext.kb.util.KBConstants;
import ext.kb.util.KBType;
import ext.kb.util.KBTypeIdProvider;
import ext.kb.util.KBUtils;
import wt.doc.WTDocument;
import wt.log4j.LogR;
import wt.util.WTException;

public class EditDocumentAttributesDataUtility extends DefaultDataUtility {

    private static final Logger LOG = LogR.getLogger(EditDocumentAttributesDataUtility.class.getName());
    

    @Override
    public Object getDataValue(String paramString, Object paramObject, ModelContext paramModelContext)
			throws WTException {

		Object customValue = getDataValueInternal(paramString, paramObject, paramModelContext);

		boolean isKBDocument = KBTypeIdProvider.isDescendant(paramObject, KBConstants.KB_DOCUMENT_TYPE);
		boolean isRefDoc = KBTypeIdProvider.isDescendant(paramObject, KBConstants.REFERENCE_DOCUMENT_TYPE);
		boolean isEditMode = KBUtils.isEditMode(paramModelContext.getDescriptorMode());
		boolean isCreateMode = KBUtils.isCreateMode(paramModelContext.getDescriptorMode());
		boolean isViewMode = KBUtils.isViewMode(paramModelContext.getDescriptorMode());

		if ((isKBDocument || isRefDoc) && isEditMode) {
			WTDocument document = (WTDocument) OidHelper.getPersistable(paramObject);
			boolean isAttributeEditable = DataUtilityHelper.shouldBeEditableOnDocument(document);
			DataUtilityHelper.setEditableFieldOnComponent(customValue, isAttributeEditable);
			LOG.debug(paramString + " on " + document + " can be edited.");
		}
		
		// to check if the doc is mentioned type, if yes then check the state of the doc
		// and if >1010 then disable value for editing
		if (!isCreateMode && !isViewMode) {
			Object object = paramModelContext.getNmCommandBean().getPrimaryOid().getRefObject();
			LOG.debug("Getting object from model context. : " + object.getClass());
			if (object instanceof WTDocument
					&& KBType.isOneOfTypes((WTDocument) object, KBUtils.supportedTypesForLeadingLanguage)
					&& paramString.equals(KBConstants.KB_LEADING_LANGUAGE)) {
				WTDocument document = (WTDocument) object;
				boolean isAttributeEditable = DataUtilityHelper.shouldBeEditableOnDocument(document);
				LOG.debug("is Attribute editable ?? : " + isAttributeEditable);
				// execute only if edit mode
				if (KBUtils.isUserAllowedToChangeLeadingLanguage(document)) {
					LOG.debug("User is either admin or data manager. So Leading language is editable");
					DataUtilityHelper.setEditableFieldOnComponent(customValue, true);
				} else {
					DataUtilityHelper.setEditableFieldOnComponent(customValue, isAttributeEditable);
					LOG.debug("User is not admin or data manager.");
				}
			}
		}

		return customValue;
	}

    protected Object getDataValueInternal(String paramString, Object paramObject, ModelContext paramModelContext)
            throws WTException {
        return super.getDataValueInternal(paramString, paramObject, paramModelContext, false);
    }
}
