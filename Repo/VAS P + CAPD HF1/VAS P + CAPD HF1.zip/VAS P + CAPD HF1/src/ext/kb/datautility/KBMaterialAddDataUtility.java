package ext.kb.datautility;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.rendering.AbstractGuiComponent;
import com.ptc.core.components.rendering.RenderingContext;
import com.ptc.core.components.rendering.RenderingException;
import com.ptc.core.components.rendering.guicomponents.AttributeDisplayCompositeComponent;
import com.ptc.core.components.rendering.guicomponents.AttributeInputCompositeComponent;
import com.ptc.core.components.rendering.guicomponents.ComboBox;
import com.ptc.core.components.rendering.guicomponents.TextDisplayComponent;
import com.ptc.core.components.rendering.renderers.ComboBoxRenderer;
import com.ptc.core.components.rendering.renderers.HTMLGuiComponentRenderer;
import com.ptc.generic.iba.AttributeService;
import com.ptc.netmarkets.util.beans.NmCommandBean;

import ext.kb.cache.instance.MaterialCacheManager;
import ext.kb.dynamiclist.CatalogueContainer;
import ext.kb.util.KBUtils;
import wt.inf.container.WTContainer;
import wt.org.WTOrganization;
import wt.util.WTException;

public class KBMaterialAddDataUtility extends EditArticleAttributesDataUtility {

	private static final Logger LOG = Logger.getLogger(KBMaterialAddDataUtility.class);

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.ptc.core.components.factory.dataUtilities.DefaultDataUtility#
	 * getDataValue(java.lang.String, java.lang.Object,
	 * com.ptc.core.components.descriptor.ModelContext)
	 *
	 * In edit or create mode returns a customized ComboBox object that is
	 * populated with materials based on the current context. This ComboBox is
	 * created with a special renderer, that puts the additional HTML title
	 * attribute to the option elements to have the requested tooltip.
	 * 
	 * If the organization is HVAC retrieves the materials from a different
	 * library
	 */
	@Override
	public Object getDataValueInternal(String paramString, Object paramObject, ModelContext paramModelContext)
			throws WTException {

		if (LOG.isDebugEnabled()) {
			LOG.debug("entering getDataValueInternal(String,Object,ModelContext)");
			LOG.debug("paramString: \"" + paramString + "\"");
			LOG.debug("paramObject: " + paramObject);
			LOG.debug("paramModelContext: " + paramModelContext);
		}
		AbstractGuiComponent defaultVal = (AbstractGuiComponent) super.getDataValueInternal(paramString, paramObject,
				paramModelContext);
		LOG.debug("getDataValueInternal - start");
		long time = System.currentTimeMillis();

		if (KBUtils.isEditOrCreateMode(paramModelContext.getDescriptorMode())) {
			String orgName = getOrgName(paramModelContext.getNmCommandBean());

			AttributeInputCompositeComponent tmp = (AttributeInputCompositeComponent) defaultVal;

			MaterialCacheManager matCache = null;
			try {
				matCache = MaterialCacheManager.getCache();
			} catch (RemoteException e) {
				e.printStackTrace();
			}

			List<CatalogueContainer> localMaterials = (List<CatalogueContainer>) matCache.retrieve();
			if (localMaterials == null) {
				localMaterials = new ArrayList<>();
			}
			String selectedId = null;
			if (KBUtils.isEditMode(paramModelContext.getDescriptorMode())) {
				selectedId = AttributeService.getAttribute(
						paramModelContext.getNmCommandBean().getPrimaryOid().getRefObject(), "KB_MATERIAL_ADDITIONAL");
			}

			ComboBox cb = new KBComboBox(localMaterials, selectedId);
			cb.setColumnName(tmp.getColumnName());
			cb.setLocale(tmp.getLocale());
			cb.setLabel(tmp.getLabel());
			cb.setId(tmp.getId());

			defaultVal = cb;
		} else if (KBUtils.isViewMode(paramModelContext.getDescriptorMode())) {
			String materialAdd = AttributeService.getAttribute(paramObject, "KB_MATERIAL_ADDITIONAL");
			String value = KBUtils.convertMaterialNumberName(paramObject, materialAdd);
			if (value != null) {
				LOG.info("value: " + value);
				AttributeDisplayCompositeComponent comp = (AttributeDisplayCompositeComponent) defaultVal;
				TextDisplayComponent textComponent = (TextDisplayComponent) comp.getValueDisplayComponent();
				textComponent.setValue(value);
			}
		}
		long timeEnd = System.currentTimeMillis();
		long timeTaken = timeEnd - time;
		LOG.debug("time" + timeTaken);

		LOG.debug("getDataValueInternal - end");
		if (LOG.isDebugEnabled()) {
			LOG.debug("exiting getDataValueInternal()");
			LOG.debug("returning: " + defaultVal);
		}
		return defaultVal;

	}

	private class KBComboBoxRenderer extends ComboBoxRenderer {

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		private List<CatalogueContainer> items;
		private List<String> selected = new ArrayList<String>();

		public KBComboBoxRenderer(List<CatalogueContainer> items, String selectedId) {
			this.items = items;
			if (!StringUtils.isEmpty(selectedId)) {
				selected.add(selectedId);
			}
		}

		protected String render(Object paramObject, RenderingContext paramRenderingContext) throws RenderingException {

			if (LOG.isDebugEnabled()) {
				LOG.debug("entering render(Object,RenderingContext)");
				LOG.debug("paramObject: " + paramObject);
				LOG.debug("paramRenderingContext: " + paramRenderingContext);
			}
			StringBuilder localStringBuilder = new StringBuilder();
			ComboBox localComboBox = (ComboBox) paramObject;
			try {
				ArrayList localArrayList1 = localComboBox.getValues();

				if (localComboBox.isEnabled()) {

					String comboboxId = localComboBox.getId();

					String str3 = "";
					if (localComboBox.getSize() >= 1) {
						str3 = "size=\"" + localComboBox.getSize() + "\"";
					}

					localStringBuilder.append("<select " + HTMLGuiComponentRenderer.getIdString(comboboxId));
					localStringBuilder.append(str3 + " ");
					localStringBuilder.append(localComboBox.getStyleClasses() + " ");
					localStringBuilder
							.append(getNameStringWithContext(paramRenderingContext, localComboBox, false) + " ");
					localStringBuilder.append(HTMLGuiComponentRenderer.getDisabledString(localComboBox.isEditable()));
					localStringBuilder.append(HTMLGuiComponentRenderer.getTooltipString(localComboBox.getTooltip()));
					localStringBuilder
							.append(HTMLGuiComponentRenderer.getJsActionsString(localComboBox.getJsActions()));
					localStringBuilder.append(">");

					for (CatalogueContainer item : items) {

						String id = item.getKey();
						String optionId = "id_" + id;
						String value = item.getEn();
						String description = item.getDescription();

						localStringBuilder.append("<option " + HTMLGuiComponentRenderer.getIdString(optionId));

						localStringBuilder.append(" title=\"" + encodeForHTMLAttribute(description) + "\"");
						if ((selected.contains(id))) {
							localStringBuilder.append(" selected");
						}

						localStringBuilder.append(" value=\"" + encodeForHTMLAttribute(id) + "\"> ");
						localStringBuilder.append(KBUtils.indent(encodeForHTMLContent(value)));
						localStringBuilder.append(" </option>");
					}
					localStringBuilder.append("</select>");
				} else {
					localArrayList1 = localComboBox.getSelected();
					for (int i = 0; i < localArrayList1.size(); i++) {
						String tmp = (String) localArrayList1.get(i);
						localStringBuilder.append(tmp);
					}
				}
			} catch (Exception localException) {

				throw new RenderingException(localException);
			}

			if (LOG.isDebugEnabled()) {
				LOG.debug("exiting render()");
			}
			return localStringBuilder.toString();

		}

	}

	private class KBComboBox extends ComboBox {

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		public KBComboBox(List<CatalogueContainer> cat, String selectedId) {

			setRenderer(new KBComboBoxRenderer(cat, selectedId));
		}

	}

	private static final String getOrgName(NmCommandBean nmCommandBean) {
		if (LOG.isDebugEnabled()) {
			LOG.debug("entering getOrgName(NmCommandBean)");
			LOG.debug("nmCommandBean: " + nmCommandBean);
		}
		String result = null;
		if (nmCommandBean == null) {
			if (LOG.isDebugEnabled()) {
				LOG.debug("exiting getOrgName()");
				LOG.debug("returning: " + result);
			}
			return result;
		}

		WTContainer cont = null;
		try {
			cont = nmCommandBean.getContainer();
		} catch (WTException e) {
			result = null;
		}

		if (cont == null) {
			if (LOG.isDebugEnabled()) {
				LOG.debug("exiting getOrgName()");
				LOG.debug("returning: " + result);
			}
			return result;
		}
		WTOrganization org = cont.getOrganization();
		if (org == null) {
			if (LOG.isDebugEnabled()) {
				LOG.debug("exiting getOrgName()");
				LOG.debug("returning: " + result);
			}
			return result;
		}

		if (LOG.isDebugEnabled()) {
			LOG.debug("exiting getOrgName()");
		}
		return result = org.getName();
	}

}
