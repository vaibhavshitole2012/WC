package ext.kb.datautility;

import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.ptc.core.components.rendering.GuiComponent;
import com.ptc.core.components.rendering.guicomponents.GUIComponentArray;
import com.ptc.core.components.rendering.guicomponents.RadioButton;

import ext.kb.workflow.WFUtils;
import wt.workflow.engine.WfActivity;

public class KBAnalyzeChangeRequestRoutingChoiceStrategy implements KBRoutingChoiceStrategy {
	
	private WfActivity activity;
	private Object result;
	
	private static final String KB_FFF = "KB_FFF";
	private static final String DEFAULT_CHOICE = "Full Track";
	private static final Logger LOG = Logger.getLogger(KBAnalyzeChangeRequestRoutingChoiceStrategy.class);
	
    /**
     * 
     * @param activity The workflow activity
     * @param result  For instance a GUIComponentArray containing a list of radio buttons from the WF-task page
     */
    public KBAnalyzeChangeRequestRoutingChoiceStrategy(WfActivity activity, Object result) {
    	this.activity = activity;
    	this.result = result;
    }

	@Override
	/**
	 * This method returns the choices a user has in this WF-activity. It must be a list of radio buttons.
	 * One is set to the default option.
	 * @param obj The task result choices
	 * @return Updated task result choices, one of them set as default
	 */
	public Object getRoutingChoice() {
		Boolean isFFF = (Boolean) WFUtils.getWfVariableValue(activity, KB_FFF);
		LOG.debug("FFF = '"+isFFF+"'");

		/*
		 * If Form-Fit-Function is not affected, return the OOTB task options.
		 */
		if(!ObjectUtils.equals(isFFF, Boolean.TRUE)) {
			return result;
		}

		/*
		 * If the options are not presented as radio buttons, return the OOTB task options.
		 */
		if(!(result instanceof GUIComponentArray)) {
			return result;
		}

		/*
		 * FFF affected and options are presented as radio buttons. Set the default.
		 */
		GUIComponentArray guiCompArray = (GUIComponentArray) result;
		for(int i=0; i< guiCompArray.size();i++){
			GuiComponent component = guiCompArray.get(i);
			if(component instanceof RadioButton){
				RadioButton radioBtn = (RadioButton)component;
				if(StringUtils.startsWithIgnoreCase(radioBtn.getValue(), DEFAULT_CHOICE)){
					radioBtn.setChecked(true);
					if(LOG.isDebugEnabled()){
						LOG.debug(DEFAULT_CHOICE+" set as default routing");
					}
				}
			}
		}

		return guiCompArray;
	}

}
