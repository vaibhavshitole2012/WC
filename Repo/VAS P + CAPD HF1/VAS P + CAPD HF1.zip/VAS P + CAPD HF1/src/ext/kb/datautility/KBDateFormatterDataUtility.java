package ext.kb.datautility;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

import wt.util.WTException;
import wt.util.WTProperties;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.dataUtilities.DefaultDataUtility;
import com.ptc.core.components.rendering.guicomponents.AttributeDisplayCompositeComponent;
import com.ptc.core.components.rendering.guicomponents.TextDisplayComponent;
import com.ptc.core.ui.resources.ComponentMode;
import com.ptc.generic.iba.AttributeService;

import ext.kb.util.KBConstants;

public class KBDateFormatterDataUtility extends DefaultDataUtility {
	private static final Logger LOG = Logger.getLogger(KBDateFormatterDataUtility.class);
	
	private static final String DATEFORMATTER_PROPERTY_KEY = "ext.kb.dateformatter.hvac.display.format";

	private String targetFormat;
	
	{
		WTProperties properties = null;
		try {
			properties = WTProperties.getServerProperties();
		} catch (IOException e) {
			LOG.error(String.format("%s could not be read, due to ",DATEFORMATTER_PROPERTY_KEY),e);
		}

		targetFormat = properties.getProperty(DATEFORMATTER_PROPERTY_KEY, KBConstants.DEFAULTDATEFORMAT);
		LOG.info(String.format("Date format on target state 1035 is %s.", DATEFORMATTER_PROPERTY_KEY));
	}
	
	public void setModelData(String paramString, List<?> paramList, ModelContext paramModelContext) throws WTException {
	}

	public Object getDataValue(String paramString, Object paramObject, ModelContext paramModelContext) throws WTException {
		
		AttributeDisplayCompositeComponent comp = (AttributeDisplayCompositeComponent)super.getDataValue(paramString, paramObject, paramModelContext);
		if (!paramModelContext.getDescriptorMode().equals(ComponentMode.VIEW)) {
			return comp;
		}
		
		String dateFormat = AttributeService.getAttribute(paramObject, KBConstants.KB_DATE_FORMAT_IBA);

		if (dateFormat != null && !dateFormat.equals(targetFormat)) {
			SimpleDateFormat attributeDateFormat = new SimpleDateFormat(dateFormat);
			TextDisplayComponent textDispComp = (TextDisplayComponent)comp.getValueDisplayComponent();;
			String value = textDispComp.getValue();
			try {
				Date parsedDate = attributeDateFormat.parse(value);
				SimpleDateFormat targetDateFormat = new SimpleDateFormat(targetFormat);
				textDispComp.setValue(targetDateFormat.format(parsedDate));
				comp.setValueDisplayComponent(textDispComp);
			} catch (ParseException parseException) {
				if (LOG.isDebugEnabled()) {
					LOG.debug("Wrong date for " + paramString
							+ ". Using original value:" + value, parseException);
				}
			}
		}
		
		return comp;
	}
}
