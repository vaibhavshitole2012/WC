package ext.kb.datautility;

import java.util.List;

import wt.util.WTException;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.windchill.enterprise.object.dataUtilities.ConfigLinkSoftAttrDataUtility;

import ext.kb.util.KBUtils;

/**
 * DataUtility to skip log error messages in case the table is empty.
 *
 */
public class EmptyFilteringConfigLinkSoftAttrDataUtility extends ConfigLinkSoftAttrDataUtility {
    
    @Override
    public void setModelData(String paramString, List<?> paramList, ModelContext paramModelContext) throws WTException {
        if (KBUtils.isEmpty(paramList)) {
            return;
          }
        super.setModelData(paramString, paramList, paramModelContext);
    }
}
