package ext.kb.datautility;

import java.io.IOException;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import wt.facade.netmarkets.NetmarketsHref;
import wt.inf.container.WTContainerHelper;
import wt.log4j.LogR;
import wt.org.DirectoryContextProvider;
import wt.org.OrganizationServicesHelper;
import wt.org.WTOrganization;
import wt.org.WTPrincipal;
import wt.org.WTUser;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.util.WTProperties;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.dataUtilities.DefaultDataUtility;
import com.ptc.core.components.rendering.guicomponents.UrlDisplayComponent;
import com.ptc.generic.iba.AttributeService;

import ext.kb.util.KBConstants;
import ext.kb.util.KBUtils;

public class KBPrincipalDatautility extends DefaultDataUtility{

	protected static final Logger LOG = LogR.getLogger(KBPrincipalDatautility.class.getName());
	
	private Set<String> ibaNames = new HashSet<String>();
	private static final String USE_FOR_HVAC_SHORT_NAMES_PROPERTY = "ext.kb.hvac.useForHvacShortNames";
	
	{
		ibaNames.add(KBConstants.KB_VERIFIED_BY_IBA);
		ibaNames.add(KBConstants.KB_RELEASED_BY_IBA);
	}
	
	@Override
	public Object getDataValue(String paramString, Object paramObject, ModelContext paramModelContext)
			throws WTException {
		if (LOG.isDebugEnabled()){
			LOG.debug("starting...");
		}
		if(!KBUtils.isViewMode(paramModelContext.getDescriptorMode())){
			return super.getDataValue(paramString, paramObject, paramModelContext);
		}
		if(!ibaNames.contains(paramString)){
			return super.getDataValue(paramString, paramObject, paramModelContext);
		}
		String ibaValue = AttributeService.getAttribute(paramObject, paramString);
		if (LOG.isDebugEnabled()){
			LOG.debug("ibaValue: " + ibaValue);
		}
		if(StringUtils.isEmpty(ibaValue) || KBConstants.KB_REVISION_REST_VALUE.equals(ibaValue)){
			return super.getDataValue(paramString, paramObject, paramModelContext);
		}
		WTPrincipal principal = OrganizationServicesHelper.manager.findPersistedUser(new String[]{(String)ibaValue}, null, null, null, null, false, false);
		if (principal == null){
			// trying to handle ibaValue as fullname and resolve the principal 
			DirectoryContextProvider contextProvider = WTContainerHelper.service.getExchangeContainer().getContextProvider();
			Enumeration<WTPrincipal> eUsers = OrganizationServicesHelper.manager.findLikeUsers(WTUser.FULL_NAME, ibaValue, contextProvider);
			if (eUsers.hasMoreElements()) {
				principal = eUsers.nextElement();
			}
		}
		if (principal == null){
			// trying to handle ibaValue as shortname and resolve the principal using external mapping file
			// if org is KB or param is set to true (same logic as in SetAttributesListenerDelegate)
			WTProperties wtProp;
			try{
				 wtProp = WTProperties.getServerProperties();
			} catch (IOException e){
				LOG.error("Error getting server properties", e);
				wtProp = new WTProperties(new Properties());
			}
			boolean useForHVACShortNames = Boolean.valueOf(wtProp.getProperty(USE_FOR_HVAC_SHORT_NAMES_PROPERTY,"false")).booleanValue();
			WTOrganization wtOrganization = SessionHelper.manager.getPrincipal().getOrganization();
			if (KBUtils.isKB(wtOrganization) || useForHVACShortNames) {
				try{
					String wcId = KBUtils.getWindchillIdFromUserId(ibaValue);
					principal = OrganizationServicesHelper.manager.findPersistedUser(new String[]{(String)wcId}, null, null, null, null, false, false);
				} catch (IOException e){
					LOG.error("Error getting getting WindchillId from user id", e);
					principal = null;
				}
			}
		}
		if (LOG.isDebugEnabled()){
			LOG.debug("principal: " + principal);
		}
		if (principal == null){
			return super.getDataValue(paramString, paramObject, paramModelContext);
		}
		NetmarketsHref localNetmarketsHref = new NetmarketsHref(principal);
		String href = localNetmarketsHref.getHref();
		UrlDisplayComponent comp = new UrlDisplayComponent(StringUtils.EMPTY,principal.getUniqueDisplayIdentifier(),href);
		if (LOG.isDebugEnabled()){
			LOG.debug("ended.");
		}
		return comp;
	}
}
