package ext.kb.datautility;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.NumberFormat;

import wt.session.SessionHelper;
import wt.util.WTException;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.dataUtilities.DefaultDataUtility;
import com.ptc.core.components.rendering.guicomponents.AttributeDisplayCompositeComponent;
import com.ptc.core.components.rendering.guicomponents.AttributeInputComponent;
import com.ptc.core.components.rendering.guicomponents.AttributeInputCompositeComponent;
import com.ptc.core.components.rendering.guicomponents.NumericDisplayComponent;
import com.ptc.core.ui.resources.ComponentMode;

import ext.kb.ui.validation.KBFloatingPointAttributesProcessorDelegate;
import ext.kb.util.KBUtils;

public class KBFloatingPointAttributesDataUtility extends EditArticleAttributesDataUtility {
	@Override
	public Object getDataValueInternal(String paramString, Object paramObject, ModelContext paramModelContext) throws WTException {
		
		Object mainComponent = new DefaultDataUtility().getDataValue(paramString, paramObject, paramModelContext);

		try {
			if (KBUtils.isDataUtilityRunInOrganization(paramModelContext, KBUtils.HVAC_ORG_NAME)) {
				ComponentMode componentMode = paramModelContext.getDescriptorMode();
				if (KBUtils.isCreateMode(componentMode) || KBUtils.isEditMode(componentMode)) {
					AttributeInputCompositeComponent attributeInputCompositeComponent = (AttributeInputCompositeComponent) mainComponent;

					AttributeInputComponent attributeInputComponent = attributeInputCompositeComponent.getValueInputComponent();

					if (attributeInputComponent != null)
						attributeInputComponent.addHiddenField("FormProcessorDelegate", KBFloatingPointAttributesProcessorDelegate.class.getName());
				} else if (KBUtils.isViewMode(componentMode)) {
					AttributeDisplayCompositeComponent attributeDisplayCompositeComponent = (AttributeDisplayCompositeComponent) mainComponent;

					if (attributeDisplayCompositeComponent.getValueDisplayComponent() instanceof NumericDisplayComponent) {
						NumericDisplayComponent numericDisplayComponent = (NumericDisplayComponent) attributeDisplayCompositeComponent.getValueDisplayComponent();

						KBNumericDisplayComponent kbNumericDisplayComponent = new KBNumericDisplayComponent(numericDisplayComponent);
						attributeDisplayCompositeComponent.setValueDisplayComponent(kbNumericDisplayComponent);
					}
				}
			}
		} catch (Exception exception) {
			exception.printStackTrace();
		}

		return mainComponent;
	}

	static class KBNumericDisplayComponent extends NumericDisplayComponent {
		private static final long serialVersionUID = 1L;

		public KBNumericDisplayComponent(NumericDisplayComponent numericDisplayComponent) {
			super(numericDisplayComponent.getLabel(), numericDisplayComponent.getUnitOfMeasure());

			setValue(numericDisplayComponent.getValue());
		}

		@Override
		public String getDisplayValue() {
			String displayValue;
			if (getValue() != null) {
				try {
					displayValue = truncateDecimal(getValue().doubleValue(), 6);
				} catch (WTException exception) {
					exception.printStackTrace();

					displayValue = " ";
				}
				if (getUnitOfMeasure() != null)
					displayValue = displayValue + " " + getUnitOfMeasure().toString();
			} else {
				displayValue = " ";
			}
			return displayValue;
		}

		public static String truncateDecimal(Double number, int numberofDecimals) throws WTException {
			DecimalFormat decimalFormat = (DecimalFormat) NumberFormat.getNumberInstance(SessionHelper.getLocale());
			decimalFormat.setMinimumFractionDigits(numberofDecimals);
			decimalFormat.setMaximumFractionDigits(numberofDecimals);

			if (number > 0)
				decimalFormat.setRoundingMode(RoundingMode.FLOOR);
			else
				decimalFormat.setRoundingMode(RoundingMode.CEILING);

			return decimalFormat.format(number);
		}

	}
}
