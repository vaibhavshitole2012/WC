package ext.kb.datautility;

public interface KBRoutingChoiceStrategy {
	
	public Object getRoutingChoice();

}
