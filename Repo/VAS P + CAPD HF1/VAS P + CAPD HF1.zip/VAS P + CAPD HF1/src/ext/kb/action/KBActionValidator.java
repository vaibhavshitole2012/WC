package ext.kb.action;

import java.util.Locale;

import org.apache.log4j.Logger;

import wt.fc.Persistable;
import wt.fc.WTReference;
import wt.log4j.LogR;
import wt.util.WTException;
import wt.workflow.engine.WfVariable;
import wt.workflow.work.WfAssignedActivity;
import wt.workflow.work.WorkItem;

import com.ptc.core.ui.validation.DefaultUIComponentValidator;
import com.ptc.core.ui.validation.UIValidationCriteria;
import com.ptc.core.ui.validation.UIValidationKey;
import com.ptc.core.ui.validation.UIValidationResult;
import com.ptc.core.ui.validation.UIValidationResultSet;
import com.ptc.core.ui.validation.UIValidationStatus;

public class KBActionValidator extends DefaultUIComponentValidator {
    private Logger LOG;

    public KBActionValidator() {
        this.LOG = LogR.getLogger(KBActionValidator.class.getName());
    }

    @Override
    public UIValidationResultSet performFullPreValidation(UIValidationKey paramUIValidationKey,
            UIValidationCriteria paramUIValidationCriteria, Locale paramLocale) throws WTException {
        this.LOG.trace("ENTERING KBActionValidator.performFullPreValidation");
        
        this.LOG.trace("  validationKey -> " + paramUIValidationKey);
        this.LOG.trace("  validationCriteria -> " + paramUIValidationCriteria.toString());

        UIValidationStatus localUIValidationStatus = UIValidationStatus.HIDDEN;
        
        UIValidationResultSet localUIValidationResultSet = UIValidationResultSet.newInstance();

        WTReference localWTReference = paramUIValidationCriteria.getContextObject();

        if (localWTReference != null) {
            WorkItem localWorkItem = (WorkItem) localWTReference.getObject();
            Persistable p = localWorkItem.getSource().getObject();
            if (p instanceof WfAssignedActivity) {
                WfAssignedActivity activity = (WfAssignedActivity) p;
                for (WfVariable var : activity.getContext().getVariableList()) {
                    if ("kbrolesetup".equalsIgnoreCase(var.getName())) {
                        Object o = var.getValue();
                        if (o instanceof Boolean) {
                            if ((Boolean) o && !activity.isComplete()) {
                                localUIValidationStatus = UIValidationStatus.ENABLED;
                            }
                        } else {
                            localUIValidationStatus = UIValidationStatus.DISABLED;
                        }
                    }
                }
            }
        }
      
        localUIValidationResultSet.addResult(UIValidationResult.newInstance(paramUIValidationKey, localUIValidationStatus,
                localWTReference));
        this.LOG.trace("RETURNING " + localUIValidationResultSet.toString());
        this.LOG.trace("EXIT KBActionValidators.performFullPreValidation");

        return localUIValidationResultSet;
    }
}
