package ext.kb.associate;

import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import wt.epm.EPMDocument;
import wt.epm.build.EPMBuildRule;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.log4j.LogR;
import wt.part.WTPart;
import wt.util.WTException;

import com.ptc.generic.epm.EPMAssociation;
import com.ptc.generic.epm.StandardEPMAssociateService;

import ext.kb.util.KBConstants;
import ext.kb.util.KBUtils;

public class AssociateUtil {
	private static final Logger LOGGER = LogR.getLogger(AssociateUtil.class.getName());
	
	private static HashMap<String, Integer> buildFlags = new HashMap<String, Integer>();
	
	static {
		//Mapping based on StandardEPMAssociateService.class:
        buildFlags.put(KBConstants.LINKTYPE_OWNER, EPMBuildRule.ALL_BUILD_ROLES);
        buildFlags.put(KBConstants.LINKTYPE_CONTRIBUTING_CONTENT, EPMBuildRule.BUILD_ATTRIBUTES);
        buildFlags.put(KBConstants.LINKTYPE_CONTRIBUTING_IMAGE, EPMBuildRule.CAD_REPRESENTATION + EPMBuildRule.BUILD_ATTRIBUTES);
        buildFlags.put(KBConstants.LINKTYPE_IMAGE, EPMBuildRule.CAD_REPRESENTATION);
        buildFlags.put(KBConstants.LINKTYPE_CONTENT, 0);
    }
	public static void associate(EPMDocument epm, WTPart part, String linktype) throws WTException {
		if (LOGGER.isDebugEnabled()){
			LOGGER.debug("Creating " + linktype + " link between epm:" + epm.getNumber() + " and part:" + part.getNumber() );
		}
		boolean isEbomPart = KBUtils.isEbomPart(part);
		if(!isEbomPart) {
			LOGGER.info("Skipping part as it is MBOM, not EBOM");
			return;
		}
		if (isAlreadyAssociated(epm, part, linktype)){
			return;
		}
		try{
			EPMBuildRule buildRule = EPMBuildRule.newEPMBuildRule(epm, part, buildFlags.get(linktype));
			PersistenceServerHelper.manager.insert(buildRule);
			if (LOGGER.isDebugEnabled()){
				LOGGER.debug("buildrule created between part and CAD");
			}
		} catch (WTException e){
			LOGGER.error("Association failed: "  + linktype + " link between epm:" + epm.getNumber() + " and part:" + part.getNumber() );
			throw e;
		}
	}
	
	public static boolean isAlreadyAssociated(EPMDocument epm, WTPart part, String linktype) throws WTException {
		List<EPMAssociation> associations = StandardEPMAssociateService.newStandardEPMAssociateService().getActiveAssociations(part);
		for (EPMAssociation epmAssociation : associations) {
			EPMDocument epmDoc = epmAssociation.getDoc();
			if (epmDoc.equals(epm) && epmAssociation.getBuildFlags() == buildFlags.get(linktype)){
				return true;
			}
		}
		return false;
	}
	
	public static boolean isAlreadyAssociatedToAnotherPart(EPMDocument epm, WTPart associatedPart, String linktype) throws WTException {
		List<EPMAssociation> associations = StandardEPMAssociateService.newStandardEPMAssociateService().getActiveAssociations(epm);
		for (EPMAssociation epmAssociation : associations) {
			WTPart anotherAssociatedPart = epmAssociation.getPart();
			if (!associatedPart.equals(anotherAssociatedPart) && epmAssociation.getBuildFlags() == buildFlags.get(linktype)){
				return true;
			}
		}
		return false;
	}
	
	public static WTPart getAssociatedPart(EPMDocument epm) {
		if (epm != null) {
			try {
				QueryResult result = PersistenceHelper.manager.navigate(epm, EPMBuildRule.ROLE_BOBJECT_ROLE,
						EPMBuildRule.class, false);
				if (result.hasMoreElements()) {
					EPMBuildRule link = (EPMBuildRule) result.nextElement();
					return (WTPart) link.getRoleBObject();
				}
			} catch (WTException e) {
				LOGGER.debug("Exception while retrieving content part.");
			}
		}
		return null;
	}
	
}
