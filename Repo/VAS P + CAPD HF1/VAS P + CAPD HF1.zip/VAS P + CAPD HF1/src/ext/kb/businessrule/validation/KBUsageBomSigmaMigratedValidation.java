package ext.kb.businessrule.validation;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;

import wt.fc.BinaryLink;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.inf.container.WTContainer;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.part.WTPartUsageLink;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTAttributeNameIfc;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.WTProperties;
import wt.vc.VersionControlHelper;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.core.businessRules.validation.RuleValidationKey;

import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.KBConstants;
import ext.kb.util.KBUtils;

import org.apache.log4j.Logger;

public class KBUsageBomSigmaMigratedValidation extends KBValidation implements PartUsageLinkLogicExecutable {

	private static final Logger logger = Logger.getLogger(KBUsageBomSigmaMigratedValidation.class);
	private static final String VALIDATION_RESULT = "VALIDATION_RESULT";
	private static String incorrectBomProductName = null;

	static {
		WTProperties properties = null;
		try {
			properties = WTProperties.getServerProperties();
		} catch (IOException e) {
			logger.error(String.format("%s could not be read, due to ", KBConstants.INCORRECTBOM_PRODUCT), e);
		}

		incorrectBomProductName = properties.getProperty(KBConstants.INCORRECTBOM_PRODUCT);
		logger.info(KBConstants.INCORRECTBOM_PRODUCT + " is: '" + incorrectBomProductName + "'.");

	}

	/*
	 * Checks if the main Bom has uses link bad product, that is a subBom
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void executeSpecific(WTPartUsageLink link, List<BinaryLink> linksOnSameLevel, 
			RuleValidationKey paramRuleValidationKey) throws WTException {

		if (logger.isDebugEnabled()) {
			logger.debug("entering executeSpecific(WTPartUsageLink,List<BinaryLink>)");
			logger.debug("link: " + link);
			logger.debug("linksOnSameLevel: " + linksOnSameLevel);
		}
		if (StringUtils.isEmpty(incorrectBomProductName)) {
			logger.info(KBConstants.INCORRECTBOM_PRODUCT + " is not set --> skip validation.");
			if (logger.isDebugEnabled()) {
				logger.debug("exiting executeSpecific()");
			}
			return;
		}
		WTPartMaster master = link.getUses();
		WTContainer container = master.getContainer();
		String contextName = container.getName();
		if (StringUtils.equals(contextName, incorrectBomProductName)) {
			QueryResult result = VersionControlHelper.service.allIterationsOf(master);
			if (result.hasMoreElements()) {
				WTPart localPart = (WTPart) result.nextElement();
				long id = PersistenceHelper.getObjectIdentifier(localPart).getId();

				long[] idsToFetch = new long[] { id };
				List<BinaryLink> subLinks = queryAndFetchUsageLinks(idsToFetch);
				if (CollectionUtils.isNotEmpty(subLinks)) {
					String numberOfSubAssy = localPart.getNumber();
					String numberOfMainAssy = link.getUsedBy().getNumber();
					List<RuleFeedbackMessage> validationResult = (List<RuleFeedbackMessage>) paramRuleValidationKey.getProcessingMapValue(VALIDATION_RESULT);
					validationResult.add(new RuleFeedbackMessage(
							new WTMessage(RESOURCE, BusinessRuleRB.KB_USAGEBOM_SIGMA_MIGRATED,
									new String[] { numberOfMainAssy, numberOfSubAssy, incorrectBomProductName }),
							getFeedbackType()));
				}
			}
		}
		if (logger.isDebugEnabled()) {
			logger.debug("exiting executeSpecific()");
		}

	}

	/*
	 * We need to check only one level (non-Javadoc)
	 * 
	 * @see ext.kb.businessrule.validation.PartUsageLinkLogicExecutable#
	 * isOnlyToplevel()
	 */
	public boolean isOnlyToplevel() {

		if (logger.isDebugEnabled()) {
			logger.debug("entering isOnlyToplevel()");
			logger.debug("exiting isOnlyToplevel()");
			logger.debug("returning: " + true);
		}
		return true;
	}

	@Override
	public void executeSpecificPreProcess(List<BinaryLink> links) throws WTException {
		if (logger.isDebugEnabled()) {
			logger.debug("entering executeSpecificPreProcess(List<BinaryLink>)");
			logger.debug("links: " + links);
			logger.debug("exiting executeSpecificPreProcess()");
		}
	}

	@Override
	public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList, RuleValidationKey paramRuleValidationKey) throws WTException {
		if (logger.isDebugEnabled()) {
			logger.debug(
					"entering isRulesValid(Persistable,Map<String,Set<AttributeRuleSet>>,List<RuleFeedbackMessage>)");
			logger.debug("paramPersistable: " + paramPersistable);
			logger.debug("paramMap: " + paramMap);
			logger.debug("paramList: " + paramList);
		}
		boolean success = true;
		BasePartUsageLinkProcessor logicExecutor = new BasePartUsageLinkProcessor(this);
		List<RuleFeedbackMessage> localValidationResult = new ArrayList<>();
		paramRuleValidationKey.addToProcessingMap(VALIDATION_RESULT, localValidationResult);
		if (!(paramPersistable instanceof WTPart)) {
			if (logger.isDebugEnabled()) {
				logger.debug("exiting isRulesValid()");
				logger.debug("returning: " + success);
			}
			return success;
		}
		WTPart part = (WTPart) paramPersistable;
		boolean isEbomPart = KBUtils.isEbomPart(part);
		if(!isEbomPart) {
			logger.info("Found part is MBOM, will not take into account.");
			return success;
		}
		logicExecutor.process(part, paramRuleValidationKey);
		if (!CollectionUtils.isEmpty(localValidationResult)) {
			paramList.addAll(localValidationResult);
			success = false;
		}
		if (logger.isDebugEnabled()) {
			logger.debug("exiting isRulesValid()");
			logger.debug("returning: " + success);
		}
		return success;
	}

	@Override
	public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList) throws WTException {
		return false;
	}
	
	public List<BinaryLink> queryAndFetchUsageLinks(long[] ids) throws WTException{
		QuerySpec qs = new QuerySpec();
		int usageLinkIndex = qs.addClassList(WTPartUsageLink.class, true);
	    int[] indices = new int[] { usageLinkIndex };
	    qs.appendWhere(new SearchCondition(WTPartUsageLink.class, WTAttributeNameIfc.ROLEA_OBJECT_ID, ids), indices);
	    QueryResult qr = PersistenceServerHelper.manager.query(qs);
	    return KBUtils.fetchUsageLinks(qr);
	}

}
