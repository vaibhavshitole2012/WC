package ext.kb.businessrule.validation;

import java.util.List;
import java.util.Map;
import java.util.Set;

import wt.fc.Persistable;
import wt.util.WTException;
import wt.util.WTMessage;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.generic.iba.AttributeService;

import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.KBConstants;

public class KBGivenToCustomerValidation extends KBValidation {

	
	@Override
	public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap, List<RuleFeedbackMessage> paramList) throws WTException {
		String givenToCustomer = AttributeService.getAttribute(paramPersistable, KBConstants.KB_GIVEN_TO_CUSTOMER_IBA);
		boolean result = "1".equals(givenToCustomer) || "2".equals(givenToCustomer);
		if (!result){
			paramList.add(new RuleFeedbackMessage(new WTMessage(RESOURCE, BusinessRuleRB.GIVEN_TO_CUSTOMER, new Object[]{}),
					getFeedbackType()));
		}
		return result;
	}
}
