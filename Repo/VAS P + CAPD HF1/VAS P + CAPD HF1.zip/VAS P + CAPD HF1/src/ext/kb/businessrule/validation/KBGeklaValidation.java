package ext.kb.businessrule.validation;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.ptc.generic.iba.AttributeService;
import ext.kb.util.KBConstants;
import wt.fc.Persistable;
import wt.part.WTPart;
import wt.type.Typed;
import wt.util.WTException;
import wt.util.WTMessage;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;

import ext.kb.accesscontrol.AccessControlHelper;
import org.apache.log4j.Logger;

public class KBGeklaValidation extends KBValidation {

	private static final Logger logger = Logger.getLogger(KBGeklaValidation.class);

	@Override
	public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList) throws WTException {
		if (logger.isDebugEnabled()) {
			logger.debug(
					"entering isRulesValid(Persistable,Map<String,Set<AttributeRuleSet>>,List<RuleFeedbackMessage>)");
			logger.debug("paramPersistable: " + paramPersistable);
			logger.debug("paramMap: " + paramMap);
			logger.debug("paramList: " + paramList);
		}
		Set<String> attributeRuleKeys = paramMap.keySet();

		boolean isRuleValid = true;

		if (logger.isDebugEnabled()) {
			logger.debug("Evaluating attribute rules target object : " + paramPersistable);
		}

		try {
			if(AttributeService.isEmpty(paramPersistable, KBConstants.GEKLA_IBA)){
				paramList.add(new RuleFeedbackMessage(new WTMessage(RESOURCE, "KBGEKLA_MISSING", null), getFeedbackType()));
				return false;
			}
			WTPart gekla = (WTPart) AccessControlHelper.getAuthorizedGekla((Typed) paramPersistable);
			String number = gekla.getNumber();
			for (Iterator<String> ruleKeys = attributeRuleKeys.iterator(); ruleKeys.hasNext();) {
				String str = ruleKeys.next();
				Set<AttributeRuleSet> ruleSet = paramMap.get(str);

				for (AttributeRuleSet attributeRuleSet : ruleSet) {

					logger.debug("Evaluating rule for attribute and value.");
					logger.debug("\nRule: " + attributeRuleSet.toString());
					logger.debug("\nAttribute: " + str);
					if (!AccessControlHelper.isGeklaAuthorized((Typed) paramPersistable) || "XXXX".equals(number)) {
						logger.debug("KBGeklaValidation rule did not pass.");
						paramList.add(new RuleFeedbackMessage(new WTMessage(RESOURCE, "KBGEKLA_MISSING", null),
								getFeedbackType()));
						isRuleValid = false;
					}
				}
			}
		} catch (Exception localException) {
			logger.error("Unexpected error while validating attribute rule.", localException);
			isRuleValid = false;
		}

		if (logger.isDebugEnabled()) {
			logger.debug("All attribute rules passed for target object.");
		}

		if (logger.isDebugEnabled()) {
			logger.debug("exiting isRulesValid()");
			logger.debug("returning: " + isRuleValid);
		}
		return isRuleValid;
	}

}
