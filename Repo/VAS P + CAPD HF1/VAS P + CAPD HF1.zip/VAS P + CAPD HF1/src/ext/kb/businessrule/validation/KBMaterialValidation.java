package ext.kb.businessrule.validation;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.generic.iba.AttributeService;
import ext.kb.businessrule.util.BusinessRuleDao;
import ext.kb.businessrule.util.InfoEngineBusinessRuleDao;
import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.IBAHelper;
import ext.kb.util.KBConstants;
import ext.kb.util.MaterialHelper;
import wt.fc.Persistable;
import wt.part.WTPart;
import wt.util.WTException;
import wt.util.WTMessage;

public class KBMaterialValidation extends KBValidation {

	private static final Logger logger = Logger.getLogger(KBMaterialValidation.class);

	private static final String DYNAMIC_LIST_SEPARATOR = "_";

	private static final String KB = "KB";
	
	private static final List<String> INVALID_PART_CATEGORY_KB = Arrays.asList("3", "5");
	
	private static KBMaterialValidation instance = new KBMaterialValidation();

	private BusinessRuleDao dao;

	private KBMaterialValidation() {
		dao = new InfoEngineBusinessRuleDao();
	}

	public KBMaterialValidation(BusinessRuleDao dao) {
		this.dao = dao;
	}

	public static KBMaterialValidation getInstance() {
		if (logger.isDebugEnabled()) {
			logger.debug("entering getInstance()");
			logger.debug("exiting getInstance()");
			logger.debug("returning: " + instance);
		}
		return instance;
	}

	protected void setDao(BusinessRuleDao dao) {
		if (logger.isDebugEnabled()) {
			logger.debug("entering setDao(BusinessRuleDao)");
			logger.debug("dao: " + dao);
		}
		this.dao = dao;
		if (logger.isDebugEnabled()) {
			logger.debug("exiting setDao()");
		}
	}

	@SuppressWarnings("deprecation")
	public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList) throws WTException {
		if (logger.isDebugEnabled()) {
			logger.debug(
					"entering isRulesValid(Persistable,Map<String,Set<AttributeRuleSet>>,List<RuleFeedbackMessage>)");
			logger.debug("paramPersistable: " + paramPersistable);
			logger.debug("paramMap: " + paramMap);
			logger.debug("paramList: " + paramList);
		}
		Set<String> attributeRuleKeys = paramMap.keySet();
		boolean isRuleValid = true;

		if (logger.isDebugEnabled()) {
			logger.debug("Evaluating attribute rules target object : " + paramPersistable);
		}

		try {
			HashMap<String, Object> attributes = IBAHelper.readIBAs(paramPersistable,
					attributeRuleKeys.toArray(new String[attributeRuleKeys.size()]));

			for (Iterator<String> ruleKeys = attributeRuleKeys.iterator(); ruleKeys.hasNext();) {
				String str = ruleKeys.next();
				Set<AttributeRuleSet> localSet2 = paramMap.get(str);

				for (AttributeRuleSet attributeRuleSet : localSet2) {
					Object localObject = attributes.get(str);

					if (localObject != null) {
						logger.debug("Evaluating rule for attribute and value.");
						logger.debug("\nRule: " + attributeRuleSet.toString());
						logger.debug("\nAttribute: " + str);
						logger.debug("\nValue: " + localObject);

						String obId = (String) localObject;
						if (obId.contains(DYNAMIC_LIST_SEPARATOR)) { // As
																		// dynamicList
																		// can't
																		// handle
																		// :
							// it was replaced with _, needs
							// to be switched back
							obId = obId.replaceAll(DYNAMIC_LIST_SEPARATOR, ":");
						}
						logger.debug("\npartNumber: " + obId);
						WTPart material = MaterialHelper.getMaterial(obId);
						boolean isInvalid  = material == null || KBConstants.INVALID.equalsIgnoreCase(material.getState().toString());
						if (isInvalid) {
							logger.debug("KBMaterialValidation rule did not pass.");
							//obId is a number attribute of obsolete material
							RuleFeedbackMessage errorMessage = getErrorMessage(obId, paramPersistable);
							if(errorMessage != null){
								paramList.add(errorMessage);
								isRuleValid = false;
							}
						}
					} else {
						logger.debug("Skipping check as attribute is not filled.");
					}
				}
			}
		} catch (Exception localException) {
			logger.error("Unexpected error while validating attribute rule.", localException);
			isRuleValid = false;
		}

		if (logger.isDebugEnabled()) {
			logger.debug("All attribute rules passed for target object.");
		}

		if (logger.isDebugEnabled()) {
			logger.debug("exiting isRulesValid()");
			logger.debug("returning: " + isRuleValid);
		}
		return isRuleValid;
	}

	/**
	 * KB Requirement 203620
	 * Add the information about supersedings for obsolete material if any exists
	 * @param number
	 * @return
	 * @throws WTException
	 */
	private RuleFeedbackMessage getErrorMessage(String number, Persistable paramPersistable) {
		RuleFeedbackMessage message = null;
		WTPart material = MaterialHelper.getMaterial(number);
		WTPart part = (WTPart) paramPersistable;
		logger.debug("part number " + part.getNumber());
		logger.debug("part organization " + part.getOrganizationName());
		boolean isKBOrganization = !KB.equalsIgnoreCase(part.getOrganizationName()) ? false : true;
		String partCategory = AttributeService.getAttribute(part, KBConstants.KB_PART_CATEGORY_IBA);
		logger.debug("part category " + partCategory);
		if (material == null) {
			if (!isKBOrganization) {
				return new RuleFeedbackMessage(
						new WTMessage(RESOURCE, BusinessRuleRB.KBMATERIAL_MISSING, new Object[] {}), getFeedbackType());
			}
			if (isKBOrganization && INVALID_PART_CATEGORY_KB.contains(partCategory)) {
				return new RuleFeedbackMessage(
						new WTMessage(RESOURCE, BusinessRuleRB.KBMATERIAL_MISSING, new Object[] {}), getFeedbackType());
			}
		} else {
			Object supersededBy = AttributeService.getAttribute(material, "KB_SUPERSEDED_BY_ALIAS_NAME");
			if (supersededBy == null) {
				return new RuleFeedbackMessage(new WTMessage(RESOURCE, BusinessRuleRB.KBMATERIAL_OBSOLETE,
						new Object[] { material.getName() }), getFeedbackType());
			}
			if (supersededBy instanceof Object[]) {
				supersededBy = StringUtils.join((Object[]) supersededBy, ", ");
			}
			if (logger.isDebugEnabled()) {
				logger.debug(material + " is superseded by " + supersededBy);
			}
			return new RuleFeedbackMessage(new WTMessage(RESOURCE, BusinessRuleRB.KBMATERIAL_MISSING_WITH_SUPERSEDINGS,
					new Object[] { material.getName(), supersededBy }), getFeedbackType());
		}
		return message;
	}
}
