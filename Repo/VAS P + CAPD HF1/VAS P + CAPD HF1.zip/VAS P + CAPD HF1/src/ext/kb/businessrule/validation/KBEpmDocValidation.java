package ext.kb.businessrule.validation;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import ext.kb.util.KBTypeIdProvider;
import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;

import wt.epm.EPMDocument;
import wt.epm.build.EPMBuildRule;
import wt.epm.navigator.CollectItem;
import wt.epm.navigator.EPMNavigateHelper;
import wt.epm.navigator.relationship.CADAssociatedParts;
import wt.epm.structure.EPMDescribeLink;
import wt.fc.Persistable;
import wt.log4j.LogR;
import wt.part.WTPart;
import wt.util.WTException;
import wt.util.WTMessage;
import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.core.businessRules.feedback.RuleFeedbackType;
import com.ptc.generic.iba.AttributeService;
import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.DBUtils;
import ext.kb.util.KBConstants;
import ext.kb.util.KBType;

public class KBEpmDocValidation extends KBValidation {

	protected static final Logger LOG = LogR.getLogger(KBEpmDocValidation.class.getName());

	public KBEpmDocValidation() {
		setFeedbackType(RuleFeedbackType.WARNING);
	}
  
	/*
	 * This method executes 2 constraints on an EPMDocument First it can have
	 * associated parts, when it is not marked as phantom, secondly when it is
	 * of type Drawing it must have associtated parts
	 */
	@Override
	public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList) throws WTException {

		if (LOG.isDebugEnabled()) {
					LOG.debug(
							"entering isRulesValid(Persistable,Map<String,Set<AttributeRuleSet>>,List<RuleFeedbackMessage>)");
					LOG.debug("paramPersistable: " + paramPersistable);
					LOG.debug("paramMap: " + paramMap);
					LOG.debug("paramList: " + paramList);
				}
		boolean isRuleValid = true;

		if (LOG.isDebugEnabled()) {
			LOG.debug("Evaluating attribute rules target object : " + paramPersistable);
		}

		try {

			if (paramPersistable instanceof EPMDocument) {
				EPMDocument doc = (EPMDocument) paramPersistable;
				String organizationName = doc.getOrganizationName();
				Boolean kbPhantom = AttributeService.getAttribute(doc, KBConstants.KB_PHANTOM_IBA);
				boolean isNotPhantom = Boolean.FALSE.equals(kbPhantom);
				List<WTPart> associatedParts = null;
				boolean needToLoadBuildRules = !isNotPhantom;
				boolean is2DCAD = KBType.isOfType(paramPersistable, "com.ptc.DesignCADDrw");
				boolean is3DCAD = KBType.isOfType(paramPersistable, "com.ptc.DesignCADDoc");
				
				if (isNotPhantom && is3DCAD) {

					// References/by tables
					associatedParts = DBUtils.navigateBetweenObjects(WTPart.class, EPMBuildRule.class, doc,
							EPMBuildRule.BUILD_SOURCE_ROLE);
					associatedParts.addAll(DBUtils.navigateBetweenObjects(WTPart.class, EPMBuildRule.class, doc,
							EPMBuildRule.BUILD_TARGET_ROLE));

					associatedParts = associatedParts.stream().filter(part -> KBTypeIdProvider.isDescendant(part,
							KBConstants.ARTICLE_TYPE)).collect(Collectors.toList());

					if (CollectionUtils.isEmpty(associatedParts)) {
						String identity = doc.getIdentity();
						paramList.add(new RuleFeedbackMessage(new WTMessage(RESOURCE,
								BusinessRuleRB.KBCAD_PHANTOM_NO_PART_ASSOCIATED, new Object[] { identity }),
								getFeedbackType()));
						isRuleValid = false;
					}
				}

				if (is2DCAD) {

					if (needToLoadBuildRules) {
						associatedParts = DBUtils.navigateBetweenObjects(WTPart.class, EPMBuildRule.class, doc,
								EPMBuildRule.BUILD_SOURCE_ROLE);
						associatedParts.addAll(DBUtils.navigateBetweenObjects(WTPart.class, EPMBuildRule.class, doc,
								EPMBuildRule.BUILD_TARGET_ROLE));
						associatedParts.addAll(DBUtils.navigateBetweenObjects(WTPart.class, EPMDescribeLink.class, doc,
								EPMDescribeLink.DESCRIBED_BY_ROLE));
						associatedParts.addAll(DBUtils.navigateBetweenObjects(WTPart.class, EPMDescribeLink.class, doc,
								EPMDescribeLink.DESCRIBES_ROLE));
						
						// Calculated links
						associatedParts.addAll(getCalculatedLinks(doc));
					}  
					if (isNotPhantom) {

						if (organizationName.equalsIgnoreCase("HVAC")) {
							associatedParts = DBUtils.navigateBetweenObjects(WTPart.class, EPMDescribeLink.class, doc,
									EPMDescribeLink.DESCRIBED_BY_ROLE);
							associatedParts.addAll(DBUtils.navigateBetweenObjects(WTPart.class, EPMDescribeLink.class,
									doc, EPMDescribeLink.DESCRIBES_ROLE));
							
							// Calculated links
							associatedParts.addAll(getCalculatedLinks(doc));
						} else {
							associatedParts = DBUtils.navigateBetweenObjects(WTPart.class, EPMDescribeLink.class, doc,
									EPMDescribeLink.DESCRIBED_BY_ROLE);
							associatedParts.addAll(DBUtils.navigateBetweenObjects(WTPart.class, EPMDescribeLink.class,
									doc, EPMDescribeLink.DESCRIBES_ROLE));
						}
					}

					associatedParts = associatedParts.stream().filter(part -> KBTypeIdProvider.isDescendant(part,
							KBConstants.ARTICLE_TYPE)).collect(Collectors.toList());

					if (CollectionUtils.isEmpty(associatedParts)) {
						LOG.debug("KBEpmDocValidation rule did not pass.");

						paramList.add(new RuleFeedbackMessage(
								new WTMessage(RESOURCE, BusinessRuleRB.KBCAD_NO_PART_ASSOCIATED, null),
								getFeedbackType()));
						isRuleValid = false;

					} else {
						LOG.trace("Found " + associatedParts.size() + " articles associated with doc :" + doc.getNumber());
					}
				} else {
					LOG.trace("Not correct drawing type for: " + doc.getDocType().toString());
				}
			} else {
				LOG.trace("Not EpmDocument type, skipping for: " + paramPersistable.getClass());
			}

		} catch (Exception localException) {
			LOG.error("Unexpected error while validating attribute rule.", localException);
			isRuleValid = false;
		}

		if (LOG.isDebugEnabled()) {
			LOG.debug("All attribute rules passed for target object.");
			LOG.debug("exiting isRulesValid()");
			LOG.debug("returning: " + isRuleValid);
		}

		return isRuleValid;

	}

	private List<WTPart> getCalculatedLinks(EPMDocument doc) throws WTException {
		List<WTPart> associatedParts = new ArrayList<WTPart>();
		CADAssociatedParts relationship = new CADAssociatedParts();
		relationship.setTypes(CADAssociatedParts.Type.IMPLICIT);
		List<Object[]> parts = EPMNavigateHelper.navigate(doc, relationship, CollectItem.SEED_ID, CollectItem.OTHERSIDE)
				.getRawResults();
		if (parts != null) {
			for (Object[] objects : parts) {
				for (Object o : objects) {
					if (o instanceof WTPart) {
						WTPart tempPart = (WTPart) o;
						associatedParts.add(tempPart);
					}
				}
			}
		}
		return associatedParts;
	}

}
