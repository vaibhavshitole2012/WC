package ext.kb.businessrule.validation;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.core.businessRules.feedback.RuleFeedbackType;
import com.ptc.generic.iba.AttributeService;

import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.DBUtils;
import ext.kb.util.KBConstants;
import ext.kb.util.KBUtils;
import ext.kb.util.ObjectRevisionHelper;
import wt.fc.Persistable;
import wt.identity.IdentityFactory;
import wt.part.WTPart;
import wt.part.WTPartUsageLink;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.util.WTMessage;

public class KBBOMRepairFlagRuleValidator extends KBValidation {

	/**
	 * Validates if given Part has WTPartUsageLinks with all first level BOM
	 * dependencies, which have KB_REPAIR_FLAG attribute set
	 */
	@Override
	public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList) throws WTException {
		if (logger.isDebugEnabled()) {
			logger.debug(
					"entering isRulesValid(Persistable,Map<String,Set<AttributeRuleSet>>,List<RuleFeedbackMessage>)");
			logger.debug("paramPersistable: " + paramPersistable);
			logger.debug("paramMap: " + paramMap);
			logger.debug("paramList: " + paramList);
		}

		boolean result = true;

		if (paramPersistable instanceof WTPart) {
			WTPart part = (WTPart) paramPersistable;
			boolean isEbomPart = KBUtils.isEbomPart(part);
			if(isEbomPart) {
				List<WTPartUsageLink> usageLinks = DBUtils.retrieveLinks(WTPartUsageLink.class, part, WTPartUsageLink.ROLE_BOBJECT_ROLE);
				result = validateRepairFlag(usageLinks);
			}
		}

		if (!result) {
			RuleFeedbackMessage localRuleFeedbackMessage = getErrorFeedbackMessage(paramPersistable,
					getMessageType(paramPersistable));
			paramList.add(localRuleFeedbackMessage);
		}
		if (logger.isDebugEnabled()) {
			logger.debug("validation result: " + result);
		}
		return result;
	}

	/**
	 * Checks if Repair Flag attribute is set on all Usage Links
	 * 
	 * @param usageLinks
	 * @return true if all Usage Links have Repair Flag attribute set, false
	 *         otherwise
	 */
	private boolean validateRepairFlag(List<WTPartUsageLink> usageLinks) {
		boolean result = true;
		for (WTPartUsageLink link : usageLinks) {
			Object repairFlagAttr = AttributeService.getAttribute(link, KBConstants.KB_REPAIR_FLAG);
			if (repairFlagAttr == null || ((String) repairFlagAttr).isEmpty()) {
				result = false;
				break;
			}
		}
		return result;
	}

	/**
	 * Gets message type based on predecessor state
	 * 
	 * @param paramPersistable
	 * @return WARNING is predecessors state was 1030 or higher, ERROR otherwise
	 * @throws WTException
	 */
	private RuleFeedbackType getMessageType(Persistable paramPersistable) throws WTException {
		RuleFeedbackType messageType = RuleFeedbackType.ERROR;
		return messageType;
	}

	private RuleFeedbackMessage getErrorFeedbackMessage(Persistable paramPersistable, RuleFeedbackType feedbackType)
			throws WTException {
		String localizedMessage = IdentityFactory.getDisplayIdentifier(paramPersistable)
				.getLocalizedMessage(SessionHelper.manager.getLocale());
		WTMessage message = new WTMessage(BusinessRuleRB.class.getName(), BusinessRuleRB.KB_BOM_REPAIR_FLAG_ERROR_MSG,
				new Object[] { localizedMessage });
		RuleFeedbackMessage localRuleFeedbackMessage = new RuleFeedbackMessage(message, feedbackType);
		return localRuleFeedbackMessage;
	}

}
