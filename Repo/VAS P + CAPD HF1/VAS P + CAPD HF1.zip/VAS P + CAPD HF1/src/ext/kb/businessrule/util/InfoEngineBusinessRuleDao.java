package ext.kb.businessrule.util;

import java.util.Set;

import org.apache.log4j.Logger;

import ext.kb.dynamiclist.naming.MaterialCatalogueEnumerationInfoProvider;
import wt.log4j.LogR;

public class InfoEngineBusinessRuleDao implements BusinessRuleDao {

	protected static final Logger LOGGER = LogR.getLogger(InfoEngineBusinessRuleDao.class.getName());
	protected static final MaterialCatalogueEnumerationInfoProvider ieProvider = new MaterialCatalogueEnumerationInfoProvider();

	@Override
	public Set<String> getValidMaterials(Object o) {
		Set<String> elements = ieProvider.getMaterialNumbers();
		return elements;

	}

}
