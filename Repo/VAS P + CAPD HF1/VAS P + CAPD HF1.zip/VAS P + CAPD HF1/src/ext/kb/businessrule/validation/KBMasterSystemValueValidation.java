/**
 * 
 */
package ext.kb.businessrule.validation;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import wt.fc.Persistable;
import wt.util.WTException;
import wt.util.WTMessage;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.generic.iba.AttributeService;

import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.KBConstants;
import ext.kb.util.KBTypeIdProvider;

/**
 * @author bankowskie
 *
 */
public class KBMasterSystemValueValidation extends KBValidation {

	private static final String IBA = "KB_MASTERSYSTEM";
    private static final Logger LOGGER = Logger.getLogger(KBMasterSystemValueValidation.class);
	/* (non-Javadoc)
	 * @see ext.kb.businessrule.validation.KBValidation#isRulesValid(wt.fc.Persistable, java.util.Map, java.util.List)
	 */
	@Override
	public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList) throws WTException {
		boolean isArticle = KBTypeIdProvider.isDescendant(paramPersistable, "ARTICLE");
		boolean isKbDoc = KBTypeIdProvider.isDescendant(paramPersistable, "KBDOC");
		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("Is article? "+isArticle+", is kb doc? "+isKbDoc);
		}
		if(isArticle || isKbDoc){
			String masterSystem  = AttributeService.getAttribute(paramPersistable, IBA);
			if(LOGGER.isDebugEnabled()){
				LOGGER.debug("Got mastersystem value: "+masterSystem);
			}
			if(masterSystem!=null && !masterSystem.equals(KBConstants.WNC_MASTERSYSTEM)){
				  paramList.add(new RuleFeedbackMessage(new WTMessage(RESOURCE, BusinessRuleRB.WRONG_MASTERSYSTEM, null), getFeedbackType()));
					if(LOGGER.isDebugEnabled()){
						LOGGER.debug("Invalid mastersystem value");
					}
				return false;
			}
		}
		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("Valid mastersystem value or not article/kbdocument");
		}
		return true;
	}

}

