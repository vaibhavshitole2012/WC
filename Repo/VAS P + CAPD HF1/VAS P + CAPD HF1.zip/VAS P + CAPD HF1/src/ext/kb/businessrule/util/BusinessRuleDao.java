package ext.kb.businessrule.util;

import java.util.Set;

public interface BusinessRuleDao {

    public Set<String> getValidMaterials(Object o);

}
