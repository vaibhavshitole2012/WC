package ext.kb.businessrule.validation;

import com.ptc.core.businessRules.feedback.RuleFeedbackType;

public class KBEpmDocErrorValidation extends KBEpmDocValidation{

	public KBEpmDocErrorValidation(){
		setFeedbackType(RuleFeedbackType.ERROR);
	}
}
