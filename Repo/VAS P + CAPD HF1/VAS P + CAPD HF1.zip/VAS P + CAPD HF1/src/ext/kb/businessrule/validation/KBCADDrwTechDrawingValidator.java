package ext.kb.businessrule.validation;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.core.businessRules.feedback.RuleFeedbackType;
import com.ptc.core.businessRules.validation.RuleValidationKey;
import com.ptc.core.meta.common.TypeIdentifierHelper;

import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.DBUtils;
import ext.kb.util.KBConstants;
import ext.kb.util.KBTypeIdProvider;
import ext.kb.util.ObjectRevisionHelper;
import ext.kb.workflow.EPMChangeUtils;
import wt.doc.WTDocument;
import wt.epm.EPMDocument;
import wt.epm.build.EPMBuildRule;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.part.WTPart;
import wt.representation.PublishedContentLink;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.WTProperties;

public class KBCADDrwTechDrawingValidator extends KBValidation {

	private static final Logger logger = Logger.getLogger(KBCADDrwTechDrawingValidator.class);
	private static final String VALIDATION_RESULT = "VALIDATION_RESULT";
	static String contList = "";

	static {
		try {
			WTProperties wtproperties = WTProperties.getLocalProperties();
			contList = wtproperties.getProperty("ext.workflow.standardWorkerProducts", "");
		} catch (Exception wte) {
			wte.printStackTrace();
		}
	}

	@Override
	public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList, RuleValidationKey paramRuleValidationKey) throws WTException {

		boolean result = true;
		boolean validationNeeded = true;
		boolean docType = false;
		boolean docVersion = false;

		List<RuleFeedbackMessage> localValidationResult = new ArrayList<>();
		paramRuleValidationKey.addToProcessingMap(VALIDATION_RESULT, localValidationResult);
		if (paramPersistable instanceof EPMDocument) {
			EPMDocument epmDoc = (EPMDocument) paramPersistable;
			if ((epmDoc.getDocType().toString()).equals("CADDRAWING")) {
				String[] aconList = contList.split("\\|");
				logger.debug("aconList size : " + aconList.length);
				String conName = epmDoc.getContainer().getName();
				logger.debug("Container Name : " + conName);
				for (int i = 0; i < aconList.length; i++) {
					logger.debug("Container name from proeprty : " + aconList[i]);
					if (aconList[i].equals(conName)) {
						validationNeeded = false;
					}
				}
				logger.debug("validationNeeded : " + validationNeeded);
				Boolean kbPhantom = false;
				kbPhantom = ext.kb.util.IBAHelper.readIBA(epmDoc, KBConstants.KB_PHANTOM_IBA);
				logger.debug("kbPhantom : " + kbPhantom);
				if (validationNeeded && (kbPhantom!=null && !kbPhantom)) {
					
					List<WTDocument> relatedDocs = getPublishedData(epmDoc);
					logger.debug("List size : "+relatedDocs.size());
					
					if(relatedDocs.size()<=0){
						docType = false;
					}
					
					for (WTDocument wtDoc : relatedDocs) {
						docType = true;
						logger.debug("WTDocument : " + wtDoc.getNumber());
						String doctype = TypeIdentifierHelper.getType(wtDoc).getTypename();
						logger.debug("Document Type : " + doctype);
						
							String epmDocRevision = epmDoc.getVersionIdentifier().getValue();
							String epmDocState = epmDoc.getState().getState().getStringValue();
							logger.debug("EPMDocument state : " + epmDocRevision + " " + epmDocState);
							String wtDocRevision = wtDoc.getVersionIdentifier().getValue();
							String wtDocState = wtDoc.getState().getState().getStringValue();
							logger.debug("WTDocument state : " + wtDocRevision + " " + wtDocState);
							if (wtDocRevision.equals(epmDocRevision) && wtDocState.equals(epmDocState)) {
								docVersion = true;
							}
						
						if(docVersion){
							break;
						}
					}
					
					if (!docType) {
						RuleFeedbackType feedbackType = RuleFeedbackType.ERROR;
						List<RuleFeedbackMessage> validationResult = (List<RuleFeedbackMessage>) paramRuleValidationKey
								.getProcessingMapValue(VALIDATION_RESULT);
						validationResult.add(new RuleFeedbackMessage(new WTMessage(RESOURCE,
								BusinessRuleRB.NO_NEUTRAL_DATA, new String[] { epmDoc.getNumber() }), feedbackType));

					} else if (docType && !docVersion) {
						RuleFeedbackType feedbackType = RuleFeedbackType.ERROR;
						List<RuleFeedbackMessage> validationResult = (List<RuleFeedbackMessage>) paramRuleValidationKey
								.getProcessingMapValue(VALIDATION_RESULT);
						validationResult.add(new RuleFeedbackMessage(new WTMessage(RESOURCE,
								BusinessRuleRB.STATE_NEUTRAL_DATA, new String[] { epmDoc.getNumber() }), feedbackType));
					}
				}
			}
		}
		if (!CollectionUtils.isEmpty(localValidationResult)) {
			paramList.addAll(localValidationResult);
			result = false;
		}
		return result;
	}

	@Override
	public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList) throws WTException {

		return false;
	}
	
	public static List getPublishedData(EPMDocument document) throws WTException {
		List<WTDocument> relatedDocs = new ArrayList<WTDocument>();
		relatedDocs.addAll(DBUtils.navigateBetweenObjects(WTDocument.class, PublishedContentLink.class, document,
				PublishedContentLink.ALL_ROLES));
		logger.debug("relatedDocs size : "+relatedDocs.size());
		List<WTDocument> neutralDocs = new ArrayList<WTDocument>();
		for (WTDocument doc : relatedDocs) {
			String doctype = TypeIdentifierHelper.getType(doc).getTypename();
			logger.debug("Document Type : " + doctype);
			if (doctype.contains("com.ptc.KBNeutralData")) {
				neutralDocs.add(doc);
			}
		}
		
		return neutralDocs;
	}

}
