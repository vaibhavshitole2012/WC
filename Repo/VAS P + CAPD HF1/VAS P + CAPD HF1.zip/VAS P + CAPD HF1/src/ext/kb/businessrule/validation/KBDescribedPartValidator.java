package ext.kb.businessrule.validation;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.core.businessRules.feedback.RuleFeedbackType;
import com.ptc.core.businessRules.validation.RuleValidationCriteria;
import com.ptc.core.businessRules.validation.RuleValidationKey;
import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.KBType;
import ext.kb.util.KBUtils;
import ext.kb.util.ObjectRevisionHelper;
import ext.kb.workflow.ChangeTaskUtils;
import org.apache.log4j.Logger;
import wt.change2.WTChangeActivity2;
import wt.doc.WTDocument;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.part.WTPart;
import wt.part.WTPartHelper;
import wt.util.WTException;
import wt.util.WTMessage;

import java.util.*;

public class KBDescribedPartValidator extends KBValidation {

    private static final String TECHNICAL_DRAWING = "com.ptc.KBTechnicalDrawing";
    private static final List<String> ALLOWED_STATES;
    private static final String Technical_DOCUMENT = "com.ptc.KBTechnicalDocument";
    private static final Logger LOG = Logger.getLogger(KBDescribedPartValidator.class);

    static {
        ALLOWED_STATES = Arrays.asList("1030", "1035", "1045", "1050", "1058", "1060", "1070");
    }

    @Override
    public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap, List<RuleFeedbackMessage> paramList, RuleValidationKey validationKey) throws WTException {
        boolean isRuleValid;
        if (!KBType.isOneOfTypes(paramPersistable, Technical_DOCUMENT, TECHNICAL_DRAWING)) {
            return true;
        }
        Set<WTPart> describesWTParts = getDescribesWTParts((WTDocument) paramPersistable);
        LOG.debug("describesWTParts:  " + describesWTParts);
        WTChangeActivity2 ect = (WTChangeActivity2) validationKey.getProcessingMapValue(ECT);
        validateObjects(paramList, describesWTParts, ect);
        Persistable predecessor = ObjectRevisionHelper.getPreviousVersionLatestIteration(paramPersistable);
        if (predecessor != null && paramList.isEmpty()) {
            Set<WTPart> describesWTPartsPredecessor = getDescribesWTParts((WTDocument) predecessor);
            validateObjects(paramList, describesWTPartsPredecessor, ect);
            LOG.debug("predecessor validated:  " + KBUtils.getObjectNumber(predecessor));
            LOG.debug("describesWTPartsPredecessor:  " + describesWTPartsPredecessor);
        }
        isRuleValid = paramList.isEmpty();
        LOG.debug("validated object:  " + KBUtils.getObjectNumber(paramPersistable));
        LOG.debug("exiting isRulesValid, returning " + isRuleValid);
        LOG.debug("paramList:  " + paramList);
        return isRuleValid;
    }

    private void validateObjects(List<RuleFeedbackMessage> paramList, Set<WTPart> describesWTParts, WTChangeActivity2 ect) throws WTException {
        for (WTPart part : describesWTParts) {
            if (!isValidPart(part, ect)) {
                paramList.add(getWarningMessage());
                return;
            }
        }
    }

    private boolean isValidPart(WTPart part, WTChangeActivity2 ect) throws WTException {
        LOG.debug("validated part:  " + part.getNumber());
        WTPart previousRevision = (WTPart) ObjectRevisionHelper.getPreviousVersionLatestIteration(part);
        boolean isReleasedState = isReleasedState(part);
        boolean isReleasedStatePreviousRevision = false;
        if (previousRevision != null) {
            isReleasedStatePreviousRevision = isReleasedState(previousRevision);
        }
        if (isReleasedState || isReleasedStatePreviousRevision) {
            LOG.debug("isReleasedState  " + isReleasedState);
            LOG.debug("isReleasedStatePreviousRevision  " + isReleasedStatePreviousRevision);
            return isAffectedObject(part, ect);
        }
        return true;
    }

    private boolean isAffectedObject(WTPart describedPart, WTChangeActivity2 ect) {
        Set<Object> affectedObjects = ChangeTaskUtils.getAffectedObjects(ect, true);
        for (Object object : affectedObjects)
            if (object instanceof WTPart) {
                WTPart affectedPart = (WTPart) object;
                if (affectedPart.getNumber().equalsIgnoreCase(describedPart.getNumber())) {
                    LOG.debug("Part exists as affected Object  " + describedPart.getNumber());
                    return true;
                }
            }
        LOG.debug("Part doesn't exist as affected Object  " + describedPart.getNumber());
        return false;
    }

    private boolean isReleasedState(WTPart part) {
        return ALLOWED_STATES.contains(part.getState().toString());
    }

    private RuleFeedbackMessage getWarningMessage() {
        return new RuleFeedbackMessage(new WTMessage(RESOURCE, BusinessRuleRB.KB_DESCRIBED_PART_RULE, null), getFeedbackType());
    }

    private Set<WTPart> getDescribesWTParts(WTDocument paramPersistable) throws WTException {
        Set<WTPart> describesWTPartsSet = new HashSet<>();
        QueryResult describesWTParts = WTPartHelper.service.getDescribesWTParts(paramPersistable);

        while (describesWTParts.hasMoreElements()) {
            Persistable persistable = (Persistable) describesWTParts.nextElement();
            WTPart part = (WTPart) (persistable);
            describesWTPartsSet.add(part);
        }
        return describesWTPartsSet;
    }

    @Override
    public void prepareForValidation(RuleValidationKey validationKey, RuleValidationCriteria paramRuleValidationCriteria) {
        if (logger.isDebugEnabled()) {
            logger.debug("entering prepareForValidation(RuleValidationKey,RuleValidationCriteria)");
            logger.debug("arg0: " + validationKey);
            logger.debug("paramRuleValidationCriteria: " + paramRuleValidationCriteria);
        }
        validationKey.addToProcessingMap(ECT, paramRuleValidationCriteria.getPrimaryBusinessObject());
        if (logger.isDebugEnabled()) {
            logger.debug("exiting prepareForValidation()");
        }
    }

    @Override
    public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap, List<RuleFeedbackMessage> paramList) throws WTException {
        return false;
    }

    public KBDescribedPartValidator() {
        setFeedbackType(RuleFeedbackType.WARNING);
    }
}
