package ext.kb.businessrule.validation;

import java.util.List;
import java.util.Map;
import java.util.Set;
import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.windchill.suma.axl.AXLContext;
import com.ptc.windchill.suma.axl.AXLHelper;
import com.ptc.windchill.suma.jca.util.SumaJcaHelper;
import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.KBType;
import wt.fc.Persistable;
import wt.fc.collections.WTArrayList;
import wt.inf.container.OrgContainer;
import wt.inf.container.WTContainerHelper;
import wt.org.WTOrganization;
import wt.part.WTPart;
import wt.util.WTException;
import wt.util.WTMessage;

public class KBCommercialPartPreReleaseValidator extends KBValidation{
	

	@Override
	public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList) throws WTException {
		boolean result = true;
		boolean isComercialPart = KBType.isDescendedFrom(paramPersistable, "com.ptc.KBCommercial");
		if (isComercialPart) {
			WTArrayList amlPartsList = getAMLParts(paramPersistable);
			if (amlPartsList.isEmpty()) {
				paramList.add(getErrorFeedbackMessage(BusinessRuleRB.COMMERCCIAL_PART_RULE_ERROR_MSG));
				result = false;
			} 
		}
		return result;
	}

	/**
	 * Returns list of related AML Parts
	 * @param paramPersistable - associated part
	 * @return list of related AML Parts
	 */
	private WTArrayList getAMLParts(Persistable paramPersistable) throws WTException {
		WTPart oePart = (WTPart) paramPersistable;
		WTOrganization oemOrganization = oePart.getOrganization();
		OrgContainer orgContainer = WTContainerHelper.service.getOrgContainer(oemOrganization);
		AXLContext defaultSourcingContext = SumaJcaHelper.getDefaultSourcingContext(orgContainer);
		return new WTArrayList(AXLHelper.service.getAML(oePart, defaultSourcingContext));
	}

	/**
	 * Method, which return the error message for the current business rule
	 * @param message - message
	 * @return the error message
	 */
	private RuleFeedbackMessage getErrorFeedbackMessage(String message) {
		WTMessage wtMessage = new WTMessage(RESOURCE, message, null);
		return new RuleFeedbackMessage(wtMessage, getFeedbackType());
	}

}
