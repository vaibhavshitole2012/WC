package ext.kb.businessrule.validation;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.core.businessRules.validation.RuleValidationKey;

import ext.kb.util.KBConstants;
import ext.kb.util.KBUtils;
import ext.kb.util.ObjectRevisionHelper;
import wt.fc.Persistable;
import wt.lifecycle.State;
import wt.part.WTPart;
import wt.util.WTException;

public class KBLatestOrLatestReleasedArticleValidator extends KBLatestVersionValidation {
	
	@Override
	public boolean isRulesValid(Persistable persistable, Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList, RuleValidationKey paramRuleValidationKey) throws WTException {
		boolean result = true;
		boolean isWTPart = persistable instanceof WTPart;
		if(isWTPart && !KBUtils.isEbomPart((WTPart) persistable)) {
			return result;
		}	
		boolean isLatest = super.isRulesValid(persistable, paramMap, paramList, paramRuleValidationKey);
		if (!isLatest && isWTPart) {
			Persistable latestVersion = ObjectRevisionHelper.getLatestVersionByPersistable(persistable);
			Set<State> states = new HashSet<>();
			states.add(KBConstants.PRE_SERIES_RELEASED_STATE);
			states.add(KBConstants.RELEASED_STATE);
			states.add(KBConstants.SALES_BLOCK_STATE);
			states.add(KBConstants.ORDER_BLOCK_STATE);
			Persistable latestReleased = ObjectRevisionHelper.getLatestReleasedVersionWithStates(latestVersion, states);
			
			if (!persistable.equals(latestReleased)) {
				result = false;
			} else {
				paramList.clear();
			}
			
		}
		return result;
	}

}
