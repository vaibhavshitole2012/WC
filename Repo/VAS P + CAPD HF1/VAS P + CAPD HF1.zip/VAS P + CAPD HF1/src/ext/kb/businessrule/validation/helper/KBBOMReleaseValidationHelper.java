package ext.kb.businessrule.validation.helper;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.core.businessRules.feedback.RuleFeedbackType;
import com.ptc.core.businessRules.validation.RuleValidationKey;

import ext.kb.businessrule.util.KBBusinessRuleUtil;
import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.KBDocumentUtils;
import ext.kb.util.KBUtils;
import ext.kb.util.ObjectRevisionHelper;
import wt.change2.ChangeRecord2;
import wt.doc.WTDocument;
import wt.enterprise.RevisionControlled;
import wt.epm.EPMDocument;
import wt.identity.IdentityFactory;
import wt.lifecycle.State;
import wt.log4j.LogR;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.util.WTException;
import wt.util.WTMessage;

public class KBBOMReleaseValidationHelper {

	private static final Logger LOG = LogR.getLogger(KBBOMReleaseValidationHelper.class.getName());
	
	private Map<String,EPMDocument> resultingCadDocsByNumber = new HashMap<>();

	public void prepareForValidation(RuleValidationKey ruleValidationKey) {
		Map<Object,State> targetStatesByResultingObject = (Map)ruleValidationKey.getProcessingMapValue("TARGET_STATES_MAP");
		filterCadDocsAndFillMapByNumber(targetStatesByResultingObject);
	}

	private void filterCadDocsAndFillMapByNumber(Map<Object,State> targetStatesByResObjects){
		resultingCadDocsByNumber.clear();
		for(Object resultingObject : targetStatesByResObjects.keySet()){
			fillMapByNumberIfCad(resultingObject);
		}
	}

	private void fillMapByNumberIfCad(Object resultingObject){
		if(KBDocumentUtils.isCadDocOrCadDrawing(resultingObject)){
			EPMDocument resultingCad = (EPMDocument)resultingObject;
			resultingCadDocsByNumber.put(resultingCad.getNumber(), resultingCad);
		}
	}
	
	public String constructDisplayIdentity(RevisionControlled rc) {
		StringBuilder sb = new StringBuilder();
		String identity = rc.getIdentity();
		if(!StringUtils.isEmpty(identity)){
			sb.append(identity);
		}
		Locale locale = KBUtils.getCurrentLocale();
		String objectType = IdentityFactory.getDisplayType(rc).getLocalizedMessage(locale);
		sb.insert(0,objectType+" ");
		return sb.toString();
	}
	
	public boolean cadDocWithSameNumberExists(WTDocument techDrawing){
		String techDrwNumber = techDrawing.getNumber();
		EPMDocument cadWithSameNumber = resultingCadDocsByNumber.get(techDrwNumber);
		return (cadWithSameNumber != null);
	}
	
	public static RuleFeedbackMessage validateChangeContext(Set<State> validStates, Set<State> invalidStates,
			ChangeRecord2 cr, RuleFeedbackMessage error, String objectnumber) {
		if (LOG.isDebugEnabled()) {
			LOG.debug("Component's latest iteration is IN the Change Context");
		}
		String targetTransition = "";
		if (cr.getTargetTransition() != null) {
			targetTransition = cr.getTargetTransition().toString();
		}
		if (targetTransition.isEmpty()
				|| !KBBusinessRuleUtil.isStateValid(targetTransition, validStates, invalidStates)) {
			error = new RuleFeedbackMessage(new WTMessage(BusinessRuleRB.class.getName(),
					BusinessRuleRB.KB_CHILD_INVALID_TARGET_STATE, new Object[] { objectnumber, targetTransition }),
					RuleFeedbackType.ERROR);
		}
		return error;
	}
	
	public static RuleFeedbackMessage validateOutsideChangeContext(Set<State> validStates, Set<State> invalidStates,
			WTPart componentLatestIteration, RuleFeedbackMessage error, String objectnumber) throws WTException {
		if (LOG.isDebugEnabled()) {
			LOG.debug("Component's latest iteration is NOT in the Change Context");
		}
		RevisionControlled predecessor = (RevisionControlled) ObjectRevisionHelper
				.getPreviousVersionLatestIteration(componentLatestIteration);
		
		if (componentLatestIteration.getState().toString().compareTo("1020") <= 0 && predecessor != null) {
			
			
			if (!KBBusinessRuleUtil.isStateValid(predecessor.getState().toString(), validStates, invalidStates)) {
				error = new RuleFeedbackMessage(new WTMessage(BusinessRuleRB.class.getName(),
						BusinessRuleRB.KB_REVISIONS_INVALID_STATE,
						new Object[] { objectnumber, componentLatestIteration.getState().toString(),
								predecessor.getVersionDisplayIdentifier(), predecessor.getState().toString() }),
						RuleFeedbackType.ERROR);
			}
		} else {
			
			if (!KBBusinessRuleUtil.isStateValid(componentLatestIteration.getState().toString(), validStates,
					invalidStates)) {
				error = new RuleFeedbackMessage(
						new WTMessage(BusinessRuleRB.class.getName(), BusinessRuleRB.KB_CHILD_INVALID_STATE,
								new Object[] { objectnumber, componentLatestIteration.getState().toString() }),
						RuleFeedbackType.ERROR);
			}
		}
		return error;
	}

	public static RuleFeedbackMessage validateChangeContextForSubstitute(Set<State> validStates,
			Set<State> invalidStates, ChangeRecord2 cr, RuleFeedbackMessage error, String objectnumber, WTPartMaster childMaster) {
		if (LOG.isDebugEnabled()) {
			LOG.debug("Component's latest iteration is IN the Change Context");
		}
		String targetTransition = "";
		if (cr.getTargetTransition() != null) {
			targetTransition = cr.getTargetTransition().toString();
		}
		if (targetTransition.isEmpty()
				|| !KBBusinessRuleUtil.isStateValid(targetTransition, validStates, invalidStates)) {
			error = new RuleFeedbackMessage(new WTMessage(BusinessRuleRB.class.getName(),
					BusinessRuleRB.KB_SUBSTITUTE_INVALID_TARGET_STATE, new Object[] { objectnumber, childMaster.getNumber(), targetTransition }),
					RuleFeedbackType.ERROR);
		}
		return error;
	}

	public static RuleFeedbackMessage validateOutsideChangeContextForSubstitute(Set<State> validStates,
			Set<State> invalidStates, WTPart subPart, RuleFeedbackMessage error, String objectnumber, WTPartMaster childMaster) throws WTException {
		if (LOG.isDebugEnabled()) {
			LOG.debug("Component's latest iteration is NOT in the Change Context");
		}
		RevisionControlled predecessor = (RevisionControlled) ObjectRevisionHelper
				.getPreviousVersionLatestIteration(subPart);
		
		if (subPart.getState().toString().compareTo("1020") <= 0 && predecessor != null) {
			
			
			if (!KBBusinessRuleUtil.isStateValid(predecessor.getState().toString(), validStates, invalidStates)) {
				error = new RuleFeedbackMessage(new WTMessage(BusinessRuleRB.class.getName(),
						BusinessRuleRB.KB_SUBSTITUTE_INVALID_STATE,
						new Object[] { objectnumber, childMaster.getNumber(), subPart.getState().toString(),
								predecessor.getVersionDisplayIdentifier(), predecessor.getState().toString() }),
						RuleFeedbackType.ERROR);
			}
		} else {
			
			if (!KBBusinessRuleUtil.isStateValid(subPart.getState().toString(), validStates,
					invalidStates)) {
				error = new RuleFeedbackMessage(
						new WTMessage(BusinessRuleRB.class.getName(), BusinessRuleRB.KB_SUB_INVALID_STATE,
								new Object[] { objectnumber,childMaster.getNumber(), subPart.getState().toString() }),
						RuleFeedbackType.ERROR);
			}
		}
		return error;
	}

}
