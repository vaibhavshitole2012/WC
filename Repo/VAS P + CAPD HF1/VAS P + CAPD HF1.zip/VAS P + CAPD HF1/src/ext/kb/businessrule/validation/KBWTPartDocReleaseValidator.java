package ext.kb.businessrule.validation;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.core.businessRules.validation.RuleValidationKey;
import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.KBUtils;
import wt.enterprise.RevisionControlled;
import wt.fc.Persistable;
import wt.util.WTException;

public class KBWTPartDocReleaseValidator extends KBWTPartDocPreReleaseValidator {

	@Override
	public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList, RuleValidationKey validationKey) throws WTException {
		if (logger.isDebugEnabled()) {
			logger.debug(
					"entering isRulesValid(Persistable,Map<String,Set<AttributeRuleSet>>,List<RuleFeedbackMessage>)");
			logger.debug("paramPersistable: " + paramPersistable);
			logger.debug("paramMap: " + paramMap);
			logger.debug("paramList: " + paramList);
		}
		
		boolean result = super.isRulesValid(paramPersistable, paramMap, paramList, validationKey);
		ArrayList<RuleFeedbackMessage> ruleFeedbackMessages = (ArrayList<RuleFeedbackMessage>) validationKey.getProcessingMapValue(FEEDBACKMESSAGES);
		List<Persistable> docsInSameECN = (List<Persistable>) validationKey.getProcessingMapValue(DOCSINSAMEECN);
		
		if (ruleFeedbackMessages.isEmpty()) {
			validateDocCurrentState(docsInSameECN, ruleFeedbackMessages);
			if (!ruleFeedbackMessages.isEmpty()) {
				for (RuleFeedbackMessage message : ruleFeedbackMessages) {
					paramList.add(message);
				}
				ruleFeedbackMessages.clear();
				result = false;
			}
		}

		return result;
	}

	private void validateDocCurrentState(List<Persistable> docsInSameECN, ArrayList<RuleFeedbackMessage> ruleFeedbackMessages) throws WTException {
		if (docsInSameECN == null) {
			return;
		}
		for (Persistable doc : docsInSameECN) {
			if (!isDocumentValidForCheck(doc)) {
				continue;
			}
			String stateStr = KBUtils.getKBStateNumericValueString((RevisionControlled) doc);
			try {
				int stateInt = Integer.parseInt(stateStr);
				if (stateInt < 1020) {
					ruleFeedbackMessages.add(getErrorFeedbackMessage(doc, BusinessRuleRB.KB_WTPART_DOC_ERROR_MSG));
				}
			} catch (NumberFormatException ex) {
				logger.error(ex.getLocalizedMessage());
			}
		}
	}
}
