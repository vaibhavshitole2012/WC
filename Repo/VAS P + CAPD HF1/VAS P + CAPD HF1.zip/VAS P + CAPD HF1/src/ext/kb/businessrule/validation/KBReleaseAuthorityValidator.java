package ext.kb.businessrule.validation;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import wt.change2.ChangeActivity2;
import wt.change2.ChangeException2;
import wt.change2.ChangeHelper2;
import wt.change2.ChangeRecord2;
import wt.change2.WTChangeActivity2;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.identity.IdentityFactory;
import wt.inf.container.WTContained;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerHelper;
import wt.inf.container.WTContainerRef;
import wt.org.DirectoryContextProvider;
import wt.org.OrganizationServicesHelper;
import wt.org.WTGroup;
import wt.org.WTPrincipalReference;
import wt.team.Team;
import wt.util.WTException;
import wt.util.WTMessage;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.core.businessRules.feedback.RuleFeedbackType;
import com.ptc.core.businessRules.validation.RuleValidationCriteria;
import com.ptc.core.businessRules.validation.RuleValidationKey;
import com.ptc.core.businessRules.validation.RuleValidationObject;
import com.ptc.core.businessRules.validation.RuleValidationResult;
import com.ptc.generic.iba.AttributeService;

import ext.kb.util.KBConstants;
import ext.kb.util.KBTypeIdProvider;
import ext.kb.util.KBUtils;
import ext.kb.workflow.ChangeTaskUtils;

public class KBReleaseAuthorityValidator extends KBValidation {

	private static final String ECTCONTAINER2 = "ECTCONTAINER";
	private static final String RESULTINGCONTAINERSVALIDATIONMESSAGES = "resultingContainersValidationMessages";
	private static final Logger logger = Logger.getLogger(KBReleaseAuthorityValidator.class);

	/*
	 * Validates if the current resulting object(paramPersistable) is in the
	 * same context as in the ECN was created. If not a new feddbackMessage is
	 * created
	 */
	@Override
	public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList, RuleValidationKey validationKey) throws WTException {
		if (logger.isDebugEnabled()) {
			logger.debug(
					"entering isRulesValid(Persistable,Map<String,Set<AttributeRuleSet>>,List<RuleFeedbackMessage>)");
			logger.debug("paramPersistable: " + paramPersistable);
			logger.debug("paramMap: " + paramMap);
			logger.debug("paramList: " + paramList);
		}
		boolean success = true;
		if (paramPersistable instanceof WTContained) {
			WTContained contained = (WTContained) paramPersistable;
			WTContainer container = contained.getContainer();
			String resultingObjectContName = container == null ? null : container.getName();
			String identity = IdentityFactory.getDisplayIdentifier((Persistable) paramPersistable).getLocalizedMessage(Locale.ENGLISH);
			WTContainer ectContainer = (WTContainer) validationKey.getProcessingMapValue(ECTCONTAINER2);
			boolean theSameContext = isTheSameContext(resultingObjectContName, ectContainer);
			if (!theSameContext) {
				boolean areAttributesEqual = areAttributesEqual(container, ectContainer);
				if (!areAttributesEqual) {
					success = false;
					WTMessage message = new WTMessage("ext.kb.resources.BusinessRuleRB",
							"KB_RELEASE_AUTHORITY_ERROR_MSG", new Object[] { resultingObjectContName });
					RuleFeedbackMessage localRuleFeedbackMessage = new RuleFeedbackMessage(message,
							getFeedbackType());
					paramList.add(localRuleFeedbackMessage);
				} else  {
					success = false;
					WTMessage message = new WTMessage("ext.kb.resources.BusinessRuleRB",
							"KB_RELEASE_AUTHORITY_RESULTING_OBJ_WARNING_MSG", new Object[] {identity});
					RuleFeedbackMessage localRuleFeedbackMessage = new RuleFeedbackMessage(message,
							RuleFeedbackType.WARNING);
					paramList.add(localRuleFeedbackMessage);
				}
			}
		}
		if (logger.isDebugEnabled()) {
			logger.debug("exiting isRulesValid()");
			logger.debug("returning: " + success);
		}
		return success;
	}
	
	@Override
	public RuleValidationResult performValidation(RuleValidationKey paramRuleValidationKey,
			RuleValidationObject paramRuleValidationObject, RuleValidationCriteria paramRuleValidationCriteria)
			throws WTException {
		if (logger.isDebugEnabled()) {
			logger.debug("entering performValidation(RuleValidationKey,RuleValidationObject,RuleValidationCriteria)");
			logger.debug("paramRuleValidationKey: " + paramRuleValidationKey);
			logger.debug("paramRuleValidationObject: " + paramRuleValidationObject);
			logger.debug("paramRuleValidationCriteria: " + paramRuleValidationCriteria);
		}
		RuleValidationResult result = super.performValidation(paramRuleValidationKey, paramRuleValidationObject,
				paramRuleValidationCriteria);
		
		ArrayList<RuleFeedbackMessage> resultingContainersValidationMessages = (ArrayList<RuleFeedbackMessage>) paramRuleValidationKey.getProcessingMapValue(RESULTINGCONTAINERSVALIDATIONMESSAGES);
		
		if (resultingContainersValidationMessages.size()>0){
			while (resultingContainersValidationMessages.size()>0){
				result.addFeedbackMessage(resultingContainersValidationMessages.remove(0));
			}
		}
		return result;
	}
	
	/*
	 * Sets the context name, in which the ECT was created, and processes the Resulting Objects
	 */
	@Override
	public void prepareForValidation(RuleValidationKey validationKey, RuleValidationCriteria paramRuleValidationCriteria)
			throws WTException {
		if (logger.isDebugEnabled()) {
			logger.debug("entering prepareForValidation(RuleValidationKey,RuleValidationCriteria)");
			logger.debug("arg0: " + validationKey);
			logger.debug("paramRuleValidationCriteria: " + paramRuleValidationCriteria);
			logger.debug("BR context: " + validationKey.getBusinessRule().getContainer().getName());
			logger.debug("RuleValidationCriteria context: " + paramRuleValidationCriteria.getContainerRef().getName());
		}
		WTChangeActivity2 changeActivity = (WTChangeActivity2) paramRuleValidationCriteria.getPrimaryBusinessObject();
		validationKey.addToProcessingMap(ECTCONTAINER2, changeActivity.getContainer());
		selectFeedbackType((Team) changeActivity.getTeamId().getObject());
		checkResultObjectContainerType(validationKey, changeActivity);
		if (logger.isDebugEnabled()) {
			logger.debug("exiting prepareForValidation()");
		}
	}
	
	

	private void checkResultObjectContainerType(RuleValidationKey validationKey, WTChangeActivity2 changeActivity) throws WTException {
		Set<Object> changeRecords = ChangeTaskUtils.getResultingObjects(changeActivity, false);
		HashMap<WTContained, WTContainer> resultingMap = new HashMap<WTContained, WTContainer>();
		//KB_TYPE_PROJECTPDM = com.ptc.KB_PDMProject_OEM
		ArrayList<RuleFeedbackMessage> resultingContainersValidationMessages = new ArrayList<RuleFeedbackMessage>();
		HashSet<WTContainer> tmpContainers = new HashSet<WTContainer>();
		for (Object object : changeRecords) {
			ChangeRecord2 changeRecord = (ChangeRecord2) object;
			WTContained resultingObject = (WTContained) changeRecord.getChangeable2();
			WTContainer resultingObjectContainer = WTContainerHelper.getContainer((WTContained) resultingObject);
			resultingMap.put(resultingObject, resultingObjectContainer);
			tmpContainers.add(resultingObjectContainer);
		}
		for (WTContained resultingObject : resultingMap.keySet()) {
			WTContainer resultingObjectContainer = resultingMap.get(resultingObject);
			if (KBTypeIdProvider.isDescendant(resultingObjectContainer, "PROJECTPDM")){
				tmpContainers.remove(resultingObjectContainer);
				if (tmpContainers.size()>0){
					WTMessage message = new WTMessage("ext.kb.resources.BusinessRuleRB",
							"KB_RELEASE_AUTHORITY_RESULTING_OBJ_NOT_AUTH_ERROR", new Object[] {});
					RuleFeedbackMessage localRuleFeedbackMessage = new RuleFeedbackMessage(message,
							RuleFeedbackType.ERROR);
					resultingContainersValidationMessages.add(localRuleFeedbackMessage);
				}
			}
		}
		validationKey.addToProcessingMap(RESULTINGCONTAINERSVALIDATIONMESSAGES, resultingContainersValidationMessages);
	}

	private void selectFeedbackType(Team ectTeam) throws WTException {
		// all the members of the Assignee role in the team of the ECT are member of the site group "Central Data Management".
		Map rolePrincipalMap = ectTeam.getRolePrincipalMap();
		DirectoryContextProvider ctxProvider = WTContainerHelper.getExchangeRef().getReferencedContainer().getContextProvider();
		WTGroup cdmWtGroup = OrganizationServicesHelper.manager.getGroup("CENTRAL DATA MANAGEMENT", ctxProvider);
		
		List<WTPrincipalReference>  assignees = (List<WTPrincipalReference>) rolePrincipalMap.get(KBConstants.ASSIGNEE_ROLE);
		if (logger.isDebugEnabled()){
			logger.debug("assignees from rolePrincipalMap:" + assignees);
		}
		if (logger.isDebugEnabled()) {
			logger.debug("feedback set to WARNING");
		}
		setFeedbackType(RuleFeedbackType.WARNING);
		for (WTPrincipalReference wtPrincipalReference : assignees) {
			if (!cdmWtGroup.isMember(wtPrincipalReference.getPrincipal())) {
				if (logger.isDebugEnabled()) {
					logger.debug("assignee(" + wtPrincipalReference.getUniqueDisplayIdentifier() + ") is NOT member of CDM group");
					logger.debug("feedback set to ERROR");
				}
				setFeedbackType(RuleFeedbackType.ERROR);
			} else {
				if (logger.isDebugEnabled()) {
					logger.debug("assignee(" + wtPrincipalReference.getUniqueDisplayIdentifier() + ") is member of CDM group");
				}
			}
		}
	}
	
	public static boolean isTheSameContext(String tmpContName, WTContainer parentContainer) {
		if (logger.isDebugEnabled()) {
			logger.debug("entering isTheSameContext(String,WTContainer)");
			logger.debug("tmpContName: \"" + tmpContName + "\"");
			logger.debug("parentContainer: " + parentContainer);
			logger.debug("exiting isTheSameContext()");
		}
		boolean result = StringUtils.equals(tmpContName, parentContainer.getName());
		if (logger.isDebugEnabled()) {
			logger.debug("exiting isTheSameContext()");
			logger.debug("returning: " + result);
		}
		return result;
	}

	public static boolean areAttributesEqual(WTContainer affObjContainer, WTContainer parentContainer) {
		if (logger.isDebugEnabled()) {
			logger.debug("entering areAttributesEqual(WTContainer,WTContainer)");
			logger.debug("affObjContainer: " + affObjContainer);
			logger.debug("parentContainer: " + parentContainer);
		}
		String affectedCOC = AttributeService.getAttribute(affObjContainer, "KB_COC");
		String affectedDepartment = AttributeService.getAttribute(affObjContainer, "KB_DEPARTMENT");
		String affectedLocation = AttributeService.getAttribute(affObjContainer, "KB_LOCATION");
		String parentCOC = AttributeService.getAttribute(parentContainer, "KB_COC");
		String parentDepartment = AttributeService.getAttribute(parentContainer, "KB_DEPARTMENT");
		String parentLocation = AttributeService.getAttribute(parentContainer, "KB_LOCATION");
		if (KBUtils.isEmpty(affectedCOC) || KBUtils.isEmpty(affectedDepartment) || KBUtils.isEmpty(affectedLocation)
				|| KBUtils.isEmpty(parentCOC) || KBUtils.isEmpty(parentDepartment) || KBUtils.isEmpty(parentLocation)) {
			if (logger.isDebugEnabled()) {
				logger.debug("exiting areAttributesEqual()");
				logger.debug("returning: " + false);
			}
			return false;
		}
		boolean isCOCEqual = StringUtils.equals(affectedCOC, parentCOC);
		boolean isDepartmentEqual = StringUtils.equals(affectedDepartment, parentDepartment);
		boolean isLocationEqual = StringUtils.equals(affectedLocation, parentLocation);
		if (logger.isDebugEnabled()) {
			logger.debug("exiting areAttributesEqual()");
			logger.debug("returning: " + (isCOCEqual && isDepartmentEqual && isLocationEqual));
		}
		return isCOCEqual && isDepartmentEqual && isLocationEqual;
	}

	@Override
	public boolean isRulesValid(Persistable paramPersistable,
			Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList) throws WTException {
		// TODO Auto-generated method stub
		return false;
	}
}
