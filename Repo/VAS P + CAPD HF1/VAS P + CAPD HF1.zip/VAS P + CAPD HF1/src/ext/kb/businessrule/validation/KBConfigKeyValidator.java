package ext.kb.businessrule.validation;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.core.businessRules.feedback.RuleFeedbackType;
import com.ptc.core.businessRules.validation.RuleValidationKey;
import com.ptc.generic.iba.AttributeService;

import ext.kb.resources.BusinessRuleRB;
import wt.fc.Persistable;
import wt.part.WTPart;
import wt.util.WTException;
import wt.util.WTMessage;

public class KBConfigKeyValidator extends KBValidation {

	private static final String CONFIG_KEY_IBA = "defaultTraceCode";
	private static final String CONFIG_KEY_UNSPECIFIED = "X";

	@Override
	public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList, RuleValidationKey validationKey) throws WTException {
		boolean success = true;

		if (paramPersistable instanceof WTPart) {
			Object configKey = AttributeService.getAttribute(paramPersistable, CONFIG_KEY_IBA);
			if (CONFIG_KEY_UNSPECIFIED.equals(configKey)) {
				WTMessage message = new WTMessage(RESOURCE, BusinessRuleRB.KB_CONFIG_KEY_RULE_NOT_DEFINED, new Object[] {});
				RuleFeedbackMessage localRuleFeedbackMessage = new RuleFeedbackMessage(message, RuleFeedbackType.ERROR);
				paramList.add(localRuleFeedbackMessage);
				success = false;
			}
		}

		return success;
	}

	@Override
	public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList) throws WTException {
		return false;
	}

}
