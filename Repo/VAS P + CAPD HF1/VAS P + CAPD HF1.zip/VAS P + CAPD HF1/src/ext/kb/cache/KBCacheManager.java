package ext.kb.cache;

import java.rmi.RemoteException;
import java.util.List;

import wt.cache.CacheManager;

public abstract class KBCacheManager extends CacheManager {

	private static final long serialVersionUID = 7801836033479457041L;
	protected final String key;
	
	public KBCacheManager(String key) throws RemoteException {
		super();
		this.key = key;
	}

	protected void store(List<?> list){
		super.put(key, list);
	}
	
	public List<?> retrieve(){
		return (List<?>) super.get(key);
	}
	
	protected void store(String key, Object object){
		super.put(key, object);
	}
	
	protected Object retrieve(String key){
		return super.get(key);
	}
}
