package ext.kb.cache.instance;

import java.rmi.RemoteException;
import java.util.List;

import ext.kb.cache.KBCacheManager;
import ext.kb.dynamiclist.infoengine.PermissionControlledInfoEngineEnumerationInfoProvider;

public class GeklaCacheManager extends KBCacheManager {

	private static final long serialVersionUID = -543871992221249175L;
	private static final String KEY = "GEKLA_ID";
	private static final String KEY_INFO_PROVIDER = "GEKLA_ID_INFO_PROVIDER";
	private static GeklaCacheManager instance = null;

	public PermissionControlledInfoEngineEnumerationInfoProvider getPermissionControlledInfoEngineEnumerationInfoProvider() {
		return (PermissionControlledInfoEngineEnumerationInfoProvider) retrieve(KEY_INFO_PROVIDER);
	}

	public void setPermissionControlledInfoEngineEnumerationInfoProvider(
			PermissionControlledInfoEngineEnumerationInfoProvider permissionControlledInfoEngineEnumerationInfoProvider) {
		store(KEY_INFO_PROVIDER, permissionControlledInfoEngineEnumerationInfoProvider);
	}

	public GeklaCacheManager() throws RemoteException {
		super(KEY);
	}

	public static synchronized void createCache() throws RemoteException {
		if (instance == null) {
			instance = new GeklaCacheManager();
		}
	}

	public static GeklaCacheManager getCache() throws RemoteException {
		if (instance == null) {
			createCache();
		}
		return instance;
	}

	public void store(List<?> list) {
		synchronized (GeklaCacheManager.class) {
			super.store(list);
		}
	}
}
