package ext.kb.bom;

public class Substitute {
	
	String partNumber;
	String partType;
	String CADIM_CID;
	String defaultUnit;
	String masterSystem;
	long obid;
	String version;
	
	public Substitute(){
		
	}
	
	public Substitute(String partNumber,String partType,String CADIM_CID,String defaultUnit,String masterSystem,long obid,String version){
		super();
		this.partNumber=partNumber;
		this.partType=partType;
		this.CADIM_CID=CADIM_CID;
		this.defaultUnit=defaultUnit;
		this.masterSystem=masterSystem;
		this.obid=obid;
		this.version=version;
	}
	
	public String getPartNumber() {
		return partNumber;
	}

	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}

	public String getPartType() {
		return partType;
	}

	public void setPartType(String partType) {
		this.partType = partType;
	}

	public String getCADIM_CID() {
		return CADIM_CID;
	}

	public void setCADIM_CID(String cADIM_CID) {
		CADIM_CID = cADIM_CID;
	}

	public String getDefaultUnit() {
		return defaultUnit;
	}

	public void setDefaultUnit(String defaultUnit) {
		this.defaultUnit = defaultUnit;
	}

	public String getMasterSystem() {
		return masterSystem;
	}

	public void setMasterSystem(String masterSystem) {
		this.masterSystem = masterSystem;
	}

	public long getObid() {
		return obid;
	}

	public void setObid(long obid) {
		this.obid = obid;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

}
