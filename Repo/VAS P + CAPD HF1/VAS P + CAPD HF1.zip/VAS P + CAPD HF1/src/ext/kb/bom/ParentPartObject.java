package ext.kb.bom;

public class ParentPartObject {
	String parentpartnumber;
	String childrenpart;
	String refdesignator;

	public ParentPartObject(String parentnumber) {
		this.parentpartnumber = parentnumber;
	}

	public ParentPartObject() {
	}

	public String getParentpartnumber() {
		return this.parentpartnumber;
	}

	public void setParentpartnumber(String parentpartnumber) {
		this.parentpartnumber = parentpartnumber;
	}
}
