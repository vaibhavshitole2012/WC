/**
 * 
 */
package ext.kb.builder.table;

import java.beans.PropertyVetoException;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

import org.apache.commons.lang.StringUtils;

import com.ptc.core.components.rendering.guicomponents.IconComponent;
import com.ptc.core.components.rendering.guicomponents.UrlDisplayComponent;
import com.ptc.jca.mvc.components.JcaComponentParams;
import com.ptc.mvc.components.AbstractComponentBuilder;
import com.ptc.mvc.components.ColumnConfig;
import com.ptc.mvc.components.ComponentBuilder;
import com.ptc.mvc.components.ComponentConfig;
import com.ptc.mvc.components.ComponentConfigFactory;
import com.ptc.mvc.components.ComponentParams;
import com.ptc.mvc.components.TableConfig;
import com.ptc.mvc.util.ClientMessageSource;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import com.ptc.netmarkets.util.misc.NmContextItem;
import com.ptc.netmarkets.util.misc.NmElementAddress;

import ext.kb.resources.ActionsRB;
import ext.kb.util.KBDocumentUtils;
import ext.kb.util.KBUtils;
import wt.doc.WTDocument;
import wt.epm.EPMDocument;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.type.TypeDefinitionReference;
import wt.type.TypedUtilityServiceHelper;
import wt.util.WTException;

/**
 * @author bankowskie
 *
 */
@ComponentBuilder("ext.kb.builder.table.ConvertToCadTableBuilder")
public class ConvertToCadTableBuilder extends AbstractComponentBuilder {
	
	private static final String RESOURCE = "ext.kb.resources.ActionsRB";
	private final ClientMessageSource messageSource = getMessageSource(RESOURCE);
	
	public static final class Record {
		private IconComponent dataType;
		private UrlDisplayComponent numberLink;
		private String name;
		
		public IconComponent getDataType() {
			return dataType;
		}

		public void setDataType(IconComponent dataType) {
			this.dataType = dataType;
		}

		public UrlDisplayComponent getNumberLink() {
			return numberLink;
		}

		public void setNumberLink(UrlDisplayComponent numberLink) {
			this.numberLink = numberLink;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}
	}
	
	@Override
	public Object buildComponentData(ComponentConfig arg0, ComponentParams arg1) throws Exception {
		JcaComponentParams params = (JcaComponentParams) arg1;
		NmCommandBean commandBean = params.getHelperBean().getNmCommandBean();
		List<Persistable> documents = getParams(commandBean);
		if(documents.isEmpty()){
			Stack elementContext = commandBean.getElementContext().getContextItems();
			for(Object obj : elementContext){
				NmContextItem contextItem = (NmContextItem) obj;
				NmOid nmoid = (NmOid) NmElementAddress.fromString(contextItem.getElemAddress().getElemAddressStr()).getOids().peek();
				Object refObject = nmoid.getRefObject();
				if(refObject instanceof Persistable) documents.add((Persistable) refObject);
			}
		}
		List<Record> records = new ArrayList<>();
		for(Persistable document : documents){
			records.add(generateRecord(document));
		}
		return records;
	}

	private Record generateRecord(Persistable document) throws Exception {
		Record record = new Record();
		record.setDataType(getDataType(document));
		record.setNumberLink(getNumberLink(document));
		record.setName(getName(document));
		return record;
	}

	private String getName(Persistable document) {
		if(document instanceof WTDocument) {
			return ((WTDocument)document).getName();
		} else if(document instanceof EPMDocument) {
			return ((EPMDocument)document).getName();	
		}
		return StringUtils.EMPTY;
	}

	private UrlDisplayComponent getNumberLink(Persistable document) throws Exception {
		String number = StringUtils.EMPTY;
		if(document instanceof WTDocument) {
			number = ((WTDocument)document).getNumber();
		} else if(document instanceof EPMDocument) {
			number =  ((EPMDocument)document).getNumber();
		}
		return KBUtils.getUrlDisplayComponent(number, KBUtils.getUrl(document));
	}

	private IconComponent getDataType(Persistable document) throws WTException, PropertyVetoException, IllegalAccessException, InvocationTargetException {
		return KBUtils.getIconComponent(document);
	}

	@Override
	public ComponentConfig buildComponentConfig(ComponentParams arg0) throws WTException {
		ComponentConfigFactory factory = getComponentConfigFactory();
		TableConfig table = factory.newTableConfig();
		table.setSelectable(true);
		table.setSingleSelect(true);
		table.setLabel(messageSource.getMessage(ActionsRB.DOCUMENT_VARIANTS_TABLE));
		table.setShowCount(true);
		ColumnConfig config = factory.newColumnConfig(ActionsRB.DOCUMENT_VARIANTS_TABLE_COL1_ID, false);
		config.setLabel(ActionsRB.DOCUMENT_VARIANTS_TABLE_COL1_LABEL);
		table.addComponent(config);
		config = factory.newColumnConfig(ActionsRB.DOCUMENT_VARIANTS_TABLE_COL2_ID, false);
		config.setLabel(ActionsRB.DOCUMENT_VARIANTS_TABLE_COL2_LABEL);
		table.addComponent(config);
		config = factory.newColumnConfig(ActionsRB.DOCUMENT_VARIANTS_TABLE_COL3_ID, false);
		config.setLabel(ActionsRB.DOCUMENT_VARIANTS_TABLE_COL3_LABEL);
		table.addComponent(config);
		return table;
	}
	
	public static List<Persistable> getParams(NmCommandBean commandBean) throws WTException, RemoteException {
		List<Persistable> epms = new ArrayList<>();
		String caddocType = "com.ptc.DesignCADDoc";
		String caddrwType = "com.ptc.DesignCADDrw";
		String sytemcaddrwType = "com.ptc.SystemCADDrw";
		TypeDefinitionReference caddocTypeDefinitionReference = TypedUtilityServiceHelper.service.getTypeDefinitionReference(caddocType);
		TypeDefinitionReference caddrwTypeDefinitionReference = TypedUtilityServiceHelper.service.getTypeDefinitionReference(caddrwType);
		TypeDefinitionReference sytemcaddrwTypeDefinitionReference = TypedUtilityServiceHelper.service.getTypeDefinitionReference(sytemcaddrwType);
		QuerySpec spec = new QuerySpec(EPMDocument.class);
		spec.appendWhere(new SearchCondition(EPMDocument.class, "typeDefinitionReference.key.id", SearchCondition.EQUAL, caddocTypeDefinitionReference.getKey().getId()), new int[] { 0 });
		spec.appendOr();
		spec.appendWhere(new SearchCondition(EPMDocument.class, "typeDefinitionReference.key.id", SearchCondition.EQUAL, caddrwTypeDefinitionReference.getKey().getId()), new int[] { 0 });
		spec.appendOr();
		spec.appendWhere(new SearchCondition(EPMDocument.class, "typeDefinitionReference.key.id", SearchCondition.EQUAL, sytemcaddrwTypeDefinitionReference.getKey().getId()), new int[] { 0 });
		spec.appendOr();
		spec.appendWhere( new SearchCondition(EPMDocument.class,EPMDocument.AUTHORING_APPLICATION,SearchCondition.EQUAL,"ACAD"), new int [] {0} ); 
		QueryResult find = PersistenceHelper.manager.find(spec);
		while(find.hasMoreElements()) {
			epms.add((Persistable) find.nextElement());
		}
		return epms;
	}
}

