package ext.kb.builder.table;

import com.ptc.core.meta.common.TypeIdentifierHelper;
import com.ptc.mvc.components.*;
import ext.kb.ui.report.methods.AttributesMethods;
import ext.kb.util.KBUtils;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import wt.configurablelink.ConfigurableMastersLink;
import wt.configurablelink.ConfigurableReferenceLink;
import wt.doc.WTDocument;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.part.WTPart;
import wt.part.WTPartDescribeLink;
import wt.part.WTPartMaster;
import wt.part.WTPartReferenceLink;
import wt.query.*;
import wt.session.SessionHelper;
import wt.type.TypedUtilityServiceHelper;
import wt.util.WTException;
import wt.vc.VersionControlHelper;
import wt.vc.wip.WorkInProgressHelper;

import java.util.*;

@ComponentBuilder("ext.kb.builder.table.ItemsToDocumentReportBuilder")
public class ItemsToDocumentReportBuilder extends AbstractComponentConfigBuilder implements ComponentDataBuilder {

    private static final Logger logger = LogManager.getLogger(ItemsToDocumentReportBuilder.class);
    private static final String PIPE = "\\|";
    private static final String ITEMS_TO_DOCUMENT_TABLE = "itemsToDocumentTable";
    private static final String ITEMS_TO_DOCUMENT_TABLE_LABEL = "Items to Document";
    private static final String DOCUMENT_NUMBER = "Document Number";
    private static final String ITEM_NUMBER = "Item Number";
    private static final String DOCUMENT_NUMBER_PARAMETER = "Document_Number";
    private static final String DOCUMENT_NAME = "Document Name";
    private static final String RESPONSIBLE_DEVISION = "Responsible Devision";
    private static final String VERSION = "Version";
    private static final String STATE = "State";
    private static final String DOC_CONTENT_TYPE = "Doc Content Type";
    private static final String LANGUAGE = "Language";
    private static final String NO_OF_PAGES = "No of Pages";
    private static final String ITEM_RESPONSIBLE_DEVISION = "Item Responsible Devision";
    private static final String ITEM_VERSION = "Item Version";
    private static final String ITEM_STATE = "Item State";
    private static final String ITEM_VIEW = "Item View";
    private static final String KB_REF_INFO_LINK = "com.ptc.KBRefInfoLink";
    private static final String KB_CONTRACT_LINK = "com.ptc.KBContractLink";
    private static final String EXPORT_ACTIONS = "report results table actions";
    private static final String DOC_TYPE = "Type of Document";

    @Override
    public ComponentConfig buildComponentConfig(ComponentParams componentParams) throws WTException {
        ComponentConfigFactory factory = getComponentConfigFactory();
        TableConfig tableConfig = factory.newTableConfig();
        tableConfig.setId(ITEMS_TO_DOCUMENT_TABLE);
        tableConfig.setLabel(ITEMS_TO_DOCUMENT_TABLE_LABEL);
        tableConfig.setFreezable(true);
        tableConfig.setShowCount(true);
        tableConfig.setShowCustomViewLink(false);
        tableConfig.setSelectable(true);
        tableConfig.setConfigurable(false);
        tableConfig.setActionModel(EXPORT_ACTIONS);
        tableConfig.addComponent(factory.newColumnConfig(DOCUMENT_NUMBER, true));
        tableConfig.addComponent(factory.newColumnConfig(DOCUMENT_NAME, true));
        tableConfig.addComponent(factory.newColumnConfig(DOC_TYPE, true));
        tableConfig.addComponent(factory.newColumnConfig(RESPONSIBLE_DEVISION, true));
        tableConfig.addComponent(factory.newColumnConfig(VERSION, true));
        tableConfig.addComponent(factory.newColumnConfig(STATE, true));
        tableConfig.addComponent(factory.newColumnConfig(DOC_CONTENT_TYPE, true));
        tableConfig.addComponent(factory.newColumnConfig(LANGUAGE, true));
        tableConfig.addComponent(factory.newColumnConfig(NO_OF_PAGES, true));
        tableConfig.addComponent(factory.newColumnConfig(ITEM_NUMBER, true));
        tableConfig.addComponent(factory.newColumnConfig(ITEM_RESPONSIBLE_DEVISION, true));
        tableConfig.addComponent(factory.newColumnConfig(ITEM_VERSION, true));
        tableConfig.addComponent(factory.newColumnConfig(ITEM_STATE, true));
        tableConfig.addComponent(factory.newColumnConfig(ITEM_VIEW, true));
        return tableConfig;
    }

    @Override
    public Object buildComponentData(ComponentConfig componentConfig, ComponentParams componentParams) throws Exception {
        logger.debug("ItemsToDocumentReportBuilder - buildComponentData started");
        String[] documentsNumbers = componentParams.getParameter(DOCUMENT_NUMBER_PARAMETER).toString().split(PIPE);
        logger.debug("Documents numbers: " + Arrays.toString(documentsNumbers));
        List<Map<String, Object>> objectsForReport = new ArrayList<>();
        QueryResult documents = getWTDocumentsByNumbers(documentsNumbers);
        while (documents.hasMoreElements()) {
            WTDocument document = (WTDocument) documents.nextElement();
            if (!WorkInProgressHelper.isWorkingCopy(document)) {
                objectsForReport.addAll(findDescribesItems(document));
                objectsForReport.addAll(findReferencedByItems(document));
                objectsForReport.addAll(findItemsByRefLink(document));
                objectsForReport.addAll(findItemsByContractsLink(document));
            }
        }
        logger.debug("ItemsToDocumentReportBuilder - buildComponentData finished");
        return objectsForReport;
    }

    private QueryResult getWTDocumentsByNumbers(String[] documentsNumbers) throws WTException {
        QuerySpec queryForDocuments = new QuerySpec(WTDocument.class);
        if (documentsNumbers.length > 1 || !documentsNumbers[0].equals(StringUtils.EMPTY)) {
            queryForDocuments.appendWhere(new SearchCondition(new ClassAttribute(WTDocument.class, WTDocument.NUMBER),
                    SearchCondition.IN, new ArrayExpression(documentsNumbers)), new int[]{0});
            queryForDocuments.appendAnd();
        }
        queryForDocuments.appendWhere(new SearchCondition(WTDocument.class, WTDocument.LATEST_ITERATION,
                SearchCondition.IS_TRUE), new int[]{0});
        return PersistenceServerHelper.manager.query(queryForDocuments);
    }

    private List<Map<String, Object>> findDescribesItems(WTDocument document) throws WTException {
        List<Map<String, Object>> objectsForReport = new ArrayList<>();
        QueryResult queryResult = PersistenceHelper.navigate(document, WTPartDescribeLink.DESCRIBES_ROLE, WTPartDescribeLink.class, true);
        while (queryResult.hasMoreElements()) {
            Object object = queryResult.nextElement();
            if (object instanceof WTPart) {
                WTPart wtPart = (WTPart) object;
                if (!WorkInProgressHelper.isWorkingCopy(wtPart) && KBUtils.isEbomPart(wtPart))
                    objectsForReport.add(addWTPartToReport(wtPart, document));
            }
        }
        return objectsForReport;
    }

    private List<Map<String, Object>> findReferencedByItems(WTDocument document) throws WTException {
        List<Map<String, Object>> objectsForReport = new ArrayList<>();
        QueryResult queryResult = PersistenceHelper.navigate(document.getMaster(), WTPartReferenceLink.REFERENCED_BY_ROLE, WTPartReferenceLink.class, true);
        while (queryResult.hasMoreElements()) {
            Object object = queryResult.nextElement();
            if (object instanceof WTPart) {
                WTPart part = (WTPart) object;
                if (part.isLatestIteration() && !WorkInProgressHelper.isWorkingCopy(part) && KBUtils.isEbomPart(part))
                    objectsForReport.add(addWTPartToReport(part, document));
            }
        }
        return objectsForReport;
    }

    private List<Map<String, Object>> findItemsByRefLink(WTDocument document) throws WTException {
        List<Map<String, Object>> objectsForReport = new ArrayList<>();
        NavigateSpec navigateSpec = PersistenceHelper.buildNavigateSpec(document.getMaster(),
                ConfigurableReferenceLink.REFERENCED_BY_ROLE, ConfigurableReferenceLink.class, false);
        navigateSpec.appendWhere(TypedUtilityServiceHelper.service.getSearchCondition(
                TypeIdentifierHelper.getTypeIdentifier(KB_REF_INFO_LINK), true), new int[]{1});
        QueryResult queryResult = PersistenceServerHelper.manager.query(navigateSpec);
        while (queryResult.hasMoreElements()) {
            Object object = queryResult.nextElement();
            if (object instanceof Persistable[]) {
                Persistable[] persistables = (Persistable[]) object;
                if (persistables[0] instanceof WTPart) {
                    WTPart part = (WTPart) persistables[0];
                    if (part.isLatestIteration() && !WorkInProgressHelper.isWorkingCopy(part) && KBUtils.isEbomPart(part))
                        objectsForReport.add(addWTPartToReport(part, document));
                }
            }
        }
        return objectsForReport;
    }

    private List<Map<String, Object>> findItemsByContractsLink(WTDocument document) throws WTException {
        List<Map<String, Object>> objectsForReport = new ArrayList<>();
        NavigateSpec navigateSpec = PersistenceHelper.buildNavigateSpec(document.getMaster(),
                ConfigurableMastersLink.TRACED_BY_ROLE, ConfigurableMastersLink.class, false);
        navigateSpec.appendWhere(TypedUtilityServiceHelper.service.getSearchCondition(
                TypeIdentifierHelper.getTypeIdentifier(KB_CONTRACT_LINK), true), new int[]{1});
        QueryResult queryResult = PersistenceServerHelper.manager.query(navigateSpec);
        while (queryResult.hasMoreElements()) {
            Object object = queryResult.nextElement();
            if (object instanceof Persistable[]) {
                Persistable[] persistables = (Persistable[]) object;
                if (persistables[0] instanceof WTPartMaster) {
                    WTPartMaster partMaster = (WTPartMaster) persistables[0];
                    WTPart latestIteration = (WTPart) VersionControlHelper.service.allIterationsOf(partMaster).nextElement();
                    if (!WorkInProgressHelper.isWorkingCopy(latestIteration) && KBUtils.isEbomPart(latestIteration))
                        objectsForReport.add(addWTPartToReport(latestIteration, document));
                }
            }
        }
        return objectsForReport;
    }

    private Map<String, Object> addWTPartToReport(WTPart part, WTDocument document) throws WTException {
        logger.debug("WTPart: " + part);
        logger.debug("WTDocument: " + document);
        Map<String, Object> row = new HashMap<>();
        row.put(DOCUMENT_NUMBER, document.getNumber());
        row.put(DOCUMENT_NAME, document.getName());
        row.put(DOC_TYPE, document.getDisplayType().getLocalizedMessage(SessionHelper.getLocale()));
        row.put(RESPONSIBLE_DEVISION, AttributesMethods.getDepartment(document));
        row.put(VERSION, AttributesMethods.getRevision(document));
        row.put(STATE, document.getLifeCycleState().getDisplay());
        row.put(DOC_CONTENT_TYPE, AttributesMethods.getDocContentType(document));
        row.put(LANGUAGE, AttributesMethods.getLanguage(document));
        row.put(NO_OF_PAGES, AttributesMethods.getNoOfPages(document));
        row.put(ITEM_NUMBER, part.getNumber());
        row.put(ITEM_VIEW, part.getViewName());
        row.put(ITEM_RESPONSIBLE_DEVISION, AttributesMethods.getDepartment(part));
        row.put(ITEM_VERSION, AttributesMethods.getRevision(part));
        row.put(ITEM_STATE, part.getLifeCycleState().getDisplay());
        return row;
    }

}
