package ext.kb.builder.compconfig;

import java.util.List;
import java.util.Locale;

import com.extjs.gxt.ui.client.Style;
import com.ptc.cat.config.client.ActionConfig;
import com.ptc.cat.config.client.ActionConfig.ButtonType;
import com.ptc.cat.config.client.DefaultActionConfig;
import com.ptc.mvc.components.ComponentBuilder;
import com.ptc.mvc.components.ComponentBuilderType;
import com.ptc.mvc.components.OverrideComponentBuilder;
import com.ptc.windchill.enterprise.part.psb.server.PSBUsesConfigBuilder;

@ComponentBuilder(value = { "PSB.uses" }, type = ComponentBuilderType.CONFIG_ONLY)
@OverrideComponentBuilder
public class PSBUsesConfigBuilderExtension extends PSBUsesConfigBuilder {
	
	@Override
	protected List<ActionConfig> getToolbarConfigOverrides(Locale paramLocale) {
		List<ActionConfig> actionConfigs = super.getToolbarConfigOverrides(paramLocale);
		actionConfigs.add(new DefaultActionConfig("autoFillEmptyNumbersGWT",
				ButtonType.BUTTON, null,
				Style.ButtonScale.SMALL));
		return actionConfigs;
	}
	
}
