package ext.kb.builder.table;

import java.util.List;

import wt.util.WTException;

import com.ptc.core.htmlcomp.tableview.ConfigurableTable;
import com.ptc.mvc.components.ComponentBuilder;
import com.ptc.mvc.components.OverrideComponentBuilder;
import com.ptc.windchill.enterprise.change2.mvc.builders.tables.AffectedItemsTableBuilder;

import ext.kb.enumconstant.InventoryDispositions;
import ext.kb.tableview.AdditionalInventoriesChangeTaskAffectedItemsTableViews;

/**
 * KB Custom table builder for affected items edit window. (changeTask.affectedItemsTable)
 *
 */

@ComponentBuilder("changeTask.affectedItemsTable")
@OverrideComponentBuilder
public class AdditionalInventoriesAffectedItemsTableBuilder extends AffectedItemsTableBuilder {

    // private static final Logger log =
    // LogR.getLogger(InventoryDispositionBuilder.class.getName());

    @Override
    public List<String> getDispositionComponentIds() {
        return InventoryDispositions.ALL_DISPOSITIONS;
    }

    @Override
    public ConfigurableTable buildConfigurableTable(String arg0) throws WTException {
        return new AdditionalInventoriesChangeTaskAffectedItemsTableViews();
    }

}
