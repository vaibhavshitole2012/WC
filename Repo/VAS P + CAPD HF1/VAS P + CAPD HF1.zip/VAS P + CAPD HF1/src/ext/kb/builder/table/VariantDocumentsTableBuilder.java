/**
 * 
 */
package ext.kb.builder.table;

import java.beans.PropertyVetoException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.ptc.core.components.rendering.guicomponents.IconComponent;
import com.ptc.core.components.rendering.guicomponents.UrlDisplayComponent;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.TypeIdentifierHelper;
import com.ptc.generic.iba.AttributeService;
import com.ptc.jca.mvc.components.JcaComponentParams;
import com.ptc.mvc.components.AbstractComponentBuilder;
import com.ptc.mvc.components.ColumnConfig;
import com.ptc.mvc.components.ComponentBuilder;
import com.ptc.mvc.components.ComponentConfig;
import com.ptc.mvc.components.ComponentConfigFactory;
import com.ptc.mvc.components.ComponentParams;
import com.ptc.mvc.components.TableConfig;
import com.ptc.mvc.util.ClientMessageSource;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import com.ptc.netmarkets.util.misc.NmContext;
import com.ptc.netmarkets.util.misc.NmContextItem;
import com.ptc.netmarkets.util.misc.NmElementAddress;

import ext.kb.resources.ActionsRB;
import ext.kb.util.DocumentVariantHelper;
import ext.kb.util.IBAHelper;
import ext.kb.util.KBConstants;
import ext.kb.util.KBTypeIdProvider;
import ext.kb.util.KBUtils;
import wt.configurablelink.ConfigurableRevisionLink;
import wt.doc.WTDocument;
import wt.enterprise._RevisionControlled;
import wt.epm.EPMDocument;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.iba.value.IBAHolder;
import wt.util.WTException;
import wt.vc.wip.WorkInProgressHelper;
import wt.vc.wip.Workable;

/**
 * @author bankowskie
 *
 */
@ComponentBuilder("ext.kb.builder.table.VariantDocumentsTableBuilder")
public class VariantDocumentsTableBuilder extends AbstractComponentBuilder{
	
	private static final String RESOURCE = "ext.kb.resources.ActionsRB";
	private final ClientMessageSource messageSource = getMessageSource(RESOURCE);
	private final Logger LOGGER = Logger.getLogger(VariantDocumentsTableBuilder.class);
	
	public static final class Record {
		private IconComponent dataType;
		private UrlDisplayComponent numberLink;
		private String name;
		private String status;
		private String language;
		private String leadingLanguage;
		private String variantLangs;
		private String isVariant;
		private String cadimCid;
		private String isSourceReleased;
		private String isCheckedOut;
		private String isValidNd;
		private String isInterfaceActive;
		
		public IconComponent getDataType() {
			return dataType;
		}

		public void setDataType(IconComponent dataType) {
			this.dataType = dataType;
		}

		public UrlDisplayComponent getNumberLink() {
			return numberLink;
		}

		public void setNumberLink(UrlDisplayComponent numberLink) {
			this.numberLink = numberLink;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getStatus() {
			return status;
		}

		public void setStatus(String status) {
			this.status = status;
		}

		public String getLanguage() {
			return language;
		}

		public void setLanguage(String language) {
			this.language = language;
		}

		public String getLeadingLanguage() {
			return leadingLanguage;
		}

		public void setLeadingLanguage(String leadingLanguage) {
			this.leadingLanguage = leadingLanguage;
		}

		public String getVariantLangs() {
			return variantLangs;
		}

		public void setVariantLangs(String variantLangs) {
			this.variantLangs = variantLangs;
		}

		public String getIsVariant() {
			return isVariant;
		}

		public void setIsVariant(String isVariant) {
			this.isVariant = isVariant;
		}
		
		public String getCadimCid() {
			return cadimCid;
		}

		public void setCadimCid(String cadimCid) {
			this.cadimCid = cadimCid;
		}

		public String getIsSourceReleased() {
			return isSourceReleased;
		}

		public void setIsSourceReleased(String isSourceReleased) {
			this.isSourceReleased = isSourceReleased;
		}
		
		public String getIsCheckedOut() {
			return isCheckedOut;
		}

		public void setIsCheckedOut(String isCheckedOut) {
			this.isCheckedOut = isCheckedOut;
		}

		public String getIsValidNd() {
			return isValidNd;
		}

		public void setIsValidNd(String isWrongNd) {
			this.isValidNd = isWrongNd;
		}

		public String getIsInterfaceActive() {
			return isInterfaceActive;
		}

		public void setIsInterfaceActive(String isInterfaceActive) {
			this.isInterfaceActive = isInterfaceActive;
		}
	}
	
	@Override
	public Object buildComponentData(ComponentConfig arg0, ComponentParams arg1) throws Exception {
		JcaComponentParams params = (JcaComponentParams) arg1;
		NmCommandBean commandBean = params.getHelperBean().getNmCommandBean();
		ArrayList<Persistable> documents = getParams(commandBean);
		if(documents.isEmpty()){
			Stack elementContext = commandBean.getElementContext().getContextItems();
			for(Object obj : elementContext){
				NmContextItem contextItem = (NmContextItem) obj;
				NmOid nmoid = (NmOid) NmElementAddress.fromString(contextItem.getElemAddress().getElemAddressStr()).getOids().peek();
				Object refObject = nmoid.getRefObject();
				if(refObject instanceof Persistable) {
					documents.add((Persistable) refObject);
				}
			}
		}
		List<Record> records = new ArrayList<>();
		for(Persistable document : documents){
			records.add(generateRecord(document));
		}
		return records;
	}

	private Record generateRecord(Persistable document) throws Exception {
		Record record = new Record();
		record.setDataType(getDataType(document));
		record.setNumberLink(getNumberLink(document));
		record.setName(getName(document));
		record.setLanguage(getLanguage(document));
		record.setLeadingLanguage(getLeadingLanguage(document));
		record.setIsVariant(isVariantDocument(document));
		record.setIsInterfaceActive(String.valueOf(KBUtils.isInterfaceActivated()));
		record.setCadimCid(hasCadimCid(document));
		record.setVariantLangs(getVariantLangs(getVariants(document)));
		record.setIsSourceReleased(isReleasedSourceDocument(document));
		record.setIsCheckedOut(isCheckedOut(document));
		record.setIsValidNd(isValidNeutralData(document));
		return record;
	}

	private String isReleasedSourceDocument(Persistable document) {
		return String.valueOf((((_RevisionControlled) document).getState().toString().equals(KBConstants.RELEASED) 
				&& !KBTypeIdProvider.isDescendant(document, "NEUTRALDATA")));
	}

	private String isCheckedOut(Persistable document) throws WTException {
		return String.valueOf(WorkInProgressHelper.isCheckedOut((Workable) document));
	}

	private String isValidNeutralData(Persistable document) {
		if(document instanceof WTDocument) {
			return String.valueOf(DocumentVariantHelper.hasValidNeutralDataConstraints(((WTDocument)document)));
		}
		return String.valueOf(true);
	}

	private String getVariantLangs(List<Persistable> variants) throws WTException {
		String variantLangs = "";
		for(Persistable variant : variants){
			String variantLang =  IBAHelper.getStringIBAValue((IBAHolder) variant, KBConstants.KBLANGUAGE_IBA);
			String variantLeadingLang = (String) IBAHelper.getIBAValue((IBAHolder) variant, "KB_LEADING_LANGUAGE");
			variantLangs+=variantLeadingLang+"/"+variantLang+"+";
		}
		return variantLangs;
	}

	private String getLeadingLanguage(Persistable document) throws WTException {
		return (String) IBAHelper.getIBAValue((IBAHolder) document, "KB_LEADING_LANGUAGE");
	}

	private String getLanguage(Persistable document) throws WTException {
		return IBAHelper.getStringIBAValue((IBAHolder) document, KBConstants.KBLANGUAGE_IBA);
	}

	private String getName(Persistable document) {
		if(document instanceof WTDocument) {
			return ((WTDocument)document).getName();
		} else if(document instanceof EPMDocument) {
			return ((EPMDocument)document).getName();	
		}
		return StringUtils.EMPTY;
	}

	private UrlDisplayComponent getNumberLink(Persistable document) throws Exception {
		String number = StringUtils.EMPTY;
		if(document instanceof WTDocument) {
			number = ((WTDocument)document).getNumber();
		} else if(document instanceof EPMDocument) {
			number =  ((EPMDocument)document).getNumber();
		}
		return KBUtils.getUrlDisplayComponent(number, KBUtils.getUrl(document));
	}

	private IconComponent getDataType(Persistable document) throws WTException, PropertyVetoException, IllegalAccessException, InvocationTargetException {
		return KBUtils.getIconComponent(document);
	}

	@Override
	public ComponentConfig buildComponentConfig(ComponentParams arg0) throws WTException {
		ComponentConfigFactory factory = getComponentConfigFactory();
		TableConfig table = factory.newTableConfig();
		table.setLabel(messageSource.getMessage(ActionsRB.DOCUMENT_VARIANTS_TABLE));
		table.setShowCount(true);
		ColumnConfig config = factory.newColumnConfig(ActionsRB.DOCUMENT_VARIANTS_TABLE_COL1_ID, false);
		config.setLabel(ActionsRB.DOCUMENT_VARIANTS_TABLE_COL1_LABEL);
		table.addComponent(config);
		config = factory.newColumnConfig(ActionsRB.DOCUMENT_VARIANTS_TABLE_COL2_ID, false);
		config.setLabel(ActionsRB.DOCUMENT_VARIANTS_TABLE_COL2_LABEL);
		table.addComponent(config);
		config = factory.newColumnConfig(ActionsRB.DOCUMENT_VARIANTS_TABLE_COL3_ID, false);
		config.setLabel(ActionsRB.DOCUMENT_VARIANTS_TABLE_COL3_LABEL);
		table.addComponent(config);
		config = factory.newColumnConfig(ActionsRB.DOCUMENT_VARIANTS_TABLE_COL5_ID, false);
		config.setLabel(ActionsRB.DOCUMENT_VARIANTS_TABLE_COL5_LABEL);
		table.addComponent(config);
		config = factory.newColumnConfig(ActionsRB.DOCUMENT_VARIANTS_TABLE_COL6_ID, false);
		config.setLabel(ActionsRB.DOCUMENT_VARIANTS_TABLE_COL6_LABEL);
		table.addComponent(config);
		config = factory.newColumnConfig("variantLangs", false);
		config.setLabel("variantLangs");
		table.addComponent(config);
		config = factory.newColumnConfig("isVariant", false);
		config.setLabel("isVariant");
		table.addComponent(config);
		config = factory.newColumnConfig("cadimCid", false);
		config.setLabel("cadimCid");
		table.addComponent(config);
		config = factory.newColumnConfig("isInterfaceActive", false);
		config.setLabel("isInterfaceActive");
		table.addComponent(config);
		config = factory.newColumnConfig("isSourceReleased", false);
		config.setLabel("isSourceReleased");
		table.addComponent(config);
		config = factory.newColumnConfig("isCheckedOut", false);
		config.setLabel("isCheckedOut");
		table.addComponent(config);
		config = factory.newColumnConfig("isValidNd", false);
		config.setLabel("isValidNd");
		table.addComponent(config);
		config = factory.newColumnConfig(ActionsRB.DOCUMENT_VARIANTS_TABLE_COL4_ID, false);
		config.setLabel(ActionsRB.DOCUMENT_VARIANTS_TABLE_COL4_LABEL);
		table.addComponent(config);
		return table;
	}
	
	public static ArrayList<Persistable> getParams(NmCommandBean commandBean) throws WTException{
		ArrayList<Persistable> documents = new ArrayList<Persistable>();
		ArrayList selectedObjects = commandBean.getSelectedContextsForPopup();
		for(Object selectedObj : selectedObjects){
			if (selectedObj instanceof NmContext) {
				NmOid oid  = ((NmContext) selectedObj).getTargetOid();
				Object refObject = oid.getRefObject();
				if(refObject instanceof WTDocument || refObject instanceof EPMDocument) {
					documents.add((Persistable) refObject);
				}
             }
		}
		return documents;
	}
	
	private ArrayList<Persistable> getVariants(Persistable document){
		ArrayList<Persistable> documents = new ArrayList<>();
		try {
			QueryResult allLinks = PersistenceHelper.manager.navigate(document, ConfigurableRevisionLink.ALL_ROLES, ConfigurableRevisionLink.class, true);
			while (allLinks.hasMoreElements()) {
				Object obj = allLinks.nextElement();
				if (obj instanceof Persistable) {
					Persistable doc = (Persistable) obj;
					TypeIdentifier targetType = wt.type.TypedUtilityServiceHelper.service.getTypeIdentifier(doc);
					boolean hasValidType = isDocumentAppropriateType(targetType);
					if(hasValidType) {
						documents.add((Persistable) obj);
					}
				}
			}
		} catch (WTException e) {
			//LOG.error("Unable to query for source document of " + persistable, e);
		}
		return documents;
	}
	
	private String isVariantDocument(Persistable persistable) {
		String sapIdx = AttributeService.getAttribute(persistable, KBConstants.KBSAP_IDX_IBA);
		return String.valueOf(sapIdx != null && Integer.parseInt(sapIdx) > 0);
	}
	
	private String hasCadimCid(Persistable persistable) {
		if(persistable instanceof EPMDocument || KBTypeIdProvider.isDescendant(persistable, "TECHDRWDOC")) {
			return String.valueOf(true);
		}
		String cadimCid = AttributeService.getAttribute(persistable, "KB_CADIM_CID");
		return String.valueOf(cadimCid!=null && !cadimCid.isEmpty());
	}
	
	
	private boolean isDocumentAppropriateType(TypeIdentifier targetType) {
		return targetType.isEquivalentTypeIdentifier(TypeIdentifierHelper.getTypeIdentifier("com.ptc.KBCertificate"))
				|| targetType.isEquivalentTypeIdentifier(TypeIdentifierHelper.getTypeIdentifier("com.ptc.KBStandard"))
				|| targetType.isEquivalentTypeIdentifier(TypeIdentifierHelper.getTypeIdentifier("com.ptc.KBTechnicalDocument"))
				|| targetType.isEquivalentTypeIdentifier(TypeIdentifierHelper.getTypeIdentifier("com.ptc.KBTechnicalDrawing"))
				|| targetType.isEquivalentTypeIdentifier(TypeIdentifierHelper.getTypeIdentifier("com.ptc.DesignCADDrw"));
	}

}