/* bcwti
 *
 * Copyright (c) 2010 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */

package ext.kb.builder.helper;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import org.apache.log4j.Logger;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import com.ptc.netmarkets.util.misc.NmContext;
import com.ptc.netmarkets.workflow.NmWorkflowHelper;
import com.ptc.netmarkets.workflow.RouteDescriptorConstants;
import com.ptc.netmarkets.workflow.RouteParticipantsBean;
import com.ptc.netmarkets.workflow.RouteTeamParticipantsHelper;

import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.fc.WTObject;
import wt.fc.WTReference;
import wt.fc.collections.WTHashSet;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerRef;
import wt.inf.team.ContainerTeam;
import wt.inf.team.ContainerTeamHelper;
import wt.inf.team.ContainerTeamManaged;
import wt.lifecycle.LifeCycleHelper;
import wt.lifecycle.LifeCycleManaged;
import wt.lifecycle.LifeCycleService;
import wt.lifecycle.LifeCycleTemplate;
import wt.log4j.LogR;
import wt.method.MethodLocal;
import wt.org.OrganizationServicesHelper;
import wt.org.OrganizationServicesManager;
import wt.org.WTGroup;
import wt.org.WTPrincipal;
import wt.org.WTPrincipalReference;
import wt.org.WTUser;
import wt.preference.PreferenceClient;
import wt.preference.PreferenceHelper;
import wt.project.Role;
import wt.session.SessionHelper;
import wt.team.RolePrincipalMap;
import wt.team.Team;
import wt.team.TeamHelper;
import wt.team.WTRoleHolder2;
import wt.util.WTException;
import wt.util.WTProperties;
import wt.workflow.definer.WfDefinerHelper;
import wt.workflow.engine.WfProcess;
import wt.workflow.engine.WfState;

/**
 * Helper class for handling the Promotion Request participants table.
 * 
 * <BR>
 * <BR>
 * <B>Supported API: </B>false <BR>
 * <BR>
 * <B>Extendable: </B>false
 */

public class KBRouteTeamParticipantsHelper extends RouteTeamParticipantsHelper {

	private static final String INCLUDE_TEAMTEMPLATE_ROLES = "includeTeamTemplateRoles";

	private static final String INCLUDE_LIFECYCLETEMPLATE_ROLES = "includeLifeCycleTemplateRoles";

	private static final String IGNORE_OWNER = "ignoreOwner";

	private static Logger logger = LogR.getLogger(RouteDescriptorConstants.ROUTE_LOGGER);

	private static final MethodLocal<RouteParticipantsBean> paricipantsBean = new MethodLocal<RouteParticipantsBean>();

	private static final String FLATTENED_MEMBERS_PREF = "/promote/participants/flattenedMembers";

	private static final boolean ROUTE_EXPLODE_GROUPS;

	static {
		try {
			WTProperties properties = WTProperties.getLocalProperties();
			ROUTE_EXPLODE_GROUPS = properties.getProperty("com.ptc.netmarkets.workflow.routeExplodeGroups", false);
		} catch (Throwable t) {
			if (logger.isDebugEnabled()) {
				logger.debug(t.getLocalizedMessage(), t);
			}
			throw new ExceptionInInitializerError(t);
		}
	}

	/**
	 * Given the form data returns the columns(roles) to be rendered in the
	 * participants table. It gets all the particpants role defined in the
	 * workflow process template. Based on the properties set on the
	 * ComponentDescriptor, the columns might change.The behavior is as follows
	 * for each property
	 * 
	 * ignoreOwner - ignores the owner role defined in the workflow template
	 * includeLifeCycleTemplateRoles - includes the roles defined in the LC
	 * template includeTeamTemplateRoles - includes te roles defined for team
	 * tempalte
	 * 
	 * @param mc
	 * @return columns(roles) to be rendered in the participants table
	 * @throws WTException
	 */

	public static List<String> getParticipantRoles(ModelContext mc) throws WTException {
		List<String> roles = new ArrayList<String>();

		NmCommandBean clientData = mc.getNmCommandBean();

		roles = NmWorkflowHelper.service.getParticipantRoles(clientData);

		if (logger.isDebugEnabled()) {
			logger.debug("roles : " + roles.toString());
		}

		return roles;
	}

	/**
	 * Helper method to get the value from the parameters and translate to
	 * boolean if the value is the string value for boolean
	 * 
	 * @param parameters
	 * @param parameterName
	 * @return
	 */
	private static boolean GetBooleanValueForProperty(Map<String, Object> parameters, String parameterName) {
		if (parameters == null || parameterName == null) {
			logger.debug("Either parameters or the parameter name is null parameters : " + parameters
					+ " parameterName : " + parameterName);
			return false;
		}
		Object value = parameters.get(parameterName);

		if (value instanceof String) {
			return Boolean.parseBoolean((String) value);
		} else if (value instanceof Boolean) {
			return (Boolean) value;
		}

		logger.debug("the value for parameter is either null or not supported " + value);
		return false;

	}

	/**
	 * Get the component descriptor properties defined on the role column to
	 * resolve the columns for participants table.
	 * 
	 * @param mc
	 * @return
	 */
	protected static Map<String, Object> getRoleResolutionParameters(ModelContext mc) {
		Map<String, Object> parameters = new HashMap<String, Object>();
		if (mc == null) {
			logger.debug("Model Context is null");
			return parameters;
		}
		Object ignoreOwner = mc.getParentDescriptor().getProperty(IGNORE_OWNER, "true");
		parameters.put(IGNORE_OWNER, ignoreOwner);
		Object includeLifeCycleTemplateRoles = mc.getParentDescriptor().getProperty(INCLUDE_LIFECYCLETEMPLATE_ROLES,
				"false");
		parameters.put(INCLUDE_LIFECYCLETEMPLATE_ROLES, includeLifeCycleTemplateRoles);
		Object includeTeamTemplateRoles = mc.getParentDescriptor().getProperty(INCLUDE_TEAMTEMPLATE_ROLES, "false");
		parameters.put(INCLUDE_TEAMTEMPLATE_ROLES, includeTeamTemplateRoles);

		if (logger.isDebugEnabled()) {
			logger.debug("parameters : " + parameters.toString());
		}
		return parameters;
	}

	/**
	 * Given a role, it will get the backing group representing the role and the
	 * direct members of that role
	 * 
	 * @param role
	 * @return a set containing backing group representing the role and the
	 *         direct members of that role
	 * @throws WTException
	 */
	private static Set<WTPrincipal> getParticipants(String role) throws WTException {
		HashSet<WTPrincipal> participants = new HashSet<WTPrincipal>();
		if (role == null) {
			return participants;

		}
		RouteParticipantsBean participantsbean = RouteTeamParticipantsHelper.getParticipantsBean();

		WTRoleHolder2 processTeam = participantsbean.getProcessTeam();
		if (processTeam != null) {
			QueryResult qr = TeamHelper.service.findRolePrincipalMap(wt.project.Role.toRole(role), null, processTeam);
			while (qr.hasMoreElements()) {
				RolePrincipalMap rpm = (RolePrincipalMap) qr.nextElement();
				WTPrincipalReference principal = (WTPrincipalReference) rpm.getPrincipalParticipant();
				if (principal != null)
					participants.add(principal.getPrincipal());
			}
			return participants;
		}

		ContainerTeam localTeam = participantsbean.getLocalContainerTeam();
		if (localTeam != null) {
			WTGroup group = ContainerTeamHelper.service.findContainerTeamGroup(localTeam,
					ContainerTeamHelper.ROLE_GROUPS, role);
			if (group != null) {
				// participants.add(group);
				participants.addAll(getDirectMembers(localTeam, group, true));
			}
		}
		ContainerTeam sharedTeam = participantsbean.getSharedContainerTeam();
		if (sharedTeam != null) {
			WTGroup sharedgroup = ContainerTeamHelper.service.findContainerTeamGroup(sharedTeam,
					ContainerTeamHelper.ROLE_GROUPS, role);
			if (sharedgroup != null) {
				// participants.add(sharedgroup);
				participants.addAll(getDirectMembers(sharedTeam, sharedgroup, true));
			}
		}

		return participants;
	}

	/**
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @return the PromotionRequestDataUtilityBean in the thread.
	 */
	public static RouteParticipantsBean getParticipantsBean() {
		RouteParticipantsBean bean = paricipantsBean.get();
		if (bean == null) {
			bean = new RouteParticipantsBean();
			paricipantsBean.set(bean);
		}
		return bean;
	}

	/**
	 * Given the team and the role, returns the backing groups that represents
	 * the role.
	 * 
	 * @param team
	 *            - team that is of interest
	 * @param searchBase
	 *            - role that is of interest
	 * @return list of groups representing the role.
	 * @throws WTException
	 */
	private static ArrayList<WTPrincipal> getGroupsForSearchBase(ContainerTeam team, String searchBase)
			throws WTException {

		if (team == null || searchBase == null) {
			logger.debug("Either team or the search base is null team : " + team + " searchBase : " + searchBase);
			return new ArrayList<WTPrincipal>();
		}
		@SuppressWarnings("unchecked")
		Enumeration<WTPrincipal> roleGroups = ContainerTeamHelper.service.findContainerTeamGroups(team, searchBase);

		if (logger.isDebugEnabled()) {
			logger.debug("roleGroups : " + roleGroups);
		}
		return Collections.list(roleGroups);
	}

	/**
	 * Returns a boolean flag indicating if the group is a group representing a
	 * role.
	 * 
	 * @param group
	 *            that is of interest
	 * @return flag
	 * @throws WTException
	 */
	public static boolean isARoleGroup(WTGroup group) throws WTException {
		if (group == null) {
			logger.debug("The group is null, hence returning false");
			return false;
		}
		RouteParticipantsBean participantsbean = getParticipantsBean();
		HashSet<WTPrincipal> roles = participantsbean.getRoleGroupList();
		if (roles != null && roles.size() > 0) {
			logger.debug("is a role group : " + roles.contains(group));
			return roles.contains(group);
		}

		return false;
	}

	/**
	 * Returns a boolean flag indicating if the group is a group representing a
	 * organization.
	 * 
	 * @param group
	 *            that is of interest
	 * @return flag
	 * @throws WTException
	 */
	public static boolean isAOrgGroup(WTGroup group) throws WTException {
		if (group == null) {
			logger.debug("The group is null, hence returning false");
			return false;
		}

		RouteParticipantsBean participantsbean = getParticipantsBean();
		HashSet<WTPrincipal> roles = participantsbean.getOrgGroupList();
		if (roles != null && roles.size() > 0) {
			logger.debug("is a role group : " + roles.contains(group));
			return roles.contains(group);
		}
		return false;
	}

	/**
	 * get the direct members of the group. If the group is a backing group
	 * representing a role, then we might have to get the members from the local
	 * team as well as shared team if applicable.
	 * 
	 * @param team
	 *            - get the direct members for a role, given a team. if it is
	 *            regular group the team be empty
	 * @param group
	 *            that is of interest
	 * @param isRoleGroup
	 *            - true, if the group is a group representing role
	 * @return direct members of the group
	 * @throws WTException
	 */
	protected static List<WTPrincipal> getDirectMembers(ContainerTeam team, WTGroup group, boolean isRoleGroup)
			throws WTException {
		if (group == null || team == null) {
			if (logger.isDebugEnabled())
				logger.debug(
						"Either team or the group is null team : " + (team == null) + " group : " + (group == null));
			return new ArrayList<WTPrincipal>();
		}

		// need to get the WTGroup from the team, if the Group is a backing
		// group representing roles.
		WTGroup parentGroup = null;
		if (isRoleGroup) {
			parentGroup = ContainerTeamHelper.service.findContainerTeamGroup(team, ContainerTeamHelper.ROLE_GROUPS,
					group.getName());
		} else {
			parentGroup = group;
		}

		// gets the direct members of the group.
		@SuppressWarnings("unchecked")
		Enumeration<WTPrincipal> members = getOrganizationServicesManager().members(parentGroup, false);
		List<WTPrincipal> childElements = new ArrayList<WTPrincipal>();
		childElements.addAll(Collections.list(members));
		if (logger.isDebugEnabled()) {
			logger.debug("childElements : " + childElements);
		}
		return childElements;
	}

	/**
	 * Gets the direct members of a WTGroup. if the group is a backing group
	 * representing a role, then we might have to get the members from the local
	 * team as well as shared team if applicable.
	 * 
	 * @param group
	 *            - group that is of interest
	 * @return direct members of the group
	 * @throws WTException
	 */
	public static HashSet<WTPrincipal> getMembers(WTGroup group) throws WTException {
		HashSet<WTPrincipal> members = new HashSet<WTPrincipal>();
		RouteParticipantsBean participantsbean = getParticipantsBean();
		ContainerTeam localTeam = participantsbean.getLocalContainerTeam();
		ContainerTeam sharedTeam = participantsbean.getSharedContainerTeam();

		if (isARoleGroup(group)) {

			if (localTeam != null) {
				members.addAll(getDirectMembers(localTeam, group, true));
			}

			if (sharedTeam != null) {
				members.addAll(getDirectMembers(sharedTeam, group, true));
			}

		} else {
			members.addAll(getDirectMembers(localTeam, group, false));
		}

		return members;
	}

	/**
	 * Helper method to check if the role is valid to be added to the list. The
	 * default role is not valid in the participants table.
	 * 
	 * @param principal
	 * @return
	 */
	protected static boolean isValidRole(WTPrincipal principal) {

		if (principal != null && !(principal.getName().equals(ContainerTeamHelper.DEFAULT_ROLE))) {
			return true;
		}
		return false;

	}

	/**
	 * Returns the OrganizationServicesManager. <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @return OrganizationServicesManager
	 */
	private static OrganizationServicesManager getOrganizationServicesManager() {
		return OrganizationServicesHelper.manager;
	}

	/**
	 * Returns the LifeCycleService. <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @return LifeCycleService
	 */
	private static LifeCycleService getLifeCycleService() {
		return LifeCycleHelper.service;
	}

	/**
	 * checks if the given principal is member of any Groups that is identified
	 * as initially selected principals.
	 * 
	 * @param initiallySelectedMap
	 *            - Map that contains the direct members that are identified as
	 *            initially selected principals
	 * @param principal
	 *            the principal to check for
	 * @param role
	 *            the role of interest
	 * @return indicator if the given principal is a member of the initially
	 *         selected group.
	 * @throws WTException
	 */
	public static boolean isDescendantOfInitiallyChecked(Map<String, Set<WTPrincipal>> initiallySelectedMap,
			WTPrincipal principal, String role) throws WTException {
		boolean isMember = false;
		if (initiallySelectedMap != null && role != null && principal != null
				&& initiallySelectedMap.get(role) != null) {
			for (WTPrincipal principal_next : initiallySelectedMap.get(role)) {
				if (principal_next instanceof WTGroup && ((WTGroup) principal_next).isMember(principal)) {
					isMember = true;
					break;
				}
			}
		}
		return isMember;
	}

	/**
	 * This method does check if we need to use Default Promotion process for
	 * processing.
	 * 
	 * @param clientData
	 * @return flag indicating if the default process need to be used for
	 *         processing
	 * @throws WTException
	 */
	public static boolean useDefaultPromotionProcess(NmCommandBean clientData) throws WTException {

		String templateSelected = clientData.getTextParameter("templateSelected");
		if (templateSelected == null || ("".equals(templateSelected))) {
			return true;
		}
		return false;
	}

	/**
	 * Returns a List containing principals from both the shared team and the
	 * local team in the case where the shared team is marked as being
	 * extendable. If the shared team is not marked as being extentable then the
	 * shared team members will be in the container team by default.
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param participantsBean
	 * @param container
	 * @return Vector
	 * @throws WTException
	 */
	@SuppressWarnings("unchecked")
	protected static WTHashSet getTeamMembers(RouteParticipantsBean participantsBean, WTContainer container)
			throws WTException {
		ContainerTeam containerTeam = participantsBean.getLocalContainerTeam();
		WTHashSet teamList = containerTeam != null ? new WTHashSet(containerTeam.getMembers()) : new WTHashSet();
		ContainerTeam sharedContainerTeam = participantsBean.getSharedContainerTeam();
		if (sharedContainerTeam != null) {
			teamList.addAll(sharedContainerTeam.getMembers());
		}

		if (teamList.size() > 0 && doFlattenTheGroups(container)) {
			WTHashSet members = new WTHashSet();
			members.addAll(teamList);
			for (Object object : members.persistableCollection()) {
				HashSet<WTPrincipal> principals = new HashSet<WTPrincipal>();
				flattenPrincipal((WTPrincipal) object, principals);
				teamList.addAll(principals);
			}
		}
		return teamList;
	}

	/**
	 * Returns the value of the 'Flatten the group' preference
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param container
	 * @return true if the preference to flatten the group is true, otherwise
	 *         false
	 * @throws WTException
	 */
	protected static boolean doFlattenTheGroups(WTContainer container) throws WTException {
		WTUser user = (WTUser) SessionHelper.getPrincipal();
		WTContainerRef containerRef = WTContainerRef.newWTContainerRef(container);
		Object pref = PreferenceHelper.service.getValue(containerRef, FLATTENED_MEMBERS_PREF,
				PreferenceClient.WINDCHILL_CLIENT_NAME, user);
		if ((pref != null) && (((Boolean) pref).booleanValue() == true)) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Given the WTPrincipal, this method inflates it getting all the members in
	 * it
	 * 
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 * 
	 * @param principal
	 *            - given principal
	 * @param principals
	 *            - flattened collection of principals
	 */

	protected static void flattenPrincipal(WTPrincipal principal, HashSet<WTPrincipal> principals) throws WTException {
		principals.add(principal);
		if (principal instanceof WTGroup) {
			Enumeration<?> members = getOrganizationServicesManager().members((WTGroup) principal, false);
			while (members.hasMoreElements()) {
				flattenPrincipal((WTPrincipal) members.nextElement(), principals);
			}
		}
	}

	/**
	 * Given a container reference returns the initially selected promotion
	 * request participants. The keys in the map returned are the roles and the
	 * values are the list of principals for the role. If the role is mapped to
	 * another role via promotion preference, then we get the initially selected
	 * participants from the mapped role.Otherwise we derive the initially
	 * selected participants from the given role.
	 * 
	 * @param containerRef
	 *            - the container ref
	 * @param roles
	 *            - all the the roles/columns that are applicable.
	 * @return a map of initially selected participants
	 * @throws WTException
	 */
	public static Map<String, Set<WTPrincipal>> getInitiallySelectedParticipantMap(WTContainerRef containerRef,
			List<String> roles) throws WTException {
		Map<String, Set<WTPrincipal>> participantMap = new HashMap<String, Set<WTPrincipal>>();
		// The mapped roles based on Fixed Roles for Promote preference.
		Map<String, List<String>> map = new HashMap<String, List<String>>();// getFixedRolesForPromote(containerRef);

		for (String role : roles) {
			List<String> containerRoleStrList = new ArrayList<String>();
			// if the map is mapped to a different role via preference, use the
			// mapped role.
			if (map.containsKey(role)) {
				containerRoleStrList.addAll(map.get(role));
			} else {
				containerRoleStrList.add(role);
			}
			for (String roleStr : containerRoleStrList) {
				Set<WTPrincipal> roleParticipants = getParticipants(roleStr);
				if (roleParticipants != null) {
					participantMap.put(role, roleParticipants);
				}
			}
		}
		return participantMap;
	}

	/**
	 * Explodes members from their respective groups.
	 */
	private static HashSet<WTPrincipal> explodeGroupsMembers(Set<WTPrincipal> participants) throws Exception {
		if (logger.isTraceEnabled())
			logger.trace(">>In explodeGroupsMembers() method");
		Vector teamVec = new Vector();
		teamVec.addAll(participants);

		Enumeration teamEnum = teamVec.elements();
		HashSet<WTPrincipal> uniqueMembers = new HashSet<WTPrincipal>();
		uniqueMembers.addAll(teamVec);

		while (teamEnum.hasMoreElements()) {
			Object obj = teamEnum.nextElement();
			Object prinRef;
			if (obj instanceof WTPrincipalReference)
				prinRef = ((WTPrincipalReference) obj).getObject(); // Gets
																	// Objects
																	// viz.
																	// WTGroup &
																	// WTUser
			else
				prinRef = obj;

			/* If Group then explode members */
			if (prinRef instanceof WTGroup) {
				WTGroup group = (WTGroup) prinRef;
				Enumeration groupMembers = group.members();
				/* There are members within group */
				while (groupMembers.hasMoreElements()) {
					Object o = groupMembers.nextElement();
					uniqueMembers.add((WTPrincipal) o);
					if (logger.isTraceEnabled())
						logger.trace(">>uniqueMembers Added -" + o);
				}
			}
		}
		if (logger.isTraceEnabled())
			logger.trace(">>Out explodeGroupsMembers() method");

		return uniqueMembers;
	}

	/**
	 * Returns the model data for the command class.
	 * 
	 * @param clientData
	 * @return a hash set of participants
	 * @throws WTException
	 */
	@SuppressWarnings("unchecked")
	public static Collection<WTPrincipal> getParticipantList(NmCommandBean clientData) throws WTException {
		Set<WTPrincipal> participants = new HashSet<WTPrincipal>();

		if (clientData == null) {
			logger.debug("No command bean found in request...");
			return participants;
		}

		RouteParticipantsBean participantsBean = RouteTeamParticipantsHelper.getParticipantsBean(clientData);
		// participants.addAll(participantsBean.getOrgGroupList());

		HashSet<WTPrincipal> roleGroups = participantsBean.getRoleGroupList();
//		for (WTPrincipal roleGroup : roleGroups) {
//			if (isValidRole(roleGroup)) {
//				participants.add(roleGroup);
//			}
//		}
		HashSet<WTPrincipal> filteredSet = new HashSet<WTPrincipal>();
		for (WTPrincipal wtPrincipal : roleGroups) {
			if ("PACKAGE APPROVER".equals(wtPrincipal.getName())) {
				filteredSet.add(wtPrincipal);
				ContainerTeamManaged viewingContainer = (ContainerTeamManaged) clientData.getViewingContainer();
				ContainerTeam team = ContainerTeamHelper.service
						.getContainerTeam((ContainerTeamManaged) viewingContainer);
				List all = team.getAllPrincipalsForTarget(Role.toRole(wtPrincipal.getName()));
				participants.addAll(all);
			}
		}
		if (!filteredSet.isEmpty()) {
			roleGroups = filteredSet;
		}
		// participants.addAll(getTeamMembers(participantsBean, clientData
		// .getContainer()));

		ContainerTeam localTeam = participantsBean.getLocalContainerTeam();
//		if (localTeam != null)
//			participants.add(ContainerTeamHelper.service.findContainerTeamGroup(localTeam,
//					ContainerTeamHelper.TEAM_MEMBERS, ContainerTeamHelper.TEAM_MEMBERS));

		/* Explode Group Members */
		if (ROUTE_EXPLODE_GROUPS) {
			try {
				if (participants != null)
					participants = explodeGroupsMembers(participants);
			} catch (Exception e) {
				if (logger.isDebugEnabled())
					logger.debug(e.getLocalizedMessage(), e);
			}
		}

		String viewChange = null;
		if ((clientData.getRequest() != null)) {
			viewChange = clientData.getRequest().getParameter("viewchange");
		}

		boolean onViewChange = false;
		if ((viewChange != null) && (viewChange.equalsIgnoreCase("true"))) {
			onViewChange = true;
		}

		String currentViewKey = com.ptc.core.htmlcomp.components.TableViewUtils
				.getCurrentViewKey(RouteDescriptorConstants.TableIdentifiers.ROUTE_TEAM_TABLE);

		// Not the best way to check if current view is 'View Selected Members'
		// as these numbers(workflowResource.38) may change
		// But since getCurrentView returns string in server specific locale,
		// comparison could not be made directly with'View Selected Members' as
		// was done earlier.
		// As of now dont see any other approach to solve this issue.
		if ("com.ptc.netmarkets.workflow.workflowResource.38".equals(currentViewKey)) {
			if (onViewChange) {
				ArrayList specialparticipants = new ArrayList();
				java.util.Iterator iter = participants.iterator();
				while (iter.hasNext()) {
					Object tobj = iter.next();
					wt.fc.Persistable obj = null;
					if (tobj instanceof wt.org.WTPrincipalReference) {
						obj = ((wt.org.WTPrincipalReference) tobj).getObject();
					} else if (tobj instanceof wt.org.WTGroup) {
						obj = ((wt.org.WTGroup) tobj);
					}
					if (obj != null) {
						wt.fc.ObjectIdentifier oid = obj.getPersistInfo().getObjectIdentifier();
						HashMap selectedParticipant = clientData.getChecked();
						java.util.Iterator iter1 = selectedParticipant.keySet().iterator();
						boolean isParticipantChecked = false;
						while (iter1.hasNext()) {
							Object tempObj = iter1.next();
							if (((tempObj.toString()).indexOf(oid.toString())) >= 0) {
								isParticipantChecked = true;
								break;
							}
						}
						if (!isParticipantChecked) {
							specialparticipants.add(tobj);
						}
					}
				}
				participants.removeAll(specialparticipants);
			} else {
				// getInitiallySelectedParticipantMap
				List<String> roles = new ArrayList<String>();
				roles = NmWorkflowHelper.service.getParticipantRoles(clientData);
				Map<String, Set<WTPrincipal>> initialParticiapnt = getInitiallySelectedParticipantMap(
						clientData.getContainerRef(), roles);
				initialParticiapnt.size();
				Set specialparticipants = new HashSet();
				if (initialParticiapnt != null) {
					java.util.Iterator iter1 = initialParticiapnt.keySet().iterator();
					while (iter1.hasNext()) {
						HashSet tempObj = (HashSet) initialParticiapnt.get(iter1.next());
						java.util.Iterator iter2 = tempObj.iterator();
						while (iter2.hasNext()) {
							specialparticipants.add(iter2.next());
						}
					}
				}
				return specialparticipants;
			}
		}

		if (logger.isDebugEnabled()) {
			logger.debug("participants : " + participants);
		}

		return participants;
	}

	public static RouteParticipantsBean getParticipantsBean(NmCommandBean formData) throws WTException {
		return getParticipantsBean(formData, true);
	}

	/**
	 * This method does create a participants bean and set the bean attributes,
	 * if a bean is not created for session. Would set the local container team,
	 * shared container team and the role groups from the local team and shared
	 * team , if applicable. Only sets the container attributes if the
	 * setAllAttributes is false;
	 * 
	 * @param formData
	 * @param setAllAttributes
	 * @return
	 * @throws WTException
	 */
	public static RouteParticipantsBean getParticipantsBean(NmCommandBean formData, boolean setAllAttributes)
			throws WTException {
		RouteParticipantsBean participantsbean = RouteTeamParticipantsHelper.getParticipantsBean();

		// only initializes, if the table tree map is not initialized.
		boolean initialized = participantsbean.isInitialized();

		if (initialized) {
			logger.debug("The bean have been initialized, so need not initialize it again...");
			return participantsbean;
		}

		if (formData == null) {
			logger.debug("No command bean found in request...");
			return participantsbean;
		}

		WTContainer container = formData.getViewingContainer();
		if (container != null && container instanceof ContainerTeamManaged) {
			ContainerTeamManaged ctm = (ContainerTeamManaged) container;

			// sets the local container team
			ContainerTeam containerTeam = ContainerTeamHelper.service.getContainerTeam((ContainerTeamManaged) container,
					false);
			participantsbean.setLocalContainerTeam(containerTeam);

			ContainerTeam sharedContainerTeam = null;
			if (ctm.getContainerTeamManagedInfo().getSharedTeamId() != null) {

				// sets the shared container team
				sharedContainerTeam = ContainerTeamHelper.service.getContainerTeam((ContainerTeamManaged) container,
						true);
				participantsbean.setSharedContainerTeam(sharedContainerTeam);
			}
			if (setAllAttributes) {
				// set the groups that are backing groups representing the
				// roles.
				HashSet<WTPrincipal> roles = new HashSet<WTPrincipal>();
				roles.addAll(KBRouteTeamParticipantsHelper.getGroupsForSearchBase(containerTeam,
						ContainerTeamHelper.ROLE_GROUPS));

				if (sharedContainerTeam != null) {
					roles.addAll(KBRouteTeamParticipantsHelper.getGroupsForSearchBase(sharedContainerTeam,
							ContainerTeamHelper.ROLE_GROUPS));
				}
				HashSet<WTPrincipal> filteredSet = new HashSet<WTPrincipal>();
				for (WTPrincipal wtPrincipal : roles) {
					if ("PACKAGE APPROVER".equals(wtPrincipal.getName())) {
						filteredSet.add(wtPrincipal);
					}
				}
				if (!filteredSet.isEmpty()) {
					roles = filteredSet;
				}
				participantsbean.setRoleGroupList(roles);

				Enumeration<?> orgGroups = null;
				if (participantsbean.getLocalContainerTeam() != null)

					orgGroups = ContainerTeamHelper.service.findContainerTeamGroups(
							participantsbean.getLocalContainerTeam(), ContainerTeamHelper.ORG_GROUPS);

				if (participantsbean.getSharedContainerTeam() != null)

					orgGroups = ContainerTeamHelper.service.findContainerTeamGroups(
							participantsbean.getSharedContainerTeam(), ContainerTeamHelper.ORG_GROUPS);

				// if (orgGroups != null) {
				// @SuppressWarnings("unchecked")
				// Collection<WTPrincipal> orgGroupCollection =
				// (Collection<WTPrincipal>) Collections
				// .list(orgGroups);
				// participantsbean.setOrgGroupList(orgGroupCollection);
				// }
			}
			setProcessTeam(formData, participantsbean);

		}

		participantsbean.setBeanToInitialized();

		if (logger.isDebugEnabled()) {
			logger.debug("Local Team  : " + participantsbean.getLocalContainerTeam());
			logger.debug("Shared Team  : " + participantsbean.getSharedContainerTeam());
			logger.debug("RoleGroups list  : " + participantsbean.getRoleGroupList());
		}
		return participantsbean;

	}

	public static void setProcessTeam(NmCommandBean cb, RouteParticipantsBean participantsbean) throws WTException {
		Locale locale = SessionHelper.getLocale();
		LifeCycleTemplate lct = null;
		WfProcess process = null;
		String routeChoice = (String) cb.getRadio().get(NmWorkflowHelper.CHOICE);
		NmOid oid = null;

		ArrayList sel = cb.getSelectedInOpener();
		if (sel == null || sel.size() == 0) {
			sel = cb.getSelected();
			for (int i = 0; i < sel.size(); i++) {
				Object nextObj = sel.get(i);
				if (nextObj instanceof NmContext) {
					oid = ((NmContext) nextObj).getPrimaryOid();
				}
			}
		} else {
			for (int i = 0; i < sel.size(); i++) {
				Object nextObj = sel.get(i);
				if (nextObj instanceof NmContext) {
					oid = ((NmContext) nextObj).getTargetOid();
				}
			}
		}

		if (routeChoice != null && routeChoice.equals(NmWorkflowHelper.UPDATE)) {
			if (oid == null) {
				oid = (NmOid) cb.getActionOidsWithoutWizard().get(0);
			}
			lct = getLCT(oid);
			process = getProcess(oid);
		} else {
			String actionName = cb.getRequest().getParameter("actionName");

			if (actionName.equalsIgnoreCase("route")) {
				Object temp = cb.getRequest().getParameter("routingLCTemplate");
				oid = NmOid.newNmOid(temp.toString());
			} else {
				Object temp = cb.getRequest().getParameter("oid");
				oid = NmOid.newNmOid(temp.toString());
			}

			if (oid == null) {
				oid = (NmOid) cb.getActionOidsWithoutWizard().get(0);
			}
			if (oid.isA(LifeCycleTemplate.class))
				lct = (LifeCycleTemplate) oid.getRef();
			else if (oid.isA(WfProcess.class))
				process = (WfProcess) oid.getRef();
		}

		if (process != null && process.getTeamId() != null) {
			WTRoleHolder2 processTeam = null;
			processTeam = (Team) process.getTeamId().getObject();
			participantsbean.setProcessTeam(processTeam);
		}

	}

	private static LifeCycleTemplate getLCT(NmOid oid) throws WTException {
		LifeCycleTemplate lct = null;
		WTObject businessObject = null;
		WfProcess process = null;

		if (oid.isA(WfProcess.class)) {
			process = (WfProcess) oid.getRef();
			ReferenceFactory rf = new ReferenceFactory();
			WTReference brof = process.getBusinessObjectReference(rf);

			if (brof == null) {
				if (process.isNested()) {
					businessObject = (WTObject) process.getContext().getValue(WfDefinerHelper.PRIMARY_BUSINESS_OBJECT);
				}
			}

			if (brof != null && brof.getKey() != null) {
				businessObject = (wt.fc.WTObject) brof.getObject();
			}

			lct = (LifeCycleTemplate) ((LifeCycleManaged) businessObject).getLifeCycleTemplate().getObject();

		} else {
			lct = (LifeCycleTemplate) ((LifeCycleManaged) oid.getRef()).getLifeCycleTemplate().getObject();

		}
		if (logger.isTraceEnabled())
			logger.trace(">>Out StandardNmWorkflowService...getLCT() method--" + lct);

		return lct;
	}

	private static WfProcess getProcess(NmOid oid) throws WTException {
		WfProcess process = null;
		if (oid.isA(WfProcess.class)) {
			process = (WfProcess) oid.getRef();
		} else {
			getProcessForOid(oid, null);
			process = (WfProcess) oid.getProcess();
		}
		if (logger.isTraceEnabled())
			logger.trace(">>Out StandardNmWorkflowService...getProcess() method--" + oid);
		return process;
	}

	private static void getProcessForOid(NmOid oid, WTContainer container) throws WTException {
		Persistable p = (Persistable) oid.getRef();
		// if we pass the cref, we might miss the process in the source
		// container
		Enumeration proceses = NmWorkflowHelper.service.getAssociatedProcesses(p, WfState.OPEN, null);
		if (proceses.hasMoreElements()) {
			oid.setProcess(proceses.nextElement());
		} else {
			getCompletedProcessForOid(oid);
		}
	}

	private static void getCompletedProcessForOid(NmOid oid) throws WTException {
		Persistable p = (Persistable) oid.getRef();
		Enumeration proceses = NmWorkflowHelper.service.getAssociatedProcesses(p, WfState.CLOSED_COMPLETED, null);
		if (proceses.hasMoreElements()) {
			oid.setProcess(proceses.nextElement());
		}
	}
}
