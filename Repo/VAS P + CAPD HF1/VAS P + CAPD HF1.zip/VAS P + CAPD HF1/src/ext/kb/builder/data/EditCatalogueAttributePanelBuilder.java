/**
 * 
 */
package ext.kb.builder.data;

import com.ptc.core.components.rendering.guicomponents.IconComponent;
import com.ptc.core.components.rendering.guicomponents.UrlDisplayComponent;
import com.ptc.core.ui.resources.ComponentMode;
import com.ptc.core.ui.resources.ComponentType;
import com.ptc.jca.mvc.components.JcaComponentParams;
import com.ptc.mvc.components.AbstractComponentBuilder;
import com.ptc.mvc.components.AttributeConfig;
import com.ptc.mvc.components.AttributePanelConfig;
import com.ptc.mvc.components.ComponentBuilder;
import com.ptc.mvc.components.ComponentConfig;
import com.ptc.mvc.components.ComponentConfigFactory;
import com.ptc.mvc.components.ComponentParams;
import com.ptc.mvc.components.GroupConfig;
import com.ptc.netmarkets.util.beans.NmCommandBean;

import ext.kb.util.KBConstants;
import wt.epm.EPMDocument;
import wt.fc.Persistable;
import wt.util.WTException;


/**
 * @author bankowskie
 *
 */
@ComponentBuilder("ext.kb.builder.data.EditCatalogueAttributePanelBuilder")
public class EditCatalogueAttributePanelBuilder extends AbstractComponentBuilder {

	private static final String GEKLA_DATAUTILITY = "KB_GEKLA";
	private static final String MATERIAL_DATAUTILITY = "KB_MATERIAL";
	private static final String DESCRIPTION_DATAUTILITY = "KB_TRANSLATION_ID";
	private static final String DESCRIPTION2_DATAUTILITY = "KB_TRANSLATION2_ID";
	private static final String ACTION_NAME = "actionName";
	
	
	@Override
	public Object buildComponentData(ComponentConfig config, ComponentParams params) throws Exception {
		NmCommandBean commandBean = ((JcaComponentParams) params).getHelperBean().getNmCommandBean();
		Persistable primaryObject = commandBean.getPrimaryOid().getWtRef().getObject();
		EPMDocument epm = (EPMDocument) primaryObject;
		return epm;
	}

	@Override
	public ComponentConfig buildComponentConfig(ComponentParams params) throws WTException {
		ComponentConfigFactory ccf = getComponentConfigFactory();
		AttributePanelConfig panelConfig = ccf.newAttributePanelConfig();

		NmCommandBean commandBean = ((JcaComponentParams) params).getHelperBean().getNmCommandBean();
		String actionName = getActionName(commandBean);

		panelConfig.setComponentMode(ComponentMode.EDIT);

		panelConfig.setType(EPMDocument.class.getName());
		panelConfig.setComponentType(ComponentType.WIZARD_ATTRIBUTES_TABLE);

		GroupConfig groupConfig = ccf.newGroupConfig("epmAttributesGroup");
		groupConfig.setLabel("Edit Catalogues");

		if (actionName != null) {
			AttributeConfig descConfig = ccf.newAttributeConfig(KBConstants.TRANSLATION_ID_IBA);
			descConfig.setLabel("Description1 (Dyn)");
			descConfig.setDataUtilityId(DESCRIPTION_DATAUTILITY);
			groupConfig.addComponent(descConfig);
			
			AttributeConfig desc2Config = ccf.newAttributeConfig(KBConstants.TRANSLATION2_ID_IBA);
			desc2Config.setLabel("Description2 (Dyn)");
			desc2Config.setDataUtilityId(DESCRIPTION2_DATAUTILITY);
			groupConfig.addComponent(desc2Config);
			
			AttributeConfig matConfig = ccf.newAttributeConfig(KBConstants.KBMATERIAL_IBA);
			matConfig.setLabel("Material");
			matConfig.setDataUtilityId(MATERIAL_DATAUTILITY);
			groupConfig.addComponent(matConfig);
		}
		panelConfig.addComponent(groupConfig);
		return panelConfig;
	}
	
	private String getActionName(NmCommandBean commandBean) {
		String name = null;
		Object actionObj = commandBean.getRequestData().getParameterMap().get(ACTION_NAME);
		if (actionObj != null && actionObj instanceof String[]) {
			name = ((String[]) actionObj)[0];
		}
		return name;
	}
}
