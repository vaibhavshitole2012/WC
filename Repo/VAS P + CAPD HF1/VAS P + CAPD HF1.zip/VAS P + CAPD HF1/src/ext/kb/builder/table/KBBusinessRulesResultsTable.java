package ext.kb.builder.table;

import wt.util.WTException;

import com.ptc.jca.mvc.components.JcaComponentParams;
import com.ptc.jca.mvc.components.JcaTableConfig;
import com.ptc.mvc.components.ComponentConfig;
import com.ptc.mvc.components.ComponentParams;
import com.ptc.mvc.components.OverrideComponentBuilder;
import com.ptc.windchill.enterprise.businessRules.mvc.builders.BusinessRulesResultsTable;

/**
 * Business rules table builder.
 *
 */

@OverrideComponentBuilder
public class KBBusinessRulesResultsTable extends BusinessRulesResultsTable {

	@Override
	public ComponentConfig buildComponentConfig(ComponentParams componentParams) throws WTException {
		ComponentConfig tableConfig = super.buildComponentConfig(componentParams);

		boolean isGroupByObjectView = isGroupByObject((JcaComponentParams) componentParams);

		if (isGroupByObjectView) {
			JcaTableConfig jcaTableConfig = (JcaTableConfig) tableConfig;
			jcaTableConfig.setSelectable(true);
		}

		return tableConfig;
	}
}
