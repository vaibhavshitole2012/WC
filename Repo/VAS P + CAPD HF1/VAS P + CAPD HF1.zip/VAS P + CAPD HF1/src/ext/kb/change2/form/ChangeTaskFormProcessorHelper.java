package ext.kb.change2.form;

import java.util.HashMap;
import java.util.Set;

import org.apache.log4j.Logger;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.FormProcessingStatus;
import com.ptc.core.components.forms.FormResult;
import com.ptc.core.components.util.FeedbackMessage;
import com.ptc.windchill.enterprise.wizardParticipant.beans.RoleParticipantOid;
import com.ptc.windchill.enterprise.wizardParticipant.delegate.ParticipantSelectionDelegate;

import wt.change2.WTChangeActivity2;
import wt.log4j.LogR;
import wt.project.Role;
import wt.util.WTException;

public class ChangeTaskFormProcessorHelper {

	protected static final Logger logger = LogR.getLogger(ChangeTaskFormProcessorHelper.class.getName());

	private static final String ASSIGNEE = "ASSIGNEE";
	private static final String ERROR_MESSAGE_ASSIGNEE = "Assignee for the Change Task is required";
	private static final String ERROR_MESSAGE_NAME_LENGTH = "Short description of the Change Task should not be longer than 160 characters";

	private static final Role ASSIGNEE_ROLE = Role.toRole(ASSIGNEE);

	private ChangeTaskFormProcessorHelper() {
	};

	public static void validateChangeTaskName(ObjectBean bean, FormResult result) {
		WTChangeActivity2 changeActivity = (WTChangeActivity2) bean.getObject();
		if (changeActivity.getName().length() > 160) {
			addFeedbackMessage(ERROR_MESSAGE_NAME_LENGTH, result);
		}
	}

	public static void validateChangeTaskAssignee(ObjectBean bean, FormResult result) throws WTException {
		ParticipantSelectionDelegate selectionDelegate = ParticipantSelectionDelegate.newInstance(bean);
		HashMap<Role, Set<RoleParticipantOid>> userSelected = selectionDelegate.getUserSelected();
		logger.debug(String.format("Selected principals: %s", userSelected));

		if (!userSelected.keySet().contains(ASSIGNEE_ROLE)) {
			addFeedbackMessage(ERROR_MESSAGE_ASSIGNEE, result);
		}
	}

	private static void addFeedbackMessage(String message, FormResult result) {
		FeedbackMessage feedback = new FeedbackMessage();
		feedback.addMessage(message);
		result.addFeedbackMessage(feedback);
		result.setStatus(FormProcessingStatus.FAILURE);
	}

}
