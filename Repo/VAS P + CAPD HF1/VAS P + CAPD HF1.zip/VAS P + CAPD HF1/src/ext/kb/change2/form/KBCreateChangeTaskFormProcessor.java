package ext.kb.change2.form;

import java.util.List;

import org.apache.log4j.Logger;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.FormProcessingStatus;
import com.ptc.core.components.forms.FormResult;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import com.ptc.windchill.enterprise.change2.forms.ChangeManagementFormProcessorHelper;
import com.ptc.windchill.enterprise.change2.forms.processors.CreateChangeTaskFormProcessor;

import ext.kb.util.KBType;
import wt.log4j.LogR;
import wt.util.WTException;

public class KBCreateChangeTaskFormProcessor extends CreateChangeTaskFormProcessor {

	protected static final Logger logger = LogR.getLogger(KBCreateChangeTaskFormProcessor.class.getName());

	@Override
	public FormResult postProcess(NmCommandBean cmdBeans, List<ObjectBean> objBeans) throws WTException {
		FormResult result = null;

		try {
			result = super.postProcess(cmdBeans, objBeans);
			if (result.getStatus() == FormProcessingStatus.SUCCESS) {
				for (ObjectBean bean : objBeans) {
					if (KBType.isDescendedFrom(bean.getObject(), "com.ptc.KBECT")) {
						ChangeTaskFormProcessorHelper.validateChangeTaskName(bean, result);
						ChangeTaskFormProcessorHelper.validateChangeTaskAssignee(bean, result);
					}
				}
			}
		} catch (Exception e) {
			result = ChangeManagementFormProcessorHelper.handleFormResultException(result, getLocale(), e,
					getProcessorErrorMessage());
			logger.error(e);
		}

		return result;
	}

}
