package ext.kb.change2.flexible;

import ext.kb.util.KBUtils;
import wt.change2.WTChangeRequest2;
import wt.change2.flexible.FlexibleChangeItemReadinessDelegate;
import wt.fc.ObjectReference;
import wt.fc.collections.WTCollection;
import wt.fc.collections.WTKeyedHashMap;
import wt.fc.collections.WTKeyedMap;
import wt.util.WTException;
import wt.util.WTMessage;

public class KBFlexibleChangeItemReadinessDelegate extends FlexibleChangeItemReadinessDelegate {

	@Override
	public WTKeyedMap determineReadiness(WTCollection changeItems) throws WTException {
		
		WTKeyedMap changeItemToReadinessMap = new WTKeyedHashMap();

		for (Object object : changeItems) {

			boolean isReady = false;
			boolean shouldContinue = false;
			WTMessage reasonMsg = null;
			ReadinessInfo readinessInfo = null;
			ObjectReference changeItemRef = (ObjectReference) object;
			Object changeItemObject = changeItemRef.getObject();
			
			if (changeItemObject instanceof WTChangeRequest2) {

				WTChangeRequest2 changeItem = (WTChangeRequest2) changeItemObject;
				if (KBUtils.isInKB(changeItem)) {

					reasonMsg = new WTMessage(null, "Change Request {0} marked as ready",
							new Object[] { changeItem.getNumber() });
					isReady = true;
					
				} else {
					reasonMsg = new WTMessage(null, "Change Request {0} marked as not ready",
							new Object[] { changeItem.getNumber() });
				}
			} else {
				reasonMsg = new WTMessage(null, "Not a Change Request, marked as not ready",
						new Object[] {});
			}

			readinessInfo = new ReadinessInfo(isReady, changeItemRef, reasonMsg);
			readinessInfo.setShouldContinueProcessing(shouldContinue);
			changeItemToReadinessMap.put(object, readinessInfo);
		}

		return changeItemToReadinessMap;
	}
	
}
