package ext.kb.change2.form.delegate;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Vector;

import org.apache.log4j.Logger;

import wt.change2.ChangeItemIfc;
import wt.change2.ChangeRequest2;
import wt.change2.WTChangeRequest2;
import wt.configurablelink.ConfigurableLinkHelper;
import wt.fc.collections.WTArrayList;
import wt.fc.collections.WTCollection;
import wt.pds.ObjectReferenceOidHolder;
import wt.util.WTException;
import wt.vc.VersionForeignKey;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.FormResult;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import com.ptc.netmarkets.util.misc.NmContextStringTokenizer;
import com.ptc.windchill.enterprise.change2.forms.delegates.ChangeItemFormDelegate;

import ext.kb.util.DBUtils;
import ext.kb.util.KBTypeIdProvider;
import ext.kb.util.KBUtils;

public class KBAssociateEcrWithRedDelegate extends ChangeItemFormDelegate {

    private WTChangeRequest2 association;
    private static final String CLASSNAME = KBAssociateEcrWithRedDelegate.class.getName();
	static Logger logger = Logger.getLogger(CLASSNAME);
	
    @Override
    public FormResult postProcess(NmCommandBean paramNmCommandBean, List<ObjectBean> paramList) throws WTException {
    	logger.trace("postProcess - start");
    	Object o = paramList.get(0).getObject();
    	if  (KBTypeIdProvider.isDescendant(o, "ECR")) {
	    	@SuppressWarnings("unchecked")
	        HashMap<String, String> idValues = paramNmCommandBean.getOldText();
	        Iterator<Entry<String, String>> it = idValues.entrySet().iterator();
	        while (it.hasNext()) {
	            Entry<String, String> item = it.next();
	            if (item.getKey().startsWith("redItemPicker")) {
	            	String value = item.getValue();
					if (!KBUtils.isEmpty(value)) {
						NmContextStringTokenizer t = new NmContextStringTokenizer(value, ':');
		                String identifierType = t.nextToken();
		                String classText = t.nextToken();
		                String id = t.nextToken();
		                if (identifierType.endsWith("VR")) {
		                    try {
		                        VersionForeignKey oid = new VersionForeignKey();
		                        oid.setClassname(classText);
		                        oid.setBranchId(Long.parseLong(id));
		                        association = DBUtils.queryObjectById(WTChangeRequest2.class, oid);
		                    } catch (NumberFormatException e) {
		                        throw new RuntimeException("Unable to parse project id", e);
		                    } 
		                }
					}
					break;
	            }
	        }
    	}
        FormResult res = super.postProcess(paramNmCommandBean, paramList);
        logger.trace("postProcess - exit");
        return res;
    }

    @Override
    protected Class getAssociationClass(ChangeItemIfc paramChangeItemIfc) {
        return WTChangeRequest2.class;
    }

    @Override
    protected String getDefaultTableId() {
        return "kbecr.kbdefinereddependency";
    }

    @Override
    protected String getDelegateName() {
        return KBAssociateEcrWithRedDelegate.class.toString();
    }

    @Override
    protected Vector getItemsToStoreForAssociation(List paramList) throws WTException {
        Vector<ChangeRequest2> v = new Vector<ChangeRequest2>();
        if (association != null) {
            v.add(association);
        }
        return v;
    }

    @Override
    protected WTCollection getRefreshedAssociationLinks(ChangeItemIfc paramChangeItemIfc) throws WTException {
        WTCollection col = new WTArrayList();
        if (association != null) {
            col.add(association);
        }
        return col;
    }

    @Override
    protected WTCollection processLinkAttributes(ChangeItemIfc paramChangeItemIfc, WTCollection paramWTCollection)
            throws WTException {
        if (!paramWTCollection.isEmpty()) {
            WTChangeRequest2 req = (WTChangeRequest2)paramChangeItemIfc;
            ObjectReferenceOidHolder o = new ObjectReferenceOidHolder();
            o.setKey(req.getPersistInfo().getObjectIdentifier());
            WTCollection col = ConfigurableLinkHelper.service.createConfigurableDescribeLink(o, KBTypeIdProvider.getType("ECRREDLINK"), paramWTCollection, true);
            return col;
        } else return new WTArrayList();
    }
}
