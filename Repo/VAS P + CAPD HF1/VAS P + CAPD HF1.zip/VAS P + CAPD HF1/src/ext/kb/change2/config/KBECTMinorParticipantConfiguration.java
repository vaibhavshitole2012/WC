package ext.kb.change2.config;

import com.ptc.core.components.beans.FormDataHolder;
import ext.kb.util.KBConstants;
import wt.project.Role;
import wt.util.WTException;

import java.util.HashSet;
import java.util.Set;

public class KBECTMinorParticipantConfiguration extends KBParticipantConfiguration {

    @Override
    public Set<Role> excludedWorkflowRoles(FormDataHolder formData) throws WTException {
        HashSet<Role> hashset = new HashSet<Role>();
        hashset.add(Role.toRole("MANUFACTURING ENGINEER"));
        hashset.add(Role.toRole("RELEASE MANAGER"));
        hashset.add(Role.toRole("WF-NOTIFICATION-RECIPENT")); 
        hashset.add(Role.toRole("APPROVER"));
        hashset.add(Role.toRole("DATA MANAGEMENT"));
        hashset.add(Role.toRole("ADDITIONAL APPROVERS"));
        hashset.add(KBConstants.BONDING_ENGINEER_ROLE);
        hashset.add(KBConstants.WELDING_ENGINEER_ROLE);
        return hashset;
    }
}
