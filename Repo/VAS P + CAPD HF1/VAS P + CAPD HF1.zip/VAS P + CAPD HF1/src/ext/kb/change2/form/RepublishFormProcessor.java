package ext.kb.change2.form;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormResult;
import com.ptc.core.components.util.FeedbackMessage;
import com.ptc.core.ui.resources.FeedbackType;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;

import ext.kb.change2.helper.ChangeNoticeUtils;
import ext.kb.resources.ActionsRB;
import ext.kb.workflow.BaselineHelper;
import ext.kb.workflow.EPMChangeUtils;
import wt.change2.WTChangeActivity2;
import wt.change2.WTChangeOrder2;
import wt.epm.EPMDocument;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.WTObject;
import wt.fc.WTReference;
import wt.fc.collections.WTArrayList;
import wt.fc.collections.WTCollection;
import wt.representation.Representable;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.vc.baseline.ManagedBaseline;
import wt.vc.wip.WorkInProgressHelper;

public class RepublishFormProcessor extends DefaultObjectFormProcessor {

	private static final Logger logger = Logger.getLogger(RepublishFormProcessor.class);
	private static final String RESOURCE = "ext.kb.resources.ActionsRB";

	@Override
	public FormResult doOperation(NmCommandBean cb, List<ObjectBean> objectBeans) throws WTException {

		if (logger.isDebugEnabled()) {
			logger.debug("entering doOperation(NmCommandBean,List<ObjectBean>)");
			logger.debug("cb: " + cb);
			logger.debug("objectBeans: " + objectBeans);
		}
		FormResult result = new FormResult();

		WTCollection publishToCADCollection = getValidCadsToRepublish(cb);
		NmOid contextObjectOid = cb.getPrimaryOid();
		Object target = contextObjectOid.getRefObject();
		WTChangeActivity2 changeActivity = (WTChangeActivity2) target;
		WTChangeOrder2 changeNotice = ChangeNoticeUtils.getECN(changeActivity);
		ManagedBaseline mb = BaselineHelper.findReleasedBaseline(changeActivity, changeNotice);
		if (publishToCADCollection != null && !publishToCADCollection.isEmpty()) {
			for (Object object : publishToCADCollection) {
				EPMChangeUtils.publish((Representable) ((ObjectReference) object).getObject(), mb);
			}
		}
		updateFormResult(cb, publishToCADCollection, result);
		if (logger.isDebugEnabled()) {
			logger.debug("exiting doOperation()");
			logger.debug("returning: " + result);
		}
		return result;
	}

	private WTCollection getValidCadsToRepublish(NmCommandBean cb) throws WTException {
		if (logger.isDebugEnabled()) {
			logger.debug("entering getValidCadsToRepublish(NmCommandBean)");
			logger.debug("cb: " + cb);
		}
		WTCollection publishToCADCollection;
		WTCollection selectedCADs = getSelectedObjects(cb, true);

		publishToCADCollection = filterInvalidCADs(selectedCADs);
		if (logger.isDebugEnabled()) {
			logger.debug("exiting getValidCadsToRepublish()");
			logger.debug("returning: " + publishToCADCollection);
		}
		return publishToCADCollection;
	}

	private WTCollection filterInvalidCADs(WTCollection selectedEPMs) throws WTException {
		if (logger.isDebugEnabled()) {
			logger.debug("entering filterInvalidCADs(WTCollection)");
			logger.debug("selectedEPMs: " + selectedEPMs);
		}
		// Filter out checked out epms
		if (selectedEPMs == null || selectedEPMs.isEmpty()) {
			if (logger.isDebugEnabled()) {
				logger.debug("exiting filterInvalidCADs()");
				logger.debug("returning: " + selectedEPMs);
			}
			return selectedEPMs;
		}
		WTCollection checkedOutEPMs = WorkInProgressHelper.getCheckedOut(selectedEPMs);
		selectedEPMs.remove(checkedOutEPMs);
		if (logger.isDebugEnabled()) {
			logger.debug("exiting filterInvalidCADs()");
			logger.debug("returning: " + selectedEPMs);
		}
		return selectedEPMs;
	}

	private void updateFormResult(NmCommandBean cb, WTCollection validPartsForPublishToCAD, FormResult result)
			throws WTException {

		if (logger.isDebugEnabled()) {
			logger.debug("entering updateFormResult(NmCommandBean,WTCollection,FormResult)");
			logger.debug("cb: " + cb);
			logger.debug("validPartsForPublishToCAD: " + validPartsForPublishToCAD);
			logger.debug("result: " + result);
		}
		String messageTitle = null;
		String message = null;

		WTCollection selectedObjs = getSelectedObjects(cb, false);
		FeedbackType feedBackType = null;

		if (validPartsForPublishToCAD == null || validPartsForPublishToCAD.isEmpty()
				|| validPartsForPublishToCAD.size() == 0) {
			message = WTMessage.getLocalizedMessage(RESOURCE, ActionsRB.REPUBLISH_FAILED_MESSAGE);
			feedBackType = FeedbackType.FAILURE;
		} else {
			message = WTMessage.getLocalizedMessage(RESOURCE, ActionsRB.REPUBLISH_SUCCESS_MESSAGE);
			feedBackType = FeedbackType.SUCCESS;
		}
		FeedbackMessage feedback = new FeedbackMessage(feedBackType, SessionHelper.getLocale(), messageTitle, null,
				message);

		result.addFeedbackMessage(feedback);
		if (logger.isDebugEnabled()) {
			logger.debug("exiting updateFormResult()");
		}
	}

	private WTCollection getSelectedObjects(NmCommandBean cb, boolean returnEPMsOnly) throws WTException {
		if (logger.isDebugEnabled()) {
			logger.debug("entering getSelectedObjects(NmCommandBean,boolean)");
			logger.debug("cb: " + cb);
			logger.debug("returnEPMsOnly: " + returnEPMsOnly);
		}
		ArrayList selected = cb.getSelected();
		WTCollection selectedObjs = null;

		if (selected.size() > 0) {
			selectedObjs = convertToPersistables(selected);
			if (returnEPMsOnly) {
				selectedObjs = selectedObjs.subCollection(EPMDocument.class);
			}
		} else if (cb.getActionOid() != null) {
			// Invoked from epm details page
			NmOid oid = cb.getActionOid();
			if (returnEPMsOnly) {
				if (EPMDocument.class.isAssignableFrom(oid.getReferencedClass())) {
					WTReference wtRef = (WTReference) oid.getWtRef();
					EPMDocument epmDocument = (EPMDocument) wtRef.getObject();
					selectedObjs = new WTArrayList();
					selectedObjs.add(epmDocument);
				}
			} else {
				WTReference wtRef = (WTReference) oid.getWtRef();
				WTObject wtobject = (WTObject) wtRef.getObject();
				selectedObjs = new WTArrayList();
				selectedObjs.add(wtobject);
			}
		}

		if (logger.isDebugEnabled()) {
			logger.debug("exiting getSelectedObjects()");
			logger.debug("returning: " + selectedObjs);
		}
		return selectedObjs;
	}

	private WTArrayList convertToPersistables(ArrayList selectedObjs) throws WTException {
		if (logger.isDebugEnabled()) {
			logger.debug("entering convertToPersistables(ArrayList)");
			logger.debug("selectedObjs: " + selectedObjs);
		}
		WTArrayList persistables = new WTArrayList();
		Iterator it = selectedObjs.iterator();
		while (it.hasNext()) {
			Object obj = it.next();
			obj = NmCommandBean.getOidFromObject(obj);
			if (obj instanceof NmOid) {
				Object newObj = ((NmOid) obj).getRefObject();
				persistables.add((Persistable) newObj);
			}
		}
		if (logger.isDebugEnabled()) {
			logger.debug("exiting convertToPersistables()");
			logger.debug("returning: " + persistables);
		}
		return persistables;
	}

}
