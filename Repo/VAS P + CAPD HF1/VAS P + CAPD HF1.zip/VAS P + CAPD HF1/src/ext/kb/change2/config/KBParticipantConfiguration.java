/**
 * 
 */
package ext.kb.change2.config;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import com.ptc.core.components.beans.CreateAndEditWizBean;
import com.ptc.core.components.beans.FormDataHolder;
import com.ptc.windchill.enterprise.wizardParticipant.configuration.DefaultParticipantConfiguration;

import ext.kb.util.KBConstants;
import wt.fc.collections.WTHashSet;
import wt.fc.collections.WTSet;
import wt.inf.container.WTContainerRef;
import wt.org.OrganizationOwned;
import wt.project.Role;
import wt.team.RolePoolMap;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;


/**
 * @author ebankowski
 *
 */
public class KBParticipantConfiguration extends DefaultParticipantConfiguration{
        private static final Logger LOGGER = Logger.getLogger(KBParticipantConfiguration.class.getName());
       
        @Override
        public Set<Role> excludedWorkflowRoles(FormDataHolder formData) throws WTException {                 
                       HashSet<Role> hashset = new HashSet<Role>();
                       hashset.add(Role.toRole("ADDITIONAL APPROVERS"));
                       hashset.add(Role.toRole("MANUFACTURING ENGINEER"));
                       hashset.add(Role.toRole("RELEASE MANAGER"));
                       hashset.add(Role.toRole("WF-NOTIFICATION-RECIPENT"));
                       return hashset;
        }
        
        @Override
        public Map<Role, Set<Role>> getInitialRoleSelections(FormDataHolder formData) throws WTException {
         HashMap<Role, Set<Role>> roleSelectionMap = (HashMap<Role, Set<Role>>) super.getInitialRoleSelections(formData);
         WTContainerRef containerRef = CreateAndEditWizBean.getContainerRef(formData);
         OrganizationOwned orgOwned = (OrganizationOwned) containerRef.getObject();
         
         if (KBConstants.KB.equals(orgOwned.getOrganizationName())) {
        	 roleSelectionMap.put(KBConstants.REVIEWER_ROLE, Collections.singleton(KBConstants.CAD_APPROVE_ROLE));
        	 roleSelectionMap.put(KBConstants.BONDING_ENGINEER_ROLE, Collections.singleton(KBConstants.BONDING_ENGINEER_ROLE));
        	 roleSelectionMap.put(KBConstants.WELDING_ENGINEER_ROLE, Collections.singleton(KBConstants.WELDING_ENGINEER_ROLE));
        	 
         } else if (KBConstants.HVAC.equals(orgOwned.getOrganizationName())) {
        	 roleSelectionMap.put(KBConstants.ASSIGNEE_ROLE, Collections.singleton(KBConstants.ASSIGNEE_ROLE));
        	 roleSelectionMap.put(KBConstants.REVIEWER_ROLE, Collections.singleton(KBConstants.ASSIGNEE_ROLE));
        	 roleSelectionMap.put(KBConstants.BONDING_ENGINEER_ROLE, Collections.singleton(KBConstants.BONDING_ENGINEER_ROLE));
        	 roleSelectionMap.put(KBConstants.WELDING_ENGINEER_ROLE, Collections.singleton(KBConstants.WELDING_ENGINEER_ROLE));
         }
         return roleSelectionMap;
        }
        
        /**
    	 * Adding roles to be selectable during ECTState creation
    	 */
    	@Override
	public Map<Role, WTSet> getWorkflowResourcePools(FormDataHolder paramFormDataHolder) throws WTException {
		Map<Role, WTSet> workflowResourcePools = super.getWorkflowResourcePools(paramFormDataHolder);

		WTSet wtSetReleaseManager = workflowResourcePools.get(KBConstants.RELEASE_MANAGER);
		if (wtSetReleaseManager == null) {
			wtSetReleaseManager = new WTHashSet();
		}
		WTSet wtSetWeldingEngineer = workflowResourcePools.get(KBConstants.WELDING_ENGINEER_ROLE);
		if (wtSetWeldingEngineer == null) {
			wtSetWeldingEngineer = new WTHashSet();
		}
		WTSet wtSetBondingEngineer = workflowResourcePools.get(KBConstants.BONDING_ENGINEER_ROLE);
		if (wtSetBondingEngineer == null) {
			wtSetBondingEngineer = new WTHashSet();
		}

		RolePoolMap mapReleaseManager = RolePoolMap.newRolePoolMap();
		RolePoolMap mapWeldingEngineer = RolePoolMap.newRolePoolMap();
		RolePoolMap mapBondingEngineer = RolePoolMap.newRolePoolMap();
		try {
			mapReleaseManager.setRole(Role.toRole("CAD-RELEASE"));
			mapWeldingEngineer.setRole(KBConstants.WELDING_ENGINEER_ROLE);
			mapBondingEngineer.setRole(KBConstants.BONDING_ENGINEER_ROLE);
		} catch (WTPropertyVetoException e) {
			LOGGER.error("getWorkflowResourcePools");  
			LOGGER.error(e.getLocalizedMessage());  
		}
 
		wtSetReleaseManager.add(mapReleaseManager);
		wtSetWeldingEngineer.add(mapWeldingEngineer);
		wtSetBondingEngineer.add(mapBondingEngineer);

		workflowResourcePools.put(KBConstants.RELEASE_MANAGER, wtSetReleaseManager);
		workflowResourcePools.put(KBConstants.WELDING_ENGINEER_ROLE, wtSetWeldingEngineer);
		workflowResourcePools.put(KBConstants.BONDING_ENGINEER_ROLE, wtSetBondingEngineer);

		return workflowResourcePools;
	}
        
}

