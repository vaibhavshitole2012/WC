package ext.csc.support.domain.util;

import com.symantec.itools.javax.swing.JButtonGroupPanel;
import com.symantec.itools.javax.swing.borders.BevelBorder;
import com.symantec.itools.javax.swing.borders.LineBorder;
import com.symantec.itools.javax.swing.borders.TitledBorder;
import java.awt.Button;
import java.awt.Choice;
import java.awt.Color;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.Label;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.PrintStream;
import java.util.LinkedList;
import javax.swing.JApplet;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JViewport;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableColumn;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceManager;
import wt.fc.QueryResult;
import wt.fc.WTObject;
import wt.introspection.ColumnDescriptor;
import wt.part.WTPart;
import wt.query.ClassAttribute;
import wt.query.ConstantExpression;
import wt.query.OrderBy;
import wt.query.QueryException;
import wt.query.QuerySpec;
import wt.query.RelationalExpression;
import wt.query.SearchCondition;
import wt.util.WTException;
import wt.vc.IterationIdentifier;
import wt.vc.VersionControlException;
import wt.vc.VersionControlHelper;
import wt.vc.VersionIdentifier;
import wt.vc.config.LatestConfigSpec;

public class KYCPartSearchList extends JDialog
{
  LinkedList globalValue = new LinkedList();

  testModel tableModel = null;

  LinkedList vShapeType = new LinkedList();
  LinkedList vDrawingSize = new LinkedList();
  LinkedList vSupplyType = new LinkedList();
  LinkedList vPartState = new LinkedList();
  LinkedList vPartCategory = new LinkedList();

  boolean frameSizeAdjusted = false;

  JScrollPane JScrollPane1 = new JScrollPane();
  JTable JTable1 = new JTable();

  TextField tfPartNumber = new TextField();
  TextField tfPartName = new TextField();
  TextField tfMainItemName = new TextField();

  Label Label1 = new Label();
  Label Label9 = new Label();
  Label Label10 = new Label();
  Label Label5 = new Label();
  Label Label2 = new Label();
  Label Label6 = new Label();
  Label Label7 = new Label();
  Label Label8 = new Label();

  Choice cShapeType = new Choice();
  Choice cDrawingSize = new Choice();
  Choice cPartCategory = new Choice();
  Choice cSupplyType = new Choice();
  Choice cPartState = new Choice();

  Button btSuccess = new Button("È® ï¿½ï¿½");
  Button btClose = new Button("ï¿½ï¿½ ï¿½ï¿½");
  Button btSearch = new Button("ï¿½ï¿½ ï¿½ï¿½");

  TitledBorder titledBorder1 = new TitledBorder();
  BevelBorder bevelBorder1 = new BevelBorder();
  JButtonGroupPanel JButtonGroupPanel1 = new JButtonGroupPanel();
  TitledBorder titledBorder2 = new TitledBorder();
  JButtonGroupPanel JButtonGroupPanel2 = new JButtonGroupPanel();
  LineBorder lineBorder1 = new LineBorder();

  public KYCPartSearchList(JApplet parent, LinkedList returnValue, int selectionMode)
  {
    this.globalValue = returnValue;

    setModal(true);
    setTitle("  ï¿½ï¿½Ç° ï¿½Ë»ï¿½");

    getContentPane().setLayout(null);
    setSize(612, 500);
    setVisible(false);

    getContentPane().add(this.tfPartNumber);
    this.tfPartNumber.setFont(new Font("Dialog", 0, 11));
    this.tfPartNumber.setBounds(88, 36, 150, 20);
    getContentPane().add(this.tfPartName);
    this.tfPartName.setFont(new Font("Dialog", 0, 11));
    this.tfPartName.setBounds(320, 36, 150, 20);

    this.Label5.setText("ï¿½ï¿½ Ç°  ï¿½ï¿½");
    this.Label5.setAlignment(2);
    getContentPane().add(this.Label5);
    this.Label5.setBounds(256, 36, 58, 24);

    this.Label2.setText("ï¿½Û¼ï¿½ï¿½Î¼ï¿½");
    this.Label2.setAlignment(2);
    getContentPane().add(this.Label2);
    this.Label2.setBounds(24, 61, 58, 24);

    this.Label6.setText("ï¿½ï¿½Ã¼ï¿½ï¿½ï¿½ï¿½");
    this.Label6.setAlignment(2);
    getContentPane().add(this.Label6);
    this.Label6.setBounds(256, 61, 58, 24);

    this.Label7.setText("ï¿½ï¿½ï¿½Â±ï¿½ï¿½ï¿½");
    this.Label7.setAlignment(2);
    getContentPane().add(this.Label7);
    this.Label7.setBounds(256, 86, 58, 24);

    this.Label8.setText("ï¿½ï¿½  ï¿½ï¿½  ï¿½ï¿½");
    this.Label8.setAlignment(2);
    getContentPane().add(this.Label8);
    this.Label8.setBounds(256, 111, 58, 24);

    this.Label1.setText("ï¿½ï¿½Ç°ï¿½ï¿½È£");
    this.Label1.setAlignment(2);
    getContentPane().add(this.Label1);
    this.Label1.setBounds(24, 36, 58, 24);

    this.Label9.setText("ï¿½ï¿½Ç°ï¿½ï¿½ï¿½ï¿½");
    this.Label9.setAlignment(2);
    getContentPane().add(this.Label9);
    this.Label9.setBounds(24, 111, 58, 24);

    this.Label10.setText("ï¿½ï¿½      ï¿½ï¿½");
    this.Label10.setAlignment(2);
    getContentPane().add(this.Label10);
    this.Label10.setBounds(24, 86, 58, 24);

    getContentPane().add(this.tfMainItemName);
    this.tfMainItemName.setFont(new Font("ï¿½ï¿½ï¿½ï¿½", 0, 11));
    this.tfMainItemName.setBounds(88, 61, 150, 20);

    this.cShapeType.setBackground(Color.white);
    this.cShapeType.setFont(new Font("ï¿½ï¿½ï¿½ï¿½", 0, 11));
    getContentPane().add(this.cShapeType);
    this.cShapeType.setBounds(320, 59, 150, 20);
    this.cDrawingSize.setBackground(Color.white);
    this.cDrawingSize.setFont(new Font("ï¿½ï¿½ï¿½ï¿½", 0, 11));
    getContentPane().add(this.cDrawingSize);
    this.cDrawingSize.setBounds(88, 86, 150, 20);
    this.cPartCategory.setBackground(Color.white);
    this.cPartCategory.setFont(new Font("ï¿½ï¿½ï¿½ï¿½", 0, 11));
    getContentPane().add(this.cPartCategory);
    this.cPartCategory.setBounds(88, 111, 150, 20);
    this.cSupplyType.setBackground(Color.white);
    this.cSupplyType.setFont(new Font("ï¿½ï¿½ï¿½ï¿½", 0, 11));
    getContentPane().add(this.cSupplyType);
    this.cSupplyType.setBounds(320, 86, 150, 20);
    this.cPartState.setBackground(Color.white);
    this.cPartState.setFont(new Font("ï¿½ï¿½ï¿½ï¿½", 0, 11));
    getContentPane().add(this.cPartState);
    this.cPartState.setBounds(320, 111, 150, 20);

    getContentPane().add(this.btSearch);
    this.btSearch.setBounds(504, 36, 84, 28);

    getContentPane().add(this.btSuccess);
    this.btSuccess.setBounds(416, 456, 84, 28);

    getContentPane().add(this.btClose);
    this.btClose.setBounds(516, 456, 84, 28);

    this.titledBorder1.setTitle(" ï¿½ï¿½Ç°ï¿½Ë»ï¿½ ");
    this.JButtonGroupPanel1.setBorder(this.titledBorder1);
    this.JButtonGroupPanel1.setLayout(new GridLayout(1, 0, 0, 0));
    getContentPane().add(this.JButtonGroupPanel1);

    this.JButtonGroupPanel1.setBounds(12, 12, 476, 140);
    this.JButtonGroupPanel2.setBorder(this.titledBorder2);
    this.JButtonGroupPanel2.setLayout(new GridLayout(1, 0, 0, 0));
    getContentPane().add(this.JButtonGroupPanel2);

    this.JButtonGroupPanel2.setBounds(492, 20, 108, 130);

    this.tableModel = new testModel();

    this.JTable1 = new JTable();
    this.JScrollPane1 = new JScrollPane(this.JTable1);

    this.JTable1.setBounds(14, 164, 586, 276);
    this.JTable1.setSelectionMode(selectionMode);

    this.JScrollPane1.setBounds(14, 164, 586, 276);
    this.JScrollPane1.getViewport().add(this.JTable1);

    getContentPane().add(this.JScrollPane1);

    this.JTable1.setAutoCreateColumnsFromModel(false);
    this.JTable1.setModel(this.tableModel);

    for (int i = 0; i < this.tableModel.columnNames.length; i++)
    {
      DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();

      TableColumn column = new TableColumn(i, this.tableModel.columnWidth[i], renderer, null);

      this.JTable1.addColumn(column);
    }

    SymWindow aSymWindow = new SymWindow();
    addWindowListener(aSymWindow);
    SymAction lSymAction = new SymAction();
    this.btSearch.addActionListener(lSymAction);

    this.btSuccess.addActionListener(lSymAction);
    this.btClose.addActionListener(lSymAction);
  }

  public void setVisible(boolean b)
  {
    if (b)
      setLocation(50, 50);
    super.setVisible(b);
  }

  public void addNotify()
  {
    Dimension size = getSize();

    super.addNotify();

    if (this.frameSizeAdjusted)
      return;
    this.frameSizeAdjusted = true;

    Insets insets = getInsets();
    setSize(insets.left + insets.right + size.width, insets.top + insets.bottom + size.height);
  }

  void btSearch_ActionPerformed(ActionEvent event)
  {
    String partNumber = "";
    String partName = "";
    String mainItemName = "";
    String viewTypeKey = "";
    String drawingSizeKey = "";
    String supplyTypeKey = "";
    String partCategoryKey = "";
    String partStateKey = "";
    String error = "";

    LinkedList searchedParts = new LinkedList();
    QueryResult qr = null;

    partNumber = this.tfPartNumber.getText();
    partName = this.tfPartName.getText();

    ClassAttribute classAttribute = null;
    RelationalExpression expression = null;
    SearchCondition condition = null;
    try
    {
      QuerySpec querySpec = new QuerySpec(WTPart.class);

      querySpec.appendWhere(new SearchCondition(WTPart.class, "ownership.owner.key.classname", true));

      if (((partNumber != null) && (!partNumber.equals(""))) || (
        (partName != null) && (!partName.equals(""))))
      {
        querySpec.appendAnd();
      }

      if ((partName != null) && (!partName.equals(""))) {
        classAttribute = new ClassAttribute(WTPart.class, "master>name");

        expression = ConstantExpression.newExpression(partName.replace('*', '%'), classAttribute.getColumnDescriptor().getJavaType());
        condition = new SearchCondition(classAttribute, "LIKE", expression);
        querySpec.appendWhere(condition);

        if ((partNumber != null) && (!partNumber.equals(""))) querySpec.appendAnd();

      }

      if ((partNumber != null) && (!partNumber.equals(""))) {
        classAttribute = new ClassAttribute(WTPart.class, "master>number");

        expression = ConstantExpression.newExpression(partNumber.replace('*', '%'), classAttribute.getColumnDescriptor().getJavaType());
        condition = new SearchCondition(classAttribute, "LIKE", expression);
        querySpec.appendWhere(condition);
      }

      LatestConfigSpec latestCSpec = new LatestConfigSpec();
      querySpec = latestCSpec.appendSearchCriteria(querySpec);

      classAttribute = new ClassAttribute(WTPart.class, 
        "master>thePersistInfo.createStamp");

      querySpec.appendOrderBy(new OrderBy(classAttribute, true));

      qr = PersistenceHelper.manager.find(querySpec);

      LinkedList bufLinkedList = new LinkedList();

      if (qr.size() == 0) {
        JOptionPane.showMessageDialog(this, "ï¿½Ë»ï¿½ï¿½ï¿½ï¿½Ç¿ï¿½ ï¿½ï¿½Ä¡ï¿½Ï´ï¿½ ï¿½ï¿½Ç°ï¿½ï¿½ ï¿½ï¿½ï¿½ï¿½Ï´ï¿½.");
        return;
      }

      LinkedList qrVector = KYCViewerHelper.getQuerySort(qr, 1);

      for (int index = 0; index < qrVector.size(); index++)
      {
        bufLinkedList.addLast(qrVector.get(index));
      }

      this.tableModel.setQueryResult(bufLinkedList);

      this.JTable1.validate();
      this.JTable1.updateUI();
    }
    catch (QueryException que)
    {
      System.out.println("DEBUG> ï¿½ï¿½ï¿½ï¿½ï¿½ï¿½ï¿½ï¿½ ï¿½ï¿½ï¿½ï¿½");
      System.out.println(que);
      setCursor(Cursor.getDefaultCursor());
    }
    catch (WTException wte) {
      setCursor(Cursor.getDefaultCursor());
      error = wte.getLocalizedMessage();
      System.out.println(error);
    }

    System.out.println("DEBUG> End Search");
  }

  void btSuccess_ActionPerformed(ActionEvent event)
  {
    int sRow = this.JTable1.getSelectedRow();
    LinkedList selectedPartInfo = this.tableModel.selectPart();

    this.globalValue.add(0, "true");
    this.globalValue.add(1, selectedPartInfo);

    setModal(true);
    setVisible(false);
  }

  void btClose_ActionPerformed(ActionEvent event)
  {
    setVisible(false);
  }

  void PartSearchList_WindowClosing(WindowEvent event)
  {
    setVisible(false);
  }

  class SymAction
    implements ActionListener
  {
    SymAction()
    {
    }

    public void actionPerformed(ActionEvent event)
    {
      Object object = event.getSource();

      if (object.equals(KYCPartSearchList.this.btSearch))
      {
        KYCPartSearchList.this.btSearch_ActionPerformed(event);
      }
      else if (object.equals(KYCPartSearchList.this.btSuccess)) {
        KYCPartSearchList.this.btSuccess_ActionPerformed(event);
      }
      else if (object == KYCPartSearchList.this.btClose)
        KYCPartSearchList.this.btClose_ActionPerformed(event);
    }
  }

  class SymWindow extends WindowAdapter
  {
    SymWindow()
    {
    }

    public void windowClosing(WindowEvent event)
    {
      Object object = event.getSource();
      if (object == KYCPartSearchList.this)
        KYCPartSearchList.this.PartSearchList_WindowClosing(event);
    }
  }

  class testModel extends AbstractTableModel
  {
    final String[] columnNames = { "ï¿½ï¿½Ç°ï¿½ï¿½È£", "ï¿½ï¿½Ç°ï¿½ï¿½", "ï¿½Û¼ï¿½ï¿½Î¼ï¿½", "ï¿½ï¿½ï¿½ï¿½" };
    final int[] columnWidth = { 500, 500, 500, 200 };

    private LinkedList queryResult = new LinkedList();

    public testModel()
    {
    }

    public testModel(LinkedList qr)
    {
      this();
      this.queryResult = qr;
    }

    public int getColumnCount() {
      return this.columnNames.length;
    }

    public int getRowCount()
    {
      return this.queryResult.size();
    }

    public String getColumnName(int col) {
      return this.columnNames[col];
    }

    public void setQueryResult(LinkedList result)
    {
      this.queryResult = result;
    }

    public LinkedList selectPart()
    {
      int[] sRow = KYCPartSearchList.this.JTable1.getSelectedRows();

      LinkedList selectPartInfo = new LinkedList();

      if (sRow.length >= 0) {
        for (int index = 0; index < sRow.length; index++) {
          selectPartInfo.add(index, (WTObject)this.queryResult.get(sRow[index]));
        }
      }
      return selectPartInfo;
    }

    public Object getValueAt(int row, int col)
    {
      String colElementInfo = "";
      String queriedState = "";
      String sPartView = "";
      String sDisplayView = "";

      if (this.queryResult.size() > row)
      {
        WTPart partInfo = (WTPart)this.queryResult.get(row);

        if (partInfo != null)
        {
          if (col == 0)
          {
            String number = partInfo.getNumber();
            colElementInfo = number;
          }
          else if (col == 1) {
            colElementInfo = partInfo.getName();
          } else if (col != 2)
          {
            if (col == 3) {
              try
              {
                String partVersion = VersionControlHelper.getVersionIdentifier(partInfo).getValue();

                String partIteration = partInfo.getIterationIdentifier().getValue();
                sDisplayView = partVersion + "." + partIteration;
                colElementInfo = sDisplayView;
              }
              catch (VersionControlException localVersionControlException)
              {
              }
            }
          }
        }
      }
      return colElementInfo;
    }
  }
}