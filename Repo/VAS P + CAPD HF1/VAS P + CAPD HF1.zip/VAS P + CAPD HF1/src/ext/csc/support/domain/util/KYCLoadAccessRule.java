package ext.csc.support.domain.util;

import java.io.PrintStream;
import java.io.Serializable;
import java.util.Hashtable;
import java.util.ResourceBundle;
import java.util.Vector;
import wt.access.AccessControlHelper;
import wt.access.AccessControlManager;
import wt.access.AccessControlRule;
import wt.access.AccessPermission;
import wt.access.AccessPermissionSet;
import wt.admin.AdminDomainRef;
import wt.admin.AdministrativeDomain;
import wt.admin.AdministrativeDomainHelper;
import wt.admin.AdministrativeDomainManager;
import wt.doc.WTDocument;
import wt.doc.WTDocumentDependencyLink;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceManager;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.fc.WTReference;
import wt.inf.container.OrgContainer;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerHelper;
import wt.inf.container.WTContainerRef;
import wt.inf.container.WTContainerService;
import wt.inf.library.WTLibrary;
import wt.lifecycle.State;
import wt.load.LoadServerHelper;
import wt.method.RemoteAccess;
import wt.org.OrganizationServicesHelper;
import wt.org.OrganizationServicesManager;
import wt.org.WTPrincipalReference;
import wt.org.WTRolePrincipal;
import wt.pdmlink.PDMLinkProduct;
import wt.pom.Transaction;
import wt.projmgmt.admin.Project2;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTContext;
import wt.util.WTException;
import wt.util.WTProperties;

public class KYCLoadAccessRule
  implements RemoteAccess, Serializable
{
  private static String CURRENT_CONTENT_HOLDER = "Current ContentHolder";
  private static final String DOCUMENT_CACHE_KEY = "DOCUMENT_CACHE_KEY:";
  private static final String DOCUMENT_PREVIOUS_USER = "DOCUMENT_PREVIOUS_USER:";
  private static final String OLYDOCUMENT = "";
  private static final String DOCUMENT_NEW_VERSION = "DOCUMENT_NEW_VERSION";
  private static String CURRENT_DOCUMENT = "Current Document";

  private static String RESOURCE = "wt.doc.docResource";
  private static ResourceBundle rb;
  public static boolean VERBOSE;

  static
  {
    try
    {
      rb = ResourceBundle.getBundle(RESOURCE, 
        WTContext.getContext().getLocale());
      WTProperties properties = WTProperties.getLocalProperties();
      VERBOSE = properties.getProperty("wt.doc.load.verbose", false);
    }
    catch (Throwable t)
    {
      System.err.println("Error initializing " + KYCLoadAccessRule.class.getName());
      t.printStackTrace(System.err);
      throw new ExceptionInInitializerError(t);
    }
  }

  public static boolean addAccessRule(Hashtable nv, Hashtable cmd_line, Vector return_objects)
  {
    try
    {
      String containerType = getValue("containerType", nv, cmd_line, false);

      String containerName = getValue("containerName", nv, cmd_line, false);

      String domain = getValue("domain", nv, cmd_line, false);

      String typeId = getValue("typeId", nv, cmd_line, false);

      String permission = getValue("permission", nv, cmd_line, false);

      String principalType = getValue("principalType", nv, cmd_line, false);

      String principal = getValue("principal", nv, cmd_line, false);

      String permissionList = getValue("permissionList", nv, cmd_line, false);

      String state = getValue("state", nv, cmd_line, false);

      String appliesTo = getValue("appliesTo", nv, cmd_line, false);

      WTContainer container = null;
      Class aClass = OrgContainer.class;
      if (containerType.equals("wt.inf.container.ExchangeContainer")) {
        container = WTContainerHelper.service.getExchangeContainer();
      } else if (containerType.equals("wt.inf.container.OrgContainer")) {
        aClass = OrgContainer.class;
      } else if (containerType.equals("wt.inf.library.WTLibrary")) {
        aClass = WTLibrary.class;
      } else if (containerType.equals("wt.projmgmt.admin.Project2")) {
        aClass = Project2.class;
      } else if (containerType.equals("wt.pdmlink.PDMLinkProduct")) {
        aClass = PDMLinkProduct.class;
      } else {
        LoadServerHelper.printMessage("\n\n########ERROR-0002: Do not have Contianer Class name: '" + containerName + "'.");
        return false;
      }

      QuerySpec spec = new QuerySpec(aClass);
      SearchCondition cond = new SearchCondition(aClass, "containerInfo.name", "=", containerName);
      spec.appendWhere(cond);
      QueryResult result = PersistenceHelper.manager.find(spec);

      if ((result == null) || (result.size() == 0)) {
        LoadServerHelper.printMessage("\n\n########ERROR-0001: Do not have " + aClass.getName() + " Container which was the name of '" + containerName + "'.");
        return false;
      }

      container = (WTContainer)result.nextElement();

      WTContainerRef ref = WTContainerRef.newWTContainerRef(container);
      AdministrativeDomain adminDomain = AdministrativeDomainHelper.manager.getDomain(domain, ref);

      if (adminDomain == null) {
        LoadServerHelper.printMessage("\n\n########ERROR-0003: Do not have domain path '" + domain + "'.");
        return false;
      }

      AdminDomainRef dRef = AdminDomainRef.newAdminDomainRef(adminDomain);

      WTPrincipalReference principalRef = null;

      if (principal.equals("ALL")) {
        principalRef = WTPrincipalReference.ALL;
      } else if (principal.equals("OWNER")) {
        principalRef = WTPrincipalReference.OWNER;
      }
      else if (principalType.equals("ROLE")) {
        WTRolePrincipal rolePrincipal = OrganizationServicesHelper.manager.getRolePrincipal(principal, ref, true, null);
        principalRef = WTPrincipalReference.newWTPrincipalReference(rolePrincipal);
      } else {
        principalRef = OrganizationServicesHelper.manager.getPrincipalReference(principal);
      }

      if (principalRef == null) {
        LoadServerHelper.printMessage("\n\n########ERROR-0004: Do not have principal Reference '" + domain + "'.");
        return false;
      }

      State stateInstance = null;
      if (!state.equals("ALL")) {
        stateInstance = State.toState(state);
        if (stateInstance == null) {
          LoadServerHelper.printMessage("\n\n########ERROR-0005: Do not have State '" + state + "'.");
          return false;
        }

      }

      AccessPermissionSet aSet = new AccessPermissionSet();
      if (permissionList.equals("ALL")) {
        aSet.add(AccessPermission.ALL);
      } else {
        String[] accessSet = permissionList.split("/");

        for (int i = 0; i < accessSet.length; i++)
        {
          if (accessSet[i].equals("CHANGE_CONTEXT"))
            aSet.add(AccessPermission.CHANGE_CONTEXT);
          else if (accessSet[i].equals("CHANGE_DOMAIN"))
            aSet.add(AccessPermission.CHANGE_DOMAIN);
          else if (accessSet[i].equals("CHANGE_PERMISSIONS"))
            aSet.add(AccessPermission.CHANGE_PERMISSIONS);
          else if (accessSet[i].equals("CREATE"))
            aSet.add(AccessPermission.CREATE);
          else if (accessSet[i].equals("CREATE_BY_MOVE"))
            aSet.add(AccessPermission.CREATE_BY_MOVE);
          else if (accessSet[i].equals("DELETE"))
            aSet.add(AccessPermission.DELETE);
          else if (accessSet[i].equals("DOWNLOAD"))
            aSet.add(AccessPermission.DOWNLOAD);
          else if (accessSet[i].equals("MODIFY"))
            aSet.add(AccessPermission.MODIFY);
          else if (accessSet[i].equals("MODIFY_CONTENT"))
            aSet.add(AccessPermission.MODIFY_CONTENT);
          else if (accessSet[i].equals("MODIFY_IDENTITY"))
            aSet.add(AccessPermission.MODIFY_IDENTITY);
          else if (accessSet[i].equals("NEW_VIEW_VERSION"))
            aSet.add(AccessPermission.NEW_VIEW_VERSION);
          else if (accessSet[i].equals("READ"))
            aSet.add(AccessPermission.READ);
          else if (accessSet[i].equals("REVISE"))
            aSet.add(AccessPermission.REVISE);
          else if (accessSet[i].equals("SET_STATE"))
            aSet.add(AccessPermission.SET_STATE);
          else if (accessSet[i].equals("ADMINISTRATIVE")) {
            aSet.add(AccessPermission.ADMINISTRATIVE);
          }

        }

      }

      boolean isAppliesTo = true;
      if (appliesTo.equals("true"))
        isAppliesTo = true;
      else {
        isAppliesTo = false;
      }

      if (permission.equals("+"))
      {
        AccessControlRule aRule = findAccessControlRule(dRef, typeId, stateInstance, principalRef);
        if (aRule != null) {
          AccessPermissionSet gSet = aRule.getGrantPermissions();
          AccessPermissionSet dSet = aRule.getDenyPermissions();

          AccessPermissionSet abSet = aRule.getAbsoluteDenyPermissions();

          if ((gSet != null) && (gSet.size() > 0))
            gSet.addAll(aSet);
          else {
            gSet = aSet;
          }

          AccessControlHelper.manager.updateAccessControlRule(
            dRef, 
            typeId, 
            stateInstance, 
            principalRef, 
            isAppliesTo, 
            gSet, dSet, abSet);
        } else {
          AccessControlHelper.manager.createAccessControlRule(
            dRef, 
            typeId, 
            stateInstance, 
            principalRef, 
            isAppliesTo, 
            aSet, null, null);
        }

      }
      else if (permission.equals("-"))
      {
        AccessControlRule aRule = findAccessControlRule(dRef, typeId, stateInstance, principalRef);

        if (aRule != null) {
          AccessPermissionSet gSet = aRule.getGrantPermissions();
          AccessPermissionSet dSet = aRule.getDenyPermissions();

          AccessPermissionSet abSet = aRule.getAbsoluteDenyPermissions();
          if ((dSet != null) && (dSet.size() > 0))
            dSet.addAll(aSet);
          else {
            dSet = aSet;
          }

          AccessControlHelper.manager.updateAccessControlRule(
            dRef, 
            typeId, 
            stateInstance, 
            principalRef, 
            isAppliesTo, 
            gSet, dSet, abSet);
        } else {
          AccessControlHelper.manager.createAccessControlRule(
            dRef, 
            typeId, 
            stateInstance, 
            principalRef, 
            isAppliesTo, 
            null, aSet, null);
        }
      }
      else
      {
        AccessControlRule aRule = findAccessControlRule(dRef, typeId, stateInstance, principalRef);

        if (aRule != null) {
          AccessPermissionSet gSet = aRule.getGrantPermissions();
          AccessPermissionSet dSet = aRule.getDenyPermissions();

          AccessPermissionSet abSet = aRule.getAbsoluteDenyPermissions();
          if ((abSet != null) && (abSet.size() > 0))
            abSet.addAll(aSet);
          else {
            abSet = aSet;
          }

          AccessControlHelper.manager.updateAccessControlRule(
            dRef, 
            typeId, 
            stateInstance, 
            principalRef, 
            isAppliesTo, 
            gSet, dSet, abSet);
        } else {
          AccessControlHelper.manager.createAccessControlRule(
            dRef, 
            typeId, 
            stateInstance, 
            principalRef, 
            isAppliesTo, 
            null, null, aSet);
        }
      }

    }
    catch (WTException e)
    {
      LoadServerHelper.printMessage(e.getLocalizedMessage());
      e.printStackTrace();
    }

    return true;
  }

  public static boolean addAccessRule(KYCWTObjectNode theNode, Vector data) {
    Transaction trx = new Transaction();
    try
    {
      trx.start();

      Hashtable oneData = new Hashtable();

      for (int k = 0; k < data.size(); k++) {
        oneData = (Hashtable)data.get(k);

        String containerType = (String)oneData.get("containerType");

        String containerName = (String)oneData.get("containerName");

        String domain = (String)oneData.get("domain");

        String typeId = (String)oneData.get("typeId");

        String permission = (String)oneData.get("permission");

        String principalType = (String)oneData.get("principalType");

        String principal = (String)oneData.get("principal");

        String permissionList = (String)oneData.get("permissionList");

        String state = (String)oneData.get("state");

        String appliesTo = (String)oneData.get("appliesTo");

        AdministrativeDomain adminDomain = (AdministrativeDomain)theNode.getObject();

        WTContainer container = adminDomain.getContainer();

        WTContainerRef ref = WTContainerRef.newWTContainerRef(container);

        //if (adminDomain == null);
        AdminDomainRef dRef = AdminDomainRef.newAdminDomainRef(adminDomain);

        WTPrincipalReference principalRef = null;

        if (principal.equals("ALL")) {
          principalRef = WTPrincipalReference.ALL;
        } else if (principal.equals("OWNER")) {
          principalRef = WTPrincipalReference.OWNER;
        }
        else if (principalType.equals("ROLE")) {
          WTRolePrincipal rolePrincipal = OrganizationServicesHelper.manager.getRolePrincipal(principal, ref, true, null);
          principalRef = WTPrincipalReference.newWTPrincipalReference(rolePrincipal);
        }
        else {
          WTRolePrincipal rolePrincipal = OrganizationServicesHelper.manager.getRolePrincipal(principal, ref, true, null);
          principalRef = WTPrincipalReference.newWTPrincipalReference(rolePrincipal);
        }

        if (principalRef == null) {
          LoadServerHelper.printMessage("\n\n########ERROR-0004: Do not have principal Reference '" + domain + "'.");
          trx.rollback();
          return false;
        }

        State stateInstance = null;
        if (!state.equals("ALL")) {
          stateInstance = State.toState(state);
          if (stateInstance == null) {
            LoadServerHelper.printMessage("\n\n########ERROR-0005: Do not have State '" + state + "'.");
            trx.rollback();
            return false;
          }

        }

        AccessPermissionSet aSet = new AccessPermissionSet();
        if (permissionList.equals("ALL")) {
          aSet.add(AccessPermission.ALL);
        } else {
          String[] accessSet = permissionList.split("/");

          for (int i = 0; i < accessSet.length; i++)
          {
            if (accessSet[i].equals("CHANGE_CONTEXT"))
              aSet.add(AccessPermission.CHANGE_CONTEXT);
            else if (accessSet[i].equals("CHANGE_DOMAIN"))
              aSet.add(AccessPermission.CHANGE_DOMAIN);
            else if (accessSet[i].equals("CHANGE_PERMISSIONS"))
              aSet.add(AccessPermission.CHANGE_PERMISSIONS);
            else if (accessSet[i].equals("CREATE"))
              aSet.add(AccessPermission.CREATE);
            else if (accessSet[i].equals("CREATE_BY_MOVE"))
              aSet.add(AccessPermission.CREATE_BY_MOVE);
            else if (accessSet[i].equals("DELETE"))
              aSet.add(AccessPermission.DELETE);
            else if (accessSet[i].equals("DOWNLOAD"))
              aSet.add(AccessPermission.DOWNLOAD);
            else if (accessSet[i].equals("MODIFY"))
              aSet.add(AccessPermission.MODIFY);
            else if (accessSet[i].equals("MODIFY_CONTENT"))
              aSet.add(AccessPermission.MODIFY_CONTENT);
            else if (accessSet[i].equals("MODIFY_IDENTITY"))
              aSet.add(AccessPermission.MODIFY_IDENTITY);
            else if (accessSet[i].equals("NEW_VIEW_VERSION"))
              aSet.add(AccessPermission.NEW_VIEW_VERSION);
            else if (accessSet[i].equals("READ"))
              aSet.add(AccessPermission.READ);
            else if (accessSet[i].equals("REVISE"))
              aSet.add(AccessPermission.REVISE);
            else if (accessSet[i].equals("SET_STATE"))
              aSet.add(AccessPermission.SET_STATE);
            else if (accessSet[i].equals("ADMINISTRATIVE")) {
              aSet.add(AccessPermission.ADMINISTRATIVE);
            }

          }

        }

        boolean isAppliesTo = true;
        if (appliesTo.equals("true"))
          isAppliesTo = true;
        else {
          isAppliesTo = false;
        }

        if (permission.equals("+"))
        {
          AccessControlRule aRule = findAccessControlRule(dRef, typeId, stateInstance, principalRef, isAppliesTo);
          if (aRule != null) {
            AccessPermissionSet gSet = aRule.getGrantPermissions();
            AccessPermissionSet dSet = aRule.getDenyPermissions();
            AccessPermissionSet abSet = aRule.getAbsoluteDenyPermissions();

            if ((gSet != null) && (gSet.size() > 0))
              gSet.addAll(aSet);
            else {
              gSet = aSet;
            }

            AccessControlHelper.manager.updateAccessControlRule(
              dRef, 
              typeId, 
              stateInstance, 
              principalRef, 
              isAppliesTo, 
              gSet, dSet, abSet);
          } else {
            AccessControlHelper.manager.createAccessControlRule(
              dRef, 
              typeId, 
              stateInstance, 
              principalRef, 
              isAppliesTo, 
              aSet, null, null);
          }
        }
        else if (permission.equals("-"))
        {
          AccessControlRule aRule = findAccessControlRule(dRef, typeId, stateInstance, principalRef, isAppliesTo);

          if (aRule != null) {
            AccessPermissionSet gSet = aRule.getGrantPermissions();
            AccessPermissionSet dSet = aRule.getDenyPermissions();
            AccessPermissionSet abSet = aRule.getAbsoluteDenyPermissions();
            if ((dSet != null) && (dSet.size() > 0))
              dSet.addAll(aSet);
            else {
              dSet = aSet;
            }

            AccessControlHelper.manager.updateAccessControlRule(
              dRef, 
              typeId, 
              stateInstance, 
              principalRef, 
              isAppliesTo, 
              gSet, dSet, abSet);
          }
          else {
            AccessControlHelper.manager.createAccessControlRule(
              dRef, 
              typeId, 
              stateInstance, 
              principalRef, 
              isAppliesTo, 
              null, aSet, null);
          }
        }
        else
        {
          AccessControlRule aRule = findAccessControlRule(dRef, typeId, stateInstance, principalRef, isAppliesTo);

          if (aRule != null) {
            AccessPermissionSet gSet = aRule.getGrantPermissions();
            AccessPermissionSet dSet = aRule.getDenyPermissions();
            AccessPermissionSet abSet = aRule.getAbsoluteDenyPermissions();
            if ((abSet != null) && (abSet.size() > 0))
              abSet.addAll(aSet);
            else {
              abSet = aSet;
            }

            AccessControlHelper.manager.updateAccessControlRule(
              dRef, 
              typeId, 
              stateInstance, 
              principalRef, 
              isAppliesTo, 
              gSet, dSet, abSet);
          } else {
            AccessControlHelper.manager.createAccessControlRule(
              dRef, 
              typeId, 
              stateInstance, 
              principalRef, 
              isAppliesTo, 
              null, null, aSet);
          }
        }
      }

      trx.commit();
    } catch (WTException e) {
      trx.rollback();
      LoadServerHelper.printMessage(e.getLocalizedMessage());
      e.printStackTrace();
      return false;
    }

    return true;
  }

  private static String getValue(String name, Hashtable nv, Hashtable cmd_line, boolean required)
    throws WTException
  {
    String value = LoadServerHelper.getValue(name, nv, cmd_line, required ? 0 : 1);

    if ((required) && (value == null)) throw new WTException("\nRequired value for " + name + " not provided in input file.");

    return value;
  }

  private static AccessControlRule findAccessControlRule(AdminDomainRef dRef, String typrId, State stateInstance, WTPrincipalReference principalRef) throws WTException {
    AccessControlRule aRule = AccessControlHelper.manager.getAccessControlRule(dRef, typrId, stateInstance, principalRef, false);
    return aRule;
  }

  private static AccessControlRule findAccessControlRule(AdminDomainRef dRef, String typrId, State stateInstance, WTPrincipalReference principalRef, boolean appliesTo) throws WTException {
    AccessControlRule aRule = AccessControlHelper.manager.getAccessControlRule(dRef, typrId, stateInstance, principalRef, appliesTo);
    return aRule;
  }

  private static AccessPermissionSet getGrantPermission(AccessControlRule aRule) throws WTException {
    AccessPermissionSet aSet = aRule.getGrantPermissions();
    return aSet;
  }

  private static AccessPermissionSet getDenyPermission(AccessControlRule aRule) throws WTException {
    AccessPermissionSet aSet = aRule.getDenyPermissions();
    return aSet;
  }

  public void operation()
    throws WTException
  {
    WTDocument docA = (WTDocument)getObjectFromOid("VR:wt.doc.WTDocument:78836");
    QueryResult queryResult = PersistenceHelper.manager.navigate(docA, "describedBy", WTDocumentDependencyLink.class, false);
  }

  public Persistable getObjectFromOid(String oid) throws WTException
  {
    ReferenceFactory referencefactory = new ReferenceFactory();
    WTReference wtreference = referencefactory.getReference(oid);
    return wtreference.getObject();
  }

  public static void main(String[] argv) {
    KYCLoadAccessRule op = new KYCLoadAccessRule();
    try {
      op.operation();
    }
    catch (WTException e) {
      e.printStackTrace();
    }
  }
}