package ext.csc.support.domain.util;

import java.awt.BorderLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import wt.util.WTException;

public class KYCTreePanel extends JPanel
{
  KYCDraggableTree partTree;
  KYCTreeLogic theLogic;
  JFrame parentFrame;
  KYCTreeToolbar theToolbar;

  public KYCTreePanel(JFrame parentFrame, boolean sourceOnly)
    throws WTException
  {
    setLayout(new BorderLayout());
    this.parentFrame = parentFrame;
    this.partTree = new KYCDraggableTree(!sourceOnly);
    JScrollPane treeScroller = new JScrollPane(this.partTree);
    add(treeScroller, "Center");
    this.partTree.setCellRenderer(new KYCPartTreeCellRenderer());
    this.theLogic = new KYCTreeLogic(parentFrame, this.partTree);
    this.theToolbar = new KYCTreeToolbar(this.theLogic, sourceOnly);
  }

  public KYCTreePanel(JFrame parentFrame, boolean sourceOnly, String oid)
    throws WTException
  {
    setLayout(new BorderLayout());
    this.parentFrame = parentFrame;
    this.partTree = new KYCDraggableTree(!sourceOnly);
    JScrollPane treeScroller = new JScrollPane(this.partTree);
    add(treeScroller, "Center");
    this.partTree.setCellRenderer(new KYCPartTreeCellRenderer());
    this.theLogic = new KYCTreeLogic(parentFrame, this.partTree, oid);
    this.theToolbar = new KYCTreeToolbar(this.theLogic, sourceOnly);
  }

  public KYCTreePanel(JFrame parentFrame, boolean sourceOnly, String oid, String labelName)
    throws WTException
  {
    setLayout(new BorderLayout());
    this.parentFrame = parentFrame;
    this.partTree = new KYCDraggableTree(!sourceOnly);
    JScrollPane treeScroller = new JScrollPane(this.partTree);
    add(treeScroller, "Center");
    this.partTree.setCellRenderer(new KYCPartTreeCellRenderer());
    this.theLogic = new KYCTreeLogic(parentFrame, this.partTree, oid, labelName);
    this.theToolbar = new KYCTreeToolbar(this.theLogic, sourceOnly);
    add("North", this.theToolbar);
  }

  public KYCTreeToolbar getTreeToolbar()
  {
    return this.theToolbar;
  }

  public KYCTreeLogic getTreeLogic() {
    return this.theLogic;
  }
}