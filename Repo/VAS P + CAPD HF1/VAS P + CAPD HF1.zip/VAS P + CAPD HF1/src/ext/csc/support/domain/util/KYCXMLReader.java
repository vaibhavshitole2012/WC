package ext.csc.support.domain.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import wt.util.WTException;
import wt.util.WTProperties;

public class KYCXMLReader
{
  String readFileType = "CSV";
  File readFile = null;
  boolean readingType = true;

  public static String CSV = "CSV";
  public static String XML = "XML";
  public static String WT_HOME;

  static
  {
    try
    {
      WTProperties wt = WTProperties.getLocalProperties();
      WT_HOME = wt.getProperty("wt.home");
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public KYCXMLReader(File file, String filetype, boolean rType)
  {
    this.readFile = file;
    this.readFileType = filetype;
    this.readingType = rType;
  }

  public Vector reading() throws WTException, ParserConfigurationException, SAXException, IOException {
    if (this.readFileType.equals(CSV)) {
      return readingCSV();
    }
    return readingXML();
  }

  public Vector readingXML() throws WTException, ParserConfigurationException, SAXException, IOException
  {
    Vector returnVector = new Vector();

    File dtdfile = new File(this.readFile.getAbsolutePath().substring(0, this.readFile.getAbsolutePath().lastIndexOf("\\")) + "\\standardX10.dtd");
    File windcilldtdfile = new File(WT_HOME + "\\loadXMLFiles\\standardX10.dtd");

    boolean dtd_copy_flag = false;

    if (!dtdfile.exists()) {
      dtd_copy_flag = copyFile(windcilldtdfile, dtdfile);
    }
    DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
    DocumentBuilder db = dbf.newDocumentBuilder();
    Document doc = db.parse(this.readFile);
    doc.getDocumentElement().normalize();

    NodeList nodeLst = doc.getElementsByTagName("csvAccessRuleKYC");

    String csvcontainerType = null;
    String csvcontainerName = null;
    String csvdomain = null;
    String csvtypeId = null;
    String csvpermission = null;
    String csvprincipalType = null;
    String csvprincipal = null;
    String csvpermissionList = null;
    String csvstate = null;
    String csvappliesTo = null;

    Hashtable oneNode = null;
    for (int s = 0; s < nodeLst.getLength(); s++)
    {
      Node fstNode = nodeLst.item(s);

      if (fstNode.getNodeType() == 1) {
        oneNode = new Hashtable();

        Element fstElmnt = (Element)fstNode;

        if (this.readingType) {
          Node a_node = getNodeFromElement(fstElmnt, "csvcontainerType");
          csvcontainerType = a_node.getNodeValue();
          oneNode.put("containerType", csvcontainerType);

          a_node = getNodeFromElement(fstElmnt, "csvcontainerName");
          csvcontainerName = a_node.getNodeValue();
          oneNode.put("containerName", csvcontainerName);

          a_node = getNodeFromElement(fstElmnt, "csvdomain");
          csvdomain = a_node.getNodeValue();
          oneNode.put("domain", csvdomain);
        }

        Node a_node = getNodeFromElement(fstElmnt, "csvtypeId");
        csvtypeId = a_node.getNodeValue();
        oneNode.put("typeId", csvtypeId);

        a_node = getNodeFromElement(fstElmnt, "csvpermission");
        csvpermission = a_node.getNodeValue();
        oneNode.put("permission", csvpermission);

        a_node = getNodeFromElement(fstElmnt, "csvprincipal");
        csvprincipal = a_node.getNodeValue();
        oneNode.put("principal", csvprincipal);

        a_node = getNodeFromElement(fstElmnt, "csvprincipalType");
        csvprincipalType = a_node.getNodeValue();
        oneNode.put("principalType", csvprincipalType);

        a_node = getNodeFromElement(fstElmnt, "csvpermissionList");
        csvpermissionList = a_node.getNodeValue();
        oneNode.put("permissionList", csvpermissionList);

        a_node = getNodeFromElement(fstElmnt, "csvstate");
        csvstate = a_node.getNodeValue();
        oneNode.put("state", csvstate);

        a_node = getNodeFromElement(fstElmnt, "csvappliesTo");
        csvappliesTo = a_node.getNodeValue();
        if ((csvappliesTo == null) || (csvappliesTo.equals(""))) csvappliesTo = "false";
        oneNode.put("appliesTo", csvappliesTo);
      }
      returnVector.add(oneNode);
    }

    if (dtd_copy_flag) {
      dtdfile.delete();
    }

    return returnVector;
  }

  public Vector readingCSV() throws WTException, FileNotFoundException, IOException {
    Vector returnVector = new Vector();

    BufferedReader in = new BufferedReader(new FileReader(this.readFile));
    String str = null;

    String csvcontainerType = "";
    String csvcontainerName = "";
    String csvdomain = "";
    String csvtypeId = "";
    String csvpermission = "";
    String csvprincipalType = "";
    String csvprincipal = "";
    String csvpermissionList = "";
    String csvstate = "";

    Hashtable oneNode = null;

    while ((str = in.readLine()) != null) {
      oneNode = new Hashtable();

      if (!str.substring(0, 1).equals("#")) {
        String[] tagValue = str.split("[,]");
        if ((tagValue.length == 11) || (tagValue.length == 8)) {
          for (int i = 1; i < tagValue.length; i++) {
            if (this.readingType)
              switch (i) {
              case 1:
                oneNode.put("containerType", tagValue[i]);
                break;
              case 2:
                oneNode.put("containerName", tagValue[i]);
                break;
              case 3:
                oneNode.put("domain", tagValue[i]);
                break;
              case 4:
                oneNode.put("typeId", tagValue[i]);
                break;
              case 5:
                oneNode.put("permission", tagValue[i]);
                break;
              case 6:
                oneNode.put("principalType", tagValue[i]);
                break;
              case 7:
                oneNode.put("principal", tagValue[i]);
                break;
              case 8:
                oneNode.put("appliesTo", tagValue[i]);
                break;
              case 9:
                oneNode.put("permissionList", tagValue[i]);
                break;
              case 10:
                oneNode.put("state", tagValue[i]);
              default:
                break;
              }
            else switch (i) {
              case 1:
                oneNode.put("typeId", tagValue[i]);
                break;
              case 2:
                oneNode.put("permission", tagValue[i]);
                break;
              case 3:
                oneNode.put("principalType", tagValue[i]);
                break;
              case 4:
                oneNode.put("principal", tagValue[i]);
                break;
              case 5:
                oneNode.put("appliesTo", tagValue[i]);
                break;
              case 6:
                oneNode.put("permissionList", tagValue[i]);
                break;
              case 7:
                oneNode.put("state", tagValue[i]);
              }
          }

        }
        else if ((tagValue.length == 10) || (tagValue.length == 7)) {
          for (int i = 1; i < tagValue.length; i++) {
            if (this.readingType)
              switch (i) {
              case 1:
                oneNode.put("containerType", tagValue[i]);
                break;
              case 2:
                oneNode.put("containerName", tagValue[i]);
                break;
              case 3:
                oneNode.put("domain", tagValue[i]);
                break;
              case 4:
                oneNode.put("typeId", tagValue[i]);
                break;
              case 5:
                oneNode.put("permission", tagValue[i]);
                break;
              case 6:
                oneNode.put("principalType", tagValue[i]);
                break;
              case 7:
                oneNode.put("principal", tagValue[i]);
                break;
              case 8:
                oneNode.put("appliesTo", "false");
                oneNode.put("permissionList", tagValue[i]);
                break;
              case 9:
                oneNode.put("state", tagValue[i]);
              default:
                break;
              }
            else switch (i) {
              case 1:
                oneNode.put("typeId", tagValue[i]);
                break;
              case 2:
                oneNode.put("permission", tagValue[i]);
                break;
              case 3:
                oneNode.put("principalType", tagValue[i]);
                break;
              case 4:
                oneNode.put("principal", tagValue[i]);
                break;
              case 5:
                oneNode.put("appliesTo", "false");
                oneNode.put("permissionList", tagValue[i]);
                break;
              case 6:
                oneNode.put("state", tagValue[i]);
              }
          }

        }

        returnVector.add(oneNode);
      }
    }

    return returnVector;
  }

  public Node getNodeFromElement(Element fstElmnt, String node_name) {
    NodeList fstNmElmntLst = fstElmnt.getElementsByTagName(node_name);
    Element fstNmElmnt = (Element)fstNmElmntLst.item(0);
    NodeList fstNm = fstNmElmnt.getChildNodes();

    return fstNm.item(0);
  }

  public boolean copyFile(File source, File target) {
    boolean transaction_result = true;

    FileInputStream fis = null;
    FileOutputStream fos = null;
    try {
      fis = new FileInputStream(source);
      fos = new FileOutputStream(target);

      byte[] buffer = new byte[4096];
      int read;
      while ((read = fis.read(buffer)) != -1)
      {
        fos.write(buffer, 0, read);
      }
    } catch (IOException e) {
      e.printStackTrace();
      transaction_result = false;
      try
      {
        if (fis != null) {
          fis.close();
        }
        if (fos != null)
          fos.close();
      }
      catch (IOException ie) {
        ie.printStackTrace();
        transaction_result = false;
      }
    }
    finally
    {
      try
      {
        if (fis != null) {
          fis.close();
        }
        if (fos != null)
          fos.close();
      }
      catch (IOException e) {
        e.printStackTrace();
        transaction_result = false;
      }
    }

    return transaction_result;
  }

  public static void main(String[] args)
  {
    KYCXMLReader op = new KYCXMLReader(new File("D:\\ptc\\Windchill_9.1\\Windchill\\loadFiles\\kycaccess.csv"), CSV, true);
    try {
      Vector gotData = op.reading();
      for (int i = 0; i < gotData.size(); i++) {
        System.out.println("============================");
        Hashtable oneNode = (Hashtable)gotData.get(i);
        Enumeration keys = oneNode.keys();
        while (keys.hasMoreElements()) {
          String key = (String)keys.nextElement();
          String data = (String)oneNode.get(key);

          System.out.println(key + "=" + data);
        }
      }
    }
    catch (WTException e)
    {
      e.printStackTrace();
    }
    catch (ParserConfigurationException e) {
      e.printStackTrace();
    }
    catch (SAXException e) {
      e.printStackTrace();
    }
    catch (IOException e) {
      e.printStackTrace();
    }
  }
}