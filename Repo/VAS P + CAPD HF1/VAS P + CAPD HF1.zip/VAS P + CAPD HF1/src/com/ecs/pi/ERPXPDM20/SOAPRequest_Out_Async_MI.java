/**
 * SOAPRequest_Out_Async_MI.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ecs.pi.ERPXPDM20;

public interface SOAPRequest_Out_Async_MI extends java.rmi.Remote {
	public com.ecs.pi.ERPXPDM20.SOAPResponse_DT SOAPRequest_Out_Async_MI(com.ecs.pi.ERPXPDM20.SOAPRequest_DT SOAPRequest_MT) throws java.rmi.RemoteException;
}
