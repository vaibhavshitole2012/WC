package com.deploy.util;



import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Appender;
import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.FileAppender;
import org.apache.log4j.Layout;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;

import wt.dataops.containermove.ContainerMoveHelper;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.collections.WTValuedHashMap;
import wt.fc.collections.WTValuedMap;
import wt.folder.Folder;
import wt.folder.FolderHelper;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerRef;
import wt.inf.library.WTLibrary;
import wt.method.RemoteMethodServer;
import wt.org.WTOrganization;
import wt.org.WTPrincipal;
import wt.part.WTPart;
import wt.part.WTPartHelper;
import wt.pdmlink.PDMLinkProduct;
import wt.pds.StatementSpec;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.session.SessionHelper;
import wt.type.TypedUtilityServiceHelper;
import wt.util.WTException;
import wt.vc.wip.WorkInProgressHelper;
import wt.vc.wip.Workable;

import com.ptc.ddl.lock.LockException;

import ext.kb.util.KBUtils;





// TODO: Auto-generated Javadoc

/**

 * The Class PartMoveUtil.

 */

public class PartMoveUtil {



	/**

	 * The Constant CLASSNAME.

	 */

	private static final String CLASSNAME = PartMoveUtil.class.getName();



	/**

	 * The args.

	 */

	private String[] args;



	/**

	 * The logger.

	 */



	private static Logger logger = null;



	static {

		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss");

		Date date = new Date();



		logger = Logger.getLogger(CLASSNAME);

		Layout layout = new PatternLayout("");

		Appender console = new ConsoleAppender(layout);

		Appender file = null;

		try {

			file = new FileAppender(new PatternLayout(

					PatternLayout.DEFAULT_CONVERSION_PATTERN), "/opt/ptc/Windchill/Windchill/logs/IXBExpImp/PartMoveUtil_"+dateFormat.format(date)+".log");



		} catch (IOException e) {

			// TODO Auto-generated catch block

			e.printStackTrace();

		}

		logger.addAppender(console);

		logger.addAppender(file);

		Level level = Level.DEBUG;

		logger.setLevel(level);

	}



	/**

	 * Instantiates a new File Format Utility.

	 *

	 * @param args

	 *            the args

	 */

	public PartMoveUtil(String[] args) {

		this.args = args;

	}



	/**

	 * The main method.

	 *

	 * @param args

	 *            the arguments

	 */

	public static void main(String[] args) {

		new PartMoveUtil(args).run();

	}



	/**

	 * Run.

	 */

	public void run() {

		logger.info("PartMoveUtil starts");

		if (args.length < 3 || args.length > 14) {

			printUsage();

			logger.info("PartMoveUtil ends with status 1");

			System.exit(1);

		}



		// Authenticate to Windchill as wcadmin

		String login = args[0];

		String password = args[1];

		authenticate(login, password);



		// start processing part

		process();

		logger.info("PartMoveUtil ends with status 0");

		System.exit(0);

	}



	/**

	 * Authenticate.

	 *

	 * @param username

	 *            the username

	 * @param password

	 *            the password

	 */

	private void authenticate(String username, String password) {

		RemoteMethodServer remoteMethodServer = RemoteMethodServer.getDefault();

		remoteMethodServer.setUserName(username);

		remoteMethodServer.setPassword(password);

		try {

			WTPrincipal currentUser = SessionHelper.manager.getPrincipal();

			WTPrincipal wtAdministrator = SessionHelper.manager

					.getAdministrator();

			if (!currentUser.equals(wtAdministrator)) {

				logger.info("Invalid user! DeletePrincipal may be launched by Windchill Administrator only \nPartMoveUtil ends with status 1");

				System.exit(1);

			}

		} catch (WTException e) {

			logger.error("Authentication failed! " + e.getLocalizedMessage()

					+ "\nPartMoveUtil ends with status 1");

			logger.error(" Exception :" + e.toString());

			System.exit(1);

		}

	}



	/**

	 * Process.

	 */

	public void process() {

		try {

			List<String> arguments = Arrays.asList(args);

			// if file has been specified

			Map<String, String> argumentMap = new HashMap<String, String>();



			// Preprocess actions arguments except -f

			String[] theActions = new String[] { "-p" };

			for (String action : theActions) {

				if (arguments.contains(action)) {

					String argValue = arguments

							.get(arguments.indexOf(action) + 1);

					argumentMap.put(action, argValue);

				}

			}



			logger.info("arguments= " + arguments);

			if (arguments.contains("-f")) {

				// process contents from file

				try {

					int indexOfFilePath = arguments.indexOf("-f") + 1;

					String filePath = arguments.get(indexOfFilePath);



					BufferedReader reader = new BufferedReader(new FileReader(

							filePath));

					String textLine = "";

					String unknown = "UNKNOWN";

					// read file line by line

					while ((textLine = reader.readLine()) != null) {

						// for all possible actions (like delete user in WT and

						// LDAP -u)

						textLine = textLine.trim();

						String[] possibleActions = new String[] { "-p" };

						boolean foundAction = false;

						for (String action : possibleActions) {



							if (textLine.startsWith(action)) {

								foundAction = true;

								logger.info("action= " + action);

								// remove "action's" part of string

								textLine = textLine.replaceFirst(action, "");

								textLine = textLine.trim();

								// if list of arguments contains already the

								// same action

								String previousValue = "";

								if (argumentMap.containsKey(action)) {

									previousValue = argumentMap.get(action);

									// concatenate both values (new and

									// from textline)

									String nextvalue = previousValue

											.concat(",").concat(textLine);

									argumentMap.put(action, nextvalue);

								} else {

									argumentMap.put(action, textLine);

								}

							}

						}

						if (!foundAction) {

							if (!argumentMap.containsKey(unknown)) {

								argumentMap.put(unknown, textLine);

							} else {

								String texUnknown = argumentMap.get(unknown);

								texUnknown = texUnknown.concat(",").concat(

										textLine);

								logger.info("texUnknown= " + texUnknown);

								argumentMap.put(unknown, texUnknown);

							}



						}

						foundAction = false;

					}



					if (argumentMap.containsKey(unknown)) {

						String text2 = argumentMap.get(unknown);

						throw new IOException("Some data can from " + filePath

								+ " not be processed: \n" + text2);

					} else {

						logger.info("Data in file processed successfully");



					}

				} catch (IOException e) {

					logger.error("Unable to load data from file specified.\nDeletePrincipal ends with status 1");

					logger.error(" Exception :" + e.toString());

				}

			}



			if (argumentMap.containsKey("-p")) {

				// # Part Number , Part Cage Code , Target Type , Target

				// CageCode, Target Container Type

				logger.info("Processing -p argument...");

				String[] parts = argumentMap.get("-p").split(",");



				for (String partsToUpdate : parts) {

					String[] partUpdate = partsToUpdate.split(":");

					String partNumber = partUpdate[0];

					String partCageCode = partUpdate[1];



					WTOrganization org = getOrganization(partCageCode);

					logger.info("###########################");

					WTPart wtPart = searchPart(partNumber, partCageCode, org);
					boolean isEbomPart = KBUtils.isEbomPart(wtPart);
					if(!isEbomPart) {
						logger.info("Skipping part as it is MBOM, not EBOM");
						continue;
					}


					// Code to check if there is Target Type , Target CageCode

					// or

					// Target Container Type based on String Literal Patterns

					// Matching

					String[] containerUpdate = null;

					String partTargetType = null;

					String partTargetCageCode = null;

					String partTargetContainerType = null;

					String partTargetContainerFolder = "/Default/30 Hidden";



					String patternPartType = "(wt.part)";

					String patternTypeKnorr = "(com.knorr_bremse.corp)";

					String patternPTC = "(com.ptc)";

					// String patternCageCode = "(0)";

					String patternContainerLibrary = "(Library)";

					String patternContainerProduct = "(Product)";



					// Create a Pattern object

					Pattern r = Pattern.compile(patternPartType);

					// Pattern r2 = Pattern.compile(patternCageCode);

					Pattern r3 = Pattern.compile(patternContainerLibrary);

					Pattern r4 = Pattern.compile(patternContainerProduct);

					Pattern r5 = Pattern.compile(patternTypeKnorr);

					Pattern r6 = Pattern.compile(patternPTC);

					int nArguments = 0;

					for (int i = 2; i <= partUpdate.length-1; i++) {



						//logger.info("i = " + i + " lenght: " + partUpdate.length);



						// Now create matcher object.

						Matcher m = r.matcher(partUpdate[i]);

						// Matcher m2 = r2.matcher(partUpdate[i+2]);

						Matcher m3 = r3.matcher(partUpdate[i]);

						Matcher m4 = r4.matcher(partUpdate[i]);

						Matcher m5 = r5.matcher(partUpdate[i]);

						Matcher m6 = r6.matcher(partUpdate[i]);



						if (m.find() || m5.find() || m6.find()) {

							partTargetType = partUpdate[i];

							logger.info("Found Target Type: " + partTargetType);

						} else if (m3.find()) {

							partTargetContainerType = partUpdate[i];

							logger.info("Found Target Container Library: "

									+ partTargetContainerType);



							containerUpdate = partTargetContainerType.split(";");

							partTargetContainerType = containerUpdate[1];



						} else if (m4.find()){

							partTargetContainerType = partUpdate[i];

							logger.info("Found Target Container Product: "

									+ partTargetContainerType);



							containerUpdate = partTargetContainerType.split(";");

							partTargetContainerType = containerUpdate[1];

						} else {

							partTargetCageCode = partUpdate[i];

							logger.info("Found Target CageCode: " + partTargetCageCode);

						}

						nArguments++;

					}



					try{

						//logger.info("Evaluating number of arguments...");

						//logger.info("Number of arguments: " + nArguments);

						//Just one argument

						if (nArguments == 1 && !(wtPart == null)){





							//Change Target Type

							if (partTargetCageCode == null & partTargetContainerType == null) {



								logger.info("Update - Target Type: " + partTargetType);



								//CHECKOUT

								WTPart work = (WTPart) checkOut(wtPart, "CheckOut by PartMoveUtil");



								work.setTypeDefinitionReference(TypedUtilityServiceHelper.service.getTypeDefinitionReference(partTargetType));



								//CHECKIN

								checkIn(work, "CheckIn by PartMoveUtil");



							}



							//Change Target Container

							else if (partTargetType == null && partTargetCageCode == null) {

								logger.info("Update - Target Container: " + partTargetContainerType);



								WTContainer targetContainer = null;



								if (containerUpdate[0].equals("Product")){

									targetContainer = getContainerProduct(partTargetContainerType);

								}else{

									targetContainer = getContainerLibrary(partTargetContainerType);

								}



								if (containerUpdate.length == 2){

									moveToContainer(targetContainer, partTargetContainerFolder, wtPart);

								}else{

									moveToContainer(targetContainer, containerUpdate[2], wtPart);

								}





							}

							//Change Target Cage Code / Organization

							//if (partTargetType == null && partTargetContainerType == null)

							else {

								logger.info("Update - Target Cage Code: "

								+ partTargetCageCode);





								WTOrganization targetOrg = getOrganization(partTargetCageCode);



								//CHECKOUT

								WTPart work = (WTPart) checkOut(wtPart, "CheckOut by PartMoveUtil");



								WTPartHelper.service.changeWTPartMasterIdentity(work.getMaster(),work.getName(), work.getNumber(), targetOrg);



								//CHECKIN

								checkIn(work, "CheckIn by PartMoveUtil");



							}

						}else if ((nArguments == 2) && !(wtPart == null)){

							//

							// #- If only Type is not given

							if (!(partTargetCageCode == null) && !(partTargetContainerType == null) && (partTargetType == null)) {



								logger.info("Update - Target Cage Code: "

									+ partTargetCageCode + " Update - Target Container: "

									+ partTargetContainerType);



								WTOrganization targetOrg = getOrganization(partTargetCageCode);



								WTContainer targetContainer = null;



								if (containerUpdate[0].equals("Product")){

									targetContainer = getContainerProduct(partTargetContainerType);

								}else{

									targetContainer = getContainerLibrary(partTargetContainerType);

								}



								if (containerUpdate.length == 2){

									moveToContainer(targetContainer, partTargetContainerFolder, wtPart);

								}else{

									moveToContainer(targetContainer, containerUpdate[2], wtPart);

								}



								//CHECKOUT

								WTPart work = (WTPart) checkOut(wtPart, "CheckOut by PartMoveUtil");



								WTPartHelper.service.changeWTPartMasterIdentity(work.getMaster(),work.getName(), work.getNumber(), targetOrg);



								//CHECKIN

								checkIn(work, "CheckIn by PartMoveUtil");



							}

							//#- If only Container Type not given

							else if (!(partTargetType == null) && !(partTargetCageCode == null) && (partTargetContainerType == null)) {



								logger.info("Update - Target Container: " 	+ partTargetContainerType + " Update - Target Type: " + partTargetType);



								WTOrganization targetOrg = getOrganization(partTargetCageCode);





								//CHECKOUT

								WTPart work = (WTPart) checkOut(wtPart, "CheckOut by PartMoveUtil");



								WTPartHelper.service.changeWTPartMasterIdentity(work.getMaster(),work.getName(), work.getNumber(), targetOrg);

								work.setTypeDefinitionReference(TypedUtilityServiceHelper.service.getTypeDefinitionReference(partTargetType));



								//CHECKIN

								checkIn(work, "CheckIn by PartMoveUtil");



							}

							// #- If only Cage Code is not given

							if (!(partTargetType == null) && !(partTargetContainerType == null) && (partTargetCageCode == null)) {



								logger.info("Update - Target Container: " 	+ partTargetContainerType + " Update - Target Type: " + partTargetType);



								WTContainer targetContainer = null;



								if (containerUpdate[0].equals("Product")){

									targetContainer = getContainerProduct(partTargetContainerType);

								}else{

									targetContainer = getContainerLibrary(partTargetContainerType);

								}



								if (containerUpdate.length == 2){

									moveToContainer(targetContainer, partTargetContainerFolder, wtPart);

								}else{

									moveToContainer(targetContainer, containerUpdate[2], wtPart);

								}



								//CHECKOUT

								WTPart work = (WTPart) checkOut(wtPart, "CheckOut by PartMoveUtil");



								work.setTypeDefinitionReference(TypedUtilityServiceHelper.service.getTypeDefinitionReference(partTargetType));



								//CHECKIN

								checkIn(work, "CheckIn by PartMoveUtil");



							}

						} else {

							//#- Update all

							if(!(partTargetContainerType == null) && !(partTargetType == null) && !(partTargetCageCode == null) && !(wtPart == null)){

								logger.info("Update ALL " + "Update - Target Container: " 	+ partTargetContainerType + " Update - Target Type: " + partTargetType + " Update - Target Cage Code: "

								+ partTargetCageCode);



								WTContainer targetContainer = null;



								if (containerUpdate[0].equals("Product")){

									targetContainer = getContainerProduct(partTargetContainerType);

								}else{

									targetContainer = getContainerLibrary(partTargetContainerType);

								}



								WTOrganization targetOrg = getOrganization(partTargetCageCode);



								logger.info(containerUpdate.length);

								if (containerUpdate.length == 2){

									moveToContainer(targetContainer, partTargetContainerFolder, wtPart);

								}else{

									moveToContainer(targetContainer, containerUpdate[2], wtPart);

								}



								//CHECKOUT

								WTPart work = (WTPart) checkOut(wtPart, "CheckOut by PartMoveUtil");



								work.setTypeDefinitionReference(TypedUtilityServiceHelper.service.getTypeDefinitionReference(partTargetType));



								WTPartHelper.service.changeWTPartMasterIdentity(work.getMaster(),work.getName(), work.getNumber(), targetOrg);



								//CHECKIN

								checkIn(work, "CheckIn by PartMoveUtil");

							}

						}

					}catch (Exception e){

						logger.warn("WARNING: " + e);

					}



				}

			}



		} catch (Exception e) {

			logger.error("Exception!! " + e.getLocalizedMessage()

					+ "  \nPartMoveUtil ends with status 1");

			logger.error(" Exception :" + e.toString());

			System.exit(1);

		}

	}



	/**

	 * Prints the usage.

	 */

	private void printUsage() {

		System.out

		.println("Usage: PartMoveUtil <login> <password> -f <path to file with list of parts to be updated> \n"

						+ "Update Parts in WT\n"

						+ "<login> - login of Windchill administrator\n"

						+ "<password> - password of Windchill administrator\n"

						+ "-f <path to file parts> - path to file with parts to be updated\n"

						+ "EXAMPLE: windchill com.eads.efw.common.tools.PartMoveUtil <login> <password> -f <path to file>\n"

						+ "EXAMPLE: file row example: -p <partNumber>:<partCageCode>:<targetCageCode>:<Product;Product Container Name;/Default>:<targetType>\n"

						+ "<partNumer> and <partCageCode> are OBRIGATORY\n"

						+ "Enter at least 1 <targetCageCode> or <Product/Product Container Name> or <targetType>\n"

						+ "NOTE: <Product;Product Container Name> or <Library;Library Container Name;/Default>");

	}



	private static WTOrganization getOrganization(String epmOrg) {

		WTOrganization org = null;

		try {

			int[] fromIndicies = { 0, -1 };



			QuerySpec querySpec = new QuerySpec(WTOrganization.class);

			querySpec.appendWhere(new SearchCondition(WTOrganization.class,

					WTOrganization.NAME, SearchCondition.EQUAL, epmOrg),

					fromIndicies);



			Enumeration orgEnum = PersistenceHelper.manager

					.find((StatementSpec) querySpec);

			if (orgEnum.hasMoreElements()){

				org = (WTOrganization) orgEnum.nextElement();

			}

		}catch(WTException e){

			e.printStackTrace();

		}

		return org;

	}



	private static WTContainer getContainerLibrary(String container) {

		WTContainer cont = null;

		try {

			int[] fromIndicies = { 0, -1 };



			QuerySpec querySpec = new QuerySpec(WTLibrary.class);

			querySpec.appendWhere(new SearchCondition(WTLibrary.class,

					WTLibrary.NAME, SearchCondition.EQUAL, container),

					fromIndicies);



			Enumeration contEnum = PersistenceHelper.manager

					.find((StatementSpec) querySpec);

			if (contEnum.hasMoreElements()){

				cont = (WTContainer) contEnum.nextElement();

			}

		}catch(WTException e){

			e.printStackTrace();

		}

		return cont;

	}



	private static WTContainer getContainerProduct(String container) {

		WTContainer cont = null;

		try{

			int[] fromIndicies = { 0, -1 };



			QuerySpec querySpec = new QuerySpec(PDMLinkProduct.class);

			querySpec.appendWhere(new SearchCondition(PDMLinkProduct.class,

					PDMLinkProduct.NAME, SearchCondition.EQUAL, container),

					fromIndicies);



			Enumeration contEnum = PersistenceHelper.manager

					.find((StatementSpec) querySpec);

			if (contEnum.hasMoreElements()){

				cont = (WTContainer) contEnum.nextElement();

			}

		}catch(WTException e){

			e.printStackTrace();

		}

		return cont;

	}



	public static void moveToContainer (WTContainer targetContainer, String targetFolder, WTPart wtPart){



		WTContainerRef c_ref;

		try {

			c_ref = WTContainerRef.newWTContainerRef(targetContainer);

			//Original folder if needed

			//Folder folder1 = targetContainer.getDefaultCabinet();



			//Target folder: Move the doc to AA folder in the product

			Folder folder2 = FolderHelper.service.getFolder(targetFolder, c_ref);



			//Get moved doc

			WTValuedMap objFolderMap = new WTValuedHashMap(1);

			objFolderMap.put(wtPart, folder2);

			ContainerMoveHelper.service.moveAllVersions(objFolderMap);





		} catch (WTException e) {

			// TODO Auto-generated catch block

			e.printStackTrace();

		}



	}

	public static void moveAllViewVersionsToContainer (WTContainer targetContainer, String targetFolder, WTPart wtPart){



		WTContainerRef c_ref;

		try {

			c_ref = WTContainerRef.newWTContainerRef(targetContainer);

			//Original folder if needed

			//Folder folder1 = targetContainer.getDefaultCabinet();



			//Target folder: Move the doc to AA folder in the product

			Folder folder2 = FolderHelper.service.getFolder(targetFolder, c_ref);



			//Get moved doc

			WTValuedMap objFolderMap = new WTValuedHashMap(1);

			objFolderMap.put(wtPart, folder2);

			ContainerMoveHelper.service.moveAllViewVersions(objFolderMap);





		} catch (WTException e) {

			// TODO Auto-generated catch block

			e.printStackTrace();

		}



	}



	private static WTPart searchPart(String partNumber, String partCageCode, WTOrganization org){

		WTPart wtPart = null;

		try{

			QuerySpec qs = new QuerySpec(WTPart.class);

			qs.appendWhere(new SearchCondition(WTPart.class,

					WTPart.NUMBER, SearchCondition.EQUAL,

					partNumber), new int[] { 0 });

			qs.appendAnd();

			qs.appendWhere(

					new SearchCondition(WTPart.class,

							"master>organizationReference.key.id",

							SearchCondition.EQUAL,

							Long.parseLong(org.getReferenceID())),

							new int[] { 0 });

			qs.appendAnd();

			qs.appendWhere(

					new SearchCondition(WTPart.class,

							"iterationInfo.latest",

							SearchCondition.IS_TRUE),

							new int[] { 0 });



			QueryResult qr = PersistenceHelper.manager

					.find((StatementSpec) qs);



			if (qr.hasMoreElements()) {

				//logger.info(qr.getObjectVectorIfc());

				wtPart = (WTPart) qr.nextElement();

				logger.info("PART FOUND IN WINDCHILL!!   Part Name: "

					+ wtPart.getName() + " Part Number: " + wtPart.getNumber());

			}else {

				logger.warn("No Object was found with the NUMBER: "

					+ partNumber + " and CAGECODE: "

					+ partCageCode);

			}



		}catch (WTException e){

			e.printStackTrace();

		}

		return wtPart;

	}



	//-------------------------------------------------------------

	/*

	 *	Checks in a Workable (WTPart, WTDocument) and returns the working copy

	 *

	 *	@param	workable	Workable object to be checked out

	 *	@param	message		Comment to be included during checkin operation

	 *	@exception			WTException

	 *	@exception			LockException

	 */

	private static void checkIn(Workable workable, String message) throws LockException, WTException

	{

		try

		{

			WorkInProgressHelper.service.checkin(workable, message);

		}

		catch(Exception exception)

		{

			exception.printStackTrace();

			logger.warn(exception.getMessage());

		}

		return;

	}



	/*

	 *	Checks out a Workable (WTPart, WTDocument) and returns the working copy

	 *

	 *	@param	workable	Workable object to be checked out

	 *	@param	message		Comment to be included during checkout operation

	 *	@exception			WTException

	 *	@exception			LockException

	 */

	private static Workable checkOut(Workable workable, String message) throws LockException, WTException

	{

		Workable workable1 = null;

		try

		{

			if (!workable.getCheckoutInfo().getState().toString().equals("c/o") || !workable.getCheckoutInfo().getState().toString().equals("wrk")){

				if(WorkInProgressHelper.service.isCheckoutAllowed(workable))

				{

					WorkInProgressHelper.service.checkout(workable, WorkInProgressHelper.service.getCheckoutFolder(), message);

					workable1 = WorkInProgressHelper.service.workingCopyOf(workable);

				}

				else

				{

					String moreInfo = workable.getCheckoutInfo().getState().toString();

					logger.warn("Checkout failed! Object checkout state: " + moreInfo);

					logger.warn("Make sure the object is CheckedIn.");

				}

			}else{

				workable1 = WorkInProgressHelper.service.workingCopyOf(workable);

			}

		}

		catch(Exception exception)

		{

			exception.printStackTrace();

		}

		return workable1;

	}



}
