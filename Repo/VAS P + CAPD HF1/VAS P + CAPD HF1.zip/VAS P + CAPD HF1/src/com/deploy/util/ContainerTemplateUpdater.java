package com.deploy.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.commons.collections.ExtendedProperties;
import org.apache.log4j.Logger;
import org.jfree.util.Log;
import org.xml.sax.SAXException;

import ext.kb.util.ContainerHelper;
import ext.kb.util.QueryHelper;
import wt.access.AccessControlHelper;
import wt.fc.PersistInfo;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.collections.WTHashSet;
import wt.inf.container.ContainerSpec;
import wt.inf.container.WTContained;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerHelper;
import wt.inf.container.WTContainerRef;
import wt.inf.container.WTContainerTemplateRef;
import wt.inf.library.WTLibrary;
import wt.inf.team.ContainerTeam;
import wt.inf.team.ContainerTeamHelper;
import wt.inf.team.ContainerTeamManaged;
import wt.inf.template.ContainerTemplateHelper;
import wt.inf.template.ContainerTemplateServerHelper;
import wt.inf.template.DefaultWTContainerTemplate;
import wt.inf.template.WTContainerTemplateException;
import wt.log4j.LogR;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.org.WTPrincipal;
import wt.org.WTPrincipalReference;
import wt.pdmlink.PDMLinkProduct;
import wt.pds.StatementSpec;
import wt.pom.Transaction;
import wt.preference.PreferenceInstance;
import wt.project.Role;
import wt.projmgmt.admin.Project2;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;
import wt.util.WTProperties;
import wt.util.WTPropertyVetoException;
import wt.xml.XMLLob;

/**
 * The Class ContainerTemplateUpdater. Tool created for updating the container
 * template reference after running ACLRemover.
 *
 * @author kbil
 */
public class ContainerTemplateUpdater implements RemoteAccess {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = Logger.getLogger(ContainerTemplateUpdater.class);

	/** The Constant USERNAME_ARG. */
	private static final String USERNAME_ARG = "-u";

	/** The Constant PASSWORD_ARG. */
	private static final String PASSWORD_ARG = "-p";

	/** The Constant CONTAINER_PATH_ARG. */
	private static final String CONTAINER_PATH_ARG = "-c";

	/** The Constant SOURCE_FILE. */
	private static final String SOURCE_FILE = "-f";

	/** The Constant CONTAINER. */
	private static final String CONTAINER = "-o";

	/** The Constant TEMPLATE_NAME. */
	private static final String TEMPLATE_NAME = "-t";
	/** Name of the class. */
	private static final String CLASSNAME = ContainerTemplateUpdater.class.getName();

	private static Logger logger = LogR.getLogger(CLASSNAME);

	private static Class[] supportedClasses = new Class[] { PDMLinkProduct.class, WTLibrary.class, Project2.class};

	private static final String XSL_PROPERTY = "ext.liebherr.containerUpdate.templateFilterFile";

	/** Sample usage of the tool. */
	private static final String SAMPLE_USAGE = "\nSample usage: windchill com.deploy.util.ContainerTemplateUpdater -u $username "
			+ "-p $password -c $containerPath -o KB" + "\n-f - source file with conainers path which should be updated"
			+ "\n-c - path to container wich should be changed, example: /wt.inf.container.OrgContainer=KB/wt.pdmlink.PDMLinkProduct=MUC-BC-D14"
			+ "\n-o - container ofr example HVAC, KB or / - site " + "\n both options -f and -c can be used"
			+ "\n -t - template name" + "\nRoles configuration is set in file codebase/ext/roles_map_properties.xconf"
			+ "\nsourceRole,destinationRole"
			+ "\n<Property name=\"ext.kb.roles.map.source.to.destination.1\" 	overridable=\"true\" targetFile=\"codebase/wt.properties\"  value=\"CAD-APPROVE,CAD-APPROVER\"/>";

	/** The rms. */
	private static RemoteMethodServer rms = RemoteMethodServer.getDefault();

	@SuppressWarnings("rawtypes")
	public static void main(String[] args) {
		int argsLength = args.length;
		String username = "";
		String password = "";
		String containerPath = "";
		String filePath = "";
		String container = "";
		String templateName = "";

		if (argsLength == 0) {
			System.out.println("\nNo arguments passed!");
			System.out.println(SAMPLE_USAGE);
			System.exit(1);
		}

		for (int i = 0; i < argsLength; i++) {
			if (args[i].equals(USERNAME_ARG)) {
				if (++i < argsLength) {
					username = args[i];
				} else {
					System.out.println("\nNo username passed!");
					System.out.println(SAMPLE_USAGE);
					System.exit(1);
				}
			} else if (args[i].equals(PASSWORD_ARG)) {
				if (++i < argsLength) {
					password = args[i];
				} else {
					System.out.println("\nNo password passed!");
					System.out.println(SAMPLE_USAGE);
					System.exit(1);
				}
			} else if (args[i].equals(CONTAINER)) {
				if (++i < argsLength) {
					container = args[i];
				} else {
					System.out.println("\nNo container passed!");
					System.out.println(SAMPLE_USAGE);
					System.exit(1);
				}
			} else if (args[i].equals(TEMPLATE_NAME)) {
				if (++i < argsLength) {
					templateName = args[i];
				} else {
					System.out.println("\nNo template name passed!");
					System.out.println(SAMPLE_USAGE);
					System.exit(1);
				}
			} else if (args[i].equals(CONTAINER_PATH_ARG)) {
				if (++i < argsLength) {
					containerPath = args[i];
				}
			} else if (args[i].equals(SOURCE_FILE)) {
				if (++i < argsLength) {
					filePath = args[i];
				}
			} else {
				System.out.println("\nNot recognized option" + args[i]);
				System.out.println(SAMPLE_USAGE);
				System.exit(1);
			}

		}

		if ("".equals(filePath) && "".equals(containerPath)) {
			System.out.println("\nYou have to specify -c container path or -f file path with containers path");
			System.out.println(SAMPLE_USAGE);
			System.exit(1);
		}
		if (container != null && container.isEmpty()) {
			System.out.println("\nContainer have to be passed!");
			System.out.println(SAMPLE_USAGE);
			System.exit(1);
		}
		if (username != null && !username.equals("")) {
			rms.setUserName(username);
			if (password != null) {
				rms.setPassword(password);
			}
		}
		Map<String, String> productList = new HashMap<>();
		if (!"".equals(filePath)) {
			productList = getProductsFromFile(filePath);
		}else{
		productList.put(containerPath, templateName);}
		try {
			Class[] argTypes = { Map.class, String.class };
			Object[] arg = { productList, container };
			rms.invoke("updateContainerTemplate", CLASSNAME, null, argTypes, arg);
			System.out.println("-> Container template updated!");
		} catch (RemoteException | InvocationTargetException e) {
			LOGGER.error("Error updating container template!");
			e.printStackTrace();
		}
		System.exit(0);
	}

	/**
	 * Performs the update of container template.
	 *
	 * @param container
	 *            path of the container to be updated
	 * @throws Exception
	 *             the exception
	 */
	public static void updateContainerTemplate(Map<String, String> containerList, String container) throws Exception {
		System.out.println("================================================================================");
		System.out.println("Starting CONTAINER TEAMPLATE UPDATER");
		System.out.println("================================================================================");
		System.out.println("================================================================================");
		System.out.println("Starting updating containers template");
		File file = createFileForProductsWithBadName();
		BufferedWriter writer = new BufferedWriter(new FileWriter(file));
		for (Map.Entry<String, String> entry : containerList.entrySet()) {
			WTContainerRef containerRef;
			WTContainer containerByName = getContainerByName(entry.getKey());
			if(entry.getKey() != null && containerByName != null){
			String path = getPathFromProductName(containerByName, container);
			try {
				containerRef = WTContainerHelper.service.getByPath(path);
				System.out.println(updateContainerSrv(containerRef, true, false, null, false, entry.getValue(), null));
			} catch (WTException e) {
				System.out.println("********************************************************************************");
				System.out.println("Cannot find container :" + entry.getKey());
				System.out.println("********************************************************************************");
			}}else{
			writer.append(entry.getKey());
			writer.newLine();
			}
		}
		writer.close();
		System.out.println("Finishing CONTAINER TEAMPLATE UPDATER");
		System.out.println("================================================================================");
	}

	private static void copyMembers(Map<String, String> containerList, String container) throws WTException, IOException {
		System.out.println("================================================================================");
		System.out.println("Starting copying members from roles ");
		HashMap<String, String> rolesConfiguration = getRolesConfiguration();
		for (Map.Entry<String, String> entry : containerList.entrySet()) {
			WTContainer containerByName = getContainerByName(entry.getKey());
			if(containerByName != null){
				String path = getPathFromProductName(containerByName, container);
				copyRoleMembers(rolesConfiguration, path);
			}
		}
		System.out.println("================================================================================");
		System.out.println("Finishing copying members from roles");
	}

	public static String getPathFromProductName(WTContainer containerByName, String container) throws WTException, IOException{
		if ("/".equals(container)) {
			container = "/";
		} else {
			container = "/wt.inf.container.OrgContainer=" + container;
		}
		return container + "/" + containerByName.getConceptualClassname() + "=" + containerByName.getName();
		
	}

	private static HashMap<String, String> getRolesConfiguration() {
		WTProperties serverProps = null;
		try {
			serverProps = WTProperties.getServerProperties();
		} catch (IOException e) {
			e.printStackTrace();
		}
		Iterator<String> it = getRolesMapIterator(serverProps);
		HashMap<String, String> rolesConfiguration = new HashMap<String, String>();
		System.out.println("================================================================================");
		System.out.println("Roles congiguration:");
		while (it != null && it.hasNext()) {
			String saveAsAttribResetPropKey = it.next();
			String saveAsResetProp = (String) serverProps.getProperty(saveAsAttribResetPropKey);
			String[] tokenizer = saveAsResetProp.split(",", -1);
			String sourceRole;
			String destinationRole;
			sourceRole = tokenizer[0];
			destinationRole = tokenizer[1];
			rolesConfiguration.put(sourceRole, destinationRole);
			System.out.println("Members from role " + sourceRole + " should will be copied to role " + destinationRole);
		}
		System.out.println("================================================================================");
		return rolesConfiguration;
	}

	public static void copyRoleMembers(HashMap<String, String> rolesConfiguration, String containerPath)
			throws WTException {

		Iterator<Map.Entry<String, String>> iterator = rolesConfiguration.entrySet().iterator();
		System.out.println("================================================================================");
		System.out.println("Copying members in " + containerPath);
		try {
			QueryResult queryProducts = getContainers(containerPath);
			while (queryProducts.hasMoreElements()) {
				WTContained contained = (WTContained) queryProducts.nextElement();
				ContainerTeam containerTeam = ContainerTeamHelper.service
						.getContainerTeam((ContainerTeamManaged) contained);
				while (iterator.hasNext()) {
					Map.Entry<String, String> pair = iterator.next();
					copyMembers(containerTeam, pair.getKey(), pair.getValue());
				}
			}
		} catch (WTException e) {
			System.out.println("********************************************************************************");
			System.out.println("Cannot find container :" + containerPath);
			System.out.println("********************************************************************************");
		}
		System.out.println("Exiting form " + containerPath);
		System.out.println("================================================================================");
	}

	private static void copyMembers(ContainerTeam containerTeam, String sourceRoleName, String destinationRoleName)
			throws WTException {
		Role sourceRole = Role.toRole(sourceRoleName);
		Role destinationRole = Role.toRole(destinationRoleName);
		ArrayList<WTPrincipalReference> principalReference = containerTeam.getAllPrincipalsForTarget(sourceRole);
		System.out.println("Copying from role " + sourceRoleName + " to role " + destinationRole);
		for (WTPrincipalReference principal : principalReference) {
			System.out.println("Copying member " + principal.getDisplayName());
			containerTeam.addPrincipal(destinationRole, (WTPrincipal) principal.getObject());
			if (sourceRoleName.equals("CAD-VIEWER-INTERNAL")) {
				ContainerTeamHelper.service.removeMember(containerTeam, sourceRole, principal.getPrincipal()); 
			}
		}
		
	}

	public static WTContainer getContainerByName(String containerName) throws WTException, IOException{
		QuerySpec queryContainers = new QuerySpec(WTContainer.class);
		queryContainers.appendWhere(new SearchCondition(WTContainer.class,
				WTContainer.NAME, SearchCondition.EQUAL, containerName),
				new int[] { 0 });
		QueryResult foundContainers = PersistenceHelper.manager
				.find((StatementSpec) queryContainers);
		if (foundContainers.size() > 1) {
			throw new WTException("More than one container found!");
		} else if (foundContainers.size() == 0) {
			Log.error("Error with product name: " + containerName);
			return null;
		}
		return (WTContainer)foundContainers.nextElement();
	}
	
	public static QueryResult getContainers(String conatinerPath) throws WTException {
		WTContainerRef wtContainerRef = WTContainerHelper.service.getByPath(conatinerPath);
		ContainerSpec csProd = new ContainerSpec(PDMLinkProduct.class);
		csProd.addSearchContainer(WTContainerRef.newWTContainerRef(wtContainerRef));
		QueryResult qrProd = WTContainerHelper.service.getContainers(csProd);
		return qrProd;
	}

	public static Map<String, String> getProductsFromFile(String filePath) {

		Map<String, String> products = new HashMap<>();
		File inFile = new File(filePath);
		BufferedReader brFile = null;
		try {
			brFile = new BufferedReader(new FileReader(inFile));
			String lineFromFile = null;
			while ((lineFromFile = brFile.readLine()) != null) {
				String[] line = lineFromFile.split(",");
				products.put(line[0], line[1]);
			}
		} catch (FileNotFoundException e) {
			System.out.println("File " + filePath + " not found");
			System.exit(1);
		} catch (IOException e) {
			System.out.println("Canot open file " + filePath);
			System.exit(1);
		}
		return products;
	}

	private static Iterator<String> getRolesMapIterator(WTProperties serverProps) {
		ExtendedProperties extendedProps = ExtendedProperties.convertProperties(serverProps);
		Iterator<String> it;
		it = extendedProps.getKeys("ext.kb.roles.map.source.to.destination.");
		return it;
	}

	public static String updateContainerSrv(WTContainerRef containerRef, boolean forceUpdate, boolean deleteAllPrefs,
			String[] prefsDelete, boolean deleteACLs, String templateName, File xslFile) {

		System.out.println("START updateContainer() with containerRef='" + containerRef.getKey() + "' forceUpdate="
				+ forceUpdate + " deletePrefs=" + deleteAllPrefs + " deleteACLs=" + deleteACLs + " templateName='"
				+ templateName + "', xslFile=" + (xslFile == null ? null : xslFile.getAbsolutePath()));

		Class<WTContainer> containerClass = containerRef.getReferencedClass();

		if (!Arrays.asList(supportedClasses).contains(containerClass)) {
			logger.error("Container class " + containerClass + " is not supported.");
			return ("ERROR: Container class " + containerClass + " is not supported.");
		}
		boolean changeTemplate = false;

		Transaction trx = null;
		try {
			WTContainer cont = containerRef.getReferencedContainerReadOnly();
			System.out.println("Found Container '" + containerRef.getName() + "'");

			WTContainerTemplateRef latestIterationTemplateRef = getTemplateForName(containerRef, templateName);
			changeTemplate = true;

			if (forceUpdate || changeTemplate) {
				System.out.println("Updating Container, because forceUpdate=" + forceUpdate + ", changeTemplate="
						+ changeTemplate);

				trx = new Transaction();
				trx.start();

				if (deleteAllPrefs || (prefsDelete != null && prefsDelete.length > 0)) {
					System.out.println("Deleting Preferences...");
					deletePreferenceInstances(cont, prefsDelete);
					logger.trace("Delete Preferences finished.");
				}

				if (deleteACLs) {
					System.out.println("Deleting ACLs...");
					logger.trace("Before delete of /Default ACLs.");
					AccessControlHelper.manager.deleteAccessControlRules(cont.getDefaultDomainReference());
					logger.trace("Before delete of /System ACLs.");
					AccessControlHelper.manager.deleteAccessControlRules(cont.getSystemDomainReference());
					logger.trace("Delete ACLs finished.");
				}

				containerRef = assignContainerToTemplate(containerRef, latestIterationTemplateRef, xslFile);

				trx.commit();
				trx = null;

				System.out.println("Successfully updated Container '" + WTContainerHelper.getDisplayPath(containerRef)
						+ "' with the latest iteration of Template '" + latestIterationTemplateRef.getName() + "'.");
				return "Successfully updated Container '" + WTContainerHelper.getDisplayPath(containerRef)
						+ "' with the latest iteration of Template '" + latestIterationTemplateRef.getName() + "'.";
			}
			System.out.println(
					"No update needed for Container '" + WTContainerHelper.getDisplayPath(containerRef) + "'.");
			return "No update needed for Container '" + WTContainerHelper.getDisplayPath(containerRef) + "'.";
		} catch (WTException e) {
			logger.error("WTException in updateContainer() ", e);
			return "ERROR: An Exception occured: " + e.getLocalizedMessage();
		} finally {
			if (trx != null) {
				logger.error("Roll Back Transaction!!!");
				trx.rollback();
			}
		}

	}

	private static boolean hasContent(String strin) {
		return strin != null && strin.length() > 0;
	}

	private static WTContainerTemplateRef getTemplateForName(WTContainerRef containerRef, String templateName)
			throws WTException {

		DefaultWTContainerTemplate containerTemplate = null;
		QueryResult qRes = ContainerTemplateHelper.service.getAllTemplates(containerRef,
				containerRef.getReferencedClass());
		List<DefaultWTContainerTemplate> allTemplates = QueryHelper.getObjectsFromQr(qRes, 0);
		for (DefaultWTContainerTemplate t : allTemplates) {
			if (t.getName().equals(templateName)) {
				containerTemplate = t;
				t.isLatestIteration();
				System.out.println("Found new template '" + containerTemplate.getName() + "' (" + containerTemplate
						+ "). latest=" + containerTemplate.isLatestIteration());
				break;
			}
		}
		if (containerTemplate == null) {
			throw new WTException("No applicable Container Template found for name '" + templateName + "'");
		}
		return ContainerTemplateHelper.service.getContainerTemplateRef(containerTemplate);
	}

	private static void deletePreferenceInstances(WTContainer container, String[] prefs) throws WTException {

		System.out.println(
				"START deletePreferenceInstances() for container=" + container + ", prefs=" + Arrays.toString(prefs));

		List<PreferenceInstance> prefInstances = ContainerHelper.getContainerPreferenceInstances(container, prefs);

		if (prefInstances.size() > 0) {
			if (logger.isTraceEnabled()) {
				logger.trace(prefInstances);
				for (PreferenceInstance inst : prefInstances) {
					logger.trace("Delete Preference " + inst.getPreferenceDefinition().getDisplayName() + "="
							+ inst.getValue() + " (" + inst.getClient().getDisplayName() + ")");
				}
			}
			PersistenceHelper.manager.delete(new WTHashSet(prefInstances));
		}

	}

	private static WTContainerRef assignContainerToTemplate(WTContainerRef container,
			WTContainerTemplateRef containerTemplate, File filterTemplateFile) throws WTException {

		Transaction trx = new Transaction();
		try {
			trx.start();
			WTContainer cont = container.getReferencedContainer();

			DefaultWTContainerTemplate tmpl = (DefaultWTContainerTemplate) containerTemplate.getTemplate();
			XMLLob businessXML = tmpl.getXml();

			String name = tmpl.getName();
			System.out.println("Import Business XML from template '" + tmpl.getName() + "'...");
			if (businessXML != null) {
				businessXML = filterXML(businessXML, filterTemplateFile);
				container = ContainerTemplateServerHelper.service.importBusinessXML(container, businessXML);
			}
			System.out.println("Update Template reference for container...");
			PersistInfo localPersistInfo = cont.getPersistInfo();
			if (localPersistInfo != null) {

				boolean persistedBefore = localPersistInfo.isPersisted();
				int updateCountBefore = localPersistInfo.getUpdateCount();

				if (persistedBefore) {
					localPersistInfo.makeNonPersistent();
				}
				cont.setContainerTemplateReference(containerTemplate);
				if (persistedBefore) {
					localPersistInfo.makePersisted();
					localPersistInfo.setUpdateCount(updateCountBefore);
				}

			} else {
				// actually this case should never happen because this method is
				// not used for new containers...
				cont.setContainerTemplateReference(containerTemplate);
			}
			System.out.println("Save Container...");
			cont = (WTContainer) PersistenceHelper.manager.refresh(cont);
			cont = (WTContainer) PersistenceHelper.manager.save(cont);
			WTContainerRef contRef = WTContainerRef.newWTContainerRef(cont);
			trx.commit();
			trx = null;
			return contRef;

		} catch (WTPropertyVetoException pve) {
			throw new WTContainerTemplateException(pve);
		} finally {
			if (trx != null) {
				trx.rollback();
			}
		}
	}

	private static XMLLob filterXML(XMLLob inXML, File filterTemplateFile) throws WTException {

		if (filterTemplateFile == null) {
			try {
				WTProperties properties = WTProperties.getLocalProperties();
				String filterTemplateFileName = properties.getProperty(XSL_PROPERTY, null);

				if (!hasContent(filterTemplateFileName)) {
					return inXML;
				}
				filterTemplateFile = new File(filterTemplateFileName);

			} catch (IOException e) {
				logger.error("IOException while reading properties:", e);
				throw new WTException(e);
			}
		}

		XMLLob outXML = XMLLob.newXMLLob();

		try {
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			dbf.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
			DocumentBuilder dBuild = dbf.newDocumentBuilder();
			DOMSource inDOM = new DOMSource(
					dBuild.parse(inXML.getInputStream(inXML.getContents(), inXML.getEncoding())));
			StringWriter newContent = new StringWriter();
			TransformerFactory tFactory = TransformerFactory.newInstance();
			Transformer transformer = tFactory.newTransformer(new StreamSource(filterTemplateFile));
			transformer.transform(inDOM, new StreamResult(newContent));
			outXML.setContents(newContent.toString());
		} catch (UnsupportedEncodingException e) {
			logger.error("UnsupportedEncodingException in filterXML():", e);
			throw new WTException(e);
		} catch (TransformerConfigurationException e) {
			logger.error("TransformerConfigurationException in filterXML():", e);
			throw new WTException(e);
		} catch (IllegalArgumentException e) {
			logger.error("IllegalArgumentException in filterXML():", e);
			throw new WTException(e);
		} catch (ParserConfigurationException e) {
			logger.error("ParserConfigurationException in filterXML():", e);
			throw new WTException(e);
		} catch (SAXException e) {
			logger.error("SAXException in filterXML():", e);
			throw new WTException(e);
		} catch (IOException e) {
			logger.error("IOException in filterXML():", e);
			throw new WTException(e);
		} catch (TransformerFactoryConfigurationError e) {
			logger.error("TransformerFactoryConfigurationError in filterXML():", e);
			throw new WTException(e);
		} catch (TransformerException e) {
			logger.error("TransformerException in filterXML():", e);
			throw new WTException(e);
		}
		return outXML;
	}

	public static File createFileForProductsWithBadName() throws IOException{
		File file = new File("/opt/ptc/wt111/windchill/extension/ContainerTemplateUpdater/productsWithBadName.txt");
		if (!file.exists()) {
		file.createNewFile();
		}
		return file;
	}
	
}
