package com.deploy.util;

import org.apache.log4j.Appender;
import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Layout;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;

import wt.epm.EPMDocument;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.method.RemoteMethodServer;
import wt.org.WTPrincipal;
import wt.pds.StatementSpec;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.session.SessionHelper;
import wt.util.WTException;


/**
 * The Class DeleteCADTemplate.
 */
public class DeleteCADTemplate {

	/**
	 * The Constant CLASSNAME.
	 */
	private static final String CLASSNAME = DeleteCADTemplate.class.getName();
	
	/**
	 * The args.
	 */
	private String[] args;
	
	/**
	 * The logger.
	 */
	private static Logger logger = null;

	static {
		logger = Logger.getLogger(CLASSNAME);
		Layout layout = new PatternLayout("");
		Appender console = new ConsoleAppender(layout);
		logger.addAppender(console);
		Level level = Level.DEBUG;
		logger.setLevel(level);
	}

	/**
	 * Instantiates a new delete template.
	 *
	 * @param args the args
	 */
	public DeleteCADTemplate(String[] args) {
		this.args = args;
	}

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {
		new DeleteCADTemplate(args).run();
	}

	/**
	 * Run.
	 */
	public void run() {
		logger.info("DeleteCADTemplate starts");
		
		if (args.length > 3 || args.length < 2) {
			printUsage();
			logger.info("DeleteCADTemplate ends with status 1");
			System.exit(1);
		}
		
		String login = args[0];
		//logger.info("login = " + args[0]);
		String password = args[1];
		//logger.info("password = " + args[1]);
		authenticate(login, password);

		// start processing part
		process();
		logger.info("DeleteCADTemplate ends with status 0");
		System.exit(0);
	}

	/**
	 * Authenticate.
	 *
	 * @param username the username
	 * @param password the password
	 */
	private void authenticate(String username, String password) {
		RemoteMethodServer remoteMethodServer = RemoteMethodServer.getDefault();
		remoteMethodServer.setUserName(username);
		remoteMethodServer.setPassword(password);
		try {
			WTPrincipal currentUser = SessionHelper.manager.getPrincipal();
			WTPrincipal wtAdministrator = SessionHelper.manager
					.getAdministrator();
			if (!currentUser.equals(wtAdministrator)) {
				logger
						.info("Invalid user! DeleteTemplate may be launched by Windchill Administrator only \nDeleteTemplate ends with status 1");
				System.exit(1);
			}
		} catch (WTException e) {
			logger.error("Authentication failed! " + e.getLocalizedMessage()
					+ "\nDeletePrincipal ends with status 1");
			logger.error(" Exception :" + e.toString());
			System.exit(1);
		}
	}

	/**
	 * Process.
	 */
	public void process() {
		try {
			String[] templateNames = null;
			logger.info("templateNames = " + args[2]);
			templateNames = args[2].split(",");

			logger.info("DeleteTemplate process EPMDocuments");
			
			QuerySpec queryEPMDocument = new QuerySpec(EPMDocument.class);

			for (int i = 0; i < templateNames.length; i++) {
				String templateName = templateNames[i];
				queryEPMDocument.appendWhere(new SearchCondition(
						EPMDocument.class, EPMDocument.NAME,
						SearchCondition.EQUAL, templateName),
						new int[] { 0 });
				if (i + 1 < templateNames.length) {
					queryEPMDocument.appendOr();
				}
			}
			
			//logger.info("querySpec" + queryEPMDocument);
			QueryResult queryResult = PersistenceHelper.manager.find((StatementSpec)queryEPMDocument);
			
			
			while(queryResult.hasMoreElements()){
				EPMDocument epmDoc = (EPMDocument)queryResult.nextElement();
				logger.info("epmTemplate removed: " + epmDoc.getName() + "\n");
				PersistenceHelper.manager.delete(epmDoc);				
			}
		} catch (WTException e) {
			logger.error(e.getLocalizedMessage() + " Exiting!!!");
			logger.error(" Exception :" + e.toString());
			System.exit(1);
		}
	}

	/**
	 * Prints the usage.
	 */
	private void printUsage() {
		System.out
				.println("Usage: DeleteCADTemplate <login> <password> <templateName1[, templateName2]>\n"
						+ "<login> - login of Windchill administrator\n"
						+ "<password> - password of Windchill administrator\n"
						+ "<templateName1[, templateName2]> - comma separated list of templates to be deleted\n"
						+ "EXAMPLE: windchill com.deploy.util.DeleteCADTemplate wcadmin wtadmin \"10 HVAC Creo Assembly mm,10 HVAC Creo Part mm\"");
	}

}
