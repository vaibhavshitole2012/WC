/* bcwti
 *
 * Copyright (c) 2009 Parametric Technology Corporation (PTC). All Rights
 * Reserved.
 *
 * This software is the confidential and proprietary information of PTC.
 * You shall not disclose such confidential information and shall use it
 * only in accordance with the terms of the license agreement.
 *
 * ecwti
 */
package com.deploy.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;

import wt.admin.AdminDomainRef;
import wt.admin.AdministrativeDomain;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.index.IndexPolicyHelper;
import wt.index.IndexPolicyRule;
import wt.method.RemoteMethodServer;
import wt.query.ClassAttribute;
import wt.query.ConstantExpression;
import wt.query.QuerySpec;
import wt.query.RelationalExpression;
import wt.query.SearchCondition;
import wt.session.SessionHelper;


public class DeleteIndexPolicy
{
	static String	_libName		= null;
	static String	_domainName		= null;
	static String   _user			= null;
	static String	_passwd		 	= null;
	static boolean	_performDelete 	= false;
	static List<String> _containers = null;
	
	public static void main(String argv[]) {
		if (argv.length == 0 || argv.length > 7) {
			System.out.println("Usage : java com.deploy.util.DeleteIndexPolicy [-delete] -u user -p passwd <libName>/<domainName>");
			System.out.println("   Default behaviour is to do NOT delete Indexing Policy. Add parameter -delete to perform real delete.");
			System.exit(0);
		}
		
		//
		// Parse args
		//
		Hashtable args = new Hashtable();
		for(int i=0;i<argv.length;i++) {
			if (argv[i].charAt(0) == '-' && argv[i+1].charAt(0) == '-')
				args.put(argv[i], argv[i]);
			else if (argv[i].charAt(0) == '-' && argv[i+1].charAt(0) != '-')
				args.put(argv[i], argv[i+1]);
		}
		
		_performDelete = args.containsKey("-delete");
		_user = (String) args.get("-u");
		_passwd = (String) args.get("-p");
		
		init(argv);
		invoke();

		System.exit(0);
	}
	
	private static void invoke(){
		System.out.println("Cleaning domain       : " + _domainName);
		System.out.println("In library            : " + _libName);
		System.out.println("Perform delete of ACL : " + _performDelete);
		System.out.println();
		
		try {
			// Log on Windchill
			//
			RemoteMethodServer rms = RemoteMethodServer.getDefault();
			if (_user != null && !_user.equals("")) {
				rms.setUserName(_user);
				if (_passwd != null)
					rms.setPassword(_passwd);
			}
			
			SessionHelper.manager.getPrincipal();
			
			QuerySpec qs = new QuerySpec();
			int ind2 = qs.addClassList(AdministrativeDomain.class, true);
			
			ClassAttribute classAttribute = new ClassAttribute(AdministrativeDomain.class, AdministrativeDomain.NAME);
			RelationalExpression expression = ConstantExpression.newExpression(_domainName, classAttribute.getColumnDescriptor().getJavaType());
			qs.appendWhere(new SearchCondition(classAttribute, SearchCondition.EQUAL, expression), new int[]{ind2});
			
			QueryResult qr = PersistenceHelper.manager.find(qs);
			
			//
			// Loop into the results
			//
			while (qr.hasMoreElements()) {
				Object[] o = (Object[]) qr.nextElement();
				AdministrativeDomain domain = (AdministrativeDomain) o[0];
				// If rule is related to lib passes as parameter
				if (domain.getContainerName().equals(_libName) && domain.getName().equals(_domainName)){
					System.out.println("domainName=" + domain.getName() + " - domain ContainerName:" + domain.getContainerName());
					
					// Get all rules of the domain _domainName ( including inherited ones )
					Enumeration apRules = IndexPolicyHelper.manager.getIndexPolicyRules(AdminDomainRef.newAdminDomainRef(domain));
					
					while (apRules.hasMoreElements()){
						IndexPolicyRule rule = (IndexPolicyRule) apRules.nextElement();
						// print only rule defined in _domainName
						if (((AdministrativeDomain)rule.getDomainRef().getObject()).getName().equals(_domainName)){
							System.out.println(rule);
							System.out.println();
							System.out.println();
						}
					}
					
					if (_performDelete) {
						IndexPolicyHelper.manager.deleteIndexingRules(AdminDomainRef.newAdminDomainRef(domain));
						System.out.println(" -> Domain cleaned !");
					} else {
						System.out.println(" -> Domain NOT cleaned (add -delete to perform the delete)");
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private static void init(String argv[]){
		String tmpDomain = argv[argv.length-1];
		if (tmpDomain == null || tmpDomain.trim().isEmpty() || "/".equals(tmpDomain.trim())){
			_libName = "Site";
			_domainName = "Root";
		} else {
			_libName = argv[argv.length-1].split("/")[0];
			String[] subDomain = argv[argv.length-1].split("/");
			_domainName = subDomain[subDomain.length-1];
		}
	}
}



