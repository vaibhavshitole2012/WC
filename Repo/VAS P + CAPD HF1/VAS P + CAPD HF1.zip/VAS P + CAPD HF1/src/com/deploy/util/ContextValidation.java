package com.deploy.util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.ExtendedProperties;
import org.apache.log4j.Logger;

import com.ibm.icu.util.GregorianCalendar;

import ext.kb.util.KBConstants;
import wt.admin.AdministrativeDomain;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.folder.SubFolder;
import wt.folder.SubFolderReference;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.org.WTOrganization;
import wt.pdmlink.PDMLinkProduct;
import wt.pds.StatementSpec;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;
import wt.util.WTProperties;

public class ContextValidation implements RemoteAccess  {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = Logger.getLogger(ContextValidation.class);

	/** The Constant USERNAME_ARG. */
	private static final String USERNAME_ARG = "-u";

	/** The Constant PASSWORD_ARG. */
	private static final String PASSWORD_ARG = "-p";
	
	/** Name of the class. */
	private static final String CLASSNAME = ContextValidation.class.getName();
	
	private static final String SAMPLE_USAGE = 
			"\n Sample usage: windchill com.deploy.util.ContainerTemplateUpdater -u $username -p $password";

	private static RemoteMethodServer rms = RemoteMethodServer.getDefault();
	
	@SuppressWarnings("rawtypes")
	public static void main(String[] args) {
		int argsLength = args.length;
		String username = "";
		String password = "";

		if (argsLength == 0) {
			System.out.println("\nNo arguments passed!");
			System.out.println(SAMPLE_USAGE);
			System.exit(1);
		}

		for (int i = 0; i < argsLength; i++) {
			if (args[i].equals(USERNAME_ARG)) {
				if (++i < argsLength) {
					username = args[i];
				} else {
					System.out.println("\nNo username passed!");
					System.out.println(SAMPLE_USAGE);
					System.exit(1);
				}
			} else if (args[i].equals(PASSWORD_ARG)) {
				if (++i < argsLength) {
					password = args[i];
				} else {
					System.out.println("\nNo password passed!");
					System.out.println(SAMPLE_USAGE);
					System.exit(1);
				}}}
		if (username != null && !username.equals("")) {
			rms.setUserName(username);
			if (password != null) {
				rms.setPassword(password);
			}
		}
	
		try {
			Class[] argTypes = {};
			Object[] arg = {};
			rms.invoke("validateFolderStructureAndDomain", CLASSNAME, null, argTypes, arg);
			System.out.println("-> Folder Structure and Domain Validated!");
		} catch (RemoteException | InvocationTargetException e) {
			LOGGER.error("Error validating folder structure and domain!");
			e.printStackTrace();
		}
		System.exit(0);
		
	}
	
	public static void validateFolderStructureAndDomain() throws WTException, IOException{
		System.out.println("================================================================================");
		System.out.println("Starting Validate folder structure and domain tool");
		System.out.println("================================================================================");
		List<PDMLinkProduct> kbProducts = getKBProducts();
		validateFolders(kbProducts);
		System.out.println("================================================================================");
		System.out.println("Validation Ends.");
		System.out.println("================================================================================");
	}
	
	public static List<PDMLinkProduct> getKBProducts() throws WTException{
		
		List<PDMLinkProduct> products = new ArrayList<>();
		QuerySpec qs = new QuerySpec();
		int pdmLinkProduct = qs.appendClassList(PDMLinkProduct.class, true);
		int organization = qs.appendClassList(WTOrganization.class, true);
		
		SearchCondition joinPDMLinkProductWithOrgContainer = 
				new SearchCondition(PDMLinkProduct.class, "organizationReference.key.id", WTOrganization.class, "thePersistInfo.theObjectIdentifier.id");
		SearchCondition orgByName = new SearchCondition(WTOrganization.class, "name", SearchCondition.EQUAL, KBConstants.KB);
		
		qs.appendWhere(joinPDMLinkProductWithOrgContainer, new int[]{pdmLinkProduct, organization});
		qs.appendAnd();
		qs.appendWhere(orgByName, new int[]{organization});
		
		QueryResult qr = PersistenceHelper.manager.find((StatementSpec)qs);
	
		while(qr.hasMoreElements()){
				Persistable[] product = (Persistable[])qr.nextElement();
				if(product.length == 2){
				PDMLinkProduct p=(PDMLinkProduct)product[0];
					if(!products.contains(p)){
						products.add(p);
					
				}
			}
		}
	
		return products;
	}
	
	
	public static QueryResult queryFoldersAndDomainsFromKBProduct(String productName) throws WTException{
		
		QuerySpec qs = new QuerySpec();
		int pdmLinkProduct = qs.appendClassList(PDMLinkProduct.class, true);
		int subFolder = qs.appendClassList(SubFolder.class, true);
		int administrativeDomain = qs.appendClassList(AdministrativeDomain.class, true);
		
		SearchCondition joinSubFolderWithPDMLinkProduct = 
				new SearchCondition(SubFolder.class, "containerReference.key.id", PDMLinkProduct.class, "thePersistInfo.theObjectIdentifier.id");
		SearchCondition joinSubFolderWithDomain = 
				new SearchCondition(SubFolder.class, "domainRef.key.id", AdministrativeDomain.class, "thePersistInfo.theObjectIdentifier.id");
		SearchCondition productByName = new SearchCondition(PDMLinkProduct.class, PDMLinkProduct.NAME, SearchCondition.EQUAL, productName);
		
		qs.appendWhere(joinSubFolderWithPDMLinkProduct, new int[]{subFolder, pdmLinkProduct});
		qs.appendAnd();
		qs.appendWhere(joinSubFolderWithDomain, new int[]{subFolder, administrativeDomain});
		qs.appendAnd();
		qs.appendWhere(productByName, new int[pdmLinkProduct]);
		
		return PersistenceHelper.manager.find((StatementSpec)qs);
	}
	
	
	public static void validateFolders(List<PDMLinkProduct> productList) throws WTException, IOException{
		
		Date time = new GregorianCalendar().getTime();
		File file = createFileForProductsWithIssue("/opt/ptc/wt111/windchill/temp/ContextValidation - " + time.getTime() +".txt" );
		BufferedWriter writer = new BufferedWriter(new FileWriter(file));
		
		
		HashMap<String, String> foldersConfigurationForDomains = getFoldersConfiguration("ext.kb.folders.map.name.and.domain.");
		HashMap<String, String> foldersConfigurationForFolderStructure = getFoldersConfiguration("ext.kb.folders.map.name.and.parent.name.");
			
		for(PDMLinkProduct product : productList){
			Map<String, String> folderAndDomainMap= new HashMap<>();
			Map<String, String> folderAndParentFolderMap= new HashMap<>();
			String productName = product.getName();
			QueryResult qr = queryFoldersAndDomainsFromKBProduct(productName);
			while(qr.hasMoreElements()){
					Persistable[] nextElement = (Persistable[])qr.nextElement();
					SubFolder folder = (SubFolder)nextElement[1];
					SubFolderReference parentFolder = folder.getParentFolder();
					AdministrativeDomain domain = (AdministrativeDomain)nextElement[2];
					if(!folder.getName().equals("Reports") && !folder.getName().equals("ChangeMonitor") && !folder.getName().equals("Custom")){
					if(parentFolder.getName() == null){
						folderAndParentFolderMap.put(folder.getName(), "Default");
						folderAndDomainMap.put(folder.getName(), domain.getName());
					}else{
						folderAndDomainMap.put(folder.getName() + " " +  parentFolder.getName(), domain.getName());
						folderAndParentFolderMap.put(folder.getName() + " " +  parentFolder.getName(), parentFolder.getName());
					}
					}
			}
			if(foldersConfigurationForFolderStructure.equals(folderAndParentFolderMap) && foldersConfigurationForDomains.equals(folderAndDomainMap)){
				writer.append(productName + " - OK DOMAIN AND FOLDER STRUCTURE");
				writer.newLine();
			}else if(!foldersConfigurationForFolderStructure.equals(folderAndParentFolderMap) && foldersConfigurationForDomains.equals(folderAndDomainMap)){
				writer.append(productName + " - Bad Folder Structure");
				writer.newLine();
			}else if(foldersConfigurationForFolderStructure.equals(folderAndParentFolderMap) && !foldersConfigurationForDomains.equals(folderAndDomainMap)){
				writer.append(productName + " - Bad Domain");
				writer.newLine();
			}else{
				writer.append(productName + " - Bad Folder Structure and Domain");
				writer.newLine();
			}		
		}
		writer.close();
	}
	

	private static HashMap<String, String> getFoldersConfiguration(String propertyName) {
		WTProperties serverProps = null;
		try {
			serverProps = WTProperties.getServerProperties();
		} catch (IOException e) {
			e.printStackTrace();
		}
		Iterator<String> it = getFolderMapIterator(serverProps, propertyName);
		HashMap<String, String> folderConfiguration = new HashMap<String, String>();
		System.out.println("================================================================================");
		System.out.println("Folders configuration:");
		while (it != null && it.hasNext()) {
			String saveAsAttribResetPropKey = it.next();
			String saveAsResetProp = (String) serverProps.getProperty(saveAsAttribResetPropKey);
			String[] tokenizer = saveAsResetProp.split(",", -1);
			String folderName;
			String domain;
			folderName = tokenizer[0];
			domain = tokenizer[1];
			folderConfiguration.put(folderName, domain);
			System.out.println("Folder: " + folderName + " with domain: " + domain);
		}
		System.out.println("================================================================================");
		return folderConfiguration;
	}
	
	private static Iterator<String> getFolderMapIterator(WTProperties serverProps, String propertyName) {
		ExtendedProperties extendedProps = ExtendedProperties.convertProperties(serverProps);
		return extendedProps.getKeys(propertyName);
	}

	public static File createFileForProductsWithIssue(String filePath){
		File file = new File(filePath);
		if (!file.exists()) {
			try {
				file.createNewFile();
			} catch (IOException e) {
				LOGGER.error("Error with creating file", e);
			}
		}
		return file;
	}
	
}
