package com.deploy.util;

import wt.util.resource.RBComment;
import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("com.deploy.util.utilResource")
public class utilResource extends WTListResourceBundle {

    @RBEntry("There was error while reading windchill property {0}.")
    @RBComment("This string is used as the error message when property can't be read")
    public static final String IOEXCEPTION_WHILE_READING_PROPERTY = "IOEXCEPTION_WHILE_READING_PROPERTY";

}
