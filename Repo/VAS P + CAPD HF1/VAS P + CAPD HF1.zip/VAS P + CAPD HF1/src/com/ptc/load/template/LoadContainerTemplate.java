/*
 *
 * Copyright (c) 2011 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 *
 * LoadContainerTemplate.java
 *	
 * Definition: This loader is designed to load a container template, replacing the
 * 		business xml file if the template already exists and iterating the template
 *	
 * Created By: Bill Cowger
 * Created Date: 6/24/2011
 *
 * Revision: 
 * Revised By: 
 * Revision Date: 
 * Revisions: 
 *
 * Uniontown Solution Center
 * 
 */

package com.ptc.ssp.load.template;

import com.ptc.ssp.load.LoadHelper;

import java.io.File;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Vector;

import org.apache.log4j.Logger;

import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.inf.container.WTContainerRef;
import wt.inf.container.WTContainerTemplateRef;
import wt.inf.template.ContainerTemplateHelper;
import wt.inf.template.DefaultWTContainerTemplate;
import wt.inf.template.UploadTemplateRequest;
import wt.inf.template.WTContainerTemplateMaster;
import wt.load.LoadServerHelper;
import wt.log4j.LogR;
import wt.util.WTException;
import wt.util.WTProperties;
import wt.util.WTPropertyVetoException;
import wt.vc.wip.WorkInProgressException;
import wt.vc.wip.WorkInProgressHelper;

public class LoadContainerTemplate{
	private static Logger logger = null;
		
	/**
	 * Get the logger for this class
	 */
	static{
		try{
			logger = LogR.getLogger("com.ptc.ssp.load");
		}catch(Throwable t){
			System.out.println("Error loading logging resource");
			t.printStackTrace();
			throw new ExceptionInInitializerError(t);
		}
	}
	
	
	/**
	 * private constructor 
	 */
	LoadContainerTemplate () {
		
	}
	
	/**
	 * Method to create a container template
	 * If the template already exists on this container it will be overridden as a new iteration
	 *
	 * @return boolean value containing whether or not the import was successful
	 */
	public static boolean createContainerTemplate(Hashtable<?,?> nv, Hashtable<?,?> cmd_line, Vector<?> return_objects){
		try{			
			// Get values from the input file
			String name = LoadServerHelper.getValue("name", nv, cmd_line, LoadServerHelper.REQUIRED);
			String xmlPath = LoadServerHelper.getValue("xmlPath", nv, cmd_line, LoadServerHelper.REQUIRED);
			String container = LoadServerHelper.getValue("containerClassName", nv, cmd_line, LoadServerHelper.REQUIRED);
			String overwriteStr = LoadServerHelper.getValue("overwrite", nv, cmd_line, LoadServerHelper.NOT_REQUIRED);
			
			// If overwrite is not specified make overwrite=true the default action
			if(overwriteStr == null || "".equals(overwriteStr.trim())){
				overwriteStr = "true";
			}
			
			boolean overwrite = new Boolean(overwriteStr).booleanValue(); // Flag to whether or not to overwrite an existing template
			boolean success = false; // Flag to set whether to commit or roll back the transaction.
			// success flag is false because there is no need to commit unless a template is created, which sets this flag to true if it succeeds
			
			logger.debug("Overwrite flag: " + overwrite);
			
			// Create a where clause and see if the template already exists
			Vector<String> where = new Vector<>();
			where.add("name='" + name + "'");
			where.add("containerClassName='" + container + "'");
			
			Persistable p = LoadHelper.queryForObject("wt.inf.template.WTContainerTemplateMaster", where);
			
			// If the template already exists deal with it
			if (p instanceof WTContainerTemplateMaster){
				// If overwrite is enabled delete the existing template
				if(overwrite){
					logger.info("Replacing Business XML");
					WTContainerTemplateMaster master = (WTContainerTemplateMaster)p;
					DefaultWTContainerTemplate template = (DefaultWTContainerTemplate)ContainerTemplateHelper.service.getContainerTemplateRef(master).getTemplate();
					success = updateTemplate(template, xmlPath) ;
				}else{  // Overwrite is disabled, output a message and set the return flag to true to indicate a successful load
					logger.warn("Existing template found and update is set to false.  No content changes were made!!!");
					success = true;
				}
			}else{
				logger.info("Passing the work to the OOTB loader");
				success = wt.inf.template.LoadContainerTemplate.createContainerTemplate(nv, cmd_line, return_objects);
			}
			
			return success;
		}catch(WTException wte){
			wte.printStackTrace();
			logger.fatal("Error updating container template");
			return false;
		}
	}

	
	/**
	 * Updates the given container template with a new business xml file
	 *  
	 * @param template - The DefaultWTContainerTemplate to update
	 * @param xmlPath - Path to the new business xml file, relative to WT_HOME
	 * 
	 * @return boolean saying whether or not the update was successful
	 */
	private static boolean updateTemplate(DefaultWTContainerTemplate template, String xmlPath) {
		try {
			WTProperties props = WTProperties.getLocalProperties();
			File XMLFile = new File(props.getProperty("wt.home") + File.separator + "loadXMLFiles" + File.separator + xmlPath);
			
			// Make sure the xml file given exists and is readable
			if(!XMLFile.exists() || !XMLFile.canRead()){
				logger.fatal("File not found or cannot be read: " + XMLFile.getAbsolutePath());
				return false;  // Can't load a template that can't be read, return with failure
			}else{
				logger.debug("Content file is readable: " + XMLFile.getAbsolutePath());
			}

			// Get an upload request to the template content file and replace the old content with the new
			logger.info("Getting upload request and setting new business xml");
			UploadTemplateRequest req = ContainerTemplateHelper.service.getUploadRequest(XMLFile);
			DefaultWTContainerTemplate workingTemplate = (DefaultWTContainerTemplate)ContainerTemplateHelper.service.replaceBusinessXML(WTContainerTemplateRef.newWTContainerTemplateRef(template), req);
			
			// Check out the working copy of the template
			WorkInProgressHelper.service.checkout(workingTemplate, WorkInProgressHelper.service.getCheckoutFolder(), "EMB: Automatic delivery check out");

			// Check in the working copy of the template
			WorkInProgressHelper.service.checkin(workingTemplate, "EMB: Automatic delivery check in");
		} catch (WorkInProgressException e) {
			e.printStackTrace();
		} catch (WTPropertyVetoException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (WTException e) {
			e.printStackTrace();
		}
		
		logger.info("Container Template Update Complete");
		return true;
	}
	
	/**
	 * Sets the 'enabled' field of a container template to true
	 * 
	 * @param nv
	 * @param cmd_line
	 * @param return_objects
	 * 
	 * @return boolean value containing whether or not the import was successful
	 */
	public static boolean enableTemplate(Hashtable<?,?> nv, Hashtable<?,?> cmd_line, Vector<?> return_objects){
		return processTemplate(nv, cmd_line, return_objects, true);
	}
	
	/**
	 * Sets the 'enabled' field of a container template to false
	 * 
	 * @param nv
	 * @param cmd_line
	 * @param return_objects
	 * 
	 * @return boolean value containing whether or not the import was successful
	 */
	public static boolean disableTemplate(Hashtable<?,?> nv, Hashtable<?,?> cmd_line, Vector<?> return_objects){
		return processTemplate(nv, cmd_line, return_objects, false);
	}
	
	/**
	 * Sets the 'enabled' field of a container template to the value passed in
	 * 
	 * @param nv
	 * @param cmd_line
	 * @param return_objects
	 * @param enable
	 * 
	 * @return boolean value containing whether or not the import was successful
	 */
	private static boolean processTemplate(Hashtable<?,?> nv, Hashtable<?,?> cmd_line, Vector<?> return_objects, boolean enable){
		boolean retVal = false;
		
		try {
			String name = LoadServerHelper.getValue("name", nv, cmd_line, LoadServerHelper.REQUIRED);
			WTContainerRef container = LoadServerHelper.getTargetContainer(cmd_line);
			QueryResult qr = ContainerTemplateHelper.service.getAllTemplateMasters(container);
			DefaultWTContainerTemplate template = null;
			
			// Check all templates in the CONT_PATH for one that matches the given name
			if(qr != null){
				while(qr.hasMoreElements()){
					Object o = qr.nextElement();
					logger.debug("Object Found: " + o.toString());
					template = ((WTContainerTemplateMaster)o).getContainerTemplate();
					if(name.equalsIgnoreCase(template.getName())){
						break;
					}
				}
			}
			// If a template was found set the Enabled field and save
			if(template != null){
				logger.debug("Found Template");
				template.setEnabled(enable);
				PersistenceHelper.manager.save(template.getMaster());
				template = (DefaultWTContainerTemplate)PersistenceHelper.manager.refresh(template);
				retVal = true;
			}else{
				logger.error("Template " + name + " not found in container " + container.getName());
			}
		} catch (WTException e) {
			e.printStackTrace();
		} catch (WTPropertyVetoException e) {
			e.printStackTrace();
		}
		
		return retVal;
	}
}