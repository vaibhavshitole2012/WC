package com.ptc;

import wt.access.AccessControlled;
import wt.access.PolicyAccessControlled;
import wt.fc.WTObject;
import wt.inf.container.WTContained;
import wt.type.TypeManaged;
import wt.util.WTException;

import com.ptc.windchill.annotations.metadata.ColumnProperties;
import com.ptc.windchill.annotations.metadata.GenAsPersistable;
import com.ptc.windchill.annotations.metadata.GeneratedProperty;
import com.ptc.windchill.annotations.metadata.PropertyConstraints;

@GenAsPersistable(superClass=WTObject.class,interfaces={AccessControlled.class,PolicyAccessControlled.class,WTContained.class,TypeManaged.class},
properties={
//    @GeneratedProperty(name="keyOrder", type=Integer.class, columnProperties=@ColumnProperties(index=true),constraints=@PropertyConstraints(required=true)),
    @GeneratedProperty(name="sourceLanguage", type=String.class, columnProperties=@ColumnProperties(unique=true),constraints=@PropertyConstraints(required=true)),
    @GeneratedProperty(name="english", type=String.class),
    @GeneratedProperty(name="german", type=String.class),
    @GeneratedProperty(name="french", type=String.class),
    @GeneratedProperty(name="italian", type=String.class),
    @GeneratedProperty(name="spanish", type=String.class),
    @GeneratedProperty(name="portuguese", type=String.class),
    @GeneratedProperty(name="chinese", type=String.class),
    @GeneratedProperty(name="selectable", type=Boolean.class, constraints=@PropertyConstraints(required=true))
}
)

public class KBNameCatalogueEntry extends _KBNameCatalogueEntry{

    static final long serialVersionUID = 1;

    public static KBNameCatalogueEntry newCatalogueEntry() throws WTException{
        final KBNameCatalogueEntry instance = new KBNameCatalogueEntry();
        instance.initialize();
        return instance;
    }
    
}
