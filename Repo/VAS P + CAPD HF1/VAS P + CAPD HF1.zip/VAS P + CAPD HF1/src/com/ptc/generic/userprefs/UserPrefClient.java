/* bcwti
 * 
 * Copyright (c) 2010 Parametric Technology Corporation (PTC). All Rights
 * Reserved.
 * 
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 * 
 * ecwti
 */
package com.ptc.generic.userprefs;

import com.ptc.generic.userprefs.UserPrefsService;

import wt.preference.PreferenceClient;

/**
 * Supported preference clients
 * @author Marek Piechut
 */
public enum UserPrefClient {

    /**
     * General windchill preference - it will be visible and editable in
     * Windchill OOTB preference manager
     */
    WINDCHILL(PreferenceClient.WINDCHILL_CLIENT_NAME),
    /**
     * ECA client preference. It will be invisible in OOTB preference manager
     */
    ECA(UserPrefsService.ECA_CLIENT_NAME);
    /**
     *  Windchill client name to use in queries
     */
    private final String clientName;

    private UserPrefClient(String client) {
        this.clientName = client;
    }

    /**
     * Get Windchill client name to use in queries
     * @return
     */
    public String getClientName() {
        return clientName;
    }
}
