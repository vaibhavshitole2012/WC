/* bcwti
 *
 * Copyright (c) 2008 Parametric Technology Corporation (PTC). All Rights
 * Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */
package com.ptc.generic.netmarkets;


import java.net.URL;
import java.util.*;

import wt.fc.*;
import wt.httpgw.*;
import wt.query.template.URLGenerator;
import wt.services.StandardManager;
import wt.session.*;
import wt.util.WTContext;
import wt.util.WTException;
import wt.vc.*;

import org.apache.log4j.Logger;

import com.ptc.generic.netmarkets.NetmarketsService;
import com.ptc.netmarkets.util.misc.NmAction;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import com.ptc.netmarkets.util.misc.NmActionServiceHelper;
import com.ptc.service.annotations.GenerateService;
import com.ptc.core.ui.validation.UIValidationCriteria;
import com.ptc.generic.FcHelper;
import com.ptc.netmarkets.model.NmObjectHelper;


/**
 *
 * <p>
 * Use the <code>newStandardNetmarketsService</code> static factory method(s),
 * not the <code>StandardNetmarketsService</code> constructor, to construct
 * instances of this class.  Instances must be constructed using the static
 * factory(s), in order to ensure proper initialization of the instance.
 * <p>
 *
 *
 * @version   1.0
 **/
@GenerateService
public class StandardNetmarketsService extends StandardManager implements NetmarketsService {

    private static final String OID_URL_PREFIX = "OR:";
	private static final String RESOURCE = "com.ptc.generic.netmarkets.netmarketsResource";
    private static final String CLASSNAME = StandardNetmarketsService.class.getName();
    private static final ReferenceFactory RF = new ReferenceFactory();
    private static final URLFactory UF;
    private static final Logger logger = Logger.getLogger(StandardNetmarketsService.class);

    static {
        URLFactory uRLFactory = null;
        try {
            uRLFactory = new URLFactory();
        } catch (WTException ex) {
            logger.fatal("URL factory was not initialized! Some methods may fail!");
        } finally {
            UF = uRLFactory;
        }
    }

    /**
     * Default factory for the class.
     *
     * @return    StandardNetmarketsService
     * @exception wt.util.WTException
     **/
    public static StandardNetmarketsService newStandardNetmarketsService()
            throws WTException {

        StandardNetmarketsService instance = new StandardNetmarketsService();
        instance.initialize();
        return instance;
    }

    /**
     * Get URL that will open part info page on 3'rd level navigation selected
     * according to passed action object type and name.
     *
     * @param     oid  Has to represent Iterated persistable
     * @param     actionType
     * @param     actionName
     * @param     useLatest
     * @return    URL
     * @exception wt.util.WTException
     **/
    public URL getInfoPageActionURL(String oid, String actionType, String actionName, boolean useLatest)
            throws WTException {
        // <editor-fold defaultstate="collapsed" desc="Logging">
        if (logger.isInfoEnabled()) {
            StringBuilder sb = new StringBuilder("Retrieving URL for action: ");
            sb.append(actionName);
            sb.append(" type: ");
            sb.append(actionType);
            sb.append(" useLatest: ");
            sb.append(useLatest);
            sb.append(" OID: ");
            sb.append(oid);

            logger.info(sb);
        }// </editor-fold>
        URL url = null;
        Persistable object = FcHelper.convertToPersistable(oid);

        if (object instanceof Iterated && useLatest) {
            logger.debug("Using latest iteration");
            object = VersionControlHelper.getLatestIteration((Iterated)object, false);
        }

        ObjectIdentifier obid = object.getPersistInfo().getObjectIdentifier();
        String infoUrl = URLGenerator.buildInfoPageURL(obid.getClassname(), Long.toString(obid.getId()), true);

        HashMap<String, String> params = new HashMap<String, String>();

        if (actionType != null && actionName != null) {
            params.put(NmAction.TLN_TYPE, actionType);
            params.put(NmAction.TLN_ACTION, actionName);
        }

        try {
            infoUrl = new URLFactory().getHREF(infoUrl, params);
            url = new URL(infoUrl);
        } catch (Exception ex) {
            logger.error("Could not create URL for action: " + actionName + " type: " + actionType + " oid: " + obid, ex);
            throw new WTException(ex);
        }

        // <editor-fold defaultstate="collapsed" desc="Logging">
        if (logger.isDebugEnabled()) {
            logger.debug("Generated URL: " + url.toExternalForm());
        }// </editor-fold>
        return url;
    }

    /**
     * Generate URL to passed oid object info page
     *
     * @param     oid
     * @param     useLatest  use latest iteration of object
     * @return    URL
     * @exception wt.util.WTException
     **/
    public URL getInfoPageURL(String oid, boolean useLatest)
            throws WTException {

        URL url = getInfoPageActionURL(oid, null, null, useLatest);

        return url;
    }

    /**
     * Get URL to Wizard that is used to render passed in action. It will
     * return direct jsp URL with object oid, container oid, wizard class
     * and method added to URL.
     *
     * @param     oid  Has to represent Iterated and WTContained persistable
     * @param     actionType
     * @param     actionName
     * @param     useLatest
     * @return    URL
     * @exception wt.util.WTException
     **/
    public URL getDirectWizardURL(String oid, String actionType, String actionName, boolean useLatest)
            throws WTException {
        return getDirectWizardURL(oid, actionType, actionName, useLatest, new HashMap(0));
    }

    /**
     * Get URL to Wizard that is used to render passed in action. It will
     * return direct jsp URL with object oid, container oid, wizard class
     * and method added to URL. Addtionally it returns parameters and values
     * pair put into params Map.
     *
     *     @param     oid  Has to represent Iterated and WTContained persistable
     *     @param     actionType object type name from action model
     *     @param     actionName action name from action model
     *     @param     useLatest
     *     @param addtionalParams addtional params added to url
     *     @return      URL
     *     @exception wt.util.WTException
     *
     **/
    public URL getDirectWizardURL(String oid, String actionType, String actionName, boolean useLatest, Map<String, String> addtionalParams)
            throws WTException {
        if (logger.isInfoEnabled()) {
            logger.info("Generating direct Wizard URL for: " + oid + " action type: " + actionType + " action name: " + actionName + " use latest: " + useLatest);
        }

        Iterated object = (Iterated) RF.getReference(oid).getObject();
        if (useLatest) {
            logger.debug("Using latest iteration");
            object = VersionControlHelper.getLatestIteration(object, false);
        }

        URL url = null;

        ObjectIdentifier obid = object.getPersistInfo().getObjectIdentifier();
        NmAction action = NmActionServiceHelper.getAction(actionType, actionName, SessionHelper.getLocale());
        action.setContextObject(new NmOid(obid));
        if (action != null) {
            HashMap<String, String> params = new HashMap<String, String>(addtionalParams);
            // VW_ECA-153 : hide parameters oid and containerOid
            // add parameters portlet and refreshParent
            if (!actionName.equals(NMActionConstants.ACTIONNAME_VW_ECA_CREATE_THEOTEIL_WIZARD) && !actionName.equals(NMActionConstants.ACTIONNAME_VW_ECA_PARTUSAGE)) {
                params.put("oid", RF.getReferenceString(object));
            }
//           WTContainer container = ((WTContained) object).getContainer();
//           if (container != null) {
//               params.put("ContainerOid", RF.getReferenceString(container));
//           }
            String actionClass = action.getActionClass();
            String actionMethod = action.getActionMethod();

            params.put("wizardActionClass", actionClass);
            params.put("wizardActionMethod", actionMethod);
            params.put("portlet", "poppedup");
            params.put("refreshParent", "false");


            url = UF.getURL(action.getWizardUrl().toString(), params);
        }
        if (logger.isDebugEnabled()) {
            logger.debug("Generated URL: " + url.toExternalForm());
        }
        return url;
    }
    
    /**
     * Based on the provided oid (full oid, like 'wt.part.WTPart:11111'), this method 
     * creates and returns the full windchill URL. To open a this page from the applet,
     * you may invoke this: WTContext.getContext().showDocument(___URLfromthismethod____, "_blank");
     * 
     */
    public URL createUrlToInfoPageOfObject(String oid) throws WTException {
    	
    	if (oid == null) {
    		logger.error("provided OID is null, will return null too");
    		return null;
    	}
    	
    	HashMap<Object, Object> params = new HashMap<Object, Object>();

    	// in Windchill 10.1 we need this OR: prefix before the oid. Hence, attach it if necessary
    	if (!oid.startsWith(OID_URL_PREFIX)) {
    		oid = OID_URL_PREFIX + oid;
    	}
    	
		params.put("oid", oid);
		params.put("refreshParent", "false");
		
		String viewActionBaseUrl = NmActionServiceHelper.service.getAction("object", "view").getUrl();
	
		URLFactory urlFactory = new URLFactory();
		String infoPageUrlString = urlFactory.getHREF(viewActionBaseUrl, params, true);
    	URL infoPageUrl = urlFactory.getURL(infoPageUrlString);

    	return infoPageUrl;
    }

    public Object getSessionValue(NmCommandBean commandBean, String context, String attribute) {
        Map sessionContext = getSessionContext(commandBean, context);
        Object value = sessionContext.get(attribute);
        return value;
    }

    public Object getSessionValue(UIValidationCriteria criteria, String context, String attribute) {
        Map sessionContext = getSessionContext(criteria, context);
        Object value = sessionContext.get(attribute);
        return value;
    }

    public void putSessionValue(NmCommandBean commandBean, String context, String name, Object value) {
        Map sessionContext = getSessionContext(commandBean, context);
        sessionContext.put(name, value);
    }

    public void putSessionValue(UIValidationCriteria criteria, String context, String name, Object value) {
        Map sessionContext = getSessionContext(criteria, context);
        sessionContext.put(name, value);
    }

    private SessionContext getSessionContext(NmCommandBean commandBean, String context) {
        String sessionId = getSessionID(commandBean);
        SessionContext sessionContext = SessionContext.getContext(context, sessionId);
        return sessionContext;
    }

    private SessionContext getSessionContext(UIValidationCriteria criteria, String context) {
        String sessionId = getSessionID(criteria);
        SessionContext sessionContext = SessionContext.getContext(context, sessionId);
        return sessionContext;
    }

    private String getSessionID(NmCommandBean commandBean) {
        Map cgiData = (Map) commandBean.getMap().get(NmObjectHelper.CGI_DATA);
        String sessionId = (String) cgiData.get(CGIConstants.CGI_SERVLET_SESSION);
        return sessionId;
    }

    private String getSessionID(UIValidationCriteria criteria) {
        Map cgiData = (Map) criteria.getFormData().get(NmObjectHelper.CGI_DATA);
        String sessionId = (String) cgiData.get(CGIConstants.CGI_SERVLET_SESSION);
        return sessionId;
    }
}
