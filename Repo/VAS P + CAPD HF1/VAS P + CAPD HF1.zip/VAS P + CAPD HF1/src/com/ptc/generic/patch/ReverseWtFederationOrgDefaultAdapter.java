/* 
 * bcwti
 *
 * Copyright (c) 2012 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */
/**
 * 
 */
package com.ptc.generic.patch;

import java.util.ArrayList;
import java.util.StringTokenizer;

/**
 * @author Benjamin Mueller (bmueller@ptc.com)
 * @version 20140516
 * @see VW_ECA-17941
 * @since 5.0
 * 
 * Tool to reverse the value of wt.federation.org.defaultAdapter.
 * Used for on the fly Ldap entry replacement.
 */
public class ReverseWtFederationOrgDefaultAdapter {

	public static final String svnRev = "$Revision: 1.1.1.3 $ $Date: 2015/12/10 21:01:36IST $";
	public static final String svnUrl = "$URL: http://127.0.0.1/svn/KB_04082016/components/Generic-Utilities/src/com/ptc/generic/patch/ReverseWtFederationOrgDefaultAdapter.java $";

	/**
	 * 
	 */
	private ReverseWtFederationOrgDefaultAdapter() {
	}

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(final String[] args) throws Exception {
		
		if (args == null) {
			throw new Exception("argument was null!");
		}
		
		if (args.length != 1) {
			throw new Exception("Illegal number of arguments!");
		}
		
		if (!args[0].contains(".")) {
			throw new Exception("Illegal argument!");
		}
		
		final ArrayList<String> segments = new ArrayList<String>();
		
		// expected is something like vwg.vw.wob.Ldap
		final StringTokenizer st = new StringTokenizer(args[0], ".");
		while (st.hasMoreElements()) {
			segments.add(st.nextToken());
		}
		
		// needed result is something like Ldap.wob.vw.vwg
		final StringBuffer sb = new StringBuffer();
		for (int i = segments.size() - 1; i > 0; --i) {
			sb.append(segments.get(i));
			sb.append(".");
		}
		sb.append(segments.get(0));
		
		System.out.println(sb.toString());		
	}
}
