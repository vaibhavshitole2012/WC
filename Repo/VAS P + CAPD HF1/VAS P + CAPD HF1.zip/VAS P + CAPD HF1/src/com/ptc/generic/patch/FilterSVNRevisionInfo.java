/* 
 * bcwti
 *
 * Copyright (c) 2012 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */
/**
 * 
 */
package com.ptc.generic.patch;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.Charset;

/**
 * @author Benjamin Mueller (bmueller@ptc.com)
 * @version 20140530
 * @see VW_ECA-18345
 * @since 5.0
 * 
 * Tool to cleanup the revision infos
 */
public class FilterSVNRevisionInfo {

	public static final String svnRev = "$Revision: 1.1.1.3 $ $Date: 2015/12/10 21:01:36IST $";
	public static final String svnUrl = "$URL: http://127.0.0.1/svn/KB_04082016/components/Generic-Utilities/src/com/ptc/generic/patch/FilterSVNRevisionInfo.java $";

	private static final String FILENAMESTART = "Path: ";
	private static final String REVISIONSTART = "Revision: ";
	private static final String SEP = System.getProperty("line.separator");
	private static final Charset ENCODING = Charset.forName("cp1252");

	private FilterSVNRevisionInfo() {
	}

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		
		if (args == null || args.length != 1) {
			throw new IllegalArgumentException();
		}

		// read in the revision info file
		final StringBuffer sb = new StringBuffer();
		String currentLine = null;
		String currentFile = null;
		final BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(args[0]), ENCODING));

		while ((currentLine = br.readLine()) != null) {
			
			if (currentLine.startsWith(FILENAMESTART)) {
				currentFile = currentLine.substring(FILENAMESTART.length());
				currentFile = currentFile.replace("\\", "/");
			} else if (currentLine.startsWith(REVISIONSTART)) {
				sb.append(currentFile + " " + currentLine.substring(REVISIONSTART.length()));
				sb.append(SEP);
			}
		}
		br.close();

		// writing the cleaned revision infos
		final BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(args[0]), ENCODING));
		bw.write(sb.toString());
		bw.flush();
		bw.close();
	}
}
