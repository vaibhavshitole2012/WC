package com.ptc.generic.domain;


import java.util.Vector;

import wt.access.AccessPermission;
import wt.admin.AdminDomainRef;
import wt.admin.AdministrativeDomainHelper;
import wt.lifecycle.State;
import wt.org.WTPrincipal;
import wt.org.WTPrincipalReference;
import wt.util.WTContext;
import wt.util.WTException;

import com.ptc.core.domain.admin.common.impl.DomainAdministratorHelper;
import com.ptc.core.meta.common.IdentifierFactory;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.impl.LogicalIdentifierFactory;
import com.ptc.ssp.util.AuthenticationHelper;


/**
 * hardcoded tool to change the Access Rule for the Team object from Read to Full on root level
 * used for setting up VMWare images 
 *
 * @author lberger
 *
 * usage in Windchill Shell (cd to WT_HOME), must be executed as a Site Admin:
 * windchill com.ptc.generic.domain.ChangeDomainForTeamMain -u <user> -p <pwd>
 *
 * @deprecated better would be if we knew how the users get that access right. 
 * I don't think that at we've changed that rule on root level
 *  
 */
@Deprecated
public class ChangeDomainForTeamMain {
	
	public static final String svnRev = "$Revision: 1.1.1.3 $ $Date: 2015/12/10 21:01:36IST $";
	public static final String svnUrl = "$URL: http://127.0.0.1/svn/KB_04082016/components/Generic-Utilities/src/com/ptc/generic/domain/ChangeDomainForTeamMain.java $";
	
	private static IdentifierFactory identifierFactory = new LogicalIdentifierFactory();

	public static void main(String[] args) {
		@SuppressWarnings("rawtypes")
		Vector v = null;
		try {
			v = AuthenticationHelper.authenticateUser(args, true); //remove -u .. -p .. -url .. args
//			if(v==null || v.isEmpty()) {
//			}
			WTPrincipal user = (WTPrincipal)v.elementAt(0);
			System.out.println("authenticated as: " + user.getName());
		} catch (WTException w) {
			System.out.println("could not authenticate user. Exception:" + w.getLocalizedMessage());
			w.printStackTrace();
			System.exit(1);
		}

		// init WTContext and set locale
		WTContext.init(args);
//		System.out.println("remaining v.size=" + v.size() + " v=" + v);

		try {
			//set parameters
			AdminDomainRef domain_ref = AdministrativeDomainHelper.getGlobalDomainRef(AdministrativeDomainHelper.ROOT_DOMAIN); //'Site /'
			System.out.println("domain_ref=" + domain_ref + " dr.name=" + domain_ref.getName() + " dr.desc=" + domain_ref.getDescription());
			TypeIdentifier type_id = (TypeIdentifier)identifierFactory.get("WCTYPE|wt.team.Team");; //'WCTYPE|wt.team.Team'
			State state = null; //'All'
			WTPrincipalReference principal_ref = WTPrincipalReference.OWNER; //'OWNER'
			boolean all_except_principal = false; // false only for principal, true all except principal
			Vector<AccessPermission> grant_permissions = new Vector<AccessPermission>(); //Full Control (All)
			grant_permissions.add(AccessPermission.ALL);
			Vector<AccessPermission> deny_permissions = new Vector<AccessPermission>(); //empty
			Vector<AccessPermission> absolute_deny_permissions = new Vector<AccessPermission>(); //empty
			
			//change rule
			DomainAdministratorHelper.service.updateAccessControlRule(domain_ref, type_id, state, principal_ref, all_except_principal,
					grant_permissions, deny_permissions, absolute_deny_permissions);
			
		} catch (Exception w) {
			w.printStackTrace();
			System.exit(1);
		}
		System.exit(0);
	}
}