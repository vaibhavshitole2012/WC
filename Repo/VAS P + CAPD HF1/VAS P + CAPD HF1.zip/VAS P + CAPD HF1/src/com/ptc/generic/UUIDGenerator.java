/* bcwti
 * 
 * Copyright (c) 2011 Parametric Technology Corporation (PTC). All Rights
 * Reserved.
 * 
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 * 
 * ecwti
 */
package com.ptc.generic;

import java.net.InetAddress;
import java.security.SecureRandom;

/**
 *
 * This is a GUID generator that does not need a singleton
 * a database - can be safely pooled on a single machine and
 * deployed in a cluster to provide completely scalable
 * performance. Any GUID has a combination of the following four properties
 *
 * 1) is unique to the millisecond
 * 2) is unique to the machine
 * 3) is unique to the object creating it
 * 4) is unique to the method call for the same object
 *
 * The GUID can be represented as a 36-digit alphanumeric (including hyphens) of
 * the format xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx:
 *
 * 1) (1-8 hex characters) use the low 32 bits of
 * System.currentTimeMillis(). This gives us a uniqueness of a millisecond - therefore
 * any clashing object will have to be generated within the same
 * millisecond.
 *
 * 2) (9-16 hex characters) the IP address of the machine as a
 * hex representation of the 32 bit integer underlying IP - gives
 * us a spatial uniqueness to a single machine - guarantees that
 * these characters will be different for machines in a cluster
 * or on a LAN.
 *
 * 3) (17-24 hex characters) the hex value of the object's hashCode (a 32 bit int)
 * This removes the need for a singleton object as any
 * object uses its own hashCode.
 *
 * 4) (25-32 hex characters) a random 32 bit integer generated
 * for each method invocation from the SecureRandom java class
 * using SecureRandom.nextInt(). This method produces a
 * cryptographically strong pseudo-random integer.
 *
 * @author Steve Woodcock
 */
public class UUIDGenerator {

   private static final boolean USE_SHORT_UUIDS = true;
   private static final String  EMPTY           = "";

   // class variables used to cache some of the data
   private static SecureRandom  seeder;
   private static String        midValue;

   private void initialize() {

      // initalise the secure random instance
      seeder = new SecureRandom();

      // load up the randomizer first value
      int node = seeder.nextInt();

      try {

         // get the inet address
         InetAddress inet = InetAddress.getLocalHost();
         byte[] bytes = inet.getAddress();
         String hexInetAddress = hexFormat(getInt(bytes), 8);

         // get the hashcode
         String thisHashCode = hexFormat(System.identityHashCode(this), 8);

         // In order to speed up the method calls we can cache some infomation in the static initialization
         StringBuffer sb = new StringBuffer();
         sb.append("-");
         sb.append(hexInetAddress.substring(0, 4));
         sb.append("-");
         sb.append(hexInetAddress.substring(4));
         sb.append("-");
         sb.append(thisHashCode.substring(0, 4));
         sb.append("-");
         sb.append(thisHashCode.substring(4));
         midValue = sb.toString();

      } catch (Exception ex) {
         midValue = "-none-none-none-none";
      }
      if (USE_SHORT_UUIDS) // skip the constant part of the UUID
         midValue = EMPTY;
   }

   /**
    * Default Constructor.
    */
   public UUIDGenerator() {
      this.initialize();
   }

   /**
    * The actual method call to get the unique numbers is then very simple
    */
   public final String getUUID() {
      long timeNow = System.currentTimeMillis();
      int timeLow = (int) timeNow & 0xFFFFFFFF;
      int node = seeder.nextInt();
      return (hexFormat(timeLow, 8) + midValue + hexFormat(node, 8));
   }

   /**
    *
    * @param bytes
    * @return
    */
   private final int getInt(byte bytes[]) {
      int i = 0;
      int j = 24;
      for (int k = 0; j >= 0; k++) {
         int l = bytes[k] & 0xff;
         i += l << j;
         j -= 8;
      }
      return i;
   }

   /**
    *
    * @param i
    * @param j
    * @return
    */
   protected final String hexFormat(int i, int j) {
      String s = Integer.toHexString(i);
      return padHex(s, j) + s;
   }

   /**
    *
    * @param s
    * @param i
    * @return
    */
   private final String padHex(String s, int i) {
      StringBuffer stringbuffer = new StringBuffer();
      if (s.length() < i) {
         for (int j = 0; j < i - s.length(); j++)
            stringbuffer.append("0");
      }
      return stringbuffer.toString();
   }

   /**
    *
    * @param args
    */
   public static void main(String[] args) {
      UUIDGenerator uuidGenerator = new UUIDGenerator();
      for (int i = 0; i < 10; i++) {
         System.out.println("UUID[" + i + "] = \t" + uuidGenerator.getUUID());
      }
   }
}