package com.ptc.generic.performance;


import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.ptc.ssp.util.AuthenticationHelper;

import wt.doc.WTDocument;
import wt.fc.*;
import wt.jmx.core.Metrics;
import wt.method.*;
import wt.org.WTPrincipal;
import wt.part.WTPart;
import wt.query.QuerySpec;
import wt.util.*;


/**
 * tests if MCMetrics can be embedded into each other
 * 
 * usage in Windchill Shell:
 * windchill com.ptc.generic.performance.MCMetricsTest -u wcadmin -p wcadmin
 * 
 * @author lberger
 */
public class MCMetricsTest implements RemoteAccess {
	
	private static final Logger loggerOverall = Logger.getLogger(MCMetricsTest.class);
	private static final Logger loggerInner1 = Logger.getLogger(MCMetricsTest.class.getName() + "_INNER-1");
	private static final Logger loggerInner2 = Logger.getLogger(MCMetricsTest.class.getName() + "_INNER-2");
	
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			WTPrincipal user = AuthenticationHelper.authenticateUser(args);
			System.out.println("authenticated as: " + user.getName());
		} catch (WTException w) {
			System.out.println("could not authenticate user. Exception:" + w.getLocalizedMessage());
			w.printStackTrace();
			System.exit(1);
		}

		// init WTContext and set locale
		WTContext.init(args);

		try {
			if (RemoteMethodServer.ServerFlag) {
				execOnServer();
			} else {
				Class[]	argTypes = {};
				Object[] args2 = {};
				try {
					RemoteMethodServer.getDefault().invoke("execOnServer", MCMetricsTest.class.getName(), null, argTypes, args2 );
				} catch (RemoteException e) {
					throw new WTException(e);
				} catch (InvocationTargetException e) {
					throw new WTException(e);
				}
			}
	
		} catch (Exception w) {
			w.printStackTrace();
			System.exit(1);
		}
		
		System.exit(0);
	}
	
	public static void execOnServer() throws WTException {
		System.out.println("on server");
		
		//start overall metric
		loggerOverall.setLevel(Level.DEBUG);
		
		//start to measure spent CPU time and number of JDBC Calls
        Metrics metricsOverall = new MCMetrics("Overall");
        metricsOverall.start(loggerOverall);
        
        execInner1();
        
        execInner2();
        
		//stop measure and print out result
        metricsOverall.stop(loggerOverall, null);        
	}

	public static void execInner1() throws WTException {
		//start inner metric
		loggerInner1.setLevel(Level.DEBUG);
		//start to measure spent CPU time and number of JDBC Calls
        Metrics metricsInner1 = new MCMetrics("Inner-1");
        metricsInner1.start(loggerInner1);
        
        //do a query
        QuerySpec qs = new QuerySpec(WTPart.class);
        QueryResult qr = PersistenceHelper.manager.find(qs);
        System.out.println("found WTParts: " + qr.size());
        
		//stop measure and print out result
        metricsInner1.stop(loggerInner1, null);        
	}

	public static void execInner2() throws WTException {
		//start inner metric
		loggerInner2.setLevel(Level.DEBUG);
		//start to measure spent CPU time and number of JDBC Calls
        Metrics metricsInner2 = new MCMetrics("Inner-2");
        metricsInner2.start(loggerInner2);
        
        //do a query
        QuerySpec qs = new QuerySpec(WTDocument.class);
        QueryResult qr = PersistenceHelper.manager.find(qs);
        System.out.println("found WTDocuments: " + qr.size());
        
		//stop measure and print out result
        metricsInner2.stop(loggerInner2, null);        
	}

	}