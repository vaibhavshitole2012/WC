// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) definits fieldsfirst noctor 
// Source File Name:   TemplateProcessorFactory.java

/**
 * this class is used to find out more about how the factory methods for finding TPs, ADs, URLADs, FTDs work
 */
package com.ptc.generic;

import org.apache.log4j.*;
import wt.enterprise.*;
import wt.services.applicationcontext.*;
import wt.services.applicationcontext.implementation.UnableToLoadServiceProperties;
import wt.util.*;

/**
 * A class that helps finding problems in the factory of finding the correct TP/FTD/URLAD/AD for a given action/oid combination
 * @author lberger
 *
 */
public class VerboseFactory implements ApplicationContextChild {

	private static final String CLASSNAME = (VerboseFactory.class).getName();
	private static final Logger logger = Logger.getLogger(CLASSNAME);
	
	private ApplicationContext applicationContext = null;

	public VerboseFactory() throws UnableToLoadServiceProperties {
		applicationContext = ApplicationContextFactory.getDefaultApplicationContextServices();
	}

	public Object getServiceEntry(String type, String s, Object obj) throws WTException {
		logger.debug("Entering getServiceEntry()...");
		if (obj instanceof String)
			try {
				obj = Class.forName((String) obj);
			} catch (ClassNotFoundException classnotfoundexception) {
				classnotfoundexception.printStackTrace();
				throw new WTException(classnotfoundexception);
			}
		Object found = null;
		try {
			found = getApplicationContextServices().getService(this, obj, type, s);
		} catch (ServiceNotFoundException servicenotfoundexception) {
			servicenotfoundexception.printStackTrace();
		} catch (UnableToCreateServiceException unabletocreateserviceexception) {
			unabletocreateserviceexception.printStackTrace();
		}
		System.out.println(type + " for action=" + s + " and class=" + obj + " is:"); 
		System.out.println("  " + found);
		return found;
	}

	public ApplicationContextServices getApplicationContextServices() {
		return (ApplicationContextServices) applicationContext;
	}

	public ApplicationContext getApplicationContext() {
		return applicationContext;
	}

	public void setApplicationContext(ApplicationContext applicationcontext)
			throws WTPropertyVetoException {
		applicationContext = applicationcontext;
	}

	public static void main(String args[]) {
		try {
			VerboseFactory vf = new VerboseFactory();
			if(args!=null && args.length>=1) {
				String action=args[0];
				String className = "java.lang.Object"; //default
				if(args.length>=2) {
					className = args[1];
				}
				String type = "wt.enterprise.TemplateProcessor"; //default
				if(args.length>=3) {
					type = args[2];
				}
				vf.getServiceEntry(type, action, className);
			} else {
				// examples
				vf.getServiceEntry("wt.enterprise.TemplateProcessor", "UEBERGABEVB", "wt.part.WTProduct");
				vf.getServiceEntry("wt.enterprise.ActionDelegate", "GENERALPROPS", "java.lang.Object");
				vf.getServiceEntry("wt.enterprise.ActionDelegate", "GENERALPROPS", "wt.part.WTProduct");
				vf.getServiceEntry("wt.enterprise.URLActionDelegate", "GENERALPROPS", "java.lang.Object");
				vf.getServiceEntry("wt.templateutil.processor.FormTaskDelegate", "CreateEAProduct", "java.lang.Object");
				// this does not work for resources!
				// vf.getServiceEntry("wt.templateutil.DefaultHTMLTemplate",
				// "UEBERGABEVB", "wt.part.WTProduct");
				
				System.out.println("");
				System.out.println("java com.ptc.generic.VerboseFactory [action className] [service]");
				System.out.println("e.g. java com.ptc.generic.VerboseFactory ObjProps");
				System.out.println("  -> defaults: service=wt.enterprise.TemplateProcessor, class=java.lang.Object");
				System.out.println("  -> searches a wt.enterprise.TemplateProcessor for action=ObjProps and class=java.lang.Object");
				System.out.println("e.g. java com.ptc.generic.VerboseFactory ObjProps wt.part.WTPart");
				System.out.println("  -> defaults: service=wt.enterprise.TemplateProcessor");
				System.out.println("  -> searches a wt.enterprise.TemplateProcessor for action=ObjProps and class=wt.part.WTPart");
				System.out.println("e.g. java com.ptc.generic.VerboseFactory Create wt.part.WTPart wt.enterprise.ActionDelegate");
				System.out.println("  -> searches a wt.enterprise.ActionDelegate for action=Create and class=wt.part.WTPart");
				}
		} catch (Throwable t) {
			t.printStackTrace();
			System.exit(1);
		}
		System.exit(0);
	}
}
