package com.ptc.generic.infoengine;


import java.io.*;

import org.apache.log4j.Logger;

import com.infoengine.object.factory.Element;

public class ElementUtils {
   private static Logger logger = Logger.getLogger(ElementUtils.class);

   public static String getOid(Element element, String attribName, String classNameStart) {
      String ufid = element.getAtt(attribName).getValue().toString();
	if(ufid==null) {
	   return null;
	}
	if(logger.isDebugEnabled()) {
	   logger.debug("ufid=" + ufid);
	}
	if(ufid.startsWith(classNameStart)) {
	  ufid = ufid.substring(classNameStart.length(), ufid.indexOf(":", classNameStart.length()));
	} else {
	  ufid = ufid.substring(ufid.lastIndexOf("WCP")+4, ufid.lastIndexOf("|"));
	}
	String oid = classNameStart + ufid;
	if(logger.isDebugEnabled()) {
	   logger.debug("oid=" + oid);
	}
	return oid;
   }

   public static void dumpElement(Element element, Logger localLogger) {
	ByteArrayOutputStream obj_outbuf = new ByteArrayOutputStream();
      PrintWriter obj_printToStringBuf = new PrintWriter(obj_outbuf);
	element.toXML(obj_printToStringBuf, true);
	localLogger.debug(obj_outbuf.toString());
   }
}
