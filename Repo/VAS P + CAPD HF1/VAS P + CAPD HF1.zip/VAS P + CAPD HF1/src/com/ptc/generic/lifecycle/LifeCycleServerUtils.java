package com.ptc.generic.lifecycle;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.apache.log4j.Logger;

import wt.fc.ObjectIdentifier;
import wt.fc.ObjectReference;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.lifecycle.IteratedLifeCycleManaged;
import wt.lifecycle.LifeCycleHistory;
import wt.lifecycle.LifeCycleTemplate;
import wt.lifecycle.ObjectHistory;
import wt.part.WTPart;
import wt.pds.StatementSpec;
import wt.query.ArrayExpression;
import wt.query.ClassAttribute;
import wt.query.OrderBy;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.query.TableColumn;
import wt.util.WTAttributeNameIfc;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.util.WrappedTimestamp;
import wt.vc.Iterated;

import com.ptc.generic.query.QueryServerUtils;

public class LifeCycleServerUtils {
	

	private static final Logger logger = Logger.getLogger(LifeCycleServerUtils.class.getName());
	
	// these constants are needed for in-query sorting
	private static final String SORTBY_BRANCHID_ALIAS = "sortByBranchID";	
	private static final String SORTBY_IDA2A2_ALIAS = "sortByIDA2A2";	
	private static final String SORTBY_DATE_ALIAS = "sortByDate";
	
	private static final String COLUMN_NAME_BRANCH_IDITERATION_INFO = "branchIditerationInfo";
	private static final String ATTRIBUTE_NAME_ITERATION_INFO_BRANCH_ID = "iterationInfo.branchId";
	
	private static Map<IteratedLifeCycleManaged, Long> EMPTY_TIME_OF_LC_STATE_CHANGE_MAP = new HashMap<IteratedLifeCycleManaged, Long>();

	/**
	 * Obtains the date of the change of the Lifecycle state. Internally it is based on an OOTB LifeCycleHelper.getHistory method, 
	 * however this method operates on a set of the objects AND it does not retrieve whole LifecycleHistory objects,
	 * but only the necessary attributes.
	 * 
	 * @param iteratedList - list of objects implementing the Iterated interface (WTParts, WTDocuments...)
	 * @return - a map of object -> mod date of LC state change
	 * @throws WTException
	 */
	public static Map<IteratedLifeCycleManaged, Long> getTimeOfLCStateChange(List<IteratedLifeCycleManaged> iteratedList) throws WTException {
		
		// return an empty map when a null is passed
		if (iteratedList == null || iteratedList.isEmpty()) {
			return EMPTY_TIME_OF_LC_STATE_CHANGE_MAP;
		}
		
		// this map is used to match an object with its branchid
		Map<Long, IteratedLifeCycleManaged> branchIdToObjectMap = new HashMap<Long, IteratedLifeCycleManaged>();
		
		// this array is used in the query
		long[] branchIdsArray = new long[iteratedList.size()];
		for (int i = 0; i<iteratedList.size(); i++) {
			
			IteratedLifeCycleManaged iterated = iteratedList.get(i);
			Long branchId = iterated.getIterationInfo().getBranchId();
			
			branchIdsArray[i] = branchId;
			branchIdToObjectMap.put(branchId, iterated);
		}
		
		// query for all objects with one query
		QuerySpec qs = getTimeOfLCChangeCreateQuerySpec(branchIdsArray);
		
		QueryResult sortedResult = PersistenceHelper.manager.find((StatementSpec) qs);
		
		// get the newest modification dates for each object that was passed in
		Map<IteratedLifeCycleManaged, Long> timeOfLCStateChangeMap = createLCStateChangeMapFromSortedResultSet(sortedResult, branchIdToObjectMap);
		
		return timeOfLCStateChangeMap;
		
	}
	

	/**
	 * Loops over the pre-sorted result and obtains the newest modification date for each branch Id. 
	 * Afterwards matches the branch id to persistable object to create a persistable -> mod date map.
	 * 
	 * @param sortedResult - results of the query sorted by branchId - createstamp - ida2a2
	 * @param branchIdToObjectMap - used to match a branchid to an object that was passed in
	 * @return
	 */
	private static Map<IteratedLifeCycleManaged, Long> createLCStateChangeMapFromSortedResultSet(QueryResult sortedResult, Map<Long, IteratedLifeCycleManaged> branchIdToObjectMap) {
		Map<IteratedLifeCycleManaged, Long> timeOfLCStateChangeMap = new HashMap<IteratedLifeCycleManaged, Long>();
		
		Set<Long> setOfBranchIdForWhichModTimeWasFound = new TreeSet<Long>();
		
		while (sortedResult.hasMoreElements()) {
			Object[] resultRow = (Object[])sortedResult.nextElement();
			
			Long branchId = Long.parseLong(((BigDecimal) resultRow[0]).toString());
			
			// in the sorted results, for each branch ID the first result is the latest mod date
			// hence, if we already have a mod date for a particular branch id, we skip it
			if (!setOfBranchIdForWhichModTimeWasFound.contains(branchId)) {
				
				WrappedTimestamp latestLCModTimestamp = (WrappedTimestamp) resultRow[1];
				
				if (latestLCModTimestamp != null) {
					
					// get the object corresponding to this branch id
					IteratedLifeCycleManaged ilcmObject = branchIdToObjectMap.get(branchId);
					timeOfLCStateChangeMap.put(ilcmObject, latestLCModTimestamp.getTime());
					
					// putt this branch id in this set, so this branch id will be skipped once we have the mod date
					setOfBranchIdForWhichModTimeWasFound.add(branchId);
				}					
			}
		}
		
		return timeOfLCStateChangeMap;
	}

	/**
	 * Creates a query spec to obtains timestamp of the LC state change. Is based on an OOTB method (LifeCycleHelper.getHistory):
	 * - results are sorted using these conditions (in this order):
	 * -> on branchId in LifecycleHistory (needed to group the results)
	 * -> on CreateTimestamp of LifecycleHistory (Oracle does not support sorting on miliseconds), 
	 * -> on Ida2a2 of LifecycleHistory  
	 * LifecycleHistory objects. 
	 * However, here we are interested only in the time of the latest change. Because of the above sorting scheme we are sure that
	 * for each branchId the first result is the latest change.
	 * 
	 * @param iteratedList
	 * @param branchIdsArray
	 * @return
	 * @throws WTException
	 */
	private static QuerySpec getTimeOfLCChangeCreateQuerySpec(long[] branchIdsArray) throws WTException {
		
		QuerySpec qs = new QuerySpec();
		qs.setAdvancedQueryEnabled(true);
		
		// FROM BLOCK
		int iteratedTableIndex = qs.addClassList(Iterated.class, false);
		int objectHistoryTableIndex = qs.addClassList(ObjectHistory.class, false);
        int lifecycleHistoryTableIndex = qs.addClassList(LifeCycleHistory.class, false);
         
        // select two attributes: modify stamp and branchId (which is needed to check to which object this mod date matches)
        ClassAttribute modifyStamp = new ClassAttribute(LifeCycleHistory.class, WTAttributeNameIfc.MODIFY_STAMP_NAME);
        ClassAttribute branchIdToSelect = new ClassAttribute(Iterated.class, ATTRIBUTE_NAME_ITERATION_INFO_BRANCH_ID); 
        int[] LIFECYCLEHISTORY_INDEX = new int[] {lifecycleHistoryTableIndex};
        int[] ITERATED_INDEX = new int[] {iteratedTableIndex};
        qs.appendSelect(branchIdToSelect, ITERATED_INDEX, false);
        qs.appendSelect(modifyStamp, LIFECYCLEHISTORY_INDEX, false);
		
	
        // CONDITION BLOCK
        String objRefId = "." + ObjectReference.KEY + "." + ObjectIdentifier.ID;
		SearchCondition sc = new SearchCondition(LifeCycleHistory.class, WTAttributeNameIfc.ID_NAME, ObjectHistory.class,
				ObjectHistory.ROLE_BOBJECT_REF + objRefId);
		qs.appendWhere((sc), new int[] {lifecycleHistoryTableIndex, objectHistoryTableIndex});
		qs.appendAnd();
		SearchCondition sc2 = new SearchCondition(Iterated.class, WTAttributeNameIfc.ID_NAME, ObjectHistory.class,
				ObjectHistory.ROLE_AOBJECT_REF + objRefId);
		qs.appendWhere((sc2), new int[] {iteratedTableIndex, objectHistoryTableIndex});
		qs.appendAnd();

		// query for all objects at once
		TableColumn branchIDTableColumn = new TableColumn("A"+iteratedTableIndex, COLUMN_NAME_BRANCH_IDITERATION_INFO);
		SearchCondition sc3 = new SearchCondition(branchIDTableColumn, SearchCondition.IN, new ArrayExpression(branchIdsArray));
		qs.appendWhere((sc3), new int[] {iteratedTableIndex});
		
		// add sorting to the query
		// sorting on createTimestamp + ida2a2 is the OOTB solution (since Oracle does not support sorting on miliseconds)
		try {
			// -> on branchId in LifecycleHistory (needed to group the results)
			ClassAttribute branchId = new ClassAttribute(Iterated.class, ATTRIBUTE_NAME_ITERATION_INFO_BRANCH_ID);
			branchId.setColumnAlias(SORTBY_BRANCHID_ALIAS);
			qs.appendSelect(branchId, ITERATED_INDEX, true);
			qs.appendOrderBy(new OrderBy(branchId, true), ITERATED_INDEX);
			
			// -> on CreateTimestamp of LifecycleHistory (Oracle does not support sorting on miliseconds), 
			ClassAttribute createStamp = new ClassAttribute(LifeCycleHistory.class, WTAttributeNameIfc.CREATE_STAMP_NAME);
			createStamp.setColumnAlias(SORTBY_DATE_ALIAS);
			qs.appendSelect(createStamp, LIFECYCLEHISTORY_INDEX, true);
			qs.appendOrderBy(new OrderBy(createStamp, true), LIFECYCLEHISTORY_INDEX);
			
			// -> on Ida2a2 of LifecycleHistory  
			ClassAttribute ida2a2 = new ClassAttribute(LifeCycleHistory.class, WTAttributeNameIfc.ID_NAME);
			ida2a2.setColumnAlias(SORTBY_IDA2A2_ALIAS);
			qs.appendSelect(ida2a2, LIFECYCLEHISTORY_INDEX, true);
			qs.appendOrderBy(new OrderBy(ida2a2, true), LIFECYCLEHISTORY_INDEX);
	
			
		} catch (WTPropertyVetoException e) {
			String errorMessage = "PropertyVetoException during creating of the query to get the LC mod date of BST parts";
			logger.error(errorMessage, e);
			throw new WTException(errorMessage);
		}
	

		return qs;

	}


	/**
	 * A more convinient entry point to the method. @see(getTimeOfLCStateChange(List<IteratedLifeCycleManaged> iteratedList))
	 * 
	 * @param wtpartCollection
	 * @return
	 * @throws WTException
	 */
	public static Map<IteratedLifeCycleManaged, Long> getTimeOfLCStateChangeMap(Collection<WTPart> wtpartCollection) throws WTException {
		
		List<IteratedLifeCycleManaged> iteratedLcManagedList = new ArrayList<IteratedLifeCycleManaged>();
		for (WTPart wtPart : wtpartCollection) {
			iteratedLcManagedList.add(wtPart);
		}
		
		return getTimeOfLCStateChange(iteratedLcManagedList);
	}

	/**
	 * Get an array of life cycle template oids for a specific life cycle name
	 * 
	 * @param lifeCycleName
	 *            the name of a life cycle
	 * @return an array of life cycle template oids
	 * @throws WTException
	 */
	public static long[] getLCTemplateIdsForLCName(String lifeCycleName) throws WTException {
		long[] lifeCycleOids = null;

		QuerySpec qs = new QuerySpec();
		qs.setAdvancedQueryEnabled(true);
		QueryServerUtils.setAliasPrefix(qs, "LC");
		int idxLCTemplate = qs.appendClassList(LifeCycleTemplate.class, false);
		qs.appendSelectAttribute(QueryServerUtils.PERSIST_INFO_THE_OBJECT_IDENTIFIER_ID, idxLCTemplate, false);

		// Search condition for a specific life cycle name
		SearchCondition scLifeCycleName = new SearchCondition(LifeCycleTemplate.class,
				LifeCycleTemplate.NAME, SearchCondition.EQUAL, lifeCycleName);
		qs.appendWhere(scLifeCycleName, new int[] { idxLCTemplate });

		// Execute the query
		QueryResult qr = PersistenceHelper.manager.find(qs);

		// Prepare the data to return as result
		lifeCycleOids = new long[qr.size()];
		int i = 0;
		while (qr.hasMoreElements()) {
			Object[] result = (Object[]) qr.nextElement();
			long lcOid = ((BigDecimal) result[0]).longValue();
			lifeCycleOids[i++] = lcOid;
		}

		return lifeCycleOids;
	}

}
