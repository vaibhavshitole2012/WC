/*
 * VWElementHelper.java
 *
 * Created on 17. April 2007, 15:43
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.ptc.generic.infoengine;

import com.infoengine.object.factory.Att;
import com.infoengine.object.factory.Element;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Set;
import java.util.Vector;

/**
 *
 * @author Simone Graf
 */
public class VWElementHelper {
    
    /** Creates a new instance of VWElementHelper */
    public VWElementHelper() {
    }
    
    public static Vector convertElementToVWElement(Vector vectorOfElements) {
        Vector vectorOfVWElements = new Vector();
        
        for (int i = 0; i < vectorOfElements.size(); i++) {
            Element element = (Element)vectorOfElements.get(i);
            VWElement vwElement = new VWElement();
            
            Enumeration enumAtts = element.getAtts();
            while (enumAtts.hasMoreElements()) {
                Att att = (Att)enumAtts.nextElement();
                String key = att.getName();
                Object value = att.getValue();
                
                vwElement.put(key, value);
            }
            vectorOfVWElements.add(vwElement);
        }
        
        return vectorOfVWElements;
    }
    
    public static Vector convertVWElementToElement(Vector vectorOfVWElements) {
        Vector vectorOfElements = new Vector();
        
        for (int i = 0; i < vectorOfVWElements.size(); i++) {
            VWElement vwelement = (VWElement)vectorOfVWElements.get(i);
            Element element = new Element();
            
            Iterator it = vwelement.keySet().iterator();
            while (it.hasNext()) {
                String key = (String)it.next();
                Object value = vwelement.get(key);
                
                Att att = new Att(key, value);
                element.addAtt(att);
                
            }
            
            vectorOfElements.add(element);
        }
        
        return vectorOfElements;
    }
    
}
