package com.ptc.generic;

import java.util.SortedMap;
import java.util.TreeMap;

import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.part.WTPart;
import wt.util.WTException;
import wt.vc.Iterated;
import wt.vc.VersionControlException;
import wt.vc.VersionControlHelper;
import wt.vc.VersionReference;
import wt.vc.Versioned;

public class VersionUtil {

	private static final String COLON = ":";
	private static final ReferenceFactory RF = new ReferenceFactory();

	public static String getVersionIterationDisplay(Versioned objIteration) throws VersionControlException {
		return VersionControlHelper.getVersionIdentifier(objIteration).getValue() + "."
				+ VersionControlHelper.getIterationIdentifier(objIteration).getValue();
	}

	protected static String getSortableVersionIterationDisplay(Versioned objIteration) throws VersionControlException {
		return VersionControlHelper.getVersionIdentifier(objIteration).getValue() + "."
				+ String.format("%2s", VersionControlHelper.getIterationIdentifier(objIteration).getValue());
	}

	protected static SortedMap<String, Versioned> getSortedIterationsAsc(QueryResult qr) throws VersionControlException {
		SortedMap<String, Versioned> sortedIterations = new TreeMap<String, Versioned>();
		while (qr.hasMoreElements()) {
			Versioned iteration = (Versioned) qr.nextElement();
			sortedIterations.put(getSortableVersionIterationDisplay(iteration), iteration);
		}
		return sortedIterations;
	}

	public static Iterated getLatestIteration(String oid) throws WTException, VersionControlException {
		Iterated latestIteration = getIteration(oid);

		if (!latestIteration.isLatestIteration()) {
			latestIteration = VersionControlHelper.getLatestIteration(latestIteration);
		}
		return latestIteration;
	}

	/**
	 * Get the iterated object for an oid
	 * 
	 * TODO: Rewrite to handle persistables as return type / Move to other
	 * package
	 * 
	 * @param oid
	 *            the oid of an objet
	 * @return the iterated object
	 * @throws WTException
	 */
	public static Iterated getIteration(String oid) throws WTException {
		Iterated iteration = null;
		try {
			iteration = (Iterated) RF.getReference(oid).getObject();
		} catch (Exception ex) {
			System.out.println("Teil existiert nicht");
		}

		return iteration;
	}

	/**
	 * Get the iterated object for an classname and oid
	 * 
	 * @param classname
	 *            the name of an class
	 * @param oid
	 *            the oid of an objet
	 * @return the iterated object
	 * @throws WTException
	 */
	public static Iterated getIteration(String classname, long oid) throws WTException {
		return VersionUtil.getIteration(classname + COLON + oid);
	}

	/**
	 * Returns all iterations of a version object sorted
	 * 
	 * @param oid
	 *            the oid of a versioned
	 * @return a sorted map with the iteration as key e.g. A.21 and the iterated
	 *         as value
	 * @throws WTException
	 */
	public static SortedMap<String, Versioned> getSortedIterations(String oid) throws WTException {
		Iterated latestIteration = VersionUtil.getLatestIteration(oid);

		QueryResult qrAllIterations = VersionControlHelper.service.allIterationsFrom(latestIteration);

		SortedMap<String, Versioned> sortedIterations = VersionUtil.getSortedIterationsAsc(qrAllIterations);

		return sortedIterations;
	}

	/**
	 * Get the version reference of a part
	 * 
	 * @param part
	 *            the part
	 * @return the version reference
	 * @throws WTException
	 */
	public static String getVersionReference(WTPart part) throws WTException {
		return RF.getReferenceString(VersionReference.newVersionReference(part));
	}

	/**
	 * Return the Id from the OID e.g. wt.part.WTPart:13280 => 13280
	 * 
	 * @param string
	 *            the oid
	 * @return the id
	 * @throws WTException
	 */
	public static long getId(String oid) throws WTException {
		int colon = oid.lastIndexOf(COLON);

		if (colon == -1) {
			throw new WTException("No valid oid given");
		}

		String id = oid.substring(colon + 1);

		return Long.parseLong(id);
	}
	
	/**
	 * Handy method to constructs a oid from the classname and the id
	 * 
	 * @param className the classname  e.g. wt.part.WTPart
	 * @param id the id
	 * @return the od
	 */
	public static String getOid(String className, long id) {
		return className + COLON + id;
	}
	
	   /**
     * Returns the version (String) and iteration (Integer) as an array with two
     * elements.
     *
     * @param versioned
     * @return [version as String, iteration as Integer]
     */
    public static Object[] getVersionIteration(Versioned versioned) {
        Object[] versionIteration = null;
        try {
                versionIteration = new Object[] {
                                VersionControlHelper.getVersionIdentifier(versioned).getValue(),
                                new Integer(VersionControlHelper.getIterationIdentifier(versioned).getValue()) };
        } catch (VersionControlException e) {
                e.printStackTrace();
        }

        return versionIteration;
    }

    /**
     * Compares the version and iteration objects
     * @param versionIteration1 array of two objects: [version, iteration]
     * @param versionIteration2 array of two objects: [version, iteration]
     * @return -1 if versionIteration1 < versionIteration2,
     * 0 if versionIteration1 = versionIteration2,
     * 1 if versionIteration1 > versionIteration2
     */
    public static int compareTo(Object[] versionIteration1, Object[] versionIteration2) {
        // Compare versions first.
        String version1 = (String) versionIteration1[0];
        String version2 = (String) versionIteration2[0];
        int comparison = version1.compareTo(version2);

        if (comparison == 0) {
                // Equal versions. Compare iterations.
                Integer iteration1 = (Integer) versionIteration1[1];
                Integer iteration2 = (Integer) versionIteration2[1];
                comparison = iteration1.compareTo(iteration2);
        }

        return comparison;
    }
}
