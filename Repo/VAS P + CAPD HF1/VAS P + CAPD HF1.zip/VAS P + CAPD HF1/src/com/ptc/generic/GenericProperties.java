/* bcwti
 *
 * Copyright (c) 2001 Parametric Technology Corporation (PTC). All Rights
 * Reserved.
 *
 * This software is the confidential and proprietary information of PTC.
 * You shall not disclose such confidential information and shall use it
 * only in accordance with the terms of the license agreement.
 *
 * ecwti
 */

package com.ptc.generic;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;

import com.ptc.generic.genericResource;

import wt.util.WTContext;
import wt.util.WTException;
import wt.util.WTProperties;

/**
 * GenericProperties organizes the central access to the property files.
 * The <code>GenericProperties</code> class is a generalized singleton.
 * This means, there exists only one instance of this class per VM and property file.
 * This is guaranteed through the protected constructor.<br>
 * The <code>GenericProperties</code> instance for a given property file
 * is only accessible through the static method {@link #getProperties()}.
 * During instantiation of the GenericProperties instance, the properties file(s)
 * are read.
 *
 * @version   1.0
 **/
public class GenericProperties extends WTProperties implements Serializable {

	// --- Attribute Section ---
	private static final String RESOURCE = "com.ptc.generic.genericResource";
	private static final String CLASSNAME = GenericProperties.class.getName();
	private static final String DELIM = " & ";

	// Don't use log4j for logging here as property files managed by this classs
	// might contain log4j configuration information (e.g. used by Log4jConfigurator) 	
	private static final Logger logger = Logger.getLogger(CLASSNAME); // Hmm, better to use Log4j nevertheless

	// Hashtable of GenericProperties instances. The corresponding keys are the names
	// of the property files (e.g. ext/avm.properties) relative to wt.home/codebase or test.home/codebase.
	// In the latter case the property test.home has to be set in wt.properties. 
	private static Hashtable theInstances;

	// Relative filename of the default property file	
	public static final String PROPERTIES_DEFAULT = "ext/test.properties";

	// Whether to load property files from the server (true) or client (false) by default
	private static final Boolean SERVER_DEFAULT = Boolean.TRUE;

	public static final String WT_HOME_KEY = "wt.home";
	public static final String WT_HOME_DEFAULT = "W:\\Windchill";

	private String[] filenames;
	private String filename;
	private Boolean server;
	/**
	 * For testing purposes only. Prints all entries from the default properties file
	 * (e.g. ext/test.properties) in a structured format.
	 *
	 * @param     args vector of command line arguments
	 **/
	public static void main(String[] args) {
		try {
			Hashtable argsHash = getArgsHash(args);
			String[] argNames = { "user", "password", "server", "filename" };
			String[] defaultValues = { "wtadmin", "wtadmin", "false", PROPERTIES_DEFAULT };
			setDefaultValues(argsHash, argNames, defaultValues);
			if (checkRequiredArgs(argsHash, argNames)) {
				showUsageAndExit(CLASSNAME);
			}
			String user = (String) argsHash.get("user");
			String password = (String) argsHash.get("password");
			String s = (String) argsHash.get("server");
			Boolean server = "true".equalsIgnoreCase(s) ? Boolean.TRUE : Boolean.FALSE;
			String filename = (String) argsHash.get("filename");
			System.out.println("user=" + user);
			System.out.println("password=" + password);
			System.out.println("server=" + server);
			System.out.println("filename=" + filename);
			System.out.println("");
			if (server.booleanValue()) {
				AuthHelper.authenticateUser(user, password);
			}
			//			String[] filenames = {"wt.properties","ext/avm.properties"};
			//			testProperties(filenames, server);
			testProperties(filename, server);
		} catch (Exception e) {
			System.err.println("An exception has occured:");
			e.printStackTrace(System.err);
			System.exit(1);
		}
		System.exit(0);
	}

	/**
	 * Constructs a GenericProperties by reading it from the server or client.
	 * Forces a one time load of the property file.
	 * 
	 * @param     filename property file name relative to $(wt.home)/codebase
	 * @param     server whether to load the property file from the server (true) or client (false)
	 * @return    Properties the instance of GenericProperties
	 * @exception wt.util.WTException
	 */
	private static final GenericProperties newGenericProperties(String filename, Boolean server) throws WTException {
		GenericProperties genericProperties = new GenericProperties(filename, server);
		genericProperties.load(filename, server);
		return genericProperties;
	}
	private static final GenericProperties newGenericProperties(String[] filenames, Boolean server) throws WTException {
		GenericProperties genericProperties = new GenericProperties(filenames, server);
		genericProperties.load(filenames, server);
		return genericProperties;
	}

	/**
	 * Loads GenericProperties by reading it from the server or client.
	 * Forces a one time load of the property file.
	 * Returns an instance of GenericProperties.
	 * 
	 * @param     filename property file name relative to $(wt.home)/codebase (server=true) or $(test.home)/codebase (server=false)
	 * @param     server whether to load the property file from the server (true) or client (false)
	 * @return    Properties the instance of GenericProperties
	 * @exception wt.util.WTException
	 */
	protected void load(String filename, Boolean server) throws WTException {
		logger.debug("load(" + filename + "," + server + ") started");

		//HLO: 2006-12-19, does not work any more, dont know why (somehow after the BIF change the
		// conf's of Apache
		// so disable the server block:
		//server = new Boolean(false);

		boolean success = false;

		if (server.booleanValue()) {
			try {
				WTContext wtcontext = WTContext.getContext();

				// try to find out why getServerResourceAsStream() does not work on some machines
				if (logger.isDebugEnabled()) {
					URL url = wtcontext.getCodeBase();
					if (url != null) {
						logger.debug("codebase (from key wt.server.codebase or wt.server.codebase.locator in wt.properties): " + url.toString());
					} else {
						logger.debug(
								"wtcontext.getCodeBase() returned null. Please check key wt.server.codebase or wt.server.codebase.locator in wt.properties");
					}
				}
				InputStream inputstream = wtcontext.getServerResourceAsStream(filename);
				if (inputstream != null) {
					this.load(inputstream);
					success = true;
					logger.debug("loading " + filename + " done: size() = " + this.size());
				} else {
					logger.debug("Could not load " + filename);
				}
			} catch (IOException ie) {
				logger.error("Could not load " + filename, ie);
			}


			// 2007-01-15, workaround hlo to make this code running from inside Applet and from command line
			if( !success ){
				// insert non-server-code:

				try {
					WTProperties wtprops = WTProperties.getLocalProperties();
					String WT_HOME = wtprops.getProperty(WT_HOME_KEY, WT_HOME_DEFAULT);
					String fullFilename = WT_HOME + File.separator + "codebase" + File.separator + filename;
					if (logger.isDebugEnabled()) {
						logger.debug("WT_HOME = " + WT_HOME);
						logger.debug("fullFilename=" + fullFilename);
					}
					FileInputStream fileInputStream = new FileInputStream(fullFilename);
					this.load(fileInputStream);
					fileInputStream.close();
					success = true;
				} catch (FileNotFoundException e) {
					throw new WTException(e, "File " + filename + " not found");
				} catch (IOException e) {
					throw new WTException(e, "Could not load " + filename);
				}
				if( !success ){
					Object[] obj = { filename };
					throw new WTException(null, RESOURCE, genericResource.CANNOT_LOAD_PROPERTIES, obj);
				}
			}
		} else {
			try {
				WTProperties wtprops = WTProperties.getLocalProperties();
				String WT_HOME = wtprops.getProperty(WT_HOME_KEY, WT_HOME_DEFAULT);
				String fullFilename = WT_HOME + File.separator + "codebase" + File.separator + filename;
				if (logger.isDebugEnabled()) {
					logger.debug("WT_HOME = " + WT_HOME);
					logger.debug("fullFilename=" + fullFilename);
				}
				FileInputStream fileInputStream = new FileInputStream(fullFilename);
				this.load(fileInputStream);
				fileInputStream.close();
				success = true;
			} catch (FileNotFoundException e) {
				//throw new WTException(e, "File " + filename + " not found");
			} catch (IOException e) {
				//throw new WTException(e, "Could not load " + filename);
			}


			// 2007-01-15, workaround hlo to make this code running from inside Applet and from command line
			if( !success ){
				// insert server-code:

				try {
					WTContext wtcontext = WTContext.getContext();

					// try to find out why getServerResourceAsStream() does not work on some machines
					if (logger.isDebugEnabled()) {
						URL url = wtcontext.getCodeBase();
						if (url != null) {
							logger.debug("codebase (from key wt.server.codebase or wt.server.codebase.locator in wt.properties): " + url.toString());
						} else {
							logger.debug(
									"wtcontext.getCodeBase() returned null. Please check key wt.server.codebase or wt.server.codebase.locator in wt.properties");
						}
					}
					InputStream inputstream = wtcontext.getServerResourceAsStream(filename);
					if (inputstream != null) {
						this.load(inputstream);
						success = true;
						logger.debug("loading " + filename + " done: size() = " + this.size());
					} else {
						logger.debug("Could not load " + filename);
						Object[] obj = { filename };
						throw new WTException(null, RESOURCE, genericResource.CANNOT_LOAD_PROPERTIES, obj);
					}
				} catch (IOException ie) {
					logger.error("Could not load " + filename, ie);
					Object[] obj = { filename };
					throw new WTException(null, RESOURCE, genericResource.CANNOT_LOAD_PROPERTIES, obj);
				}
				if( !success ){
					Object[] obj = { filename };
					throw new WTException(null, RESOURCE, genericResource.CANNOT_LOAD_PROPERTIES, obj);
				}
			}
		}
		logger.debug("load(" + filename + "," + server + ") finished");
	}
	protected void load(String[] filenames, Boolean server) throws WTException {
		for (String filename : filenames) {
			load(filename, server);
		}
	}

	/**
	 * Gets an instance of GenericProperties belonging to the given filename coming from the server
	 * or from the client.
	 * 
	 * @param     filename property file name relative to $(wt.home)/codebase (server=true) or $(test.home)/codebase (server=false)
	 * @param     server whether the property file is/was coming from the server (true) or client (false)
	 * @exception wt.util.WTException
	 **/
	public static GenericProperties getProperties(String filename, Boolean server) throws WTException {
		return getProperties(filename, server, null);
	}
	public static GenericProperties getProperties(String[] filenames, Boolean server) throws WTException {
		return getProperties(filenames, server, null);
	}

	/**
	 * Gets an instance of GenericProperties belonging to the given filename coming from the server
	 * or from the client.
	 * 
	 * @param     filename property file name relative to $(wt.home)/codebase (server=true) or $(test.home)/codebase (server=false)
	 * @param     server whether the property file is/was coming from the server (true) or client (false)
	 * @exception wt.util.WTException
	 **/
	protected static GenericProperties getProperties(String filename, Boolean server, String className) throws WTException {
		synchronized (GenericProperties.class) {
			if (theInstances == null) {
				theInstances = new Hashtable();
			}
			String key = getKey(filename, server);
			GenericProperties theInstance = (GenericProperties) theInstances.get(key);
			if (theInstance == null) {
				if (className == null) {
					theInstance = newGenericProperties(filename, server);
				} else {
					try {
						Class theClass = Class.forName(className);
						String shortName = null;
						StringTokenizer st = new StringTokenizer(className, ".");
						while (st.hasMoreElements()) {
							shortName = st.nextToken();
						}
						String methodName = "new" + shortName;
						Class args[] = { java.lang.String.class, java.lang.Boolean.class };
						Object params[] = { filename, server };

						try {
							Method theMethod = theClass.getMethod(methodName, args);
							Object out = theMethod.invoke(null, params);
							if (out instanceof GenericProperties) {
								theInstance = (GenericProperties) out;
							} else {
								throw new WTException("getProperties() - Error : Created object is not of type GenericProperties");
							}
						} catch (NoSuchMethodException nsme) {
							throw new WTException(nsme,
									"getProperties() - Error : Method " + methodName + " not found for params = (" + params[0] + "," + params[1] + ")");
						} catch (IllegalArgumentException iae) {
							throw new WTException(iae,
									"getProperties() - Error : Illegal argument with params = (" + params[0] + "," + params[1] + ")");
						} catch (IllegalAccessException iae) {
							throw new WTException("getProperties() - Error : Illegal access - " + iae.getMessage());
						} catch (InvocationTargetException ite) {
							throw new WTException(ite.getTargetException(), "getProperties() - Error : Invocation target exception");
						}
					} catch (ClassNotFoundException cnfe) {
						throw new WTException(cnfe, "getProperties() - Error : Class not found exception - " + cnfe.getMessage());
					} catch (Exception e) {
						throw new WTException(e);
					}
				}
				theInstances.put(key, theInstance);
			}
			return theInstance;
		}
	}
	protected static GenericProperties getProperties(String[] filenames, Boolean server, String className) throws WTException {
		synchronized (GenericProperties.class) {
			if (theInstances == null) {
				theInstances = new Hashtable();
			}
			String key = getKey(filenames, server);
			GenericProperties theInstance = (GenericProperties) theInstances.get(key);
			if (theInstance == null) {
				if (className == null) {
					theInstance = newGenericProperties(filenames, server);
				} else {
					try {
						Class theClass = Class.forName(className);
						String shortName = null;
						StringTokenizer st = new StringTokenizer(className, ".");
						while (st.hasMoreElements()) {
							shortName = st.nextToken();
						}
						String methodName = "new" + shortName;
						Class args[] = { java.lang.String[].class, java.lang.Boolean.class };
						Object params[] = { filenames, server };

						try {
							Method theMethod = theClass.getMethod(methodName, args);
							Object out = theMethod.invoke(null, params);
							if (out instanceof GenericProperties) {
								theInstance = (GenericProperties) out;
							} else {
								throw new WTException("getProperties() - Error : Created object is not of type GenericProperties");
							}
						} catch (NoSuchMethodException nsme) {
							throw new WTException(
									"getProperties() - Error : Method " + methodName + " not found for params = (" + params[0] + "," + params[1] + ")");
						} catch (IllegalArgumentException iae) {
							throw new WTException(
									"getProperties() - Error : Illegal argument with params = (" + params[0] + "," + params[1] + ")");
						} catch (IllegalAccessException iae) {
							throw new WTException("getProperties() - Error : Illegal access - " + iae.getMessage());
						} catch (InvocationTargetException ite) {
							ite.printStackTrace();
							throw new WTException("getProperties() - Error : Invocation target exception - " + ite.getTargetException());
						}
					} catch (ClassNotFoundException cnfe) {
						cnfe.printStackTrace();
						throw new WTException("getProperties() - Error : Class not found exception - " + cnfe.getMessage());
					} catch (Exception e) {
						e.printStackTrace();
						throw new WTException(e.getMessage());
					}
				}
				theInstances.put(key, theInstance);
			}
			return theInstance;
		}
	}

	/**
	 * Gets the key for a given property file name that should be loaded from the server or client.
	 * The key for a property file is given by the the string "SERVER" (from server) or "CLIENT" (from client)
	 * a colon and the relative name of the property file.
	 * Example: SERVER:ext/avm.properties
	 * 
	 * @param     filename property file name relative to $(wt.home)/codebase (server=true) or $(test.home)/codebase
	 * @param     server whether the property file is/was coming from the server (true) or client (false)
	 **/
	private static final String getKey(String filename, Boolean server) {
		String key = (server.booleanValue() == true ? "SERVER" : "CLIENT") + ":" + filename.replace('\\', '/');
		return key;
	}

	/**
	 * Gets the key for multiple given property file names that should be loaded from the server or client
	 * using the same instanve of <code>GenericProperties</code>.
	 * The key for a array of property files is given by the concatination of the keys for
	 * the property file names with respect to the delimiter " & ".
	 * Example: SERVER:wt.properties & SERVER:ext/avm.properties
	 * 
	 * @param     filename property file name relative to $(wt.home)/codebase (server=true) or $(test.home)/codebase
	 * @param     server whether the property file is/was coming from the server (true) or client (false)
	 * @throws NullPointerException if filenames is null
	 * 
	 **/
	private static final String getKey(String[] filenames, Boolean server) {
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < filenames.length; i++) {
			String filename = filenames[i];
			if (i != 0) {
				sb.append(DELIM);
			}
			sb.append(getKey(filename, server));
		}
		return sb.toString();
	}

	/**
	 * Gets an instance of GenericProperties belonging to the default properties file
	 * (e.g. ext/test.properties) from the server or from the client.
	 * 
	 * @param     server whether the property file is/was coming from the server (true) or client (false)
	 * @exception wt.util.WTException
	 **/
	public static GenericProperties getProperties(Boolean server) throws WTException {
		return getProperties(PROPERTIES_DEFAULT, server);
	}

	/**
	 * Gets an instance of GenericProperties belonging to the given filename coming from the server.
	 * 
	 * @param     filename property file name relative to $(wt.home)/codebase
	 * @exception wt.util.WTException
	 **/
	public static GenericProperties getProperties(String filename) throws WTException {
		return getProperties(filename, SERVER_DEFAULT);
	}
	public static GenericProperties getProperties(String[] filenames) throws WTException {
		return getProperties(filenames, SERVER_DEFAULT);
	}

	/**
	 * Gets an instance of GenericProperties belonging to the default properties file
	 * (e.g. ext/test.properties) from the server.
	 * 
	 * @exception wt.util.WTException
	 **/
	public static GenericProperties getProperties() throws WTException {
		return getProperties(PROPERTIES_DEFAULT, SERVER_DEFAULT);
	}

	/**
	 * Default constructor. Creates an empty property list without any defaults (The default object is null).
	 */
	protected GenericProperties(String aFilename, Boolean aServer) {
		this();
		filename = aFilename;
		filenames = null;
		server = aServer;
	}

	/**
	 * Default constructor. Creates an empty property list without any defaults (The default object is null).
	 */
	protected GenericProperties(String[] aFilenames, Boolean aServer) {
		this();
		filename = null;
		filenames = aFilenames;
		server = aServer;
	}

	/**
	 * Default constructor. Creates an empty property list without any defaults (The default object is null).
	 */
	protected GenericProperties() {
		super(null);
	}

	/** Shows usage for the main method and exits the VM */
	protected static void showUsageAndExit(String className) {
		System.err.println("Usage:");
		System.err.println("java " + className + " -user=<user> -password=<password> -server=<server> -properties=<properties>");
		System.err.println("\t<user>:\t\t\tWindchill user name, e.g. wtadmin.");
		System.err.println("\t<password>:\t\tPassword for <user>");
		System.err.println("\t<server>:\t\tLoad properties from Server (true) or from client (false)");
		System.err.println("\t<properties>:\tRelative filename of properties file (e.g. ext/avm.properties)");
		System.exit(1);
	}

	/** Print all key/value pairs to stdout */
	protected static void testProperties(String filename, Boolean server) throws WTException {
		String defaultValue = "defaultValue";
		WTProperties testProperties = GenericProperties.getProperties(filename, server);
		Enumeration keys = testProperties.keys();
		int i = 0;
		while (keys.hasMoreElements()) {
			String key = (String) keys.nextElement();
			String value = testProperties.getProperty(key, defaultValue);
			System.out.println("key[" + i + "] = " + key);
			System.out.println("value[" + i + "] = " + value);
			System.out.println("");
			i++;
		}
	}
	protected static void testProperties(String[] filenames, Boolean server) throws WTException {
		String defaultValue = "defaultValue";
		WTProperties testProperties = GenericProperties.getProperties(filenames, server);
		Enumeration keys = testProperties.keys();
		int i = 0;
		while (keys.hasMoreElements()) {
			String key = (String) keys.nextElement();
			String value = testProperties.getProperty(key, defaultValue);
			System.out.println("key[" + i + "] = " + key);
			System.out.println("value[" + i + "] = " + value);
			System.out.println("");
			i++;
		}
	}

	/**
	 * Constructs a GenericProperties from the given properties. 
	 * All key/value pairs of props are copied to the newly created instance of GenericProperties.
	 */
	/*
	private GenericProperties(Properties props) {
		super(props);
		this.putAll(props);
	}
	 */

	/** return the text AFTER the specified separator */
	public static final String textAfter(String text, String separator) {
		StringTokenizer st = new StringTokenizer(text, separator);
		st.nextToken(); // skip first token
		return st.nextToken();
	}

	/** return the text BEFORE the specified separator */
	public static final String textBefore(String text, String separator) {
		StringTokenizer st = new StringTokenizer(text, separator);
		return st.nextToken();
	}

	/**
	 * Stores command line parameters of the form key=value and -key=value as key/value pairs
	 * in a Hashtable.
	 * 
	 * @param args Vector of command line parameters
	 * @return the Hashtable of command line parameters
	 */
	public static final Hashtable getArgsHash(String[] args) {
		Hashtable argsHash = new Hashtable();
		for (String arg2 : args) {
			String arg = textBefore(arg2, "=");
			String value = textAfter(arg2, "=");
			if (arg.startsWith("-")) {
				arg = arg.substring(1);
			}
			argsHash.put(arg, value);
		}
		return argsHash;
	}

	/**
	 * For any command line parameter <code>argNames[i]</code> in <code>String[] argNames</code>
	 * the command line parameter Hashtable <code>argsHash</code> is checked for null or empty values.
	 * 
	 * @param argsHash Hashtable of command line parameters
	 * @param argNames Vector of command line parameter names
	 * @return true if at least one of the parameter values is null or empty, false otherwise 
	 */
	public static final boolean checkRequiredArgs(Hashtable argsHash, String[] argNames) {
		boolean shouldExit = false;
		for (String argName : argNames) {
			String argValue = (String) argsHash.get(argName);
			if (argValue == null || "".equalsIgnoreCase(argValue)) {
				System.err.println("No value found for required arg = " + argName);
				shouldExit = true;
			}
		}
		return shouldExit;
	}

	/**
	 * For any command line parameter <code>argNames[i]</code> in <code>String[] argNames</code>
	 * the corresponding default value <code>defaultValues[i]</code> from
	 * <code>String[] defaultValues</code> is set in the command line parameter Hashtable
	 * <code>argsHash</code> if not already set. 
	 *  
	 * @param argsHash Hashtable of command line parameters
	 * @param argNames Vector of command line parameter names
	 * @param defaultValues Vector of default values for the command line parameters
	 */
	public static final void setDefaultValues(Hashtable argsHash, String[] argNames, String[] defaultValues) {
		if (defaultValues == null) {
			return;
		}
		for (int i = 0; i < argNames.length; i++) {
			String argValue = (String) argsHash.get(argNames[i]);
			if (argValue == null || "".equalsIgnoreCase(argValue)) {
				argsHash.put(argNames[i], defaultValues[i]);
			}
		}
	}
	/**
	 * Gets the filename for this instance
	 * @return
	 */
	public String getFilename() {
		return filename;
	}

	/**
	 * Gets the server flag for this instance
	 * @return
	 */
	public Boolean getServer() {
		return server;
	}

	/**
	 * Sets the filename for this instance
	 * @param string
	 */
	public void setFilename(String string) {
		filename = string;
	}

	/**
	 * Sets the server flag for this instance
	 * @param b
	 */
	public void setServer(Boolean b) {
		server = b;
	}

	/**
	 * Gets the filenames for this instance
	 * @return
	 */
	public String[] getFilenames() {
		return filenames;
	}

	/**
	 * Sets the filenames for this instance
	 * @param strings
	 */
	public void setFilenames(String[] strings) {
		filenames = strings;
	}

	/** returns all values of Property file with a key starting with given argument filter
	 * @param filter String to filter values 
	 * @return property values
	 */
	public HashSet getPropertyValuesStartsWith(String filter)
	{       
		HashSet returnset = new HashSet();
		Enumeration en = super.keys();
		while (en.hasMoreElements())
		{
			String key = (String) en.nextElement();
			if (key.startsWith(filter)) {
				returnset.add(super.get(key));
			}
		}
		return returnset;
	}

}
