/* bcwti
 *
 * Copyright (c) 2008 Parametric Technology Corporation (PTC). All Rights
 * Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */
package com.ptc.generic.epm;

import java.beans.PropertyVetoException;
import java.io.IOException;
import java.io.Serializable;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.ptc.generic.FcHelper;
import com.ptc.generic.LocaleUtil;
import com.ptc.generic.dependency.DependencyRetrieverHelper;
import com.ptc.generic.epm.EPMAssociation.BuildType;
import com.ptc.generic.epm.EPMAssociation.ModificationType;
import com.ptc.generic.iba.IBAUtil;
import com.ptc.generic.part.PartHelper;
import com.ptc.service.annotations.GenerateService;
import com.ptc.windchill.collector.api.cad.CadCollectedResult;
import com.ptc.windchill.collector.api.cad.CadCollector;
import com.ptc.windchill.collector.api.cad.CadCollector.GatherDependents;
import com.ptc.windchill.uwgm.common.associate.Association;
import com.ptc.windchill.uwgm.common.conflict.ErrorElement;
import com.ptc.windchill.uwgm.common.conflict.UwgmErrorException;
import com.ptc.windchill.uwgm.common.util.BuildHelper;
import com.ptc.windchill.uwgm.common.util.PrintHelper;
import com.ptc.windchill.uwgm.proesrv.action.AssociateAction;
import com.ptc.windchill.uwgm.proesrv.action.DisassociateAction;
import com.ptc.wvs.common.ui.VisualizationHelper;
import com.ptc.wvs.server.util.WVSContentHelper;

import ext.tools.ToolUtils;
import wt.build.BuildHistory;
import wt.conflict.ConflictException;
import wt.content.ApplicationData;
import wt.content.ContentHelper;
import wt.content.ContentItem;
import wt.epm.EPMDocConfigSpec;
import wt.epm.EPMDocument;
import wt.epm.EPMDocumentMaster;
import wt.epm.build.EPMBuildHistory;
import wt.epm.build.EPMBuildRule;
import wt.epm.familytable.EPMSepFamilyTable;
import wt.epm.structure.EPMDescribeLink;
import wt.epm.structure.EPMReferenceLink;
import wt.epm.structure.EPMStructureHelper;
import wt.epm.workspaces.CheckinOption;
import wt.epm.workspaces.EPMAsStoredConfigSpec;
import wt.epm.workspaces.EPMWorkspace;
import wt.fc.BinaryLink;
import wt.fc.ObjectIdentifier;
import wt.fc.ObjectReference;
import wt.fc.PersistInfo;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.fc.WTReference;
import wt.fc.collections.CollectionsHelper;
import wt.fc.collections.WTArrayList;
import wt.fc.collections.WTCollection;
import wt.fc.collections.WTKeyedHashMap;
import wt.fc.collections.WTKeyedMap;
import wt.fc.collections.WTList;
import wt.fc.collections.WTSet;
import wt.fc.collections.WTValuedHashMap;
import wt.fc.collections.WTValuedMap;
import wt.filter.NavigationCriteria;
import wt.fv.master.RedirectDownload;
import wt.httpgw.URLFactory;
import wt.iba.definition.AttributeDefinition;
import wt.iba.value.AbstractValue;
import wt.ownership.OwnershipHelper;
import wt.part.WTPart;
import wt.pds.StatementSpec;
import wt.pom.Transaction;
import wt.query.ArrayExpression;
import wt.query.ClassAttribute;
import wt.query.ExistsExpression;
import wt.query.NegatedExpression;
import wt.query.OrderBy;
import wt.query.QueryException;
import wt.query.QuerySpec;
import wt.query.SQLFunction;
import wt.query.SearchCondition;
import wt.query.TableExpression;
import wt.representation.Representable;
import wt.representation.Representation;
import wt.services.StandardManager;
import wt.session.SessionHelper;
import wt.util.LocalizableMessage;
import wt.util.WTAttributeNameIfc;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.vc.VersionControlException;
import wt.vc.VersionControlHelper;
import wt.vc.config.ConfigSpec;
import wt.vc.struct.StructHelper;
import wt.vc.wip.WorkInProgressException;
import wt.vc.wip.WorkInProgressHelper;
import wt.vc.wip.Workable;


@GenerateService(generateHelper = true)
public class StandardEPMAssociateService extends StandardManager implements EPMAssociateService, Serializable {
	
	public static final String svnRev = "$Revision: 1.2 $ $Date: 2016/07/11 14:14:12IST $";
	public static final String svnUrl = "$URL: http://127.0.0.1/svn/KB_04082016/components/Generic-Utilities/src/com/ptc/generic/epm/StandardEPMAssociateService.java $";
	
	private static final long serialVersionUID = 2833521025275645176L;
	private static final String CLASSNAME = StandardEPMAssociateService.class.getName();
	private static final Logger logger = Logger.getLogger(CLASSNAME);
	private static final ReferenceFactory RF = new ReferenceFactory();
	private static final Hashtable<BuildType, Integer> buildFlags = new Hashtable<BuildType, Integer>();
	private static final String ESCAPE = "/";
	

   public static enum ConfSpec {
      LATEST, ASSTORED
   }

    static {
        buildFlags.put(BuildType.OWNER, EPMBuildRule.ALL_BUILD_ROLES);
        buildFlags.put(BuildType.CONTIBUTING_CONTENT, EPMBuildRule.BUILD_ATTRIBUTES);
        buildFlags.put(BuildType.CONTIBUTING_IMAGE, EPMBuildRule.CAD_REPRESENTATION + EPMBuildRule.BUILD_ATTRIBUTES);
        buildFlags.put(BuildType.IMAGE, EPMBuildRule.CAD_REPRESENTATION);
        buildFlags.put(BuildType.CONTENT, 0);
    }

   /**
    * Default factory for the class.
    *
    * @return    StandardEPMAssociateService
    * @exception wt.util.WTException
    **/
   public static StandardEPMAssociateService newStandardEPMAssociateService() throws WTException {
	   StandardEPMAssociateService instance = new StandardEPMAssociateService();
      instance.initialize();
      return instance;
   }

   /**
    * returns the one EPMDocument that is linked as 'owner' to the given
    * WTPart.
    * if no 'owner' link was found, null is returned.
    * if more than one 'owner' link was found, an exception is thrown.
    *
    * internal note: depending if given WTPart is a latest iteration either
    * the EPMBuildRule links or the EPMBuildHistory links are navigated
    * towards EPMDocuments.
    *
    * @param     part  can be either a WTPart or a WTReference or a String (oid)
    * @return    EPMDocument
    * @exception wt.util.WTException
    **/
   public EPMDocument getOwnerEPMDoc( Object part ) throws WTException {
       WTPart givenPart = PartHelper.convertToWTPart(part);
       if(givenPart==null) {
           throw new WTException("no part given to method EPMHelper.service.getAssociatedOwnerEPMDoc()");
       }
       return getActiveEPMDoc(givenPart, new BuildType[] {BuildType.OWNER});
   }

   /**
    * @param     o
    * @return    List<EPMAssociation>
    * @exception wt.util.WTException
    **/
   public List<EPMAssociation> getActiveAssociations( Object o ) throws WTException {
       WTPart givenPart = null;
       EPMDocument givenEPMDoc = null;

       //try to convert given object to WTPart
       try {
           givenPart = PartHelper.convertToWTPart(o);
       } catch(Exception e) {
           //don't throw this exception, we will try to find a given EPMDocument instead
       }

       if(givenPart!=null) {
           return getActiveAssociationsOfPart(givenPart);
       } else {
           //try to convert given object to EPMDocument
           try {
               givenEPMDoc = EPMHelper.convertToEPMDoc(o);
              if(givenEPMDoc!=null) {
                  return getActiveAssociationsOfEPMDoc(givenEPMDoc);
              } else {
                  throw new Exception("nix"); //we'll throw a nice Exception below then
              }
           } catch(Exception e) {
               //we could convert given Object to either WTPart or EPMDocument
               throw new WTException("given object is neither a WTPart nor an EPMDocument. givenObject=" + o + " class: " + (o==null?"NULL":o.getClass().getName()));
           }
       }
   }

   /**
    * @param     o
    * @return    List<EPMAssociation>
    * @exception wt.util.WTException
    **/
   public List<EPMAssociation> getPassiveAssociations( Object o ) throws WTException {
       WTPart givenPart = null;
       EPMDocument givenEPMDoc = null;

       //try to convert given object to WTPart
       try {
           givenPart = PartHelper.convertToWTPart(o);
       } catch(Exception e) {
           //don't throw this exception, we will try to find a given EPMDocument instead
       }

       if(givenPart!=null) {
           return getPassiveAssociationsOfPart(givenPart);
       } else {
           //try to convert given object to EPMDocument
           try {
               givenEPMDoc = EPMHelper.convertToEPMDoc(o);
              if(givenEPMDoc!=null) {
                  return getPassiveAssociationsOfEPMDoc(givenEPMDoc);
              } else {
                  throw new Exception("nix"); //we'll throw a nice Exception below then
              }
           } catch(Exception e) {
               //we could convert given Object to either WTPart or EPMDocument
               throw new WTException("given object is neither a WTPart nor an EPMDocument. givenObject=" + o + " class: " + (o==null?"NULL":o.getClass().getName()));
           }
       }
   }

   /**
    * @param     o
    * @return    List<EPMAssociation>
    * @exception wt.util.WTException
    **/
   public List<EPMAssociation> getAllAssociations( Object o ) throws WTException {
           WTPart givenPart = null;
           EPMDocument givenEPMDoc = null;

           //try to convert given object to WTPart
           try {
               givenPart = PartHelper.convertToWTPart(o);
           } catch(Exception e) {
               //don't throw this exception, we will try to find a given EPMDocument instead
           }

           if(givenPart!=null) {
               return getAllAssociationsOfPart(givenPart);
           } else {
               //try to convert given object to EPMDocument
               try {
                   givenEPMDoc = EPMHelper.convertToEPMDoc(o);
                  if(givenEPMDoc!=null) {
                      return getAllAssociationsOfEPMDoc(givenEPMDoc);
                  } else {
                      throw new Exception("nix"); //we'll throw a nice Exception below then
                  }
               } catch(Exception e) {
                   //we could convert given Object to either WTPart or EPMDocument
                   throw new WTException("given object is neither a WTPart nor an EPMDocument. givenObject=" + o + " class: " + (o==null?"NULL":o.getClass().getName()));
               }
           }
   }
   
   private List<EPMAssociation> getAllAssociationsOfEPMDoc(EPMDocument givenEPMDoc) throws WTException {
       throw new WTException("getAllAssociationsOfEPMDoc(EPMDoc) is not yet implemented.");
   }
   
   private List<EPMAssociation> getPassiveAssociationsOfEPMDoc(EPMDocument epmdoc) throws WTException {
       throw new WTException("getPassiveAssociationsOfEPMDoc(EPMDoc) is not yet implemented.");
   }
   
   /**
    * @param     ws EPMWorkspace
    * @param     instructions Collection<Association>
    * @exception wt.util.WTException
    **/
   public void associate( EPMWorkspace ws, Collection instructions ) throws WTException {
       Collection<Association> toAssociate = new ArrayList<Association>();
       //special logic for active associations
       //get available active association type - owner or contributing content
       for (Object association : instructions) {
           Association a = getAvailableAssociation((Association)association);
           toAssociate.add(a);
           logger.debug("added association for processing: " + a);
       }

       AssociateAction aa = new AssociateAction(EPMWorkspaceHelper.service.getRequestContext(), ws, toAssociate);
       aa.execute();
       logger.debug("executed AssociateAction with " + toAssociate.size() + " associations in ws=" + ws);
   }
   
   /**
    * @param     ws
    * @param     instructions
    * @exception wt.util.WTException
    **/
   public void disassociate( EPMWorkspace ws, Collection instructions ) throws WTException {
       logger.debug("added dis-associations for processing: " + instructions);
       DisassociateAction da = new DisassociateAction(EPMWorkspaceHelper.service.getRequestContext(), ws, instructions);
       da.execute();
       logger.debug("executed DisassociateAction with " + instructions.size() + " associations in ws=" + ws);
   }

   /**
    * @param     part  can be either a WTPart or a WTReference or a String (oid)
    * @param     epm  can be either a EPMDocument or a WTReference or a String (oid)
    * @exception wt.util.WTException
    **/
   public void createOwner( Object part, Object epm ) throws WTException {
       WTPart wtpart = PartHelper.convertToWTPart(part);
       EPMDocument epmdoc = EPMHelper.convertToEPMDoc(epm);
       EPMWorkspace ws = EPMWorkspaceHelper.service.findOrCreateWorkspace(EPMWorkspaceHelper.TMP_WS, wtpart.getContainer(),false);

       WTCollection originals = new WTArrayList();
       originals.add(wtpart);
       originals.add(epmdoc);

       // keys: originals, value: working copies
       WTValuedMap orig2wrkCp = wt.epm.workspaces.EPMWorkspaceHelper.manager.checkout(ws, originals);
       EPMDocument epmDocWrk = (EPMDocument) orig2wrkCp.getPersistable(epmdoc);
       WTPart wtpartWrk = (WTPart) orig2wrkCp.getPersistable(wtpart);
       Association ownerAssoc = new Association(epmDocWrk, wtpartWrk, Association.Type.ACTIVE, true, true, true);

       Collection<Association> instructions = new Vector<Association>();
       instructions.add(ownerAssoc);

       associate(ws, instructions);

       //now we need to checkin all objects (wtpart + epmdocs)
      WTKeyedHashMap toCheckin = buildCheckinOptionsMap(orig2wrkCp, "createOwner");
      WTSet ci = wt.epm.workspaces.EPMWorkspaceHelper.manager.checkin(ws, toCheckin);
      wt.epm.workspaces.EPMWorkspaceHelper.manager.removeFromWorkspace(ws, ci);
   }

    /**
     * Create a passive content reference between the given part and the given epm document.
     *
     * Instantiates and persists a new <code>EPMDescribeLink</code> between
	 * given <code>part</code> that acts as Role A object (referencedBy) and
	 * given <code>epm</code> that acts as Role B object (references).
     *
     * @param part
     * @param epm
     * @throws WTException, WTPropertyVetoException
     */
    public void createPassive(WTPart part, EPMDocument epm) throws WTException, WTPropertyVetoException {
        EPMDescribeLink epmDescribeLink = EPMDescribeLink.newEPMDescribeLink(part, epm);
        epmDescribeLink.setBuiltFlag(false);
        PersistenceServerHelper.manager.insert(epmDescribeLink);
    }

   /**
    * performs Associate and Disassociate action on given part and collection
    * of associations comparing the input collection to current association
    * of given part
    *
    * @param     associationContainer  Part to be associated/disassociated with input collection of desired associations - this a list of all "to-be" associations so if one of current ones is not presented here, it will be removed (disassociated)
    * @return    WTPart
    * @exception wt.util.WTException
    **/
   public WTPart setAssociations( AssociationContainer associationContainer ) throws WTException {
       WTPart part = associationContainer.getPart();
        if (validate(associationContainer)) {

            Collection<Association> toAssociate = new ArrayList<Association>();
            Collection<Association> toDisassociate = new ArrayList<Association>();
            WTCollection toCheckout = new WTArrayList();
            
            for (EPMAssociation association : associationContainer.associations) {
                switch (association.getModificationType()) {
                case NEW:
                    toAssociate.add(association);
                    if(association.getAssocType() == Association.Type.ACTIVE) {
                    	toCheckout.add(association.getDoc());
                    }
                    break;
                case TO_BE_REMOVED:
                    toDisassociate.add(association);
                    if(association.getAssocType() == Association.Type.ACTIVE) {
                        toCheckout.add(association.getDoc());
                    }
                    break;
                default:
                    break;
                }
            }

            Transaction trx = new Transaction();
            try {
                trx.start();
                part = saveAssociations(part, toAssociate, toDisassociate, toCheckout);
                trx.commit();
                trx = null;
            } finally {
                if (trx != null) {
                    logger.debug("Conflict occured - rolling back the transaction...");
                    trx.rollback();
                    logger.debug("...done");
                }
            }
        }
        return part;
   }

   /**
    * returns the one EPMDocument that is actively linked to the given WTPart,
    * if no link was found, null is returned.
    * if more than one link was found, an exception is thrown.
    *
    * internal note: depending if given WTPart is a latest iteration either
    * the EPMBuildRule links or the EPMBuildHistory links are navigated
    * towards EPMDocuments.
    *
    * @param     part  can be either a WTPart or a WTReference or a String (oid)
    * @return    EPMDocument
    * @exception wt.util.WTException
    **/
   public EPMDocument getActiveEPMDoc( Object part )
            throws WTException {
       WTPart givenPart = PartHelper.convertToWTPart(part);
       if(givenPart==null) {
          throw new WTException("no part given to method EPMHelper.service.getAssociatedOwnerEPMDoc()");
       }
       //custom logic: return owner OR contribContent
       return getActiveEPMDoc(givenPart, new BuildType[]{BuildType.OWNER, BuildType.CONTIBUTING_CONTENT});
   }
   
   /**
    * Collects <i>ProductView</i> and <i>Download</i> links for given collection
    * of part OIDs
    * 
    * @param oids source
    * @param pView defines if <i>ProductView</i> link has to returned or not
    * @param download defines if <i>Download</i> link has to returned or not
    * @return map where key = "[part OID] + [_PVIEW | _DOWNLOAD]" and value = certain link 
    */
   public Map getCalulatedURLs(final Collection oids, final boolean pView, final boolean download) {
       final long startTime = System.currentTimeMillis();
       final String PVIEW_URL_KEY_SUFFIX = "_PVIEW";
       final String DOWNLOAD_URL_KEY_SUFFIX = "_DOWNLOAD";
       
       Map<String, URL> urls = new HashMap<String, URL>();
       for (Object oid : oids) {
           if (pView && !urls.containsKey(oid + PVIEW_URL_KEY_SUFFIX)) {
               try {
                   urls.put(oid + PVIEW_URL_KEY_SUFFIX, getProductViewURL(oid));
               } catch (WTException wtex) {
                   logger.error(wtex.getLocalizedMessage(), wtex);
               }
           }
           if (download && !urls.containsKey(oid + DOWNLOAD_URL_KEY_SUFFIX)) {
               try {
                   urls.put(oid + DOWNLOAD_URL_KEY_SUFFIX, getDownloadURL(oid));
               } catch (WTException wtex) {
                   logger.error(wtex.getLocalizedMessage(), wtex);
               }
           }
       }
       
       return urls;
   }

   /**
    * Convert given object into a Representable, get the default representation of it, and return a URL to Creo View for this representation
    * 
    * @param     object (WTPart, EPMDocument, WTReference to them, or oid of them)
    * @return    URL to open Creo View with the default representation. Null if representable has no default representation
    * @exception wt.util.WTException if given object cannot be converted to a Representable object
    **/
   public URL getProductViewURL( Object object ) throws WTException {
       // Furthermore it is not listed in the API, hence not supported.
       Representable representable = (Representable) FcHelper.convertToPersistable(object);      
       logger.debug("representable=" + ToolUtils.prettyPrint(representable, false));

       //display the default representation. If given object has no default representation, then return null
       //we could enhance this that if no default rep on WTPart is found, retrieve EPMDoc (via owner) and return its default rep
       
       //code for retrieval of .pvs were found in CreoRepresentationURLsDataUtility (WT10.1 M030)
       //                  and the resulting URL looked like what was opened from info pages
       //                  just the objref=... was added, otherwise Creo View didn't show the geometry
       // Representation rep = PublishUtils.getRepresentation(representable); //gets the 'Default' representation
		Representation rep = null;
		
		// following https://support.ptc.com/apps/case_logger_viewer/auth/ssl/case=07717359
		final VisualizationHelper vh = new VisualizationHelper();
		rep = vh.getRepresentation(representable);
		
		if (rep == null) {
			if (representable instanceof WTPart) {
				logger.debug("Fallback for TheoTeile that are linked with Contributing Content link.");
				try {
					final EPMDocument epm = getActiveEPMDoc((WTPart) representable, new BuildType[] { BuildType.CONTIBUTING_CONTENT });
					if (epm != null) {						
						rep = vh.getRepresentation(epm);
						if (rep != null) {
							logger.debug("Fallback result for = " + epm.getDisplayIdentifier().toString());
							logger.debug("Representation = " + rep);
						}
					}
				} catch (final Exception e) {
					logger.error(e.getLocalizedMessage(), e);
				}
			}
		}

       URLFactory urlFactory = new URLFactory();
       URL url = null;
       if(rep==null) {
    	   logger.debug("no represenation found for representable, creating URL that should create representation");
    	   // Create the representation if it doesn't exist
    	  
    	   if (object == null) {
    		   // No method parameter given
    	   } else  if (object instanceof EPMDocument) {
    		   // Method was called with EPMDocument as parameter (CadDocTableListener)
    		    url = urlFactory.getURL("/wtcore/jsp/wvs/edrview.jsp?&viewIfPublished=1" + "&sendToPublisher=OR:" + representable);
    	   } else if (object instanceof String && StringUtils.containsIgnoreCase((String) object, "wt.part.WTPart")) {
    		   // Methode was called with part oid
    		   url = urlFactory.getURL("/wtcore/jsp/wvs/edrview.jsp?&viewIfPublished=1&sendToPublisher=OR:" + object);
    	   }
       } else {
    	   logger.debug("represenation=" + ToolUtils.prettyPrint(rep));
    	   URL pvsURL = null;
    	   QueryResult appDatas = ContentHelper.service.getContentsByRole(rep, wt.content.ContentRoleType.PRODUCT_VIEW_ED);
    	   logger.debug("appData.size()=" + appDatas.size());

    	   if (appDatas.size() == 1) {
    		   ApplicationData pvsFile = (ApplicationData) appDatas.nextElement();
    		   if(logger.isTraceEnabled()) {
    			   logger.trace("pvsFile=" + ToolUtils.prettyPrint(pvsFile));
    		   }
    		   pvsURL = WVSContentHelper.getDownloadURL(pvsFile, rep);
    		   logger.debug("pvsURL=" + pvsURL.toString());
    		   logger.debug("pvsURL externalForm=" + pvsURL.toExternalForm());
    		   url = urlFactory.getURL("/wtcore/jsp/wvs/edrview.jsp?url=" + pvsURL.toString() + "&objref=" + RF.getReferenceString(rep));

    	   } else {
    		   logger.debug("appData.size not 1 -> leaving method with url=null");
    	   }
       }

       logger.debug("overall url=" + url);
       return url;
   }

   /**
    * given Object can be either a WTPart, an EPMDocument, a WTReference
    * (to WTPart or EPMDocument), or a String oid (representing a WTPart
    * or an EPMDocument). In all cases we will try to retrieve an EPMDocument
    * (if WTPart given, then get the one "active" one) and return a String
    * representation of a URL that will download the primary content (normally
    * the CAD File) of the EPMDocument
    *
    * @param     object
    * @return    URL
    * @exception wt.util.WTException
    **/
   public URL getDownloadURL( Object object ) throws WTException {
       //second param is just for nicer exception messages
       EPMDocument epmdoc = this.convertParamIntoEPMDoc(object, "EPMHelper.service.getDownloadURL(Object)");
       if(epmdoc==null) {
           return null;
       }

       //lberger 20100714: at this time just copied the old code from StandardECEPMService without reviewing it
       //just used the already available epmdoc from above

        URL url = null;
        //String filename;
        ContentItem theContent;
        try {
            EPMSepFamilyTable epmsepDoc = null;
            if (epmdoc.isGeneric() || epmdoc.isInstance()){

                QueryResult containedInResult = EPMStructureHelper.service.navigateContainedIn(epmdoc, null, true);
                epmsepDoc = (EPMSepFamilyTable)containedInResult.nextElement();
                //filename = epmsepDoc.getName();
                epmsepDoc = (EPMSepFamilyTable) ContentHelper.service.getContents(epmsepDoc);
                theContent = ContentHelper.getPrimary (epmsepDoc);

                url = RedirectDownload.getPreferredURL((ApplicationData) theContent, epmdoc, true, epmdoc.getCADName());
                }
            else {
                epmdoc = (EPMDocument) ContentHelper.service.getContents(epmdoc);
                theContent = ContentHelper.getPrimary(epmdoc);
                if (theContent != null && theContent instanceof ApplicationData) {
                    url = RedirectDownload.getPreferredURL((ApplicationData) theContent, epmdoc, true, epmdoc.getCADName());
                }
            }
        } catch(PropertyVetoException e) {
            throw new WTException(e);
        } catch(QueryException e) {
            throw new WTException(e);
        } catch(IOException e) {
            throw new WTException(e);
        }
        return url;
   }

   /**
    * Gets the latest iterations of EPMDocuments searched by concatenation of following conditions:
    * 1) wildcard search on name;
    * 2) widcard search on number;
    * 3) wildcard search on IBA "Naming".
    * Each returned object can be:
    * - a working copy if current user owns it;
    * - checked in;
    * - checked out if working copy doesn't belong to current user (original copy). 
    *
    * @param name name of EPMDocument - can be concrete or pattern
    * @param number of EPMDocument - can be concrete or pattern
    * @param naming IBA's value of EPMDocument - can be concrete or pattern
    * @return QueryResult
    * @exception wt.util.WTException
    * @exception java.lang.Exception
    **/
   public QueryResult findEPMDocuments(String name, String number, String naming) throws WTException, Exception {
        QuerySpec latestIterations = getLatestIterationsQuery(name, number, naming); // used as a base for other two queries
        QuerySpec myLatestWorkingCopy = (QuerySpec) latestIterations.clone(); // will be used to get a current user's working copy 
        QuerySpec availableEPMDocuments = (QuerySpec) latestIterations.clone(); // will be used as main query to retrieve EPMDocuments
        int[] indices = new int[] {availableEPMDocuments.getFromClause().getPosition(EPMDocument.class)};
        myLatestWorkingCopy.appendAnd();
        myLatestWorkingCopy.appendWhere(WorkInProgressHelper.getSearchCondition_WRK(EPMDocument.class), indices); // is a working copy
        myLatestWorkingCopy.appendAnd();
        myLatestWorkingCopy.appendWhere(OwnershipHelper.getSearchCondition(EPMDocument.class, SessionHelper.getPrincipal(), true), indices); // owned by current user
        availableEPMDocuments.setAdvancedQueryEnabled(true);
        availableEPMDocuments.appendAnd();
        availableEPMDocuments.appendOpenParen();
        availableEPMDocuments.appendOpenParen();
        availableEPMDocuments.appendWhere(WorkInProgressHelper.getSearchCondition_WRK(EPMDocument.class), indices); // is a working copy
        availableEPMDocuments.appendAnd();
        availableEPMDocuments.appendWhere(OwnershipHelper.getSearchCondition(EPMDocument.class, SessionHelper.getPrincipal(), true), indices); // owned by current user
        availableEPMDocuments.appendCloseParen();
        availableEPMDocuments.appendOr();
        availableEPMDocuments.appendWhere(WorkInProgressHelper.getSearchCondition_CI(EPMDocument.class), indices); // is checked in
        availableEPMDocuments.appendOr();
        availableEPMDocuments.appendOpenParen();
        availableEPMDocuments.appendWhere(WorkInProgressHelper.getSearchCondition_CO(EPMDocument.class), indices); // is checked out
        availableEPMDocuments.appendAnd();
        availableEPMDocuments.appendWhere(new NegatedExpression(new ExistsExpression(myLatestWorkingCopy)), indices); // doesn't exists working copy owned by current user
        availableEPMDocuments.appendCloseParen();
        availableEPMDocuments.appendCloseParen();
        
        OrderBy orderByDocType = new OrderBy(new ClassAttribute(EPMDocument.class, EPMDocument.DOC_TYPE), false);
        availableEPMDocuments.appendOrderBy(orderByDocType, indices);
        OrderBy orderByNumber = new OrderBy(new ClassAttribute(EPMDocument.class, EPMDocument.NUMBER), false);
        availableEPMDocuments.appendOrderBy(orderByNumber, indices);

        return PersistenceHelper.manager.find((StatementSpec) availableEPMDocuments);
   }

   /**
    * Creates query to get the latest iterations of EPMDocuments that name, number or naming are like given in parameters. 
    * 
    * @param name name of EPMDocument - can be concrete or pattern
    * @param number of EPMDocument - can be concrete or pattern
    * @param naming IBA's value of EPMDocument - can be concrete or pattern
    * @return
    * @throws QueryException
    * @throws VersionControlException
    * @throws Exception
    */
	private QuerySpec getLatestIterationsQuery(String name, String number, String naming) throws QueryException, VersionControlException, Exception {
		QuerySpec query = new QuerySpec();
		int epmIndex = query.addClassList(EPMDocument.class, true);
		int[] indices = new int[] { epmIndex };
		query.appendWhere(VersionControlHelper.getSearchCondition(EPMDocument.class, true), indices);

		SearchCondition sc = null;
		// Specify search criteria for Cad Docs
		// add name search condition
		if (StringUtils.isNotBlank(name)) {
			String nameEscaped = escapeForQuery(name);
			boolean escaped = wasEscaped(name, nameEscaped);
			if (escaped) {
				name = nameEscaped;
			}
			name = convertToDatabaseWildcards(name);
			sc = new SearchCondition(EPMDocument.class, EPMDocument.NAME, SearchCondition.LIKE, name, false);
			// Add escape only if we escaped anything
			if (escaped) {
				try {
					sc.setOption("ESCAPE '" + ESCAPE + "'");
				} catch (WTPropertyVetoException e) {
					name = name.replaceAll(ESCAPE + "_", "_");
					sc = new SearchCondition(EPMDocument.class, EPMDocument.NAME, SearchCondition.LIKE, name, false);
				}
			}
			query.appendAnd();
			query.appendWhere(sc, indices);
		}

		// add number search condition
		if (StringUtils.isNotBlank(number)) {
			String numberEscaped = escapeForQuery(number);
			boolean escaped = wasEscaped(number, numberEscaped);
			if (escaped) {
				number = numberEscaped;
			}
			number = convertToDatabaseWildcards(number);
			sc = new SearchCondition(EPMDocument.class, EPMDocument.NUMBER, SearchCondition.LIKE, number, false);
			// Add escape only if we escaped anything
			if (escaped) {
				try {
					sc.setOption("ESCAPE '" + ESCAPE + "'");
				} catch (WTPropertyVetoException e) {
					sc = new SearchCondition(EPMDocument.class, EPMDocument.NUMBER, SearchCondition.LIKE, number, false);
				}
			}
			query.appendAnd();
			query.appendWhere(sc, indices);
		}

		// add iba naming search condition
		// currently only 1 iba is supported
		if (StringUtils.isNotBlank(naming)) {
			naming = convertToDatabaseWildcards(naming);
			List<AttributeDefinition> ibaDefVector = IBAUtil.getIBADefs("NAMING");
			for (AttributeDefinition def : ibaDefVector) {
				// attribute definition id
				Class<? extends AbstractValue> attributeValueClass = IBAUtil.getIBAValueClass(def);
				int valueIndex = query.addClassList(attributeValueClass, true);
				long attributeId = def.getPersistInfo().getObjectIdentifier().getId();
				sc = new SearchCondition(attributeValueClass, "definitionReference.key.id", SearchCondition.EQUAL, attributeId);
				query.appendAnd();
				query.appendWhere(sc, new int[] { valueIndex });
				sc = new SearchCondition(attributeValueClass, "value2", SearchCondition.LIKE, naming);
				query.appendAnd();
				query.appendWhere(sc, new int[] { valueIndex });
				// navigate from ibavalue to part
				TableExpression[] tables = new TableExpression[2];
				String aliases[] = new String[2];
				tables[0] = query.getFromClause().getTableExpressionAt(valueIndex);
				aliases[0] = query.getFromClause().getAliasAt(valueIndex);
				tables[1] = query.getFromClause().getTableExpressionAt(epmIndex);
				aliases[1] = query.getFromClause().getAliasAt(epmIndex);
				SearchCondition correlatedJoin = new SearchCondition(attributeValueClass, "theIBAHolderReference.key.id", EPMDocument.class,
						WTAttributeNameIfc.ID_NAME);
				query.appendAnd();
				query.appendWhere(correlatedJoin, tables, aliases);
			}
		}
		return query;
	}
	
	private boolean wasEscaped(String valueBefore, String valueAfter) {
		return !valueBefore.equals(valueAfter);
	}

	private String convertToDatabaseWildcards(String value) {
		return value.replace('*', '%').replace('?', '_');
	}
	
   /**
    * Get the 'active' EPMDocument (normally a .prt/.asm) for the given part
    * Get all drawings that contain this EPMDocument. From those drawings first try to use the ones
    * that fit exactly to the As-Stored-Baseline of the .prt/.asm, or otherwise use latest iteration of the drw
    *
    * @param part
    * @return
    * @throws WTException
    */
   public Collection<EPMDocument> getAssociatedDrawings(WTPart part) throws WTException {
        
        EPMDocument topObjEpmDoc = getActiveEPMDoc(part);
        if (topObjEpmDoc != null) {
            return DependencyRetrieverHelper.service.getDrawingsFor3D(topObjEpmDoc, true/*getLatestIfNotInAsStoredBL*/);
        } else {
            return null;
        }
        
    }

   /**
    * @param     part
    * @return    Vector (at least empty, never null)
    * @exception wt.util.WTException
    *
    * @deprecated this method always retrieves latest iterations of EPMDocument drawings. That is not always correct.
    **/
   @Deprecated
   public Vector<EPMDocument> getReferencedDrawingsFromPart(WTPart part) throws WTException {
       logger.debug("getReferencedDrawingsFromPart <<< BEGIN");
       Vector<EPMDocument> results = new Vector<EPMDocument>();

       //Get active cad document
       EPMDocument activeEPM = EPMHelper.service.getActiveEPMDoc(part);
       if(activeEPM==null) {
           logger.debug("given " + part + " has no active EPMDoc, leaving method with empty Vector");
           return results;
       }

       EPMDocumentMaster docMaster = (EPMDocumentMaster)activeEPM.getMaster();
       QueryResult qrRefedByLinks = EPMStructureHelper.service.navigateReferencedBy(docMaster, null, false);
       while (qrRefedByLinks.hasMoreElements()) {
           EPMReferenceLink epmReferenceLink = (EPMReferenceLink)qrRefedByLinks.nextElement();
           if (epmReferenceLink.getDepType()!=4) {
               continue; // only display DRW which are of type Drawing model ==4
           }

           EPMDocument epmDocument = null;
           try {
               epmDocument = epmReferenceLink.getReferencedBy();
           } catch (Exception exception) {
               continue;
           }
           if (!VersionControlHelper.isLatestIteration(epmDocument)) {
               continue;  // Only display the latest iteration of each Version branch
           }
           if (WorkInProgressHelper.isWorkingCopy(epmDocument)) {
               continue;  // Don't display the working copy
           }

           if ((epmDocument.getDocType().toString()).equals("CADDRAWING")) {
               results.add(epmDocument);
           }
       }
       logger.debug("getReferencedDrawingsFromPart >>> END");
       return results;
   }

    private WTKeyedHashMap buildCheckinOptionsMap(WTValuedMap co2wrkMap, String comment){
        if (comment==null || "".equals(comment)) {
            comment="Checked-in automatically";
        }
        WTKeyedHashMap toCheckIn = new WTKeyedHashMap(co2wrkMap.size());

        CheckinOption checkinOption = new CheckinOption(comment);
        for (Iterator it = co2wrkMap.entrySet().iterator(); it.hasNext();) {
            WTValuedMap.WTValuedEntry e = (WTValuedMap.WTValuedEntry) it.next();
            toCheckIn.put(e.getValue(), checkinOption);
        }
        return toCheckIn;
    }

   private List<EPMAssociation> getActiveAssociationsOfPart(WTPart part) throws WTException {
       List<EPMAssociation> list = new ArrayList<EPMAssociation>();

       if(part==null) {
           throw new WTException("no part given to method EPMHelper.service.getActiveAssociationsOfPart()");
       }

       logger.debug("getActiveAssociationsOfPart(), incoming part="+PrintHelper.printPersistable(part));
       if(VersionControlHelper.isLatestIteration(part)) {
           logger.debug("navigating via GenericUtilities.getBuildRules(part)");
           //BinaryLink links[] = GenericUtilities.getBuildRules(part);
           ArrayList<EPMBuildRule> links = getBuildRules(part);
           for(int i=0; (links!=null) && (i<links.size()); i++) {
               EPMBuildRule rule = links.get(i);
               logger.debug("found rule=" + rule);

               EPMDocument epmd = (EPMDocument)rule.getBuildSource();
               if(WorkInProgressHelper.isCheckedOut(epmd, SessionHelper.getPrincipal()) && !WorkInProgressHelper.isWorkingCopy(epmd)) {
               //this is an original copy where current user also owns the working copy. Ignore and use the working copy
               } else {
                   Association assoc = new Association(epmd, part, Association.Type.ACTIVE, EPMHelper.isRoleStruct(rule.getBuildType()),
                           EPMHelper.isRoleRep(rule.getBuildType()), EPMHelper.isRoleAttr(rule.getBuildType()));
                   EPMAssociation epmassoc = EPMAssociation.newAssociation(assoc, EPMAssociation.ModificationType.CLEAN, rule);
                   list.add(epmassoc);
               }
           }
       } else {
           logger.debug("navigating via BuildHistory");
           QueryResult qr = PersistenceHelper.manager.navigate(part, BuildHistory.BUILT_BY_ROLE, BuildHistory.class, false);
           while(qr.hasMoreElements()) {
               EPMBuildHistory hist = (EPMBuildHistory)qr.nextElement();
               logger.debug("found hist=" + hist);
               Association assoc = new Association((EPMDocument)hist.getBuiltBy(), part, Association.Type.ACTIVE, EPMHelper.isRoleStruct(hist.getBuildType()),
                       EPMHelper.isRoleRep(hist.getBuildType()), EPMHelper.isRoleAttr(hist.getBuildType()));
               EPMAssociation epmassoc = EPMAssociation.newAssociation(assoc, EPMAssociation.ModificationType.CLEAN, hist);
               list.add(epmassoc);
           }
       }

      return list;
   }
   private List<EPMAssociation> getActiveAssociationsOfEPMDoc(EPMDocument epmdoc) throws WTException {
       List<EPMAssociation> list = new ArrayList<EPMAssociation>();

       if(epmdoc==null) {
          throw new WTException("no epmdoc given to method EPMHelper.service.getActiveAssociationsOfPart()");
       }

       if(VersionControlHelper.isLatestIteration(epmdoc)) {
           logger.debug("navigating via BuildRule");
           QueryResult qr = PersistenceHelper.manager.navigate(epmdoc, EPMBuildRule.BUILD_TARGET_ROLE, EPMBuildRule.class, false);
           while(qr.hasMoreElements()) {
               EPMBuildRule buildRule = (EPMBuildRule)qr.nextElement();
              logger.debug("found hist=" + buildRule);

              Association assoc = new Association(epmdoc, (WTPart) buildRule.getBuildTarget(), Association.Type.ACTIVE,
                    EPMHelper.isRoleStruct(buildRule.getBuildType()), EPMHelper.isRoleRep(buildRule.getBuildType()), 
                    EPMHelper.isRoleAttr(buildRule.getBuildType()));
              EPMAssociation epmassoc = EPMAssociation.newAssociation(assoc, EPMAssociation.ModificationType.CLEAN, buildRule);
              list.add(epmassoc);
           }
       } else {
          logger.debug("navigating via BuildHistory");
          QueryResult qr = PersistenceHelper.manager.navigate(epmdoc, BuildHistory.BUILT_ROLE, BuildHistory.class, false);
          while(qr.hasMoreElements()) {
             EPMBuildHistory hist = (EPMBuildHistory)qr.nextElement();
             logger.debug("found hist=" + hist);

             Association assoc = new Association(epmdoc, (WTPart) hist.getBuilt(), Association.Type.ACTIVE, EPMHelper.isRoleStruct(hist.getBuildType()), 
                   EPMHelper.isRoleRep(hist.getBuildType()), EPMHelper.isRoleAttr(hist.getBuildType()));
             EPMAssociation epmassoc = EPMAssociation.newAssociation(assoc, EPMAssociation.ModificationType.CLEAN, hist);
             list.add(epmassoc);
          }
       }

       return list;
   }

    private List<EPMAssociation> getPassiveAssociationsOfPart(WTPart part) throws WTException {
        List<EPMAssociation> associations = new ArrayList<EPMAssociation>();
        WTCollection parts = new WTArrayList();
        parts.add(part);
        WTKeyedMap partToDocs = StructHelper.service.navigateDescribedBys(parts,EPMDescribeLink.class, false);
        WTList list = (WTList) partToDocs.get(part);

        if (list!=null) {
            for (Object object : list.persistableCollection()) {
                EPMDescribeLink link = (EPMDescribeLink) object;
                Association assoc = new Association((EPMDocument) link.getDescribedBy(), part, Association.Type.PASSIVE, false, false, false);
                EPMAssociation epmassoc = EPMAssociation.newAssociation(assoc, ModificationType.CLEAN, link);
                associations.add(epmassoc);
            }
        }
        return associations;
    }

    private boolean validate(AssociationContainer ac) throws WTException {
        boolean partCheckedOut = WorkInProgressHelper.isCheckedOut(ac.getPart());

        List<EPMAssociation> active = new ArrayList<EPMAssociation>();
        for (EPMAssociation a : ac.associations) {
            if (a.isActive() && (ModificationType.NEW.equals(a.getModificationType()) || ModificationType.CLEAN.equals(a.getModificationType()) )  ) {
                active.add(a);
            }
        }

        return partCheckedOut;
    }

    private List<EPMAssociation> getAllAssociationsOfPart(WTPart givenPart) throws WTException {

        List<EPMAssociation> activeAssociationsOfPart = getActiveAssociationsOfPart(givenPart);
        List<EPMAssociation> passiveAssociationsOfPart = getPassiveAssociationsOfPart(givenPart);

        List<EPMAssociation> allAssociations = new ArrayList<EPMAssociation>(activeAssociationsOfPart.size()+passiveAssociationsOfPart.size());
        allAssociations.addAll(activeAssociationsOfPart);
        allAssociations.addAll(passiveAssociationsOfPart);

        return allAssociations;
    }

    // Substitute objects in the instructions by their working copies
    private void substituteObjects(Collection<Association> instructions, WTValuedMap substMap, WTCollection affectedObjects, WTCollection modifyObjects) throws WTException {
        for (Association ai : instructions) {
            EPMDocument doc = (EPMDocument) substMap.getPersistable(ai.getDoc());
            if (doc == null) {
                doc = ai.getDoc();
            } else {
                ai.setDoc(doc);
            }
            affectedObjects.add(doc);

            if (ai.getAssocType() == Association.Type.ACTIVE) {
                modifyObjects.add(doc);
            }
            if (ai.createPart()) {
                WTPart newPart = ai.getPartDescriptor().getCreatedPart();
                ai.setPart(newPart);
                continue;
            }

            WTPart part = (WTPart) substMap.getPersistable(ai.getPart());
            if (part == null) {
                part = ai.getPart();
            } else {
                ai.setPart(part);
            }
            affectedObjects.add(part);
        }
    }

    /**
     * Returns exactly one actively linked CAD documents which relation type is one of given buildTypes
     * @param part given wtpart
     * @param buildTypes array of desired build types of active links {@link BuildType}
     * @return CAD Document related to given WTPart by active relation with build flags indicated by given buildTypes
     * @throws WTException when more that one 'active' CAD Document is found
     */
    private EPMDocument getActiveEPMDoc(WTPart part, BuildType[] buildTypes) throws WTException {
        //20101018:         added custom logic that can cope with some inconsistent data in the production database:
        //                  if (and only if) we have multiple "active" links, then we ignore those towards .drw/.frm/... EPMDocs (everything that is not a .prt/.asm, i.e. a "3D model")
        //                  i.e. logic still remains: if there are multiple "active" links and more of them points towards .prt or .asm, then we still throw Exception
        //                  throw exception if there are multiple "active" links towards .drw/.frm/... and none of them is a .prt/.asm

        if(logger.isDebugEnabled()) {
            logger.debug("incoming part="+ToolUtils.prettyPrint(part));
            logger.debug("buildTypes=" + Arrays.toString(buildTypes));
        }
        EPMDocument epmdoc = null;
        boolean foundMultipleActive2D = false;
        if (VersionControlHelper.isLatestIteration(part)) {
            ArrayList<EPMBuildRule> links = getBuildRules(part);
            if (links == null) {
                return null;
            }
            logger.debug("found " + links.size() + " EPMBuildRule links");
            for (int i = 0; i < links.size(); i++) {
                EPMBuildRule rule = links.get(i);

                for (int j = 0; j < buildTypes.length; j++) {
                    BuildType btToCheck = buildTypes[j];

                    if(logger.isDebugEnabled()) {
                        logger.debug("btToCheck=" + btToCheck + " rule=" + ToolUtils.prettyPrint(rule) + " buildFlags=" + rule.getBuildType());
                    }

                    if (rule.getBuildType() == buildFlags.get(btToCheck)) {
                        logger.debug("matched build type: " + btToCheck);
                        if (epmdoc != null) { //epmdoc is the EPMDoc that was found in previous loop cycle
                            logger.debug("epmdoc!=null");
                            //there was already another EPMDoc found in a previous loop run that is actively associated on the part
                            //check that we don't have more than 1 .prt/.asm/.. (everything else than .drw)
                            if(isEPMDoc3D(epmdoc)) { //previous EPMDoc found was already 3D
                                EPMDocument tempEPM = (EPMDocument) rule.getBuildSource();
                                logger.debug("in isEPMDoc3D: tempEPM="+ tempEPM);
                                if(isEPMDoc3D(tempEPM)) { //and this one is also 3D
                                    if(WorkInProgressHelper.isCheckedOut(tempEPM, SessionHelper.getPrincipal())
                                            && !WorkInProgressHelper.isWorkingCopy(tempEPM)) {
                                        //this is an original copy where current user also owns the working copy. Ignore and use the working copy
                                    } else {
                                        //what should we do here? It seems that we have a 2nd 3D active EPMDoc (and we're not talking original/working copy here
                                        //previously we threw WTException, but that kills some usecases. So we just continue to use the EPMDoc that was found previously
                                    }
                                } else { //this one is not a 3D
                                    //do nothing, i.e. keep the previous found 3D as the "found" one and continue
                                }
                            } else { //previous found was not a 3D
                                EPMDocument tempEPM = (EPMDocument) rule.getBuildSource();
                                logger.debug("tempEPM="+ tempEPM);
                                if(isEPMDoc3D(tempEPM)) { //and this one is 3D
                                    if(WorkInProgressHelper.isCheckedOut(tempEPM, SessionHelper.getPrincipal()) && !WorkInProgressHelper.isWorkingCopy(tempEPM)) {
                                        //we should also check on the given WTPart, because a given o/c copy of WTPart will not have a link to a wrk copy of EPMDoc.
                                        //in that case we should use the o/c of EPMDoc
                                        if(WorkInProgressHelper.isCheckedOut(part)) {
                                            epmdoc = tempEPM;
                                        } else {
                                            //this is an original copy where current user also owns the working copy. Ignore and use the working copy
                                            logger.debug("ignoring w/c of: " + tempEPM);
                                        }
                                    } else {
                                        //use this 3D one as the "found" one
                                        epmdoc = tempEPM;
                                    }
                                } else { //this one is not 3D
                                    //this is at least the 2nd non-3D one that we find. Ignore
                                    foundMultipleActive2D = true;
                                }
                            }
                            logger.debug("epmdoc=" + epmdoc);
                        } else { //we didn't find any other 'active' link before, use currently found one
                            logger.debug("epmdoc was null");
                            EPMDocument tempEPM = (EPMDocument) rule.getBuildSource();
                            if(WorkInProgressHelper.isCheckedOut(tempEPM, SessionHelper.getPrincipal()) && !WorkInProgressHelper.isWorkingCopy(tempEPM)) {
                                //we should also check on the given WTPart, because a given o/c copy of WTPart will not have a link to a wrk copy of EPMDoc.
                                //in that case we should use the o/c of EPMDoc
                                if(WorkInProgressHelper.isCheckedOut(part)) {
                                    epmdoc = tempEPM;
                                } else {
                                    //this is an original copy where current user also owns the working copy. Ignore and use the working copy
                                    logger.debug("ignoring w/c of: " + tempEPM);
                                }
                            } else {
                                epmdoc = tempEPM;
                                logger.debug("epmdoc=" + epmdoc);
                            }
                        }
                    } else {
                        logger.debug("needed buildType=" + btToCheck + " did not match buildType of link: " + rule.getBuildType());
                    }
                    logger.debug("end of inner loop. epmdoc=" + epmdoc);
                }
            }
            if(epmdoc!=null && (!isEPMDoc3D(epmdoc)) /* the one "found" EPMDoc is a 2D */ && foundMultipleActive2D) {
                throw new WTException("there was more than 1 'active' link to 2D-CADDocuments (no link to 3D) starting from given part=" + part);
            }
        } else {
            logger.debug("navigating via BuildHistory");
            ArrayList<EPMBuildHistory> links = getBuildHistories(part);
            if (links == null) {
                return null;
            }
            logger.debug("found " + links.size() + "EPMBuildHistory links");
            for (int i = 0; i < links.size(); i++) {
                EPMBuildHistory hist = links.get(i);
                logger.debug("found EPMBuildHistory=" + hist);

                for (int j = 0; j < buildTypes.length; j++) {
                    if(logger.isDebugEnabled()) {
                        logger.debug("getActiveEPMDoc(), EPMBuildHistory=" + PrintHelper.printPersistable(hist.getBuiltBy()) + " <---> " + PrintHelper.printPersistable(hist.getBuilt()) + ", buildFlags=" + hist.getBuildType());
                    }
                    if (hist.getBuildType() == buildFlags.get(buildTypes[j])) {
                        logger.debug("matched build type: " + buildTypes[j]);
                        if (epmdoc != null) {
                            //there was already another EPMDoc found in a previous loop run that is actively associated on the part
                            //check that we don't have more than 1 .prt/.asm/.. (everything else than .drw)
                            if(isEPMDoc3D(epmdoc)) { //previous EPMDoc found was already 3D
                                EPMDocument tempEPM = (EPMDocument) hist.getBuiltBy();
                                if(isEPMDoc3D(tempEPM)) { //and this one is also 3D
                                    throw new WTException("there was more than 1 'active' link to 3D-CADDocuments starting from given part=" + part);
                                } else { //this one is not a 3D
                                    //do nothing, i.e. keep the previous found 3D as the "found" one and continue
                                }
                            } else { //previous found was not a 3D
                                EPMDocument tempEPM = (EPMDocument) hist.getBuiltBy();
                                if(isEPMDoc3D(tempEPM)) { //and this one is 3D
                                    //use this 3D one as the "found" one
                                    epmdoc = (EPMDocument) hist.getBuiltBy();
                                } else { //this one is not 3D
                                    //this is at least the 2nd non-3D one that we find. Ignore
                                    foundMultipleActive2D = true;
                                }
                            }
                        } else { //we didn't find any other 'active' link before, use currently found one
                            epmdoc = (EPMDocument) hist.getBuiltBy();
                        }
                    }
                }
            }
            if(epmdoc!=null && (!isEPMDoc3D(epmdoc)) /* the one "found" EPMDoc is a 2D */ && foundMultipleActive2D) {
                throw new WTException("there was more than 1 'active' link to 2D-CADDocuments (no link to 3D) starting from given part=" + part);
            }
        }
        return epmdoc;
    }

    /**
     * Saves the associations of given WTPart in database and checks-in associated objects.
     * @param part WTPart to be associated/disassociated
     * @param toAssociate associations to be created/modified
     * @param toDisassociate associations to be removed
     * @param chekout original copies of EPMDocuments associated/disassociated from given WTPart that need to be checked out (ACTIVE associations)
     * @throws WTException
     * @throws WorkInProgressException
     */
    private WTPart saveAssociations(WTPart part, Collection<Association> toAssociate, Collection<Association> toDisassociate, WTCollection checkout) throws WTException, WorkInProgressException {
        EPMWorkspace ws = EPMWorkspaceHelper.service.findOrCreateWorkspace(EPMWorkspaceHelper.TMP_WS, part.getContainer(),false);
        WTValuedMap orig2wrkCp = new WTValuedHashMap();
        if (toAssociate.size() > 0 || toDisassociate.size() > 0) {
            // keys: originals, value: working copies

            logger.debug("going to checkout: " + checkout);
            orig2wrkCp = wt.epm.workspaces.EPMWorkspaceHelper.manager.checkout(ws, checkout);
            logger.debug("checked out " + checkout!=null?checkout.size():0 + " objects");

            WTCollection affectedObjects = new WTArrayList();
            WTCollection modifyObjects = new WTArrayList();

            substituteObjects(toDisassociate, orig2wrkCp, affectedObjects, modifyObjects);
            logger.debug("going to dis-associate: " + toDisassociate);
            disassociate(ws, toDisassociate);
            logger.debug("dis-associated: " + toDisassociate!=null?toDisassociate.size():0 + " objects");

            substituteObjects(toAssociate, orig2wrkCp, affectedObjects, modifyObjects);
            logger.debug("going to associate: " + toAssociate);
            associate(ws, toAssociate);
            logger.debug("associated: " + toAssociate!=null?toAssociate.size():0 + " objects");

        }
        //TODO AG: consider checking-in "affectedObjects" collection
        orig2wrkCp.put(WorkInProgressHelper.service.originalCopyOf(part), part);
        logger.debug("going to checkin: " + orig2wrkCp);
        part = checkin(ws, orig2wrkCp);
        logger.debug("checked in " + orig2wrkCp!=null?orig2wrkCp.size():0 + " objects");
        return part;
    }
    
    private WTPart checkin(EPMWorkspace ws, WTValuedMap orig2wrkCp) throws WTException {
        WTPart part;
        WTKeyedHashMap toCheckin = buildCheckinOptionsMap(orig2wrkCp,"saveAssociations");

        // CH 07122011 PM01047754:
        WTSet ci = null;
        try{
            ci = wt.epm.workspaces.EPMWorkspaceHelper.manager.checkin(ws, toCheckin);
        } catch (UwgmErrorException uwgme){
            // We have to catch UwgmErrorExceptions here, because it is not serializable
            // AND we want to throw it back to the ECList, not to the UWGM. This type of
            // exception does not belong in the ECList.
            // Instead of UwgmErrorException throw a WTExcption with the exceptions data.
            String message = "A UwgmErrorException has been caught. Please take a look at the method server logs for further details!"; //dummy
            ErrorElement[] elements = uwgme.getErrorElements();
            if (elements != null && elements.length >= 1){
                message = elements[0].getMsgString();
                for (int i = 1; i < elements.length; i++){
                    message += "\n" + elements[i].getMsgString();
                }
            }
            throw new WTException(message);
        }catch (ConflictException cex){
        	LocalizableMessage message = cex.getConflictElements()[0].getMessage();
        	throw new WTException(message.getLocalizedMessage(LocaleUtil.getLocaleFromContext()));
        }

        wt.epm.workspaces.EPMWorkspaceHelper.manager.removeFromWorkspace(ws, ci);//check if it works with a single part

        //send checked in EPMDocs to the publishing
        Collection<EPMDocument> epmdocsToPublish = new ArrayList<EPMDocument>();
        for(Object p : ci.persistableCollection()) {
            logger.debug("checked in: " + p);
            if(p instanceof EPMDocument) {
                epmdocsToPublish.add((EPMDocument)p);
                 logger.debug("sent to publishing: " + p);
            }
        }

        //the following code assumes that there's only one WTPart inside the collection, the rest are EPMDocs
        Iterator<WTPart> checkedInParts = ci.persistableIterator(WTPart.class, true);
        part = checkedInParts.next();
        return part;
    }

    private QuerySpec buildCountEpmDocsQuery(String partRoleIdColumn, Class<? extends BinaryLink> linkClass, long[] ids) throws QueryException {
        QuerySpec qs = new QuerySpec();
        qs.setAdvancedQueryEnabled(true);
        int linkIdx = qs.appendClassList(linkClass, false);
        int[] indexes = new int[]{linkIdx};
        ClassAttribute linkId = new ClassAttribute(linkClass, Persistable.PERSIST_INFO + '.' + PersistInfo.OBJECT_IDENTIFIER + '.' + ObjectIdentifier.ID);
        ClassAttribute partId = new ClassAttribute(linkClass, partRoleIdColumn);

        qs.appendSelect(SQLFunction.newSQLFunction(SQLFunction.COUNT, linkId), indexes, false);
        qs.appendWhere(new SearchCondition(partId, SearchCondition.IN, new ArrayExpression(ids)), new int[]{linkIdx});
        qs.appendGroupBy(new ClassAttribute(linkClass, partRoleIdColumn), indexes, true);
        return qs;
    }

   private EPMDocument convertParamIntoEPMDoc(Object object, String callingMethodName) throws WTException {
       //for nicer exception methods:
       callingMethodName = (callingMethodName==null?"convertParamIntoEPMDoc()":callingMethodName);

       WTPart part = null;
       EPMDocument epmdoc = null;

       if(object instanceof String) {
           //try to convert into WTReference
           try {
               object = RF.getReference((String)object);
           } catch(WTException w) {
               throw new WTException(callingMethodName + " was called with a parameter that could not be converted to a WTReference. Given object was: " + object + " o.class=" + (object==null?"NULL":object.getClass().getName()));
           }
       }

       if(object instanceof WTReference) {
           //try to convert into Persistable
           try {
               object = ((WTReference)object).getObject();
           } catch(Exception w) {
               throw new WTException(callingMethodName + " was called with a parameter that could not be converted to a Persistable");
           }
       }

       //now object should be a Persistable

       if(object instanceof WTPart) {
           part = (WTPart)object;
       } else if(object instanceof EPMDocument) {
           epmdoc = (EPMDocument)object;
       } else {
           throw new WTException(callingMethodName + " was called with a parameter that could not be converted to WTPart or EPMDocument");
       }

       //if part is not null, then something representing a WTPart was given.
       //find the "active" EPMDocument on that given WTPart
       if(part!=null) {
           epmdoc = this.getActiveEPMDoc(part);
       }

       //now we should finally have an EPMDocument
       return epmdoc;
   }

   /**
    * Will escape string for name or number query to avoid oracle
    * db expanding it's wildcards (_ and %). Will also escape the escape
    * character itself.
    * @param queryParam
    * @return
    */
   private String escapeForQuery(String queryParam) {
       queryParam = queryParam.replaceAll(ESCAPE, ESCAPE + ESCAPE);
       queryParam = queryParam.replaceAll("_", ESCAPE + "_");
       queryParam = queryParam.replaceAll("%", ESCAPE + "%");
       return queryParam;
   }

    /**
     * Returns active links for given WTPart
     * @param part WTPart to find its active links
     * @return Collection of EPMBuildRule representing active relation between given part and CAD documents
     */
    private static ArrayList<EPMBuildRule> getBuildRules(WTPart part) {
        ArrayList<EPMBuildRule> buildRules = new ArrayList<EPMBuildRule>();
        try {
            if (VersionControlHelper.isLatestIteration(part)) {
                QueryResult result = PersistenceHelper.manager.navigate(part, EPMBuildRule.BUILD_SOURCE_ROLE, EPMBuildRule.class, false);

                while (result.hasMoreElements()) {
                    Object obj = result.nextElement();
                    if (obj instanceof EPMBuildRule) {
                        buildRules.add((EPMBuildRule) obj);
                    }
                }
            }
        } catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
        }
        return buildRules;
    }

    /**
     * Returns active links for given WTPart
     * @param part WTPart to find its active links
     * @return Collection of EPMBuildRule representing active relation between given part and CAD documents
     */
    private static ArrayList<EPMBuildHistory> getBuildHistories(WTPart part) {
        ArrayList<EPMBuildHistory> buildHistories = new ArrayList<EPMBuildHistory>();
        try {
            if (!VersionControlHelper.isLatestIteration(part)) {
                QueryResult result = PersistenceHelper.manager.navigate(part, EPMBuildHistory.BUILT_BY_ROLE, EPMBuildHistory.class, false);

                while (result.hasMoreElements()) {
                    Object obj = result.nextElement();
                    if (obj instanceof EPMBuildHistory) {
                        buildHistories.add((EPMBuildHistory) obj);
                    }
                }
            }
        } catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
        }
        return buildHistories;
    }


    /**
     * Returns Association object representing available relation
     * between WTPart and EPMDocument
     * @param association Association object representing target relation between WTPart and EPMDocument
     * @return incoming Association if it is 'passive' type {@link Association.Type}, otherwise:
     *         1) CONTIBUTING_CONTENT relation if target EPMDocument is already associated as owner to different WTPart
     *         2) OWNER relation otherwise
     * @throws WTException
     */
    private Association getAvailableAssociation(Association association) throws WTException {
        if (Association.Type.ACTIVE.equals(association.getAssocType())) {
            List<EPMAssociation> activeAssociations = getActiveAssociations(association.getDoc());

            for (EPMAssociation epmassoc : activeAssociations) {
                if (epmassoc.isOwner()) {
                    return EPMAssociation.newAssociation(association.getPart(), association.getDoc(), BuildType.CONTIBUTING_CONTENT);
                }
            }
            return EPMAssociation.newAssociation(association.getPart(), association.getDoc(), BuildType.OWNER);

        }
        return association;
    }

   private boolean isEPMDoc3D(EPMDocument epm) throws WTException {
       if(epm==null) {
           throw new WTException("cannot check isEPMDoc3D() on a null object");
       }
       return StringUtils.endsWithIgnoreCase(epm.getCADName(), ".prt") || StringUtils.endsWithIgnoreCase(epm.getCADName(), ".asm");
   }
   
   
	/**
	 * Get the CONTENT links from provided epmDocument. Internally CONTENT links
	 * are EPMDescribeLinks.
	 * 
	 * @param epmDoc
	 * @return
	 * @throws WTException
	 */
	public WTList getDecribesLinks(EPMDocument epmDoc) throws WTException {

		WTCollection epmDocs = new WTArrayList();
		epmDocs.add(epmDoc);

		WTKeyedMap describeLinksMap = StructHelper.service.navigateDescribes(epmDocs, EPMDescribeLink.class, false);
		WTList linksWTList = (WTList) describeLinksMap.get(epmDoc);
		
		// return an empty list in case there are no links
		if (linksWTList == null) {
			linksWTList = new WTArrayList();
		}

		return linksWTList;
	}

	/**
	 * Gets the WTParts that are connected with provided EPMDocument using CONTENT link (internally EPMDecribesLink).
	 * 
	 * @param epmDoc
	 * @param onlyLatestIterations -flag that specifies that only latest iterations of parts will be returned.
	 * @return
	 * @throws WTException
	 */
	public List<WTPart> getWTPartsThatAreDescibedByGivenEPMDoc(EPMDocument epmDoc, boolean onlyLatestIterations) throws WTException {
		List<WTPart> parts = new ArrayList<WTPart>();

		WTList decribesLinks = getDecribesLinks(epmDoc);
		
		for (Object object : decribesLinks) {
			
			Persistable obj = ((ObjectReference) object).getObject();
			EPMDescribeLink descLink = (EPMDescribeLink) obj;
			
			WTPart wtPart = descLink.getDescribes();
			if (!onlyLatestIterations) {
				parts.add(wtPart);
			} else if (wtPart.isLatestIteration()){
				parts.add(wtPart);
			}
		}

		return parts;
	}
	
	
	/**
	 * Get dependent EPMDocuments.
	 * 
	 * @param pbo
	 * @return CadCollectResult
	 * @throws WTPropertyVetoException
	 * @throws WTException
	 * 
	 * @see https://support.ptc.com/appserver/cs/view/solution.jsp?n=CS81089
	 * 
	 * @deprecated FIXME x22m040 OOTB error with inherited external simplified representations, 
	 * see https://support.ptc.com/apps/case_logger_viewer/auth/ssl/case=12463572
	 */
	@Deprecated
	public CadCollectedResult getCadCollectedResult(final EPMDocument pbo) throws WTPropertyVetoException, WTException {

		// asStored filter criteria for CadCollector
		final EPMAsStoredConfigSpec asStored = EPMAsStoredConfigSpec.newEPMAsStoredConfigSpec(pbo);
		final EPMDocConfigSpec configSpec = new EPMDocConfigSpec();

		if (asStored != null) {
			logger.debug("getCadCollectedResult: using AsStored config.");
			configSpec.setAsStoredConfig(asStored);
			configSpec.setAsStoredActive(true);
		} else {
			logger.debug("getCadCollectedResult: using latest config.");
			configSpec.setLatestActive();
		}

		final NavigationCriteria criteria = NavigationCriteria.newNavigationCriteria();
		criteria.setApplicableType(EPMDocument.class.getName());
		criteria.setConfigSpecs(Arrays.asList(new ConfigSpec[] { configSpec }));

		// collect all required EPMDocuments that belong to the given assembly (epm)
		final WTCollection seeds = CollectionsHelper.singletonWTList(pbo);

		final CadCollector collector = CadCollector.newInstance(seeds, criteria);
		collector.dependents(GatherDependents.ONLY_REQUIRED);

		return collector.collect();
	}
	
	/**
	 * 
	 * Build needed to be performed only when the association is made while the CAD Doc is checked in.
	 * Executed when
	 * -- Edit Association of Checked in CAD Doc from Workspace
	 * -- Auto Association of Checked in CAD Doc from Workspace
	 * Executed not when
	 * -- Edit Association of Checked out CAD Doc from Workspace
	 * -- Auto Association of checked out CAD Doc from Workspace
	 * -- Association using custom Doc UI as we checkout EPMDoc in our custom logic.
	 * 
	 * This logic is similar to triggering 'Build Associated Part' from CAD Doc UI
	 * except that this method won't build the structure recursively.
	 * 
	 * Along with building, this method also synchronizes all IBA's from EPMDoc to Theo. Part.
	 * 
	 * @param buildRule
	 *  - a <code> EPMBuildRule </code> type
	 *  
	 * This method won't throw any WTException. Instead this method logs error message.
	 * Enable debugging to see full stack trace of the error.
	 * In this way, we don't stop the association.
	 * 
	 */
	public void performBuild (EPMBuildRule buildRule) {
		final Persistable epmDoc = buildRule.getRoleAObject();
		final Persistable part = buildRule.getRoleBObject();
		logger.debug("EPMDoc:"+epmDoc);
		logger.debug("part:"+part);
		try {
			if (WorkInProgressHelper.isCheckedOut((Workable) epmDoc)) {
				logger.debug("EPMDoc is checked out. No need to perform build Operation. It is performed upon check in of EPMDoc anyway");
				return;
			}
			logger.debug("EPMDoc is not checked out. So building the WTPart to propogate Attributes...");
			WTCollection objList = new WTArrayList(1);
			objList.add(epmDoc);
			// Build recurisve is not needed here. Just sufficient to build the
			// current node so that attributes are populated.
			BuildHelper.buildFromCAD(objList, null /* no config spec */, false /* build recursive */);
		} catch (WTException wte) {
			if (logger.isDebugEnabled()) {
				wte.printStackTrace();
			}
			logger.error(wte.getLocalizedMessage());
		}
	}
  
}
