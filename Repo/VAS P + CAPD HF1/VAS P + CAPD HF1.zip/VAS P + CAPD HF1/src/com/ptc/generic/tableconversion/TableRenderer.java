package com.ptc.generic.tableconversion;

import java.io.OutputStream;

/**
 * This Interface specifies Classes that implements the Ability to render Tables. Define Methods here that are usefull
 * for all Renderer-Classes. Don't specify Methods that are needed for special Cases like CSV or Excel or ...
 *
 * @see TableRendererFactory
 * @author carsten.trautmann@plussysteme.de
 * @since 2011-03
 */
public interface TableRenderer {

    /**
     * "main" Rendering method.
     * Renders the cell matrix (table) to a given output stream (byte stream). This is the normal use of the Renderer.
     *
     * @param outStream
     * @param tableCells
     * @throws RenderException
     */
    public void renderToStream(OutputStream outStream, Cell[][] tableCells) throws RenderException;
}