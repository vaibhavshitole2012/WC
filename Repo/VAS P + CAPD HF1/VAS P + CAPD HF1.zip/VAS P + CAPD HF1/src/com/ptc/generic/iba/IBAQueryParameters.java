package com.ptc.generic.iba;

import java.util.ArrayList;
import java.util.List;

public class IBAQueryParameters {
	private long ibaDefinitionId[];
	private String ibaHolderClass;
	private long[] ibaHolderIds;
	private String[] ibaValues;
	private List<String> selectAttributes;

	/** 
	 * Get a list of attributes which should be used in the select statement of a query
	 * 
	 * @return a list of attributes
	 */
	public List<String> getSelectAttributes() {
		return selectAttributes;
	}

	/**
	 * Set a list of attributes which should be used in the select statement of a query
	 * 
	 * @param selectAttributes a list of attributes
	 */
	public void setSelectAttributes(List<String> selectAttributes) {
		this.selectAttributes = selectAttributes;
	}

	/**
	 * Set a  attribute which should be used in the select statement of a query
	 * 
	 * @param selectAttributes an attributes
	 */
	public void setSelectAttributes(String selectAttributes) {
		this.selectAttributes.add(selectAttributes);
	}

	/**
	 * Initialize the IBAQueryParameters
	 */
	public IBAQueryParameters() {
		super();
		this.selectAttributes = new ArrayList<String>();
	}

	/**
	 * Get an array of IBA Definition IDs
	 * 
	 * @return an array of IBA Definition Ids
	 */
	public long[] getIbaDefinitionId() {
		return ibaDefinitionId;
	}

	/**
	 * Set an array of IBA Definition IDs
	 * 
	 * @param ibaDefinitionId an array of IBA Definition IDs
	 */
	public void setIbaDefinitionId(long ibaDefinitionId) {
		this.ibaDefinitionId = new long[] { ibaDefinitionId };
	}

	/**
	 * Get the class of the IBAHolder e.g. wt.part.WTPart
	 * 
	 * @return the class of the IBAHolder
	 */
	public String getIbaHolderClass() {
		return ibaHolderClass;
	}

	/**
	 * Set the class of the IBAHolder e.g. wt.part.WTPart
	 * 
	 * @param ibaHolderClass the class of the IBAHolder
	 */
	public void setIbaHolderClass(String ibaHolderClass) {
		this.ibaHolderClass = ibaHolderClass;
	}

	/**
	 * Get an array of IBA values
	 * 
	 * @return an array of IBA values
	 */
	public String[] getIbaValues() {
		return ibaValues;
	}

	/**
	 * Set an array of IBA values
	 * 
	 * param an array of IBA values
	 */
	public void setIbaValues(String[] ibaValues) {
		this.ibaValues = ibaValues;
	}

	/**
	 * Get an array of IBA Holder Ids
	 * 
	 * @return an array of IBA Holder Ids
	 */
	public long[] getIbaHolderIds() {
		return ibaHolderIds;
	}

	/**
	 * Set an array of IBA Holder Ids
	 * 
	 * @param ibaHolderIds an array of IBA Holder Ids
	 */
	public void setIbaHolderIds(long[] ibaHolderIds) {
		this.ibaHolderIds = ibaHolderIds;
	}

	/**
	 *  Set an array of IBA Definition Ids
	 * 
	 * @param ibaDefinitionId  an array of IBA Definition Ids
	 */
	public void setIbaDefinitionId(long[] ibaDefinitionId) {
		this.ibaDefinitionId = ibaDefinitionId;
	}

}