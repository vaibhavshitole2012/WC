/** 

Factory class for the creation of a table renderer configuration object.

@author Lothar Germund, PLUS-Systeme GmbH
@since 20.10.2010
*/

package com.ptc.generic.tableconversion;

/**
 * @author DVORGER
 *
 */
public interface TableConfigurationFactory  {

    /**
     * Creates a table configuration object.
     *
     * @param renderType
     * @return renderer object
     * @throws RenderException
     */
    public TableConfiguration create(String renderType) throws RenderException;
}
