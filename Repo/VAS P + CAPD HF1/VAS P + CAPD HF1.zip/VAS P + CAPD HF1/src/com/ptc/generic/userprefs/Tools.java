/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ptc.generic.userprefs;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.ptc.generic.userprefs.UserPrefsHelper;

import wt.session.SessionHelper;
import wt.util.WTException;


/**
 * Command line tools to aid development regarding user preferences
 * 
 * Usage: 
 * - windchill com.ptc.generic.userprefs.Tools update all
 * - windchill com.ptc.generic.userprefs.Tools set <prefname> <value>
 *   e.g.: windchill com.ptc.generic.userprefs.Tools set USE_NEW_REFRESHLOGIC true
 * - windchill com.ptc.generic.userprefs.Tools delete <prefname>
 * - windchill com.ptc.generic.userprefs.Tools definitionNames <client name> <category name> [true/false]
 * 
 * 
 * @author Marek Piechut <mpiechut@ptc.com>, additions by Lorenz Berger <lberger@ptc.com>
 */
public class Tools {

	private static List<UserPreference> NO_UPDATE_ON_PREFS;
	
	
	// add userpreferences which should not be updated by "update all" command
	// fix for VW_ECA-1774
	static{
		NO_UPDATE_ON_PREFS = new ArrayList<UserPreference>();
		NO_UPDATE_ON_PREFS.add(UserPreference.PRE_SELECT_KVS_CHECKBOX_IN_CHANGE_WIZARD);
		NO_UPDATE_ON_PREFS.add(UserPreference.PRE_SELECT_KVS_CHECKBOX_IN_UBERGABE_WIZARD);
	}

	
    public static void main(String[] args) {
        if (args.length > 1 && "update".equals(args[0]) && "all".equals(args[1])) {
            updatePreferenceDefinitions();
        } else if(args.length==3 && "set".equals(args[0])) {
      	  	setPref(args[1], args[2]);
        } else if( args.length == 2 && "delete".equals(args[0])){
        	deleteUserPref( args[1]);
        } else if(args.length>=3 && "definitionNames".equalsIgnoreCase(args[0])) {
        	printPrefDefNames(args);
        } else {
            printUsage();
        }
    }

    /**
     * 
     * @param args 0: is always 'definitionNames'; 1: client name; 2: category name; optional 3: 'true/false'
     * 
     */
    private static void printPrefDefNames(final String args[]) {
    	//we can assume that args[] has at least 3 elements, otherwise we'd never get in here
    	final String clientName = args[1];
    	final String categoryName = args[2];
    	boolean onlyUserInstances = false;
    	if(args.length==4 && args[3]!=null) {
    		onlyUserInstances = Boolean.parseBoolean(args[3]);
    	}
    	try {
        	Collection<String> prefNames = UserPrefsHelper.service.getUserPreferenceNames(null /*prefix*/, 
        			clientName,
        			UserPrefCategory.valueOf(categoryName), 
        			onlyUserInstances?SessionHelper.getPrincipal():null);
        	System.out.println("found: " + prefNames);
    	} catch(WTException w) {
    		w.printStackTrace();
    	}
    	
    }
    
    private static void updatePreferenceDefinitions() {

        for (UserPreference pref : UserPreference.class.getEnumConstants()) {
            try {
                if( !NO_UPDATE_ON_PREFS.contains(pref)){
                	System.out.println("Updating default value for: " + pref.getName());
                	UserPrefsManager.INSTANCE.updateDefaultValue(pref);
                }/*else{
                	System.out.println("No update for: " + pref.getName() + " It is on the list for not updatable userpreferences.");
                }*/
                
            } catch (Exception ex) {
                System.err.println(ex);
            }
        }

        System.out.println("Preference definitions updated");
    }
    
    private static void setPref(String prefName, String value) {
   	 try {
	   	 UserPreference pref = UserPreference.valueOf(prefName);
	   	 UserPrefsManager.INSTANCE.setUserPreference(pref, value);
	   	 
	   	 String newValue = UserPrefsManager.INSTANCE.getUserPreference(pref);
	   	 System.out.println("new value for '" + pref.getName() + "' is: " + newValue);
   	 } catch(Exception e) {
   		 e.printStackTrace();
   	 }
    }

    private static void printUsage() {
        System.out.println("Updates Windchill database default value of user preference with default declared in UserPreference enum class");
        System.out.println("Usage: windchill com.ptc.generic.userprefs.Tools update all");
        System.out.println();
        System.out.println("   or: windchill com.ptc.generic.userprefs.Tools set <prefname> <value>");
        System.out.println(" e.g.: windchill com.ptc.generic.userprefs.Tools set USE_NEW_REFRESHLOGIC true");
        System.out.println();
        System.out.println("Deleting a User Preference:");
        System.out.println("Usage: windchill com.ptc.generic.userprefs.Tools delete <prefname>");
        System.out.println();
        System.out.println("Printing PreferenceDefinition names:");
        System.out.println("Usage: windchill com.ptc.generic.userprefs.Tools definitionNames <client name> <category name> [true/false]");
        System.out.println("       last param defines if only PreferenceDefinitions should be returned that user has instances of");
        System.out.println(" e.g.: windchill com.ptc.generic.userprefs.Tools definitionNames ECA ECA_VIEW [true/false]");
    }
    
    private static void deleteUserPref(String prefName){
    	try {
			UserPrefsManager.INSTANCE.deleteUserPreference( UserPreference.valueOf(prefName));
	    	System.out.print("UserPref " + prefName + " deleted");
		} catch (Exception e) {
			e.printStackTrace();
		}
    }
}
