package com.ptc.generic.epm;

// This is auto generated class.
// DO NOT EDIT!
// It will be regenerated from Standard..Service on each compilation!

public class EPMWorkspaceHelper {
	public static String  TMP_WS = "KB_TEMP_WS";
    /**
     * <p><b>RMI proxy to access remote service or direct reference if on server.</b></p>
     * Service that provides methods for EPMWorkspace handling. Use like this: VWEPMWorkspaceHelper.service.someMethod().
     **/
    public static final com.ptc.generic.epm.EPMWorkspaceService service = wt.services.ServiceFactory.getService(com.ptc.generic.epm.EPMWorkspaceService.class);

}

