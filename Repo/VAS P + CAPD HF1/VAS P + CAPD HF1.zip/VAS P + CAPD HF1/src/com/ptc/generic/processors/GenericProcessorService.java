/*
 * GenericProcessorService.java
 *
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.ptc.generic.processors;

import java.util.Properties;
import java.util.Vector;
import wt.templateutil.processor.HTTPState;
import wt.templateutil.processor.ProcessorService;
import wt.util.LocalizableMessage;

/**
 * This class implements all abstract methods from ProcessorService. 
 * So if you need your own subclass from ProcessorService you just extend from this one.
 * If you do so you wont take care to implement the abstract methods.
 * @author Simone Graf
 */
public class GenericProcessorService implements ProcessorService {
    
    private HTTPState theState = null;
    
   /**
     * @deprecated Method getState is deprecated
     */

    public HTTPState getState()
    {
        return theState;
    }

    /**
     * @deprecated Method setState is deprecated
     */

    public void setState(HTTPState httpstate)
    {
        theState = httpstate;
    }

    /**
     * @deprecated Method getContextAction is deprecated
     */

    public String getContextAction()
    {
        try
        {
            return getState().getContextAction();
        }
        catch(NullPointerException nullpointerexception)
        {
            return null;
        }
    }

    /**
     * @deprecated Method setContextAction is deprecated
     */

    public void setContextAction(String s)
    {
        getState().setContextAction(s);
    }

    /**
     * @deprecated Method getContextObj is deprecated
     */

    public Object getContextObj()
    {
        try
        {
            return getState().getContextObj();
        }
        catch(NullPointerException nullpointerexception)
        {
            return null;
        }
    }

    /**
     * @deprecated Method setContextObj is deprecated
     */

    public void setContextObj(Object obj)
    {
        getState().setContextObj(obj);
    }

    /**
     * @deprecated Method getContextClassName is deprecated
     */

    public String getContextClassName()
    {
        try
        {
            return getState().getContextClassName();
        }
        catch(NullPointerException nullpointerexception)
        {
            return null;
        }
    }

    /**
     * @deprecated Method setContextClassName is deprecated
     */

    public void setContextClassName(String s)
    {
        getState().setContextClassName(s);
    }

    /**
     * @deprecated Method getContextProperties is deprecated
     */

    public Properties getContextProperties()
    {
        try
        {
            return getState().getContextProperties();
        }
        catch(NullPointerException nullpointerexception)
        {
            return null;
        }
    }

    /**
     * @deprecated Method setContextProperties is deprecated
     */

    public void setContextProperties(Properties properties)
    {
        getState().setContextProperties(properties);
    }

    /**
     * @deprecated Method getResponseExceptions is deprecated
     */

    public Vector getResponseExceptions()
    {
        try
        {
            return getState().getResponseExceptions();
        }
        catch(NullPointerException nullpointerexception)
        {
            return null;
        }
    }

    /**
     * @deprecated Method setResponseExceptions is deprecated
     */

    public void setResponseExceptions(Vector vector)
    {
        getState().setResponseExceptions(vector);
    }

    /**
     * @deprecated Method getResponseFooters is deprecated
     */

    public Vector getResponseFooters()
    {
        try
        {
            return getState().getResponseFooters();
        }
        catch(NullPointerException nullpointerexception)
        {
            return null;
        }
    }

    /**
     * @deprecated Method setResponseFooters is deprecated
     */

    public void setResponseFooters(Vector vector)
    {
        getState().setResponseFooters(vector);
    }

    /**
     * @deprecated Method getResponseHeaders is deprecated
     */

    public Vector getResponseHeaders()
    {
        try
        {
            return getState().getResponseHeaders();
        }
        catch(NullPointerException nullpointerexception)
        {
            return null;
        }
    }

    /**
     * @deprecated Method setResponseHeaders is deprecated
     */

    public void setResponseHeaders(Vector vector)
    {
        getState().setResponseHeaders(vector);
    }

    /**
     * @deprecated Method getResponseMessages is deprecated
     */

    public Vector getResponseMessages()
    {
        try
        {
            return getState().getResponseMessages();
        }
        catch(NullPointerException nullpointerexception)
        {
            return null;
        }
    }

    /**
     * @deprecated Method setResponseMessages is deprecated
     */

    public void setResponseMessages(Vector vector)
    {
        getState().setResponseMessages(vector);
    }

    /**
     * @deprecated Method getResponseString is deprecated
     */

    public String getResponseString()
    {
        try
        {
            return getState().getResponseString();
        }
        catch(NullPointerException nullpointerexception)
        {
            return null;
        }
    }

    /**
     * @deprecated Method setResponseString is deprecated
     */

    public void setResponseString(String s)
    {
        getState().setResponseString(s);
    }

    /**
     * @deprecated Method getStatus is deprecated
     */

    public int getStatus()
    {
        try
        {
            return getState().getStatus();
        }
        catch(NullPointerException nullpointerexception)
        {
            return 0;
        }
    }

    /**
     * @deprecated Method setStatus is deprecated
     */

    public void setStatus(int i)
    {
        getState().setStatus(i);
    }

    /**
     * @deprecated Method getFormData is deprecated
     */

    public Properties getFormData()
    {
        try
        {
            return getState().getFormData();
        }
        catch(NullPointerException nullpointerexception)
        {
            return null;
        }
    }

    /**
     * @deprecated Method setFormData is deprecated
     */

    public void setFormData(Properties properties)
    {
        getState().setFormData(properties);
    }

    /**
     * @deprecated Method getQueryData is deprecated
     */

    public Properties getQueryData()
    {
        try
        {
            return getState().getQueryData();
        }
        catch(NullPointerException nullpointerexception)
        {
            return null;
        }
    }

    /**
     * @deprecated Method setQueryData is deprecated
     */

    public void setQueryData(Properties properties)
    {
        getState().setQueryData(properties);
    }

    /**
     * @deprecated Method addToResponseExceptions is deprecated
     */

    public void addToResponseExceptions(Exception exception)
    {
    }

    /**
     * @deprecated Method addToResponseMessages is deprecated
     */

    public void addToResponseMessages(LocalizableMessage localizablemessage)
    {
    }

    /**
     * @deprecated Method addToResponseHeaders is deprecated
     */

    public void addToResponseHeaders(LocalizableMessage localizablemessage)
    {
    }

    /**
     * @deprecated Method addToResponseFooters is deprecated
     */

    public void addToResponseFooters(LocalizableMessage localizablemessage)
    {
    }
    
}
