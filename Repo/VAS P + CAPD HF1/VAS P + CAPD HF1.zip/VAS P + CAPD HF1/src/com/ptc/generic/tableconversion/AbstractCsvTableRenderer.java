/** 

Class with CSV table render implementation.

@author of extensions for universal rendering: Lothar Germund, PLUS-Systeme GmbH
@since 20.10.2010
*/
package com.ptc.generic.tableconversion;

import org.apache.log4j.Logger;

import java.io.*;

abstract public class AbstractCsvTableRenderer extends AbstractExportTableRenderer
{
     
    private CsvConfigurationImpl config;
    private static final Logger logger = Logger.getLogger(CsvConfigurationImpl.class);
    private static final Logger logPerformance = Logger.getLogger(CsvConfigurationImpl.class + "#PERFORMANCE");


    /**
     * Don't use this constructor, so it's private and it throws an exception.
     * Avoid construction without a configuration.
     * 
     * @throws com.ptc.generic.tableconversion.RenderException
     */
    private AbstractCsvTableRenderer() throws com.ptc.generic.tableconversion.RenderException {
        super(BASICAPI_STREAMREF);
        throw new com.ptc.generic.tableconversion.RenderException("Don't use the default constructor, use the one with config parameter");
    }
    
    
    
    /**
     * Constructor which has a filled configuration parameter.
     * 
     * @param config
     */
    public AbstractCsvTableRenderer(CsvConfigurationImpl config) {
        super(BASICAPI_STREAMREF);
        this.config = config;
    }

    /**
     * Getter for TableConfiguration
     */
    public CsvConfigurationImpl getTableConfiguration() {
        return this.config;
    }


    /**
     * String filter function for configured delimiter and quote characters.
     * Filters only what needed, depends on delimiter/quote setting.
     * 
     * @param source
     * @return
     */
    private String filterDelimiter(String source) {
        String result = source;

        // replace quote " --> ' other quotes to blank
        char quote = config.getQuote();
        char replaceQuote;
        if (quote == '\"') {
            replaceQuote = '\'';
        } else {
            replaceQuote = ' ';
        }
        if (quote != ' ') {
            result = result.replace(quote, replaceQuote);
        }

        // replace delimiter ';' --> ',' other delimiter to ';' to avoid new cells
        if (quote == ' ') {
            char delimiter = config.getDelimiter();
            if (delimiter == ';')
                result = result.replace(delimiter, ',');
            else
                result = result.replace(delimiter, ';');
        }

        return result;
    }

    
    /**
     * Initializing for CSV rendering process.
     * Set additional configuration data and optionally filters/translates the cells.
     * 
     * @param tableCells
     */
    private void initRendering(com.ptc.generic.tableconversion.Cell[][] tableCells) {
        int rowCount = trimRowcount(tableCells);
        int columnCount = (rowCount > 0) ? tableCells[0].length : 0;

        config.setRows(rowCount);
        config.setColumns(columnCount);
        // set "must have" filters
        int cellFilter = config.getCellFilter();
        if ((cellFilter & AbstractExportTableConfiguration.CELLFILTER_SPEC_ATTRIBUTES) != 0) {
            cellFilter |= AbstractExportTableConfiguration.CELLFILTER_HEADER_ROW;
            cellFilter |= AbstractExportTableConfiguration.CELLFILTER_DEFAULT;
        }
        config.setCellFilter(cellFilter);

        boolean withHeader = ((cellFilter & AbstractExportTableConfiguration.CELLFILTER_HEADER_ROW) != 0);

        if (rowCount > 0) {
            // always one filter is set
            // filter/translate cell values, optionally also the quote char

            String query = config.getQueryName();
            com.ptc.generic.tableconversion.Cell[] headerRow = tableCells[0];

            // if header filter is set then header row contains the column names at this point, so the header cells must be String types

            // filter data cells (may contain rows with null cells),
            // the filter function contains the quote/delimiter filter
            for (int row = (withHeader) ? 1 : 0; row < rowCount; row++) { // data rows
                com.ptc.generic.tableconversion.Cell[] currRow = tableCells[row];
                for (int i = 0; i < columnCount; i++) {
                    com.ptc.generic.tableconversion.Cell currCell = currRow[i];
                    if (currCell != null) {
                        String value = (String) filterCell(currCell.getValue(), (String) (headerRow[i].getValue()), true); // header cell is used for formatting options
                        currCell.setValue(value);
                    }
                }
            }

            if (withHeader) {
                // transform header row (filtered display names)
                for (int i = 0; i < columnCount; i++) {
                    String name = this.getHeaderName(headerRow[i].getValue(), query);//AWQueryHelper.getDisplayNameForAttribute((String) (headerRow[i].getValue()), query);
                    name = (String) filterCell(name, name, false);
                    headerRow[i].setValue(name);
                }
            }
        }
    }

    
    /**
     * Renders the cell matrix (table) to a given output stream (byte stream).
     * 
     * @param outStream
     * @param tableCells
     * @throws com.ptc.generic.tableconversion.RenderException
     */
    private void renderLocal(OutputStream outStream, com.ptc.generic.tableconversion.Cell[][] tableCells) throws com.ptc.generic.tableconversion.RenderException {
        OutputStreamWriter sw = null;
        try {
            sw = new OutputStreamWriter(outStream, config.getEncoding());
        } catch (UnsupportedEncodingException e) {
            throw new com.ptc.generic.tableconversion.RenderException(e.getMessage());
        }

        try {
            int bufferCount = 0;
            char quote = config.getQuote();
            int rowCount = config.getRows();

            for (int x = 0; x < rowCount; x++) {
                com.ptc.generic.tableconversion.Cell[] row = tableCells[x];

                for (int y = 0; y < row.length; y++) {
                    bufferCount++;
                    com.ptc.generic.tableconversion.Cell cell = row[y];

                    StringBuffer columnContent = new StringBuffer();
                    if (cell != null) {
                        if (quote != ' ')
                            columnContent.append(quote);
                        String value = (String) cell.getValue();
                        if (value != null) {
                            columnContent.append(value);
                        }
                        if (quote != ' ')
                            columnContent.append(quote);
                        if (y < (row.length - 1)) {
                            columnContent.append(config.getDelimiter());
                        }
                    }
                    sw.write(columnContent.toString());
                }

                sw.write("\n");
                if (bufferCount >= config.getBufferSize()) {
                    // sw.flush(); // on HTTP streams flush causes a close of the underlaying OutputStream (Browser finishes)
                    bufferCount = 0;
                }
            }

            sw.flush();
        } catch (IOException e) {
            throw new com.ptc.generic.tableconversion.RenderException(e.getMessage());
        }
    }



    /**
     * "main" method.
     * Renders the cell matrix (table) to a given output stream (byte stream). One method is basic and the others derived from it.
     * Depending from the construction parameter implement this method or call only basicRenderToStreamSourceArray(...).
     * 
     * @param outStream
     * @param tableCells
     * @throws com.ptc.generic.tableconversion.RenderException
     */
    public void renderToStream(OutputStream outStream, com.ptc.generic.tableconversion.Cell[][] tableCells) throws com.ptc.generic.tableconversion.RenderException {
        long start = System.currentTimeMillis();
        initRendering(tableCells);
        long startCsv = System.currentTimeMillis();

        try {
            // the work
            renderLocal(outStream, tableCells);
        } catch (com.ptc.generic.tableconversion.RenderException ex) {
            logger.error("renderToStream(): can not render", ex);
        }

        if (logPerformance.isDebugEnabled()) {
            try {
                long stop = System.currentTimeMillis();
                long timePerHundredEntries;
                logPerformance.debug("renderToStream(): Runtime for init render part= " + (startCsv - start));
                logPerformance.debug("renderToStream(): Runtime for csv render part= " + (stop - startCsv));
                timePerHundredEntries = ((stop - start) * 100) / tableCells.length;
                logPerformance.debug("renderToStream(): Average runtime for 100 entries= " + timePerHundredEntries);
            } catch (Throwable t) {
            }
        }
    }

    
    
    /**
     * "main" method.
     * Renders the cell matrix (table) and returns a byte array. One method is basic and the others derived from it.
     * Depending from the construction parameter implement this method or call only basicRenderToArraySourceStream(...).
     * 
     * @param tableCells
     * @return
     * @throws com.ptc.generic.tableconversion.RenderException
     */
    public byte[] renderToArray(com.ptc.generic.tableconversion.Cell[][] tableCells) throws com.ptc.generic.tableconversion.RenderException {
        return basicRenderToArraySourceStream(tableCells);
    }

    
    
    /**
     * Renders the cell matrix (table) and returns a byte array output stream.
     * Better usage: Use renderToArrayStream (same parameters) or renderToArray with byte[] return value.
     * 
     * @param tableCells
     * @return
     * @throws com.ptc.generic.tableconversion.RenderException
     */
    public ByteArrayOutputStream renderTable(com.ptc.generic.tableconversion.Cell[][] tableCells) throws com.ptc.generic.tableconversion.RenderException {
        return renderToArrayStream(tableCells);
    }

}
