package com.ptc.generic.xml;

import java.io.File;

import javax.xml.XMLConstants;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

import org.apache.commons.lang.StringUtils;
import org.xml.sax.SAXException;

import wt.util.WTException;


/**
 * Static utility methods for XML Files
 * 
 * Example usage:
 * final Unmarshaller unmarshaller = VWXMLUtils.newUnMarshaller("com.ptc.projectplan.xmlelements", ".\vwConfig\projectplan\importPlan.xsd");
 * Object rootElement = VWXMLUtils.unmarshal(unmarshaller, ".\testdata\com\ptc\projectplan\plan1.xml");
 * 
 * @author lberger
 * @since ECA5.0 P1-2015
 */
public class VWXMLUtils {
	
	/**
	 * Creates a new Unmarshaller instance
	 * 
	 * @param packageName must not be null
	 * @param schemaFile full patch to schema file; optional
	 * @return
	 * @throws WTException
	 */
	public static Unmarshaller newUnMarshaller(final String packageName, final String schemaFile) throws WTException {

		if (packageName == null) {
			throw new WTException("packageName == null");
		}

		try {
			// create JAXBContext and Unmarshaller
			final JAXBContext jaxbContext = JAXBContext.newInstance(packageName);
			final Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();

			if (schemaFile != null) {
				// Sets schema file for XML validation during reading.
				final SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
				if(!StringUtils.isEmpty(schemaFile)) {
					//check if given schemaFile exists
					File f = new File(schemaFile);
					if(!f.exists()) {
						throw new WTException("cannot read schemaFile: " + schemaFile);
					}
					final Schema schema = sf.newSchema(f);
					unmarshaller.setSchema(schema);
				}
			}
			return unmarshaller;
		} catch(JAXBException e) {
			throw new WTException(e);
		} catch(SAXException e) {
			throw new WTException(e);
		}
	}
	
	/**
	 * Creates a new DefaultValidationEventHandler, sets it on the given Unmarshaller, and returns it
	 * 
	 * @param unmarshaller
	 * @return
	 */
	public static VWDefaultValidationEventHandler addDefaultValidationEventHandler(final Unmarshaller unmarshaller) throws WTException {
		VWDefaultValidationEventHandler eh = VWDefaultValidationEventHandler.newVWDefaultValidationEventHandler();
		try {
			unmarshaller.setEventHandler(eh);
		} catch (JAXBException e) {
			throw new WTException(e);
		}
		return eh;
	}
	
	/**
	 * Unmarshalls the File represented by the given filename with the given Unmarshaller.
	 * 
	 * @param unmarshaller
	 * @param xmlFileName
	 * @return
	 * @throws WTException
	 */
	public static Object unmarshal(final Unmarshaller unmarshaller, final String xmlFileName) throws WTException {
		File xmlFile = new File(xmlFileName);
		if(!xmlFile.exists()) {
			throw new WTException("cannot read xmlFile: " + xmlFileName);
		}
		try {
			return unmarshaller.unmarshal(xmlFile);
		} catch (JAXBException e) {
			throw new WTException(e);
		}
	}
}
