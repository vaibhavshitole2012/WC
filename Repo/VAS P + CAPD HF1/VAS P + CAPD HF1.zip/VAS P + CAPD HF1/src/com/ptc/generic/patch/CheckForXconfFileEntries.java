/* 
 * bcwti
 *
 * Copyright (c) 2012 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */
/**
 * 
 */
package com.ptc.generic.patch;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/**
 * @author Benjamin Mueller (bmueller@ptc.com)
 * @version 20140625
 * @see VW_ECA-18345
 * @since 5.0
 * 
 *        Tool to check the component.xml for missing xconf file entries.
 */
public class CheckForXconfFileEntries {

	public static final String svnRev = "$Revision: 1.1.1.3 $ $Date: 2015/12/10 21:01:36IST $";
	public static final String svnUrl = "$URL: http://127.0.0.1/svn/KB_04082016/components/Generic-Utilities/src/com/ptc/generic/patch/CheckForXconfFileEntries.java $";

	private static final Charset ENCODING = Charset.forName("cp1252");

	private CheckForXconfFileEntries() {
	}

	/**
	 * @param args
	 *            0 = diff list, 1 = component.xml
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {

		if (args == null || args.length != 2) {
			throw new IllegalArgumentException();
		}

		// read diff list and store .xconf entries
		final Set<String> xconfEntries = new HashSet<String>();

		String currentLine = null;
		BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(args[0]), ENCODING));

		while ((currentLine = br.readLine()) != null) {

			currentLine = currentLine.trim().toLowerCase();
			if (currentLine.endsWith(".xconf")) {
				int idx = currentLine.lastIndexOf("/");
				if (idx == -1) {
					idx = currentLine.lastIndexOf("\\");
				}
				xconfEntries.add(currentLine.substring(idx + 1));
			}
		}
		br.close();

		if (xconfEntries.isEmpty()) {
			System.out.println("CheckForXconfFileEntries: OK");
			return;
		}

		// read component.xml
		br = new BufferedReader(new InputStreamReader(new FileInputStream(args[1]), ENCODING));

		while ((currentLine = br.readLine()) != null) {

			// check xconf tasks against xconf files from diff list
			currentLine = currentLine.trim().toLowerCase();
			if (currentLine.startsWith("<xconf ") && currentLine.contains(" mode=\"site\" ") && currentLine.contains(".xconf")) {
				for (final Iterator<String> it = xconfEntries.iterator(); it.hasNext();) {
					if (currentLine.contains(it.next())) {
						// remove xconf file if there is an entry inside
						// component.xml
						it.remove();
						break;
					}
				}
			}
		}
		br.close();

		if (xconfEntries.isEmpty()) {
			System.out.println("CheckForXconfFileEntries: OK");
		} else {
			throw new Exception("Missing entry for: " + xconfEntries.toString());
		}
	}
}
