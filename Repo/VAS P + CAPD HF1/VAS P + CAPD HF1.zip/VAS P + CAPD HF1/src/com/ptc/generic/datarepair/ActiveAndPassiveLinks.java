package com.ptc.generic.datarepair;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.SortedMap;
import java.util.logging.Level;
import java.util.logging.Logger;

import wt.epm.EPMDocument;
import wt.epm.build.EPMBuildHistory;
import wt.epm.structure.EPMDescribeLink;
import wt.fc.PersistenceServerHelper;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.org.WTPrincipal;
import wt.part.WTPart;
import wt.util.WTContext;
import wt.util.WTException;
import wt.util.WTProperties;
import wt.vc.VersionControlException;
import wt.vc.Versioned;
import wt.vc.wip.WorkInProgressHelper;

import com.ptc.generic.AuthHelper;

public class ActiveAndPassiveLinks implements RemoteAccess {

    private static final String PARAM_DELETE = "-del";
    private static final String PARAM_FILE = "-file";
    private static final String PARAM_VERSION = "-version";
    private static final String PARAM_ITERATION = "-iteration";
    private static BufferedWriter logWriter;

    public static void main(String args[]) {

        WTContext.init(args);
        String logFile = "logging.txt";
        ActiveAndPassiveLinks ac = new ActiveAndPassiveLinks();
        ac.initLogFile(logFile);


        if (args == null || args.length == 0) {
            printUsage();
        } else {
            List<EPMDescribeLink> duplicateActiveAndPassiveLinks = null;

            try {
                WTPrincipal user = AuthHelper.authenticateUser(args);
                if (user == null) {
                    //System.out.println("Could not authenticate.");
                } else {
                    //System.out.println("authenticated as: " + user.getName());
                }
                duplicateActiveAndPassiveLinks = handleDifferentInputOptions(args);
            } catch (WTException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

            if (args.length >= 7 && args[6].equals(PARAM_DELETE)) {
                try {
                    logEverywhere(deleteEPMDescribeLinks(duplicateActiveAndPassiveLinks));

                } catch (WTException ex) {
                    Logger.getLogger(ActiveAndPassiveLinks.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        ac.closeLogFile();
    }
    
    private static void printUsage() {
    	
    	System.out.println("The parameter \"oid\" has additionally to include the object defintion e.g.:");
    	System.out.println("wt.part.WTPart:12345678\n");
        System.out.println("ActiveAndPassiveLinks -u username -p password " + PARAM_ITERATION + " oid");
        System.out.println("ActiveAndPassiveLinks -u username -p password " + PARAM_ITERATION + " oid " + PARAM_DELETE);
        System.out.println("ActiveAndPassiveLinks -u username -p password " + PARAM_VERSION + " oid");
        System.out.println("ActiveAndPassiveLinks -u username -p password " + PARAM_VERSION + " oid " + PARAM_DELETE);
        System.out.println("ActiveAndPassiveLinks -u username -p password " + PARAM_FILE);
        System.out.println("ActiveAndPassiveLinks -u username -p password " + PARAM_FILE + " " + PARAM_DELETE);
    }

    private static List<EPMDescribeLink> handleDifferentInputOptions(String[] args) throws WTException, IOException {
        List<EPMDescribeLink> duplicateActiveAndPassiveLinks = null;

        if (args[4].equals(PARAM_ITERATION) && args.length >= 6) {
            String oid = args[5];
            duplicateActiveAndPassiveLinks = findDuplicateActiveAndPassiveLinksPerIteration(oid);


        } else if (args[4].equals(PARAM_VERSION) && args.length >= 6) {
            String oid = args[5];
            duplicateActiveAndPassiveLinks = findDuplicateActiveAndPassiveLinksPerVersion(oid);

        } else if (args[4].equals(PARAM_FILE) && args.length >= 6) {
            String fileWithFolder = args[5];
            duplicateActiveAndPassiveLinks = findDuplicateActiveAndPassiveLinksFromFile(fileWithFolder);
        }

        return duplicateActiveAndPassiveLinks;
    }

    private static List<EPMDescribeLink> findDuplicateActiveAndPassiveLinksFromFile(String fileWithFolder) throws WTException,
            FileNotFoundException, IOException {
        List<EPMDescribeLink> duplicateActiveAndPassiveLinks = new ArrayList<EPMDescribeLink>();

        BufferedReader reader = LogUtil.getBufferedReader(fileWithFolder);

        String oidPartIteration;

        while ((oidPartIteration = reader.readLine()) != null) {
            oidPartIteration = oidPartIteration.trim();
            if (oidPartIteration.length() > 0) {
                duplicateActiveAndPassiveLinks.addAll(findDuplicateActiveAndPassiveLinksPerIteration(oidPartIteration));
            }
        }

        return duplicateActiveAndPassiveLinks;
    }

    public static String deleteEPMDescribeLinks(List<EPMDescribeLink> duplicateActiveAndPassiveLinks) throws WTException {

        if (RemoteMethodServer.ServerFlag) {
            return _deleteEPMDescribeLinks(duplicateActiveAndPassiveLinks);
        } else {
            try {
                Class[] classes = {List.class};
                Object[] params = {duplicateActiveAndPassiveLinks};
                
                return (String) RemoteMethodServer.getDefault().invoke("deleteEPMDescribeLinks", "com.ptc.generic.datarepair.ActiveAndPassiveLinks", null, classes, params);
            } catch (Exception ex) {
                throw new WTException(ex);
            }
        }
    }

    private static String _deleteEPMDescribeLinks(List<EPMDescribeLink> duplicateActiveAndPassiveLinks) throws WTException {

        String log = "";
        if (duplicateActiveAndPassiveLinks.size() > 0) {
            for (EPMDescribeLink epmDescribeLink : duplicateActiveAndPassiveLinks) {
                log = log + ("Loesche " + epmDescribeLink + " \n");
                try {
                    PersistenceServerHelper.manager.remove(epmDescribeLink);
                } catch (Exception exw) {
                    exw.printStackTrace();
                }
            }
        } else {
            log = "Liste duplicateActiveAndPassiveLinks leer oder  nur ausgecheckte EPM - keine Links vorhanden.";
        }

        return log;
    }

    private static List<EPMDescribeLink> findDuplicateActiveAndPassiveLinksPerVersion(String oid) throws WTException {
        ArrayList<EPMDescribeLink> duplicateActiveAndPassiveLinks = new ArrayList<EPMDescribeLink>();

        SortedMap<String, Versioned> sortedPartIterations = DataRepairUtil.getSortedIterations(oid);

        for (String key : sortedPartIterations.keySet()) {
            WTPart partIteration = (WTPart) sortedPartIterations.get(key);
            duplicateActiveAndPassiveLinks.addAll(findDuplicateActiveAndPassiveLinksPerIteration(partIteration));
        }

        return duplicateActiveAndPassiveLinks;
    }

    private static List<EPMDescribeLink> findDuplicateActiveAndPassiveLinksPerIteration(String oidPartIteration) throws WTException {
        ArrayList<EPMDescribeLink> duplicateActiveAndPassiveLinks = null;

        if (oidPartIteration != null) {
            try {
                WTPart partIteration = (WTPart) DataRepairUtil.getIteration(oidPartIteration);
                duplicateActiveAndPassiveLinks = (ArrayList<EPMDescribeLink>) findDuplicateActiveAndPassiveLinksPerIteration(partIteration);
            } catch (Exception exw) {
                exw.printStackTrace();
            }
        } else {
            duplicateActiveAndPassiveLinks = new ArrayList<EPMDescribeLink>();
        }

        return duplicateActiveAndPassiveLinks;
    }

    private static List<EPMDescribeLink> findDuplicateActiveAndPassiveLinksPerIteration(WTPart partIteration) throws WTException {
        ArrayList<EPMDescribeLink> duplicateActiveAndPassiveLinks = new ArrayList<EPMDescribeLink>();

        ArrayList<EPMBuildHistory> buildHistories = (ArrayList<EPMBuildHistory>) EPMUtil.getBuildHistories(partIteration);
        ArrayList<EPMDescribeLink> describeLinks = (ArrayList<EPMDescribeLink>) EPMUtil.getEPMDescribeLinks(partIteration);

        boolean hasActiveLink = buildHistories != null && buildHistories.size() > 0;
        boolean hasPassiveLink = describeLinks != null && describeLinks.size() > 0;
        String epmDocNumber = null;

        if (hasActiveLink && hasPassiveLink) {

            logEverywhere("Das Theoretische Teil " + WorkInProgressHelper.isCheckedOut(partIteration) + " besitzt einen aktiven und passiven Link");
            if (WorkInProgressHelper.isCheckedOut(partIteration)) {
                logEverywhere("Das Theoretische Teil  ist ausgecheckt. Links werden nicht geloescht");
            } else {
                ArrayList<String> activeEPMDocIds = getActiveEPMDocIds(buildHistories);
                ArrayList<String> activeEPMDoc = getActiveEPMDoc(buildHistories);

                for (int i = 0; i < activeEPMDoc.size(); i++) {
                    epmDocNumber = activeEPMDoc.get(i);
                }

                for (EPMDescribeLink epmDescribeLink : describeLinks) {
                    logEverywhere(" - passiv zu " + EPMUtil.getEPMDocumentDisplay((EPMDocument) epmDescribeLink.getRoleBObject()));

                    if (EPMUtil.getEPMDoc((EPMDocument) epmDescribeLink.getRoleBObject()).equals(epmDocNumber)) {

                        boolean hasActiveAndPassiveLinkToTheSameEPMDocument = activeEPMDocIds.contains((epmDescribeLink.getRoleBObjectId().toString()));

                        if (WorkInProgressHelper.isCheckedOut((EPMDocument) epmDescribeLink.getRoleBObject()) || WorkInProgressHelper.isWorkingCopy((EPMDocument) epmDescribeLink.getRoleBObject())){
                            logEverywhere("    => EPMDokument ist ausgecheckt. Links werden nicht geloescht");
                        } else {
                            if (hasActiveAndPassiveLinkToTheSameEPMDocument) {
                            logEverywhere("    => Das CAD-Dokument is aktiv und passiv mit dem TT verknuepft. => Loeschen (" + epmDescribeLink + ")");
                            duplicateActiveAndPassiveLinks.add(epmDescribeLink);
                            } else {
                            logEverywhere("    => Eine fruehere Iteration des CAD-Dokumentes ist mit dem TT verknuepft. => Loeschen (" + epmDescribeLink + ")");
                            duplicateActiveAndPassiveLinks.add(epmDescribeLink);
                            }
                        }

                    }
                }

            }
        }

        return duplicateActiveAndPassiveLinks;
    }

    private static ArrayList<String> getActiveEPMDocIds(ArrayList<EPMBuildHistory> buildHistories) throws VersionControlException, WTException {
        ArrayList<String> activeEPMDocIds = new ArrayList<String>();

        for (EPMBuildHistory buildHistory : buildHistories) {
            logEverywhere(" - aktiv zu " + EPMUtil.getEPMDocumentDisplay((EPMDocument) buildHistory.getRoleAObject()));
            if (WorkInProgressHelper.isCheckedOut((EPMDocument) buildHistory.getRoleAObject()) || WorkInProgressHelper.isWorkingCopy((EPMDocument) buildHistory.getRoleAObject())) {
            logEverywhere("    => EPMDokument ist ausgecheckt. Links werden nicht geloescht");
            }
            activeEPMDocIds.add(buildHistory.getRoleAObjectId().toString());
        }
        return activeEPMDocIds;
    }

    private static ArrayList<String> getActiveEPMDoc(ArrayList<EPMBuildHistory> buildHistories) throws VersionControlException {
        ArrayList<String> activeEPMDoc = new ArrayList<String>();

        for (EPMBuildHistory buildHistory : buildHistories) {
            //logEverywhere(" - aktiv zu " + EPMUtil.getEPMDocumentDisplay((EPMDocument) buildHistory.getRoleAObject()));

            activeEPMDoc.add(EPMUtil.getEPMDoc((EPMDocument) buildHistory.getRoleAObject()));
        }
        return activeEPMDoc;
    }

    public void initLogFile(String logFilePath) {

        String folderName = "ActiveAndPassiveLinks";
        String WT_LOGS = null;
        WTProperties wtprops;

        try {
            wtprops = WTProperties.getLocalProperties();
            WT_LOGS = wtprops.getProperty("wt.logs.dir");

        } catch (IOException ex) {
            ex.printStackTrace();
        }
        Calendar k = Calendar.getInstance();
        GregorianCalendar gk = new GregorianCalendar();
        File newFolder = new File(WT_LOGS + File.separator + folderName);
        if (newFolder.exists()) {
        } else {

            boolean sucess = new File(WT_LOGS + File.separator + folderName).mkdir();

        }
        logFilePath = WT_LOGS + File.separator + folderName + File.separator + gk.get(Calendar.YEAR) + "-" + gk.get(Calendar.MONTH) + "-" + gk.get(Calendar.DAY_OF_MONTH) + "-" + Integer.toString(k.get(Calendar.HOUR_OF_DAY)) + Integer.toString(k.get(Calendar.MINUTE)) + Integer.toString(k.get(Calendar.SECOND)) + "-" + logFilePath;
        try {
            logWriter = new BufferedWriter(new FileWriter(logFilePath));
        } catch (IOException exception) {
            System.out.println("Unable to create log file '" + logFilePath + "' " + exception);
        }
    }

    private static void logToFile(String message) {
        if (logWriter != null) {
            try {
                logWriter.write(message);
                logWriter.newLine();
            } catch (IOException exception) {
                System.out.println("Unable to write to log file (message='" + message + "')");
            }
        }
    }

    public void closeLogFile() {
        if (logWriter != null) {
            try {
                logWriter.close();
            } catch (IOException e) {
                System.out.println("Unable to close log file");
            }
        }
    }

    private static void logEverywhere(String msg) {
        System.out.println(msg);
        logToFile(msg);
    }
}