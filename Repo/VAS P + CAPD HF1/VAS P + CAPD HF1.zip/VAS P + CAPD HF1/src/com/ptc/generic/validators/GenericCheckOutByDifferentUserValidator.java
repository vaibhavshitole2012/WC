package com.ptc.generic.validators;

import java.text.MessageFormat;

import org.apache.log4j.Logger;

import wt.org.WTPrincipal;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.vc.wip.WorkInProgressHelper;
import wt.vc.wip.Workable;


/**
 * GenericCheckOutByDifferentUserValidator
 *
 * Validation passes if:<br>
 * - passed object is checked out by a different user than the one in current session
 *
 * @author lstrobin
 *
 */
public class GenericCheckOutByDifferentUserValidator<T extends Workable> implements GenericValidator<T> {

	private ValidationResult validationResult;
	private String errorMessage;
	private static final String CLASSNAME = GenericCheckOutByDifferentUserValidator.class.getName();
	private static final Logger logger = Logger.getLogger(CLASSNAME);
	

	/**
	 * returns true if passed object is checked out by a user that is not the current user
	 * 
	 */
	
	public boolean validate(Workable object) {
		
		resetValidationResult();
		try {
			
			validationResult = new ValidationResult(errorMessage, false);
			
			// check if an object is checked out, and, if necessary, check if it is checked out by the current user
			if (WorkInProgressHelper.isCheckedOut(object) &&
				!WorkInProgressHelper.isCheckedOut(object, SessionHelper.getPrincipal())) {
				validationResult = new ValidationResult(SUCCESS_MESSAGE, true);
			}			
			
		} catch (Exception e) {
			validationResult = new ValidationResult(MessageFormat.format(EXCEPTION_THROWN, e.getLocalizedMessage()), false, null, e);
			logger.error("exception in checking of object is checked out by another user", e);
		}
		
		return validationResult.getIsValid();
	}

	public ValidationResult getValidationResult() {
		return validationResult;
	}

	public void resetValidationResult() {
		validationResult = null;
		
	}

	
}
