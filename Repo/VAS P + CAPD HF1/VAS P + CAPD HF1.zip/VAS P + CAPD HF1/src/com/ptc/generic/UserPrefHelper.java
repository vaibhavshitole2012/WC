package com.ptc.generic;

import com.ptc.generic.userprefs.UserPrefsManager;

import java.util.*;

import org.apache.log4j.Logger;

import wt.org.WTPrincipal;
import wt.org.WTUser;
import wt.prefs.*;
import wt.services.ServiceFactory;
import wt.session.SessionHelper;
import wt.util.WTException;


public class UserPrefHelper {
   
   public static final String CLASSNAME = UserPrefHelper.class.getName();
   
   //initialize logging
   private static final Logger logger = Logger.getLogger(CLASSNAME);
   private static final PreferenceService service = ServiceFactory.getService(PreferenceService.class);

   /**
    *
    * @param path
    * @param key
    * @throws WTException
    * @deprecated This code uses old 8.0 user preferences api. Use UserPrefsManager instead
    * @see UserPrefsManager
    */
   @Deprecated
   public static void deleteUserPrefs(String path, String key) throws WTException {
      if (logger.isDebugEnabled()) {
         logger.debug("path=" + path);
         logger.debug("key=" + key);
      }
      
      String[] context = PreferenceHelper.createContextMask(WTPreferences.USER_CONTEXT, (WTUser) SessionHelper.manager.getPrincipal());
      // returns the preference node at that path
      WTPreferences prefs = (WTPreferences) WTPreferences.root().node(path);
      ((WTPreferences) prefs).setEditContext(PreferenceHelper.createEditMask());
      prefs.setContextMask(context);
      
      prefs.remove(key);
   }

     /**
      * gets user preference from Session User
      * @param path Path of preference
      * @param key name of key
      * @param defaultValue what should be returned if preference doesn't exist?
      * @return User Preference
      *  @deprecated This code uses old 8.0 user preferences api. Use UserPrefsManager instead
      * @see UserPrefsManager
      */
   @Deprecated
   public static String getUserPrefs( String path, String key, String defaultValue )
   throws WTException {
      String[] context = PreferenceHelper.createContextMask(WTPreferences.USER_CONTEXT, (WTUser) SessionHelper.manager.getPrincipal());
      
      // returns the preference node at that path
      WTPreferences prefs = (WTPreferences) WTPreferences.root().node(path);
      prefs.setContextMask(context);
      
      return prefs.get(key, defaultValue);
   }
   /**
    *
    * @param path
    * @param key
    * @param defaultValue
    * @param principal
    * @return
    * @throws WTException
    * @deprecated This code uses old 8.0 user preferences api. Use UserPrefsManager instead
    * @see UserPrefsManager
    */
   @Deprecated
   public static String getUserPrefs( String path, String key, String defaultValue, WTPrincipal principal) throws WTException
   {
      String[] context = PreferenceHelper.createContextMask(WTPreferences.USER_CONTEXT, (WTUser) principal);
      WTPreferences prefs = (WTPreferences) WTPreferences.root().node(path);
      prefs.setContextMask(context);      
      return prefs.get(key, defaultValue);
   } 

   /**
    *
    * @param path
    * @return
    * @throws WTException
    * @deprecated This code uses old 8.0 user preferences api. Use UserPrefsManager instead
    * @see UserPrefsManager
    */
   @Deprecated
   public static String[] getUserPrefKeys( String path )
   throws WTException {
      String[] context = PreferenceHelper.createContextMask(WTPreferences.USER_CONTEXT, (WTUser) SessionHelper.manager.getPrincipal());
      WTPreferences prefs = (WTPreferences) WTPreferences.root().node(path);
      prefs.setContextMask(context);
      
      return prefs.keys();
   }
   
   
   /**
    * 
    * @param path
    * @return
    * @throws WTException
     @deprecated This code uses old 8.0 user preferences api. Use UserPrefsManager instead
    * @see UserPrefsManager
    */
   @Deprecated
   public static Map getAllUserPrefs(String path) throws WTException {
       //HLO: achtung: getEntries gibts mit 8.0 jetzt zweimal, d.h. null musste auf String oder String[] gecastet werdeb,
       // noch rausfinden, ob das Probleme gibt
      String[] context = PreferenceHelper.createContextMask(WTPreferences.DEFAULT_CONTEXT, (WTUser) SessionHelper.manager.getPrincipal());
      //TODO ECA5.0: review this change
      //PrefEntry[] localPrefs = prefFwd.getEntries(path, context, (String)null);
      PrefEntry[] localPrefs = service.getEntries(path, context, (String)null);
      Map prefs = new HashMap();
      for(int i=0; i<localPrefs.length; i++) {
      	prefs.put(path + "/" + localPrefs[i].getName(), localPrefs[i].getValue());
      }
      context = PreferenceHelper.createContextMask(WTPreferences.USER_CONTEXT, (WTUser) SessionHelper.manager.getPrincipal());
      //TODO ECA5.0: review this change
      //localPrefs = prefFwd.getEntries(path, context, (String)null);
      localPrefs = service.getEntries(path, context, (String)null);
      for(int i=0; i<localPrefs.length; i++) {
      	prefs.put(path + "/" + localPrefs[i].getName(), localPrefs[i].getValue());
      }
      return prefs;
   }

   /**
      * set user preference from Session User
      * @param path Path of preference
      * @param key name of key
      * @param value value to set
     *  @deprecated This code uses old 8.0 user preferences api. Use UserPrefsManager instead
     * @see UserPrefsManager
      */
   @Deprecated
   public static void setUserPrefs( String path, String key, String value )
   throws WTException {
       setUserPrefs( path, key, value, WTPreferences.USER_CONTEXT );
   }
   
   /**
      * set user preference from Session User
      * @param path Path of preference
      * @param key name of key
      * @param value value to set
      * @param prefContext the context
     *  @deprecated This code uses old 8.0 user preferences api. Use UserPrefsManager instead
     * @see UserPrefsManager
      */
   @Deprecated
   public static void setUserPrefs( String path, String key, String value, String prefContext )
   throws WTException {
      if (logger.isDebugEnabled()) {
         logger.debug("path=" + path);
         logger.debug("key=" + key);
         logger.debug("value=" + value);
         logger.debug("prefContext=" + prefContext);
      }
      
      String[] context = PreferenceHelper.createContextMask(prefContext, (WTUser) SessionHelper.manager.getPrincipal());
      // returns the preference node at that path
      WTPreferences prefs = (WTPreferences) WTPreferences.root().node(path);
      ((WTPreferences) prefs).setEditContext(wt.prefs.PreferenceHelper.createEditMask());
      prefs.setContextMask(context);
      
      prefs.put(key, value);
   }
   
   public static void main(String args[]) {
   	try {
   		Map m = UserPrefHelper.getAllUserPrefs("/ext/custom/eclist/userPreferences");
   		System.out.println("m=" + m);
   		System.exit(0);
   	} catch(WTException w) {
   		w.printStackTrace();
   		System.exit(1);
   	}
   }
}
