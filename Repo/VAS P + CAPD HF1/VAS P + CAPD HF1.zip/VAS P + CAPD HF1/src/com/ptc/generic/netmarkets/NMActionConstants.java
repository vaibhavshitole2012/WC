/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ptc.generic.netmarkets;

/**
 *
 * @author Marek Piechut <mpiechut@ptc.com>
 */
public interface NMActionConstants {
    String ACTIONTYPE_PART = "part";
    String ACTIONTYPE_THEO_TEIL = "TheoTeil";
    String ACTIONTYPE_DOCUMENT = "document";
    String ACTIONTYPE_PARTUSAGE = "ecapartusage";
    String ACTIONTYPE_OBJECT = "object";
    String ACTIONTYPE_WORKFLOW = "workflow";

    String ACTIONNAME_PART_RELATED_DOCUMENTS = "relatedPartsDocuments";
    String ACTIONNAME_PART_RELATED_CAD_DOCUMENTS = "relatedPartsCADDocuments";
    String ACTIONNAME_OBJECT_ATTRIBUTES_AND_CONTENT = "attributesAndContent";
    String ACTIONNAME_VW_ECA_RELATED_DOC_CREATE_WIZARD_PART_DESCRIBED = "vw_eca_related_doc_create_wizard_part_described";
    String ACTIONNAME_VW_ECA_CREATE_THEOTEIL_WIZARD = "createVWTheoPartWizard";
    String ACTIONNAME_VW_ECA_PART_EDIT_WIZARD = "vw_eca_part_edit_wizard";
    String ACTIONNAME_VW_ECA_PARTUSAGE = "VWPartUsageWizard";
    String ACTIONNAME_EDIT_STUECKLISTE = "tabular_input";
    String ACTIONNAME_PROCESS_HISTORY = "processHistory";
}
