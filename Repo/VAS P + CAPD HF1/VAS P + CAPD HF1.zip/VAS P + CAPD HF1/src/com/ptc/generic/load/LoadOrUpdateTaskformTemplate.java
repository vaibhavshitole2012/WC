/* bcwti
 * 
 *  Copyright (c) 2013 Parametric Technology Corporation (PTC). All Rights
 *  Reserved.
 * 
 *  This software is the confidential and proprietary information of PTC.
 *  You shall not disclose such confidential information and shall use it
 *  only in accordance with the terms of the license agreement.
 * 
 *  ecwti
 */
package com.ptc.generic.load;

import java.io.File;
import java.util.Hashtable;
import java.util.List;
import java.util.Vector;

import wt.admin.AdminDomainRef;
import wt.content.ContentHelper;
import wt.content.ContentHolder;
import wt.content.ContentItem;
import wt.content.ContentRoleType;
import wt.content.ContentServerHelper;
import wt.fc.PersistenceHelper;
import wt.folder.Folder;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerRef;
import wt.load.LoadServerHelper;
import wt.pom.Transaction;
import wt.util.WTException;
import wt.util.WTProperties;
import wt.util.WTPropertyVetoException;
import wt.vc.wip.CheckoutLink;
import wt.vc.wip.WorkInProgressHelper;
import wt.workflow.templates.TaskFormTemplate;
import wt.workflow.templates.TaskFormTemplateHelper;

import com.ptc.netmarkets.model.NmObjectHelper;

/**
 * Loader for Task Form Templates that first checks if the template
 * already exists and replaces the primary content with new file passed in loader parameters
 * or creates new template if not found.
 *
 * <p>
 * Can be safely used in place of com.ptc.netmarkets.workflow.taskformtemplates.LoadTaskformTemplate.createTemplate
 * Just replace:<br/><br/>
 * <code>handler="com.ptc.netmarkets.workflow.taskformtemplates.LoadTaskformTemplate.createTemplate"</code><br/><br/>
 * with<br/><br/>
 * <code>handler="com.ptc.load.LoadOrUpdateTaskformTemplate.createOrUpdateTemplate"</code><br/><br/>
 * in your load file.
 * </p>
 * 
 * @author cherrmann
 */
public class LoadOrUpdateTaskformTemplate {
	public static final String svnRev = "$Revision: 1.1.1.3 $ $Date: 2015/12/10 21:10:40IST $";
	public static final String svnUrl = "$URL: http://127.0.0.1/svn/KB_04082016/components/Generic-Utilities/src/com/ptc/generic/load/LoadOrUpdateTaskformTemplate.java $";

	public static String wt_home = "";
	static {
		try {
			WTProperties properties = WTProperties.getLocalProperties();
			wt_home = properties.getProperty("wt.home", "");
		} catch (Throwable t) {
			System.err.println("Error initializing " + LoadOrUpdateTaskformTemplate.class.getName());
			t.printStackTrace(System.err);
			throw new ExceptionInInitializerError(t);
		}
	}

	/**
	 * Update Task Form Template if already existant, create new otherwise.
	 * 
	 * @param nv
	 * @param cmd_line
	 * @param return_objects
	 * @return
	 */
	public static boolean createOrUpdateTemplate(Hashtable<?, ?> nv, Hashtable<?, ?> cmd_line, Vector<?> return_objects) {
		boolean result = false;
		
		Transaction trx = null;
		try {
			WTContainerRef containerRef = LoadServerHelper.getTargetContainer(nv, cmd_line);
			String fileName = getValue("FileName", nv, cmd_line, false);
			String filePath = getValue("FilePath", nv, cmd_line, false);
			String taskType = getValue("TaskType", nv, cmd_line, false);
			String pboClass = getValue("PboClass", nv, cmd_line, false);
			String fileFormat = getValue("FileFormat", nv, cmd_line, false);
			String description = getValue("description", nv, cmd_line, false);
			
			// first search for existing templates
			List<?> taskFormTemplates = TaskFormTemplateHelper.service.getAllTemplates(containerRef);
			TaskFormTemplate template = null;
			boolean newTemplate = true;
			for (Object tmp : taskFormTemplates){
				if (tmp instanceof TaskFormTemplate) {
					TaskFormTemplate tft = (TaskFormTemplate) tmp;
					if (tft.getName().equals(fileName) 
							&& tft.getTypeFormat().equals(fileFormat) 
							&& tft.getTaskType().equals(taskType)
							&& tft.getPboClass().equals(pboClass)) {
						//a template with the same type and name already exists -> update
						template = tft;
						newTemplate = false;
						break;
					}
				}
			}
			
			if (newTemplate) {
				template = TaskFormTemplate.newTaskFormTemplate();
			}
			
			trx = new Transaction();
			trx.start();
			
			if (newTemplate) {
				// set necessary information on the new template
				template.setName(fileName);
				template.setContainerReference(containerRef);
				template.setTaskType(taskType);
				template.setTypeFormat(fileFormat);
				template.setDomainRef(AdminDomainRef.newAdminDomainRef(((WTContainer) containerRef.getObject()).getSystemDomain()));
				template.setPboClass(pboClass);
				template.setDescription(description);
				template.setEnabled(true);
			} else {
				// needs to bechecked out to be modified
				Folder checkoutFolder = WorkInProgressHelper.service.getCheckoutFolder();
		        CheckoutLink link = null;

		        try {
		            link = WorkInProgressHelper.service.checkout(template, checkoutFolder, "Checked Out for Update");
		        } catch (WTPropertyVetoException wpe) {
		            throw new WTException(wpe);
		        }

		        if (link != null) {
		            template = (TaskFormTemplate) link.getWorkingCopy();
		        } else {
		            throw new WTException("Checkout of the template failed!");
		        }
			}
			
			// update information
			template.setDescription(description);
			template.setEnabled(true);
			//template.setPboClass(pboClass);
			
			String file = wt_home + File.separator + "loadFiles" + File.separator + filePath + "." + fileFormat;
			if (newTemplate) {
				// create the new template and upload the content
				template = (TaskFormTemplate) TaskFormTemplateHelper.service.createTemplate(template);
				NmObjectHelper.service.uploadContent(template, file, file);
			} else {
				// existing template: locate and delete the primary content
				ContentHolder contentHolder = ContentHelper.service.getContents(template);
				Vector<?> contents = contentHolder.getContentVector();
				for (Object o : contents) {
					if (o instanceof ContentItem) {
						ContentItem content = (ContentItem) o;
						if (ContentRoleType.PRIMARY.equals(content.getRole())) {
							ContentServerHelper.service.deleteContent(contentHolder, content);
							break;
						}
					}
					
				}
				
				// upload the new content, modify the template and checkIn again
				NmObjectHelper.service.uploadContent(template, file, file);
				template = (TaskFormTemplate) PersistenceHelper.manager.modify(template);
				template = (TaskFormTemplate) PersistenceHelper.manager.refresh(template);
				template = (TaskFormTemplate) WorkInProgressHelper.service.checkin(template, "Checked In after Update");
			}
			
			trx.commit();
			trx = null;
			result = true;
		} catch (WTException wte) {
			LoadServerHelper.printMessage("\nCreate Taskform template Failed : " + wte.getLocalizedMessage());
			wte.printStackTrace();
		} catch (Exception e) {
			LoadServerHelper.printMessage("\nCreate Taskform template Failed : " + e.getMessage());
			e.printStackTrace();
		}
		
		if (trx != null) {
			trx.rollback();
		}

		return result;
	}

	private static String getValue(String name, Hashtable<?, ?> nv, Hashtable<?, ?> cmd_line, boolean required) throws WTException {

		String value = LoadServerHelper.getValue(name, nv, cmd_line, required ? LoadServerHelper.REQUIRED : LoadServerHelper.NOT_REQUIRED);

		if (required && value == null)
			throw new WTException("\nRequired value for " + name + " not provided in input file.");

		return value;
	}
}
