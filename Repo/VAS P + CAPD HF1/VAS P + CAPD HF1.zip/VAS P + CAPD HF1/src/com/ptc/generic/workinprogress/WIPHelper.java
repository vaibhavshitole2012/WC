package com.ptc.generic.workinprogress;


import com.ptc.generic.vc.VCHelper;
import com.ptc.generic.workinprogress.WIPService;

import wt.services.ServiceFactory;
import wt.util.WTException;
import wt.vc.Iterated;
import wt.vc.Mastered;


public class WIPHelper {


   // --- Attribute Section ---
   private static final String RESOURCE = "com.ptc.generic.workinprogress.workinprogressResource";
   private static final String CLASSNAME = WIPHelper.class.getName();

   public static final int MODE_RETURN_OBJECTS = 0;
   public static final int MODE_RETURN_OIDS = 1;
   public static final int MODE_RETURN_BRANCHIDS = 2;

   public static final WIPService service = ServiceFactory.getService(WIPService.class);



   // --- Operation Section ---

   /**
    * Get latest iteration from master object
    * 
    * @deprecated please use VCHelper.service.getLatestIterationForGivenVersion(Mastered, String) instead
    * 
    * @param master
    * @return
    * @throws WTException
    */
   @Deprecated
    public static Iterated getLatestIteration(Mastered master) throws WTException {
	   return (Iterated) VCHelper.service.getLatestIterationForGivenVersion(master, null);
    }
}
