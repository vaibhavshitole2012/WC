package com.ptc.generic.query;

import wt.folder.IteratedFolderMemberLink;
import wt.iba.value.BooleanValue;
import wt.iba.value.StringValue;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.query.ArrayExpression;
import wt.query.ClassAttribute;
import wt.query.QueryException;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.query.SubSelectExpression;
import wt.query.TableColumn;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;

import com.ptc.generic.fc.ImprovedQuerySpec;
import com.ptc.generic.iba.IBAQueryParameters;

public class QueryServerUtils {

	public static final String CHECKOUT_INFO_STATE = "checkoutInfo.state";
	public static final String IBA_DEFINITION_ID = "definitionReference.key.id";
	public static final String IBA_HOLDER_REFERENCE_CLASS = "theIBAHolderReference.key.classname";
	public static final String IBA_HOLDER_REFERENCE_ID = "theIBAHolderReference.key.id";
	public static final String IBA_VALUE = "value";
	public static final String IDA2A2 = "ida2a2";
	public static final String ITERATION_INFO_BRANCH_ID = "iterationInfo.branchId";
	public static final String ITERATION_INFO_IDENTIFIER_ITERATION_ID = "iterationInfo.identifier.iterationId";
	public static final String ITERATION_INFO_LATEST = "iterationInfo.latest";
	public static final String LIFE_CYCLE_ID = "state.lifeCycleId.key.id";
	public static final String MASTER_REFERENCE_KEY_ID = "masterReference.key.id";
	public static final String PERSIST_INFO_THE_OBJECT_IDENTIFIER_ID = "thePersistInfo.theObjectIdentifier.id";
	public static final String ROLE_A_OBJECT_REF_KEY_ID = "roleAObjectRef.key.id";
	public static final String ROLE_B_OBJECT_REF_KEY_ID = "roleBObjectRef.key.id";
	public static final String ROLE_B_OBJECT_REF_KEY_BRANCHID = "roleBObjectRef.key.branchId";
	public static final String TC_IBA_DEFINITION_ID = "ida3a6";
	public static final String TC_IBA_HOLDER_REFERENCE_ID = "ida3a4";

	public static final String TC_LIFECYCLE_TEMPLATE_ID = "ida3a2state";
	public static final String VERSION_INFO_IDENTIFIER_VERSION_ID = "versionInfo.identifier.versionId";
	public static final String WORKING_COPY = "wrk";
	//Added as part of CR_2013_108 for project plan objects
	public static final String SUMMARY_ACTIVITY_PARENT_ID = "parentProcessRef.key.id";
	public static final String SUMMARY_ACTIVITY_PARENT_CLASS="parentProcessRef.key.classname";
	public static final String MILESTONE_PARENT_ID = "parentProcessRef.key.id";
	public static final String LC_STATE="state.state";
	/**
	 * Appends a search condition to exclude working copies from the result
	 * 
	 * @param qs
	 *            the query spec
	 * @param searchClass
	 *            the search class
	 * @param idxS
	 *            the index of the class in the query
	 * @throws QueryException
	 */
	public static void appendSCExcludeWorkingCopies(QuerySpec qs, Class searchClass, int idx) throws WTException {
		SearchCondition scExcludeWorkingCopies = new SearchCondition(searchClass, QueryServerUtils.CHECKOUT_INFO_STATE, SearchCondition.NOT_EQUAL,
				QueryServerUtils.WORKING_COPY);
		qs.appendWhere(scExcludeWorkingCopies, new int[] { idx });
	}

	/**
	 * Appends a search condition to get all StringValues with a
	 * StringDefinition in an array of Ids
	 * 
	 * @param qs
	 *            the query spec
	 * @param ibaQueryParameter
	 *            the IBAQueryParameters which defines the array of
	 *            StringDefinition
	 * @param idxStringValue
	 *            the index of the StringValue table in the select statement
	 * @throws WTException
	 */
	public static void appendSCIBADefinitionIdIn(QuerySpec qs, IBAQueryParameters ibaQueryParameter, int idxStringValue) throws WTException {
		TableColumn tcIBADefinitionId = new TableColumn("IBA0", QueryServerUtils.TC_IBA_DEFINITION_ID);
		ArrayExpression arrayExpressionDefinitionIds = new ArrayExpression(ibaQueryParameter.getIbaDefinitionId());
		SearchCondition scIBADefinitionId = new SearchCondition(tcIBADefinitionId, SearchCondition.IN, arrayExpressionDefinitionIds);
		qs.appendWhere(scIBADefinitionId, new int[] { idxStringValue });
	}

	/**
	 * Appends a search condition to get all StringValues with a certain class
	 * for the IBA Holder
	 * 
	 * @param qs
	 *            the query spec
	 * @param ibaQueryParameter
	 *            the IBAQueryParameters which defines the class of the IBA
	 *            Holder
	 * @param idxStringValue
	 *            the index of the StringValue table in the select statement
	 * @throws QueryException
	 */
	public static void appendSCIBAHolderClassName(QuerySpec qs, IBAQueryParameters ibaQueryParameter, int idxStringValue) throws WTException {
		SearchCondition scIBAHolderClassName = new SearchCondition(StringValue.class, QueryServerUtils.IBA_HOLDER_REFERENCE_CLASS,
				SearchCondition.EQUAL, ibaQueryParameter.getIbaHolderClass());
		qs.appendWhere(scIBAHolderClassName, new int[] { idxStringValue });
	}

	public static void appendSCIBAHolderClassNameBoolean(QuerySpec qs, IBAQueryParameters ibaQueryParameter, int idxStringValue) throws WTException {
		SearchCondition scIBAHolderClassName = new SearchCondition(BooleanValue.class, QueryServerUtils.IBA_HOLDER_REFERENCE_CLASS,
				SearchCondition.EQUAL, ibaQueryParameter.getIbaHolderClass());
		qs.appendWhere(scIBAHolderClassName, new int[] { idxStringValue });
	}

	/**
	 * Appends a search condition to get all StringValues with IBA Holders in an
	 * array of Ids
	 * 
	 * @param qs
	 *            the query spec
	 * @param ibaQueryParameter
	 *            the IBAQueryParameters which defines the array of IBA Holder
	 *            Ids
	 * @param idxStringValue
	 *            the index of the StringValue table in the select statement
	 * @throws WTException
	 */
	public static void appendSCIBAHolderIdIn(QuerySpec qs, IBAQueryParameters ibaQueryParameter, int idxStringValue) throws WTException {
		TableColumn tcIBAValue = new TableColumn("IBA0", QueryServerUtils.TC_IBA_HOLDER_REFERENCE_ID);
		ArrayExpression arrayExpressionPartIterations = new ArrayExpression(ibaQueryParameter.getIbaHolderIds());
		SearchCondition scIBAValue = new SearchCondition(tcIBAValue, SearchCondition.IN, arrayExpressionPartIterations);
		qs.appendWhere(scIBAValue, new int[] { idxStringValue });
	}

	/**
	 * Appends a search condition to get all StringValues with values in an
	 * array of Ids. <br>
	 * Be aware that the table column contains all values in upper cases.
	 * 
	 * @param qs
	 *            the query spec
	 * @param ibaQueryParameter
	 *            the IBAQueryParameters which defines the array of IBA values
	 * @param idxStringValue
	 *            the index of the StringValue table in the select statement
	 * @throws WTException
	 */
	public static void appendSCIBAValueIn(QuerySpec qs, IBAQueryParameters ibaQueryParameter, int idxStringValue) throws WTException {
		TableColumn tcIBAValue = new TableColumn("IBA0", StringValue.VALUE);
		ArrayExpression arrayExpressionPartIterations = new ArrayExpression(ibaQueryParameter.getIbaValues());
		SearchCondition scIBAValue = new SearchCondition(tcIBAValue, SearchCondition.IN, arrayExpressionPartIterations);
		qs.appendWhere(scIBAValue, new int[] { idxStringValue });
	}

	/**
	 * Appends a search condition to get all StringValues with values in an
	 * array of Ids with like. <br>
	 * Be aware that the table column contains all values in upper cases.
	 * 
	 * @param qs
	 *            the query spec
	 * @param ibaQueryParameter
	 *            the IBAQueryParameters which defines the array of IBA values
	 * @param idxStringValue
	 *            the index of the StringValue table in the select statement
	 * @throws WTException
	 */
	public static void appendSCIBAValueLike(ImprovedQuerySpec qs, IBAQueryParameters ibaHolderQueryParameters, int idxStringValue) throws WTException {
		boolean isFirstLoop = true;

		qs.appendOpenParen();

		for (String ibaValue : ibaHolderQueryParameters.getIbaValues()) {
			if (isFirstLoop) {
				isFirstLoop = false;
			} else {
				qs.appendOr();
			}
			SearchCondition scIBAValue = new SearchCondition(StringValue.class, QueryServerUtils.IBA_VALUE, SearchCondition.LIKE, ibaValue);
			qs.appendWhere(scIBAValue, new int[] { idxStringValue });
		}

		qs.appendCloseParen();

	}

	/**
	 * Appends a select statement to query.
	 * 
	 * @param qs
	 *            the query spec
	 * @param ibaQueryParameter
	 *            the IBAQueryParameters which defines the select attributes
	 * @param idxStringValue
	 *            the index of the StringValue table in the select statement
	 * @throws WTException
	 */
	public static void appendSelectAttributes(QuerySpec qs, IBAQueryParameters ibaQueryParameter, int idxStringValue) throws WTException {
		for (String selectAttribute : ibaQueryParameter.getSelectAttributes()) {
			qs.appendSelectAttribute(selectAttribute, idxStringValue, false);
		}
	}

	/**
	 * Add the WTPartMaster attributes name and number to the search condition. <br>
	 * Also it adds an search condition to connect the WTPart with the
	 * WTPartMaster table. <br>
	 * Append an search condition with an and.
	 * 
	 * @param qs
	 *            the existing query spec
	 * @param idxWTPart
	 *            the index of the WTPart in the select statement
	 * @throws WTException
	 */
	public static void appendWTPartMasterDebugAttributes(QuerySpec qs, int idxWTPart) throws WTException {
		int idxWTPartMaster = qs.appendClassList(WTPartMaster.class, false);
		qs.appendSelectAttribute(WTPartMaster.NAME, idxWTPartMaster, false);
		qs.appendSelectAttribute(WTPartMaster.NUMBER, idxWTPartMaster, false);

		SearchCondition scJoinLinkToPic = new SearchCondition(WTPartMaster.class, QueryServerUtils.PERSIST_INFO_THE_OBJECT_IDENTIFIER_ID,
				WTPart.class, QueryServerUtils.MASTER_REFERENCE_KEY_ID);
		qs.appendAnd();
		qs.appendWhere(scJoinLinkToPic, new int[] { idxWTPartMaster, idxWTPart });
	}

	/**
	 * Returns a search condition for all life cycle template ids in
	 * 
	 * @param tableName
	 *            the alias of the table
	 * @param lcTemplateOids
	 *            a list of life cycle template ids
	 * @return a search condition for all life cycle template ids in
	 * @throws WTException
	 */
	public static SearchCondition getSCLifeCycleTemplates(String tableName, long[] lcTemplateOids) throws QueryException {
		TableColumn tcLifeCyleTemplate = new TableColumn(tableName, QueryServerUtils.TC_LIFECYCLE_TEMPLATE_ID);
		ArrayExpression arrayExpressionLCTemplateOids = new ArrayExpression(lcTemplateOids);
		SearchCondition scLCVirtualPhase = new SearchCondition(tcLifeCyleTemplate, SearchCondition.IN, arrayExpressionLCTemplateOids);
		return scLCVirtualPhase;
	}

	/**
	 * Set the alias of an query. Converts the WTPropertyVetoException into a
	 * WTException. <br>
	 * => Easier to read instead of putting an try catch block into your code
	 * 
	 * @param qs
	 * @param prefix
	 * @throws WTException
	 */
	public static void setAliasPrefix(QuerySpec qs, String prefix) throws WTException {
		try {
			qs.getFromClause().setAliasPrefix(prefix);
		} catch (WTPropertyVetoException e) {
			throw new WTException(e);
		}
	}

	/**
	 * Create a query spec which returns the WTPart branchids for all given oids
	 * 
	 * SELECT branchiditerationinfo FROM wtpart WHERE ida2a2 IN oids
	 * => Find the branch ids for a list of ids
	 * 
	 * @param oids
	 *            a list of oids
	 * @return the QuerySpec to find the the WTPart branch ids from the oids
	 * @throws WTException
	 */
	public static ImprovedQuerySpec getQSWTPartBranchIdFromOid(Long[] oids) throws WTException {
		try {
			// SELECT branchiditerationinfo FROM wtpart
			ImprovedQuerySpec qsBranchId = new ImprovedQuerySpec();
			int idxWTPart = qsBranchId.appendClassList(WTPart.class, false);
			qsBranchId.appendSelectAttribute(WTPart.BRANCH_IDENTIFIER, idxWTPart, false);

			// WHERE branchIterationInfo IN oids
			ClassAttribute ida2a2 = new ClassAttribute(WTPart.class, QueryServerUtils.PERSIST_INFO_THE_OBJECT_IDENTIFIER_ID);
			ArrayExpression oidExpression = new ArrayExpression(oids);
			SearchCondition scOids = new SearchCondition(ida2a2, SearchCondition.IN, oidExpression);
			qsBranchId.appendWhere(scOids, new int[] { idxWTPart });

			return qsBranchId;
		} catch (QueryException queryExcption) {
			throw new WTException(queryExcption);
		}
	}

	/**
	 * <pre>
	 * Create a query spec which returns all part iteration (ids) for all given branchIds
	 * 
	 * SELECT ida2a2 FROM wtpart WHERE branchiditerationinfo IN branchIds
	 * => Return a list of iterations (ids) for a list of branch ids
	 * </pre>
	 * 
	 * @param branchIds
	 *            a list of branchIds
	 * @return the QuerySpec to find the the WTPart oids from the branch ids
	 * @throws WTException
	 */
	public static ImprovedQuerySpec getQSWTPartOidsFromBranchIds(Long[] branchIds) throws WTException {
		try {
			// SELECT branchiditerationinfo FROM wtpart
			ImprovedQuerySpec qsOid = new ImprovedQuerySpec();
			int idxWTPart = qsOid.appendClassList(WTPart.class, false);
			qsOid.appendSelectAttribute(QueryServerUtils.PERSIST_INFO_THE_OBJECT_IDENTIFIER_ID, idxWTPart, false);

			// WHERE oids IN branchIds
			ClassAttribute branchId = new ClassAttribute(WTPart.class, WTPart.BRANCH_IDENTIFIER);
			ArrayExpression branchIdExpression = new ArrayExpression(branchIds);
			SearchCondition scBranchIds = new SearchCondition(branchId, SearchCondition.IN, branchIdExpression);
			qsOid.appendWhere(scBranchIds, new int[] { idxWTPart });

			return qsOid;
		} catch (QueryException queryExcption) {
			throw new WTException(queryExcption);
		}
	}

	/**
	 * <pre>
	 * Create a query spec which returns all part iteration (ids) for all given branchIds.
	 * The branchIds are returned from the given sub query.
	 * 
	 * SELECT ida2a2 FROM wtpart WHERE branchiditerationinfo IN qsBranchIds
	 * => Return a list of iterations (ids) for a list of branch ids 
	 * => The list of branch ids is the result of the given sub query
	 * </pre>
	 * 
	 * @param qsBranchIds
	 *            a SubSelect which returns a list of branchIds
	 * @return the QuerySpec to find the the WTPart oids from the branch ids
	 * @throws WTException
	 */
	public static ImprovedQuerySpec getQSWTPartOidsFromBranchIds(QuerySpec qsBranchIds) throws WTException {
		try {
			// SELECT ida2a2 FROM wtpart
			ImprovedQuerySpec qsOid = new ImprovedQuerySpec();
			int idxWTPart = qsOid.appendClassList(WTPart.class, false);
			qsOid.appendSelectAttribute(QueryServerUtils.PERSIST_INFO_THE_OBJECT_IDENTIFIER_ID, idxWTPart, false);

			// WHERE branchiditerationinfo IN qsBranchIds
			ClassAttribute branchId = new ClassAttribute(WTPart.class, WTPart.BRANCH_IDENTIFIER);
			SubSelectExpression subQSBranchIds = new SubSelectExpression(qsBranchIds);
			SearchCondition scBranchIds = new SearchCondition(branchId, SearchCondition.IN, subQSBranchIds);
			qsOid.appendWhere(scBranchIds, new int[] { idxWTPart });

			return qsOid;
		} catch (QueryException queryExcption) {
			throw new WTException(queryExcption);
		}
	}

	/**
	 * <pre>
	 * Create a query spec which returns the subfolder oids for all object given branchIds e.g. part, document. 
	 * The given branch ids from the foldered object comes from a subquery
	 * 
	 * SELECT ida3b5 FROM IterFolderMemberLink WHERE branchIdA3B5 IN qsBranchIds
	 * => Find all subfolder ids from a list of folder objects which are returned from a sub query.
	 * </pre>
	 * 
	 * @param qsBranchIds
	 *            a SubSelect which returns a list of branchIds
	 * @return the QuerySpec to find the the subfolder oids from the branch ids
	 * @throws WTException
	 */
	public static ImprovedQuerySpec getQSSubFolderFromBranchIds(QuerySpec qsBranchIds) throws WTException {
		try {
			// SELECT ida3b5 FROM IterFolderMemberLink
			ImprovedQuerySpec qsSubFolderOids = new ImprovedQuerySpec();
			int idxFolderMemberLink = qsSubFolderOids.appendClassList(IteratedFolderMemberLink.class, false);
			qsSubFolderOids.appendSelectAttribute(QueryServerUtils.ROLE_A_OBJECT_REF_KEY_ID, idxFolderMemberLink, false);

			// WHERE branchIdA3B5 IN qsBranchIds
			ClassAttribute branchId = new ClassAttribute(IteratedFolderMemberLink.class, QueryServerUtils.ROLE_B_OBJECT_REF_KEY_BRANCHID);
			SubSelectExpression subQSBranchIds = new SubSelectExpression(qsBranchIds);
			SearchCondition scBranchIds = new SearchCondition(branchId, SearchCondition.IN, subQSBranchIds);
			qsSubFolderOids.appendWhere(scBranchIds, new int[] { idxFolderMemberLink });

			return qsSubFolderOids;
		} catch (QueryException queryExcption) {
			throw new WTException(queryExcption);
		}
	}

	/**
	 * <pre>
	 * Create a query spec which returns the subfolder oids for all given objects branchIds e.g. part document .
	 * 
	 * SELECT ida3b5 FROM IterFolderMemberLink WHERE branchIdA3B5 IN branchIds
	 *  => Find all subfolder ids from a list of folder objects (identified by branchId)
	 * </pre>
	 * 
	 * @param qsBranchIds
	 *            a SubSelect which returns a list of branchIds
	 * @return the QuerySpec to find the the subfolder oids from the branch ids
	 * @throws WTException
	 */
	public static ImprovedQuerySpec getQSSubFolderFromBranchIds(Long[] branchIds) throws WTException {
		try {
			// SELECT ida3b5 FROM IterFolderMemberLink
			ImprovedQuerySpec qsSubFolderOids = new ImprovedQuerySpec();
			int idxFolderMemberLink = qsSubFolderOids.appendClassList(IteratedFolderMemberLink.class, false);
			qsSubFolderOids.appendSelectAttribute(QueryServerUtils.ROLE_A_OBJECT_REF_KEY_ID, idxFolderMemberLink, false);

			// WHERE branchIdA3B5 IN qsBranchIds
			ClassAttribute branchId = new ClassAttribute(IteratedFolderMemberLink.class, QueryServerUtils.ROLE_B_OBJECT_REF_KEY_BRANCHID);
			ArrayExpression branchIdExpression = new ArrayExpression(branchIds);
			SearchCondition scBranchIds = new SearchCondition(branchId, SearchCondition.IN, branchIdExpression);
			qsSubFolderOids.appendWhere(scBranchIds, new int[] { idxFolderMemberLink });

			return qsSubFolderOids;
		} catch (QueryException queryExcption) {
			throw new WTException(queryExcption);
		}
	}

}
