/*
 * Created on Aug 10, 2004
 */
package com.ptc.generic.softtypes;

/**
 * @author mvonhasselbach@ptc.com, PTC
 */
import java.io.Externalizable;
import java.io.IOException;
import java.io.InvalidClassException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Vector;

import wt.adapter.BasicWebjectDelegate;
import wt.fc.EvolvableHelper;
import wt.fc.IconDelegate;
import wt.fc.IconDelegateFactory;
import wt.fc.ObjectIdentifier;
import wt.fc.WTObject;
import wt.fc.WTReference;
import wt.httpgw.URLFactory;
import wt.inf.container.WTContainerRef;
import wt.pds.PDSObjectInput;
import wt.services.applicationcontext.implementation.DefaultServiceProvider;
import wt.util.IconSelector;
import wt.util.WTException;
import wt.vc.wip.WorkInProgressState;

import com.infoengine.object.factory.Att;
import com.infoengine.object.factory.Element;
import com.infoengine.object.factory.Group;
import com.infoengine.object.factory.Task;
import com.infoengine.object.factory.Webject;
import com.ptc.core.adapter.server.impl.AbstractWebjectDelegate;
import com.ptc.core.foundation.persistable.server.impl.ObjectIconHelper;
import com.ptc.core.meta.common.AttributeTypeIdentifier;
import com.ptc.core.meta.common.IdentifierFactory;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.TypeInstanceIdentifier;
import com.ptc.core.meta.server.TypeIdentifierUtility;
import com.ptc.core.meta.type.common.TypeInstance;

// Referenced classes of package com.ptc.core.adapter.server.impl:
//            AbstractWebjectDelegate

/**
 */
public class GetIconURLWebjectDelegate extends AbstractWebjectDelegate
    implements Externalizable
{

    public GetIconURLWebjectDelegate()
    {
    }

    /**
     * Method writeExternal.
     * @param objectoutput ObjectOutput
     * @throws IOException
     * @see java.io.Externalizable#writeExternal(ObjectOutput)
     */
    public void writeExternal(ObjectOutput objectoutput)
        throws IOException
    {
        objectoutput.writeLong(-3658319176036811472L);
        super.writeExternal(objectoutput);
    }

    /**
     * Method readExternal.
     * @param objectinput ObjectInput
     * @throws IOException
     * @throws ClassNotFoundException
     * @see java.io.Externalizable#readExternal(ObjectInput)
     */
    public void readExternal(ObjectInput objectinput)
        throws IOException, ClassNotFoundException
    {
        long l = objectinput.readLong();
        readVersion(this, objectinput, l, false, false);
    }

    /**
     * Method readVersion.
     * @param geticonurlwebjectdelegate GetIconURLWebjectDelegate
     * @param objectinput ObjectInput
     * @param l long
     * @param flag boolean
     * @param flag1 boolean
     * @return boolean
     * @throws IOException
     * @throws ClassNotFoundException
     */
    protected boolean readVersion(GetIconURLWebjectDelegate geticonurlwebjectdelegate, ObjectInput objectinput, long l, boolean flag, boolean flag1)
        throws IOException, ClassNotFoundException
    {
        boolean flag2 = true;
        if(l == -3658319176036811472L)
        {
            if(!flag1)
                super.readExternal(objectinput);
        } else
        {
            flag2 = readOldVersion(objectinput, l, flag, flag1);
            if(objectinput instanceof PDSObjectInput)
                EvolvableHelper.requestRewriteOfEvolvedBlobbedObject();
        }
        return flag2;
    }

    /**
     * Method readOldVersion.
     * @param objectinput ObjectInput
     * @param l long
     * @param flag boolean
     * @param flag1 boolean
     * @return boolean
     * @throws IOException
     * @throws ClassNotFoundException
     */
    private boolean readOldVersion(ObjectInput objectinput, long l, boolean flag, boolean flag1)
        throws IOException, ClassNotFoundException
    {
        boolean flag2 = true;
        if(l != 7366880762506002674L)
            if(!flag1)
            {
                flag2 = super.readVersion(this, objectinput, l, false, false);
                if(flag2 && !flag && l != 957977401221134810L)
                    readVersion(this, objectinput, objectinput.readLong(), false, true);
            } else
            {
                throw new InvalidClassException(CLASSNAME, "Local class not compatible: stream classdesc externalizationVersionUID=" + l + " local class externalizationVersionUID=" + -3658319176036811472L);
            }
        return flag2;
    }
    
    /**
     * Method invoke.
     * @param task Task
     * @return Task
     * @throws WTException
     * @see com.ptc.core.adapter.server.impl.TypeAwareWebjectDelegate#invoke(Task)
     */
    public Task invoke(Task task)
    throws WTException
{
    Webject webject = task.getWebject();
    preset(task);
    Group group = task.getGroupIn();
    Vector vector = new Vector(0);
    if(super.objectRefs != null && super.objectRefs.length > 0 || super.whereClause != null && !super.targetType.equals(""))
        vector = getTargetTypeInstances();
    else
    if(group == null)
        throw new WTException(null, "com.ptc.core.adapter.server.impl.implResource", "14", null);
    if((vector == null || vector.size() < 1) && (group == null || group.getElementCount() < 1))
        throw new WTException(null, "wt.adapter.adapterResource", "20", null);
    String s = webject.paramValue("CONTAINER_REF");
    WTReference wtreference = null;
    if(!s.equals(""))
        wtreference = BasicWebjectDelegate.getObjectRefByUfid(s);
    try
    {
        Group group1 = new Group(super.groupOutName);
        group1.setClassName(super.groupOutClass);
        Element element2;
        for(Enumeration enumeration = vector.elements(); enumeration.hasMoreElements(); group1.addElement(element2))
        {
            TypeInstance typeinstance = (TypeInstance)enumeration.nextElement();
            TypeInstanceIdentifier typeinstanceidentifier = (TypeInstanceIdentifier)typeinstance.getIdentifier();
            wt.fc.ObjectReference objectreference = TypeIdentifierUtility.getObjectReference(typeinstanceidentifier);
            TypeIdentifier typeidentifier = (TypeIdentifier)typeinstanceidentifier.getDefinitionIdentifier();
            String s3 = typeidentifier.getTypename();
            String s4 = getOBID(typeinstance);
            element2 = new Element();
            element2.addAtt(new Att("class", s3));
            element2.addAtt(new Att("obid", s4));
            element2.setUfid(s4);
            element2.setFti(s3);
            String s6 = (String)typeinstance.get(DATA_FORMAT_ICON_ATI);
            //mvh: removed to display right icons for Type-driven content holders
            s6=null;
            String s8 = (String)typeinstance.get(AUTHORING_APP_ID_ATI);
            String s10 = (String)typeinstance.get(EPM_DOC_TYPE_ATI);
            String s12 = ObjectIconHelper.getContentIcons(s6, s8, s10);
            //System.out.println("build el for obid: "+s4+", contentIcon: "+s12);
            if(s12 != null)
                element2.addAtt(new Att("icon", s12));
            else
                element2.addAtt(new Att("icon", getIconURL(objectreference)));
            String s14 = (String)typeinstance.get(CHECKOUT_INFO_STATE_ATI);
            WorkInProgressState workinprogressstate1 = s14 == null ? null : WorkInProgressState.toWorkInProgressState(s14);
            Object obj1 = typeinstance.get(ONE_OFF_VERSION_ID_ATI);
            TypeInstanceIdentifier typeinstanceidentifier1 = (TypeInstanceIdentifier)typeinstance.get(CONTAINER_REFERENCE_ATI);
            WTContainerRef wtcontainerref1 = typeinstanceidentifier1 == null ? null : WTContainerRef.newWTContainerRef(ObjectIdentifier.newObjectIdentifier(typeinstanceidentifier1.getPersistenceIdentifier()));
            Vector vector2 = ObjectIconHelper.getObjectIconGlyphs(objectreference, wtcontainerref1, workinprogressstate1, obj1, wtreference);
            for(Enumeration enumeration3 = vector2.elements(); enumeration3.hasMoreElements(); element2.addAtt(new Att("glyph", (String)enumeration3.nextElement())));
        }

        if(group != null)
        {
            Element element1;
            for(Enumeration enumeration1 = group.getElements(); enumeration1.hasMoreElements(); group1.addElement(element1))
            {
                Element element = (Element)enumeration1.nextElement();
                String s1 = element.getUfid();
                String s2 = element.getFti();
                WTReference wtreference1 = BasicWebjectDelegate.getObjectRefByUfid(s1);
                element1 = new Element();
                element1.addAtt(new Att("class", s2));
                element1.addAtt(new Att("obid", s1));
                element1.setUfid(s1);
                element1.setFti(s2);
                String s5 = (String)element.getValue("authoringApplication");
                String s7 = (String)element.getValue("docType");
                String s9 = (String)element.getValue("standardIconStr");
                //mvh: removed to display right icons for Type-driven content holders
                s9=null;
                String s11 = ObjectIconHelper.getContentIcons(s9, s5, s7);
                if(s11 != null)
                    element1.addAtt(new Att("icon", s11));
                else
                    element1.addAtt(new Att("icon", getIconURL(wtreference1)));
                String s13 = (String)element.getValue("checkoutInfo.state");
                WorkInProgressState workinprogressstate = s13 == null ? null : WorkInProgressState.toWorkInProgressState(s13);
                Object obj = element.getValue("oneOffVersionInfo.identifier.oneOffVersionId");
                Object obj2 = element.getValue("containerReference");
                WTContainerRef wtcontainerref = null;
                if(obj2 instanceof String)
                    wtcontainerref = (WTContainerRef)BasicWebjectDelegate.getObjectRefByUfid((String)obj2);
                else
                if(obj2 instanceof TypeInstanceIdentifier)
                    wtcontainerref = WTContainerRef.newWTContainerRef(ObjectIdentifier.newObjectIdentifier(((TypeInstanceIdentifier)obj2).getPersistenceIdentifier()));
                Vector vector1 = ObjectIconHelper.getObjectIconGlyphs(wtreference1, wtcontainerref, workinprogressstate, obj, wtreference);
                for(Enumeration enumeration2 = vector1.elements(); enumeration2.hasMoreElements(); element1.addAtt(new Att("glyph", (String)enumeration2.nextElement())));
            }

        }
        Task task1 = new Task();
        task1.addVdb(group1);
        return task1;
    }
    catch(Exception exception)
    {
        if(exception instanceof WTException)
            throw (WTException)exception;
        else
            throw new WTException(exception);
    }
}
    /**
     * Method getIconURL.
     * @param wtreference WTReference
     * @return String
     * @throws WTException
     */
    private String getIconURL(WTReference wtreference)
    throws WTException
{
    try
    {
        IconDelegateFactory icondelegatefactory = new IconDelegateFactory();
        //mvh: modified the following line to reference the object, not the class
        IconDelegate icondelegate = icondelegatefactory.getIconDelegate((WTObject)wtreference.getObject());
        //System.out.println("icondelegate: "+icondelegate.getClass().getName());
        //icondelegate.setObject((WTObject)wtreference.getObject());
        IconSelector iconselector;
        for(iconselector = icondelegate.getStandardIconSelector(); !iconselector.isResourceKey(); iconselector = icondelegate.getStandardIconSelector())
            icondelegate = icondelegate.resolveSelector(iconselector);

        URLFactory urlfactory = new URLFactory();
        //System.out.println("iconselector.getIconKey(): "+iconselector.getIconKey() );

        return urlfactory.getHREF(iconselector.getIconKey());
    }
    catch(Exception exception)
    {
        if(exception instanceof WTException)
            throw (WTException)exception;
        else
            throw new WTException(exception);
    }
}

    /**
     * Method invoke2.
     * @param task Task
     * @return Task
     * @throws WTException
     */
    public Task invoke2(Task task)
        throws WTException
    {
        Webject webject = task.getWebject();
        preset(task);
        Group group = task.getGroupIn();
        Vector vector = new Vector(0);
        if(super.objectRefs != null && super.objectRefs.length > 0 || super.whereClause != null && !super.targetType.equals(""))
            vector = getTargetTypeInstances();
        else
        if(group == null)
            throw new WTException(null, "com.ptc.core.adapter.server.impl.implResource", "14", null);
        if((vector == null || vector.size() < 1) && (group == null || group.getElementCount() < 1))
            throw new WTException(null, "wt.adapter.adapterResource", "20", null);
        try
        {
            Group group1 = new Group(super.groupOutName);
            group1.setClassName(super.groupOutClass);
            Element element2;
            URLFactory urlfactory = new URLFactory();
            for(Enumeration enumeration = vector.elements(); enumeration.hasMoreElements(); group1.addElement(element2))
            {
                TypeInstance typeinstance = (TypeInstance)enumeration.nextElement();
                TypeInstanceIdentifier typeinstanceidentifier = (TypeInstanceIdentifier)typeinstance.getIdentifier();
                wt.fc.ObjectReference objectreference = TypeIdentifierUtility.getObjectReference(typeinstanceidentifier);
                TypeIdentifier typeidentifier = (TypeIdentifier)typeinstanceidentifier.getDefinitionIdentifier();
                String typeName = typeidentifier.getTypename();
                String obid = getOBID(typeinstance);
                element2 = buildIconElement(urlfactory, objectreference, typeName, obid);
/*                
                String s14 = (String)typeinstance.get(CHECKOUT_INFO_STATE_ATI);
                WorkInProgressState workinprogressstate1 = s14 == null ? null : WorkInProgressState.toWorkInProgressState(s14);
                //is it shared??
                Object obj1 = typeinstance.get(ONE_OFF_VERSION_ID_ATI);
                TypeInstanceIdentifier typeinstanceidentifier1 = (TypeInstanceIdentifier)typeinstance.get(CONTAINER_REFERENCE_ATI);
                WTContainerRef wtcontainerref1 = typeinstanceidentifier1 == null ? null : WTContainerRef.newWTContainerRef(ObjectIdentifier.newObjectIdentifier(typeinstanceidentifier1.getPersistenceIdentifier()));
                
                Vector vector2 = ObjectIconHelper.getObjectIconGlyphs(objectreference, wtcontainerref1, workinprogressstate1, obj1, wtreference);
                for(Enumeration enumeration3 = vector2.elements(); enumeration3.hasMoreElements(); element2.addAtt(new Att("glyph", (String)enumeration3.nextElement())));
*/            
            }

            if(group != null)
            {
                Element element1;
                for(Enumeration enumeration1 = group.getElements(); enumeration1.hasMoreElements(); group1.addElement(element1))
                {
                    Element element = (Element)enumeration1.nextElement();
                    String obid = element.getUfid();
                    String typeName = element.getFti();
                    WTReference wtreference1 = BasicWebjectDelegate.getObjectRefByUfid(obid);
                    element1 = buildIconElement(urlfactory, wtreference1, typeName, obid);
                }

            }
            Task task1 = new Task();
            task1.addVdb(group1);
            return task1;
        }
        catch(Exception exception)
        {
            if(exception instanceof WTException)
                throw (WTException)exception;
            else
                throw new WTException(exception);
        }
    }

    /**
	 * @param urlfactory
	 * @param objectreference
	 * @param typeName
	 * @param obid
	 * @return Element
     * @throws WTException
	 */
	private Element buildIconElement(URLFactory urlfactory, WTReference objectreference, String typeName, String obid) throws WTException {
		Element element2;
		element2 = new Element();
		element2.addAtt(new Att("class", typeName));
		element2.addAtt(new Att("obid", obid));
		element2.setUfid(obid);
		element2.setFti(typeName);
		
		IconSelector iconselector = getIconSelector(objectreference);
		element2.addAtt(new Att("icon", urlfactory.getHREF(iconselector.getIconKey()) ));
		Vector adors = iconselector.getAdornments();
		for (Iterator iter = adors.iterator(); iter.hasNext();) {
			element2.addAtt(new Att("glyph", (String) iter.next() ));
		}
		return element2;
	}

	/**
	 * Method getIconSelector.
	 * @param wtreference WTReference
	 * @return IconSelector
	 * @throws WTException
	 */
	private IconSelector getIconSelector(WTReference wtreference)
        throws WTException
    {
        try
        {
            IconDelegateFactory icondelegatefactory = new IconDelegateFactory();
            IconDelegate icondelegate = icondelegatefactory.getIconDelegate(wtreference.getReferencedClass());
            icondelegate.setObject((WTObject)wtreference.getObject());
            return icondelegate.getStandardIconSelector();            
        }
        catch(Exception exception)
        {
            if(exception instanceof WTException)
                throw (WTException)exception;
            else
                throw new WTException(exception);
        }
    }

    /**
     * Method _mthclass$.
     * @param s String
     * @return Class
     */
    static Class _mthclass$(String s)
    {
        try
        {
            return Class.forName(s);
        }
        catch(ClassNotFoundException classnotfoundexception)
        {
            throw new NoClassDefFoundError(classnotfoundexception.getMessage());
        }
    }

    private static final String RESOURCE = "com.ptc.core.adapter.server.impl.implResource";
    private static final String CLASSNAME;
    static final long serialVersionUID = 1L;
    public static final long EXTERNALIZATION_VERSION_UID = -3658319176036811472L;
    protected static final long OLD_FORMAT_VERSION_UID = 7366880762506002674L;
    private static final String ADAPTER_RESOURCE = "wt.adapter.adapterResource";
    private static final String CHECKOUT_INFO_STATE = "checkoutInfo.state";
    private static final String CONTAINER_REFERENCE = "containerReference";
    private static final String DATA_FORMAT_ICON = "standardIconStr";
    private static final String ONE_OFF_VERSION_ID = "oneOffVersionInfo.identifier.oneOffVersionId";
    private static final String AUTHORING_APP_ID = "authoringApplication";
    private static final String EPM_DOC_TYPE = "docType";
    private static AttributeTypeIdentifier CHECKOUT_INFO_STATE_ATI;
    private static AttributeTypeIdentifier CONTAINER_REFERENCE_ATI;
    private static AttributeTypeIdentifier ONE_OFF_VERSION_ID_ATI;
    private static AttributeTypeIdentifier DATA_FORMAT_ICON_ATI;
    private static AttributeTypeIdentifier AUTHORING_APP_ID_ATI;
    private static AttributeTypeIdentifier EPM_DOC_TYPE_ATI;

    static 
    {
        CLASSNAME = (com.ptc.core.adapter.server.impl.GetIconURLWebjectDelegate.class).getName();
        try
        {
            IdentifierFactory identifierfactory = (IdentifierFactory)DefaultServiceProvider.getService(com.ptc.core.meta.common.IdentifierFactory.class, "logical");
            CHECKOUT_INFO_STATE_ATI = (AttributeTypeIdentifier)identifierfactory.get("checkoutInfo.state", "wt.vc.wip.Workable");
            CONTAINER_REFERENCE_ATI = (AttributeTypeIdentifier)identifierfactory.get("containerReference", "wt.inf.container.WTContained");
            ONE_OFF_VERSION_ID_ATI = (AttributeTypeIdentifier)identifierfactory.get("oneOffVersionInfo.identifier.oneOffVersionId", "wt.vc.OneOffVersioned");
            DATA_FORMAT_ICON_ATI = (AttributeTypeIdentifier)identifierfactory.get("format.standardIconStr", "wt.content.FormatContentHolder");
            AUTHORING_APP_ID_ATI = (AttributeTypeIdentifier)identifierfactory.get("authoringApplication", "wt.epm.EPMDocument");
            EPM_DOC_TYPE_ATI = (AttributeTypeIdentifier)identifierfactory.get("docType", "wt.epm.EPMDocument");
        }
        catch(Exception exception)
        {
            throw new ExceptionInInitializerError(exception);
        }
    }
}


