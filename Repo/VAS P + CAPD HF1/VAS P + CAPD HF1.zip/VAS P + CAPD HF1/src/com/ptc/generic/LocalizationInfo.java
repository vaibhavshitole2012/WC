package com.ptc.generic;


import java.util.Locale;

import wt.method.*;
import wt.session.SessionHelper;
import wt.util.*;


public class LocalizationInfo implements RemoteAccess {
	
	public static String getStringFromServer(String resourceBundle, String key) throws WTException {
   	try {
   		if(RemoteMethodServer.ServerFlag)
   			return _getString(resourceBundle, key);
   		else
   			return (String)RemoteMethodServer.getDefault().invoke( "getStringFromServer", LocalizationInfo.class.getName(), null, 
   					new Class[] {String.class, String.class}, new Object[] {resourceBundle, key});
   	} catch(Exception e) {
   		if(e instanceof WTException) {
   			throw (WTException) e;
   		} else {
   			throw new WTException(e);
   		}
   	}
	}
	
	public static String _getString(String resourceBundle, String key) throws WTException {
		StringBuilder sb = new StringBuilder();
		sb.append("WTContext.getContext().getLocale()=");
		sb.append(WTContext.getContext().getLocale());
		sb.append("\nSessionHelper.getLocale()=");
		sb.append(SessionHelper.getLocale());
		sb.append("\nSessionHelper.manager.getLocale()=");
		sb.append(SessionHelper.manager.getLocale());
		sb.append("\nLocale.getDefault()=");
		sb.append(Locale.getDefault());
		
	   sb.append("\nWTMessage called without locale: ");
		sb.append(WTMessage.getLocalizedMessage(resourceBundle, key, null));
	   sb.append("\nWTMessage called with locale=SessionHelper.getLocale(): ");
		sb.append(WTMessage.getLocalizedMessage(resourceBundle, key, null, SessionHelper.getLocale()));
		return sb.toString();
	}
}
