package com.ptc.generic.iba;


import java.math.*;
import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.text.NumberFormat;
import java.text.ParsePosition;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import wt.fc.ObjectIdentifier;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.WTObject;
import wt.fc.collections.WTHashSet;
import wt.iba.definition.AbstractAttributeDefinition;
import wt.iba.definition.AttributeDefinition;
import wt.iba.definition.BooleanDefinition;
import wt.iba.definition.FloatDefinition;
import wt.iba.definition.IntegerDefinition;
import wt.iba.definition.RatioDefinition;
import wt.iba.definition.ReferenceDefinition;
import wt.iba.definition.StringDefinition;
import wt.iba.definition.TimestampDefinition;
import wt.iba.definition.URLDefinition;
import wt.iba.definition.UnitDefinition;
import wt.iba.definition.litedefinition.AbstractAttributeDefinizerView;
import wt.iba.definition.litedefinition.AttributeDefDefaultView;
import wt.iba.definition.litedefinition.BooleanDefView;
import wt.iba.definition.litedefinition.FloatDefView;
import wt.iba.definition.litedefinition.IntegerDefView;
import wt.iba.definition.litedefinition.StringDefView;
import wt.iba.definition.litedefinition.TimestampDefView;
import wt.iba.definition.litedefinition.UnitDefView;
import wt.iba.definition.service.IBADefinitionCache;
import wt.iba.definition.service.IBADefinitionHelper;
import wt.iba.value.AbstractValue;
import wt.iba.value.BooleanValue;
import wt.iba.value.DefaultAttributeContainer;
import wt.iba.value.FloatValue;
import wt.iba.value.IBAHolder;
import wt.iba.value.IBAHolderReference;
import wt.iba.value.IBAValueUtility;
import wt.iba.value.IntegerValue;
import wt.iba.value.RatioValue;
import wt.iba.value.ReferenceValue;
import wt.iba.value.StringValue;
import wt.iba.value.TimestampValue;
import wt.iba.value.URLValue;
import wt.iba.value.UnitValue;
import wt.iba.value.litevalue.AbstractValueView;
import wt.iba.value.litevalue.BooleanValueDefaultView;
import wt.iba.value.litevalue.FloatValueDefaultView;
import wt.iba.value.litevalue.IntegerValueDefaultView;
import wt.iba.value.litevalue.StringValueDefaultView;
import wt.iba.value.litevalue.TimestampValueDefaultView;
import wt.iba.value.litevalue.UnitValueDefaultView;
import wt.iba.value.service.IBAValueHelper;
import wt.introspection.WTIntrospectionException;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.org.WTPrincipal;
import wt.pds.StatementSpec;
import wt.query.ArrayExpression;
import wt.query.ClassAttribute;
import wt.query.OrderBy;
import wt.query.QueryException;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.query.SubSelectExpression;
import wt.query.TableExpression;
import wt.services.applicationcontext.implementation.DefaultServiceProvider;
import wt.session.SessionHelper;
import wt.type.TypedUtility;
import wt.units.Unit;
import wt.util.WTAttributeNameIfc;
import wt.util.WTContext;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;

import com.ptc.core.meta.common.AttributeIdentifier;
import com.ptc.core.meta.common.AttributeTypeIdentifier;
import com.ptc.core.meta.common.IdentifierFactory;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.server.IBAModel;
import com.ptc.core.meta.type.common.TypeInstance;
import com.ptc.core.meta.type.server.TypeInstanceUtility;
import com.ptc.generic.StringValuesHelper;
import com.ptc.ssp.util.AuthenticationHelper;

/**
 * This class can be used in static mode or instance mode. In static mode you
 * have to provide the IBA holder into each method (code block at beginning
 * of this file) In instance mode, you can instantiate this class with an IBA
 * holder (code block at end of this file) Code for instance mode was copied
 * from old IBATool
 */
public class IBAUtil implements RemoteAccess {

    private static final Hashtable<String, Class<? extends AbstractValue>> ibaValueClasses = new Hashtable<String, Class<? extends AbstractValue>>();
    private static final String CLASSNAME = IBAUtil.class.getName();
    
    private static final Logger logger = Logger.getLogger(CLASSNAME);
    private static final Logger loggerPerformance = Logger.getLogger(CLASSNAME + "_Performance");
    //TODO ECA5.0: clean this up, this important flag must not be driven by log4j. Just a prototype for performance analysis
    private static final Logger loggerSwitchIgnoreEmpty = Logger.getLogger(CLASSNAME + "_SwitchIgnoreEmpty");  
    private static final Logger loggerSwitchFastQuery = Logger.getLogger(CLASSNAME + "_SwitchFastQuery");  
    private static IBADefinitionCache ibaDefinitionsCache = null; //only instanciate it if we're on server-side
    private static final String IDA2A2 = "thePersistInfo.theObjectIdentifier.id";
    private static final IdentifierFactory idFactory = (IdentifierFactory) DefaultServiceProvider.getService(IdentifierFactory.class);
    public static final String IBAS_SEPARATOR = ";";
    public static final String MULTI_VALUE_SPLITTER = ": ";
    private static final Pattern MULTI_VALUE_PATTERN = Pattern.compile("^(?:\\d+:\\s)(.*)$");
    
    private static final boolean IS_SERVER = RemoteMethodServer.ServerFlag;
    
    static {
    	ibaValueClasses.put(TimestampDefinition.class.getCanonicalName(), TimestampValue.class);
        ibaValueClasses.put(IntegerDefinition.class.getCanonicalName(), IntegerValue.class);
        ibaValueClasses.put(RatioDefinition.class.getCanonicalName(), RatioValue.class);
        ibaValueClasses.put(UnitDefinition.class.getCanonicalName(), UnitValue.class);
        ibaValueClasses.put(ReferenceDefinition.class.getCanonicalName(), ReferenceValue.class);
        ibaValueClasses.put(URLDefinition.class.getCanonicalName(), URLValue.class);
        ibaValueClasses.put(FloatDefinition.class.getCanonicalName(), FloatValue.class);
        ibaValueClasses.put(StringDefinition.class.getCanonicalName(), StringValue.class);
        ibaValueClasses.put(BooleanDefinition.class.getCanonicalName(), BooleanValue.class);
        
        if(IS_SERVER) {
        	ibaDefinitionsCache = IBADefinitionCache.getIBADefinitionCache();
        }
    }
        
	/**
	 * retrieves the IBA values for the given attributes (ibaNames) for the set of given objects (objectRefs)
	 * 
	 * @param ibaNames
	 * @param objectRefs
	 * @throws java.lang.Exception
	 * @return
	 */
    public static Hashtable getIBAs(String[] ibaNames, long[] objectRefs)
    		throws Exception {

    	long timeStart = System.currentTimeMillis();

    	if(logger.isTraceEnabled()) {
    		logger.trace("entering .getIBAs(ibaNames, objectRefs) for ibaNames=" + Arrays.toString(ibaNames)
    				+ " objectRefs=" + Arrays.toString(objectRefs));
    	}

    	// Vector of AttributeDefinition objects for given ibaNames
    	List<AttributeDefinition> ibaDefVector = getIBADefs(ibaNames);
    	logger.trace("ibaDefVector size=" + ibaDefVector.size());

    	// an Attempt to reduce the number of Queries
    	// key: IBA Definition Class
    	// value: Vector of IBA Defs of that IBA Defintion Class (eg.
    	// StringDefinition)
    	Hashtable<String, Vector<AttributeDefinition>> ibaDefsForType = new Hashtable<String, Vector<AttributeDefinition>>();

    	// key: IBA Definition ID
    	// value: IBA Definition Name
    	Hashtable<Long, String> typeDefs = new Hashtable<Long, String>();
    	for (int i = 0; i < ibaDefVector.size(); i++) {
    		AttributeDefinition def = ibaDefVector.get(i);
    		String defName = def.getPersistInfo().getObjectIdentifier().getClassname();
    		Vector<AttributeDefinition> ibaDefs = null;
    		ibaDefs = ibaDefsForType.get(defName);
    		if (ibaDefs == null) {
    			ibaDefs = new Vector<AttributeDefinition>();
    		}
    		ibaDefs.add(def);
    		ibaDefsForType.put(defName, ibaDefs);
    		Long defId = Long.valueOf(def.getPersistInfo().getObjectIdentifier().getId());
    		typeDefs.put(defId, def.getName());
    	}

    	if(logger.isTraceEnabled()) {
    		logger.trace("ibaDefsForType: " + ibaDefsForType);
    	}

    	//now for the different kind of IBAs (String, Boolean, ...) send the query to DB
    	Hashtable<Long, Hashtable<String, Object>> ibas = new Hashtable<Long, Hashtable<String, Object>>();
    	Enumeration<String> keys = ibaDefsForType.keys();
    	long time1 = System.currentTimeMillis();
    	while (keys.hasMoreElements()) {
    		long time1a = System.currentTimeMillis();
    		String defkey = keys.nextElement();
    		Vector<AttributeDefinition> defs = ibaDefsForType.get(defkey);

    		long[] defIds = null;
    		defIds = new long[defs.size()];

    		AttributeDefinition def = null;

    		// array of IBA Def IDs (long) needed for SearchCondition
    		for (int i = 0; i < defs.size(); i++) {
    			def = defs.elementAt(i);
    			long attributeId = def.getPersistInfo().getObjectIdentifier() .getId();
    			defIds[i] = attributeId;
    		}
    		//logger.debug("defIds=" + defIds);

    		Class<? extends AbstractValue> attributeValueClass = getIBAValueClass(def.getPersistInfo().getObjectIdentifier().getClassname());
    		long time1b = System.currentTimeMillis();
    		long time1c = 0;
    		int resultSize = -1;


    		//new improved query for StringValue
    		if(loggerSwitchFastQuery.isDebugEnabled() && StringValue.class.equals(attributeValueClass)) {
    			logger.error("!!!!!! Using prototype code for StringValue !!!!!");
    			//do query:
    			QueryResult result = getStringValues(defIds, objectRefs);
    			time1c = System.currentTimeMillis();
    			resultSize = result.size();
    			if (logger.isDebugEnabled()) {
    				logger.debug("for " + defkey + " found #values:" + resultSize);
    			}

    			//loop over result:
    			Object[] resultSetEntry = null;
    			Long defId = null;
    			Long ibaHolderId = null;
    			String value = null;
    			String attributeName = null;
    			while (result.hasMoreElements()) {
    				resultSetEntry = (Object[]) result.nextElement();
    				//logger.debug(Arrays.toString(resultSetEntry));
    				defId = ((BigDecimal)resultSetEntry[2]).longValue();
    				ibaHolderId = ((BigDecimal)resultSetEntry[1]).longValue();
    				value = (String)resultSetEntry[3];
    				attributeName = typeDefs.get(defId);
    				
    				//if value is null, then continue because we cannot put null as a value into ibaValues
    				//actually shouldn't happen because the query filters on non-null and in Oracle for Strings that includes empty Strings, see 
    				if(value==null) {
    					logger.warn("found value=null for attributeName=" + attributeName + " ibaHolderId=" + ibaHolderId);
    					continue;
    				}

    				Hashtable<String, Object> ibaValues = ibas.get(ibaHolderId);

    				try {
    					// if this is the first iba for this objectreference
    					if (ibaValues == null) {
    						ibaValues = new Hashtable<String, Object>();
    						ibas.put(ibaHolderId, ibaValues);    				
    					}

    					//TODO ECA5.0 P1-2015? (Performance EC-Applet start): handling of multivalues
    					if (ibaValues.containsKey(attributeName)) {
    						if (MULTI_VALUE_PATTERN.matcher(value).matches()) {
    							// IBA is String, was already added to given object's IBAs
    							// but it has more values that match to multi value pattern.
    							// We must get all values and concatenates them.
    							//    						String concatenatedValue = getMultiValueIBA(value, result.getObjectVectorIfc().getVector());
    							//    						ibaValues.put(attributeName, concatenatedValue);
    							logger.error("multiValue IBA not yet handled! attributeName=" + attributeName + " value=" + value + " ibaHolderId=" + ibaHolderId);
    							ibaValues.put(attributeName, value); //TEMP: just use the latest found one
    						} else {
    							logger.error("IBA '" + attributeName + "' value = " + value
    									+ " doesn't match to multi value pattern. value = " + ((AbstractValue)ibaValues.get(attributeName)).getValueObject().toString() + " already read."
    									+ " IBAHolder = " + ibaHolderId + " and IBA = " + ((AbstractValue)ibaValues.get(attributeName)).getPersistInfo().toString());
    						}
    					} else {
    						ibaValues.put(attributeName, value);
    					}
    				} catch(Throwable t) {
    					//not nice, but we had NPE that I can't explain
    					//let's catch it and continue for the next values
    					logger.error("Exception follows for ibaHolderId=" + ibaHolderId + " defId=" + defId + " attributeName=" + attributeName);
    					t.printStackTrace();
    				}
    			}
    		//end: new improved query for StringValue
    		} else {

    			QueryResult result = getValues(attributeValueClass, defIds, objectRefs);
    			time1c = System.currentTimeMillis();
    			resultSize = result.size();

    			// Create hashtable1 with key: objectreference, value Hashtable.
    			// Hashtable2 contains key: ibaName, value: ibaValue.
    			if (logger.isDebugEnabled()) {
    				logger.debug("for " + defkey + " found #values:" + resultSize);
    			}
    			while (result.hasMoreElements()) {
    				Object[] resultSetEntry = (Object[]) result.nextElement();
    				AbstractValue value = (AbstractValue) resultSetEntry[0];
    				IBAHolderReference ibaholderReference = value.getIBAHolderReference();
    				Long defId = Long.valueOf(((ObjectIdentifier) value.getAbstractDefinition().getAttributeDefinitionReference().getKey()).getId());

    				Hashtable<String, Object> ibaValues = null;
    				Long key = Long.valueOf(((ObjectIdentifier) ibaholderReference.getKey()).getId());
    				ibaValues = ibas.get(key);

    				// if this is the first iba for this objectreference
    				if (ibaValues == null) {
    					ibaValues = new Hashtable<String, Object>();
    				}

    				String attributeName = typeDefs.get(defId);
    				if (ibaValues.containsKey(attributeName)
    						&& value instanceof StringValue) {
    					if (MULTI_VALUE_PATTERN.matcher(((StringValue) value).getValue()).
    							matches()) {
    						// IBA is StringValue, was already added to given object's IBAs
    						// but it has more values that match to multi value pattern.
    						// We must get all values and concatenates them.
    						String concatenatedValue = getMultiValueIBA((StringValue) value, result.getObjectVectorIfc().getVector());
    						ibaValues.put(attributeName, concatenatedValue);
    					} else {
    						logger.error("IBA '" + attributeName + "' value = " + ((StringValue) value).getValue()
    								+ " doesn't match to multi value pattern. value = " + ((AbstractValue)ibaValues.get(attributeName)).getValueObject().toString() + " already read."
    								+ " IBAHolder = " + ibaholderReference + " and IBA = " + ((AbstractValue)ibaValues.get(attributeName)).getPersistInfo().toString());
    					}
    				} else if (!ibaValues.containsKey(attributeName)) {
    					ibaValues.put(attributeName, value);
    				}

    				// put is back into the iba table
    				ibas.put(key, ibaValues);
    			}
    		}
    		long time1d = System.currentTimeMillis();
    		if(loggerPerformance.isDebugEnabled()) {
    			loggerPerformance.debug("getIBAs in loop: IBA retrieval for " + defkey 
    					+ ": prep=" + (time1b-time1a) 
    					+ " query=" + (time1c-time1b)
    					+ " processResult=" + (time1d-time1c)
    					+ "; query parameters were: " + defIds.length + " attribute names and " + objectRefs.length + " IBAHolder oids; found nr of values=" + resultSize);
    		}
    	}
    	long timeEnd = System.currentTimeMillis();
    	if(loggerPerformance.isDebugEnabled()) {
    		loggerPerformance.debug("getIBAs: total=" + (timeEnd-timeStart)
    				+ " overallPrep=" + (time1-timeStart)
    				+ " loopForAllQueries=" + (timeEnd-time1));
    	}
    	return ibas;
    }

    /**
     * Retrieves values of given attribute's class type and definitions' IDs for given objects.
     *
     * resulting query looks like this (when attributeValueClass is StringValue):<br>
     * SELECT *<br>
     * FROM StringValue<br>
     * WHERE idA3A4 IN (261055,40786, ... list of oids of the IBAHolders)<br>
     * AND idA3A6 in (11043,10954, ... list of oids of the StringDefinition)<br>
     * optional: AND (value2 IS NOT NULL )
     * 
     * @param attributeValueClass
     * @param defIds
     * @param objectRefs
     * @return
     * @throws QueryException
     * @throws WTException
     */
    private static QueryResult getValues(Class<? extends AbstractValue> attributeValueClass, long[] defIds, long[] objectRefs)
        throws QueryException, WTException {
    	
        QuerySpec qs1 = new QuerySpec();
        int valueIndex = qs1.addClassList(attributeValueClass, true);

        // resultset with ibaHolderRef in objectRefs array
        if (objectRefs.length == 0) {
            throw new WTException("objectRefs.length==0 in IBAUtil.getIBAs()");
        }
        SearchCondition sc = new SearchCondition(attributeValueClass, "theIBAHolderReference.key.id", objectRefs);
        qs1.appendWhere(sc, new int[] {valueIndex});
        qs1.appendAnd();

        // iba definition
        SearchCondition sc2 = new SearchCondition(attributeValueClass, "definitionReference.key.id", defIds);
        qs1.appendWhere(sc2, new int[] {valueIndex});
        
        //TODO ECA5.0: clean this up, this important flag must not be driven by log4j. Just a prototype for performance analysis
        //do not return values that are "" or null for StringValues
        if(loggerSwitchIgnoreEmpty.isDebugEnabled() && StringValue.class.equals(attributeValueClass)) {
        	qs1.appendAnd();
        	//filter on not null
        	SearchCondition scNotNull = new SearchCondition(attributeValueClass, "value2", false); //false: not null
        	qs1.appendWhere(scNotNull, new int[] {valueIndex});
        	
        	//filter on not empty not necessary, as Oracle treats '' as null for Strings
//        	qs1.appendAnd();
//        	//filter on not empty
//        	SearchCondition scNotEmpty = new SearchCondition(attributeValueClass, "value2", SearchCondition.NOT_EQUAL, ""); //false: not ""
//        	qs1.appendWhere(scNotEmpty, new int[] {valueIndex});
        }
        
        if(loggerPerformance.isTraceEnabled()) {
			loggerPerformance.trace("qs1=" + qs1);
        }

        return PersistenceHelper.manager.find((StatementSpec) qs1);
    }

    // PROTOTYPE CODE !!!
    //query that does not return instanciated StringValue objects. Instead, it just returns Strings
    private static QueryResult getStringValues(long[] defIds, long[] objectRefs) throws QueryException, WTException {
    	// resultset with ibaHolderRef in objectRefs array
    	if (objectRefs.length == 0) {
    		throw new WTException("objectRefs.length==0 in IBAUtil.getIBAs()");
    	}

    	QuerySpec qs = new QuerySpec();
    	int idxClass = qs.addClassList(StringValue.class, false);

    	qs.appendSelectAttribute(WTAttributeNameIfc.ID_NAME, idxClass, false);
    	//qs.appendSelectAttribute(WTAttributeNameIfc.OID_CLASSNAME, idxClass, false);
    	qs.appendSelectAttribute("theIBAHolderReference.key.id", idxClass, false);
    	qs.appendSelectAttribute("definitionReference.key.id", idxClass, false);
    	qs.appendSelectAttribute("value2", idxClass, false);

    	SearchCondition sc = new SearchCondition(StringValue.class, "theIBAHolderReference.key.id", objectRefs);
    	qs.appendWhere(sc, new int[] {idxClass});
    	qs.appendAnd();

    	// iba definition
    	SearchCondition sc2 = new SearchCondition(StringValue.class, "definitionReference.key.id", defIds);
    	qs.appendWhere(sc2, new int[] {idxClass});

    	//TODO ECA5.0: clean this up, this important flag must not be driven by log4j. Just a prototype for performance analysis
    	//do not return values that are "" or null for StringValues
    	if(loggerSwitchIgnoreEmpty.isDebugEnabled() && StringValue.class.equals(StringValue.class)) {
    		qs.appendAnd();
    		//filter on not null
    		SearchCondition scNotNull = new SearchCondition(StringValue.class, "value2", false); //false: not null
    		qs.appendWhere(scNotNull, new int[] {idxClass});

    		//filter on not empty not necessary, as Oracle treats '' as null for Strings
    	}

    	if(loggerPerformance.isTraceEnabled()) {
    		loggerPerformance.trace("qs=" + qs);
    	}

    	return PersistenceHelper.manager.find(qs);
    }

	/**
	 * returns Hashtable with specified IBA-Attributes for Enumeration of
	 * Business Objects.
	 *
	 * @param ibaAttributeNames
	 *           Vector with IBAAttributeNames
	 * @param wtObjects
	 *           Collection of Objects with IBAs
	 * @return IBAs of Referenced Objects
	 * @throws java.lang.Exception
	 * @author etrauca
	 * @since 3.00
	 */
	public static Hashtable getIBAs(Vector ibaAttributeNames,
			Collection wtObjects) throws Exception {

		Vector<String> refIds = new Vector<String>();

		Iterator<WTObject> objIter = wtObjects.iterator();
		while (objIter.hasNext()) {

			WTObject obj = objIter.next();
			refIds.add("" + obj.getPersistInfo().getObjectIdentifier().getId());
		}

		logger.debug("refIds=" + refIds);
		return getIBAs(ibaAttributeNames, refIds);
	}

   /**
    * returns first found for specified for given
    * Business Objects.
    *
    * @param attributeName
    *           name of IBA Definition
    * @param wtObject
    *           Business Objects with IBAs
    * @return String representation of IBA of Business Object
    * @throws wt.util.WTException when IBA value does not exist on given object
    * @author agasiorek
    * @since 4.00
    */
    public static String getIBAValueAsString(String attributeName, WTObject wtObject) throws WTException {
        Collection<WTObject> objects = new Vector<WTObject>();
        objects.add(wtObject);
        Vector<String> names = new Vector<String>();
        names.add(attributeName);

        Hashtable<Long, Hashtable<String, Object>> ibas = new Hashtable<Long, Hashtable<String, Object>>();
        try {
            ibas = getIBAs(names, objects);
        } catch (Exception e) {
            throw new WTException(e);
        }

        if (ibas.isEmpty()) {
            throw new WTException("Error: Could not find value for " + attributeName);
        } else {
            Object value = ibas.values().toArray()[0];
            if (value == null) {
                throw new WTException("Error: Could not find value for " + attributeName);
            }
            return String.valueOf(value);
        }
    }

	/**
	 * returns Hashtable with specified IBA-Attributes for WTObjects in
	 * QueryResult.
	 *
         * @param ibanames
         * @param ibaAttributeNames
	 *           Vector with IBAAttributeNames
	 * @param queryResult
	 *           a QueryResult including the IBAHolder in an indexed Array
	 * @param resultIndex
	 *           the Index of the IBAHolder in QueryResult Array
	 * @return IBAs of Referenced Objects
	 * @throws java.lang.Exception
	 * @author etrauca
	 * @since 3.00
	 */
	public static Hashtable getIBAs(String[] ibanames, QueryResult queryResult,
			int resultIndex) throws Exception {

		long refIds[] = new long[queryResult.size()];

		Enumeration<Object[]> queryEnum = queryResult.reset();
		for (int i = 0; i < queryResult.size(); i++) {

			Object[] objArray = queryEnum.nextElement();
			WTObject obj = (WTObject) objArray[resultIndex];

			refIds[i] = obj.getPersistInfo().getObjectIdentifier().getId();
		}

		return IBAUtil.getIBAs(ibanames, refIds);
	}

	/**
	 * This Method is useful to get a specified Value in a Hashtable returned by
	 * the getIBAs Methods of this Class.
	 *
	 * @param ibaTable
	 *           the IBATable that is returned by the getIBAs Method
	 * @param object
	 *           the WTObject that has IBAs in the ibaTable
	 * @param attributeName
	 *           Name of the IBA that is requested.
	 * @return the IBA Value
	 * @author etrauca
	 * @since 3.00
	 */
	public static Object getIBAValue(Hashtable ibaTable, WTObject object,
			String attributeName) {
		long id = object.getPersistInfo().getObjectIdentifier().getId();
		return getIBAValue(ibaTable, id, attributeName);
	}

	/**
         * This Method is useful to get a specified Value in a Hashtable returned by
         * the getIBAs Methods of this Class.
         *
	 * @param ibaTable   the IBATable that is returned by the getIBAs Method
	 * @param objectId  id of Object as a long value
	 * @param attributeName Name of the IBA that is requested.
	 * @author emensel
	 * @since 3.1
	 * @return
	 */
	public static Object getIBAValue(Hashtable ibaTable, long objectId, String attributeName)
	{
            Object attValue = null;
            Long id = Long.valueOf(objectId);
            if (ibaTable != null)
            {
                Hashtable objectIBAs = (Hashtable) ibaTable.get(id);
                if (objectIBAs != null)
                {
                    attValue = objectIBAs.get(attributeName);
                }
            }
            return attValue;
        }

	/**
	 * This Method is useful to get a specified Value in a Hashtable returned by
	 * the getIBAs Methods of this Class. The Method returns Values as Java
	 * Standard Objects.
	 *
	 * @param ibaTable
	 *           the IBATable that is returned by the getIBAs Method
	 * @param object
	 *           the WTObject that has IBAs in the ibaTable
	 * @param attributeName
	 *           Name of the IBA that is requested.
	 * @return the IBA Value
         * @throws WTException
         * @author etrauca
	 * @since 3.00
	 */
	public static Object getIBAValueAsJavaStandardObj(Hashtable ibaTable,
			WTObject object, String attributeName) throws WTException {

		Object attValue = null;

		attValue = getIBAValue(ibaTable, object, attributeName);

		attValue = convertIBAValueToJavaStandardObj(attValue);

		return attValue;
	}


	/**
         * This Method is useful to get a specified Value in a Hashtable returned by
         * the getIBAs Methods of this Class. The Method returns Values as Java
         * Standard Objects.
         *
         * @param ibaTable
         *           the IBATable that is returned by the getIBAs Method
         * @param objectId
         * @param attributeName
         *           Name of the IBA that is requested.
         * @return the IBA Value
         * @throws WTException
         * @author emensel
         * @since 3.1
         */
	public static Object getIBAValueAsJavaStandardObj(Hashtable ibaTable,
                long objectId, String attributeName) throws WTException {

                Object attValue = null;

                attValue = getIBAValue(ibaTable, objectId, attributeName);

                attValue = convertIBAValueToJavaStandardObj(attValue);

                return attValue;
        }


	/**
	 * converts the WT IBA Value to an Java Standard Object.
	 *
         * @param attValue
	 * @return the Java Standard Object
         * @throws WTException
         * @author etrauca
	 * @since 3.00
	 */
	public static Object convertIBAValueToJavaStandardObj(Object attValue)
			throws WTException {

		if (attValue instanceof StringValue) {
			StringValue raw = (StringValue) attValue;
			attValue = raw.getValue();
		} else if (attValue instanceof TimestampValue) {
			TimestampValue raw = (TimestampValue) attValue;
			attValue = raw.getValue();
		} else if (attValue instanceof BooleanValue) {
			BooleanValue raw = (BooleanValue) attValue;
			attValue = Boolean.valueOf(raw.isValue());
		} else if (attValue instanceof FloatValue) {
			FloatValue raw = (FloatValue) attValue;
			attValue = new Float(raw.getValue());
		} else if (attValue instanceof IntegerValue) {
			IntegerValue raw = (IntegerValue) attValue;
			attValue = Long.valueOf(raw.getValue());
		} else {

			if (attValue == null) {
				// do nothing (Shit happens!)
			} else {
				throw new WTException("IBAUtil: unknown ibatype = "
						+ attValue.getClass());
			}
		}

		return attValue;
	}

	public static List<AttributeDefinition> getIBADefs(String... names) throws Exception {
		List<AttributeDefinition> attributesDefinitions = new ArrayList<AttributeDefinition>(names.length);
		for (String name : names) {
			AttributeDefinition attDefinition = getDefinition(name);
			if (attDefinition != null) {
				attributesDefinitions.add(attDefinition);
			}
		}
		return attributesDefinitions;
	}
	
	public static Class<? extends AbstractValue> getIBAValueClass(AttributeDefinition definition) throws Exception {
		return getIBAValueClass(definition.getPersistInfo().getObjectIdentifier().getClassname());
	}

    public static Class<? extends AbstractValue> getIBAValueClass(String defClassname) throws Exception {
        return ibaValueClasses.get(defClassname);
    }

	/**
	 *
	 * @param vIbaNames
	 * @param objectRefs
	 * @throws java.lang.Exception
	 * @return
	 */
	public static Hashtable getIBAs(Vector vIbaNames, Vector objectRefs)
			throws Exception {
		long objectRefs2[] = new long[objectRefs.size()];

		for (int i = 0, n = objectRefs.size(); i < n; i++) {
			objectRefs2[i] = Long.parseLong((String) objectRefs.elementAt(i));
		}

		return getIBAs(vIbaNames, objectRefs2);
	}

	/**
	 *
	 * @param vIbaNames
	 * @param objectRefs
	 * @throws java.lang.Exception
	 * @return
	 */
	public static Hashtable getIBAs(Vector vIbaNames, long[] objectRefs)
			throws Exception {
		String ibaNames[] = (String[]) vIbaNames.toArray(new String[vIbaNames.size()]);
		return getIBAs(ibaNames, objectRefs);
	}
	
	/**
     * Returns an IBA attribute definition from the cache or database given the
     * external hierarchy id.
     * 
     * @param extHid external hierarchy id
     * 
	 * @return AbstractAttributeDefinition
	 * @throws WTException
	 */
	   public static AbstractAttributeDefinition getIBADefinition(String extHid) throws WTException {
        AbstractAttributeDefinition attributeDef = IBAModel.getIBADefinitionByHid(extHid);
        if (attributeDef != null) {
            return attributeDef;
        } else {
            return null;
        }
    }
	
	private static <T extends AttributeDefinition> T getDefinition(String name, Class<T> definitionClass) throws WTException {
		AttributeDefinition definition = getDefinition(name);
		if (definition != null && definitionClass.isAssignableFrom(definition.getClass())) {
			return (T) definition;
		} else {
			throw new WTException("Attribute " + name + " doesn't exist or has definition type different than " + definitionClass.getName());
		}
	}

	//the ibaDefinitionCache is only hold server-side. Because it cannot fill itself on the client-side
	protected static AttributeDefinition getDefinition(String name) throws WTException {
		
		/**
		 * AW 21.01.14: Mybe it could be a better solution to use OOTB implementation to retrieve the AttributeDefinition: 
		 * AbstractAttributeDefinition attributeDef = IBAModel.getIBADefinitionByHid(extHid);
		 */
		
		if(IS_SERVER) {
			return _getDefinition(name);
		} else {
			try {
				return (AttributeDefinition)RemoteMethodServer.getDefault().invoke("_getDefinition",CLASSNAME,null, new Class[]{String.class}, new Object[]{name});
			} catch(Exception e) {
				if(e instanceof WTException) {
					throw (WTException)e; 
				} else {
					 throw new WTException(e);
				}
			}
		}
	}
	//this is the server-side method
	public static AttributeDefinition _getDefinition(String name) throws WTException {
		if(!IS_SERVER) {
			throw new WTException("IBAUtil._getDefinition() must only be used on the server-side!");
		}
		return ibaDefinitionsCache.getAttributeDefinition(name);
	}
	
	private static <T> T getIBA(String ibaName, Persistable ibaHolder, Class<? extends AbstractValue> valueClass, 
			Class<? extends AttributeDefinition> definitionClass)  throws WTException, QueryException {
		if (ibaName == null || ibaHolder == null) {
			logger.warn((ibaName == null ? "ibaName" : ibaHolder == null ? "ibaHolder" : "") + " can't be null");
			return null;
		}
		if (logger.isDebugEnabled()) {
			logger.debug("Getting value for attribute " + ibaName + " for object " + ibaHolder.getPersistInfo().getObjectIdentifier());
		}
//		if(("snType".equals(ibaName) || "isBaukasten".equals(ibaName))  &&  logger.isTraceEnabled()) {
//			(new WTException("who called getIBA for ibaName=" + ibaName)).printStackTrace();
//		}
		AttributeDefinition definition = null;
		try {
			definition = getDefinition(ibaName, definitionClass);
		} catch (WTException exception) {
			logger.error(exception.getLocalizedMessage(), exception);
			return null;
		}
		long attributeId = definition.getPersistInfo().getObjectIdentifier().getId();
		long objectId = ibaHolder.getPersistInfo().getObjectIdentifier().getId();

		QuerySpec query = new QuerySpec();
		int valueIndex = query.addClassList(valueClass, true);
		int[] indices = new int[] {valueIndex};
		// resultset with ibaHolderRef in objectRefs array
		SearchCondition sc1 = new SearchCondition(valueClass,"theIBAHolderReference.key.id", SearchCondition.EQUAL, objectId);
		query.appendWhere(sc1, indices);
		query.appendAnd();
		// iba definition
		SearchCondition sc2 = new SearchCondition(valueClass, "definitionReference.key.id", SearchCondition.EQUAL, attributeId);
		query.appendWhere(sc2, indices);
		QueryResult result = PersistenceHelper.manager.find((StatementSpec) query);
		if (result.hasMoreElements()) {
			Object[] resultEntry = (Object[]) result.nextElement();
			AbstractValue value = (AbstractValue) resultEntry[valueIndex];
			try {
				return getValue(value, valueClass);
			} catch (WTException exception) {
				logger.error(exception.getLocalizedMessage(), exception);
				return null;
			}
		}
		return null;
	}

	private static <T> T getValue(AbstractValue value, Class<? extends AbstractValue> valueClass) throws WTException {
		if (value != null && valueClass.isAssignableFrom(value.getClass())) {
			return (T) valueClass.cast(value).getValueObject();
		} else {
			throw new WTException("Attribute's value is null or has type different than " + valueClass.getName());
		}
	}
	
	/**
	 * @param ibaName
	 * @param ibaHolder
	 * @return Date
	 * @throws WTException
	 */
	public static Date getDateIBA(String ibaName, Persistable ibaHolder) throws WTException {
		Timestamp timestamp = getIBA(ibaName, ibaHolder, TimestampValue.class, TimestampDefinition.class);
		return new Date(timestamp.getTime());
	}
	
	/**
	 * @param ibaName
	 * @param ibaHolder
	 * @return String
	 * @throws WTException
	 */
	public static String getStringIBA(String ibaName, Persistable ibaHolder) throws WTException {
		return getIBA(ibaName, ibaHolder, StringValue.class, StringDefinition.class);
	}

	/**
	 * @param ibaName
	 * @param ibaHolder
	 * @return String
	 * @throws WTException
	 */
	public static Integer getIntegerIBA(String ibaName, Persistable ibaHolder) throws WTException {
		Number value = getIBA(ibaName, ibaHolder, IntegerValue.class, IntegerDefinition.class);
		if (value instanceof Long) {
			return ((Long) value).intValue(); // cast to Integer because it was done that way from the beginning
		}
		return null;
	}

	/**
	 * @param ibaName
	 * @param ibaHolder
	 * @return Double
	 * @throws WTException
	 */
	public static Double getFloatIBA(String ibaName, Persistable ibaHolder) throws WTException {
		Number value = getIBA(ibaName, ibaHolder, FloatValue.class, FloatDefinition.class);
		return new Double(value.doubleValue());
	}

    /**
     * @param ibaName
     * @param ibaHolder
     * @return Double
     * @throws WTException
     */
    public static Unit getUnitIBA(String ibaName, Persistable ibaHolder) throws WTException {
        Number ibaValue = getIBA(ibaName, ibaHolder, UnitValue.class, UnitDefinition.class);
        if (ibaValue != null) {
        	
        	// special behavior, because UnitValue$UnitNumber is hidden. we need to parse the values...
        	int digits = 2;
        	String unit = null;
        	double value = ibaValue.doubleValue();
        	
        	if ("wt.iba.value.UnitValue$UnitNumber".equals(ibaValue.getClass().getName())) {
            	String stringValue = ibaValue.toString();
        		if (stringValue != null) {
        		    String[] split = stringValue.split(" ");
        		    
        		    if (split != null && split.length == 2) {
        		    	ParsePosition localParsePosition = new ParsePosition(0);
        		        Number number = NumberFormat.getNumberInstance(WTContext.getContext().getLocale()).parse(split[0], localParsePosition);
        		        if (number != null){
        		        	value = number.doubleValue();
        		        	
        		        	if (split[0].contains("E")) {
            		            digits = split[0].substring(0, split[0].indexOf('E')).length() - 1;
            		        } else {
            		            digits = split[0].length() - 1;
            		        }
            		        
            		        unit = split[1];
        		        }        		        
        		    }
        		}
            }
        	
        	return new Unit(value, digits, unit);
        } else {
            return null;
        }
    }

    /**
	 * @param ibaName
	 * @param ibaHolder
	 * @return Boolean
	 * @throws WTException
	 */
	public static Boolean getBooleanIBA(String ibaName, Persistable ibaHolder) throws WTException {
		return getIBA(ibaName, ibaHolder, BooleanValue.class, BooleanDefinition.class);
	}

	/**
	 * Does NOT persist IbaHolder! That needs to happen separately, otherwise values will not be stored
	 * 
	 * @param ibaHolder
	 * @param ibaName
	 * @throws WTException
	 */
    public static void deleteValueOnAttribContainer(IBAHolder ibaHolder, String ibaName) throws WTException {
        try {
            DefaultAttributeContainer container = (DefaultAttributeContainer) ibaHolder.getAttributeContainer();
            if (ibaHolder.getAttributeContainer() == null) {
                ibaHolder = IBAValueHelper.service.refreshAttributeContainerWithoutConstraints(ibaHolder);
                container = (DefaultAttributeContainer) ibaHolder.getAttributeContainer();
            }
            AttributeDefDefaultView attributeDefinition = IBADefinitionHelper.service.getAttributeDefDefaultViewByPath(
                    ibaName);
            if (attributeDefinition != null) {
                container.deleteAttributeValues(attributeDefinition);
            }
            ibaHolder.setAttributeContainer(container);
        } catch (RemoteException ex) {
            throw new WTException(ex);
        }
    }
        
    /**
     *
     * Updates the given iba with the value. If the iba do no exist the system
     * creates the iba. Method works only on working copy of ibaHolder. Exception
     * is thrown if you pass original copy.
     * All IBA values will be removed if passed null for ibaValue.
     * <p>
     * <b>You have to save IBAHolder after setting IBAs</b>
     * <b>Supports only single value IBAs, Exception is thrown if multi-value IBA found</p>
     * </p>
     * <ul>
     *  <li>First a check is done if any value exists:
     *   <ul>
     *    <li>if there is no value - create new and add it to ibaHolder</li>
     *    <li>if there is only one value - update it and save</li>
     *    <li>if there are more than one value - throw WTException</li>
     *   </ul>
     *  </li>
     *  <li>Then object is updated only if value was really changed (nothing is done if
     *  IBA already have same value - String.equals() is used)</li>
     * </ul>
     *
     * @param ibaHolder object that will have attribute value set
     * @param ibaName name of attribute to change/create
     * @param ibaValue value for attribute (may be null, all IBA values will be removed from database then)
     * @throws wt.util.WTException if multi valued IBA was passed for update or if anything failed
     */
    public static void updateStringValueOnAttribContainer(IBAHolder ibaHolder,
            String ibaName, String ibaValue)
            throws WTException {
        updateStringValueOnAttribContainer(ibaHolder, ibaName, ibaValue, false);
    }

    /**
     *
     * Updates the given iba with the value. If the iba do no exist the system
     * creates the iba. Method works only on working copy of ibaHolder. Exception
     * is thrown if you pass original copy.
     * All IBA values will be removed if passed null for ibaValue.
     * <p>
     * <b>You have to save IBAHolder after setting IBAs</b>
     * <b>Supports only single value IBAs, Exception is thrown if multi-value IBA found
     * (Only exception is if true was passed for clearOtherValues)</p>
     * </p>
     * <ul>
     *  <li>First a check is done if any value exists:
     *   <ul>
     *    <li>if there is no value - create new and add it to ibaHolder</li>
     *    <li>if there is only one value - update it and save</li>
     *    <li>if there are more than one value - remove other values if true was passed for clearOtherValues
     *    or throw exception otherwise</li>
     *   </ul>
     *  </li>
     *  <li>Then object is updated only if value was really changed (nothing is done if
     *  IBA already have same value - String.equals() is used)</li>
     * </ul>
     *
     * @param ibaHolder object that will have attribute value set
     * @param ibaName name of attribute to change/create
     * @param ibaValue value for attribute (may be null, all IBA values will be removed from database then)
     * @param clearOtherValues remove all other iba values (if multi valued ibak)
     * @throws wt.util.WTException if multi valued IBA was passed for update or if anything failed
     */
    public static void updateStringValueOnAttribContainer(IBAHolder ibaHolder,
            String ibaName, String ibaValue, boolean clearOtherValues)
            throws WTException {
        try {
            if (ibaHolder.getAttributeContainer() == null) {
                ibaHolder = IBAValueHelper.service.refreshAttributeContainerWithoutConstraints(ibaHolder);
            }

            TypeIdentifier typeId = TypedUtility.getTypeIdentifier(ibaHolder);
            TypeInstance typeInstance = TypeInstanceUtility.getIBAValues(ibaHolder);
            AttributeTypeIdentifier attTypeId = (AttributeTypeIdentifier) idFactory.get(ibaName, typeId);

            AttributeIdentifier[] attIds = typeInstance.getAttributeIdentifiers(attTypeId);

            if (ibaValue == null) {
                if (attIds.length > 0) {
                    logger.debug("Requested null value and some value was already in database. Removing all old values");
                    typeInstance.remove(attTypeId);
                }
            } else {
                String currentValue = null;
                AttributeIdentifier attId = null;
                if (attIds.length == 0) {
                    logger.debug("Found no previous value. Creating new");
                    createIBAStringValue(ibaHolder, ibaName, ibaValue);
                    return;
                } else if (attIds.length == 1) {
                    logger.debug("Found old value. Will update");
                    currentValue = (String) typeInstance.get(attIds[0]);
                    attId = attIds[0];
                } else if (clearOtherValues) {
                    logger.debug("Found many values. Will remove all but new one");
                    currentValue = (String) typeInstance.get(attIds[0]);
                    attId = attIds[0];
                    for (int i = 1; i < attIds.length; i++) {
                        AttributeIdentifier idToRemove = attIds[i];
                        typeInstance.remove(idToRemove);
                    }
                } else {
                    throw new WTException("Trying to update multi-value IBA: " + ibaName
                            + " with updateStringValueOnAttribContainer which handle only single valued attributes.");
                }

                if (!ibaValue.equals(currentValue)) {
                    if (logger.isDebugEnabled()) {
                        logger.debug("Setting value for: " + attTypeId.getAttributeName() + " to value: " + ibaValue);
                    }
                    typeInstance.put(attId, ibaValue);
                } else {
                    logger.debug("Change to the same value. Doing nothing");
                }
            }
            logger.debug("Updating IBAHolder");
            TypeInstanceUtility.updateIBAValues(ibaHolder, typeInstance);
        } catch (RemoteException ex) {
            throw new WTException(ex.getCause(), "Error refreshing attribute container for IBA Holder");
        }
    }

    /**
     * Does NOT persist IbaHolder! That needs to happen separately, otherwise values will not be stored
     * 
     * @param ibaHolder
     * @param ibaName
     * @param ibaValue
     * @throws WTException
     */
	public static void createIBAStringValue(IBAHolder ibaHolder, String ibaName, String ibaValue) throws WTException {
		logger.debug("createIBAStringValue() started");
		DefaultAttributeContainer attribContainer = (DefaultAttributeContainer) ibaHolder.getAttributeContainer();
		if (attribContainer == null) {
			throw new WTException("can not create IBA if no attributeContainer was initialized");
		}

		// Get reference definition (e.g. CAN-Netzwerk)
		AbstractAttributeDefinizerView stringDefinizer = null;
		try {
			stringDefinizer = IBADefinitionHelper.service.getAttributeDefDefaultViewByPath(ibaName);
		} catch (RemoteException remoteexception) {
			Object aobj[] = { "getAttributeOrganizerRoots" };
			throw new WTException(remoteexception, "wt.fc.fcResource", "0", aobj);
		}
		if (stringDefinizer == null) {
			throw new WTException("Error: Could not find definition for " + ibaName);
		}

		// Create new reference attribute.
		StringValueDefaultView stringValue = newStringValue(stringDefinizer, ibaValue);

		// Add new reference attribute to attribContainer.
		try {
			attribContainer.addAttributeValue(stringValue);
		} catch (Exception exception) {
			logger.error(exception.getLocalizedMessage(), exception);
		}
		logger.debug("createIBAStringValue() finished");
	}
	
	/**
	 * Updates the given iba with the value. If the iba do no exist the system creates the iba.
	 * 
	 * You must save the IbaHolder manually.
	 * 
	 * @param ibaHolder
	 *            the IbaHolder
	 * @param ibaName
	 *            the name of the iba
	 * @param ibaValue
	 *            the new value of the iba
	 * @throws wt.util.WTException
	 *             throws WTException
	 */
	public static void updateTimestampValueOnAttribContainer(IBAHolder ibaHolder, String ibaName, Date ibaValue) throws WTException {
		logger.debug("ibaName=" + ibaName + " ibaValue=" + ibaValue);
		boolean found = false;
		DefaultAttributeContainer attribContainer = (DefaultAttributeContainer) ibaHolder.getAttributeContainer();
		if (attribContainer == null) {
			try {
				ibaHolder = IBAValueHelper.service.refreshAttributeContainer(ibaHolder, null, null, null);
				attribContainer = (DefaultAttributeContainer) ibaHolder.getAttributeContainer();
			} catch (RemoteException ex) {
				logger.error(ex.getLocalizedMessage(), ex);
			}
		}
		try {
			if (attribContainer != null) {
				AbstractValueView abstractValuesView[] = attribContainer.getAttributeValues();

				for (int k = 0; k < abstractValuesView.length; k++) {
					logger.debug("definition name: " + abstractValuesView[k].getDefinition().getName());
					if (abstractValuesView[k].getDefinition().getName().equals(ibaName) && abstractValuesView[k] instanceof TimestampValueDefaultView) {
						logger.debug("found");
						TimestampValueDefaultView theIBA = (TimestampValueDefaultView) abstractValuesView[k];
						theIBA.setValue(new Timestamp(ibaValue.getTime()));

						attribContainer.updateAttributeValue(theIBA);
						found = true;
						break;
					}
				}
			}
			if (!found) {
				logger.debug("not found, going to create");
				createIBATimestampValue(ibaHolder, ibaName, ibaValue);
			}
		} catch (Exception e) {
			logger.error(e.getLocalizedMessage(), e);
		}
		logger.debug("updateIBATimestampValue() finished ibaH=" + ibaHolder + " ibaH.hc=" + ibaHolder.hashCode());
	}
	
	
	public static void createIBATimestampValue(IBAHolder ibaHolder, String ibaName, Date ibaValue) throws WTException {
		logger.debug("createIBATimestampValue() started");
		DefaultAttributeContainer attribContainer = (DefaultAttributeContainer) ibaHolder.getAttributeContainer();
		if (attribContainer == null) {
			throw new WTException("can not create IBA if no attributeContainer was initialized");
		}

		// Get reference definition (e.g. CAN-Netzwerk)
		AbstractAttributeDefinizerView timestampDefinizer = null;
		try {
			timestampDefinizer = IBADefinitionHelper.service.getAttributeDefDefaultViewByPath(ibaName);
		} catch (RemoteException remoteexception) {
			Object aobj[] = { "getAttributeOrganizerRoots" };
			throw new WTException(remoteexception, "wt.fc.fcResource", "0", aobj);
		}
		if (timestampDefinizer == null) {
			throw new WTException("Error: Could not find definition for " + ibaName);
		}

		// Create new reference attribute.
		TimestampValueDefaultView timestampValue = newTimeStampValue(timestampDefinizer, ibaValue);

		// Add new reference attribute to attribContainer.
		try {
			attribContainer.addAttributeValue(timestampValue);
		} catch (Exception exception) {
			logger.error(exception.getLocalizedMessage(), exception);
		}
		logger.debug("createIBATimestampValue() finished");
	}
	
	private static TimestampValueDefaultView newTimeStampValue(
			AbstractAttributeDefinizerView defView, Date dateValue) {
		logger.debug("newTimestampValue() started");
		TimestampValueDefaultView newTimeStampView = null;

		if (dateValue == null) {
			dateValue = new Date();
		}
		
		try {
			newTimeStampView = new TimestampValueDefaultView((TimestampDefView) defView, new Timestamp(dateValue.getTime()));
		} catch (Exception ive) {
			logger.error("Can't create Timestamp value");
			logger.error(ive.getLocalizedMessage(), ive);
			newTimeStampView = null;
		}
		logger.debug("newTimestampValue() finished");
		return newTimeStampView;
	}
	
    private static StringValueDefaultView newStringValue(
			AbstractAttributeDefinizerView defView, String valueStr) {
		logger.debug("newStringValue() started");
		
		if(defView==null) {
			logger.error("Can't create string value for AttributeDefinizerView==null; given valueStr=" + valueStr);
			return null;
		}
		if(!(defView instanceof StringDefView)) {
			logger.error("Can't create string value when given defView is not an instance of StringDefView. defView=" 
				+ defView + " defView.name=" + defView.getName()
				+ "given valueStr=" + valueStr);
			return null;
		}
		
		StringValueDefaultView newStringView = null;

		if (valueStr == null) {
			valueStr = "Default";
		}

		try {
			newStringView = new StringValueDefaultView((StringDefView) defView, valueStr);
		} catch (Exception ive) {
			logger.error("Can't create string value for defView=" + defView + " valueStr=" + valueStr);
			logger.error(ive.getLocalizedMessage(), ive);
			newStringView = null;
		}
		logger.debug("newStringValue() finished");
		return newStringView;
	}

	/**
	 * Updates the given iba with the value. If the iba do no exist the system creates the iba.
	 * 
	 * You must save the IbaHolder manually.
	 * 
	 * @param ibaHolder
	 *            the IbaHolder
	 * @param ibaName
	 *            the name of the iba
	 * @param ibaValue
	 *            the new value of the iba
	 * @throws wt.util.WTException
	 *             throws WTException
	 */
	public static void updateBooleanValueOnAttribContainer(IBAHolder ibaHolder, String ibaName, boolean ibaValue) throws WTException {
		logger.debug("ibaName=" + ibaName + " ibaValue=" + ibaValue);
		boolean found = false;
		DefaultAttributeContainer attribContainer = (DefaultAttributeContainer) ibaHolder.getAttributeContainer();
		if (attribContainer == null) {
			try {
				ibaHolder = IBAValueHelper.service.refreshAttributeContainer(ibaHolder, null, null, null);
				attribContainer = (DefaultAttributeContainer) ibaHolder.getAttributeContainer();
			} catch (RemoteException ex) {
				logger.error(ex.getLocalizedMessage(), ex);
			}
		}
		try {
			if (attribContainer != null) {
				AbstractValueView abstractValuesView[] = attribContainer.getAttributeValues();

				for (int k = 0; k < abstractValuesView.length; k++) {
					logger.debug("definition name: " + abstractValuesView[k].getDefinition().getName());
					if (abstractValuesView[k].getDefinition().getName().equals(ibaName) && abstractValuesView[k] instanceof BooleanValueDefaultView) {
						logger.debug("found");
						BooleanValueDefaultView theIBA = (BooleanValueDefaultView) abstractValuesView[k];
						theIBA.setValue(ibaValue);

						attribContainer.updateAttributeValue(theIBA);
						found = true;
						break;
					}
				}
			}
			if (!found) {
				logger.debug("not found, going to create");
				createIBABooleanValue(ibaHolder, ibaName, ibaValue);
			}
		} catch (Exception e) {
			logger.error(e.getLocalizedMessage(), e);
		}
		logger.debug("updateIBABooleanValue() finished ibaH=" + ibaHolder + " ibaH.hc=" + ibaHolder.hashCode());
	}

	public static void createIBABooleanValue(IBAHolder ibaHolder, String ibaName, boolean ibaValue) throws WTException {
		logger.debug("createIBABooleanValue() started");
		DefaultAttributeContainer attribContainer = (DefaultAttributeContainer) ibaHolder.getAttributeContainer();
		if (attribContainer == null) {
			throw new WTException("can not create IBA if no attributeContainer was initialized");
		}

		// Get reference definition (e.g. CAN-Netzwerk)
		AbstractAttributeDefinizerView booleanDefinizer = null;
		try {
			booleanDefinizer = IBADefinitionHelper.service.getAttributeDefDefaultViewByPath(ibaName);
		} catch (RemoteException remoteexception) {
			Object aobj[] = { "getAttributeOrganizerRoots" };
			throw new WTException(remoteexception, "wt.fc.fcResource", "0", aobj);
		}
		if (booleanDefinizer == null) {
			throw new WTException("Error: Could not find definition for " + ibaName);
		}

		// Create new reference attribute.
		BooleanValueDefaultView booleanValue = newBooleanValue(booleanDefinizer, ibaValue);

		// Add new reference attribute to attribContainer.
		try {
			attribContainer.addAttributeValue(booleanValue);
		} catch (Exception exception) {
			logger.error(exception.getLocalizedMessage(), exception);
		}
		logger.debug("createIBABooleanValue() finished");
	}

	private static BooleanValueDefaultView newBooleanValue(
			AbstractAttributeDefinizerView defView, boolean valueStr) {
		logger.debug("newBooleanValue() started");
		BooleanValueDefaultView newBooleanView = null;

		try {
			newBooleanView = new BooleanValueDefaultView((BooleanDefView) defView,
					valueStr);
		} catch (Exception ive) {
			logger.error("Can't create boolean value");
			logger.error(ive.getLocalizedMessage(), ive);
			newBooleanView = null;
		}
		logger.debug("newBooleanValue() finished");
		return newBooleanView;
	}
	
	/**
	 * Updates the given iba with the value. If the iba do no exist the system
	 * creates the iba.
	 *
	 * You must save the IbaHolder manually.
	 *
	 * @param ibaHolder
	 *           the IbaHolder
	 * @param ibaName
	 *           the name of the iba
	 * @param ibaValue
	 *           the new value of the iba
	 * @throws wt.util.WTException
	 *            throws WTException
	 */
	public static void updateTimeStampValueOnAttribContainer(IBAHolder ibaHolder,
			String ibaName, Timestamp ibaValue) throws WTException {
		logger.debug("ibaName=" + ibaName + " ibaValue=" + ibaValue);
		boolean found = false;
		DefaultAttributeContainer attribContainer = (DefaultAttributeContainer) ibaHolder
				.getAttributeContainer();
		if (attribContainer == null) {
			try {
				ibaHolder = IBAValueHelper.service.refreshAttributeContainer(
						ibaHolder, null, null, null);
				attribContainer = (DefaultAttributeContainer) ibaHolder
						.getAttributeContainer();
			} catch (RemoteException ex) {
				logger.error(ex.getLocalizedMessage(), ex);
			}
		}
		try {
			if (attribContainer != null) {
				AbstractValueView abstractValuesView[] = attribContainer
						.getAttributeValues();

				for (int k = 0; k < abstractValuesView.length; k++) {
					logger.debug("definition name: "
							+ abstractValuesView[k].getDefinition().getName());
					if (abstractValuesView[k].getDefinition().getName().equals(
							ibaName)
							&& abstractValuesView[k] instanceof TimestampValueDefaultView) {
						logger.debug("found");
						TimestampValueDefaultView theIBA = (TimestampValueDefaultView) abstractValuesView[k];
						theIBA.setValue(ibaValue);

						attribContainer.updateAttributeValue(theIBA);
						found = true;
						break;
					}
				}
			}
			if (!found) {
				logger.debug("not found, going to create");
				createIBATimeStampValue(ibaHolder, ibaName, ibaValue);
			}
		} catch (Exception e) {
			logger.error(e.getLocalizedMessage(), e);
		}
		logger.debug("updateTimeStampValue() finished ibaH=" + ibaHolder
				+ " ibaH.hc=" + ibaHolder.hashCode());
	}

	public static void createIBATimeStampValue(IBAHolder ibaHolder,
			String ibaName, Timestamp ibaValue) throws WTException {
		logger.debug("createIBATimestampValue() started");
		DefaultAttributeContainer attribContainer = (DefaultAttributeContainer) ibaHolder
				.getAttributeContainer();
		if (attribContainer == null) {
			throw new WTException(
					"can not create IBA if no attributeContainer was initialized");
		}

		// Get reference definition (e.g. CAN-Netzwerk)
		AbstractAttributeDefinizerView timestampDefinizer = null;
		try {
			timestampDefinizer = IBADefinitionHelper.service
					.getAttributeDefDefaultViewByPath(ibaName);
		} catch (RemoteException remoteexception) {
			Object aobj[] = { "getAttributeOrganizerRoots" };
			throw new WTException(remoteexception, "wt.fc.fcResource", "0", aobj);
		}
		if (timestampDefinizer == null) {
			throw new WTException("Error: Could not find definition for "
					+ ibaName);
		}

		// Create new reference attribute.
		TimestampValueDefaultView timestampValue = newTimeStampValue(timestampDefinizer,
				ibaValue);

		// Add new reference attribute to attribContainer.
		try {
			attribContainer.addAttributeValue(timestampValue);
		} catch (Exception exception) {
			logger.error(exception.getLocalizedMessage(), exception);
		}
		logger.debug("createIBATimestampValue() finished");
	}

	private static TimestampValueDefaultView newTimeStampValue(
			AbstractAttributeDefinizerView defView, Timestamp value) {
		logger.debug("newTimestampView() started");
		TimestampValueDefaultView newTimestampView = null;

		try {
			newTimestampView = new TimestampValueDefaultView((TimestampDefView) defView, value);
		} catch (Exception ive) {
			logger.error("Can't create timestamp value");
			logger.error(ive.getLocalizedMessage(), ive);
			newTimestampView = null;
		}
		logger.debug("newTimestampView() finished");
		return newTimestampView;
	}

	/**
	 * Updates the given iba with the value. If the iba do no exist the system creates the iba.
	 * 
	 * You must save the IbaHolder manually.
	 * 
	 * @param ibaHolder
	 *            the IbaHolder
	 * @param ibaName
	 *            the name of the iba
	 * @param ibaValue
	 *            the new value of the iba
	 * @throws wt.util.WTException
	 *             throws WTException
	 */
	public static void updateFloatValueOnAttribContainer(IBAHolder ibaHolder, String ibaName, double ibaValue) throws WTException {
		logger.debug("ibaName=" + ibaName + " ibaValue=" + ibaValue);
		boolean found = false;
		DefaultAttributeContainer attribContainer = (DefaultAttributeContainer) ibaHolder.getAttributeContainer();
		if (attribContainer == null) {
			try {
				ibaHolder = IBAValueHelper.service.refreshAttributeContainer(ibaHolder, null, null, null);
				attribContainer = (DefaultAttributeContainer) ibaHolder.getAttributeContainer();
			} catch (RemoteException ex) {
				logger.error(ex.getLocalizedMessage(), ex);
			}
		}
		try {
			if (attribContainer != null) {
				AbstractValueView abstractValuesView[] = attribContainer.getAttributeValues();

				for (int k = 0; k < abstractValuesView.length; k++) {
					logger.debug("definition name: " + abstractValuesView[k].getDefinition().getName());
					if (abstractValuesView[k].getDefinition().getName().equals(ibaName) && abstractValuesView[k] instanceof FloatValueDefaultView) {
						logger.debug("found");
						FloatValueDefaultView theIBA = (FloatValueDefaultView) abstractValuesView[k];
						theIBA.setValue(ibaValue);

						attribContainer.updateAttributeValue(theIBA);
						found = true;
						break;
					}
				}
			}
			if (!found) {
				logger.debug("not found, going to create");
				createIBAFloatValue(ibaHolder, ibaName, ibaValue);
			}
		} catch (Exception e) {
			logger.error(e.getLocalizedMessage(), e);
		}
		logger.debug("updateIBAFloatValue() finished ibaH=" + ibaHolder + " ibaH.hc=" + ibaHolder.hashCode());
	}

	/**
	 * Updates the given iba with the value. If the iba do no exist the system
	 * creates the iba.
	 * 
	 * You must save the IbaHolder manually.
	 * 
	 * @param ibaHolder
	 *            the IbaHolder
	 * @param ibaName
	 *            the name of the iba
	 * @param unitValue
	 *            the new value of the iba
	 * @throws wt.util.WTException
	 *             throws WTException
	 */
	public static void updateUnitValueOnAttribContainer(IBAHolder ibaHolder, String ibaName, Unit unitValue) throws WTException {
		logger.debug("ibaName=" + ibaName + " ibaValue=" + unitValue);
		boolean found = false;
		DefaultAttributeContainer attribContainer = (DefaultAttributeContainer) ibaHolder.getAttributeContainer();
		if (attribContainer == null) {
			try {
				ibaHolder = IBAValueHelper.service.refreshAttributeContainer(ibaHolder, null, null, null);
				attribContainer = (DefaultAttributeContainer) ibaHolder.getAttributeContainer();
			} catch (RemoteException ex) {
				logger.error(ex.getLocalizedMessage(), ex);
			}
		}
		try {
			if (attribContainer != null) {
				AbstractValueView abstractValuesView[] = attribContainer.getAttributeValues();

				for (int k = 0; k < abstractValuesView.length; k++) {
					logger.debug("definition name: " + abstractValuesView[k].getDefinition().getName());
					if (abstractValuesView[k].getDefinition().getName().equals(ibaName) && abstractValuesView[k] instanceof UnitValueDefaultView) {
						logger.debug("found");
						UnitValueDefaultView theIBA = (UnitValueDefaultView) abstractValuesView[k];
						theIBA.updateFromUnit(unitValue);

						attribContainer.updateAttributeValue(theIBA);
						found = true;
						break;
					}
				}
			}
			if (!found) {
				logger.debug("not found, going to create");
				createIBAUnitValue(ibaHolder, ibaName, unitValue);
			}
		} catch (Exception e) {
			logger.error(e.getLocalizedMessage(), e);
		}
		logger.debug("updateIBAUnitValue() finished ibaH=" + ibaHolder + " ibaH.hc=" + ibaHolder.hashCode());
	}

	public static void createIBAFloatValue(IBAHolder ibaHolder, String ibaName, double ibaValue) throws WTException {
		logger.debug("createIBAStringValue() started");
		DefaultAttributeContainer attribContainer = (DefaultAttributeContainer) ibaHolder.getAttributeContainer();
		if (attribContainer == null) {
			throw new WTException("can not create IBA if no attributeContainer was initialized");
		}

		// Get reference definition (e.g. CAN-Netzwerk)
		AbstractAttributeDefinizerView floatDefinizer = null;
		try {
			floatDefinizer = IBADefinitionHelper.service.getAttributeDefDefaultViewByPath(ibaName);
		} catch (RemoteException remoteexception) {
			Object aobj[] = { "getAttributeOrganizerRoots" };
			throw new WTException(remoteexception, "wt.fc.fcResource", "0", aobj);
		}
		if (floatDefinizer == null) {
			throw new WTException("Error: Could not find definition for " + ibaName);
		}

		// Create new reference attribute.
		FloatValueDefaultView doubleValue = newFloatValue(floatDefinizer, ibaValue);

		// Add new reference attribute to attribContainer.
		try {
			attribContainer.addAttributeValue(doubleValue);
		} catch (Exception exception) {
			logger.error(exception.getLocalizedMessage(), exception);
		}
		logger.debug("createIBAFloatValue() finished");
	}

	public static void createIBAUnitValue(IBAHolder ibaHolder, String ibaName, Unit unitValue) throws WTException {
		logger.debug("createIBAUnitValue() started");
		DefaultAttributeContainer attribContainer = (DefaultAttributeContainer) ibaHolder.getAttributeContainer();
		if (attribContainer == null) {
			throw new WTException("can not create IBA if no attributeContainer was initialized");
		}

		// Get reference definition (e.g. CAN-Netzwerk)
		AbstractAttributeDefinizerView unitDefinizer = null;
		try {
			unitDefinizer = IBADefinitionHelper.service.getAttributeDefDefaultViewByPath(ibaName);
		} catch (RemoteException remoteexception) {
			Object aobj[] = { "getAttributeOrganizerRoots" };
			throw new WTException(remoteexception, "wt.fc.fcResource", "0", aobj);
		}
		if (unitDefinizer == null) {
			throw new WTException("Error: Could not find definition for " + ibaName);
		}

		// Create new reference attribute.
		UnitValueDefaultView doubleValue = newUnitValue(unitDefinizer, unitValue);

		// Add new reference attribute to attribContainer.
		try {
			attribContainer.addAttributeValue(doubleValue);
		} catch (Exception exception) {
			logger.error(exception.getLocalizedMessage(), exception);
		}
		logger.debug("createIBAUnitValue() finished");
	}

	private static FloatValueDefaultView newFloatValue(
			AbstractAttributeDefinizerView defView, double valueDouble) {
		logger.debug("newFloatValue() started");
		FloatValueDefaultView newFloatView = null;

                int precision = 14;
                
                // VW_ECA-18257; affects float values created for the first time;
                // there is still way to put there values with custom precision;
                // e.g.: 0.000, 0.0
                if (valueDouble == 0) precision = 0;

		try {
			newFloatView = new FloatValueDefaultView((FloatDefView) defView,
					valueDouble, precision);
		} catch (Exception ive) {
			logger.warn("Can't create Float value");
			logger.error(ive.getLocalizedMessage(), ive);
			newFloatView = null;
		}
		logger.debug("newFloatValue() finished");
		return newFloatView;
	}

	private static UnitValueDefaultView newUnitValue(AbstractAttributeDefinizerView defView, Unit unitValue) {
		logger.debug("newUnitValue() started");
		UnitValueDefaultView newUnitView = null;
		
		try {
			newUnitView = new UnitValueDefaultView((UnitDefView) defView);
			newUnitView.updateFromUnit(unitValue);
		} catch (Exception ive) {
			logger.warn("Can't create unit value");
			logger.error(ive.getLocalizedMessage(), ive);
			newUnitView = null;
		}
		logger.debug("newUnitView() finished");
		return newUnitView;
	}

	/**
	 * Updates the given iba with the value. If the iba do no exist the system creates the iba.
	 * 
	 * You must save the IbaHolder manually.
	 * 
	 * @param ibaHolder
	 *            the IbaHolder
	 * @param ibaName
	 *            the name of the iba
	 * @param ibaValue
	 *            the new value of the iba
	 * @throws wt.util.WTException
	 *             throws WTException
	 */
	public static void updateIntegerValueOnAttribContainer(IBAHolder ibaHolder, String ibaName, int ibaValue) throws WTException {
		logger.debug("ibaName=" + ibaName + " ibaValue=" + ibaValue);
		boolean found = false;
		DefaultAttributeContainer attribContainer = (DefaultAttributeContainer) ibaHolder.getAttributeContainer();
		if (attribContainer == null) {
			try {
				ibaHolder = IBAValueHelper.service.refreshAttributeContainer(ibaHolder, null, null, null);
				attribContainer = (DefaultAttributeContainer) ibaHolder.getAttributeContainer();
			} catch (RemoteException ex) {
				logger.error(ex.getLocalizedMessage(), ex);
			}
		}
		try {
			if (attribContainer != null) {
				AbstractValueView abstractValuesView[] = attribContainer.getAttributeValues();

				for (int k = 0; k < abstractValuesView.length; k++) {
					logger.debug("definition name: " + abstractValuesView[k].getDefinition().getName());
					if (abstractValuesView[k].getDefinition().getName().equals(ibaName) && abstractValuesView[k] instanceof IntegerValueDefaultView) {
						logger.debug("found");
						IntegerValueDefaultView theIBA = (IntegerValueDefaultView) abstractValuesView[k];
						theIBA.setValue(ibaValue);

						attribContainer.updateAttributeValue(theIBA);
						found = true;
						break;
					}
				}
			}
			if (!found) {
				logger.debug("not found, going to create");
				createIBAIntegerValue(ibaHolder, ibaName, ibaValue);
			}
		} catch (Exception e) {
			logger.error(e.getLocalizedMessage(), e);
		}
		logger.debug("updateIBAIntegerValue() finished ibaH=" + ibaHolder + " ibaH.hc=" + ibaHolder.hashCode());
	}

	public static void createIBAIntegerValue(IBAHolder ibaHolder, String ibaName, int ibaValue) throws WTException {
		logger.debug("createIBAStringValue() started");
		DefaultAttributeContainer attribContainer = (DefaultAttributeContainer) ibaHolder.getAttributeContainer();
		if (attribContainer == null) {
			throw new WTException("can not create IBA if no attributeContainer was initialized");
		}

		// Get reference definition (e.g. CAN-Netzwerk)
		AbstractAttributeDefinizerView integerDefinizer = null;
		try {
			integerDefinizer = IBADefinitionHelper.service.getAttributeDefDefaultViewByPath(ibaName);
		} catch (RemoteException remoteexception) {
			Object aobj[] = { "getAttributeOrganizerRoots" };
			throw new WTException(remoteexception, "wt.fc.fcResource", "0", aobj);
		}
		if (integerDefinizer == null) {
			throw new WTException("Error: Could not find definition for " + ibaName);
		}

		// Create new reference attribute.
		IntegerValueDefaultView intValue = newIntegerValue(integerDefinizer, ibaValue);

		// Add new reference attribute to attribContainer.
		try {
			attribContainer.addAttributeValue(intValue);
		} catch (Exception exception) {
			logger.error(exception.getLocalizedMessage(), exception);
		}
		logger.debug("createIBAIntegerValue() finished");
	}

	private static IntegerValueDefaultView newIntegerValue(
			AbstractAttributeDefinizerView defView, int valueInteger) {
		logger.debug("newIntegerValue() started");
		IntegerValueDefaultView newIntegerView = null;
		try {
			newIntegerView = new IntegerValueDefaultView((IntegerDefView) defView,
					valueInteger);
		} catch (Exception ive) {
			logger.warn("Can't create Integer value");
			logger.error(ive.getLocalizedMessage(), ive);
			newIntegerView = null;
		}
		logger.debug("newIntegerValue() finished");
		return newIntegerView;
	}

	public static QuerySpec appendQuerySpecForIBAType(QuerySpec qsIBA,
			Class classDef, Class classVal, Vector ibaNames, long[] ida2a2)
			throws WTException {

		/*
		 * Desired SQL Query
		 *
		 * SELECT A0.VALUE, A0.classnamekeyA4, A0.IDA3A4, A1.NAME FROM STRINGVALUE
		 * A0, STRINGDEFINITION A1 WHERE A0.IDA3A6 IN (SELECT IDA2A2 FROM
		 * STRINGDEFINITION WHERE NAME IN ('MOD_DATE','BEMERKUNG1')) AND
		 * A1.IDA2A2=A0.IDA3A6 AND A0.IDA3A4 IN ('27734','15519','16020','12345')
		 * ORDER BY A0.IDA3A4;;
		 *
		 * The above query will give a list of IBA alongwith the corresponding
		 * PIC/PART oids. Since the IDA2A2 is unique for any Windchill object in
		 * the oracle tablespace for any oracle user, the column value 'A0.IDA3A4'
		 * can be used as a key to know whether the IBA value is associated to any
		 * PART/PIC
		 *
		 * ###############THE SQL OUTPUT WILL BE AS SHOWN
		 * BELOW######################
		 * |---------------------------------------------------------------------------------------------------------------------------------| |
		 * IBAVALUE CLASSNAME PIC/PART OID IBANAME |
		 * |---------------------------------------------------------------------------------------------------------------------------------|
		 * PIC_BEMERKUNG2 ext.vw.ec.part.VWPart 15519 BEMERKUNG2 PIC_BEMERKUNG1
		 * ext.vw.ec.part.VWPart 15519 BEMERKUNG1 PIC_BEMERKUNG1_PIC3
		 * ext.vw.ec.part.VWPart 16020 BEMERKUNG1 BEMERKUNG4 ext.vw.ec.pic.PIC
		 * 27734 BEMERKUNG4 BEMERKUNG3 ext.vw.ec.pic.PIC 27734 BEMERKUNG3 11/11/11
		 * ext.vw.ec.part.VWPart 27734 MOD_DATE
		 */

		// SELECT A0.VALUE, A0.classnamekeyA4, A0.IDA3A4 FROM STRINGVALUE A0,
		int ibaValIndex = qsIBA.addClassList(classVal, false);
		if (classVal.equals(IntegerValue.class)) {
			qsIBA.appendSelectAttribute("value", ibaValIndex, false);
		} else {
			qsIBA.appendSelectAttribute("value2", ibaValIndex, false);
		}
		qsIBA.appendSelectAttribute("theIBAHolderReference.key.classname",
				ibaValIndex, false);
		qsIBA.appendSelectAttribute("theIBAHolderReference.key.id", ibaValIndex,
				false);

		int ibaDefIndex = qsIBA.addClassList(classDef, false);
		// A1.NAME FROM STRINGDEFINITION A1
		qsIBA.appendSelectAttribute("name", ibaDefIndex, false);

		// SELECT IDA2A2 FROM STRINGDEFINITION WHERE NAME IN
		// ('MOD_DATE','BEMERKUNG1');
		// SUB-SELECT QUERY: BEGINS
		// building a sub-query for IBA names for
		// StringDefintion/IntegerDefintion/FloatDefintion/BooleanDefintion Table
		QuerySpec subQuery = new QuerySpec();
		int defIndex = subQuery.appendClassList(classDef, false);

		subQuery.appendSelectAttribute(IDA2A2, defIndex, false);

		if (logger.isDebugEnabled()) {
			logger.debug("IBA Names that are to be queried:\t" + ibaNames);
		}
		SearchCondition scNames = new SearchCondition(classDef, "name",
				convertVectorToStringArray(ibaNames), false);
		subQuery.appendWhere(scNames, new int[] { defIndex });
		// SUB-SELECT QUERY: ENDS

		// WHERE A0.IDA3A6 IN (SELECT IDA2A2 FROM STRINGDEFINITION WHERE NAME IN
		// ('MOD_DATE','BEMERKUNG1');)
		qsIBA.appendWhere(new SearchCondition(new ClassAttribute(classVal,
				"definitionReference.key.id"), SearchCondition.IN,
				new SubSelectExpression(subQuery)), new int[] { defIndex });

		qsIBA.appendAnd();
		// AND A1.IDA2A2=A0.IDA3A6
		SearchCondition scValDef = new SearchCondition(classDef, IDA2A2,
				classVal, "definitionReference.key.id");
		try {
			scValDef.setOuterJoin(SearchCondition.NO_OUTER_JOIN);
		} catch (WTPropertyVetoException wtpve) {
			throw new WTException(wtpve);
		}
		qsIBA.appendWhere(scValDef, new int[] { ibaDefIndex, ibaValIndex });

		// AND
		qsIBA.appendAnd();
		if (logger.isDebugEnabled()) {
			logger.debug("appending ida2a2 array of lenght  for IN query :\t"
					+ ida2a2.length);
		}
		SearchCondition scPBOIdA2A2 = new SearchCondition(classVal,
				"theIBAHolderReference.key.id", ida2a2);

		// A0.IDA2A2 IN (27734,28024) [list of PIC/PART oid's]
		qsIBA.appendWhere(scPBOIdA2A2, new int[] { ibaValIndex });

		return qsIBA;
	}

	//TODO ECA5.0: check if this is used
	/**
	 * @deprecated use IBAQueryServerUtils.addIBACondition(...) instead
	 */
	@Deprecated
	public static QuerySpec appendFilterOnIba(QuerySpec qsGiven,
			Class enterpriseClass, int enterpriseClassIndexInQS, Class classDef,
			Class classVal, String ibaName, String operator, Object ibaValue)
			throws WTException {
		return appendFilterOnIba(qsGiven, enterpriseClass,
				enterpriseClassIndexInQS, classDef, classVal, ibaName, operator,
				ibaValue, false, false);
	}

	//TODO ECA5.0: check if this is used
	/**
	 * @deprecated use IBAQueryServerUtils.addIBACondition(...) instead
	 */
	@Deprecated
	public static QuerySpec appendFilterOnIba(QuerySpec qsGiven,
			Class enterpriseClass, int enterpriseClassIndexInQS, Class classDef,
			Class classVal, String ibaName, String operator, Object ibaValue,
			boolean returnDefinition, boolean returnValue) throws WTException {

		/*
		 * SQL Query (this method only cares about the WHERE clause, rest of SQL
		 * is just an example)
		 *
		 * SELECT A1.name, A0.value, A0.value2, A0.classnamekeyA4, A2.ida2a2 FROM
		 * StringValue A0, StringDefinition A1, WTPart A2 WHERE
		 * A0.IDA3A4=A2.ida2a2 #join StringValue with enterpriseClass AND
		 * A1.IDA2A2=A0.IDA3A6 #join StringDefinition with StringValue AND
		 * A0.classnamekeyA4='wt.part.WTPart' #filter on given enterpriseClassName
		 * AND A1.name='teilegueltigkeit' #filter on given ibaName AND
		 * a0.value='+D2H' #filter on given ibaValue
		 */

		// we don't want the SELECT, only the where clause
		int ibaValIndex = qsGiven.addClassList(classVal, returnValue); // A0 in
																							// above
																							// where
		int ibaDefIndex = qsGiven.addClassList(classDef, returnDefinition); // A1
																									// in
																									// above
																									// where
		// given: int enterpriseClassIndexInQS //A2 in above where

		// qsGiven.appendAnd();
		// A0.IDA3A4=A2.ida2a2
		SearchCondition scLinkValueAndEnterprise = new SearchCondition(classVal,
				"theIBAHolderReference.key.id", enterpriseClass, IDA2A2);
		qsGiven.appendWhere(scLinkValueAndEnterprise, new int[] { ibaValIndex,
				enterpriseClassIndexInQS });

		qsGiven.appendAnd();
		// A1.IDA2A2=A0.IDA3A6
		SearchCondition scLinkDefAndValue = new SearchCondition(classDef, IDA2A2,
				classVal, "definitionReference.key.id");
		qsGiven.appendWhere(scLinkDefAndValue, new int[] { ibaDefIndex,
				ibaValIndex });

		qsGiven.appendAnd();
		// A0.classnamekeyA4='wt.part.WTPart'
		SearchCondition scClassname = new SearchCondition(classVal,
				"theIBAHolderReference.key.classname", SearchCondition.EQUAL,
				enterpriseClass.getName());
		qsGiven.appendWhere(scClassname, new int[] { ibaValIndex });

		qsGiven.appendAnd();
		// A1.name='teilegueltigkeit'
		SearchCondition scIbaName = new SearchCondition(classDef, "name",
				SearchCondition.EQUAL, ibaName);
		qsGiven.appendWhere(scIbaName, new int[] { ibaDefIndex });

		qsGiven.appendAnd();
		// A1.name='teilegueltigkeit'
		if ((operator.equals(SearchCondition.EQUAL) || operator
				.equals(SearchCondition.LIKE))
				&& ibaValue instanceof String) {
			SearchCondition scIbaValue = new SearchCondition(classVal, "value",
					operator, (String) ibaValue);
			qsGiven.appendWhere(scIbaValue, new int[] { ibaValIndex });
		} else if (operator.equals(SearchCondition.IN)
				|| ibaValue instanceof String[]) {
			SearchCondition scIbaValue = new SearchCondition(classVal, "value",
					(String[]) ibaValue, false); // false: NOT case sensitive
			qsGiven.appendWhere(scIbaValue, new int[] { ibaValIndex });
		} else if (operator.equals(SearchCondition.EQUAL) && ibaValue instanceof Boolean) {
			SearchCondition scIbaValue = new SearchCondition(classVal, "value", 
					((Boolean) ibaValue).booleanValue() ? SearchCondition.IS_TRUE : SearchCondition.IS_FALSE);
			qsGiven.appendWhere(scIbaValue, new int[] { ibaValIndex });
		} else {
			throw new WTException(
					"combination is not allowed in appendFilterOnIba(): operator="
							+ operator + " value=" + ibaValue + " value.class="
							+ ibaValue.getClass());
		}

		return qsGiven;
	}

	private static String[] convertVectorToStringArray(Vector vec) {

		String[] stringArray = new String[vec.size()];
		if (logger.isDebugEnabled()) {
			logger.debug("Names Vector:\t" + vec);
		}

		for (int x = 0; x < vec.size(); x++) {
			stringArray[x] = vec.get(x).toString();
		}

		return stringArray;
	}

	/**
	 * usage: windchill com.ptc.generic.iba.IBAUtil -u <user> -p <pwd>
         *
         * @param args
         */
	public static void main(String[] args) {
		try {
			WTPrincipal user = AuthenticationHelper.authenticateUser(args);
			System.out.println("authenticated as: " + user.getName());
		} catch (WTException w) {
			System.out.println("could not authenticate user. Exception:" + w.getLocalizedMessage());
			w.printStackTrace();
			System.exit(1);
		}

		// init WTContext and set locale
		WTContext.init(args);

		try {
			//now do the real stuff.....
			long[] oids = {264036, 16090};
			QueryResult qr = IBAUtil.findEmptyStringValues(oids);
			boolean printedClasses=false;
			while(qr.hasMoreElements()) {
				Object[] o = (Object[])qr.nextElement();
				if(!printedClasses) {
					System.out.println("oid.c=" + o[0].getClass().getName() + " IBA.value=" + o[1] + " IBA.name.c=" + o[2].getClass().getName());
					printedClasses=true;
				}
				//System.out.println("found: " + Arrays.toString(o));
				System.out.println("oid=" + o[0] + " IBA.value=" + o[1] + " IBA.name=" + o[2]);
			}

		} catch (WTException w) {
			w.printStackTrace();
			System.exit(1);
		}
		System.exit(0);
	}

	/**
	 * for the given oids queries if those objects have StringValues with null or empty ('') value
	 * result is sorted by oid of IBAHolder
	 *
	 * @param ibaholderOids
	 * @return QueryResult each element in there is of Object[3], [0]=oid(java.math.BigDecimal) [1]=value(java.lang.String) [2]=name of StringDefinition(java.lang.String)
	 * @throws WTException
	 */
	public static QueryResult findEmptyStringValues(long[] ibaholderOids) throws WTException {
		//long persistableOid = ((Persistable)ibaholder).getPersistInfo().getObjectIdentifier().getId();
		QuerySpec qs = new QuerySpec();
		qs.setAdvancedQueryEnabled(true);

		//do not add the full class into the result, just add the one column we need
		int indexValue = qs.addClassList(StringValue.class, false);
		qs.appendSelectAttribute("theIBAHolderReference.key.id", indexValue, false); //false=add as column to result set
		qs.appendSelectAttribute("value", indexValue, false); //false=add as column to result set

		//do not add the full class StringDefinition into the result, just add the name of the StringDefinition
		int indexDefinition = qs.addClassList(StringDefinition.class, false);
		qs.appendSelectAttribute("name", indexDefinition, false);

		//filter on oid of persistable
		//SearchCondition scOid = new SearchCondition(StringValue.class, "theIBAHolderReference.key.id", SearchCondition.EQUAL, persistableOid);
		SearchCondition scOid = new SearchCondition(StringValue.class, "theIBAHolderReference.key.id", ibaholderOids);
		//where value is null
		SearchCondition scNull = new SearchCondition(StringValue.class, "value", true);
		//where value is empty string
		SearchCondition scEmpty = new SearchCondition(StringValue.class, "value", SearchCondition.EQUAL, "");

		qs.appendWhere(scOid, new int[] {indexValue});
		qs.appendAnd();
		qs.appendOpenParen();
		qs.appendWhere(scNull, new int[] {indexValue});
		qs.appendOr();
		qs.appendWhere(scEmpty, new int[] {indexValue});
		qs.appendCloseParen();

		//connect StringDefinition and StringValues tables
		TableExpression[] tables1 = new TableExpression[2];
		String aliases1[] = new String[2];
		tables1[0] = qs.getFromClause().getTableExpressionAt(indexValue);
		aliases1[0] = qs.getFromClause().getAliasAt(indexValue);
		tables1[1] = qs.getFromClause().getTableExpressionAt(indexDefinition);
		aliases1[1] = qs.getFromClause().getAliasAt(indexDefinition);
		SearchCondition correlatedJoin = new SearchCondition(StringValue.class, "definitionReference.key.id",
				StringDefinition.class, WTAttributeNameIfc.ID_NAME);
		qs.appendAnd();
		qs.appendWhere(correlatedJoin, tables1, aliases1);

		//sort by oid of IBAHolder
		OrderBy orderBy = new OrderBy(new ClassAttribute(StringValue.class, "theIBAHolderReference.key.id"), false);
		qs.appendOrderBy(orderBy);

		logger.debug("qs=" + qs);

		return PersistenceHelper.manager.find((StatementSpec) qs);
	}

	//the iba values are returned as a list of Strings (could be multi-valued, therefore a list)
	public static Map<String, List<String>> getAllIbas(IBAHolder ibaHolder) throws WTException {
		Map<String, List<String>> ibas = new HashMap<String, List<String>>();

		try {
			ibaHolder = IBAValueHelper.service.refreshAttributeContainer(ibaHolder, null, SessionHelper.manager.getLocale(), null);
		} catch(RemoteException re) {
			throw new WTException(re);
		}
			DefaultAttributeContainer attribContainer = (DefaultAttributeContainer) ibaHolder.getAttributeContainer();
			if (attribContainer != null) {
				AttributeDefDefaultView[] attribDefinitions = attribContainer.getAttributeDefinitions();
				for (int i = 0; i < attribDefinitions.length; i++) {
					logger.debug("attribDefinitions[i].getName()=" + attribDefinitions[i].getName());
						AbstractValueView[] theValues = attribContainer.getAttributeValues(attribDefinitions[i]);
						if (theValues != null) {
							List<String> ibaValues = new ArrayList<String>();
							for(AbstractValueView v : theValues) {
								ibaValues.add(IBAValueUtility.getLocalizedIBAValueDisplayString(v, SessionHelper.manager.getLocale()));
							}
							ibas.put(attribDefinitions[i].getName(), ibaValues);
						}
				}
			}

		return ibas;
	}


	// ////////////////////////////////////////////////////////////////////////////////////////////////////
	// methods for instance usage of this class
	// ////////////////////////////////////////////////////////////////////////////////////////////////////
	// instance variables
	private IBAHolder ibaHolder = null;
	private Hashtable ibaContainer = null;
	// hold a reference to the attributeContainer of ibaHolder
	// is set inside setIBAHolder(IBAHolder)
	private DefaultAttributeContainer attribContainer = null;
	// holds the attribute definition of the attribContainer
	// is set inside setIBAHolder(IBAHolder)
	private AttributeDefDefaultView[] attribDefinitions = null;
	// is set after ibaHolder, attribContainer and attribDefinitions are
	// initialized inside setIBAHolder()
	// is set inside setIBAHolder(IBAHolder)
	private boolean initialized = false;

	public IBAUtil(IBAHolder ih, String ibaNames) throws WTException {
		if (ih == null) {
			throw new WTException("null given as IBAHolder");
		}
		this.setIBAHolder(ih, ibaNames);
	}

	// Populate only those IBAs that are in IBANames to improve performce and
	// avoid unwanted IBA value calls.
	private void setIBAHolder(IBAHolder a_ibaHolder, String ibaNames) {
		this.ibaHolder = a_ibaHolder;
		ibaContainer = new Hashtable();

		boolean checkIbaNames = false;
		if (ibaNames != null && ibaNames.length() != 0) {
			ibaNames = ";" + ibaNames.toUpperCase() + ";";
			checkIbaNames = true;
		}
		logger.debug("checkIbaNames=" + checkIbaNames);

		try {
			ibaHolder = IBAValueHelper.service.refreshAttributeContainer(
					ibaHolder, null, SessionHelper.manager.getLocale(), null);
			attribContainer = (DefaultAttributeContainer) ibaHolder
					.getAttributeContainer();
			if (attribContainer != null) {
				attribDefinitions = attribContainer.getAttributeDefinitions();
				for (int i = 0; i < attribDefinitions.length; i++) {
					logger.debug("attribDefinitions[i].getName()="
							+ attribDefinitions[i].getName());
					if (!checkIbaNames
							|| (checkIbaNames && ibaNames.indexOf(";"
									+ ((attribDefinitions[i].getName()).toUpperCase())
									+ ";") != -1)) {
						logger.debug("in if");
						AbstractValueView[] theValues = attribContainer
								.getAttributeValues(attribDefinitions[i]);
						if (theValues != null) {
							logger.debug("in if2");
							Object[] temp = new Object[2];
							temp[0] = attribDefinitions[i];
							temp[1] = theValues[0];
							ibaContainer.put(attribDefinitions[i].getName(), temp);
						}
					}
				}
			}
			initialized = true;
		} catch (Exception e) {
			logger.error(e.getLocalizedMessage(), e);
			ibaHolder = null;
			initialized = false;
		}
	}

	public String getValue(String name) {
		try {
			return (getValue(name, SessionHelper.manager.getLocale()));
		} catch (Exception e) {
			if (logger.isDebugEnabled()) {
				logger.info("getValue() for " + name + " failed", e);
			}
			return (null);
		}
	}

	public String getValue(String name, Locale locale) {
		try {
			// logger.debug("(" + name + ") ibaContainer=" + ibaContainer);
			if (ibaContainer.get(name) != null
					&& ((Object[]) ibaContainer.get(name)).length != 0) {
				AbstractValueView theValue = (AbstractValueView) ((Object[]) ibaContainer
						.get(name))[1];
				return (IBAValueUtility.getLocalizedIBAValueDisplayString(theValue,
						locale));
			} else {
				return null;
			}
		} catch (Exception e) {
			if (logger.isDebugEnabled()) {
				logger.info("getValue() for " + name + " with " + locale
						+ " failed", e);
			}
			return (null);
		}

	}

	/**
	 * returns an Integer IBA Value
	 *
	 * @param name
	 *           of IBA to get Value from
	 * @return long value
	 */
	public long getIntegerValue(String name) {
		AbstractValueView value1 = getAbstractValue(name);
		IntegerValueDefaultView integervalue = (IntegerValueDefaultView) value1;
		return (integervalue.getValue());
	}

	/**
	 * returns an String IBA Value unformatted
	 *
	 * @param name
	 *           of IBA to get Value from
	 * @return unformatted IBA value
	 */
	public String getRawStringValue(String name) {
		AbstractValueView value1 = getAbstractValue(name);
		StringValueDefaultView rawvalue = (StringValueDefaultView) value1;
		return (rawvalue.getValue());
	}

	/**
	 * returns an Timestamp IBA Value unformatted
	 *
	 * @param name
	 *           of IBA to get Value from
	 * @return Timestamp IBA value
	 */
	public Timestamp getTimestampValue(String name) {
		AbstractValueView value1 = getAbstractValue(name);
		TimestampValueDefaultView rawvalue = (TimestampValueDefaultView) value1;
		return (rawvalue.getValue());
	}

	public Boolean getBooleanValue(String name) {
		AbstractValueView value1 = getAbstractValue(name);
		BooleanValueDefaultView rawvalue = (BooleanValueDefaultView) value1;
		return (rawvalue == null ? null : Boolean.valueOf(rawvalue.getValueAsString()));
	}

        @Override
	public String toString() {
		StringBuilder tempString = new StringBuilder();
		Enumeration<String> enumIbas = ibaContainer.keys();
		try {
			while (enumIbas.hasMoreElements()) {
				String theKey = enumIbas.nextElement();
				AbstractValueView theValue = (AbstractValueView) ((Object[]) ibaContainer
						.get(theKey))[1];
				tempString.append(theKey);
				tempString.append(": ");
				tempString.append(IBAValueUtility
						.getLocalizedIBAValueDisplayString(theValue,
								SessionHelper.manager.getLocale()));
				tempString.append('\n');
			}
			// if(values!=null) {
			// for( int i = 0; i < values.length; ++i ) {
			// AbstractValueView theValue = ( AbstractValueView )values[ i ];
			// tempString.append( "##multiIBA##: " );
			// tempString.append(
			// IBAValueUtility.getLocalizedIBAValueDisplayString(
			// theValue,
			// SessionHelper.manager.getLocale() ) );
			// tempString.append( '\n' );
			// }
			// } else {
			tempString.append("values not initialized!");
			// }
		} catch (Exception e) {
			logger.error(e.getLocalizedMessage(), e);
		}
		return (tempString.toString());
	}

	/**
	 * gets an abstract IBA value. Is used by getIntegerValue()
	 *
	 * @param name
	 *           Name of value to get
	 * @return abstract representation of iba value
	 */
	private AbstractValueView getAbstractValue(String name) {
		try {
			// logger.debug("(" + name + ") ibaContainer=" + ibaContainer);
			if (ibaContainer.get(name) != null
					&& ((Object[]) ibaContainer.get(name)).length != 0) {
				return ((AbstractValueView) ((Object[]) ibaContainer.get(name))[1]);
			} else {
				return null;
			}
		} catch (Exception e) {
			if (logger.isDebugEnabled()) {
				logger.info("getAbstractValue() for " + name + " failed", e);
			}
			return (null);
		}
	}

	/**
     * Delete all StringValue objects with passed in names for holder
     * (in single delete, no iteration)
     * @param ibaNames names of attributes to remove
     * @param holder attribute holder to remove attributes for
     * @throws Exception
     */
    public static void deleteStringIbaValues(Collection<String> ibaNames, IBAHolder holder)
            throws Exception {
        if (holder != null && ibaNames != null && !ibaNames.isEmpty()) {
            long picId = PersistenceHelper.getObjectIdentifier((Persistable) holder).getId();
            Hashtable<Long, Hashtable<String, Object>> ibas = getIBAs(ibaNames.toArray(new String[ibaNames.size()]), new long[]{picId});
            Map<String, Object> picIbas = ibas.get(picId);
            if (picIbas != null && !picIbas.isEmpty()) {
                WTHashSet toRemove = new WTHashSet(picIbas.values());
                PersistenceHelper.manager.delete(toRemove);
            }
        }
    }

    public static QueryResult getStringIBAQueryResult(String ibaName, IBAHolder holder) throws QueryException, WTException {
    	if(holder==null) {
    		throw new WTException("can't retrieve IBAs for ibaHolder=null");
    	}
    	
        logger.debug("Retrieve String IBA values: " + ibaName);

        QuerySpec qs = new QuerySpec();
        int vIdx = qs.appendClassList(StringValue.class, true);
        int dIdx = qs.appendClassList(StringDefinition.class, false);

        qs.appendWhere(new SearchCondition(StringValue.class,
                "theIBAHolderReference.key.id", SearchCondition.EQUAL, ((Persistable) holder).getPersistInfo().
                getObjectIdentifier().getId()),
                new int[]{vIdx});

        qs.appendAnd();
        qs.appendWhere(new SearchCondition(StringDefinition.class,
                StringDefinition.NAME, SearchCondition.EQUAL, ibaName), new int[]{dIdx});
        qs.appendAnd();
        SearchCondition sc = new SearchCondition(new ClassAttribute(
                StringValue.class, "definitionReference.key.id"), SearchCondition.EQUAL,
                new ClassAttribute(StringDefinition.class,
                "thePersistInfo.theObjectIdentifier.id"));

        sc.setFromIndicies(new int[]{vIdx, dIdx}, 0);
        qs.appendWhere(sc, new int[]{vIdx, dIdx});

        return PersistenceHelper.manager.find(qs);
    }

    /**
     * Retrieve list of StringValue objects for given IBAHolder. (All values will be retrieved)
     *
     * @param attName Name of IBA
     * @param holder
     * @return List of StringValues
     * @throws wt.util.WTException
     */
    public static List<StringValue> getStringIBAStringValues(String attName, IBAHolder holder)
            throws WTException {
        QueryResult qr = getStringIBAQueryResult(attName, holder);

        List<StringValue> values = new LinkedList<StringValue>();
        while (qr.hasMoreElements()) {
            values.add((StringValue) ((Object[]) qr.nextElement())[0]);
        }

        logger.debug("Found " + values.size() + " values");
        return values;
    }

    /**
     * Retrieve list of String values of given IBA for given IBAHolder. (All values will be
     * retrieved)
     *
     * @param attName Name of IBA
     * @param holder
     * @return List of StringValues
     * @throws wt.util.WTException
     */
    public static List<String> getStringIBAValues(String attName, IBAHolder holder) throws
            WTException {
        QueryResult qr = getStringIBAQueryResult(attName, holder);

        List<String> values = new LinkedList<String>();
        while (qr.hasMoreElements()) {
            values.add(((StringValue) ((Object[]) qr.nextElement())[0]).getValue());
        }

        logger.debug("Found " + values.size() + " values");
        return values;
    }

    /**
     * Retrieve values for String IBAs from IBA Holder.
     * Only single valued IBAs are supported (multi values will return random one).
     *
     * @param ibaHolder IBA holder to retrieve values for
     * @param ibas names of IBAs to query
     * @return IBA name to IBA value mapping
     * @throws WTException
     */
    public static Map<String, String> getStringIBAs(IBAHolder ibaHolder, String... ibas)
            throws WTException {
        logger.debug("Retrieve String IBA values: " + Arrays.toString(ibas));

        QuerySpec qs = new QuerySpec();
        int vIdx = qs.appendClassList(StringValue.class, true);
        int dIdx = qs.appendClassList(StringDefinition.class, true);

        qs.appendWhere(new SearchCondition(StringValue.class,
                "theIBAHolderReference.key.id", SearchCondition.EQUAL, ((Persistable) ibaHolder).getPersistInfo().getObjectIdentifier().getId()),
                new int[]{vIdx});

        qs.appendAnd();
        qs.appendWhere(new SearchCondition(new ClassAttribute(StringDefinition.class, StringDefinition.NAME),
                SearchCondition.IN, new ArrayExpression(ibas)), new int[]{dIdx});
        qs.appendAnd();
        SearchCondition sc = new SearchCondition(new ClassAttribute(
                StringValue.class, "definitionReference.key.id"), SearchCondition.EQUAL,
                new ClassAttribute(StringDefinition.class,
                "thePersistInfo.theObjectIdentifier.id"));

        sc.setFromIndicies(new int[]{vIdx, dIdx}, 0);
        qs.appendWhere(sc, new int[]{vIdx, dIdx});

        QueryResult qr = PersistenceHelper.manager.find((StatementSpec) qs);

        Map<String, String> values = new HashMap<String, String>(qr.size());
        while (qr.hasMoreElements()) {
            Object[] result = (Object[]) qr.nextElement();
            StringValue sv = (StringValue) result[0];
            StringDefinition sd = (StringDefinition) result[1];
            values.put(sd.getName(), sv.getValue());
        }

        logger.debug("Found " + values.size() + " values");
        return values;
    }

	/**
	 * Returns all String IBAs with a specific value for a certain String IBA
	 *
	 * @param attName the name of the String IBA
	 * @param value the value of the String IBA
	 * @return a list of StringValues
	 * @throws WTException
	 */
	public static List<StringValue> getStringIBAsWithValue(String attName, String value) throws WTException {

		List<StringValue> values = new LinkedList<StringValue>();
			logger.debug("Retrieve String IBA values: " + attName);

			QuerySpec qs = new QuerySpec();
			int vIdx = qs.appendClassList(StringValue.class, true);
			int dIdx = qs.appendClassList(StringDefinition.class, false);

			qs.appendWhere(new SearchCondition(StringDefinition.class, StringDefinition.NAME, "=", attName),
					new int[] { dIdx });
			qs.appendAnd();
			SearchCondition sc = new SearchCondition(new ClassAttribute(StringValue.class, "definitionReference.key.id"),
					SearchCondition.EQUAL, new ClassAttribute(StringDefinition.class, "thePersistInfo.theObjectIdentifier.id"));


			sc.setFromIndicies(new int[] { vIdx, dIdx }, 0);
			qs.appendWhere(sc, new int[] { vIdx, dIdx });

			qs.appendAnd();
			qs.appendWhere(new SearchCondition(StringValue.class, StringValue.VALUE, SearchCondition.EQUAL, value.toUpperCase()),
					new int[] { vIdx });

			logger.debug("Database quere: " + qs);

			QueryResult qr = PersistenceHelper.manager.find((StatementSpec) qs);

			while (qr.hasMoreElements()) {
				Persistable resultPersistable[] = (Persistable[]) qr.nextElement();
				values.add((StringValue) resultPersistable[0]);
			}

			logger.debug("Found " + values.size() + " values");
			return values;

	}

    public static void deleteBooleanIBAValue(IBAHolder ibaHolder, String ibaName) throws WTException {
		deleteValueOnAttribContainer(ibaHolder, ibaName);
    }

    /**
     * Remove all TimeStamp objects for given attribute on given IBAHolder.
     * <b>It will NOT get empty timestamp value but will be removed from database</b>
     * @param holder Object to remove IBA values for
     * @param IBAName Name of IBA to clear values
     * @throws wt.util.WTException
     */
    public static void deleteTimeStampIBAValues(IBAHolder holder, String IBAName)
            throws WTException {
    	deleteValueOnAttribContainer(holder, IBAName);
    }

    /**
     * Remove all StringValue objects for given attribute on given IBAHolder.
     * <b>It will NOT get empty string value but will be removed from database</b>
     * @param holder Object to remove IBA values for
     * @param IBAName Name of IBA to clear values
     * @throws wt.util.WTException
     */
    public static void deleteStringIBAValues(IBAHolder holder, String IBAName)
            throws WTException {
		deleteValueOnAttribContainer(holder, IBAName);
    }

    /**
     * Remove all IntegerValue objects for given attribute on given IBAHolder.
     * <b>It will NOT get empty integer value but will be removed from database</b>
     * @param holder Object to remove IBA values for
     * @param IBAName Name of IBA to clear values
     * @throws wt.util.WTException
     */
    public static void deleteIntegerIBAValues(IBAHolder holder, String IBAName)
            throws WTException {
    	deleteValueOnAttribContainer(holder, IBAName);
    }
    public static void deleteFloatIBAValue(IBAHolder holder, String IBAName)
            throws WTException {
		deleteValueOnAttribContainer(holder, IBAName);
    }

 	/**
 	 * Retrieve list of StringValue objects for given IBAHolder. (All values will
 	 * be retrieved)
 	 *
 	 * @param attName
 	 *           Name of IBA
 	 * @param holder
 	 * @return List of StringValues
 	 * @throws wt.util.WTException
 	 */
    public static List getTimeStampIBAValues(String attName, IBAHolder holder) throws WTException {
    	return getIBAValues(attName, holder, TimestampValue.class, TimestampDefinition.class);
    }
 	public static List getIntegerIBAValues(String attName, IBAHolder holder) throws WTException {
 		return getIBAValues(attName, holder, IntegerValue.class, IntegerDefinition.class);
 	}
 	public static List getFloatIBAValues(String attName, IBAHolder holder) throws WTException {
 		return getIBAValues(attName, holder, FloatValue.class, FloatDefinition.class);
 	}
 	public static List getBooleanIBAValues(String attName, IBAHolder holder) throws WTException {
 		return getIBAValues(attName, holder, BooleanValue.class, BooleanValue.class);
 	}
 	public static List getIBAValues(String attName, IBAHolder holder, Class valueClass, Class definitionClass) throws WTException {
 		logger.debug("Retrieve String IBA values: " + attName);

 		QuerySpec qs = new QuerySpec();
 		int vIdx = qs.appendClassList(valueClass, true);
 		int dIdx = qs.appendClassList(definitionClass, false);

 		qs.appendWhere(new SearchCondition(valueClass,
 				"theIBAHolderReference.key.id", "=", ((Persistable) holder)
 						.getPersistInfo().getObjectIdentifier().getId()),
 				new int[] { vIdx });

 		qs.appendAnd();
 		qs.appendWhere(new SearchCondition(definitionClass,
 				"name", "=", attName), new int[] { dIdx });
 		qs.appendAnd();
 		SearchCondition sc = new SearchCondition(new ClassAttribute(
 				valueClass, "definitionReference.key.id"), "=",
 				new ClassAttribute(definitionClass,
 						"thePersistInfo.theObjectIdentifier.id"));

 		sc.setFromIndicies(new int[] { vIdx, dIdx }, 0);
 		qs.appendWhere(sc, new int[] { vIdx, dIdx });

 		QueryResult qr = PersistenceHelper.manager.find(qs);

 		List values = new LinkedList();
 		while (qr.hasMoreElements()) {
 			values.add(((Object[]) qr.nextElement())[0]);
 		}

 		logger.debug("Found " + values.size() + " values");
 		return values;
 	}

    /**
     * Set holder's new IBA, splits it, replaces old values with new ones
     * Does NOT persist IbaHolder! That needs to happen separately, otherwise values will not be stored
     *
     * @param holder
     * @param ibaName
     * @param ibaValue
     * @throws WTIntrospectionException
     * @throws WTException
     */
    public static void setMultiValueIBA(IBAHolder holder, String ibaName, String ibaValue) throws
            WTIntrospectionException, WTException {
        // split new IBAs values
        List<String> splittedIBAs = StringValuesHelper.splitMultiValue(StringValue.class, StringValue.VALUE, ibaValue, true, 0);
        logger.debug("splittedIBAs=" + splittedIBAs);
        setMultiValueIBA(holder, ibaName, splittedIBAs);
    }

    /**
     * Set holder's new IBA, replaces old values with new ones
     * Does NOT persist IbaHolder! That needs to happen separately, otherwise values will not be stored
     *
     * @param holder
     * @param ibaName
     * @param ibaValues
     * @throws WTIntrospectionException
     * @throws WTException 
     */
    public static void setMultiValueIBA(IBAHolder holder, String ibaName, List<String> ibaValues)
            throws WTIntrospectionException, WTException {
        logger.debug("ibaName=" + ibaName + " ibaValue=" + ibaValues);
        // remove old IBAs values
        deleteValueOnAttribContainer(holder, ibaName);
        // insert new IBAs values
        for (int i = 0; i < ibaValues.size(); i++) {
            String splittedIBA = ibaValues.get(i);
            logger.debug("Splitted IBA: splittedIBA=" + splittedIBA);
            if (StringUtils.isNotBlank(splittedIBA)) {
                logger.debug("Creating IBAs StringValue");
                IBAUtil.createIBAStringValue(holder, ibaName, splittedIBA);
            }
        }
    }

    /**
     * Iterates through holder's new IBAs, replaces old values with new ones
     * Does NOT persist IbaHolder! That needs to happen separately, otherwise values will not be stored
     *
     * @param holder
     * @param ibas
     * @return
     * @throws WTIntrospectionException
     * @throws WTException
     */
    public static IBAHolder setMultiValueIBAsLists(IBAHolder holder, Map<String, List<String>> ibas)
            throws WTIntrospectionException, WTException {
        for (Entry<String, List<String>> iba : ibas.entrySet()) {
            setMultiValueIBA(holder, iba.getKey(), iba.getValue());
        }
        return holder;
    }

    /**
     * Iterates through holder's new IBAs, splits them, replaces old values with new ones
     *
     * @param holder
     * @param ibas
     * @return
     * @throws WTIntrospectionException
     * @throws WTException
     */
    public static IBAHolder setMultiValueIBAs(IBAHolder holder, Map<String, String> ibas) throws
            WTIntrospectionException, WTException {
        for (Entry<String, String> iba : ibas.entrySet()) {
            setMultiValueIBA(holder, iba.getKey(), iba.getValue());
        }
        return holder;
    }

    /**
     * Joins all values for IBA in proper sequence and return as one String
     *
     * @param holder
     * @param name of requested IBA
     * @return concatenated IBA
     */
    public static String getMultiValueIBA(IBAHolder holder, String name) {
        try {
            List<StringValue> ibaValues = getStringIBAStringValues(name, holder);
            return concatIBAValue(ibaValues);
        } catch (WTException exception) {
            logger.error("Could not retrieve IBA value for view", exception);
        }
        return null;
    }

    /**
     * Concatenates StringValues from given list. First it sorts list, then parses values with multi
     * value pattern.
     *
     * @param values
     * @return
     */
    private static String concatIBAValue(List<StringValue> values) {
        StringBuilder buffer = new StringBuilder();
        // Sort to have right IBAs order
        try {
            Collections.sort(values, new StringValueComparator());
        } catch (NumberFormatException exception) {
            logger.error("Cannot sort collection");
            logger.error(exception.getLocalizedMessage(), exception);
            return "";
        }
        for (StringValue value : values) {
            buffer.append(getParsedValue(value));
        }
        return buffer.toString();
    }

    /**
     * Searches for IBAs with the same definition as given StringValue IBA in given vector. It
     * concatenates found values into one long String.
     *
     * @param value
     * @param values
     * @return
     * @throws WTException
     */
    public static String getMultiValueIBA(StringValue value, Vector<Persistable[]> values) throws
            WTException {
        IBAHolderReference ibaHolderReference = value.getIBAHolderReference();
        Long defintionId = Long.valueOf(((ObjectIdentifier) value.getAbstractDefinition().getAttributeDefinitionReference().getKey()).
                getId());
        Long objectId = Long.valueOf(((ObjectIdentifier) ibaHolderReference.getKey()).getId());
        List<StringValue> multiValues = new ArrayList<StringValue>();
        for (Persistable[] stringValues : values) {
            if (stringValues[0] instanceof StringValue) {
                StringValue innerValue = (StringValue) stringValues[0];
                IBAHolderReference innerHolderReference = innerValue.getIBAHolderReference();
                Long innerDefinitionId = Long.valueOf(((ObjectIdentifier)innerValue.getAbstractDefinition().
                        getAttributeDefinitionReference().getKey()).getId());
                Long innerObjectId = Long.valueOf(((ObjectIdentifier) innerHolderReference.getKey()).getId());
                if (objectId.equals(innerObjectId) && defintionId.equals(innerDefinitionId)) {
                    multiValues.add(innerValue);
                }
            }
        }
        return concatIBAValue(multiValues);
    }

    /**
     * Returns given object iba's values as List of single Strings splitted by IBAS_SEPARATOR
     *
     * @param holder
     * @param name of requested IBA
     * @return concatenated IBA
     */
    public static List<String> getMultiValueIBAsList(IBAHolder holder, String name) {
        try {
            List<String> ibas = getStringIBAValues(name, holder);
            return ibas;
        } catch (WTException exception) {
            logger.error("Could not retrieve IBA value for view", exception);
        }
        return null;
    }

    private static String getParsedValue(StringValue stringValue) {
        String value = stringValue.getValue();
        Matcher matcher = MULTI_VALUE_PATTERN.matcher(value);
        if (matcher.matches()) {
            value = matcher.group(1);
        }
        return value;
    }
}
