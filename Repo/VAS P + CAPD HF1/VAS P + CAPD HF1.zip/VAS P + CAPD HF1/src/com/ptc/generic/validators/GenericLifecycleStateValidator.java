package com.ptc.generic.validators;

import org.apache.commons.lang.ArrayUtils;

import com.ptc.generic.validators.validatorsResource;

import wt.lifecycle.LifeCycleManaged;
import wt.lifecycle.State;
import wt.util.WTMessage;

/**
 * GenericLifecycleStateValidator
 *
 * Checks if a given object is in one of the specified lifecycle states.
 *
 * @author cherrmann
 *
 */
public class GenericLifecycleStateValidator<T extends LifeCycleManaged> implements GenericValidator<T> {

	private ValidationResult validationResult;
	private String errorMessage;

	private State[] validLifeCycleStates;

	/**
	 * GenericLifecycleStateValidator
	 *
	 * @param lifeCycleStates life cycle states which will be validated
	 */
	public GenericLifecycleStateValidator(State... lifeCycleStates) {
		this(WTMessage.getLocalizedMessage(VALIDATION_RESOURCE, validatorsResource.INVALID_LIFECYCLE_STATE, null), lifeCycleStates);
	}

	/**
	 * GenericLifecycleStateValidator
	 *
	 * @param errorMessage the default error message
	 * @param lifeCycleStates life cycle states which will be validated
	 */
	public GenericLifecycleStateValidator(String errorMessage, State... lifeCycleStates){
		this.validLifeCycleStates = lifeCycleStates;
		this.errorMessage = errorMessage;
	}

	/**
	 * Checks if the given object is in one of the specified lifecycle states.
	 *
	 * @param object an object of type LifeCycleManaged
	 * @return true if the given object is in one of the given lifecycle states
	 * @see com.ptc.generic.validators.GenericValidator#validate(java.lang.Object)
	 */
	public boolean validate(LifeCycleManaged object) {
		resetValidationResult();

		if (object != null){
			if (this.validLifeCycleStates != null){
				State lcState = ((LifeCycleManaged)object).getLifeCycleState();
				if (!ArrayUtils.contains(this.validLifeCycleStates, lcState)){
					this.validationResult = new ValidationResult(errorMessage, false);
				}
			}
		} else {
			this.validationResult = new ValidationResult(INVALID_PARAMETER_WAS_NULL, false);
		}

		if (this.validationResult == null){
			this.validationResult = new ValidationResult(SUCCESS_MESSAGE, true);
		}

		return this.validationResult.getIsValid();
	}

	public ValidationResult getValidationResult() {
		return this.validationResult;
	}

	public void resetValidationResult(){
		this.validationResult = null;
	}

}
