package com.ptc.generic.userprefs;

import wt.preference.PreferenceDefinition;

/**
 * //TODO Klassenfunktion dokumentieren.
 *
 * @author etrauca
 * @since 20.07.2010
 */
public class DynamicPreference implements PreferenceIfc {

    private String           name;
    private String           defaultValue;
    private UserPrefCategory category;
    private int              visibility;

    /**
     * Creates new ECA user preference. Adds passed prefix to all preferences (instead of ECA_PREFIX)
     * and sets passed category
     * @param prefix prefix to add to name
     * @param name name of preference
     * @param defaultValue default value (will be set on preference definition)
     * @param category category to save preference in
     */
    public DynamicPreference(String prefix, String name, String defaultValue, UserPrefCategory category) {
        this(prefix, name, defaultValue, category, PreferenceDefinition.VISIBILITY_USER);
    }

    /**
     * Creates new preference. Use when you need to set definition visibility to something else then user
     *
     * @param prefix prefix to add to name
     * @param name name of preference
     * @param defaultValue default value (will be set on preference definition)
     * @param category category to save preference in
     * @param visibility visibility of preference (in what context it's visible/can be overridden)
     * @see PreferenceDefinition#VISIBILITY_USER
     * @see PreferenceDefinition#VISIBILITY_CONTAINER
     * @see PreferenceDefinition#VISIBILITY_ORG
     * @see PreferenceDefinition#VISIBILITY_SITE
     */
    public DynamicPreference(String prefix, String name, String defaultValue, UserPrefCategory category, int visibility) {
        this.name = prefix + name;
        this.defaultValue = defaultValue;
        this.category = category;
        this.visibility = visibility;
    }

    public String getName() {
        return this.name;
    }

    public String getDefaultValue() {
        return this.defaultValue;
    }

    public UserPrefCategory getCategory() {
        return category;
    }

    public int getVisibility() {
        return visibility;
    }

    public UserPrefClient getClient() {
        return UserPrefClient.ECA;
    }
}
