package com.ptc.generic.epm;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;

import wt.epm.EPMDocument;
import wt.fc.PersistenceHelper;
import wt.part.WTPart;
import wt.util.WTException;


// contains all links to EPMDocuments from one WTPart (which is the 'part' in this container)
public class AssociationContainer implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	//collection of all (CLEAN, NEW, MODIFIED, TO_BE_REMOVED) associations of given part
	List<EPMAssociation> associations = null;
	//the part that is the context
	WTPart part = null;
	
	public WTPart getPart() {
		return part;
	}

	public void setPart(WTPart part) {
		this.part = part;
	}

	private AssociationContainer() {
		associations = new LinkedList<EPMAssociation>();
	}
	
	public static AssociationContainer newAssociationContainer(WTPart part) throws WTException {
		AssociationContainer cont = new AssociationContainer();
		cont.setPart(part);
		return cont;
	}
	
	public static AssociationContainer newAssociationContainer(WTPart part, List<EPMAssociation> associations) throws WTException {
		AssociationContainer cont = new AssociationContainer();
		cont.setPart(part);
		cont.addAssociations(associations);
		return cont;
	}
	
	public void addAssociation(EPMAssociation a) {
		//there can be only 1 assoc to the same EPMDoc
		//EPMDocument doc = a.getDoc();
		associations.add(a);
	}
	
	private void addAssociations(List<EPMAssociation> listToBeAdded) {
		for (EPMAssociation a: listToBeAdded) {
			this.addAssociation(a);
		}
	}
	
	public EPMAssociation findAssociation(EPMDocument epmdoc) {
		for (EPMAssociation association : associations) {
			if (PersistenceHelper.isEquivalent(epmdoc, association.getDoc())) {
				return association;
			}
		}
		return null;
	}
}
