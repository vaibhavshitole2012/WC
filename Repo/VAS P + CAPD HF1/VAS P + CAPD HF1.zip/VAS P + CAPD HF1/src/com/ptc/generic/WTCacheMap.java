package com.ptc.generic;

import java.rmi.RemoteException;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import wt.cache.CacheManager;

public class WTCacheMap<K, V> implements Map<K, V> {

	TreeMap<K, V> localMap = null;
	private WTCache thisWTCache = null;

	private class WTCache extends CacheManager {
		private static final long serialVersionUID = 8037576778567364771L;

		public WTCache() throws RemoteException {
			super();
		}

		public Iterator getKeys() {
			return super.getKeys();
		}
	}

	public WTCacheMap() throws RemoteException {
		localMap = new TreeMap<K, V>();
		thisWTCache = new WTCache();
	}

	public WTCacheMap(Map<K, V> map) throws RemoteException {
		this();
		Set<K> keys = map.keySet();
		for (K key : keys) {
			put(key, map.get(key));
		}
	}

	@Override
	public int size() {
		int i = 0;
		Iterator iter = thisWTCache.getKeys();
		while (iter.hasNext()) {
			i++;
		}
		return i;
	}

	@Override
	public boolean isEmpty() {
		return size() == 0;
	}

	@Override
	public boolean containsKey(Object key) {

		if (localMap.containsKey(key))
			return true;

		Iterator iter = thisWTCache.getKeys();
		while (iter.hasNext()) {
			Object rkey = (Object) iter.next();
			if (rkey.equals(key))
				return true;
		}
		return false;
	}

	@Override
	public boolean containsValue(Object value) {
		boolean notFound = false;

		Iterator iter = thisWTCache.getKeys();
		while (iter.hasNext()) {
			Object key = (Object) iter.next();
			if (get(key).equals(value))
				return true;
		}

		return notFound;
	}

	@Override
	public void putAll(Map<? extends K, ? extends V> m) {
		Set keys = m.keySet();
		for (Object key : keys) {
			thisWTCache.put(key, m.get(key));
		}
		localMap.putAll(m);
	}

	@Override
	public void clear() {
		Iterator keys = thisWTCache.getKeys();
		while (keys.hasNext()) {
			remove(keys.next());
		}
		localMap.clear();
	}

	@Override
	public Set<K> keySet() {
		return localMap.keySet();
	}

	@Override
	public Collection<V> values() {
		return localMap.values();
	}

	@Override
	public Set<java.util.Map.Entry<K, V>> entrySet() {
		return localMap.entrySet();
	}

	@SuppressWarnings("unchecked")
	@Override
	public V get(Object key) {
		V value = localMap.get(key);
		if (value != null)
			return value;

		return (V) thisWTCache.get(key);
	}

	@Override
	public V put(K key, V value) {
		V prev = (V) get(key);

		localMap.put(key, value);
		thisWTCache.put(key, value);

		return prev;
	}

	@Override
	public V remove(Object key) {
		V prev = (V) get(key);

		localMap.remove(key);
		thisWTCache.remove(key);

		return prev;
	}

}