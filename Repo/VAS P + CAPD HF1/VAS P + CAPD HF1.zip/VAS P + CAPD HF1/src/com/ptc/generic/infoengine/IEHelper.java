package com.ptc.generic.infoengine;


import java.util.*;

import org.apache.log4j.*;

import wt.fc.*;
import wt.util.WTException;

import com.infoengine.object.factory.Att;
import com.infoengine.object.factory.Element;
import com.infoengine.object.factory.Group;

import ext.tools.ToolUtils;


public class IEHelper {

	private static final String CLASSNAME = IEHelper.class.getName();
	private static final Logger logger= Logger.getLogger(CLASSNAME);
	private static final Logger loggerIE = Logger.getLogger(CLASSNAME + "_IE");
	private static final ReferenceFactory RF = new ReferenceFactory();
	
	public static Persistable doIECreate(String task, Hashtable ht) throws WTException {
		System.out.println("task=" + task);
		System.out.println("ht=" + ht);
		
		Persistable returnObj = null;
		try {
			Map map = doIETask(task, ht);
			
			// we only reach this if no error appeared at task excecution
			//Element elements[] = gCO.getElementArray();
			//if (elements.length == 1 && gCO.getStatus() == 0) {
			Collection elements = map.values();
			Element element = null;
			if(elements.size()==1) {
				element = (Element)elements.iterator().next();
				logger.debug("PersistenceIdentifier=" + element.getPersistenceIdentifier());
				Att obid = element.getAtt("obid");
				String shortObid = ToolUtils.shortObid(obid.getValue());
				returnObj = RF.getReference(shortObid).getObject();
				logger.debug("returnObj=" + returnObj);
			} else if(elements.size()==0){
				throw new WTException("I*E task '" + task + "' returned no element");
			} else {
				throw new WTException("I*E task '" + task + "' returned more than 1 element: " + elements.size());
			}
		} catch (Exception e) {
			if (e instanceof WTException) {
				logger.error("got WTException: " + e.toString());
				logger.debug("locMsg=" + e.getLocalizedMessage());
				throw (WTException) e;
			} else {
				logger.error("got (non-WT)Exception: " + e.toString());
				logger.debug("locMsg=" + e.getLocalizedMessage());
				throw new WTException(e);
			}
		}
		return returnObj;
	}
	
	public static Map doIETask(String task, Hashtable ht) throws WTException {
		System.out.println("task=" + task);
		System.out.println("ht=" + ht);
		
		HashMap returnObj = new HashMap();
		
		try {
			Group gCO = null;
			gCO = ToolUtils.callTask(ht, null, task, null);
			if (loggerIE.isDebugEnabled()) {
				loggerIE.debug("I*E RESULT: gCO=");
				gCO.toXML(new java.io.PrintWriter(System.out), true);
			}
			logger.debug("gCO.status=" + gCO.getStatus());

			// error handling
			if (gCO != null) {
				Object err = gCO.getAttributeValue(0, "exception-object");
				if (err != null) {
					System.out.println("found exception:" + err);
					if (err instanceof WTException) {
						throw (WTException) err;
					} else if (err instanceof Throwable) {
						throw new WTException((Throwable) err);
					} else {
						throw new WTException(err.toString());
					}
				}
				logger.debug("GROUP SUCCESS: " + gCO.getSuccess());
			}

			// we only reach this if no error appeared at task excecution
			Element elements[] = gCO.getElementArray();
			
			if (gCO.getStatus() != 0) {
				logger.error("elements.length=" + elements.length + " gCO.getStatus()=" + gCO.getStatus());
				throw new WTException("return status of I*E task '" + task + "' was not 0: " + gCO.getStatus());
			} else {
				for(int i=0; i<elements.length; i++) {
					logger.debug("PersistenceIdentifier=" + elements[i].getPersistenceIdentifier());
					Att obid = elements[i].getAtt("obid");
					String shortObid = ToolUtils.shortObid(obid.getValue());
					returnObj.put(shortObid, elements[i]);
				}
			}
		} catch (Exception e) {
			if (e instanceof WTException) {
				logger.error("got WTException: " + e.toString());
				logger.debug("locMsg=" + e.getLocalizedMessage());
				throw (WTException) e;
			} else {
				logger.error("got (non-WT)Exception: " + e.toString());
				logger.debug("locMsg=" + e.getLocalizedMessage());
				throw new WTException(e);
			}
		}
		return returnObj;
	}
}
