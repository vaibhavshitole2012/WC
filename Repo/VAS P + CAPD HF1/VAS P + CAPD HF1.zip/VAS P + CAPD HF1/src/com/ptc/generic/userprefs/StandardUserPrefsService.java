/*
 * bcwti
 *
 * Copyright (c) 2013 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */
package com.ptc.generic.userprefs;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import wt.fc.ObjectIdentifier;
import wt.fc.ObjectReference;
import wt.fc.PersistInfo;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.fc.WTReference;
import wt.inf.container.WTContainerHelper;
import wt.org.WTPrincipal;
import wt.org.WTUser;
import wt.pds.ReferenceJoinCondition;
import wt.pds.StatementSpec;
import wt.pom.Transaction;
import wt.preference.PreferenceCategory;
import wt.preference.PreferenceClient;
import wt.preference.PreferenceDefinition;
import wt.preference.PreferenceHelper;
import wt.preference.PreferenceInstance;
import wt.query.ClassAttribute;
import wt.query.CompositeWhereExpression;
import wt.query.LogicalOperator;
import wt.query.QuerySpec;
import wt.query.SQLFunction;
import wt.query.SearchCondition;
import wt.services.StandardManager;
import wt.session.SessionContext;
import wt.session.SessionHelper;
import wt.util.WTException;

import com.ptc.generic.Introspector;
import com.ptc.generic.StringValuesHelper;
import com.ptc.service.annotations.GenerateService;
import com.ptc.service.annotations.InterfaceConstant;
import com.ptc.generic.userprefs.UserPrefsService;

/**
 *
 * <p>
 * Use the <code>newStandardUserPrefsService</code> static factory method(s),
 * not the <code>StandardUserPrefsService</code> constructor, to construct
 * instances of this class.  Instances must be constructed using the static
 * factory(s), in order to ensure proper initialization of the instance.
 * <p>
 *
 *
 * @version   1.0
 **/
@GenerateService(interfaceConstants = {
    @InterfaceConstant(type = String.class, name = "PREFERENCE_DEFAULT_HANDLER",
    value = "\"com.ptc.windchill.enterprise.preference.handler.StringPreferenceValueHandler\""),
    @InterfaceConstant(type = String.class, name = "ECA_CLIENT_NAME", value = "\"ECA\"")
})
public class StandardUserPrefsService extends StandardManager implements UserPrefsService, Serializable {

    public static final String svnRev = "$Revision: 1.1.1.3 $ $Date: 2015/12/10 21:01:36IST $";
    public static final String svnUrl = "$URL: http://127.0.0.1/svn/KB_04082016/components/Generic-Utilities/src/com/ptc/generic/userprefs/StandardUserPrefsService.java $";

    private static final long serialVersionUID = 6400210159534581737L;
    private static final Logger logger = Logger.getLogger(StandardUserPrefsService.class);
    private static final String NAME_PREFIX = "#";
    private static int dbColumnMaxLength = 0;
    private static final boolean ALLOW_CLEANING = false; //flag to allow cleaning Preference Definitions - set to false when definitions should not be deleted

    /**
     * Default factory for the class.
     *
     * @return    StandardUserPrefsService
     * @exception wt.util.WTException
     **/
    public static StandardUserPrefsService newStandardUserPrefsService()
            throws WTException {
        StandardUserPrefsService instance = new StandardUserPrefsService();
        instance.initialize();
        return instance;
    }

    /**
     * Get value for single user preference. This method retrieves value
     * for current user context preference in ECA_CATEGORY_NAME category
     * for given application. If the preference is multivalue one, the value
     * is concatenated together with values from PreferenceDefinition's with
     * the same names but ending with numbers #1..#n.
     *
     * @param     name
     * @param     client
     * @return    String
     * @exception wt.util.WTException
     **/
    public String getUserPreference(String name, String client)
            throws WTException {
        if (logger.isDebugEnabled()) {
            logger.debug("Retrieving user preference value for name=" + name + " client=" + client);
        }
        // Preference value that is to be returned.
        StringBuilder value = new StringBuilder();
        String temp = null;
        // Get user that has administrative rights.
        WTUser user = (WTUser) SessionHelper.manager.getPrincipal();
        // Get value from a single PreferenceInstance
        Object valueObject = PreferenceHelper.service.getValue(user, name, client);
        // If the value exists append it to retuned value.
        // Get the max column length if it's not stored.
//        if (dbColumnMaxLength <= 0) {
        dbColumnMaxLength = Introspector.introspectColumnLength(PreferenceInstance.class, PreferenceInstance.VALUE);
//        }
        // Number to add to preference name.
        int nextPrefNumber = 1;

        while (valueObject!=null) {
            temp = valueObject.toString();
            temp = temp.trim();
            value.append(temp);
            try {
                // Try to get the next part of preference value and increase the number.
                valueObject = PreferenceHelper.service.getValue(user, name + NAME_PREFIX + nextPrefNumber, client);
                nextPrefNumber++;
            } catch (Exception e) {
                break;
            }
        }
        if (logger.isDebugEnabled()) {
            logger.debug("returning Value for " + name + " preference: " + value);
        }
        return value.toString();
    }

    /**
     * Sets single user preference value in current user context in ECA_CATEGORY_NAME.
     * If given preference does not yet have definition it will create new
     * String preference definition in ECA_CATEGORY_NAME category.
     * If the preference value is too long to add to a single PreferenceInstance value,
     * the value is splitted and added to another PreferenceDefinition with name ending
     * with number 1..n
     * If the value is shorter unused PreferenceInstances will be deleted.
     * <p>
     * <b>Note that visibility will only be used on preference definition
     * creation - when no previous preference instance was created (for ANY
     * user). So it can't be used to change current preference definition
     * visibility</b>
     * </p>
     *
     * @param     name
     * @param     client
     * @param     category
     * @param     value
     * @param     defaultValue
     * @param     visibility
     * @exception wt.util.WTException
     */
    //AB - made method synchronized because of huge amount of parallel calls to the userpref for saving expansion states on Baustufenseite
    public synchronized void setUserPreference(String name, String client, UserPrefCategory category, String value, String defaultValue, int visibility)
            throws WTException {
        Transaction trx = new Transaction();
        try {
            trx.start();
            if(defaultValue == null){defaultValue="";}
            if (logger.isDebugEnabled()) {
                logger.debug("Setting user preference " + name + " to: " + value 
                		+ "; client=" + client + " category=" + category + " defaultValue=" + defaultValue + " visibility=" + visibility);
            }
            WTUser user = (WTUser) SessionHelper.manager.getPrincipal();
            // Check if the preference definition exists. If not create one.           
            if(value != null) {
                PreferenceDefinition definition = PreferenceHelper.service.getPreferenceDefinition(name);
                if(definition == null){
                    createPreferenceDefinition(name, category.name(), client, defaultValue, visibility);
                }else{
                	//VW_ECA-16932 - just delete preference value when we are sure that preference exists 
                	deleteUserPreference(name, client, false);
                }
                PreferenceHelper.service.setValue(name, client, "", user);

                if (dbColumnMaxLength <= 0) {
                        dbColumnMaxLength = Introspector.introspectColumnLength(PreferenceInstance.class, PreferenceInstance.VALUE);
                }
                // Split the value into a List<String> of values that will fit single PreferenceInstance value.
                List<String> values = value.length() > 0 ? StringValuesHelper.splitMultiValue(PreferenceInstance.class,
                        PreferenceInstance.VALUE, value, false, dbColumnMaxLength) : new ArrayList<String>();
                int preferenceInstanceNr = 1;
                if (values.size() > 0) {
                	logger.debug("values size: " + values.size());
                    preferenceInstanceNr = values.size();
                    // Set value of the first preference definition (without prefix, to fit the storing convention for the rest of prefecences)
                    PreferenceHelper.service.setValue(name, client, values.get(0), user);
                    // For every other splitted values do the same.
                    for (int i = 1; i < values.size(); i++) {
                    	logger.debug("preferenceDefinition name: " + name + NAME_PREFIX + i);
                        definition = PreferenceHelper.service.getPreferenceDefinition(name + NAME_PREFIX + i);                      
                        if(definition == null){
                            createPreferenceDefinition(name + NAME_PREFIX + i, category.name(), client, defaultValue, visibility);
                            logger.debug("preferenceDefinition null - created new");
                        }else{
                        	deleteUserPreference(name + NAME_PREFIX + i, client, false);
                        	logger.debug("preferenceDefinition not null - deleted existing");
                        }
                        PreferenceHelper.service.setValue(name + NAME_PREFIX + i, client, values.get(i), user);
                    }
                }
                else {
                    PreferenceHelper.service.setValue(name, client, "", user);
                }

                /*
                * bmueller 20120509
                * Delete PreferenceInstances that are not used anymore.
                */
                definition = PreferenceHelper.service.getPreferenceDefinition(name + NAME_PREFIX + preferenceInstanceNr);
                while (definition != null) {
                        deleteUserPreference(name + NAME_PREFIX + preferenceInstanceNr, client, true);
                        if (logger.isDebugEnabled()) {
                                logger.debug("PreferenceInstance " + name + NAME_PREFIX + preferenceInstanceNr + " deleted!");
                        }
                        ++preferenceInstanceNr;
                        definition = PreferenceHelper.service.getPreferenceDefinition(name + NAME_PREFIX + preferenceInstanceNr);
                }
            }
            trx.commit();
            trx = null;
            if (logger.isDebugEnabled()) {
                logger.debug("Preference " + name + " saved");
            }
        } finally {
            if(trx != null) {
                trx.rollback();
            }
        }
    }

    /**
     * Retrieve multiple preference values in current user context for passed client name
     *
     * @param names
     * @param client
     * @return Map<String,Object>
     * @exception wt.util.WTException
     */
    public Map<String, Object> getUserPreferences(Collection<String> names, String client) throws WTException {
        return getUserPreferences(names, client, SessionHelper.manager.getPrincipal());
    }

    /**
     * Retrieve multiple preference values in given user context for passed client name
     *
     * @param names
     * @param client
     * @param principal
     * @return Map<String,Object>
     * @exception wt.util.WTException
     */
    public Map<String, Object> getUserPreferences(Collection<String> names, String client, WTPrincipal principal)
            throws WTException {

    	if(logger.isDebugEnabled()) {
    		logger.debug("getting userPrefs for names=" + names + " client=" + client 
    				+ " principal=" + principal!=null?principal.getName():"null");
    	}
    	
    	//bmueller 20120510 Added support for multiple PreferenceInstances
    	final List<String> additionalNames = new ArrayList<String>();
    	for (String entry : names) {
    		additionalNames.addAll(getPreferenceInstanceNames(entry));
        }
    	names.addAll(additionalNames);

        if (logger.isDebugEnabled()) {
            StringBuilder sb = new StringBuilder("Retrieving user preferences:\n");
            for (String preferenceName : names) {
                sb.append('\t');
                sb.append(preferenceName);
                sb.append('\n');
            }

            logger.debug(sb.toString());
        }

        Map<String, Object> splitUserPrefs = new HashMap<String, Object>();
        if (principal != null) {
            splitUserPrefs = PreferenceHelper.service.getValues(null, splitUserPrefs, names, null, client,
                    (WTUser) principal);
        } else {
            splitUserPrefs = PreferenceHelper.service.getValues(splitUserPrefs, names, null, client,
                    WTContainerHelper.service.getOrgContainer(SessionHelper.getPrincipal().getOrganization()));
        }
        Map<String, Object> userPrefs = new HashMap<String, Object>(splitUserPrefs.size());
        SortedMap<String, Object> sortedUserPrefs = new TreeMap<String, Object>(splitUserPrefs);
        for (String key : sortedUserPrefs.keySet()) {
            if (!key.contains(NAME_PREFIX)) {
                Object value = sortedUserPrefs.get(key);
                String concatenatedValue = value == null ? null : StringUtils.isBlank(value.toString()) ? null : value.
                        toString();
                if (concatenatedValue != null) {
                    StringBuilder valueBuilder = new StringBuilder(concatenatedValue);
                    for (Entry<String, Object> userPref : sortedUserPrefs.entrySet()) {
                        if (userPref.getKey().contains(NAME_PREFIX) && userPref.getKey().startsWith(key)) {
                        	if(StringUtils.isEmpty((String) sortedUserPrefs.get(userPref.getKey())) && userPref.getKey().contains("/ext/vw/eclist/userPreferences/applet.config.")){
                        		//START VW_ECA-18076
                        		//for some reason we are using uppercase and lowercase userpref names in db sometimes
                        		//when concat multiple userprefs we have to use the uppercase name
                        		String userPrefKey = userPref.getKey();
                        		String temp = userPrefKey.replace("/ext/vw/eclist/userPreferences/applet.config.", "");
                        		int index = temp.lastIndexOf(".");
                        		String prefName = temp.substring(0, index);
                        		String prefNameNew = StringUtils.upperCase(prefName);
                        		userPrefKey = StringUtils.replace(userPrefKey, prefName, prefNameNew);

                        		if(StringUtils.isNotEmpty((String) sortedUserPrefs.get(userPrefKey))){
                        			valueBuilder.append(sortedUserPrefs.get(userPrefKey));
                        		}
                        		//END VW_ECA-18076
				   }else{
					 valueBuilder.append(sortedUserPrefs.get(userPref.getKey()));
				   }
			     }
			  }
                    concatenatedValue = valueBuilder.toString();
                }
                userPrefs.put(key, concatenatedValue);
            }
        }
        if(logger.isDebugEnabled()) {
        	logger.debug("returning userPrefs=" + userPrefs);
        }
        return userPrefs;
    }

    /**
     * Helper method to add support for PreferenceInstances.
     * Checks if there are unused PreferenceInstances.
     *
     * @author bmueller 20120510
     * @param name PreferenceDefinition
     * @return List of PreferenceInstances for deletion
     * @throws WTException
     */
	private List<String> getPreferenceInstanceNames(String name) throws WTException {
		if(logger.isDebugEnabled()) {
			logger.debug("getPrefInstanceNames for name=" + name);
		}
		final List<String> names = new ArrayList<String>();
		PreferenceDefinition definition = PreferenceHelper.service.getPreferenceDefinition(name);
		int instanceNr = 1;
		while (definition != null) {
			names.add(name);
                        name = new StringBuilder(name).append(NAME_PREFIX).append(instanceNr).toString();
			definition = PreferenceHelper.service.getPreferenceDefinition(name);
			++instanceNr;
		}
		if(logger.isDebugEnabled()) {
			logger.debug("returning names=" + names);
		}
		return names;
	}

    /**
     * Remove user preference value from Windchill database. Only value will
     * be deleted, preference definition will be preserved unless you pass
     * true for cleanupDefinition.
     *
     * @param name
     * @param client
     * @param cleanupDefinition  If preference definition should be removed if no preference instances left in database
     * @exception wt.util.WTException
     */
    public void deleteUserPreference(String name, String client, boolean cleanupDefinition) throws WTException {
        deleteUserPreference(name, client, cleanupDefinition, SessionHelper.manager.getPrincipal());
    }

    /**
     * Remove user preference value from Windchill database. Only value will
     * be deleted, preference definition will be preserved unless you pass
     * true for cleanupDefinition.
     *
     * @param name
     * @param client
     * @param cleanupDefinition  If preference definition should be removed if no preference instances left in database
     * @param principal
     * @exception wt.util.WTException
     */
    public void deleteUserPreference(String name, String client, boolean cleanupDefinition, WTPrincipal principal)
            throws WTException {
        if (principal == null) {
            throw new WTException("Null principal");
        }
        if (logger.isDebugEnabled()) {
            logger.debug("Deleting userPref for name=" + name + "; client: " + client + " cleanupDefinition=" + cleanupDefinition
            		+ "principal=" + principal.getName());
        }

        SessionContext oldContext = SessionContext.newContext();
        try {
            SessionHelper.manager.setAdministrator();
            PreferenceHelper.service.deleteWTUserPreferenceInstance(name, client, (WTUser) principal);
            PreferenceHelper.service.deleteWTUserPreferenceInstance(name, (WTUser) principal);
        } finally {
            SessionContext.setContext(oldContext);
        }
        logger.debug("Preference instance removed");
        if (cleanupDefinition) {
			try {
				cleanupDefinition(name);
			} catch (WTException ex) {
				logger.error("Could not check and remove preference definition. Unused definition may be left in system.", ex);
			}

		}
    }

    /**
     * Remove preference value from site context
     *
     * @param name name of preference
     * @param client name of preference client
     * @param asAdmin delete preference as site admin (not as current user) bypassing access rules
     * @param cleanupDefinition If preference definition should be removed if no preference instances left in database
     * @throws WTException
     */
    public void deleteSitePreference(String name, String client, boolean asAdmin, boolean cleanupDefinition)
            throws WTException {
        if (logger.isDebugEnabled()) {
            logger.debug("Removing site preference: " + name + " client: " + client + " asAdmin: " + asAdmin + " cleanupDefinition: " + cleanupDefinition);
        }
        if(asAdmin) {
            SessionContext oldContext = SessionContext.newContext();
            try {
                SessionHelper.manager.setAdministrator();
                PreferenceHelper.service.deleteSitePreferenceInstance(name, client);
            } finally {
                SessionContext.setContext(oldContext);
            }
        } else {
            PreferenceHelper.service.deleteSitePreferenceInstance(name, client);
        }

        if (cleanupDefinition) {
			try {
				cleanupDefinition(name);
			} catch (WTException ex) {
				logger.error("Could not check and remove preference definition. Unused definition may be left in system.", ex);
			}
		}
    }

	/**
	 * Retrieve all user preference names for the given client and category.
	 * 
	 * @param client
	 * @param category
	 * @return Collection<String>
	 * @exception wt.util.WTException
	 */
	public Collection<String> getUserPreferenceNames(final String client, final UserPrefCategory category) throws WTException {
		return getUserPreferenceNames(null, client, category, null);
	}
    
	/**
	 * Retrieve all user preference names that start with given prefix from
	 * given category and client for the given user
	 * 
	 * @param prefix
	 * @param client
	 * @param category
	 * @param principal : if null search will use the current user
	 * @return Collection<String>
	 * @exception wt.util.WTException
	 */
	public Collection<String> getUserPreferenceNames(final String prefix, final String client, final UserPrefCategory category, WTPrincipal principal)
			throws WTException {

		if (logger.isInfoEnabled()) {
			logger.info("Retrieving all preference names with prefix='" + prefix + "' for client=" + client + " and category=" + category);
		}

		if (principal == null) {
			principal = SessionHelper.getPrincipal();
		}
		final ObjectIdentifier userOid = principal.getPersistInfo().getObjectIdentifier();

		if (logger.isDebugEnabled()) {
			logger.debug("Searching preferences only for user: " + principal.getPrincipalDisplayIdentifier());
		}
		final Set<String> preferenceNamesFromAllCategories = new HashSet<String>();

		final QuerySpec qs = new QuerySpec();
		int pcatIdx = -1;
		if (category != null) {
			pcatIdx = qs.appendClassList(PreferenceCategory.class, false);
		}
		final int pcliIdx = qs.appendClassList(PreferenceClient.class, false);
		final int pdefIdx = qs.appendClassList(PreferenceDefinition.class, true);
		final int pinsIdx = qs.appendClassList(PreferenceInstance.class, false);

		// Join preference definition (we only search for definitions that
		// current user has instances for)
		qs.appendCondition(new ReferenceJoinCondition(pinsIdx, pdefIdx, PreferenceInstance.PREFERENCE_DEFINITION_REFERENCE));
		// Join client (only instances for passed client should be used)
		qs.appendCondition(new ReferenceJoinCondition(pinsIdx, pcliIdx, PreferenceInstance.CLIENT_REFERENCE));

		final CompositeWhereExpression where = new CompositeWhereExpression(LogicalOperator.AND);
		where.append(new SearchCondition(PreferenceClient.class, PreferenceClient.NAME, SearchCondition.EQUAL, client), new int[] { pcliIdx });
		// Check for category name
		if (category != null) {
			where.append(new SearchCondition(PreferenceCategory.class, PreferenceCategory.NAME, SearchCondition.EQUAL, category.name()),
					new int[] { pcatIdx });
		}

		// Check for visibility: USER or USER_ONLY
		where.append(new SearchCondition(PreferenceDefinition.class, PreferenceDefinition.VISIBILITY, SearchCondition.GREATER_THAN_OR_EQUAL,
				PreferenceDefinition.VISIBILITY_USER), new int[] { pdefIdx });
		// Check for user (only instances for current user )
		where.append(new SearchCondition(PreferenceInstance.class, PreferenceInstance.WTUSER_REFERENCE + '.' + WTReference.KEY + '.'
				+ ObjectIdentifier.ID, SearchCondition.EQUAL, userOid.getId()), new int[] { pinsIdx });

		// Search for given prefix in name
		if (StringUtils.isNotBlank(prefix)) {
			where.append(new SearchCondition(PreferenceDefinition.class, PreferenceDefinition.NAME, SearchCondition.LIKE, new StringBuilder(prefix)
					.append("%").toString()), new int[] { pdefIdx });
		}

		if (StringUtils.isNotBlank(prefix)) {
			if (category != null && principal != null) {
				qs.appendWhere(where, new int[] { pcliIdx, pcatIdx, pdefIdx, pinsIdx, pdefIdx });
			} else if (category != null) {
				qs.appendWhere(where, new int[] { pcliIdx, pcatIdx, pdefIdx, pdefIdx });
			} else if (principal != null) {
				qs.appendWhere(where, new int[] { pcliIdx, pdefIdx, pinsIdx, pdefIdx });
			} else {
				qs.appendWhere(where, new int[] { pcliIdx, pdefIdx, pdefIdx });
			}
		} else {
			if (category != null) {
				qs.appendWhere(where, new int[] { pcliIdx, pcatIdx, pdefIdx, pinsIdx });
			} else {
				qs.appendWhere(where, new int[] { pcliIdx, pdefIdx, pinsIdx });
			}
		}

		if (logger.isTraceEnabled()) {
			logger.trace("qs=" + qs);
		}

		final QueryResult qr = PersistenceHelper.manager.find((StatementSpec) qs);

		Object[] nextElement = null;
		PreferenceDefinition pd = null;
		while (qr.hasMoreElements()) {
			nextElement = (Object[]) qr.nextElement();
			pd = (PreferenceDefinition) nextElement[0];
			logger.debug("found pd=" + pd + " " + pd.getName());
			preferenceNamesFromAllCategories.add(pd.getName());
		}
		if (logger.isDebugEnabled()) {
			logger.trace("preferenceNamesFromAllCategories=" + preferenceNamesFromAllCategories);
			logger.debug("Retrieved " + preferenceNamesFromAllCategories.size() + " preference names");
		}
		
		// If no category is specified we return everything we found.
		if (category == null) {
			return preferenceNamesFromAllCategories;
		}

		// ECA5.0: workaround for the missing category join reference
		Set<String> preferenceNames = null;
		if (StringUtils.isNotBlank(prefix)) {
			preferenceNames = getPreferenceNamesForCategory(category.name(), PreferenceDefinition.VISIBILITY_USER, prefix);	
		} else {
			preferenceNames = getPreferenceNamesForCategory(category.name(), PreferenceDefinition.VISIBILITY_USER);
		}
		if (logger.isDebugEnabled()) {
			logger.debug("preferenceNames=" + preferenceNames);
		}

		/*
		 * build intersection of the set of preferencesNames for the user (i.e.
		 * category independent) and from the set of preferenceNames from all
		 * categories (i.e. user independent)
		 */
		preferenceNames.retainAll(preferenceNamesFromAllCategories);
		if (logger.isDebugEnabled()) {
			logger.debug("after retainAll: preferenceNames=" + preferenceNames);
			logger.debug("Retrieved " + preferenceNames.size() + " preference names");
		}

		return preferenceNames;
	}

    /* 
     * client = ECA
     * category = [ECA_VIEW, ECA_COLUMN_FILTER, ECA_PR_FILTER, ECA_EXPANSION_STATES]
     * definition = ?
     * instance = ?
     *
     * looking for definition.getName()
     *
     * since ECA 5.0
     * 
     * @param category The category to search for PreferenceNames
     * @param visiblity Threshold for the minimum visibility 
     * @return the Preference names from the given category that are visible
     */
    private Set<String> getPreferenceNamesForCategory(final String category, final int visibility) throws WTException {

    	Collection<PreferenceDefinition> definitions = getPreferenceDefinitionsForCategory(category);

    	final Set<String> definitionsName = new HashSet<String>();
    	definitions = filterVisibility(definitions, visibility);

    	String name = null;
    	for (final PreferenceDefinition preferenceDefinition : definitions) {
    		name = preferenceDefinition.getName();
			definitionsName.add(name);
		}
    	return definitionsName;
    }

    /*
     * since ECA 5.0
     * @param definitions Collection to filter
     * @param visibility Threshold for the minimum visibility
     * @return The PreferenceDefinition Collection were non-visible objects have been removed.
     */
    private Collection<PreferenceDefinition> filterVisibility(final Collection<PreferenceDefinition> definitions, final int visibility) {

    	final Collection<PreferenceDefinition> filtered = new ArrayList<PreferenceDefinition>();

    	for (final PreferenceDefinition preferenceDefinition : definitions) {

    		/*
    		 * not sure if this check is even required.
    		 * Visibility value has changed from 900 (9.1) to 16 (10.x) for User
    		 */
			if (preferenceDefinition.getVisibility() >= visibility) {
				filtered.add(preferenceDefinition);
			}
		}
    	return filtered;
    }

    /*
     * since ECA 5.0
     * 
     * @param category The category to search for PreferenceNames
     * @param visibility Threshold for the minimum visibility
     * @param searchstring will be used for startsWith search
     * @return the Preference names from the given category that are visible and starts with the given search string 
     */
    private Set<String> getPreferenceNamesForCategory(final String category, final int visibility, final String searchstring) throws WTException {

    	Collection<PreferenceDefinition> definitions = getPreferenceDefinitionsForCategory(category);

    	final Set<String> definitionsName = new HashSet<String>();
    	definitions = filterVisibility(definitions, visibility);

    	String name = null;
    	for (final PreferenceDefinition preferenceDefinition : definitions) {
    		name = preferenceDefinition.getName();

			if (searchstring != null && searchstring.length() > 0 && name.startsWith(searchstring)) {
				definitionsName.add(name);
			}
		}
    	return definitionsName;
    }

    /*
     * since ECA 5.0
     * @param The category to look into
     * @return A Collection of PreferenceDefinitions from the given category
     */
    private Collection<PreferenceDefinition> getPreferenceDefinitionsForCategory(final String category) throws WTException {

    	final Collection<PreferenceDefinition> definitions = new ArrayList<PreferenceDefinition>();
    	final Collection<String> categoryNames = new ArrayList<String>();
    	categoryNames.add(category);

    	return PreferenceHelper.service.getPreferenceDefinitionsFromPreferenceCategories(definitions, categoryNames);
    }

    /**
     * Change default value of user preference on server. This method allows
     * you to change default value on server without changing user preference
     * class (no need to restart server). Keep in mind, that server default
     * value will be different than value stored on UserPreference after
     * calling this method so use UserPrefsManager.updateDefaultValue if
     * you don't really need this.
     *
     * @see UserPrefsManager#updateDefaultValue
     *
     * @param     name
     * @param     category
     * @param     client
     * @param     newDefault
     * @param     visibility
     * @exception wt.util.WTException
     **/
    public void changeDefaultValue(String name, String category, String client, String newDefault, int visibility)
            throws WTException {
        if (logger.isInfoEnabled()) {
            logger.info("Changing default value for preference: " + name + " to value: " + newDefault);
        }
        createPreferenceDefinition(name, category, client, newDefault, visibility);
        if (logger.isDebugEnabled()) {
            logger.debug("Default value changed");
        }

    }

    /**
     * This method does not support values higher than PTC OOTB configuration.
     *
     * @param name
     * @param categoryName
     * @param client
     * @param defaultValue
     * @param visibility
     * @throws WTException
     */
	private void createPreferenceDefinition(String name, String categoryName, String client, String defaultValue,
			int visibility) throws WTException {

		SessionContext oldContext = SessionContext.newContext();
		SessionHelper.manager.setAdministrator();
		try {
			
			// Check if given client and category exist.
			final PreferenceClient preferenceClient = PreferenceHelper.service.getPreferenceClient(client);
			if (preferenceClient == null) {
				throw new WTException("The given PreferenceClient (" + client + ") does not exist!");
			}
			final PreferenceCategory preferenceCategory = PreferenceHelper.service.getPreferenceCategory(categoryName);
			if (preferenceCategory == null) {
				throw new WTException("The given PreferenceCategory (" + categoryName + ") does not exist!");
			}

			// bmueller 20120510 Added meaningful error message
			if (dbColumnMaxLength <= 0) {
				dbColumnMaxLength = Introspector.introspectColumnLength(PreferenceInstance.class,
						PreferenceInstance.VALUE);
			}
			if (defaultValue.length() > dbColumnMaxLength) {
				throw new WTException("Length of defaultValue (" + defaultValue.length()
						+ ") exceeds the limit of the database column (" + dbColumnMaxLength + ")");
			}

			if(logger.isDebugEnabled()) {
				logger.debug("creating prefDefinition as admin user=" + SessionHelper.getPrincipal().getName());
				logger.debug("name=" + name + " categoryName=" + categoryName + " visibility=" + visibility + " defaultValue=" + defaultValue);
			}
			PreferenceHelper.service.createPreferenceDefinition(name, categoryName, "", name, "", name, "", name,
					visibility, PREFERENCE_DEFAULT_HANDLER, defaultValue);
			if (logger.isDebugEnabled()) {
				logger.debug("Definition for preference" + name + "created");
			}

			boolean linkCreated = PreferenceHelper.service.setClientDefinitionLink(name, client);
			if (logger.isDebugEnabled()) {
				logger.debug("Definition " + (linkCreated ? "" : "NOT ") + "linked to " + client + " client.");
			}
		} finally {
			SessionContext.setContext(oldContext);
		}
	}

    /**
     * DO NOT CALL THIS METHOD - DEFINITIONS WILL NOT BE REMOVED ANY LONGER
     * 
     * Check if we have any preference instance in database referring definition
     * with this name. Remove definition if no longer used.
     *
     * @param name Name of preference definition to check
     * @throws WTException if query or PreferenceHelper failed
     * @deprecated
     */
    private void cleanupDefinition(String name)
            throws WTException {
		if (ALLOW_CLEANING) {
			if (logger.isInfoEnabled()) {
				logger.info("Checking if definition of " + name + " preference is still needed");
			}
			QuerySpec qs = new QuerySpec();
			qs.setAdvancedQueryEnabled(true);

			// We need this only to count elements
			int piIdx = qs.appendClassList(PreferenceInstance.class, false);
			int pdIdx = qs.appendClassList(PreferenceDefinition.class, false);

			// Add COUNT function as we don't need objects but only check if
			// they exist
			SQLFunction count = SQLFunction.newSQLFunction(SQLFunction.COUNT, new ClassAttribute(PreferenceInstance.class,
					PreferenceInstance.PERSIST_INFO + '.' + PersistInfo.OBJECT_IDENTIFIER + '.' + ObjectIdentifier.ID));
			qs.appendSelect(count, new int[] { piIdx }, false);

			// Check if we have instances for definition with passed name
			CompositeWhereExpression composite = new CompositeWhereExpression(LogicalOperator.AND);
			composite.append(new SearchCondition(PreferenceDefinition.class, PreferenceDefinition.NAME, SearchCondition.EQUAL, name, true),
					new int[] { pdIdx });
			composite.append(new SearchCondition(PreferenceDefinition.class, PreferenceDefinition.PERSIST_INFO + '.' + PersistInfo.OBJECT_IDENTIFIER
					+ '.' + ObjectIdentifier.ID, PreferenceInstance.class, PreferenceInstance.PREFERENCE_DEFINITION_REFERENCE + '.'
					+ ObjectReference.KEY + '.' + ObjectIdentifier.ID), new int[] { pdIdx, piIdx });
			qs.appendWhere(composite, new int[] { pdIdx, pdIdx, piIdx });

			QueryResult qr = PersistenceServerHelper.manager.query(qs);

			if (qr.hasMoreElements()) {
				Object[] result = (Object[]) qr.nextElement();
				BigDecimal value = (BigDecimal) result[0];
				if (value.compareTo(BigDecimal.ZERO) == 0) {
					logger.debug("Setting administrator");
					SessionContext oldContext = SessionContext.newContext();
					try {
						SessionHelper.manager.setAdministrator();
						logger.debug("No preference instances found. Removing definition");
						PreferenceHelper.service.deletePreferenceDefinition(name);
					} finally {
						logger.debug("Resetting method context");
						SessionContext.setContext(oldContext);
					}
				} else {
					if (logger.isDebugEnabled()) {
						logger.debug("Still " + value.toPlainString() + " preference instances exist. Leaving definition");
					}
				}
			}
		}else{
			logger.debug("cleanup of definition is not allowed");
		}

	}
}
