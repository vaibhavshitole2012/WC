package com.ptc.ssp.log4jconfig;

import wt.services.*;
import wt.util.WTException;

public class Log4jService extends StandardManager {
   private static final String CLASSNAME = Log4jService.class.getName();

   public String getConceptualClassname() {
      return CLASSNAME;
   }
   
   protected synchronized void performStartupProcess() throws ManagerException {
      super.performStartupProcess();
      
      //instanciate Log4jSynchronizer to make sure that an instance is available in all methodservers
      try {
      	Log4jSynchronizer lc = Log4jSynchronizer.getLog4jCache();
      	System.out.println("Log4jConfig: instanciated Log4jSynchronizer");
      } catch(Exception e) {
      	throw new ManagerException(this, e);
      }
   }
   
   public static Log4jService newLog4jService() throws WTException {
   	Log4jService instance = new Log4jService();
		instance.initialize();
		return instance;
   }
}
