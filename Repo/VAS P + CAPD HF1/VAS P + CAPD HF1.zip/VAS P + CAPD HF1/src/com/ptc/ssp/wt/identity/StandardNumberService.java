package com.ptc.ssp.wt.identity;

import java.rmi.RemoteException;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import org.apache.log4j.Logger;

import wt.doc.WTDocumentMaster;
import wt.epm.EPMDocumentMaster;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.method.RemoteAccess;
import wt.part.WTPartMaster;
import wt.pds.StatementSpec;
import wt.query.ClassAttribute;
import wt.query.QueryException;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.services.ManagerException;
import wt.services.StandardManager;
import wt.session.SessionContext;
import wt.session.SessionThread;
import wt.util.WTException;

public class StandardNumberService extends StandardManager implements NumberService, RemoteAccess {

	private static final long serialVersionUID = 1L;
	private static final String CLASSNAME = StandardNumberService.class.getName();
	private static Logger logger = Logger.getLogger(CLASSNAME); 

	private static StandardNumberService numberService;	
	private NumberingCache numberingCache;
	
	@Override
	protected synchronized void performShutdownProcess() throws wt.services.ManagerException {};

	@Override
	public void performStartupProcess() throws ManagerException {
		logger.info("StandardNumberService startup.");
		String serviceName = System.getProperty("wt.method.serviceName");
		logger.info("StandardNumberService startup - server:" + serviceName);
		boolean isBGMS = "BackgroundMethodServer".equals(serviceName);
		if (isBGMS && IdentityProperties.skippedNumberCacheEnabled) {
			Runnable bgStart = new Runnable(){
				@Override
				public void run() {
					try {
						logger.debug("retrieving all existing number for WTDoc, WTPart and EPMDoc...");

						final String prefix = IdentityProperties.CachedNumberPrefix;
						Set<String> allNumbers = new HashSet<String>();
						final int meaningfulDigits = IdentityProperties.MeaningfulDigits;
						
						QuerySpec qs = new QuerySpec();
						QueryResult qr;
						String likeSearchCondition = prefix + "%";
						logger.info("SearchCondition :" + likeSearchCondition);

						// WTPart
						int index = qs.appendClassList(WTPartMaster.class, false);
						ClassAttribute wtpartNumberColumn = new ClassAttribute(WTPartMaster.class, WTPartMaster.NUMBER);
						qs.appendSelect(wtpartNumberColumn, false);
						qs.appendWhere(new SearchCondition(WTPartMaster.class, WTPartMaster.NUMBER, SearchCondition.LIKE, likeSearchCondition), new int[]{index});

						qr = PersistenceHelper.manager.find((StatementSpec) qs);

						while (qr.hasMoreElements()) {
							Object object = qr.nextElement();
							if (object instanceof Object[]) {
								allNumbers.add(((Object[]) object)[0].toString());
							}
						}

						// WTDocument
						qs = new QuerySpec();
						int index2 = qs.appendClassList(WTDocumentMaster.class, false);
						ClassAttribute wtdocumentNumberColumn = new ClassAttribute(WTDocumentMaster.class, WTDocumentMaster.NUMBER);
						qs.appendSelect(wtdocumentNumberColumn, false);
						qs.appendWhere(new SearchCondition(WTDocumentMaster.class, WTDocumentMaster.NUMBER, SearchCondition.LIKE, likeSearchCondition), new int[]{index2});

						qr = PersistenceHelper.manager.find((StatementSpec)qs);

						while (qr.hasMoreElements()) {
							Object object = qr.nextElement();
							if (object instanceof Object[]) {
								allNumbers.add(((Object[]) object)[0].toString());
							}
						}

						//EPMDocument
						qs = new QuerySpec();
						int index3 = qs.appendClassList(EPMDocumentMaster.class, false);
						ClassAttribute epmdocumentNumberColumn = new ClassAttribute(EPMDocumentMaster.class, EPMDocumentMaster.NUMBER);
						qs.appendSelect(epmdocumentNumberColumn, false);
						qs.appendWhere(new SearchCondition(EPMDocumentMaster.class, EPMDocumentMaster.NUMBER, SearchCondition.LIKE, likeSearchCondition), new int[]{index3});
						qr = PersistenceHelper.manager.find((StatementSpec) qs);

						while (qr.hasMoreElements()) {
							Object object = qr.nextElement();
							if (object instanceof Object[]) {
								allNumbers.add(((Object[]) object)[0].toString());
							}
						}

						logger.info("all numbers count: " + allNumbers.size());

						int prefixLength = prefix.length();
						logger.info("number prefix to be cached: " + prefix);

						
						// java.util.Set used in order to eliminate same numbers with different suffixes
						Set<Integer> numberSet = new HashSet<Integer>();

						for (String s : allNumbers) {
							if (s.startsWith(prefix) && (s.length() >= prefixLength + meaningfulDigits)) {
								// prefix and "-xxxx" suffix are skipped
								String numberString = s.substring(prefixLength, prefixLength + meaningfulDigits);
								try {
									int number = Integer.parseInt(numberString);
									numberSet.add(number);
								} catch (java.lang.NumberFormatException nfe) {
									logger.info("Illegal Number : " + s);
								}
							}
						}

						logger.info("numbers in database with given prefix: " + numberSet.size());

						// sequence value is always used to determine the highest value of number
						String lastSequence = PersistenceHelper.manager.getNextSequence(IdentityProperties.OracleSequenceNameForNumbers);
						int maxValue = Integer.parseInt(lastSequence);
						logger.info("current sequence value is: " + maxValue);
						ArrayList<Integer> finalNumberList = new ArrayList<Integer>();
						for (int i = 1; i < maxValue; i++) {
							if (!numberSet.contains(i)) {
								finalNumberList.add(i);
							}
						}
						
						numberingCache.storeCacheList(finalNumberList);
						logger.info("number of free numbers cached: " + (finalNumberList.size()));
						logger.info("all free numbers cached: " + finalNumberList);

					} catch (QueryException e) {
						e.printStackTrace();
					} catch (WTException e) {
						e.printStackTrace();
					} 				}
			};
			new SessionThread(bgStart, new SessionContext()).start();
		} else if (!isBGMS) {
			logger.info("Skipped Number Cache not initialazing on ths method server");
		} else {
			logger.info("Skipped Number Cache disabled.");
		}
		for (int i = 0; i < 30; i++) {
			numberService.getNumber();
			try {
				SessionThread.sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
	}

	public static StandardNumberService newStandardNumberService() {
		NumberingCache cache = null;
		try {
			cache = new NumberingCache();
			numberService = new StandardNumberService(cache);
		} catch (RemoteException re) {
			re.printStackTrace();
		}
		return numberService;
	}

	public StandardNumberService(NumberingCache numberingCache) {
		super();
		this.numberingCache = numberingCache;
	}


	public static StandardNumberService getStandardNumberService (){
		if (numberService != null) {
			return numberService;
		} else {
			return newStandardNumberService();
		}
	}

	@Override
	public String getNumber() {
		logger.debug("getNumber() start");
		String generatedNumber;
		synchronized (numberService) {
			Integer number = numberingCache.getNumber();
			logger.debug("cached value: " + number);
			if (number ==null) {
				try {
					
					String sequence = PersistenceHelper.manager.getNextSequence(IdentityProperties.OracleSequenceNameForNumbers);
					number = Integer.parseInt(sequence);
					logger.debug("sequence value: " + number);
				} catch (WTException e) {
					e.printStackTrace();
				}
			}
			NumberFormat nf = new DecimalFormat("0000000");
			generatedNumber = IdentityProperties.CachedNumberPrefix + nf.format(number);
			logger.debug("getNumber() end,  generated number: " + generatedNumber);
		}
		
		return generatedNumber;
	}
	
}
