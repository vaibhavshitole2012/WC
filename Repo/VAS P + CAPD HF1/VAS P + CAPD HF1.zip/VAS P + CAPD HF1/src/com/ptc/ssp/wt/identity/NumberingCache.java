/**
 * Copyright (c) 1998-2008 Parametric Technology. All Rights Reserved.
 */
package com.ptc.ssp.wt.identity;

import java.rmi.RemoteException;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import wt.cache.CacheManager;

/**
 *
 * @author aweyerer
 * @since 4.2
 */
public class NumberingCache extends CacheManager {

    /**
	 * 
	 */
	private static final long serialVersionUID = 5646525299077389759L;
	public static final String cacheKey = "SkippedNumberCacheKey";
	public static final String cacheStatusKey = "CacheStatusKey";
	private static final String CLASSNAME = NumberingCache.class.getName();
	private static final Logger LOGGER = Logger.getLogger(CLASSNAME);
	/**
	 * Default constructor.
	 * 
	 * @throws RemoteException 
	 */
	public NumberingCache() throws RemoteException {
		super();
	}
	
	protected void storeCacheList (ArrayList<Integer> list) {
		if (list.size() > 0) {
			super.put(cacheKey, list);
		}
	}
	
	protected Integer getNumber() {
			ArrayList<Integer> cachedNumbers = (ArrayList<Integer>) super.get(cacheKey);
			if (cachedNumbers != null && cachedNumbers.size() > 0 ) {
				Integer number = cachedNumbers.remove(0);
				storeCacheList(cachedNumbers);
				return number;
			} else {
				return null;
			}
	}
}
