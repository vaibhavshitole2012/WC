package com.ptc.cat.entity.client;


public class CustomPSBComparator extends DefaultAttributeComparator {

	private static final int FIND_NUMBER_MAX_LENGTH = 4;
	private static final String FIND_NUMBER_ATTR_NAME = "findNumber";
	private static final String KB_ELECTR_REF_ATTR_NAME = "IBA|KB_ELECTR_REF";
	
	@Override
	public int compare(Object value1, Object value2, String attribute) {
		if (attribute.equals(FIND_NUMBER_ATTR_NAME)) {
			String str1 = "";
            String str2 = "";
            if (value1 != null) {
                str1 = value1.toString();
            }
            if (value2 != null) {
                str2 = value2.toString();
            }
            return compareFindNumbers(str1, str2);
		} else if (attribute.equals(KB_ELECTR_REF_ATTR_NAME)) {
			String str1 = "";
            String str2 = "";
            if (value1 != null) {
                str1 = value1.toString();
            }
            if (value2 != null) {
                str2 = value2.toString();
            }
            return compareFindNumbers(str1, str2);
		} else {
			return super.compare(value1, value2, attribute);
		}
	}
	
	private int compareFindNumbers(String value1, String value2) {
		value1 = getValueWithZerosPrefix(value1, FIND_NUMBER_MAX_LENGTH);
		value2 = getValueWithZerosPrefix(value2, FIND_NUMBER_MAX_LENGTH);
		return value1.compareTo(value2);
	}
	
	private String getValueWithZerosPrefix(String value, int valueMaxLength) {
		int zerosToAdd = valueMaxLength - value.length();
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < zerosToAdd; i++) {
			sb.append('0');
		}
		return sb.append(value).toString();
	}

}
