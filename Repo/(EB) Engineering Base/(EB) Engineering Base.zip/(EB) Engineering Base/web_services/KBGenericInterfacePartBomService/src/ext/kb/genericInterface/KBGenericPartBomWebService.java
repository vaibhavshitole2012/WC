package ext.kb.genericInterface;
import java.util.ArrayList;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

import org.apache.log4j.Logger;

import com.ptc.jws.servlet.JaxWsWebService;

import ext.kb.genericInterface.partBom.BomObject;
import ext.kb.genericInterface.partBom.GenericInterfaceforPartBom;
import wt.log4j.LogR;

@WebService()
public class KBGenericPartBomWebService extends JaxWsWebService {

	private static final Logger LOGGER = LogR.getLogger(KBGenericPartBomWebService.class.getName());

	@WebMethod(operationName = "createPartBOM")
	public ArrayList<BomObject> createPartBOM(@WebParam(name = "bomObject") ArrayList<BomObject> bom) {
		ArrayList<BomObject> response = GenericInterfaceforPartBom.performOperationon(bom);
		return response;
	}
}
