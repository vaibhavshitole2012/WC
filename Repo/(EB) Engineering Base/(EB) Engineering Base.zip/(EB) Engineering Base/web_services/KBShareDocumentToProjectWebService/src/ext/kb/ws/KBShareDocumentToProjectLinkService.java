package ext.kb.ws;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;
import java.util.Set;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

import org.apache.log4j.Logger;

import com.ptc.jws.servlet.JaxWsWebService;

import ext.kb.project.ProjectHelper;
import ext.kb.service.WebServiceHelper;
import ext.kb.util.KBConstants;
import ext.kb.util.KBUtils;
import ext.kb.util.ObjectRevisionHelper;
import ext.kb.ws.SharedDocumentObject;
import wt.enterprise.RevisionControlled;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.folder.Folder;
import wt.inf.container.WTContainer;
import wt.inf.sharing.DataSharingHelper;
import wt.inf.sharing.SharedContainerMap;
import wt.log4j.LogR;
import wt.org.WTPrincipal;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.pds.StatementSpec;
import wt.preference.PreferenceHelper;
import wt.projmgmt.admin.Project2;
import wt.projmgmt.admin.Project2Reference;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.vc.VersionControlHelper;
import wt.vc.Versioned;
import wt.vc.views.ViewManageable;

@WebService()
public class KBShareDocumentToProjectLinkService extends JaxWsWebService {
	private static final Logger LOGGER = LogR.getLogger(KBShareDocumentToProjectLinkService.class.getName());
	private static boolean isDebugEnabled = false;
	private static PrintWriter logPw = null;
	private static ArrayList<SharedDocumentObject> outPutArr = null;
	private static final  String SHARED_OBJECT_NUMBER = "Shared Object number: ";
	private static final  String SHARED_OBJECT_TYPE = "Shared Object Type: ";
	private static final  String SHARED_OBJECT_VERSION = "Shared Object Version: ";
	private static final String DOCUMENT_WITH_NUMBER = "Document with number: ";
	private static final String NOT_FOUND = " Not found.";
	private static final  String AUTOMATIC_PRODUCTION_SHARING_BLACKLIST = "KB_Automatic_Production_Sharing_Blacklist";

	@WebMethod(operationName = "shareDocumentToProject")
	public ArrayList<SharedDocumentObject> shareDocumentToProject(@WebParam(name = "projectName") String projectName,
			@WebParam(name = "sharedDocs") ArrayList<SharedDocumentObject> sharedDocs) throws WTException, IOException

	{
		isDebugEnabled = LOGGER.isDebugEnabled();
		String wtHome = WebServiceHelper.getWindchillHome();
		String logFileName = wtHome + "/logs/interface";
		WebServiceHelper.createDirIfNotExisting(logFileName);
		logFileName = wtHome + "/logs/interface/Cadim2WctShareDocumentToProjectLink.log";

		FileWriter fw = null;
		BufferedWriter bw = null;
		File file = new File(logFileName);
		file.setExecutable(true, false);
		file.setReadable(true, false);
		file.setWritable(true, false);
		fw = new FileWriter(logFileName, true);
		bw = new BufferedWriter(fw);
		logPw = new PrintWriter(bw);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		String formatedDate = sdf.format(date);
		outPutArr = new ArrayList<>();
		logPw.println(" Processing create Share Document to project on " + formatedDate + " request project name is "
				+ projectName);

		String productBlackList = (String) PreferenceHelper.service
				.getValue(AUTOMATIC_PRODUCTION_SHARING_BLACKLIST, KBConstants.WINDCHILL);

		logPw.println("ProductBlacklist ===" + productBlackList);
		List<String> automaticProductBlackList = Arrays
				.asList(productBlackList.split(KBConstants.COMMA_DELIMITER));
		logPw.println("AutomaticProductBlacklist" + automaticProductBlackList);
		if (isDebugEnabled) {
			LOGGER.debug("plantNumber" + projectName);
			LOGGER.debug("After getting log file ===" + file);
			LOGGER.debug("WT_HOME : " + wtHome);
			LOGGER.debug("ProductBlacklist ===" + productBlackList);
			LOGGER.debug("AutomaticProductBlacklist" + automaticProductBlackList);
		}
		logPw.println("plantNumber" + projectName);
		if (!automaticProductBlackList.contains(projectName)) {

			shareObjectsToProject(sharedDocs, projectName); // share the Objects to projects

		} else {
			SharedDocumentObject errorSDO = new SharedDocumentObject();
			for (int i = 0; i < sharedDocs.size(); i++) {

				SharedDocumentObject cdo = sharedDocs.get(i);
				if (isDebugEnabled) {
					LOGGER.debug(SHARED_OBJECT_NUMBER + cdo.getObjectNumber());
					LOGGER.debug(SHARED_OBJECT_TYPE + cdo.getObjectType());
					LOGGER.debug(SHARED_OBJECT_VERSION + cdo.getObjectVersion());
				}
				logPw.println(SHARED_OBJECT_NUMBER + cdo.getObjectNumber());
				logPw.println(SHARED_OBJECT_TYPE + cdo.getObjectType());
				logPw.println(SHARED_OBJECT_VERSION + cdo.getObjectVersion());
				errorSDO.setObjectNumber(cdo.getObjectNumber());
				errorSDO.setObjectVersion(cdo.getObjectVersion());
				errorSDO.setObjectType(cdo.getObjectType());
				errorSDO.setMessage(
						"The Plant Number exists in Automatic Production Sharing Blacklist. Objects will not be shared Automatically. Please contact Administrator");
				outPutArr.add(errorSDO);
			}
		}
		logPw.flush();
		logPw.close();
		return outPutArr;
	}

	/**
	 * @param sharedDocs
	 * @param projectName
	 */
	private void shareObjectsToProject(ArrayList<SharedDocumentObject> sharedDocs, String projectName) {

		for (int i = 0; i < sharedDocs.size(); i++) {
			SharedDocumentObject cdo = sharedDocs.get(i);
			if (isDebugEnabled) {
				LOGGER.debug(SHARED_OBJECT_NUMBER + cdo.getObjectNumber());
				LOGGER.debug(SHARED_OBJECT_TYPE + cdo.getObjectType());
				LOGGER.debug(SHARED_OBJECT_VERSION + cdo.getObjectVersion());
			}
			logPw.println(SHARED_OBJECT_NUMBER + cdo.getObjectNumber());
			logPw.println(SHARED_OBJECT_TYPE + cdo.getObjectType());
			logPw.println(SHARED_OBJECT_VERSION + cdo.getObjectVersion());
			try {

				if (cdo.getObjectType().equalsIgnoreCase("WTPart")) {

					QueryResult sharedObjQR = searchForPart(cdo);

					if (sharedObjQR.size() > 0) {

						collectAndShareObjects(sharedObjQR, projectName);

					} else {

						logPw.println(DOCUMENT_WITH_NUMBER + cdo.getObjectNumber() + NOT_FOUND);
						throw new WTException(DOCUMENT_WITH_NUMBER + cdo.getObjectNumber() + NOT_FOUND);

					}
				}
			} catch ( WTException e) {
				SharedDocumentObject errorSDO = new SharedDocumentObject();
				errorSDO.setObjectNumber(cdo.getObjectNumber());
				errorSDO.setObjectType(cdo.getObjectType());
				errorSDO.setObjectVersion(cdo.getObjectVersion());
				errorSDO.setMessage(e.getMessage());
				LOGGER.debug(DOCUMENT_WITH_NUMBER + cdo.getObjectNumber() + " has exception error message "
						+ e.getMessage());
				logPw.println(DOCUMENT_WITH_NUMBER + cdo.getObjectNumber() + " has exception error message "
						+ e.getMessage());
				outPutArr.add(errorSDO);
			}

		}

	}

	/**
	 * @param cdo
	 * @return QueryResult containing part with the cdo info.
	 * @throws WTException
	 */
	private QueryResult searchForPart(SharedDocumentObject cdo) throws WTException {

		QuerySpec sharedObjQS = new QuerySpec();
		int sharedObjIndex = sharedObjQS.appendClassList(WTPart.class, true);
		int sharedObjMasterIndex = sharedObjQS.appendClassList(WTPartMaster.class, false);
		sharedObjQS.appendWhere(new SearchCondition(WTPart.class, "masterReference.key.id", WTPartMaster.class,
				"thePersistInfo.theObjectIdentifier.id"), new int[] { sharedObjIndex, sharedObjMasterIndex });

		sharedObjQS.appendAnd();
		sharedObjQS.appendWhere(
				new SearchCondition(WTPartMaster.class, "number", SearchCondition.EQUAL, cdo.getObjectNumber()),
				new int[] { sharedObjMasterIndex });

		QueryResult sharedObjQR = PersistenceHelper.manager.find((StatementSpec) sharedObjQS);
		int sharedObjSize = sharedObjQR.size();
		if (isDebugEnabled) {
			LOGGER.debug("sharedDocQR -> " + sharedObjQS);
			LOGGER.debug("sharedDocQR.size(): " + sharedObjSize);
		}
		logPw.println("sharedDocQR.size(): " + sharedObjSize);
		return sharedObjQR;
	}

	/**
	 * @param sharedObjQR
	 * @param projectName
	 * @throws WTException
	 */
	private void collectAndShareObjects(QueryResult sharedObjQR, String projectName) throws WTException {
		Persistable[] sharedDocObj = (Persistable[]) sharedObjQR.nextElement();

		logPw.println("resObj: " + sharedDocObj[0]);
		Persistable sharedObj = sharedDocObj[0];
		Persistable latestSharedObjVer = getLatestSharedObjVer(sharedObj);

		if (latestSharedObjVer != null && KBUtils.isInKB((WTPart) latestSharedObjVer)) {

			Project2Reference projectRef = new Project2Reference();
			logPw.println("projectRef: " + projectRef);
			projectName = "Plant - " + projectName;
			logPw.println("projectName" + projectName);
			Project2 project = (Project2) getProjectContainer(projectName);
			logPw.println("prj: " + project);
			projectRef.setObject(project);
			logPw.println("After setting to prj ref:  ");
			Folder folder = project.getDefaultCabinet();
			logPw.println("fodler: " + folder);

			if (isDebugEnabled) {
				LOGGER.debug("resObj: " + sharedDocObj[0]);
				LOGGER.debug("projectRef: " + projectRef);
				LOGGER.debug("projectName" + projectName);
				LOGGER.debug("prj: " + project);
				LOGGER.debug("After setting to prj ref: ");
				LOGGER.debug("folder: " + folder);
			}

			if (latestSharedObjVer instanceof WTPart) {
				WTPart part = (WTPart) latestSharedObjVer;
				// collects parts to share
				List<Persistable> revisionsToShare = lastThreeRevisionsWithStateEqGtThan1030(part);
				if (revisionsToShare.isEmpty()) {
					revisionsToShare.add(part);
				}

				WTPrincipal currentUser = SessionHelper.manager.getPrincipal();
				SessionHelper.manager.setAdministrator();

				try {

					// collect related documents to share
					List<Persistable> docRevisionsToShare = KBUtils.getRelatedWTDocsToShare(part, true);
					revisionsToShare.addAll(docRevisionsToShare);

					// collect document variants to share
					revisionsToShare.addAll(KBUtils.getVariantsToShare(docRevisionsToShare));

					Set<Persistable> toShareSet = ProjectHelper.filterAlreadyShared(revisionsToShare, project);
					// share everything at one place
					shareCollectedObjectsToProject(toShareSet, projectRef, folder);

					if (isDebugEnabled) {
						LOGGER.debug("Number of parts to be shared: "
								+ (revisionsToShare.size() - docRevisionsToShare.size()));
						LOGGER.debug("Number of Documents to be shared: " + docRevisionsToShare.size());
					}

				} finally {
					SessionHelper.manager.setPrincipal(currentUser.getName());
				}
			}
		} else if (isDebugEnabled) {
			LOGGER.debug("No Design view object found " + sharedObj);

		}

	}

	/**
	 * @param revisionsToShare
	 * @param projectRef
	 * @param folder
	 * @throws WTException
	 */
	private void shareCollectedObjectsToProject(Set<Persistable> revisionsToShare, Project2Reference projectRef,
			Folder folder) throws WTException {
		for ( Persistable toShare : revisionsToShare) {
			if (!DataSharingHelper.service.isSharedTo(toShare, projectRef)) {
				SharedContainerMap localSharedContainerMap = DataSharingHelper.service.shareVersion(toShare,
						projectRef, folder);
				if (isDebugEnabled) {
					LOGGER.debug("localSharedContainerMap: " + localSharedContainerMap);
					LOGGER.debug("Sharing the object: " + toShare);
				}
				logPw.println("Sharing the object: " + toShare);
				logPw.println("localSharedContainerMap: " + localSharedContainerMap);
			}
		}
	}

	/**
	 * @param sharedObj
	 * @return Latest released shared object version
	 * @throws WTException
	 */
	private Persistable getLatestSharedObjVer(Persistable sharedObj) throws WTException {
		WTPart latestPartRevision = (WTPart) ObjectRevisionHelper.getLatestVersionByPersistable(sharedObj);
		Persistable latestReleasedSharedObjVer = null;
		QueryResult result = VersionControlHelper.service.allIterationsOf(latestPartRevision.getMaster(), false);

		while (result.hasMoreElements()) {
			WTPart part = (WTPart) result.nextElement();
			if (KBUtils.isDesignView(part)) {
				latestReleasedSharedObjVer = part;
				break;
			}
		}

		if (isDebugEnabled && latestReleasedSharedObjVer != null) {
			LOGGER.debug("latestReleasedSharedObjVer version is "
					+ ((WTPart) latestReleasedSharedObjVer).getVersionIdentifier().getValue() + " Iteration is "
					+ ((WTPart) latestReleasedSharedObjVer).getIterationIdentifier().getValue());
		}
		if (latestReleasedSharedObjVer != null) {
			logPw.println("latestReleasedSharedObjVer version is "
					+ ((WTPart) latestReleasedSharedObjVer).getVersionIdentifier().getValue() + " Iteration is "
					+ ((WTPart) latestReleasedSharedObjVer).getIterationIdentifier().getValue());
		}
		return latestReleasedSharedObjVer;
	}

	/**
	 * @param latestReleasedSharedObjVer
	 * @return Last three released revisions of the part
	 * @throws WTException
	 */
	private List<Persistable> lastThreeRevisionsWithStateEqGtThan1030(Persistable latestReleasedSharedObjVer)
			throws WTException {
		List<Persistable> lastThreeRevisionsWithStateEqGtThan1030 = new ArrayList<>();
		QueryResult allVersionsOf = VersionControlHelper.service.allVersionsOf((Versioned) latestReleasedSharedObjVer);
		LOGGER.debug("All versions size is : " + allVersionsOf.size());
		while (allVersionsOf.hasMoreElements()) {
			Persistable p = (Persistable) allVersionsOf.nextElement();
			if(p!=null && p instanceof WTPart){
				// retrieving Design view part
				//p=WebServiceHelper.getDesignViewPart((WTPart)p);
				if (LOGGER.isDebugEnabled()) {
					LOGGER.debug("Object details : " + KBUtils.getIdentityWithStateAndRevision((RevisionControlled) p));
				}
				int state = Integer.parseInt(KBUtils.getKBStateNumericValueString((RevisionControlled) p));
				if (state >= 1030 && KBUtils.isEbomPart((WTPart) p) && !lastThreeRevisionsWithStateEqGtThan1030.contains(p)) {
					lastThreeRevisionsWithStateEqGtThan1030.add(p);
				}
				if (lastThreeRevisionsWithStateEqGtThan1030.size() == 3) {
					break;
				}
			}
		}

		if (isDebugEnabled) {
			LOGGER.debug("Number of revisions found: " + lastThreeRevisionsWithStateEqGtThan1030.size());
		}
		logPw.println("Number of revisions found: " + lastThreeRevisionsWithStateEqGtThan1030.size());

		return lastThreeRevisionsWithStateEqGtThan1030;
	}

	/**
	 * @param projName
	 * @return Container object with the projName as name.
	 * @throws WTException
	 */
	private static WTContainer getProjectContainer(String projName) throws WTException {

		WTContainer cont = null;

		try {

			int[] fromIndicies = { 0, -1 };

			QuerySpec querySpec = new QuerySpec(Project2.class);

			querySpec.appendWhere(new SearchCondition(Project2.class,

					Project2.NAME, SearchCondition.EQUAL, projName),

					fromIndicies);

			Enumeration contEnum = PersistenceHelper.manager

					.find((StatementSpec) querySpec);

			if (contEnum.hasMoreElements()) {

				cont = (WTContainer) contEnum.nextElement();
				if (isDebugEnabled) {
					LOGGER.debug("project found with name " + projName);
				}
				logPw.println("project found with name " + projName);

			}
			if (cont == null) {
				throw new WTException("Project does not exist ");
			}

		} catch ( WTException e) {
			throw new WTException("Exception while searching for project error message is " + e.getMessage());
		}

		return cont;

	}
}