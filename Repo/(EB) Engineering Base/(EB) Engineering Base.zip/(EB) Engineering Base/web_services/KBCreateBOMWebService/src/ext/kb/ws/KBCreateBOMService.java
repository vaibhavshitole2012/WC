package ext.kb.ws;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.rmi.RemoteException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.xml.bind.JAXBException;

import org.apache.log4j.Logger;

import wt.doc.WTDocumentMaster;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.iba.definition.StringDefinition;
import wt.iba.value.StringValue;
import wt.log4j.LogR;
import wt.part.LineNumber;
import wt.part.Quantity;
import wt.part.QuantityUnit;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.part.WTPartUsageLink;
import wt.part._WTPartUsageLink;
import wt.pds.StatementSpec;
import wt.pom.Transaction;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.vc.VersionControlHelper;

import com.ptc.jws.servlet.JaxWsWebService;

import ext.kb.service.WebServiceHelper;
import ext.kb.util.DBUtils;
import ext.kb.util.IBAHelper;
import ext.kb.util.ObjectRevisionHelper;


@WebService()
public class KBCreateBOMService extends JaxWsWebService
{
	private static final Logger LOGGER = LogR.getLogger(KBCreateBOMService.class.getName());
	@WebMethod(operationName="createBOM")
    public List<String> createBOM (@WebParam(name="parentID") String parentID,@WebParam(name="parent_CID") String parent_CID, @WebParam(name="childIDs") String childID[][]) throws WTException,WTPropertyVetoException, JAXBException, IOException
    
    {

    	Transaction trx = null;
    	List<String> result = new ArrayList<String>();
    	String wtHome = WebServiceHelper.getWindchillHome();
		LOGGER.debug("WT_HOME : "+wtHome);
		String LOG_FILE_NAME = wtHome+"/logs/interface";
		WebServiceHelper.createDirIfNotExisting(LOG_FILE_NAME);
		LOG_FILE_NAME = wtHome+"/logs/interface/Cadim2WctCreateBOM.log";
    	//String LOG_FILE_NAME = "/opt/ptc/wt111/Cadim2WctCreateBOM.log";
	    PrintWriter logPw = null;
	    FileWriter fw = null;
	    BufferedWriter bw = null;
        
        try {
            
        trx = new Transaction();
        trx.start();
        File file = new File(LOG_FILE_NAME);
		file.setExecutable(true, false);
        file.setReadable(true, false);
        file.setWritable(true, false);
        LOGGER.debug("After getting log file ==="+file);
        fw = new FileWriter(LOG_FILE_NAME,true);
        bw = new BufferedWriter(fw);
        logPw = new PrintWriter(bw);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date date = new Date();
        String formatedDate = sdf.format(date);
        
        logPw.println(" Processing create BOM on "+formatedDate+" request parent number is "+parentID+" parent_CID is "+parent_CID);

    	QuerySpec resQS = WebServiceHelper.findPartByNumberAndCadim(parentID,parent_CID);
		QueryResult resQR = PersistenceHelper.manager.find((StatementSpec) resQS);
    	int size = resQR.size();
    	 if(size > 0)
		 {
		 Persistable resObj [] = (Persistable [])resQR.nextElement();
		 LOGGER.debug("resObj: " + resObj);

		 LOGGER.debug("resObj: " + resObj[0]);
		 WTPart resPart = (WTPart)resObj[0];
		 LOGGER.debug("resPart: " + resPart);
		 WTPart latestPartRevision = (WTPart)ObjectRevisionHelper.getLatestVersionByPersistable(resPart);
		 WTPart latestPartIteration = (WTPart)VersionControlHelper.getLatestIteration(latestPartRevision);
		//retrieving design view part
		 latestPartIteration = (WTPart)WebServiceHelper.getDesignViewPart((WTPart)latestPartIteration);
			if(latestPartIteration == null)
				throw new WTException("Design view Part with number "+latestPartRevision.getNumber()+" not found");
	 

		ArrayList<WTPartUsageLink> usageLinksList = (ArrayList<WTPartUsageLink>) DBUtils.retrieveLinks(WTPartUsageLink.class, latestPartIteration, WTPartUsageLink.ROLE_BOBJECT_ROLE);
		LOGGER.debug("usageLinksList size " + usageLinksList.size());
		logPw.println("usageLinksList size " + usageLinksList.size());
		for (WTPartUsageLink wtPartUsageLink : usageLinksList) {
			LOGGER.debug("B4 deleting usageLinksList " );
			PersistenceServerHelper.manager.remove(wtPartUsageLink);
			LOGGER.debug("After deleting wtPartUsageLink ");
			logPw.println("After deleting wtPartUsageLink ");
		}
			ArrayList<WTPartUsageLink> usageLinksList1 = (ArrayList<WTPartUsageLink>) DBUtils.retrieveLinks(WTPartUsageLink.class, latestPartIteration, WTPartUsageLink.ROLE_BOBJECT_ROLE);
			LOGGER.debug("usageLinksList1 size " + usageLinksList1.size());
			WTPartMaster parentMaster = (WTPartMaster) latestPartIteration.getMaster();
			LOGGER.debug("parent number: " + latestPartIteration.getNumber());
			LOGGER.debug("childID.size(): " + childID.length);
			logPw.println("childID.size(): " + childID.length);
		for(int i=0;i<childID.length;i++)
		{
			
			LOGGER.debug("childID.get(i).size() - 1" + (childID[i].length - 1));
			LOGGER.debug("childID.get(i)" + childID[i]);
			QuerySpec qschild = new QuerySpec(WTPart.class);
			String childNumber = childID[i][0];
			LOGGER.debug("childNumber" + childNumber);
			qschild.appendWhere(new SearchCondition(WTPart.class, WTPart.NUMBER, SearchCondition.EQUAL, childID[i][0], false));
			QueryResult qrchild = PersistenceHelper.manager.find((StatementSpec) qschild);
			LOGGER.debug("qrchild.size(): " + qrchild.size());
			if(qrchild.size()>0)
			{
				WTPart childPart =  (WTPart)qrchild.nextElement();
				LOGGER.debug("childPart number " + childPart.getNumber());
				logPw.println("childPart number " + childPart.getNumber());
				//retrieving design view part
				childPart = (WTPart)WebServiceHelper.getDesignViewPart((WTPart)childPart);
					if(childPart == null)
						throw new WTException("Design view Part with number "+childNumber+" not found");
				WTPartMaster childMaster = (WTPartMaster) childPart.getMaster();
				WTPartUsageLink newWTPartUsageLink = WTPartUsageLink.newWTPartUsageLink(latestPartIteration, childMaster);
				LOGGER.debug("newWTPartUsageLink " + newWTPartUsageLink);
				LOGGER.debug("(childID.get(i).size() - 1) " + (childID[i].length - 1));
		 
				LOGGER.debug("find number  " + childID[i][1]); 
				logPw.println("find number  " + childID[i][1]);
				newWTPartUsageLink.setFindNumber(childID[i][1]);
				LOGGER.debug("Line number  " + childID[i][2]); 
				logPw.println("Line number  " + childID[i][2]);
				long newLineNumber = Long.parseLong(childID[i][2]);
				LineNumber lineNumber = LineNumber.newLineNumber(newLineNumber);
				newWTPartUsageLink.setLineNumber(lineNumber);
				LOGGER.debug("Quantity Amount  " + childID[i][3]); 
				logPw.println("Quantity Amount  " + childID[i][3]);
				if(!childID[i][3].equals(""))
				{
				Double amount = Double.parseDouble(childID[i][3]);
				//LOGGER.debug("Quantity Unit " + childID[i][4]); 
				//logPw.println("Quantity Unit  " + childID[i][4]);
				QuantityUnit unit = QuantityUnit.toQuantityUnit("g");
				Quantity linkQuantity = Quantity.newQuantity(amount,unit);
				newWTPartUsageLink.setQuantity(linkQuantity);
				}
				PersistenceServerHelper.manager.insert(newWTPartUsageLink);	
				LOGGER.debug("KB_FREE_TEXT " + childID[i][4]); 
				logPw.println("KB_FREE_TEXT  " + childID[i][4]);
				newWTPartUsageLink = (WTPartUsageLink)IBAHelper.setIba(newWTPartUsageLink, "KB_FREE_TEXT", childID[i][4]);
				LOGGER.debug("KB_DELIVERY_FLAG " + childID[i][5]); 
				logPw.println("KB_DELIVERY_FLAG " + childID[i][5]);
				newWTPartUsageLink = (WTPartUsageLink)IBAHelper.setIba(newWTPartUsageLink, "KB_DELIVERY_FLAG", childID[i][5]);
				LOGGER.debug("KB_REMARK_COL1 " + childID[i][6]); 
				logPw.println("KB_REMARK_COL1  " + childID[i][6]);
				newWTPartUsageLink = (WTPartUsageLink)IBAHelper.setIba(newWTPartUsageLink, "KB_REMARK_COL1", childID[i][6]);
				LOGGER.debug("KB_REMARK_COL2 " + childID[i][7]); 
				logPw.println("KB_REMARK_COL2  " + childID[i][7]);
				newWTPartUsageLink = (WTPartUsageLink)IBAHelper.setIba(newWTPartUsageLink, "KB_REMARK_COL2", childID[i][7]);
				LOGGER.debug("KB_REMARK_COL3 " + childID[i][8]); 
				logPw.println("KB_REMARK_COL3  " + childID[i][8]);
				newWTPartUsageLink = (WTPartUsageLink)IBAHelper.setIba(newWTPartUsageLink, "KB_REMARK_COL3", childID[i][8]);
				LOGGER.debug("KB_REMARK_COL4 " + childID[i][9]); 
				logPw.println("KB_REMARK_COL4 " + childID[i][9]);
				newWTPartUsageLink = (WTPartUsageLink)IBAHelper.setIba(newWTPartUsageLink, "KB_REMARK_COL4", childID[i][9]);
				LOGGER.debug("KB_REPAIR_FLAG " + childID[i][10]); 
				logPw.println("KB_REPAIR_FLAG  " + childID[i][10]);
				newWTPartUsageLink = (WTPartUsageLink)IBAHelper.setIba(newWTPartUsageLink, "KB_REPAIR_FLAG", childID[i][10]);
				LOGGER.debug("KB_OBSERVATIONS " + childID[i][11]); 
				logPw.println("KB_OBSERVATIONS  " + childID[i][11]);
				newWTPartUsageLink = (WTPartUsageLink)IBAHelper.setIba(newWTPartUsageLink, "KB_OBSERVATIONS", childID[i][11]);
				PersistenceServerHelper.manager.update(newWTPartUsageLink);
				LOGGER.debug("After link Attributes "); 
				logPw.println("After setting link Attributes ");
	     					
			}	
			else{
	    		 throw new WTException("Child Part with number "+childID[i][0]+" not found");
	    	 }
			
		}

		trx.commit();
        trx = null;    
        result.add("0");
        result.add("Success");
        LOGGER.info(result);
        logPw.println("Result of the resquest is "+result);
		return result;
		 }
    	 else{
    		 throw new WTException("Parent Part Not found");
    	 }
        }
        catch (WTException e) {
            String message = "WTException during BOM Creation exception is "+e ;
            result.add("1");
            result.add(message);
            LOGGER.info(result);
            logPw.println("Result of the resquest is "+result);
			return result;
            
        } catch (WTPropertyVetoException e) {
     	   String message = "WTException during BOM Creation exception is "+e ;
     	  result.add("1");
          result.add(message);
          LOGGER.info(result);
          logPw.println("Result of the resquest is "+result);
		  return result;
        } 
        finally {
        	LOGGER.debug("trx in finally==="+trx );
            if (trx != null) {
                trx.rollback();
            }
            logPw.flush();
            logPw.close();
        }
    }
    
}