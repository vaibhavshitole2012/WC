package ext.kb.ws;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.xml.bind.JAXBException;

import org.apache.log4j.Logger;

import wt.configurablelink.ConfigurableLinkHelper;
import wt.configurablelink.ConfigurableRevisionLink;
import wt.doc.WTDocument;
import wt.doc.WTDocumentMaster;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.fc.collections.WTHashSet;
import wt.folder.FolderHelper;
import wt.folder.SubFolder;
import wt.inf.container.WTContainerRef;
import wt.log4j.LogR;
import wt.pds.StatementSpec;
import wt.pom.Transaction;
import wt.query.QuerySpec;
import wt.type.TypeDefinitionReference;
import wt.type.TypedUtilityServiceHelper;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.vc.VersionControlHelper;

import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.TypeIdentifierHelper;
import com.ptc.jws.servlet.JaxWsWebService;

import ext.kb.service.WebServiceHelper;
import ext.kb.util.IBAHelper;
import ext.kb.util.ObjectRevisionHelper;
import ext.kb.ws.MoveArticlePosition;


@WebService()
public class KBMoveDocumentService extends JaxWsWebService
{
	private static final Logger LOGGER = LogR.getLogger(KBMoveArticleService.class.getName());
	@WebMethod(operationName="moveDocumentOwnership")
    public String moveDocumentOwnership (@WebParam(name="docIDs") ArrayList<MoveArticlePosition> docIDs) throws WTException,WTPropertyVetoException, JAXBException, IOException
    
    {

    	Transaction trx = null;
    	String result = "";
    	String wtHome = WebServiceHelper.getWindchillHome();
		LOGGER.debug("WT_HOME : "+wtHome);
		String LOG_FILE_NAME = wtHome+"/logs/interface";
		WebServiceHelper.createDirIfNotExisting(LOG_FILE_NAME);
		LOG_FILE_NAME = wtHome+"/logs/interface/Cadim2WctMoveDocumentOwnership.log";
    	//String LOG_FILE_NAME = "/opt/ptc/wt111/Cadim2WctMoveDocumentOwnership.log";
	    PrintWriter logPw = null;
	    FileWriter fw = null;
	    BufferedWriter bw = null;
	    Iterator doc = docIDs.iterator();        
	    File file = new File(LOG_FILE_NAME);
		file.setExecutable(true, false);
        file.setReadable(true, false);
        file.setWritable(true, false);
        LOGGER.debug("After getting log file ==="+file);
        fw = new FileWriter(LOG_FILE_NAME,true);
        bw = new BufferedWriter(fw);
        logPw = new PrintWriter(bw);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        String MASTER_SYSTEM_IBA = "KB_MASTERSYSTEM";
        Date date = new Date();
        String formatedDate = sdf.format(date);
        
	    for(int i=0;i<docIDs.size();i++)
        { 
	    
	    MoveArticlePosition pos = (MoveArticlePosition) doc.next();
	    try {
            
        logPw.println(" Processing move article ownership service on "+formatedDate+" request parent number is "+pos.getNumber()+" parent_CID is "+pos.getCID());

        QuerySpec resQS = WebServiceHelper.findDocumentByNumberAndCadim(pos.getNumber(),pos.getCID());
		QueryResult resQR = PersistenceHelper.manager.find((StatementSpec) resQS);
    	int size = resQR.size();
    	 if(size > 0)
		 {
		 Persistable resObj [] = (Persistable [])resQR.nextElement();
		 LOGGER.debug("resObj: " + resObj);

		 LOGGER.debug("resObj: " + resObj[0]);
		 WTDocument resDoc = (WTDocument)resObj[0];
		 LOGGER.debug("resDoc: " + resDoc);
		 WTDocument latestDocRevision = (WTDocument)ObjectRevisionHelper.getLatestVersionByPersistable(resDoc);
		 WTDocument latestDocIteration = (WTDocument)VersionControlHelper.getLatestIteration(latestDocRevision);	
		 WTDocumentMaster master = (WTDocumentMaster) latestDocIteration.getMaster();
		 master = (WTDocumentMaster)IBAHelper.setIba(master, MASTER_SYSTEM_IBA, "WCT");
		 PersistenceServerHelper.manager.update(master);			
		 LOGGER.debug("After setting master system");
		 String articleLocation = latestDocIteration.getLocation();
		 WTContainerRef contRef = latestDocIteration.getContainerReference();
		 String containerName = latestDocIteration.getContainerName();
         String presentFolder = latestDocIteration.getFolderPath();
         String [] folderPath = presentFolder.split("/");
         LOGGER.debug( " presentFolder" + presentFolder);
         logPw.println( " presentFolder " + presentFolder);
         String targetFolder = "/"+folderPath[1]+"/"+folderPath[2]+"/Data";
         LOGGER.debug( " targetFolder" + targetFolder);
         logPw.println( " targetFolder " + targetFolder);
         WebServiceHelper.moveDocToContainer(contRef.getContainer(), targetFolder, latestDocIteration);
         LOGGER.debug(" Moved " + latestDocIteration.getNumber()+" to folder "+ targetFolder);
         logPw.println(" Moved " + latestDocIteration.getNumber()+" to folder "+ targetFolder);
         
		 TypeIdentifier typeIdentifier = TypeIdentifierHelper.getTypeIdentifier("com.ptc.KBVariantLink");
		 TypeDefinitionReference typeDefinitionReference = TypedUtilityServiceHelper.service.getTypeDefinitionReference(typeIdentifier.getTypename());
   		 QueryResult allVarLinks = PersistenceHelper.manager.navigate(latestDocIteration, ConfigurableRevisionLink.ROLE_BOBJECT_ROLE, ConfigurableRevisionLink.class, true);
		 LOGGER.debug("allLinks size "+allVarLinks.size());
         logPw.println("allLinks size "+allVarLinks.size());
		 WTHashSet varLinkSet = new WTHashSet();
         while(allVarLinks.hasMoreElements()){
         Object obj = allVarLinks.nextElement();
         logPw.println("Got: "+obj);
         LOGGER.debug("Got: "+obj);
         if(obj instanceof WTDocument){
        	 WTDocument variantDoc = (WTDocument)obj;
        	 LOGGER.debug("variant document number is  "+variantDoc.getNumber());
	         logPw.println("variant document number is  "+variantDoc.getNumber());
	         WTDocumentMaster variantDocMaster = (WTDocumentMaster) variantDoc.getMaster();
	         variantDocMaster = (WTDocumentMaster)IBAHelper.setIba(variantDocMaster, MASTER_SYSTEM_IBA, "WCT");
	         PersistenceServerHelper.manager.update(variantDocMaster);			
	   		 LOGGER.debug("After setting master system for variant doc");
	   		 String variantLocation = variantDoc.getLocation();
	   		 WTContainerRef varContRef = variantDoc.getContainerReference();
	   		 String varContainerName = variantDoc.getContainerName();
	         String varPresentFolder = variantDoc.getFolderPath();
	         String [] varFolderPath = varPresentFolder.split("/");
	         LOGGER.debug( " varFolderPath" + varFolderPath);
	         logPw.println( " varFolderPath " + varFolderPath);
	         String varTargetFolder = "/"+folderPath[1]+"/"+folderPath[2]+"/Data";
	         LOGGER.debug( " varTargetFolder" + varTargetFolder);
	         logPw.println( " varTargetFolder " + varTargetFolder);
	         WebServiceHelper.moveDocToContainer(varContRef.getContainer(), varTargetFolder, variantDoc);
	         LOGGER.debug(" Moved " + variantDoc.getNumber()+" to folder "+ varTargetFolder);
	         logPw.println(" Moved " + variantDoc.getNumber()+" to folder "+ varTargetFolder);
         	}
         }
         
		}
    	 else{
    		 logPw.println("  document number "+pos.getNumber()+" document CID is "+pos.getCID() +" not found ");
    		 result = result+pos.getCID()+";";
    	 }
		
        }
       
	    catch (Exception e) {
	     	   String message = "Exception during move doc exception is "+e ;

	     	  result = result+pos.getCID()+";";
	          LOGGER.debug(message);
	          logPw.println("message of the resquest is "+message);

	        } 
        }
	    logPw.flush();
        logPw.close();
	    return result;
    }
    
}