package ext.kb.ws;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import org.apache.log4j.Logger;
import wt.configurablelink.ConfigurableRevisionLink;
import wt.doc.WTDocument;
import wt.doc.WTDocumentMaster;
import wt.enterprise.RevisionControlled;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.folder.Folder;
import wt.inf.container.WTContainer;
import wt.inf.sharing.DataSharingHelper;
import wt.log4j.LogR;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.pds.StatementSpec;
import wt.projmgmt.admin.Project2;
import wt.projmgmt.admin.Project2Reference;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;
import wt.vc.VersionControlHelper;
import wt.vc.Versioned;

import com.ptc.jws.servlet.JaxWsWebService;

import ext.kb.service.WebServiceHelper;
import ext.kb.util.DBUtils;
import ext.kb.util.KBUtils;
import ext.kb.util.ObjectRevisionHelper;
import wt.util.WTPropertyVetoException;

@WebService()
public class KBUnShareDocumentToProjectLinkService extends JaxWsWebService
{
	private static final Logger LOGGER = LogR.getLogger(KBUnShareDocumentToProjectLinkService.class.getName());	
	@WebMethod(operationName="UnShareDocumentToProject")
	public ArrayList<SharedDocumentObject> shareDocumentToProject (@WebParam(name="projectName") String projectName, @WebParam(name="sharedDocs")
	ArrayList<SharedDocumentObject> sharedDocs) throws WTPropertyVetoException,WTException, IOException
    
	{
		String wtHome = WebServiceHelper.getWindchillHome();
		LOGGER.debug("WT_HOME : "+wtHome);
		String LOG_FILE_NAME = wtHome+"/logs/interface";
		WebServiceHelper.createDirIfNotExisting(LOG_FILE_NAME);
		LOG_FILE_NAME = wtHome+"/logs/interface/Cadim2WctUnShareDocumentToProjectLink.log";
    	//String LOG_FILE_NAME = "/opt/ptc/wt111/Cadim2WctUnShareDocumentToProjectLink.log";
	    PrintWriter logPw = null;
	    FileWriter fw = null;
	    BufferedWriter bw = null;
        File file = new File(LOG_FILE_NAME);
		file.setExecutable(true, false);
        file.setReadable(true, false);
        file.setWritable(true, false);
        LOGGER.debug("After getting log file ==="+file);
        fw = new FileWriter(LOG_FILE_NAME,true);
        bw = new BufferedWriter(fw);
        logPw = new PrintWriter(bw);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date date = new Date();
        String formatedDate = sdf.format(date);
        ArrayList<SharedDocumentObject> OutputArr = new ArrayList<SharedDocumentObject>();              
        logPw.println(" Processing create Share Document to project on "+formatedDate+" request project name is "+projectName);
        
        LOGGER.debug("plantNumber" + projectName);
		logPw.println("plantNumber" + projectName);
		
		for(int i=0;i<sharedDocs.size();i++)
		{
			SharedDocumentObject cdo = (SharedDocumentObject) sharedDocs.get(i);
			LOGGER.debug("Shared Object number" + cdo.getObjectNumber());
			LOGGER.debug("Shared Object Type" + cdo.getObjectType());
			LOGGER.debug("Shared Object Version" + cdo.getObjectVersion());
			logPw.println("Shared Object number" + cdo.getObjectNumber());
			logPw.println("Shared Object Type" + cdo.getObjectType());
			logPw.println("Shared Object Version" + cdo.getObjectVersion());
			try
			{
									
			QuerySpec sharedObjQS = new QuerySpec();
			if(cdo.getObjectType().equalsIgnoreCase("WTDocument"))
			{
			int sharedObjIndex = sharedObjQS.appendClassList(WTDocument.class, true);
			int sharedObjMasterIndex = sharedObjQS.appendClassList(WTDocumentMaster.class,false);
			sharedObjQS.appendWhere(new SearchCondition(WTDocument.class,
					"masterReference.key.id", WTDocumentMaster.class,
					"thePersistInfo.theObjectIdentifier.id"), new int[] {
				sharedObjIndex, sharedObjMasterIndex });
			
			sharedObjQS.appendAnd();
			sharedObjQS.appendWhere(new SearchCondition(WTDocumentMaster.class, "number",
					SearchCondition.EQUAL, cdo.getObjectNumber()),
					new int[] { sharedObjMasterIndex });
			}
			if(cdo.getObjectType().equalsIgnoreCase("WTPart"))
			{
			int sharedObjIndex = sharedObjQS.appendClassList(WTPart.class, true);
			int sharedObjMasterIndex = sharedObjQS.appendClassList(WTPartMaster.class,false);
			sharedObjQS.appendWhere(new SearchCondition(WTPart.class,
					"masterReference.key.id", WTPartMaster.class,
					"thePersistInfo.theObjectIdentifier.id"), new int[] {
				sharedObjIndex, sharedObjMasterIndex });
			
			sharedObjQS.appendAnd();
			sharedObjQS.appendWhere(new SearchCondition(WTPartMaster.class, "number",
					SearchCondition.EQUAL, cdo.getObjectNumber()),
					new int[] { sharedObjMasterIndex });
			}
			QueryResult sharedObjQR = PersistenceHelper.manager.find((StatementSpec) sharedObjQS);
	    	int sharedObjSize = sharedObjQR.size();
			LOGGER.debug("sharedDocQR.size(): " + sharedObjQR.size());
			logPw.println("sharedDocQR.size(): " + sharedObjQR.size());
			if(sharedObjQR.size()>0)
			{
				List<WTDocument> variantDocumentList = new ArrayList();
				Persistable sharedDocObj [] = (Persistable [])sharedObjQR.nextElement();
				LOGGER.debug("resObj: " + (Persistable)sharedDocObj[0]);
				logPw.println("resObj: " + (Persistable)sharedDocObj[0]);
				Persistable sharedObj = (Persistable)sharedDocObj[0];
				Persistable latestReleasedSharedObjVer = WebServiceHelper.getLatestReleasedObjectVersion(sharedObj);
				LOGGER.debug("latestReleasedSharedObjVer: " + latestReleasedSharedObjVer);
				logPw.println("latestReleasedSharedObjVer: " + latestReleasedSharedObjVer);
				
				if(cdo.getObjectType().equalsIgnoreCase("WTPart"))
				{
				
					if(latestReleasedSharedObjVer == null)
					{
						WTPart latestDocRevision = (WTPart)ObjectRevisionHelper.getLatestVersionByPersistable(sharedObj);
						latestReleasedSharedObjVer = (WTPart) VersionControlHelper.getLatestIteration(latestDocRevision);
					}
					LOGGER.debug("latestReleasedSharedObjVer version is " +((WTPart)latestReleasedSharedObjVer).getVersionIdentifier().getValue()+" Iteration is "+((WTPart)latestReleasedSharedObjVer).getIterationIdentifier().getValue());
					logPw.println("latestReleasedSharedObjVer version is " +((WTPart)latestReleasedSharedObjVer).getVersionIdentifier().getValue()+" Iteration is "+((WTPart)latestReleasedSharedObjVer).getIterationIdentifier().getValue());
				}
				if(cdo.getObjectType().equalsIgnoreCase("WTDocument"))
				{
				
					if(latestReleasedSharedObjVer == null)
					{
						WTDocument latestDocRevision = (WTDocument)ObjectRevisionHelper.getLatestVersionByPersistable(sharedObj);
						latestReleasedSharedObjVer = (WTDocument) VersionControlHelper.getLatestIteration(latestDocRevision);
					}
					LOGGER.debug("latestReleasedSharedObjVer version is " +((WTDocument)latestReleasedSharedObjVer).getVersionIdentifier().getValue()+" Iteration is "+((WTDocument)latestReleasedSharedObjVer).getIterationIdentifier().getValue());
					logPw.println("latestReleasedSharedObjVer version is " +((WTDocument)latestReleasedSharedObjVer).getVersionIdentifier().getValue()+" Iteration is "+((WTDocument)latestReleasedSharedObjVer).getIterationIdentifier().getValue());
					variantDocumentList = DBUtils.navigateBetweenObjects(WTDocument.class, ConfigurableRevisionLink.class, latestReleasedSharedObjVer, ConfigurableRevisionLink.ROLE_BOBJECT_ROLE);
					LOGGER.debug("No of variant documents is "+variantDocumentList.size());
					logPw.println("No of variant documents is "+variantDocumentList.size());
					LOGGER.debug("latestReleasedSharedObjVer version is " +((WTDocument)latestReleasedSharedObjVer).getVersionIdentifier().getValue()+" Iteration is "+((WTDocument)latestReleasedSharedObjVer).getIterationIdentifier().getValue());
					logPw.println("latestReleasedSharedObjVer version is " +((WTDocument)latestReleasedSharedObjVer).getVersionIdentifier().getValue()+" Iteration is "+((WTDocument)latestReleasedSharedObjVer).getIterationIdentifier().getValue());
				}
							
				Project2Reference projectRef = new Project2Reference();
				LOGGER.debug("projectRef: " + projectRef);
				logPw.println("projectRef: " + projectRef);
				projectName = "Plant - "+projectName;
				LOGGER.debug("projectName" + projectName);
				logPw.println("projectName" + projectName);
				Project2 prj = (Project2) getProjectContainer(projectName);
				LOGGER.debug("prj: " + prj);
				logPw.println("prj: " + prj);
				projectRef.setObject(prj);
				LOGGER.debug("After setting to prj ref: ");
				logPw.println("After setting to prj ref:  ");
				Folder f = prj.getDefaultCabinet();
				LOGGER.debug("folder: " +f);
				logPw.println("fodler: " +f);
				
				List<Persistable> revisionsToShare = lastThreeRevisionsWithStateEqGtThan1050(latestReleasedSharedObjVer);
				for (Persistable toUnshare : revisionsToShare) {
					boolean shared = DataSharingHelper.isShared(toUnshare);
					if(shared)
					{
					DataSharingHelper.service.removeShare(toUnshare, projectRef);
					LOGGER.debug("After unsharing document from project: ");
					logPw.println("After unsharing document from project:: ");
					}
					else
					{
						SharedDocumentObject errorSDO = new SharedDocumentObject();
						errorSDO.setObjectNumber(cdo.getObjectNumber());
						 errorSDO.setObjectType(cdo.getObjectType());
						 errorSDO.setObjectVersion(cdo.getObjectVersion());
						errorSDO.setMessage("The Object is not shared to project");
						 OutputArr.add(errorSDO);	
					}
				}
								
				if(cdo.getObjectType().equalsIgnoreCase("WTDocument"))
				{
				if (variantDocumentList.size() > 0) {
					LOGGER.debug("Variant Document exists going to unshare it also with project");
					logPw.println("Variant Document exists going to unshare it also with project");
					for (WTDocument variantDoc : variantDocumentList) {
						boolean varshared = DataSharingHelper.isShared(variantDoc);
						if(varshared)
						{
						DataSharingHelper.service.removeShare(variantDoc, projectRef);
						LOGGER.debug("After unsharing "+variantDoc.getNumber()+" and name "+ variantDoc.getName()+" and  version " +variantDoc.getVersionIdentifier().getValue()+" Iteration "+variantDoc.getIterationIdentifier().getValue()+" document from project ");
						logPw.println("After unsharing "+variantDoc.getNumber()+" and name "+ variantDoc.getName()+" and  version " +variantDoc.getVersionIdentifier().getValue()+" Iteration "+variantDoc.getIterationIdentifier().getValue()+" document from project ");
						}
						else
						{
						LOGGER.debug("variantDoc number "+variantDoc.getNumber()+" and name "+ variantDoc.getName()+" and  version " +variantDoc.getVersionIdentifier().getValue()+" Iteration "+variantDoc.getIterationIdentifier().getValue()+" is not shared to project");
						logPw.println("variantDoc number "+variantDoc.getNumber()+" and name "+ variantDoc.getName()+" and version " +variantDoc.getVersionIdentifier().getValue()+" Iteration "+variantDoc.getIterationIdentifier().getValue()+" is not shared to project");
						}
					}
				}
				}
									     					
			}	
			else{
	    		 
	    		 LOGGER.debug("Document with number"+ cdo.getObjectNumber() + " Not found");
				 logPw.println("Document with number"+ cdo.getObjectNumber() + " Not found");
				 throw new WTException("Document with number"+ cdo.getObjectNumber() + " Not found");
				
	    	 }
			}
			 catch (WTException e) {
				 SharedDocumentObject errorSDO = new SharedDocumentObject();
				 errorSDO.setObjectNumber(cdo.getObjectNumber());
				 errorSDO.setObjectType(cdo.getObjectType());
				 errorSDO.setObjectVersion(cdo.getObjectVersion());
				 errorSDO.setMessage(e.getMessage());
				 LOGGER.debug("Document with number"+ cdo.getObjectNumber() + " has exception error message "+e.getMessage());
				 logPw.println("Document with number"+ cdo.getObjectNumber() + " has exception error message "+e.getMessage());
				 OutputArr.add(errorSDO);		                 
		        } 
						
		}	
		
		logPw.flush();
        logPw.close();
        return OutputArr;
        }
       
	
	private List<Persistable> lastThreeRevisionsWithStateEqGtThan1050(Persistable latestReleasedSharedObjVer)
			throws WTPropertyVetoException,WTException {
		List<Persistable> lastThreeRevisionsWithStateEqGtThan1050 = new ArrayList<>();
		QueryResult allVersionsOf = VersionControlHelper.service.allVersionsOf((Versioned) latestReleasedSharedObjVer);
		while (allVersionsOf.hasMoreElements()) {
			Persistable p = (Persistable) allVersionsOf.nextElement();
			if(p!=null && p instanceof WTPart){
				//retrieving design view part
				p = WebServiceHelper.getDesignViewPart((WTPart)p);
			}
			int state = Integer.parseInt(KBUtils.getKBStateNumericValueString((RevisionControlled) p));
			if (state >= 1050 && !lastThreeRevisionsWithStateEqGtThan1050.contains(p)) {
				lastThreeRevisionsWithStateEqGtThan1050.add(p);
			}
			if (lastThreeRevisionsWithStateEqGtThan1050.size() == 3) {
				break;
			}
		}
		return lastThreeRevisionsWithStateEqGtThan1050;
	}
       	
	 private static WTContainer getProjectContainer(String projName) throws WTException {

			WTContainer cont = null;

			try{

				int[] fromIndicies = { 0, -1 };

		

				QuerySpec querySpec = new QuerySpec(Project2.class);

				querySpec.appendWhere(new SearchCondition(Project2.class,

						Project2.NAME, SearchCondition.EQUAL, projName),

						fromIndicies);

			

				Enumeration contEnum = PersistenceHelper.manager

						.find((StatementSpec) querySpec);

				if (contEnum.hasMoreElements()){

					cont = (WTContainer) contEnum.nextElement();
					LOGGER.debug("project found with name "+projName);

				}	
				if(cont == null){
					throw new WTException("Project does not exist ");
				}

			}catch(WTException e){

				e.printStackTrace();
				throw new WTException("Exception while searching for project error message is "+e.getMessage());
				}

			return cont;

		}
}