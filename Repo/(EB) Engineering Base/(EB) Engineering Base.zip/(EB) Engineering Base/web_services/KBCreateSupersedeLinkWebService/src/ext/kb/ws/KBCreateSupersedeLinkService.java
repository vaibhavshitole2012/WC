package ext.kb.ws;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.xml.bind.JAXBException;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import wt.doc.WTDocument;
import wt.doc.WTDocumentMaster;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.iba.value.IBAHolder;
import wt.log4j.LogR;
import wt.part.WTPart;
import wt.part.WTPartDescribeLink;
import wt.part.WTPartMaster;
import wt.part.WTPartReferenceLink;
import wt.pds.StatementSpec;
import wt.pom.Transaction;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.supersede.SupersedeGroup;
import wt.supersede.SupersedeLink;
import wt.type.TypedUtilityServiceHelper;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.vc.VersionControlHelper;

import com.ptc.jws.servlet.JaxWsWebService;

import ext.kb.service.WebServiceHelper;
import ext.kb.util.DBUtils;
import ext.kb.util.IBAHelper;
import ext.kb.util.ObjectRevisionHelper;

@WebService()
public class KBCreateSupersedeLinkService extends JaxWsWebService
{
private static final Logger LOGGER = LogR.getLogger(KBCreateSupersedeLinkService.class.getName());
	
	@WebMethod(operationName = "createSupersedeLink")
	public List<String> createSupersedeLink(
			@WebParam(name = "partID") String partID,
			@WebParam(name = "part_CID") String part_CID,
			@WebParam(name = "supersededBy") String supersededBy,
			@WebParam(name = "supersededBy_CID") String supersededBy_CID,
			@WebParam(name = "supersedes") String supersedes,
			@WebParam(name = "supersedes_CID") String supersedes_CID) throws WTException,
			WTPropertyVetoException, JAXBException, IOException

	{
		Transaction trx = null;
		List<String> result = new ArrayList<String>();
		String wtHome = WebServiceHelper.getWindchillHome();
		LOGGER.debug("WT_HOME : "+wtHome);
		String LOG_FILE_NAME = wtHome+"/logs/interface";
		WebServiceHelper.createDirIfNotExisting(LOG_FILE_NAME);
		LOG_FILE_NAME = wtHome+"/logs/interface/Cadim2WctCreateSupersedeLink.log";
		//String LOG_FILE_NAME = "/opt/ptc/wt111/Cadim2WctCreateSupersedeLink.log";
	    PrintWriter logPw = null;
	    FileWriter fw = null;
	    BufferedWriter bw = null;
		try {

			trx = new Transaction();
			trx.start();
			File file = new File(LOG_FILE_NAME);
			file.setExecutable(true, false);
	        file.setReadable(true, false);
	        file.setWritable(true, false);
	        LOGGER.debug("After getting log file ==="+file);
	        fw = new FileWriter(LOG_FILE_NAME,true);
	        bw = new BufferedWriter(fw);
	        logPw = new PrintWriter(bw);
	        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
            Date date = new Date();
            String formatedDate = sdf.format(date);
            String dummyPartNumber = "REF-INFO001";
            String supersedesPartNumber = "SUPERSEDES";
            String supersededByPartNumber = "SUPERSEDED.BY";
	        
	        logPw.println(" Processing create Supersede Link request on "+formatedDate+" part number is "+partID+" part_CID is "+part_CID);
			QuerySpec resQS = WebServiceHelper.findPartByNumberAndCadim(partID, part_CID);
			QueryResult resQR = PersistenceHelper.manager
					.find((StatementSpec) resQS);
			System.out.println("resQR: " + resQR);
			LOGGER.debug("resQR.size()"+resQR.size());
			int size = resQR.size();
			if (size > 0) {

				Persistable resObj[] = (Persistable[]) resQR.nextElement();
				LOGGER.debug("resObj[0] " + resObj[0]);

				WTPart resPart = (WTPart) resObj[0];
				WTPart latestPartRevision = (WTPart)ObjectRevisionHelper.getLatestVersionByPersistable(resPart);
				WTPart latestPartIteration = (WTPart) VersionControlHelper
						.getLatestIteration(latestPartRevision);
				List<SupersedeLink> supersededLinksList = DBUtils
						.retrieveLinks(SupersedeLink.class,
								latestPartIteration.getMaster(),
								SupersedeLink.SUPERSEDED_ROLE);
				List<SupersedeLink> supersedingLinksList = DBUtils
						.retrieveLinks(SupersedeLink.class,
								latestPartIteration.getMaster(),
								SupersedeLink.SUPERSEDING_ROLE);
				
				LOGGER.debug("supersededLinksList size "+ supersededLinksList.size());
				logPw.println("supersededLinksList size "+ supersededLinksList.size());
				
				LOGGER.debug("supersedingLinksList size "+ supersedingLinksList.size());
				logPw.println("supersedingLinksList size "+ supersedingLinksList.size());
				
				for (SupersedeLink supersedeLink : supersededLinksList) {
					LOGGER.debug("B4 deleting supersedeLink in supersededLinksList");
					logPw.println("B4 deleting wtPartDescribeLink in supersededLinksList");
					PersistenceServerHelper.manager.remove(supersedeLink);
					LOGGER.debug("After deleting wtPartDescribeLink in supersededLinksList");
					logPw.println("After deleting wtPartDescribeLink in supersededLinksList");
				}
				
				for (SupersedeLink supersedeLink1 : supersedingLinksList) {
					LOGGER.debug("B4 deleting SupersedeLink in supersedingLinksList");
					logPw.println("B4 deleting SupersedeLink  in supersedingLinksList");
					PersistenceServerHelper.manager.remove(supersedeLink1);
					LOGGER.debug("After deleting SupersedeLink in supersedingLinksList");
					logPw.println("After deleting SupersedeLink in supersedingLinksList");
				}
								
				QuerySpec supersedesPartQS = new QuerySpec();
				int SupersedesPartIndex = supersedesPartQS.appendClassList(WTPart.class, true);
				int SupersedesPartMasterIndex = supersedesPartQS.appendClassList(WTPartMaster.class,false);
				supersedesPartQS.appendWhere(new SearchCondition(WTPart.class,
						"masterReference.key.id", WTPartMaster.class,
						"thePersistInfo.theObjectIdentifier.id"), new int[] {
					SupersedesPartIndex, SupersedesPartMasterIndex });
				supersedesPartQS.appendAnd();
				supersedesPartQS.appendWhere(new SearchCondition(WTPartMaster.class, "number",
						SearchCondition.EQUAL, supersedesPartNumber),
						new int[] { SupersedesPartMasterIndex });
				QueryResult SupersedesPartQR = PersistenceHelper.manager.find((StatementSpec) supersedesPartQS);
				LOGGER.debug("SupersedesPartQR size = "+SupersedesPartQR.size());
				logPw.println("SupersedesPartQR size = "+SupersedesPartQR.size());
				Persistable SupersedesPartObj[] = (Persistable[]) SupersedesPartQR.nextElement();
				LOGGER.debug("dummyDocObj[0] " + SupersedesPartObj[0]);
				logPw.println("dummyDocObj[0] " + SupersedesPartObj[0]);
				WTPart SupersedesPart = (WTPart) SupersedesPartObj[0];
				
				QuerySpec SupersededByPartQS = new QuerySpec();
				int SupersededByPartIndex = SupersededByPartQS.appendClassList(WTPart.class, true);
				int SupersededByPartMasterIndex = SupersededByPartQS.appendClassList(WTPartMaster.class,false);
				SupersededByPartQS.appendWhere(new SearchCondition(WTPart.class,
						"masterReference.key.id", WTPartMaster.class,
						"thePersistInfo.theObjectIdentifier.id"), new int[] {
					SupersededByPartIndex, SupersededByPartMasterIndex });
				SupersededByPartQS.appendAnd();
				SupersededByPartQS.appendWhere(new SearchCondition(WTPartMaster.class, "number",
						SearchCondition.EQUAL, supersededByPartNumber),
						new int[] { SupersededByPartMasterIndex });
				QueryResult SupersededByPartQR = PersistenceHelper.manager.find((StatementSpec) SupersededByPartQS);
				LOGGER.debug("SupersededByPartQR size = "+SupersededByPartQR.size());
				logPw.println("SupersededByPartQR size = "+SupersededByPartQR.size());
				Persistable SupersededByPartObj[] = (Persistable[]) SupersededByPartQR.nextElement();
				LOGGER.debug("SupersededByPartObj[0] " + SupersededByPartObj[0]);
				logPw.println("SupersededByPartObj[0] " + SupersededByPartObj[0]);
				WTPart SupersededByPart = (WTPart) SupersededByPartObj[0];
				
				if(supersededBy != null)
				{
				
				LOGGER.debug("supersededBy is not null ");
				logPw.println("supersededBy is not null ");
				QuerySpec supersededByQS = WebServiceHelper.findPartByNumberAndCadim(supersededBy, supersededBy_CID);
				QueryResult supersededByQR = PersistenceHelper.manager
						.find((StatementSpec) supersededByQS);
				LOGGER.debug("supersededByQR.size()"+supersededByQR.size());
				logPw.println("supersededByQR.size()"+supersededByQR.size());
				int sizeSupersededBy = supersededByQR.size();
				if(sizeSupersededBy>0)
				{
					Persistable supersededByObj[] = (Persistable[]) supersededByQR.nextElement();
					LOGGER.debug("suepersededByObj[0] " + supersededByObj[0]);

					WTPart supersedingPart = (WTPart) supersededByObj[0];
					LOGGER.debug("spersedingPart: " + supersedingPart.getNumber());
					logPw.println("spersedingPart: " + supersedingPart.getNumber());
					SupersedeLink link = SupersedeLink.newSupersedeLink(resPart.getMaster(), supersedingPart.getMaster());
					link = (SupersedeLink) PersistenceHelper.manager.save(link);
					LOGGER.debug("After creating supersede link with part as superseded part ");
					logPw.println("After creating supersede link with part as superseded part ");
										 
				}
				else
				{

					SupersedeLink link = SupersedeLink.newSupersedeLink(resPart.getMaster(), SupersededByPart.getMaster());
					link = (SupersedeLink) PersistenceHelper.manager.save(link);
					LOGGER.debug("After creating supersede link with dummy part as superseding part");
					logPw.println("After creating supersede link with dummy part as superseding part");
					SupersedeGroup supersedeGroup = link.getGroup();
					IBAHelper.writeIBA(supersedeGroup, "KB_INSTRUCTIONS", supersededBy);
					LOGGER.debug("After updating supersede group");
					logPw.println("After updating supersede group");
				}
				}
				
				if(supersedes != null)
				{
				QuerySpec suepersedingQS = WebServiceHelper.findPartByNumberAndCadim(supersedes, supersedes_CID);
				QueryResult suepersedingQR = PersistenceHelper.manager
						.find((StatementSpec) suepersedingQS);
				LOGGER.debug("suepersedingQR.size()"+suepersedingQR.size());
				logPw.println("suepersedingQR.size()"+suepersedingQR.size());
				int sizeSuperseding = suepersedingQR.size();
				if(sizeSuperseding>0)
				{
					Persistable supersedingByObj[] = (Persistable[]) suepersedingQR.nextElement();
					LOGGER.debug("suepersededByObj[0] " + supersedingByObj[0]);

					WTPart supersededPart = (WTPart) supersedingByObj[0];
					LOGGER.debug("spersedingPart: " + supersededPart.getNumber());
					SupersedeLink link = SupersedeLink.newSupersedeLink(supersededPart.getMaster(), resPart.getMaster());
					link = (SupersedeLink) PersistenceHelper.manager.save(link);

					LOGGER.debug("After creating supersede link with part as superseding part ");
					logPw.println("After creating supersede link with part as superseding part ");
				}
				else
				{
					SupersedeLink link = SupersedeLink.newSupersedeLink(SupersedesPart.getMaster(), resPart.getMaster());
					link = (SupersedeLink) PersistenceHelper.manager.save(link);
					LOGGER.debug("After creating supersede link with dummy part as superseded part");
					logPw.println("After creating supersede link with dummy part as superseded part");
					SupersedeGroup supersedeGroup = link.getGroup();
					IBAHelper.writeIBA(supersedeGroup, "KB_INSTRUCTIONS", supersedes);
					LOGGER.debug("After updating supersede group");
					logPw.println("After updating supersede group");
				}
				}

				
					
				logPw.println("trx==="+trx );
				trx.commit();
	            trx = null;	
	            result.add("0");
                result.add("Success");
                LOGGER.debug(result);
                logPw.println("Result for the service request is"+result);	
                return result;
			} else {
				throw new WTException("Part with number "+partID+" and CID "+part_CID+" not found");
			}
		} catch (WTException e) {
			String message = "WTException during create Supersede Link Service exception is "
					+ e;
			result.add("1");
            result.add(message);
            LOGGER.debug(result);
            logPw.println("Result for the service request is"+result);	
            return result;

		} catch (WTPropertyVetoException e) {
			String message = "WTException during create Supersede Link Service exception is "
					+ e;
			result.add("1");
            result.add(message);
            LOGGER.info(result);
            logPw.println("Result for the service request is"+result);	
            return result;
		} finally {
			logPw.println("trx in finally===" + trx);
			LOGGER.debug("trx in finally===" + trx);
			if (trx != null) {
				trx.rollback();
			}
			logPw.flush();
            logPw.close();
		}

	}
}