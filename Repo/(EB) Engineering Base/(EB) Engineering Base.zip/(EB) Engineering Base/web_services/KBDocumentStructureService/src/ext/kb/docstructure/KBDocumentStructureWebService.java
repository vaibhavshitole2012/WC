package ext.kb.docstructure;

import java.util.ArrayList;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

import com.ptc.jws.servlet.JaxWsWebService;

import ext.kb.part.OutputRefDesignatorObject;
import ext.kb.part.RefDesignatorObject;
import ext.kb.part.ReferenceDesignatorHelper;
import wt.util.WTException;

@WebService()
public class KBDocumentStructureWebService extends JaxWsWebService
{
	@WebMethod(operationName="getDocumentStructure")
    public ArrayList<OutputDocumentStructure> getDocumentStructure(@WebParam(name="ParentDocs") ArrayList<ParentDocs> parentDocs)
    {
    	ArrayList outobj=new ArrayList();
		outobj = KBDocumentStructureHelper.startProcess(parentDocs);
    	return outobj;
    }
}