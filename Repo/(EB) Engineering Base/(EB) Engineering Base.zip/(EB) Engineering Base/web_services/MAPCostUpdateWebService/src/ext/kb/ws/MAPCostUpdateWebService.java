package ext.kb.ws;

import com.ptc.jws.servlet.JaxWsWebService;
import ext.kb.tool.MAPCostUpdateTool;
import org.apache.log4j.Logger;
import wt.log4j.LogR;

import javax.jws.Oneway;
import javax.jws.WebMethod;
import javax.jws.WebService;

@WebService()
public class MAPCostUpdateWebService extends JaxWsWebService
{
    private static Logger log = LogR.getLogger(MAPCostUpdateWebService.class.getName());

    @WebMethod(operationName="mapUpdate")
    @Oneway
    public void mapUpdate (String inputFile, String logsPath)
    {
        try {
            MAPCostUpdateTool.mapUpdate(inputFile, logsPath);
        } catch (Exception e) {
            log.error(e);
        }
    }
}