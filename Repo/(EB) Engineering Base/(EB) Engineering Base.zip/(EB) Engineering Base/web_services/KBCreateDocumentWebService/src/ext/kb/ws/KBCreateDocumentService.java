package ext.kb.ws;


import java.beans.PropertyVetoException;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.xml.bind.JAXBException;

import org.apache.log4j.Logger;

import wt.configurablelink.ConfigurableLinkHelper;
import wt.configurablelink.ConfigurableRevisionLink;
import wt.content.ApplicationData;
import wt.content.ContentRoleType;
import wt.content.ContentServerHelper;
import wt.doc.WTDocument;
import wt.doc.WTDocumentMaster;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.fc.collections.WTHashSet;
import wt.folder.Folder;
import wt.folder.FolderEntry;
import wt.folder.FolderHelper;
import wt.iba.definition.litedefinition.AttributeDefDefaultView;
import wt.iba.value.AttributeContainer;
import wt.iba.value.DefaultAttributeContainer;
import wt.iba.value.IBAHolder;
import wt.iba.value.service.IBAValueDBService;
import wt.inf.container.WTContainerHelper;
import wt.inf.container.WTContainerRef;
import wt.log4j.LogR;
import wt.org.WTPrincipalReference;
import wt.part.WTPart;
import wt.pds.StatementSpec;
import wt.pom.Transaction;
import wt.query.QuerySpec;
import wt.series.MultilevelSeries;
import wt.type.TypeDefinitionReference;
import wt.type.TypedUtilityServiceHelper;
import wt.util.WTException;
import wt.util.WTProperties;
import wt.util.WTPropertyVetoException;
import wt.vc.VersionControlHelper;
import wt.vc.VersionIdentifier;
import wt.vc.Versioned;

import com.ptc.core.lwc.server.PersistableAdapter;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.TypeIdentifierHelper;
import com.ptc.core.meta.common.impl.WCTypeIdentifier;
import com.ptc.generic.content.StandardAdvContentService;
import com.ptc.jws.servlet.JaxWsWebService;
import com.ptc.wpcfg.utilities.PrincipalHelper;

import ext.kb.service.WebServiceHelper;
import ext.kb.util.IBAHelper;
import ext.kb.util.KBConstants;
import ext.kb.util.KBDocumentUtils;
import ext.kb.util.NamingHelper;

@WebService()
public class KBCreateDocumentService extends JaxWsWebService {
	private static final Logger LOGGER = LogR.getLogger(KBCreateDocumentService.class.getName());
	
	@WebMethod(operationName = "createDocument")
	public List<String> createDocument(
			@WebParam(name = "name") String name,
			@WebParam(name = "number") String number,
			@WebParam(name = "SAP_IDX") String SAP_IDX,
			@WebParam(name = "Parent_CID") String Parent_CID,
			@WebParam(name = "type") String type,
			@WebParam(name = "container") String containerPath,
			@WebParam(name = "folder") String folderPath,
			@WebParam(name = "primaryContentPath") String primaryContentPath,
			@WebParam(name = "revisionIdentifier") String revisionIdentifier,
			@WebParam(name = "contentFileName") String contentFileName,
			@WebParam(name = "contentLocation") String contentLocation,
			@WebParam(name = "cadimTransferDate") String cadimTransferDate,
			@WebParam(name = "masterSystem") String masterSystem,
			@WebParam(name = "sheetNo") String sheetNo,
			@WebParam(name = "localization") String localization,
			@WebParam(name = "creatorName") String creatorName,
			@WebParam(name = "secondaryContent") String secondaryContent[][],
			@WebParam(name = "ibas") HashMap<String, String> ibas)
			throws WTException, JAXBException, PropertyVetoException, ClassNotFoundException, IOException, ParseException
	{

		Transaction trx = null;
		List<String> result = new ArrayList<String>();
		
		String wtHome = WebServiceHelper.getWindchillHome();
		LOGGER.debug("WT_HOME : "+wtHome);
		String LOG_FILE_NAME = wtHome+"/logs/interface";
		WebServiceHelper.createDirIfNotExisting(LOG_FILE_NAME);
		LOG_FILE_NAME = wtHome+"/logs/interface/Cadim2WctCreateDocument.log";
		//String LOG_FILE_NAME = "/opt/ptc/wt111/Cadim2WctCreateDocument.log";
		
	    PrintWriter logPw = null;
	    FileWriter fw = null;
	    BufferedWriter bw = null;
	    WTProperties properties = WTProperties.getServerProperties();
		String defaultDomain = properties.getProperty("KBDefaultExternalDomain","CADIM DOMAIN");
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
		try {

			trx = new Transaction();
			trx.start();
			
		    File file = new File(LOG_FILE_NAME);
			file.setExecutable(true, false);
            file.setReadable(true, false);
            file.setWritable(true, false);
            LOGGER.debug("After getting log file ==="+file);
            fw = new FileWriter(LOG_FILE_NAME,true);
            bw = new BufferedWriter(fw);
            logPw = new PrintWriter(bw);
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
            Date date = new Date();
            String formatedDate = sdf.format(date);
            Map<String, String> FolderNameMapping = new HashMap<String, String>();
            FolderNameMapping.put("/Default/00 Protected Space/Data",   "/Default/00 Confidential/Data");
            FolderNameMapping.put("/Default/10 BA - Limited/Data",   "/Default/10 Internal/Data");
            FolderNameMapping.put("/Default/50 Public - Global/Data",   "/Default/50 Public - Global/Data");
            FolderNameMapping.put("/Default/20 BA - Extended/Data",   "/Default/20 Public/Data");
			LOGGER.info("Create Doc service on "+formatedDate+" for document with number "+number+" and name "+name );
			LOGGER.debug("number is "+number+" name is "+name+" type is "+type+" container is "+containerPath+" and folder is  "+folderPath);
			logPw.println(" Processing create request on "+formatedDate+" for document number is "+number+" name is "+name+" type is "+type+" container is "+containerPath+" and folder is  "+folderPath);

			WTDocument doc = WTDocument.newWTDocument();

			// to get translation ID from ibas
			String translationID = "";
			String namingPartValue = "";
			if (ibas.keySet().contains(KBConstants.TRANSLATION_ID_IBA)) {
				translationID = ibas.get(KBConstants.TRANSLATION_ID_IBA);
				// Getting Description 1 EN value using NamingEntry and translation ID
				if (translationID != null && !translationID.equalsIgnoreCase("")) {
					LOGGER.debug("translationID has been obtained. Translation ID is :" + translationID);
					WTPart namingPart = NamingHelper.getNamingEntryByNumber(translationID);
					LOGGER.debug("Naming catalog part obtained is :" + namingPart);
					if (namingPart != null) {
						namingPartValue = namingPart.getName();
						LOGGER.debug("Naming catalog part name is :" + namingPartValue);
					}
				}
			}
			LOGGER.debug("TranslationID is : " + translationID);
			
			 if(!SAP_IDX.equals("000"))
	            {
				 	LOGGER.debug("SAP_IDX is not 000 going to create Variant Document parent_CID =="+Parent_CID);
					logPw.println("SAP_IDX is not 000 going to create Variant Document parent_CID =="+Parent_CID);	
					QuerySpec sourceDocQS = WebServiceHelper.findDocumentByNumberAndCadim(number+"-000",Parent_CID);
					QueryResult sourceDocQR = PersistenceHelper.manager.find((StatementSpec) sourceDocQS);
					System.out.println("sourceDocQR: " + sourceDocQR);
					int size = sourceDocQR.size();
					LOGGER.debug("size: " + size);
					if (size > 0) {
						Persistable newObj[] = (Persistable[]) sourceDocQR.nextElement();
						WTDocument sourceDoc = (WTDocument) newObj[0];
						logPw.println( " Source Doc" + sourceDoc);
						LOGGER.debug( " Source Doc" + sourceDoc);
						
						QueryResult sourceDocIter = VersionControlHelper.service.allIterationsOf(sourceDoc.getMaster());
						logPw.println( " sourceDocIter size " + sourceDocIter.size());
						LOGGER.debug( " sourceDocIter size " + sourceDocIter.size());
						while (sourceDocIter.hasMoreElements()) {
							WTDocument interimSourceDoc = (WTDocument) sourceDocIter.nextElement();
							String sourceDocVersion = interimSourceDoc.getVersionIdentifier().getValue();
							logPw.println( " Interim Source Doc Version " + sourceDocVersion);
							LOGGER.debug( " Interim Source Doc Version " + sourceDocVersion);
							if(sourceDocVersion.equals(revisionIdentifier))
							{
								logPw.println( " Interim Source Doc Version is same as revision identifier. This version will be taken as source doc");
								LOGGER.debug( " Interim Source Doc Version is same as revision identifier. This version will be taken as source doc ");
								sourceDoc = interimSourceDoc;
							}
							
						}
						
						doc.setName(name);
						if (type == null) {
							type = WTDocument.class.getName();
						}
						TypeDefinitionReference reference = TypedUtilityServiceHelper.service
								.getTypeDefinitionReference(type);
						doc.setTypeDefinitionReference(reference);
						WTContainerRef containerReference = WTContainerHelper.service
								.getByPath(containerPath);
						doc.setContainerReference(containerReference);
						Folder folder = null;
						logPw.println( " folder path" + folderPath);
						LOGGER.debug( " folder path" + folderPath);
						boolean folderExists = WebServiceHelper.folderExistsInContainer(containerReference.getContainer(), folderPath, doc);
						logPw.println( " folderExists " + folderExists);
						LOGGER.debug( " folderExists " + folderExists);
						if(!folderExists)
						{
							String oldFolderPath = FolderNameMapping.get(folderPath);
							logPw.println( " oldFolderPath " + oldFolderPath);
							LOGGER.debug( " oldFolderPath " + oldFolderPath);
							if(oldFolderPath != null)
							{
								boolean oldFolderExists = WebServiceHelper.folderExistsInContainer(containerReference.getContainer(), oldFolderPath, doc);
								logPw.println( " oldFolderPath " + oldFolderPath);
								LOGGER.debug( " oldFolderPath " + oldFolderPath);
								if(oldFolderExists)
								{
								folder = FolderHelper.service.getFolder(oldFolderPath,
										containerReference);
								}
								else{
									folder = FolderHelper.service.getFolder("/Default",
											containerReference);
								}
								}
							else{
								folder = FolderHelper.service.getFolder("/Default",containerReference);
							}
						}
						else{
						folder = FolderHelper.service.getFolder(folderPath,
								containerReference);
						}
						FolderHelper.assignLocation((FolderEntry) doc, folder);
						//String Creator = ibas.get("iterationInfo.creator");
						logPw.println("Created by =="+creatorName);
						LOGGER.debug("Created by =="+creatorName);
						if(creatorName != null){
							WTPrincipalReference principalReference = PrincipalHelper.getPrincipal(creatorName);
							if(principalReference != null)
							{
							VersionControlHelper.assignIterationCreator(doc, principalReference);
							VersionControlHelper.setIterationModifier(doc, principalReference);
							}
							else{
								WTPrincipalReference principalReference1 = PrincipalHelper.getPrincipal("INTERFACE_SAP");
								VersionControlHelper.assignIterationCreator(doc, principalReference1);
								VersionControlHelper.setIterationModifier(doc, principalReference1);
							}
							
							}
									
						WTDocumentMaster variantDocMaster = (WTDocumentMaster) doc.getMaster();
						logPw.println("docMaster00 "+variantDocMaster);
						LOGGER.debug("docMaster00 "+variantDocMaster);
						variantDocMaster = (WTDocumentMaster)IBAHelper.setIba(variantDocMaster, "KB_MASTERSYSTEM", masterSystem);
						logPw.println("After Setting Master System ");
						LOGGER.debug("After Setting Master System ");
						Long sheet = Long.valueOf(sheetNo);
						variantDocMaster = (WTDocumentMaster)IBAHelper.setIba(variantDocMaster, KBConstants.SHEET_NO_IBA, sheet);
						logPw.println("After setting Sheet No ");
						LOGGER.debug("After setting Sheet No ");
						variantDocMaster = (WTDocumentMaster)IBAHelper.setIba(variantDocMaster, KBConstants.KBLOCALIZATION_IBA, localization);
						logPw.println("After setting Localization ");
						LOGGER.debug("After setting Localization ");
						variantDocMaster = (WTDocumentMaster)IBAHelper.setIba(variantDocMaster, KBConstants.KBDOCUMENT_ID_IBA, number);
						logPw.println("After setting document_ID ");
						LOGGER.debug("After setting document_ID ");
						variantDocMaster = (WTDocumentMaster)IBAHelper.setIba(variantDocMaster, KBConstants.KBSAP_IDX_IBA, SAP_IDX);
						logPw.println("After setting SAP_IDX "+SAP_IDX);
						LOGGER.debug("After setting SAP_IDX "+SAP_IDX);
						doc.setName(sourceDoc.getName());
			            logPw.println("After setting name " + sourceDoc.getName());
			            LOGGER.debug("After setting name  " + sourceDoc.getName());
						String[] split = type.split("\\.");
						int splitSize = split.length;
						logPw.println("splitSize ==="+splitSize);
						LOGGER.debug("splitSize ==="+splitSize);
						String objectType = split[splitSize -1];
						logPw.println("objectType ==="+objectType);
						LOGGER.debug("objectType ==="+objectType);
						if(objectType.equalsIgnoreCase("KBTechnicalDrawing")|| objectType.equalsIgnoreCase("KBTechnicalDocument"))
						{
						doc = (WTDocument)IBAHelper.setIba(doc, KBConstants.KBLANGUAGE_IBA, ibas.get("KB_LANGUAGE"));
						logPw.println("After setting Language ");
						LOGGER.debug("After setting Language ");
						doc = (WTDocument)IBAHelper.setIba(doc,"KB_DOC_CONTENT_TYPE" , ibas.get("KB_DOC_CONTENT_TYPE"));
						logPw.println("After setting Language ");
						LOGGER.debug("After setting Language ");
						}
						
						 doc.getMaster().setSeries("wt.series.HarvardSeries.KB_Revision");
						 MultilevelSeries multilevelseries = MultilevelSeries.newMultilevelSeries("wt.series.HarvardSeries.KB_Revision", revisionIdentifier);
						VersionIdentifier versionidentifier = VersionIdentifier.newVersionIdentifier(multilevelseries);
						VersionControlHelper.setVersionIdentifier((Versioned)doc, versionidentifier);
						LOGGER.debug("After setting version");
						logPw.println("After seting version ");
						doc.setNumber(number+"-"+SAP_IDX);
						logPw.println("After setting number "+number+"-"+SAP_IDX);
						LOGGER.debug("After setting number "+number+"-"+SAP_IDX);
						
						 TypeIdentifier targetType = wt.type.TypedUtilityServiceHelper.service.getTypeIdentifier(doc);
							PersistableAdapter persistanceAdapter = new PersistableAdapter((Persistable) doc,
									((WCTypeIdentifier) targetType).getLeafName(), null, null);
							
							persistanceAdapter.load(ibas.keySet());
							
							for (Entry<String, String> attEntry : ibas.entrySet()) {
								AttributeDefDefaultView attributeDefinition = IBAHelper.getAttributeDefDefaultView(attEntry.getKey());
								logPw.println("Attribute Definition =="+ attributeDefinition);
								LOGGER.debug("Attribute Definition =="+ attributeDefinition);
								LOGGER.debug("Attribute name is"+ attEntry.getKey());
								logPw.println("Attribute name is"+ attEntry.getKey());
								
								// setting description 1 EN from translation ID - start
								if (KBConstants.DESCRIPTION_EN.equalsIgnoreCase(attEntry.getKey())) {
									attEntry.setValue(namingPartValue);
									LOGGER.debug("Setting attribute KB_DESCRIPTION_EN value as : " + namingPartValue);
								}
								// setting description 1 EN from translation ID - stop
								
								if(attEntry.getValue() != null && !attEntry.getValue().equals(""))
								{
								
								LOGGER.debug(" Attribute Value is not null it is "+attEntry.getValue());
								logPw.println(" Attribute Value is not null it is "+attEntry.getValue());
								AttributeDefDefaultView attributeDefDefaultView = IBAHelper.getAttributeDefDefaultView(attEntry.getKey());
								Object attrValue = WebServiceHelper.parseAttributeValue(attributeDefDefaultView,attEntry.getValue());
								LOGGER.debug("Attribute name is"+ attEntry.getKey()+" Attribute Value is "+attrValue);
								logPw.println("Attribute name is"+ attEntry.getKey()+" Attribute Value is "+attrValue);				
								if(!attEntry.getKey().equals("KB_DOCUMENT_ID"))
								persistanceAdapter.set(attEntry.getKey(), attrValue);
								}
							}
							
							persistanceAdapter.apply();
						
						doc = (WTDocument) PersistenceHelper.manager.save(doc);
		                doc = (WTDocument) PersistenceHelper.manager.refresh(doc);
						TypeIdentifier typeIdentifier = TypeIdentifierHelper.getTypeIdentifier("com.ptc.KBVariantLink");
						
						//WTDocument latestDocIteration = (WTDocument) VersionControlHelper.getLatestIteration(variantDoc);
		                QueryResult allLinks = PersistenceHelper.manager.navigate(doc, ConfigurableRevisionLink.ROLE_BOBJECT_ROLE, ConfigurableRevisionLink.class, true);
		                WTHashSet linkSet = new WTHashSet();
		                while(allLinks.hasMoreElements()){
		                	Object obj = allLinks.nextElement();
		                	LOGGER.debug("Got: "+obj);
		                	if(obj instanceof WTDocument){
		                		linkSet.addAll(ConfigurableLinkHelper.service.getConfigurableLinks(doc, (WTDocument)obj, typeIdentifier));		                		
		                	}
		                }
		                for(Object link : linkSet){
		                	LOGGER.debug("Got: "+link);
		                	if(link instanceof ConfigurableRevisionLink){
		                    	LOGGER.debug("Got linked from: "+((ConfigurableRevisionLink)link).getLinkedFrom().getIdentity()+" ,linked to: "+((ConfigurableRevisionLink)link).getLinkedTo().getIdentity());
		                	}

		                }
		                PersistenceHelper.manager.delete(linkSet);

		                TypeDefinitionReference typeDefinitionReference = TypedUtilityServiceHelper.service.
		                        getTypeDefinitionReference(typeIdentifier.getTypename());
		                ConfigurableRevisionLink kbVariantLink = ConfigurableRevisionLink.newConfigurableRevisionLink(
		                		sourceDoc, doc, typeDefinitionReference);
		                PersistenceHelper.manager.save(kbVariantLink);
					}
					else{
						throw new WTException(" Document with number " + number
								+ "-000 and CID " + Parent_CID + " not found");
					}
	            }
			
			 else{
			doc.setName(name);
			doc.setNumber(number+"-"+SAP_IDX);
			if (type == null) {
				type = WTDocument.class.getName();
			}
			TypeDefinitionReference reference = TypedUtilityServiceHelper.service
					.getTypeDefinitionReference(type);
			doc.setTypeDefinitionReference(reference);
			WTContainerRef containerReference = WTContainerHelper.service
					.getByPath(containerPath);
			doc.setContainerReference(containerReference);
			Folder folder = null;
			logPw.println( " folder path" + folderPath);
			LOGGER.debug( " folder path" + folderPath);
			boolean folderExists = WebServiceHelper.folderExistsInContainer(containerReference.getContainer(), folderPath, doc);
			logPw.println( " folderExists " + folderExists);
			LOGGER.debug( " folderExists " + folderExists);
			if(!folderExists)
			{
				String oldFolderPath = FolderNameMapping.get(folderPath);
				logPw.println( " oldFolderPath " + oldFolderPath);
				LOGGER.debug( " oldFolderPath " + oldFolderPath);
				if(oldFolderPath != null)
				{
					boolean oldFolderExists = WebServiceHelper.folderExistsInContainer(containerReference.getContainer(), oldFolderPath, doc);
					logPw.println( " oldFolderPath " + oldFolderPath);
					LOGGER.debug( " oldFolderPath " + oldFolderPath);
					if(oldFolderExists)
					{
					folder = FolderHelper.service.getFolder(oldFolderPath,
							containerReference);
					}
					else{
						folder = FolderHelper.service.getFolder("/Default",
								containerReference);
					}
					}
				else{
					folder = FolderHelper.service.getFolder("/Default",containerReference);
				}
			}
			else{
			folder = FolderHelper.service.getFolder(folderPath,
					containerReference);
			}
			FolderHelper.assignLocation((FolderEntry) doc, folder);
			//Folder folder = FolderHelper.service.getFolder(folderPath,containerReference);
			FolderHelper.assignLocation((FolderEntry) doc, folder);
			//String Creator = ibas.get("iterationInfo.creator");
			logPw.println("Created by =="+creatorName);
			LOGGER.debug("Created by =="+creatorName);
			if(creatorName != null){
				WTPrincipalReference principalReference = PrincipalHelper.getPrincipal(creatorName);
				if(principalReference != null)
				{
				VersionControlHelper.assignIterationCreator(doc, principalReference);
				VersionControlHelper.setIterationModifier(doc, principalReference);
				}
				else{
					WTPrincipalReference principalReference1 = PrincipalHelper.getPrincipal("INTERFACE_SAP");
					VersionControlHelper.assignIterationCreator(doc, principalReference1);
					VersionControlHelper.setIterationModifier(doc, principalReference1);
				}
				
				}
						
			//doc = (WTDocument) PersistenceHelper.manager.store(doc);
			//logPw.println("After creating doc "+doc);	
			//LOGGER.debug("After creating doc "+doc);
			
			WTDocumentMaster docMaster = (WTDocumentMaster) doc.getMaster();
			logPw.println("docMaster00 "+docMaster);
			LOGGER.debug("docMaster00 "+docMaster);
			docMaster = (WTDocumentMaster)IBAHelper.setIba(docMaster, "KB_MASTERSYSTEM", masterSystem);
			logPw.println("After Setting Master System "+masterSystem);
			LOGGER.debug("After Setting Master System "+masterSystem);
			Long sheet = Long.valueOf(sheetNo);
			docMaster = (WTDocumentMaster)IBAHelper.setIba(docMaster, KBConstants.SHEET_NO_IBA, sheet);
			logPw.println("After setting Sheet No "+sheet);
			LOGGER.debug("After setting Sheet No "+sheet);
			docMaster = (WTDocumentMaster)IBAHelper.setIba(docMaster, KBConstants.KBLOCALIZATION_IBA, localization);
			logPw.println("After setting Localization "+localization);
			LOGGER.debug("After setting Localization "+localization);
			docMaster = (WTDocumentMaster)IBAHelper.setIba(docMaster, KBConstants.KBSAP_IDX_IBA, SAP_IDX);
			logPw.println("After setting SAP_IDX "+SAP_IDX);
			LOGGER.debug("After setting SAP_IDX "+SAP_IDX);
			docMaster = (WTDocumentMaster)IBAHelper.setIba(docMaster, KBConstants.KBDOCUMENT_ID_IBA, number);
			logPw.println("After setting DOCUMENT_ID "+number);
			LOGGER.debug("After setting DOCUMENT_ID "+number);
			String[] split = type.split("\\.");
			int splitSize = split.length;
			logPw.println("splitSize ==="+splitSize);
			LOGGER.debug("splitSize ==="+splitSize);
			String objectType = split[splitSize -1];
			logPw.println("objectType ==="+objectType);
			LOGGER.debug("objectType ==="+objectType);
			if(objectType.equalsIgnoreCase("KBTechnicalDrawing")|| objectType.equalsIgnoreCase("KBTechnicalDocument"))
			{
			doc = (WTDocument)IBAHelper.setIba(doc, KBConstants.KBLANGUAGE_IBA, ibas.get("KB_LANGUAGE"));
			logPw.println("After setting Language ");
			LOGGER.debug("After setting Language ");
			doc = (WTDocument)IBAHelper.setIba(doc,"KB_DOC_CONTENT_TYPE" , ibas.get("KB_DOC_CONTENT_TYPE"));
			logPw.println("After setting Doc Content type ");
			LOGGER.debug("After setting Doc Content type ");
			}

			}
			 
			 doc.getMaster().setSeries("wt.series.HarvardSeries.KB_Revision");
			 MultilevelSeries multilevelseries = MultilevelSeries.newMultilevelSeries("wt.series.HarvardSeries.KB_Revision", revisionIdentifier);
			 VersionIdentifier versionidentifier = VersionIdentifier.newVersionIdentifier(multilevelseries);
			 VersionControlHelper.setVersionIdentifier((Versioned)doc, versionidentifier);
			 LOGGER.debug("After setting version");
			 logPw.println("After seting version ");
			
            ApplicationData content = ApplicationData.newApplicationData(doc);
            logPw.println("primaryContentPath "+primaryContentPath);
            LOGGER.debug("primaryContentPath "+primaryContentPath);
            if(primaryContentPath != null)
            {
            File contentFile = new File(primaryContentPath);
            logPw.println("contentFile "+contentFile);
            LOGGER.debug("contentFile "+contentFile);
            boolean uploadPrimary = WebServiceHelper.uploadDocContent(doc,contentFile,ContentRoleType.toContentRoleType("PRIMARY"));
            logPw.println("After updateContent Primary Content ");
            LOGGER.debug("After updateContent Primary Content ");
            }
            logPw.println("secondaryContent.length "+secondaryContent.length);
            LOGGER.debug("secondaryContent.length "+secondaryContent.length);
            if(secondaryContent.length>0)
            {
            for (int i = 0; i < secondaryContent.length; i++) {
            	File secContentFile = new File(secondaryContent[i][0]);
            	boolean uploadSecondary = WebServiceHelper.uploadDocContent(doc,secContentFile,ContentRoleType.toContentRoleType("SECONDARY"));
            	logPw.println("doc after refresh "+doc);  
            	LOGGER.debug("doc after refresh "+doc);            	
            }
            }
            doc = (WTDocument)IBAHelper.setIba(doc, "KB_CADIM_TRANSFER_DATE", new Timestamp(dateFormat.parse(cadimTransferDate).getTime()));
            TypeIdentifier targetType = wt.type.TypedUtilityServiceHelper.service.getTypeIdentifier(doc);
			PersistableAdapter persistanceAdapter = new PersistableAdapter((Persistable) doc,
					((WCTypeIdentifier) targetType).getLeafName(), null, null);
			
			persistanceAdapter.load(ibas.keySet());
			for (Entry<String, String> attEntry : ibas.entrySet()) {
				AttributeDefDefaultView attributeDefinition = IBAHelper.getAttributeDefDefaultView(attEntry.getKey());
				logPw.println("Attribute Definition =="+ attributeDefinition);
				LOGGER.debug("Attribute Definition =="+ attributeDefinition);
				LOGGER.debug("Attribute name is"+ attEntry.getKey());
				logPw.println("Attribute name is"+ attEntry.getKey());
				AttributeDefDefaultView attributeDefDefaultView = IBAHelper.getAttributeDefDefaultView(attEntry.getKey());
				Object attrValue = WebServiceHelper.parseAttributeValue(attributeDefDefaultView,attEntry.getValue());
				LOGGER.debug("Attribute name is"+ attEntry.getKey()+" Attribute Value is "+attrValue);
				logPw.println("Attribute name is"+ attEntry.getKey()+" Attribute Value is "+attrValue);				
				if(!attEntry.getKey().equals("KB_DOCUMENT_ID"))
				persistanceAdapter.set(attEntry.getKey(), attrValue);
				if(attEntry.getKey().equals(KBConstants.KBLANGUAGE_IBA))
				{
					String [] langStr = attrValue.toString().split("/");
					LOGGER.debug("langStr "+langStr);
					persistanceAdapter.set(attEntry.getKey(), langStr);
				}
				
				// setting description 1 EN from translation ID - start
				if (KBConstants.DESCRIPTION_EN.equalsIgnoreCase(attEntry.getKey())) {
					attEntry.setValue(namingPartValue);
					LOGGER.debug("Setting attribute KB_DESCRIPTION_EN value as : " + namingPartValue);
				}
				// setting description 1 EN from translation ID - stop
			}
			
			persistanceAdapter.apply();
			          
            doc = (WTDocument) PersistenceHelper.manager.save(doc);
			doc = (WTDocument) PersistenceHelper.manager.refresh(doc);
			logPw.println("After creating doc "+doc);	
			LOGGER.debug("After creating doc "+doc);            
            
            if(primaryContentPath != null)
            {
            File contentFolder = new File(contentLocation);
            logPw.println("doc before deleting secondary content file"+contentFolder); 
            LOGGER.debug("doc before deleting secondary content file"+contentFolder); 
            WebServiceHelper.deleteDir(contentFolder);
            logPw.println("doc after deleting secondary content file");
            LOGGER.debug("doc after deleting secondary content file");
            }
            if(secondaryContent.length>0)
            {
            for (int i = 0; i < secondaryContent.length; i++) {
            	File secContentLocationFile = new File(secondaryContent[i][2]);
            	logPw.println("doc before deleting secondary content file"+secContentLocationFile); 
            	LOGGER.debug("doc before deleting secondary content file"+secContentLocationFile); 
            	WebServiceHelper.deleteDir(secContentLocationFile);
            	logPw.println("doc after deleting secondary content file");
            	LOGGER.debug("doc after deleting secondary content file");
            }
            }
            
            LOGGER.debug("containerName name ==="+ doc.getContainerName());
			logPw.println("containerName name ==="+ doc.getContainerName());
            LOGGER.debug( " part domain before \"" + doc.getDomainRef().getName() + "\" domain");
            logPw.println( " part domain before \"" + doc.getDomainRef().getName() + "\" domain");
            //WebServiceHelper.setCadimDomain(doc, defaultDomain, doc.getContainerName());
            LOGGER.debug( " part domain After \"" + doc.getDomainRef().getName() + "\" domain");
            logPw.println( " part domain After \"" + doc.getDomainRef().getName() + "\" domain");
            
           
            
			LOGGER.debug("trx== "+trx);
			trx.commit();
            trx = null;	
            String docNumber = doc.getNumber();
            LOGGER.debug("docNumber== "+docNumber);
            result.add("ReturnCode: 0");
            result.add("Text: Success");
            result.add("Windchill Document Number is "+docNumber);
            logPw.println("Result for the service request is"+result);	
            LOGGER.info(result);
			return result;
		} catch (WTException e) {
			String message = "WTException during document creation exception is "
					+ e;
			result.add("ReturnCode: 1");
			result.add("Text: "+message);
			logPw.println("Result for the service request is"+result);	
            LOGGER.info(result);
			return result;

		} catch (WTPropertyVetoException e) {
			String message = "WTPropertyVetoException during document creation exception is "
					+ e;
			result.add("ReturnCode: 1");
            result.add("Text: "+message);
            logPw.println("Result for the service request is"+result);	
            LOGGER.info(result);
			return result;
		} 
		catch (IOException e) {
			String message = "IOException during document creation exception is "
					+ e;
			
			LOGGER.info(result);
			result.add("ReturnCode: 1");
			result.add("Text: "+message); 
			logPw.println("Result for the service request is"+result);	
			return result;

		}finally {
			System.out.println("trx in finally===" + trx);
			if (trx != null) {
				trx.rollback();
			}
			logPw.flush();
            logPw.close();
		}
	}
}