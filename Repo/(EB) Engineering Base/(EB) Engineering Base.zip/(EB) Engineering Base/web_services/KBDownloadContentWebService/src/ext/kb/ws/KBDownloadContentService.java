package ext.kb.ws;

import java.io.IOException;
import java.text.MessageFormat;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.apache.log4j.Logger;

import wt.log4j.LogR;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.util.WTRuntimeException;

import com.ptc.jws.servlet.JaxWsWebService;

import ext.kb.service.KBDownloadContentHelper;

/**
 * 
 * Created on 22.03.2016.
 * 
 */
@WebService()
public class KBDownloadContentService extends JaxWsWebService
{
    private static Logger log = LogR.getLogger(KBDownloadContentService.class.getName());

    @WebMethod(operationName = "downloadPermittedContent")
    public String downloadPermittedContent(String[] urls, String permissionName, String user) {
        log.debug(MessageFormat
                .format(
                    "Web service operation downloadPermittedContent called with user= {0}, permission={1}, urls:{2}",
                    user, permissionName, urls.length));
        try {
            final String result = KBDownloadContentHelper.downloadPermittedContent(urls,
                permissionName, user);
            return result;
        } catch (WTRuntimeException | WTException | IOException | WTPropertyVetoException e) {
            log.error(e);
        }
        return null;
    }
}