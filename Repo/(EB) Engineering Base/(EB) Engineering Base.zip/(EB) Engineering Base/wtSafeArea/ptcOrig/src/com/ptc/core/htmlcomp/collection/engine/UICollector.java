/* bcwti
 *
 * Copyright (c) 2010 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */

package com.ptc.core.htmlcomp.collection.engine;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import com.ptc.core.collectionsrv.engine.ClassObject;
import com.ptc.core.collectionsrv.engine.CollectionConfig;
import com.ptc.core.collectionsrv.engine.CollectionDefinition;
import com.ptc.core.collectionsrv.engine.CollectionPackage;
import com.ptc.core.collectionsrv.engine.CollectionSrvHelper;
import com.ptc.core.collectionsrv.engine.CollectionToExecute;
import com.ptc.core.collectionsrv.engine.CollectionToExecute.AdditionalCollectionToExecute;
import com.ptc.core.collectionsrv.engine.CollectorDefinitionIDS;
import com.ptc.core.collectionsrv.engine.CollectorSrvCache;
import com.ptc.core.collectionsrv.engine.Link;
import com.ptc.core.collectionsrv.engine.ResultGraph;
import com.ptc.core.htmlcomp.htmlcompResource;
import com.ptc.core.htmlcomp.collection.DependencyTracingLimitExceededException;
import com.ptc.core.htmlcomp.cs.ConfigSpecHolder;
import com.ptc.core.htmlcomp.util.DataValidator;
import com.ptc.core.htmlcomp.util.DataValidity;
import com.ptc.core.htmlcomp.util.Message;
import com.ptc.core.logging.Log;
import com.ptc.core.logging.LogFactory;

import wt.doc.WTDocument;
import wt.epm.EPMDocConfigSpec;
import wt.epm.EPMDocument;
import wt.epm.familytable.EPMSepFamilyTable;
import wt.epm.retriever.FamilyTableHelper;
import wt.epm.retriever.FamilyTableResult;
import wt.epm.retriever.LastFoundIteration;
import wt.epm.retriever.LatestConfigSpecWithoutWorkingCopies;
import wt.epm.structure.EPMReferenceLink;
import wt.epm.workspaces.EPMWorkspace;
import wt.fc.ObjectIdentifier;
import wt.fc.ObjectToObjectLink;
import wt.fc.ObjectVector;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.collections.WTArrayList;
import wt.fc.collections.WTCollection;
import wt.fc.collections.WTHashSet;
import wt.fc.collections.WTKeyedMap;
import wt.filter.FilterCache;
import wt.filter.FilteredStatus;
import wt.filter.NavigationCriteria;
import wt.filter.NavigationFilter2;
import wt.filter.NavigationFilterDelegate2;
import wt.filter.NavigationFilterDelegateFactory;
import wt.inf.container.WTContainer;
import wt.navigation.CADProximityPathFilter;
import wt.navigation.CollectedResultValidator;
import wt.navigation.CollectionRequest;
import wt.navigation.DTRequest;
import wt.navigation.DependencyHelper;
import wt.navigation.NavigatedGraph;
import wt.navigation.NavigationMarker;
import wt.navigation.NavigationMarkerCache;
import wt.navigation.NavigationUnit;
import wt.navigation.PartProximityPathFilter;
import wt.navigation.ReplaceIterationWithMasterEndNodeTag;
import wt.navigation.VirtualPathFilteredStatusModifier;
import wt.org.WTUser;
import wt.part.WTPart;
import wt.part.WTPartConfigSpec;
import wt.part.WTPartReferenceLink;
import wt.part.WTPartUsageLink;
import wt.preference.PreferenceHelper;
import wt.projmgmt.admin.Project2;
import wt.query.QuerySpec;
import wt.sandbox.SandboxConfigSpec;
import wt.util.Evolvable;
import wt.util.WTAttributeNameIfc;
import wt.util.WTContext;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.WTPropertyVetoException;
import wt.vc.Iterated;
import wt.vc.Mastered;
import wt.vc.config.ConfigSpec;
import wt.vc.config.LatestConfigSpec;
import wt.vc.wip.WorkInProgressHelper;

/**
 *
 * <BR>
 * <BR>
 * <B>Supported API: </B>false <BR>
 * <BR>
 * <B>Extendable: </B>false
 *
 * @version 1.0
 **/
public class UICollector implements Evolvable {
    static final long serialVersionUID = 1;

    public static final long EXTERNALIZATION_VERSION_UID = 3614648120700176951L;

    private static final String CLASSNAME = UICollector.class.getName();

    private String id;

    private Map collectedFTVersions;

    private int request;

    private Map<Object, String> dictionary;

    private long counter;

    private CollectorResult crData = null;

    private Map ftMembers;

    private Map foundRelations;

    private Map missedRelations;

    private Set noDependents;

    private Set checkedDependents;

    private Set tracedDependents;

    private CollectorSrvCache cache;

    final private ConfigSpec latestConfigSpec = new LatestConfigSpec();

    final private static Log log = LogFactory.getLog(UICollector.class);

    final private static String resource = "com.ptc.core.htmlcomp.htmlcompResource";

    private Boolean ignoreESRResultRules;

    private boolean isExecuted = false,
            hasUnresolvedObjects = false,
            isCollectLinks = false,
            isMissedDependenciesEnabled = false,
            isUseLatestVersionForDuplicatedSeedMaster = false,
            isIgnoreContainerScope = false,
            isIgnoreObjectsInOtherContexts = false,
            ignoreND = false,
            isCollector = false,
            isRecursion = true,
            isWhereUsed = true,
            wrkCanBeCreatedOlyInEPMWorkspace = true,
            isDrawingTracingIgnored = false,
            isOnlyDrawingRequest = true,
            isRequiredIBRulesIgnored = false;

    private String componentID,
            seedsValidator;

    private Object sValidator;

    private ConfigSpecHolder configSpecs;

    private WTContainer container;

    private EPMWorkspace ws;

    private CollectionContext context;

    private FilteredStatus visibleFilteredStatus;

    private Set rff, ut;

    private Locale locale;

    private long[][] times;

    private static String ALL = CollectionKind.SCOPE_ALL,
            NONE = CollectionKind.SCOPE_NONE,
            SEEDS = CollectionKind.SCOPE_SEEDS,
            DRAWINGS = CollectorDefinitionIDS.RELATED_DRAWINGS,
            CALCULATED_DRAWINGS = CollectorDefinitionIDS.CALCULATED_DRAWINGS,
            OLD_REQUIRED_DEPENDENTS = CollectorDefinitionIDS.REQUIRED_DEPENDENTS,
            NEW_REQUIRED_DEPENDENTS = CollectorDefinitionIDS.NEW_REQUIRED_DEPENDENTS,
            REQUIRED_DEPENDENTS = CollectionSrvHelper.isESREnabled ? NEW_REQUIRED_DEPENDENTS : OLD_REQUIRED_DEPENDENTS,
            REQUIRED_MEMBER_DEPENDENTS = CollectorDefinitionIDS.REQUIRED_MEMBER_DEPENDENTS,
            REQUIRED_REF_DEPENDENTS = CollectorDefinitionIDS.REQUIRED_REF_DEPENDENTS,
            REQUIRED_VARIANT_DEPENDENTS = CollectorDefinitionIDS.REQUIRED_VARIANT_DEPENDENTS,
            OLD_OPTIONAL_DEPENDENTS = CollectorDefinitionIDS.OPTIONAL_DEPENDENTS,
            NEW_OPTIONAL_DEPENDENTS = CollectorDefinitionIDS.NEW_OPTIONAL_DEPENDENTS,
            OPTIONAL_DEPENDENTS = CollectionSrvHelper.isESREnabled ? NEW_OPTIONAL_DEPENDENTS : OLD_OPTIONAL_DEPENDENTS,
            OPTIONAL_MEMBER_DEPENDENTS = CollectorDefinitionIDS.OPTIONAL_MEMBER_DEPENDENTS,
            OPTIONAL_REF_DEPENDENTS = CollectorDefinitionIDS.OPTIONAL_REF_DEPENDENTS,
            OPTIONAL_VARIANT_DEPENDENTS = CollectorDefinitionIDS.OPTIONAL_VARIANT_DEPENDENTS,
            RELATED_CADDOCS = CollectorDefinitionIDS.WTPART_RELATED_CADDOCS,
            RELATED_WTPARTS = CollectorDefinitionIDS.CAD_RELATED_WTPARTS,
            WTPART_DEPENDENTS = "WTPART_DEPENDENTS",
            FAMILY = CollectorDefinitionIDS.FAMILY,
            INSEPARABLE_FAMILY = CollectorDefinitionIDS.INSEPARABLE_FAMILY,
            FAMILY_INSTANCES = CollectorDefinitionIDS.FAMILY_INSTANCES,
            FAMILY_GENERICS = CollectorDefinitionIDS.FAMILY_GENERICS,
            UPSTREAM_DERIVED = "UPSTREAM_DERIVED",
            DOWNSTREAM_DERIVED = "DOWNSTREAM_DERIVED",
            EXCLUDE_NON_LATEST_DRAWINGS = CollectorDefinitionIDS.EXCLUDE_NON_LATEST_DRAWINGS,
            CENTRIC = "CENTRIC",
            CHECKOUT_ACTION = "Checkout",
            ADD2WS_ACTION = "Download",
            UPDATE_ACTION = "Update",
            RR_ACTION = "RelationshipReport",
            WU_ACTION = "WhereUsedReport",
            INITIAL_SEEDS = "S@",
            PROCESS_PLAN = "GWT_RECURSIVE_OPERATION_HOLDER_ASSOCIATIONS",
            SEND_TO_PDM = "SBSendToPdm",
            WTPART_WHERE_USED = "WTPART_WHERE_USED",
            CAD_WHERE_USED = "CAD_WHERE_USED";

    private static int FAMILY_KIND = CollectionKind.FAMILY,
            INSEPARABLE_FAMILY_KIND = CollectionKind.INSEPARABLE_FAMILY,
            OPTIONAL_DEPENDENTS_KIND = CollectionKind.OPTIONAL_DEPENDENTS,
            FAMILY_INSTANCES_KIND = CollectionKind.FAMILY_INSTANCES,
            FAMILY_GENERICS_KIND = CollectionKind.FAMILY_GENERICS,
            REQUIRED_VARIANT_DEPENDENTS_KIND = CollectionKind.REQUIRED_VARIANT_DEPENDENTS,
            RELATED_CADDOCS_KIND = CollectionKind.RELATED_CADDOCS,
            RELATED_WTPARTS_KIND = CollectionKind.CAD_RELATED_WTPARTS;

    /**
     * Writes the non-transient fields of this class to an external source.
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     *
     * @param output
     * @exception java.io.IOException
     **/
    @Override
    public void writeExternal(ObjectOutput output) throws IOException {
        long time = System.currentTimeMillis();

        output.writeLong(EXTERNALIZATION_VERSION_UID);
        output.writeObject(checkedDependents);
        output.writeObject(collectedFTVersions);
        output.writeObject(foundRelations);
        output.writeObject(ftMembers);
        output.writeObject(id);
        output.writeObject(missedRelations);
        output.writeObject(noDependents);
        output.writeInt(request);
        output.writeObject(tracedDependents);
        output.writeLong(counter);
        output.writeObject(dictionary);
        output.writeObject(ignoreESRResultRules);
        output.writeObject(ut);
        writeCache(output, cache);

        elapsedTime(time, "writeExternal");
    }

    /**
     * Serialize collector cache in a special way to bypass Evolvable checks in POM.<br>
     * Collector cache content is short lived and not required to be Evolvable.<br>
     * Convert cache to byte array and serialize to avoid Not Evolvable warnings.
     *
     * @param output
     *            POM output stream
     * @param obj
     *            cache object to serialize
     * @throws IOException
     *             if cannot make it
     */
    private final static void writeCache(final ObjectOutput output, final CollectorSrvCache obj) throws IOException {
        if (obj != null) {
            final ByteArrayOutputStream bos = new ByteArrayOutputStream();
            final ObjectOutputStream oos = new ObjectOutputStream(bos);
            oos.writeObject(obj);
            oos.flush();
            oos.close();
            bos.close();
            output.writeObject(bos.toByteArray());
        }
        else {
            output.writeObject(null);
        }
    }

    /**
     * Deserialize cache in a special way needed to bypass Evolvable checks in POM.<br>
     * Restore cache from byte array.
     *
     * @param input
     *            POM input stream
     * @return cache restored object
     * @throws IOException
     *             if cannot make it
     * @throws ClassNotFoundException
     *             in other trouble
     */
    private final static CollectorSrvCache readCache(final ObjectInput input)
            throws IOException, ClassNotFoundException {
        Object obj = input.readObject();
        if (obj instanceof byte[]) {
            final byte[] byteArray = (byte[]) obj;
            final ByteArrayInputStream bis = new ByteArrayInputStream(byteArray);
            final ObjectInputStream ois = new ObjectInputStream(bis);
            obj = ois.readObject();
            bis.close();
            ois.close();
        }
        return (CollectorSrvCache) obj;
    }

    /**
     * Reads the non-transient fields of this class from an external source.
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     *
     * @param input
     * @exception java.io.IOException
     * @exception java.lang.ClassNotFoundException
     **/
    @Override
    public void readExternal(ObjectInput input)
            throws IOException, ClassNotFoundException {
        long time = System.currentTimeMillis();
        try {
            input.readLong();
            checkedDependents = (Set) input.readObject();
            collectedFTVersions = (Map) input.readObject();
            foundRelations = (Map) input.readObject();
            ftMembers = (Map) input.readObject();
            id = (String) input.readObject();
            missedRelations = (Map) input.readObject();
            noDependents = (Set) input.readObject();
            request = input.readInt();
            tracedDependents = (Set) input.readObject();
            counter = input.readLong();
            dictionary = (Map) input.readObject();
            ignoreESRResultRules = (Boolean) input.readObject();
            ut = (Set) input.readObject();
            cache = readCache(input);
        } catch (Exception e) {
            if (log.isTraceEnabled()) {
                CollectionSrvHelper.getStackTrace(e, log);
            }
            releaseParameters(true);
        }
        elapsedTime(time, "readExternal");
    }

    /**
     * Gets the value of the attribute: id.
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     *
     * @return String
     **/
    public String getId() {
        return id;
    }

    /**
     * Sets the value of the attribute: id.
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     *
     * @param a_Id
     * @exception wt.util.WTPropertyVetoException
     **/
    public void setId(String a_Id)
            throws WTPropertyVetoException {
        idValidate(a_Id); // throws exception if not valid
        id = a_Id;
    }

    /**
     * @param a_Id
     * @exception wt.util.WTPropertyVetoException
     **/
    private void idValidate(String a_Id)
            throws WTPropertyVetoException {
        if (a_Id != null && a_Id.length() > 200) { // upper limit check
            Object[] args = { new wt.introspection.PropertyDisplayName(CLASSNAME, "id"), "200" };
            throw new WTPropertyVetoException("wt.introspection.introspectionResource",
                    wt.introspection.introspectionResource.UPPER_LIMIT, args,
                    new java.beans.PropertyChangeEvent(this, "id", id, a_Id));
        }
    }

    /**
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     *
     * @param collectionRules
     * @return UICollector
     * @exception wt.util.WTException
     **/
    public static UICollector newUICollector(List collectionRules)
            throws WTException {
        return new UICollector();
    }

    /**
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     *
     * @param context
     * @param seedsValidator
     * @param configSpecs
     * @param collectionRules
     * @param collectionsToExecute
     * @param collectionsToAdd
     * @param collectionDefinitionModifiers
     * @exception wt.util.WTException
     **/
    public void setup(CollectionContext context, String seedsValidator, ConfigSpecHolder configSpecs,
            Collection collectionRules, Collection collectionsToExecute, Collection collectionsToAdd,
            List<String> collectionDefinitionModifiers)
            throws WTException {
        if (context == null) {
            throw new IllegalArgumentException("Context is null");
        }

        ArrayList params = new ArrayList();
        params.add(context);
        params.add(seedsValidator);
        params.add(configSpecs);
        params.add(collectionRules);
        params.add(collectionsToExecute);
        params.add(collectionsToAdd);
        params.add(collectionDefinitionModifiers);
        WTContext.getContext().put(getId(), params);
    }

    /**
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     *
     * @exception wt.util.WTException
     **/
    public void resetCollection()
            throws WTException {
        request = 0;
        counter = 0;
        dictionary = null;
        boolean isFilterAndMarkerCacheByValueEnabled = cache == null ? false
                : cache.isFilterAndMarkerCacheByValueEnabled();
        // Map cachedParams = cache==null?null:cache.getCachedParameters();//MPMLink workaround
        cache = new CollectorSrvCache();
        cache.setFilterAndMarkerCacheByValueEnabled(isFilterAndMarkerCacheByValueEnabled);
        // cache.setCachedParameters(cachedParams);//MPMLink workaround
        collectedFTVersions = null;
        ftMembers = null;
        foundRelations = null;
        missedRelations = null;
        noDependents = null;
        checkedDependents = null;
        tracedDependents = null;
        ut = null;
    }

    /**
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     *
     * @param isQuickSearch
     * @return CollectorResult
     * @exception wt.util.WTException
     **/
    public CollectorResult collect(boolean isQuickSearch)
            throws WTException {
        ArrayList params = (ArrayList) WTContext.getContext().get(getId());

        if (params == null) {
            throw new IllegalArgumentException("Parameters for " + getId() + " are not defined");
        }

        context = (CollectionContext) params.get(0);
        seedsValidator = (String) params.get(1);
        configSpecs = (ConfigSpecHolder) params.get(2);
        List collectionRules = (List) params.get(3);
        List collectionsToExecute = (List) params.get(4);
        List collectionsToAdd = (List) params.get(5);

        WTContext.getContext().remove(getId());

        return collect(context, seedsValidator, configSpecs, collectionRules, collectionsToExecute, collectionsToAdd,
                isQuickSearch);
    }

    /*
     * Purpose :- Traverse the Structure of Owner associated object of all seeds and collect related objects Note :- No
     * Of Arguments will be reduced once this class is redesigned Returns :- true/false
     */
    public boolean getRelatedOthersideObjects(WTCollection seeds, WTCollection wtCollectedObjects,
            HashMap executedKinds,
            HashMap allKinds, HashSet forcedKinds, HashMap addKinds, HashMap processed, HashMap processedExecutedKinds,
            HashSet wsObjs, HashSet ignoreToAdd, Map types, Set initSeeds, NavigationCriteria filter,
            CollectorResult collectedData, WTCollection dependents) throws WTException {

        boolean isOk = true;
        boolean isPartCentric = (context.getCentricityType() == WTPart.class);
        long time = System.currentTimeMillis();
        WTCollection relatedDependents = new WTHashSet();
        CollectionConfig installedConfig = CollectionSrvHelper.getInstalledCollectionConfig(),
                customConfig = CollectionSrvHelper.getCustomCollectionConfig();

        try {
            WTCollection inputSeeds = new WTHashSet(
                    seeds.subCollection(isPartCentric ? EPMDocument.class : WTPart.class, true)
                            .persistableCollection());

            for (Iterator i = inputSeeds.persistableIterator(); i.hasNext();) {
                if (tracedDependents.contains(
                        getKey(PersistenceHelper.getObjectIdentifier((Persistable) i.next()), CENTRIC))) {
                    i.remove();
                }
            }

            WTKeyedMap relatedMap = null;
            CollectorSrvCache localCache = new CollectorSrvCache();
            if (!inputSeeds.isEmpty()) {
                relatedMap = CollectionSrvHelper.getNestedDependentsMap(
                        (isPartCentric ? RELATED_WTPARTS : RELATED_CADDOCS), wtCollectedObjects, ftMembers,
                        inputSeeds, ws, container, null, isIgnoreObjectsInOtherContexts, true, localCache);
            }

            if (relatedMap != null && !relatedMap.isEmpty()) {

                HashSet hiddenRelated = null;
                boolean isOptional = executedKinds.containsKey(OPTIONAL_DEPENDENTS);
                for (Iterator i = relatedMap.wtKeySet().persistableIterator(); i.hasNext();) {
                    Persistable seed = (Persistable) i.next();
                    Collection allAssociated = (Collection) relatedMap.get(seed);

                    // nmarne:Start:- Get only one(Lowest BuildRuleId) owner associated otherside object
                    if (allAssociated != null && !allAssociated.isEmpty()) {
                        HashMap<Iterated, Persistable> associatedLinkMap = new HashMap<>();
                        for (Object associated : allAssociated) {
                            Persistable link = CollectionSrvHelper.getAssociationLink(localCache.getColID(), localCache,
                                    (Iterated) seed,
                                    (Iterated) associated);
                            if (link != null && CollectionSrvHelper.isOwnerAssociation(link)) {
                                associatedLinkMap.put((Iterated) associated, link);
                            }
                        }
                        Persistable preferredAssociated = getPreferredAssociated(
                                associatedLinkMap);

                        if (hiddenRelated == null) {
                            hiddenRelated = new HashSet();
                        }
                        if (preferredAssociated != null) {
                            hiddenRelated.add(PersistenceHelper.getObjectIdentifier(preferredAssociated));
                            // Replace other associated, as we are only interested in oldest owner
                            // association.

                            relatedMap.replace(seed, new HashSet(Arrays.asList(preferredAssociated)));
                        }
                    }
                    // End:- Get only one(Lowest BuildRuleId) owner associated otherside object
                }

                if (hiddenRelated != null && !hiddenRelated.isEmpty()) {
                    HashMap executedCentricKinds = new HashMap();
                    if (isPartCentric) {
                        addForcedKind(WTPART_DEPENDENTS, allKinds, executedKinds, executedCentricKinds,
                                forcedKinds);
                        addForcedKind(RELATED_CADDOCS, allKinds, executedKinds, executedCentricKinds,
                                forcedKinds);
                    }
                    else {
                        addForcedKind(isOptional ? OPTIONAL_DEPENDENTS : REQUIRED_DEPENDENTS, allKinds,
                                executedKinds, executedCentricKinds, forcedKinds);
                        addForcedKind(isOptional ? OPTIONAL_MEMBER_DEPENDENTS : REQUIRED_MEMBER_DEPENDENTS,
                                allKinds, executedKinds, executedCentricKinds, forcedKinds);
                        addForcedKind(isOptional ? OPTIONAL_REF_DEPENDENTS : REQUIRED_REF_DEPENDENTS,
                                allKinds, executedKinds, executedCentricKinds, forcedKinds);
                        addForcedKind(
                                isOptional ? OPTIONAL_VARIANT_DEPENDENTS : REQUIRED_VARIANT_DEPENDENTS,
                                allKinds, executedKinds, executedCentricKinds, forcedKinds);
                        addForcedKind(RELATED_WTPARTS, allKinds, executedKinds, executedCentricKinds,
                                forcedKinds);
                    }

                    if (log.isTraceEnabled()) {
                        CollectionSrvHelper.trace("Centric seeds", null, hiddenRelated, log);
                    }

                    time = System.currentTimeMillis();
                    relatedDependents = new WTHashSet(hiddenRelated);
                    // We want to collect links for this collection only
                    boolean isCollectLinksTemp = isCollectLinks;
                    isCollectLinks = true;
                    isOk = getDependents(executedCentricKinds, addKinds, allKinds,
                            new WTHashSet(hiddenRelated), relatedDependents, false, installedConfig,
                            customConfig, processed, processedExecutedKinds, ignoreToAdd, forcedKinds,
                            wsObjs, wtCollectedObjects, types, initSeeds, filter, null);
                    isCollectLinks = isCollectLinksTemp;

                    if (log.isDebugEnabled()) {
                        log.debug("<<Centric " + (forcedKinds.size() == 2 ? "quick" : "main") + " request["
                                + hiddenRelated.size() + "," + dependents.size() + ","
                                + (System.currentTimeMillis() - time) + "] " + log.freeMem());
                    }
                }

                if (!relatedDependents.isEmpty()
                        && processed.get(isPartCentric ? RELATED_CADDOCS : RELATED_WTPARTS) != null) {
                    String depColDefId = isPartCentric ? WTPART_DEPENDENTS : REQUIRED_DEPENDENTS;
                    if (!isPartCentric && isOptional) {
                        depColDefId = OPTIONAL_DEPENDENTS;
                    }

                    if (processed.containsKey(depColDefId)) {
                        ResultGraph depGraph = ((CollectionDefinition) processed.get(depColDefId))
                                .getResultGraph();
                        int depAsKey = ((CollectionKind) allKinds.get(depColDefId)).getCollectedAsKey();
                        ResultGraph assGraph = ((CollectionDefinition) processed
                                .get(isPartCentric ? RELATED_CADDOCS : RELATED_WTPARTS)).getResultGraph();
                        boolean includeDependents = executedKinds.containsKey(depColDefId);

                        Map associatedMap = new HashMap();
                        for (Iterator i = relatedDependents.persistableIterator(); i.hasNext();) {
                            Iterated dependent = (Iterated) i.next();
                            Collection nested = assGraph.getNestedRelated(dependent, false, null, cache);
                            addAssociated(associatedMap, dependent, nested);
                        }

                        for (Iterator i = relatedMap.wtKeySet().persistableIterator(); i.hasNext();) {
                            Iterated dependent = (Iterated) i.next();
                            Iterated associated = (Iterated) ((HashSet) relatedMap.get(dependent))
                                    .iterator().next();
                            // Remove other associated with seed as only owner associated is to be
                            // considered
                            associatedMap.remove(dependent);
                            addAssociated(associatedMap, dependent,
                                    Arrays.asList(new Iterated[] { associated }));
                        }

                        for (Iterator i = relatedMap.wtKeySet().persistableIterator(); i.hasNext();) {
                            Iterated s = (Iterated) i.next();
                            traceCentric(s, depAsKey, depGraph, includeDependents, dependents,
                                    associatedMap, collectedData, new WTHashSet(), false,
                                    CollectionSrvHelper.isConsiderOwnerAssociationOnly);
                        }

                        wtCollectedObjects.addAll(dependents);
                    }
                }
            }
        } catch (WTException e) {
            CollectionSrvHelper.getStackTrace(e, log);
            isOk = false;
        }

        return isOk;
    }

    public CollectorResult collect(CollectionContext acontext, String aseedsValidator, ConfigSpecHolder aconfigSpecs,
            Collection collectionRules, Collection collectionsToExecute, Collection collectionsToAdd,
            boolean isQuickSearch) throws WTException {
        CollectorResult collectedData = null;
        CollectionConfig installedConfig = null, customConfig = null;
        Set<String> featuresToSkipCaching = new HashSet<>();

        try {
            long time = System.currentTimeMillis();

            context = acontext;
            seedsValidator = aseedsValidator;
            configSpecs = aconfigSpecs;
            locale = context.getLocale();
            NavigationCriteria filter = configSpecs == null
                    || configSpecs.getConfigSpecs(NavigationCriteria.class) == null ? null
                            : (NavigationCriteria) configSpecs.getConfigSpecs(NavigationCriteria.class).get(0);
            isUseLatestVersionForDuplicatedSeedMaster = context.isUseLatestVersionForDuplicatedSeedMaster();
            boolean isPartCentric = (context.getCentricityType() == WTPart.class);
            boolean isUseCentricity = context.isUseCentricity();
            boolean isRefilteringEnabled = context.isRefilteringEnabled();
            boolean isLightReturnEnabled = context.isLightReturnEnabled();
            isIgnoreObjectsInOtherContexts = context.isIgnoreObjectsInOtherContexts();
            isIgnoreContainerScope = context.isIgnoreContainerScope();
            isCollectLinks = context.isCollectLinks();
            boolean isIgnoreFilteredStatusEnabled = !isCollectLinks;
            visibleFilteredStatus = context.getVisibleFilteredStatus();
            if (visibleFilteredStatus.equals(FilteredStatus.NOT_FILTERED)) {
                visibleFilteredStatus = FilteredStatus.NOT_FILTERED_NO_TRAVERSE;
            }
            container = !isIgnoreContainerScope ? (WTContainer) context.getContainer() : null;
            CollectedResultValidator crValidator = context.getCollectedResultValidator();
            ws = context.getWorkspace();
            if (ws == null && filter != null) {
                List<ConfigSpec> specs = filter.getConfigSpecs();
                if (specs != null && !specs.isEmpty()) {
                    for (ConfigSpec spec : specs) {
                        Object[] objs = CollectionSrvHelper.getWorkspaceByConfigSpec(spec);
                        if (objs[0] != null) {
                            ws = (EPMWorkspace) objs[0];
                            if (container == null) {
                                container = (WTContainer) objs[1];
                            }
                            break;
                        }
                    }
                }
            }
            Collection originalSeeds = context.getSeeds();
            componentID = (String) context.getValue(CollectionSrvHelper.COMPONENT_ID);
            String componentChunk = (String) context.getValue(CollectionSrvHelper.COMPONENT_CHUNK);
            String componentLimit = (String) context.getValue(CollectionSrvHelper.COMPONENT_LIMIT);
            if (componentChunk == null && componentLimit == null) {
                componentLimit = CollectionSrvHelper.getDependencyLimitProperty();
            }

            if (context == null) {
                throw new IllegalArgumentException("Context is null");
            }

            if (collectionRules == null) {
                throw new IllegalArgumentException("Rule values are not defined");
            }

            if (collectionRules.isEmpty() && log.isTraceEnabled()) {
                log.trace("No Rule values");
            }

            if (originalSeeds == null) {
                throw new IllegalArgumentException("Seeds are not defined");
            }
            request++;

            WTCollection wtCollectedObjects = new WTHashSet();

            if (request == 1 || cache == null) {
                if (request > 1) {
                    log.error("Collect input:" +
                            "\n\tid=" + getId() +
                            "\n\trequest=" + request +
                            "\n\tcache=lost");
                    request = 1;
                }

                collectedFTVersions = new HashMap();
                ftMembers = new HashMap();
                foundRelations = new HashMap();
                missedRelations = new HashMap();
                noDependents = new HashSet();
                checkedDependents = new HashSet();
                tracedDependents = new HashSet();
                dictionary = new HashMap();
                if (cache == null) {
                    cache = new CollectorSrvCache();
                }
                cache.setExpandedAll(false);
                CollectorCacheServerHelper.removeCr(getId());
            }

            cache.setRequest(request);
            cache.setComponentID(componentID);
            if (componentID == null) {
                isIgnoreFilteredStatusEnabled = false;
            }
            cache.setAccessControlWarningEnabled(CollectionSrvHelper.isAccessControlWarningsEnabled ? true
                    : context.isAccessControlWarningsEnabled());
            if (componentLimit != null) {
                cache.setInputParameter(CollectionSrvHelper.COMPONENT_LIMIT, componentLimit);
            }
            if (componentChunk != null) {
                cache.setInputParameter(CollectionSrvHelper.COMPONENT_CHUNK, componentChunk);
            }
            Object par = context.getValue(CollectionRequest.WTPART_ALTERNATE_REP);
            if (par != null) {
                ObjectIdentifier parID = null;
                if (par instanceof Persistable) {
                    parID = PersistenceHelper.getObjectIdentifier((Persistable) par);
                }
                else if (par instanceof ObjectIdentifier) {
                    parID = (ObjectIdentifier) par;
                }

                if (parID != null) {
                    cache.setWTPartAlternateRepID(parID);
                }
            }
            Map inputParams = (Map) context.getValue(CollectionSrvHelper.INPUT_PARAMS);
            if (inputParams != null) {
                boolean isWTPartAlternateRep = cache.getWTPartAlternateRep() != null;
                for (Map.Entry<String, Object> param : (Collection<Map.Entry<String, Object>>) inputParams.entrySet()) {
                    String key = param.getKey();
                    Object value = param.getValue();
                    cache.setInputParameter(key, value);
                    if (!isWTPartAlternateRep && value instanceof ObjectIdentifier
                            && key.equals(CollectionRequest.WTPART_ALTERNATE_REP)) {
                        cache.setWTPartAlternateRepID((ObjectIdentifier) value);
                    }
                }
            }

            Object stdOperationInfo = context.getValue(CollectionRequest.STANDARD_OPERATIONS_INFO);
            if (stdOperationInfo != null) {
                cache.setStdOperationInfo((String) stdOperationInfo);
            }
            hasUnresolvedObjects = false;
            Map types = new HashMap();
            cacheValue(CollectionSrvHelper.COMPONENT_LID, context);
            cacheValue(CollectionSrvHelper.COMPONENT_NDI, context);
            cacheValue(CollectionRequest.COMPONENT_IDENTIFIERS, context);

            boolean isWorkspaceScope = CollectionSrvHelper.isWorkspaceScope(ws,
                    (configSpecs == null ? null : configSpecs.getConfigSpecs(EPMDocument.class)));

            isMissedDependenciesEnabled = CollectionSrvHelper.isMissedDependenciesWarningEnabled && !isWorkspaceScope
                    && componentID != null
                    && (componentID.equals(CHECKOUT_ACTION) || componentID.equals(ADD2WS_ACTION));
            if (isMissedDependenciesEnabled) {
                cache.setMissedDependentsWarningEnabled(true);
            }

            NavigationMarker marker = context.getNavigationMarker();
            if (marker != null) {
                isIgnoreFilteredStatusEnabled = false;
            }
            cache.setNavigationCriteria(filter);
            cache.setIncludeLinks(isCollectLinks);
            cache.setNavigationMarker(marker);
            cache.setMarkingPreparationEnabled(marker != null);
            rff = null;
            if (componentID != null && componentID.equals(SEND_TO_PDM) && !isCollectLinks) {
                if (rff == null) {
                    rff = new HashSet();
                }
                rff.add(CollectionRequest.APPLY_FILTER_BY_LATEST_ITERATION_FEATURE);
            }
            if (marker != null && marker.getRequiredCollectionModifiers() != null
                    && marker.getRequiredCollectionModifiers().length > 0 && !cache.getExpandedAll()) {
                rff = new HashSet();
                setRequiredModifiers(cache.getNavigationMarker().getRequiredCollectionModifiers(), rff);
            }
            if (filter != null && filter.getFilters() != null && !filter.getFilters().isEmpty()) {
                isIgnoreFilteredStatusEnabled = false;
                if (rff == null) {
                    rff = new HashSet();
                }
                for (NavigationFilter2 navFilter : filter.getFilters()) {
                    NavigationFilterDelegate2 delegate = new NavigationFilterDelegateFactory().getDelegate(navFilter);
                    if (delegate != null) {
                        setRequiredModifiers(delegate.getRequiredCollectionModifiers(navFilter), rff);
                    }

                    if (navFilter instanceof CADProximityPathFilter) {
                        cache.setInputParameter(CollectionSrvHelper.COMPONENT_NDI,
                                ((CADProximityPathFilter) navFilter).getProximityNDIdentifiers());
                    }
                    else if (navFilter instanceof PartProximityPathFilter) {
                        cache.setInputParameter(CollectionSrvHelper.COMPONENT_LID, DependencyHelper.convert(
                                ((PartProximityPathFilter) navFilter).getProximityPathOccurrenceIdentifiers()));
                    }
                }
            }

            if (rff != null && rff.isEmpty()) {
                rff = null;
            }
            if (isCollectLinks && rff != null && (rff.contains(CollectionRequest.TRACE_BY_PATH_FEATURE)
                    || rff.contains(CollectionRequest.WTPART_PATH_OCCURRENCE_FEATURE))) {
                isCollector = false;
            }
            if (isCollectLinks && componentID != null && componentID.equals(RR_ACTION)) {
                cache.setIsLinkDepType(true);
            }
            if (componentID != null && !CollectionSrvHelper
                    .isFeatureEnabled(CollectionRequest.DO_NOT_IGNORE_OPTIONAL_DUMMY_DEPENDENTS, componentID, rff)
                    && (!isCollectLinks || componentID.equals(RR_ACTION))) {
                cache.setIsExcludeOptionalDummyDepType(true);
            }
            if (configSpecs == null && rff != null
                    && !rff.contains(CollectionRequest.USE_CACHE_WITHOUT_TRACING_AND_FILTERING)) {
                throw new IllegalArgumentException("Config specs are not defined");
            }
            Set<NavigationFilter2> vfs = context.getInvisibleFilters();
            if (vfs != null && !vfs.isEmpty()) {
                cache.setInputParameter(CollectionSrvHelper.INVISIBLE_FILTERS, vfs);
                for (NavigationFilter2 vf : vfs) {
                    cache.setInputParameter(vf.getFilterType(), vf);
                }
            }

            Map<String, Object> ps = (Map<String, Object>) context.getValue(CollectorDefinitionIDS.QUERIES_PARAMS);
            if (ps != null) {
                for (Map.Entry<String, Object> entry : ps.entrySet()) {
                    String k = entry.getKey();
                    Object v = cache.getInputParameter(k);
                    if (v != null) {
                        log.warn("Existing parameter " + k + " will be replaced");
                    }
                    cache.setInputParameter(k, entry.getValue());
                }
            }

            List orderToExecute = context.getCollectionsExecutionOrder();
            if (orderToExecute != null && orderToExecute.isEmpty()) {
                orderToExecute = null;
            }

            StringBuffer buf = new StringBuffer();
            String path_ndi = cache.printInputParameter(CollectionSrvHelper.COMPONENT_NDI);

            boolean isCATClient = getId() != null
                    ? isClient("com.ptc.cat.assocnav.server.CollectorServiceAssociationNavigator")
                    : false,
                    isVis = getId() != null ? isClient("com.ptc.wvs.server.loader.NavigationHelper") : false;

            cache.setCollectorId(getId());
            cache.setWVSEnabled(isVis);

            // System.out.println("isVisualiation="+cache.isWVS());

            if (log.isDebugEnabled()) {
                log.debug("Collect input:" +
                        "\n\tisWorkspaceScope=" + isWorkspaceScope +
                        "\n\tid=" + getId() +
                        "\n\trequest=" + request +
                        "\n\tws=" + (ws == null ? "" : ws.getName() + "[" + ws.toString() + "]") +
                        "\n\tcontainer=" + (container == null ? "" : container.toString()) +
                        "\n\tisIgnoreContainerScope=" + isIgnoreContainerScope +
                        "\n\tisIgnoreObjectsInOtherContexts=" + isIgnoreObjectsInOtherContexts +
                        "\n\tisPartCentric=" + isPartCentric +
                        "\n\tisUseCentricity=" + isUseCentricity +
                        "\n\tisUseLatestVersionForDuplicatedSeedMaster=" + isUseLatestVersionForDuplicatedSeedMaster +
                        "\n\tisMissedDependenciesEnabled=" + isMissedDependenciesEnabled +
                        "\n\tisIlEnabled=" + CollectionSrvHelper.isIlEnabled +
                        "\n\tignoreESRResultRules=" + cache.getIgnoreESRResultRules() +
                        "\n\tisGenerationOfMissedPartPathOccurrenceEnabled="
                        + CollectionSrvHelper.isGenerationOfMissedPartPathOccurrenceEnabled +
                        "\n\tisRunTimePathToOccurrenceEnabled=" + CollectionSrvHelper.isRunTimePathToOccurrenceEnabled +
                        "\n\tisCollectLinks=" + isCollectLinks +
                        "\n\tisCollector=" + isCollector +
                        "\n\tisCATClient=" + isCATClient +
                        "\n\tisVisualization=" + isVis +
                        "\n\ttrafoParType="
                        + (CollectionSrvHelper.trafoParType == null ? "" : CollectionSrvHelper.trafoParType) +
                        "\n\tisSuspended=" + cache.isSuspended() +
                        "\n\tisLightReturnEnabled=" + isLightReturnEnabled +
                        "\n\tcollected result validator=" + crValidator +
                        "\n\tisFilterAndMarkerCacheByValueEnabled=" + cache.isFilterAndMarkerCacheByValueEnabled() +
                        "\n\tisAccessControlWarningsEnabled=" + cache.getAccessControlWarningEnabled() +
                        "\n\tpath identifiers=" + cache.printInputParameter(CollectionSrvHelper.COMPONENT_LID) +
                        "\n\tpath ndi=" + path_ndi +
                        "\n\torder to execute=" + (orderToExecute == null ? "default" : orderToExecute) +
                        "\n\tcomponent paths=" + cache.printInputParameter(CollectionRequest.COMPONENT_IDENTIFIERS) +
                        "\n\tisRefilteringEnabled=" + isRefilteringEnabled +
                        "\n\tisCacheOnlyEnabled=" + cache.isCacheOnlyEnabled() +
                        "\n\tvisibleFilteredStatus=" + visibleFilteredStatus +
                        "\n\tvirtual filters=" + (vfs == null ? "" : vfs) +
                        "\n\tnavigation marker=" + marker +
                        "\n\t\tnavigation marker modifiers="
                        + (marker == null || marker.getRequiredCollectionModifiers() == null
                                || marker.getRequiredCollectionModifiers().length == 0 ? null
                                        : marker.getRequiredCollectionModifiers()[0] + "...")
                        +
                        "\n\t\texpanded=" + cache.getExpandedAll() +
                        "\n\t\tmarked=" + cache.getMarkedAll() +
                        "\n\tnavigation criteria=" + filter +
                        (filter == null ? ""
                                : "\n\t\tspecs=" + filter.getConfigSpecs() +
                                        "\n\t\tfilters=" + filter.getFilters() +
                                        "\n\t\tapplicable type=" + filter.getApplicableType() +
                                        "\n\t\ttype=" + filter.getType() +
                                        "\n\t\tisCentricity=" + filter.isCentricity() +
                                        "\n\t\tisUseDefaultForUnresolved=" + filter.isUseDefaultForUnresolved() +
                                        "\n\t\tisApplyToTopLevelObject=" + filter.isApplyToTopLevelObject())
                        +
                        "\n\t\tfilters and marker modifiers=" + rff +
                        "\n\tlocale=" + locale +
                        "\n\tcomponent id=" + componentID +
                        "\n\tut=" + ut +
                        "\n\tisReplaceSeeds="
                        + (configSpecs == null ? "config spec holder is null" : configSpecs.isReplaceSeeds()) +
                        "\n\tcollected FT versions=" + collectedFTVersions.size() +
                        "\n\tcollected objects=" + cache.getCollectedSize() +
                        "\n\tfilters=" + cache.getFilters().keySet() +
                        "\n\t" + configSpecs.toString());
            }

            if (log.isTraceEnabled()) {
                log.trace("\tfilter cache:\n" + cache.getFilters().values());
            }

            ignoreND = false;
            installedConfig = CollectionSrvHelper.getInstalledCollectionConfig();
            customConfig = CollectionSrvHelper.getCustomCollectionConfig();

            if (marker != null) {
                String markerCl = marker.newMarkerCache().getClass().getName();
                NavigationMarker preMarker = context.getPreNavigationMarker(),
                        postMarker = context.getPostNavigationMarker();

                if (log.isDebugEnabled()) {
                    log.debug("Custom markers of " + markerCl + ":" +
                            "\n\tAPI pre marker=" + preMarker +
                            "\n\tAPI post marker=" + postMarker);
                }

                if (preMarker == null) {
                    preMarker = installedConfig.getPreMarker(markerCl);
                    if (log.isDebugEnabled()) {
                        log.debug("Intsalled pre marker=" + preMarker);
                    }
                }

                if (postMarker == null) {
                    postMarker = installedConfig.getPostMarker(markerCl);
                    if (log.isDebugEnabled()) {
                        log.debug("Intsalled post marker=" + postMarker);
                    }
                }

                if (preMarker != null) {
                    cache.setPreNavigationMarker(preMarker);
                }

                if (postMarker != null) {
                    cache.setPostNavigationMarker(postMarker);
                }

                if (log.isDebugEnabled()) {
                    log.debug("\tused pre-marker=" + (preMarker == null ? null : preMarker.getClass().getName()) +
                            "\tused post-marker=" + (postMarker == null ? null : postMarker.getClass().getName()));
                }
            }

            HashMap allKinds = getKinds(collectionRules, "collectionRules", false, false, null, installedConfig),
                    addKinds = getKinds(collectionsToAdd, "collectionsToAdd", true, false, null, installedConfig),
                    executedKinds = getKinds(collectionsToExecute, "collectionsToExecute", true, true, addKinds,
                            installedConfig);
            isOnlyDrawingRequest = executedKinds.size() == 1;
            for (Iterator i = executedKinds.values().iterator(); i.hasNext();) {
                CollectionKind ck = (CollectionKind) i.next();
                String params = ck.getCollectionQueryParameters();
                if (params != null) {
                    cache.addUICollectionQueryParameter(params);
                }
                if (isOnlyDrawingRequest && ck.getCollectedAsKey() != CollectionRequest.CAD_RELATED_DRAWINGS) {
                    isOnlyDrawingRequest = false;
                }

            }

            if ((rff == null || !(rff.contains(CollectionRequest.APPLY_FILTER_BY_LATEST_VERSION_FEATURE)
                    || rff.contains(CollectionRequest.DO_NOT_APPLY_FILTER_BY_LATEST_VERSION_FEATURE)))
                    && CollectionSrvHelper.isDependentsLatestVersionOnly) {
                if (rff == null) {
                    rff = new HashSet();
                }
                rff.add(CollectionRequest.APPLY_FILTER_BY_LATEST_VERSION_FEATURE);
            }

            if (request == 1 && componentChunk != null && cache.getChunk() == 0 && !cache.isSuspended()) {
                boolean isChunking = !isCollectLinks && marker == null && (filter == null
                        || (filter != null && (filter.getFilters() == null || filter.getFilters().isEmpty())));
                if (isChunking) {
                    for (Iterator i = executedKinds.values().iterator(); i.hasNext() && isChunking;) {
                        CollectionKind kind = (CollectionKind) i.next();

                        if (kind.getRecursionLimit() == DTRequest.UNLIMITED_TRACING) {
                            String key = kind.getCollectionServiceKey();
                            CollectionPackage colDefPkg = installedConfig.getPackageByCollectionID(key);
                            CollectionDefinition colDef = colDefPkg == null ? null
                                    : colDefPkg.getCollectionDefinition(key);
                            if (colDef == null) {
                                isChunking = key.equals(REQUIRED_MEMBER_DEPENDENTS)
                                        || key.equals(REQUIRED_REF_DEPENDENTS)
                                        || key.equals(REQUIRED_VARIANT_DEPENDENTS);
                            }
                            else if (colDef.hasRecursionRetriever()) {
                                isChunking = !key.equals(NEW_OPTIONAL_DEPENDENTS);
                            }
                            else {
                                isChunking = false;
                            }
                        }
                        else {
                            isChunking = false;
                        }
                    }
                }

                if (isChunking) {
                    componentLimit = null;
                }
                else {
                    componentChunk = null;
                }
            }
            else if (cache.getExpandedAll()) {
                boolean isProcessPlan = false;
                for (Iterator i = executedKinds.entrySet().iterator(); !isProcessPlan && i.hasNext();) {
                    Map.Entry e = (Map.Entry) i.next();
                    String key = (String) e.getKey();
                    if (key.equals(PROCESS_PLAN)) {
                        CollectionKind ck = (CollectionKind) e.getValue();
                        Set features = ck.getFeatures();
                        if (!features.contains(CollectionRequest.UPDATE_CACHE_DURING_INCREMENTAL_REQUEST)) {
                            ck.addFeature(CollectionRequest.USE_CACHE_WITHOUT_TRACING_AND_FILTERING);
                            log.warn("added " + CollectionRequest.USE_CACHE_WITHOUT_TRACING_AND_FILTERING);
                            cache.setIsCacheOnlyEnabled(true);
                        }
                        else {
                            cache.setIsCacheOnlyEnabled(false);
                        }
                        isProcessPlan = true;
                    }
                }

                /*
                 * if(isProcessPlan) for( Iterator i=executedKinds.keySet().iterator(); i.hasNext(); ) { String key =
                 * (String) i.next(); if( !key.equals(PROCESS_PLAN))
                 *
                 * { log.warn("removed "+key); i.remove(); } }
                 */
            }

            if (componentChunk != null && cache.getChunk() == 0 && !cache.isSuspended()) {
                cache.initChunk(componentChunk);
            }
            if (componentLimit != null && cache.getChunk() == 0) {
                cache.setInputParameter(CollectionSrvHelper.COMPONENT_LIMIT, componentLimit);
            }

            if (cache.isSuspended()) {
                if (log.isDebugEnabled()) {
                    log.debug("increment chunk");
                }
                cache.incrementChunk();
            }

            if (log.isDebugEnabled()) {
                log.debug("\n\tlimit=" + cache.getComponentLimit() +
                        "\n\tchunk=" + cache.getChunk() +
                        "\n\tchunk limit=" + cache.getComponentChunk());
            }

            if (container != null && container instanceof Project2 && isWhereUsed) {
                if (filter != null) {
                    filter = (NavigationCriteria) filter.duplicate();
                    List ss = filter.getConfigSpecs();
                    ss.clear();
                    ss.add(new LastFoundIteration(true));
                    filter.setConfigSpecs(ss);
                    if (log.isDebugEnabled()) {
                        log.debug("where used for project");
                    }
                }
            }

            if (request == 1 && rff != null
                    && rff.contains(CollectionRequest.DO_NOT_AUTO_CONFIGURE_RESULT_RULES_FILTER)) {
                if (ignoreESRResultRules == null) {
                    ignoreESRResultRules = Boolean.TRUE;
                }
            }

            if (ignoreESRResultRules != null) {
                if (rff == null
                        || (rff != null
                                && !rff.contains(CollectionRequest.DO_NOT_AUTO_CONFIGURE_RESULT_RULES_FILTER))) {
                    log.error("Initial request included DO_NOT_AUTO_CONFIGURE_RESULT_RULES_FILTER modifier.");
                }
            }
            else if (rff != null && rff.contains(CollectionRequest.DO_NOT_AUTO_CONFIGURE_RESULT_RULES_FILTER)) {
                log.error(
                        "Initial request did not include DO_NOT_AUTO_CONFIGURE_RESULT_RULES_FILTER modifier. This modifier can not be changed in the incremental request.");
            }

            if (ignoreESRResultRules != null) {
                cache.setIgnoreESRResultRules(ignoreESRResultRules.booleanValue());
            }

            if (log.isDebugEnabled()) {
                log.debug("\tinitial ignoreESRResultRules=" + ignoreESRResultRules + "\n\tcache ignoreESRResultRules="
                        + cache.getIgnoreESRResultRules());
            }

            if (rff != null && cache.isTracingByPath()) {
                rff.add(CollectionRequest.TRACE_BY_PATH_FEATURE);
            }
            cache.setModifiers(rff);
            if (cache.getNavigationMarker() != null && executedKinds != null && !executedKinds.isEmpty()) {
                cache.setMarkerColId(new HashSet(executedKinds.keySet()));
            }

            if (rff != null) {
                isDrawingTracingIgnored = rff.contains(CollectionRequest.DO_NOT_TRACE_COLLECTED_DRAWINGS_FEATURE);
                isRequiredIBRulesIgnored = rff.contains(CollectionRequest.DO_NOT_INCLUDE_IB_RULES_FOR_REQUIRED_FEATURE);
            }

            List scc = CollectorCacheServerHelper.getCr(getId());
            boolean isRecursive = false;
            if (scc != null) {
                boolean isCompatible = false, isResult = false, isLimited = false;
                if (scc.size() < 6) {
                    if (log.isDebugEnabled()) {
                        log.debug(getId() + " includes the different " + scc.size() + " objects ");
                    }
                }
                else {
                    int sr = ((Integer) scc.get(3)).intValue();
                    if (request < sr || (!cache.isSuspended() && !isCollectLinks
                            && ((rff == null && !executedKinds.containsKey(NEW_OPTIONAL_DEPENDENTS)) || (rff != null
                                    && !rff.contains(CollectionRequest.USE_CACHE_WITHOUT_TRACING_AND_FILTERING))))) {

                        if (log.isDebugEnabled()) {
                            if (cache.isSuspended()) {
                                log.debug("chunk started");
                            }
                            else {
                                log.debug(isCollectLinks ? "requests are different: " + sr : "ignore links");
                            }
                        }
                        CollectorCacheServerHelper.removeCr(getId());
                    }
                    else if (!executedKinds.isEmpty()) {
                        Set sm = (Set) scc.get(4);
                        isCompatible = !(rff != null && ((rff.contains(CollectionRequest.WTPART_USES_OCCURRENCE_FEATURE)
                                && (sm == null || !sm.contains(CollectionRequest.WTPART_USES_OCCURRENCE_FEATURE)))
                                || (rff.contains(CollectionRequest.WTPART_PATH_OCCURRENCE_FEATURE) && (sm == null
                                        || !sm.contains(CollectionRequest.WTPART_PATH_OCCURRENCE_FEATURE)))));
                        if ((sm == null && rff == null) || (sm != null && rff != null && (sm.size() == rff.size()
                                || rff.contains(CollectionRequest.USE_CACHE_WITHOUT_TRACING_AND_FILTERING)))) {
                            isResult = true;
                            if (sm != null && rff != null
                                    && !rff.contains(CollectionRequest.USE_CACHE_WITHOUT_TRACING_AND_FILTERING)) {
                                for (Iterator i = sm.iterator(); i.hasNext() && isResult;) {
                                    isResult = rff.contains(i.next());
                                }
                            }

                            if (isResult) {
                                Collection sKinds = (Collection) scc.get(5);
                                if (collectionsToExecute == null || sKinds.size() != executedKinds.size()
                                        || marker != null) {
                                    isResult = false;
                                }
                                else {
                                    for (Iterator i = sKinds.iterator(); isResult && i.hasNext();) {
                                        Object ce = i.next();
                                        if (ce instanceof CollectionKind) {
                                            CollectionKind sk = (CollectionKind) ce;
                                            if (sk.isNavigatedGraphEmpty()) {
                                                isResult = false;
                                            }
                                            else {
                                                CollectionKind k = null;
                                                for (Iterator j = collectionsToExecute.iterator(); j.hasNext()
                                                        && k == null;) {
                                                    Object ek = j.next();
                                                    if (ek instanceof CollectionKind) {
                                                        k = (CollectionKind) ek;
                                                        if (!k.getCollectionServiceKey()
                                                                .equals(sk.getCollectionServiceKey())) {
                                                            k = null;
                                                        }
                                                    }
                                                }

                                                if (k != null) {
                                                    CollectionDefinition colDef = getCollectionDefinition(
                                                            installedConfig, k.getCollectionServiceKey());
                                                    if (colDef != null && colDef.hasRecursionRetriever()) {
                                                        isRecursive = true;
                                                    }
                                                }

                                                if (k == null || k.getRecursionLimit() != DTRequest.UNLIMITED_TRACING) {
                                                    isResult = false;

                                                    if (k != null) {
                                                        isLimited = true;
                                                    }
                                                }
                                            }
                                        }
                                        else {
                                            isResult = false;
                                        }
                                    }
                                }

                                if (!isResult) {
                                    if (log.isDebugEnabled()) {
                                        log.debug("Executed collections are different:\n" + sKinds);
                                    }
                                }
                                else {
                                    Collection ss = cache.getSeeds();
                                    isResult = ss.size() == originalSeeds.size();
                                    for (Iterator i = originalSeeds.iterator(); i.hasNext() && isResult;) {
                                        Object s = i.next();
                                        isResult = ss.contains(s);
                                    }
                                    if (!isResult) {
                                        if (log.isDebugEnabled()) {
                                            log.debug("Seeds are different:\n");
                                        }
                                    }
                                    else if (log.isDebugEnabled() && originalSeeds.size() < 2) {
                                        log.debug(getTracedObjects("\tseeds", originalSeeds));
                                    }
                                }
                            }
                            else {
                                if (log.isDebugEnabled()) {
                                    log.debug("Modifiers are diffirent:\n" + sm + "\n" + rff);
                                }
                            }
                        }
                        else if (log.isDebugEnabled()) {
                            log.debug("Modifiers cannot be compared:\n" + sm + "\n" + rff);
                        }

                    }

                    if (request >= sr) {
                        long ste = ((Long) scc.get(0)).longValue();
                        validateExpired(ste);
                    }
                }

                if (log.isDebugEnabled()) {
                    log.debug("\tisCompatible=" + isCompatible + " isResult=" + isResult + " isRecursion=" + isRecursion
                            + " isLimited=" + isLimited + " isRecursive=" + isRecursive);
                }

                if (isCompatible) {
                    if (isResult) {
                        if (scc.get(1) != null) {
                            if (rff != null
                                    && rff.contains(CollectionRequest.UPDATE_CACHE_DURING_INCREMENTAL_REQUEST)) {
                                if (log.isDebugEnabled()) {
                                    log.debug("result is not returned because of requested retracing");
                                }
                            }
                            else {
                                if (log.isDebugEnabled()) {
                                    log.debug("result should be returned");
                                    // return (CollectorResult) scc.get(1);
                                }
                            }
                        }
                        else if (log.isDebugEnabled()) {
                            log.debug("result is not defined");
                        }
                    }

                    if (scc.get(2) != null) {
                        if (cache.isSuspended()) {
                            cache.setChunkInfo((Object[]) scc.get(2));
                            cache.incrementChunk();
                            if (log.isDebugEnabled()) {
                                log.debug("reuse chunk info");
                            }
                        }
                        else {
                            cache.setDependents((Collection) scc.get(2));
                            if (isRecursion && !isRefilteringEnabled && rff != null
                                    && !rff.contains(CollectionRequest.USE_CACHE_WITHOUT_TRACING_AND_FILTERING)) {
                                rff.add(CollectionRequest.USE_CACHE_WITHOUT_TRACING_AND_FILTERING);
                                featuresToSkipCaching
                                        .add(CollectionRequest.USE_CACHE_WITHOUT_TRACING_AND_FILTERING);
                            }
                            if (log.isDebugEnabled()) {
                                log.debug("dependents are " + (rff != null
                                        && rff.contains(CollectionRequest.USE_CACHE_WITHOUT_TRACING_AND_FILTERING)
                                                ? "reused"
                                                : "returned"));
                            }
                        }
                    }
                    else if (log.isDebugEnabled()) {
                        log.debug("dependents are not defined");
                    }
                }
            }
            else if (cache.isSuspended()) {
                if (log.isDebugEnabled()) {
                    log.debug("inflate chunks info");
                }
                cache.inflateChunk();
            }
            else {
                if (log.isDebugEnabled()) {
                    log.debug("scc=null");
                }
            }

            if (cache.isSuspended()) {
                if (log.isDebugEnabled()) {
                    log.debug("setup chunk seeds");
                }
                originalSeeds = cache.getChunkSeeds();
                cache.wasResumed();
            }

            CollectionKind nrd = (CollectionKind) executedKinds.get(NEW_REQUIRED_DEPENDENTS);
            if (nrd != null && !allKinds.containsKey(NEW_REQUIRED_DEPENDENTS)) {
                allKinds = new HashMap(allKinds);
                allKinds.put(nrd.getCollectionServiceKey(), nrd);
            }

            collectedData = new CollectorResult(allKinds);
            collectedData.setCollectedResultValidator(crValidator);
            collectedData.setCollectorID(getId());
            /*
             * if( log.isDebugEnabled()) collectedData.setProfiler(new long[13][3]);
             */

            WTCollection seeds = getValidSeeds(collectedData, originalSeeds, allKinds, configSpecs, filter);
            if (seeds.isEmpty()) {
                releaseParameters(true);
                restore(new Collection[] { collectionRules, collectionsToExecute, collectionsToAdd });
                return collectedData;
            }
            if (originalSeeds instanceof List) {
                Collection vSeeds = new ArrayList();
                List oSeeds = (List) originalSeeds;
                for (int i = 0; i < oSeeds.size(); i++) {
                    Object seed = oSeeds.get(i);
                    if (seeds.contains(seed)) {
                        vSeeds.add(seed);
                    }
                }
                collectedData.setSeeds(vSeeds);
            }
            else {
                collectedData.setSeeds(seeds.persistableCollection());
            }

            if (cache.getChunk() > 1) {
                collectedData.setChunkSeeds(originalSeeds);
            }

            if (isIgnoreFilteredStatusEnabled && !cache.isEsr()) {
                cache.setIgnoreFilteredStatusEnabled();
                if (log.isDebugEnabled()) {
                    log.debug("isIgnoreFilteredStatusEnabled=" + cache.ignoreFilteredStatusEnabled());
                }
            }

            if (request == 1) {
                if (CollectorCacheServerHelper.isCTEnabled() && getId() == null && path_ndi != null
                        && seeds.size() == 1) {
                    String pathID = path_ndi + seeds.iterator().next().toString();
                    scc = CollectorCacheServerHelper.getCr(pathID);
                    if (scc != null) {
                        Object cr = scc.get(1);
                        if (cr instanceof CollectorResult) {
                            if (log.isDebugEnabled()) {
                                log.debug("found by path id " + pathID);
                            }
                            return (CollectorResult) cr;
                        }
                    }
                }

                cache.setSeeds(seeds.persistableCollection());
            }
            else {
                cache.setIncrementalSeeds(seeds.persistableCollection());
            }

            if (log.isDebugEnabled()) {
                log.debug("\n\tisTrafoStructure=" + cache.isTrafoStructure());
            }

            cache.addLinkSeeds(executedKinds.keySet(), installedConfig);

            cache.setIsRefilteringEnabled(isRefilteringEnabled);
            cache.setInputParameter(EXCLUDE_NON_LATEST_DRAWINGS,
                    PreferenceHelper.service.getValue(EXCLUDE_NON_LATEST_DRAWINGS, (WTContainer) null, (WTUser) null));

            if (filter != null) {
                String at = filter.getApplicableType();
                if (at == null) {
                    if (log.isTraceEnabled()) {
                        log.error("Illegal null value for passed applicable type. Please fix it.");
                        CollectionSrvHelper.getStackTrace(new Throwable(), log);
                    }
                }
                else {
                    try {
                        Class atCl = Class.forName(at);
                        cache.setInputParameter(CollectorDefinitionIDS.NC_APPLICABLE_TYPE_CLASS, atCl);
                    } catch (Exception e) {
                        log.error("Invalid applicable type=" + at + " Please fix it.");
                        CollectionSrvHelper.getStackTrace(new Throwable(), log);
                    }
                }
                Set<Class> cls = new HashSet();
                if (isUseCentricity) {
                    cls.add(isPartCentric ? WTPart.class : EPMDocument.class);
                }
                for (Iterator i = seeds.persistableIterator(); i.hasNext();) {
                    Persistable p = (Persistable) i.next();
                    if (p instanceof Iterated) {
                        cls.add(p.getClass());
                    }
                }

                for (Class cl : cls) {
                    List specs = CollectionSrvHelper.getConfigSpecsByClass(cl, configSpecs.getSpecsMap(), filter,
                            cache);
                    if (specs != null && !specs.isEmpty()) {
                        configSpecs.setConfigSpecs(cl, specs);
                        cache.addSpec(cl, (ConfigSpec) specs.get(0));
                        if (log.isTraceEnabled()) {
                            try {
                                for (int n = 0; n < specs.size(); n++) {
                                    QuerySpec qs = new QuerySpec(cl);
                                    qs = ((ConfigSpec) specs.get(n)).appendSearchCriteria(qs);
                                    log.trace(cl + " " + (n + 1) + ". " + qs.toString());
                                }
                            } catch (Exception e) {
                                CollectionSrvHelper.getStackTrace(e, log);
                            }
                        }
                    }
                }

                List<ConfigSpec> css = filter.getConfigSpecs();
                for (ConfigSpec cs : css) {
                    if (CollectionSrvHelper.isSandboxConfigSpec(cs)) {
                        if (log.isDebugEnabled()) {
                            SandboxConfigSpec sbcs = null;
                            if (cs instanceof EPMDocConfigSpec) {
                                sbcs = ((EPMDocConfigSpec) cs).getSandboxConfig();
                            }
                            else if (cs instanceof WTPartConfigSpec) {
                                sbcs = ((WTPartConfigSpec) cs).getSandbox();
                            }
                            else if (cs instanceof SandboxConfigSpec) {
                                sbcs = (SandboxConfigSpec) cs;
                            }

                            if (sbcs != null) {
                                log.debug("\tinclude personal checkouts=" + sbcs.isIncludePersonalCheckouts() +
                                        "\n\tuse sandbox baseline=" + sbcs.isUseSandboxBaseline() +
                                        "\n\tuser config spec=" + sbcs.getUserConfigSpec());
                            }

                        }

                        cache.setIsSB(true);
                        break;
                    }
                }
                if (container != null && container instanceof Project2 && !cache.isSB()) {
                    log.debug("Project requires sandbox config spec");
                }

            }

            if (configSpecs != null) {
                cache.setConfigSpecMap(configSpecs.getSpecsMap());
            }

            if (log.isDebugEnabled()) {
                cache.setProfiler(new long[34][3]);
            }

            WTCollection dependents = new WTHashSet(), relatedDependents = new WTHashSet();

            if (request > 1 && (cache.isCacheOnlyEnabled()
                    || (cache.getExpandedAll() && (scc == null || (scc != null && isRecursive)) && rff != null
                            && rff.contains(CollectionRequest.USE_CACHE_WITHOUT_TRACING_AND_FILTERING)
                            && !rff.contains(CollectionRequest.UPDATE_CACHE_DURING_INCREMENTAL_REQUEST)))) {
                int vs = visibleFilteredStatus.getOrder();
                Map vPath = new HashMap(), ivPath = new HashMap(), fg = new HashMap();
                List executedKindsList = getOrderedCollections(executedKinds, customConfig, installedConfig);
                WTCollection cSeeds = new WTHashSet(seeds.persistableCollection());
                Set linkSeeds = cache.getRequredSeedLinks();
                for (int j = 0; j < executedKindsList.size(); j++) {
                    CollectionKind ck = (CollectionKind) executedKindsList.get(j);
                    cache.setColID(ck.getCollectionServiceKey());
                    boolean isUnlimited = ck.getRecursionLimit() == DTRequest.UNLIMITED_TRACING;
                    if (log.isTraceEnabled()) {
                        log.trace("<<<Process " + ck.getCollectionServiceKey());
                    }
                    for (Iterator i = cSeeds.persistableIterator(); i.hasNext();) {
                        Persistable seed = (Persistable) i.next();
                        // System.out.println("get cahced dependents of "+CollectionSrvHelper.getObjectInfo(seed));
                        getCachedDependents(seed, dependents, isUnlimited, cache, vs, ck.getCollectionServiceKey(),
                                ck.getCollectedAsKey(), collectedData, vPath, ivPath, fg, linkSeeds, isVis);
                    }
                    cSeeds.addAll(dependents.persistableCollection());
                }
                collectedData.addAllDependents(dependents.persistableCollection());
                for (Iterator i = dependents.persistableIterator(); i.hasNext();) {
                    Persistable p = (Persistable) i.next();
                    if (cache.isParent(p)) {
                        collectedData.addParent(p);
                    }
                }

                if (cache.isTrafoStructure()) {
                    collectedData.setHasVirtualElements(cache.hasClonedPaths());
                }

                if (log.isDebugEnabled()) {
                    log.debug("getCachedDependents[" + seeds.size() + "," + dependents.size() + ","
                            + cache.hasClonedPaths() + "]=" + (System.currentTimeMillis() - time) + "ms");
                }
                cache.setIsDirty(false);
            }
            else {
                if (ignoreND && !cache.isSimpleCollector()) {
                    noDependents = new HashSet();
                    tracedDependents = new HashSet();
                    if (log.isTraceEnabled()) {
                        log.trace("\trebuild cached maps");
                    }
                }

                Set initSeeds = null;
                if (CollectionSrvHelper.isIlEnabled) {
                    if (request == 1) {
                        initSeeds = new HashSet(seeds.size());
                        for (Iterator i = seeds.persistableIterator(); i.hasNext();) {
                            Persistable p = (Persistable) i.next();
                            if (CollectionSrvHelper.isDrawing(p) || CollectionSrvHelper.isFTMember(p)) {
                                initSeeds.add(PersistenceHelper.getObjectIdentifier(p));
                            }
                        }
                        ftMembers.put(INITIAL_SEEDS, initSeeds);
                    }
                    else {
                        initSeeds = (Set) ftMembers.get(INITIAL_SEEDS);
                    }
                }

                HashSet forcedKinds = new HashSet(),
                        hiddenRelated = null,
                        wsObjs = CollectionSrvHelper.getWorkspaceObjs(ws, ftMembers, cache);

                if (log.isDebugEnabled()) {
                    log.debug("<<Preparing[" + (System.currentTimeMillis() - time) + "]" + log.freeMem());
                }

                boolean isOk = installedConfig.isValid();

                if (isOk) {
                    HashMap veKinds = getValidKinds(seeds, executedKinds, installedConfig, types);
                    if (!CollectionSrvHelper.isQuickCheckEnabled) {
                        for (Iterator j = executedKinds.entrySet().iterator(); j.hasNext();) {
                            Map.Entry e = (Map.Entry) j.next();
                            CollectionKind ck = (CollectionKind) e.getValue();
                            String cID = (String) e.getKey();

                            CollectionPackage colDefPkg = installedConfig.getPackageByCollectionID(cID);
                            CollectionDefinition colDef = colDefPkg == null ? null
                                    : colDefPkg.getCollectionDefinition(cID);
                            if (colDef != null && colDef.hasRecursionRetriever()
                                    && ck.getScope() == CollectionKind.SCOPE_ALL
                                    && ck.getRecursionLimit() == DTRequest.UNLIMITED_TRACING) {
                                collectedData.addAllLevelCollection(ck);
                            }
                        }
                    }

                    Set sCl = new HashSet();
                    if (!executedKinds.isEmpty()) {
                        for (Iterator i = executedKinds.keySet().iterator(); i.hasNext();) {
                            String colId = (String) i.next();
                            CollectionPackage pkg = getCollectionPackage(colId, customConfig, installedConfig);
                            if (pkg == null) {
                                colId = installedConfig.getAssociatedCollectionDefinitionID(colId);
                                if (colId != null) {
                                    pkg = getCollectionPackage(colId, customConfig, installedConfig);
                                }
                            }
                            if (pkg != null) {
                                CollectionDefinition colDef = pkg.getCollectionDefinition(colId);
                                if (colDef.isResultGraph()) {
                                    Set nodes = colDef.getResultGraph().getNodes();
                                    for (Iterator j = nodes.iterator(); j.hasNext();) {
                                        sCl.add(((ClassObject) j.next()).getTargetClass());
                                    }
                                }
                            }

                        }
                    }

                    for (Iterator i = seeds.persistableIterator(); i.hasNext();) {
                        Persistable seed = (Persistable) i.next();
                        boolean add = true;
                        if (!(seed instanceof Iterated) && !sCl.isEmpty()) {
                            add = false;
                            for (Iterator j = sCl.iterator(); j.hasNext() && !add;) {
                                if (((Class) j.next()).isAssignableFrom(seed.getClass())) {
                                    add = true;
                                }
                            }
                        }
                        if (add) {
                            dependents.add(seed);
                        }
                    }

                    HashMap processed = new HashMap(),
                            processedExecutedKinds = new HashMap(executedKinds);

                    HashSet ignoreToAdd = new HashSet();

                    time = System.currentTimeMillis();

                    crData = collectedData;
                    if (orderToExecute == null && veKinds.size() < executedKinds.size()) {
                        isOk = getDependents(veKinds, addKinds, allKinds, seeds, dependents, false, installedConfig,
                                customConfig, processed, processedExecutedKinds, ignoreToAdd, forcedKinds, wsObjs,
                                wtCollectedObjects, types, initSeeds, filter, null);
                        HashMap reKinds = new HashMap();
                        for (Iterator i = executedKinds.entrySet().iterator(); i.hasNext();) {
                            Map.Entry e = (Map.Entry) i.next();
                            Object key = e.getKey();
                            if (!veKinds.isEmpty()) {
                                String assColId = installedConfig.getAssociatedCollectionDefinitionID((String) key);
                                if (assColId != null) {
                                    boolean isExecuted = veKinds.containsKey(assColId);
                                    if (!isExecuted) {
                                        if (assColId.equals(OLD_REQUIRED_DEPENDENTS)) {
                                            isExecuted = veKinds.containsKey(NEW_REQUIRED_DEPENDENTS);
                                        }
                                        if (!isExecuted && assColId.equals(OLD_OPTIONAL_DEPENDENTS)) {
                                            isExecuted = veKinds.containsKey(NEW_OPTIONAL_DEPENDENTS);
                                        }
                                    }
                                    if (isExecuted) {
                                        continue;
                                    }
                                }
                            }
                            if (!veKinds.containsKey(key)) {
                                reKinds.put(key, e.getValue());
                            }
                        }
                        if (!reKinds.isEmpty() && log.isDebugEnabled()) {
                            log.debug("reKinds=" + reKinds.keySet());
                        }
                        isOk = getDependents(reKinds, addKinds, allKinds, seeds, dependents, false, installedConfig,
                                customConfig, processed, processedExecutedKinds, ignoreToAdd, forcedKinds, wsObjs,
                                wtCollectedObjects, types, initSeeds, filter, null);
                    }
                    else {
                        isOk = getDependents(executedKinds, addKinds, allKinds, seeds, dependents, false,
                                installedConfig, customConfig, processed, processedExecutedKinds, ignoreToAdd,
                                forcedKinds, wsObjs, wtCollectedObjects, types, initSeeds, filter, null);
                    }
                    if (log.isDebugEnabled()) {
                        log.debug("<<DT request[" + seeds.size() + "," + dependents.size() + ","
                                + (System.currentTimeMillis() - time) + "] " + log.freeMem());
                        setProfiler();
                    }

                    if (isOk && isUseCentricity && !executedKinds.isEmpty() &&
                            (!seeds.subCollection(isPartCentric ? EPMDocument.class : WTPart.class, true).isEmpty() &&
                                    ((isPartCentric && allKinds.containsKey(WTPART_DEPENDENTS))
                                            || (!isPartCentric && allKinds.containsKey(REQUIRED_DEPENDENTS))))
                            &&
                            !(executedKinds.size() == 1
                                    && ((executedKinds.containsKey(RELATED_CADDOCS) && isPartCentric)
                                            || (executedKinds.containsKey(RELATED_WTPARTS) && !isPartCentric)))) {
                        startProfile(0);
                        // nmarne: This if block is to be removed once isConsiderOwnerAssociationOnly is made
                        // public(always true)
                        if (!CollectionSrvHelper.isConsiderOwnerAssociationOnly) {
                            WTCollection inputSeeds = new WTHashSet(
                                    seeds.subCollection(isPartCentric ? EPMDocument.class : WTPart.class, true)
                                            .persistableCollection());

                            for (Iterator i = inputSeeds.persistableIterator(); i.hasNext();) {
                                if (tracedDependents.contains(
                                        getKey(PersistenceHelper.getObjectIdentifier((Persistable) i.next()),
                                                CENTRIC))) {
                                    i.remove();
                                }
                            }

                            WTKeyedMap relatedMap = null;
                            if (!inputSeeds.isEmpty()) {
                                relatedMap = CollectionSrvHelper.getNestedDependentsMap(
                                        (isPartCentric ? RELATED_WTPARTS : RELATED_CADDOCS), wtCollectedObjects,
                                        ftMembers, inputSeeds, ws, container, null, isIgnoreObjectsInOtherContexts);
                            }

                            if (relatedMap != null && !relatedMap.isEmpty()) {
                                boolean isOptional = executedKinds.containsKey(OPTIONAL_DEPENDENTS);

                                for (Iterator i = relatedMap.wtKeySet().persistableIterator(); i.hasNext();) {
                                    Persistable p = (Persistable) i.next();
                                    Collection related = (Collection) relatedMap.get(p);
                                    Persistable relatedSeed = (Persistable) related.iterator().next();

                                    if (hiddenRelated == null) {
                                        hiddenRelated = new HashSet();
                                    }

                                    hiddenRelated.add(PersistenceHelper.getObjectIdentifier(relatedSeed));
                                }

                                if (hiddenRelated != null) {
                                    HashMap executedCentricKinds = new HashMap();
                                    if (isPartCentric) {
                                        addForcedKind(WTPART_DEPENDENTS, allKinds, executedKinds, executedCentricKinds,
                                                forcedKinds);
                                        addForcedKind(RELATED_CADDOCS, allKinds, executedKinds, executedCentricKinds,
                                                forcedKinds);
                                    }
                                    else {
                                        addForcedKind(isOptional ? OPTIONAL_DEPENDENTS : REQUIRED_DEPENDENTS, allKinds,
                                                executedKinds, executedCentricKinds, forcedKinds);
                                        addForcedKind(
                                                isOptional ? OPTIONAL_MEMBER_DEPENDENTS : REQUIRED_MEMBER_DEPENDENTS,
                                                allKinds, executedKinds, executedCentricKinds, forcedKinds);
                                        addForcedKind(isOptional ? OPTIONAL_REF_DEPENDENTS : REQUIRED_REF_DEPENDENTS,
                                                allKinds, executedKinds, executedCentricKinds, forcedKinds);
                                        addForcedKind(
                                                isOptional ? OPTIONAL_VARIANT_DEPENDENTS : REQUIRED_VARIANT_DEPENDENTS,
                                                allKinds, executedKinds, executedCentricKinds, forcedKinds);
                                        addForcedKind(RELATED_WTPARTS, allKinds, executedKinds, executedCentricKinds,
                                                forcedKinds);
                                    }

                                    if (log.isTraceEnabled()) {
                                        CollectionSrvHelper.trace("Centric seeds", null, hiddenRelated, log);
                                    }

                                    time = System.currentTimeMillis();
                                    relatedDependents = new WTHashSet(hiddenRelated);

                                    isOk = getDependents(executedCentricKinds, addKinds, allKinds,
                                            new WTHashSet(hiddenRelated), relatedDependents, false, installedConfig,
                                            customConfig, processed, processedExecutedKinds, ignoreToAdd, forcedKinds,
                                            wsObjs, wtCollectedObjects, types, initSeeds, filter, null);
                                    if (log.isDebugEnabled()) {
                                        log.debug("<<Centric " + (forcedKinds.size() == 2 ? "quick" : "main")
                                                + " request["
                                                + hiddenRelated.size() + "," + dependents.size() + ","
                                                + (System.currentTimeMillis() - time) + "] " + log.freeMem());
                                    }
                                }

                                if (!relatedDependents.isEmpty()
                                        && processed.get(isPartCentric ? RELATED_CADDOCS : RELATED_WTPARTS) != null) {
                                    String depColDefId = isPartCentric ? WTPART_DEPENDENTS : REQUIRED_DEPENDENTS;
                                    if (!isPartCentric && isOptional) {
                                        depColDefId = OPTIONAL_DEPENDENTS;
                                    }

                                    if (processed.containsKey(depColDefId)) {
                                        ResultGraph depGraph = ((CollectionDefinition) processed.get(depColDefId))
                                                .getResultGraph();
                                        int depAsKey = ((CollectionKind) allKinds.get(depColDefId)).getCollectedAsKey();
                                        ResultGraph assGraph = ((CollectionDefinition) processed
                                                .get(isPartCentric ? RELATED_CADDOCS : RELATED_WTPARTS))
                                                        .getResultGraph();
                                        boolean includeDependents = executedKinds.containsKey(depColDefId);

                                        Map associatedMap = new HashMap();
                                        for (Iterator i = relatedDependents.persistableIterator(); i.hasNext();) {
                                            Iterated dependent = (Iterated) i.next();
                                            Collection nested = assGraph.getNestedRelated(dependent, false, null,
                                                    cache);
                                            addAssociated(associatedMap, dependent, nested);
                                        }

                                        for (Iterator i = relatedMap.wtKeySet().persistableIterator(); i.hasNext();) {
                                            Iterated dependent = (Iterated) i.next();
                                            Iterated associated = (Iterated) ((HashSet) relatedMap.get(dependent))
                                                    .iterator().next();
                                            addAssociated(associatedMap, dependent,
                                                    Arrays.asList(new Iterated[] { associated }));
                                        }

                                        for (Iterator i = relatedMap.wtKeySet().persistableIterator(); i.hasNext();) {
                                            Iterated s = (Iterated) i.next();
                                            traceCentric(s, depAsKey, depGraph, includeDependents, dependents,
                                                    associatedMap, collectedData, new WTHashSet(), false, false);
                                        }

                                        if (includeDependents) {
                                            for (Iterator i = relatedMap.wtKeySet().persistableIterator(); i
                                                    .hasNext();) {
                                                Iterated s = (Iterated) i.next();

                                                Set rs = (Set) associatedMap.get(s);
                                                if (rs != null) {
                                                    for (Iterator n = rs.iterator(); n.hasNext();) {
                                                        Iterated rsd = (Iterated) n.next();
                                                        Set vs = (Set) associatedMap.get(rsd);
                                                        if (vs != null && !vs.isEmpty()) {
                                                            vs.remove(s);
                                                        }
                                                        if (vs != null && !vs.isEmpty()) {
                                                            collectedData.addDependents(s, depAsKey, new WTHashSet(vs),
                                                                    false);
                                                            dependents.addAll(vs);
                                                        }
                                                    }
                                                }

                                            }
                                        }

                                        wtCollectedObjects.addAll(dependents);
                                    }
                                }
                            }
                        }
                        else {
                            isOk = getRelatedOthersideObjects(seeds, wtCollectedObjects, executedKinds,
                                    allKinds, forcedKinds, addKinds, processed, processedExecutedKinds,
                                    wsObjs, ignoreToAdd, types, initSeeds, filter,
                                    collectedData, dependents);
                        }
                        endProfile(0);
                    }

                    if (isOk && isQuickSearch && CollectionSrvHelper.isQuickCheckEnabled) {
                        time = System.currentTimeMillis();
                        isOk = getDependents(allKinds, addKinds, allKinds, seeds, dependents, true, installedConfig,
                                customConfig, processed, processedExecutedKinds, ignoreToAdd, forcedKinds, wsObjs,
                                wtCollectedObjects, types, initSeeds, filter, crData);
                        if (log.isDebugEnabled()) {
                            log.debug("<<Quick check request[" + (seeds.size() + dependents.size()) + ","
                                    + (System.currentTimeMillis() - time) + "] " + log.freeMem());
                        }
                    }

                    crData = null;
                    if (isOk) {
                        Map ptm = (Map) cache.getInputParameter(CollectorDefinitionIDS.POST_TRACING_MARKERS);
                        if (ptm != null && !ptm.isEmpty()) {
                            for (Iterator l = ptm.values().iterator(); l.hasNext();) {
                                NavigationMarker ptf = (NavigationMarker) l.next();
                                CollectionSrvHelper.applyMarker(ptf, cache, true);
                            }
                        }
                        else if (cache.isTrafoStructure() && !cache.isTrafoStructureModified()
                                && (cache.isWVS() || cache.getNavigationMarker() != null) && getId() != null) {
                            NavigationMarker ptf = cache.getPreNavigationMarker();
                            if (ptf == null && cache.isTrafoStructure()
                                    && (cache.isWVS() || cache.getNavigationMarker() != null)) {
                                ptf = installedConfig.getPreMarker(CollectionSrvHelper.trafoParType);

                                if (cache.getMarkerColID() == null && executedKinds != null
                                        && !executedKinds.isEmpty()) {
                                    cache.setMarkerColId(new HashSet(executedKinds.keySet()));
                                }

                                if (log.isDebugEnabled()) {
                                    log.debug("Trafo structure planned to update");
                                }
                            }

                            CollectionSrvHelper.applyMarker(ptf, cache, true);
                            cache.setTrafoStructureModified();

                            NavigationMarker pm = installedConfig.getPostMarker(CollectionSrvHelper.trafoParType);
                            if (pm != null) {
                                if (cache.getMarkerColID() == null && executedKinds != null
                                        && !executedKinds.isEmpty()) {
                                    cache.setMarkerColId(new HashSet(executedKinds.keySet()));
                                }
                                if (log.isDebugEnabled()) {
                                    log.debug("Trafo post marking planned to execute");
                                }
                                CollectionSrvHelper.applyMarker(pm, cache, true);
                                cache.setTrafoTransformixMatrixModified();
                                if (pm instanceof VirtualPathFilteredStatusModifier) {
                                    cache.setVirtualPathFilteredStatusModifier((VirtualPathFilteredStatusModifier) pm);
                                }
                            }
                        }

                        CollectionSrvHelper.setNavigationMark(cache, false);

                        NavigationMarker pm = cache.getPostNavigationMarker();
                        if (pm != null && cache.isTrafoStructure() && cache.isTrafoTransformixMatrixModified()) {
                            pm = null;
                        }

                        CollectionSrvHelper.applyMarker(pm, cache, false);

                        if (log.isTraceEnabled()) {
                            log.trace(getTracedObjects("Found dependents", dependents.persistableCollection()));
                            CollectionSrvHelper.trace("Processed", null, processed.keySet(), log);
                            CollectionSrvHelper.trace("Executed", null, processedExecutedKinds.keySet(), log);
                            CollectionSrvHelper.trace("Forced", null, forcedKinds, log);
                            log.trace("Cached navigation units");
                            Set check = new HashSet();
                            for (Iterator i = seeds.persistableIterator(); i.hasNext();) {
                                getChildren(cache, processedExecutedKinds.keySet(), (Persistable) i.next(), check);
                            }
                        }

                        if (cache.getACMD()) {
                            collectedData.setHasUnresolvedObjectsByAccessRights();
                            if (log.isDebugEnabled()) {
                                log.debug("acmd found");
                            }
                        }
                        else if (cache.getMD()) {
                            collectedData.setHasUnresolvedObjects();
                            if (log.isDebugEnabled()) {
                                log.debug("md found");
                            }
                        }

                        startProfile(1);
                        time = System.currentTimeMillis();
                        HashMap unforcedKinds = new HashMap(processedExecutedKinds);
                        unforcedKinds.putAll(addKinds);
                        HashSet unforcedFT = new HashSet();
                        CollectionKind cku = (CollectionKind) unforcedKinds.get(FAMILY);
                        if (cku == null) {
                            cku = (CollectionKind) unforcedKinds.get(INSEPARABLE_FAMILY);
                        }
                        if (cku != null) {
                            boolean isAll = cku.getScope().equals(ALL),
                                    isIFT = cku.getCollectionServiceKey().equals(INSEPARABLE_FAMILY);

                            for (Iterator i = dependents.persistableIterator(); i.hasNext();) {
                                Persistable p = (Persistable) i.next();
                                if (isIFT && !CollectionRulePreferenceHelper.isInseparableFTMember(p, context)) {
                                    continue;
                                }

                                Long vID = (Long) ftMembers.get(PersistenceHelper.getObjectIdentifier(p));

                                if (vID != null && (isAll || seeds.contains(p))) {
                                    unforcedFT.add(vID);
                                }
                            }
                        }

                        collectedData.addAllDependents(dependents.persistableCollection());
                        if (processedExecutedKinds.containsKey(FAMILY)
                                || processedExecutedKinds.containsKey(INSEPARABLE_FAMILY)
                                || processedExecutedKinds.containsKey(FAMILY_GENERICS)
                                || processedExecutedKinds.containsKey(REQUIRED_VARIANT_DEPENDENTS)
                                || processedExecutedKinds.containsKey(OPTIONAL_DEPENDENTS)
                                || processedExecutedKinds.containsKey(REQUIRED_DEPENDENTS)) {
                            for (Object d : dependents.persistableCollection()) {
                                if (CollectionSrvHelper.isFTMember(d)) {
                                    cache.addGeneric((EPMDocument) d);
                                }
                            }

                            if (!processedExecutedKinds.containsKey(FAMILY)
                                    && (cache.isDifferentGenericTraced() || cache.isGenericSeed())) {
                                FamilyTableHelper fth = new FamilyTableHelper(dependents);
                                fth.setFilterInstancesByInput(true);
                                fth.setWorkspace(ws);
                                fth.setContainer(container);
                                try {
                                    FamilyTableResult ftr = fth.getFamilyInfo();
                                    if (!ftr.isCompatibleResult()) {
                                        CollectionSrvHelper.setIncompatibility(ftr, ftr.getIncompatibleFT(), ftMembers,
                                                wsObjs);
                                    }
                                } catch (Exception ve) {
                                    CollectionSrvHelper.getStackTrace(ve, log);
                                }
                            }

                            Map iv = (Map) ftMembers.get(CollectionSrvHelper.INCOMPATIBLE);
                            HashSet errors = new HashSet();
                            Set ftwrk = (Set) ftMembers.get(CollectionSrvHelper.FTWRK);
                            if (iv != null) {
                                Map fmWrk = ftMembers == null ? null : (Map) ftMembers.get(CollectionSrvHelper.FMWRK),
                                        msgs = new HashMap();

                                for (Iterator i = iv.entrySet().iterator(); i.hasNext();) {
                                    Map.Entry e = (Map.Entry) i.next();
                                    EPMDocument member = (EPMDocument) cache.getCachedObject(e.getKey());

                                    if (member != null && dependents.contains(member)) {
                                        String ivName = (String) e.getValue();
                                        boolean isWarning = ((Boolean) ftMembers.get(ivName)).booleanValue();
                                        if (!isWarning && ftwrk != null) {
                                            isWarning = ftwrk.contains(ivName);
                                        }
                                        errors.add(PersistenceHelper.getObjectIdentifier(member));
                                        WTMessage msg = (WTMessage) msgs.get(ivName);
                                        if (msg == null) {
                                            msg = new WTMessage(resource, htmlcompResource.INCOMPATIBLE_MEMBER,
                                                    new Object[] { ivName });
                                            msgs.put(ivName, msg);
                                        }

                                        boolean isWrk = fmWrk == null ? false
                                                : fmWrk.containsKey(member.getMasterReference().getKey());
                                        addMessage(collectedData, member, msg,
                                                !isWrk && isWarning && member.isInstance() && seeds.contains(member)
                                                        ? Message.WARNING
                                                        : Message.FATAL);
                                    }
                                }
                            }

                            if (ws != null) {
                                FamilyTableHelper fth = new FamilyTableHelper(dependents);
                                fth.setFilterInstancesByInput(true);
                                fth.setWorkspace(ws);
                                Set wrkm = (Set) ftMembers.get(CollectionSrvHelper.WRKM);
                                Map pwrkm = (Map) ftMembers.get(CollectionSrvHelper.PWRKM);
                                try {
                                    iv = fth.getRelatedIncompatibleFTMembersFromWorkspace(
                                            componentID == null || UPDATE_ACTION.equals(componentID) ? null
                                                    : (wrkm == null ? Collections.EMPTY_SET : wrkm),
                                            pwrkm == null ? null : pwrkm.keySet());
                                } catch (Exception ve) {
                                    CollectionSrvHelper.getStackTrace(ve, log);
                                }
                                if (iv != null && !iv.isEmpty()) {
                                    for (Iterator i = iv.entrySet().iterator(); i.hasNext();) {
                                        Map.Entry e = (Map.Entry) i.next();
                                        EPMDocument member = (EPMDocument) e.getKey();
                                        if (!errors.contains(PersistenceHelper.getObjectIdentifier(member))) {
                                            Object[] objs = (Object[]) e.getValue();
                                            WTMessage msg = new WTMessage(resource,
                                                    htmlcompResource.INCOMPATIBLE_WITH_WORKSPACE_MEMBERS,
                                                    new Object[] { objs[1] });
                                            boolean isWrkMaster = wrkm != null && wrkm.contains(BigDecimal.valueOf(
                                                    ((ObjectIdentifier) member.getMasterReference().getKey()).getId())),
                                                    isWrkVersion = objs[0] instanceof ObjectIdentifier && wrkm != null
                                                            && wrkm.contains(BigDecimal
                                                                    .valueOf(((ObjectIdentifier) objs[0]).getId()));

                                            addMessage(collectedData, member, msg,
                                                    (member.isInstance() && !isWrkMaster && isWrkVersion
                                                            ? Message.WARNING
                                                            : Message.ERROR));
                                        }
                                    }
                                }
                                else {
                                    if (pwrkm != null) {
                                        for (Iterator i = dependents.persistableIterator(); i.hasNext();) {
                                            Persistable p = (Persistable) i.next();
                                            if (CollectionSrvHelper.isFTMember(p)) {
                                                EPMDocument member = (EPMDocument) p;
                                                Object key = member.getMasterReference().getKey();
                                                if (pwrkm.containsKey(key)
                                                        && !WorkInProgressHelper.isPrivateWorkingCopy(member)) {
                                                    WTMessage msg = new WTMessage(resource,
                                                            htmlcompResource.INCOMPATIBLE_WITH_WORKSPACE_MEMBERS,
                                                            new Object[] { member.getCADName() });
                                                    addMessage(collectedData, member, msg, Message.WARNING);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            HashSet v = (HashSet) ftMembers.get(CollectionSrvHelper.FTS);
                            if (v != null) {
                                for (Iterator i = v.iterator(); i.hasNext();) {
                                    Long vID = (Long) i.next();
                                    Boolean found = (Boolean) ftMembers.get(vID);
                                    if (found != null && found.booleanValue()) {
                                        collectedFTVersions.remove(vID);
                                    }
                                    else {
                                        collectedFTVersions.put(vID, vID);
                                    }
                                }
                            }
                        }

                        for (Iterator i = processed.values().iterator(); i.hasNext();) {
                            Object value = i.next();
                            if (value instanceof CollectionDefinition) {
                                CollectionDefinition colDef = (CollectionDefinition) value;
                                if (colDef.isResultGraph()) {
                                    ResultGraph g = colDef.getResultGraph();
                                    g.refine(processed, cache);
                                }
                            }
                        }
                        endProfile(1);

                        startProfile(2);
                        boolean isEPMRootProcessed = !cache.getEsrSeed();
                        for (Iterator i = processed.values().iterator(); i.hasNext();) {
                            Object value = i.next();
                            if (!(value instanceof CollectionDefinition)) {
                                continue;
                            }

                            CollectionDefinition colDef = (CollectionDefinition) value;

                            if (colDef.isResultGraph()) {
                                ResultGraph g = colDef.getResultGraph();
                                List defs = new ArrayList();
                                defs.add(colDef.getCollectionID());
                                for (Iterator j = g.getLinks().iterator(); j.hasNext();) {
                                    Link link = (Link) j.next();
                                    String assColId = link.getAssociatedCollectionDefinitionId();
                                    if (assColId != null) {
                                        defs.add(assColId);
                                        if (colDef.getCollectionID().equals(NEW_REQUIRED_DEPENDENTS)
                                                && !cache.getIncludeLinks()) {
                                            link.setIsLinkUpdated(true);
                                        }
                                    }
                                }

                                for (int l = 0; l < defs.size(); l++) {
                                    boolean isFound = false;
                                    buf = new StringBuffer();

                                    String colDefId = (String) defs.get(l);
                                    boolean isMember = colDefId.equals(OPTIONAL_MEMBER_DEPENDENTS)
                                            || colDefId.equals(REQUIRED_MEMBER_DEPENDENTS);

                                    buf.append("===" + colDefId + "===\n");

                                    CollectionKind kind = (CollectionKind) allKinds.get(colDefId);
                                    if (kind == null) {
                                        continue;
                                    }

                                    int collectedAsKey = kind.getCollectedAsKey();

                                    for (Iterator j = dependents.persistableIterator(); j.hasNext();) {
                                        Persistable parent = (Persistable) j.next();
                                        ObjectIdentifier parentId = PersistenceHelper.getObjectIdentifier(parent);
                                        if (!isEPMRootProcessed && isMember
                                                && CollectionSrvHelper.isExtSimpRep(parent)) {
                                            isEPMRootProcessed = true;
                                            NavigationUnit[] cn = cache.getChildren(parent, REQUIRED_MEMBER_DEPENDENTS);
                                            for (int k = 0; k < cn.length; k++) {
                                                Persistable child = cn[k].getEndNode();
                                                Set lnks = cn[k].getParnts(child, EPMReferenceLink.class, true);
                                                if (lnks != null && !lnks.isEmpty() && !cn[k].getFilteredStatus(child)
                                                        .equals(FilteredStatus.FILTERED)) {
                                                    Map links = new HashMap();
                                                    links.put(child, lnks);
                                                    addDependents(collectedData, parent,
                                                            CollectionSrvHelper.isExtSimpRep(parent)
                                                                    && collectedAsKey == CollectionKind.REQUIRED_MEMBER_DEPENDENTS
                                                                            ? CollectionKind.REQUIRED_REF_DEPENDENTS
                                                                            : collectedAsKey,
                                                            links, true, unforcedFT);
                                                }
                                            }
                                        }

                                        String key = getKey(parentId, colDefId);

                                        if (noDependents.contains(key)) {
                                            NavigationUnit[] c = cache.getChildren(parent, colDefId);
                                            if (c == null || c.length == 0) {
                                                continue;
                                            }
                                        }

                                        if (log.isTraceEnabled()) {
                                            buf.append("<<<Process "
                                                    + CollectionSrvHelper.getObjectInfo(parent, true, true) + "\n");
                                        }
                                        boolean isMissed = false, isFiltered = false;
                                        Collection children = (Collection) foundRelations.get(key);
                                        Collection nestedRelated = g.getNestedRelated(parent, true,
                                                (l == 0 ? null : colDefId), cache);

                                        if (nestedRelated != null && !nestedRelated.isEmpty()) {
                                            int missedChildren = 0;

                                            for (Iterator m = nestedRelated.iterator(); m.hasNext();) {
                                                Persistable child = (Persistable) m.next();
                                                ObjectIdentifier childId = PersistenceHelper.getObjectIdentifier(child);

                                                if (!isValidChild(colDefId, child, parent)) {
                                                    continue;
                                                }

                                                if (children == null) {
                                                    children = new HashSet();
                                                    foundRelations.put(key, children);
                                                }
                                                children.add(childId);

                                                if (!cache.isCached(childId)) {
                                                    missedChildren++;
                                                    isMissed = true;

                                                    Map parentCls = (Map) missedRelations.get(childId);
                                                    if (parentCls == null) {
                                                        parentCls = new HashMap();
                                                        missedRelations.put(childId, parentCls);
                                                    }

                                                    Collection parents = (Collection) parentCls.get(colDefId);
                                                    if (parents == null) {
                                                        parents = new HashSet();
                                                        parentCls.put(colDefId, parents);
                                                    }

                                                    parents.add(parentId);
                                                }
                                            }

                                            isFiltered = nestedRelated.size() > missedChildren;
                                        }
                                        if (!isMissed && children != null) {
                                            for (Iterator m = children.iterator(); m.hasNext() && !isMissed;) {
                                                if (!cache.isCached(m.next())) {
                                                    isMissed = true;
                                                }
                                            }
                                        }

                                        if (isMissed && !isFiltered) {
                                            isFound = true;
                                            addAC(collectedData, parent, collectedAsKey, isMissed, isUseCentricity);
                                        }

                                        if (!isMissed || (isMissed && isFiltered)) {
                                            if (!(!tracedDependents.contains(key)
                                                    && !CollectionSrvHelper.isQuickCheckEnabled)) {
                                                noDependents.add(key);
                                            }

                                            if (children != null && !children.isEmpty()) {
                                                WTCollection wtChildren = new WTHashSet(children.size());
                                                for (Iterator m = children.iterator(); m.hasNext();) {
                                                    Object mn = m.next();
                                                    Persistable child = (Persistable) cache.getCachedObject(mn);
                                                    if (child instanceof Iterated) {
                                                        Persistable cmn = ((Iterated) child).getMaster();
                                                        if (PersistenceHelper.getObjectIdentifier(cmn).equals(mn)) {
                                                            child = cmn;
                                                        }
                                                    }
                                                    if (isValidChild(colDefId, child, parent)) {
                                                        wtChildren.add(child);
                                                    }
                                                }

                                                if (!ignoreToAdd.contains(colDefId)) {
                                                    boolean isParentESR = CollectionSrvHelper.isExtSimpRep(parent);
                                                    Map c = g.getChildrenWithLinks(parent, wtChildren, colDefId, cache);

                                                    if (colDefId.equals(NEW_REQUIRED_DEPENDENTS) && c != null
                                                            && !c.isEmpty()) {
                                                        refine(g, c, parent, wtChildren, REQUIRED_MEMBER_DEPENDENTS);
                                                        refine(g, c, parent, wtChildren, REQUIRED_REF_DEPENDENTS);
                                                    }

                                                    if (cache.isEsr() && !isParentESR && request > 1 && c != null
                                                            && !c.isEmpty()
                                                            && executedKinds.containsKey(NEW_OPTIONAL_DEPENDENTS)) {
                                                        for (Iterator en = c.entrySet().iterator(); en.hasNext();) {
                                                            Map.Entry e = (Map.Entry) en.next();
                                                            if (e.getValue() == null) {
                                                                en.remove();
                                                            }
                                                        }
                                                    }

                                                    if (cache.isEsr()
                                                            && collectedAsKey == CollectionKind.OPTIONAL_VARIANT_DEPENDENTS) {
                                                        collectedAsKey = CollectionKind.REQUIRED_VARIANT_DEPENDENTS;
                                                    }
                                                    addDependents(collectedData, parent,
                                                            (isParentESR
                                                                    && collectedAsKey == CollectionKind.REQUIRED_MEMBER_DEPENDENTS
                                                                            ? CollectionKind.REQUIRED_REF_DEPENDENTS
                                                                            : collectedAsKey),
                                                            c, !unforcedKinds.containsKey(colDefId), unforcedFT);
                                                    if (collectedAsKey == REQUIRED_VARIANT_DEPENDENTS_KIND) {
                                                        addDependents(collectedData, parent, FAMILY_GENERICS_KIND,
                                                                g.getChildrenWithLinks(parent, wtChildren,
                                                                        FAMILY_GENERICS, cache),
                                                                !unforcedKinds.containsKey(FAMILY_GENERICS),
                                                                unforcedFT);
                                                        if (!CollectionSrvHelper.isQuickCheckEnabled) {
                                                            addOppositeDependents(customConfig, installedConfig,
                                                                    colDefId, FAMILY_INSTANCES, allKinds, parent,
                                                                    wtChildren, collectedData, unforcedKinds,
                                                                    unforcedFT);
                                                        }
                                                    }

                                                    isFound = true;
                                                }

                                                if (l == 0) {
                                                    addOppositeDependents(customConfig, installedConfig, colDefId,
                                                            g.getOppositeCollectionId(), allKinds, parent, wtChildren,
                                                            collectedData, unforcedKinds, unforcedFT);
                                                }
                                            }

                                            foundRelations.remove(key);
                                        }
                                        Map parentCls = (Map) missedRelations.get(parentId);

                                        if (parentCls != null && !parentCls.isEmpty()) {
                                            isFound = true;
                                            WTCollection foundChild = new WTHashSet();
                                            foundChild.add(parent);

                                            for (Iterator k = parentCls.entrySet().iterator(); k.hasNext();) {
                                                Map.Entry e = (Map.Entry) k.next();

                                                String missedColDefId = (String) e.getKey();
                                                int missedCollectedAsKey = ((CollectionKind) allKinds
                                                        .get(missedColDefId)).getCollectedAsKey();

                                                for (Iterator m = ((Collection) e.getValue()).iterator(); m
                                                        .hasNext();) {
                                                    ObjectIdentifier missedParentId = (ObjectIdentifier) m.next();

                                                    Persistable missedParent = (Persistable) cache
                                                            .getCachedObject(missedParentId);

                                                    if (missedParent != null) {
                                                        if (!ignoreToAdd.contains(missedColDefId)
                                                                && isValidChild(missedColDefId, parent, missedParent)) {
                                                            addDependents(collectedData, missedParent,
                                                                    missedCollectedAsKey,
                                                                    g.getChildrenWithLinks(missedParent, foundChild,
                                                                            missedColDefId, cache),
                                                                    !unforcedKinds.containsKey(missedColDefId)
                                                                            || !dependents.contains(missedParent),
                                                                    unforcedFT);

                                                            CollectionPackage pkg = installedConfig
                                                                    .getPackageByCollectionID(missedColDefId);
                                                            ResultGraph mg = null;
                                                            if (pkg != null) {
                                                                mg = pkg.getCollectionDefinition(missedColDefId)
                                                                        .getResultGraph();
                                                            }

                                                            if (mg != null) {
                                                                WTCollection opAd = new WTHashSet();
                                                                opAd.add(parent);

                                                                addOppositeDependents(customConfig, installedConfig,
                                                                        missedColDefId, mg.getOppositeCollectionId(),
                                                                        allKinds, missedParent, opAd, collectedData,
                                                                        processedExecutedKinds, unforcedFT);
                                                            }
                                                        }
                                                        String missedKey = getKey(
                                                                PersistenceHelper.getObjectIdentifier(missedParent),
                                                                missedColDefId);
                                                        Collection missedChildren = (Collection) foundRelations
                                                                .get(missedKey);

                                                        if (missedChildren != null) {
                                                            missedChildren.remove(parentId);

                                                            if (missedChildren.isEmpty()) {
                                                                noDependents.add(missedKey);
                                                                foundRelations.remove(missedKey);
                                                            }
                                                        }
                                                    }
                                                }
                                            }

                                            missedRelations.remove(parentId);
                                        }
                                    }

                                    if (log.isTraceEnabled() && isFound) {
                                        log.trace(buf.toString());
                                    }
                                }
                            }
                        }
                        endProfile(2);

                        HashMap versions = null,
                                tops = null,
                                checkedRecursions = null,
                                storedVersions = null,
                                nodes = null;

                        Set substitues = (Set) ftMembers.get(CollectionSrvHelper.SUBS);
                        Message smsg = substitues != null ? new Message(
                                "The original iteration to be included in the as-stored could not be found and that an alternative one has been chosen",
                                Message.WARNING) : null;

                        if (CollectionSrvHelper.isQuickCheckEnabled) {
                            checkedRecursions = new HashMap();
                            for (Iterator i = allKinds.entrySet().iterator(); i.hasNext();) {
                                Map.Entry e = (Map.Entry) i.next();

                                String colDefId = (String) e.getKey();

                                CollectionPackage pkg = installedConfig.getPackageByCollectionID(colDefId);
                                if (pkg != null && pkg.getCollectionDefinition(colDefId).hasRecursionRetriever()
                                        && !processedExecutedKinds.containsKey(colDefId)) {
                                    checkedRecursions.put(colDefId, e.getValue());
                                }
                            }
                        }

                        if (CollectionSrvHelper.isParentBaseline()
                                && CollectionSrvHelper.isDifferentStoredVersionsWarningEnabled) {
                            startProfile(3);
                            boolean isStored = false;
                            List cs = configSpecs.getConfigSpecs(EPMDocument.class);
                            if (cs != null && !cs.isEmpty()) {
                                isStored = CollectionSrvHelper.isAsStoredConfigSpec((ConfigSpec) cs.get(0));
                            }
                            if (isStored) {
                                WTCollection cads = dependents.subCollection(EPMDocument.class, true);
                                if (!cads.isEmpty()) {
                                    nodes = new HashMap();

                                    for (Iterator i = cads.persistableIterator(); i.hasNext();) {
                                        EPMDocument doc = (EPMDocument) i.next();
                                        PersistenceHelper.getObjectIdentifier(doc);

                                        Collection cfos = collectedData.getCollectedFromObjs(doc);
                                        if (cfos != null && !cfos.isEmpty()) {
                                            for (Iterator j = cfos.iterator(); j.hasNext();) {
                                                CollectedFromObj cfo = (CollectedFromObj) j.next();
                                                int cko = cfo.getCollectionKey();
                                                if (cko == CollectionKind.OPTIONAL_MEMBER_DEPENDENTS
                                                        || cko == CollectionKind.OPTIONAL_REF_DEPENDENTS
                                                        || cko == CollectionKind.REQUIRED_MEMBER_DEPENDENTS
                                                        || cko == CollectionKind.REQUIRED_REF_DEPENDENTS) {
                                                    Object p = cfo.getCollectedFrom();
                                                    if (CollectionSrvHelper.isCadAssembly(p)
                                                            || CollectionSrvHelper.isDrawing(p)) {
                                                        HashSet prs = (HashSet) nodes.get(doc);
                                                        if (prs == null) {
                                                            prs = new HashSet();
                                                            nodes.put(doc, prs);
                                                        }
                                                        prs.add(p);
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    if (!nodes.isEmpty()) {
                                        for (Iterator i = nodes.entrySet().iterator(); i.hasNext();) {
                                            Map.Entry e = (Map.Entry) i.next();
                                            HashSet prs = (HashSet) e.getValue();
                                            if (prs.size() < 2) {
                                                i.remove();
                                            }
                                        }

                                        if (!nodes.isEmpty()) {
                                            storedVersions = CollectionSrvHelper.getStoredVersions(nodes);
                                        }
                                    }
                                }
                            }
                            endProfile(3);
                        }

                        startProfile(4);
                        for (Iterator i = dependents.persistableIterator(); i.hasNext();) {
                            Persistable p = (Persistable) i.next();
                            ObjectIdentifier pID = PersistenceHelper.getObjectIdentifier(p);

                            if (substitues != null && substitues.contains(Long.valueOf(pID.getId()))) {
                                addMessage(collectedData, p, smsg);
                            }

                            String oftv = (String) ftMembers.get(CollectionSrvHelper.REPLACEMENT + pID.getId());
                            if (oftv != null) {
                                addMessage(collectedData, p,
                                        new WTMessage(resource,
                                                htmlcompResource.RESOLVED_BY_LAST_COMPATIBLE_RULE, new Object[] {
                                                        CollectionSrvHelper.getVersionDisplay((Iterated) p), oftv }),
                                        Message.WARNING);
                                ftMembers.remove(CollectionSrvHelper.REPLACEMENT + pID.getId());
                            }

                            if (storedVersions != null && !storedVersions.isEmpty() && p instanceof EPMDocument)

                            {
                                HashMap sversions = (HashMap) storedVersions
                                        .get(((EPMDocument) p).getMasterReference().getKey());
                                HashSet prs = (HashSet) nodes.get(p);
                                if (sversions != null && prs != null && prs.size() > 1) {
                                    boolean hasOther = false;
                                    List<Message> matched = new ArrayList();
                                    String ov = CollectionSrvHelper.getVersionDisplay((EPMDocument) p);

                                    for (Iterator j = sversions.entrySet().iterator(); j.hasNext();) {
                                        Map.Entry e = (Map.Entry) j.next();
                                        boolean isDifferent = !ov.equals(e.getKey());
                                        String version = ((EPMDocument) p).getCADName() + " (" + (String) e.getKey()
                                                + ")";
                                        for (Iterator k = ((HashSet) e.getValue()).iterator(); k.hasNext();) {
                                            EPMDocument parent = (EPMDocument) cache
                                                    .getCachedObject(new ObjectIdentifier(EPMDocument.class,
                                                            ((BigDecimal) k.next()).longValue()));
                                            if (prs.contains(parent)) {
                                                if (isDifferent) {
                                                    hasOther = true;
                                                }

                                                Message msg = new Message(parent.getCADName() + " ("
                                                        + CollectionSrvHelper.getVersionDisplay(parent) + ") requires "
                                                        + version, Message.WARNING);

                                                if (isDifferent) {
                                                    addMessage(collectedData, p, msg);
                                                }
                                                else {
                                                    matched.add(msg);
                                                }
                                            }
                                        }
                                    }

                                    if (hasOther && !matched.isEmpty()) {
                                        for (Message msg : matched) {
                                            addMessage(collectedData, p, msg);
                                        }
                                    }
                                }
                            }

                            if (!CollectionSrvHelper.isQuickCheckEnabled) {
                                for (Iterator j = allKinds.entrySet().iterator(); j.hasNext();) {
                                    Map.Entry e = (Map.Entry) j.next();
                                    String cID = (String) e.getKey();
                                    int collectedAsKey = ((CollectionKind) e.getValue()).getCollectedAsKey();

                                    CollectionPackage colDefPkg = installedConfig.getPackageByCollectionID(cID);
                                    CollectionDefinition colDef = colDefPkg == null ? null
                                            : colDefPkg.getCollectionDefinition(cID);

                                    String key = getKey(pID, cID);
                                    if (!tracedDependents.contains(key)) {
                                        boolean isApplied = true;
                                        Long vID = CollectionSrvHelper.isFTMember(p)
                                                ? (Long) ftMembers
                                                        .get(PersistenceHelper.getObjectIdentifier(p))
                                                : null;

                                        if (noDependents.contains(key) ||
                                                (!CollectionSrvHelper.isFTMember(p) && (cID.equals(FAMILY)
                                                        || cID.equals(INSEPARABLE_FAMILY) || cID.equals(FAMILY_GENERICS)
                                                        || cID.equals(FAMILY_INSTANCES)))
                                                ||
                                                (CollectionSrvHelper.isFTMember(p) && ((EPMDocument) p).isTopGeneric()
                                                        && cID.equals(FAMILY_GENERICS))
                                                ||
                                                (CollectionSrvHelper.isFTMember(p) && !((EPMDocument) p).isGeneric()
                                                        && cID.equals(FAMILY_INSTANCES))
                                                ||
                                                (vID != null && unforcedFT.contains(vID)
                                                        && (cID.equals(FAMILY) || cID.equals(INSEPARABLE_FAMILY)
                                                                || cID.equals(FAMILY_GENERICS)
                                                                || cID.equals(FAMILY_INSTANCES)))
                                                ||
                                                (colDef == null && (!CollectionSrvHelper.isIlEnabled
                                                        && !(CollectionSrvHelper.isDrawing(p)
                                                                || (CollectionSrvHelper.isFTMember(p)
                                                                        && CollectionSrvHelper.isCadAssembly(p))))
                                                        ||
                                                        (colDef != null && !colDef.canBeSeed(p, types)
                                                                && !((isPartCentric && p instanceof EPMDocument
                                                                        && cID.equals(WTPART_DEPENDENTS))
                                                                        || (!isPartCentric && p instanceof WTPart
                                                                                && cID.equals(
                                                                                        REQUIRED_DEPENDENTS)))))) {
                                            isApplied = false;
                                        }

                                        addAC(collectedData, p, collectedAsKey, isApplied, isUseCentricity);
                                    }
                                    else if ((collectedAsKey == RELATED_CADDOCS_KIND && p instanceof WTPart)
                                            || (collectedAsKey == RELATED_WTPARTS_KIND && p instanceof EPMDocument)) {
                                        Set pd = (Set) ftMembers.get(cID);
                                        if (pd == null) {
                                            pd = new HashSet();
                                            ftMembers.put(cID, pd);
                                        }

                                        Long value = Long.valueOf(PersistenceHelper.getObjectIdentifier(p).getId());
                                        if (!pd.contains(value)) {
                                            pd.add(value);
                                        }
                                    }
                                }
                            }
                            else if (checkedRecursions != null && !checkedRecursions.isEmpty()) {
                                for (Iterator j = checkedRecursions.entrySet().iterator(); j.hasNext();) {
                                    Map.Entry e = (Map.Entry) j.next();
                                    String key = getKey(pID, (String) e.getKey());
                                    int colKey = ((CollectionKind) e.getValue()).getCollectedAsKey();

                                    if (!tracedDependents.contains(key)
                                            && !(!CollectionSrvHelper.isFTMember(p) && (colKey == FAMILY_INSTANCES_KIND
                                                    || colKey == FAMILY_GENERICS_KIND
                                                    || colKey == INSEPARABLE_FAMILY_KIND))
                                            && !(CollectionSrvHelper.isFTMember(p) && ((EPMDocument) p).isTopGeneric()
                                                    && colKey == FAMILY_GENERICS_KIND)) {
                                        addAC(collectedData, p, colKey, true, isUseCentricity);
                                        noDependents.remove(key);
                                    }
                                }
                            }

                            if (CollectionSrvHelper.isQuickCheckEnabled && isMissedDependenciesEnabled) {
                                CollectionKind kind = (CollectionKind) allKinds.get(OPTIONAL_DEPENDENTS);
                                if (kind != null && !executedKinds.containsKey(OPTIONAL_DEPENDENTS)) {
                                    String cID = OPTIONAL_DEPENDENTS;
                                    String key = getKey(pID, cID);
                                    if (!tracedDependents.contains(key)) {
                                        addAC(collectedData, p, kind.getCollectedAsKey(), true, isUseCentricity);
                                        checkedDependents.remove(key);
                                        noDependents.remove(key);
                                    }
                                }
                            }

                            if (!tracedDependents.contains(getKey(pID, REQUIRED_DEPENDENTS))) {
                                noDependents.remove(getKey(pID, OPTIONAL_DEPENDENTS));
                                addAC(collectedData, p, OPTIONAL_DEPENDENTS_KIND, true, isUseCentricity);
                            }

                            if (!collectedFTVersions.isEmpty() && CollectionSrvHelper.isFTMember(p)) {
                                Long vID = (Long) ftMembers.get(pID);
                                if (vID != null && collectedFTVersions.containsKey(vID)) {
                                    String key = null;
                                    if (CollectionRulePreferenceHelper.isInseparableFTMember(p, context)
                                            && allKinds.containsKey(INSEPARABLE_FAMILY)) {
                                        key = getKey(pID, INSEPARABLE_FAMILY);
                                        collectedData.addAppliedCollection(p, INSEPARABLE_FAMILY_KIND, true);
                                    }
                                    else {
                                        key = getKey(pID, FAMILY);
                                        collectedData.addAppliedCollection(p, FAMILY_KIND, true);
                                    }
                                    noDependents.remove(key);
                                }
                            }

                            if (CollectionSrvHelper.isFTMember(p) && ((EPMDocument) p).isTopGeneric()) {
                                if (tops == null) {
                                    tops = new HashMap();
                                }
                                tops.put(((EPMDocument) p).getCADName(), p);
                            }

                            if (CollectionSrvHelper.isFTMember(p) && !seeds.contains(p)
                                    && collectedData.getCollectedFromObjs(p) == null) {
                                boolean isInstance = ((EPMDocument) p).isInstance(),
                                        hasGeneric = isInstance;

                                if (hasGeneric) {
                                    ObjectIdentifier genericID = (ObjectIdentifier) ftMembers
                                            .get(CollectionSrvHelper.GENERIC + p.toString());

                                    if (genericID == null || !dependents.contains(genericID)) {
                                        hasGeneric = false;
                                    }
                                }

                                if (isInstance && !hasGeneric && ftMembers.get(pID) != null) {
                                    if (versions == null) {
                                        versions = new HashMap();
                                    }

                                    ObjectIdentifier ftv = new ObjectIdentifier(EPMSepFamilyTable.class,
                                            ((Long) ftMembers.get(pID)).longValue());
                                    WTCollection members = (WTCollection) versions.get(ftv);
                                    if (members == null) {
                                        members = new WTHashSet();
                                        versions.put(ftv, members);
                                    }

                                    members.add(p);
                                }
                            }
                        }

                        if (versions != null) {
                            for (Iterator i = new WTHashSet(versions.keySet()).persistableIterator(); i.hasNext();) {
                                EPMSepFamilyTable version = (EPMSepFamilyTable) i.next();

                                EPMDocument top = tops == null ? null : (EPMDocument) tops.get(version.getName());

                                collectedData.addDependents(top == null ? version.getName() : top,
                                        CollectionKind.FAMILY_INSTANCES,
                                        (WTCollection) versions.get(PersistenceHelper.getObjectIdentifier(version)),
                                        !unforcedKinds.containsKey(FAMILY_INSTANCES));
                            }
                        }
                        endProfile(4);

                        startProfile(5);
                        for (Iterator j = missedRelations.values().iterator(); j.hasNext();) {
                            Map parentCls = (Map) j.next();

                            for (Iterator k = parentCls.entrySet().iterator(); k.hasNext();) {
                                Map.Entry e = (Map.Entry) k.next();

                                String missedColDefId = (String) e.getKey();

                                if (ignoreToAdd.contains(missedColDefId)) {
                                    continue;
                                }

                                int missedCollectedAsKey = ((CollectionKind) allKinds.get(missedColDefId))
                                        .getCollectedAsKey();

                                for (Iterator m = ((Collection) e.getValue()).iterator(); m.hasNext();) {
                                    collectedData.addAppliedCollection(
                                            cache.getCachedObject(m.next()), missedCollectedAsKey,
                                            true);
                                }
                            }
                        }
                        endProfile(5);

                        if (log.isTraceEnabled()) {
                            log.trace("==Dictionary==");
                            for (Iterator i = dictionary.entrySet().iterator(); i.hasNext();) {
                                Map.Entry e = (Map.Entry) i.next();
                                log.trace("\t" + e.getKey() + "=" + e.getValue());
                            }

                            log.trace("==ftMembers==");
                            for (Iterator i = ftMembers.entrySet().iterator(); i.hasNext();) {
                                Map.Entry e = (Map.Entry) i.next();
                                log.trace("\t" + e.getKey() + "=" + e.getValue());
                            }

                            log.trace("==checkedDependents==");
                            for (Iterator i = checkedDependents.iterator(); i.hasNext();) {
                                log.trace("\t" + i.next());
                            }

                            log.trace("==tracedDependents==");
                            for (Iterator i = tracedDependents.iterator(); i.hasNext();) {
                                log.trace("\t" + i.next());
                            }

                            log.trace("==noDependents==");
                            for (Iterator i = noDependents.iterator(); i.hasNext();) {
                                log.trace("\t" + i.next());
                            }

                            log.trace("==foundRelations==");
                            for (Iterator i = foundRelations.entrySet().iterator(); i.hasNext();) {
                                Map.Entry e = (Map.Entry) i.next();
                                CollectionSrvHelper.trace("\t" + e.getKey(), null, (Collection) e.getValue(), log);
                            }

                            log.trace("==missedRelations==");
                            for (Iterator i = missedRelations.entrySet().iterator(); i.hasNext();) {
                                Map.Entry e = (Map.Entry) i.next();

                                log.trace("\t*" + e.getKey() + "*");

                                Map parentCl = (Map) e.getValue();
                                for (Iterator j = parentCl.entrySet().iterator(); j.hasNext();) {
                                    Map.Entry p = (Map.Entry) j.next();
                                    CollectionSrvHelper.trace("\t\t" + p.getKey(), null, (Collection) p.getValue(),
                                            log);
                                }
                            }
                        }

                        if (hasUnresolvedObjects) {
                            collectedData.setHasUnresolvedObjects();
                        }

                        Set idps = isCollectLinks ? new HashSet() : null;
                        boolean isFiltered = false;

                        if (isCollectLinks) {
                            startProfile(6);
                            Map ngKinds = new HashMap(processedExecutedKinds), vPath = new HashMap(),
                                    ivPath = new HashMap();
                            if (ngKinds.containsKey(NEW_REQUIRED_DEPENDENTS)) {
                                CollectionKind ck = (CollectionKind) allKinds.get(REQUIRED_MEMBER_DEPENDENTS);
                                if (ck != null) {
                                    ngKinds.put(ck.getCollectionServiceKey(), ck);
                                }
                                ck = (CollectionKind) allKinds.get(REQUIRED_REF_DEPENDENTS);
                                if (ck != null) {
                                    ngKinds.put(ck.getCollectionServiceKey(), ck);
                                }
                                ck = (CollectionKind) allKinds.get(REQUIRED_VARIANT_DEPENDENTS);
                                if (ck != null) {
                                    ngKinds.put(ck.getCollectionServiceKey(), ck);
                                }
                            }
                            for (Iterator i = ngKinds.values().iterator(); i.hasNext();) {
                                CollectionKind ck = (CollectionKind) i.next();

                                if (!ck.isNavigatedGraphEmpty()) {
                                    String cdId = ck.getCollectionServiceKey();
                                    CollectionPackage pkg = getCollectionPackage(cdId, customConfig, installedConfig);
                                    String assColId = null;
                                    if (pkg == null) {
                                        assColId = installedConfig.getAssociatedCollectionDefinitionID(cdId);
                                        if (assColId != null) {
                                            pkg = getCollectionPackage(assColId, customConfig, installedConfig);
                                            if (CollectionSrvHelper.isESREnabled) {
                                                if (assColId.equals(CollectorDefinitionIDS.REQUIRED_DEPENDENTS)) {
                                                    assColId = REQUIRED_DEPENDENTS;
                                                }
                                                if (assColId.equals(CollectorDefinitionIDS.OPTIONAL_DEPENDENTS)) {
                                                    assColId = OPTIONAL_DEPENDENTS;
                                                }
                                            }
                                        }
                                    }
                                    CollectionDefinition cd = null;
                                    if (pkg != null) {
                                        cd = assColId == null ? pkg.getCollectionDefinition(cdId)
                                                : pkg.getCollectionDefinition(assColId);
                                    }
                                    if (cd != null) {
                                        long bt = System.currentTimeMillis();
                                        cd.refresh(cache);
                                        Collection nds = cd.getResultList().getNodeValues(cache);
                                        int visibilityOrder = visibleFilteredStatus.getOrder();
                                        boolean refine = cache.getEsrSeed() || cache.getNavigationMarker() != null
                                                || (((filter != null && filter.getFilters() != null
                                                        && !filter.getFilters().isEmpty())
                                                        || cache.getInputParameter(
                                                                CollectionSrvHelper.COMPONENT_LID) != null)),
                                                rcID = cd.getCollectionID().equals(NEW_REQUIRED_DEPENDENTS);

                                        if (log.isTraceEnabled()) {
                                            log.trace("Navigated graphs:");
                                        }
                                        int n = 0;

                                        for (Iterator j = dependents.persistableIterator(); j.hasNext();) {
                                            int collectedAsKey = ck.getCollectedAsKey();
                                            Persistable parent = (Persistable) j.next();

                                            Collection cfos = collectedData.getChildren(parent,
                                                    Integer.valueOf(collectedAsKey));
                                            if ((cfos == null || cfos.isEmpty())
                                                    && collectedAsKey == CollectionKind.OPTIONAL_MEMBER_DEPENDENTS
                                                    && CollectionSrvHelper.isExtSimpRep(parent) && isVis) {
                                                cfos = collectedData.getChildren(parent,
                                                        Integer.valueOf(CollectionKind.REQUIRED_REF_DEPENDENTS));
                                                if (cfos != null) {
                                                    collectedAsKey = CollectionKind.REQUIRED_REF_DEPENDENTS;
                                                }
                                            }

                                            if (cfos != null) {
                                                for (Iterator k = cfos.iterator(); k.hasNext();) {
                                                    String id = cdId;
                                                    CollectedFromObj cfo = (CollectedFromObj) k.next();
                                                    Map upds = new HashMap();
                                                    Persistable pa = (Persistable) cfo.getCollectedFrom(),
                                                            ch = (Persistable) cfo.getCollectedObject();
                                                    NavigationUnit nu = cache.getNavigationUnit(pa, ch, cdId);
                                                    if (nu != null && this.getRequest() > 1
                                                            && cache.isFeatureEnabled(
                                                                    CollectionRequest.UPDATE_CACHE_DURING_INCREMENTAL_REQUEST)
                                                            && !cdId.equals(PROCESS_PLAN)) {
                                                        nu = cd.getNavigatedGraph(pa, ch, cfo.getLinks(),
                                                                visibleFilteredStatus, cache, upds);
                                                        collectedData.addGraph(collectedAsKey, (NavigatedGraph) nu);
                                                    }
                                                    if (nu == null && assColId != null) {
                                                        nu = cache.getNavigationUnit(pa, ch, assColId);
                                                        id = assColId;
                                                    }
                                                    if (nu == null && rcID) {
                                                        nu = cache.getNavigationUnit(pa, ch,
                                                                REQUIRED_MEMBER_DEPENDENTS);
                                                        id = REQUIRED_MEMBER_DEPENDENTS;
                                                    }
                                                    if (nu == null && rcID) {
                                                        nu = cache.getNavigationUnit(pa, ch, REQUIRED_REF_DEPENDENTS);
                                                        id = REQUIRED_REF_DEPENDENTS;
                                                    }
                                                    if (nu != null && log.isTraceEnabled()) {
                                                        log.trace("Retrieved from cache:\n" + nu);
                                                    }
                                                    if (nu == null) {
                                                        boolean isFound = true;
                                                        if (!nds.contains(pa)) {
                                                            if (pa instanceof Iterated
                                                                    && !nds.contains(((Iterated) pa).getMaster())) {
                                                                isFound = false;
                                                                log.trace("Missed parent=" + pa);
                                                            }
                                                        }

                                                        if (!nds.contains(ch)) {
                                                            if (ch instanceof Iterated
                                                                    && !nds.contains(((Iterated) ch).getMaster())) {
                                                                isFound = false;
                                                                log.trace("Missed child=" + ch);
                                                            }
                                                        }

                                                        if (isFound) {
                                                            Collection<Persistable> links = cfo.getLinks();
                                                            if (ch instanceof WTDocument && links != null
                                                                    && !links.isEmpty()
                                                                    && cfo.getCollectionKey() == CollectionRequest.PSB_WTPART_RELATED_WTDOCUMENTS
                                                                    && !cache.isValidMasterDuplicate((Iterated) ch)) {
                                                                links = new HashSet(links);
                                                                for (Iterator it = links.iterator(); it.hasNext();) {
                                                                    Object lnk = it.next();
                                                                    if (lnk instanceof WTPartReferenceLink) {
                                                                        it.remove();
                                                                    }
                                                                }
                                                            }
                                                            nu = cd.getNavigatedGraph(pa, ch, links,
                                                                    visibleFilteredStatus, cache, upds);
                                                            id = "cd " + cd.getCollectionID();
                                                            if (getId() != null) {
                                                                cache.addNavigationUnit(
                                                                        Arrays.asList(new NavigationUnit[] { nu }),
                                                                        cdId);
                                                            }
                                                        }
                                                        else {
                                                            log.trace("Found=" + nds);
                                                        }
                                                    }
                                                    if (nu != null && nu.getFilteredStatus(nu.getEndNode())
                                                            .getOrder() <= visibilityOrder) {
                                                        if (refine) {
                                                            Persistable ri = nu.getTags(nu.getEndNode(),
                                                                    ReplaceIterationWithMasterEndNodeTag.class, false)
                                                                    .isEmpty() ? null
                                                                            : ((Iterated) nu.getEndNode()).getMaster();
                                                            nu = cache.getNavigatedGraph(nu, visibilityOrder, false,
                                                                    vPath, ivPath);
                                                            if (ri != null) {
                                                                upds.put(ri, cfo.getLinks());
                                                            }
                                                        }

                                                        if (nu != null && isLightReturnEnabled) {
                                                            nu = new NavigatedGraph(nu.getStartNode(), nu.getEndNode(),
                                                                    null);
                                                        }

                                                        if (nu != null) {
                                                            collectedData.addGraph(collectedAsKey, (NavigatedGraph) nu);
                                                            if (log.isTraceEnabled()) {
                                                                log.trace((++n) + ". " + (refine ? "after refine " : "")
                                                                        + id + "\n" + nu);
                                                            }
                                                            idps.remove(ch);

                                                            if (!upds.isEmpty()) {
                                                                collectedData.addAllDependents(upds.keySet());
                                                                collectedData.addDependents(parent,
                                                                        cfo.getCollectionKey(), upds,
                                                                        cfo.isCollectedByForce());
                                                            }

                                                        }
                                                        else {
                                                            idps.add(ch);
                                                            isFiltered = true;
                                                        }
                                                    }
                                                    else {
                                                        idps.add(ch);
                                                        isFiltered = true;
                                                    }
                                                }
                                            }
                                        }
                                        if (log.isTraceEnabled()) {
                                            log.trace("Excluded parents:" + idps);
                                        }
                                        if (log.isDebugEnabled()) {
                                            log.debug("Built navigated graph for " + cd.getCollectionID() + "," + cdId
                                                    + "=" + (System.currentTimeMillis() - bt) + "ms");
                                        }
                                    }
                                }
                            }
                            endProfile(6);
                        }

                        collectedData.setHasVirtualElements(cache.hasClonedPaths());

                        if (isFiltered) {
                            collectedData.refineDependents();
                            if (log.isDebugEnabled()) {
                                log.debug("remaining dependents=" + collectedData.getCollectedObjects().size());
                            }
                        }

                        if (cache.isSuspended()) {
                            collectedData.setWasIncompleted();
                            if (cache.getChunk() > 1) {
                                collectedData.removeEmptySeeds(seeds.persistableCollection());
                            }
                        }
                        else {
                            cache.removeChunkInfo();
                        }

                        if (log.isDebugEnabled()) {
                            log.debug("<<Build collector result[" + dependents.size() + ","
                                    + (System.currentTimeMillis() - time) + "] " + log.freeMem());
                        }

                        if (log.isTraceEnabled() && isCollectLinks) {
                            log.trace("===Linked Objects===");
                            for (Iterator i = dependents.persistableIterator(); i.hasNext();) {
                                Persistable dependent = (Persistable) i.next();

                                Collection cfos = collectedData.getCollectedFromObjs(dependent);

                                if (cfos != null) {
                                    log.trace("Collection of linked objects for "
                                            + CollectionSrvHelper.getObjectInfo(dependent) + " :");

                                    for (Iterator k = cfos.iterator(); k.hasNext();) {
                                        CollectedFromObj cfo = (CollectedFromObj) k.next();

                                        StringBuffer b = new StringBuffer("\t" + cfo.getCollectionKey() + "*"
                                                + CollectionSrvHelper.getObjectInfo(cfo.getCollectedFrom()));

                                        if (cfo != null && cfo.getLinks() != null) {
                                            for (Iterator j = cfo.getLinks().iterator(); j.hasNext();) {
                                                b.append("*link=" + j.next());
                                            }
                                        }
                                        else {
                                            b.append("*no link");
                                        }

                                        log.trace(b.toString());
                                    }
                                }
                            }
                        }

                        startProfile(7);
                        boolean isForceExpandCheck = (rff != null
                                && rff.contains(CollectionRequest.FORCE_EXPAND_CHECK)), isExpandableCheck = true,
                                isRecursiveCollectionExecuted = false, isRelatedCollectionExecuted = false,
                                isComponentPath = cache
                                        .getInputParameter(CollectionRequest.COMPONENT_IDENTIFIERS) != null
                                        || (cache.printInputParameter(CollectionSrvHelper.COMPONENT_LID) != null
                                                && isForceExpandCheck);

                        for (Iterator i = executedKinds.values().iterator(); i.hasNext() && isExpandableCheck;) {
                            CollectionKind kind = (CollectionKind) i.next();
                            // kind.getRecursionLimit() != -1 nmarne:Int:6170150:check leaf node isParent.
                            if (kind.getRecursionLimit() != -1 || isForceExpandCheck) {
                                String colId = kind.getCollectionServiceKey();
                                CollectionPackage pkg = getCollectionPackage(colId, customConfig, installedConfig);
                                if (pkg == null) {
                                    colId = installedConfig.getAssociatedCollectionDefinitionID(colId);
                                    if (colId != null) {
                                        pkg = getCollectionPackage(colId, customConfig, installedConfig);
                                    }
                                }
                                if (pkg != null) {
                                    CollectionDefinition colDef = pkg.getCollectionDefinition(colId);

                                    if (colDef.hasRecursionRetriever()) {
                                        isRecursiveCollectionExecuted = true;
                                        if (!(kind.getFeatures() == null || !kind.getFeatures()
                                                .contains(CollectionRequest.WITHOUT_CHECK_FOR_CHILDREN_FEATURE))) {
                                            isExpandableCheck = false;
                                        }

                                        if (cache.getNavigationMarker() != null) {
                                            if (ut == null) {
                                                ut = new HashSet();
                                            }
                                            ut.add(colId);
                                        }
                                    }
                                    else if (!isRelatedCollectionExecuted &&
                                            !(colId.equals(REQUIRED_MEMBER_DEPENDENTS) ||
                                                    colId.equals(REQUIRED_REF_DEPENDENTS) ||
                                                    colId.equals(REQUIRED_VARIANT_DEPENDENTS) ||
                                                    colId.equals(OPTIONAL_MEMBER_DEPENDENTS) ||
                                                    colId.equals(OPTIONAL_REF_DEPENDENTS) ||
                                                    colId.equals(OPTIONAL_VARIANT_DEPENDENTS) ||
                                                    colId.equals(FAMILY) ||
                                                    colId.equals(INSEPARABLE_FAMILY) ||
                                                    colId.equals(FAMILY_INSTANCES) ||
                                                    colId.equals(DRAWINGS) ||
                                                    colId.equals(FAMILY_GENERICS))) {
                                        isRelatedCollectionExecuted = true;
                                    }
                                }
                            }
                            else {
                                isExpandableCheck = false;
                            }
                        }

                        if (!isExpandableCheck && isComponentPath && isForceExpandCheck) {
                            isExpandableCheck = true;
                        }

                        if (log.isDebugEnabled()) {
                            log.debug("isRelatedCollectionExecuted=" + isRelatedCollectionExecuted
                                    + " isRecursiveCollectionExecuted=" + isRecursiveCollectionExecuted
                                    + " isExpandableCheck=" + isExpandableCheck);
                        }

                        if (isExpandableCheck) {
                            Collection pseeds = new HashSet(collectedData.getCollectedObjects());
                            pseeds.removeAll(collectedData.getParents());
                            if (idps != null && !idps.isEmpty()) {
                                pseeds.removeAll(idps);
                            }
                            if (cache.getExpandedAll()) {
                                Collection cpseeds = cache.getHavingChildren(pseeds);
                                if (!cpseeds.isEmpty()) {
                                    for (Object cpseed : cpseeds) {
                                        pseeds.remove(cpseed);
                                        collectedData.addParent((Persistable) cpseed);
                                    }
                                }
                            }

                            if (isRelatedCollectionExecuted || isRecursiveCollectionExecuted || isComponentPath) {
                                for (Iterator i = executedKinds.entrySet().iterator(); i.hasNext()
                                        && !pseeds.isEmpty();) {
                                    Map.Entry e = (Map.Entry) i.next();
                                    Object key = e.getKey();
                                    if (ut != null && ut.contains(key)) {
                                        if (log.isDebugEnabled()) {
                                            log.debug("light check's done for " + key);
                                        }
                                        if (!isComponentPath) {
                                            continue;
                                        }
                                    }

                                    String nept = ((CollectionKind) e.getValue()).getNotExpandableTypes();
                                    if (nept != null) {
                                        Class seedCl = cache.getSeeds().iterator().next().getClass();
                                        cache.setNotExpandableTypes(nept);
                                        WTCollection vseeds = cache.getValidParents(new WTArrayList(pseeds), seedCl);
                                        if (vseeds.size() < pseeds.size()) {
                                            pseeds = vseeds.persistableCollection();
                                        }
                                        cache.setNotExpandableTypes(null);
                                    }

                                    HashMap ex = new HashMap();
                                    ex.put(e.getKey(), e.getValue());
                                    if (e.getKey().equals(CollectorDefinitionIDS.WTPART_OCCURENCE)) {
                                        filterSeedsMarkedAsNoTraverse(pseeds);
                                        time = System.currentTimeMillis();
                                        Set links = null;
                                        try {
                                            links = CollectionSrvHelper.getParentsByLinks(WTPartUsageLink.class,
                                                    WTAttributeNameIfc.ROLEA_OBJECT_ID, pseeds);
                                        } catch (WTPropertyVetoException ve) {
                                            throw new WTException(ve);
                                        }

                                        seeds = new WTHashSet();
                                        dependents = new WTHashSet();
                                        for (Iterator j = pseeds.iterator(); j.hasNext();) {
                                            Persistable seed = (Persistable) j.next();
                                            if (links.contains(BigDecimal
                                                    .valueOf(PersistenceHelper.getObjectIdentifier(seed).getId()))) {
                                                if (CollectionSrvHelper.isAccurateCheck) {
                                                    seeds.add(seed);
                                                }
                                                else {
                                                    collectedData.addParent(seed);
                                                    j.remove();
                                                }
                                            }
                                        }
                                        if (!seeds.isEmpty()) {
                                            getDependents(ex, new HashMap(), ex, seeds, dependents, true,
                                                    installedConfig, customConfig, processed, processedExecutedKinds,
                                                    ignoreToAdd, forcedKinds, wsObjs, wtCollectedObjects, types,
                                                    initSeeds, filter, collectedData);

                                            if (log.isDebugEnabled()) {
                                                log.debug("<<Parents request[1," + pseeds.size() + ","
                                                        + collectedData.getParents().size() + "," + seeds.size() + ","
                                                        + (System.currentTimeMillis() - time) + "] " + log.freeMem());
                                            }
                                            pseeds.removeAll(collectedData.getParents());
                                        }

                                        if (executedKinds.size() == 1) {
                                            pseeds.clear();
                                        }
                                    }

                                    if (!pseeds.isEmpty()) {
                                        time = System.currentTimeMillis();
                                        seeds = new WTHashSet(pseeds);
                                        dependents = new WTHashSet(pseeds);

                                        getDependents(ex, new HashMap(), ex, seeds, dependents, true, installedConfig,
                                                customConfig, processed, processedExecutedKinds, ignoreToAdd,
                                                forcedKinds, wsObjs, wtCollectedObjects, types, initSeeds, filter,
                                                collectedData);
                                        if (log.isDebugEnabled()) {
                                            log.debug("<<Parents request[2," + pseeds.size() + ","
                                                    + (System.currentTimeMillis() - time) + "] " + log.freeMem());
                                        }
                                        pseeds.removeAll(collectedData.getParents());

                                    }
                                }
                            }

                            if (log.isTraceEnabled() || request == 1) {
                                if (log.isTraceEnabled()) {
                                    log.trace("Found parents:\n");
                                }
                                for (Object p : collectedData.getParents()) {
                                    if (log.isTraceEnabled()) {
                                        log.trace("\t" + CollectionSrvHelper.getObjectInfo(p));
                                    }
                                    if (request == 1) {
                                        cache.addRootParents(p);
                                    }
                                }
                            }

                            if (log.isDebugEnabled()) {
                                log.debug("Found #" + collectedData.getParents().size() + " parents");
                            }
                        }
                    }
                    endProfile(7);
                }

                if (!cache.getExpandedAll()
                        && ((cache.getNavigationMarker() != null && cache.getNavigationMarker().requiresExpandAll())
                                || (rff != null && rff.contains(CollectionRequest.FIND_IN_CACHE)))) {
                    cache.setExpandedAll(true);
                }

                updateCacheHolders();

                boolean isUnlimited = false, isRecursionRetriever = false, isProcessPlan = false;
                if (CollectorCacheServerHelper.isCTEnabled() && collectionsToExecute != null
                        && !collectionsToExecute.isEmpty() && getId() != null
                        && cache.getOccurrenceIdentifiers() == null) {
                    startProfile(8);
                    for (Iterator i = collectionsToExecute.iterator(); i.hasNext() && !isRecursionRetriever;) {
                        CollectionKind ck = (CollectionKind) i.next();
                        String colDefId = ck.getCollectionServiceKey();
                        isProcessPlan = colDefId.equals(PROCESS_PLAN);
                        CollectionPackage pkg = installedConfig.getPackageByCollectionID(colDefId);
                        if (pkg == null) {
                            colDefId = installedConfig.getAssociatedCollectionDefinitionID(colDefId);
                            if (colDefId != null) {
                                pkg = getCollectionPackage(colDefId, customConfig, installedConfig);
                            }
                        }
                        if (pkg != null && pkg.getCollectionDefinition(colDefId).hasRecursionRetriever()) {
                            isRecursionRetriever = true;
                            isUnlimited = ck.getRecursionLimit() == DTRequest.UNLIMITED_TRACING;
                        }
                    }
                    boolean isAdd = false;
                    if (cache.getExpandedAll() || isUnlimited || cache.getNavigationMarker() != null) {
                        isAdd = true;
                    }
                    else if (!cache.getExpandedAll() && !isUnlimited) {
                        isAdd = true;
                    }
                    else if (cache.isSuspended()) {
                        isAdd = true;
                    }

                    if (isAdd) {
                        Set features = rff == null ? null : new HashSet(rff);
                        if (features != null && !featuresToSkipCaching.isEmpty()) {
                            features.removeAll(featuresToSkipCaching);
                        }

                        boolean isCR = !isUnlimited || cache.getNavigationMarker() != null || !cache.getExpandedAll()
                                || cache.isSuspended();
                        Object[] chunks = cache.isSuspended() ? cache.getChunkInfo() : null;

                        long d = cache.getExpandedAll() && isProcessPlan && isUnlimited ? 40 * 60 * 1000 : 0;
                        boolean isCached = CollectorCacheServerHelper.addCr(getId(),
                                new Object[] { isCR ? null : collectedData,
                                        chunks != null ? chunks : cache.getDependents(), Integer.valueOf(request),
                                        features, collectionsToExecute, null },
                                d);

                        if (log.isDebugEnabled()) {
                            log.debug("added to map[" + getId() + "," + cache.getExpandedAll() + "," + isUnlimited + ","
                                    + (cache.getNavigationMarker() != null) + "," + request + "," + !isCR + ","
                                    + cache.isSuspended() + "," + d + "," + isCached + "]");
                        }
                    }
                    endProfile(8);
                }

                if (request == 1 && rff != null
                        && rff.contains(CollectionRequest.USE_CACHE_WITHOUT_TRACING_AND_FILTERING)) {
                    cache.setIsCacheOnlyEnabled(true);
                }

                if (!cache.getExpandedAll() && ut != null) {
                    ut.clear();
                }

                releaseParameters(!cache.isSimpleCollector());

                if (getId() == null && path_ndi != null && seeds.size() == 1) {
                    String pathID = path_ndi + seeds.iterator().next().toString();
                    CollectorCacheServerHelper.addCr(pathID, new Object[] { collectedData });
                    if (log.isDebugEnabled()) {
                        log.debug("added ndi path " + pathID + " to map");
                    }
                }

                if (getId() != null) {
                    cache.deflate();
                }

                restore(new Collection[] { collectionRules, collectionsToExecute, collectionsToAdd });
            }
        } catch (RuntimeException re) {
            cache.setQueryException(re);
        } catch (Exception cex) {
            cache.setQueryException(cex);
        }

        Throwable qe = cache.getQueryException();
        if (qe == null && cache.isAborted()) {
            WTMessage msg = new WTMessage(resource, htmlcompResource.DEPENDENCY_TRACING_WAS_ABORTED,
                    new Object[] { String.valueOf(cache.getComponentLimit()) });
            qe = new DependencyTracingLimitExceededException(msg);
            log.error("Was aborted");
        }

        locale = null;

        if (qe != null) {
            collectedData = new CollectorResult();
            collectedData.setException(qe instanceof WTException ? (WTException) qe : new WTException(qe));
            if (cache.isAborted()) {
                collectedData.setWasAborted();
            }
        }

        crData = null;
        if (installedConfig != null) {
            installedConfig.release();
            installedConfig = null;
        }

        if (customConfig != null) {
            customConfig.release();
            customConfig = null;
        }

        startProfile(9);
        collectedData.setEsrMemberLink(cache.getEsrs());
        endProfile(9);
        collectedData.setWasPathToOccurrenceAlwaysRequested(cache.wasPathToOccurrenceAlwaysRequested());

        if (log.isDebugEnabled()) {
            /*
             * if( collectedData!=null) printProfile("Collector result usage", collectedData.getProfiler());
             */

            printProfile("UICollector usage", times);

            if (cache != null) {
                log.debug("collected " + cache.getCollectedUnitsSize());
                printProfile("Cache usage", cache.getProfiler());
            }
        }

        return collectedData;
    }

    private void filterSeedsMarkedAsNoTraverse(Collection seeds) {
        if (!cache.ignoreFilteredStatusEnabled()) {
            Iterator seedsIterator = seeds.iterator();
            while (seedsIterator.hasNext()) {
                Persistable seed = (Persistable) seedsIterator.next();
                if (FilteredStatus.NOT_FILTERED_NO_TRAVERSE.equals(cache.getWeakestFilteredStatus(seed))) {
                    seedsIterator.remove();
                }
            }
        }
    }

    private void restore(Collection[] rules) {
        if (CollectionSrvHelper.isESREnabled) {
            for (int j = 0; j < rules.length; j++) {
                if (rules[j] != null && !rules[j].isEmpty()) {
                    for (Iterator i = rules[j].iterator(); i.hasNext();) {
                        Object rule = i.next();

                        if (rule instanceof CollectionKind) {
                            CollectionKind kind = (CollectionKind) rule;
                            try {
                                if (kind.getCollectionServiceKey().equals(NEW_REQUIRED_DEPENDENTS)) {
                                    kind.setCollectionServiceKey(OLD_REQUIRED_DEPENDENTS);
                                }
                                else if (kind.getCollectionServiceKey().equals(NEW_OPTIONAL_DEPENDENTS)) {
                                    kind.setCollectionServiceKey(OLD_OPTIONAL_DEPENDENTS);
                                }
                            } catch (WTPropertyVetoException e) {
                                log.error(e, e);
                            }
                        }
                    }
                }
            }
        }
    }

    private void addMessage(CollectorResult collectedData, Object obj, WTMessage m, int type) throws WTException {
        if (m != null) {
            addMessage(collectedData, obj, new Message(m.getLocalizedMessage(locale), type));
        }
    }

    private void addMessage(CollectorResult collectedData, Object obj, Message msg) {
        collectedData.addMessage(obj, msg);

        if (log.isDebugEnabled()) {
            log.debug(CollectionSrvHelper.getObjectInfo(obj, true, true) + ": " + msg.getMessage() + " with severity="
                    + msg.getSeverity());
        }
    }

    private HashMap getKinds(Collection rules, String msg, boolean printRecursion, boolean checkModifiers, Map add,
            CollectionConfig installedConfig) throws WTException {
        HashMap ret = new HashMap();
        try {
            if (rules != null) {
                for (Iterator i = rules.iterator(); i.hasNext();) {
                    Object rule = i.next();

                    if (rule instanceof UICollectionRuleUsage) {
                        UICollectionRuleUsage ruleUsage = (UICollectionRuleUsage) rule;
                        HashSet kinds = getRuleUsageCollectionKinds(ruleUsage);

                        if (kinds != null) {
                            for (Iterator k = kinds.iterator(); k.hasNext();) {
                                CollectionKind kind = (CollectionKind) k.next();
                                String key = kind.getCollectionServiceKey();
                                if (key.equals(OLD_REQUIRED_DEPENDENTS)) {
                                    key = REQUIRED_DEPENDENTS;
                                    kind = getUpdatedCollectionKind(key, kind);
                                }
                                else if (key.equals(OLD_OPTIONAL_DEPENDENTS)) {
                                    key = OPTIONAL_DEPENDENTS;
                                    kind = getUpdatedCollectionKind(key, kind);
                                }
                                addKind(ret, checkModifiers, key, kind, add != null, installedConfig);
                            }
                        }
                    }
                    else if (rule instanceof CollectionKind) {
                        CollectionKind kind = (CollectionKind) rule;

                        String key = kind.getCollectionServiceKey();
                        if (key.equals(OLD_REQUIRED_DEPENDENTS)) {
                            kind = getUpdatedCollectionKind(NEW_REQUIRED_DEPENDENTS, kind);
                            if (!isCollector && kind.getRecursionLimit() == CollectionKind.RECURSION_UNLIMITED) {
                                ignoreND = true;
                            }

                        }
                        else if (key.equals(OLD_OPTIONAL_DEPENDENTS)) {
                            kind = getUpdatedCollectionKind(NEW_OPTIONAL_DEPENDENTS, kind);
                            if (!isCollector && kind.getRecursionLimit() == CollectionKind.RECURSION_UNLIMITED) {
                                ignoreND = true;
                            }
                        }
                        else if ((key.equals(UPSTREAM_DERIVED) || key.equals(DOWNSTREAM_DERIVED))
                                && kind.getScope().equals(SEEDS)) {
                            kind.setRecursionLimit(1);
                        }
                        addKind(ret, checkModifiers, kind.getCollectionServiceKey(), kind, add != null,
                                installedConfig);

                        if (kind.getFeatures() != null) {
                            if (rff == null) {
                                rff = new HashSet();
                            }
                            rff.addAll(kind.getFeatures());
                        }

                        if (kind.getRecursionLimit() == CollectionKind.RECURSION_UNLIMITED && add != null) {
                            if (ut == null) {
                                ut = new HashSet();
                            }
                            ut.add(kind.getCollectionServiceKey());
                        }

                        if (checkModifiers && isRecursion) {
                            CollectionDefinition colDef = getCollectionDefinition(installedConfig, key);
                            isRecursion = colDef != null && colDef.hasRecursionRetriever();
                        }
                    }
                }
            }

            if (add != null && ret.containsKey(NEW_OPTIONAL_DEPENDENTS) && ret.containsKey(NEW_REQUIRED_DEPENDENTS)) {
                for (Iterator i = ret.entrySet().iterator(); i.hasNext();) {
                    Map.Entry e = (Map.Entry) i.next();
                    String key = (String) e.getKey();
                    if (key.equals(NEW_REQUIRED_DEPENDENTS) || key.equals(REQUIRED_MEMBER_DEPENDENTS)
                            || key.equals(REQUIRED_REF_DEPENDENTS) || key.equals(REQUIRED_VARIANT_DEPENDENTS)) {
                        add.put(key, e.getValue());
                        i.remove();
                        if (log.isTraceEnabled()) {
                            log.trace("Moved to collection to add: " + key);
                        }
                    }
                }
            }

            if (add != null) {
                if (ret.isEmpty()) {
                    isWhereUsed = false;
                }
                else if (isWhereUsed && request == 1) {
                    CollectionKind kind = (CollectionKind) ret.values().iterator().next();
                    if (kind.getRecursionLimit() != CollectionKind.RECURSION_UNLIMITED) {
                        cache.setIsSimpleCollector(false);
                    }
                }
            }

            if (log.isDebugEnabled()) {
                StringBuffer b = new StringBuffer();

                b.append("\t" + msg + " [" + (rules == null ? 0 : rules.size()) + "]:");

                if (!ret.isEmpty()) {
                    b.append("\n\t");

                    for (Iterator i = ret.entrySet().iterator(); i.hasNext();) {
                        Map.Entry e = (Map.Entry) i.next();
                        b.append(" " + e.getKey());
                        CollectionKind ck = (CollectionKind) e.getValue();

                        if (printRecursion) {
                            Set fs = ck.getFeatures();
                            b.append("[" + ck.getScope() + "," + ck.getRecursionLimit()
                                    + (ck.getExpandableTypes() != null ? ",expandable " + ck.getExpandableTypes() : "")
                                    + (ck.getNotExpandableTypes() != null
                                            ? ",not expandable " + ck.getNotExpandableTypes()
                                            : "")
                                    + (fs != null && !fs.isEmpty() ? "," + ck.getFeatures() : "")
                                    + (ck.getCollectionQueryParameters() != null
                                            ? ",collection query parameters " + ck.getCollectionQueryParameters()
                                            : ""));
                            long[] compId = ck.getComponents();
                            if (compId != null) {
                                for (int n = 0; n < compId.length; n++) {
                                    b.append((n == 0 ? ",{" : ",") + compId[n]);
                                }
                                b.append("}");
                            }

                            b.append("]");
                        }
                    }
                }

                log.debug(b.toString());
            }
        } catch (WTPropertyVetoException e) {
            throw new WTException(e);
        }

        return ret;
    }

    private void addKind(Map ret, boolean checkModifiers, String key, CollectionKind kind, boolean isExecute,
            CollectionConfig installedConfig) {
        ret.put(key, kind);
        int cas = kind.getCollectedAsKey();
        if (checkModifiers && isWhereUsed) {
            if (!(cas == CollectionRequest.CAD_WHERE_USED || cas == CollectionRequest.WTPART_WHERE_USED
                    || cas == CollectionRequest.WTDOC_WHERE_USED)) {
                isWhereUsed = false;
            }
        }
        if (isExecute && cache != null && !cache.isSimpleCollectorDefined()) {
            String cID = kind.getCollectionServiceKey();
            CollectionPackage colDefPkg = installedConfig.getPackageByCollectionID(cID);
            CollectionDefinition colDef = colDefPkg == null ? null : colDefPkg.getCollectionDefinition(cID);
            if (colDef != null && colDef.hasRecursionRetriever()
                    && !(cas == CollectionRequest.CAD_WHERE_USED || cas == CollectionRequest.WTPART_WHERE_USED
                            || cas == CollectionRequest.WTDOC_WHERE_USED || cas == CollectionRequest.UPSTREAM_DERIVED
                            || cas == CollectionRequest.DOWNSTREAM_DERIVED)) {
                cache.setIsSimpleCollector(kind.getRecursionLimit() == DTRequest.UNLIMITED_TRACING && !isCollectLinks);
            }
        }
    }

    private HashSet getRuleUsageCollectionKinds(UICollectionRuleUsage ruleUsage) {
        HashSet ret = new HashSet();
        if (ruleUsage instanceof AtomicUICollectionRuleUsage) {
            Vector options = ((AtomicUICollectionRule) ruleUsage.getRule()).getOptions();

            if (options != null) {
                for (Iterator j = options.iterator(); j.hasNext();) {
                    UICollectionRuleOption option = (UICollectionRuleOption) j.next();
                    Vector kinds = option.getCollections();
                    if (kinds != null) {
                        ret.addAll(kinds);
                    }
                }
            }
        }
        else if (ruleUsage instanceof UICollectionRuleGroupUsage) {
            Vector usages = ((UICollectionRuleGroupUsage) ruleUsage).getRuleUsages();
            if (usages != null) {
                for (Iterator j = usages.iterator(); j.hasNext();) {
                    ret.addAll(getRuleUsageCollectionKinds((UICollectionRuleUsage) j.next()));
                }
            }
        }

        return ret;
    }

    private WTCollection getValidSeeds(CollectorResult collectedData, Collection seeds, HashMap allKinds,
            ConfigSpecHolder configSpecs, NavigationCriteria filter) throws WTException {
        if (seedsValidator != null && (sValidator == null || !sValidator.getClass().getName().equals(seedsValidator))) {
            try {
                sValidator = Class.forName(seedsValidator).newInstance();
            } catch (Exception e) {
                log.error("Invalid seed validator class=" + seedsValidator);
                CollectionSrvHelper.getStackTrace(e, log);
                throw new WTException(e);
            }
        }

        if (log.isTraceEnabled()) {
            log.trace(getTracedObjects("\tseeds", seeds));
        }
        else if (log.isDebugEnabled() && seeds.size() < 2) {
            log.debug(getTracedObjects("\tseeds", seeds));
        }

        HashSet validSeeds = new HashSet(seeds.size());
        if (configSpecs != null && configSpecs.isReplaceSeeds() && request == 1) {
            seeds = CollectionSrvHelper.getFilteredIterations(seeds, configSpecs.getSpecsMap(), filter, cache, false);
        }

        if (sValidator != null) {
            ArrayList tmp = new ArrayList(seeds);

            List dvs = ((DataValidator) sValidator).validate(tmp, locale);

            for (int i = 0; i < dvs.size(); i++) {
                DataValidity dv = (DataValidity) dvs.get(i);
                Object seed = tmp.get(i);

                if (!dv.getValidFlag()) {
                    addMessage(collectedData, seed, new Message(dv.getMessage(), Message.FATAL));
                }
                else if (isValidCollectable(seed)) {
                    validSeeds.add(seed);
                }
            }
        }
        else {
            for (Iterator j = seeds.iterator(); j.hasNext();) {
                Object seed = j.next();

                if (isValidCollectable(seed)) {
                    validSeeds.add(seed);

                    if (!(seed instanceof Iterated) && !(seed instanceof ObjectToObjectLink)) {
                        collectedData.addAllDependents(Arrays.asList(new Object[] { seed }));
                    }
                }
            }
        }

        if (isUseLatestVersionForDuplicatedSeedMaster) {
            HashMap duplicated = new HashMap(seeds.size());

            for (Iterator i = validSeeds.iterator(); i.hasNext();) {
                Object seed = i.next();

                if (seed instanceof Iterated) {
                    Iterated iter = (Iterated) seed;
                    ObjectIdentifier masterID = iter.getMasterReference().getObjectId();

                    HashSet iters = (HashSet) duplicated.get(masterID);
                    if (iters == null) {
                        iters = new HashSet();
                        duplicated.put(masterID, iters);
                    }
                    iters.add(iter);
                }
            }
            for (Iterator i = duplicated.entrySet().iterator(); i.hasNext();) {
                Map.Entry e = (Map.Entry) i.next();

                HashSet iters = (HashSet) e.getValue();

                if (iters.size() > 1) {
                    if (log.isTraceEnabled()) {
                        log.trace(getTracedObjects("\tduplicated iterations of master " + e.getKey(), iters));
                    }
                    Persistable latest = (Persistable) latestConfigSpec
                            .process(new QueryResult(new ObjectVector(new Vector(iters)))).nextElement();
                    WTMessage msg = new WTMessage(resource,
                            htmlcompResource.LATEST_VERSION_WAS_TAKEN_TO_COLLECT_DEPENDENTS,
                            new Object[] { CollectionSrvHelper.getVersionDisplay((Iterated) latest) });
                    long latestID = PersistenceHelper.getObjectIdentifier(latest).getId();

                    for (Iterator j = iters.iterator(); j.hasNext();) {
                        Iterated iter = (Iterated) j.next();
                        if (PersistenceHelper.getObjectIdentifier(iter).getId() != latestID) {
                            validSeeds.remove(iter);

                            addMessage(collectedData, iter, msg, Message.FATAL);
                        }
                    }
                }
            }
        }

        if (validSeeds.size() != seeds.size()) {
            HashSet invalidSeeds = new HashSet();

            for (Iterator i = seeds.iterator(); i.hasNext();) {
                Object seed = i.next();

                if (!validSeeds.contains(seed)) {
                    invalidSeeds.add(seed);
                }
            }

            collectedData.addAllDependents(invalidSeeds);

            if (log.isTraceEnabled()) {
                log.debug(getTracedObjects("\tvalid seeds", validSeeds));
            }
            else if (log.isDebugEnabled() && validSeeds.size() < 2) {
                log.debug(getTracedObjects("\tvalid seeds", validSeeds));
            }
        }

        for (Iterator i = validSeeds.iterator(); i.hasNext();) {
            Persistable p = (Persistable) i.next();
            if (wrkCanBeCreatedOlyInEPMWorkspace) {
                wrkCanBeCreatedOlyInEPMWorkspace = CollectionSrvHelper.wrkCanBeCreatedOlyInEPMWorkspace(p);
            }
            validateFTMember(p);
            if (request == 1 && !cache.getEsrSeed() && CollectionSrvHelper.isExtSimpRep(p)) {
                cache.setEsrSeed(true);
            }
        }

        return new WTHashSet(validSeeds);
    }

    private HashMap getValidKinds(WTCollection seeds, Map executedKinds, CollectionConfig installedConfig, Map types)
            throws WTException {
        HashMap ret = new HashMap();

        if (seeds != null && !seeds.isEmpty() && executedKinds != null && !executedKinds.isEmpty()) {
            Set validPkg = new HashSet();

            for (Iterator i = executedKinds.entrySet().iterator(); i.hasNext();) {
                Map.Entry e = (Map.Entry) i.next();
                String key = (String) e.getKey(), colDefId = key;

                CollectionPackage colDefPkg = installedConfig.getPackageByCollectionID(colDefId);
                if (colDefPkg == null) {
                    colDefId = installedConfig.getAssociatedCollectionDefinitionID(colDefId);
                    if (colDefId != null) {
                        colDefPkg = installedConfig.getPackageByCollectionID(colDefId);
                    }
                }
                CollectionDefinition colDef = colDefPkg == null ? null : colDefPkg.getCollectionDefinition(colDefId);

                if (colDef != null && CollectionSrvHelper.hasValidSeed(colDef, seeds, types, false, null)) {
                    validPkg.add(colDefPkg);
                }
            }

            for (Iterator i = executedKinds.entrySet().iterator(); i.hasNext();) {
                Map.Entry e = (Map.Entry) i.next();
                String key = (String) e.getKey(), colDefId = key;

                CollectionPackage colDefPkg = installedConfig.getPackageByCollectionID(colDefId);
                if (colDefPkg != null && validPkg.contains(colDefPkg)) {
                    ret.put(key, e.getValue());
                }
            }

            if (log.isTraceEnabled() && !ret.isEmpty()) {
                log.trace("Valid collections: " + ret.keySet());
            }
        }

        return ret;
    }

    private boolean isValidCollectable(Object collectable) {
        // For now check and see if Persistable.
        return collectable instanceof Persistable;
    }

    private String getTracedObjects(String msg, Collection c) throws WTException {
        StringBuffer b = new StringBuffer();

        b.append(msg + "[" + (c == null ? 0 : c.size()) + "]:");

        if (c != null) {
            for (Iterator i = c.iterator(); i.hasNext();) {
                b.append("\n\t" + CollectionSrvHelper.getObjectInfo(i.next(), true, true));
            }
        }
        return b.toString();
    }

    private boolean getDependents(HashMap executedKinds, HashMap addKinds, HashMap allKinds, WTCollection seeds,
            WTCollection dependents, boolean isQuickCheck, CollectionConfig installedConfig,
            CollectionConfig customConfig, HashMap processed, HashMap processedExecutedKinds, HashSet ignoreToAdd,
            HashSet forcedKinds, HashSet wsObjs, WTCollection wtCollectedObjects, Map types, Set initSeeds,
            NavigationCriteria filter, CollectorResult collectedData)
            throws WTException {
        boolean isOk = true;

        if (log.isTraceEnabled()) {
            log.trace("<<<" + (isQuickCheck ? "Quick check" : "Main request") + ">>>");
        }

        HashSet pkgs = new HashSet();
        Map associated = new HashMap();

        for (Iterator i = executedKinds.values().iterator(); i.hasNext();) {
            CollectionKind ck = (CollectionKind) i.next();
            String colId = ck.getCollectionServiceKey();

            CollectionPackage pkg = getCollectionPackage(colId, customConfig, installedConfig);

            if (pkg != null) {
                pkgs.add(pkg.getPackageID());
            }
            else {
                String assColId = installedConfig.getAssociatedCollectionDefinitionID(colId);
                if (assColId != null) {
                    pkg = getCollectionPackage(assColId, customConfig, installedConfig);
                    if (pkg != null) {
                        List ass = (List) associated.get(assColId);
                        if (ass == null) {
                            ass = new ArrayList();
                            associated.put(assColId, ass);
                        }
                        ass.add(ck);
                    }
                }
            }

            if (pkg != null) {
                pkgs.add(pkg.getPackageID());
            }
            else {
                log.error(colId + " is not valid");
                // isOk = false;
            }
        }

        if (!isOk) {
            return false;
        }

        Set executedIds = executedKinds.isEmpty() && wsObjs.isEmpty() ? Collections.EMPTY_SET
                : new HashSet(executedKinds.keySet());
        if (!wsObjs.isEmpty()) {
            executedIds.addAll(wsObjs);
        }

        List pkgOrder = customConfig.isValid() ? customConfig.getPackageExecutionOrder()
                : installedConfig.getPackageExecutionOrder();

        for (int i = 0; i < pkgOrder.size() && isOk; i++) {
            String pkgId = (String) pkgOrder.get(i);

            if (!pkgs.contains(pkgId)) {
                continue;
            }

            CollectionPackage pkg = null;
            if (customConfig.isValid()) {
                pkg = customConfig.getPackageByPackageID(pkgId);
            }

            if (pkg == null) {
                pkg = installedConfig.getPackageByPackageID(pkgId);
            }

            if (pkg != null) {
                if (log.isTraceEnabled()) {
                    log.trace("<<< Process package " + pkg.getPackageID());
                }
                List colOrder = pkg.getPackageExecutionOrder();

                List recursionCol = new ArrayList(colOrder.size());

                boolean isProcessed = false;
                int start = dependents.size(), recursion = 0;
                while (!isProcessed) {
                    for (int j = 0; j < colOrder.size() && isOk && !cache.isAborted(); j++) {
                        CollectionToExecute ce = (CollectionToExecute) colOrder.get(j);

                        String colId = ce.getCollectionID();

                        if (recursion > 0 && !recursionCol.contains(colId)) {
                            continue;
                        }

                        CollectionKind kind = (CollectionKind) executedKinds.get(colId);

                        if (kind == null) {
                            List ass = (List) associated.get(colId);
                            if (ass != null) {
                                kind = (CollectionKind) ass.get(0);
                                if (CollectionSrvHelper.isESREnabled && !isCollector) {
                                    if (colId.equals(OLD_REQUIRED_DEPENDENTS)
                                            && !executedKinds.containsKey(NEW_REQUIRED_DEPENDENTS)) {
                                        colId = NEW_REQUIRED_DEPENDENTS;
                                    }
                                    else if (colId.equals(OLD_OPTIONAL_DEPENDENTS)
                                            && !executedKinds.containsKey(NEW_OPTIONAL_DEPENDENTS)) {
                                        colId = NEW_OPTIONAL_DEPENDENTS;
                                    }

                                    if (colId.equals(OLD_REQUIRED_DEPENDENTS)
                                            || colId.equals(OLD_OPTIONAL_DEPENDENTS)) {
                                        kind = null;
                                    }
                                }
                                else {
                                    if (colId.equals(NEW_REQUIRED_DEPENDENTS)) {
                                        colId = OLD_REQUIRED_DEPENDENTS;
                                    }
                                    else if (colId.equals(NEW_OPTIONAL_DEPENDENTS)) {
                                        colId = OLD_OPTIONAL_DEPENDENTS;
                                    }
                                }

                                if (log.isTraceEnabled() && kind != null) {
                                    log.trace(
                                            "**Execute associated " + colId + " for " + kind.getCollectionServiceKey());
                                }
                            }
                        }

                        if (recursionCol.contains(colId) && log.isDebugEnabled()) {
                            log.debug("*Repeat collection");
                        }

                        if (recursion == 0 && ce.isRecursiveExecution()) {
                            recursionCol.add(colId);
                        }

                        WTHashSet bco = new WTHashSet(dependents);

                        isOk = processCollectionDefinition(colId, kind, pkg, isQuickCheck, seeds, dependents, processed,
                                executedIds, ignoreToAdd, forcedKinds, wtCollectedObjects, types, initSeeds, filter,
                                collectedData, null);

                        // if( isOk && ( cache.getOccurrenceNDI()!=null ||
                        // cache.getInputParameter(CollectionSrvHelper.COMPONENT_LID)!=null ||
                        // cache.getInputParameter(CollectionRequest.COMPONENT_IDENTIFIERS)!=null) && (rff!=null &&
                        // rff.contains(CollectionRequest.FORCE_CHILDREN_RETRIEVE_FEATURE)) &&
                        // (colId.equals(CollectionRequest.WTPART_OCCURRENCE_COLLECTION) ||
                        // colId.equals(CollectionRequest.OPTIONAL_MEMBER_DEPENDENTS)))
                        // CollectionSrvHelper.addForcedChildrenByComponents(pkg.getCollectionDefinition( colId ),
                        // dependents, cache, filter);

                        if (isOk && isExecuted && !isQuickCheck && kind != null && !kind.getScope().equals(NONE)) {
                            List addCols = ce.getAdditionalCollectionIDs();

                            if (addCols != null) {
                                for (int k = 0; k < addCols.size(); k++) {
                                    AdditionalCollectionToExecute adCol = (AdditionalCollectionToExecute) addCols
                                            .get(k);
                                    if (!adCol.isApplicable(kind.getFeatures())) {
                                        if (log.isTraceEnabled()) {
                                            log.trace("Additional collection " + adCol + " is invalid");
                                        }
                                        continue;
                                    }

                                    String addColId = adCol.getCollectionID();

                                    if (addColId.equals(CollectorDefinitionIDS.OPTIONAL_DEPENDENTS) && !isCollector) {
                                        addColId = NEW_OPTIONAL_DEPENDENTS;
                                    }
                                    else if (addColId.equals(CollectorDefinitionIDS.REQUIRED_DEPENDENTS)
                                            && !isCollector) {
                                        addColId = NEW_REQUIRED_DEPENDENTS;
                                    }

                                    if (isDrawingTracingIgnored && colId.equals(DRAWINGS)
                                            && (addColId.equals(NEW_REQUIRED_DEPENDENTS)
                                                    || addColId.equals(NEW_OPTIONAL_DEPENDENTS))) {
                                        if (log.isTraceEnabled()) {
                                            log.trace("Additional collection " + adCol + " is skipped for drawings ");
                                        }
                                        continue;
                                    }

                                    if (isRequiredIBRulesIgnored && colId.equals(NEW_OPTIONAL_DEPENDENTS)
                                            && addColId.equals(NEW_REQUIRED_DEPENDENTS)) {
                                        if (log.isTraceEnabled()) {
                                            log.trace("Additional collection " + adCol
                                                    + " is skipped for all dependents");
                                        }
                                        continue;
                                    }

                                    CollectionKind addKind = (CollectionKind) addKinds.get(addColId);
                                    if (addKind == null) {
                                        addKind = (CollectionKind) executedKinds.get(addColId);
                                    }

                                    if ((adCol.isPDMLinkOnly() && CollectionSrvHelper.isIlEnabled)
                                            && !CollectionSrvHelper.isFeatureEnabled(
                                                    CollectionSrvHelper.DO_NOT_IGNORE_DRAWING_DEPENDENCIES, componentID)
                                            ||
                                            ((colId.equals(FAMILY) || colId.equals(INSEPARABLE_FAMILY))
                                                    && !addColId.equals(FAMILY_INSTANCES)
                                                    && !addColId.equals(FAMILY_GENERICS) && addKind == null)) {
                                        CollectionKind found = addKind;
                                        addKind = null;

                                        for (Iterator l = dependents.persistableIterator(); l.hasNext();) {
                                            Persistable seed = (Persistable) l.next();
                                            boolean isProEAuthApp = CollectionSrvHelper
                                                    .isAuthoringApplicationProE(seed), isBCO = bco.contains(seed);

                                            if (isBCO || !(adCol.isPDMLinkOnly() && CollectionSrvHelper.isIlEnabled
                                                    && isProEAuthApp)) {
                                                if (!isBCO && !isProEAuthApp && addKind == null) {
                                                    addKind = found;
                                                }
                                                continue;
                                            }

                                            ObjectIdentifier oid = PersistenceHelper.getObjectIdentifier(seed);
                                            String key = getKey(oid, addColId);

                                            if (!tracedDependents.contains(key)) {
                                                tracedDependents.add(key);
                                                noDependents.add(key);
                                            }

                                            if (addColId.equals(REQUIRED_DEPENDENTS)) {
                                                key = getKey(oid, OPTIONAL_DEPENDENTS);

                                                if (!tracedDependents.contains(key)) {
                                                    tracedDependents.add(key);
                                                    noDependents.add(key);
                                                }
                                            }
                                        }
                                    }
                                    else if (addKind == null && (!colId.equals(DRAWINGS)
                                            || (colId.equals(DRAWINGS) && addKinds.containsKey(addColId)))) {
                                        addKind = (CollectionKind) allKinds.get(addColId);
                                        if (addColId.equals(CALCULATED_DRAWINGS) && addKind == null) {
                                            addKind = new CollectionKind();
                                            try {
                                                addKind.setCollectionServiceKey(addColId);
                                                addKind.setScope(CollectionKind.SCOPE_ALL);
                                                addKind.setCollectedAsKey(CollectionKind.RELATED_CADDOCS);
                                                allKinds.put(addColId, addKind);
                                                executedKinds.put(addColId, addKind);
                                                if (isCollectLinks) {
                                                    addKind.setIsNavigatedGraphEmpty(false);
                                                }
                                            } catch (WTPropertyVetoException ve) {
                                                log.error(ve, ve);
                                            }
                                        }
                                    }

                                    if (log.isTraceEnabled()) {
                                        log.trace("<<<Additional collection " + addColId
                                                + (addKind == null ? " ignored" : " processed"));
                                    }

                                    if (addKind != null) {
                                        if (!executedIds.contains(addColId)) {
                                            executedIds.add(addColId);
                                            CollectionDefinition colDef = pkg.getCollectionDefinition(addColId);
                                            for (Iterator l = colDef.getResultGraph().getLinks().iterator(); l
                                                    .hasNext();) {
                                                Link link = (Link) l.next();
                                                String assColId = link.getAssociatedCollectionDefinitionId();
                                                if (assColId != null) {
                                                    executedIds.add(assColId);
                                                }
                                            }
                                        }

                                        String or = addKind.getScope();
                                        boolean skip = false;

                                        boolean isIncrementalRequired = request > 1 && !CollectionSrvHelper.isIlEnabled
                                                && addColId.equals(NEW_REQUIRED_DEPENDENTS)
                                                && !executedKinds.containsKey(NEW_REQUIRED_DEPENDENTS)
                                                && !executedKinds.containsKey(NEW_OPTIONAL_DEPENDENTS)
                                                && (executedKinds.containsKey(DRAWINGS)
                                                        || executedKinds.containsKey(FAMILY));
                                        if (addColId.equals(FAMILY_GENERICS)) {
                                            try {
                                                addKind.setScope(ALL);
                                            } catch (Exception wte) {
                                                log.error(wte, wte);
                                            }
                                        }
                                        if (!isIncrementalRequired && cache.isEsr()
                                                && (!isCollectLinks || cache.isLinkDepType())
                                                && !cache.getIgnoreESRResultRules()
                                                && addColId.equals(NEW_REQUIRED_DEPENDENTS) && !isCollector) {
                                            CollectionDefinition aColDef = pkg
                                                    .getCollectionDefinition(NEW_OPTIONAL_DEPENDENTS);
                                            CollectionDefinition rColDef = pkg.getCollectionDefinition(addColId);
                                            WTCollection esrs = CollectionSrvHelper.getAllEsr(aColDef, cache);
                                            if (cache.isSaEsr()) {
                                                cache.addLockedEsr(esrs.persistableCollection());
                                                WTHashSet notEsrSeeds = new WTHashSet(dependents);
                                                notEsrSeeds.removeAll(esrs);
                                                isOk = processCollectionDefinition(addColId, addKind, pkg, isQuickCheck,
                                                        notEsrSeeds, dependents, processed, executedIds, ignoreToAdd,
                                                        forcedKinds, wtCollectedObjects, types, initSeeds, filter,
                                                        collectedData, esrs);
                                                cache.releaseLockedEsr();
                                                bco.addAll(notEsrSeeds);
                                                skip = true;
                                            }
                                            else {
                                                cache.addModifier(CollectionRequest.MDA_ALL_FEATURE);
                                                processedExecutedKinds.put(addColId, addKind);
                                                processed.put(addColId, rColDef);
                                                addColId = NEW_OPTIONAL_DEPENDENTS;
                                                addKind = (CollectionKind) executedKinds.get(addColId);
                                                CollectionSrvHelper.setAllEsr(rColDef, aColDef, cache,
                                                        esrs.persistableCollection());
                                                bco = null;
                                            }
                                        }

                                        if (colId.equals(NEW_OPTIONAL_DEPENDENTS)
                                                && addColId.equals(NEW_REQUIRED_DEPENDENTS)) {
                                            bco = null;
                                        }

                                        if (!skip) {
                                            isOk = processCollectionDefinition(addColId, addKind, pkg, isQuickCheck,
                                                    seeds, dependents, processed, executedIds, ignoreToAdd, forcedKinds,
                                                    wtCollectedObjects, types, initSeeds, filter, collectedData, bco);
                                        }

                                        if (addColId.equals(FAMILY_GENERICS)) {
                                            try {
                                                addKind.setScope(or);
                                            } catch (Exception wte) {
                                                log.error(wte, wte);
                                            }
                                        }
                                        cache.removeModifier(CollectionRequest.MDA_ALL_FEATURE);

                                        if (addKind != null) {
                                            processedExecutedKinds.put(addColId, addKind);
                                        }
                                    }
                                }
                            }

                        }
                    }

                    if (recursionCol.isEmpty() || start == dependents.size()) {
                        isProcessed = true;
                    }
                    else {
                        recursion++;
                        if (log.isDebugEnabled()) {
                            log.debug("number of dependents before recursive loop=" + start
                                    + "\nnumber of dependents added in " + recursion + " recursion="
                                    + (dependents.size() - start));
                        }
                        start = dependents.size();
                    }
                }
            }
        }

        for (Iterator i = associated.entrySet().iterator(); i.hasNext();) {
            Map.Entry e = (Map.Entry) i.next();

            String assColId = (String) e.getKey();

            if (processedExecutedKinds.containsKey(assColId)) {
                for (Iterator j = ((List) e.getValue()).iterator(); j.hasNext();) {
                    CollectionKind kind = (CollectionKind) j.next();
                    processedExecutedKinds.put(kind.getCollectionServiceKey(), kind);
                }
            }
            if (processed.containsKey(assColId)) {
                for (Iterator j = ((List) e.getValue()).iterator(); j.hasNext();) {
                    CollectionKind kind = (CollectionKind) j.next();
                    processed.put(kind.getCollectionServiceKey(), kind);
                }
            }
        }

        return isOk;
    }

    private boolean processCollectionDefinition(String colId, CollectionKind kind, CollectionPackage pkg,
            boolean isQuickCheck, WTCollection seeds, WTCollection dependents, HashMap processed, Set executedIds,
            HashSet ignoreToAdd, HashSet forcedKinds, WTCollection wtCollectedObjects, Map types, Set initialSeeds,
            NavigationCriteria filter, CollectorResult collectedData, WTCollection bco) {
        boolean isOk = true;

        isExecuted = false;

        if (kind != null && !kind.getScope().equals(NONE)) {
            try {
                CollectionDefinition colDef = pkg.getCollectionDefinition(colId);
                String cd = colDef.getCollectionID();

                if ((cache.isSimpleCollector() || cache.isLinkDepType()) && !isQuickCheck
                        && kind.getRecursionLimit() == DTRequest.UNLIMITED_TRACING && colDef.hasRecursionRetriever()) {
                    cache.addExpandedCollection(cd);
                }

                Class[] cls = colDef.getUsedClasses();

                Map specs = new HashMap();
                for (int k = 0; k < cls.length; k++) {
                    List cs = configSpecs.getConfigSpecs(cls[k]);
                    if (cs != null && !cs.isEmpty()) {
                        if (ws == null && wrkCanBeCreatedOlyInEPMWorkspace) {
                            List tmp = new ArrayList(cs.size());
                            for (Iterator i = cs.iterator(); i.hasNext();) {
                                ConfigSpec spec = (ConfigSpec) i.next();
                                boolean isLatest = CollectionSrvHelper.isLatestConfigSpec(spec);
                                if (componentID != null && componentID.equals(WU_ACTION) && isLatest) {
                                    tmp.add(new LastFoundIteration(false));
                                }
                                else {
                                    tmp.add(isLatest ? new LatestConfigSpecWithoutWorkingCopies() : spec);
                                }
                            }
                            cs = tmp;
                        }

                        specs.put(cls[k], cs);
                    }
                }
                if (filter != null) {
                    specs.put(filter.getClass(), filter);
                }

                Set idfm = (Set) ftMembers.get(CollectionSrvHelper.IDFM);

                WTCollection seedsToProcess = new WTHashSet(seeds);
                int cas = kind.getCollectedAsKey();
                if (!forcedKinds.isEmpty() || ((isQuickCheck || !kind.getScope().equals(SEEDS)) && !dependents.isEmpty()
                        && ((colDef.hasRecursionRetriever() && (kind.getRecursionLimit() != 1
                                || (kind.getRecursionLimit() == 1 && (cas == CollectionRequest.CAD_WHERE_USED
                                        || cas == CollectionRequest.WTPART_WHERE_USED
                                        || cas == CollectionRequest.WTDOC_WHERE_USED))))
                                || !colDef.hasRecursionRetriever())
                        && !(colDef.getCollectionID().equals(NEW_REQUIRED_DEPENDENTS)
                                && processed.containsKey(NEW_OPTIONAL_DEPENDENTS)
                                && kind.getRecursionLimit() != DTRequest.UNLIMITED_TRACING))) {
                    seedsToProcess.addAll(dependents);
                }

                Set rgNodes = null;
                if (isQuickCheck && !colDef.hasRecursionRetriever()) {
                    ResultGraph rg = colDef.getResultGraph();
                    if (rg != null) {
                        for (Iterator i = rg.getNodes().iterator(); i.hasNext();) {
                            ClassObject clObj = (ClassObject) i.next();
                            if (rgNodes == null) {
                                rgNodes = new HashSet();
                            }
                            rgNodes.addAll(clObj.getValues(cache));
                        }
                    }
                }

                for (Iterator i = seedsToProcess.persistableIterator(); i.hasNext();) {
                    Persistable p = (Persistable) i.next();
                    ObjectIdentifier pID = PersistenceHelper.getObjectIdentifier(p);
                    String key = getKey(pID, colId);

                    if (rgNodes != null && rgNodes.contains(p)) {
                        i.remove();
                        continue;
                    }

                    if ((CollectionSrvHelper.isQuickCheckEnabled && (!(cd.equals(OPTIONAL_DEPENDENTS)
                            && (CollectionSrvHelper.isExtSimpRep(p) || CollectionSrvHelper.isDesign(p)))
                            && forcedKinds.isEmpty() && (noDependents.contains(key) || tracedDependents.contains(key)
                                    || (isQuickCheck && checkedDependents.contains(key)))))
                            ||
                            (bco != null && bco.contains(p))
                            ||
                            (!CollectionSrvHelper.isFTMember(p) && (cd.equals(INSEPARABLE_FAMILY) || cd.equals(FAMILY)
                                    || cd.equals(FAMILY_GENERICS) || cd.equals(FAMILY_INSTANCES)))
                            ||
                            (!CollectionSrvHelper.isQuickCheckEnabled && ((CollectionSrvHelper.isFTMember(p)
                                    && cd.equals(INSEPARABLE_FAMILY) && noDependents.contains(key))
                                    || ((CollectionSrvHelper.isDrawing(p) || CollectionSrvHelper.isFTMember(p))
                                            && idfm != null && idfm.contains(Long.valueOf(pID.getId()))
                                            && CollectionSrvHelper.isIlEnabled && (cd.equals(NEW_REQUIRED_DEPENDENTS)
                                                    || cd.equals(NEW_OPTIONAL_DEPENDENTS)))))) {
                        i.remove();
                    }
                    else if (!isQuickCheck && forcedKinds.isEmpty()) {
                        tracedDependents.add(key);
                    }
                }

                for (Iterator i = colDef.getResultGraph().getLinks().iterator(); i.hasNext();) {
                    Link link = (Link) i.next();
                    if (link.getAssociatedCollectionDefinitionId() != null) {
                        ignoreToAdd.add(colDef.getCollectionID());
                        break;
                    }
                }

                if (!seedsToProcess.isEmpty()) {
                    Collection linkSeeds = cache.getLinkSeeds(colDef, seedsToProcess.persistableCollection());
                    if (linkSeeds != null) {
                        seedsToProcess.addAll(linkSeeds);
                        if (log.isTraceEnabled()) {
                            log.trace("Added calculated usage links[" + linkSeeds.size() + "]");
                        }
                    }
                }

                if (log.isTraceEnabled()) {
                    CollectionSrvHelper.trace("Seeds [" + seeds.size() + "," + seedsToProcess.size() + "] of" + cd,
                            null, seedsToProcess, log);
                }

                if (seedsToProcess.isEmpty()) {
                    if (!log.isTraceEnabled() && log.isDebugEnabled()) {
                        log.debug(cd + " skipped");
                    }
                    return true;
                }

                if (!isQuickCheck && crData != null) {
                    crData.addCollectedAsKey(kind.getCollectedAsKey());
                }
                Set fts = new HashSet();
                if (kind.getFeatures() != null) {
                    fts.addAll(kind.getFeatures());
                }
                if (kind.getLocalFeatures() != null) {
                    fts.addAll(kind.getLocalFeatures());
                }
                if (rff != null) {
                    fts.addAll(rff);
                }
                boolean isLinks = cache.getNavigationCriteria() != null
                        && cache.getNavigationCriteria().getFilters() != null
                        && !cache.getNavigationCriteria().getFilters().isEmpty() ? true : isCollectLinks,
                        isSeedOnly = colDef.hasRecursionRetriever() && kind.getRecursionLimit() == 1
                                && kind.getScope().equals(SEEDS);
                cache.setNotExpandableTypes(kind.getNotExpandableTypes());

                if (log.isDebugEnabled()) {
                    CollectionSrvHelper.setProfiler(new long[25][3]);
                }
                isOk = CollectionSrvHelper.buildResult(cache, ftMembers, ws,
                        (isIgnoreContainerScope ? null : container), specs, seedsToProcess, isQuickCheck,
                        isIgnoreObjectsInOtherContexts, colDef, executedIds, false, isLinks, componentID,
                        kind.getRecursionLimit(), fts, types);
                if (log.isDebugEnabled()) {
                    printProfile(colId, CollectionSrvHelper.getProfiler());
                    CollectionSrvHelper.removeProfiler();
                }
                isExecuted = true;

                if (isOk && !colDef.getResultList().getNodeValues(cache).isEmpty()) {
                    if (!isQuickCheck && cache.getEsrSeed() && seedsToProcess.size() == 1
                            && (colId.equals(OPTIONAL_DEPENDENTS) || colId.equals(REQUIRED_DEPENDENTS))) {
                        Persistable p = (Persistable) seedsToProcess.persistableIterator().next();
                        if (CollectionSrvHelper.isExtSimpRep(p)) {
                            NavigationUnit[] cn = cache.getChildren(p);
                            for (int i = 0; i < cn.length; i++) {
                                Persistable child = cn[i].getEndNode();
                                Set lnks = cn[i].getParnts(child, EPMReferenceLink.class, true);
                                if (lnks != null && !lnks.isEmpty()
                                        && !cn[i].getFilteredStatus(child).equals(FilteredStatus.FILTERED)) {
                                    dependents.add(child);
                                }
                            }
                        }
                    }

                    if (collectedData != null) {
                        boolean smartToolBar = isQuickCheck && CollectionSrvHelper.isQuickCheckEnabled;
                        for (Iterator i = seedsToProcess.persistableIterator(); i.hasNext();) {
                            Persistable p = (Persistable) i.next();
                            if (p instanceof ObjectToObjectLink) {
                                p = (Persistable) cache.getCachedObject(((ObjectToObjectLink) p).getRoleAObjectId());
                            }
                            if (p != null) {
                                if (!smartToolBar) {
                                    dependents.add(p);
                                }
                                Collection nested = colDef.getResultGraph().getNestedRelated(p, true, cache);
                                if (nested != null) {
                                    if (!smartToolBar) {
                                        collectedData.addParent(p);
                                    }
                                    if (isQuickCheck) {
                                        collectedData.addAppliedCollection(p, kind.getCollectedAsKey(), true);
                                    }
                                }
                                else if (!smartToolBar && isQuickCheck) {
                                    collectedData.addAppliedCollection(p, kind.getCollectedAsKey(), false);
                                }
                            }
                        }
                    }
                    else {
                        if (!isQuickCheck) {
                            if (colDef.isResultGraph() && (colDef.getResultGraph().hasOptionalNodes()
                                    || (kind.getRecursionLimit() == 1 && cache.getIncludeLinks()))) {
                                for (Iterator i = seedsToProcess.persistableIterator(); i.hasNext();) {
                                    Persistable p = (Persistable) i.next();
                                    dependents.add(p);
                                    Collection nested = colDef.getResultGraph().getNestedRelated(p, true, cache);
                                    if (nested != null) {
                                        dependents.addAll(nested);
                                    }
                                    else if (kind.getRecursionLimit() == 1 && cache.getIncludeLinks()) {
                                        NavigationUnit[] c = cache.getChildren(p);
                                        for (int n = 0; n < c.length; n++) {
                                            dependents.add(c[n].getEndNode());
                                        }
                                    }
                                }
                            }
                            else {
                                dependents.addAll(
                                        colDef.getResultList().getNodeValues(true, null, visibleFilteredStatus, cache));
                            }

                            wtCollectedObjects.addAll(dependents);
                            cache.addDependencies(dependents.persistableCollection());
                        }

                        if (colDef.isResultGraph()) {
                            colDef.getResultGraph().buildAdjacencyMatrix(cache);
                            if (isMissedDependenciesEnabled && !hasUnresolvedObjects && !isQuickCheck
                                    && !colDef.getCollectionID().equals("DRAWINGS")) {
                                hasUnresolvedObjects = colDef.getResultGraph().hasUnresolvedObjects();
                            }
                        }

                        processed.put(colId, colDef);

                        if (forcedKinds.isEmpty()) {
                            if (colDef.isResultGraph()) {
                                ftMembers.putAll(colDef.getResultGraph().getFTMembers(cache));
                            }

                            for (Iterator i = colDef.getResultList().getNodeValues(cache).iterator(); i.hasNext();) {
                                Persistable p = (Persistable) i.next();
                                ObjectIdentifier pID = PersistenceHelper.getObjectIdentifier(p);
                                validateFTMember(p);
                                String key = getKey(pID, colId);

                                if (isSeedOnly || ((colId.equals(OPTIONAL_DEPENDENTS) || colId.equals(FAMILY_GENERICS))
                                        && !tracedDependents.contains(getKey(pID, REQUIRED_DEPENDENTS)))) {
                                    continue;
                                }

                                if (colDef.hasRecursionRetriever() || tracedDependents.contains(key)
                                        || colId.equals(FAMILY)
                                        || (colId.equals(INSEPARABLE_FAMILY) && !noDependents.contains(key))) {
                                    if (isQuickCheck) {
                                        checkedDependents.add(key);
                                    }
                                    else if (!(colId.equals(WTPART_WHERE_USED) || colId.equals(CAD_WHERE_USED))) {
                                        tracedDependents.add(key);
                                    }
                                }
                            }
                        }
                    }
                }

                if (log.isTraceEnabled()) {
                    log.trace("<<<Process " + colDef.getCollectionID() + " with scope "
                            + (isQuickCheck ? "seeds" : kind.getScope()) + "="
                            + (isOk && !colDef.getResultList().getNodeValues(cache).isEmpty()
                                    ? colDef.getResultList().getNodeValues(cache).size()
                                    : 0));
                }
            } catch (WTException e) {
                CollectionSrvHelper.getStackTrace(e, log);
                isOk = false;
            }
        }

        return isOk;
    }

    private boolean isValidChild(String colDefId, Persistable child, Persistable parent) {
        if (parent == null || child == null) {
            return false;
        }
        else if (parent == child) {
            return false;
        }
        else if (!(colDefId.equals(FAMILY) || colDefId.equals(INSEPARABLE_FAMILY))) {
            return true;
        }
        else {
            return (child instanceof EPMDocument && ((EPMDocument) child).isTopGeneric());
        }
    }

    private void addForcedKind(String colDefId, Map allKinds, Map executedKinds, Map executedCentricKinds,
            Set forcedKinds) {
        executedCentricKinds.put(colDefId, allKinds.get(colDefId));
        if (!executedKinds.containsKey(colDefId)) {
            forcedKinds.add(colDefId);
        }
    }

    /**
     * The purpose of this method is to get Owner associated otherside object. In case of, for multiple owners, returns
     * oldest.
     *
     * @return Iterated: Link with minimum RuleID (ida2a2) is preferred.
     */
    private Iterated getPreferredAssociated(HashMap<Iterated, Persistable> associatedLinkMap) {
        Iterated preferredAssociated = null;
        if (associatedLinkMap == null || associatedLinkMap.isEmpty()) {
            return null;
        }
        long tmpVal = Long.MAX_VALUE;
        Set<Iterated> keys = associatedLinkMap.keySet();
        for (Iterated key : keys) {
            long ruleID = PersistenceHelper.getObjectIdentifier(associatedLinkMap.get(key)).getId();

            if (tmpVal > ruleID) {
                tmpVal = ruleID;
                preferredAssociated = key;
            }
        }
        return preferredAssociated;

    }

    private void traceCentric(Iterated seed, int depAsKey, ResultGraph depGraph, boolean includeDependents,
            WTCollection dependents, Map associatedMap, CollectorResult collectedData, WTCollection traced,
            boolean isForced, boolean isConsiderOwnerAssociationOnly) throws WTException {
        Set seedAssociates = (Set) associatedMap.get(seed);

        if (seedAssociates != null) {
            for (Iterator i = seedAssociates.iterator(); i.hasNext();) {
                Iterated seedAssociate = (Iterated) i.next();

                Collection directdDependents = depGraph.getNestedRelated(seedAssociate, false, null, cache);

                if (directdDependents != null && !directdDependents.isEmpty()) {
                    WTHashSet seedNested = new WTHashSet();

                    for (Iterator j = directdDependents.iterator(); j.hasNext();) {
                        Iterated directDependent = (Iterated) j.next();

                        Set associates = (Set) associatedMap.get(directDependent);

                        if (associates != null) {
                            HashMap<Iterated, Persistable> associatedLinkMap = new HashMap<>();
                            for (Iterator k = associates.iterator(); k.hasNext();) {
                                Iterated associated = (Iterated) k.next();

                                Persistable link = null;
                                if (isConsiderOwnerAssociationOnly) {
                                    link = CollectionSrvHelper.getAssociationLink(cache.getColID(), cache,
                                            directDependent, associated);
                                    // Only ACTIVE type associations are cached, and we are not interested in CC
                                    // association
                                    if (link != null && !CollectionSrvHelper.isContributingAssociation(link)) {
                                        seedNested.add(associated);
                                    }
                                }
                                else {
                                    seedNested.add(associated);
                                }

                                if (includeDependents && !traced.contains(associated)
                                        && !traced.contains(directDependent)) {

                                    if (isConsiderOwnerAssociationOnly) {
                                        if (link != null && CollectionSrvHelper.isOwnerAssociation(link)) {
                                            tracedDependents.add(associated.toString() + CENTRIC);
                                            traced.add(associated);
                                            traced.add(directDependent);
                                            associatedLinkMap.put(associated, link);
                                        }
                                    }
                                    else// Remove this block once isConsiderOwnerAssociationOnly Regularised
                                    {
                                        tracedDependents.add(associated.toString() + CENTRIC);
                                        traced.add(associated);
                                        traced.add(directDependent);
                                        traceCentric(associated, depAsKey, depGraph, includeDependents, dependents,
                                                associatedMap, collectedData, traced, isForced,
                                                isConsiderOwnerAssociationOnly);
                                    }
                                }
                            }
                            // Filter out to get only oldest Owner associated, to traverse its deps.
                            if (isConsiderOwnerAssociationOnly && !associatedLinkMap.isEmpty()) {
                                Iterated preferredAssociated = getPreferredAssociated(associatedLinkMap);

                                if (preferredAssociated != null) {
                                    traceCentric(preferredAssociated, depAsKey, depGraph, includeDependents, dependents,
                                            associatedMap, collectedData, traced, isForced,
                                            isConsiderOwnerAssociationOnly);
                                }
                            }
                        }
                    }

                    if (!seedNested.isEmpty()) {
                        collectedData.addAppliedCollection(seed, depAsKey, !includeDependents);

                        if (includeDependents) {
                            collectedData.addDependents(seed, depAsKey, seedNested, isForced);
                            dependents.addAll(seedNested);
                            tracedDependents.add(seed.toString() + CENTRIC);
                        }
                    }
                }
            }
        }
    }

    private void releaseParameters(boolean clean) {
        sValidator = null;
        configSpecs = null;
        container = null;
        ws = null;
        context = null;
        seedsValidator = null;

        if (clean) {
            foundRelations = new HashMap();
            missedRelations = new HashMap();
            noDependents = new HashSet();
            checkedDependents = new HashSet();
            tracedDependents = new HashSet();
            ut = null;
        }
    }

    private void validateFTMember(Persistable p) {
        if (CollectionSrvHelper.isFTMember(p) && !CollectionRulePreferenceHelper.isInseparableFTMember(p, context)) {
            noDependents.add(getKey(PersistenceHelper.getObjectIdentifier(p), INSEPARABLE_FAMILY));
        }
    }

    public int getRequest() {
        return request;
    }

    private String getKey(ObjectIdentifier objKey, String colDefKey) {
        return getDictionaryKey(objKey) + "@" + getDictionaryKey(colDefKey);
    }

    private String getDictionaryKey(Object key) {
        if (!dictionary.containsKey(key)) {
            dictionary.put(key, String.valueOf(counter++));
        }

        return dictionary.get(key);
    }

    private void elapsedTime(long time, String title) {
        if (log.isDebugEnabled()) {
            log.debug(title + "[" + counter + "]=" + (System.currentTimeMillis() - time) + "ms");
        }
    }

    private void addOppositeDependents(CollectionConfig customConfig, CollectionConfig installedConfig, String colID,
            String opColID, HashMap allKinds, Persistable parent, WTCollection wtChildren,
            CollectorResult collectedData, HashMap processedExecutedKinds, Set unforcedFT) throws WTException {
        if (opColID != null && allKinds.containsKey(opColID)) {
            CollectionPackage pkgOp = getCollectionPackage(opColID, customConfig, installedConfig),
                    pkg = getCollectionPackage(colID, customConfig, installedConfig);

            ResultGraph crOp = pkgOp == null ? null : pkgOp.getCollectionDefinition(opColID).getResultGraph(),
                    cr = pkg == null ? null : pkg.getCollectionDefinition(colID).getResultGraph();

            CollectionKind opKind = (CollectionKind) allKinds.get(opColID);
            Map links = cr == null ? Collections.EMPTY_MAP : cr.getChildrenWithLinks(parent, wtChildren, colID, cache);
            int opCollectedAsKey = opKind.getCollectedAsKey();

            WTCollection opAd = new WTHashSet();
            opAd.add(parent);

            for (Iterator m = wtChildren.persistableIterator(); m.hasNext();) {
                Iterated p = (Iterated) m.next();

                Map opLinks = crOp == null ? Collections.EMPTY_MAP : crOp.getChildrenWithLinks(p, opAd, opColID, cache);
                HashSet a = (HashSet) links.get(p);
                if (a != null && !a.isEmpty()) {
                    HashSet aOp = (HashSet) opLinks.get(p);
                    if (aOp == null) {
                        aOp = new HashSet();
                    }
                    aOp.addAll(a);

                    if (crOp == null) {
                        opLinks = new HashMap();
                    }

                    opLinks.put(parent, aOp);
                }

                addDependents(collectedData, p, opCollectedAsKey, opLinks, !processedExecutedKinds.containsKey(opColID),
                        unforcedFT);
            }
        }
    }

    private void addAC(CollectorResult collectedData, Persistable parent, int collectedAsKey, boolean isMissed,
            boolean isUseCentricity) throws WTException {
        if (isMissed && ((collectedAsKey == RELATED_CADDOCS_KIND && parent instanceof WTPart)
                || (collectedAsKey == RELATED_WTPARTS_KIND && parent instanceof EPMDocument))) {
            String key = collectedAsKey == RELATED_CADDOCS_KIND ? RELATED_CADDOCS : RELATED_WTPARTS;
            Set pd = (Set) ftMembers.get(key);
            if (pd == null) {
                pd = new HashSet();
                ftMembers.put(key, pd);
            }
            if (isMissed && pd.contains(Long.valueOf(PersistenceHelper.getObjectIdentifier(parent).getId()))) {
                isMissed = false;
            }
        }

        if (!(parent instanceof WTPart && isMissed && !isUseCentricity
                && (collectedAsKey == CollectionKind.REQUIRED_DEPENDENTS
                        || collectedAsKey == CollectionKind.OPTIONAL_DEPENDENTS))) {
            if (!((collectedAsKey == CollectionKind.REQUIRED_DEPENDENTS
                    && (cache.isExpandedCollection(NEW_OPTIONAL_DEPENDENTS)
                            || cache.isExpandedCollection(NEW_REQUIRED_DEPENDENTS)))
                    || (collectedAsKey == CollectionKind.OPTIONAL_DEPENDENTS
                            && cache.isExpandedCollection(NEW_OPTIONAL_DEPENDENTS)))) {
                boolean isEsrDrawing = isOnlyDrawingRequest && cache.isEsr() && CollectionSrvHelper.isDrawing(parent);
                if (!(isEsrDrawing && (collectedAsKey == CollectionKind.REQUIRED_DEPENDENTS
                        || collectedAsKey == CollectionKind.REQUIRED_VARIANT_DEPENDENTS
                        || collectedAsKey == CollectionKind.REQUIRED_MEMBER_DEPENDENTS
                        || collectedAsKey == CollectionKind.REQUIRED_REF_DEPENDENTS
                        || collectedAsKey == CollectionKind.OPTIONAL_DEPENDENTS
                        || collectedAsKey == CollectionKind.OPTIONAL_VARIANT_DEPENDENTS
                        || collectedAsKey == CollectionKind.OPTIONAL_MEMBER_DEPENDENTS
                        || collectedAsKey == CollectionKind.OPTIONAL_REF_DEPENDENTS))) {
                    collectedData.addAppliedCollection(parent, collectedAsKey, isMissed);
                }

                if (isMissed && !isEsrDrawing && collectedAsKey == FAMILY_GENERICS_KIND) {
                    collectedData.addAppliedCollection(parent, FAMILY_KIND, isMissed);
                }

                if (isMissed && !isEsrDrawing && collectedAsKey == CollectionKind.REQUIRED_DEPENDENTS) {
                    collectedData.addAppliedCollection(parent, CollectionKind.REQUIRED_MEMBER_DEPENDENTS, isMissed);
                    collectedData.addAppliedCollection(parent, CollectionKind.REQUIRED_REF_DEPENDENTS, isMissed);
                    collectedData.addAppliedCollection(parent, CollectionKind.REQUIRED_VARIANT_DEPENDENTS, isMissed);
                }

                if (isMissed && !isEsrDrawing && collectedAsKey == CollectionKind.OPTIONAL_DEPENDENTS) {
                    collectedData.addAppliedCollection(parent, CollectionKind.OPTIONAL_MEMBER_DEPENDENTS, isMissed);
                    collectedData.addAppliedCollection(parent, CollectionKind.OPTIONAL_REF_DEPENDENTS, isMissed);
                    collectedData.addAppliedCollection(parent, CollectionKind.OPTIONAL_VARIANT_DEPENDENTS, isMissed);
                }
            }
        }
    }

    private void addAssociated(Map associatedMap, Iterated dependent, Collection nested) {
        if (nested != null && !nested.isEmpty()) {
            Set as = (Set) associatedMap.get(dependent);
            if (as == null) {
                as = new HashSet();
                associatedMap.put(dependent, as);
            }
            as.addAll(nested);

            for (Iterator j = nested.iterator(); j.hasNext();) {
                Iterated associated = (Iterated) j.next();

                as = (Set) associatedMap.get(associated);
                if (as == null) {
                    as = new HashSet();
                    associatedMap.put(associated, as);
                }
                as.add(dependent);
            }
        }
    }

    private void addDependents(CollectorResult collectedData, Object p, int collectedAsKey, Map links, boolean isForced,
            Set unforcedFT) throws WTException {
        if (p instanceof EPMDocument
                && (collectedAsKey == FAMILY_INSTANCES_KIND || collectedAsKey == FAMILY_GENERICS_KIND)) {
            Long vID = (Long) ftMembers.get(PersistenceHelper.getObjectIdentifier((EPMDocument) p));
            if (!(vID != null && unforcedFT.contains(vID))) {
                isForced = true;
            }
        }

        collectedData.addDependents(p, collectedAsKey, links, isForced);
    }

    @Override
    public String toString() {
        StringBuffer buf = new StringBuffer();
        buf.append("checked=" + (checkedDependents == null ? 0 : checkedDependents.size()) +
                "\nFT=" + (collectedFTVersions == null ? 0 : collectedFTVersions.size()) +
                "\ncollected=" + (cache == null ? 0 : cache.getCollectedSize()) +
                "\nfound=" + (foundRelations == null ? 0 : foundRelations.size()) +
                "\nmembers=" + (ftMembers == null ? 0 : ftMembers.size()) +
                "\nid=" + id +
                "\nmissed=" + (missedRelations == null ? 0 : missedRelations.size()) +
                "\nnone=" + (noDependents == null ? 0 : noDependents.size()) +
                "\nrequest=" + request +
                "\ntraced=" + (tracedDependents == null ? 0 : tracedDependents.size()) +
                "\ndictionary=" + (dictionary == null ? 0 : dictionary.size()) +
                "\nfilters=" + (cache == null ? 0 : cache.getFilters().size()));
        return buf.toString();
    }

    public FilterCache getFilterCache(String ft) {
        long time = System.currentTimeMillis();

        FilterCache ret = null;
        if (cache != null && ft != null) {
            ret = cache.getFilterCache(ft);
        }

        if (log.isDebugEnabled()) {
            log.trace("getFilterCache[" + ft + "," + getId() + "," + request + ","
                    + (ret == null ? null : getClass().getName()) + "," + (System.currentTimeMillis() - time) + "ms]");
        }

        return ret;
    }

    public void setFilterCache(String ft, FilterCache ftCache) {
        long time = System.currentTimeMillis();

        if (cache != null && ft != null) {
            cache.setFilterCache(ft, ftCache);
            updateCacheHolders();
        }

        if (log.isDebugEnabled()) {
            log.trace("setFilterCache[" + ft + "," + getId() + "," + request + ","
                    + (ftCache == null ? null : ftCache.getClass().getName()) + ","
                    + (System.currentTimeMillis() - time) + "ms]");
        }
    }

    public NavigationMarkerCache getMarkerCache() {
        long time = System.currentTimeMillis();

        NavigationMarkerCache ret = null;
        if (cache != null) {
            ret = cache.getMarkerCache();
        }

        if (log.isDebugEnabled()) {
            log.trace(
                    "getMarkerCache[" + getId() + "," + request + "," + (ret == null ? null : ret.getClass().getName())
                            + "," + (System.currentTimeMillis() - time) + "ms]");
        }

        return ret;
    }

    public Map getCachedParameters() {
        Map ret = null;
        if (cache != null) {
            ret = (Map) cache.getInputParameter(CollectorDefinitionIDS.CACHED_PARAMS);
        }

        if (log.isDebugEnabled()) {
            log.debug("Collect input:" +
                    "\n\tid=" + getId() +
                    "\n\trequest=" + request +
                    "\n\tcached parameters=" + ret);
        }
        return ret != null ? new HashMap(ret) : null;
    }

    public void setCachedParameters(Map params) {
        if (cache != null) {
            Map cparams = new HashMap(params);
            cache.setInputParameter(CollectorDefinitionIDS.CACHED_PARAMS, cparams);

            if (log.isDebugEnabled()) {
                log.debug("Collect input:" +
                        "\n\tid=" + getId() +
                        "\n\trequest=" + request +
                        "\n\tinput params=" + params +
                        "\n\tcached parameters=" + cache.getCachedParameters());
            }
        }
    }

    public void setFilterAndMarkerCacheByValueEnabled(boolean isFilterAndMarkerCacheByValueEnabled) {
        if (cache == null) {
            cache = new CollectorSrvCache();
        }
        cache.setFilterAndMarkerCacheByValueEnabled(isFilterAndMarkerCacheByValueEnabled);

        if (log.isDebugEnabled()) {
            log.debug("setFilterAndMarkerCacheByValueEnabled[" + getId() + ","
                    + cache.isFilterAndMarkerCacheByValueEnabled() + "]");
        }
    }

    public NavigationMarkerCache getUpdatedMarkerCache(NavigationMarker marker) throws WTException {
        long time = System.currentTimeMillis();

        NavigationMarkerCache ret = null;
        CollectionConfig installedConfig = null;

        try {
            String markerCl = marker != null ? marker.newMarkerCache().getClass().getName() : null;
            if (log.isDebugEnabled()) {
                log.debug("getUpdatedMarkerCache[" + getId() + "," + markerCl + ",started]");
            }

            if (cache != null) {
                request++;
                cache.setCollectorId(getId());
                installedConfig = CollectionSrvHelper.getInstalledCollectionConfig();
                if (cache.isTrafoStructure()) {
                    NavigationMarker pm = installedConfig.getPostMarker(CollectionSrvHelper.trafoParType);
                    if (pm instanceof VirtualPathFilteredStatusModifier) {
                        cache.setVirtualPathFilteredStatusModifier((VirtualPathFilteredStatusModifier) pm);
                    }
                }

                cache.setMarkChangedByUserEnabled(true);
                long time1 = System.currentTimeMillis();
                ret = cache.getMarkerCache(markerCl);
                if (log.isDebugEnabled()) {
                    log.debug("getMarkerCache[" + (System.currentTimeMillis() - time1) + "ms]");
                }

                time1 = System.currentTimeMillis();
                marker.updateCacheForReMark(ret);
                if (log.isDebugEnabled()) {
                    log.debug("updateCacheForReMark[" + (ret == null ? null : ret.getClass().getName()) + ","
                            + (System.currentTimeMillis() - time1) + "ms]");
                }

                time1 = System.currentTimeMillis();
                cache.setMarkerCache(markerCl, ret);
                if (log.isDebugEnabled()) {
                    log.debug("setMarkerCache[" + (System.currentTimeMillis() - time1) + "ms]");
                }

                time1 = System.currentTimeMillis();
                cache.setNavigationMarker(marker);
                if (log.isDebugEnabled()) {
                    log.debug("setNavigationMarker[" + (System.currentTimeMillis() - time1) + "ms]");
                }

                NavigationMarker postMarker = installedConfig.getPostMarker(markerCl);
                if ((postMarker != null && !cache.isTrafoStructure())
                        || (cache.isTrafoStructure() && !cache.isTrafoStructureModified())) {
                    time1 = System.currentTimeMillis();
                    CollectionSrvHelper.applyMarker(cache.getPostNavigationMarker(), cache, false);
                    if (log.isDebugEnabled()) {
                        log.debug("post marking[" + (System.currentTimeMillis() - time1) + "ms]");
                    }

                }
                else {
                    // System.out.println("Don't apply post marker");
                }

                cache.setExpandedAll(false);
                List scc = CollectorCacheServerHelper.getCr(getId());
                if (log.isDebugEnabled()) {
                    log.debug("getCr[" + getId() + "," + request + "," + (scc == null ? 0 : scc.size()) + "]");
                }

                if (scc != null) {

                    int sr = ((Integer) scc.get(3)).intValue();
                    if (request < sr) {
                        if (log.isDebugEnabled()) {
                            log.debug("requests are different: " + sr);
                        }
                        CollectorCacheServerHelper.removeCr(getId());
                    }
                    else {
                        if (scc.get(2) != null) {
                            cache.setDependents((Collection) scc.get(2));
                            if (log.isDebugEnabled()) {
                                log.debug("dependents are returned");
                            }
                        }
                        else if (log.isDebugEnabled()) {
                            log.debug("dependents are not defined");
                        }

                        if (request >= sr) {
                            long ste = ((Long) scc.get(0)).longValue();
                            validateExpired(ste);
                        }
                    }
                }

                time1 = System.currentTimeMillis();
                CollectionSrvHelper.setNavigationMark(cache, false);
                if (log.isDebugEnabled()) {
                    log.debug("marking[" + (System.currentTimeMillis() - time1) + "ms]");
                }

                time1 = System.currentTimeMillis();
                ret = cache.getMarkerCache(markerCl);
                if (log.isDebugEnabled()) {
                    log.debug("getMarkerCache[" + (System.currentTimeMillis() - time1) + "ms]");
                }

                updateCacheHolders();

                if (CollectorCacheServerHelper.isCTEnabled() && getId() != null) {
                    CollectorCacheServerHelper.addCr(getId(), new Object[] { null, cache.getDependents(),
                            Integer.valueOf(request), cache.getModifiers(), cache.getCollections(), null });
                    if (log.isDebugEnabled()) {
                        log.debug("added to map");
                    }
                }

                cache.deflate();
            }

            if (log.isDebugEnabled()) {
                log.debug("getUpdatedMarkerCache[" + getId() + "," + markerCl + ",ended,"
                        + (System.currentTimeMillis() - time) + "ms]");
            }
        } catch (Exception e) {
            CollectionSrvHelper.getStackTrace(e, log);
        }

        if (installedConfig != null) {
            installedConfig.release();
            installedConfig = null;
        }

        return ret;
    }

    public void setUpdatedMarkerCache(NavigationMarkerCache markerCache) throws WTException {
        long time = System.currentTimeMillis();

        String markerCl = markerCache == null ? null : markerCache.getClass().getName();
        if (cache != null) {
            request++;
            cache.setMarkerCache(markerCl, markerCache);
            cache.setNMCDirty(true);
            updateCacheHolders();
        }

        if (log.isDebugEnabled()) {
            log.debug("setUpdatedMarkerCache[" + getId() + "," + request + "," + markerCl + ","
                    + (System.currentTimeMillis() - time) + "ms");
        }

    }

    public boolean isEsrEditMode() throws WTException {
        boolean ret = cache == null ? false : cache.getIgnoreESRResultRules();

        if (log.isDebugEnabled()) {
            log.debug("isEsrEditMode[" + getId() + "," + request + "," + ret + "]");
        }
        return ret;
    }

    public Collection getSeeds() throws WTException {
        long time = System.currentTimeMillis();
        Collection ret = cache == null ? null : cache.getSeeds();

        if (log.isDebugEnabled()) {
            log.debug("getSeeds[" + getId() + "," + request + "," + (ret == null ? 0 : ret.size()) + ","
                    + (System.currentTimeMillis() - time) + "ms]");
        }
        if (log.isTraceEnabled()) {
            log.trace(ret);
        }

        return ret;
    }

    private void getChildren(CollectorSrvCache cache, Set colIds, Persistable parent, Set check) {
        for (Iterator i = colIds.iterator(); i.hasNext();) {
            String colId = (String) i.next();
            NavigationUnit[] children = cache.getChildren(parent, colId);
            for (int j = 0; j < children.length; j++) {
                String key = colId + children[j].getStartNode() + children[j].getEndNode();
                if (!check.contains(key)) {
                    log.trace("Collection " + colId + "\n" + children[j]);
                    check.add(key);
                    getChildren(cache, colIds, children[j].getEndNode(), check);
                }
            }
        }
    }

    private void setRequiredModifiers(String[] mfs, Set rff) {
        if (mfs != null && mfs.length > 0) {
            for (int i = 0; i < mfs.length; i++) {
                rff.add(mfs[i]);
            }
        }
    }

    private void cacheValue(String key, CollectionContext cc) {
        Object value = context.getValue(key);
        if (value != null && cache != null) {
            cache.setInputParameter(key, value);
        }
    }

    public boolean isChanged() {
        return (cache == null) ? false : cache.isDirty();
    }

    public UICollector() {
    }

    private CollectionPackage getCollectionPackage(String colId, CollectionConfig customConfig,
            CollectionConfig installedConfig) {
        CollectionPackage pkg = null;

        if (customConfig.isValid()) {
            pkg = customConfig.getPackageByCollectionID(colId);
        }

        if (pkg == null) {
            pkg = installedConfig.getPackageByCollectionID(colId);
        }

        return pkg;
    }

    private void getCachedDependents(Persistable parent, WTCollection dependents, boolean isUnlimitedTracing,
            CollectorSrvCache cache, int visibilityOrder, String cID, int depAsKey, CollectorResult collectedData,
            Map vPath, Map ivPath, Map found, Set requiredLinkSeeds, boolean isVis) throws WTException {
        dependents.add(parent);
        long time = System.currentTimeMillis();
        /*
         * if( PersistenceHelper.getObjectIdentifier(parent).getId()==53195) System.out.println(
         * "Start tracing of Left Actuator");
         */
        NavigationUnit[] nus = cache.getChildren(parent, cID);
        if (log.isDebugEnabled()) {
            log.debug("get children[" + nus.length + "]=" + (System.currentTimeMillis() - time) + "ms");
        }
        if (nus != null && nus.length > 0) {
            collectedData.addParent(parent);
            for (int i = 0; i < nus.length; i++) {
                NavigationUnit nu = nus[i];
                Persistable child = nu.getEndNode();
                FilteredStatus fs = nu.getFilteredStatus(child);
                if (visibilityOrder >= fs.getOrder()) {
                    nu = cache.getNavigatedGraph(nu, visibilityOrder, false, vPath, ivPath);

                    if (nu != null) {
                        Set gs = (Set) found.get(cID);
                        if (gs == null) {
                            gs = new HashSet();
                            found.put(cID, gs);
                        }
                        if (gs.contains(nu)) {
                            continue;
                        }

                        if (isVis && !cache.isFeatureEnabled(CollectionRequest.INCLUDE_MASTERS_FEATURE)
                                && nu.getEndNode() instanceof Mastered) {
                            if (log.isTraceEnabled()) {
                                log.trace("skip unresolved\n" + nu);
                            }
                            continue;
                        }

                        /*
                         * if( cache.isTrafoStructure() && !cache.isWVS() ) { if( ((NavigatedGraph) nu).hasClonedPath())
                         * System.out.println("Erasing of cachced virtual elements is required");
                         *
                         * nu=cache.eraseClonedElements(nu); }
                         */

                        gs.add(nu);

                        collectedData.addDependents(parent, depAsKey,
                                new WTHashSet(Arrays.asList(new Persistable[] { child })), false);
                        collectedData.addGraph(depAsKey, (NavigatedGraph) nu);
                        if (log.isTraceEnabled()) {
                            log.trace("\n\t" + gs.size() + ".Returned\n" + nu);
                        }

                        if (cache.isNGUpperSupport((NavigatedGraph) nu) || ((NavigatedGraph) nu).hasClonedPath()) {
                            log.debug("Cached\n" + nu);
                        }

                        /*
                         * if( ((NavigatedGraph) nu).hasClonedPath()) System.out.println("Returned cached cloned\n"+nu);
                         */

                        dependents.add(child);
                        if (requiredLinkSeeds != null) {
                            for (Class cl : (Collection<Class>) requiredLinkSeeds) {
                                Set links = nu.getElements(cl, true);
                                if (links != null && !links.isEmpty()) {
                                    dependents.addAll(links);
                                }
                            }
                        }

                        if (isUnlimitedTracing) {
                            getCachedDependents(child, dependents, isUnlimitedTracing, cache, visibilityOrder, cID,
                                    depAsKey, collectedData, vPath, ivPath, found, requiredLinkSeeds, isVis);
                        }
                        else if (cache.isParent(child)) {
                            collectedData.addParent(child);
                        }
                    }
                }
            }
        }
    }

    private CollectionKind getUpdatedCollectionKind(String key, CollectionKind kind) throws WTPropertyVetoException {
        CollectionKind ret = new CollectionKind();
        ret.setCollectionServiceKey(key);
        ret.setCollectedAsKey(kind.getCollectedAsKey());
        ret.setScope(kind.getScope());
        ret.setRecursionLimit(kind.getRecursionLimit());
        return ret;
    }

    private void updateCacheHolders() {
        if (getId() != null) {
            try {
                long time = System.currentTimeMillis();
                List holders = cache.getUpdatedCacheHolders();
                if (holders != null && !holders.isEmpty()) {
                    for (Iterator i = holders.iterator(); i.hasNext();) {
                        CollectorCache holder = (CollectorCache) i.next();
                        long st = System.currentTimeMillis();
                        holder = CollectorCacheServerHelper.storeCollectorCache(holder);
                        String holderID = holder.getCollector().getId();
                        CollectorCacheServerHelper.addCr(holderID, new Object[] { holder });
                        if (log.isDebugEnabled()) {
                            log.debug("Update[" + holderID + "," + cache.getHolderNameById(holderID) + "]="
                                    + (System.currentTimeMillis() - st) + "ms");
                        }
                    }
                }
                if (log.isDebugEnabled()) {
                    log.debug("updateCacheHolders[" + (holders == null ? 0 : holders.size()) + "]="
                            + (System.currentTimeMillis() - time) + "ms");
                }
            } catch (Exception e) {
                CollectionSrvHelper.getStackTrace(e, log);
            }
        }
    }

    public boolean isFilterAndMarkerCacheByValueEnabled() {
        return cache == null ? false : cache.isFilterAndMarkerCacheByValueEnabled();
    }

    private List getOrderedCollections(Map executedKinds, CollectionConfig customConfig,
            CollectionConfig installedConfig) {
        List ret = new ArrayList();

        HashSet pkgs = new HashSet();
        for (Iterator i = executedKinds.values().iterator(); i.hasNext();) {
            CollectionKind ck = (CollectionKind) i.next();
            String colId = ck.getCollectionServiceKey();

            CollectionPackage pkg = getCollectionPackage(colId, customConfig, installedConfig);
            if (pkg == null) {
                colId = installedConfig.getAssociatedCollectionDefinitionID(colId);
                if (colId != null) {
                    pkg = getCollectionPackage(colId, customConfig, installedConfig);
                }
            }

            if (pkg != null) {
                pkgs.add(pkg.getPackageID());
            }
        }

        List pkgOrder = customConfig.isValid() ? customConfig.getPackageExecutionOrder()
                : installedConfig.getPackageExecutionOrder();

        for (int i = 0; i < pkgOrder.size(); i++) {
            String pkgId = (String) pkgOrder.get(i);

            if (!pkgs.contains(pkgId)) {
                continue;
            }

            CollectionPackage pkg = null;
            if (customConfig.isValid()) {
                pkg = customConfig.getPackageByPackageID(pkgId);
            }

            if (pkg == null) {
                pkg = installedConfig.getPackageByPackageID(pkgId);
            }

            if (pkg != null) {
                List colOrder = pkg.getPackageExecutionOrder();

                for (int j = 0; j < colOrder.size(); j++) {
                    CollectionToExecute ce = (CollectionToExecute) colOrder.get(j);

                    String colId = ce.getCollectionID();
                    CollectionKind kind = (CollectionKind) executedKinds.get(colId);
                    if (kind != null) {
                        ret.add(kind);
                    }
                    List<String> associatedCollectionDefnIds = getAssociatedCollectionDefinitionIds(colId);
                    for (String associatedCollectionDefnId : associatedCollectionDefnIds) {
                        kind = (CollectionKind) executedKinds.get(associatedCollectionDefnId);
                        if (kind != null) {
                            ret.add(kind);
                        }
                    }
                }
            }
        }

        if (log.isTraceEnabled()) {
            log.trace("Ordered collections=" + ret);
        }

        return ret;
    }

    private List<String> getAssociatedCollectionDefinitionIds(String collectionDefinitionId) {
        List<String> associatedCollectionDefnIds = new ArrayList<>();
        if (REQUIRED_DEPENDENTS.equals(collectionDefinitionId)) {
            associatedCollectionDefnIds.add(REQUIRED_MEMBER_DEPENDENTS);
            associatedCollectionDefnIds.add(REQUIRED_REF_DEPENDENTS);
            associatedCollectionDefnIds.add(REQUIRED_VARIANT_DEPENDENTS);
        }
        else if (OPTIONAL_DEPENDENTS.equals(collectionDefinitionId)) {
            associatedCollectionDefnIds.add(OPTIONAL_MEMBER_DEPENDENTS);
            associatedCollectionDefnIds.add(OPTIONAL_REF_DEPENDENTS);
            associatedCollectionDefnIds.add(OPTIONAL_VARIANT_DEPENDENTS);
        }
        return associatedCollectionDefnIds;
    }

    private void validateExpired(long ste) {
        String id = getId();
        if (ste < System.currentTimeMillis()) {
            CollectorCacheServerHelper.releaseCollectorCache(id);
        }
        if (log.isDebugEnabled()) {
            log.debug("removed expired " + id);
        }
    }

    private void refine(ResultGraph g, Map c, Persistable parent, WTCollection wtChildren, String coldDefId)
            throws WTException {
        if (c == null || c.isEmpty()) {
            return;
        }

        Map cm = g.getChildrenWithLinks(parent, wtChildren, coldDefId, cache);
        if (cm != null && !cm.isEmpty()) {
            for (Iterator k = cm.keySet().iterator(); k.hasNext();) {
                c.remove(k.next());
            }
        }
    }

    private boolean isClient(String clientCl) {
        boolean ret = false;
        StackTraceElement[] tes = new Throwable().getStackTrace();

        for (int n = 0; n < tes.length && !ret; n++) {
            String callerCl = tes[n].getClassName();
            ret = callerCl.contains(clientCl);
        }
        return ret;
    }

    private void printProfile(String msg, long[][] profile) {
        log.debug(msg + ":");
        if (profile != null) {
            for (int i = 0; i < profile.length; i++) {
                if (profile[i][0] > 0 && profile[i][1] > 0) {
                    log.debug("\t" + i + ". " + profile[i][0] + "=" + profile[i][1] + "ms");
                }
            }
        }
    }

    private void startProfile(int i) {
        if (times != null) {
            times[i][0]++;
            times[i][2] = System.currentTimeMillis();
        }
    }

    private void endProfile(int i) {
        if (times != null) {
            times[i][1] = times[i][1] + (System.currentTimeMillis() - times[i][2]);
        }
    }

    public void setProfiler() {
        times = new long[10][3];
        for (int i = 0; i < times.length; i++) {
            times[i][0] = 0;
            times[i][1] = 0;
        }
    }

    private CollectionDefinition getCollectionDefinition(CollectionConfig installedConfig, String collectionID) {
        CollectionDefinition collectionDefinition = null;
        String collectionServiceKey = collectionID;
        CollectionPackage colDefPkg = installedConfig.getPackageByCollectionID(collectionServiceKey);
        if (colDefPkg == null) {
            collectionServiceKey = installedConfig.getAssociatedCollectionDefinitionID(collectionServiceKey);
            if (collectionServiceKey != null) {
                colDefPkg = installedConfig.getPackageByCollectionID(collectionServiceKey);
            }
        }
        if (colDefPkg != null) {
            collectionDefinition = colDefPkg.getCollectionDefinition(collectionServiceKey);
        }
        return collectionDefinition;
    }
}
