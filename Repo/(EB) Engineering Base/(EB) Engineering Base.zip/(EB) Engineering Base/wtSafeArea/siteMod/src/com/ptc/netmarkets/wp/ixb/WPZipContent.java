package com.ptc.netmarkets.wp.ixb;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.DirectoryStream;
import java.nio.file.FileSystem;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.StandardOpenOption;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import org.apache.log4j.Logger;

import com.ptc.core.htmlcomp.util.TypeHelper;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.netmarkets.wp.ixb.AttachmentContent.AttachmentElement;
import com.ptc.netmarkets.wp.ixb.util.WPIxbHndHelper;
import com.ptc.windchill.enterprise.baseline.baselineResource;
import com.ptc.windchill.wp.AbstractWorkPackage;
import com.ptc.windchill.wp.WPHelper;
import com.ptc.windchill.wp.WPTypeBasedPropertiesOverride;
import com.ptc.windchill.wp.delivery.DeliveryHelper;
import com.ptc.windchill.wp.delivery.DeliveryManifestType;
import com.ptc.windchill.wp.delivery.DeliveryMediumType;
import com.ptc.windchill.wp.delivery.DeliveryRecord;
import com.ptc.windchill.wp.delivery.ExportFormatType;
import com.ptc.windchill.wp.delivery.WTUserSecurityChoice;
import com.ptc.windchill.wp.delivery.ZipInfo.ZipChunkInfoHelper;
import com.ptc.windchill.wp.delivery.export.AbstractDeliveryExportDelegate;
import com.ptc.windchill.wp.delivery.export.DependencyAssistant;
import com.ptc.windchill.wp.delivery.export.ExportHelper;

import wt.access.AccessControlHelper;
import wt.access.AccessPermission;
import wt.content.ApplicationData;
import wt.content.ContentHelper;
import wt.content.ContentHolder;
import wt.content.ContentItem;
import wt.content.ContentRoleType;
import wt.content.ExternalStoredData;
import wt.content.URLData;
import wt.doc.WTDocumentDependencyLink;
import wt.doc.WTDocumentUsageLink;
import wt.epm.build.EPMBuildHistory;
import wt.epm.familytable.EPMSepFamilyTable;
import wt.epm.structure.EPMContainedIn;
import wt.epm.structure.EPMDescribeLink;
import wt.epm.structure.EPMReferenceLink;
import wt.facade.ixb.IxbDocument;
import wt.facade.ixb.IxbElement;
import wt.facade.ixb.IxbHndHelperConstants;
import wt.facade.persistedcollection.PersistedCollectable;
import wt.facade.persistedcollection.PersistedCollectionHelper;
import wt.facade.suma.SumaFacade;
import wt.fc.BinaryLink;
import wt.fc.ObjectIdentifier;
import wt.fc.ObjectReference;
import wt.fc.PersistenceHelper;
import wt.fc.collections.WTCollection;
import wt.fc.collections.WTHashSet;
import wt.fc.collections.WTSet;
import wt.introspection.LinkInfo;
import wt.introspection.RoleDescriptor;
import wt.ixb.clientAccess.IXBJarWriter;
import wt.ixb.epm.handlers.EPMHndHelper;
import wt.ixb.handlers.forclasses.ExpImpForRepresentation;
import wt.ixb.publicforapps.IxbHelper;
import wt.ixb.publicforhandlers.IxbHndHelper;
import wt.log4j.LogR;
import wt.org.WTUser;
import wt.part.WTPartAlternateLink;
import wt.part.WTPartDescribeLink;
import wt.part.WTPartReferenceLink;
import wt.part.WTPartSubstituteLink;
import wt.session.SessionHelper;
import wt.session.SessionServerHelper;
import wt.type.ClientTypedUtility;
import wt.util.LocalizableMessage;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.vc.baseline.BaselineMember;
import wt.vc.baseline.ManagedBaseline;
import wt.viewmarkup.DerivedImage;

/**
 * Contains all of the content contained within the
 *
 * <BR><BR>
 * <b>Supported API: </b>true
 * <BR><BR>
 * <b>Extendable: </b>false.
 */
public class WPZipContent {

    private static final String IN_ZIP_MISSING_OBJECT_DIR = "importData/MISSINGOBJECT/";

    private static final String MISSING_OBJECT_DIR_SUFFIX = "--MISSING--OBJ";

    /** The Constant logger. */
    private static final Logger logger = LogR.getLogger(AbstractManifest.class.getName());
    
    private final MemoryObject pkgMemObj;

    private final Map<AttachmentContent.AttachmentElement, InputStream> packageAttachmentElementToInputStream =
            new HashMap<AttachmentContent.AttachmentElement, InputStream>();

    /** Object that manages I/O for the grouped zip files. */
    private final ChunkedZipFiles groupedZipFiles;

    /** Type cache for object xml documents. */
    private final DocTypeCache docTypeCache = new DocTypeCache();

    /**
     * A map of file names to the IXBJarReader they came from.
     *
     * This is needed because InputStreams from a jar file cannot be reset
     *   and must be acquired again to be reset to the beginning of the stream
     */
    private final Map<String, Path> fileNameToFileSystem = new HashMap<String, Path>();

    /**
     * A map containing the filenames of the Representaion object for a given object.
     * The keys in the map are the filenames of the business objects.
     * If an object does not have an associated Representaion then no entry in the map is created
     */
    private final Map<String, Set<String>> docFileName2Representation = new HashMap<String, Set<String>>();

    /**
     * A map that contains a xml filename to it's related attachment content
     *
     * The AttachmentContent object is created when the business xmls are parsed during object initialization.
     * The AttachmentContent object contains all of data for all attachments for a given object.
     * If an object does not have content or is not a content holder then no entry in the map is created.
     */
    private final Map<String, AttachmentContent> fileNameToAttachmentContent = new HashMap<String, AttachmentContent>();

    /** The file name to memory objs. */
    private final Map<String, MemoryObject> fileNameToMemoryObjs = new HashMap<String, MemoryObject>();

    /** The file name to memory links. */
    private final Map<String, MemoryLink> fileNameToMemoryLinks = new HashMap<String, MemoryLink>();

    /** The oem partfile name to axl entry infos. */
    private final Map<String, Set<AxlEntryInfo>> oemPartfileNameToAxlEntryInfos = new HashMap<String, Set<AxlEntryInfo>>();

    /** The delivery record of the zip being exported. */
    private final DeliveryRecord deliveryRecord;

    /** Is the zip being exported importable. */
    private final boolean isImportable;

    /** The copy forward zip files. */
    private final boolean copyForwardZipFiles;

    /** The memory objs new in current package export. */
    private Set<MemoryObject> newMemoryObjs;

    /** The memory objs changed in current package export. */
    private Set<MemoryObject> changedMemoryObjs;

    /** The objs unchanged in current package export. */
    private WTCollection unchangedObjs;

    /** The objs absent from current package export. */
    private WTCollection absentObjs;
    
    private static final String WP_IXB_RESOURCE = "com.ptc.netmarkets.wp.ixb.wpIxbResource";
    
    private final boolean createManifest;

     /**
     * !!!FOR TESTING ONLY!!!
     * This constructor is exposed for testing ONLY.
     *
     */
    WPZipContent() {
        this.pkgMemObj = null;
        this.groupedZipFiles = null;
        this.isImportable = true;
        this.deliveryRecord = null;
        this.copyForwardZipFiles = true;
        this.createManifest = false;
    }

    /**
     * Parses the jarFiles and collects up all of the files being exported.
     *
     * @param ixbFiles
     * @param delivery
     * @param trackedObjects
     * 
     * @throws IOException
     * @throws WTException
     */
    protected WPZipContent(File[] ixbFiles, DeliveryRecord delivery, TrackedDeliveryObjects trackedObjects) throws IOException, WTException {
        this(ixbFiles, delivery, trackedObjects, null);
    }

    /**
     * Parses the jarFiles and collects up all of the files being exported.
     *
     * @param ixbFiles
     *            the ixb files
     * @param delivery
     *            the delivery
     * @param newObjects
     * @param changedObjects
     * @param absentObjects
     * @param addZipInfoFiles
     *           whether generate and add info files to zip (0.data & Missing object file) or not.
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     * @throws WTException
     *             the wT exception
     */
    protected WPZipContent(File[] ixbFiles, DeliveryRecord delivery, TrackedDeliveryObjects trackedObjects, Boolean addZipInfoFiles) throws IOException, WTException {

        long startTime = System.currentTimeMillis();
        logger.debug("AbstractManifest.WPZipContent (Start) - " + startTime);
        logger.debug("WPZipContent: Processing for delivery:" + delivery + " trackedObjects: "+trackedObjects+ " addZipInfoFiles: "+addZipInfoFiles);

        this.deliveryRecord = delivery;
        this.isImportable = ExportHelper.isImportableDeliveryRecord(deliveryRecord);
        //if addZipInfoFiles is null keep createManifest to false because it is downgrade delivery
        this.createManifest = (Objects.isNull(addZipInfoFiles) ? false : true);

        if (trackedObjects != null) {
            this.newMemoryObjs = new HashSet<MemoryObject>(trackedObjects.getNewObjects().size());
            this.changedMemoryObjs = new HashSet<MemoryObject>(trackedObjects.getChangedObjects().size());
            this.absentObjs = new WTHashSet(trackedObjects.getAbsentObjects());
            this.unchangedObjs = new WTHashSet(trackedObjects.getUnchangedObjects());
        }

        // Get export chunk size based on delivery medium
        DeliveryMediumType deliveryMedium = delivery.getDeliveryMedium();
        long lChunkSize = Long.parseLong(DeliveryHelper.getService().getDeliveryMediumTypeSize(deliveryMedium));
        if (logger.isDebugEnabled()) {
            String deliveryMediumValue = ((deliveryMedium != null) ? deliveryMedium.toString() : "<null>");
            logger.debug("Setting export chunk size to " + lChunkSize + " for delivery medium " + deliveryMediumValue);
        }

        //Convert MB to bytes
        lChunkSize = lChunkSize * (1048576);
        //Account for the size the zip chunk info file in the importable package
        if (this.isImportable) {
            lChunkSize = lChunkSize - ExportHelper.IMPORT_CHUNK_RESERVE_SIZE;
        }

        this.groupedZipFiles = new ChunkedZipFiles(ixbFiles, AbstractDeliveryExportDelegate.getExportFileName(deliveryRecord), lChunkSize);

        final Set<String> allMetaDataDocNames = new HashSet<String>();

        FetchXML fetchXML = new FetchXML();
        this.groupedZipFiles.processFileVisitor(fetchXML);


        Map<String, Set<String>> masterUFIDtoObjectUFIDs = new HashMap<String, Set<String>>();
        Map<String, String> objectUfidToDocFileName = new HashMap<String, String>();

        // Temporary Data Sets for Linking Family Table Content to it's Specific Object
        Map<String, Set<String>> ufidToRepresentationNames = new HashMap<String, Set<String>>();
        Map<String, Set<ObjectReference>> empUfidToFamilyTableOids = new HashMap<String, Set<ObjectReference>>();
        Map<ObjectReference, Set<IxbElement>> familyTableRefToContentItems = new HashMap<ObjectReference, Set<IxbElement>>();


        final TypeIdentifier contentHolderTi = TypeHelper.getTypeIdentifier(ContentHolder.class);
        final TypeIdentifier persistedCollectableTi = TypeHelper.getTypeIdentifier(PersistedCollectable.class);
        final TypeIdentifier epmContainedInTi = TypeHelper.getTypeIdentifier(EPMContainedIn.class);
        final TypeIdentifier epmSepFamilyTableTi = TypeHelper.getTypeIdentifier(EPMSepFamilyTable.class);
        final TypeIdentifier binaryLinkTi = TypeHelper.getTypeIdentifier(BinaryLink.class);
        final TypeIdentifier deriveImageTi = TypeHelper.getTypeIdentifier(DerivedImage.class);
        final TypeIdentifier substituteLinkTi = TypeHelper.getTypeIdentifier(WTPartSubstituteLink.class);
        final TypeIdentifier docDependancyLinkTi = TypeHelper.getTypeIdentifier(WTDocumentUsageLink.class);
        final TypeIdentifier abstractWorkPackageTi = TypeHelper.getTypeIdentifier(AbstractWorkPackage.class);
        final TypeIdentifier managedBaselineTi = TypeHelper.getTypeIdentifier(ManagedBaseline.class);
        final LinkInfo baselineMemberLink = new BaselineMember().getLinkInfo();

        // Temporary Data For Building in Memory Linking Structure
        Map<TypeIdentifier, LinkInfo> tiToBinaryLinkClassCache = new HashMap<TypeIdentifier, LinkInfo>();
        Map<MemoryLink, String[]> linkToUFIDs = new HashMap<MemoryLink, String[]>();
        // Temporary Data for linking AxlEntry to oempart, AML and AVL
        Map<String, String[]> axlEntryFileNamesToPartUfids = new HashMap<String, String[]>();

        // Initialize Data nonGeneric Links
        final Map<TypeIdentifier, String[]> linkTypeRoleOverrides = new HashMap<TypeIdentifier, String[]>();
        linkTypeRoleOverrides.put(TypeHelper.getTypeIdentifier(EPMBuildHistory.class), new String[]{EPMHndHelper.XML_ATTR_BUILD_SOURCE, EPMHndHelper.XML_ATTR_BUILD_TARGET});

        Map<RoleDescriptor, LocalizableMessage> linkRoleToDisplayName = getLabelsForLinkRole();

        boolean destroyDanglingLinks = true;
        if (PersistenceHelper.isPersistent(delivery) && WPTypeBasedPropertiesOverride.isZipComparisonTest(delivery)) {
            destroyDanglingLinks = false;
        }

        /*
         * If addZipInfoFiles is null, set value of destroyDanglingLinks to copyForwardZipFiles
         */
        if (Objects.isNull(addZipInfoFiles)) {
            this.copyForwardZipFiles = destroyDanglingLinks;
        } else {
            this.copyForwardZipFiles = addZipInfoFiles;
        }

        /*
         * BEGIN Processing Package Object 
         */
        AbstractWorkPackage pkg = null;
        ObjectReference pkgRef = delivery.getMyPackageReference();
      	boolean deflateRef = !pkgRef.isObjectInflated();
    	boolean originalAccessEnforced = SessionServerHelper.manager.setAccessEnforced(false);
    	try{
           pkg = (AbstractWorkPackage)pkgRef.getObject();
    	}finally{
    		SessionServerHelper.manager.setAccessEnforced(originalAccessEnforced);
    		if(deflateRef){
    			//Ensure reference is deflated before returning
    			pkgRef.deflate();
    		}
    	}
            
      
         this.pkgMemObj = new MemoryObject(pkg);
         final WTSet seeds = PersistedCollectionHelper.service.getSeeds(delivery.getMyPackage());
         this.docTypeCache.addDoc(this.pkgMemObj.getFileName(), delivery.getMyPackage());
         AttachmentContent pkgContent = getAttachmentContent(delivery);
         if (pkgContent.getAttachmentElements() != null && !pkgContent.getAttachmentElements().isEmpty()) {
          this.fileNameToAttachmentContent.put(this.pkgMemObj.getFileName(), pkgContent);
         }
       

        /*
         * END - Processing Package Object
         */
        long totalTimeProcessingXML = 0;
        for (Path xmlFilePath : fetchXML.xmlFiles) {
            if (xmlFilePath == null) {
                continue;
            }

            long startTimeXMLProcessing = System.nanoTime();
            // Process the metaData XMLs
            String fileName = xmlFilePath.toString();
            allMetaDataDocNames.add(fileName);
            this.fileNameToFileSystem.put(fileName, xmlFilePath);

            InputStream is = new ByteArrayInputStream(Files.readAllBytes(xmlFilePath));
            IxbDocument doc = IxbHelper.newIxbDocument(is, false);
            this.docTypeCache.addDoc(fileName, doc);
            TypeIdentifier objTi = this.docTypeCache.getTypeIdentifier(fileName);

            if (objTi == null) {
                if (fileName.contains("Representation")) {
                    addRepresentationByUfidToMap(ufidToRepresentationNames, doc);
                }
            } else {

                if (objTi.isDescendedFrom(epmContainedInTi)) {
                    appendFamilyTableRefsByEpmDocUfidToMap(empUfidToFamilyTableOids, doc);
                } else if (objTi.isDescendedFrom(epmSepFamilyTableTi)) {
                    addContentItemsByFamilyTableUfidToMap(familyTableRefToContentItems, doc);
                } else {
                    // Start processing XML object with valid TI
                    IxbElement docRoot = doc.getRootElement();

                    if (objTi.isDescendedFrom(persistedCollectableTi) || objTi.isDescendedFrom(abstractWorkPackageTi)) {
                        String objectUfid = docRoot.getValue(IxbHndHelperConstants.XML_ATTR_UFID);
                        objectUfidToDocFileName.put(objectUfid, fileName);
                        String masterUfid = docRoot.getValue("masterUfid");
                        Set<String> objectUFIDs = masterUFIDtoObjectUFIDs.get(masterUfid);
                        if (objectUFIDs == null) {
                            objectUFIDs = new HashSet<String>(1);
                            masterUFIDtoObjectUFIDs.put(masterUfid, objectUFIDs);
                        }
                        objectUFIDs.add(objectUfid);

                        // Create new memory object
                        MemoryObject mObj = new MemoryObject(doc, fileName, this.docTypeCache);
                        if (seeds != null && seeds.contains(mObj.getObjectReference())) {
                            mObj.setSeedObj(true);
                        }
                        this.fileNameToMemoryObjs.put(fileName, mObj);

                        if (trackedObjects.getNewObjects().contains(mObj.getObjectReference())) {
                            newMemoryObjs.add(mObj);
                        } else if (trackedObjects.getChangedObjects().contains(mObj.getObjectReference())) {
                            changedMemoryObjs.add(mObj);
                        } else if (this.unchangedObjs.contains(mObj.getObjectReference())) {
                            // Remove the unchanged object from the set so they do not appear in the Not Delivered table
                            this.unchangedObjs.remove(mObj.getObjectReference());
                        }

                        if (managedBaselineTi != null && objTi.isDescendedFrom(managedBaselineTi)) {
                            @SuppressWarnings("unchecked")
                            Enumeration<IxbElement> baselineMemElmts = docRoot.getElements(IxbHndHelperConstants.XML_ATTR_MANAGEDBASELINE_BASELINEMEMBERS);
                            if (baselineMemElmts != null) {
                                while (baselineMemElmts.hasMoreElements()) {
                                    IxbElement baselineMemElmt = baselineMemElmts.nextElement();
                                    String baselineMembersUfid = baselineMemElmt.getValue();
                                    if (baselineMembersUfid != null) {

                                        // create MemoryLink to be used for Related Objects table for ManagedBaseline
                                        MemoryLink mlink = new MemoryLink(
                                                mObj.getFileName(),
                                                null,
                                                baselineMemberLink.getRoleA().getName(),
                                                linkRoleToDisplayName.get(baselineMemberLink.getRoleA().getOtherRole()),
                                                linkRoleToDisplayName.get(baselineMemberLink.getRoleB().getOtherRole()),
                                                baselineMemberLink.getRoleB().getName(),
                                                null, true
                                                );
                                        linkToUFIDs.put(mlink, new String[]{objectUfid, baselineMembersUfid});
                                    }

                                }
                            }
                        }

                        if (objTi.isDescendedFrom(contentHolderTi)) {
                            this.fileNameToAttachmentContent.put(fileName, new AttachmentContent(doc));
                        }

                    } else if (objTi.isDescendedFrom(binaryLinkTi)) {
                        LinkInfo linkInfo = tiToBinaryLinkClassCache.get(objTi);
                        if (linkInfo == null) {
                            String className = ClientTypedUtility.getClassname(objTi);
                            BinaryLink binaryLink;
                            try {
                                binaryLink = (BinaryLink) Class.forName(className).newInstance();
                            } catch (ClassNotFoundException e) {
                                throw new WTException(e);
                            } catch (InstantiationException e) {
                                throw new WTException(e);
                            } catch (IllegalAccessException e) {
                                throw new WTException(e);
                            }
                            linkInfo = binaryLink.getLinkInfo();
                            tiToBinaryLinkClassCache.put(objTi, linkInfo);
                        }

                        String roleAName;
                        String roleBName;
                        String[] linkRoleOverrides = linkTypeRoleOverrides.get(objTi);
                        if (linkRoleOverrides == null) {
                            roleAName = linkInfo.getRoleA().getName();
                            roleBName = linkInfo.getRoleB().getName();
                        } else {
                            roleAName = linkRoleOverrides[0];
                            roleBName = linkRoleOverrides[1];
                        }

                        String roleALinkUfid = null;
                        IxbElement temp = null;
                        temp = docRoot.getElement(roleAName);
                        if (temp != null) {
                            temp = temp.getElement(IxbHndHelper.XML_TAG_OBJECT_REFERENCE);
                            if (temp != null) {
                                roleALinkUfid = temp.getValue(IxbHndHelper.XML_TAG_UFID);
                            }
                        }

                        String roleBLinkUfid = null;
                        temp = docRoot.getElement(roleBName);
                        if (temp != null) {
                            temp = temp.getElement(IxbHndHelper.XML_TAG_OBJECT_REFERENCE);
                            if (temp != null) {
                                roleBLinkUfid = temp.getValue(IxbHndHelper.XML_TAG_UFID);
                            }
                        }

                        if ((roleALinkUfid != null) && (roleBLinkUfid != null)) {
                            // Create MemoryLink
                            MemoryLink mLink = new MemoryLink(
                                    fileName,
                                    null,
                                    roleAName,
                                    linkRoleToDisplayName.get(linkInfo.getRoleA()),
                                    linkRoleToDisplayName.get(linkInfo.getRoleB()),
                                    roleBName,
                                    null, 
                                    false
                                    );
                            linkToUFIDs.put(mLink, new String[]{roleALinkUfid, roleBLinkUfid});
                            this.fileNameToMemoryLinks.put(mLink.fileName, mLink);

                            String objectUfid = docRoot.getValue(IxbHndHelperConstants.XML_ATTR_UFID);
                            if (objectUfid != null) {
                                objectUfidToDocFileName.put(objectUfid, fileName);
                            }

                            // Process Link Type Specific Attributes
                            if (objTi.isDescendedFrom(docDependancyLinkTi)) {
                                String structOrder = docRoot.getValue(IxbHndHelperConstants.XML_ATTR_USAGE_LINK_STRUCT_ORDER);
                                mLink.addTypeSpecificAttribute(IxbHndHelperConstants.XML_ATTR_USAGE_LINK_STRUCT_ORDER, structOrder);
                            }

                        }
                        else {
                            // This means the link XML does not use the role names for the tag names
                            logger.warn("Failed to get UFID for link, link will be skipped. Failed type instance: " + objTi.toExternalForm());
                        }
                    } else if (WPIxbHndHelper.AXLENTRY_TI != null && objTi.isDescendedFrom(WPIxbHndHelper.AXLENTRY_TI)) {
                        String oEMPartAXLEntryUfid = docRoot.getValue(WPIxbHndHelper.XML_TAG_AXLENTRY_OEMPART_UFID);
                        if (oEMPartAXLEntryUfid == null)
                            continue;
                        String mfgPartMasterAXLEntryUfid = docRoot.getValue(WPIxbHndHelper.XML_TAG_AXLENTRY_MANUFACTURERPARTAXLINFO_WTPARTMASTERREF_UFID);
                        String vendorPartMasterAXLEntryUfid = docRoot.getValue(WPIxbHndHelper.XML_TAG_AXLENTRY_VENDORPARTAXLINFO_WTPARTMASTERREF_UFID);
                        if (mfgPartMasterAXLEntryUfid != null || vendorPartMasterAXLEntryUfid != null) {
                            axlEntryFileNamesToPartUfids.put(fileName, new String[]{oEMPartAXLEntryUfid, mfgPartMasterAXLEntryUfid, vendorPartMasterAXLEntryUfid});
                        }
                    } else if (objTi.isDescendedFrom(deriveImageTi)) {
                        addRepresentationByUfidToMap(ufidToRepresentationNames, doc);
                    }

                }
                // End processing XML object with valid TI
            }

            long endTimeXMLProcessing = System.nanoTime();
            totalTimeProcessingXML += (endTimeXMLProcessing - startTimeXMLProcessing);
        }

        if(fetchXML.error != null) throw fetchXML.error;
        System.out.println("Total XML Processing Time: " + (totalTimeProcessingXML / 1000000000.0));

        // Remove WTPartSubstitionLinks and place them into a seperate collection
        //   so they can be processed specially and not dereferenced too earily.
        Set<String> subLinkFileNames = this.docTypeCache.getMetaDataFileNamesDescendedFrom(substituteLinkTi);
        Map<MemoryLink, String[]> substituteLinksToUFIDs = new HashMap<MemoryLink, String[]>(subLinkFileNames.size());
        for (String subLinkFileName : subLinkFileNames) {
            MemoryLink subLink = getMemoryLinkByFileName(subLinkFileName);
            substituteLinksToUFIDs.put(subLink, linkToUFIDs.get(subLink));
            linkToUFIDs.remove(subLink);
        }

        // Post-process links and link them to the objects in memory
        for (Map.Entry<MemoryLink, String[]> linkToUFIDsEntry : linkToUFIDs.entrySet()) {
            MemoryLink link = linkToUFIDsEntry.getKey();
            String[] ufids = linkToUFIDsEntry.getValue();

            Set<MemoryObject> parentMemObjs = getMemoryObjectSetFromUFID(ufids[0], masterUFIDtoObjectUFIDs, objectUfidToDocFileName);

            if (!parentMemObjs.isEmpty()) {
                link.parentMemObjs = parentMemObjs;
            }

            if (destroyDanglingLinks && link.parentMemObjs == null) {
                logger.debug("Dangling link encountered: " + link.fileName);
                unreferenceLink(link);
                continue;
            }

            Set<MemoryObject> childMemObjs = getMemoryObjectSetFromUFID(ufids[1], masterUFIDtoObjectUFIDs, objectUfidToDocFileName);

            if (!childMemObjs.isEmpty()) {
                link.childMemObjs = childMemObjs;
            }

            if (destroyDanglingLinks && link.childMemObjs == null) {
                logger.debug("Dangling link encountered: " + link.fileName);
                unreferenceLink(link);
                continue;
            }

            Set<MemoryObject> objectsThatAreParentsAndChildren = new HashSet<MemoryObject>(link.parentMemObjs);
            objectsThatAreParentsAndChildren.retainAll(link.childMemObjs);

            if (!objectsThatAreParentsAndChildren.isEmpty()) {
                logger.error("Invalid link detected (links to self): " + link.fileName);
                unreferenceLink(link);
                continue;
            }

            for (MemoryObject parentMemObj : link.parentMemObjs) {
                parentMemObj.addRelatedLink(link);
            }
            for (MemoryObject childMemObj : link.childMemObjs) {
                childMemObj.addRelatedLink(link);
            }
        }

        if (!axlEntryFileNamesToPartUfids.isEmpty()) {
            // post-process AxlEntry files to link oempart to aml and or avl
            processAxlEntryXMLFiles(axlEntryFileNamesToPartUfids, masterUFIDtoObjectUFIDs, objectUfidToDocFileName, linkRoleToDisplayName);
        }

        // Process WTPartSubstitutionLinks
        for (Map.Entry<MemoryLink, String[]> subLinksToUFIDsEntry : substituteLinksToUFIDs.entrySet()) {
            MemoryLink subMemLink = subLinksToUFIDsEntry.getKey();
            String[] ufids = subLinksToUFIDsEntry.getValue();

            unreferenceLink(subMemLink);
            MemoryLink usageLink = getMemoryLinkByFileName(objectUfidToDocFileName.get(ufids[0]));
            if (destroyDanglingLinks && usageLink == null) {
                logger.debug("Dangling link encountered: " + subMemLink.fileName);
                continue;
            }

            Set<MemoryObject> subPartMemObjSet = getMemoryObjectSetFromUFID(ufids[1], masterUFIDtoObjectUFIDs, objectUfidToDocFileName);
            if (destroyDanglingLinks && subPartMemObjSet.isEmpty()) {
                logger.debug("Dangling link encountered: " + subMemLink.fileName);
                continue;
            }

            for (MemoryObject subPartMemObj : subPartMemObjSet) {
                SubstitutionLink subLink = new SubstitutionLink(subMemLink.fileName, subPartMemObj, usageLink);

                subPartMemObj.addSubstitutionLink(subLink);
                for (MemoryObject memObj : usageLink.parentMemObjs) {
                    memObj.addSubstitutionLink(subLink);
                }
                for (MemoryObject memObj : usageLink.childMemObjs) {
                    memObj.addSubstitutionLink(subLink);
                }
            }
        }

        // Init docFileName2Representation
        for (Map.Entry<String, Set<String>> ufidsToRepUfidsEntry : ufidToRepresentationNames.entrySet()) {
            String docFileName = objectUfidToDocFileName.get(ufidsToRepUfidsEntry.getKey());
            Set<String> representationFileNames = ufidsToRepUfidsEntry.getValue();
            if (!(representationFileNames == null || representationFileNames.isEmpty())) {
                this.docFileName2Representation.put(docFileName, representationFileNames);
            }
        }

        // Init EpmDocFileName2FamilyTableContent
        Map<String, ObjectReference> epmDocUfidToLatestFamilyTableVersion = DependencyAssistant.getLatestRelatedObject(empUfidToFamilyTableOids);
        for (Map.Entry<String, ObjectReference> epmDocUfidToFamilyTableEntry : epmDocUfidToLatestFamilyTableVersion.entrySet()) {
            String epmDocUfid = epmDocUfidToFamilyTableEntry.getKey();
            String epmDocFileName = objectUfidToDocFileName.get(epmDocUfid);
            if (epmDocFileName != null) {
                Set<IxbElement> contentItems = familyTableRefToContentItems.get(empUfidToFamilyTableOids.get(epmDocUfid));
                if (!(contentItems == null || contentItems.isEmpty())) {
                    AttachmentContent attachmentContentForObj = this.fileNameToAttachmentContent.get(epmDocFileName);
                    for (IxbElement contentItem : contentItems) {
                        attachmentContentForObj.addContentItem(contentItem);
                    }
                }
            }

        }

        long endTime = System.currentTimeMillis();
        logger.debug("AbstractManifest.WPZipContent (End) - " + endTime);
        logger.debug("AbstractManifest.WPZipContent (Duration) - " + (endTime - startTime));
      
    }

    private Set<MemoryObject> getMemoryObjectSetFromUFID(String ufid, Map<String, Set<String>> masterUFIDtoObjectUFIDs, Map<String, String> objectUfidToDocFileName) {
        Set<MemoryObject> memObjs = new HashSet<MemoryObject>();
        String objectFileName = objectUfidToDocFileName.get(ufid);

        if (objectFileName == null) {
            Set<String> objectUFIDs = masterUFIDtoObjectUFIDs.get(ufid);
            if (objectUFIDs != null) {
                for (String objectUFID : objectUFIDs) {

                    objectFileName = objectUfidToDocFileName.get(objectUFID);

                    MemoryObject memObj = getMemoryObjectByFileName(objectFileName);
                    if (memObj != null) {
                        memObjs.add(memObj);
                    }
                }
            }
        } else {
            MemoryObject memObj = getMemoryObjectByFileName(objectFileName);
            if (memObj != null) {
                memObjs.add(memObj);
            }
        }

        return memObjs;
    }

    private AttachmentContent getAttachmentContent(DeliveryRecord delivery) throws WTException {
        AbstractWorkPackage pkg = delivery.getMyPackage();
        AttachmentContent packageContent = new AttachmentContent();

        boolean currentUserHasAccess = AccessControlHelper.manager.hasAccess(SessionHelper.getPrincipal(), this.deliveryRecord.getMyPackage(), AccessPermission.DOWNLOAD);
        boolean recipientHasAccess = true;
        WTUser recipient = delivery.getSentTo();
        if(recipient != null && WTUserSecurityChoice.USER_ONLY.equals(delivery.getWtUserSecurityChoice())) {
            //Will check recipient download permission only if security options selected is only package contents accessible to recipient.
            recipientHasAccess = AccessControlHelper.manager.hasAccess(recipient,  this.deliveryRecord.getMyPackage(), AccessPermission.DOWNLOAD);
        }

        if (currentUserHasAccess && recipientHasAccess) {
            List<ContentRoleType> includedContentRoles = WPHelper.getIncludedPackageContentRoles(pkg);
            if (! includedContentRoles.contains(ContentRoleType.WP_EXP_SECONDARY))
               includedContentRoles.add(ContentRoleType.WP_EXP_SECONDARY);
            ContentRoleType[] contentTypes = includedContentRoles.toArray(new ContentRoleType[includedContentRoles.size()]);

            boolean origAccess = SessionServerHelper.manager.setAccessEnforced(false);
            try {
                @SuppressWarnings("unchecked")
                Map<Object, Map<ContentItem, InputStream>> contentStreamsMap =
                        ContentHelper.service.getInputStreamsByRoles(pkg, contentTypes);

                for (Map<ContentItem, InputStream> contentItemMap : contentStreamsMap.values()) {
                    for (Map.Entry<ContentItem, InputStream> contentItemMapEntry : contentItemMap.entrySet()) {
                        ContentItem contentItem = contentItemMapEntry.getKey();
                        if (ApplicationData.class.isAssignableFrom(contentItem.getClass())) {
                            ApplicationData contentData = (ApplicationData) contentItem;
                            AttachmentContent.AttachmentElement ae = packageContent.new AttachmentElement(contentData);
                            this.packageAttachmentElementToInputStream.put(ae, contentItemMapEntry.getValue());
                        } else if (URLData.class.isAssignableFrom(contentItem.getClass())) {
                            URLData contentData = (URLData) contentItem;
                            AttachmentContent.AttachmentElement ae = packageContent.new AttachmentElement(contentData);
                            this.packageAttachmentElementToInputStream.put(ae, null);
                        } else if (ExternalStoredData.class.isAssignableFrom(contentItem.getClass())) {
                            ExternalStoredData contentData = (ExternalStoredData) contentItem;
                            AttachmentContent.AttachmentElement ae = packageContent.new AttachmentElement(contentData);
                            this.packageAttachmentElementToInputStream.put(ae, null);
                        } else {
                            logger.debug("Encountered an unknown ContentItem type.");
                        }
                    }
                }

            } finally {
                SessionServerHelper.manager.setAccessEnforced(origAccess);
            }

        }

        return packageContent;
    }

    /**
     * Process AxlEntry files to link oempart to aml and or avl.
     *
     * @param axlEntryFileNamesToPartUfids the axl entry file names to part ufids
     * @param masterUFIDtoObjectUFID the master ufi dto object ufid
     * @param objectUfidToDocFileName the object ufid to doc file name
     * @throws WTException the wT exception
     */
    private void processAxlEntryXMLFiles(Map<String, String[]> axlEntryFileNamesToPartUfids, Map<String, Set<String>> masterUFIDtoObjectUFIDs, Map<String, String> objectUfidToDocFileName, Map<RoleDescriptor, LocalizableMessage> linkRoleToDisplayName) throws WTException {
        for (String axlEntryFileName : axlEntryFileNamesToPartUfids.keySet()) {
            String[] ufids = axlEntryFileNamesToPartUfids.get(axlEntryFileName);
            MemoryObject oemPartMemObj = getMemoryObjectByFileName(objectUfidToDocFileName.get(ufids[0]));
            if (oemPartMemObj == null) {
                logger.debug("Dangling axllink encountered: " + axlEntryFileName);
                continue;
            }
            Set<MemoryObject> mfgPartMemObjs = getMemoryObjectSetFromUFID(ufids[1], masterUFIDtoObjectUFIDs, objectUfidToDocFileName);
            Set<MemoryObject> vendorPartMemObjs = getMemoryObjectSetFromUFID(ufids[2], masterUFIDtoObjectUFIDs, objectUfidToDocFileName);

            if (!mfgPartMemObjs.isEmpty() || !vendorPartMemObjs.isEmpty()) {
                Set<AxlEntryInfo> axlLinks = oemPartfileNameToAxlEntryInfos.get(oemPartMemObj.getFileName());
                if (axlLinks == null) {
                    axlLinks = new HashSet<AxlEntryInfo>();
                    oemPartfileNameToAxlEntryInfos.put(oemPartMemObj.getFileName(), axlLinks);
                }

                // create AxlEntryInfo to be used for AML-AVL table data generation
                axlLinks.add(new AxlEntryInfo(axlEntryFileName, mfgPartMemObjs, vendorPartMemObjs));

                Set<MemoryObject> oemPartMemObjSet = new HashSet<MemoryObject>(1);
                // create MemoryLink to be used for Related Objects table AML-AVL data generation
                MemoryLink mlink;
                mlink = new MemoryLink(
                        axlEntryFileName,
                        oemPartMemObjSet,
                        WPIxbHndHelper.OEM_PART_ROLE_NAME,
                        linkRoleToDisplayName.get(WPIxbHndHelper.OEMPART_PART_ROLEDESCRIPTOR),
                        linkRoleToDisplayName.get(WPIxbHndHelper.MANUFACTURER_PART_ROLEDESCRIPTOR),
                        WPIxbHndHelper.MANUFACTURER_PART_ROLE_NAME,
                        mfgPartMemObjs, false);
                for (MemoryObject memObj : mfgPartMemObjs) {
                    memObj.addRelatedLink(mlink);
                }

                mlink = new MemoryLink(
                        axlEntryFileName,
                        oemPartMemObjSet,
                        WPIxbHndHelper.OEM_PART_ROLE_NAME,
                        linkRoleToDisplayName.get(WPIxbHndHelper.OEMPART_PART_ROLEDESCRIPTOR),
                        linkRoleToDisplayName.get(WPIxbHndHelper.VENDOR_PART_ROLEDESCRIPTOR),
                        WPIxbHndHelper.VENDOR_PART_ROLE_NAME,
                        vendorPartMemObjs, false);
                for (MemoryObject memObj : vendorPartMemObjs) {
                    memObj.addRelatedLink(mlink);
                }
            }
        }
    }

    /**
     * Unreference link.
     *
     * @param mLink the m link
     */
    private void unreferenceLink(MemoryLink mLink) {
        logger.debug("Unreferencing link: " + mLink.fileName);
        if(!mLink.isEmbededLink) {
            this.docTypeCache.unreference(mLink.fileName);
        }
        this.fileNameToMemoryLinks.remove(mLink.fileName);
    }

    /**
     * Gets the labels for link role.
     *
     * @return the labels for link role
     * @throws WTException the wT exception
     */
    private Map<RoleDescriptor, LocalizableMessage> getLabelsForLinkRole() throws WTException {
        Map<RoleDescriptor, LocalizableMessage> labelsForLinkRoles = new HashMap<RoleDescriptor, LocalizableMessage>();

        WTMessage PartTableFromCAD = new WTMessage("com.ptc.windchill.uwgm.cadx.caddoc.relatedparts.relatedPartsResource", "1", null);
        if (PartTableFromCAD.getLocalizedMessage() == null) throw new WTException("Could not get label");

        WTMessage referencesDocFromDoc = new WTMessage("com.ptc.windchill.enterprise.doc.documentResource", "REFERENCES_DOC_TABLE_HEADER", null);
        if (referencesDocFromDoc.getLocalizedMessage() == null) throw new WTException("Could not get label");
        WTMessage referencedByDocFromDoc = new WTMessage("com.ptc.windchill.enterprise.doc.documentResource", "REFERENCED_BY_DOC_TABLE_HEADER", null);
        if (referencedByDocFromDoc.getLocalizedMessage() == null) throw new WTException("Could not get label");

        WTMessage referencesEPMDocFromEPMDoc = new WTMessage("com.ptc.windchill.uwgm.cadx.caddoc.references.referenceLinkResource", "REFERENCES", null);
        if (referencesEPMDocFromEPMDoc.getLocalizedMessage() == null) throw new WTException("Could not get label");
        WTMessage referencedByEPMDocFromEPMDoc = new WTMessage("com.ptc.windchill.uwgm.cadx.caddoc.references.referenceLinkResource", "REFERENCED_BY", null);
        if (referencedByEPMDocFromEPMDoc.getLocalizedMessage() == null) throw new WTException("Could not get label");

        WTMessage describesPartsFromDoc = new WTMessage("com.ptc.windchill.enterprise.part.partResource", "DESCRIBES_PARTS_TABLE_HEADER", null);
        if (describesPartsFromDoc.getLocalizedMessage() == null) throw new WTException("Could not get label");
        WTMessage referencedByPartsFromRefDoc = new WTMessage("com.ptc.windchill.enterprise.part.partResource", "REFERENCED_BY_PARTS_TABLE_HEADER", null);
        if (referencedByPartsFromRefDoc.getLocalizedMessage() == null) throw new WTException("Could not get label");
        WTMessage describedByDocsFromPart = new WTMessage("com.ptc.windchill.enterprise.part.partResource", "DESCRIBED_BY_DOC_TABLE_HEADER", null);
        if (describedByDocsFromPart.getLocalizedMessage() == null) throw new WTException("Could not get label");
        WTMessage ReferencesDocsFromPart = new WTMessage("com.ptc.windchill.enterprise.part.partResource", "REFERENCES_DOC_TABLE_HEADER", null);
        if (ReferencesDocsFromPart.getLocalizedMessage() == null) throw new WTException("Could not get label");
        WTMessage cadDocsFromPart = new WTMessage("com.ptc.windchill.enterprise.part.partResource", "DESCRIBED_BY_CAD_DOC_TABLE_HEADER", null);
        if (cadDocsFromPart.getLocalizedMessage() == null) throw new WTException("Could not get label");
        if (SumaFacade.getInstance().isInstalled()) {
            WTMessage amlAvlWhereUsedFromSupplierPart = new WTMessage("com.ptc.windchill.suma.jca.jcaResource", "AML_WHERE_USED_LABEL", null);
            if (amlAvlWhereUsedFromSupplierPart.getLocalizedMessage() == null)
                throw new WTException("Could not get label for AML AVL Where Used");
            labelsForLinkRoles.put(WPIxbHndHelper.OEMPART_PART_ROLEDESCRIPTOR, amlAvlWhereUsedFromSupplierPart);
        }

        WTMessage baselineableObject = new WTMessage("com.ptc.windchill.enterprise.baseline.baselineResource", baselineResource.BASELINE_CONTENTS_TEXT, null);
        if (baselineableObject.getLocalizedMessage() == null) {
            throw new WTException("Could not get label for Baselineable Objects");
        }

        WTMessage baselineObject = new WTMessage("com.ptc.windchill.enterprise.baseline.baselineResource", baselineResource.VIEW_BASELINES_TITLE, null);
        if (baselineObject.getLocalizedMessage() == null) {
            throw new WTException("Could not get label for Baseline Objects");
        }

        WTMessage alternatePart = new WTMessage("com.ptc.windchill.enterprise.part.replacementResource", "0", null);
        if (alternatePart.getLocalizedMessage() == null) throw new WTException("Could not get label");

        LinkInfo liWTDocumentDependencyLink = new WTDocumentDependencyLink().getLinkInfo();
        // Referenced By Documents
        labelsForLinkRoles.put(liWTDocumentDependencyLink.getRoleA(), referencedByDocFromDoc); // WTDocument - "describedBy"
        // References Documents
        labelsForLinkRoles.put(liWTDocumentDependencyLink.getRoleB(), referencesDocFromDoc); // WTDocument - "describes"

        LinkInfo liEPMReferenceLink = new EPMReferenceLink().getLinkInfo();
        // Referenced By EPMDocuments
        labelsForLinkRoles.put(liEPMReferenceLink.getRoleA(), referencedByEPMDocFromEPMDoc);
        // References EPMDocuments
        labelsForLinkRoles.put(liEPMReferenceLink.getRoleB(), referencesEPMDocFromEPMDoc);

        LinkInfo liWTPartDescribeLink = new WTPartDescribeLink().getLinkInfo();
        // Describes Parts
        labelsForLinkRoles.put(liWTPartDescribeLink.getRoleA(), describesPartsFromDoc); // WTPart - "describes"
        // Described By Documents
        labelsForLinkRoles.put(liWTPartDescribeLink.getRoleB(), describedByDocsFromPart); // WTDocument - "describedBy"

        LinkInfo liWTPartReferenceLink = new WTPartReferenceLink().getLinkInfo();
        // Referenced By Parts
        labelsForLinkRoles.put(liWTPartReferenceLink.getRoleA(), referencedByPartsFromRefDoc); // WTPart - "referencedBy"
        // References Documents
        labelsForLinkRoles.put(liWTPartReferenceLink.getRoleB(), ReferencesDocsFromPart); // WTDocumentMaster - "references"

        // com.ptc.windchill.enterprise.part.partResource (Not accessable)
        LinkInfo liEPMBuildHistory = new EPMBuildHistory().getLinkInfo();
        // CAD/Dynamic Documents
        labelsForLinkRoles.put(liEPMBuildHistory.getRoleA(), cadDocsFromPart); // BuildSource - "builtBy"
        // Parts
        labelsForLinkRoles.put(liEPMBuildHistory.getRoleB(), PartTableFromCAD); // WTPart - "built"

        LinkInfo liEPMDescribeLink = new EPMDescribeLink().getLinkInfo();
        labelsForLinkRoles.put(liEPMDescribeLink.getRoleA(), PartTableFromCAD); // WTPart - "describes"
        labelsForLinkRoles.put(liEPMDescribeLink.getRoleB(), cadDocsFromPart); // EPMDocument - "describedBy"

        LinkInfo liWTPartAlternateLink = new WTPartAlternateLink().getLinkInfo();
        labelsForLinkRoles.put(liWTPartAlternateLink.getRoleB(), alternatePart); // WTPart - "alternate"

        LinkInfo baselineMemberLink = new BaselineMember().getLinkInfo();
        labelsForLinkRoles.put(baselineMemberLink.getRoleB().getOtherRole(), baselineableObject); // Managed Baseline - "Baseline Object"
        labelsForLinkRoles.put(baselineMemberLink.getRoleA().getOtherRole(), baselineObject); //Basleines



        /*
        From CAD
        Parts
        - EPMBuildHistory
        - EPMDescribeLink

        From Document
        References Documents
        - WTDocumentDependencyLink (support in progress)
        Referenced By Documents
        - WTDocumentDependencyLink (support in progress)
        Describes Parts
        - WTPartDescribeLink
        Referenced By Parts
        - WTPartReferenceLink

        From Part
        Described By Documents
        - WTPartDescribeLink
        - WTProductInstanceDescribeLink ? for Product Instance?
        References Documents
        - WTPartReferenceLink
        - WTProductInstanceReferenceLink (support?)
        CAD/Dynamic Documents
        - EPMBuildHistory
        - EPMDescribeLink
        AML AVL
        Alternate
        - WTPartAlternateLink

        From AML AVL
        OemPart - Vendor

        From ManagedBaseline
        Baseline Objects


         */

        return Collections.unmodifiableMap(labelsForLinkRoles);
    }

    /**
     * Adds the to jar.
     *
     * @param file the file
     * @param pathInZip the path in zip
     * @throws IOException Signals that an I/O exception has occurred.
     * @throws WTException the wT exception
     */
    public int addToJar(File file, String pathInZip) throws IOException, WTException {
        FileInputStream fileIS = new FileInputStream(file);
        int chunkForData = addToJar(pathInZip, fileIS, file.length());
        fileIS.close();

        return chunkForData;
    }

    /**
     * Adds the to jar.
     *
     * @param fileName
     *            the file name
     * @param inputStream
     *            the input stream
     * @param sizeOfFile
     *            the size of file
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     * @throws WTException
     *             the wT exception
     */
    public int addToJar(String fileName, InputStream inputStream, long sizeOfFile) throws IOException, WTException {
        if (logger.isDebugEnabled()) {
            logger.debug("WPZipContent.addToJar: fileName: " + fileName + " sizeOfFile: " + sizeOfFile + " from: "
                    + this.groupedZipFiles);
        }
        return this.groupedZipFiles.addToZip(fileName, inputStream, sizeOfFile);
    }

    /**
     * Deprecated.
     * <BR/>
     * Instead use getPackageMemoryObject()
     * <BR/>
     * <BR/>
     * Gets the Ixb metadata file for the workpackage
     *
     * <BR><BR>
     * <b>Supported API: </b>false
     * <BR><BR>.
     *
     * @return <code>IxbDocument</code>
     * @throws WTException the wT exception
     */
    @Deprecated
    public IxbDocument getWorkPackageMetaData() throws WTException {
        return null;
    }

    /**
     * Deprecated.
     * <BR/>
     * Instead use getPackageMemoryObject()
     * <BR/>
     * <BR/>
     * Gets the name of the Ixb metadata file for the workpackage
     *
     * <BR><BR>
     * <b>Supported API: </b>false.
     *
     * @return <code>String</code>
     * @throws WTException the wT exception
     */
    @Deprecated
    public String getWorkPackageFileName() throws WTException {
        return null;
    }

    /**
     * Gets the <code>MemoryObject</code> that represents the Package being exported.
     *
     * <BR><BR>
     * <b>Supported API: </b>true.
     *
     * @return <code>String</code>
     * @throws WTException the wT exception
     */
    public MemoryObject getPackageMemoryObject() throws WTException {
        return this.pkgMemObj;
    }

    /**
     * Gets a Set of the names of the Ixb metadata files
     *
     * <BR><BR>
     * <b>Supported API: </b>true
     * <BR><BR>.
     *
     * @return <code>Set<String_></code> - A set of strings containing all of the file names of the IxbDocuments in all zip files
     */
    public Set<String> getMetaDataFileNames() {
        return Collections.unmodifiableSet(fileNameToFileSystem.keySet());
    }

    /**
     * Gets a specific Ixb metadata file by file name.
     *
     * <BR><BR>
     * <b>Supported API: </b>true
     * <BR><BR>.
     *
     * @param fileName - <code>String</code>
     * @return <code>IxbDocument</code>
     * @throws WTException the wT exception
     */
    public IxbDocument getMetaDataByFileName(String fileName) throws WTException {
        try {
            InputStream is = getStreamByFileName(fileName);
            IxbDocument doc = IxbHelper.newIxbDocument(is, false);
            if (is != null)
                is.close();
            return doc;
        } catch (IOException e) {
            throw new WTException(e);
        }
    }

    /**
     * Gets the InputStream of the specified file name
     * This only return streams that are in the original files
     * InputStreams added to the new files are not retained
     * this so they can be garbage collected to reduce memory usage
     *
     * Returns null if the file name cannot be found in any of the original files
     * The returned InputStream is reset before being returned
     *
     * <BR><BR>
     * <b>Supported API: </b>true
     * <BR><BR>.
     *
     * @param fileName - <code>String</code>
     * @return <code>InputStream</code>
     * @throws IOException Signals that an I/O exception has occurred.
     * @throws WTException the wT exception
     */
    private InputStream getStreamByFileName(String fileName) throws IOException, WTException {
        InputStream inputStream = null;
        Path filePath = this.fileNameToFileSystem.get(fileName);
        if (filePath != null) {
            inputStream = Files.newInputStream(filePath, StandardOpenOption.READ);
        }

        return inputStream;
    }

    /**
     * Gets the representation file names by doc file name.
     *
     * @param docFileName the doc file name
     * @return the representation file names by doc file name
     */
    public Set<String> getRepresentationFileNamesByDocFileName(String docFileName) {
        Set<String> representations = docFileName2Representation.get(docFileName);
        if (representations == null) {
            return Collections.emptySet();
        } else {
            return new HashSet<String>(representations);
        }
    }

    /**
     * Gets the attachment content by file name.
     *
     * @param fileName the file name
     * @return the attachment content by file name
     */
    public AttachmentContent getAttachmentContentByFileName(String fileName) {
        return this.fileNameToAttachmentContent.get(fileName);
    }

    /**
     * Returns the export format from the delivery record.
     * This can be used for adjustments for cross-version handling.
     *
     * <b>Supported API: </b>true
     *
     * @return format of the export
     */
    public ExportFormatType getExportFormat() {
        return deliveryRecord.getFormatType();
    }

    /**
     * Returns the in memory object represented by the given file name.
     *
     * @param fileName the file name
     * @return In Memory Object
     */
    public MemoryObject getMemoryObjectByFileName(String fileName) {
        return this.fileNameToMemoryObjs.get(fileName);
    }

    /**
     * Returns the in memory link represented by the given file name.
     *
     * @param fileName the file name
     * @return In Memory Link
     */
    public MemoryLink getMemoryLinkByFileName(String fileName) {
        return this.fileNameToMemoryLinks.get(fileName);
    }

    /**
     * Returns memory objects for package members that are new in current export.
     * 
     * @return Set of new MemoryObjects
     */
    public Set<MemoryObject> getNewMemoryObjs() {
        if (newMemoryObjs == null) {
            return Collections.emptySet();
        }

        return Collections.unmodifiableSet(newMemoryObjs);
    }

    /**
     * Returns memory objects for package members that have changed in current export.
     * 
     * @return Set of changed MemoryObjects
     */
    public Set<MemoryObject> getChangedMemoryObjs() {
        if (changedMemoryObjs == null) {
            return Collections.emptySet();
        }

        return Collections.unmodifiableSet(changedMemoryObjs);
    }

    /**
     * Returns memory objects for package members that have not changed in current export.
     * 
     * @return Set of unchanged MemoryObjects
     */
    public Set<MemoryObject> getUnchangedMemoryObjs() {
        Set<MemoryObject> unchangedMemoryObjects = new HashSet<MemoryObject>(this.fileNameToMemoryObjs.values());
        unchangedMemoryObjects.removeAll(this.newMemoryObjs);
        unchangedMemoryObjects.removeAll(this.changedMemoryObjs);

        return Collections.unmodifiableSet(unchangedMemoryObjects);
    }

    /**
     * Returns previously delivered object references.
     * 
     * @return Previously delivered objs
     */
    @SuppressWarnings(value="unchecked")
    public WTCollection getPreviouslyDeliveredObjs() {
        WTSet previouslyDeliveredObjs = new WTHashSet();
        previouslyDeliveredObjs.addAll(this.unchangedObjs);
        previouslyDeliveredObjs.addAll(this.absentObjs);

        return previouslyDeliveredObjs;
    }

    protected boolean isNewObject(MemoryObject memObj) {
        return this.newMemoryObjs.contains(memObj);
    }

    protected boolean isChangedObject(MemoryObject memObj) {
        return this.changedMemoryObjs.contains(memObj);
    }

    protected boolean isUnchangedObject(MemoryObject memObj) {
        boolean isChanged = false;
        if (!isNewObject(memObj) && !isChangedObject(memObj) && this.fileNameToMemoryObjs.containsValue(memObj)) {
            isChanged = true;
        }

        return isChanged;
    }

    protected boolean isUnchangedObject(ObjectReference objRef) {
        return this.unchangedObjs.contains(objRef);
    }

    protected boolean isAbsentObject(ObjectReference objRef) {
        return this.absentObjs.contains(objRef);
    }

    /**
     * Returns a set of AxlMemoryLink for the given oemPartFileName.
     *
     * @param oemPartFileName the oem part file name
     * @return Set of AxlMemoryLinks
     */
    public Set<AxlEntryInfo> getAxlEntryInfosByOemPartFileName(String oemPartFileName) {
        Set<AxlEntryInfo> axlEntryInfos = oemPartfileNameToAxlEntryInfos.get(oemPartFileName);
        if (axlEntryInfos == null) {
            return Collections.emptySet();
        } else {
            return new HashSet<AxlEntryInfo>(axlEntryInfos);
        }
    }

    /**
     * Creates the new zip files.
     *
     * <BR><BR>
     * <b>Supported API: </b>false
     * <BR><BR>
     *
     * @return File[]
     * @throws IOException Signals that an I/O exception has occurred.
     * @throws WTException the wT exception
     */
    protected File[] closeNewExportFiles() throws IOException, WTException {

        long startTime = System.currentTimeMillis();
        logger.debug("AbstractManifest.WPZipContent.createNewExportFiles (Start) - " + startTime);
        int chunkForPackageContent = 0;
        // if createManifest is false then we need to append the attachment 
        if(!this.createManifest){
            chunkForPackageContent = appendPackageAttachments();
        }
        if (this.copyForwardZipFiles) {
            if (this.isImportable) {
                generateAndAddZipInfoFiles(chunkForPackageContent);
            }

        }
        File[] newFiles = this.groupedZipFiles.getFinalizedFiles();

        long endTime = System.currentTimeMillis();
        logger.debug("AbstractManifest.WPZipContent.createNewExportFiles (End) - " + endTime);
        logger.debug("AbstractManifest.WPZipContent.createNewExportFiles (Duration) - " + (endTime - startTime));

        return newFiles;
    }

    /**
     * Delete files.
     */
    protected void deleteFiles() {
        try {
            File[] closedFiles = this.groupedZipFiles.closeFiles();
            closedFiles = WPHelper.getParentFolders(closedFiles);
            WPHelper.deleteFromSystem(closedFiles);
        } catch (IOException e) {
            logger.error("Could not close file writer", e);
        }
    }

    /**
     * Adds content attached to the package to the export.
     * 
     * @return the chunk the package attachments were added to
     * @throws IOException
     */
    private int appendPackageAttachments() throws IOException, WTException {
        long sizeOfAllAttachments = 0;
        for (AttachmentElement element : this.packageAttachmentElementToInputStream.keySet()) {
            sizeOfAllAttachments += Long.parseLong(element.getSize());
        }
        int chunkForPackageAttachments = this.groupedZipFiles.determineChunkForData(sizeOfAllAttachments);

        for (Map.Entry<AttachmentElement, InputStream> packageContent : this.packageAttachmentElementToInputStream.entrySet()) {
            AttachmentElement contentItem = packageContent.getKey();
            String fileName = contentItem.getFileName();
            long fileSize = Long.parseLong(contentItem.getSize());

            this.groupedZipFiles.addToZipIgnoringMaxSizeLimit(chunkForPackageAttachments, fileName, packageContent.getValue(), fileSize);
        }

        return chunkForPackageAttachments;
    }

    /**
     * Generate and add zip info files.
     *
     * @throws IOException Signals that an I/O exception has occurred.
     * @throws WTException the wT exception
     */
    private void generateAndAddZipInfoFiles(int chunkForPackageAttachments) throws IOException, WTException {
        short numOfChunks = this.groupedZipFiles.getCountOfZipChunks();
        short chunkWithManifestFile = -1;
        String manifestFileName = null;
        if (DeliveryManifestType.STATIC == this.deliveryRecord.getDeliveryManifest()) {
        	AbstractWorkPackage wp = null;
        	ObjectReference pkgRef = this.deliveryRecord.getMyPackageReference();
           	boolean deflateRef = !pkgRef.isObjectInflated();
        	boolean originalAccessEnforced = SessionServerHelper.manager.setAccessEnforced(false);
        	try{
               wp = (AbstractWorkPackage)pkgRef.getObject();
        	}finally{
        		SessionServerHelper.manager.setAccessEnforced(originalAccessEnforced);
        		if(deflateRef){
        			//Ensure reference is deflated before returning
        			pkgRef.deflate();
        		}
        	}       	
        	        	
            manifestFileName = WPHelper.service.getManifestFileName(wp);
            FindManifestFileVisitor findManifestFileVisitor = new FindManifestFileVisitor(manifestFileName);
            this.groupedZipFiles.processFileVisitor(findManifestFileVisitor);
            FileSystem fileSystem = findManifestFileVisitor.staticManifest.getFileSystem();
            if (fileSystem != null) {
                chunkWithManifestFile = this.groupedZipFiles.getFileChunk(fileSystem);
            }
        }

        // Create and fill List with null values
        List<Set<AttachmentContent.AttachmentElement>> wpContentPerChunk = new ArrayList<Set<AttachmentContent.AttachmentElement>>(numOfChunks);
        for (int i=0; i<numOfChunks; i++) wpContentPerChunk.add(null);

        AttachmentContent wpAttachmentContent = getAttachmentContentByFileName(this.pkgMemObj.getFileName());

        if(wpAttachmentContent != null) {
            wpContentPerChunk.set(chunkForPackageAttachments, wpAttachmentContent.getAttachmentElements());
        }

        InputStream[] zipInfoFiles = ZipChunkInfoHelper.generateInfoFiles(this.deliveryRecord, wpContentPerChunk, chunkWithManifestFile, manifestFileName);
        for (int i = 0; i < zipInfoFiles.length; i++) {
            this.groupedZipFiles.addToZipIgnoringMaxSizeLimit(i, ZipChunkInfoHelper.getZipInfoPathAndName(), zipInfoFiles[i], 0L);
        }

        /*If exists missing object info tmp dir, catch and append files to zip*/
        File missingObjFile = new File(this.groupedZipFiles.getZipPath() + MISSING_OBJECT_DIR_SUFFIX);
        if (missingObjFile.exists()) {
            try (DirectoryStream<Path> stream = Files.newDirectoryStream(missingObjFile.toPath())) {
                for (Path entry: stream) {
                    this.groupedZipFiles.addToZip(entry.toFile(), IN_ZIP_MISSING_OBJECT_DIR + entry.getFileName());
                }
            }
            if (logger.isDebugEnabled()) {
                logger.debug("generateAndAddZipInfoFiles : missing object file dir exists");
            }
        }
    }

    /**
     * Adds the representation by ufid to map.
     *
     * @param ufidToRepresentationFilePaths the ufid to representation file paths
     * @param representationDoc the representation doc
     * @throws WTException the wT exception
     */
    private void addRepresentationByUfidToMap(
            Map<String, Set<String>> ufidToRepresentationFilePaths,
            IxbDocument representationDoc
    ) throws WTException {
        IxbElement docRoot = representationDoc.getRootElement();
        String representationFilePath = docRoot.getValue(ExpImpForRepresentation.XML_ATTR_REPRESENTATION_CONTENT_ID);

        // representationFilePath is null in the business xml if
        // the representation file is excluded from the zip by using ContentControl or the file extension filter
        if (representationFilePath != null) {
            IxbElement objRef = docRoot.getElement(ExpImpForRepresentation.XML_TAG_REPRESENTABLE_OBJ_REF);
            Enumeration repObjRefChildren = objRef.getElements();
            repObjRefChildren.nextElement();
            objRef = (IxbElement) repObjRefChildren.nextElement();
            String ufid = objRef.getValue(IxbHndHelperConstants.XML_ATTR_UFID);

            Set<String> representationFileNames = ufidToRepresentationFilePaths.get(ufid);
            if (representationFileNames == null) {
                representationFileNames = new HashSet<String>();
                ufidToRepresentationFilePaths.put(ufid, representationFileNames);
            }
            representationFileNames.add(representationFilePath);
        }
    }

    /**
     * Append family table refs by epm doc ufid to map.
     *
     * @param empUfidToFamilyTableOids the emp ufid to family table oids
     * @param epmContainedInDoc the epm contained in doc
     * @throws WTException the wT exception
     */
    private void appendFamilyTableRefsByEpmDocUfidToMap(
            Map<String, Set<ObjectReference>> empUfidToFamilyTableOids,
            IxbDocument epmContainedInDoc
    ) throws WTException {
        IxbElement root = epmContainedInDoc.getRootElement();
        String epmDocId = root.getValue(EPMHndHelper.XML_ATTR_CONTAINS_UFID);
        String sepTableId = root.getValue(EPMHndHelper.XML_ATTR_CONTAINEDIN_UFID);
        ObjectReference sepTableRef = getObjectRef(sepTableId);

        Set<ObjectReference> familyTables = empUfidToFamilyTableOids.get(sepTableRef);
        if (familyTables == null) {
            familyTables = new HashSet<ObjectReference>();
            empUfidToFamilyTableOids.put(epmDocId, familyTables);
        }

        familyTables.add(sepTableRef);
    }

    /**
     * Gets the object ref.
     *
     * @param ufid the ufid
     * @return the object ref
     * @throws WTException the wT exception
     */
    private ObjectReference getObjectRef(String ufid) throws WTException {
        String localId = ufid.substring(0, ufid.indexOf('|')).trim();
        ObjectIdentifier objId = ObjectIdentifier.newObjectIdentifier(localId);
        ObjectReference objRef = ObjectReference.newObjectReference(objId);

        return objRef;
    }

    /**
     * Adds the content items by family table ufid to map.
     *
     * @param familyTableRefToContentItems the family table ref to content items
     * @param familyTableDoc the family table doc
     * @throws WTException the wT exception
     */
    private void addContentItemsByFamilyTableUfidToMap(
            Map<ObjectReference, Set<IxbElement>> familyTableRefToContentItems,
            IxbDocument familyTableDoc) throws WTException {

        IxbElement root = familyTableDoc.getRootElement();
        String sepTableOidStr = root.getValue(IxbHndHelperConstants.XML_ATTR_LOCAL_ID);
        ObjectReference sepTableRef = ObjectReference.newObjectReference(ObjectIdentifier.newObjectIdentifier(sepTableOidStr));

        Set<IxbElement> contentItemList = familyTableRefToContentItems.get(sepTableRef);
        if (contentItemList == null) {
            contentItemList = new HashSet<IxbElement>();
            familyTableRefToContentItems.put(sepTableRef, contentItemList);
        }

        Enumeration epmSepTableContentIds = root.getElements(IxbHndHelperConstants.XML_CONTENT);
        while (epmSepTableContentIds.hasMoreElements()) {
            IxbElement element1 = (IxbElement) epmSepTableContentIds.nextElement();
            if (element1 != null) {
                contentItemList.add(element1);
            }
        }

    }

    /**
     * Gets the parent class.
     *
     * @param fileName the file name
     * @return the parent class
     * @throws WTException the wT exception
     */
    public Class getParentClass(String fileName) throws WTException {
        return this.docTypeCache.getParentClass(fileName);
    }

    /**
     * Gets the type identifier.
     *
     * @param fileName the file name
     * @return the type identifier
     * @throws WTException the wT exception
     */
    public TypeIdentifier getTypeIdentifier(String fileName) throws WTException {
        return this.docTypeCache.getTypeIdentifier(fileName);
    }

    /**
     * Get the display name for the object's TypeIdentifier.
     *
     * @param fileName the file name
     * @param locale the locale
     * @return the type identifier display name
     * @throws WTException the wT exception
     */
    public String getTypeIdentifierDisplayName(String fileName, Locale locale) throws WTException {
        return this.docTypeCache.getTypeIdentifierDisplayName(fileName, locale);
    }

    /**
     * Get the display name for the object.
     *
     * @param fileName the file name
     * @param locale the locale
     * @return the object type display name
     * @throws WTException the wT exception
     */
    public String getObjectTypeDisplayName(String fileName, Locale locale) throws WTException {
        return this.docTypeCache.getObjectTypeDisplayName(fileName, locale);
    }

    /**
     * Gets the org id label.
     *
     * @param fileName the file name
     * @param locale the locale
     * @return the org id label
     * @throws WTException the wT exception
     */
    public String getOrgIdLabel(String fileName, Locale locale) throws WTException {
        return this.docTypeCache.getOrgIdLabel(fileName, locale);
    }

    /**
     * Gets the meta data file names descended from.
     *
     * @param parentTI the parent ti
     * @return the meta data file names descended from
     */
    public Set<String> getMetaDataFileNamesDescendedFrom(TypeIdentifier parentTI) {
        return this.docTypeCache.getMetaDataFileNamesDescendedFrom(parentTI);
    }

    public DocTypeCache getDocTypeCache() {
        return this.docTypeCache;
    }

    /**
     * The Class MemoryObject.
     */
    static protected class MemoryObject {

        /** The file name. */
        private final String fileName;
        /** The obj ref. */
        private final ObjectReference objRef;
        /** The name. */
        private final String name;
        /** The number. */
        private final String number;
        /** The revision. */
        private final String revision;
        /** The iteration. */
        private final String iteration;
        /** The container name. */
        private final String containerName;
        /** The view. */
        private final String view; // null is valid
        /** The lifecycle state. */
        private final String lifecycleState;
        /** The owning org. */
        private final String owningOrg;
        /** The related links. */
        private List<MemoryLink> relatedLinks = null;
        /** The sub links. */
        private List<SubstitutionLink> subLinks = null;
        /** The rich text description. */
        private final IxbElement richTextDescription;
        private boolean isSeedObject = false;

        /**
         * Adds the related link.
         *
         * @param mLink the m link
         */
        private void addRelatedLink(MemoryLink mLink) {
            if (this.relatedLinks == null) {
                this.relatedLinks = new ArrayList<MemoryLink>();
            }
            this.relatedLinks.add(mLink);
        }

        /**
         * Get all links this objects plays a role in.
         *
         * If this method becomes heavily used the backing object should be initialized
         *    to an unmodifiable list after all zip data has been processed.
         *
         * @return Unmodifiable list
         */
        public List<MemoryLink> getRelatedLinks() {
            if (this.relatedLinks == null) {
                return Collections.emptyList();
            } else {
                return Collections.unmodifiableList(this.relatedLinks);
            }
        }

        /**
         * Adds the substitution link.
         *
         * @param sLink the s link
         */
        private void addSubstitutionLink(SubstitutionLink sLink) {
            if (this.subLinks == null) {
                this.subLinks = new ArrayList<SubstitutionLink>();
            }
            this.subLinks.add(sLink);
        }

        /**
         * Get all substitution links this objects plays a role in.
         *
         * If this method becomes heavily used the backing object should be initialized
         *    to an unmodifiable list after all zip data has been processed.
         *
         * @return Unmodifiable list
         */
        public List<SubstitutionLink> getSubstitutionLinks() {
            if (this.subLinks == null) {
                return Collections.emptyList();
            } else {
                return Collections.unmodifiableList(this.subLinks);
            }
        }

        /**
         * !!!FOR TESTING ONLY!!!
         * This constructor is exposed for testing ONLY.
         *
         * @param objRef is used for object comparison and hashcode.
         * @throws WTException the wT exception
         */
        MemoryObject(ObjectReference objRef, boolean isSeed) throws WTException {
            this.objRef = objRef;
            this.fileName = null;
            this.name = null;
            this.number = null;
            this.revision = null;
            this.iteration = null;
            this.containerName = null;
            this.view = null; // null is valid
            this.lifecycleState = null;
            this.owningOrg = null;
            this.richTextDescription = null;
            this.isSeedObject = isSeed;
        }

        /**
         * Instantiates a new memory object.
         *
         * @param pkg the WorkPackage
         * @throws WTException the WTException
         */
        MemoryObject(AbstractWorkPackage pkg) throws WTException {
            this.objRef = ObjectReference.newObjectReference(pkg);
            this.fileName = "PACKAGE";
            this.name = pkg.getName();
            this.number = pkg.getNumber();
            this.revision = pkg.getVersionIdentifier().getValue();
            this.iteration = pkg.getIterationIdentifier().getValue();
            this.containerName = pkg.getContainerName();
            this.view = null; // null is valid
            this.lifecycleState = pkg.getLifeCycleState().toString();
            this.owningOrg = pkg.getOrganizationName();
            this.richTextDescription = null;
        }

        /**
         * Return true is obj is used as seed in PersistedCollectionHolder.
         * @return boolean
         */
        public boolean isSeedObj() {
            return isSeedObject;
        }

        /**
         * Sets isSeed attribute.
         * @param isSeedObj
         */
        private void setSeedObj(boolean isSeedObj) {
            isSeedObject = isSeedObj;
        }

        /**
         * Instantiates a new memory object.
         *
         * @param doc the doc
         * @param fileName the file name
         * @throws WTException the wT exception
         */
        protected MemoryObject(IxbDocument doc, String fileName, DocTypeCache docTypeCache) throws WTException {
            this.fileName = fileName;
            if (this.fileName == null) {
                throw new WTException("Error initalizing MemoryObject, file name was null");
            }

            IxbElement docRoot = doc.getRootElement();
            this.objRef = (ObjectReference) WPIxbHndHelper.getObjectReference(doc);
            this.name = getTrimmedStringOrNull(docRoot.getValue(IxbHndHelperConstants.XML_ATTR_NAME));

            String number = docRoot.getValue(IxbHndHelperConstants.XML_ATTR_NUMBER); 
            if(number == null) {
                number = docRoot.getValue(IxbHndHelperConstants.XML_ATTR_PRODUCTINSTANCE_NUMBER);
            }
            this.number = getTrimmedStringOrNull(number);
            StringBuilder versionId = new StringBuilder();
            String revId = getTrimmedStringOrNull(docRoot.getValue(IxbHndHelperConstants.XML_ATTR_VERSION_ID));
            if(revId == null) {
                revId = getTrimmedStringOrNull(docRoot.getValue(IxbHndHelper.XML_ATTR_PRODUCTINSTANCE_VERSIONID));
            }
            String oneOffVersionId = getTrimmedStringOrNull(docRoot.getValue(IxbHndHelperConstants.XML_ATTR_ONE_OFF_VERSION_ID));
            if (revId != null && !revId.isEmpty()) {
                versionId.append(revId);
                if (oneOffVersionId != null && !oneOffVersionId.isEmpty()) {
                    versionId.append(WTMessage.getLocalizedMessage(WP_IXB_RESOURCE, wpIxbResource.DASH));
                    versionId.append(oneOffVersionId);
                }
            }
            
            this.revision =  getTrimmedStringOrNull(versionId.toString(), true);
            this.iteration = getTrimmedStringOrNull(docRoot.getValue(IxbHndHelperConstants.XML_ATTR_ITERATION_ID), true);
            this.view = getTrimmedStringOrNull(docRoot.getValue(IxbHndHelperConstants.XML_ATTR_VIEW), true);
            //Some xml files has lifecycle state set in lifecycleState instead of lifecycleinfo/lifecycleState
            String lifecycleStateValue = docRoot.getValue(IxbHndHelperConstants.XML_LIFECYCLE_STATE);
            this.lifecycleState = getTrimmedStringOrNull(
                    (lifecycleStateValue != null) ? lifecycleStateValue : docRoot.getValue(IxbHndHelperConstants.XML_ATTR_LIFECYCLESTATE),
                    true);

            String contName = null;
            String objectContainerPath = docRoot.getValue(IxbHndHelper.XML_ATTR_OBJECT_CONTAINER_PATH);
            // Container path os not exported for some objects
            //     Example: ATO; Option Set
            if (objectContainerPath != null) {
                String[] objectContainerPathSplit = objectContainerPath.split("=");
                if (objectContainerPathSplit.length >= 3) {
                    contName = objectContainerPathSplit[2];
                }
            }
            this.containerName = contName != null ? contName.intern() : null;

            // First attempt org id
            String sOrgID = docRoot.getValue(IxbHndHelper.XML_ATTR_ORGANIZATION_ID);
            if (sOrgID != null) {
                if (sOrgID.indexOf('$') >= 0) {
                    sOrgID = sOrgID.substring(sOrgID.indexOf('$') + 1);
                }
            } else {
                sOrgID = docRoot.getValue(IxbHndHelper.XML_ATTR_ORGANIZATION_NAME);
            }
            this.owningOrg = getTrimmedStringOrNull(sOrgID, true);

            this.richTextDescription = WPIxbHndHelper.convertRichTextDescription(doc, docTypeCache.getTypeIdentifier(fileName));
        }

        /**
         * Gets the trimmed string or null.
         *
         * @param string the string
         * @return the trimmed string or null
         */
        private String getTrimmedStringOrNull(String string) {
            String trimmedString = null;
            if (string != null) {
                trimmedString = string.trim();
                if (trimmedString.isEmpty()) {
                    trimmedString = null;
                }
            }

            return trimmedString;
        }

        /**
         * For the given string passed in, this method returns either null if the string does not contain
         * any non-whitespace characters, or the trimmed string.  The string will be interned as directed by
         * the second parameter.<p>
         *
         * @param string string to process
         * @param bInternString boolean determining if the resulting string should be interned
         *
         * @return trimmed string interned as desired if not empty; null otherwise
         */
        private String getTrimmedStringOrNull(String string, final boolean bInternString) {
           String result = getTrimmedStringOrNull(string);
           if ((result != null) && bInternString)
              return result.intern();
           else
              return result;
        }

        /**
         * Gets the file name.
         *
         * @return the file name
         */
        public String getFileName() {
            return this.fileName;
        }

        /**
         * Gets the object reference.
         *
         * @return the object reference
         */
        public ObjectReference getObjectReference() {
            return this.objRef;
        }

        /**
         * Gets the name.
         *
         * @return the name
         */
        public String getName() {
            return this.name;
        }

        /**
         * Gets the number.
         *
         * @return the number
         */
        public String getNumber() {
            return this.number;
        }

        /**
         * Gets the revision.
         *
         * @return the revision
         */
        public String getRevision() {
            return this.revision;
        }

        /**
         * Gets the iteration.
         *
         * @return the iteration
         */
        public String getIteration() {
            return this.iteration;
        }

        /**
         * Gets the container name.
         *
         * @return the container name
         */
        public String getContainerName() {
            return this.containerName;
        }

        /**
         * Gets the view.
         *
         * @return the view
         */
        public String getView() {
            return this.view;
        }

        /**
         * Gets the life cycle state.
         *
         * @return the life cycle state
         */
        public String getLifeCycleState() {
            return this.lifecycleState;
        }

        /**
         * Gets the owning organization.
         *
         * @return the owning organization
         */
        public String getOwningOrganization() {
            return this.owningOrg;
        }

        /**
         * Gets the rich text description.
         *
         * @return the rich text description
         */
        public IxbElement getRichTextDescription() {
            return this.richTextDescription;
        }

        @Override
        public int hashCode() {
            return this.objRef.hashCode();
        }

        @Override
        public boolean equals(Object obj) {
            boolean isEqual = false;
            if (obj != null && obj instanceof MemoryObject) {
                isEqual = this.objRef.equals( ((MemoryObject)obj).objRef );
            }

            return isEqual;
        }
    }

    /**
     * The Class MemoryLink.
     */
    static protected class MemoryLink {

        /** The file name. */
        private final String fileName;
        /** The parent mem obj. */
        private Set<MemoryObject> parentMemObjs;
        /** The parent link role. */
        private final String parentLinkRole;
        /** The parent role desc. */
        private final LocalizableMessage parentRoleDisplayName;
        /** The child role desc. */
        private final LocalizableMessage childRoleDisplayName;
        /** The child link role. */
        private final String childLinkRole;
        /** The child mem obj. */
        private Set<MemoryObject> childMemObjs;
        /** The type specific attributes. */
        private Map<String, String> typeSpecificAttributes = null;
        private boolean isEmbededLink = false;
        
        
        

        @Override
		public String toString() {
			return "MemoryLink [fileName=" + fileName + ", parentMemObjs=" + parentMemObjs + ", parentLinkRole="
					+ parentLinkRole + ", parentRoleDisplayName=" + parentRoleDisplayName + ", childRoleDisplayName="
					+ childRoleDisplayName + ", childLinkRole=" + childLinkRole + ", childMemObjs=" + childMemObjs
					+ ", typeSpecificAttributes=" + typeSpecificAttributes + ", isEmbededLink=" + isEmbededLink + "]";
		}

		public boolean isEqualsTo(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			MemoryLink other = (MemoryLink) obj;
			if (childLinkRole == null) {
				if (other.childLinkRole != null)
					return false;
			} else if (!childLinkRole.equals(other.childLinkRole))
				return false;
			if (childMemObjs == null) {
				if (other.childMemObjs != null)
					return false;
			} else if (!childMemObjs.equals(other.childMemObjs))
				return false;
			if (childRoleDisplayName == null) {
				if (other.childRoleDisplayName != null)
					return false;
			} else if (!childRoleDisplayName.equals(other.childRoleDisplayName))
				return false;
			if (isEmbededLink != other.isEmbededLink)
				return false;
			if (parentLinkRole == null) {
				if (other.parentLinkRole != null)
					return false;
			} else if (!parentLinkRole.equals(other.parentLinkRole))
				return false;
			if (parentMemObjs == null) {
				if (other.parentMemObjs != null)
					return false;
			} else if (!parentMemObjs.equals(other.parentMemObjs))
				return false;
			if (parentRoleDisplayName == null) {
				if (other.parentRoleDisplayName != null)
					return false;
			} else if (!parentRoleDisplayName.equals(other.parentRoleDisplayName))
				return false;
			if (typeSpecificAttributes == null) {
				if (other.typeSpecificAttributes != null)
					return false;
			} else if (!typeSpecificAttributes.equals(other.typeSpecificAttributes))
				return false;
			return true;
		}

		/**
         * Instantiates a new memory link.
         *
         * @param fileName the file name
         * @param parentMemObj the parent mem obj
         * @param parentLinkRole the parent link role
         * @param parentRoleDesc the parent role desc
         * @param childRoleDesc the child role desc
         * @param childLinkRole the child link role
         * @param childMemObj the child mem obj
         */
        protected MemoryLink(
                String fileName,
                Set<MemoryObject> parentMemObjs,
                String parentLinkRole,
                LocalizableMessage parentRoleDisplayName,
                LocalizableMessage childRoleDisplayName,
                String childLinkRole,
                Set<MemoryObject> childMemObjs,
                boolean isEmbededLink) {
            this.fileName = fileName;
            this.parentMemObjs = parentMemObjs;
            this.parentLinkRole = parentLinkRole;
            this.parentRoleDisplayName = parentRoleDisplayName;
            this.childRoleDisplayName = childRoleDisplayName;
            this.childLinkRole = childLinkRole;
            this.childMemObjs = childMemObjs;
            this.isEmbededLink = isEmbededLink;
        }

		public String getParentLinkRole() {
			return parentLinkRole;
		}

		public String getChildLinkRole() {
			return childLinkRole;
		}

		/**
         * Gets the file name.
         *
         * @return the file name
         */
        public String getFileName() {
            return fileName;
        }

        /**
         * Adds the type specific attribute.
         *
         * @param xmlAttributePath the xml attribute path
         * @param attributeValue the attribute value
         */
        void addTypeSpecificAttribute(String xmlAttributePath, String attributeValue) {
            if (this.typeSpecificAttributes == null) {
                this.typeSpecificAttributes = new HashMap<String, String>();
            }
            this.typeSpecificAttributes.put(xmlAttributePath, attributeValue);
        }

        /**
         * Gets the type specific attribute.
         *
         * @param xmlAttributePath the xml attribute path
         * @return the type specific attribute
         */
        public String getTypeSpecificAttribute(String xmlAttributePath) {
            if (this.typeSpecificAttributes == null) {
                return null;
            } else {
                return this.typeSpecificAttributes.get(xmlAttributePath);
            }
        }

        /**
         * Gets the link role display name for member.
         *
         * @param memObject the mem object
         * @return the link role display name for member
         */
        public LocalizableMessage getLinkRoleDisplayNameForMember(MemoryObject memObject) {
            if (this.parentRoleDisplayName != null && this.parentMemObjs != null && this.parentMemObjs.contains(memObject)) {
                return parentRoleDisplayName;
            } else if (this.childRoleDisplayName != null && this.childMemObjs != null && this.childMemObjs.contains(memObject)) {
                return childRoleDisplayName;
            } else {
                return null;
            }
        }

        /**
         * Gets the member object by role.
         *
         * @param linkRole the link role
         * @return the member object by role
         */
        public Set<MemoryObject> getMemberObjectsByRole(String linkRole) {
            if (this.parentLinkRole.equals(linkRole)) {
                return Collections.unmodifiableSet(this.parentMemObjs);
            } else if (this.childLinkRole.equals(linkRole)) {
                return Collections.unmodifiableSet(this.childMemObjs);
            } else {
                return Collections.emptySet();
            }
        }
        
        public Set<MemoryObject> getParentObjects() {
        	return this.parentMemObjs;
        }
        
        public Set<MemoryObject> getChildObjects() {
        	return this.childMemObjs;
        }

        /**
         * Gets the role by member object.
         *
         * @param memObject the mem object
         * @return the role by member object
         */
        public String getRoleByMemberObject(MemoryObject memObject) {
            if (this.parentMemObjs != null && this.parentMemObjs.contains(memObject)) {
                return this.parentLinkRole;
            } else if (this.childMemObjs != null && this.childMemObjs.contains(memObject)) {
                return this.childLinkRole;
            } else {
                return null;
            }
        }

        /**
         * Gets the other side object.
         *
         * @param memObject the mem object
         * @return the other side object
         */
        public Set<MemoryObject> getOtherSideObjects(MemoryObject memObject) {
            if (this.parentMemObjs != null && this.parentMemObjs.contains(memObject)) {
                return Collections.unmodifiableSet(this.childMemObjs);
            } else if (this.childMemObjs != null && this.childMemObjs.contains(memObject)) {
                return Collections.unmodifiableSet(this.parentMemObjs);
            } else {
                return Collections.emptySet();
            }
        }
    }

    /**
     * The Class AxlEntryInfo.
     */
    protected class AxlEntryInfo {

        /** The file name. */
        private String fileName;
        /** The mfg part mem obj. */
        private Set<MemoryObject> mfgPartMemObjs;
        /** The vendor part mem obj. */
        private Set<MemoryObject> vendorPartMemObjs;
        /** The mfg part source status. */
        private String mfgPartSourceStatus;
        /** The vendor part source status. */
        private String vendorPartSourceStatus;

        /**
         * Instantiates a new axl entry info.
         *
         * @param fileName the file name
         * @param mfgPartMemObj the mfg part mem obj
         * @param vendorPartMemObj the vendor part mem obj
         * @throws WTException the wT exception
         */
        private AxlEntryInfo(String fileName, Set<MemoryObject> mfgPartMemObjs, Set<MemoryObject> vendorPartMemObjs) throws WTException {
            this.fileName = fileName;
            this.mfgPartMemObjs = mfgPartMemObjs;
            this.vendorPartMemObjs = vendorPartMemObjs;

            // TODO AXLEntry XML files should be processed with all other XMLs. It is inefficient to process these after all XMLs have already been processed.
            IxbDocument doc = getMetaDataByFileName(fileName);
            if (doc != null) {
                IxbElement docRoot = doc.getRootElement();
                if (docRoot != null) {
                    this.mfgPartSourceStatus = WPIxbHndHelper.getSourcingStatusKey(docRoot.getValue(WPIxbHndHelper.XML_TAG_MANUFACTURERPARTAXLINFO_AXLPREFERENCE_VALUE));
                    this.vendorPartSourceStatus = WPIxbHndHelper.getSourcingStatusKey(docRoot.getValue(WPIxbHndHelper.XML_TAG_VENDORPARTAXLINFO_AXLPREFERENCE_VALUE));
                }
            }

        }

        /**
         * Gets the file name.
         *
         * @return the file name
         */
        public String getFileName() {
            return fileName;
        }

        /**
         * Gets the mfg part mem obj.
         *
         * @return the mfg part mem obj
         */
        public Set<MemoryObject> getMfgPartMemObjs() {
            return mfgPartMemObjs;
        }

        /**
         * Gets the vendor part mem obj.
         *
         * @return the vendor part mem obj
         */
        public Set<MemoryObject> getVendorPartMemObjs() {
            return vendorPartMemObjs;
        }

        /**
         * Gets the mfg part source status.
         *
         * @return the mfg part source status
         */
        public String getMfgPartSourceStatus() {
            return mfgPartSourceStatus;
        }

        /**
         * Gets the vendor part source status.
         *
         * @return the vendor part source status
         */
        public String getVendorPartSourceStatus() {
            return vendorPartSourceStatus;
        }

        /**
         * Gets the type identifier.
         *
         * @return the type identifier
         * @throws WTException the wT exception
         */
        public TypeIdentifier getTypeIdentifier() throws WTException {
            return WPZipContent.this.getTypeIdentifier(this.fileName);
        }
    }

    /**
     * The Class SubstitutionLink.
     */
    public static class SubstitutionLink {

        /** The file name. */
        private String fileName;
        /** The substitution obj. */
        private MemoryObject substitutionObj;
        /** The link for substitution. */
        private MemoryLink linkForSubstitution;

        /**
         * Instantiates a new substitution link.
         *
         * @param fileName the file name
         * @param subObj the sub obj
         * @param linkForSubstitution the link for substitution
         */
        private SubstitutionLink(String fileName, MemoryObject subObj, MemoryLink linkForSubstitution) {
            this.fileName = fileName;
            this.substitutionObj = subObj;
            this.linkForSubstitution = linkForSubstitution;
        }

        /**
         * Gets the file name.
         *
         * @return the file name
         */
        public String getFileName() {
            return this.fileName;
        }

        /**
         * Gets the substitute.
         *
         * @return the substitute
         */
        public MemoryObject getSubstitute() {
            return this.substitutionObj;
        }

        /**
         * Gets the parent.
         *
         * @return the parent
         */
        public Set<MemoryObject> getParents() {
            return Collections.unmodifiableSet(this.linkForSubstitution.parentMemObjs);
        }

        /**
         * Gets the child.
         *
         * @return the child
         */
        public Set<MemoryObject> getChildren() {
            return Collections.unmodifiableSet(this.linkForSubstitution.childMemObjs);
        }
    }

    private class FetchXML extends SimpleFileVisitor<Path> {

        final private List<Path> xmlFiles = new ArrayList<Path>();
        protected IOException error = null;

        @Override
        public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs)
                throws IOException {
            FileVisitResult result;

            if (dir.getParent() == null) {
                // If the root directory
                result = FileVisitResult.CONTINUE;
            } else if (dir.startsWith(dir.getRoot().resolve(IXBJarWriter.METADATA_DIR_NAME))) {
                // The METADATA folder
                result = FileVisitResult.CONTINUE;
                if (!WPZipContent.this.isImportable) {
                    WPZipContent.this.groupedZipFiles.addToDeleteCache(dir);
                }
            } else {
                result = FileVisitResult.SKIP_SUBTREE;
            }
            return result;
        }

        @Override
        public FileVisitResult visitFile(Path file,
                BasicFileAttributes attrs) throws IOException {
            // The preVisitDirectory method will cause only
            //   only the folder that contains metaData files to be processed

            if (file.getFileName().toString().endsWith(".xml")) {
                xmlFiles.add(file);
            }

            return FileVisitResult.CONTINUE;
        }
    }

    private static class FindManifestFileVisitor extends SimpleFileVisitor<Path> {

        private final String staticManifestFileName;
        private Path staticManifest = null;

        private FindManifestFileVisitor(String manifestFileName) {
            this.staticManifestFileName = manifestFileName;
        }

        @Override
        public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs)
                throws IOException {

            if (this.staticManifestFileName == null) {
                return FileVisitResult.SKIP_SIBLINGS;
            } else if (this.staticManifest == null && dir.getParent() == null) {
                return FileVisitResult.CONTINUE;
            }

            return FileVisitResult.SKIP_SIBLINGS;
        }

        @Override
        public FileVisitResult visitFile(Path file, BasicFileAttributes attrs)
                throws IOException {

            if (this.staticManifestFileName == null) {
                return FileVisitResult.SKIP_SIBLINGS;
            } else if (this.staticManifest != null) {
                return FileVisitResult.SKIP_SIBLINGS;
            } else if (file.getFileName().toString().equals(this.staticManifestFileName)) {
                // Assuming that preVisitDirectory will only visit the root directory
                this.staticManifest = file;
                return FileVisitResult.SKIP_SIBLINGS;
            }

            return FileVisitResult.CONTINUE;
        }
    }

    /**
     * Deletes from jar
     *
     * @param filePathInZip
     */
    public void deleteFromJar(String filePathInZip) throws WTException {
        this.groupedZipFiles.removeFromZip(filePathInZip);
    }
}
