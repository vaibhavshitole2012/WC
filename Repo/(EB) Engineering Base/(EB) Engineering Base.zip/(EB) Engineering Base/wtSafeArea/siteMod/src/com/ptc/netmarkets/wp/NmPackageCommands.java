/* bcwti
 *
 * Copyright (c) 2010 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */
package com.ptc.netmarkets.wp;

import java.beans.PropertyDescriptor;
import java.io.Externalizable;
import java.io.IOException;
import java.io.InvalidClassException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import com.ptc.core.components.forms.*;
import com.ptc.core.components.util.FeedbackMessage;
import com.ptc.core.percolui.AddToCollectionHelper;
import com.ptc.core.ui.resources.ComponentType;
import com.ptc.core.ui.resources.FeedbackType;
import com.ptc.generic.iba.AttributeService;
import com.ptc.netmarkets.model.NmObjectHelper;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import com.ptc.netmarkets.util.beans.NmURLFactoryBean;
import com.ptc.netmarkets.util.misc.NetmarketURL;
import com.ptc.netmarkets.util.misc.NmAction;
import com.ptc.netmarkets.util.misc.NmContextItem;
import com.ptc.windchill.wp.AbstractWorkPackage;
import com.ptc.windchill.wp.AbstractWorkPackageMaster;
import com.ptc.windchill.wp.WPHelper;
import com.ptc.windchill.wp.WorkPackageMasterIdentity;
import com.ptc.windchill.wp.delivery.DeliveryHelper;
import com.ptc.windchill.wp.delivery.DeliveryRecord;
import com.ptc.windchill.wp.delivery.DeliveryService;
import com.ptc.windchill.wp.delivery.deliveryResource;

import wt.facade.persistedcollection.PersistedCollectionHelper;
import wt.facade.persistedcollection.PersistedCollectionRefreshInfo;
import wt.fc.IdentityHelper;
import wt.fc.ObjectReference;
import wt.fc.PersistenceHelper;
import wt.fc.ReferenceFactory;
import wt.fc.WTReference;
import wt.fc.collections.CollectionsHelper;
import wt.fc.collections.WTArrayList;
import wt.fc.collections.WTCollection;
import wt.fc.collections.WTHashSet;
import wt.inf.container.WTContainerRef;
import wt.introspection.ClassInfo;
import wt.log4j.LogR;
import wt.org.WTOrganization;
import wt.org.WTPrincipalReference;
import wt.pom.UniquenessException;
import wt.services.ServiceFactory;
import wt.session.SessionContext;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.WTPropertyVetoException;
import wt.util.WTRuntimeException;
import wt.vc.VersionReference;

// TODO: Auto-generated Javadoc
/**
 * <BR><BR><B>Supported API: </B>false
 * <BR><BR><B>Extendable: </B>false.
 *
 * @version   1.0
 */
public class NmPackageCommands implements Externalizable {

    // --- Attribute Section ---
    /** The Constant RESOURCE. */
    private static final String RESOURCE = "com.ptc.netmarkets.wp.wpResource";
    
    /** The Constant CLASSNAME. */
    private static final String CLASSNAME = NmPackageCommands.class.getName();
    
    /** The Constant serialVersionUID. */
    static final long serialVersionUID = 1;
    
    /** The Constant EXTERNALIZATION_VERSION_UID. */
    public static final long EXTERNALIZATION_VERSION_UID = 957977401221134810L;
    
    /** The Constant DELIVERY_RESOURCE. */
    private static final String DELIVERY_RESOURCE = "com.ptc.windchill.wp.delivery.deliveryResource";
    
    /** The Constant TYPE. */
    public static final String TYPE = "wp";
    
    /** The Constant PACKAGE_LIST. */
    public static final String PACKAGE_LIST = "package$list$";
    
    /** The Constant PACKAGE_COLUMN_STR. */
    public static final String PACKAGE_COLUMN_STR = "1";
    
    /** The Constant DESCRIPTION. */
    public static final String DESCRIPTION = "description";
    
    /** The Constant service. */
    public static final NmPackageService service = ServiceFactory.getService(NmPackageService.class);
    
    /** The Constant logger. */
    private static final Logger logger = LogR.getLogger(NmPackageCommands.class.getName());

    // --- Operation Section ---
    /**
     * Writes the non-transient fields of this class to an external source.
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param output the output
     * @throws IOException Signals that an I/O exception has occurred.
     */
    public void writeExternal(ObjectOutput output)
            throws IOException {
        output.writeLong(EXTERNALIZATION_VERSION_UID);
    }

    /**
     * Reads the non-transient fields of this class from an external source.
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param input the input
     * @throws IOException Signals that an I/O exception has occurred.
     * @throws ClassNotFoundException the class not found exception
     */
    public void readExternal(ObjectInput input)
            throws IOException, ClassNotFoundException {
        long readSerialVersionUID = input.readLong();                // consume UID

        if (readSerialVersionUID != EXTERNALIZATION_VERSION_UID) {
            throw new InvalidClassException(CLASSNAME, "Local class not compatible:"
                    + " stream classdesc externalizationVersionUID=" + readSerialVersionUID
                    + " local class externalizationVersionUID=" + EXTERNALIZATION_VERSION_UID);
        }
    }

    /**
     * <BR><BR><B>Supported API: </B>false.
     *
     * @param cb the cb
     * @return    FormResult
     * @throws WTException the wT exception
     */
    public static FormResult delete(NmCommandBean cb)
            throws WTException {
        FormResult result = getDeleteResult(cb);

        ArrayList<NmOid> pkgOids = cb.getActionOidsWithoutWizard();
        for (NmOid pkgOid : pkgOids) {
            AbstractWorkPackage pkg = (AbstractWorkPackage) pkgOid.getRefObject();
            WPHelper.service.delete(pkg);
        }

        return result;
    }

    /**
     * <BR><BR><B>Supported API: </B>false.
     *
     * @param cb the cb
     * @return    FormResult
     * @throws WTException the wT exception
     */
    public static FormResult sendDeliveries(NmCommandBean cb)
            throws WTException {

        WTHashSet deliveryList = new WTHashSet();
        FormResult formResult = new FormResult();
        try {
            deliveryList = DeliveryCommand.getDeliveries(cb.getActionOidsWithoutWizard());
            formResult = filterInvalidDeliveries(deliveryList, cb);

            if ((deliveryList != null) && (! deliveryList.isEmpty())) {
            DeliveryService deliveryService = DeliveryHelper.getService();
            deliveryService.send(deliveryList);
            }
        } catch (WTException e) {
            return getExceptionResult(e);
        }
        return formResult;
    }

    /**
     * <BR><BR><B>Supported API: </B>false.
     *
     * @param cb the cb
     * @return    FormResult
     * @throws WTException the wT exception
     */
    public static FormResult receiveDeliveries(NmCommandBean cb)
            throws WTException {
        ReceiveDeliveryCommand rc = new ReceiveDeliveryCommand(cb);
        FormResult result = new FormResult();
        String invalidReasonCode = null;
        try {
            invalidReasonCode = rc.execute();
        } catch (WTException e) {
            Throwable t1 = e.getCause();
            if (t1 != null && t1 instanceof WTException) {
                return getExceptionResult((WTException) t1);
            } else {
                return getExceptionResult(e);
            }
        }
        result = getReceiveDeliveriesResult(cb,invalidReasonCode);
        return result;
    }

    /**
     * Adds selected successors to the package.
     *
     * @param cb the cb
     * @return the form result
     * @throws WTException the wT exception
     */
    @SuppressWarnings("deprecation")
    public static FormResult addSuccessors(NmCommandBean cb) throws WTException {
        // get selected in package master Picker

        FormResult result = new FormResult(FormProcessingStatus.SUCCESS);
        result.setNextAction(FormResultAction.REFRESH_OPENER);
        NmOid pkgOid = cb.getPrimaryOid();
        if (pkgOid == null) {
            result = new FormResult(FormProcessingStatus.FAILURE);
            result.setNextAction(FormResultAction.NONE);
            return result;
        }

        AbstractWorkPackage pkg = (AbstractWorkPackage) pkgOid.getRefObject();
        ArrayList<NmOid> pickerList = cb.getNmOidSelected();
        if (pickerList.isEmpty()) {
            result = new FormResult(FormProcessingStatus.FAILURE);
            result.setNextAction(FormResultAction.NONE);
            return result;
        }

        ArrayList<WTReference> refs = new ArrayList<WTReference>(pickerList.size());
        getReferencesFromOids(refs, pickerList);

        ArrayList<ObjectReference> masters = new ArrayList<ObjectReference>();
        for (WTReference ref : refs) {
            ObjectReference master = ((AbstractWorkPackage) ref.getObject()).getMasterReference();
            if (!masters.contains(master)) {
                masters.add(master);
            }
        }

        WPHelper.service.addSuccessors(pkg, refs);

        if (masters.size() < pickerList.size()) {
            Object[] args = new Object[1];
            args[0] = Integer.valueOf(masters.size());
            String message = WTMessage.getLocalizedMessage(RESOURCE, wpResource.SAME_MASTER, args, SessionHelper.getLocale());
            FeedbackMessage msg = new FeedbackMessage(FeedbackType.FAILURE, cb.getLocale(), null, null, message);
            result.addFeedbackMessage(msg);
        }

        return result;
    }

    /**
     * Remove selected successors from the package.
     *
     * @param cb the cb
     * @throws WTException the wT exception
     */
    public static void removeSuccessors(NmCommandBean cb) throws WTException {
        // get selected in package Picker
        NmOid pkgOid = cb.getPrimaryOid();
        if (pkgOid == null) {
            return;
        }

        AbstractWorkPackage pkg = (AbstractWorkPackage) pkgOid.getRefObject();
        ArrayList<NmOid> pickerList = cb.getNmOidSelected();
        if (pickerList.isEmpty()) {
            return;
        }

        ArrayList<WTReference> refs = new ArrayList<WTReference>(pickerList.size());
        getReferencesFromOids(refs, pickerList);
        Collection<WTReference> collMasterReferences = getMasterReferences(refs);

        WPHelper.service.removeSuccessors(pkg, collMasterReferences);
    }

       /**
    * For the passed in collection of references, obtain the references to the associated masters.  The collection
    * of references passed in may be to packages or package masters.<p>
    *
    * @param collReferences collection of package or package master references
    * @return collection of master references from passed in references
    */
   static Collection<WTReference> getMasterReferences(Collection<WTReference> collReferences) {
      assert collReferences != null;

      if (collReferences.isEmpty())
         logger.warn("List of references passed in is empty.");

      Collection<WTReference> setResult = new HashSet<WTReference>(collReferences.size());

      // Load package references into a Windchill list for inflation, or otherwise load master references directly into result
      WTCollection wtlistPackagesOR = new WTArrayList(collReferences.size(), CollectionsHelper.OBJECT_IDENTIFIER);
      WTCollection wtlistPackagesVR = new WTArrayList(collReferences.size(), CollectionsHelper.VERSION_FOREIGN_KEY);
      for (WTReference thisReference : collReferences)
         if (AbstractWorkPackage.isTypeOf(thisReference))
            if (thisReference instanceof VersionReference)
               wtlistPackagesVR.add(thisReference);
            else
               wtlistPackagesOR.add(thisReference);
         else if (AbstractWorkPackageMaster.class.isAssignableFrom(thisReference.getReferencedClass()))
            setResult.add(thisReference);
         else
            logger.warn("Unexpected reference type passed in (...skipping it...): " + thisReference.getReferencedClass().getName());

      // If any, inflate the packages to get the master references
      addPackageMasterReferences(wtlistPackagesOR, setResult);
      addPackageMasterReferences(wtlistPackagesVR, setResult);

      // Load master references into result - converting to list here instead of returning set because
      //    service method this is passed to currently returns bit set dependent on order in passed in collection
      assert setResult != null;
      assert setResult.size() <= collReferences.size();

      return new ArrayList<WTReference>(setResult);
   }


   /**
    * For the passed in Windchill collection of packages, this routines adds the master reference for each into the passed in collection.<p>
    *
    * @param wtcollPackages Windchill collection of packages
    * @param collMasterReferences standard Java collection containing master references
    */
   private static void addPackageMasterReferences(WTCollection wtcollPackages, Collection<WTReference> collMasterReferences) {
      assert wtcollPackages != null;
      assert collMasterReferences != null;

      if (! wtcollPackages.isEmpty()) {
         try {
            wtcollPackages.inflate();
         }
         catch (WTException wtEx) {
            logger.error("Error occurred attempting to process package references.", wtEx);
            throw new WTRuntimeException(wtEx);
         }
         for (Object thisPackage : wtcollPackages.persistableCollection())
            collMasterReferences.add(((AbstractWorkPackage) thisPackage).getMasterReference());
      }
   }


    /**
     * Gets the references from oids.
     *
     * @param refs the refs
     * @param oids the oids
     * @return the references from oids
     * @throws WTException the wT exception
     */
    private static void getReferencesFromOids(List<WTReference> refs, List<NmOid> oids) throws WTException {
        for (NmOid oid : oids) {
            if (oid != null) {
                refs.add(oid.getWtRef());
            }
        }
    }

    /**
     * Filter invalid deliveries.
     *
     * @param deliveryList the delivery list
     * @param cb the cb
     * @return the form result
     * @throws WTException the wT exception
     */
    protected static FormResult filterInvalidDeliveries(WTHashSet deliveryList, NmCommandBean cb)
            throws WTException {
        return filterInvalidDeliveries(deliveryList, SessionHelper.manager.getPrincipalReference(), cb);
    }

    /**
     * Filter invalid deliveries.
     *
     * @param deliveryList the delivery list
     * @param wtPrincipalRef the wt principal ref
     * @param cb the cb
     * @return the form result
     * @throws WTException the wT exception
     */
    protected static FormResult filterInvalidDeliveries(WTHashSet deliveryList, 
             @SuppressWarnings("unused") WTPrincipalReference wtPrincipalRef, NmCommandBean cb) throws WTException {

        int selectedDeliveries = deliveryList.size();
        String invalidDeliveryReason = null;
        FormResult result = new FormResult();
        Iterator it = deliveryList.persistableIterator();
        List<DeliveryRecord> sentDeliveries = new ArrayList<DeliveryRecord>();
        List<DeliveryRecord> deliveriesWithUnlockPkg = new ArrayList<DeliveryRecord>();
        while (it.hasNext()) {
            DeliveryRecord delivery = (DeliveryRecord) it.next();
            boolean isSent = delivery.isSent();
            if (isSent) {
                sentDeliveries.add(delivery);
                it.remove();
            } else if (!DeliveryHelper.isPackageLocked(delivery, true)) {
                deliveriesWithUnlockPkg.add(delivery);
                if (!isSent) {
                    it.remove();

                }
            }
        }
        if ((deliveriesWithUnlockPkg != null && deliveriesWithUnlockPkg.size() > 0) && (sentDeliveries != null && sentDeliveries.size() > 0)) {
             // SENT_UNLOCK will be set only if the package is not locked and it has deliveries which have not been sent.
            invalidDeliveryReason = "SENT_UNLOCK";
            result = getSendDeliveriesResult(cb, invalidDeliveryReason);
        } else if ((sentDeliveries != null && sentDeliveries.size() > 0)) {
            if (sentDeliveries.size() == selectedDeliveries) {
                 // ALL_SENT will be set only if all selected deliveries have not been sent.
                invalidDeliveryReason = "ALL_SENT";
            } else {
                 // PARTIAL_SENT will be set only if some of the selected deliveries have not been sent.
                invalidDeliveryReason = "PARTIAL_SENT";
            }
            result = getSendDeliveriesResult(cb, invalidDeliveryReason);
        } else if ((deliveriesWithUnlockPkg != null && deliveriesWithUnlockPkg.size() > 0)) {
            if (deliveriesWithUnlockPkg.size() == selectedDeliveries) {
                 // ALL_UNLOCK will be set only if all the deliveries are associated with a package which is not locked.
                invalidDeliveryReason = "ALL_UNLOCK";
            } else {
                 // PARTIAL_UNLOCK will be set only if some of the deliveries are associated with a package which is not locked.
                invalidDeliveryReason = "PARTIAL_UNLOCK";
            }
            result = getSendDeliveriesResult(cb, invalidDeliveryReason);
        }else{
            // null reason code will be set only if all the deliveries selected are sent successfully.
             result = getSendDeliveriesResult(cb, null);
        }
        return result;

    }

    /**
     * Change work package identity.
     *
     * @param workPackage the work package
     * @param newName the new name
     * @param newNumber the new number
     * @param newOrg the new org
     * @return the abstract work package
     * @throws WTException the wT exception
     * @throws WTPropertyVetoException the wT property veto exception
     * @throws UniquenessException the uniqueness exception
     */
    public static AbstractWorkPackage changeWorkPackageIdentity(AbstractWorkPackage workPackage, String newName, String newNumber, WTOrganization newOrg)
            throws WTException, WTPropertyVetoException, UniquenessException {
        if (workPackage != null) {
            changeWorkPackageMasterIdentity((AbstractWorkPackageMaster) workPackage.getMaster(), newName, newNumber, newOrg);
            workPackage = (AbstractWorkPackage) PersistenceHelper.manager.refresh(workPackage, true, true);
        }

        return workPackage;
    }

    /**
     * Change work package master identity.
     *
     * @param workPackageMaster the work package master
     * @param newName the new name
     * @param newNumber the new number
     * @param newOrg the new org
     * @return the abstract work package master
     * @throws WTException the wT exception
     * @throws WTPropertyVetoException the wT property veto exception
     * @throws UniquenessException the uniqueness exception
     */
    public static AbstractWorkPackageMaster changeWorkPackageMasterIdentity(AbstractWorkPackageMaster workPackageMaster, String newName, String newNumber, WTOrganization newOrg)
            throws WTException, WTPropertyVetoException, UniquenessException {
        AbstractWorkPackageMaster newPackageMaster = null;
        WorkPackageMasterIdentity newIdentity = (WorkPackageMasterIdentity) workPackageMaster.getIdentificationObject();

        boolean changed = getNewIdentity(workPackageMaster, newIdentity, newName, newNumber, newOrg);

        if (changed == true) {
            newPackageMaster = (AbstractWorkPackageMaster) IdentityHelper.service.changeIdentity(workPackageMaster, newIdentity);

            if (logger.isDebugEnabled()) {
                logger.debug("packageMaster Old Attributes: " + workPackageMaster.getNumber() + "; "
                        + workPackageMaster.getName() + "; "
                        + workPackageMaster.getOrganizationName() + ";");
                logger.debug("packageMaster New Attributes: " + newNumber + "; "
                        + newName + "; "
                        + newOrg.getName() + ";");
            }
        }

        return newPackageMaster;
    }

    /**
     * Gets the new identity.
     *
     * @param workPackageMaster the work package master
     * @param newIdentity the new identity
     * @param newName the new name
     * @param newNumber the new number
     * @param newOrg the new org
     * @return the new identity
     * @throws WTException the wT exception
     * @throws WTPropertyVetoException the wT property veto exception
     */
    protected static boolean getNewIdentity(final AbstractWorkPackageMaster workPackageMaster, WorkPackageMasterIdentity newIdentity, final String newName, final String newNumber, final WTOrganization newOrg)
            throws WTException, WTPropertyVetoException {
        boolean changed = false;

        if (newNumber != null && !newNumber.equals(workPackageMaster.getNumber())) {
            newIdentity.setNumber(newNumber);
            changed = true;
        }

        if (newName != null && !newName.equals(workPackageMaster.getName())) {
            newIdentity.setName(newName);
            changed = true;
        }

        if (newOrg != null) {
            String newOrgName = newOrg.getName();
            if (newOrgName != null && !newOrgName.equals(workPackageMaster.getOrganizationName())) {
                WTPrincipalReference newWTOrgRef = WTPrincipalReference.newWTPrincipalReference(newOrg);
                newIdentity.setOrganizationReference(newWTOrgRef);
                changed = true;
            }
        }

        return changed;
    }

    /**
     * Gets the exception result.
     *
     * @param e the e
     * @return the exception result
     * @throws WTException the wT exception
     */
    @SuppressWarnings("deprecation")
    protected static FormResult getExceptionResult(final WTException e) throws WTException {
        FormResult result = new FormResult(FormProcessingStatus.FAILURE);
        FeedbackMessage message = new FeedbackMessage(FeedbackType.FAILURE, SessionHelper.getLocale(), null, null, e.getLocalizedMessage(SessionHelper.getLocale(), false));
        result.addFeedbackMessage(message);
        result.setNextAction(FormResultAction.NONE);
        return result;
    }

    /**
     * This method will build the FormResult depending on the appropriate reason code associated with invalid /valid deliveries.
     *
     * @param cb the cb
     * @param invalidReasonCode the invalid reason code
     * @return formResult
     * @throws WTException the wT exception
     */
    @SuppressWarnings("deprecation")
    protected static FormResult getSendDeliveriesResult(final NmCommandBean cb, String invalidReasonCode) throws WTException {
        ResourceBundle rb = ResourceBundle.getBundle(DELIVERY_RESOURCE, cb.getLocale());
        String confimMessage = null;

        if (invalidReasonCode != null) {
            // SENT_UNLOCK will be set only of the package is not locked and it has deliveries which have not been sent.
            if (invalidReasonCode.equalsIgnoreCase("SENT_UNLOCK")) {
                confimMessage = rb.getString(deliveryResource.SOME_DELIVERY_ALREADY_SENT_AND_UNLOCKPKG);
            } else if (invalidReasonCode.equalsIgnoreCase("PARTIAL_SENT")) {
                 // PARTIAL_SENT will be set only if some of the selected deliveries have not been sent.
                confimMessage = rb.getString(deliveryResource.SOME_DELIVERY_ALREADY_SENT);
            } else if (invalidReasonCode.equalsIgnoreCase("ALL_SENT")) {
                 // ALL_SENT will be set only if all selected deliveries have not been sent.
                confimMessage = rb.getString(deliveryResource.ALL_DELIVERY_ALREADY_SENT);
            } else if (invalidReasonCode.equalsIgnoreCase("PARTIAL_UNLOCK")) {
                // PARTIAL_UNLOCK will be set only if some of the deliveries are associated with a package which is not locked.
                confimMessage = rb.getString(deliveryResource.PARTIAL_DELIVERY_SENT_FOR_UNLOCKPACKAGE);
            } else if (invalidReasonCode.equalsIgnoreCase("ALL_UNLOCK")) {
                // ALL_UNLOCK will be set only if all of the deliveries are associated with a package which is not locked.
                confimMessage = rb.getString(deliveryResource.ALL_SENDDELIVERY_WITH_UNLOCKPKG);
            }
        } else {
            confimMessage = rb.getString(deliveryResource.SENT_DELIVERY);
        }
        
        final boolean bAtLeastOneDeliverySent = ! ("ALL_UNLOCK".equalsIgnoreCase(invalidReasonCode) || "ALL_SENT".equalsIgnoreCase(invalidReasonCode));
        FeedbackMessage message = new FeedbackMessage(bAtLeastOneDeliverySent ? FeedbackType.SUCCESS : FeedbackType.FAILURE, cb.getLocale(), null, null, confimMessage);

        FormResult result = new FormResult(bAtLeastOneDeliverySent ? FormProcessingStatus.SUCCESS : FormProcessingStatus.FAILURE, FormResultAction.REFRESH_CURRENT_PAGE);
        result.addFeedbackMessage(message);
        return result;
    }

    /**
     * This method will build the FormResult depending on the appropriate reason code after processing for the invalid deliveries.
     *
     * @param cb the cb
     * @param invalidReasonCode the invalid reason code
     * @return the receive deliveries result
     * @throws WTException the wT exception
     */
    @SuppressWarnings("deprecation")
    protected static FormResult getReceiveDeliveriesResult(final NmCommandBean cb, String invalidReasonCode) throws WTException {
        FormResult result = new FormResult(FormProcessingStatus.SUCCESS);
        ResourceBundle rb = ResourceBundle.getBundle(DELIVERY_RESOURCE, cb.getLocale());
        String confimMessage=null;
        if (openedFromExternalLink(cb)) {
            String soid = cb.getTextParameter("soid");
            String url = getRedirectUrlString(soid);
            result.setNextAction(FormResultAction.FORWARD);
            result.setForcedUrl(url);
        } else {
            // We have to refresh the entire page because of the "Deliveries Received" and "Deliveries Accepted" fields above the table...
            result.setNextAction(FormResultAction.REFRESH_OPENER);
        }

        if (invalidReasonCode != null && invalidReasonCode.equalsIgnoreCase("ALL_UNSENT")) {
            // ALL_UNSENT will be set only if all of the deliveries are not sent and hence cannot be received.
            confimMessage = rb.getString(deliveryResource.ALL_DELIVERY_ALREADYRECEIVED_UNDELIVERED);
        }
        else if (invalidReasonCode != null && invalidReasonCode.equalsIgnoreCase("PARTIAL_UNSENT")) {
            // PARTIAL_UNSENT will be set only if some of the deliveries are unsent.
            confimMessage = rb.getString(deliveryResource.SOME_DELIVERY_ALREADYRECEIVED_UNDELIVERED);
        } 
        else if (invalidReasonCode != null && invalidReasonCode.equalsIgnoreCase("ALL_ACCEPTEDPKG")) {
            // ALL_ACCEPTEDPKG will be set only if all of the deliveries are associated with a package whose status is already accepted.
            confimMessage = rb.getString(deliveryResource.ALL_DELIVERY_ALREADYRECEIVED_ACCEPTEDPKG);
        }
        else if (invalidReasonCode != null && invalidReasonCode.equalsIgnoreCase("PARTIAL_ACCEPTEDPKG")) {
            // PARTIAL_ACCEPTEDPKG will be set only if some of the deliveries are associated with a package whose status is already accepted.
            confimMessage = rb.getString(deliveryResource.SOME_DELIVERY_ALREADYRECEIVED_ACCEPTEDPKG);
        } else if (invalidReasonCode != null && invalidReasonCode.equalsIgnoreCase("UNSENT_ACCEPTEDPKG")) {
             // UNSENT_ACCEPTEDPKG will be set only if any of the  deliveries are not sent and if the package associated with the delivery is already accepted.
            confimMessage = rb.getString(deliveryResource.SOME_DELIVERY_UNSENT_ALREADYRECEIVED);

        } else  if (invalidReasonCode != null && invalidReasonCode.equalsIgnoreCase("DELIVERIES_RECEIVED")) {
            confimMessage = rb.getString(deliveryResource.DELIVERIES_RECEIVED);
        }
        FeedbackMessage message = new FeedbackMessage(FeedbackType.SUCCESS, cb.getLocale(), null, null, confimMessage);
        result.addFeedbackMessage(message);
        return result;
    }

    /**
     * Gets the delete result.
     *
     * @param cb the cb
     * @return the delete result
     * @throws WTException the wT exception
     */
    @SuppressWarnings("deprecation")
    protected static FormResult getDeleteResult(final NmCommandBean cb) throws WTException {
        FormResult result = new FormResult(FormProcessingStatus.SUCCESS);
        if (openedFromInfoPage(cb)) {
            NmOid oid = cb.getActionOid();
            WTContainerRef containerRef = oid.getContainerReference();
            ReferenceFactory referenceFactory = new ReferenceFactory();
            String container = referenceFactory.getReferenceString(containerRef);
            String url = getRedirectUrlString(container);
            result.setNextAction(FormResultAction.FORWARD);
            result.setForcedUrl(url);
        } else {
            result.setNextAction(FormResultAction.REFRESH_CURRENT_PAGE);
        }
        return result;
    }

    /**
     * Gets the redirect url string.
     *
     * @param oid the oid
     * @return the redirect url string
     * @throws WTException the wT exception
     */
    protected static String getRedirectUrlString(final String oid) throws WTException {
        String url = null;
        final String type = "object";
        final String action = "view";
        NmURLFactoryBean bean = new NmURLFactoryBean();

        if (oid != null) {
            NmOid oidVal = NmOid.newNmOid(oid);

            HashMap<String, String> parms = new HashMap<String, String>();
            parms.put("oid", oid);
            url = NetmarketURL.buildURL(bean, type, action, oidVal, parms, true);
        } else {
            // Go to the Home page
            NmContextItem ci = new NmContextItem();
            ci.setAction(action);
            ci.setType(NmAction.Type.NETMARKETS);
            url = NetmarketURL.buildURL(bean, ci.getType(), ci.getAction(), null, null, true);

        }

        return url;
    }

    /**
     * Opened from external link.
     *
     * @param cb the cb
     * @return true, if successful
     */
    protected static boolean openedFromExternalLink(final NmCommandBean cb) {
        if ("none".equalsIgnoreCase(cb.getOpenerCompContext())) {
            return true;
        }
        return false;
    }

    /**
     * Opened from info page.
     *
     * @param cb the cb
     * @return true, if successful
     * @throws WTException the wT exception
     */
    protected static boolean openedFromInfoPage(final NmCommandBean cb) throws WTException {
        // If action is coming from info page
        return ComponentType.INFO.name().equals(cb.getTextParameter("componentType"));
        // Alternate implementation:
        //return !cb.getAddedItems().containsKey("netmarkets.package.list") && !cb.getAddedItems().containsKey("netmarkets.relatedPackage.list");
    }

    /**
     * Refreshes a AbstractWorkPackage.
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     *
     * @param cb the cb
     * @return the form result
     * @throws WTException the wT exception
     */
    @SuppressWarnings("deprecation")
    public static FormResult refresh(NmCommandBean cb) throws WTException {
        logger.trace("Entering NmPackageCommands.refresh()...");
        FormResult result = new FormResult(FormProcessingStatus.SUCCESS);
        NmOid oid = cb.getActionOid();
        if (NmOid.isA(oid, AbstractWorkPackage.class)) {
            String message = null;
            FeedbackMessage feedBackMessage = null;
            AbstractWorkPackage wp = (AbstractWorkPackage) oid.getRefObject();
            List<String> foundLanguages = new ArrayList<>();
            String languageAttribute = AttributeService.getAttribute(wp, "KB_PACKAGE_LANGUAGE");
            if(languageAttribute != null) foundLanguages.addAll(Arrays.asList(languageAttribute.split("/")));
            SessionContext.getContext().put("addToPackageProfile", AttributeService.getAttribute(wp, "KB_PACKAGE_PROFILE"));  
            SessionContext.getContext().put("addToPackageLanguages",  foundLanguages); 
            if (PersistedCollectionHelper.isBackgroundRefreshEnabled(wp)) {
                WPHelper.service.refreshInBackground(wp, cb.getLocale());
                message = WTMessage.getLocalizedMessage(RESOURCE, wpResource.REFRESH_PKG_PENDING);
                feedBackMessage = new FeedbackMessage(FeedbackType.SUCCESS, null, message, null);
            } else {
                PersistedCollectionRefreshInfo refreshInfo = WPHelper.service.refresh(wp, cb.getLocale());
                message = AddToCollectionHelper.buildMessage(refreshInfo.getMessages());
                if (message != null && !message.isEmpty())
                    feedBackMessage = new FeedbackMessage(FeedbackType.SUCCESS, null, null, null, message);

            }

            result.setNextAction(FormResultAction.REFRESH_CURRENT_PAGE);
            if (feedBackMessage != null) {
                result.addFeedbackMessage(feedBackMessage);
            }
        } else {
            throw new WTException("Refresh must be acted on an AbstractWorkPackage");
        }

        logger.trace("Exiting NmPackageCommands.refresh()...");
        return result;
    }

    /**
     * List_delete.
     *
     * @param cb the cb
     * @return the form result
     * @throws WTException the wT exception
     */
    @SuppressWarnings("unchecked")
    public static FormResult list_delete(NmCommandBean cb) throws WTException {
        FormResult result = new FormResult();
        //To display event manager UI need to set the delete_background to true
        cb.getMap().put("delete_background", Boolean.TRUE);
        result = NmObjectHelper.service.list__delete(cb, null);
        return result;
    }

    /**
     * validates if the value of the description is less than the database max byte and string value.
     *
     * <BR><BR><B>Supported API: </B>false
     * @param actualvalue the actualvalue
     * @param attrname the attrname
     * @param locale the locale 
     * @return the error message
     * @throws WTException the wT exception
     */
    public static String validateForErrors(String actualvalue,String attrname,Locale locale)
			throws WTException {
	    String message = null;		
		message = getErrorMessage(AbstractWorkPackage.class.getName(), "description", actualvalue,locale);
		
		return message;
	}
    
    /**
     * Checks if the entered value for an attribute is less than the database max byte and string value.
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param className the className
     * @param attributeName the attributeName
     * @param actualValue the actualValue
     * @param locale the locale
     * @return the error message
     * @throws WTException the wT exception
     */
    public static String getErrorMessage(String className, String attributeName, String actualValue,Locale locale) throws WTException {
    	
    	String errorMessage = null;
    	PropertyDescriptor descriptor = wt.introspection.WTIntrospector.getClassInfo(className).getPropertyDescriptor(attributeName);
    	String label = ClassInfo.getPropertyDisplayName(descriptor, locale);
    	int descriptionUpperLimit = ((Integer) descriptor.getValue(wt.introspection.WTIntrospector.UPPER_LIMIT)).intValue();
    	boolean checkStoredLength = PersistenceHelper.checkStoredLength(actualValue, descriptionUpperLimit);
    	if (!checkStoredLength ) {
    		errorMessage = WTMessage.getLocalizedMessage(RESOURCE, wpResource.ATTRIBUTE_VALUE_EXCEEDED, new Object[]{descriptionUpperLimit, label}, locale);
    	}
    	return errorMessage;
    	
    }

}
