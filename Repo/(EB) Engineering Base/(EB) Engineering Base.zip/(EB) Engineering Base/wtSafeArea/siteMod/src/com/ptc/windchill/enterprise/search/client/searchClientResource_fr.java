/* bcwti
 *
 * Copyright (c) 2013 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */
package com.ptc.windchill.enterprise.search.client;

import wt.util.resource.RBComment;
import wt.util.resource.RBEntry;
import wt.util.resource.RBPseudo;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

/**
 * searchResource message resource bundle [English/US]
 */
@RBUUID("com.ptc.windchill.enterprise.search.client.searchClientResource")
public final class searchClientResource_fr extends WTListResourceBundle {
   @RBEntry("Mémoriser la sélection d'objets d'une session à l'autre.")
   @RBComment("Decscription for preference 'remember object selection'.")
   public static final String PRIVATE_CONSTANT_0 = "STICKY_PICKER_SHORT_DESCRIPTION";

   @RBEntry("Mémoriser la sélection d'objets d'une session à l'autre.")
   @RBComment("Decscription for preference 'remember object selection'.")
   public static final String PRIVATE_CONSTANT_1 = "STICKY_PICKER_DESCRIPTION";

   @RBEntry("Mémoriser la sélection d'objets")
   @RBComment("Preference Remember object selection.")
   public static final String PRIVATE_CONSTANT_2 = "STICKY_PICKER";

   @RBEntry("Cette préférence est utilisée pour l'application du contrôle d'accès aux résultats d'une recherche.")
   @RBComment("This preference is used to apply access control on search results.")
   public static final String PRIVATE_CONSTANT_3 = "ACCESS_CONTROL_FLAG_SHORT_DESCRIPTION";

   @RBEntry("Cette préférence est utilisée pour l'application du contrôle d'accès aux résultats d'une recherche.")
   @RBComment("This preference is used to apply access control on search results.")
   public static final String PRIVATE_CONSTANT_4 = "ACCESS_CONTROL_FLAG_DESCRIPTION";

   @RBEntry("Appliquer le contrôle d'accès aux résultats d'une recherche")
   @RBComment("Apply Access Control to Search Results")
   public static final String PRIVATE_CONSTANT_5 = "ACCESS_CONTROL_FLAG";

   @RBEntry("Cette préférence est utilisée pour l'application du contrôle d'accès aux résultats d'une recherche.")
   @RBComment("This preference is used to apply access control on search results.")
   public static final String PRIVATE_CONSTANT_6 = "ACCESS_CONTROL_FLAG_LONGDESCRIPTION";

   @RBEntry("Utilisez le caractère générique * pour élargir la recherche.")
   @RBComment("Wildcard suggestion for keyword field")
   public static final String PRIVATE_CONSTANT_7 = "WILDCARD_SUGGESSTION";

   @RBEntry("Aide")
   @RBComment("Search page help icon tooltip")
   public static final String PRIVATE_CONSTANT_8 = "HELP";

   @RBEntry("Rechercher")
   @RBComment("Label for the page title of the search page.")
   public static final String SEARCH_LABEL = "SEARCH_LABEL";

   @RBEntry("Effacer")
   @RBComment("Label for the clear button .")
   public static final String PRIVATE_CONSTANT_9 = "CLEAR_BUTTON";

   @RBEntry("Rechercher")
   @RBComment("Label for the type property on the search page.")
   public static final String PRIVATE_CONSTANT_10 = "SEARCH_FOR";

   @RBEntry("Préférences")
   @RBComment("Label for the \"Preferences\" link on search page.")
   public static final String PRIVATE_CONSTANT_11 = "PREFERENCES_LNK";

   @RBEntry("Ouvrir les préférences utilisateur")
   @RBComment("Tooltip for the \"Preferences\" link on search page.")
   public static final String PRIVATE_CONSTANT_12 = "PREFERENCES_LNK_TT";

   @RBEntry("Rechercher")
   @RBComment("Label for the \"Show Results\" input field")
   public static final String PRIVATE_CONSTANT_13 = "RANGE_OF_SEARCH_PROPTY";

   @RBEntry("Avec n'importe lequel de ces critères")
   @RBComment("Label for one of the values in the \"Show Results\" pull down list")
   public static final String PRIVATE_CONSTANT_14 = "RANGE_OF_SEARCH_VALUE_OR";

   @RBEntry("Avec l'ensemble de ces critères")
   @RBComment("Label for one of the values in the \"Show Results\" pull down list")
   public static final String PRIVATE_CONSTANT_15 = "RANGE_OF_SEARCH_VALUE_AND";

   @RBEntry("Définir l'étendue de la recherche")
   @RBComment("Label for search scope <HR> separator of the search criteria")
   public static final String PRIVATE_CONSTANT_16 = "SCOPE_SEPARATOR_LABEL";

   @RBEntry("Sélectionner les critères de recherche")
   @RBComment("Label for search criteria <HR> separator of the search criteria")
   public static final String PRIVATE_CONSTANT_17 = "CRITERIA_SEPARATOR_LABEL";

   @RBEntry("Tous les contextes")
   @RBComment("The default element in the container drop down list on search page.")
   public static final String PRIVATE_CONSTANT_18 = "ALL_CONTAINERS";

   @RBEntry("Tous les projets")
   @RBComment("Label for All Projects.")
   public static final String PRIVATE_CONSTANT_19 = "ALL_PROJECTS";

   @RBEntry("Tous les produits")
   @RBComment("Label for All Products.")
   public static final String PRIVATE_CONSTANT_20 = "ALL_PRODUCTS";

   @RBEntry("Toutes les bibliothèques")
   @RBComment("Label for All Libraries.")
   public static final String PRIVATE_CONSTANT_21 = "ALL_LIBRARIES";

   @RBEntry("Aucune relation")
   @RBComment("The default value for relationship on search in network page.")
   public static final String PRIVATE_CONSTANT_22 = "NO_RELATIONS";

   @RBEntry("Contexte")
   @RBComment("Label for the property \"Search In:\" on the search page.")
   public static final String PRIVATE_CONSTANT_23 = "CONTAINER_TYPE_PROPTY";

   @RBEntry("Je suis membre")
   @RBComment("Label for the membership checkbox on the search page")
   public static final String PRIVATE_CONSTANT_24 = "MEMBER_OF_CONTAINER_CHKBX";

   @RBEntry("Dans mon organisation")
   @RBComment("Label for the search only in contexts in my organization checkbox on the search page")
   public static final String PRIVATE_CONSTANT_25 = "SEARCH_IN_USER_ORG_CHKBX";

   @RBEntry("Résultats par page")
   @RBComment("Label for the \"Results Per Page:\" input field")
   public static final String PRIVATE_CONSTANT_26 = "ADHOC_PAGE_COUNT_PROPTY";

   @RBEntry("Recherche de classification")
   @RBComment("Label for the \"Classification Search\" link on search page.")
   public static final String PRIVATE_CONSTANT_27 = "CLASSIFICATION_SEARCH_LNK";

   @RBEntry("Ouvrir la recherche de classification")
   @RBComment("Tooltip for the \"Classification Search\" link on search page.")
   public static final String PRIVATE_CONSTANT_28 = "CLASSIFICATION_SEARCH_LNK_TT";

   @RBEntry("Recherche avancée")
   @RBComment("Label for the page title of the advanced search page.")
   public static final String ADVANCED_SEARCH_LABEL = "ADVANCED_SEARCH_LABEL";

   @RBEntry("Personnaliser...")
   @RBComment("Label for the link to the customize saved search table.")
   public static final String PRIVATE_CONSTANT_29 = "CUSTOMIZE_LINK_LABEL";

   @RBEntry("Personnaliser la liste des recherches enregistrées")
   @RBComment("Tool tip for the link to the customize saved search table.")
   public static final String PRIVATE_CONSTANT_30 = "CUSTOMIZE_LINK_TT";

   @RBEntry("Groupes")
   @RBComment("Label for header of groups table in saved search create clerk.")
   public static final String PRIVATE_CONSTANT_31 = "GROUP_TABLE_HEADER";

   @RBEntry("Ajouter")
   @RBComment("Label for 'Add' action on the Group Access table of saved search create clerk.")
   public static final String PRIVATE_CONSTANT_32 = "ADD_GROUP_LABEL";

   @RBEntry("Ajouter des groupes pour la recherche enregistrée")
   @RBComment("Tool tip for 'Add' action on the Group Access table of saved search create clerk.")
   public static final String PRIVATE_CONSTANT_33 = "ADD_GROUP_TT";

   @RBEntry("Accès au groupe")
   @RBComment("Label for the Group Access Tab in the saved search create clerk.")
   public static final String PRIVATE_CONSTANT_34 = "GROUP_ACCESS_TAB_LABEL";

   @RBEntry("Définir l'accès au groupe pour cette recherche")
   @RBComment("Tool tip for the Group Access Tab in the saved search create clerk.")
   public static final String PRIVATE_CONSTANT_35 = "GROUP_ACCESS_TAB_TT";

   @RBEntry("- Choisir une action -")
   @RBComment("Label for table action dropdown list.")
   public static final String PRIVATE_CONSTANT_36 = "TABLE_ACTION_LIST_PROMPT";

   @RBEntry("Supprimer cette recherche")
   @RBComment("Label for delete action in customize saved search table.")
   public static final String PRIVATE_CONSTANT_37 = "DELETE_LABEL";

   @RBEntry("Afficher")
   @RBComment("Label for show action in customize saved search table.")
   public static final String PRIVATE_CONSTANT_38 = "SHOW_LABEL";

   @RBEntry("Masquer")
   @RBComment("Label for hide action in customize saved search table.")
   public static final String PRIVATE_CONSTANT_39 = "HIDE_LABEL";

   @RBEntry("Recherches enregistrées")
   @RBComment("Label for header of customize saved search table.")
   public static final String PRIVATE_CONSTANT_40 = "CUSTOMIZE_SAVED_SEARCH_TABLE_LABEL";

   @RBEntry("Afficher dans la liste des recherches enregistrées")
   @RBComment("Label for display search check box on saved search create clerk.")
   public static final String PRIVATE_CONSTANT_41 = "DISPLAY_SEARCH_LABEL";

   @RBEntry("Exporter dans un fichier")
   @RBComment("Label for the export button.")
   public static final String PRIVATE_CONSTANT_42 = "EXPORT_TO_FILE_LABEL";

   @RBEntry("Exporter dans un fichier")
   @RBComment("Tool tip for the export button.")
   public static final String PRIVATE_CONSTANT_43 = "EXPORT_TO_FILE_TT";

   @RBEntry("Enregistrer le fichier exporté sous")
   @RBComment("Label for the File name in the export wizard")
   public static final String PRIVATE_CONSTANT_44 = "EXPORT_FILE_SAVE";

   @RBEntry("Format :")
   @RBComment("Label for the File format in the export wizard")
   public static final String PRIVATE_CONSTANT_45 = "EXPORT_FILE_FORMAT";

   @RBEntry("csv")
   @RBComment("Label for csv format to export")
   public static final String PRIVATE_CONSTANT_46 = "EXPORT_FORMAT_CSV";

   @RBEntry("xml")
   @RBComment("Label for xml format to export")
   public static final String PRIVATE_CONSTANT_47 = "EXPORT_FORMAT_XML";

   @RBEntry("Rapport HTML")
   @RBComment("Label for html format to export")
   public static final String PRIVATE_CONSTANT_48 = "EXPORT_FORMAT_HTML";

   @RBEntry("Rapport XLS")
   @RBComment("Label for xls format to export")
   public static final String PRIVATE_CONSTANT_49 = "EXPORT_FORMAT_XLS";

   @RBEntry("xls")
   @RBComment("Label for xls format to SUMA export")
   public static final String PRIVATE_CONSTANT_50 = "EXPORT_FORMAT_SUMA_XLS";

   @RBEntry("Téléchargement du fichier d'exportation...")
   @RBComment("Label for downloading the export file")
   public static final String PRIVATE_CONSTANT_51 = "ACT_LBL_DOWNLOAD";

   @RBEntry("Fermez la fenêtre après avoir terminé.")
   @RBComment("Close window message")
   public static final String PRIVATE_CONSTANT_52 = "ACT_LBL_CLOSE_MSG";

   @RBEntry("Est égal à")
   @RBComment("Label for the operator pulldown on the advanced search, search criteria table")
   public static final String PRIVATE_CONSTANT_53 = "OP_EQ";

   @RBEntry("N'est pas égal à")
   @RBComment("Label for the operator pulldown on the advanced search, search criteria table")
   public static final String PRIVATE_CONSTANT_54 = "OP_NE";

   @RBEntry("Inférieur à")
   @RBComment("Label for the operator pulldown on the advanced search, search criteria table")
   public static final String PRIVATE_CONSTANT_55 = "OP_LT";

   @RBEntry("Inférieur ou égal à")
   @RBComment("Label for the operator pulldown on the advanced search, search criteria table")
   public static final String PRIVATE_CONSTANT_56 = "OP_LE";

   @RBEntry("Supérieur à")
   @RBComment("Label for the operator pulldown on the advanced search, search criteria table")
   public static final String PRIVATE_CONSTANT_57 = "OP_GT";

   @RBEntry("Supérieur ou égal à")
   @RBComment("Label for the operator pulldown on the advanced search, search criteria table")
   public static final String PRIVATE_CONSTANT_58 = "OP_GE";

   @RBEntry("Rechercher les recherches enregistrées à supprimer")
   @RBComment("Label for the \"Administrative Delete\" action for saved searches.")
   public static final String PRIVATE_CONSTANT_59 = "ADMIN_DELETE";

   @RBEntry("Choisir les types d'objets")
   @RBComment("Label for the object type picker on the simple search page.")
   public static final String PRIVATE_CONSTANT_60 = "CHANGE_OBJECT_TYPES";

   @RBEntry("Sélectionner")
   @RBComment("Button to select a saved search and populate criteria")
   public static final String PRIVATE_CONSTANT_61 = "SELECT_BTN";

   @RBEntry("--Sélectionner--")
   @RBComment("Label for the default element for the \"Criteria\" pulldown on the Advanced Search page")
   public static final String PRIVATE_CONSTANT_62 = "SELECT_CRITERION";

   @RBEntry("Fermer")
   @RBComment("Label for an action button that closes a window")
   public static final String PRIVATE_CONSTANT_63 = "CLOSE_BUTTON";

   @RBEntry("Rechercher les recherches enregistrées à supprimer")
   @RBComment("Label for the saved search administrative delete clerk")
   public static final String ADMIN_DELETE_PICKER_LABEL = "ADMIN_DELETE_PICKER_LABEL";

   @RBEntry("Créateur")
   @RBComment("Label for the saved search admin delete picker for created by")
   public static final String PRIVATE_CONSTANT_64 = "ADMIN_DELETE_CREATED_BY_LABEL";

   @RBEntry("Créé le")
   @RBComment("Label for the saved search admin delete picker for created on")
   public static final String PRIVATE_CONSTANT_65 = "ADMIN_DELETE_CREATED_ON_LABEL";

   @RBEntry("Modifié le")
   @RBComment("Label for the saved search admin delete picker for last modified criteria")
   public static final String PRIVATE_CONSTANT_66 = "ADMIN_DELETE_LAST_UPDATED_LABEL";

   @RBEntry("Créé par")
   @RBComment("Label for the saved search customize table \"created by\" column")
   public static final String PRIVATE_CONSTANT_67 = "CREATED_BY_LABEL";

   @RBEntry("Client propriétaire")
   @RBComment("Label for the saved search customize table owningclient (owner) column")
   public static final String PRIVATE_CONSTANT_68 = "QUERY_OWNING_CLIENT";

   @RBEntry("Accès au groupe")
   @RBComment("Label for the saved search customize table group access column")
   public static final String PRIVATE_CONSTANT_69 = "QUERY_GROUP_ACCESS";

   @RBEntry("Etendue")
   @RBComment("Label for the saved search table scope column")
   public static final String PRIVATE_CONSTANT_70 = "SAVED_QUERY_SCOPE";

   @RBEntry("Nom")
   @RBComment("Label for the saved search customize table name column")
   public static final String PRIVATE_CONSTANT_71 = "NAME_LABEL";

   @RBEntry("Afficher")
   @RBComment("Label for the saved search customize table show column")
   public static final String PRIVATE_CONSTANT_72 = "QUERY_SHOW";

   @RBEntry("Tous les types d'objet applicables")
   @RBComment("Label for the type property")
   public static final String PRIVATE_CONSTANT_73 = "ALL_ITEMS";

   @RBEntry("Nom")
   @RBComment("Label for the name attribute")
   public static final String PRIVATE_CONSTANT_74 = "NAME_ATTRIBUTE";

   @RBEntry("Numéro")
   @RBComment("Label for the number attribute")
   public static final String PRIVATE_CONSTANT_75 = "NUMBER_ATTRIBUTE";

   @RBEntry("Modifié le")
   @RBComment("Label for the last modified attribute")
   public static final String PRIVATE_CONSTANT_76 = "LAST_UPDATED_ATTRIBUTE";

   @RBEntry("De")
   @RBComment("Label for the From date attribute")
   public static final String PRIVATE_CONSTANT_77 = "FROM_DATE_ATTRIBUTE";

   @RBEntry("A")
   @RBComment("Label for the To date attribute")
   public static final String PRIVATE_CONSTANT_78 = "TO_DATE_ATTRIBUTE";

   @RBEntry("Créé le")
   @RBComment("Label for the created attribute")
   public static final String PRIVATE_CONSTANT_79 = "CREATED_ATTRIBUTE";

   @RBEntry("Toutes")
   @RBComment("All")
   public static final String PRIVATE_CONSTANT_80 = "VERSION_ALL";

   @RBEntry("Dernière")
   @RBComment("Latest")
   public static final String PRIVATE_CONSTANT_81 = "VERSION_LATEST";

   @RBEntry("Mot-clé")
   @RBComment("Keyword")
   public static final String PRIVATE_CONSTANT_82 = "KEYWORD_LABEL";

   @RBEntry("Recherches enregistrées")
   @RBComment("Saved Searches")
   public static final String PRIVATE_CONSTANT_83 = "SAVED_SEARCH_LABEL";

   @RBEntry("--Sélectionner--")
   @RBComment("-- Select a Search --")
   public static final String PRIVATE_CONSTANT_84 = "SELECT_SEARCH_LABEL";

   @RBEntry("Révision")
   @RBComment("Version")
   public static final String PRIVATE_CONSTANT_85 = "VERSION_LABEL";

   @RBEntry("Sélectionner")
   @RBComment("Select")
   public static final String PRIVATE_CONSTANT_86 = "SELECT_LABEL";

   @RBEntry("Spécifier")
   @RBComment("Specify")
   public static final String PRIVATE_CONSTANT_87 = "SPECIFY_LABEL";

   @RBEntry("Itération")
   @RBComment("Iteration")
   public static final String PRIVATE_CONSTANT_88 = "ITERATION_LABEL";

   @RBEntry("Critères :")
   @RBComment("Criteria")
   public static final String PRIVATE_CONSTANT_89 = "CRITERIA_LABEL";

   /**
    * Picker Related localized values
    **/
   @RBEntry("Nom d'utilisateur")
   @RBComment("User Name")
   public static final String PRIVATE_CONSTANT_90 = "USER_NAME_LABEL";

   @RBEntry("Nom complet")
   @RBComment("Full Name")
   public static final String PRIVATE_CONSTANT_91 = "FULL_NAME_LABEL";

   @RBEntry("E-mail")
   @RBComment("Email")
   public static final String PRIVATE_CONSTANT_92 = "EMAIL_LABEL";

   @RBEntry("Nom de l'organisation")
   @RBComment("Organization Name")
   public static final String PRIVATE_CONSTANT_93 = "ORG_NAME_LABEL";

   @RBEntry("ID d'organisation")
   @RBComment("Organization ID")
   public static final String PRIVATE_CONSTANT_94 = "ORG_ID_LABEL";

   @RBEntry("Nom du groupe")
   @RBComment("Group Name")
   public static final String PRIVATE_CONSTANT_95 = "GROUP_NAME_LABEL";

   @RBEntry("Description")
   @RBComment("Description")
   public static final String PRIVATE_CONSTANT_96 = "DESCRIPTION_LABEL";

   @RBEntry("Nom de contexte")
   @RBComment("Context Name")
   public static final String PRIVATE_CONSTANT_97 = "CONTEXT_NAME_LABEL";

   @RBEntry("Etat")
   @RBComment("State")
   public static final String PRIVATE_CONSTANT_98 = "STATE_LABEL";

   @RBEntry("Contexte")
   @RBComment("Context")
   public static final String PRIVATE_CONSTANT_99 = "CONTEXT_LABEL";

   @RBEntry("Numéro")
   @RBComment("Number")
   public static final String PRIVATE_CONSTANT_100 = "NUMBER_LABEL";

   @RBEntry("Nom du participant")
   @RBComment("Participant Name")
   public static final String PRIVATE_CONSTANT_101 = "PARTICIPANT_NAME_LABEL";

   @RBEntry("Entrez le nom complet de l'utilisateur, le nom du groupe (Groupe Bleu) ou le nom de l'organisation (Organisation XYZ). Séparez les entrées par un point-virgule (;). Vous pouvez utiliser l'astérisque (*) comme caractère de remplacement. Exemple : J* Dupont; Savarin, Jeanne; Groupe Bleu; Organisation *.")
   @RBComment("Principal Picker Help Text")
   public static final String PRIVATE_CONSTANT_102 = "PRINCIPAL_PICKER_HELP_TEXT";

   @RBEntry("Entrez le nom complet de l'utilisateur. Séparez les entrées par un point-virgule. Vous pouvez utiliser l'astérisque (*) comme caractère de remplacement. Exemple : *, Michel; Savarin, Jeanne; J*, Dupont.")
   @RBComment("User Picker Help Text")
   public static final String PRIVATE_CONSTANT_103 = "USER_PICKER_HELP_TEXT";

   @RBEntry("par ex. Marie Savarin; *Savarin; Marie*")
   @RBComment("User Picker Short Help Text")
   public static final String PRIVATE_CONSTANT_104 = "USER_PICKER_SHORT_HELP_TEXT";

   @RBEntry("Entrez le nom de l'utilisateur (Nom d'utilisateur). Séparez les entrées par un point-virgule. Utilisez le signe * pour représenter des caractères. Exemple : Admin*; Michel")
   @RBComment("User Picker User Name Help Text")
   public static final String PRIVATE_CONSTANT_105 = "USER_PICKER_NAME_HELP_TEXT";

   @RBEntry("par ex. Admin*; Michel")
   @RBComment("User Picker User Name Short Help Text")
   public static final String PRIVATE_CONSTANT_106 = "USER_PICKER_NAME_SHORT_HELP_TEXT";

   @RBEntry("Entrez le nom de l'organisation recherchée. Séparez les entrées par un point-virgule. Le caractère générique * peut être utilisé pour représenter des caractères. Exemple : Organisation XYZ; Organisation *; ABC Org*")
   @RBComment("Org Picker Help Text")
   public static final String PRIVATE_CONSTANT_107 = "ORG_PICKER_HELP_TEXT";

   @RBEntry("Entrez le nom du groupe recherché. Séparez les entrées par un point-virgule. Le caractère générique * peut être utilisé pour représenter des caractères. Exemple : Red Group; Groupe *; Yellow * ")
   @RBComment("Group Picker Help Text")
   public static final String PRIVATE_CONSTANT_108 = "GROUP_PICKER_HELP_TEXT";

   @RBEntry("Nom de l'objet")
   @RBComment("Object Name lable comment")
   public static final String PRIVATE_CONSTANT_109 = "ITEM_NAME_LABEL";

   @RBEntry("Version de l'objet")
   @RBComment("Object Version comment")
   public static final String PRIVATE_CONSTANT_110 = "ITEM_VERSION_LABEL";

   @RBEntry("Nº de l'objet")
   @RBComment("Object Number label")
   public static final String PRIVATE_CONSTANT_111 = "ITEM_NUMBER_LABEL";

   @RBEntry("Itération de l'objet")
   @RBComment("Object Iteration label")
   public static final String PRIVATE_CONSTANT_112 = "ITEM_ITERATION_LABEL";

   @RBEntry("Nom du fichier CAO de l'objet")
   @RBComment("Object CAD File Name label")
   public static final String PRIVATE_CONSTANT_113 = "ITEM_CAD_FILE_NAME_LABEL";

   @RBEntry("Etat de l'objet")
   @RBComment("Object State label")
   public static final String PRIVATE_CONSTANT_114 = "ITEM_STATE_LABEL";

   @RBEntry("Contexte de l'objet")
   @RBComment("Object Context Path label")
   public static final String PRIVATE_CONSTANT_115 = "ITEM_CONTEXT_PATH_LABEL";

   @RBEntry("Vue de l'objet")
   @RBComment("Object View label")
   public static final String PRIVATE_CONSTANT_116 = "ITEM_VIEW_LABEL";

   @RBEntry("Créateur de l'objet")
   @RBComment("Object Creator label")
   public static final String PRIVATE_CONSTANT_117 = "ITEM_CREATOR_LABEL";

   @RBEntry("Tous les types de contexte")
   @RBComment("Text to be displayed in case of context picker for all object types")
   public static final String PRIVATE_CONSTANT_118 = "ALL_CONTEXT_ITEMS";

   /**
    * Picker Titles
    **/
   @RBEntry("Rechercher un utilisateur")
   @RBComment("User Picker Title")
   public static final String PRIVATE_CONSTANT_119 = "USER_PICKER_TITLE";

   @RBEntry("Rechercher une organisation")
   @RBComment("Organization Picker Title")
   public static final String PRIVATE_CONSTANT_120 = "ORG_PICKER_TITLE";

   /**
    * Query Builder table column headings
    **/
   @RBEntry("Critères de recherche")
   @RBComment("Search Criteria")
   public static final String QB_TABLE_HEADING_LABEL = "QB_TABLE_HEADING_LABEL";

   @RBEntry("Nom")
   @RBComment("Name")
   public static final String QB_NAME_LABEL = "QB_NAME_LABEL";

   @RBEntry("Opérateur")
   @RBComment("Operator")
   public static final String PRIVATE_CONSTANT_121 = "QB_OPERATOR_LABEL";

   @RBEntry("Valeur")
   @RBComment("Value")
   public static final String PRIVATE_CONSTANT_122 = "QB_VALUE_LABEL";

   @RBEntry("Résultats de la recherche")
   @RBComment("Search Results")
   public static final String PRIVATE_CONSTANT_123 = "SEARCH_RESULTS_TABLE";

   @RBEntry("Votre session a expiré. Renouvelez l'opération.")
   @RBComment("Session Expired")
   public static final String SESSION_EXPIRED_MSG = "SESSION_EXPIRED_MSG";

   @RBEntry("Cette page a expiré et peut provoquer des erreurs dans les résultats de la recherche. Recommencez la recherche.")
   @RBComment("Back Button Clicked before Search")
   public static final String PRIVATE_CONSTANT_124 = "CHECK_BACKBUTTON_CLICKED";

   @RBEntry("Ajouter")
   @RBComment("Add text for attribute menu drop down")
   public static final String PRIVATE_CONSTANT_125 = "ADD_CRITERIA";

   @RBEntry("Effacer")
   @RBComment("Clear criteria link")
   public static final String PRIVATE_CONSTANT_126 = "CLEAR_CRITERIA";

   @RBEntry("Exporter la liste dans un fichier")
   public static final String PRIVATE_CONSTANT_127 = "search.exportSearchResults.description";

   @RBEntry("Exporter la liste dans un fichier")
   public static final String PRIVATE_CONSTANT_128 = "search.exportSearchResults.tooltip";

   @RBEntry("../../com/ptc/core/ui/images/export.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_129 = "search.exportSearchResults.icon";

   @RBEntry("height=300,width=600")
   @RBPseudo(false)
   @RBComment("DO NOT TRANSLATE")
   public static final String PRIVATE_CONSTANT_130 = "search.exportSearchResults.moreurlinfo";

   @RBEntry("Enregistrer cette recherche")
   public static final String PRIVATE_CONSTANT_131 = "search.saveThisSearch.description";

   @RBEntry("Enregistrer cette recherche")
   public static final String PRIVATE_CONSTANT_132 = "search.saveThisSearch.tooltip";

   @RBEntry("Sélectionner")
   public static final String PRIVATE_CONSTANT_133 = "search.selectSearch.description";

   @RBEntry("Rechercher")
   public static final String PRIVATE_CONSTANT_134 = "search.search.description";

   @RBEntry("Enlever")
   public static final String PRIVATE_CONSTANT_135 = "search.remove.description";

   @RBEntry("Enlever")
   public static final String PRIVATE_CONSTANT_136 = "search.remove.tooltip";

   @RBEntry("../../wtcore/images/com/ptc/core/ca/web/misc/delete.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_137 = "search.remove.icon";

   @RBEntry("Rechercher dans le réseau")
   public static final String PRIVATE_CONSTANT_138 = "search.networkSearch.description";

   @RBEntry("Rechercher dans le réseau")
   public static final String PRIVATE_CONSTANT_139 = "search.networkSearch.tooltip";

   @RBEntry("netmarkets/images/search_tbar16.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_140 = "search.networkSearch.icon";

   @RBEntry("Rechercher dans le noeud")
   public static final String PRIVATE_CONSTANT_141 = "search.searchInNode.description";

   @RBEntry("Rechercher dans le noeud")
   public static final String PRIVATE_CONSTANT_142 = "search.searchInNode.tooltip";

   @RBEntry("../../netmarkets/images/search.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_143 = "search.searchInNode.icon";

   @RBEntry("Rechercher les objets associés")
   public static final String PRIVATE_CONSTANT_144 = "search.relatedItemSearch.description";

   @RBEntry("Rechercher les objets associés")
   public static final String PRIVATE_CONSTANT_145 = "search.relatedItemSearch.tooltip";

   @RBEntry("netmarkets/images/related_objects_search.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_146 = "search.relatedItemSearch.icon";

   @RBEntry("Personnaliser...")
   public static final String PRIVATE_CONSTANT_147 = "search.relationPicker.description";

   @RBEntry("Personnaliser...")
   public static final String PRIVATE_CONSTANT_148 = "search.relationPicker.tooltip";

   @RBEntry("Choisir les relations à rechercher")
   public static final String PRIVATE_CONSTANT_149 = "search.relationPicker.title";

   @RBEntry("height=600,width=600")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_150 = "search.relationPicker.moreurlinfo";

   @RBEntry("Sélectionner une ou plusieurs relations à rechercher")
   public static final String PRIVATE_CONSTANT_151 = "search.relationPickerStep.title";

   @RBEntry("Sélectionner les relations à rechercher")
   public static final String PRIVATE_CONSTANT_152 = "search.relationPickerStep.tooltip";

   @RBEntry("Sélectionner les relations")
   public static final String PRIVATE_CONSTANT_153 = "search.relationPickerStep.description";

   @RBEntry("Supprimer cette recherche")
   public static final String PRIVATE_CONSTANT_154 = "SavedQuery.deleteQuery.description";

   @RBEntry("Supprimer cette recherche")
   public static final String PRIVATE_CONSTANT_155 = "SavedQuery.deleteQuery.tooltip";

   @RBEntry("netmarkets/images/delete.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_156 = "SavedQuery.deleteQuery.icon";

   @RBEntry("Afficher")
   public static final String PRIVATE_CONSTANT_157 = "SavedQuery.showQuery.description";

   @RBEntry("Afficher")
   public static final String PRIVATE_CONSTANT_158 = "SavedQuery.showQuery.tooltip";

   @RBEntry("../../wtcore/images/search_show.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_159 = "SavedQuery.showQuery.icon";

   @RBEntry("Masquer")
   public static final String PRIVATE_CONSTANT_160 = "SavedQuery.hideQuery.description";

   @RBEntry("Masquer")
   public static final String PRIVATE_CONSTANT_161 = "SavedQuery.hideQuery.tooltip";

   @RBEntry("../../wtcore/images/search_hide.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_162 = "SavedQuery.hideQuery.icon";

   @RBEntry("Supprimer")
   public static final String PRIVATE_CONSTANT_163 = "SavedQuery.deleteRowQuery.description";

   @RBEntry("Supprimer")
   public static final String PRIVATE_CONSTANT_164 = "SavedQuery.deleteRowQuery.tooltip";

   @RBEntry("../../wtcore/images/com/ptc/core/ca/web/misc/delete.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_165 = "SavedQuery.deleteRowQuery.icon";

   @RBEntry("Afficher")
   public static final String PRIVATE_CONSTANT_166 = "SavedQuery.showRowQuery.description";

   @RBEntry("Afficher")
   public static final String PRIVATE_CONSTANT_167 = "SavedQuery.showRowQuery.tooltip";

   @RBEntry("../../wtcore/images/search_show.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_168 = "SavedQuery.showRowQuery.icon";

   @RBEntry("Masquer")
   public static final String PRIVATE_CONSTANT_169 = "SavedQuery.hideRowQuery.description";

   @RBEntry("Masquer")
   public static final String PRIVATE_CONSTANT_170 = "SavedQuery.hideRowQuery.tooltip";

   @RBEntry("../../wtcore/images/search_hide.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_171 = "SavedQuery.hideRowQuery.icon";

   @RBEntry("Suppression par un administrateur")
   public static final String PRIVATE_CONSTANT_172 = "search.adminDelete.description";

   @RBEntry("Suppression par un administrateur")
   public static final String PRIVATE_CONSTANT_173 = "search.adminDelete.tooltip";

   @RBEntry("../../wtcore/images/search_deletesaved.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_174 = "search.adminDelete.icon";

   /**
    * Entries for simplesearch typepicker "Customize" link.
    * Copied from \wcEnterprise\EnterpriseUI\src\com\ptc\windchill\enterprise\picker\type\typePickerResource.rbInfo
    **/
   @RBEntry("Ajouter/mettre à jour...")
   @RBComment("Used as the label for the find action for a SimpleSearch page Type Picker.")
   public static final String PRIVATE_CONSTANT_175 = "search.typePicker.description";

   @RBEntry("Rechercher le type")
   @RBComment("Used as the title for the find action pop-up wizard for a Type Picker.")
   public static final String PRIVATE_CONSTANT_176 = "search.typePicker.title";

   @RBEntry("height=600,width=500")
   @RBPseudo(false)
   @RBComment("DO NOT TRANSLATE")
   public static final String PRIVATE_CONSTANT_177 = "search.typePicker.moreurlinfo";

   /**
    * Entries for simplesearch newtypepicker "Customize" link.
    * Copied from \wcEnterprise\EnterpriseUI\src\com\ptc\windchill\enterprise\picker\type\typePickerResource.rbInfo
    **/
   @RBEntry("Ajouter/mettre à jour...")
   @RBComment("Used as the label for the find action for a SimpleSearch page Type Picker.")
   public static final String PRIVATE_CONSTANT_178 = "search.newtypePicker.description";

   @RBEntry("Rechercher le type")
   @RBComment("Used as the title for the find action pop-up wizard for a Type Picker.")
   public static final String PRIVATE_CONSTANT_179 = "search.newtypePicker.title";

   @RBEntry("height=600,width=375")
   @RBPseudo(false)
   @RBComment("DO NOT TRANSLATE")
   public static final String PRIVATE_CONSTANT_180 = "search.newtypePicker.moreurlinfo";

   @RBEntry("Liste complète des résultats")
   @RBComment("Full Result List option in the picker dropdown")
   public static final String FULL_RESULT_LIST = "FULL_RESULT_LIST";

   @RBEntry("Suppression par un administrateur")
   public static final String PRIVATE_CONSTANT_181 = "SavedQuery.finalDelete.description";

   @RBEntry("Suppression par un administrateur")
   public static final String PRIVATE_CONSTANT_182 = "SavedQuery.finalDelete.tooltip";

   @RBEntry("netmarkets/images/delete.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_183 = "SavedQuery.finalDelete.icon";

   @RBEntry("isAdminDelete=true")
   @RBPseudo(false)
   @RBComment("DO NOT TRANSLATE")
   public static final String PRIVATE_CONSTANT_184 = "SavedQuery.finalDelete.moreurlinfo";

   @RBEntry("Exporter")
   public static final String PRIVATE_CONSTANT_185 = "SavedQuery.savedQueryExport.description";

   @RBEntry("netmarkets/images/export.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_186 = "SavedQuery.savedQueryExport.icon";

   @RBEntry("Exporter les requêtes enregistrées")
   public static final String PRIVATE_CONSTANT_187 = "SavedQuery.savedQueryExport.title";

   @RBEntry("Exporter les recherches enregistrées")
   public static final String PRIVATE_CONSTANT_188 = "SavedQuery.savedQueryExport.tooltip";

   @RBEntry("height=300,width=500")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_189 = "SavedQuery.savedQueryExport.moreurlinfo";

   @RBEntry("Importer")
   public static final String PRIVATE_CONSTANT_190 = "SavedQuery.savedQueryImport.description";

   @RBEntry("netmarkets/images/import.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_191 = "SavedQuery.savedQueryImport.icon";

   @RBEntry("Importer les requêtes enregistrées")
   public static final String PRIVATE_CONSTANT_192 = "SavedQuery.savedQueryImport.title";

   @RBEntry("Importer les recherches enregistrées")
   public static final String PRIVATE_CONSTANT_193 = "SavedQuery.savedQueryImport.tooltip";

   @RBEntry("height=300,width=500")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_194 = "SavedQuery.savedQueryImport.moreurlinfo";

   @RBEntry("Importer")
   public static final String PRIVATE_CONSTANT_195 = "search.import.description";

   @RBEntry("Importer les recherches enregistrées")
   public static final String PRIVATE_CONSTANT_196 = "search.import.title";

   @RBEntry("Importer")
   public static final String PRIVATE_CONSTANT_197 = "search.import_step.description";

   @RBEntry("Importer les recherches enregistrées")
   public static final String PRIVATE_CONSTANT_198 = "search.import_step.title";

   @RBEntry("OK")
   public static final String PRIVATE_CONSTANT_199 = "search.typeChange.description";

   @RBEntry("Effacer tout")
   public static final String PRIVATE_CONSTANT_200 = "search.clearSearch.description";

   @RBEntry("Rechercher...")
   public static final String PRIVATE_CONSTANT_201 = "search.callSearchPicker.description";

   @RBEntry("Rechercher...")
   public static final String PRIVATE_CONSTANT_202 = "search.callSearchPicker.tooltip";

   @RBEntry("height=768,width=550")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_203 = "search.callSearchPicker.moreurlinfo";

   @RBEntry("Ajouter des groupes")
   public static final String PRIVATE_CONSTANT_204 = "search.callSavedSearchGroupPicker.description";

   @RBEntry("Ajouter des groupes")
   public static final String PRIVATE_CONSTANT_205 = "search.callSavedSearchGroupPicker.title";

   @RBEntry("Ajouter des groupes")
   public static final String PRIVATE_CONSTANT_206 = "search.callSavedSearchGroupPicker.tooltip";

   @RBEntry("height=550,width=400")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_207 = "search.callSavedSearchGroupPicker.moreurlinfo";

   @RBEntry("netmarkets/images/add16x16.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_208 = "search.callSavedSearchGroupPicker.icon";

   @RBEntry("Enlever des groupes")
   public static final String PRIVATE_CONSTANT_209 = "search.removeSavedSearchGroups.description";

   @RBEntry("Enlever des groupes")
   public static final String PRIVATE_CONSTANT_210 = "search.removeSavedSearchGroups.title";

   @RBEntry("Enlever des groupes")
   public static final String PRIVATE_CONSTANT_211 = "search.removeSavedSearchGroups.tooltip";

   @RBEntry("netmarkets/images/remove16x16.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_212 = "search.removeSavedSearchGroups.icon";

   @RBEntry("Options avancées")
   public static final String PRIVATE_CONSTANT_213 = "search.saveThisSearchNew.description";

   @RBEntry("Options avancées")
   public static final String PRIVATE_CONSTANT_214 = "search.saveThisSearchNew.tooltip";

   @RBEntry("Options avancées")
   public static final String PRIVATE_CONSTANT_215 = "search.saveThisSearchNew.title";

   @RBEntry("Définir le nom de la recherche enregistrée")
   public static final String PRIVATE_CONSTANT_216 = "search.saveThisSearch_saveName.description";

   @RBEntry("Définir le nom de la recherche enregistrée")
   public static final String PRIVATE_CONSTANT_217 = "search.saveThisSearch_saveName.tooltip";

   @RBEntry("Détails")
   public static final String PRIVATE_CONSTANT_218 = "search.saveThisSearch_saveName.title";

   @RBEntry("Définir les attributs obligatoires")
   public static final String PRIVATE_CONSTANT_219 = "search.saveThisSearch_saveRequired.description";

   @RBEntry("Définir les attributs obligatoires")
   public static final String PRIVATE_CONSTANT_220 = "search.saveThisSearch_saveRequired.tooltip";

   @RBEntry("Définir les attributs obligatoires")
   public static final String PRIVATE_CONSTANT_221 = "search.saveThisSearch_saveRequired.title";

   @RBEntry("Définir le tableau")
   public static final String PRIVATE_CONSTANT_222 = "search.saveThisSearch_saveTableView.description";

   @RBEntry("Définir le tableau")
   public static final String PRIVATE_CONSTANT_223 = "search.saveThisSearch_saveTableView.tooltip";

   @RBEntry("Définir le tableau")
   public static final String PRIVATE_CONSTANT_224 = "search.saveThisSearch_saveTableView.title";

   @RBEntry("Définir l'accès au groupe ")
   public static final String PRIVATE_CONSTANT_225 = "search.saveThisSearch_saveAccess.description";

   @RBEntry("Définir l'accès au groupe ")
   public static final String PRIVATE_CONSTANT_226 = "search.saveThisSearch_saveAccess.tooltip";

   @RBEntry("Définir l'accès au groupe ")
   public static final String PRIVATE_CONSTANT_227 = "search.saveThisSearch_saveAccess.title";

   /**
    * Saved Search related fields
    **/
   @RBEntry("Nom")
   @RBComment("Search Name")
   public static final String PRIVATE_CONSTANT_228 = "SAVED_SEARCH_NAME";

   @RBEntry("Afficher dans la liste des recherches enregistrées")
   @RBComment("Show in Saved Search list")
   public static final String PRIVATE_CONSTANT_229 = "SAVED_SEARCH_SHOW";

   @RBEntry("Entrer un nom")
   @RBComment("Please enter Name")
   public static final String PRIVATE_CONSTANT_230 = "PLEASE_ENTER_NAME";

   @RBEntry("Créer tableau")
   @RBComment("Create Table View")
   public static final String PRIVATE_CONSTANT_231 = "SAVED_SEARCH_CREATE_VIEW";

   @RBEntry("Tableau")
   @RBComment("Use Existing Table View")
   public static final String PRIVATE_CONSTANT_232 = "SAVED_SEARCH_EXISTING_VIEW";

   @RBEntry("- Sélectionner une vue -")
   @RBComment("- Pick a View -")
   public static final String PRIVATE_CONSTANT_233 = "PICK_VIEW";

   @RBEntry("Attributs disponibles :")
   @RBComment("Available Attributes:")
   public static final String PRIVATE_CONSTANT_234 = "AVAILABLE_ATTRIBUTES";

   @RBEntry("Attributs obligatoires :")
   @RBComment("Required Attributes:")
   public static final String PRIVATE_CONSTANT_235 = "REQUIRED_ATTRIBUTES";

   @RBEntry("Ajouter")
   @RBComment("Add")
   public static final String PRIVATE_CONSTANT_236 = "ADD_ATTRIBUTE";

   @RBEntry("Enlever")
   @RBComment("Remove")
   public static final String PRIVATE_CONSTANT_237 = "REMOVE_ATTRIBUTE";

   @RBEntry("Vue de document CAO par défaut")
   @RBComment("Default CAD Document View")
   public static final String PRIVATE_CONSTANT_238 = "CADDOC_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de document EPM par défaut")
   @RBComment("Default EPM Document Search Table View")
   public static final String PRIVATE_CONSTANT_239 = "CADDOC_TABLEVIEW_DESC";

   @RBEntry("Document EPM")
   @RBComment("EPM Document")
   public static final String PRIVATE_CONSTANT_240 = "CADDOC_TABLEVIEW_LABEL";

   @RBEntry("Vue d'article par défaut")
   @RBComment("Default Part View")
   public static final String PRIVATE_CONSTANT_241 = "WTPART_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche d'article par défaut")
   @RBComment("Default Part Search Table View")
   public static final String PRIVATE_CONSTANT_242 = "WTPART_TABLEVIEW_DESC";

   @RBEntry("Article")
   @RBComment("Part ")
   public static final String PRIVATE_CONSTANT_243 = "WTPART_TABLEVIEW_LABEL";

   @RBEntry("Vue de document par défaut")
   @RBComment("Default Document View")
   public static final String PRIVATE_CONSTANT_244 = "WTDOCUMENT_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de document par défaut")
   @RBComment("Default Document Search Table View")
   public static final String PRIVATE_CONSTANT_245 = "WTDOCUMENT_TABLEVIEW_DESC";

   @RBEntry("Document")
   @RBComment("Document")
   public static final String PRIVATE_CONSTANT_246 = "WTDOCUMENT_TABLEVIEW_LABEL";

   @RBEntry("Vue de jeu de travail par défaut")
   @RBComment("Default Work Set View")
   public static final String PRIVATE_CONSTANT_247 = "WTWORKSET_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de jeu de travail par défaut")
   @RBComment("Default Work Set Search Table View")
   public static final String PRIVATE_CONSTANT_248 = "WTWORKSET_TABLEVIEW_DESC";

   @RBEntry("Jeu de travail")
   @RBComment("Work Set")
   public static final String PRIVATE_CONSTANT_249 = "WTWORKSET_TABLEVIEW_LABEL";

   @RBEntry("Vue d'archive par défaut")
   @RBComment("Default Archive View")
   public static final String PRIVATE_CONSTANT_250 = "ARCHIVE_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche d'archive par défaut")
   @RBComment("Default Archive Search Table View")
   public static final String PRIVATE_CONSTANT_251 = "ARCHIVE_TABLEVIEW_DESC";

   @RBEntry("Archive")
   @RBComment("Archive")
   public static final String PRIVATE_CONSTANT_252 = "ARCHIVE_TABLEVIEW_LABEL";

   @RBEntry("Vue d'avis de modification par défaut")
   @RBComment("Default Change Notice View")
   public static final String PRIVATE_CONSTANT_253 = "CHANGENOTICE_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche d'avis de modification par défaut")
   @RBComment("Default Change Notice Search Table View")
   public static final String PRIVATE_CONSTANT_254 = "CHANGENOTICE_TABLEVIEW_DESC";

   @RBEntry("Avis de modification")
   @RBComment("Change Notice")
   public static final String PRIVATE_CONSTANT_255 = "CHANGENOTICE_TABLEVIEW_LABEL";

   @RBEntry("Vue de demande de modification par défaut")
   @RBComment("Default Change Request View")
   public static final String PRIVATE_CONSTANT_256 = "CHANGEREQUEST_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de demande de modification par défaut")
   @RBComment("Default Change Request Search Table View")
   public static final String PRIVATE_CONSTANT_257 = "CHANGEREQUEST_TABLEVIEW_DESC";

   @RBEntry("Demande de modification")
   @RBComment("Change Request")
   public static final String PRIVATE_CONSTANT_258 = "CHANGEREQUEST_TABLEVIEW_LABEL";

   @RBEntry("Vue de directive de modification par défaut")
   @RBComment("Default Change Directive View")
   public static final String PRIVATE_CONSTANT_259 = "CHANGEDIRECTIVE_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de directive de modification par défaut")
   @RBComment("Default Change Directive Search Table View")
   public static final String PRIVATE_CONSTANT_260 = "CHANGEDIRECTIVE_TABLEVIEW_DESC";

   @RBEntry("Directive de modification")
   @RBComment("Change Directive")
   public static final String PRIVATE_CONSTANT_261 = "CHANGEDIRECTIVE_TABLEVIEW_LABEL";

   @RBEntry("Vue de rapport de problème par défaut")
   @RBComment("Default Problem Report View")
   public static final String PRIVATE_CONSTANT_262 = "WTCHANGEISSUE_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de rapport de problème par défaut")
   @RBComment("Default Problem Report Search Table View")
   public static final String PRIVATE_CONSTANT_263 = "WTCHANGEISSUE_TABLEVIEW_DESC";

   @RBEntry("Rapport de problème")
   @RBComment("Problem Report")
   public static final String PRIVATE_CONSTANT_264 = "WTCHANGEISSUE_TABLEVIEW_LABEL";

   @RBEntry("Vue de livrable par défaut")
   @RBComment("Default Deliverable View")
   public static final String PRIVATE_CONSTANT_265 = "DELIVERABLE_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de livrable par défaut")
   @RBComment("Default Deliverable Search Table View")
   public static final String PRIVATE_CONSTANT_266 = "DELIVERABLE_TABLEVIEW_DESC";

   @RBEntry("Livrable")
   @RBComment("Deliverable")
   public static final String PRIVATE_CONSTANT_267 = "DELIVERABLE_TABLEVIEW_LABEL";

   @RBEntry("Vue de fabricant par défaut")
   @RBComment("Default Manufacturer View")
   public static final String PRIVATE_CONSTANT_268 = "MANUFACTURER_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de fabricant par défaut")
   @RBComment("Default Manufacturer Search Table View")
   public static final String PRIVATE_CONSTANT_269 = "MANUFACTURER_TABLEVIEW_DESC";

   @RBEntry("Fabricant")
   @RBComment("Manufacturer")
   public static final String PRIVATE_CONSTANT_270 = "MANUFACTURER_TABLEVIEW_LABEL";

   @RBEntry("Vue des organisations par défaut")
   @RBComment("Default Organization View")
   public static final String PRIVATE_CONSTANT_271 = "ORGNIZATION_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche des organisations par défaut")
   @RBComment("Default Organization Search Table View")
   public static final String PRIVATE_CONSTANT_272 = "ORGNIZATION_TABLEVIEW_DESC";

   @RBEntry("Organisation")
   @RBComment("Organization")
   public static final String PRIVATE_CONSTANT_273 = "ORGNIZATION_TABLEVIEW_LABEL";

   @RBEntry("Vue du projet par défaut")
   @RBComment("Default Project View")
   public static final String PRIVATE_CONSTANT_274 = "PROJECT2_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche des projets par défaut")
   @RBComment("Default Project Search Table View")
   public static final String PRIVATE_CONSTANT_275 = "PROJECT2_TABLEVIEW_DESC";

   @RBEntry("Projet")
   @RBComment("Project")
   public static final String PRIVATE_CONSTANT_276 = "PROJECT2_TABLEVIEW_LABEL";

   @RBEntry("Vue de configuration d'article par défaut")
   @RBComment("Default Part Configuration View")
   public static final String PRIVATE_CONSTANT_277 = "PARTCONFIGURATION_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de configuration d'article par défaut")
   @RBComment("Default Part Configuration Search Table View")
   public static final String PRIVATE_CONSTANT_278 = "PARTCONFIGURATION_TABLEVIEW_DESC";

   @RBEntry("Configuration de l'article")
   @RBComment("Part Configuration")
   public static final String PRIVATE_CONSTANT_279 = "PARTCONFIGURATION_TABLEVIEW_LABEL";

   @RBEntry("Vue d'instance d'article par défaut")
   @RBComment("Default Part Instance View")
   public static final String PRIVATE_CONSTANT_280 = "PARTINSTANCE_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche d'instance par défaut")
   @RBComment("Default Part Instance Search Table View")
   public static final String PRIVATE_CONSTANT_281 = "PARTINSTANCE_TABLEVIEW_DESC";

   @RBEntry("Instance d'article")
   @RBComment("Part Instance")
   public static final String PRIVATE_CONSTANT_282 = "PARTINSTANCE_TABLEVIEW_LABEL";

   @RBEntry("Vue de vendeur par défaut")
   @RBComment("Default Vendor View")
   public static final String PRIVATE_CONSTANT_283 = "VENDOR_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de vendeur par défaut")
   @RBComment("Default Vendor Search Table View")
   public static final String PRIVATE_CONSTANT_284 = "VENDOR_TABLEVIEW_DESC";

   @RBEntry("Vendeur")
   @RBComment("Vendor")
   public static final String PRIVATE_CONSTANT_285 = "VENDOR_TABLEVIEW_LABEL";

   @RBEntry("Vue de collection gérée par défaut")
   @RBComment("Default Managed Collection View")
   public static final String PRIVATE_CONSTANT_286 = "MANAGEDCOLLECTION_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de collection gérée par défaut")
   @RBComment("Default Managed Collection Search Table View")
   public static final String PRIVATE_CONSTANT_287 = "MANAGEDCOLLECTION_TABLEVIEW_DESC";

   @RBEntry("Collection gérée")
   @RBComment("Managed Collection")
   public static final String PRIVATE_CONSTANT_288 = "MANAGEDCOLLECTION_TABLEVIEW_LABEL";

   @RBEntry("Modifié par")
   @RBComment("Modified By")
   public static final String MC_MODIFIED_BY = "MC_MODIFIED_BY";

   @RBEntry("Vue de lot par défaut")
   @RBComment("Default Package View")
   public static final String PRIVATE_CONSTANT_289 = "WORKPACKAGE_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de lot par défaut")
   @RBComment("Default Package Search Table View")
   public static final String PRIVATE_CONSTANT_290 = "WORKPACKAGE_TABLEVIEW_DESC";

   @RBEntry("Lot")
   @RBComment("Package")
   public static final String PRIVATE_CONSTANT_291 = "WORKPACKAGE_TABLEVIEW_LABEL";

   /** The Constant LOCKED_ATTR_TABLE_LABEL. */
   @RBEntry("Statut de verrouillage")
   public static final String LOCKED_ATTR_TABLE_LABEL = "LOCKED_ATTR_TABLE_LABEL";

   @RBEntry("Vue de demande d'article par défaut")
   @RBComment("Default Part Request View")
   public static final String PRIVATE_CONSTANT_292 = "WTPARTREQUEST_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de demande d'article par défaut")
   @RBComment("Default Part Request Search Table View")
   public static final String PRIVATE_CONSTANT_293 = "WTPARTREQUEST_TABLEVIEW_DESC";

   @RBEntry("Demande d'article")
   @RBComment("Part Request")
   public static final String PRIVATE_CONSTANT_294 = "WTPARTREQUEST_TABLEVIEW_LABEL";

   @RBEntry("Vue de variation par défaut")
   @RBComment("Default Variance View")
   public static final String PRIVATE_CONSTANT_295 = "WTVARIANCE_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de variation par défaut")
   @RBComment("Default Variance Search Table View")
   public static final String PRIVATE_CONSTANT_296 = "WTVARIANCE_TABLEVIEW_DESC";

   @RBEntry("Variation")
   @RBComment("Variance")
   public static final String PRIVATE_CONSTANT_297 = "WTVARIANCE_TABLEVIEW_LABEL";

   @RBEntry("Vue de spécification de variante par défaut")
   @RBComment("Default Variant Spec View")
   public static final String PRIVATE_CONSTANT_298 = "VARIANTSPEC_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de spécification de variante par défaut")
   @RBComment("Default Variant Spec Search Table View")
   public static final String PRIVATE_CONSTANT_299 = "VARIANTSPEC_TABLEVIEW_DESC";

   @RBEntry("Spécification de variante")
   @RBComment("Variant Spec")
   public static final String PRIVATE_CONSTANT_300 = "VARIANTSPEC_TABLEVIEW_LABEL";

   @RBEntry("Vue d'utilisateur par défaut")
   @RBComment("Default User View")
   public static final String PRIVATE_CONSTANT_301 = "WTUSER_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche d'utilisateur par défaut")
   @RBComment("Default User Search Table View")
   public static final String PRIVATE_CONSTANT_302 = "WTUSER_TABLEVIEW_DESC";

   @RBEntry("Utilisateur")
   @RBComment("User")
   public static final String PRIVATE_CONSTANT_303 = "WTUSER_TABLEVIEW_LABEL";

   @RBEntry("Vue d'action par défaut")
   @RBComment("Default Action Item View")
   public static final String PRIVATE_CONSTANT_304 = "DISCRETEACTIONITEM_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche d'action par défaut")
   @RBComment("Default Action Item Search Table View")
   public static final String PRIVATE_CONSTANT_305 = "DISCRETEACTIONITEM_TABLEVIEW_DESC";

   @RBEntry("Action")
   @RBComment("Action Item")
   public static final String PRIVATE_CONSTANT_306 = "DISCRETEACTIONITEM_TABLEVIEW_LABEL";

   @RBEntry("Vue de document EPM maître par défaut")
   @RBComment("Default EPM Document Master View")
   public static final String PRIVATE_CONSTANT_307 = "EPMDOCUMENTMASTER_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de document EPM maître par défaut")
   @RBComment("Default EPM Document Master Search Table View")
   public static final String PRIVATE_CONSTANT_308 = "EPMDOCUMENTMASTER_TABLEVIEW_DESC";

   @RBEntry("Document EPM maître")
   @RBComment("EPM Document Master")
   public static final String PRIVATE_CONSTANT_309 = "EPMDOCUMENTMASTER_TABLEVIEW_LABEL";

   @RBEntry("Vue de document maître par défaut")
   @RBComment("Default Document Master View")
   public static final String PRIVATE_CONSTANT_310 = "WTDOCUMENTMASTER_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de document maître par défaut")
   @RBComment("Default Document Master Search Table View")
   public static final String PRIVATE_CONSTANT_311 = "WTDOCUMENTMASTER_TABLEVIEW_DESC";

   @RBEntry("Document maître")
   @RBComment("Document Master")
   public static final String PRIVATE_CONSTANT_312 = "WTDOCUMENTMASTER_TABLEVIEW_LABEL";

   @RBEntry("Vue d'article maître par défaut")
   @RBComment("Default Part Master View")
   public static final String PRIVATE_CONSTANT_313 = "WTPARTMASTER_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche d'article maître par défaut")
   @RBComment("Default Part Master Search Table View")
   public static final String PRIVATE_CONSTANT_314 = "WTPARTMASTER_TABLEVIEW_DESC";

   @RBEntry("Article maître")
   @RBComment("Part Master")
   public static final String PRIVATE_CONSTANT_315 = "WTPARTMASTER_TABLEVIEW_LABEL";

   @RBEntry("Vue de format par défaut")
   @RBComment("Default Format View")
   public static final String PRIVATE_CONSTANT_316 = "FORMAT_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de format par défaut")
   @RBComment("Default Format Search Table View")
   public static final String PRIVATE_CONSTANT_317 = "FORMAT_TABLEVIEW_DESC";

   @RBEntry("Format")
   @RBComment("Format")
   public static final String PRIVATE_CONSTANT_318 = "FORMAT_TABLEVIEW_LABEL";

   @RBEntry("Vue Groupe par défaut")
   @RBComment("Default Group View")
   public static final String PRIVATE_CONSTANT_319 = "GROUP_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de groupe par défaut")
   @RBComment("Default Group Search Table View")
   public static final String PRIVATE_CONSTANT_320 = "GROUP_TABLEVIEW_DESC";

   @RBEntry("Groupe")
   @RBComment("Group")
   public static final String PRIVATE_CONSTANT_321 = "GROUP_TABLEVIEW_LABEL";

   @RBEntry("Vue des organisations par défaut")
   @RBComment("Default Organization View")
   public static final String PRIVATE_CONSTANT_322 = "ORG_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche des organisations par défaut")
   @RBComment("Default Organization Search Table View")
   public static final String PRIVATE_CONSTANT_323 = "ORG_TABLEVIEW_DESC";

   @RBEntry("Organisation")
   @RBComment("Organization")
   public static final String PRIVATE_CONSTANT_324 = "ORG_TABLEVIEW_LABEL";

   @RBEntry("Vue de pièce jointe de référence par défaut")
   @RBComment("Default Reference Attachment View")
   public static final String PRIVATE_CONSTANT_325 = "IMPORTEDBOOKMARK_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de pièce jointe de référence par défaut")
   @RBComment("Default Reference Attachment Search Table View")
   public static final String PRIVATE_CONSTANT_326 = "IMPORTEDBOOKMARK_TABLEVIEW_DESC";

   @RBEntry("Pièce jointe de référence")
   @RBComment("Reference Attachment")
   public static final String PRIVATE_CONSTANT_327 = "IMPORTEDBOOKMARK_TABLEVIEW_LABEL";

   @RBEntry("Vue de sous-projet/programme par défaut")
   @RBComment("Default Sub Project/Program View")
   public static final String PRIVATE_CONSTANT_328 = "PROJECTPROXY_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de sous-projet/programme par défaut")
   @RBComment("Default Sub Project/Program Search Table View")
   public static final String PRIVATE_CONSTANT_329 = "PROJECTPROXY_TABLEVIEW_DESC";

   @RBEntry("Sous-projet/programme")
   @RBComment("Sub Project/Program")
   public static final String PRIVATE_CONSTANT_330 = "PROJECTPROXY_TABLEVIEW_LABEL";

   @RBEntry("Vue d'armoire par défaut")
   @RBComment("Default Cabinet View")
   public static final String PRIVATE_CONSTANT_331 = "CABINET_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche d'armoire par défaut")
   @RBComment("Default Cabinet Search Table View")
   public static final String PRIVATE_CONSTANT_332 = "CABINET_TABLEVIEW_DESC";

   @RBEntry("Armoire")
   @RBComment("Cabinet")
   public static final String PRIVATE_CONSTANT_333 = "CABINET_TABLEVIEW_LABEL";

   @RBEntry("Vue de configuration de référence par défaut")
   @RBComment("Default Managed Baseline View")
   public static final String PRIVATE_CONSTANT_334 = "MANAGEDBASELINE_TABLEVIEW_NAME";

   @RBEntry("Tableau de référence de configuration de référence par défaut")
   @RBComment("Default Managed Baseline Search Table View")
   public static final String PRIVATE_CONSTANT_335 = "MANAGEDBASELINE_TABLEVIEW_DESC";

   @RBEntry("Configuration de référence")
   @RBComment("Managed Baseline")
   public static final String PRIVATE_CONSTANT_336 = "MANAGEDBASELINE_TABLEVIEW_LABEL";

   @RBEntry("Vue de plan de processus par défaut")
   @RBComment("Default Process Plan View")
   public static final String PRIVATE_CONSTANT_337 = "MPMPROCESSPLAN_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de plan de processus par défaut")
   @RBComment("Default Process Plan Search Table View")
   public static final String PRIVATE_CONSTANT_338 = "MPMPROCESSPLAN_TABLEVIEW_DESC";

   @RBEntry("Gamme")
   @RBComment("Process Plan")
   public static final String PRIVATE_CONSTANT_339 = "MPMPROCESSPLAN_TABLEVIEW_LABEL";

   @RBEntry("Vue de séquence par défaut")
   @RBComment("Default Sequence View")
   public static final String PRIVATE_CONSTANT_340 = "MPMSEQUENCE_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de séquence par défaut")
   @RBComment("Default Sequence Search Table View")
   public static final String PRIVATE_CONSTANT_341 = "MPMSEQUENCE_TABLEVIEW_DESC";

   @RBEntry("Séquence")
   @RBComment("Sequence")
   public static final String PRIVATE_CONSTANT_342 = "MPMSEQUENCE_TABLEVIEW_LABEL";

   @RBEntry("Vue d'opération par défaut")
   @RBComment("Default Operation View")
   public static final String PRIVATE_CONSTANT_343 = "MPMOPERATION_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche d'opération par défaut")
   @RBComment("Default Operation Search Table View")
   public static final String PRIVATE_CONSTANT_344 = "MPMOPERATION_TABLEVIEW_DESC";

   @RBEntry("Opération")
   @RBComment("Operation")
   public static final String PRIVATE_CONSTANT_345 = "MPMOPERATION_TABLEVIEW_LABEL";

   @RBEntry("Vue de l'ensemble des normes de fabrication par défaut")
   @RBComment("Default Manufacturing Standard Group View")
   public static final String PRIVATE_CONSTANT_346 = "MPMMFGSTANDARDGROUP_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche d'ensemble des normes de fabrication par défaut")
   @RBComment("Default Manufacturing Standard Group Search Table View")
   public static final String PRIVATE_CONSTANT_347 = "MPMMFGSTANDARDGROUP_TABLEVIEW_DESC";

   @RBEntry("Groupe de normes de fabrication")
   @RBComment("Manufacturing Standard Group")
   public static final String PRIVATE_CONSTANT_348 = "MPMMFGSTANDARDGROUP_TABLEVIEW_LABEL";

   @RBEntry("Vue de processus de fabrication par défaut")
   @RBComment("Default Manufacturing Process View")
   public static final String PRIVATE_CONSTANT_349 = "MPMMFGPROCESS_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de processus de fabrication par défaut")
   @RBComment("Default Manufacturing Process Search Table View")
   public static final String PRIVATE_CONSTANT_350 = "MPMMFGPROCESS_TABLEVIEW_DESC";

   @RBEntry("Processus de fabrication")
   @RBComment("Manufacturing Process")
   public static final String PRIVATE_CONSTANT_351 = "MPMMFGPROCESS_TABLEVIEW_LABEL";

   @RBEntry("Vue de ressource par défaut")
   @RBComment("Default Resource View")
   public static final String PRIVATE_CONSTANT_352 = "MPMRESOURCE_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de ressource par défaut")
   @RBComment("Default Resource Search Table View")
   public static final String PRIVATE_CONSTANT_353 = "MPMRESOURCE_TABLEVIEW_DESC";

   @RBEntry("Ressource")
   @RBComment("Resource")
   public static final String PRIVATE_CONSTANT_354 = "MPMRESOURCE_TABLEVIEW_LABEL";

   @RBEntry("Vue d'usine par défaut")
   @RBComment("Default Plant View")
   public static final String PRIVATE_CONSTANT_355 = "MPMPLANT_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche d'usine par défaut")
   @RBComment("Default Plant Search Table View")
   public static final String PRIVATE_CONSTANT_356 = "MPMPLANT_TABLEVIEW_DESC";

   @RBEntry("Usine")
   @RBComment("Plant")
   public static final String PRIVATE_CONSTANT_357 = "MPMPLANT_TABLEVIEW_LABEL";

   @RBEntry("Vue de groupe de ressource par défaut")
   @RBComment("Default Resource Group View")
   public static final String PRIVATE_CONSTANT_358 = "MPMRESOURCEGROUP_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de groupe de ressource par défaut")
   @RBComment("Default Resource Group Search Table View")
   public static final String PRIVATE_CONSTANT_359 = "MPMRESOURCEGROUP_TABLEVIEW_DESC";

   @RBEntry("Groupe de ressources")
   @RBComment("Resource Group")
   public static final String PRIVATE_CONSTANT_360 = "MPMRESOURCEGROUP_TABLEVIEW_LABEL";

   @RBEntry("Vue de tâche par défaut")
   @RBComment("Default Work Item View")
   public static final String PRIVATE_CONSTANT_361 = "WORKITEM_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de tâche par défaut")
   @RBComment("Default Work Item Search Table View")
   public static final String PRIVATE_CONSTANT_362 = "WORKITEM_TABLEVIEW_DESC";

   @RBEntry("Tâche")
   @RBComment("Work Item")
   public static final String PRIVATE_CONSTANT_363 = "WORKITEM_TABLEVIEW_LABEL";

   @RBEntry("Vue de rapport par défaut")
   @RBComment("Default Report View")
   public static final String PRIVATE_CONSTANT_364 = "REPORT_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de rapport par défaut")
   @RBComment("Default Report Search Table View")
   public static final String PRIVATE_CONSTANT_365 = "REPORT_TABLEVIEW_DESC";

   @RBEntry("Rapport")
   @RBComment("Report")
   public static final String PRIVATE_CONSTANT_366 = "REPORT_TABLEVIEW_LABEL";

   @RBEntry("Vue de recherche enregistrée par défaut")
   @RBComment("Default Saved Search View")
   public static final String PRIVATE_CONSTANT_367 = "SAVEDQUERY_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de recherche enregistrée par défaut")
   @RBComment("Default Saved Search Table View")
   public static final String PRIVATE_CONSTANT_368 = "SAVEDQUERY_TABLEVIEW_DESC";

   @RBEntry("Vue de sélection de recherche enregistrée par défaut")
   @RBComment("Default Saved Search Picker View")
   public static final String PRIVATE_CONSTANT_369 = "SAVEDQUERY_PICKER_TABLEVIEW_NAME";

   @RBEntry("Tableau de sélection de recherche enregistrée par défaut")
   @RBComment("Default Saved Search Picker Table View")
   public static final String PRIVATE_CONSTANT_370 = "SAVEDQUERY_PICKER_TABLEVIEW_DESC";

   @RBEntry("Recherche enregistrée")
   @RBComment("Saved Search")
   public static final String PRIVATE_CONSTANT_371 = "SAVEDQUERY_TABLEVIEW_LABEL";

   @RBEntry("Par défaut")
   @RBComment("Default View")
   public static final String PRIVATE_CONSTANT_372 = "PERSISTABLE_TABLEVIEW_NAME";

   @RBEntry("Tableau par défaut")
   @RBComment("Default Table View")
   public static final String PRIVATE_CONSTANT_373 = "PERSISTABLE_TABLEVIEW_DESC";

   @RBEntry("Recherche simple")
   @RBComment("Simple Search")
   public static final String PRIVATE_CONSTANT_374 = "PERSISTABLE_TABLEVIEW_LABEL";

   @RBEntry("Vue de message par défaut")
   @RBComment("Default Discussion Posting View")
   public static final String PRIVATE_CONSTANT_375 = "DISCUSSIONPOSTING_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de message par défaut")
   @RBComment("Default Discussion Posting Search Table View")
   public static final String PRIVATE_CONSTANT_376 = "DISCUSSIONPOSTING_TABLEVIEW_DESC";

   @RBEntry("Message de discussion")
   @RBComment("Discussion Posting")
   public static final String PRIVATE_CONSTANT_377 = "DISCUSSIONPOSTING_TABLEVIEW_LABEL";

   @RBEntry("Vue de conférence par défaut")
   @RBComment("Default Meeting View")
   public static final String PRIVATE_CONSTANT_378 = "MEETING_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de conférence par défaut")
   @RBComment("Default Meeting Search Table View")
   public static final String PRIVATE_CONSTANT_379 = "MEETING_TABLEVIEW_DESC";

   @RBEntry("Conférence")
   @RBComment("Meeting")
   public static final String PRIVATE_CONSTANT_380 = "MEETING_TABLEVIEW_LABEL";

   /**
    * L10N CHANGE BEGIN: comment out duplicate resource id
    * PDMLINKPRODUCT_TABLEVIEW_NAME.comment=Default Product View
    * PDMLINKPRODUCT_TABLEVIEW_NAME.value=Default Product View
    * L10N CHANGE END
    * L10N CHANGE BEGIN: comment out duplicate resource id
    * PDMLINKPRODUCT_TABLEVIEW_DESC.comment=Default Product Search Table View
    * PDMLINKPRODUCT_TABLEVIEW_DESC.value=Default Product Search Table View
    * L10N CHANGE END
    * L10N CHANGE BEGIN: comment out duplicate resource id
    * PDMLINKPRODUCT_TABLEVIEW_LABEL.comment=Product
    * PDMLINKPRODUCT_TABLEVIEW_LABEL.value=Product
    * L10N CHANGE END
    **/
   @RBEntry("Vue de modèle de rapport par défaut")
   @RBComment("Default Report Template View")
   public static final String PRIVATE_CONSTANT_381 = "REPORTTEMPLATE_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de modèle de rapport par défaut")
   @RBComment("Default Report Template Search Table View")
   public static final String PRIVATE_CONSTANT_382 = "REPORTTEMPLATE_TABLEVIEW_DESC";

   @RBEntry("Modèle de rapport")
   @RBComment("Report Template")
   public static final String PRIVATE_CONSTANT_383 = "REPORTTEMPLATE_TABLEVIEW_LABEL";

   @RBEntry("Vue de processus par défaut")
   @RBComment("Default Workflow Process View")
   public static final String PRIVATE_CONSTANT_384 = "WORKFLOWPROCESS_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de processus par défaut")
   @RBComment("Default Workflow Process Search Table View")
   public static final String PRIVATE_CONSTANT_385 = "WORKFLOWPROCESS_TABLEVIEW_DESC";

   @RBEntry("Processus")
   @RBComment("Workflow Process")
   public static final String PRIVATE_CONSTANT_386 = "WORKFLOWPROCESS_TABLEVIEW_LABEL";

   @RBEntry("Vue de bibliothèque par défaut")
   @RBComment("Default Library View")
   public static final String PRIVATE_CONSTANT_387 = "WTLIBRARY_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de bibliothèque par défaut")
   @RBComment("Default Library Search Table View")
   public static final String PRIVATE_CONSTANT_388 = "WTLIBRARY_TABLEVIEW_DESC";

   @RBEntry("Bibliothèque")
   @RBComment("Library")
   public static final String PRIVATE_CONSTANT_389 = "WTLIBRARY_TABLEVIEW_LABEL";

   @RBEntry("Vue de tâche d'importation par défaut")
   @RBComment("Default Import Job View")
   public static final String PRIVATE_CONSTANT_390 = "IMPORTJOB_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de tâches d'importation par défaut")
   @RBComment("Default Import Job Search Table View")
   public static final String PRIVATE_CONSTANT_391 = "IMPORTJOB_TABLEVIEW_DESC";

   @RBEntry("Tâche d'importation")
   @RBComment("Import Job")
   public static final String PRIVATE_CONSTANT_392 = "IMPORTJOB_TABLEVIEW_LABEL";

   @RBEntry("Vue de jalon par défaut")
   @RBComment("Default Milestone View")
   public static final String PRIVATE_CONSTANT_393 = "MILESTONE_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de jalon par défaut")
   @RBComment("Default Milestone Search Table View")
   public static final String PRIVATE_CONSTANT_394 = "MILESTONE_TABLEVIEW_DESC";

   @RBEntry("Jalon")
   @RBComment("Milestone")
   public static final String PRIVATE_CONSTANT_395 = "MILESTONE_TABLEVIEW_LABEL";

   @RBEntry("Vue de ressource de projet par défaut")
   @RBComment("Default Project Resource View")
   public static final String PRIVATE_CONSTANT_396 = "PROJECTRESOURCE_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de ressource de projet par défaut")
   @RBComment("Default Project Resource Search Table View")
   public static final String PRIVATE_CONSTANT_397 = "PROJECTRESOURCE_TABLEVIEW_DESC";

   @RBEntry("Ressources du projet")
   @RBComment("Project Resource")
   public static final String PRIVATE_CONSTANT_398 = "PROJECTRESOURCE_TABLEVIEW_LABEL";

   @RBEntry("Vue d'activité de projet par défaut")
   @RBComment("Default Project Activity View")
   public static final String PRIVATE_CONSTANT_399 = "PROJECTACTIVITY_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche d'activité de projet par défaut")
   @RBComment("Default Project Activity Search Table View")
   public static final String PRIVATE_CONSTANT_400 = "PROJECTACTIVITY_TABLEVIEW_DESC";

   @RBEntry("Activité de projet")
   @RBComment("Project Activity")
   public static final String PRIVATE_CONSTANT_401 = "PROJECTACTIVITY_TABLEVIEW_LABEL";

   @RBEntry("Vue de demande de promotion par défaut")
   @RBComment("Default Promotion Request View")
   public static final String PRIVATE_CONSTANT_402 = "PROMOTIONNOTICE_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de promotion par défaut")
   @RBComment("Default Promotion Request Search Table View")
   public static final String PRIVATE_CONSTANT_403 = "PROMOTIONNOTICE_TABLEVIEW_DESC";

   @RBEntry("Demande de promotion")
   @RBComment("Promotion Request")
   public static final String PRIVATE_CONSTANT_404 = "PROMOTIONNOTICE_TABLEVIEW_LABEL";

   @RBEntry("Vue d'activité récapitulative par défaut")
   @RBComment("Default Summary Activity View")
   public static final String PRIVATE_CONSTANT_405 = "SUMMARYACTIVITY_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche d'activité récapitulative par défaut")
   @RBComment("Default Summary Activity Search Table View")
   public static final String PRIVATE_CONSTANT_406 = "SUMMARYACTIVITY_TABLEVIEW_DESC";

   @RBEntry("Activité récapitulative")
   @RBComment("Summary Activity")
   public static final String PRIVATE_CONSTANT_407 = "SUMMARYACTIVITY_TABLEVIEW_LABEL";

   @RBEntry("Vue de fournisseur par défaut")
   @RBComment("Default Supplier View")
   public static final String PRIVATE_CONSTANT_408 = "SUPPLIER_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de fournisseur par défaut")
   @RBComment("Default Supplier Search Table View")
   public static final String PRIVATE_CONSTANT_409 = "SUPPLIER_TABLEVIEW_DESC";

   @RBEntry("Fournisseur")
   @RBComment("Supplier")
   public static final String PRIVATE_CONSTANT_410 = "SUPPLIER_TABLEVIEW_LABEL";

   @RBEntry("Vue d'article fournisseur par défaut")
   @RBComment("Default Supplier Part View")
   public static final String PRIVATE_CONSTANT_411 = "SUPPLIERPART_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche d'article fournisseur par défaut")
   @RBComment("Default Supplier Part Search Table View")
   public static final String PRIVATE_CONSTANT_412 = "SUPPLIERPART_TABLEVIEW_DESC";

   @RBEntry("Article fournisseur")
   @RBComment("Supplier Part")
   public static final String PRIVATE_CONSTANT_413 = "SUPPLIERPART_TABLEVIEW_LABEL";

   @RBEntry("Vue de produit par défaut")
   @RBComment("Default Product View")
   public static final String PRIVATE_CONSTANT_414 = "PDMLINKPRODUCT_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de produit par défaut")
   @RBComment("Default Product Search Table View")
   public static final String PRIVATE_CONSTANT_415 = "PDMLINKPRODUCT_TABLEVIEW_DESC";

   @RBEntry("Produit")
   @RBComment("Product")
   public static final String PRIVATE_CONSTANT_416 = "PDMLINKPRODUCT_TABLEVIEW_LABEL";

   @RBEntry("Vue de contexte par défaut")
   @RBComment("Default Context View")
   public static final String PRIVATE_CONSTANT_417 = "CONTAINER_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de contexte par défaut")
   @RBComment("Default Context Search Table View")
   public static final String PRIVATE_CONSTANT_418 = "CONTAINER_TABLEVIEW_DESC";

   @RBEntry("Contexte")
   @RBComment("Context")
   public static final String PRIVATE_CONSTANT_419 = "CONTAINER_TABLEVIEW_LABEL";

   @RBEntry("Oui")
   @RBComment("Label for True")
   public static final String PRIVATE_CONSTANT_420 = "TRUE_LABEL";

   @RBEntry("Non")
   @RBComment("Label for False")
   public static final String PRIVATE_CONSTANT_421 = "FALSE_LABEL";

   @RBEntry("Format XML de requête enregistrée incorrect")
   @RBComment("Invalid Saved Query XML Format")
   public static final String PRIVATE_CONSTANT_422 = "INVALID_SAVED_QUERY_FORMAT";

   @RBEntry("-Sélectionner -")
   @RBComment("Label for No Selection")
   public static final String PRIVATE_CONSTANT_423 = "NO_SELECTION_LABEL";

   @RBEntry("Définir cette recherche comme recherche globale")
   @RBComment("Mark as Global Search")
   public static final String PRIVATE_CONSTANT_424 = "GLOBAL_SEARCH_SHOW";

   @RBEntry("Ecraser la recherche enregistrée")
   @RBComment("Overwrite Existing Saved Search")
   public static final String PRIVATE_CONSTANT_425 = "OVERWRITE_EXISTING";

   @RBEntry("Etendue de la recherche globale :")
   @RBComment("Set Scope of Global Search")
   public static final String PRIVATE_CONSTANT_426 = "SCOPE_OF_GLOBAL_SEARCH";

   @RBEntry("Rechercher dans le réseau")
   @RBComment("Label for search in network")
   public static final String PRIVATE_CONSTANT_427 = "SEARCH_IN_NETWORK_LABEL";

   @RBEntry("Rechercher les objets associés")
   @RBComment("Label for search related to objects in a particular context")
   public static final String PRIVATE_CONSTANT_428 = "SEARCH_FOR_ITEMS_IN_CONTEXT_LABEL";

   @RBEntry("Contextes réseau :")
   @RBComment("Label for the property \"Search In:\" on the search page when the request comes from Program tab.")
   public static final String PRIVATE_CONSTANT_429 = "SEARCH_IN_NETWORK_CONTEXT";

   @RBEntry("Types recherchés :")
   @RBComment("Label for the type property on the search page when the request comes from Program tab.")
   public static final String PRIVATE_CONSTANT_430 = "SEARCH_FOR_TYPE";

   @RBEntry("Relations :")
   @RBComment("Label for the relationship property on the search page when the request comes from Program tab.")
   public static final String PRIVATE_CONSTANT_431 = "SEARCH_FOR_RELATIONSHIP";

   @RBEntry("Fichier :")
   @RBComment("Select jar or zip to import")
   public static final String PRIVATE_CONSTANT_432 = "SELECT_FILE_IMPORT";

   @RBEntry("(.jar, .zip)")
   @RBComment("File types allowed for Import Saved Query wizard")
   public static final String PRIVATE_CONSTANT_433 = "IMPORT_FILE_TYPES";

   @RBEntry("Le fichier doit porter une extension de type .jar ou .zip.")
   @RBComment("Error message displayed when user tries to import a file other than a jar or zip file.")
   public static final String PRIVATE_CONSTANT_434 = "EXPORT_IMPORT_FILE_ERROR";

   @RBEntry("Résoudre les conflits non prioritaires")
   @RBComment("Label for the resolve overridable conflicts checkbox")
   public static final String PRIVATE_CONSTANT_435 = "RESOLVE_OVERRIDABLE_CONFLICTS";

   @RBEntry("Fichier :")
   @RBComment("File name into which the savedquery should be exported")
   public static final String PRIVATE_CONSTANT_436 = "SELECT_FILE_EXPORT";

   @RBEntry("(Indiquez un chemin+un nom avec l'extension .jar ou .zip.)")
   @RBComment("File types allowed for Export Saved Query wizard")
   public static final String PRIVATE_CONSTANT_437 = "EXPORT_FILE_TYPES";

   @RBEntry("Journal détaillé")
   @RBComment("Label for detailed log link")
   public static final String PRIVATE_CONSTANT_438 = "EXPORT_IMPORT_DETAILED_LOG";

   @RBEntry("Impossible de supprimer le ou les éléments suivants : {0}")
   @RBComment("Message showing list of queries couldn't be deleted")
   public static final String PRIVATE_CONSTANT_439 = "DELETE_QUERY_MESSAGE";

   @RBEntry("Vue de recherche de dossier par défaut")
   @RBComment("Default Folder Search View")
   public static final String PRIVATE_CONSTANT_440 = "FOLDER_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de dossier par défaut")
   @RBComment("Default Folder Search Table")
   public static final String PRIVATE_CONSTANT_441 = "FOLDER_TABLEVIEW_DESC";

   @RBEntry("Dossier")
   @RBComment("Folder")
   public static final String PRIVATE_CONSTANT_442 = "FOLDER_TABLEVIEW_LABEL";

   @RBEntry("ATTENTION : Impossible de supprimer les champs obligatoires\n\nLes champs obligatoires suivants ne peuvent pas être supprimés :\n{0}")
   @RBComment("Message for alert when one tries to remove criteria which is marked required.")
   public static final String PRIVATE_CONSTANT_443 = "REMOVE_QUERYBUILDER_ROW";

   @RBEntry("ATTENTION : Informations requises manquantes. \n\n{0} est un champ obligatoire. \nVeuillez renseigner tous les champs désignés par un astérisque (*).")
   @RBComment("Message for alert if the required attributes are not filled.")
   public static final String REQ_INFO_MISSING = "REQ_INFO_MISSING";

   @RBEntry("ATTENTION : Informations obligatoires manquantes. \n\nRenseignez tous les champs désignés par un astérisque (*).")
   public static final String SAVED_SEARCH_NAME_MISSING = "SAVED_SEARCH_NAME_MISSING";

   @RBEntry("Nom de fichier")
   @RBComment("CADName")
   public static final String PRIVATE_CONSTANT_444 = "CADNAME";

   @RBEntry("Rechercher plutôt :")
   @RBComment("The query suggestion message.")
   public static final String QUERY_SUGGESTION_MESSAGE = "QUERY_SUGGESTION_MESSAGE";

   @RBEntry("Propriétaire")
   @RBComment("Owner")
   public static final String PRIVATE_CONSTANT_445 = "OWNER_LABEL";

   @RBEntry("Récupéré par")
   @RBComment("Checked Out By")
   public static final String PRIVATE_CONSTANT_446 = "CHECKED_OUT_BY";

   @RBEntry("Mis à jour par")
   @RBComment("Updated By")
   public static final String PRIVATE_CONSTANT_447 = "UPDATED_BY";

   @RBEntry("Texte de la note")
   @RBComment("Note Text")
   public static final String PRIVATE_CONSTANT_448 = "PTC_NOTE_TEXT";

   @RBEntry("Inférieur à")
   @RBComment("Less than")
   public static final String PRIVATE_CONSTANT_449 = "OP_LESS";

   @RBEntry("Inférieur ou égal à")
   @RBComment("Less than equal to")
   public static final String PRIVATE_CONSTANT_450 = "OP_LESS_THAN_EQUAL_TO";

   @RBEntry("Supérieur à")
   @RBComment("Greater than")
   public static final String PRIVATE_CONSTANT_451 = "OP_GREATOR";

   @RBEntry("Supérieur ou égal à")
   @RBComment("Greater than equal to")
   public static final String PRIVATE_CONSTANT_452 = "OP_GREATOR_THAN_EQUAL_TO";

   @RBEntry("Nom du rôle")
   @RBComment("Role Name")
   public static final String PRIVATE_CONSTANT_453 = "ROLE_NAME";

   @RBEntry("Rôle")
   @RBComment("Role")
   public static final String PRIVATE_CONSTANT_454 = "ROLE";

   @RBEntry("Affiner la recherche")
   @RBComment("Refine search")
   public static final String PRIVATE_CONSTANT_455 = "REFINE_SEARCH";

   @RBEntry("Rechercher un objet")
   @RBComment("Item Picker Title")
   public static final String PRIVATE_CONSTANT_456 = "ITEM_PICKER_TITLE";

   @RBEntry("Sélection d'objet")
   @RBComment("Item Picker Label")
   public static final String PRIVATE_CONSTANT_457 = "ITEM_PICKER_LABEL";

   @RBEntry("Rechercher un contexte")
   @RBComment("Context Picker Title")
   public static final String PRIVATE_CONSTANT_458 = "CONTEXTS_PICKER_TITLE";

   @RBEntry("Sélection de contexte")
   @RBComment("Context Picker Label")
   public static final String PRIVATE_CONSTANT_459 = "CONTEXTS_PICKER_LABEL";

   @RBEntry("Rechercher")
   @RBComment("Find")
   public static final String PRIVATE_CONSTANT_460 = "FIND_PICKER_LABEL";

   @RBEntry("Afficher")
   @RBComment("View")
   public static final String PRIVATE_CONSTANT_461 = "VIEW_PICKER_LABEL";

   @RBEntry("Vue de recherche de contexte de classement préférentiel par défaut")
   @RBComment("Default Sourcing Context Search View")
   public static final String PRIVATE_CONSTANT_462 = "AXLCONTEXT_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de contexte de classement préférentiel par défaut")
   @RBComment("Default Sourcing Context Search Table")
   public static final String PRIVATE_CONSTANT_463 = "AXLCONTEXT_TABLEVIEW_DESC";

   @RBEntry("Contexte de classement préférentiel")
   @RBComment("Sourcing Context")
   public static final String PRIVATE_CONSTANT_464 = "AXLCONTEXT_TABLEVIEW_LABEL";

   @RBEntry("Vue de note par défaut")
   @RBComment("Default Note View")
   public static final String PRIVATE_CONSTANT_465 = "NOTE_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de note par défaut")
   @RBComment("Default Note Search Table")
   public static final String PRIVATE_CONSTANT_466 = "NOTE_TABLEVIEW_DESC";

   @RBEntry("Résultats de la recherche exportés")
   @RBComment("Exported search results header")
   public static final String PRIVATE_CONSTANT_467 = "EXPORTED_SEARCH_RESULTS";

   @RBEntry("Note")
   @RBComment("Note")
   public static final String PRIVATE_CONSTANT_468 = "NOTE_TABLEVIEW_LABEL";

   @RBEntry("Rechercher")
   public static final String PRIVATE_CONSTANT_469 = "search.pickerSearch.description";

   @RBEntry("Effacer")
   public static final String PRIVATE_CONSTANT_470 = "search.pickerClear.description";

   @RBEntry("Il semble que vous n'ayez pas défini la fonction de rappel ou qu'une erreur ait été détectée :")
   @RBComment("Error on picker call back")
   public static final String PICKER_CALL_BACK_ERROR = "PICKER_CALL_BACK_ERROR";

   @RBEntry("Nom")
   @RBComment("Name")
   public static final String SAVED_QUERY_NAME = "SAVED_QUERY_NAME";

   @RBEntry("Créateur")
   @RBComment("Creator")
   public static final String SAVED_QUERY_CREATOR = "SAVED_QUERY_CREATOR";

   @RBEntry("Page propriétaire")
   @RBComment("Owning Page")
   public static final String SAVED_QUERY_OWNINGPAGE = "SAVED_QUERY_OWNINGPAGE";

   @RBEntry("Créé le")
   @RBComment("Created")
   public static final String SAVED_QUERY_CREATEDON = "SAVED_QUERY_CREATEDON";

   @RBEntry("Mis à jour le")
   @RBComment("Last Updated")
   public static final String SAVED_QUERY_UPDATEDON = "SAVED_QUERY_UPDATEDON";

   @RBEntry("Propriétaire")
   @RBComment("Owner")
   public static final String SAVED_QUERY_OWNER = "SAVED_QUERY_OWNER";

   @RBEntry("Afficher")
   @RBComment("Show")
   public static final String SAVED_QUERY_SHOW = "SAVED_QUERY_SHOW";

   @RBEntry("La fenêtre d'ouverture est fermée.")
   @RBComment("Message thrown when picker opener is closed")
   public static final String OPENER_WINDOW_CLOSED = "OPENER_WINDOW_CLOSED";

   @RBEntry("Aucun objet sélectionné")
   @RBComment("Nothing has been selected")
   public static final String NOTHING_SELECTED = "NOTHING_SELECTED";

   @RBEntry("Entrez un critère de recherche ou saisissez un mot-clé valide")
   @RBComment("Please specify search criteria or enter a valid keyword.")
   public static final String EMPTY_CRITERAI_MESSAGE = "EMPTY_CRITERAI_MESSAGE";

   @RBEntry("Inclure tous les articles")
   @RBComment("Include All Parts")
   public static final String SEARCH_CRITERIA_INCLUDE_ALL_PARTS = "SEARCH_CRITERIA_INCLUDE_ALL_PARTS";

   @RBEntry("Inclure uniquement")
   @RBComment("Include Only")
   public static final String SEARCH_CRITERIA_INCLUDE_ONLY = "SEARCH_CRITERIA_INCLUDE_ONLY";

   @RBEntry("Code de suivi par défaut")
   @RBComment("Default Trace Code")
   public static final String DEFAULT_TRACE_CODE = "DEFAULT_TRACE_CODE";
 
   @RBEntry("Produit fini")
   @RBComment("End Item")
   public static final String DDL_OPTIONS_ENDITEM = "DDL_OPTIONS_ENDITEM";

   @RBEntry("Lot")
   @RBComment("Lot")
   public static final String DDL_OPTIONS_LOT = "DDL_OPTIONS_LOT";

   @RBEntry("Numéro de série")
   @RBComment("serialNumber")
   public static final String DDL_OPTIONS_SERIALNUMBER = "DDL_OPTIONS_SERIALNUMBER";

   @RBEntry("Numéro de lot/série")
   @RBComment("lotSerialNumber")
   public static final String DDL_OPTIONS_LOTSERIALNUMBER = "DDL_OPTIONS_LOTSERIALNUMBER";

   @RBEntry("Standard")
   @RBComment("standard")
   public static final String DDL_OPTIONS_STANDARD = "DDL_OPTIONS_STANDARD";

   @RBEntry("Générique")
   @RBComment("genericParts")
   public static final String DDL_OPTIONS_GENERICPARTS = "DDL_OPTIONS_GENERICPARTS";

   @RBEntry("Générique configurable")
   @RBComment("configurableGenericParts")
   public static final String DDL_OPTIONS_CONFIGURABLEGENERICPARTS = "DDL_OPTIONS_CONFIGURABLEGENERICPARTS";

   @RBEntry("Variante")
   @RBComment("variantParts")
   public static final String DDL_OPTIONS_VARIANTPARTS = "DDL_OPTIONS_VARIANTPARTS";

   @RBEntry("Configurable avancé")
   @RBComment("advancedConfigurableParts")
   public static final String DDL_OPTIONS_ADVANCEDCONFIGURABLEPARTS = "DDL_OPTIONS_ADVANCEDCONFIGURABLEPARTS";

   @RBEntry("Produit fini configurable avancé")
   @RBComment("advanced Configurable End Items")
   public static final String DDL_OPTIONS_ADVANCEDCONFIGURABLEENDITEMS = "DDL_OPTIONS_ADVANCEDCONFIGURABLEENDITEMS";

   @RBEntry("Configurable")
   @RBComment("configurableParts")
   public static final String DDL_OPTIONS_CONFIGURABLEPARTS = "DDL_OPTIONS_CONFIGURABLEPARTS";

   @RBEntry("Module configurable")
   @RBComment("genericType")
   public static final String GENERIC_TYPE = "GENERIC_TYPE";
  
   @RBEntry("Champ Nom de fichier sur la page Recherche simple")
   @RBComment("Property need to set to Search for CAD Name from Simple search page.")
   public static final String CADNAME_FILENAME_ENABLED = "CADNAME_FILENAME_ENABLED";

   @RBEntry("Permet d'afficher le champ Nom de fichier sur la page Recherche simple à l'aide duquel l'utilisateur peut rechercher un document CAO par son nom.")
   @RBComment("Property need to set to Search for CAD Name from Simple search page.")
   public static final String CADNAME_FILENAME_ENABLED_DESCRIPTION = "CADNAME_FILENAME_ENABLED_DESCRIPTION";

   @RBEntry("Permet d'afficher le champ Nom de fichier sur la page Recherche simple à l'aide duquel l'utilisateur peut rechercher un document CAO par son nom.")
   @RBComment("Property need to set to Search for CAD Name from Simple search page.")
   public static final String CADNAME_FILENAME_ENABLED_LONGDESCRIPTION = "CADNAME_FILENAME_ENABLED_LONGDESCRIPTION";

   @RBEntry("Miniature")
   @RBComment("Thumbnail column label")
   public static final String THUMBNAIL = "THUMBNAIL";

   @RBEntry("Le champ Résultats par page requiert une valeur numérique.")
   @RBComment("Message thrown when user enters invalid number for result per page.")
   public static final String MESSAGE_RESULT_PER_PAGE = "MESSAGE_RESULT_PER_PAGE";

   @RBEntry("Liste des types par défaut pour la recherche globale")
   @RBComment("display name for global search type list in preference manager")
   public static final String GLOBAL_SEARCH_TYPE_LIST_NAME = "GLOBAL_SEARCH_TYPE_LIST_NAME";

   @RBEntry("Cette préférence définit les types d'objet répertoriés dans la liste déroulante de la recherche globale.")
   @RBComment("short description of global search type list in preference manager")
   public static final String GLOBAL_SEARCH_TYPE_LIST_DESC = "GLOBAL_SEARCH_TYPE_LIST_DESC";

   @RBEntry("Cette préférence définit les types d'objet répertoriés dans la liste déroulante de la recherche globale.")
   @RBComment("long description of global search type list in preference manager")
   public static final String GLOBAL_SEARCH_TYPE_LIST_LONG_DESC = "GLOBAL_SEARCH_TYPE_LIST_LONG_DESC";

   @RBEntry("Affichage des miniatures dans les résultats d'une recherche")
   @RBComment("Display name for thumbnailsOnWCSearch option in Preferences client")
   public static final String THUMBNAILS_ON_WC_SEARCH = "THUMBNAILS_ON_WC_SEARCH";

   @RBEntry("Détermine si les miniatures s'affichent dans les pages de résultats d'une recherche.")
   @RBComment("Description for thumbnailsOnWCSearch option in the Preferences client")
   public static final String THUMBNAILS_ON_WC_SEARCH_DESCRIPTION = "THUMBNAILS_ON_WC_SEARCH_DESCRIPTION";

   @RBEntry("Cette préférence est utilisée par le client de recherche. Seuls les objets visualisables dans Creo View s'accompagnent de miniatures. Notez que les résultats d'une recherche s'affichent plus rapidement sans les miniatures. Par défaut, le système n'affiche pas les miniatures.")
   @RBComment("Long description for thumbnailsOnWCSearch option in the Preferences client")
   public static final String THUMBNAILS_ON_WC_SEARCH_LONGDESCRIPTION = "THUMBNAILS_ON_WC_SEARCH_LONGDESCRIPTION";

   @RBEntry("Réinitialiser la sélection GlobalType")
   @RBComment("Display name for ResetGlobalTypeSelection option in Preferences client")
   public static final String RESET_GLOBAL_TYPESELECTION = "RESET_GLOBAL_TYPESELECTION";

   @RBEntry("Autoriser l'utilisateur à réinitialiser le type global")
   @RBComment("Description for ResetGlobalTypeSelection option in the Preferences client")
   public static final String RESET_GLOBAL_TYPESELECTION_DESCRIPTION = "RESET_GLOBAL_TYPESELECTION_DESCRIPTION";

   @RBEntry("Autoriser l'utilisateur à réinitialiser le type global")
   @RBComment("Long description for ResetGlobalTypeSelection option in the Preferences client")
   public static final String RESET_GLOBAL_TYPESELECTION_LONGDESCRIPTION = "RESET_GLOBAL_TYPESELECTION_LONGDESCRIPTION";

   @RBEntry("Recherche sur tout type d'objet applicable")
   @RBComment("Display name for allSearchTypes option in Preferences client")
   public static final String ALLSEARCHTYPES = "ALLSEARCHTYPES";

   @RBEntry("Liste des types affichés dans le sélecteur de type des pages de recherche, et liste des objets recherchés lorsque l'utilisateur sélectionne l'option Tous les types d'objets applicables, comme type d'objet dans la page de recherche simple.")
   @RBComment("Description for allSearchTypes option in the Preferences client.When you search within a specific context, the object types listed are set by the context administrator and may differ from the object types that you select for this preference.")
   public static final String ALLSEARCHTYPES_DESCRIPTION = "ALLSEARCHTYPES_DESCRIPTION";

   @RBEntry("Liste des types affichés dans la fenêtre Type dans les pages de recherche. Liste également des objets recherchés lorsque l'utilisateur sélectionne l'option Tous les types d'objets applicables, comme type d'objet dans la page de recherche simple. Lorsque le serveur Windchill est installé, aucune valeur n'est attribuée à la préférence de recherche Tous les types d'objets applicables. Lors de l'accès à la page de recherche de Windchill, la valeur par défaut est définie en fonction du fichier de propriétés SearchableTypes.properties. Accédez à la page de recherche au moins une fois avant de changer les préférences de recherche.")
   @RBComment("Long description for allSearchTypes option in the Preferences client.When you search within a specific context, the object types listed are set by the context administrator and may differ from the object types that you select for this preference.")
   public static final String ALLSEARCHTYPES_LONGDESCRIPTION = "ALLSEARCHTYPES_LONGDESCRIPTION";

   @RBEntry("Type global")
   @RBComment("Display name for globalTypeSelection option in Preferences client")
   public static final String GLOBAL_TYPE_SELECTION = "GLOBAL_TYPE_SELECTION";

   @RBEntry("Cette préférence contient le type sélectionné sur la page Recherche simple. Lorsque l'utilisateur sélectionne plusieurs types d'objet, cette préférence est modifiée.")
   @RBComment("Description for Default Type Selection option in the Preferences client")
   public static final String GLOBAL_TYPE_SELECTION_DESCRIPTION = "GLOBAL_TYPE_SELECTION_DESCRIPTION";

   @RBEntry("Cette préférence contient le type sélectionné sur la page Recherche simple. Lorsque l'utilisateur sélectionne plusieurs types d'objet, cette préférence est modifiée.")
   @RBComment("Long description for Default Type Selection option in the Preferences client")
   public static final String GLOBAL_TYPE_SELECTION_LONGDESCRIPTION = "GLOBAL_TYPE_SELECTION_LONGDESCRIPTION";

   @RBEntry("Liste des types par défaut pour la recherche avancée")
   @RBComment("Display name for searchTypeSelection ")
   public static final String SEARCH_TYPE_SELECTION = "SEARCH_TYPE_SELECTION";

   @RBEntry("Cette préférence définit les types d'objet qui apparaissent par défaut sur la page de recherche avancée.")
   @RBComment("Description for Default Type Selection option in the Preferences client")
   public static final String SEARCH_TYPE_SELECTION_DESCRIPTION = "SEARCH_TYPE_SELECTION_DESCRIPTION";

   @RBEntry("Cette préférence définit les types d'objet qui apparaissent par défaut sur la page de recherche avancée.")
   @RBComment("Long description for Default Type Selection option in the Preferences client")
   public static final String SEARCH_TYPE_SELECTION_LONGDESCRIPTION = "SEARCH_TYPE_SELECTION_LONGDESCRIPTION";

   @RBEntry("Nom interne des recherches enregistrées par l'utilisateurs.")
   @RBComment("Display name for savedSearches option in Preferences client")
   public static final String SAVEDSEARCHES = "SAVEDSEARCHES";

   @RBEntry("Nom interne des recherches enregistrées par l'utilisateurs.")
   @RBComment("Description for savedSearches option in the Preferences client")
   public static final String SAVEDSEARCHES_DESCRIPTION = "SAVEDSEARCHES_DESCRIPTION";

   @RBEntry("Nom interne des recherches enregistrées par l'utilisateurs.")
   @RBComment("Long description for savedSearches option in the Preferences client")
   public static final String SAVEDSEARCHES_LONGDESCRIPTION = "SAVEDSEARCHES_LONGDESCRIPTION";

   /**
    * added for fixing SPR 1350174
    **/
   @RBEntry("Une erreur s'est produite lors de la recherche. Informez votre administrateur système et décrivez-lui l'opération que vous réalisiez lorsque le problème est survenu.")
   @RBComment("This value is will be displayed as a warning alert for exceptions which are thrown from Server side without proper embedded messages ")
   public static final String GENERIC_ERROR_MESSAGE = "GENERIC_EXCEPTION_MESSAGE";

   @RBEntry("Avertissement : Recherche réussie. Il est néanmoins possible que certains objets n'aient pas été trouvés et que la liste des résultats soit incomplète. Cliquez sur Modifier critères puis entrez des critères plus restrictifs dans le champ Mot-clé pour vous assurer que tous les résultats sont renvoyés. Pour plus d'informations concernant le champ Mot-clé, reportez-vous à l'aide en ligne.")
   @RBComment("Message to display to a user when there are possible additional search results in Rware and they need to make their criteria more specific")
   public static final String INCOMPLETE_RESULT_SET_WARNING = "INCOMPLETE_RESULT_SET_WARNING";

   @RBEntry("Avertissement : Recherche réussie. Il est néanmoins possible que certains objets n'aient pas été trouvés et que la liste des résultats soit incomplète. Cliquez sur Modifier critères puis entrez des critères plus restrictifs pour vous assurer que tous les résultats sont renvoyés. Pour plus d'informations concernant l'utilisation des critères de recherche, reportez-vous à l'aide en ligne.")
   @RBComment("Message to display to a user when there are possible additional search results at DB and they need to make their criteria more specific")
   public static final String INCOMPLETE_DB_RESULT_SET_WARNING = "INCOMPLETE_DB_RESULT_SET_WARNING";

   @RBEntry("Résultats par page")
   @RBComment("Display name for result per page in Preferences client")
   public static final String SEARCHTABLELIMIT = "SEARCHTABLELIMIT";

   @RBEntry("Cette préférence définit le nombre de résultats par page par défaut. Cette valeur est égale à 15.")
   @RBComment("Description for Results per page option in the Preferences client")
   public static final String RESULT_PER_PAGE_DESCRIPTION = "SEARCHTABLELIMIT_DESCRIPTION";

   @RBEntry("Cette préférence définit le nombre de résultats par page par défaut. Cette valeur est égale à 15.")
   @RBComment("Long description for Results per page option in the Preferences client")
   public static final String RESULT_PER_PAGE_LONGDESCRIPTION = "SEARCHTABLELIMIT_LONGDESCRIPTION";

   @RBEntry("Attention : Ces éléments sont déjà présents dans la liste des objets sélectionnés...\n\nLa liste Sélectionnés contient déjà certains éléments que vous essayez de déplacer :\n{0}\n\nLes éléments qui ne se trouvent pas déjà dans la liste Sélectionnés seront ajoutés.")
   @RBComment("Attention: Item(s) already in Selected object list...\n\nThe Selected list already contains some of the items you are attempting to move:\n{0}\n\nItems you indicated that are not already in the Selected list will be added.")
   public static final String SOME_ITEMS_ALREADY_SELECTED = "SOME_ITEMS_ALREADY_SELECTED";

   @RBEntry("Attention : Ces éléments sont déjà présents dans la liste des objets sélectionnés...\n\nLa liste Sélectionnés contient déjà les éléments que vous essayez de déplacer :\n{0}")
   @RBComment("Attention: Item(s) already in Selected object list...\n\nThe Selected list already contains the items you are attempting to move:\n{0}")
   public static final String ALL_ITEMS_ALREADY_SELECTED = "ALL_ITEMS_ALREADY_SELECTED";

   @RBEntry("Non suivi")
   @RBComment("untracedParts")
   public static final String DDL_OPTIONS_UUNTRACED = "DDL_OPTIONS_UUNTRACED";

   @RBEntry("L'option Inclure uniquement nécessite qu'au moins une option soit sélectionnée.")
   @RBComment("Alert message if user selects no checkbox from include only radio.")
   public static final String DDLALERT = "DDLALERT";

   @RBEntry("Cette valeur existe déjà.\n\nLe nom que vous venez d'entrer existe déjà. Cliquez sur OK pour remplacer le nom existant ou sur Annuler pour revenir à la page précédente et entrer un nouveau nom.")
   @RBComment("Alert message for same saved search name")
   public static final String SAVEDSEARCHNAMEALERT = "SAVEDSEARCHNAMEALERT";

   @RBEntry("Nº élément ligne contrat")
   @RBComment("search attribute for CDRLBasePackage")
   public static final String CONTRACT_LINE_ITEM = "CONTRACT_LINE_ITEM";

   @RBEntry("Numéro de contrat")
   @RBComment("search attribute for CDRLBasePackage")
   public static final String CONTRACT_NUMBER = "CONTRACT_NUMBER";

   @RBEntry("ATTENTION : Objets inappropriés pour la suppression. \n\n Les objets inappropriés ne seront pas supprimés.")
   @RBComment("Delete action is invalid for one or more selected objects")
   public static final String DELETE_ACTION_INVALID = "DELETE_ACTION_INVALID";

   @RBEntry("Dossier")
   @RBComment("Label for folder search picker.")
   public static final String LOCATION_PICKER_LABEL = "LOCATION_PICKER_LABEL";

   @RBEntry("Dernière recherche")
   @RBComment("Last Search")
   public static final String LAST_SEARCH = "LAST_SEARCH";

   @RBEntry("Application auteur")
   @RBComment("Label for EPMDocument authoring application")
   public static final String EPM_AUTHORING_APPLICATION = "EPM_AUTHORING_APPLICATION";

   @RBEntry("Catégorie de document")
   @RBComment("Label for EPMDocument document category")
   public static final String EPM_DOCUMENT_TYPE = "EPM_DOCUMENT_TYPE";

   @RBEntry("Vue d'accord par défaut")
   @RBComment("Default Agreement View")
   public static final String PRIVATE_CONSTANT_471 = "AUTHORIZATIONAGREEMENT_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche d'accord par défaut")
   @RBComment("Default Agreement Search Table View")
   public static final String PRIVATE_CONSTANT_472 = "AUTHORIZATIONAGREEMENT_TABLEVIEW_DESC";

   @RBEntry("Accord")
   @RBComment("Agreement")
   public static final String PRIVATE_CONSTANT_473 = "AUTHORIZATIONAGREEMENT_TABLEVIEW_LABEL";

   @RBEntry("Type de ressource")
   @RBComment("Label for Resource User Type dropdown having values Windchill User and Other")
   public static final String PLAN_RESOURCE_NAME_LABEL = "PLAN_RESOURCE_NAME_LABEL";

   @RBEntry("Code CAGE")
   @RBComment("Org field name on search page when wadam is installed")
   public static final String WADMORG = "WADMORG";

   @RBEntry("Nom de configuration de l'article")
   @RBComment("Label for configuration name in the configuration compare search picker")
   public static final String PART_CONFIGURATION_NAME_LABEL = "PART_CONFIGURATION_NAME_LABEL";

   @RBEntry("Nom de l'article de base")
   @RBComment("Label for base part name in the configuration compare search picker")
   public static final String BASE_PART_NAME_LABEL = "BASE_PART_NAME_LABEL";

   @RBEntry("Numéro de l'article de base")
   @RBComment("Label for base part number in the configuration compare search picker")
   public static final String BASE_PART_NUMBER_LABEL = "BASE_PART_NUMBER_LABEL";

   @RBEntry("Contact")
   @RBComment("Label for the saved search customize table contact column")
   public static final String PRIVATE_CONSTANT_474 = "CONTACT_LABEL";

   @RBEntry("Afficher la recherche avancée")
   @RBComment("Label used at picker")
   public static final String ADVANCED_SEARCH_LBL = "ADVANCED_SEARCH_LBL";

   @RBEntry("Masquer la recherche avancée")
   @RBComment("Label used at picker")
   public static final String BASIC_SEARCH_LBL = "BASIC_SEARCH_LBL";

   @RBEntry("Type")
   @RBComment("Label used at object type picker")
   public static final String OBJECT_TYPE_LBL = "OBJECT_TYPE_LBL";

   @RBEntry("Type")
   @RBComment("Label used at object type picker on advanced search page")
   public static final String TYPE_LBL = "TYPE_LBL";

   @RBEntry("Code")
   @RBComment("Label for the code field in Choice Search")
   public static final String PRIVATE_CONSTANT_475 = "CODE_LABEL";

   @RBEntry("Option")
   @RBComment("Label for the option field in Choice Search")
   public static final String PRIVATE_CONSTANT_476 = "OPTION_LABEL";

   @RBEntry("Groupe")
   @RBComment("Label for the group field in Choice Search")
   public static final String PRIVATE_CONSTANT_477 = "GROUP_LABEL";

   @RBEntry("Contextes spécifiques")
   @RBComment("Static Find Specific Context option added in context picker dropdown")
   public static final String PRIVATE_CONSTANT_478 = "FIND_CONTEXT";

   @RBEntry("Icône de format")
   @RBComment("Label for the column \"Format Icon\" in tables")
   public static final String FORMAT_ICON = "FORMAT_ICON";

   @RBEntry("Le nombre de résultats par page doit être inférieur à ")
   @RBComment("Max result per page cap.")
   public static final String RESULT_PER_PAGEMAX_CAP = "RESULT_PER_PAGEMAX_CAP";

   @RBEntry("Sélectionner une plage de dates")
   @RBComment("Choose Date Range")
   public static final String DATE_DATE_RANGE = "DATE_DATE_RANGE";

   @RBEntry("Sélectionner une plage de jours")
   @RBComment("Choose Day Range")
   public static final String DATE_DAY_RANGE = "DATE_DAY_RANGE";

   @RBEntry("Hier")
   @RBComment("Yesterday")
   public static final String DATE_YESTERDAY = "DATE_YESTERDAY";

   @RBEntry("Aujourd'hui")
   @RBComment("Today")
   public static final String DATE_TODAY = "DATE_TODAY";

   @RBEntry("Demain")
   @RBComment("Tomorrow")
   public static final String DATE_TOMORROW = "DATE_TOMORROW";

   @RBEntry("jours auparavant")
   @RBComment("days ago")
   public static final String DAYS_AGO = "DAYS_AGO";

   @RBEntry("jours à partir de maintenant")
   @RBComment("days from now")
   public static final String DAYS_NOW = "DAYS_NOW";

   @RBEntry("Nouvelle vue")
   public static final String PRIVATE_CONSTANT_479 = "search.newView.description";

   @RBEntry("Critère obsolète.")
   @RBComment("Message for alert when some of the criteria's are missing after upgrade.")
   public static final String MISSING_QUERYBUILDER_ROW = "MISSING_QUERYBUILDER_ROW";

   @RBEntry("Ce critère est devenu obsolète après la mise à niveau vers la dernière version. Supprimez-le, puis ajoutez des critères valides à partir de la liste et réenregistrez la recherche. Si la recherche enregistrée est affectée à l'administrateur, demandez à celui-ci de recréer la recherche enregistrée.")
   @RBComment("Message for alert when some of the criteria's are missing after upgrade.")
   public static final String INVALID_QUERYBUILDER_ROW = "INVALID_QUERYBUILDER_ROW";

   @RBEntry("ID")
   @RBComment("Label for Project Plan Activity ID.")
   public static final String PLAN_ACTIVITY_ID = "PLAN_ACTIVITY_ID";

   @RBEntry("Type non valide pour une recherche avancée.")
   @RBComment("wt.fc.Persistable is not a valid type for advanced search")
   public static final String INVALID_TYPE_FOR_ADVANCED_SEARCH = "INVALID_TYPE_FOR_ADVANCED_SEARCH";

   @RBEntry("Nouvelle vue")
   @RBComment("new view")
   public static final String NEWVIEW = "NEWVIEW";

   @RBEntry("Fermer")
   public static final String PRIVATE_CONSTANT_480 = "search.searchCloseButton.description";

   @RBEntry("Fabriquer")
   public static final String PRIVATE_CONSTANT_481 = "MAKE_FACET";

   @RBEntry("Acheter")
   public static final String PRIVATE_CONSTANT_482 = "BUY_FACET";

   @RBEntry("En cours de traitement")
   public static final String PRIVATE_CONSTANT_483 = "INWORK_FACET";

   @RBEntry("Officiel")
   public static final String PRIVATE_CONSTANT_484 = "RELEASED_FACET";

   @RBEntry("Articles")
   public static final String PRIVATE_CONSTANT_485 = "WTPART_FACET";

   @RBEntry("Documents")
   public static final String PRIVATE_CONSTANT_486 = "WTDOCUMENT_FACET";

   @RBEntry("Nom du destinataire")
   @RBComment("Field name for recipent name in delta delivery picker")
   public static final String RECIPIENT_NAME = "RECIPIENT_NAME";

   @RBEntry("Gérer")
   public static final String PRIVATE_CONSTANT_487 = "search.savedSearchTable.description";

   @RBEntry("Gérer")
   public static final String PRIVATE_CONSTANT_488 = "search.savedSearchTable.tooltip";

   @RBEntry("Gérer les recherches enregistrées")
   public static final String PRIVATE_CONSTANT_489 = "search.savedSearchTable.title";

   @RBEntry("height=450,width=920")
   public static final String PRIVATE_CONSTANT_523 = "search.savedSearchTable.moreurlinfo";

   @RBEntry("Enregistrer cette recherche")
   public static final String PRIVATE_CONSTANT_490 = "search.saveThisSearchDefaultName.description";

   @RBEntry("height=250,width=450")
   public static final String PRIVATE_CONSTANT_491 = "search.saveThisSearchDefaultName.moreurlinfo";

   @RBEntry("Enregistrer cette recherche")
   public static final String PRIVATE_CONSTANT_492 = "search.saveThisSearchDefaultName.title";

   @RBEntry("Nom")
   public static final String SAVED_SEARCH_DISPLAY_NAME = "SAVED_SEARCH_DISPLAY_NAME";

   @RBEntry("Fermer")
   public static final String PRIVATE_CONSTANT_493 = "search.savedSearchLightBoxCloseButton.description";

   @RBEntry("Historique des recherches et recherches enregistrées")
   public static final String PRIVATE_CONSTANT_494 = "search.searchHistSavedSearch.description";

   @RBEntry("Recherche avancée")
   public static final String PRIVATE_CONSTANT_495 = "search.advancedSearch.description";

   @RBEntry("Recherche de classification")
   public static final String PRIVATE_CONSTANT_496 = "search.classificationSearch.description";

   @RBEntry("Historique des recherches")
   @RBComment("Heading for Search History Display")
   public static final String SEARCH_HISTORY_HEADING = "SEARCH_HISTORY_HEADING";

   @RBEntry("Recherches enregistrées")
   @RBComment("Heading for Saved Search Display")
   public static final String SAVED_SEARCH_HEADING = "SAVED_SEARCH_HEADING";

   @RBEntry("Créées par moi")
   @RBComment("Saved Search section for queries saved by current user")
   public static final String SAVED_SEARCH_CREATED_BY_ME = "SAVED_SEARCH_CREATED_BY_ME";

   @RBEntry("Partagées avec moi")
   @RBComment("Saved Search section for queries saved by current user")
   public static final String SAVED_SEARCH_SHARED_WITH_ME = "SAVED_SEARCH_SHARED_WITH_ME";

   @RBEntry("Aujourd'hui")
   @RBComment(" Search History for today's searches.")
   public static final String SEARCH_HISTORY_TODAY = "SEARCH_HISTORY_TODAY";

   @RBEntry("Avant ")
   @RBComment(" Search History for older searches.")
   public static final String SEARCH_HISTORY_OLDER = "SEARCH_HISTORY_OLDER";

   @RBEntry("Aucune recherche exécutée aujourd'hui")
   @RBComment("label when no records found in todays history")
   public static final String SEARCH_HISTORY_TODAY_NO_RECORDS_LABEL = "SEARCH_HISTORY_TODAY_NO_RECORDS_LABEL";

   @RBEntry("Aucune")
   @RBComment("label when no records found in Saved Searches.")
   public static final String SAVED_SEARCH_NO_RECORDS_LABEL = "SAVED_SEARCH_NO_RECORDS_LABEL";

   @RBEntry("Modifier les critères")
   @RBComment("Label for Edit action in saved search & search history display.")
   public static final String PRIVATE_CONSTANT_497 = "EDIT_LABEL";

   @RBEntry("Mot-clé")
   @RBComment("Being used in the search history display page in search history link.")
   public static final String KEYWORD_FOR_SEARCH_HISTORY_LINK = "KEYWORD_FOR_SEARCH_HISTORY_LINK";

   @RBEntry("Type")
   @RBComment("Being used in the search history display page in search history link.")
   public static final String TYPE_FOR_SEARCH_HISTORY_LINK = "TYPE_FOR_SEARCH_HISTORY_LINK";

   @RBEntry("Vue Jeu d'options par défaut")
   @RBComment("Default Option Set View")
   public static final String PRIVATE_CONSTANT_498 = "OPTIONSET_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de jeu d'options par défaut")
   @RBComment("Default Option Set Search Table View")
   public static final String PRIVATE_CONSTANT_499 = "OPTIONSET_TABLEVIEW_DESC";

   @RBEntry("Jeu d'options  ")
   @RBComment("Option Set ")
   public static final String PRIVATE_CONSTANT_500 = "OPTIONSET_TABLEVIEW_LABEL";

   @RBEntry("OK")
   @RBComment("Label for Ok button in Ext Window for lightbix.")
   public static final String PRIVATE_CONSTANT_501 = "Ok_LABEL";

   @RBEntry("Annuler")
   @RBComment("Label for Cancel button in Ext Window for lightbix.")
   public static final String PRIVATE_CONSTANT_502 = "Cancel_LABEL";

   @RBEntry("Critères supplémentaires pour les articles :")
   @RBComment("Label for Additonal Criteria for Parts")
   public static final String PRIVATE_CONSTANT_503 = "PART_ADDITIONAL_CRITERIA";

   @RBEntry("Enregistrer")
   @RBComment("Label for Save button in Ext Window for lightbix.")
   public static final String PRIVATE_CONSTANT_504 = "Save_LABEL";

   @RBEntry("Options")
   @RBComment("Caption text at type picker launch point at search page")
   public static final String TYPE_PICKER_MENU_CAPTION = "TYPE_PICKER_MENU_CAPTION";

   @RBEntry("Ajouter")
   @RBComment("Caption text at type picker launch point at search page")
   public static final String TYPE_PICKER_MENU_ADD_UPDATE = "TYPE_PICKER_MENU_ADD_UPDATE";

   @RBEntry("Rétablir les valeurs par défaut")
   @RBComment("Caption text at type picker launch point at search page")
   public static final String TYPE_PICKER_MENU_RESTORE_DEFAULT = "TYPE_PICKER_MENU_RESTORE_DEFAULT";

   @RBEntry("Tous les types")
   @RBComment("display name for persistable type")
   public static final String ALL_TYPES = "ALL_TYPES";

   @RBEntry("Sélectionner les relations")
   @RBComment("label for relations")
   public static final String SELECT_RELATIONS = "SELECT_RELATIONS";

   @RBEntry("Vue Choix par défaut")
   @RBComment("Default Choice View")
   public static final String PRIVATE_CONSTANT_505 = "CHOICE_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de choix par défaut")
   @RBComment("Default Choice Search Table View")
   public static final String PRIVATE_CONSTANT_506 = "CHOICE_TABLEVIEW_DESC";

   @RBEntry("Choix")
   @RBComment("Choice ")
   public static final String PRIVATE_CONSTANT_507 = "CHOICE_TABLEVIEW_LABEL";

   @RBEntry("Impossible de charger la recherche enregistrée car un ou plusieurs objets associés ont été supprimés.")
   @RBComment(" Error message to be shown when user selects a deleted saved query for edit or execute.")
   public static final String SAVED_SEARCH_DELETED_MESSAGE = "SAVED_SEARCH_DELETED_MESSAGE";

   /**
    * special column labels
    **/
   @RBEntry("Nom")
   public static final String PACKAGE_NAME = "PACKAGE_NAME";

   @RBEntry("Numéro de lot")
   public static final String PACKAGE_NUMBER = "PACKAGE_NUMBER";

   @RBEntry("Version de lot")
   public static final String PACKAGE_VERSION = "PACKAGE_VERSION";

   @RBEntry("Tout")
   public static final String ALL_VIEW = "ALL_VIEW";

   @RBEntry("Tout")
   public static final String ALL_VIEW_DESCRIPTION = "ALL_VIEW_DESCRIPTION";

   @RBEntry("Nom de la recherche enregistrée ")
   @RBComment("Label of the saved search name being displayed on advanced search screen.")
   public static final String SAVED_SEARCH_NAME_LABEL = "SAVED_SEARCH_NAME_LABEL";

   @RBEntry("Démarrer une nouvelle recherche")
   @RBComment("label for start a new search link on the search page")
   public static final String START_A_NEW_SEARCH_LINK = "START_A_NEW_SEARCH_LINK";

   @RBEntry("Enregistrer cette recherche")
   @RBComment("label for save this search link on the search page ")
   public static final String SAVE_THIS_SEARCH_LINK = "SAVE_THIS_SEARCH_LINK";

   @RBEntry("Modifier les critères de recherche")
   @RBComment(" label for edit search criteria link on the search page ")
   public static final String EDIT_SEARCH_CRITERIA_LINK = "EDIT_SEARCH_CRITERIA_LINK";

   @RBEntry("Afficher l'historique des recherches et les recherches enregistrées")
   @RBComment("Label of the view saved search option")
   public static final String VIEW_SAVED_SEARCH_LABEL = "VIEW_SAVED_SEARCH_LABEL";

   @RBEntry("Choisissez un type")
   @RBComment("Label of the choose type option")
   public static final String CHOOSE_TYPE_LABEL = "CHOOSE_TYPE_LABEL";

   @RBEntry("Tous types d'objet")
   @RBComment("Label of the all type option")
   public static final String ALL_TYPE_LABEL = "ALL_TYPE_LABEL";

   @RBEntry("Historique des recherches et recherches enregistrées")
   @RBComment("Tab label for history & saved searches page")
   public static final String PRIVATE_CONSTANT_508 = "navigation.historySaved.description";

   @RBEntry("Recherche avancée")
   @RBComment("Tab label for Advanced search page")
   public static final String PRIVATE_CONSTANT_509 = "navigation.advanced.description";

   @RBEntry("Recherche de classification")
   @RBComment("Tab label for Classification search page")
   public static final String PRIVATE_CONSTANT_510 = "navigation.classification.description";

   @RBEntry("Critères supplémentaires")
   @RBComment("Label for Additional Criteria on search info page for search history and saved searches")
   public static final String ADDITIONAL_CRITERIA_LABEL = "ADDITIONAL_CRITERIA_LABEL";


   @RBEntry("Dernière exécution le")
   @RBComment("Label for Last Performed on search info page for search history and saved searches")
   public static final String LAST_PERFORMED_ON_LABEL = "LAST_PERFORMED_ON_LABEL";


   @RBEntry("Taille des listes de contextes consultés récemment")
   @RBComment("Determines maximum number of items in recently visited Context Picker drop-down.")
   public static final String MULTISELECT_CONTEXTPICKER_LIMIT = "MULTISELECT_CONTEXTPICKER_LIMIT";

   @RBEntry("Vous pouvez sélectionner {0} contextes maximum dans les résultats. Désélectionnez-en pour continuer.")
   @RBComment("Alert to be shown for user if selects more contexts than preference set for search page.")
   public static final String MULTISELECT_CONTEXTPICKER_LIMIT_ALERT = "MULTISELECT_CONTEXTPICKER_LIMIT_ALERT";

   @RBEntry("Relations réseau")
   @RBComment("Label for the network realtionship display in search criteria string ")
   public static final String NETWORK_RELATIONSHIP_LABEL = "NETWORK_RELATIONSHIP_LABEL";


   @RBEntry("Contexte réseau")
   @RBComment("Label for the network context display in search criteria string ")
   public static final String NETWORK_CONTEXT_LABEL = "NETWORK_CONTEXT_LABEL";


   @RBEntry("Modifier les critères")
   @RBComment("Link for edit criteria on search info page for search history and saved searches")
   public static final String EDIT_CRITERIA_LINK = "EDIT_CRITERIA_LINK";

   @RBEntry("Critères DDL")
   @RBComment("DDL  Criteria label on search info page for search history and saved searches")
   public static final String DDL_CRITERIA_LABEL = "DDL_CRITERIA_LABEL";

   @RBEntry("Objet associé")
   @RBComment("Related Object label on search info page for search history and saved searches")
   public static final String RELATED_OBJECT_LABEL = "RELATED_OBJECT_LABEL";


   @RBEntry("Panneau des archives")
   @RBComment("Archive Panel label on search info page for search history and saved searches")
   public static final String ARCHIVE_PANEL_LABEL = "ARCHIVE_PANEL_LABEL";

   @RBEntry("Vue des qualifications par défaut")
   @RBComment("Default Skill View")
   public static final String PRIVATE_CONSTANT_511 = "MPMPSKILL_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de qualification par défaut")
   @RBComment("Default Skill Search Table View")
   public static final String PRIVATE_CONSTANT_512 = "MPMPSKILL_TABLEVIEW_DESC";

   @RBEntry("Qualification")
   @RBComment("Skill")
   public static final String PRIVATE_CONSTANT_513 = "MPMPSKILL_TABLEVIEW_LABEL";

   @RBEntry("Vue de l'outillage par défaut")
   @RBComment("Default Tooling View")
   public static final String PRIVATE_CONSTANT_514 = "MPMTOOLING_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de l'outillage par défaut")
   @RBComment("Default Tooling Search Table View")
   public static final String PRIVATE_CONSTANT_515 = "MPMTOOLING_TABLEVIEW_DESC";

   @RBEntry("Outillage")
   @RBComment("Tooling")
   public static final String PRIVATE_CONSTANT_516 = "MPMTOOLING_TABLEVIEW_LABEL";

   @RBEntry("Vue du poste de charge par défaut")
   @RBComment("Default WorkCenter View")
   public static final String PRIVATE_CONSTANT_517 = "MPMWORKCENTER_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de poste de charge par défaut")
   @RBComment("Default WorkCenter Search Table View")
   public static final String PRIVATE_CONSTANT_518 = "MPMWORKCENTER_TABLEVIEW_DESC";

   @RBEntry("Poste de charge")
   @RBComment("WorkCenter")
   public static final String PRIVATE_CONSTANT_519 = "MPMWORKCENTER_TABLEVIEW_LABEL";

   @RBEntry("Vue des matières consommables par défaut")
   @RBComment("Default Process Material View")
   public static final String PRIVATE_CONSTANT_520 = "MPMPROCESSMATERIAL_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de matière consommable par défaut")
   @RBComment("Default Process Material Search Table View")
   public static final String PRIVATE_CONSTANT_521 = "MPMPROCESSMATERIAL_TABLEVIEW_DESC";

   @RBEntry("Matière consommable")
   @RBComment("Process Material")
   public static final String PRIVATE_CONSTANT_522 = "MPMPROCESSMATERIAL_TABLEVIEW_LABEL";



   @RBEntry("Enregistrer cette recherche")
   public static final String saveThisSearchProEDesc = "search.saveThisSearchProE.description";

   @RBEntry("Enregistrer cette recherche")
   public static final String saveThisSearchProEToolT = "search.saveThisSearchProE.tooltip";

   @RBEntry("Enregistrer cette recherche")
   public static final String saveThisSearchProETitle = "search.saveThisSearchProE.title";

   @RBEntry("Jusqu'à")
   public static final String uoToLabel = "UP_TO_ATTRIBUTE";

   @RBEntry("{0} jours auparavant")
   public static final String daysAgoAttrib = "DAYS_AGO_TO_ATTRIBUTE";

   @RBEntry("{0} jours à partir de maintenant")
   public static final String daysFromNowAttrib = "DAYS_FROM_NOW_ATTRIBUTE";

   @RBEntry("Plus")
   @RBComment("More lable in query builder")
   public static final String moreQBLabel = "MORE_QB_LABEL";


   @RBEntry("Options")
   public static final String options = "OPTIONS";

   @RBEntry("Ajouter un contexte")
   public static final String addContext = "ADD_CONTEXT";

   @RBEntry("Plus d'options")
   public static final String moreOptions = "MORE_OPTIONS";

   @RBEntry("OK")
   public static final String ok = "OK";

   @RBEntry("Annuler")
   public static final String cancel = "CANCEL";

   @RBEntry("Rechercher dans")
   public static final String searchIn = "SEARCH_IN";

   @RBEntry("Appartenance")
   public static final String membership = "MEMBERSHIP";

   @RBEntry("Je suis membre")
   public static final String iAmAMemberOf = "I_AM_A_MEMBER_OF";

   @RBEntry("Sont dans mon organisation")
   public static final String areInMyOrganization = "ARE_IN_MY_ORGANIZATION";

   @RBEntry("Entrez une valeur numérique valide.")
   @RBComment("Msg for invalid numeric entry.")
   public static final String INVALID_NUMBER = "INVALID_NUMBER";

   @RBEntry("Nouveau")
   @RBComment("Label of submenu New")
   public static final String new_submenu = "object.new_submenu.description";

   @RBEntry("Ajouter à")
   @RBComment("Label of submenu Add to")
   public static final String add_to_submenu = "object.add_to_submenu.description";

   @RBEntry("Comparer")
   @RBComment("Label of submenu Compare")
   public static final String compare_submenu = "object.compare_submenu.description";

   @RBEntry("Traiter")
   @RBComment("Label of submenu Process")
   public static final String process_submenu = "object.process_submenu.description";

   @RBEntry("Indéfini")
   public static final String UNDEFINED_LABEL = "UNDEFINED_LABEL";

   @RBEntry("Sélectionner les critères d'archivage")
   @RBComment("Label of link to launch archive panel on search page")
   public static final String ARCHIVE_LINK_LEVEL = "ARCHIVE_LINK_LEVEL";

   @RBEntry("Aucun des objets sélectionnés ne prend cette action en charge.")
   @RBComment("Warning messafe to user when invalid objects are selected to perform Email object owners action")
   public static final String INVALID_OBJECT_EMAIL = "INVALID_OBJECT_EMAIL";

   @RBEntry("Certains des objets sélectionnés ne prennent pas cette action en charge. Appuyez sur OK pour continuer.")
   @RBComment("Warning messafe to user when invalid objects are selected to perform Email object owners action")
   public static final String FEW_INVALID_OBJECT_EMAIL = "FEW_INVALID_OBJECT_EMAIL";


   @RBEntry("Impossible de rechercher {0} avec d'autres types.")
   @RBComment("Message alerting the individual type cannot be searched with other types. ")
   public static final String INDIVIDUAL_SEARCH_TYPE = "INDIVIDUAL_SEARCH_TYPE";


   @RBEntry("ID alternatif")
   @RBComment("Field name for user record key in Quality People or Places")
   public static final String ALTERNATE_IDENTIFIER = "ALTERNATE_IDENTIFIER";

   @RBEntry("Nº de téléphone")
   @RBComment("Field name for Phone number in Quality People or Places")
   public static final String PHONE_NUMBER = "PHONE_NUMBER";

   @RBEntry("E-mail")
   @RBComment("Field name for E-mail address in Quality People or Places")
   public static final String EMAIL_ADDRESS = "EMAIL_ADDRESS";

   @RBEntry("Code postal")
   @RBComment("Field name for Postal code in Quality People or Places")
   public static final String POSTAL_CODE = "POSTAL_CODE";

   @RBEntry("Enregistrer la requête :")
   @RBComment("Saved Search Create Message")
   public static final String SAVED_SEARCH_CREATED = "SAVED_SEARCH_CREATED";

   @RBEntry("Confirmation : Création terminée")
   @RBComment("Saved Search Create Message Title")
   public static final String SAVED_SEARCH_CREATED_TITLE = "SAVED_SEARCH_CREATED_TITLE";

   @RBEntry("Vue Modèle de processus par défaut")
   @RBComment("Default Workflow Process Template View")
   public static final String PRIVATE_CONSTANT_530 = "WFTEMPLATE_TABLEVIEW_NAME";

   @RBEntry("Vue Tableau de recherche de processus par défaut")
   @RBComment("Default Workflow Process Template Search Table View")
   public static final String PRIVATE_CONSTANT_531 = "WFTEMPLATE_TABLEVIEW_DESC";

   @RBEntry("Modèle de processus")
   @RBComment("Workflow Process Template")
   public static final String PRIVATE_CONSTANT_532 = "WFTEMPLATE_TABLEVIEW_LABEL";
   @RBEntry("ATTENTION : Pour les objets itérés, toutes les itérations du changement de version sélectionné seront supprimées.")
   @RBComment("If one or more of the selected objects are iterated. All iterations for the selected object revisions will be deleted.")
   public static final String CONFIRM_DELETE = "CONFIRM_DELETE";

   @RBEntry("Vue de la livraison reçue par défaut")
   @RBComment("Default Received Delivery View")
   public static final String PRIVATE_CONSTANT_533 = "RECEIVEDDELIVERY_TABLEVIEW_NAME";

   @RBEntry("Tableau de recherche de la livraison reçue par défaut")
   @RBComment("Default Received Delivery Search Table View")
   public static final String PRIVATE_CONSTANT_534 = "RECEIVEDDELIVERY_TABLEVIEW_DESC";

   @RBEntry("Livraison reçue")
   @RBComment("Received Delivery")
   public static final String PRIVATE_CONSTANT_535 = "RECEIVEDDELIVERY_TABLEVIEW_LABEL";

   @RBEntry("Nom de vue")
   @RBComment("view name label")
   public static final String PRIVATE_CONSTANT_536 = "VIEW_NAME_LABEL";

   // resources for Clear icon in Structured Enumeration Picker
   @RBEntry("Effacer...")
   public static final String PRIVATE_CONSTANT_537 = "search.callSearchPickerClear.description";

   // resources for Clear icon in Structured Enumeration Picker
   @RBEntry("Effacer...")
   public static final String PRIVATE_CONSTANT_538 = "search.callSearchPickerClear.tooltip";

   @RBEntry("Numéro")
   public static final String PRIVATE_CONSTANT_539 = "2";

   @RBEntry("Nom")
   public static final String PRIVATE_CONSTANT_540 = "1";

   @RBEntry("Spécifiez un critère de recherche")
   @RBComment("Alert shown to the user when empty search is executed with mulitple object types or multiple object types.")
   public static final String MULTI_TYPE_EMPTY_SEARCH_MESSAGE_TITLE = "MULTI_TYPE_EMPTY_SEARCH_MESSAGE_TITLE";

   @RBEntry("La date entrée ne respecte pas le format jj/MM/aaaa ou est hors plage.")
   public static final String DATE_ERROR = "DATE_ERROR";

   @RBEntry("La recherche ne s'est pas terminée correctement. Le problème peut venir des critères de recherche ou de l'impossibilité d'accéder aux objets des résultats de la recherche. Modifiez vos critères de recherche et recommencez, ou contactez l'administrateur système pour obtenir de l'aide.")
   @RBComment("Message to display to a user when there is there is an invalid search criteria.")
   public static final String INVALID_CRITERIA_ERROR = "INVALID_CRITERIA_ERROR";

   /*
    * ***********************************************************
    * Search in Folder Resources
    *************************************************************
    */
   @RBEntry("Rechercher dans le dossier sélectionné")
   @RBComment("Empty text for the Search in Folder component")
   public static final String SEARCH_IN_FOLDER_PROMPT = "SEARCH_IN_FOLDER_PROMPT";

   @RBEntry("Effacer")
   @RBComment("Clear text in Search in Folder component. Reset the text to Empty text string")
   public static final String CLEAR_SEARCH_IN_FOLDER = "CLEAR_SEARCH_IN_FOLDER";

   @RBEntry("Serveur d'index hors service")
   @RBComment("Index Server down title")
   public static final String WARN_INDEX_SERER_DOWN_FALLBACK_TO_DB_SEAR_TITLE = "WARN_INDEX_SERER_DOWN_FALLBACK_TO_DB_SEARCH_TITLE";

   @RBEntry("La fonction de recherche indexée n'étant pas disponible, une recherche d'attribut a été effectuée. Il est possible que les résultats de la recherche ne contiennent pas tous les objets attendus. Contactez l'administrateur Windchill.")
   @RBComment("Index Server down. Fall back to DB Search.")
   public static final String WARN_INDEX_SERER_DOWN_FALLBACK_TO_DB_SEARCH = "WARN_INDEX_SERER_DOWN_FALLBACK_TO_DB_SEARCH";

   /*
    ************************************************************
    * Structured Enumeration Picker Resources
    ************************************************************
    */
   @RBEntry("Arborescence de classification")
   @RBComment("Title for Classification Tree")
   public static final String CLASSIFICATION_TREE_TITLE = "csm.clfTree.title";

   @RBEntry("Classe")
   @RBComment("Title for the column in Classification Tree")
   public static final String CLASSIFICATION_TREE_COLUMN_NAME = "csm.clfTreeColumnName.title";

   // following entries are added as a part of story B-100525
   @RBEntry("Vérifiez les types d'objet sélectionnés et réexécutez la recherche.")
   @RBComment("The message to be shown to user when the parent and child types both are selected and parent types should be removed")
   public static final String PARENT_TYPE_SELECTED_MESSAGE = "PARENT_TYPE_SELECTED_MESSAGE";

   @RBEntry("Impossible d'exécuter la recherche pour les objets dans la hiérarchie.")
   @RBComment("The title to be shown to user when the parent and child types both are selected and parent types should be removed")
   public static final String PARENT_TYPE_SELECTED_MESSAGE_TITLE = "PARENT_TYPE_SELECTED_MESSAGE_TITLE";

   @RBEntry("Mes contextes favoris")
   @RBComment("Message for My Context Display")
   public static final String MY_FAVOURITE_CONTEXT_LBL = "MY_FAVOURITE_CONTEXT_LBL";

   @RBEntry("Exemples de syntaxe du mode requête")
   @RBComment("Examples for query mode syntax")
   public static final String EXAMPLES_FOR_QUERY_MODE_SYNTAX = "EXAMPLES_FOR_QUERY_MODE_SYNTAX";

   @RBEntry("Mes types favoris")
   @RBComment("Label for My Favorite Type checkbox shown on the search page")
   public static final String  MY_FAVOURITE_TYPE_LBL = "MY_FAVOURITE_TYPE_LBL";

   @RBEntry("Critères")
   @RBComment("Criteria label for the criteria fieldset on the advanced search page.")
   public static final String CRITERIA_LABEL = "CRITERIA_LBL";

   @RBEntry("Sélection de plusieurs dossiers")
   @RBComment("Warning Heading message when My Fav checkbox selected and only folders present inside it.")
   public static final String MULTIPLE_FOLDER_SELECTION_HEADING = "MULTIPLE_FOLDER_SELECTION_HEADING";
   
   @RBEntry("Vous ne pouvez sélectionner qu'un dossier à la fois")
   @RBComment("Warning message when My Fav checkbox selected and only folders present inside it.")
   public static final String MULTIPLE_FOLDER_SELECTION_MSG = "MULTIPLE_FOLDER_SELECTION_MSG";

    @RBEntry("dans")
    @RBComment("Description has format 'Type in Organization', localizing word 'in' ")
    public static final String SAVE_SEARCH_COMBO_BOX_TOOLTIP_DESCRIPTION = "SAVE_SEARCH_COMBO_BOX_TOOLTIP_DESCRIPTION";

    @RBEntry("Site")
    @RBComment("Site")
    public static final String PRIVATE_CONSTANT_541 = "Site";
    
    /*Adding Secondary Attachments column*/
    @RBEntry("Pièces jointes")
    @RBComment("Label for Secondary Attachments column")
    public static final String SECONDARY_ATTACHMENTS = "SECONDARY_ATTACHMENTS";

    @RBEntry("Balise")
    @RBComment("Label for Tag column")
    public static final String TAG_LABEL = "TAG_LABEL";
    
    @RBEntry("Filtre")
    @RBComment("Label for Filter column")
    public static final String FILTER_LABEL = "FILTER_LABEL";
    
    @RBEntry("Impossible de rechercher {0} pour un contexte particulier.")
    @RBComment("Message alerting type can not be searched with single context. ")
    public static final String DENY_SINGLE_CONTEXT_SEARCH = "DENY_SINGLE_CONTEXT_SEARCH";
}
