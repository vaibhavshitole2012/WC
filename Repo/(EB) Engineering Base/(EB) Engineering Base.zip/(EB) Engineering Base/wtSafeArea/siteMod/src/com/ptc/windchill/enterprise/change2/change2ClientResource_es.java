/* bcwti
 *
 * Copyright (c) 2010 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */
package com.ptc.windchill.enterprise.change2;

import wt.util.resource.*;

@RBUUID("com.ptc.windchill.enterprise.change2.change2ClientResource")
public final class change2ClientResource_es extends WTListResourceBundle {
   /**
    *
    * This file contains all the strings used by the DCA based Change Management clients
    *
    * ##############################################################################
    *
    * Object class names
    *
    * ##############################################################################
    **/
   @RBEntry("Variación")
   @RBComment("see wt.change2.change2ModelRB:WTVariance key")
   public static final String PRIVATE_CONSTANT_0 = "VARIANCE";

   @RBEntry("Informe de problemas")
   @RBComment("The name of the object \"Problem Report\".")
   public static final String PRIVATE_CONSTANT_1 = "PROBLEM_REPORT";

   @RBEntry("Solicitud de cambio")
   @RBComment("The name of the object \"Change Request\".")
   public static final String PRIVATE_CONSTANT_2 = "CHANGE_REQUEST";

   @RBEntry("Notificación de cambio")
   @RBComment("The name of the object \"Change Notice\".")
   public static final String PRIVATE_CONSTANT_3 = "CHANGE_NOTICE";

   /**
    * ##############################################################################
    *
    * Legacy Strings used by the local search tooltips
    * @deprecated
    *
    * ##############################################################################
    **/
   @RBEntry("Mostrar página de información del informe de problemas")
   @RBComment("Tooltip for the info page action.")
   public static final String PRIVATE_CONSTANT_4 = "CHANGE_ISSUE_INFO_PAGE_TT";

   @RBEntry("Mostrar página de información de la notificación de cambio")
   @RBComment("Tooltip for the info page action.")
   public static final String PRIVATE_CONSTANT_5 = "CHANGE_ORDER_INFO_PAGE_TT";

   @RBEntry("Mostrar página de información de la solicitud de cambio")
   @RBComment("Tooltip for the info page action.")
   public static final String PRIVATE_CONSTANT_6 = "CHANGE_REQUEST_INFO_PAGE_TT";

   @RBEntry("Mostrar página de información del informe de problemas")
   @RBComment("Tooltip for the info page action.")
   public static final String PRIVATE_CONSTANT_7 = "PR_DETAIL_TT";

   @RBEntry("Mostrar página de información de la solicitud de cambio")
   @RBComment("Tooltip for the info page action.")
   public static final String PRIVATE_CONSTANT_8 = "ECR_DETAIL_TT";

   @RBEntry("Mostrar página de información de la notificación de cambio")
   @RBComment("Tooltip for the info page action.")
   public static final String PRIVATE_CONSTANT_9 = "ECN_DETAIL_TT";

   @RBEntry("Mostrar página de información de la propuesta de cambio")
   @RBComment("Tooltip for the info page action.")
   public static final String PRIVATE_CONSTANT_10 = "CHANGE_PROPOSAL_INFO_TT";

   @RBEntry("Mostrar página de información de la tarea")
   @RBComment("Tooltip for the info page action.")
   public static final String PRIVATE_CONSTANT_11 = "CHANGE_ACTIVITY_INFO_TT";

   @RBEntry("Mostrar página de información de investigación de cambios")
   @RBComment("Tooltip for the info page action.")
   public static final String PRIVATE_CONSTANT_12 = "CHANGE_INVESTIGATION_INFO_TT";

   @RBEntry("Mostrar página de información de la actividad de análisis")
   @RBComment("Tooltip for the info page action.")
   public static final String PRIVATE_CONSTANT_13 = "ANALYSIS_ACTIVITY_INFO_TT";

   @RBEntry("Asociar cambios")
   @RBComment("The Associated Problem Reports step in the wizard.")
   public static final String PRIVATE_CONSTANT_14 = "RELATED_CHANGES";

   /**
    * ##############################################################################
    *
    * Picker titles
    *
    * ##############################################################################
    **/
   @RBEntry("Buscar incidencias y variaciones asociadas")
   @RBComment("The title for the action \"Add Associated Changes\"")
   public static final String PRIVATE_CONSTANT_15 = "FIND_ASSOCIATED_CHANGEISSUES";

   @RBEntry("Buscar solicitudes de cambio asociadas")
   @RBComment("The title for the action \"Add Associated Changes\"")
   public static final String PRIVATE_CONSTANT_16 = "FIND_ASSOCIATED_CHANGEREQUESTS";

   @RBEntry("Buscar elementos finales afectados")
   @RBComment("The title for the action \"Add Affected End Items\"")
   public static final String PRIVATE_CONSTANT_17 = "FIND_AFFECTED_END_ITEMS";

   @RBEntry("Buscar objetos afectados")
   @RBComment("The title for the action \"Add Affected Objects\"")
   public static final String PRIVATE_CONSTANT_18 = "FIND_AFFECTED_DATA";

   @RBEntry("Buscar objetos resultantes")
   @RBComment("The title for the action \"Add Resulting Objects\"")
   public static final String PRIVATE_CONSTANT_19 = "FIND_RESULTING_DATA";

   @RBEntry("Buscar notificaciones de cambio")
   @RBComment(" The title for the Change Notice Summary Report input page (from the Cognos reports page).")
   public static final String PRIVATE_CONSTANT_20 = "FIND_CHANGE_NOTICES";

   @RBEntry("Buscar solicitudes de cambio")
   @RBComment(" The title for the Change Request Summary Report input page (from the Cognos reports page).")
   public static final String PRIVATE_CONSTANT_21 = "FIND_CHANGE_REQUESTS";

   @RBEntry("Buscar variaciones")
   @RBComment(" The title for the Variance Summary Report input page (from the Cognos reports page).")
   public static final String PRIVATE_CONSTANT_22 = "FIND_VARIANCES";

   @RBEntry("Buscar informes de problemas")
   @RBComment(" The title for the Problem Reports Summary Report input page (from the Cognos reports page).")
   public static final String PRIVATE_CONSTANT_23 = "FIND_PROBLEM_REPORTS";

   /**
    * ##############################################################################
    *
    * Table titles
    *
    * ##############################################################################
    **/
   @RBEntry("Objetos afectados")
   @RBComment("The Affected Items table title.")
   public static final String PRIVATE_CONSTANT_24 = "AFFECTED_ITEMS_TABLE";

   @RBEntry("Directivas de cambio con impacto")
   @RBComment("The Impacting Directive table title.")
   public static final String PRIVATE_CONSTANT_25 = "IMPACTING_ITEMS_TABLE";

   @RBEntry("Acciones de cambio")
   @RBComment("The Change Actions table.")
   public static final String PRIVATE_CONSTANT_26 = "CHANGE_ACTIONS_TABLE";

   @RBEntry("Objetos resultantes")
   @RBComment("The Resulting Items table title.")
   public static final String PRIVATE_CONSTANT_27 = "RESULTING_ITEMS_TABLE";

   @RBEntry("Revisar objetos resultantes")
   @RBComment("The table title for the review resulting objects table on a review workflow task.")
   public static final String REVIEW_TASK_RESULTING_ITEMS_TABLE = "REVIEW_TASK_RESULTING_ITEMS_TABLE";   

   @RBEntry("Completar objetos resultantes")
   @RBComment("The table title for the complete resulting objects table on a workflow task.")
   public static final String COMPLETE_TASK_RESULTING_ITEMS_TABLE = "COMPLETE_TASK_RESULTING_ITEMS_TABLE";
   
   @RBEntry("Objetos afectados")
   @RBComment("The Affected Objects (change request, problem report, Variance) table title.")
   public static final String PRIVATE_CONSTANT_28 = "AFFECTED_DATA_TABLE";

   @RBEntry("Elementos finales afectados")
   @RBComment("The Affected End Items table title.")
   public static final String PRIVATE_CONSTANT_29 = "AFFECTED_END_ITEMS_TABLE";

   @RBEntry("Resumen de cambios")
   @RBComment("Affected and Resulting Data for all Change Tasks on a Change Notice")
   public static final String CHANGE_NOTICE_SUMMARY_TABLE = "CHANGE_NOTICE_SUMMARY_TABLE";

   @RBEntry("Resumen de cambios de auditoría")
   @RBComment("The table title for the audit change summary table.")
   public static final String AUDIT_CHANGE_NOTICE_SUMMARY_TABLE = "AUDIT_CHANGE_NOTICE_SUMMARY_TABLE";   

   @RBEntry("Incidencias y variaciones asociadas")
   @RBComment("The table title for the Related Problem Reports (as well as other issues) and Variances.")
   public static final String RELATED_CHANGEISSUES_TABLE = "RELATED_CHANGEISSUES_TABLE";

   @RBEntry("Solicitudes de cambio asociadas")
   @RBComment("The table title for the related change requests.")
   public static final String RELATED_CHANGEREQUESTS_TABLE = "RELATED_CHANGEREQUESTS_TABLE";

   @RBEntry("Incidencias y variaciones")
   @RBComment("The table title for the Related Problem Reports (and other issues) and Variances.")
   public static final String PRIVATE_CONSTANT_30 = "CHANGE_ISSUES_TABLE";

   @RBEntry("Solicitudes de cambio")
   @RBComment("The plural name of the object \"Change Request\".")
   public static final String PRIVATE_CONSTANT_31 = "CHANGE_REQUESTS_TABLE";

   @RBEntry("Notificaciones de cambio")
   @RBComment("The plural name of the object \"Change Notice\".")
   public static final String PRIVATE_CONSTANT_32 = "CHANGE_NOTICES_TABLE";

   @RBEntry("Afectados por notificaciones de cambio")
   @RBComment("The table title for the Affected by Change Notices info page table")
   public static final String PRIVATE_CONSTANT_33 = "AFFECTED_BY_CHANGE_NOTICES_TABLE";

   @RBEntry("Debidos a notificaciones de cambio")
   @RBComment("The table title for the Resulting from Change Notices info page table")
   public static final String PRIVATE_CONSTANT_34 = "RESULTING_FROM_CHANGE_NOTICES_TABLE";

   @RBEntry("Conjuntos de anotaciones")
   @RBComment("The table title for the Annotation Set table")
   public static final String PRIVATE_CONSTANT_35 = "ANNOTATION_SET_TABLE";

   @RBEntry("Atributos")
   @RBComment("The table title for the Variance Analysis attribute table.")
   public static final String VARIANCE_ANALYSIS_TABLE = "VARIANCE_ANALYSIS_TABLE";

   @RBEntry("Atributos")
   @RBComment("The table tile for the Attributes table from the information pages.")
   public static final String PRIVATE_CONSTANT_36 = "ATTRIBUTES_TABLE";

   @RBEntry("Cambios sin incorporar")
   @RBComment("The table title for the Unincorporated changes table")
   public static final String PRIVATE_CONSTANT_37 = "UNINCORPORATED_CHANGE_TABLE";

   @RBEntry("Propuestas e investigaciones")
   @RBComment("The table title for the Change Proposals and Change Investigations")
   public static final String PRIVATE_CONSTANT_38 = "PROPOSALS_AND_INVESTIGATIONS_TABLE";

   @RBEntry("Actividades de análisis")
   @RBComment("The table title for Analysis Activities")
   public static final String PRIVATE_CONSTANT_39 = "ANALYSIS_ACTIVITIES_TABLE";

   @RBEntry("Notificación de cambio")
   @RBComment("The column name for the Change Notice Id")
   public static final String HC_CHANGENOTICE = "HC_CHANGENOTICE";

   @RBEntry("Estado")
   @RBComment("The column name for the Change Notice State")
   public static final String HC_CHANGENOTICE_STATE = "HC_CHANGENOTICE_STATE";

   @RBEntry("Tarea de cambio")
   @RBComment("The column name for the Change Task Id")
   public static final String HC_CHANGETASK = "HC_CHANGETASK";

   @RBEntry("Plan de incorporación")
   @RBComment("The column name for Incorporation Plan")
   public static final String HC_INCORPOPTION = "HC_INCORPOPTION";

   @RBEntry("Revisión planificada")
   @RBComment("The column name for Planned Revision")
   public static final String HC_INCORPREVISION = "HC_INCORPREVISION";

   @RBEntry("Incidencias")
   @RBComment("The title for the All Open Issues table.")
   public static final String OPEN_ISSUES_TITLE = "OPEN_ISSUES_TITLE";

   @RBEntry("Solicitudes de cambio")
   @RBComment("The title for the All Open Change Requests table.")
   public static final String OPEN_CHANGE_REQUESTS_TITLE = "OPEN_CHANGE_REQUESTS_TITLE";

   @RBEntry("Notificaciones de cambio")
   @RBComment("The title for the All Open Change Notices table.")
   public static final String OPEN_CHANGE_NOTICES_TITLE = "OPEN_CHANGE_NOTICES_TITLE";

   @RBEntry("Variaciones")
   @RBComment("The title for the All Open Variances table.")
   public static final String OPEN_VARIANCES_TITLE = "OPEN_VARIANCES_TITLE";

   @RBEntry("Una de las formas de crear un informe de problemas es navegar hasta la página de información de un objeto que se puede cambiar, como por ejemplo un artículo o un documento, y seleccionar \"Nuevo informe de problemas\" en la lista de acciones. Para obtener más información, consulte la ayuda en línea disponible en la tabla \"Informes de problemas\".")
   @RBComment("Informational text to create problem reports.")
   public static final String OPEN_PROBLEM_REPORTS_HELP = "OPEN_PROBLEM_REPORTS_HELP";

   @RBEntry("Una de las formas de crear una notificación de cambio es navegar hasta la página de información de la solicitud de cambio y seleccionar \"Nueva notificación de cambio\" en la lista de acciones. Si desea obtener más información, consulte la ayuda en línea disponible en la tabla \"Notificaciones de cambio\".")
   @RBComment("Informational text to create change notices.")
   public static final String OPEN_CHANGE_NOTICES_HELP = "OPEN_CHANGE_NOTICES_HELP";

   @RBEntry("Una de las formas de crear una solicitud de cambio es navegar hasta la pagina de información de un informe de problemas y seleccionar \"Nueva solicitud de cambio\" en la lista de acciones. Si desea obtener más información, consulte la ayuda en línea disponible en la tabla \"Solicitudes de cambio\".")
   @RBComment("Informational text to create requests notices.")
   public static final String OPEN_CHANGE_REQUESTS_HELP = "OPEN_CHANGE_REQUESTS_HELP";

   @RBEntry("Una de las formas de crear una variación es navegar hasta la página de información de un objeto que se puede cambiar, como por ejemplo un artículo o un documento, y seleccionar \"Nueva variación\" en la lista de acciones. Para obtener más información, consulte la ayuda en línea disponible en la tabla \"Variaciones\".")
   @RBComment("Informational text to create variances.")
   public static final String OPEN_VARIANCES_HELP = "OPEN_VARIANCES_HELP";

   @RBEntry("Requisitos relacionados")
   @RBComment("Title for the fulfill requirements table")
   public static final String PRIVATE_CONSTANT_40 = "FULFILL_CHANGEACTIONS_TABLE";

   @RBEntry("Instantánea de cambios")
   @RBComment("Title for the Change Baseline report tree")
   public static final String CHANGE_BASELINE_TABLE = "CHANGE_BASELINE_TABLE";


   /**
    * ##############################################################################
    *
    * Table views
    *
    * ##############################################################################
    */

   @RBEntry("Informes de problemas")
   public static final String PROBLEM_REPORT_TABLEVIEW_NAME = "PROBLEM_REPORT_TABLEVIEW_NAME";

   @RBEntry("Vista que sólo muestra informes de problemas.")
   public static final String PROBLEM_REPORT_TABLEVIEW_DESCRIPTION = "PROBLEM_REPORT_TABLEVIEW_DESCRIPTION";

   @RBEntry("Variaciones")
   public static final String VARIANCE_TABLEVIEW_NAME = "VARIANCE_TABLEVIEW_NAME";

   @RBEntry("Vista que sólo muestra variaciones.")
   public static final String VARIANCE_TABLEVIEW_DESCRIPTION = "VARIANCE_TABLEVIEW_DESCRIPTION";

   @RBEntry("Intención del cambio")
   public static final String CHANGE_INTENT = "CHANGE_INTENT";

   @RBEntry("Contenido de liberación")
   public static final String RELEASE_CONTENT = "RELEASE_CONTENT";

   @RBEntry("Artículos afectados")
   public static final String AFFECTED_PARTS = "AFFECTED_PARTS";

   @RBEntry("Por defecto")
   @RBComment("The default table view name for the Change Baseline report")
   public static final String CHANGE_BASELINE_REPORT_TABLE_VIEW_DEFAULT_NAME = "CHANGE_BASELINE_REPORT_TABLE_VIEW_DEFAULT_NAME";

   @RBEntry("Vista por defecto")
   @RBComment("The default table view description for the Change Baseline report")
   public static final String CHANGE_BASELINE_REPORT_TABLE_VIEW_DEFAULT_DESC = "CHANGE_BASELINE_REPORT_TABLE_VIEW_DEFAULT_DESC";

   /**
    * ##############################################################################
    *
    * Table columns specific to change
    *
    * ##############################################################################
    **/
   @RBEntry("With suppliers")
   @RBComment("The label for the disposition column.")
   public static final String ONORDERDISPOSITION = "ONORDERDISPOSITION";

   @RBEntry("In warehouse")
   @RBComment("The label for the disposition column.")
   public static final String INVENTORYDISPOSITION = "INVENTORYDISPOSITION";

   @RBEntry("In production")
   @RBComment("The label for the disposition column.")
   public static final String FINISHEDDISPOSITION = "FINISHEDDISPOSITION";

   @RBEntry("With customer")
   @RBComment("The label for the disposition column.")
   public static final String WITHCUSTOMERDISPOSITION = "WITHCUSTOMERDISPOSITION";

   @RBEntry("In assembled parts")
   @RBComment("The label for the disposition column.")
   public static final String INASSEMBLEDPARTSDISPOSITION = "INASSEMBLEDPARTSDISPOSITION";

   @RBEntry("Comentarios de resolución")
   @RBComment("The label for the disposition comment column.")
   public static final String DISPOSITIONCOMMENTS = "DISPOSITIONCOMMENTS";

   @RBEntry("Cantidad aprobada")
   @RBComment("The label for Approved Quantity column.")
   public static final String APPROVEDQUANTITY = "APPROVEDQUANTITY";

   @RBEntry("Comentarios")
   @RBComment("Label to be used in the Table Views")
   public static final String CHANGE_LINK_DESCRIPTION = "CHANGE_LINK_DESCRIPTION";

   @RBEntry("Parámetros de tabla")
   @RBComment("Label used in the table views. This column is a hidden parameter column.")
   public static final String CHANGE_TABLE_DATA_COLUMN = "CHANGE_TABLE_DATA_COLUMN";

   @RBEntry("Cambio sin incorporar")
   @RBComment("Label used in the table views. This column is a hidden parameter column.")
   public static final String INCORP_HANGINGCHANGE_TABLE_DATA_COLUMN = "INCORP_HANGINGCHANGE_TABLE_DATA_COLUMN";

   @RBEntry("Objetos afectados")
   @RBComment("This column is used to filter the display of affected and resulting objects. This column is only displayed on the filter step of the table view wizard.")
   public static final String IMPACTING_OBJECTS_COLUMN = "IMPACTING_OBJECTS_COLUMN";

   @RBEntry("Relación")
   @RBComment("This column is used to display the link relation ship of the affected or resulting objects.")
   public static final String RELATIONSHIP = "RELATIONSHIP";

   @RBEntry("Nombre de tarea")
   @RBComment("This column is to display the name of the change task on a affected or resulting link.")
   public static final String TASK_NAME_COLUMN = "TASK_NAME_COLUMN";

   @RBEntry("Número de tarea")
   @RBComment("This column is to display the number of the change task on a affected or resulting link.")
   public static final String TASK_NUMBER_COLUMN = "TASK_NUMBER_COLUMN";
   
   @RBEntry("Estado de tarea")
   @RBComment("This column is to display the state of the change task on a affected or resulting link.")
   public static final String TASK_STATE_COLUMN = "TASK_STATE_COLUMN";  

   @RBEntry("Estatus afectado")
   @RBComment("This column is to indicate if the Affected Status is shown for any item which is added as a resulting object or unincorporated change on a change task but does not have a corresponding equal or predecessor revision as an affected object.")
   public static final String AFFECTED_STATUS = "AFFECTED_STATUS";

   @RBEntry("No hay objetos afectados")
   @RBComment("A message is to indicate if the Affected Status is shown for any item which is added as a resulting object or unincorporated change on a change task but does not have a corresponding equal or predecessor revision as an affected object.")
   public static final String AFFECTED_STATUS_MSG = "AFFECTED_STATUS_MSG";

   @RBEntry("Estado de destino")
   @RBComment("This column is to indicate if the Change target state of the change task resulting objects.")
   public static final String CHANGE_TARGET_STATE = "CHANGE_TARGET_STATE";

   @RBEntry("Nueva versión")
   @RBComment("This column is to indicate if the new version of the successor object in the Change Baseline report table.")
   public static final String NEW_VERSION = "NEW_VERSION";

   @RBEntry("Autorización planificada")
   @RBComment("This column is to indicate if the planned authorization of the successor object in the Change Baseline report table.")
   public static final String PLANNED_AUTHORIZATION = "PLANNED_AUTHORIZATION";

   @RBEntry("Acción")
   @RBComment("This column is to indicate if the action of the successor object in the Change Baseline report table.")
   public static final String PLANNED_ACTION = "PLANNED_ACTION";
   
   @RBEntry("Destino de liberación")
   @RBComment("This column is to indicate the change management transition for the resulting object.")
   public static final String CHANGE_TARGET_TRANSITION = "CHANGE_TARGET_TRANSITION";
   
   @RBEntry("Encargados con tareas abiertas")
   @RBComment("Set of columns intended to show the users that have open workflow tasks on a change task")
   public static final String CHANGE_TASK_ASSIGNEES = "CHANGE_TASK_ASSIGNEES";

   @RBEntry("Identidad")
   @RBComment("This column is to display the attributes that uniquely identify an object.")
   public static final String IDENTITY_COLUMN_NAME = "IDENTITY_COLUMN_NAME";

   /**
    * ##############################################################################
    *
    * The action types for the Successor objects in the Change Baseline report
    *
    * ##############################################################################
    */

    @RBEntry("Añadir")
    @RBComment("Indicates that the object was added.")
    public static final String PLANNED_ACTION_TYPE_ADD = "PLANNED_ACTION_TYPE_ADD";

    @RBEntry("Borrar")
    @RBComment("Indicates that object was removed was removed.")
    public static final String PLANNED_ACTION_TYPE_REMOVE = "PLANNED_ACTION_TYPE_REMOVE";

    @RBEntry("Crear nueva versión")
    @RBComment("Indicates that the successor object was revised.")
    public static final String PLANNED_ACTION_TYPE_REVISE = "PLANNED_ACTION_TYPE_REVISE";

   /**
    * ##############################################################################
    *
    * labels for impacting objects
    *
    * ##############################################################################
    **/

   @RBEntry("Objetos afectados")
   @RBComment("This label is used to filter affected objects.")
   public static final String SHOW_AFFECTED_OBJECTS = "SHOW_AFFECTED_OBJECTS";

   @RBEntry("Objetos resultantes")
   @RBComment("This label is used to filter resulting objects.")
   public static final String SHOW_RESULTING_OBJECTS = "SHOW_RESULTING_OBJECTS";

   @RBEntry("Objetos afectados/resultantes")
   @RBComment("This label is used to filter affected and resulting objects.")
   public static final String SHOW_AFFECTED_RESULTING_OBJECTS = "SHOW_AFFECTED_RESULTING_OBJECTS";


   /**
    * ##############################################################################
    *
    * labels specific to annotation
    *
    * ##############################################################################
    **/
   @RBEntry("Objeto afectado")
   @RBComment("Affected data label.")
   public static final String PRIVATE_CONSTANT_41 = "AFFECTED_DATA_LABEL";

   @RBEntry("Conjuntos de anotaciones")
   @RBComment("The label for related affected data column.")
   public static final String ANNOTATION_SET_LABEL = "ANNOTATION_SET_LABEL";

   @RBEntry("Lista de conjuntos de anotaciones")
   @RBComment("The label for related affected data column.")
   public static final String PRIVATE_CONSTANT_42 = "ANNOTATION_SET_LIST_LABEL";

   /**
    * #######################################################
    *
    * Owning Change Object
    *
    * #######################################################
    **/
   @RBEntry("Notificación de cambio")
   @RBComment("Label for the Owning Change Notice")
   public static final String OWNING_CHANGE_NOTICE = "OWNING_CHANGE_NOTICE";

   @RBEntry("Nombre de notificación de cambio")
   @RBComment("Label for the Owning Change Notice Name")
   public static final String OWNING_CHANGE_NOTICE_NAME = "OWNING_CHANGE_NOTICE_NAME";

   @RBEntry("Solicitud de cambio")
   @RBComment("Label for the Owning Change Request")
   public static final String OWNING_CHANGE_REQUEST = "OWNING_CHANGE_REQUEST";

   @RBEntry("Nombre de solicitud de cambio")
   @RBComment("Label for the Owning Change Request Name")
   public static final String OWNING_CHANGE_REQUEST_NAME = "OWNING_CHANGE_REQUEST_NAME";

   @RBEntry("Propuesta de cambio")
   @RBComment("Label for the Owning Change Proposal")
   public static final String OWNING_CHANGE_PROPOSAL = "OWNING_CHANGE_PROPOSAL";

   @RBEntry("Nombre de propuesta de cambio")
   @RBComment("Label for the Owning Change Proposal Name")
   public static final String OWNING_CHANGE_PROPOSAL_NAME = "OWNING_CHANGE_PROPOSAL_NAME";

   @RBEntry("Investigación de cambio")
   @RBComment("Label for the Owning Change Investigation")
   public static final String OWNING_CHANGE_INVESTIGATION = "OWNING_CHANGE_INVESTIGATION";

   @RBEntry("Nombre de investigación de cambio")
   @RBComment("Label for the Owning Change Investigation Name")
   public static final String OWNING_CHANGE_INVESTIGATION_NAME = "OWNING_CHANGE_INVESTIGATION_NAME";

   @RBEntry("Objeto de cambio")
   @RBComment("Label for the Owning Change Object")
   public static final String OWNING_CHANGE_OBJECT = "OWNING_CHANGE_OBJECT";

   @RBEntry("Nombre de objeto de cambio")
   @RBComment("Label for the Owning Change Object Name")
   public static final String OWNING_CHANGE_OBJECT_NAME = "OWNING_CHANGE_OBJECT_NAME";

   @RBEntry("(No disponible)")
   @RBComment("Label for an object that is unavailable")
   public static final String UNAVAILABLE = "UNAVAILABLE";

   /**
    * #######################################################
    *
    * Implementation Plan Table
    *
    * #######################################################
    **/
   @RBEntry("Plan de implementación")
   @RBComment("The title of the Implementaiton Plan")
   public static final String IMPLEMENTATION_PLAN_TABLE = "IMPLEMENTATION_PLAN_TABLE";

   @RBEntry("Icono de edición")
   @RBComment("Selectable Column name")
   public static final String IMPLEMENTATION_PLAN_TABLE_ICON_ACTIONS = "IMPLEMENTATION_PLAN_TABLE_ICON_ACTIONS";

   @RBEntry("Revisión")
   @RBComment("Revision Column name")
   public static final String IMPLEMENTATION_PLAN_TABLE_REVISION = "IMPLEMENTATION_PLAN_TABLE_REVISION";

   @RBEntry("Número")
   @RBComment("Number Column name")
   public static final String IMPLEMENTATION_PLAN_TABLE_NUMBER = "IMPLEMENTATION_PLAN_TABLE_NUMBER";

   @RBEntry("Nombre")
   @RBComment("Name Column name")
   public static final String IMPLEMENTATION_PLAN_TABLE_NAME = "IMPLEMENTATION_PLAN_TABLE_NAME";

   @RBEntry("Estado")
   @RBComment("State Column name")
   public static final String IMPLEMENTATION_PLAN_TABLE_STATE = "IMPLEMENTATION_PLAN_TABLE_STATE";

   @RBEntry("Encargado")
   @RBComment("Assignee Column name")
   public static final String IMPLEMENTATION_PLAN_TABLE_LAST_ROLE_ASSIGNEE = "IMPLEMENTATION_PLAN_TABLE_LAST_ROLE_ASSIGNEE";

   @RBEntry("Revisor")
   @RBComment("Reviewer Column name")
   public static final String IMPLEMENTATION_PLAN_TABLE_LAST_ROLE_REVIEWER = "IMPLEMENTATION_PLAN_TABLE_LAST_ROLE_REVIEWER";

   @RBEntry("Fecha de vencimiento estimada")
   @RBComment("Need DateColumn name")
   public static final String IMPLEMENTATION_PLAN_TABLE_NEED_DATE = "IMPLEMENTATION_PLAN_TABLE_NEED_DATE";

   @RBEntry("Secuencia")
   @RBComment("Change task sequence column name")
   public static final String IMPLEMENTATION_PLAN_TABLE_SEQUENCE = "IMPLEMENTATION_PLAN_TABLE_SEQUENCE";

   @RBEntry("Estatus de implementación")
   @RBComment("Label for Implementation Status column in the implementation plan table")
   public static final String IMPLEMENTATION_PLAN_TABLE_STATUS = "IMPLEMENTATION_PLAN_TABLE_STATUS";

   /**
    * Added to resolve compile issue
    **/
   @RBEntry("Plan de implementación")
   @RBComment("Change Notice table header.")
   public static final String CHANGE_NOTICE_TABLE_HEADER = "CHANGE_NOTICE_TABLE_HEADER";

   /**
    * ########################################################
    *
    * Revise Client Strings (ChangeItem Reissue Dialog)
    *
    * ########################################################
    **/
   @RBEntry("Impacto")
   @RBComment("The impact of the revise.  Either Modify of Proceed")
   public static final String REVISE_IMPACT = "REVISE_IMPACT";

   @RBEntry("Nueva revisión")
   @RBComment("The label for the new revision")
   public static final String NEW_REVISION = "NEW_REVISION";

   @RBEntry("Se ha producido un error durante la revisión del objeto de cambio")
   @RBComment("The message header (ATTENTION:) is already added.")
   public static final String REVISE_ERROR_HEADER = "REVISE_ERROR";

   @RBEntry("Objeto de cambio")
   @RBComment("The label for the change item Identity")
   public static final String CHANGE_ITEM_IDENTITY = "CHANGE_ITEM_IDENTITY";

   /**
    * #########################################################
    *
    * Change Status Column Strings
    *
    * #########################################################
    **/
   @RBEntry("Estatus del cambio")
   @RBComment("The column header for the change status column.")
   public static final String CHANGE_STATUS_COLUMN = "statusFamily_Change";

   /**
    * #########################################################
    *
    * Specialized Attribute handling messages.
    *
    * #########################################################
    **/
   @RBEntry("El Propietario de la variación no es válido.")
   @RBComment("The message when the user picked a user but this uid is not valid in the system.")
   public static final String VARIANCEOWNER_NOTFOUND = "VarianceOwner_NotFound";

   @RBEntry("No se puede crear la variación.")
   public static final String VARIANCE_CREATE_CANNOTCREATE = "Variance_Create_CanNotCreate";

   @RBEntry("Borrar los comentarios de resolución")
   @RBComment("Text display value for the check box to clear disposition comments.")
   public static final String CLEAR_DISPOSITION_COMMENTS = "CLEAR_DISPOSITION_COMMENTS";

   /**
    * #########################################################
    *
    * Propagation Message Strings
    *
    * #########################################################
    **/
   @RBEntry("Propagar la información desde el informe de problemas")
   @RBComment("Option label to indicate propagation of meta-data, affected data, etc.from a Problem Report to a Change Request")
   public static final String PROPAGATE_DATA_FROM_PR_LABEL = "PropagateProblemReport_label";

   @RBEntry("Propagar la información desde la variación")
   @RBComment("Option label to indicate propagation of meta-data, affected data, etc.from a Variance to a Change Request")
   public static final String PROPAGATE_DATA_FROM_VARIANCE_LABEL = "PropagateVariance_label";

   @RBEntry("Propagar la información desde la solicitud de cambio")
   @RBComment("Option label to indicate propagation of meta-data, affected data, etc.from a Change Request to a Change Notice.")
   public static final String PROPAGATE_DATA_FROM_CR_LABEL = "PropagateChangeRequest_label";

   /**
    * #########################################################
    *
    * Wizard Error messages.
    *
    * #########################################################
    **/
   @RBEntry("No se han podido procesar correctamente los Objetos afectados.")
   public static final String AFFECTED_ITEMS_PROCESSING_ERROR = "AffectedItems_Processing_Error";

   @RBEntry("No se han podido procesar los Objetos afectados.")
   public static final String AFFECTED_ITEMS_PROCESSING_ERRORHEADER = "AffectedItems_Processing_ErrorHeader";

   @RBEntry("No se han podido procesar correctamente los elementos finales afectados.")
   public static final String AFFECTED_END_ITEMS_PROCESSING_ERROR = "AffectedEndItems_Processing_Error";

   @RBEntry("No se han podido procesar los elementos finales afectados.")
   public static final String AFFECTED_END_ITEMS_PROCESSING_ERRORHEADER = "AffectedEndItems_Processing_ErrorHeader";

   @RBEntry("No se han podido procesar correctamente los Objetos resultantes.")
   public static final String RESULTING_ITEMS_PROCESSING_ERROR = "ResultingItems_Processing_Error";

   @RBEntry("No se han podido procesar los Objetos resultantes.")
   public static final String RESULTING_ITEMS_PROCESSING_ERRORHEADER = "ResultingItems_Processing_ErrorHeader";

   @RBEntry("Se ha producido un error al crear las versiones derivadas nuevas. Póngase en contacto con el administrador.")
   public static final String NEWONEOFFVERISON_ACTION_CANNOT_CREATE = "NewOneOffVersion_Action_CannotCreate";

   @RBEntry("<b>ATENCIÓN</b>: Error al crear las nuevas versiones derivadas.")
   @RBComment("The <b> tags are added to bold the attention as per UI message design.  This is using a Ext dialog which supports Bold tags.")
   public static final String NEWONEOFFVERSION_ACTION_HEADER_MSG = "NewOneOffVersion_Action_HeaderMsg";

   @RBEntry("El número de objetos no es válido: {0}\n\nEl primer mensaje recibido es:\n{1}")
   public static final String NEWONEOFFVERSION_ACTION_TOOMANYERRORS = "NewOneOffVersion_Action_TooManyErrors";

   @RBEntry("ATENCIÓN: No se ha podido definir la resolución.")
   @RBComment("Header message for the diposition dialog.")
   public static final String SETDISPOSITION_ACTION_HEADER_MSG = "SetDisposition_Action_HeaderMsg";

   @RBEntry("Ninguno de los objetos seleccionados es válido para esta operación.")
   @RBComment("Message when the action is launched and the objects are not applicable.")
   public static final String INVALIDOBJECTS = "InvalidObjects";

   @RBEntry("Solución propuesta")
   public static final String PRIVATE_CONSTANT_43 = "CHANGE_PROPOSEDCHANGES";

   @RBEntry("Póngase en contacto con el administrador.")
   public static final String CHANGEMANAGEMENT_PROCESSING_ERRORMSG = "ChangeManagement_Processing_ErrorMsg";

   @RBEntry("No se ha podido crear el informe de problemas.")
   public static final String CREATEPROBLEMREPORT_PROCESSING_ERROR = "CreateProblemReport_Processing_Error";

   @RBEntry("No se ha podido crear la variación.")
   public static final String CREATEVARIANCE_PROCESSING_ERROR = "CreateVariance_Processing_Error";

   @RBEntry("No se ha podido crear la solicitud de cambio.")
   public static final String CREATECHANGEREQUEST_PROCESSING_ERROR = "CreateChangeRequest_Processing_Error";

   @RBEntry("No se ha podido crear la plantilla de notificación de cambio.")
   public static final String CREATECHANGENOTICETEMPLATE_PROCESSING_ERROR = "CreateChangeNoticeTemplate_Processing_Error";
   
   @RBEntry("No se ha podido crear la plantilla de tarea de cambio.")
   public static final String CREATECHANGETASKTEMPLATE_PROCESSING_ERROR = "CreateChangeTaskTemplate_Processing_Error";
   
   @RBEntry("No se ha podido crear la notificación de cambio.")
   public static final String CREATECHANGENOTICE_PROCESSING_ERROR = "CreateChangeNotice_Processing_Error";

   @RBEntry("Se ha producido un error leve durante la creación de la notificación de cambio.")
   public static final String CreateChangeNotice_ImpactMatrix_ErrorHeader = "CreateChangeNotice_ImpactMatrix_ErrorHeader";

   @RBEntry("No se ha podido asociar la matriz de impacto del cambio con esta notificación de cambio. Póngase en contacto con su administrador para obtener más información.")
   public static final String CreateChangeNotice_ImpactMatrix_Error = "CreateChangeNotice_ImpactMatrix_Error";

   @RBEntry("No se ha podido crear la tarea de cambio.")
   public static final String CREATECHANGETASK_PROCESSING_ERROR = "CreateChangeTask_Processing_Error";

   @RBEntry("No se ha podido crear la propuesta de cambio.")
   public static final String CREATECHANGEPROPOSAL_PROCESSING_ERROR = "CreateChangeProposal_Processing_Error";

   @RBEntry("No se ha podido editar el informe de problemas.")
   public static final String EDITPROBLEMREPORT_PROCESSING_ERROR = "EditProblemReport_Processing_Error";

   @RBEntry("No se ha podido editar la variación.")
   public static final String EDITVARIANCE_PROCESSING_ERROR = "EditVariance_Processing_Error";

   @RBEntry("No se ha podido editar la solicitud de cambio.")
   public static final String EDITCHANGEREQUEST_PROCESSING_ERROR = "EditChangeRequest_Processing_Error";

   @RBEntry("No se ha podido editar la notificación de cambio.")
   public static final String EDITCHANGENOTICE_PROCESSING_ERROR = "EditChangeNotice_Processing_Error";
   
   @RBEntry("No se ha podido editar la plantilla de notificación de cambio.")
   public static final String EDITCHANGENOTICETEMPLATE_PROCESSING_ERROR = "EditChangeNoticeTemplate_Processing_Error";

   @RBEntry("No se ha podido editar la tarea de cambio.")
   public static final String EDITCHANGETASK_PROCESSING_ERROR = "EditChangeTask_Processing_Error";
   
   @RBEntry("No se ha podido editar la plantilla de tarea de cambio.")
   public static final String EDITCHANGETASKTEMPLATE_PROCESSING_ERROR = "EditChangeTaskTemplate_Processing_Error";

   @RBEntry("No se ha podido editar la propuesta de cambio.")
   public static final String EDITCHANGEPROPOSAL_PROCESSING_ERROR = "EditChangeProposal_Processing_Error";

   @RBEntry("No se ha podido borrar la tarea de cambio.")
   public static final String DELETECHANGETASK_PROCESSING_ERROR = "DeleteChangeTask_Processing_Error";

   @RBEntry("No se ha podido crear un plan de cambio.")
   public static final String CREATE_CHANGE_PLAN_ERROR = "CREATE_CHANGE_PLAN_ERROR";

   @RBEntry("ATENCIÓN: Faltan datos obligatorios.\n\nDebe haber al menos una tarea de cambio. Para continuar, cree una tarea de cambio.")
   public static final String IMPLEMENTATION_TABLE_NO_TASKS = "Implementation_Table_No_Tasks";

   @RBEntry("ATENCIÓN: Ha ocurrido algún problema.\n\nImposible encontrar la tabla del plan de implementación")
   public static final String UNABLE_TO_FIND_IMPL_TABLE = "Unable_To_Find_Impl_Table";

   @RBEntry("ATENCIÓN: La solicitud de cambio es obligatoria.\n\nEs necesario asociar a la notificación de cambio al menos una solicitud de cambio.")
   @RBComment("Message displayed when a Change Notice needs to have associated Change Request but it is missing")
   public static final String CHANGENOTICE_VALIDATE_ASSOCIATED_CR = "CHANGENOTICE_VALIDATE_ASSOCIATED_CR";

   @RBEntry("Atención: Acción no disponible\n\nPara crear una notificación de cambio es necesario crear una tarea de cambio.\nNo tiene permiso para crear tareas de cambio.")
   @RBComment("Error message for the Create Change Notice wizard when the user does not have access to create any Change Task types.")
   public static final String CREATECHANGENOTICE_NO_TASK_TYPES = "CreateChangeNotice_No_Task_Types";

   @RBEntry("No existe ninguna definición para {0} en el sistema de informes externo.")
   public static final String THIRDPARTYREPORTING_NODEFEXISTS_ERROR = "ThirdPartyReporting_NoDefExists_Error";

   @RBEntry("Este informe no existe: {0}")
   public static final String REPORT_NOTEXISTS_ERROR = "Report_NotExists_Error";

   @RBEntry("No existen informes para el tipo de objeto: {0}")
   public static final String REPORT_NOTSUPPORTED_ERROR = "Report_NotSupported_Error";

   @RBEntry("Relación no válida para {0}.")
   @RBComment("Message for validationg the association of an object for an AssociationConstrainable link when peforming a client action.")
   public static final String INVALID_ROLE_B_TYPE = "INVALID_ROLE_B_TYPE";

   @RBEntry("ATENCIÓN: falta información obligatoria \n\nSe necesita un número en la tarea de cambio. Edite la tarea de cambio para que incluya un número.")
   public static final String CHANGE_TASK_NUMBER_REQUIRED = "CHANGE_TASK_NUMBER_REQUIRED";

   @RBEntry("ATENCIÓN: falta información obligatoria \n\nSe necesita un número en la tarea de cambio por defecto. Edite la tarea de cambio por defecto para incluir un número.")
   public static final String DEFAULT_CHANGE_TASK_NUMBER_REQUIRED = "DEFAULT_CHANGE_TASK_NUMBER_REQUIRED";

   @RBEntry("No tiene permiso de creación en el contexto seleccionado.")
   @RBComment("Error message for the change create wizard context step.")
   public static final String NO_CREATE_FOR_CONTEXT = "NO_CREATE_FOR_CONTEXT";
   
   @RBEntry("Atención: No se puede crear la notificación de cambio.\n\nNo tiene permiso para crear uno o varios tipos de tarea de cambio en la plantilla de notificación de cambio seleccionada.")
   @RBComment("Error message for the Create Change Notice wizard when the user does not have access to create the Change Task types in the selected change notice template.")
   public static final String CREATE_CHANGE_NOTICE_FROM_TEMPLATE_NO_TASK_TYPES = "CREATE_CHANGE_NOTICE_FROM_TEMPLATE_NO_TASK_TYPES";

   /**
    * ##############################################################################
    *
    * Change Management specific workflow strings
    *
    * ##############################################################################
    **/
   @RBEntry("Crear notificación de cambio automáticamente")
   @RBComment("Label for the Automate the fast-track checkbox")
   public static final String AUTOMATE_FASTTRACK = "AUTOMATE_FASTTRACK";

   @RBEntry("ATENCIÓN: No se han rellenado algunos campos obligatorios.\n\nLos campos Responsable y Revisor son obligatorios, pero no se han especificado. Utilice el botón \"Buscar...\" para seleccionar un usuario válido.")
   public static final String CHANGETASK_VALIDATE_USER = "CHANGETASK_VALIDATE_USER";

   @RBEntry("CONFIRMACIÓN: Borrar tarea de cambio \n\n¿Desea borrar la tarea de cambio seleccionada?")
   @RBComment("Message displayed to ask user whether they are sure they wish to delete change tasks")
   public static final String CONFIRM_DELETE_CHANGE_TASK = "CONFIRM_DELETE_CHANGE_TASK";

   @RBEntry("Atención: No se puede continuar editando.\n\nEste objeto ha sido actualizado por otro usuario y el asistente se debe renovar. Se perderán los cambios realizados en esta sesión de edición.")
   @RBComment("Message displayed when the system detects a change is made.")
   public static final String CONFIRM_UPDATE_CHANGEITEM = "CONFIRM_UPDATE_CHANGEITEM";

   @RBEntry("No se puede liberar esta notificación de cambio porque están extraídos los siguientes objetos resultantes:")
   @RBComment("Special Instructions that appear in the \"Resolve Change Notice Conflicts\" Change Notice workflow task.  It is followed by a list of objects that are checked out.")
   public static final String PRERELEASE_VALIDATION_MSG = "PRERELEASE_VALIDATION_MSG";
   
   @RBEntry("No se puede liberar esta notificación de cambio porque han fallado las siguientes reglas empresariales:")
   @RBComment("Special Instructions that appear in the \"Resolve Change Notice Conflicts\" Change Notice workflow task.  It is followed by a list of business rules that failed.")
   public static final String BUSINESS_RULES_PRERELEASE_VALIDATION_MSG = "BUSINESS_RULES_PRERELEASE_VALIDATION_MSG";

   @RBEntry("CONFIRMACIÓN: ¿Desea navegar a otra página de esta tabla? Si lo hace, los datos que haya introducido en esta página se perderán.")
   @RBComment("Message displayed to ask user whether they are sure they wish to go to next page in a change table")
   public static final String CONFIRM_PAGING_CHANGE_TABLES = "CONFIRM_PAGING_CHANGE_TABLES";

   @RBEntry("La liberación de esta notificación de cambio no se puede realizar porque las siguientes tareas de cambio no están preparadas para la implementación:")
   @RBComment("Special Instructions that appear in the \"Assignee or Reviewer Conflicts\" Change Notice workflow task.  It is followed by a list of change tasks that are not ready for implementation.")
   public static final String IMPLEMENTATION_VALIDATION_MSG = "IMPLEMENTATION_VALIDATION_MSG";

   @RBEntry("La acción de recopilación ha fallado")
   @RBComment("Message for when none of the objects collected are valid for the table.")
   public static final String COLLECTED_FAILED = "COLLECTED_FAILED";

   @RBEntry("No se pueden añadir todos los objetos recopilados a esta ubicación.")
   @RBComment("Detailed message for when none of the objects collected are valid for the table.")
   public static final String COLLECTED_FAILED_MSG = "COLLECTED_FAILED_MSG";

   @RBEntry("La acción de recopilación ha fallado parcialmente")
   @RBComment("Message for when some of the objects collected are not valid for the table.")
   public static final String COLLECTED_PARTIALLY_FAILED = "COLLECTED_PARTIALLY_FAILED";

   @RBEntry("No se pueden añadir algunos de los objetos recopilados a esta ubicación:")
   @RBComment("Detailed message for when some of the objects collected are not valid for the table.")
   public static final String COLLECTED_PARTIALLY_FAILED_MSG = "COLLECTED_PARTIALLY_FAILED_MSG";

   @RBEntry("La adición de objetos de los que se ha creado una versión nueva ha fallado")
   @RBComment("Message for when the revise is successful but none of the objects revised are valid for the table.")
   public static final String REVISE_FAILED = "REVISE_FAILED";

   @RBEntry("Se ha creado una nueva versión de los objetos, pero éstos no se pueden añadir a esta ubicación.")
   @RBComment("Detailed message for when the revise is successful but none of the objects revised are valid for the table.")
   public static final String REVISE_FAILED_MSG = "REVISE_FAILED_MSG";

   @RBEntry("La adición de objetos de los que se ha creado una nueva versión ha fallado parcialmente")
   @RBComment("Message for when the revise is successful but some of the objects revised are invalid for the table.")
   public static final String REVISE_PARTIALLY_FAILED = "REVISE_PARTIALLY_FAILED";

   @RBEntry("Se ha creado una nueva versión de los objetos, pero algunos de ellos no se pueden añadir a esta ubicación:")
   @RBComment("Detailed message for when the revise is successful but some of the objects revised are invalid for the table.")
   public static final String REVISE_PARTIALLY_FAILED_MSG = "REVISE_PARTIALLY_FAILED_MSG";
   
   @RBEntry("No se ha encontrado destinos de liberación comunes")
   @RBComment("Message for when no common release targets are found when launching the release target table action.")
   public static final String NO_COMMON_RELEASE_TARGETS = "NO_COMMON_RELEASE_TARGETS";


   /**
    * ##############################################################################
    *
    * Submit Now / Submit Later messages
    *
    * ##############################################################################
    **/
   @RBEntry("<br><b>CONFIRMACIÓN</b>: ¿Desea enviar el objeto de cambio al sistema ahora?<br><br>Pulse en \"Enviar ahora\" para enviar el objeto de cambio ahora.<br>Pulse en \"Enviar más tarde\" para enviarlo en otro momento.")
   @RBComment("The string displayed to a user when they attempt to submit a change object where Submit Now is enabled.  The <br> and <b> tags are needed because this text is dumped directly into HTML content at runtime.  There are three distinct sentences.  the first is the header message.  The remaining two are the instructions.")
   public static final String SUBMIT_NOW_MESSAGE = "SUBMIT_NOW_MESSAGE";

   @RBEntry("Enviar ahora")
   @RBComment("Label for the JS Dojo button.  Equivalent of the \"Ok\" on a confirmation dialog.  See SUBMIT_NOW_MESSAGE above for context text.")
   public static final String SUBMIT_NOW_BUTTON = "SUBMIT_NOW_BUTTON";

   @RBEntry("Enviar más tarde")
   @RBComment("Label for the JS Dojo button.  Equivalent of the \"Cancel\" on a confirmation dialog.  See SUBMIT_NOW_MESSAGE above for context text.")
   public static final String SUBMIT_LATER_BUTTON = "SUBMIT_LATER_BUTTON";

   /**
    * ##############################################################################
    *
    * Change object attributes to support proper localization in client
    *
    * ##############################################################################
    **/
   @RBEntry("Complejidad")
   public static final String PRIVATE_CONSTANT_44 = "WTChangeOrder2.theChangeNoticeComplexity";

   @RBEntry("Categoría")
   public static final String THE_VARIANCE_CATEGORY = "WTVariance.theVarianceCategory";

   @RBEntry("Objetos <U class='mnemonic'>r</U>elacionados")
   @RBComment("Used for the text on the Related Objects third level nav menu.  The <U class=mnemonic> </U> tag should be put around the character that is the access key.")
   public static final String PRIVATE_CONSTANT_45 = "object.relatedDirItems.description";

   @RBEntry("r")
   @RBPseudo(false)
   @RBComment("Mnemonic for the Related Objects third level nav menu. This should be a character that matches the character surrounded by the <U class=mnemonic> </U> tag in the value line above.")
   public static final String PRIVATE_CONSTANT_46 = "object.relatedDirItems.hotkey";

   @RBEntry("Directivas <U class='mnemonic'>r</U>elacionadas")
   @RBComment("Used for the text on the Related Objects third level nav menu.  The <U class=mnemonic> </U> tag should be put around the character that is the access key.")
   public static final String PRIVATE_CONSTANT_49 = "object.relatedPartItems.description";

   @RBEntry("r")
   @RBPseudo(false)
   @RBComment("Mnemonic for the Related Objects third level nav menu. This should be a character that matches the character surrounded by the <U class=mnemonic> </U> tag in the value line above.")
   public static final String PRIVATE_CONSTANT_50 = "object.relatedPartItems.hotkey";

   @RBEntry("No se requiere revisión")
   @RBComment("Label for the Change Task no review required check box.")
   public static final String NO_REVIEW_REQUIRED = "NO_REVIEW_REQUIRED";

   @RBEntry("No es necesario")
   @RBComment("Label for the Change Task reviewer role when no review is required")
   public static final String ROLE_NOT_REQUIRED = "ROLE_NOT_REQUIRED";

   /**
    * ##############################################################################
    * Location field for Change Directive, Change Action
    * ##############################################################################
    **/
   @RBEntry("Ubicación")
   @RBComment("Label for the Location")
   public static final String LOCATION_LABEL = "LOCATION";

   @RBEntry("Directiva de cambio")
   @RBComment("Label for the Change Directive")
   public static final String CHANGE_DIRECTIVE = "CHANGE_DIRECTIVE";

   @RBEntry("Elemento de configuración")
   @RBComment("Label for the Configuration Item")
   public static final String CONFIGURATION_ITEM = "CONFIGURATION_ITEM";

   @RBEntry("Directivas de cambio con impacto")
   @RBComment("The table title for the Change Directives")
   public static final String CHANGE_DIRECTIVES_TABLE = "CHANGE_DIRECTIVES_TABLE";

   @RBEntry("Acciones de cambio relacionadas")
   @RBComment("Label for the related Change Actions")
   public static final String RELATEDCHANGEACTIONS = "RELATEDCHANGEACTIONS";

   @RBEntry("Efectividad")
   @RBComment("The column name for Effectivity")
   public static final String EFFECTIVITY = "EFFECTIVITY";

   @RBEntry("Estatus de cálculo")
   @RBComment("The column name for Calculation Status")
   public static final String CALCULATIONSTATUS = "CALCULATIONSTATUS";

   @RBEntry("Por defecto")
   @RBComment("change directive info page default table view name")
   public static final String CHANGE_DIRECTIVES_VIEW_DEFAULT_NAME = "CHANGE_DIRECTIVES_VIEW_DEFAULT_NAME";

   @RBEntry("Nombre de vista de tabla por defecto")
   @RBComment(" change directive info page description default table view name")
   public static final String CHANGE_DIRECTIVES_VIEW_DEFAULT_DESC = "CHANGE_DIRECTIVES_VIEW_DEFAULT_DESC";

   @RBEntry("Página de información")
   @RBComment(" change directive info page description default table view name")
   public static final String INFO_PAGE = "CHANGE_DIRECTIVES_VIEW_INFO_PAGE";


   @RBEntry("Programada")
   @RBComment(" status indicating that the task is scheduled not started")
   public static final String SCHEDULED = "SCHEDULED";

   @RBEntry("En curso")
   @RBComment(" status indicating that the task is in progress")
   public static final String INPROGRESS = "INPROGRESS";

   @RBEntry("Completada")
   @RBComment(" status indicating that the task has been completed")
   public static final String COMPLETED = "COMPLETED";

   @RBEntry("Vencida")
   @RBComment(" status indicating that the task is over due")
   public static final String OVERDUE = "OVERDUE";

   @RBEntry("Categoría de confirmación")
   public static final String CONFIRMATION_CATEGORY = "CONFIRMATION_CATEGORY";

   @RBEntry("Auditoría de confirmación")
   public static final String CONFIRMATION_AUDIT = "CONFIRMATION_AUDIT";
   
   @RBEntry("-- Seleccionar una plantilla --")
   public static final String SELECT_TEMPLATE = "SELECT_TEMPLATE";
   
   @RBEntry("-- No hay plantillas disponibles --")
   public static final String NO_TEMPLATES_AVAILABLE = "NO_TEMPLATES_AVAILABLE";
   
   @RBEntry("Plantilla")
   public static final String CHANGE_TEMPLATE_PICKER_LABEL = "CHANGE_TEMPLATE_PICKER_LABEL";

  @RBEntry("Fecha de vencimiento estimada")
  public static final String NEED_DATE = "NEED_DATE";
  
  @RBEntry("Tipo")
  public static final String TYPE = "TYPE";
  

  /**
   * ##############################################################################
   * Labels for Available attributes to avoid labels showing as duplicates
   * ##############################################################################
   **/
  @RBEntry("Complejidad de la notificación de cambio")
  public static final String CHANGE_ORDER_COMPLEXITY = "CHANGE_ORDER_COMPLEXITY";
  
  @RBEntry("Prioridad de la incidencia de cambio")
  public static final String ISSUE_PRIORITY = "ISSUE_PRIORITY";
  
  @RBEntry("Categoría de incidencia de cambio")
  public static final String ISSUE_CATEGORY = "ISSUE_CATEGORY";
  
  @RBEntry("Categoría")
  public static final String ISSUE_THECATEGORY = "ISSUE_THECATEGORY";
  
  @RBEntry("Prioridad de la solicitud de cambio")
  public static final String REQUEST_PRIORITY = "REQUEST_PRIORITY";
  
  @RBEntry("Categoría de solicitud de cambio")
  public static final String REQUEST_CATEGORY = "REQUEST_CATEGORY";
  
  @RBEntry("Categoría")
  public static final String REQUEST_THECATEGORY = "REQUEST_THECATEGORY"; 
  
  @RBEntry("Complejidad de solicitud de cambio")
  public static final String REQUEST_COMPLEXITY = "REQUEST_COMPLEXITY";

  @RBEntry("Propietario de la variación")
  public static final String VARIANCE_OWNER = "VARIANCE_OWNER";
  
  @RBEntry("Categoría de la variación")
  public static final String VARIANCE_CATEGORY = "VARIANCE_CATEGORY";

  /*Business rules resource bundle entry START*/
  @RBEntry("Validación de pre-liberación de cambio")
  @RBComment("Name of the rule set that will be used to display to the user when the workflow fails the check before releasing the change object.")
  public static final String CHANGE_PRE_RELEASE_RULESET_NAME = "CHANGE_PRE_RELEASE_RULESET_NAME";

  @RBEntry("Conjunto de reglas empresariales utilizado antes de la liberación de los objetos como parte del proceso de cambio")
  @RBComment("Description for the CHANGE PRE RELEASE RULESET.")
  public static final String CHANGE_PRE_RELEASE_RULESET_DESC = "CHANGE_PRE_RELEASE_RULESET_DESC";

  @RBEntry("Regla de extracción")
  @RBComment("Rule Validator to check no objects are checked out.")
  public static final String CHECK_OUT_VALIDATOR_RULE_NAME = "CHECK_OUT_VALIDATOR_RULE_NAME";

  @RBEntry("Esta regla determina si hay objetos extraídos. Si se detecta la presencia de objetos extraídos, la regla suspende. De lo contrario, aprueba.")
  @RBComment("Description for CHECK_OUT_VALIDATOR_RULE_NAME")
  public static final String CHECK_OUT_VALIDATOR_RULE_DESC = "CHECK_OUT_VALIDATOR_RULE_DESC";
  
  @RBEntry("Regla de destino de liberación")
  public static final String RELEASE_TARGET_RULE_NAME = "RELEASE_TARGET_RULE_NAME";

  @RBEntry("La regla de destino de liberación comprueba si el destino de liberación especificado en los objetos resultantes es válida para el estado actual del objeto resultante. La regla también es válida si no se ha especificado ningún destino de liberación para el objeto resultante y el destino de liberación del cambio es válido para el estado actual del objeto resultante")
  @RBComment("Description for Release Target Rule")
  public static final String RELEASE_TARGET_RULE_DESC = "RELEASE_TARGET_RULE_DESC";
  /*Business rules resource bundle entry END*/
  
  /* Workflow task tab names */
  @RBEntry("Objetos resultantes")
  @RBComment("Workflow task tab name for Change Task resulting objects")
  public static final String WFTASK_RESULTING_OBJECTS_TAB_NAME = "WFTASK_RESULTING_OBJECTS_TAB_NAME";
  
  @RBEntry("Impacto")
  @RBComment("Workflow task tab name for Change Request, Change Notice, Problem Report or Variance impacts")
  public static final String WFTASK_IMPACTS_TAB_NAME = "WFTASK_IMPACTS_TAB_NAME";

}
