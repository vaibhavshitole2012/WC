/* bcwti
 *
 * Copyright (c) 2010 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */
package com.ptc.windchill.wp.collection.forms;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.log4j.Logger;
import org.drools.core.util.StringUtils;

import com.ptc.core.components.beans.CreateAndEditWizBean;
import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormProcessingStatus;
import com.ptc.core.components.forms.FormResult;
import com.ptc.core.components.forms.FormResultAction;
import com.ptc.core.components.util.FeedbackMessage;
import com.ptc.core.lwc.common.BaseDefinitionService;
import com.ptc.core.lwc.common.view.EnumerationDefinitionReadView;
import com.ptc.core.lwc.common.view.EnumerationEntryReadView;
import com.ptc.core.lwc.server.LWCMasterEnumerationDefinition;
import com.ptc.core.lwc.server.cache.db.DBServiceHelper;
import com.ptc.core.percolui.AddToCollectionHelper;
import com.ptc.core.ui.resources.FeedbackType;
import com.ptc.generic.iba.AttributeService;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import com.ptc.windchill.classproxy.WorkPackageClassProxy;
import com.ptc.windchill.wp.AbstractWorkPackage;
import com.ptc.windchill.wp.WPHelper;
import com.ptc.windchill.wp.WorkPackage;
import com.ptc.windchill.wp.wpResource;

import ext.kb.util.IBAHelper;
import ext.kb.util.KBDocumentUtils;
import wt.facade.persistedcollection.PersistedCollectionException;
import wt.facade.persistedcollection.PersistedCollectionHelper;
import wt.facade.persistedcollection.PersistedCollectionRecipe;
import wt.facade.persistedcollection.PersistedCollectionRefreshInfo;
import wt.facade.persistedcollection.PersistedCollectionServerHelper;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.ReferenceFactory;
import wt.fc.WTReference;
import wt.fc.collections.WTCollection;
import wt.fc.collections.WTHashSet;
import wt.fc.collections.WTSet;
import wt.filter.NavCriteriaCacheId;
import wt.filter.NavigationCriteria;
import wt.filter.NavigationCriteriaHelper;
import wt.filter.NavigationFilter2;
import wt.filter.common.FilterHelper;
import wt.identity.DisplayIdentity;
import wt.identity.IdentityFactory;
import wt.log4j.LogR;
import wt.services.ServiceFactory;
import wt.session.SessionContext;
import wt.util.LocalizableMessage;
import wt.util.WTException;
import wt.util.WTMessage;

// TODO: Auto-generated Javadoc
/**
 * Form processor for the Add To Package action.<p>
 *
 * <b>Supported API: </b>false<br>
 * <b>Extendable: </b>false
 */
public class AddToPackageFormProcessor extends DefaultObjectFormProcessor {
   
   /** The Constant PARAM_PACKAGE_OID. */
   public static final String PARAM_PACKAGE_OID =              "packageOid";

   /** The Constant logger. */
   private static final Logger logger = LogR.getLogger(AddToPackageFormProcessor.class.getName());
   
   /** The Constant RESOURCE. */
   private static final String RESOURCE = "com.ptc.windchill.wp.wpResource";
   private static final String RESOURCE2 = "com.ptc.netmarkets.wp.wpResource";
   private PersistedCollectionRefreshInfo collectionRefreshInfo = null;
   
   /** The locale. */
   private Locale locale = null;
   boolean isRefreshBackgroundProcess = false;

   /* (non-Javadoc)
    * @see com.ptc.core.components.forms.DefaultObjectFormProcessor#doOperation(com.ptc.netmarkets.util.beans.NmCommandBean, java.util.List)
    */
   @Override
   public FormResult doOperation(NmCommandBean commandBean, List<ObjectBean> objectBeans) throws WTException {
      FormResult result = new FormResult(FormProcessingStatus.SUCCESS);
      locale = commandBean.getLocale();
      //TD0000001-000
      HashMap comboBox = commandBean.getComboBox();
      Object addToPackageLanguages = null;
      Object addToPackageProfile = null;
      for(Object key : comboBox.keySet()) {
    	  if(key.toString().contains("txtKBLanguage")) {
    		  addToPackageLanguages = comboBox.get(key);
    	  }
    	  if(key.toString().contains("kbDocContentType")) {
    		  addToPackageProfile = comboBox.get(key);
    	  }
      }
	  SessionContext context = SessionContext.getContext();
	  if(addToPackageLanguages != null) {
		 context.put("addToPackageLanguages", addToPackageLanguages); 
	  }
	  if(addToPackageProfile != null) {
		 context.put("addToPackageProfile", addToPackageProfile);  
	  }
      for (ObjectBean thisObjectBean : objectBeans) {
          AbstractWorkPackage wp = getWorkPackage(thisObjectBean, commandBean);
    	  try {
        	 if(addToPackageLanguages != null) {
        		 IBAHelper.updateIBAAttributeValueWithoutCheckout(wp, "KB_PACKAGE_LANGUAGE", buildStringExpression(addToPackageLanguages));
        	  }
        	  if(addToPackageProfile != null) {
        		 IBAHelper.updateIBAAttributeValueWithoutCheckout(wp, "KB_PACKAGE_PROFILE", buildStringExpression(addToPackageProfile));
        	  }
			} catch (RemoteException | ClassNotFoundException e) {
				logger.error("Unable to set package attributes", e);
    	    }
         if (!isNewPackageWizard(thisObjectBean)) {
            if (logger.isDebugEnabled()) {
               logger.debug("Updating work package seeds for object bean: " + thisObjectBean.toString());
            }

            if(!isRefreshBackgroundProcess && PersistedCollectionHelper.isBackgroundRefreshEnabled(wp)) {
                isRefreshBackgroundProcess = true;
            }
            try {         				
               saveWorkPackage(wp, commandBean, thisObjectBean);
            } catch (PersistedCollectionException ex) {

               if (PersistedCollectionException.MUST_NOT_BE_FROZEN_IDENTIFIER.equalsIgnoreCase(ex.getExceptionIdentifier()) && wp.isLocked()) {
                  throw new WTException(RESOURCE, wpResource.PACKAGE_LOCKED, new Object[]{IdentityFactory.getDisplayIdentity(wp)});
               } else {
                  throw ex;
               }
            }
         }
      }
      return result;
   }




	private Object buildStringExpression(Object list) {
			String expression = StringUtils.EMPTY;
			if(list instanceof List) {
				for(String str : (List<String>) list) {
					expression += str;
					expression+= "/";
				}
				expression = expression.substring(0, expression.length() - 1);
			}
			return expression;
	}


   /* (non-Javadoc)
    * @see com.ptc.core.components.forms.DefaultObjectFormProcessor#postProcess(com.ptc.netmarkets.util.beans.NmCommandBean, java.util.List)
    */
   @Override
   public FormResult postProcess(NmCommandBean commandBean, List<ObjectBean> objectBeans) throws WTException {
      logger.debug("Calling inherited postProcess method.");
      FormResult result = super.postProcess(commandBean, objectBeans);
      assert result != null;

      if (continueProcessing(result)) {
         for (ObjectBean thisObjectBean : objectBeans) {
            if (isNewPackageWizard(thisObjectBean)) {
               AbstractWorkPackage wp = getWorkPackage(thisObjectBean, commandBean);
               saveWorkPackage(wp, commandBean, thisObjectBean);
               this.setResultNextAction(result, commandBean, objectBeans);
            }
         }
      }
      else {
         if (logger.isDebugEnabled()) {
             String status = (result.getStatus() != null ? result.getStatus().toString() : "<null>");
             logger.debug("Not continuing processing because of result returned from inherited postProcess method (status is " + status + ").");
         }
         if (logger.isTraceEnabled()) logger.trace(result.toString());
      }
            
      assert result != null;
      return result;
   }

    /**
     * Sets the "nextAction" attribute on the given FormResult based on the processing status and adds collector
     * messages to the form result. <BR>
     * <BR>
     * 
     * If the status is SUCCESS or NON_FATAL_ERROR, the nextAction is set to REFRESH_OPENER and setRefreshInfo() is
     * called to set the information needed to dynamically refresh the parent page. <BR>
     * <BR>
     * 
     * 
     * <BR>
     * 
     * @param result - The FormResult to which the action info should be added. Input and output. Required.
     * @param clientData - Contains all the form data and other wizard context information. Input. Required.
     * @param objectBeans - Contain the form data for each target object and, typically, instances of those objects. Input.
     *            Required.
     * @return FormResult - the nextAction attribute is set and collector messages added to the result.
     * @throws WTException the wT exception
     */
    @SuppressWarnings("deprecation")
    @Override
    public FormResult setResultNextAction(FormResult result, NmCommandBean clientData, List<ObjectBean> objectBeans)
            throws WTException {
        FeedbackMessage feedBackMessage = null;
        if (isRefreshBackgroundProcess && !isNewPackageWizard(objectBeans.get(0))) {
            final String message = WTMessage.getLocalizedMessage(RESOURCE2, com.ptc.netmarkets.wp.wpResource.REFRESH_PKG_PENDING);
            final String messageTitle = WTMessage.getLocalizedMessage(RESOURCE2, com.ptc.netmarkets.wp.wpResource.ADD_TO_PACKAGE_CONFIRM_TITLE);
            feedBackMessage = new FeedbackMessage(FeedbackType.SUCCESS, null, messageTitle, null, message);
        } else if (collectionRefreshInfo != null && collectionRefreshInfo.getMessages() != null) {
            if (result.getStatus() == FormProcessingStatus.SUCCESS
                    || result.getStatus() == FormProcessingStatus.NON_FATAL_ERROR) {
                result.setNextAction(FormResultAction.REFRESH_OPENER);
                result = setRefreshInfo(result, clientData, objectBeans);

                if (isNewPackageWizard(objectBeans.get(0))) {
                    feedBackMessage = new FeedbackMessage(null, null, null, null, AddToCollectionHelper
                            .buildMessage(collectionRefreshInfo.getMessages()));
                } else {
                    feedBackMessage = new FeedbackMessage(FeedbackType.SUCCESS, null, null, null, AddToCollectionHelper
                            .buildMessage(collectionRefreshInfo.getMessages()));
                }

            } else if (result.getStatus() == FormProcessingStatus.FAILURE) {
                result.setNextAction(FormResultAction.NONE);
            }
        } else {
            super.setResultNextAction(result, clientData, objectBeans);
        }

        if (feedBackMessage != null)
            result.addFeedbackMessage(feedBackMessage);
        return result;
    }
   
    /**
     * Save work package.
     *
     * @param workPackage the work package
     * @param commandBean the command bean
     * @param objectBean the object bean
     * @throws WTException the wT exception
     */
    private void saveWorkPackage(AbstractWorkPackage workPackage, final NmCommandBean commandBean, final ObjectBean objectBean) throws WTException {
        WTCollection seeds = getSeeds(commandBean, objectBean, AddToCollectionHelper.ADD_TO_COLLECTION_TABLE_ID);
        
        PersistedCollectionRecipe recipe = getRecipe(workPackage, objectBean);

        //Removes the deleted filters
        FilterHelper.cleanseNonExistentFilter(recipe.getExpansionCriteria());

        WTSet nonAccessExistingSeeds = PersistedCollectionHelper.service.getSeeds(workPackage, false);
        seeds.addAll(nonAccessExistingSeeds);
        save(workPackage, seeds, recipe);
    }

   /**
    * Returns true if the form processor is being called from the package wizard and for the passed mode; returns false otherwise.<p>
    *
    * @param objectBean object bean as passed to form processor
    *
    * @return true if the form processor is being called from the package wizard and for the passed mode; returns false otherwise
    */
   boolean isNewPackageWizard(ObjectBean objectBean) {
      assert objectBean != null;
      return (objectBean.getParent() != null) && (objectBean.getParent().getObject() instanceof AbstractWorkPackage);
   }

   /**
    * Gets the work package.
    *
    * @param objectBean the object bean
    * @param commandBean the command bean
    * @return the work package
    * @throws WTException the wT exception
    */
   AbstractWorkPackage getWorkPackage(final ObjectBean objectBean, final NmCommandBean commandBean) throws WTException {
      assert objectBean != null;

      AbstractWorkPackage result = null;
      if (objectBean.getParent() != null) {
         result = (AbstractWorkPackage) objectBean.getParent().getObject();
         if (logger.isTraceEnabled()) logger.trace("Work package obtained from object bean parent.");
      }
      else {
         NmOid oid = objectBean.getActionOid();
         if (oid != null) {
            if (NmOid.isA(oid, AbstractWorkPackage.class)) {
               result = (AbstractWorkPackage) oid.getWtRef().getObject();
               if (logger.isTraceEnabled()) logger.trace("Work package obtained from object bean action oid, which was direct reference.");
            }
            else {
               result = (AbstractWorkPackage) WorkPackageClassProxy.getWorkPackage(oid.getWtRef().getObject());
               if (logger.isTraceEnabled() && (result != null)) logger.trace("Work package obtained from object bean action oid, which was proxy.");
            }
         }

         // If work package not yet found, we are outside of work package context
         if (result == null) {
            String packageOidParam = commandBean.getTextParameter(PARAM_PACKAGE_OID);
            if ((packageOidParam != null) && (packageOidParam.length() > 0)) {
               oid = NmOid.newNmOid(packageOidParam);
               if (((oid.getWtRef() != null) && AbstractWorkPackage.class.isAssignableFrom(oid.getWtRef().getReferencedClass()))) {
                  result = (AbstractWorkPackage) oid.getWtRef().getObject();
                  if (logger.isTraceEnabled()) logger.trace("Work package obtained from paramater \"" + PARAM_PACKAGE_OID + "\".");
               }
            }
         }

      }


      if (logger.isDebugEnabled()) {
          logger.debug("Work package being returned is " + (result != null ? result.toString() : "<null>") + ".");
      }
      return result;
   }

   /**
    * Gets the parameter from object bean.
    *
    * @param objectBean the object bean
    * @param sParamKey the s param key
    * @return the parameter from object bean
    */
   String getParameterFromObjectBean(ObjectBean objectBean, String sParamKey) {
      assert objectBean != null;
      assert (sParamKey != null) && (! sParamKey.trim().equals(""));

      String result = objectBean.getTextParameter(sParamKey);
      if ((result != null) && (! result.trim().equals("")))
         return result.trim();
      else
         return null;
   }

    /**
     * Returns the seeds from the tableId as a WTCollection.
     *
     * @param commandBean the command bean
     * @param objectBean the object bean
     * @param tableId the table id
     * @return WTCollection
     * @throws WTException the wT exception
     */
    @SuppressWarnings("unchecked")
    protected WTCollection getSeeds(NmCommandBean commandBean, ObjectBean objectBean, String tableId) throws WTException {
        List<NmOid> seedOids = objectBean.getAddedItemsByName(tableId);
        String actionTableID = commandBean.getParameterMap().get("tableID")!=null ? ((String[]) commandBean.getParameterMap().get("tableID"))[0] : "" ;
        boolean isCreateAction = (commandBean.getActionMethod() != null && commandBean.getActionMethod().equals("") ) ? commandBean.getActionMethod().equals("create") : false ;
        if( isCreateAction && ! isReplicationPackage(commandBean)) {
            seedOids.clear();
        }
        if (seedOids == null || seedOids.isEmpty()) {
            seedOids = new ArrayList<NmOid>();
            String seedObjToAdd = objectBean.getTextParameter("seedObjOidToAdd");
            if (seedObjToAdd != null && !(seedObjToAdd.trim()).isEmpty() && (isReplicationPackage(commandBean) || actionTableID.contains("relatedPackage"))) {
                seedOids.add(NmOid.newNmOid(seedObjToAdd.trim()));
            }
        }
        
        WTCollection seeds = new WTHashSet(seedOids.size());
        for (NmOid thisNmOid : seedOids) {
            final WTReference seedRef = thisNmOid.getWtRef();
            if (seedRef != null) {
                seeds.add(thisNmOid.getWtRef());
            }
        }

        return seeds;
    }

    /**
     * Returns the PersistedCollectionRecipe based off the parameters from the objectBean.
     *
     * @param workPackage the work package
     * @param objectBean the object bean
     * @return PersistedCollectionRecipe
     * @throws WTException the wT exception
     */
    protected PersistedCollectionRecipe getRecipe(AbstractWorkPackage workPackage, ObjectBean objectBean) throws WTException {
       PersistedCollectionRecipe recipe = null;
       try {
          // Get the original recipe object and ad-hoc filters.
          recipe = getPersistedCollectionRecipe(workPackage);
          if (recipe == null)
             recipe = PersistedCollectionRecipe.newPersistedCollectionRecipe();
          final Collection<NavigationFilter2> adHocFilters = PersistedCollectionServerHelper.getAdHocs(recipe);


          // Get the new/updated collector options.
          String collectorOptions = getParameterFromObjectBean(objectBean, AddToCollectionHelper.PARAM_COLLECTOR_OPTIONS);
          if (collectorOptions != null  &&  collectorOptions.trim().isEmpty())
             collectorOptions = null;
          recipe.setCollectorOptions(collectorOptions);

          // Get the new/updated NavigationCriteria object from the cache.
          String navCriteriaID = getParameterFromObjectBean(objectBean, AddToCollectionHelper.PARAM_NAV_CRITERIA_ID);
          NavigationCriteria navCriteria = null;
          if (navCriteriaID != null) {
             String remoteAddr = getParameterFromObjectBean(objectBean, AddToCollectionHelper.PARAM_NAV_CACHE_REMOTE_ADDR);
             String sessionId = getParameterFromObjectBean(objectBean, AddToCollectionHelper.PARAM_NAV_CACHE_SESSION_ID);

             String collectorId = WPHelper.service.getCollectorId(workPackage);
             NavCriteriaCacheId navCriteriaCacheId = new NavCriteriaCacheId(remoteAddr, sessionId, collectorId);
             navCriteria = NavigationCriteriaHelper.service.getCachedNavigationCriteria(navCriteriaID,
                   navCriteriaCacheId);
          }

          // Use a copy of this object in case something down stream fails and the user is returned to the
          // add-to-package UI.  In that case the original, non-persisted object will still be cached.
          if (navCriteria != null) {
             PersistedCollectionServerHelper.adjustExpansionCriteria(navCriteria);
             navCriteria = NavigationCriteriaHelper.service.getDeepCopy(navCriteria);
             recipe.setExpansionCriteria(navCriteria);
          }

          // If original recipe had ad-hoc filters then add them to the new recipe.
          if ( !adHocFilters.isEmpty() ) {
             if (navCriteria == null)
                navCriteria = NavigationCriteria.newNavigationCriteria();

             Collection<NavigationFilter2> filters = navCriteria.getFilters();
             if (filters == null)
                filters = new ArrayList<NavigationFilter2>(3);

             // Add ad-hoc filters to set of all filters.
             filters.addAll(adHocFilters);
             navCriteria.setFilters(filters);
          }

       }
       catch (Exception e) {
          throw new WTException(e);
       }

       return recipe;
    }

    /**
     * Stores the seeds and recipe in the AbstractWorkPackage.
     *
     * @param workPackage the work package
     * @param seeds the seeds
     * @param recipe the recipe
     * @return workPackage
     * @throws WTException the wT exception
     */
    protected void save(AbstractWorkPackage workPackage, WTCollection seeds, PersistedCollectionRecipe recipe) throws WTException {
        workPackage = (AbstractWorkPackage) PersistedCollectionHelper.service.checkout(workPackage);
        PersistedCollectionHelper.service.removeAllSeeds(workPackage);
        PersistedCollectionHelper.service.addSeeds(workPackage, seeds);
        PersistedCollectionHelper.service.setRecipe(workPackage, recipe);
        PersistedCollectionHelper.service.checkin(workPackage);
        if (PersistedCollectionHelper.isBackgroundRefreshEnabled(workPackage)) {
            WPHelper.service.refreshInBackground(workPackage, locale);
        } else {
        collectionRefreshInfo = WPHelper.service.refresh(workPackage, locale);
        }
    }

    /**
     * Gets the persisted collection recipe.
     *
     * @param workPackage the work package
     * @return the persisted collection recipe
     * @throws WTException the wT exception
     */
    protected PersistedCollectionRecipe getPersistedCollectionRecipe(AbstractWorkPackage workPackage) throws WTException {
        return PersistedCollectionHelper.service.getRecipe(workPackage);
    }

    /**
     * Checks if is replication package.
     *
     * @param commandBean the command bean
     * @return true, if is replication package
     * @throws WTException the wT exception
     */
    protected boolean isReplicationPackage(NmCommandBean commandBean) throws WTException {

        String objectHandle = commandBean.getTextParameter(CreateAndEditWizBean.OBJECT_HANDLE);
        if(objectHandle == null || objectHandle.isEmpty()) {
            objectHandle = "";
        }
        Object packageTypeCreated = commandBean.getRequestData().getParameterMap().get( objectHandle + CreateAndEditWizBean.ITEM_TIID_PARAMETER_NAME);
        if(packageTypeCreated != null) {
            if(((String [])packageTypeCreated)[0].toString().contains("com.ptc.windchill.wp.rep.ReplicationPackage")) {
                return true;
            }
        }
        return false;
    }
}
