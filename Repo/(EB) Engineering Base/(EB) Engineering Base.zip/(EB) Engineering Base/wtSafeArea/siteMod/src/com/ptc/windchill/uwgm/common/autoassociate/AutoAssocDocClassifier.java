/* bcwti
 *
 * Copyright (c) 2010 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */
package com.ptc.windchill.uwgm.common.autoassociate;

/*
16-Nov-06  X10-80         MMV    created
05-Dec-06  X10-81         MMV    added getValidDocs()
06-Dec-06  X10-82         MMV    always ignore "NOTE" doc type
11-Sep-07  X10-M010-06    shavale  added HDICEnabled check
08-Apr-08  X12-30         shavale  removed HDICEnabled check
12-Jun-08  X12-39         shavale  SPR 1489505, auto associate not supported for
                                   Mathcad and Isodraw objects
11-Aug-08  X12-47         atsyg    SPR 1523433: exclude  Manikin  types from autoassociate
13-Oct-08  X12-M010-06    shavale  SPR 1510052 ignore auto associate for calculation data doc type
17-Nov-08  X12-M010-09    shavale  ignore auto associate for mechanica files SPR 1612078
20-Nov-08  X12-M010-09    dbhate   ignore auto associate for Graphics Editor authored documents SPR 1262855
13-Feb-09  X20-20         shavale  moved ignore types to BOMItemsHelper
*/

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import com.ptc.core.logging.Log;
import com.ptc.core.logging.LogFactory;
import com.ptc.windchill.uwgm.common.associate.AssociationHelper;
import com.ptc.windchill.uwgm.common.autoassociate.AutoAssociateHelper;
import com.ptc.windchill.uwgm.common.autoassociate.BOMItemsHelper;

import ext.kb.autoassociate.KBAutoAssociatePartFinderCreator;
import ext.kb.util.IBAHelper;
import ext.kb.util.KBConstants;
import ext.kb.util.KBUtils;
import wt.epm.EPMDocument;
import wt.epm.EPMDocumentMaster;
import wt.epm.EPMDocumentType;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.inf.container.WTContainer;
import wt.util.WTException;
/**
 * Sort out EPMDocuments by the possible type of association to a WTPart.
 * <p>
 * Possible document types:
 * <dl>
 * <dt>MODEL
 * <dd>Can be auto-associated with a SAR link in order to drive WTPart product structure.
 *
 * <dt>IGNORE
 * <dd>Cannot be auto-associated to a WTPart. Examples include ghosts, non-latest
 * docs, Arbortext docs, etc. Do not trigger an error, just ignored.
 *
 * <dt>DRAWING
 * <dd>Documents of EPMDocumentType=DRAWING. They are actually kind of DELIVERABLE
 * type, but have special treatment, being passively associated to their model's
 * WTParts using either as-stored configuration, or Describes link, depending on
 * the CreateAsStored preference value. Standalone drawing, which does not have
 * a model, is supposed to be treated similar to DELIVERABLE type.
 *
 * <dt>DERIVED
 * <dd>Derived documents can contribute to product structure, but cannot drive it.
 * Unambigously defined by EPMDocument.isDerived() returning true. Synonim: TIM.
 * Auto-associated to their source docs with Rep link.
 *
 * <dt>DERIVED_TYPE
 * <dd>Derived documents with isDerived()==false, which EPMDocument(Sub)Types are listed
 * in the DisallowStructureDocument(Sub)Types preferences. Cannot be associated using
 * SAR link. Auto-associated to matching or created WTParts using Rep link.
 *
 * <dt>DELIVERABLE
 * <dd>Cannot contribute to product structure. Their EPMDocument(Sub)Types are listed in
 * the DisallowProductStructureDocument(Sub)Types preferences. Auto-associated
 * to matching or created WTParts using Describes link.
 * </dl>
 */
public final class AutoAssocDocClassifier
{
  // EPMDocument "types" regarding a possible association
  public enum DocType {MODEL, IGNORE, DRAWING, DERIVED, DERIVED_TYPE, DELIVERABLE};
  private static final int DOCTYPES_SIZE = DocType.values().length;

  private final Map<EPMDocument,DocType> docTypeMap;

  // Number of docs of each particular type, to optimize memory allocation.
  //
  // Should we use EnumMap instead? It would be efficient enough, but the syntax sucks:
  // numOfType.put(DocType.IGNORE, numOfType.get(DocType.IGNORE)+1);
  // vs. numOfType[DocType.IGNORE.ordinal()]++;
  private final int[] numOfType = new int[DOCTYPES_SIZE];

  // unchecked conversion warning 8-(
  private final Collection<EPMDocument>[] docsOfType = new Collection[DOCTYPES_SIZE];

  public AutoAssocDocClassifier(Collection<EPMDocument> epmDocuments, WTContainer container)
  {
    docTypeMap = new HashMap<EPMDocument,DocType>(epmDocuments.size());
    classifyDocs(epmDocuments,container);
  }

  public DocType getDocType(EPMDocument doc)
  {
    return docTypeMap.get(doc);
  }

  public Collection<EPMDocument> getDocsOfType(DocType dt)
  {
    int dtn = dt.ordinal();
    if (docsOfType[dtn] == null) // deferred allocation
    {
      docsOfType[dtn] = new ArrayList<EPMDocument>(numOfType[dtn]);
      for (Map.Entry<EPMDocument,DocType> e : docTypeMap.entrySet())
      {
        if (e.getValue() == dt)
          docsOfType[dtn].add(e.getKey());
      }
    }
    return Collections.unmodifiableCollection(docsOfType[dtn]);
  }

  public Collection<EPMDocument> getValidDocs()
  {
    int nValid = docTypeMap.size() - numOfType[DocType.IGNORE.ordinal()];

    Collection<EPMDocument> validDocs = new ArrayList<EPMDocument>(nValid);
    for (Map.Entry<EPMDocument,DocType> e : docTypeMap.entrySet())
    {
      if (e.getValue() != DocType.IGNORE)
        validDocs.add(e.getKey());
    }

    return validDocs;
  }

  private void classifyDocs(Collection<EPMDocument> epmDocuments,WTContainer container)
  {
    if (log.isDebugEnabled())
      log.debug("Classifying docs: " + epmDocuments.size());

    for (EPMDocument doc : epmDocuments)
    {
      DocType docType = DocType.MODEL;

      
      if(KBAutoAssociatePartFinderCreator.isDrawingWithArticleNum(doc))
      {
    	  docType = DocType.IGNORE;
    	  
      }else if (BOMItemsHelper.isForbiddenDoc(doc))
      {
        docType = DocType.IGNORE;
      }
      else if (doc.isDerived()) // TIM -> create rep.link to source
      {
        // No SAR link: only Rep, AR (if allowed) or Describes link.
        docType = DocType.DERIVED;
      }
      else if (AssociationHelper.isDerivedDrawing(doc))
      {
        // Deliverable, but depends on AsStored setting.
        docType = DocType.DRAWING;
      }
      else if (!AutoAssociateHelper.canDocumentContributeToProductStructure(doc))
      {
        // No SAR or Rep link: only Describes link
        // (or "A" custom link if a preference "?" is set)
        docType = DocType.DELIVERABLE;
      }
      else if (!AutoAssociateHelper.canDocumentDriveProductStructure(doc, false,container))
      {
        // No SAR link: only Rep, AR (if allowed) or Describes link
        docType = DocType.DERIVED_TYPE;
      }
      

      docTypeMap.put(doc, docType);
      numOfType[docType.ordinal()]++;
    }

    if (log.isDebugEnabled())
    {
      StringBuffer sb = new StringBuffer("Found doc types:");
      log.debug(sb.toString());
    }
  }
  private static final String KB_ARTICLE_NUM = "KB_ARTICLE_NUM";

	private boolean isDrawing(EPMDocument document) {
		if (log.isDebugEnabled()) {
			log.debug("entering isDrawing(EPMDocument)");
			log.debug("document: " + document);
			log.debug("exiting isDrawing()");
		}
		return EPMDocumentType.toEPMDocumentType("CADDRAWING").equals(document.getDocType());
	}
  
  private static final Log log = LogFactory.getLog(AutoAssocDocClassifier.class);
}