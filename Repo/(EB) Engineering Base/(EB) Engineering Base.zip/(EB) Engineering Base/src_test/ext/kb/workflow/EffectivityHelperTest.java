package ext.kb.workflow;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import wt.eff.ClientEffGroup;

public class EffectivityHelperTest {

	@Test
	public void testSetEffRange() throws Exception{
		ClientEffGroup g = new ClientEffGroup();
		
		g.setRange("2014/01/15 2:30 PM - 2014/01/16 1:30 PM");
		EffectivityHelper.setRange(g, "2014/01/17 12:00 PM");
		assertEquals("2014/01/15 2:30 PM - 2014/01/17 12:00 PM", g.getRange());
		
		g.setRange("2014/01/15 2:30 PM - 2014/01/16 1:30 PM");
		EffectivityHelper.setRange(g, "2014/01/15 11:00 AM");
		assertEquals("2014/01/15 2:30 PM", g.getRange());
		
		g.setRange("2014/01/15 2:30 PM - 2014/01/16 1:30 PM");
		EffectivityHelper.setRange(g, "2014/01/16 1:30 PM");
		assertEquals("2014/01/15 2:30 PM - 2014/01/16 1:30 PM", g.getRange());
		
		g.setRange("2014/01/15 2:30 PM-2014/01/16 1:30 PM");
		EffectivityHelper.setRange(g, "2014/01/17 12:00 PM");
		assertEquals("2014/01/15 2:30 PM - 2014/01/17 12:00 PM", g.getRange());
		
		g.setRange("2014/01/15 2:30 PM-2014/01/16 1:30 PM");
		EffectivityHelper.setRange(g, "2014/01/15 11:00 AM");
		assertEquals("2014/01/15 2:30 PM", g.getRange());
		
		g.setRange("2014/01/15 2:30 PM-2014/01/16 1:30 PM");
		EffectivityHelper.setRange(g, "2014/01/16 1:30 PM");
		assertEquals("2014/01/15 2:30 PM - 2014/01/16 1:30 PM", g.getRange());
		
		g.setRange("2014/01/15 2:30 PM -");
		EffectivityHelper.setRange(g, "2014/01/17 12:00 PM");
		assertEquals("2014/01/15 2:30 PM - 2014/01/17 12:00 PM", g.getRange());
		
		g.setRange("2014/01/15 2:30 PM-");
		EffectivityHelper.setRange(g, "2014/01/17 12:00 PM");
		assertEquals("2014/01/15 2:30 PM - 2014/01/17 12:00 PM", g.getRange());
		
		g.setRange("2014/01/15 2:30 PM -");
		EffectivityHelper.setRange(g, "2014/01/15 2:30 PM");
		assertEquals("2014/01/15 2:30 PM", g.getRange());
		
		g.setRange("2014/01/15 2:30 PM");
		EffectivityHelper.setRange(g, "2014/01/17 12:00 PM");
		assertEquals("2014/01/15 2:30 PM - 2014/01/17 12:00 PM", g.getRange());
	}

}
