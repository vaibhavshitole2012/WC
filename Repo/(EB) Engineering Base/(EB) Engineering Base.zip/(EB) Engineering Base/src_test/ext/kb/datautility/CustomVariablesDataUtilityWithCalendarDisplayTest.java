package ext.kb.datautility;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.junit.Test;

import wt.workflow.definer.WfVariableInfo;
import wt.workflow.engine.ProcessData;
import wt.workflow.engine.WfVariable;

import ext.kb.datautility.CustomVariablesDataUtilityWithCalendarDisplay;
import com.ptc.core.components.rendering.guicomponents.DateInputComponent;
import com.ptc.core.components.rendering.guicomponents.GUIComponentArray;
import com.ptc.core.components.rendering.guicomponents.StringInputComponent;

public class CustomVariablesDataUtilityWithCalendarDisplayTest {

	CustomVariablesDataUtilityWithCalendarDisplay util = new CustomVariablesDataUtilityWithCalendarDisplay();
	
	@Test
	public void testGetVariableName()
	{
		assertTrue(util.getVariableName("param").startsWith("CustActVar"));
		assertTrue(util.getVariableName("param").endsWith("CustActVar"));
	}

	@Test
	public void testCreateComponentArray() throws Exception{
		Set<String> dateFields = new HashSet<String>(Arrays.asList("myDate", "displayOnlyDate"));
		GUIComponentArray array = new GUIComponentArray();
		
		Map<String, WfVariableInfo> variables = new HashMap<String, WfVariableInfo>();
		
		WfVariableInfo info1 = new WfVariableInfo();	
		info1.setTypeName("String");
		info1.setName("otherField");
		WfVariableInfo info2 = new WfVariableInfo();	
		info2.setTypeName("java.util.Date");
		info2.setName("myDate");
		WfVariableInfo info3 = new WfVariableInfo();	
		info3.setTypeName("java.util.Date");
		info3.setName("displayOnlyDate");
		info3.setReadOnly(true);
		variables.put(info1.getName(), info1);
		variables.put(info2.getName(), info2);
		variables.put(info3.getName(), info3);
		StringInputComponent comp1 = new StringInputComponent();
		comp1.setName("otherField");
		StringInputComponent comp2 = new StringInputComponent();
		comp2.setName("myDate");
		StringInputComponent comp3 = new StringInputComponent();
		comp3.setName("displayOnlyDate");
		array.addGUIComponent(comp1);
		array.addGUIComponent(comp2);
		array.addGUIComponent(comp3);
		ProcessData processData = new ProcessData();
		WfVariable x1 = new WfVariable();
		x1.setName("otherField");
		x1.setTypeName("String");
		WfVariable x2 = new WfVariable();
		x2.setName("myDate");
		x2.setTypeName("java.util.Date");
		WfVariable x3 = new WfVariable();
		x3.setName("displayOnlyDate");
		x3.setTypeName("java.util.Date");
		x3.setReadOnly(true);
		processData.setVariables(new WfVariable[]{x1, x2, x3});
		
		GUIComponentArray arr = util.createComponentArray(dateFields, processData, variables, array);
		
		assertEquals(3, arr.size());
		assertEquals(StringInputComponent.class, arr.get(0).getClass());
		assertEquals(DateInputComponent.class, arr.get(1).getClass());
		assertEquals(StringInputComponent.class, arr.get(2).getClass());
		
		dateFields.clear();
		arr = util.createComponentArray(dateFields, processData, variables, array);
		assertEquals(3, arr.size());
		assertEquals(StringInputComponent.class, arr.get(0).getClass());
		assertEquals(StringInputComponent.class, arr.get(1).getClass());
		assertEquals(StringInputComponent.class, arr.get(2).getClass());
	
		dateFields.add("java.util.Date");
		arr = util.createComponentArray(dateFields, processData, variables, array);
		assertEquals(3, arr.size());
		assertEquals(StringInputComponent.class, arr.get(0).getClass());
		assertEquals(DateInputComponent.class, arr.get(1).getClass());
		assertEquals(StringInputComponent.class, arr.get(2).getClass());
	}
	
}
