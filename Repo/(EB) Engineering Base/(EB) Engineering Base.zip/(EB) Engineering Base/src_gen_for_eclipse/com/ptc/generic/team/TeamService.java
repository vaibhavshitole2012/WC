package com.ptc.generic.team;



@wt.method.RemoteInterface
public interface TeamService extends wt.method.RemoteAccess {

    public static final java.lang.String ADD = "addUserToRole";
    public static final java.lang.String REMOVE = "removeUserFromRole";

    
    public java.util.Vector getVectorOfRolesFromString(java.lang.String roleNames)
        throws wt.util.WTException;

    
    public java.util.HashMap getRoleUsers(wt.project.Role role, long[] teamIds)
        throws wt.util.WTException;

    
    public java.util.Vector searchUsersAndGroups(boolean searchUser, java.lang.String userName, java.lang.String userFullName, boolean searchGroup, java.lang.String groupName, wt.inf.container.WTContainer container)
        throws wt.util.WTException;

    
    public void changeTeamRoleMembers(java.util.Vector vPersistableOids, java.util.HashMap hmActions, wt.project.Role role)
        throws wt.util.WTException;

    
    public boolean addPrincipalToRole(wt.team.TeamManaged teamManaged, wt.team.Team team, wt.org.WTPrincipal principal, wt.project.Role role, boolean updateACL)
        throws wt.util.WTException;

    
    public boolean removePrincipalFromRole(wt.team.TeamManaged teamManaged, wt.team.Team team, wt.org.WTPrincipal principal, wt.project.Role role, boolean updateACL)
        throws wt.util.WTException;

    
    public void copyAdHocAcls2OldIterations(wt.team.TeamManaged teamManaged)
        throws wt.util.WTException;

    
    public wt.fc.Persistable setModifyStamp(wt.fc.Persistable p, java.sql.Timestamp t)
        throws wt.util.WTException;

    
    public java.util.Map populateRolePrincipalMap(java.lang.Long oid)
        throws wt.util.WTException;

    
    public java.util.Map getRolePrincipalMapsForTeams(java.util.Collection<java.lang.String> set, java.util.Set<java.lang.String> roleNames)
        throws wt.util.WTException;

    
    public wt.org.WTGroup createGroup(java.lang.String groupName, wt.org.WTPrincipal[] principals, wt.org.DirectoryContextProvider context)
        throws wt.util.WTException;

    
    public void cleanRole(wt.team.Team team, wt.project.Role role)
        throws wt.util.WTException;

    public java.util.Vector getRolePricipalMapChunk(wt.project.Role role, long[] teamId)
        throws wt.util.WTException;

    public wt.fc.Persistable updateAcl(wt.fc.Persistable anObject)
        throws wt.util.WTException;

    
    public java.util.LinkedList<wt.org.WTPrincipalReference> toReferences(wt.org.WTGroup group)
        throws wt.util.WTException;

}
