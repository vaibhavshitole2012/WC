package com.ptc.generic.mail;



@wt.method.RemoteInterface
public interface GenericMailService extends wt.method.RemoteAccess {

    
    public boolean sendEMailWithAttachment(java.lang.String subject, java.lang.String body, wt.org.WTPrincipal prince, java.lang.String contentHolderReference, int contentType)
        throws wt.util.WTException;

    
    public boolean sendEMailWithoutAttachment(java.lang.String subject, java.lang.String body, wt.org.WTPrincipal reciepient)
        throws wt.util.WTException;

    
    public boolean sendEMailWithoutAttachment(java.lang.String subject, java.lang.String body, wt.org.WTPrincipal reciepient, wt.org.WTPrincipal originator)
        throws wt.util.WTException;

    
    public void sendLocalizedMail(java.util.List<wt.org.WTPrincipal> recipients, java.util.List<wt.org.WTPrincipal> ccRecipients, java.util.List<wt.org.WTPrincipal> bccRecipients, wt.org.WTPrincipal originator, java.lang.Class<? extends java.util.ResourceBundle> resourceBundle, java.lang.String resourceEntry, java.lang.String[] textInsertsSubject, java.lang.String[] textInsertsBody, java.lang.String[] attachments, int attachmentType)
        throws wt.util.WTException;

}
