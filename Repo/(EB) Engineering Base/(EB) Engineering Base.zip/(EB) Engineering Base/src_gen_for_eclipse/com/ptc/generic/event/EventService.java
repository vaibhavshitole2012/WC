package com.ptc.generic.event;


@wt.method.RemoteInterface
public interface EventService extends wt.method.RemoteAccess {

    
    public void dispatchVetoableEvent(wt.events.KeyedEvent event, java.lang.String eventKey)
        throws wt.util.WTException;

    public void dispatchVetoableEvent(wt.events.KeyedEvent event)
        throws wt.util.WTException;

    public void dispatchEvent(wt.events.KeyedEvent event)
        throws wt.util.WTException;

    
    public void dispatchVetoablePersistenceEvent(java.lang.String eventName, wt.fc.Persistable persistable)
        throws wt.util.WTException;

}
