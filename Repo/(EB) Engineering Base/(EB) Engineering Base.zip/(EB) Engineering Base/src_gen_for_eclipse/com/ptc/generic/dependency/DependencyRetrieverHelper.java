package com.ptc.generic.dependency;


public class DependencyRetrieverHelper {

    
    public static final com.ptc.generic.dependency.DependencyRetrieverService service = wt.services.ServiceFactory.getService(com.ptc.generic.dependency.DependencyRetrieverService.class);

}
