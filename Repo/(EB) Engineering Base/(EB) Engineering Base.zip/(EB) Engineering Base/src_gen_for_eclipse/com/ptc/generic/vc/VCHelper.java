package com.ptc.generic.vc;


public class VCHelper {

    
    public static final com.ptc.generic.vc.VCService service = wt.services.ServiceFactory.getService(com.ptc.generic.vc.VCService.class);

}
