package com.ptc.generic.userprefs;



@wt.method.RemoteInterface
public interface UserPrefsService extends wt.method.RemoteAccess {

    public static final java.lang.String PREFERENCE_DEFAULT_HANDLER = "com.ptc.windchill.enterprise.preference.handler.StringPreferenceValueHandler";
    public static final java.lang.String ECA_CLIENT_NAME = "ECA";

    
    public java.lang.String getUserPreference(java.lang.String name, java.lang.String client)
        throws wt.util.WTException;

    
    public void setUserPreference(java.lang.String name, java.lang.String client, com.ptc.generic.userprefs.UserPrefCategory category, java.lang.String value, java.lang.String defaultValue, int visibility)
        throws wt.util.WTException;

    
    public java.util.Map<java.lang.String,java.lang.Object> getUserPreferences(java.util.Collection<java.lang.String> names, java.lang.String client)
        throws wt.util.WTException;

    
    public java.util.Map<java.lang.String,java.lang.Object> getUserPreferences(java.util.Collection<java.lang.String> names, java.lang.String client, wt.org.WTPrincipal principal)
        throws wt.util.WTException;

    
    public void deleteUserPreference(java.lang.String name, java.lang.String client, boolean cleanupDefinition)
        throws wt.util.WTException;

    
    public void deleteUserPreference(java.lang.String name, java.lang.String client, boolean cleanupDefinition, wt.org.WTPrincipal principal)
        throws wt.util.WTException;

    
    public void deleteSitePreference(java.lang.String name, java.lang.String client, boolean asAdmin, boolean cleanupDefinition)
        throws wt.util.WTException;

    
    public java.util.Collection<java.lang.String> getUserPreferenceNames(java.lang.String client, com.ptc.generic.userprefs.UserPrefCategory category)
        throws wt.util.WTException;

    
    public java.util.Collection<java.lang.String> getUserPreferenceNames(java.lang.String prefix, java.lang.String client, com.ptc.generic.userprefs.UserPrefCategory category, wt.org.WTPrincipal principal)
        throws wt.util.WTException;

    
    public void changeDefaultValue(java.lang.String name, java.lang.String category, java.lang.String client, java.lang.String newDefault, int visibility)
        throws wt.util.WTException;

}
