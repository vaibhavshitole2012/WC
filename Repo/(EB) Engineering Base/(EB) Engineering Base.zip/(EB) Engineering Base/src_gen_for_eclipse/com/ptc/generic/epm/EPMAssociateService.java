package com.ptc.generic.epm;


@wt.method.RemoteInterface
public interface EPMAssociateService extends wt.method.RemoteAccess {

    
    public wt.epm.EPMDocument getOwnerEPMDoc(java.lang.Object part)
        throws wt.util.WTException;

    
    public java.util.List<com.ptc.generic.epm.EPMAssociation> getActiveAssociations(java.lang.Object o)
        throws wt.util.WTException;

    
    public java.util.List<com.ptc.generic.epm.EPMAssociation> getPassiveAssociations(java.lang.Object o)
        throws wt.util.WTException;

    
    public java.util.List<com.ptc.generic.epm.EPMAssociation> getAllAssociations(java.lang.Object o)
        throws wt.util.WTException;

    
    public void associate(wt.epm.workspaces.EPMWorkspace ws, java.util.Collection instructions)
        throws wt.util.WTException;

    
    public void disassociate(wt.epm.workspaces.EPMWorkspace ws, java.util.Collection instructions)
        throws wt.util.WTException;

    
    public void createOwner(java.lang.Object part, java.lang.Object epm)
        throws wt.util.WTException;

    
    public void createPassive(wt.part.WTPart part, wt.epm.EPMDocument epm)
        throws wt.util.WTException, wt.util.WTPropertyVetoException;

    
    public wt.part.WTPart setAssociations(com.ptc.generic.epm.AssociationContainer associationContainer)
        throws wt.util.WTException;

    
    public wt.epm.EPMDocument getActiveEPMDoc(java.lang.Object part)
        throws wt.util.WTException;

    
    public java.util.Map getCalulatedURLs(java.util.Collection oids, boolean pView, boolean download);

    
    public java.net.URL getProductViewURL(java.lang.Object object)
        throws wt.util.WTException;

    
    public java.net.URL getDownloadURL(java.lang.Object object)
        throws wt.util.WTException;

    
    public wt.fc.QueryResult findEPMDocuments(java.lang.String name, java.lang.String number, java.lang.String naming)
        throws wt.util.WTException, java.lang.Exception;

    
    public java.util.Collection<wt.epm.EPMDocument> getAssociatedDrawings(wt.part.WTPart part)
        throws wt.util.WTException;

    
    public java.util.Vector<wt.epm.EPMDocument> getReferencedDrawingsFromPart(wt.part.WTPart part)
        throws wt.util.WTException;

    
    public wt.fc.collections.WTList getDecribesLinks(wt.epm.EPMDocument epmDoc)
        throws wt.util.WTException;

    
    public java.util.List<wt.part.WTPart> getWTPartsThatAreDescibedByGivenEPMDoc(wt.epm.EPMDocument epmDoc, boolean onlyLatestIterations)
        throws wt.util.WTException;

    
    public com.ptc.windchill.collector.api.cad.CadCollectedResult getCadCollectedResult(wt.epm.EPMDocument pbo)
        throws wt.util.WTPropertyVetoException, wt.util.WTException;

    
    public void performBuild(wt.epm.build.EPMBuildRule buildRule);

}
