package ext.kb.wtdoc;


@wt.method.RemoteInterface
public interface KBWTDocNumberingService extends wt.method.RemoteAccess {

    public ext.kb.listener.delegate.newversion.dto.WTDocNewNumberCalculatorResult genNewNrAndFailIfReserved(wt.doc.WTDocument wtDoc)
        throws wt.util.WTException;

    public ext.kb.listener.delegate.newversion.dto.WTDocNewNumberCalculatorResult genNewNr(wt.doc.WTDocument wtDoc)
        throws wt.util.WTException;

    public void saveSapIndex(wt.doc.WTDocument wtDoc, java.lang.String sapIdx)
        throws wt.util.WTException;

}
