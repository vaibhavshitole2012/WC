package ext.kb.maturity.service;


@wt.method.RemoteInterface
public interface KBMaturityService extends wt.method.RemoteAccess {

    public void setReleaseIBAs(wt.maturity.PromotionNotice promotionRequest, wt.fc.ObjectReference self);

    public void setVerifyIBAs(wt.maturity.PromotionNotice promotionRequest, wt.fc.ObjectReference self);

}
