package ext.kb.ws;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.xml.bind.JAXBException;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.ptc.jws.servlet.JaxWsWebService;

import ext.kb.project.ProjectHelper;
import ext.kb.service.WebServiceHelper;
import ext.kb.util.DBUtils;
import ext.kb.util.IBAHelper;
import ext.kb.util.KBConstants;
import ext.kb.util.KBUtils;
import ext.kb.util.ObjectRevisionHelper;
import wt.doc.WTDocument;
import wt.doc.WTDocumentMaster;
import wt.epm.EPMDocument;
import wt.epm.EPMDocumentMaster;
import wt.epm.structure.EPMDescribeLink;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.folder.Folder;
import wt.inf.container.WTContainerRef;
import wt.inf.sharing.DataSharingHelper;
import wt.log4j.LogR;
import wt.org.WTPrincipal;
import wt.part.WTPart;
import wt.part.WTPartDescribeLink;
import wt.part.WTPartReferenceLink;
import wt.pds.StatementSpec;
import wt.pom.PersistenceException;
import wt.pom.Transaction;
import wt.projmgmt.admin.Project2;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.session.SessionHelper;
import wt.type.TypedUtilityServiceHelper;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.vc.VersionControlHelper;
import wt.vc.wip.Workable;
import wt.vc.wip.WorkInProgressHelper;

@WebService()
public class KBCreateDescribeLinkService extends JaxWsWebService {
	private static final Logger LOGGER = LogR.getLogger(KBCreateDescribeLinkService.class.getName());
	private static final Logger logWriter = LogR.getLogger("ext.kb.ws.KBCreateDescribeLinkService_Log");
	
	@WebMethod(operationName = "createDescribeLink")
	public List<String> createDescribeLink(
			@WebParam(name = "partID") String parentID,
			@WebParam(name = "part_CID") String part_CID,
			@WebParam(name = "docIDs") String docIDs[][]) throws WTException,
			WTPropertyVetoException, JAXBException, IOException

	{
		Transaction trx = null;
		List<String> result = new ArrayList<String>();
		try {

			trx = new Transaction();
			trx.start();
	        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
            Date date = new Date();
            String formatedDate = sdf.format(date);
            String dummyDocNumber = "HD0000221-000";
	        
	        logWriter.info(" Processing create Describe Link request on "+formatedDate+" parent number is "+parentID+" part_CID is "+part_CID);
			QuerySpec resQS = WebServiceHelper.findPartByNumberAndCadim(parentID, part_CID);
			QueryResult resQR = PersistenceHelper.manager
					.find((StatementSpec) resQS);
			LOGGER.debug("resQR: " + resQR);
			LOGGER.debug("resQR.size()"+resQR.size());
			int size = resQR.size();
			if (size > 0) {

				Persistable resObj[] = (Persistable[]) resQR.nextElement();
				LOGGER.debug("resObj[0] " + resObj[0]);

				WTPart resPart = (WTPart) resObj[0];
				WTPart latestPartRevision = (WTPart)ObjectRevisionHelper.getLatestVersionByPersistable(resPart);
				WTPart latestPartIteration = (WTPart) VersionControlHelper
						.getLatestIteration(latestPartRevision);
				//retrieving design view part
				 latestPartIteration = (WTPart)WebServiceHelper.getDesignViewPart((WTPart)latestPartIteration);
					if(latestPartIteration == null)
						throw new WTException("Design view Part with number "+latestPartRevision.getNumber()+" not found");
				LOGGER.debug("part revision is " + latestPartIteration.getVersionIdentifier().getValue()+" and iteration is "+ latestPartIteration.getIterationIdentifier().getValue());
				List<WTPartDescribeLink> describeLinksList = DBUtils
						.retrieveLinks(WTPartDescribeLink.class,
								latestPartIteration,
								WTPartDescribeLink.DESCRIBED_BY_ROLE);
				
				List<WTPartReferenceLink> referenceLinksList = DBUtils
						.retrieveLinks(WTPartReferenceLink.class,
								latestPartIteration,
								WTPartReferenceLink.ROLE_BOBJECT_ROLE);
				
				LOGGER.debug("describeLinksList size "
						+ describeLinksList.size());
				logWriter.info("describeLinksList size "+ describeLinksList.size());
				
				LOGGER.debug("referenceLinksList size "
						+ referenceLinksList.size());
				logWriter.info("referenceLinksList size "+ referenceLinksList.size());
				
				for (WTPartDescribeLink wtPartDescribeLink : describeLinksList) {
					LOGGER.debug("B4 deleting wtPartDescribeLink ");
					PersistenceServerHelper.manager.remove(wtPartDescribeLink);
					LOGGER.debug("After deleting wtPartDescribeLink ");
					logWriter.info("After deleting wtPartDescribeLink ");
				}
				
				for (WTPartReferenceLink wtPartReferenceLink : referenceLinksList) {
					LOGGER.debug("B4 deleting wtPartReferenceLink ");
					PersistenceServerHelper.manager.remove(wtPartReferenceLink);
					LOGGER.debug("After deleting wtPartReferenceLink ");
					logWriter.info("After deleting wtPartReferenceLink ");
				}
				
				QueryResult qrDesLinkDelete = PersistenceHelper.manager.navigate(latestPartIteration,wt.epm.structure.EPMDescribeLink.DESCRIBED_BY_ROLE,wt.epm.structure.EPMDescribeLink.class, false);
				LOGGER.debug("describe Link query size before remove : "+qrDesLinkDelete.size());
				while(qrDesLinkDelete.hasMoreElements()){
					EPMDescribeLink link = (EPMDescribeLink)qrDesLinkDelete.nextElement();
					LOGGER.debug("Before deleting link : "+link);
					PersistenceServerHelper.manager.remove(link);
					LOGGER.debug("Link delted succesfully");
				}
				
				logWriter.info("Gathering data to see if the documents should be shared.");
				final int length = docIDs.length;
				final Map<WTContainerRef, Folder> sharedToProjects = getSharedToProjects(latestPartIteration, length);

				// checking if the conditions to automatically share the documents to
				// plant(s)/project(s) are met.
				final boolean shouldDocumentBeShared = sharedToProjects != null && !sharedToProjects.isEmpty();
				if (LOGGER.isDebugEnabled()) {
					LOGGER.debug("Should the documents be automatically shared to plants?: " + shouldDocumentBeShared);
				}

				
				LOGGER.debug("docIDs.size(): " + docIDs.length);
				logWriter.info("docIDs.size(): " + docIDs.length);
				for (int i = 0; i < docIDs.length; i++) {
					logWriter.info("doc number " + docIDs[i][0]);
					LOGGER.debug("doc number " + docIDs[i][0]);
					logWriter.info("doc cid " + docIDs[i][1]);
					String documentID = StringUtils.substringBeforeLast(docIDs[i][0],"-");
					LOGGER.debug("documentID  " + documentID);
					logWriter.info("documentID " + documentID);
					String SAPIDX = StringUtils.substringAfterLast(docIDs[i][0],"-");
					String rev = docIDs[i][2];
					String irev = docIDs[i][3];
					LOGGER.debug("document SAPIDX " + SAPIDX);
					logWriter.info("document SAPIDX " + SAPIDX);
					
					LOGGER.debug("document Revision " + rev);
					logWriter.info("document Revision " + rev);
					
					LOGGER.debug("document IREV " + irev);
					logWriter.info("document IREV " + irev);
					QuerySpec docQS = null;
					if(SAPIDX.equals("000"))
					{
						LOGGER.debug("document is a source going to search document with number " + docIDs[i][0]);
						logWriter.info("document is a source going to search document with number " + docIDs[i][0]);
						docQS = WebServiceHelper.findDocumentByNumberAndCadim(
							docIDs[i][0], docIDs[i][1]);
					}
					else
					{
						LOGGER.debug("document is a variant going to search for parent document with number " + documentID+"-000");
						logWriter.info("document is a variant going to search for parent document with number " + documentID+"-000");
						docQS = new QuerySpec();
						int docIndex = docQS.appendClassList(WTDocument.class, true);
						int docMasterIndex = docQS.appendClassList(WTDocumentMaster.class,false);
						docQS.appendWhere(new SearchCondition(WTDocument.class,
								"masterReference.key.id", WTDocumentMaster.class,
								"thePersistInfo.theObjectIdentifier.id"), new int[] {
								docIndex, docMasterIndex });
						docQS.appendAnd();
						docQS.appendWhere(new SearchCondition(WTDocumentMaster.class, "number",
								SearchCondition.EQUAL, documentID+"-000"),
								new int[] { docMasterIndex });
						//docQS = WebServiceHelper.findDocumentByNumberAndCadim(documentID+"-000", docIDs[i][1]);
					}
					QueryResult docQR = PersistenceHelper.manager
							.find((StatementSpec) docQS);
					int docSize = docQR.size();
					if (docSize > 0) {

						Persistable docObj[] = (Persistable[]) docQR.nextElement();
						LOGGER.debug("docObj[0] " + docObj[0]);

						WTDocument relatedDoc = (WTDocument) docObj[0];
						WTDocument describeByDoc = (WTDocument) docObj[0];
						LOGGER.debug("relatedDoc: " + relatedDoc);
						
						if(rev!=null && irev!=null){
							describeByDoc = getDocOfGivevRevItr(describeByDoc,rev,irev);
						}else{
							throw new WTException("Either Revision or Internal Revision is blank");
						}
						
						
						WTDocument latestDocRevision = (WTDocument)ObjectRevisionHelper.getLatestVersionByPersistable(relatedDoc);
						WTDocument latestDocIteration = (WTDocument) VersionControlHelper
								.getLatestIteration(latestDocRevision);
						LOGGER.debug("related Doc number "
								+ relatedDoc.getNumber());
						String typeName = TypedUtilityServiceHelper.service.getTypeIdentifier(latestDocIteration).getTypename();
						LOGGER.debug("related Doc typeName "
								+ typeName);
						
						if(typeName.equalsIgnoreCase("wt.doc.WTDocument|com.ptc.ReferenceDocument|com.ptc.KBCertificate") || typeName.equalsIgnoreCase("wt.doc.WTDocument|com.ptc.ReferenceDocument|com.ptc.KBStandard"))
						{
							LOGGER.debug("Going to create Reference link for doc number "+ latestDocIteration.getNumber());
							logWriter.info("Going to create Reference link for doc number "+ latestDocIteration.getNumber());
							WTDocumentMaster docMaster = (WTDocumentMaster) latestDocIteration.getMaster();
							WTPartReferenceLink newWTPartReferenceLink = WTPartReferenceLink.newWTPartReferenceLink(latestPartIteration, docMaster);
							LOGGER.debug("newWTPartReferenceLink " + newWTPartReferenceLink);
							PersistenceServerHelper.manager.insert(newWTPartReferenceLink);	
							LOGGER.debug("After creating Reference link for doc number "+ latestDocIteration.getNumber());
							logWriter.info("After creating Reference link for doc number "+ latestDocIteration.getNumber());
							
							if (shouldDocumentBeShared) {
								// Sharing the document to the projects where part is shared.
								logWriter.info("Sharing the reference doc to the projects where part is shared. "
										+ KBUtils.getIdentityWithStateAndRevision(latestDocIteration));
								shareDocument(sharedToProjects, latestDocIteration);
							}
						}
						else{
							LOGGER.debug("Going to create Describe link for doc number "+ describeByDoc.getNumber()+" "+describeByDoc.getIterationDisplayIdentifier());
							logWriter.info("Going to create Describe link for doc number "+ describeByDoc.getNumber());
							WTPartDescribeLink newWTDescribeUsageLink = WTPartDescribeLink
								.newWTPartDescribeLink(latestPartIteration,
										describeByDoc);
						LOGGER.debug("newWTPartUsageLink "
								+ newWTDescribeUsageLink);
						PersistenceServerHelper.manager
								.insert(newWTDescribeUsageLink);
						LOGGER.debug("After creating Describe link for doc number "+ describeByDoc.getNumber());
						logWriter.info("After creating Describe link for doc number "+ describeByDoc.getNumber());
						
							if (shouldDocumentBeShared) {
								// Sharing the document to the projects where part is shared.
								logWriter.info("Sharing the reference doc to the projects where part is shared. "
										+ KBUtils.getIdentityWithStateAndRevision(describeByDoc));
								shareDocument(sharedToProjects, describeByDoc);
	
							}
						}
						if(typeName.equalsIgnoreCase("wt.doc.WTDocument|com.ptc.KBDocuments|com.ptc.KBTechnicalDrawing|com.ptc.KBNeutralData")){
							LOGGER.debug("Document is Neutral Data "+latestDocIteration.getNumber());
							QuerySpec epmDoc = new QuerySpec();
							int epmIndex = epmDoc.appendClassList(EPMDocument.class, true);
							int epmMasterIndex = epmDoc.appendClassList(EPMDocumentMaster.class,false);
							epmDoc.appendWhere(new SearchCondition(EPMDocument.class,
									"masterReference.key.id", EPMDocumentMaster.class,
									"thePersistInfo.theObjectIdentifier.id"), new int[] {
									epmIndex, epmMasterIndex });
							epmDoc.appendAnd();
							epmDoc.appendWhere(new SearchCondition(EPMDocumentMaster.class, "number",
									SearchCondition.EQUAL, latestDocIteration.getNumber()),
									new int[] { epmMasterIndex });
							epmDoc.appendAnd();
							epmDoc.appendWhere(new SearchCondition(EPMDocument.class,"versionInfo.identifier.versionId", SearchCondition.EQUAL, latestDocIteration.getVersionIdentifier().getValue()),new int[]{epmIndex});
							QueryResult epmDocQR = PersistenceHelper.manager.find((StatementSpec) epmDoc);
							LOGGER.debug("Query Size : "+epmDocQR.size());
							String docVersion = latestDocIteration.getVersionIdentifier().getValue()+"."+latestDocIteration.getIterationIdentifier().getValue();
							LOGGER.debug("Document Version : "+docVersion);
							
							EPMDocument epmDocument =null;
							
							/*while(epmDocQR.hasMoreElements()){
								
								Persistable epmdocObj[] = (Persistable[]) epmDocQR.nextElement();
								epmDocument = (EPMDocument)epmdocObj[0];
								LOGGER.debug("EPMDocument version : "+epmDocument.getVersionIdentifier().getValue()+"."+epmDocument.getIterationIdentifier().getValue());
								
								
								QueryResult qrLatestItr = VersionControlHelper.service.allIterationsFrom(epmDocument);
								
								while(qrLatestItr.hasMoreElements()){
									epmDocument = (EPMDocument)qrLatestItr.nextElement();
									LOGGER.debug("EPM Version : "+epmDocument.isLatestIteration()+" "+epmDocument.getVersionIdentifier().getValue()+"."+epmDocument.getIterationIdentifier().getValue());
									if(epmDocument.isLatestIteration()){
										flag = true;
										break;
									}
								}
								
								if(flag) break;
							}*/
							if (epmDocQR.hasMoreElements()){
								Persistable epmdocObj[] = (Persistable[]) epmDocQR.nextElement();
								epmDocument = (EPMDocument)epmdocObj[0];
								LOGGER.debug("EPM Version : "+epmDocument.isLatestIteration()+" "+epmDocument.getVersionIdentifier().getValue()+"."+epmDocument.getIterationIdentifier().getValue());
								//epmDocument  = (EPMDocument)ObjectRevisionHelper.getLatestIterationOfVersion(epmDocument, true);
								EPMDocument latestEpmDocRevision = (EPMDocument)ObjectRevisionHelper.getLatestVersionByPersistable((EPMDocument)epmDocument);
								epmDocument = (EPMDocument) VersionControlHelper.getLatestIteration(latestEpmDocRevision);
								
							}
							
							if(epmDocument!=null){
								LOGGER.debug("latestEpmDocIteration -" +epmDocument);
								LOGGER.debug("EPM ver -> "+epmDocument.getVersionIdentifier().getValue()+"."+epmDocument.getIterationIdentifier().getValue());
								LOGGER.debug("epmDocument.getCheckoutInfo().getState().toString().equals(c/o)" +epmDocument.getCheckoutInfo().getState().toString().equals("c/o"));
								if(epmDocument.getCheckoutInfo().getState().toString().equals("c/o"))
								{
									LOGGER.debug("INSIDE getting checkoutcopy");
									WTPrincipal currentUser = SessionHelper.manager.getPrincipal();
									WTPrincipal wtAdministrator = SessionHelper.manager.getAdministrator();
									SessionHelper.manager.setPrincipal(wtAdministrator.getName());
									try {
										epmDocument = (wt.epm.EPMDocument) WorkInProgressHelper.service.workingCopyOf((Workable) epmDocument);
									} finally {
										SessionHelper.manager.setPrincipal(currentUser.getName());
									}
									LOGGER.debug("OUTSIDE getting checkoutcopy-> "+epmDocument);
								}
								LOGGER.debug("EPM Version : "+epmDocument.isLatestIteration()+" "+epmDocument.getVersionIdentifier().getValue()+"."+epmDocument.getIterationIdentifier().getValue());
								String epmTypeName = TypedUtilityServiceHelper.service.getTypeIdentifier(epmDocument).getTypename();
								LOGGER.debug("Type of CAD : "+epmTypeName+" EPMDocument ORG : "+epmDocument.getOrganization().getName());
								if(epmTypeName.contains("com.ptc.DesignCADDrw") && "KB".equalsIgnoreCase(epmDocument.getOrganization().getName())){
									String epmVersion = epmDocument.getVersionIdentifier().getValue()+"."+epmDocument.getIterationIdentifier().getValue();
									LOGGER.debug("EPM Version : "+epmVersion+" "+latestPartIteration.getVersionIdentifier().getValue()+"."+latestPartIteration.getIterationIdentifier().getValue());
												
										
											EPMDescribeLink epmDescribeLink = EPMDescribeLink.newEPMDescribeLink(latestPartIteration,epmDocument);
											epmDescribeLink.setBuiltFlag(false);
											PersistenceServerHelper.manager
											.insert(epmDescribeLink);
											epmDescribeLink = (EPMDescribeLink)PersistenceHelper.manager.refresh(epmDescribeLink);
											
											LOGGER.debug("EPM Describe link created successfully :" +epmDescribeLink);
									//		break;
								}
							}	
						}
					} else {
						LOGGER.debug("Document with number"+ docIDs[i][0] + " Not found going to create describe link with Dummy Document");
						logWriter.info("Document with number"+ docIDs[i][0] + " Not found going to create describe link with Dummy Document");
						QuerySpec dummyDoc = new QuerySpec();
						int docIndex = dummyDoc.appendClassList(WTDocument.class, true);
						int docMasterIndex = dummyDoc.appendClassList(WTDocumentMaster.class,false);
						dummyDoc.appendWhere(new SearchCondition(WTDocument.class,
								"masterReference.key.id", WTDocumentMaster.class,
								"thePersistInfo.theObjectIdentifier.id"), new int[] {
								docIndex, docMasterIndex });
						dummyDoc.appendAnd();
						dummyDoc.appendWhere(new SearchCondition(WTDocumentMaster.class, "number",
								SearchCondition.EQUAL, dummyDocNumber),
								new int[] { docMasterIndex });
						QueryResult dummyDocQR = PersistenceHelper.manager.find((StatementSpec) dummyDoc);
						LOGGER.debug("dummyDocQr size = "+dummyDocQR.size());
						logWriter.info("dummyDocQr size = "+dummyDocQR.size());
						Persistable dummyDocObj[] = (Persistable[]) dummyDocQR.nextElement();
						LOGGER.debug("dummyDocObj[0] " + dummyDocObj[0]);
						WTDocument dummyDocument = (WTDocument) dummyDocObj[0];
						//WTDocument dummyDocument = (WTDocument) dummyDocQR.nextElement();
						WTPartDescribeLink newWTDescribeUsageLink = WTPartDescribeLink.newWTPartDescribeLink(latestPartIteration,dummyDocument);
						LOGGER.debug("newWTPartUsageLink "+ newWTDescribeUsageLink);
						PersistenceServerHelper.manager.insert(newWTDescribeUsageLink);
						if (shouldDocumentBeShared) {
							// Sharing the document to the projects where part is shared.
							logWriter.info("Sharing the reference doc to the projects where part is shared. "
									+ KBUtils.getIdentityWithStateAndRevision(dummyDocument));
							shareDocument(sharedToProjects, dummyDocument);
						}
						LOGGER.debug("After creating Describe link for dummy doc number "+ dummyDocument.getNumber());
						logWriter.info("After creating Describe link for dummy doc number "+ dummyDocument.getNumber());
						
					}

				}

				System.out.println("trx==="+trx );
				trx.commit();
	            trx = null;	
	            result.add("0");
                result.add("Success");
                LOGGER.info(result);
                logWriter.info("Result for the service request is"+result);	
                return result;
			} else {
				throw new WTException("Part Not found");
			}
		} catch (WTException e) {
			String message = "WTException during create Describe Link Service exception is "
					+ e;
			result.add("1");
            result.add(message);
            LOGGER.info(result);
            logWriter.info("Result for the service request is"+result);	
            return result;

		} catch (WTPropertyVetoException e) {
			String message = "WTException during create Describe Link Service exception is "
					+ e;
			result.add("1");
            result.add(message);
            LOGGER.info(result);
            logWriter.info("Result for the service request is"+result);	
            return result;
		} finally {
			System.out.println("trx in finally===" + trx);
			if (trx != null) {
				trx.rollback();
			}

		}

	}
	
	
	/**
	 * @param latestPartIteration
	 * @param length
	 * @return a map with container reference and the folder in which the
	 *         latestPartIteration is shared
	 * @throws WTException
	 */
	private Map<WTContainerRef, Folder> getSharedToProjects(WTPart latestPartIteration, final int length) throws WTException {

		Map<WTContainerRef, Folder> sharedToProjects = null;
		final int state = Integer.parseInt(KBUtils.getKBStateNumericValueString(latestPartIteration));
		if(LOGGER.isDebugEnabled()) {
			LOGGER.debug("Part state is: " + state);
			LOGGER.debug("number of documents: " + length);
			LOGGER.debug("Is Design View? : " + KBUtils.isDesignView(latestPartIteration));
			LOGGER.debug("Is in KB? : " + KBUtils.isInKB(latestPartIteration));
		}
		if (length > 0 && state >= 1030 && KBUtils.isDesignView(latestPartIteration)
				&& KBUtils.isInKB(latestPartIteration)) {
			final WTPrincipal user = SessionHelper.manager.getPrincipal();
			final WTPrincipal admin = SessionHelper.manager.getAdministrator();
			SessionHelper.manager.setPrincipal(admin.getName());
			try {
				sharedToProjects = ProjectHelper.findSharedToProjectsFolderMap(latestPartIteration);
			} catch (final WTException e) {
				LOGGER.error("Exception while getting the part shares: ", e);
			} finally {
				SessionHelper.manager.setPrincipal(user.getName());
			}

		}
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Finding the projects in which the part is shared: "
					+ KBUtils.getIdentityWithStateAndRevision(latestPartIteration));
			LOGGER.debug("Shared To Projects: " + sharedToProjects);
		}

		return sharedToProjects;
	}

	/**
	 * @param sharedToProjects
	 * @param wtdocument
	 * @throws WTException
	 */
	private void shareDocument(Map<WTContainerRef, Folder> sharedToProjects, WTDocument wtdocument)
			throws WTException {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Sharing the associated doc to the projects where part is shared. "
					+ KBUtils.getIdentityWithStateAndRevision(wtdocument));
		}
		final WTPrincipal user = SessionHelper.manager.getPrincipal();
		final WTPrincipal admin = SessionHelper.manager.getAdministrator();
		SessionHelper.manager.setPrincipal(admin.getName());
		try {
			shareDocumentToProject(sharedToProjects, wtdocument);
		} catch (final WTException e) {
			LOGGER.error("Exception while sharing the document: ", e);
		} finally {
			SessionHelper.manager.setPrincipal(user.getName());
		}
	}

	/**
	 * @param sharedToProjects
	 * @param latestDocuments
	 * @throws WTException
	 */
	private void shareDocumentToProject(Map<WTContainerRef, Folder> sharedToProjects, WTDocument latestDocument)
			throws WTException {

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Sharing documents to: " + sharedToProjects);
		}
		final List<Persistable> finalShareList = new ArrayList<>();

		if (latestDocument != null) {
			finalShareList.addAll(KBUtils.getDocsToShare(latestDocument, true));
			final List<Persistable> relatedVariants = KBUtils.getVariantsToShare(finalShareList);
			finalShareList.addAll(relatedVariants);

			if (!finalShareList.isEmpty()) {
				for (final Map.Entry<WTContainerRef, Folder> entry : sharedToProjects.entrySet()) {
					final Set<Persistable> toBeShared = ProjectHelper.filterAlreadyShared(finalShareList,
							(Project2) entry.getKey().getObject());
					for (final Persistable toShare : toBeShared) {
						DataSharingHelper.service.shareVersion(toShare, entry.getKey(), entry.getValue());
					}
				}
			}
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Documents shared: " + finalShareList);
			LOGGER.debug("Executed shareDocumentToProject() for: " + latestDocument);
		}

	}
	

	private WTDocument getDocOfGivevRevItr(WTDocument relatedDoc, String rev, String irev) throws PersistenceException, WTException {
		
		WTDocument doc = null;
		if(relatedDoc!=null){
			
			QueryResult allVersions = VersionControlHelper.service.allVersionsOf(relatedDoc.getMaster());
			
			while(allVersions.hasMoreElements()){
				doc = (WTDocument) allVersions.nextElement();
				LOGGER.debug("Document version : "+doc.getIterationDisplayIdentifier());
				String docRev = doc.getVersionIdentifier().getValue();
				LOGGER.debug("docRev : "+docRev);
				if(docRev.equalsIgnoreCase(rev)){
					LOGGER.debug("Break");
					break;
				}
			}
			
			doc = getDocOfGivenItr(doc,irev);
			
		}else{
			throw new WTException("Document does not exist.");
		}
		return doc;
	}

	private WTDocument getDocOfGivenItr(WTDocument doc, String irev) throws PersistenceException, WTException {
		
		int i=0;
		WTDocument document = null;
		WTDocument docToCompare = null;
		ArrayList docList = new ArrayList();
		
		
		
		
		QueryResult qr = VersionControlHelper.service.iterationsOf(doc);
		LOGGER.debug("Query size : "+qr);
		while(qr.hasMoreElements()){
			
			 document =  (WTDocument) qr.nextElement();
			
			LOGGER.debug("Document is : "+document.getNumber()+" "+document.getIterationDisplayIdentifier());
			String internalRev = IBAHelper.readIBA(document, KBConstants.KB_INTERNAL_REVISION_IBA);
			LOGGER.debug("internalRev : "+internalRev);
			
			if(irev.equals("")||irev.equals(" ")){
				if("".equals(internalRev) || " ".equals(internalRev) || internalRev==null){
					LOGGER.debug("Adding DOC to list if blank");
					docList.add(document);
				}
			}
			else if(irev.equalsIgnoreCase(internalRev)){
				LOGGER.debug("Adding DOC to list");
				docList.add(document);
			}
			
		}
		
		
			Iterator itr = docList.iterator();
			while(itr.hasNext()){
				WTDocument wtdoc = (WTDocument) itr.next(); 
				
				if(i==0 && docList.size()>1){
					WTDocument wtdocument = (WTDocument) itr.next();
					docToCompare = compareIteration(wtdoc,wtdocument);
					i++;
				}else if(docList.size()>1){
					docToCompare = compareIteration(docToCompare,wtdoc);
				}else{
					docToCompare = wtdoc;
				}
				
			}
		
		if(docToCompare!=null){
			LOGGER.debug("Returning Latest Iteration : "+docToCompare.getNumber()+" Version : "+docToCompare.getIterationDisplayIdentifier());
		}else{
			throw new WTException("WTDocument "+doc.getNumber()+" with IREV "+irev+" does not exist.");
		}
		
		return docToCompare;
	}

	private WTDocument compareIteration(WTDocument docToCompare, WTDocument wtdocument) {
		
		int itr1 = Integer.parseInt(docToCompare.getIterationIdentifier().getValue());
		int itr2 = Integer.parseInt(wtdocument.getIterationIdentifier().getValue());
		LOGGER.debug("itr1 : "+itr1+"itr2 : "+itr2);
		if(itr1>itr2){
			return docToCompare;
		}else{
			return wtdocument;
		}
		
	}

	}