package ext.kb.ws;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import java.util.ArrayList;
import java.util.List;

import javax.jws.WebMethod;

import com.ptc.jws.servlet.JaxWsWebService;

import ext.kb.util.DocumentObject;
import ext.kb.util.RelationHelper;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;

@WebService()
public class KBPartDocumentRelationWebService extends JaxWsWebService
{
    @WebMethod(operationName="getRelation")
    
    public List<DocumentObject> getRelation( String oid, String masterSystem ) 
    {
	List<DocumentObject>details = new ArrayList();
      try {
    	  details = RelationHelper.getRelation(oid, masterSystem);
        } catch (Exception e) {
            e.printStackTrace();
        }
      return details;

    }
}