package ext.kb.ws;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import org.apache.log4j.Logger;
import wt.configurablelink.ConfigurableRevisionLink;
import wt.doc.WTDocument;
import wt.doc.WTDocumentMaster;
import wt.enterprise.RevisionControlled;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.folder.Folder;
import wt.inf.container.WTContainer;
import wt.inf.sharing.DataSharingHelper;
import wt.log4j.LogR;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.pds.StatementSpec;
import wt.projmgmt.admin.Project2;
import wt.projmgmt.admin.Project2Reference;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;
import wt.vc.VersionControlHelper;
import wt.vc.Versioned;

import com.ptc.jws.servlet.JaxWsWebService;

import ext.kb.service.WebServiceHelper;
import ext.kb.util.DBUtils;
import ext.kb.util.KBUtils;
import ext.kb.util.ObjectRevisionHelper;
import wt.util.WTPropertyVetoException;

@WebService()
public class KBUnShareDocumentToProjectLinkService extends JaxWsWebService
{
	private static final Logger LOGGER = LogR.getLogger(KBUnShareDocumentToProjectLinkService.class.getName());	
	private static final Logger logWriter = LogR.getLogger("ext.kb.ws.KBUnShareDocumentToProjectLinkService_Log");
	@WebMethod(operationName="UnShareDocumentToProject")
	public ArrayList<SharedDocumentObject> shareDocumentToProject (@WebParam(name="projectName") String projectName, @WebParam(name="sharedDocs")
	ArrayList<SharedDocumentObject> sharedDocs) throws WTPropertyVetoException,WTException, IOException
    
	{
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date date = new Date();
        String formatedDate = sdf.format(date);
        ArrayList<SharedDocumentObject> OutputArr = new ArrayList<SharedDocumentObject>();              
        logWriter.info(" Processing create Share Document to project on "+formatedDate+" request project name is "+projectName);
        
        LOGGER.debug("plantNumber" + projectName);
		logWriter.info("plantNumber" + projectName);
		
		for(int i=0;i<sharedDocs.size();i++)
		{
			SharedDocumentObject cdo = (SharedDocumentObject) sharedDocs.get(i);
			LOGGER.debug("Shared Object number" + cdo.getObjectNumber());
			LOGGER.debug("Shared Object Type" + cdo.getObjectType());
			LOGGER.debug("Shared Object Version" + cdo.getObjectVersion());
			logWriter.info("Shared Object number" + cdo.getObjectNumber());
			logWriter.info("Shared Object Type" + cdo.getObjectType());
			logWriter.info("Shared Object Version" + cdo.getObjectVersion());
			try
			{
									
			QuerySpec sharedObjQS = new QuerySpec();
			if(cdo.getObjectType().equalsIgnoreCase("WTDocument"))
			{
			int sharedObjIndex = sharedObjQS.appendClassList(WTDocument.class, true);
			int sharedObjMasterIndex = sharedObjQS.appendClassList(WTDocumentMaster.class,false);
			sharedObjQS.appendWhere(new SearchCondition(WTDocument.class,
					"masterReference.key.id", WTDocumentMaster.class,
					"thePersistInfo.theObjectIdentifier.id"), new int[] {
				sharedObjIndex, sharedObjMasterIndex });
			
			sharedObjQS.appendAnd();
			sharedObjQS.appendWhere(new SearchCondition(WTDocumentMaster.class, "number",
					SearchCondition.EQUAL, cdo.getObjectNumber()),
					new int[] { sharedObjMasterIndex });
			}
			if(cdo.getObjectType().equalsIgnoreCase("WTPart"))
			{
			int sharedObjIndex = sharedObjQS.appendClassList(WTPart.class, true);
			int sharedObjMasterIndex = sharedObjQS.appendClassList(WTPartMaster.class,false);
			sharedObjQS.appendWhere(new SearchCondition(WTPart.class,
					"masterReference.key.id", WTPartMaster.class,
					"thePersistInfo.theObjectIdentifier.id"), new int[] {
				sharedObjIndex, sharedObjMasterIndex });
			
			sharedObjQS.appendAnd();
			sharedObjQS.appendWhere(new SearchCondition(WTPartMaster.class, "number",
					SearchCondition.EQUAL, cdo.getObjectNumber()),
					new int[] { sharedObjMasterIndex });
			}
			QueryResult sharedObjQR = PersistenceHelper.manager.find((StatementSpec) sharedObjQS);
	    	int sharedObjSize = sharedObjQR.size();
			LOGGER.debug("sharedDocQR.size(): " + sharedObjQR.size());
			logWriter.info("sharedDocQR.size(): " + sharedObjQR.size());
			if(sharedObjQR.size()>0)
			{
				List<WTDocument> variantDocumentList = new ArrayList();
				Persistable sharedDocObj [] = (Persistable [])sharedObjQR.nextElement();
				LOGGER.debug("resObj: " + (Persistable)sharedDocObj[0]);
				logWriter.info("resObj: " + (Persistable)sharedDocObj[0]);
				Persistable sharedObj = (Persistable)sharedDocObj[0];
				Persistable latestReleasedSharedObjVer = WebServiceHelper.getLatestReleasedObjectVersion(sharedObj);
				LOGGER.debug("latestReleasedSharedObjVer: " + latestReleasedSharedObjVer);
				logWriter.info("latestReleasedSharedObjVer: " + latestReleasedSharedObjVer);
				
				if(cdo.getObjectType().equalsIgnoreCase("WTPart"))
				{
				
					if(latestReleasedSharedObjVer == null)
					{
						WTPart latestDocRevision = (WTPart)ObjectRevisionHelper.getLatestVersionByPersistable(sharedObj);
						latestReleasedSharedObjVer = (WTPart) VersionControlHelper.getLatestIteration(latestDocRevision);
					}
					LOGGER.debug("latestReleasedSharedObjVer version is " +((WTPart)latestReleasedSharedObjVer).getVersionIdentifier().getValue()+" Iteration is "+((WTPart)latestReleasedSharedObjVer).getIterationIdentifier().getValue());
					logWriter.info("latestReleasedSharedObjVer version is " +((WTPart)latestReleasedSharedObjVer).getVersionIdentifier().getValue()+" Iteration is "+((WTPart)latestReleasedSharedObjVer).getIterationIdentifier().getValue());
				}
				if(cdo.getObjectType().equalsIgnoreCase("WTDocument"))
				{
				
					if(latestReleasedSharedObjVer == null)
					{
						WTDocument latestDocRevision = (WTDocument)ObjectRevisionHelper.getLatestVersionByPersistable(sharedObj);
						latestReleasedSharedObjVer = (WTDocument) VersionControlHelper.getLatestIteration(latestDocRevision);
					}
					LOGGER.debug("latestReleasedSharedObjVer version is " +((WTDocument)latestReleasedSharedObjVer).getVersionIdentifier().getValue()+" Iteration is "+((WTDocument)latestReleasedSharedObjVer).getIterationIdentifier().getValue());
					logWriter.info("latestReleasedSharedObjVer version is " +((WTDocument)latestReleasedSharedObjVer).getVersionIdentifier().getValue()+" Iteration is "+((WTDocument)latestReleasedSharedObjVer).getIterationIdentifier().getValue());
					variantDocumentList = DBUtils.navigateBetweenObjects(WTDocument.class, ConfigurableRevisionLink.class, latestReleasedSharedObjVer, ConfigurableRevisionLink.ROLE_BOBJECT_ROLE);
					LOGGER.debug("No of variant documents is "+variantDocumentList.size());
					logWriter.info("No of variant documents is "+variantDocumentList.size());
					LOGGER.debug("latestReleasedSharedObjVer version is " +((WTDocument)latestReleasedSharedObjVer).getVersionIdentifier().getValue()+" Iteration is "+((WTDocument)latestReleasedSharedObjVer).getIterationIdentifier().getValue());
					logWriter.info("latestReleasedSharedObjVer version is " +((WTDocument)latestReleasedSharedObjVer).getVersionIdentifier().getValue()+" Iteration is "+((WTDocument)latestReleasedSharedObjVer).getIterationIdentifier().getValue());
				}
							
				Project2Reference projectRef = new Project2Reference();
				LOGGER.debug("projectRef: " + projectRef);
				logWriter.info("projectRef: " + projectRef);
				projectName = "Plant - "+projectName;
				LOGGER.debug("projectName" + projectName);
				logWriter.info("projectName" + projectName);
				Project2 prj = (Project2) getProjectContainer(projectName);
				LOGGER.debug("prj: " + prj);
				logWriter.info("prj: " + prj);
				projectRef.setObject(prj);
				LOGGER.debug("After setting to prj ref: ");
				logWriter.info("After setting to prj ref:  ");
				Folder f = prj.getDefaultCabinet();
				LOGGER.debug("folder: " +f);
				logWriter.info("fodler: " +f);
				
				List<Persistable> revisionsToShare = lastThreeRevisionsWithStateEqGtThan1050(latestReleasedSharedObjVer);
				for (Persistable toUnshare : revisionsToShare) {
					boolean shared = DataSharingHelper.isShared(toUnshare);
					if(shared)
					{
					DataSharingHelper.service.removeShare(toUnshare, projectRef);
					LOGGER.debug("After unsharing document from project: ");
					logWriter.info("After unsharing document from project:: ");
					}
					else
					{
						SharedDocumentObject errorSDO = new SharedDocumentObject();
						errorSDO.setObjectNumber(cdo.getObjectNumber());
						 errorSDO.setObjectType(cdo.getObjectType());
						 errorSDO.setObjectVersion(cdo.getObjectVersion());
						errorSDO.setMessage("The Object is not shared to project");
						 OutputArr.add(errorSDO);	
					}
				}
								
				if(cdo.getObjectType().equalsIgnoreCase("WTDocument"))
				{
				if (variantDocumentList.size() > 0) {
					LOGGER.debug("Variant Document exists going to unshare it also with project");
					logWriter.info("Variant Document exists going to unshare it also with project");
					for (WTDocument variantDoc : variantDocumentList) {
						boolean varshared = DataSharingHelper.isShared(variantDoc);
						if(varshared)
						{
						DataSharingHelper.service.removeShare(variantDoc, projectRef);
						LOGGER.debug("After unsharing "+variantDoc.getNumber()+" and name "+ variantDoc.getName()+" and  version " +variantDoc.getVersionIdentifier().getValue()+" Iteration "+variantDoc.getIterationIdentifier().getValue()+" document from project ");
						logWriter.info("After unsharing "+variantDoc.getNumber()+" and name "+ variantDoc.getName()+" and  version " +variantDoc.getVersionIdentifier().getValue()+" Iteration "+variantDoc.getIterationIdentifier().getValue()+" document from project ");
						}
						else
						{
						LOGGER.debug("variantDoc number "+variantDoc.getNumber()+" and name "+ variantDoc.getName()+" and  version " +variantDoc.getVersionIdentifier().getValue()+" Iteration "+variantDoc.getIterationIdentifier().getValue()+" is not shared to project");
						logWriter.info("variantDoc number "+variantDoc.getNumber()+" and name "+ variantDoc.getName()+" and version " +variantDoc.getVersionIdentifier().getValue()+" Iteration "+variantDoc.getIterationIdentifier().getValue()+" is not shared to project");
						}
					}
				}
				}
									     					
			}	
			else{
	    		 
	    		 LOGGER.debug("Document with number"+ cdo.getObjectNumber() + " Not found");
				 logWriter.info("Document with number"+ cdo.getObjectNumber() + " Not found");
				 throw new WTException("Document with number"+ cdo.getObjectNumber() + " Not found");
				
	    	 }
			}
			 catch (WTException e) {
				 SharedDocumentObject errorSDO = new SharedDocumentObject();
				 errorSDO.setObjectNumber(cdo.getObjectNumber());
				 errorSDO.setObjectType(cdo.getObjectType());
				 errorSDO.setObjectVersion(cdo.getObjectVersion());
				 errorSDO.setMessage(e.getMessage());
				 LOGGER.debug("Document with number"+ cdo.getObjectNumber() + " has exception error message "+e.getMessage());
				 logWriter.info("Document with number"+ cdo.getObjectNumber() + " has exception error message "+e.getMessage());
				 OutputArr.add(errorSDO);		                 
		        } 
						
		}	

        return OutputArr;
        }
       
	
	private List<Persistable> lastThreeRevisionsWithStateEqGtThan1050(Persistable latestReleasedSharedObjVer)
			throws WTPropertyVetoException,WTException {
		List<Persistable> lastThreeRevisionsWithStateEqGtThan1050 = new ArrayList<>();
		QueryResult allVersionsOf = VersionControlHelper.service.allVersionsOf((Versioned) latestReleasedSharedObjVer);
		while (allVersionsOf.hasMoreElements()) {
			Persistable p = (Persistable) allVersionsOf.nextElement();
			if(p!=null && p instanceof WTPart){
				//retrieving design view part
				p = WebServiceHelper.getDesignViewPart((WTPart)p);
			}
			int state = Integer.parseInt(KBUtils.getKBStateNumericValueString((RevisionControlled) p));
			if (state >= 1050 && !lastThreeRevisionsWithStateEqGtThan1050.contains(p)) {
				lastThreeRevisionsWithStateEqGtThan1050.add(p);
			}
			if (lastThreeRevisionsWithStateEqGtThan1050.size() == 3) {
				break;
			}
		}
		return lastThreeRevisionsWithStateEqGtThan1050;
	}
       	
	 private static WTContainer getProjectContainer(String projName) throws WTException {

			WTContainer cont = null;

			try{

				int[] fromIndicies = { 0, -1 };

		

				QuerySpec querySpec = new QuerySpec(Project2.class);

				querySpec.appendWhere(new SearchCondition(Project2.class,

						Project2.NAME, SearchCondition.EQUAL, projName),

						fromIndicies);

			

				Enumeration contEnum = PersistenceHelper.manager

						.find((StatementSpec) querySpec);

				if (contEnum.hasMoreElements()){

					cont = (WTContainer) contEnum.nextElement();
					LOGGER.debug("project found with name "+projName);

				}	
				if(cont == null){
					throw new WTException("Project does not exist ");
				}

			}catch(WTException e){

				e.printStackTrace();
				throw new WTException("Exception while searching for project error message is "+e.getMessage());
				}

			return cont;

		}
}