package ext.kb.service;

import java.beans.PropertyVetoException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.Vector;

import org.apache.log4j.Logger;

import wt.content.ApplicationData;
import wt.content.ContentHelper;
import wt.content.ContentHolder;
import wt.content.ContentRoleType;
import wt.fc.QueryResult;
import wt.log4j.LogR;
import wt.representation.Representable;
import wt.representation.Representation;
import wt.representation.RepresentationHelper;
import wt.util.WTException;

/**
 * A helper class with static methods to retrieve contents by content holder.<br>
 * Created on 04.02.2016.
 * 
 * @author wang
 * @version $Revision: 1.2 $ $Date: 2020/12/29 11:10:28IST $ $Author: Bharade, Deepali (ext) (ext-bharaded) $
 */
public class KBContentHelper {
    private static Logger logger = LogR.getLogger(KBContentHelper.class.getName());

    /**
     * Retrieves the primary content container, i.e., the
     * {@link ApplicationData} .
     * 
     * @param contentHolder
     * @return <tt>null</tt> if no primary content for that holder
     * @throws WTException
     * @throws PropertyVetoException
     * @throws IOException
     */
    public static ApplicationData retrievePrimaryContentContainer(ContentHolder contentHolder)
            throws WTException, PropertyVetoException, IOException {
        final QueryResult queryResult = ContentHelper.service.getContentsByRole(contentHolder,
            ContentRoleType.PRIMARY);

        // no more than 1 primary, therefore no loop:
        if (queryResult.hasMoreElements()) {
            Object nextElement = queryResult.nextElement();
            if (nextElement instanceof ApplicationData) {
                logger.trace("ApplicationData for primary: " + nextElement);
                return (ApplicationData) nextElement;
            }
            else {
                logger.trace("nextElement: " + nextElement);
            }
        }
        return null;
    }

    /**
     * Retrieves {@link Representation}s for the given holder.
     * 
     * @param representable
     * @return a list of {@link Representation}s. May be empty but cannot be
     *         <tt>null</tt>.
     * @throws WTException
     */
    public static List<Representation> retrieveRepresentations(final Representable representable)
            throws WTException {
        String methodName = "getRepresentations";
        logger.debug("Entering " + methodName + "...");

        final List<Representation> repList = new ArrayList<>();

        try {
            QueryResult queryResult = RepresentationHelper.service
                    .getRepresentations(representable);

            while (queryResult.hasMoreElements()) {
                Representation currentRep = (Representation) queryResult.nextElement();
                repList.add(currentRep);
            }
        } catch (WTException e) {
            logger.error("Failed to retrieve representations", e);
            throw e;
        }

        logger.debug("Exit     " + methodName + " (OK)");
        return repList;
    }

    /**
     * Retrieves attachment containers, i.e., {@link ApplicationData}s.
     * 
     * @param contentHolder
     * @return a set of {@link ApplicationData}s. May be empty but cannot be
     *         <tt>null</tt>.
     * @throws WTException
     * @throws PropertyVetoException
     */
    @SuppressWarnings("unchecked")
    public static Set<ApplicationData> retrieveAttachmentContainer(ContentHolder contentHolder)
            throws WTException, PropertyVetoException {

        final Set<ApplicationData> attachements = new HashSet<ApplicationData>();

        try {
            contentHolder = ContentHelper.service.getContents(contentHolder);

            Vector contentList = ContentHelper.getContentList(contentHolder);
            Vector contentListAll = ContentHelper.getContentListAll(contentHolder);
            logger.debug("ContentList size=== "+contentList.size());
            //System.out.println("ContentList size=== "+contentList.size());
            
            //System.out.println("contentListAll size=== "+contentListAll.size());

            // cast to ApplicationData and add to list of attachments
            for (Object contentItem : contentListAll) {
                if (contentItem instanceof ApplicationData) {
                    ApplicationData appData = (ApplicationData) contentItem;
                    attachements.add(appData);

                    logger.trace("ApplicationData for attachment: " + appData);
                }
                else {
                    logger.warn("Found unexpected type <" + contentItem + "> as attachment.");
                }
            }
        } catch (WTException | PropertyVetoException e) {
            logger.error("Failed to retrieve secondary content from <" + contentHolder + ">.", e);
            throw e;
        }

        return attachements;
    }
}
