package ext.kb.ws;

import com.ptc.jws.servlet.JaxWsWebService;
import ext.kb.tool.LogKlaUpdateTool;
import org.apache.log4j.Logger;
import wt.log4j.LogR;

import javax.jws.Oneway;
import javax.jws.WebMethod;
import javax.jws.WebService;

@WebService()
public class LogKlaUpdateWebService extends JaxWsWebService
{
    private static Logger log = LogR.getLogger(LogKlaUpdateWebService.class.getName());

    @WebMethod(operationName="logKlaUpdate")
    @Oneway
    public void logKlaUpdate (String inputFile, String logsPath)
    {
        try {
            LogKlaUpdateTool.logKlaUpdate(inputFile, logsPath);
        } catch (Exception e) {
            log.error(e);
        }
    }
}