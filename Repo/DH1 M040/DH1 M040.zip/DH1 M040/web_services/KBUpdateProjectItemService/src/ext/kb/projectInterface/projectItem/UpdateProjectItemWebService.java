package ext.kb.projectInterface.projectItem;

import java.util.ArrayList;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import ext.kb.projectInterface.projectItem.ProjectItemHelper;

import com.ptc.jws.servlet.JaxWsWebService;

@WebService()
public class UpdateProjectItemWebService extends JaxWsWebService{
	
	@WebMethod(operationName="updateProjectService")
	
	public List<String> updateProjectService(@WebParam(name="projectDetails") ArrayList<ProjectItemObject> projectDetails)
    {
		List<String>message = new ArrayList();
      try {
            message =  ProjectItemHelper.updateProject(projectDetails);
            
        } catch (Exception e) {
            e.printStackTrace();
        }
      return message;
    }

}

