package ext.kb.service;

import java.text.MessageFormat;
import java.util.Iterator;

import org.apache.log4j.Logger;

import wt.content.ApplicationData;
import wt.content.ContentHolder;
import wt.content.ContentRoleType;
import wt.content.ContentServerHelper;
import wt.enterprise.RevisionControlled;
import wt.epm.EPMDocument;
import wt.fc.ObjectReference;
import wt.fc.collections.WTArrayList;
import wt.fc.collections.WTCollection;
import wt.fc.collections.WTList;
import wt.log4j.LogR;
import wt.util.WTException;

/**
 * 
 * Created on 22.03.2016.
 * 
 */
public class KBContent {
    private static Logger log = LogR.getLogger(KBContent.class.getName());

    private ApplicationData appData;
    private ContentHolder holder;
    private String filename;

    public KBContent(ApplicationData appData) throws WTException {
        this.appData = appData;
        retrieveHolder();
        generateFilename();
    }

    private void retrieveHolder() throws WTException {
        WTList wtCollection = new WTArrayList();
        wtCollection.add(appData);
        WTCollection holderCollection = ContentServerHelper
                .getRelatedContentHolderCollection(wtCollection);
        int counter = 0;
        for (Iterator iterator = holderCollection.iterator(); iterator.hasNext();) {
            Object object = iterator.next();
            ObjectReference or = (ObjectReference) object;
            this.holder = (ContentHolder) or.getObject();

            log.debug("Content holder: " + holder);

            counter++;
        }
        if (counter != 1) {
            throw new WTException(MessageFormat.format(
                "Unexpected number of holder for content {0}: {1}", this.appData, counter));
        }
    }

    private void generateFilename() {
        final String version = generateVersionSufix();
        if (ContentRoleType.PRIMARY.equals(this.appData.getRole())
            && this.holder instanceof EPMDocument) {
            EPMDocument epmDoc = (EPMDocument) holder;
            this.filename = appendVersion(epmDoc.getCADName(), version);
            log.debug("Content filename: " + filename);
        }
        else {
            this.filename = appendVersion(this.appData.getFileName(), version);
            log.debug("Content filename: " + filename);
        }
    }

    private String appendVersion(String fileName, String version) {
        int index = fileName.lastIndexOf('.');
        if(index<0){
            return fileName+version;
        }
        
        String extension = fileName.substring(index + 1);
        String name = fileName.substring(0, index);
        return name + version + "." + extension;
    }

    /**
     * @return "_REVISOIN_ITERATION"
     */
    private String generateVersionSufix() {
        if (holder instanceof RevisionControlled) {
            RevisionControlled rc = (RevisionControlled) holder;
            String revision = rc.getVersionIdentifier().getValue();
            String iteration = rc.getIterationIdentifier().getValue();
            return "_" + revision + "_" + iteration;
        }
        else {
            return "";
        }
    }

    public String getFilename() {
        return filename;
    }

    /**
     * @return Returns the holder.
     */
    public ContentHolder getHolder() {
        return holder;
    }

}
