package ext.kb.service;

import java.beans.PropertyVetoException;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.Vector;

import org.apache.log4j.Logger;

import wt.access.AccessControlHelper;
import wt.access.AccessPermission;
import wt.content.ApplicationData;
import wt.content.ContentHelper;
import wt.content.ContentHolder;
import wt.content.ContentRoleType;
import wt.content.ContentServerHelper;
import wt.content.HolderToContent;
import wt.doc.WTDocument;
import wt.enterprise.RevisionControlled;
import wt.epm.EPMDocument;
import wt.fc.Persistable;
import wt.fc.ReferenceFactory;
import wt.fc.WTObject;
import wt.fc.WTReference;
import wt.log4j.LogR;
import wt.org.OrganizationServicesHelper;
import wt.org.WTPrincipal;
import wt.representation.Representable;
import wt.representation.Representation;
import wt.session.SessionHelper;
import wt.util.WTContext;
import wt.util.WTException;
import wt.util.WTProperties;
import wt.util.WTPropertyVetoException;
import wt.util.WTRuntimeException;


/**
 * This service exposes a static method {@link getContentUrls} that is called
 * from a Web service running on the same method server. <br>
 * Created on 02.02.2016.
 * 
 */
public class KBDownloadContentHelper {
    private static Logger log = LogR.getLogger(KBDownloadContentHelper.class.getName());

    /**
     * Authenticates to method server with a given user name. It is not for
     * remote access to Windchill.
     *
     * @param username a Windchill user name
     * @throws WTException
     */
    private static void authenticate3(String username) throws WTException {
        log.debug("Authenticating with " + username);

        WTContext.getContext().setLocale(Locale.UK);

        try {
            WTPrincipal newPrincipal = SessionHelper.manager.setPrincipal(username);
            log.trace("newPrincipal:" + newPrincipal);
            WTPrincipal newPrincipal2 = SessionHelper.manager.getPrincipal();
            log.trace("newPrincipal2:" + newPrincipal2);

        } catch (WTException e1) {
            log.error(e1);
        }

    }

    /**
     * Filters an array of URLs by the given user and the access permission
     * 
     * @param urls contains the key of Application Data object.
     * @param permissionName
     * @param user
     * @param password
     * @return
     * @throws WTException
     */
    public static String[] filterContentUrls(String[] urls, String permissionName, String user) throws WTException {
        log.debug("URLs to be filtered: " + urls.length);
        authenticate3(user);

        final WTPrincipal wtPrincipal = (WTPrincipal) OrganizationServicesHelper.manager.getUser(
            user, OrganizationServicesHelper.manager.newDirectoryContextProvider((String[]) null,
                (String[]) null));
        final AccessPermission permission = getAccessPermission(permissionName);

        final List<String> resultList = new ArrayList<>();
        for (String each : urls) {
            WTObject wtObject = obtainWTObject(each);
            if (AccessControlHelper.manager.hasAccess(wtPrincipal, wtObject, permission)) {
                resultList.add(each);
                log.trace("URL " + each + " has access");
            }
            log.trace("URL " + each + " filtered out.");
        }
        log.debug("URLs after filter: " + resultList.size());
        return resultList.toArray(new String[0]);
    }

    public static String downloadPermittedContent(String[] urls, String permissionName,
            String user) throws WTException, IOException, WTPropertyVetoException {
        authenticate3(user);
        
        final WTPrincipal wtPrincipal = (WTPrincipal) OrganizationServicesHelper.manager.getUser(
            user, OrganizationServicesHelper.manager.newDirectoryContextProvider((String[]) null,
                (String[]) null));
        final AccessPermission permission = getAccessPermission(permissionName);
        final File location = getSaveLocation("SAP_TRANSFER_LOCATION");

        //final List<String> resultList = new ArrayList<>();
		String result = "5";
		
		 for (String url : urls) {
            //if (filterAndDownload(url, wtPrincipal, permission, location)) {
                //resultList.add(url);
            //}
			result = filterAndDownload(url, wtPrincipal, permission, location);
        }

        //return resultList.toArray(new String[0]);
		return result;
    }

    /**
     * Reads the value from wt.properties file for the given property name, and
     * creates a File object of it.
     * 
     * @param propertyName property name
     * @return a File object of the directory specified by the property
     * @throws IOException
     */
    private static File getSaveLocation(String propertyName) throws IOException {
        final WTProperties properties = WTProperties.getServerProperties();
        final String value = properties.getProperty(propertyName);
        log.debug(propertyName + ": " + value);

        return new File(value);
    }

    /**
     * .
     * 
     * @param url
     * @param wtPrincipal
     * @param permission
     * @return
     * @throws IOException
     * @throws WTPropertyVetoException
     */
    private static String filterAndDownload(String url, WTPrincipal wtPrincipal,
            AccessPermission permission, File location) throws WTException, IOException,
            WTPropertyVetoException {
				String returnVal = "5";
				try
				{
					final String coid = fetchCoid(url);
					ApplicationData appData = obtainWTObject(url);
					
					log.trace("Got " + appData + " from url " + url);
					final File subFolder = makeSubFolder(location, coid);
		
					if (!AccessControlHelper.manager.hasAccess(wtPrincipal, appData, permission)) {
						returnVal = "2";
					}

					final KBContent kbContent = new KBContent(appData);

					if (null == appData.getHolderLink()) {
						HolderToContent holderLink = HolderToContent.newHolderToContent(kbContent.getHolder(),
							appData);
						appData.setHolderLink(holderLink);
						log.debug(appData.getHolderLink().getContentHolder());
					}

					String path=new File(subFolder, kbContent.getFilename()).getCanonicalPath();
					log.debug("writeContentStream for " + appData + " to "  +path);
					ContentServerHelper.service.writeContentStream(appData, path);

					returnVal = "0 coid is "+coid;
				}
				catch(IOException e)
				{
					returnVal = "3"; 
					e.printStackTrace();
				}
				catch(WTException e)
				{
					returnVal = "1";
					e.printStackTrace();
				}
				catch(WTRuntimeException e)
				{
					returnVal = "1";
					e.printStackTrace();
				}
				return returnVal;
			}
			
	private static File makeSubFolder(File location, String coid) throws IOException {
        File subFolder = new File(location, coid);
        if (!subFolder.mkdir()) {
            throw new IOException("Failed to create directory " + subFolder);
        }
        return subFolder;
    }
	
	private static String fetchCoid(String url) {
        int lastIndex = url.lastIndexOf("?coid=");
        String coid = url.substring(lastIndex + 6);
        return coid;
    }


    private static AccessPermission getAccessPermission(String permission) {
        switch (permission) {
            case "ALL":
                return AccessPermission.toAccessPermission("-1");
            case "READ":
                return AccessPermission.toAccessPermission("0");
            case "DOWNLOAD":
                return AccessPermission.toAccessPermission("10");
            case "MODIFY":
                return AccessPermission.toAccessPermission("1");
            case "MODIFY_CONTENT":
                return AccessPermission.toAccessPermission("11");
            case "MODIFY_IDENTITY":
                return AccessPermission.toAccessPermission("16");
            case "CREATE_BY_MOVE":
                return AccessPermission.toAccessPermission("13");
            case "CREATE":
                return AccessPermission.toAccessPermission("2");
            case "SET_STATE":
                return AccessPermission.toAccessPermission("15");
            case "REVISE":
                return AccessPermission.toAccessPermission("7");
            case "NEW_VIEW_VERSION":
                return AccessPermission.toAccessPermission("8");
            case "CHANGE_DOMAIN":
                return AccessPermission.toAccessPermission("12");
            case "CHANGE_CONTEXT":
                return AccessPermission.toAccessPermission("14");
            case "CHANGE_PERMISSIONS":
                return AccessPermission.toAccessPermission("9");
            case "DELETE":
                return AccessPermission.toAccessPermission("5");
            case "ADMINISTRATIVE":
                return AccessPermission.toAccessPermission("6");
            default:
                return AccessPermission.toAccessPermission(permission);
        }
    }

    /**
     * Retrieves a WTObject from the given URL.
     * 
     * @param url Example of URL:
     *            <code>http://mucs70029.corp.knorr-bremse.com:1080/Windchill
     *            /ptc1/download/KB_File_Download?coid=822140</code>
     *            .Here the coid is the id for the application data.
     * @return
     * @throws WTException
     */
    private static ApplicationData obtainWTObject(String url) throws WTException {
        int lastIndex = url.lastIndexOf("?coid=");
        String key = url.substring(lastIndex + 6);

        WTReference reference = (new ReferenceFactory())
                .getReference("OR:wt.content.ApplicationData:" + key);
        final Persistable persistable = reference.getObject();
        log.trace("Got " + persistable + " from url " + url);

        return (ApplicationData) persistable;
    }
}
