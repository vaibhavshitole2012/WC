/* $Header: WorkflowHelper.java 1.2.2.10.2.1 2020/05/04 12:34:34IST Krzeminski, Sebastian (ext) (ext-krzemins) Exp  $ */

/**
*** Purpose: 	This class helps during the execution of a workflow.
*** Autor:   	ghimmelsbach@ptc.com
*** History: 	20050120 ghimmelsbach@ptc.com, initial release
**/
// 20061205 mkr; fix deletePredecessorLink (while loop)
// 20070831 mkr; substitute ufidhelper calls, add version

package ext.tools;

import com.infoengine.SAK.Task;
import com.infoengine.object.factory.Element;
import com.infoengine.object.factory.Group;
import ext.kb.util.KBUtils;
import ext.kb.workflow.EPMChangeUtils;
import org.apache.log4j.Logger;
import wt.change2.*;
import wt.doc.DepartmentList;
import wt.doc.DocumentType;
import wt.doc.WTDocument;
import wt.enterprise.RevisionControlled;
import wt.epm.EPMDocument;
import wt.epm.EPMDocumentMaster;
import wt.epm.structure.EPMDescribeLink;
import wt.epm.structure.EPMReferenceLink;
import wt.fc.*;
import wt.folder.Cabinet;
import wt.folder.FolderHelper;
import wt.inf.container.WTContainerHelper;
import wt.lifecycle.LifeCycleHelper;
import wt.lifecycle.LifeCycleManaged;
import wt.lifecycle.State;
import wt.org.*;
import wt.part.WTPart;
import wt.part.WTPartDescribeLink;
import wt.pom.Transaction;
import wt.project.Role;
import wt.query.*;
import wt.series.MultilevelSeries;
import wt.session.SessionMgr;
import wt.team.*;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.vc.*;
import wt.vc.baseline.BaselineHelper;
import wt.vc.baseline.ManagedBaseline;
import wt.vc.baseline.ManagedBaselineIdentity;
import wt.vc.views.View;
import wt.vc.wip.CheckoutLink;
import wt.vc.wip.WorkInProgressHelper;
import wt.vc.wip.Workable;
import wt.workflow.WfException;
import wt.workflow.engine.*;

import java.util.*;

public class WorkflowHelper {

	public static final String VERSION = "1.01";
	public static final String CVSVersion = "$Header: WorkflowHelper.java 1.2.2.10.2.1 2020/05/04 12:34:34IST Krzeminski, Sebastian (ext) (ext-krzemins) Exp  $";
	private static Logger logger = Logger.getLogger("ext.tools.WorkflowHelper");
	public static State[] validReleaseStates = { State.toState("RELEASED"), };

	/**
	 * Is state a valid release state.
	 *
	 * @param State
	 *            - state to verify
	 * @return boolean true if valid
	 **/
	public static boolean isValidReleaseStatus(State s) {
		if (logger.isDebugEnabled()) {
			logger.debug("entering isValidReleaseStatus(State)");
			logger.debug("s: " + s);
		}
		boolean valid = false;
		try {
			for (int i = 0; i < validReleaseStates.length; i++)
				if (validReleaseStates[i] == s)
					valid = true;
		} catch (Exception e) {
			e.printStackTrace();
			// S.append(e.getMessage());
		}
		if (logger.isDebugEnabled()) {
			logger.debug("exiting isValidReleaseStatus()");
			logger.debug("returning: " + (valid));
		}
		return (valid);
	}

	/**
	 * Remove extension ".drw" from string.
	 *
	 * @param String
	 *            s the string
	 * @return String without extension
	 **/
	public static String removeDrwExtension(String s) {
		if (logger.isDebugEnabled()) {
			logger.debug("entering removeDrwExtension(String)");
			logger.debug("s: \"" + s + "\"");
		}
		// check the number to not include .drw
		int a = s.toUpperCase().lastIndexOf(".DRW");
		if (a >= 0)
			s = s.substring(0, a);
		logger.debug("WorkflowHelper.removeDrwExtension: new string=" + s);
		if (logger.isDebugEnabled()) {
			logger.debug("exiting removeDrwExtension()");
			logger.debug("returning: " + (s));
		}
		return (s);
	}

	/**
	 * Create a new tiff doc.
	 *
	 * @param epmDocument
	 *            EPMDocument object
	 **/
	public static WTDocument createNewTiff(WTPart p, String num, String name, String type, String department, String lc,
			String folder) {
		if (logger.isDebugEnabled()) {
			logger.debug("entering createNewTiff(WTPart,String,String,String,String,String,String)");
			logger.debug("p: " + p);
			logger.debug("num: \"" + num + "\"");
			logger.debug("name: \"" + name + "\"");
			logger.debug("type: \"" + type + "\"");
			logger.debug("department: \"" + department + "\"");
			logger.debug("lc: \"" + lc + "\"");
			logger.debug("folder: \"" + folder + "\"");
		}
		WTDocument d = null;
		logger.debug("WorkflowHelper.createNewTiff: --> start");
		try {
			num = removeDrwExtension(num);

			// Set Document Type
			d = WTDocument.newWTDocument(num, name, DocumentType.toDocumentType(type));
			wt.type.TypeDefinitionReference tr = wt.type.TypedUtility.getTypeDefinitionReference("NeutralFormatDoc2D");
			logger.debug("WorkflowHelper.createNewTiff: type=" + tr);
			if (tr != null)
				d.setTypeDefinitionReference(tr);

			// Set Department
			if (department != null)
				d.setDepartment(DepartmentList.toDepartmentList(department));
			else
				d.setDepartment(DepartmentList.getDepartmentListDefault());

			// Set LifeCycle
			if (lc != null)
				LifeCycleHelper.setLifeCycle(d, LifeCycleHelper.service.getLifeCycleTemplate(lc));
			else
				LifeCycleHelper.setLifeCycle(d, LifeCycleHelper.service.getLifeCycleTemplate("Default"));

			// Set location
			if (folder == null) {
				WTPrincipal user = SessionMgr.getPrincipal();
				Cabinet personalCabinet = FolderHelper.service.getPersonalCabinet(user);
				FolderHelper.assignLocation(d, personalCabinet);
			} else {
				FolderHelper.assignLocation(d, folder);
			}
			d = (WTDocument) PersistenceHelper.manager.store(d);

		} catch (wt.pom.UniquenessException e) {
			if (logger.isDebugEnabled()) {
				logger.debug("WorkflowHelper.createNewTiff: " + e);
			}
		} catch (WTPropertyVetoException e) {
			if (logger.isDebugEnabled()) {
				logger.debug("WorkflowHelper.createNewTiff: " + e);
			}
		} catch (WTException e) {
			if (logger.isDebugEnabled()) {
				logger.debug("WorkflowHelper.createNewTiff: " + e);
			}
		}
		if (logger.isDebugEnabled()) {
			logger.debug("WorkflowHelper.createNewTiff: --> end");
		}
		if (logger.isDebugEnabled()) {
			logger.debug("exiting createNewTiff()");
			logger.debug("returning: " + (d));
		}
		return (d);
	}

	/**
	 * Revise tiff doc.
	 *
	 * @param WTDocument
	 *            doc the document to revise
	 * @return WTDocument the newly revised WTDocument
	 **/
	public static WTDocument reviseTiff(WTDocument doc) {
		if (logger.isDebugEnabled()) {
			logger.debug("entering reviseTiff(WTDocument)");
			logger.debug("doc: " + doc);
		}
		logger.info("WorkflowHelper.reviseTiff: --> start");
		logger.debug(
				"WorkflowHelper.reviseTiff: revise doc: " + (doc == null ? "null" : "" + doc.getDisplayIdentifier()));
		try {
			doc = (wt.doc.WTDocument) wt.vc.VersionControlHelper.getLatestIteration(doc);
			wt.doc.WTDocument newVersion = null;
			newVersion = (wt.doc.WTDocument) wt.vc.VersionControlHelper.service.newVersion((wt.vc.Versioned) doc);
			// com.ptc.windchill.pdmlink.repository.common.PDMLinkRepositoryHelper.setRepository(newVersion,
			// com.ptc.windchill.pdmlink.repository.common.PDMLinkRepositoryHelper.getRepository(doc),true);
			// wt.folder.FolderHelper.assignLocation((wt.folder.Foldered)newVersion,wt.folder.FolderHelper.getFolder(doc));
			// wt.project.Project prj =
			// wt.project.ProjectHelper.service.getProject(doc);
			// if (prj != null)
			// newVersion=(wt.doc.WTDocument)wt.project.ProjectHelper.setProject(newVersion,prj);
			// newVersion=(wt.doc.WTDocument)wt.lifecycle.LifeCycleHelper.setLifeCycle((wt.lifecycle.LifeCycleManaged)newVersion,
			// wt.lifecycle.LifeCycleHelper.service.getLifeCycleTemplateReference(LCTemplate));
			newVersion = (wt.doc.WTDocument) wt.fc.PersistenceHelper.manager.save(newVersion);
			doc = (wt.doc.WTDocument) wt.fc.PersistenceHelper.manager.refresh(newVersion);
			logger.debug("WorkflowHelper.reviseTiff: new version:" + doc.getDisplayIdentifier());
		} catch (wt.util.WTPropertyVetoException e) {
			ToolUtils.logException(logger, e);
			if (logger.isDebugEnabled()) {
				logger.debug("WorkflowHelper.reviseTiff: " + e.getLocalizedMessage());
			}
		} catch (wt.util.WTException e) {
			ToolUtils.logException(logger, e);
			if (logger.isDebugEnabled()) {
				logger.debug("WorkflowHelper.reviseTiff: " + e.getLocalizedMessage());
			}
		}
		if (logger.isDebugEnabled()) {
			logger.debug("exiting reviseTiff()");
			logger.debug("returning: " + (doc));
		}
		return (doc);
	}

	/**
	 * Revise part and set new part to a specific version.
	 *
	 * @param WTPart
	 *            part the part to revise
	 * @param String
	 *            version
	 * @return WTPart the newly revised WTPart
	 **/
	public static WTPart revisePart(WTPart part, String version) throws WTException, WTPropertyVetoException {
		if (logger.isDebugEnabled()) {
			logger.debug("entering revisePart(WTPart,String)");
			logger.debug("part: " + part);
			logger.debug("version: \"" + version + "\"");
		}
		logger.info("WorkflowHelper.revisePart: --> start");
		logger.debug(
				"WorkflowHelper.revisePart: revise part:" + (part == null ? "null" : "" + part.getDisplayIdentifier()));

		part = (wt.part.WTPart) KBUtils.findLatestDesignPart(part.getMaster());
		wt.part.WTPart newVersion = null;
		newVersion = (wt.part.WTPart) wt.vc.VersionControlHelper.service.newVersion((wt.vc.Versioned) part);
		// com.ptc.windchill.pdmlink.repository.common.PDMLinkRepositoryHelper.setRepository(newVersion,
		// com.ptc.windchill.pdmlink.repository.common.PDMLinkRepositoryHelper.getRepository(part),true);
		newVersion = (wt.part.WTPart) wt.fc.PersistenceHelper.manager.save(newVersion);
		part = (wt.part.WTPart) wt.fc.PersistenceHelper.manager.refresh(newVersion);
		// set corrcect version
		// if (version != null &&
		// part.getVersionIdentifier().getValue().compareTo(version)<0)
		setVersion(part, version);

		logger.debug("WorkflowHelper.revisePart: new version:" + part.getDisplayIdentifier());
		logger.info("WorkflowHelper.revisePart: --> end");
		if (logger.isDebugEnabled()) {
			logger.debug("exiting revisePart()");
			logger.debug("returning: " + (part));
		}
		return (part);
	}

	/**
	 * Check wether there exists a WTDocument with the same number. Return the
	 * latest version if found, otherwise return null.
	 *
	 * @param num
	 *            String number of document
	 * @return WTDocument if found a document with the number = num.
	 **/
	public static WTDocument doesTiffExist(String num) {
		if (logger.isDebugEnabled()) {
			logger.debug("entering doesTiffExist(String)");
			logger.debug("num: \"" + num + "\"");
		}
		WTDocument d = null;
		WTDocument tmp = null;
		QueryResult res = null;
		num = num.toUpperCase();
		num = removeDrwExtension(num);
		logger.info("WorkflowHelper.doesTiffExist: --> start");
		logger.debug("WorkflowHelper.doesTiffExist: search for number=" + num);
		try {
			QuerySpec querySpec = new QuerySpec();
			SearchCondition condition;
			ClassAttribute classAttribute;
			RelationalExpression expression;
			java.lang.Object ob = null;
			int classIndex0 = querySpec.appendClassList(wt.doc.WTDocument.class, true);

			classAttribute = new ClassAttribute(wt.doc.WTDocument.class, wt.doc.WTDocument.NUMBER);
			expression = ConstantExpression.newExpression(num, classAttribute.getColumnDescriptor().getJavaType());
			condition = new SearchCondition(classAttribute, SearchCondition.LIKE, expression);
			querySpec.appendWhere(condition, classIndex0);
			querySpec.appendAnd();
			querySpec.appendWhere(new SearchCondition(wt.doc.WTDocument.class, wt.vc.Iterated.LATEST_ITERATION,
					SearchCondition.IS_TRUE));

			res = wt.fc.PersistenceHelper.manager.find(querySpec);
			while (res.hasMoreElements()) {
				// document found, get latest version
				ob = (java.lang.Object) (((Object[]) res.nextElement())[0]);
				if (ob instanceof wt.doc.WTDocument)
					tmp = (WTDocument) ob;
				if (tmp != null && d != null) {
					// compare versions
					if (versionLessThan(d, tmp))
						// if
						// (tmp.getVersionIdentifier().getValue().compareTo(d.getVersionIdentifier().getValue())>0)
						d = tmp;
				} else {
					d = tmp;
				}
				logger.debug("WorkflowHelper.doesTiffExist: while  d="
						+ (tmp == null ? "null" : "" + tmp.getDisplayIdentifier()));
			}
		} catch (WTException e) {
			e.printStackTrace();
		}
		if (logger.isDebugEnabled()) {
			logger.debug("WorkflowHelper.doesTiffExist: result=" + d);
		}
		if (logger.isInfoEnabled()) {
			logger.info("WorkflowHelper.doesTiffExist: --> end");
		}
		if (logger.isDebugEnabled()) {
			logger.debug("exiting doesTiffExist()");
			logger.debug("returning: " + (d));
		}
		return (d);
	}

	/**
	 * Check wether there exists a WTPart with the same number. Return the
	 * latest version if found, otherwise return null.
	 *
	 * @param num
	 *            String number of document
	 * @return WTPart if found a document with the number = num.
	 **/
	public static WTPart doesPartExist(String num, String version) {
		if (logger.isDebugEnabled()) {
			logger.debug("entering doesPartExist(String,String)");
			logger.debug("num: \"" + num + "\"");
			logger.debug("version: \"" + version + "\"");
		}
		WTPart d = null;
		WTPart tmp = null;
		QueryResult res = null;
		num = num.toUpperCase();
		num = removeDrwExtension(num);
		logger.info("WorkflowHelper.doesPartExist: --> start");
		logger.debug("WorkflowHelper.doesPartExist: search for number=" + num);
		try {
			java.lang.Object ob = null;
			QuerySpec spec = new QuerySpec();
    		int partId = spec.appendClassList(WTPart.class, true);
    		int viewId = spec.appendClassList(View.class, false);
    		SearchCondition joinPartWithView = new SearchCondition(WTPart.class, "view.key.id", View.class, "thePersistInfo.theObjectIdentifier.id");
    		SearchCondition viewNameConditon = new SearchCondition(View.class, "name", SearchCondition.EQUAL, "Design");
			SearchCondition numberCondition = new SearchCondition(WTPart.class, WTPart.NUMBER, SearchCondition.EQUAL, num.toUpperCase(), false);
			SearchCondition latestIteration = new SearchCondition(WTPart.class, Iterated.LATEST_ITERATION, SearchCondition.IS_TRUE);
    		spec.appendWhere(numberCondition, new int[] {partId});
    		spec.appendAnd();
			spec.appendWhere(latestIteration, new int[] {partId});
    		spec.appendAnd();
    		spec.appendWhere(viewNameConditon, new int[] {viewId});
    		spec.appendAnd();
    		spec.appendWhere(joinPartWithView, new int[] {partId, viewId});
			if (version != null && !version.equals("")) {
				spec.appendAnd();
				SearchCondition versionCondition = new SearchCondition(WTPart.class, "versionInfo.identifier.versionId", SearchCondition.EQUAL, version, false);
				spec.appendWhere(versionCondition, new int[] {partId});
			}
			res = wt.fc.PersistenceHelper.manager.find(spec);
    		if(res.hasMoreElements()) {
        		Persistable[] pers = (Persistable[]) res.getObjectVectorIfc().lastElement();
        		d = (WTPart) pers[0];	
    		}
		} catch (WTException e) {
			e.printStackTrace();
		}
		logger.debug("WorkflowHelper.doesPartExist: result=" + d);
		logger.info("WorkflowHelper.doesPartExist: --> end");
		if (logger.isDebugEnabled()) {
			logger.debug("exiting doesPartExist()");
			logger.debug("returning: " + (d));
		}
		return (d);
	}

	/**
	 * Create a new tiff doc or revise an existing one.
	 *
	 * @param epmDocument
	 *            EPMDocument object
	 **/
	public static WTDocument createNewTiffDocVersion(RevisionControlled p, String num, String name, String type,
			String department, String lc, String folder, String cont) throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug(
					"entering createNewTiffDocVersion(RevisionControlled,String,String,String,String,String,String,String)");
			logger.debug("p: " + p);
			logger.debug("num: \"" + num + "\"");
			logger.debug("name: \"" + name + "\"");
			logger.debug("type: \"" + type + "\"");
			logger.debug("department: \"" + department + "\"");
			logger.debug("lc: \"" + lc + "\"");
			logger.debug("folder: \"" + folder + "\"");
			logger.debug("cont: \"" + cont + "\"");
		}
		WTDocument d = null;
		boolean revisable = false;
		logger.info("WorkflowHelper.createNewTiffDocVersion: --> start");
		// check wether a document with the number already exists
		num = removeDrwExtension(num);
		d = doesTiffExist(num);

		if (d != null && p != null) {
			// if doc already exist, check wether it is a version which can be
			// revised
			// for this the docs version is one less than the wtparts version
			if (versionLessThan(d, p)) {
				// if
				// (d.getVersionIdentifier().getValue().compareTo((p.getVersionIdentifier().getValue()))<0){
				d = reviseTiff(d);
			} else {
				// if
				// (d.getVersionIdentifier().getValue().compareTo((p.getVersionIdentifier().getValue()))>0){
				logger.debug("WorkflowHelper.createNewTiffDocVersion: no document created.");
				d = null; // outside task will query.
			}
		} else {
			// d=createNewTiff(p,num,name,type,department,lc,folder);
			d = createVaultDrawing(num, p.getVersionIdentifier().getValue(), name, folder, cont, p);
		}
		logger.info("WorkflowHelper.createNewTiffDocVersion: --> end, d=" + d);
		if (logger.isDebugEnabled()) {
			logger.debug("exiting createNewTiffDocVersion()");
			logger.debug("returning: " + (d));
		}
		return (d);
	}

	/**
	 * Create a new part or revise an existing one.
	 *
	 * @param epmDocument
	 *            EPMDocument object
	 **/
	public static WTPart createNewPartVersion(String num, String name, String folder) throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("entering createNewPartVersion(String,String,String)");
			logger.debug("num: \"" + num + "\"");
			logger.debug("name: \"" + name + "\"");
			logger.debug("folder: \"" + folder + "\"");
		}
		WTPart d = null;
		boolean revisable = false;
		logger.info("WorkflowHelper.createNewPartVersion: --> start");
		// check wether a part with the number already exists
		d = doesPartExist(num, null);

		if (d != null) {
			// if part already exist, check wether it is a version which can be
			// revised
			d = revisePart(d, null);
		} else {
			// d=createNewTiff(p,num,name,type,department,lc,folder);
			d = createNewPart(num, name, folder);
		}
		logger.info("WorkflowHelper.createNewPartVersion: --> end, d=" + d);
		if (logger.isDebugEnabled()) {
			logger.debug("exiting createNewPartVersion()");
			logger.debug("returning: " + (d));
		}
		return (d);
	}

	/**
	 * Create a new part or revise an existing one.
	 *
	 * @param epmDocument
	 *            EPMDocument object
	 **/
	public static WTPart createNewPartVersion(String num, String name, String version, String folder) throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("entering createNewPartVersion(String,String,String,String)");
			logger.debug("num: \"" + num + "\"");
			logger.debug("name: \"" + name + "\"");
			logger.debug("version: \"" + version + "\"");
			logger.debug("folder: \"" + folder + "\"");
			logger.debug("exiting createNewPartVersion()");
		}
		return createNewPartVersion(num, name, version, folder, null);
	}

	/**
	 * Create a new part or revise an existing one. Either one version or tiff
	 * should be provided.
	 *
	 * @param String
	 *            num - number of wtpart to create or revise
	 * @param String
	 *            name - name of wtpart to create or revise
	 * @param String
	 *            version - version of wtpart to create or revise
	 * @param String
	 *            folder - folder for new object
	 * @param RevisionControlled
	 *            tiff - tiff to create part version for
	 * @return WTPart - the revised or new created part
	 **/
	public static WTPart createNewPartVersion(String num, String name, String version, String folder,
			RevisionControlled tiff) throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("entering createNewPartVersion(String,String,String,String,RevisionControlled)");
			logger.debug("num: \"" + num + "\"");
			logger.debug("name: \"" + name + "\"");
			logger.debug("version: \"" + version + "\"");
			logger.debug("folder: \"" + folder + "\"");
			logger.debug("tiff: " + tiff);
		}
		WTPart d = null;
		boolean revisable = false;
		logger.info("WorkflowHelper.createNewPartVersion: --> start");
		// check wether a part with the number already exists
		d = doesPartExist(num, null);

		if (d != null) {
			// WTPart tmp=doesPartExist(d.getNumber(),version);
			if (tiff != null) {
				if (versionLessThan(d, tiff))
					// revise the part
					d = revisePart(d, tiff.getVersionIdentifier().getValue());
			} else {
				// if (d.getVersionIdentifier().getValue().compareTo(version)<0)
				// revise the part
				d = revisePart(d, version);
			}
		} else {
			// d=createNewTiff(p,num,name,type,department,lc,folder);
			d = createNewPart(num, name, folder);
			if (d != null && version != null && !version.equals(""))
				setVersion(d, version);
		}
		logger.info("WorkflowHelper.createNewPartVersion: --> end, d=" + d);
		if (logger.isDebugEnabled()) {
			logger.debug("exiting createNewPartVersion()");
			logger.debug("returning: " + (d));
		}
		return (d);
	}

	/**
	 * Link a CADDrawing to a WTPart. Note: no new iteration will be created.
	 *
	 * @param mydrw
	 *            EPMDocument the drawing
	 * @param mypart
	 *            WTPart the WTPart
	 **/
	public static void linkDrw2WTPart(EPMDocument mydrw, WTPart mypart) {
		if (logger.isDebugEnabled()) {
			logger.debug("entering linkDrw2WTPart(EPMDocument,WTPart)");
			logger.debug("mydrw: " + mydrw);
			logger.debug("mypart: " + mypart);
		}
		linkDrw2WTPart(mydrw, mypart, false);
		if (logger.isDebugEnabled()) {
			logger.debug("exiting linkDrw2WTPart()");
		}
	}

	/**
	 * Link a CADDrawing to a vector of WTParts. Note: no new iteration will be
	 * created.
	 *
	 * @param mydrw
	 *            EPMDocument the drawing
	 * @param Vector
	 *            vector with parts
	 **/
	public static void linkDrw2WTParts(EPMDocument mydrw, Vector v) {
		if (logger.isDebugEnabled()) {
			logger.debug("entering linkDrw2WTParts(EPMDocument,Vector)");
			logger.debug("mydrw: " + mydrw);
			logger.debug("v: " + v);
		}
		if (mydrw != null) {
			for (int i = 0; i < v.size(); i++) {
				linkDrw2WTPart(mydrw, (WTPart) v.get(i), false);
			}
		}
		if (logger.isDebugEnabled()) {
			logger.debug("exiting linkDrw2WTParts()");
		}
	}

	/**
	 * Link a CADDrawing to a WTPart
	 *
	 * @param mydrw
	 *            EPMDocument the drawing
	 * @param mypart
	 *            WTPart the WTPart
	 * @param boolean
	 *            specify wether to create a new iteration or not (checkout)
	 **/
	public static void linkDrw2WTPart(EPMDocument mydrw, WTPart mypart, boolean checkOut) {
		if (logger.isDebugEnabled()) {
			logger.debug("entering linkDrw2WTPart(EPMDocument,WTPart,boolean)");
			logger.debug("mydrw: " + mydrw);
			logger.debug("mypart: " + mypart);
			logger.debug("checkOut: " + checkOut);
		}
		Transaction tx = null;
		// search EPMDocument
		logger.info("WorkflowHelper.linkDrw2WTPart: --> start part=" + mypart + " doc=" + mydrw);

		QueryResult q1 = null;
		boolean found = false;
		try {
			tx = new Transaction();
			tx.start();
			// make sure that you have the latest iteration
			mydrw = (EPMDocument) wt.vc.VersionControlHelper.getLatestIteration(mydrw);
			mypart = (WTPart) KBUtils.findLatestDesignPart(mypart.getMaster());

			// check, if link already exists
			q1 = PersistenceHelper.manager.navigate(mypart, wt.epm.structure.EPMDescribeLink.DESCRIBED_BY_ROLE,
					wt.epm.structure.EPMDescribeLink.class);
			found = false;
			while (q1.hasMoreElements())
				if (((wt.epm.EPMDocument) q1.nextElement()).getIdentity().equals(mydrw.getIdentity()))
					found = true;
			if (!found) {
				logger.debug("WorkflowHelper.linkDrw2WTPart: part and drw are not yet linked.");

				if (checkOut) {
					// checkout wtpart
					if (!WorkInProgressHelper.isCheckedOut((Workable) mypart)) {
						CheckoutLink col = WorkInProgressHelper.service.checkout((Workable) mypart,
								WorkInProgressHelper.service.getCheckoutFolder(),
								"Checked out by WNC, do not checkin or undoCheckout.");
						mypart = (wt.part.WTPart) col.getWorkingCopy();
					}
					if (!WorkInProgressHelper.isWorkingCopy((Workable) mypart)) {
						mypart = (wt.part.WTPart) WorkInProgressHelper.service.workingCopyOf((Workable) mypart);
					}
					logger.debug("WorkflowHelper.linkDrw2WTPart: checkedout part.");
				}

				// link doc
				if (checkOut) {
					// checkout epm
					if (!WorkInProgressHelper.isCheckedOut((Workable) mydrw)) {
						CheckoutLink col = WorkInProgressHelper.service.checkout((Workable) mydrw,
								WorkInProgressHelper.service.getCheckoutFolder(),
								"Checked out by WNC, do not checkin or undoCheckout.");
						mydrw = (wt.epm.EPMDocument) col.getWorkingCopy();
						logger.debug("WorkflowHelper.linkDrw2WTPart: checkedout drw.");
					}
					if (!WorkInProgressHelper.isWorkingCopy((Workable) mydrw)) {
						mydrw = (wt.epm.EPMDocument) WorkInProgressHelper.service.workingCopyOf((Workable) mydrw);
						logger.debug("WorkflowHelper.linkDrw2WTPart: get working copy of drw.");
					}
				}

				EPMDescribeLink epmdescribelink = null;
				if (mypart != null && mydrw != null) {
					epmdescribelink = EPMDescribeLink.newEPMDescribeLink(mypart, mydrw);
					epmdescribelink.setBuiltFlag(false);
					if (checkOut)
						epmdescribelink = (EPMDescribeLink) PersistenceHelper.manager.save(epmdescribelink);
					else
						wt.fc.PersistenceServerHelper.manager.insert(epmdescribelink);
					// get predecessor of doc and delete links to wtpart
					deletePredecessorLink("wt.epm.structure.EPMDescribeLink", mypart,
							wt.epm.structure.EPMDescribeLink.DESCRIBES_ROLE, mydrw, checkOut);
				}
				logger.debug("WorkflowHelper.linkDrw2WTPart: created EPMDescribeLink=" + epmdescribelink);

				if (checkOut)
					mydrw = (wt.epm.EPMDocument) wt.vc.wip.WorkInProgressHelper.service.checkin((Workable) mydrw,
							"Updated by synch.");

				// checkin part
				if (checkOut)
					if (WorkInProgressHelper.isCheckedOut((Workable) mypart))
						mypart = (wt.part.WTPart) wt.vc.wip.WorkInProgressHelper.service.checkin((Workable) mypart,
								"Updated by synch.");

			}
			tx.commit();
		} catch (WTPropertyVetoException e) {
			if (logger.isDebugEnabled()) {
				logger.debug("WorkflowHelper.linkDrw2WTPart: " + e);
			}
			tx.rollback();
		} catch (WTException e) {
			e.printStackTrace();
			tx.rollback();
		}
		if (logger.isDebugEnabled()) {
			logger.debug("exiting linkDrw2WTPart()");
		}
	}

	/**
	 * Update variable in a running process for a given object
	 *
	 * @param obj
	 *            Persistable any pbo with a workflow
	 * @param name
	 *            String process variable name
	 * @param value
	 *            Object process variable value
	 **/
	public static void updateProcessVariable(wt.fc.Persistable obj, String name, Object value) throws WTException {
		if (logger.isDebugEnabled()) {
			logger.debug("entering updateProcessVariable(wt.fc.Persistable,String,Object)");
			logger.debug("obj: " + obj);
			logger.debug("name: \"" + name + "\"");
			logger.debug("value: " + value);
		}
		wt.workflow.engine.WfState running = wt.workflow.engine.WfState.toWfState("OPEN_RUNNING");
		logger.debug("WorkflowHelper.updateProcessVariable: obj=" + obj.toString());
		// try {
		java.util.Enumeration myenum = wt.workflow.engine.WfEngineHelper.service.getAssociatedProcesses(obj, running);
		if (!myenum.hasMoreElements())
			myenum = wt.workflow.engine.WfEngineHelper.service.getAssociatedProcesses(obj, null);
		wt.workflow.engine.WfProcess proc = null;
		while (myenum.hasMoreElements()) {
			proc = (wt.workflow.engine.WfProcess) myenum.nextElement();
			logger.debug("WorkflowHelper.updateProcessVariable: proc=" + proc.toString());
			wt.workflow.engine.ProcessData pd = (wt.workflow.engine.ProcessData) proc.getContext();
			try {
				pd.setValue(name, value);
				if (logger.isDebugEnabled()) {
					logger.debug("WorkflowHelper.updateProcessVariable: " + name + "=" + value.toString());
				}
				proc = (wt.workflow.engine.WfProcess) wt.fc.PersistenceHelper.manager.save(proc);
			} catch (wt.util.WTException e) {
				logger.error("WorkflowHelper.updateProcessVariable: " + e);
				throw new wt.util.WTException(e);
			}
		}
		if (logger.isDebugEnabled()) {
			logger.debug("exiting updateProcessVariable()");
		}
	}

	/**
	 * Link a doc to a part and delete the link from the part to the predecessor
	 * version of the document. Do not create a new part iteration.
	 *
	 * @param doc
	 *            WTDocument the document
	 * @param part
	 *            WTPart the part
	 **/
	public static void linkDoc2WTPart(WTDocument doc, WTPart part) {
		if (logger.isDebugEnabled()) {
			logger.debug("entering linkDoc2WTPart(WTDocument,WTPart)");
			logger.debug("doc: " + doc);
			logger.debug("part: " + part);
		}
		linkDoc2WTPart(doc, part, false);
		if (logger.isDebugEnabled()) {
			logger.debug("exiting linkDoc2WTPart()");
		}
	}

	/**
	 * Link a doc to a part and delete the link from the part to the predecessor
	 * version of the document. Do not create a new part iteration.
	 *
	 * @param doc
	 *            WTDocument the document
	 * @param part
	 *            WTPart the part
	 **/
	public static void linkDoc2WTParts(WTDocument doc, Vector parts) {
		if (logger.isDebugEnabled()) {
			logger.debug("entering linkDoc2WTParts(WTDocument,Vector)");
			logger.debug("doc: " + doc);
			logger.debug("parts: " + parts);
		}
		for (int i = 0; i < parts.size(); i++)
			linkDoc2WTPart(doc, (WTPart) parts.get(i), false);
		if (logger.isDebugEnabled()) {
			logger.debug("exiting linkDoc2WTParts()");
		}
	}

	/**
	 * Delete a link between two objects. Set checkOut to true if object is
	 * checked out. Otherwise set checkOut to false, then there's no history.
	 *
	 * @param String
	 *            linkclass between these objects
	 * @param Persistable
	 *            a
	 * @param String
	 *            role of object a
	 * @param Persistable
	 *            b
	 * @param boolean
	 *            checkOut - true if object is checked out
	 **/
	public static void deleteLink(String linkclass, Persistable a, String role, Persistable b, boolean checkOut)
			throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("entering deleteLink(String,Persistable,String,Persistable,boolean)");
			logger.debug("linkclass: \"" + linkclass + "\"");
			logger.debug("a: " + a);
			logger.debug("role: \"" + role + "\"");
			logger.debug("b: " + b);
			logger.debug("checkOut: " + checkOut);
		}
		// predecessor version of doc should be removed from part
		logger.debug("WorkflowHelper.deleteLink: check link " + a + " and " + b + ".");
		java.lang.Class class2 = Class.forName(linkclass);
		wt.fc.QueryResult qr = wt.fc.PersistenceHelper.manager.find(class2, a, role, b);
		while (qr.hasMoreElements()) {
			if (checkOut)
				wt.fc.PersistenceHelper.manager.delete((wt.fc.Persistable) qr.nextElement());
			else
				wt.fc.PersistenceServerHelper.manager.remove((wt.fc.Persistable) qr.nextElement());
			logger.debug("WorkflowHelper.deleteLink: link deleted.");
		}
		if (logger.isDebugEnabled()) {
			logger.debug("exiting deleteLink()");
		}
	}

	/**
	 * Add a role (with user) to an object.
	 *
	 * @param LifeCycleManaged
	 *            o - the object to add the role
	 * @param String
	 *            role - the role to add
	 * @param wt.org.WTPrincipal
	 *            u - user or group to add to role
	 **/
	public static WTPrincipal getPrincipalForRole(LifeCycleManaged o, String role) {
		if (logger.isDebugEnabled()) {
			logger.debug("entering getPrincipalForRole(LifeCycleManaged,String)");
			logger.debug("o: " + o);
			logger.debug("role: \"" + role + "\"");
		}
		WTPrincipal p = null;
		try {
			wt.project.Role r = wt.project.Role.toRole(role);
			wt.team.Team t = wt.team.TeamHelper.service.getTeam(o);

			QueryResult qr = TeamHelper.service.findRolePrincipalMap(r, null, t);
			if (qr.hasMoreElements()) {
				RolePrincipalMap rpm = (RolePrincipalMap) qr.nextElement();
				if (rpm.getPrincipalParticipant() != null) {
					if (logger.isDebugEnabled()) {
						logger.debug("exiting getPrincipalForRole()");
					}
					return rpm.getPrincipalParticipant().getPrincipal();
				}
			}
		} catch (WTException e) {
			logger.error("WorkflowHelper.getPrincipalForRole: " + e);
		}
		if (logger.isDebugEnabled()) {
			logger.debug("exiting getPrincipalForRole()");
			logger.debug("returning: " + p);
		}
		return p;
	}

	/**
	 * Update reviewer based for a given object. The reviewer is aquired through
	 * team templates, where the submitter of the object is member. First
	 * teamtemplate wins. The reviewer role is added or replaced if already
	 * exists.
	 *
	 * @param LifeCycleManaged
	 *            o - the object to add the role
	 * @param boolean
	 *            - true if updated object
	 **/
	public static boolean updateReviewer(LifeCycleManaged o, String submitter, String reviewer) throws WTException {
		if (logger.isDebugEnabled()) {
			logger.debug("entering updateReviewer(LifeCycleManaged,String,String)");
			logger.debug("o: " + o);
			logger.debug("submitter: \"" + submitter + "\"");
			logger.debug("reviewer: \"" + reviewer + "\"");
		}
		boolean f = false;
		try {
			replaceRole(o, reviewer, getReviewer((WTUser) getPrincipalForRole(o, submitter), reviewer));
			f = true;
		} catch (Exception e) {
			logger.error("WorkflowHelper.updateReviewer: " + e);
		}
		if (logger.isDebugEnabled()) {
			logger.debug("exiting updateReviewer()");
			logger.debug("returning: " + f);
		}
		return f;
	}

	/**
	 * Add a role (with user) to an object.
	 *
	 * @param RevisionControlled
	 *            o - the object to add the role
	 * @param String
	 *            role - the role to add
	 * @param wt.org.WTPrincipal
	 *            u - user or group to add to role
	 **/
	public static void addRole(RevisionControlled o, String role, wt.org.WTPrincipal u) {
		if (logger.isDebugEnabled()) {
			logger.debug("entering addRole(RevisionControlled,String,wt.org.WTPrincipal)");
			logger.debug("o: " + o);
			logger.debug("role: \"" + role + "\"");
			logger.debug("u: " + u);
		}
		addRole((LifeCycleManaged) o, role, u);
		if (logger.isDebugEnabled()) {
			logger.debug("exiting addRole()");
		}
	}

	/**
	 * Add a role (with user) to an object.
	 *
	 * @param LifeCycleManaged
	 *            o - the object to add the role
	 * @param String
	 *            role - the role to add
	 * @param wt.org.WTPrincipal
	 *            u - user or group to add to role
	 **/
	public static void addRole(LifeCycleManaged o, String role, wt.org.WTPrincipal u) {
		if (logger.isDebugEnabled()) {
			logger.debug("entering addRole(LifeCycleManaged,String,wt.org.WTPrincipal)");
			logger.debug("o: " + o);
			logger.debug("role: \"" + role + "\"");
			logger.debug("u: " + u);
		}
		try {
			wt.project.Role r = wt.project.Role.toRole(role);
			wt.team.Team t = wt.team.TeamHelper.service.getTeam(o);
			wt.team.TeamHelper.service.addRolePrincipalMap(r, u, t);
			wt.lifecycle.LifeCycleHelper.service.augmentRoles(o);
		} catch (WTException e) {
			logger.error("WorkflowHelper.addRole: " + e);
		}
		if (logger.isDebugEnabled()) {
			logger.debug("exiting addRole()");
		}
	}

	/**
	 * Replace a role (with user) of an object.
	 *
	 * @param LifeCycleManaged
	 *            o - the object to replace the role
	 * @param String
	 *            role - the role to add
	 * @param wt.org.WTPrincipal
	 *            u - user or group to replace to role
	 **/
	public static void replaceRole(LifeCycleManaged o, String role, wt.org.WTPrincipal u) throws WTException {
		if (logger.isDebugEnabled()) {
			logger.debug("entering replaceRole(LifeCycleManaged,String,wt.org.WTPrincipal)");
			logger.debug("o: " + o);
			logger.debug("role: \"" + role + "\"");
			logger.debug("u: " + u);
		}
		logger.debug("WorkflowHelper.replaceRole: object=" + o + " role=" + role + " user=" + u);
		wt.project.Role r = wt.project.Role.toRole(role);
		wt.team.Team t = wt.team.TeamHelper.service.getTeam(o);
		t.deleteRole(r);
		wt.team.TeamHelper.service.addRolePrincipalMap(r, u, t);
		wt.lifecycle.LifeCycleHelper.service.augmentRoles(o);
		if (logger.isDebugEnabled()) {
			logger.debug("exiting replaceRole()");
		}
	}

	/**
	 * Search the link between object a and predecessor of b and delete it.
	 *
	 * @param String
	 *            linkclass between these objects
	 * @param RevisionControlled
	 *            a
	 * @param String
	 *            role of object a
	 * @param RevisionControlled
	 *            b
	 * @param boolean
	 *            checkOut - true if object is checked out
	 **/
	public static void deletePredecessorLink(String linkclass, RevisionControlled a, String role, RevisionControlled b,
			boolean checkOut) {
		if (logger.isDebugEnabled()) {
			logger.debug("entering deletePredecessorLink(String,RevisionControlled,String,RevisionControlled,boolean)");
			logger.debug("linkclass: \"" + linkclass + "\"");
			logger.debug("a: " + a);
			logger.debug("role: \"" + role + "\"");
			logger.debug("b: " + b);
			logger.debug("checkOut: " + checkOut);
		}
		// Transaction tx = null;
		try {
			logger.debug("deletePredecessorLink: " + a + " (" + a.getIdentity() + ") <--> " + b + "(" + b.getIdentity()
					+ ")");
			// tx = new Transaction();
			// tx.start();
			// get predecessor of doc
			RevisionControlled pre_b = b;
			while (pre_b != null && !versionLessThan(pre_b, b))
				pre_b = (RevisionControlled) wt.vc.VersionControlHelper.service.predecessorOf(pre_b);
			// predecessor version of doc should be removed from part
			if (pre_b != null) {
				deleteLink(linkclass, a, role, pre_b, checkOut);
				logger.debug("WorkflowHelper.deletePredecessorLink: link between " + a + " and " + pre_b + " deleted");
			}
			// tx.commit();
		} catch (WTException e) {
			ToolUtils.logException(logger, e);
			// tx.rollback();
		} catch (Exception e) {
			ToolUtils.logException(logger, e);
			// tx.rollback();
		}
		if (logger.isDebugEnabled()) {
			logger.debug("exiting deletePredecessorLink()");
		}
	}

	/**
	 * Link a doc to a part and delete the link from the part to the predecessor
	 * version of the document
	 *
	 * @param doc
	 *            WTDocument the document
	 * @param boolean
	 *            specify wether create a new iteration or not
	 * @param part
	 *            WTPart the part
	 **/
	public static void linkDoc2WTPart(WTDocument doc, WTPart part, boolean checkOut) {
		if (logger.isDebugEnabled()) {
			logger.debug("entering linkDoc2WTPart(WTDocument,WTPart,boolean)");
			logger.debug("doc: " + doc);
			logger.debug("part: " + part);
			logger.debug("checkOut: " + checkOut);
		}
		WTPartDescribeLink link = null;
		Transaction tx = null;
		try {
			tx = new Transaction();
			tx.start();
			if (checkOut) {
				part = (wt.part.WTPart) KBUtils.findLatestDesignPart(part.getMaster());
				wt.vc.wip.WorkInProgressHelper.service.checkout(part,
						wt.folder.FolderHelper.service.getFolder("/Administrator"), "");
				part = (wt.part.WTPart) wt.vc.wip.WorkInProgressHelper.service.workingCopyOf(part);
			}
			link = wt.part.WTPartDescribeLink.newWTPartDescribeLink(part, (wt.doc.WTDocument) doc);
			if (checkOut)
				link = (wt.part.WTPartDescribeLink) wt.fc.PersistenceHelper.manager.save(link);
			else
				wt.fc.PersistenceServerHelper.manager.insert(link);

			// get predecessor of doc and delete links to wtpart
			deletePredecessorLink("wt.part.WTPartDescribeLink", part, wt.part.WTPartDescribeLink.DESCRIBES_ROLE, doc,
					checkOut);

			// checkin
			if (checkOut)
				wt.vc.wip.WorkInProgressHelper.service.checkin(part, "");
			tx.commit();
		} catch (wt.util.WTException e) {
			logger.error("WorkflowHelper.linkDoc2WTPart: " + e);
			tx.rollback();
		} catch (Exception e) {
			logger.error("WorkflowHelper.linkDoc2WTPart: " + e);
			tx.rollback();
		}
		if (logger.isDebugEnabled()) {
			logger.debug("exiting linkDoc2WTPart()");
		}
	}

	/**
	 * Create a baseline
	 *
	 * @param EPMDcoument
	 *            drw - the drawing to create the baseline for
	 * @return ManagedBaseline - the baseline
	 **/
	public static ManagedBaseline createBaseLine(EPMDocument drw) {
		if (logger.isDebugEnabled()) {
			logger.debug("entering createBaseLine(EPMDocument)");
			logger.debug("drw: " + drw);
		}
		ManagedBaseline mb = null;
		try {
			mb = ManagedBaseline.newManagedBaseline();
			ManagedBaselineIdentity.assignToObject(mb);
			// mb.setName( drw.getNumber() +
			// "_"+drw.getVersionIdentifier().getValue()+ mb.getNumber());
			mb.setName(drw.getNumber() + "_" + drw.getVersionIdentifier().getValue() + "_AS_RELEASED");
			logger.debug("WorkflowHelper.createBaseLine: name=" + mb.getName() + " number=" + mb.getNumber());
			FolderHelper.assignLocation(mb, FolderHelper.getFolder(drw));
			mb = (ManagedBaseline) LifeCycleHelper.setLifeCycle(mb,
					LifeCycleHelper.service.getLifeCycleTemplate("PDMLink Released Data"));
			mb = (ManagedBaseline) PersistenceHelper.manager.save(mb);
			mb = (ManagedBaseline) BaselineHelper.service.addToBaseline(drw, mb);
			mb = (ManagedBaseline) BaselineHelper.service.populateBaseline(drw, mb,
					new wt.vc.config.LatestConfigSpec());
			// mb = (ManagedBaseline)PersistenceHelper.manager.save(mb);
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (logger.isDebugEnabled()) {
			logger.debug("exiting createBaseLine()");
			logger.debug("returning: " + mb);
		}
		return mb;
	}

	/**
	 * Search all team templates where the user belongs to. Take the user with
	 * the given role and return him. If the method doesn't find a user with the
	 * given role, the user himself is returned. If an error occurs return null.
	 *
	 * @param String
	 *            user - the user's id
	 * @param String
	 *            role - role to search
	 * @return WTUser - the reviewer
	 **/
	public static WTUser getReviewer(WTUser u, String role) {
		if (logger.isDebugEnabled()) {
			logger.debug("entering getReviewer(WTUser,String)");
			logger.debug("u: " + u);
			logger.debug("role: \"" + role + "\"");
		}
		if (null != getTeamTemplate(u, role)) {
			if (logger.isDebugEnabled()) {
				logger.debug("null != getTeamTemplate(u,role)");
				logger.debug("exiting getReviewer()");
				logger.debug("returning: " + u);
			}
			return u;
		}
		if (logger.isDebugEnabled()) {
			logger.debug("exiting getReviewer()");
			logger.debug("returning: " + null);
		}
		return null;
	}

	/**
	 * Search all team templates where the user belongs to. Take the user with
	 * the given role and return him. If the method doesn't find a user with the
	 * given role, the user himself is returned. If an error occurs return null.
	 *
	 * @param String
	 *            user - the user's id
	 * @param String
	 *            role - role to search
	 * @return WTUser - the reviewer
	 **/
	public static WTUser getReviewer(String userid, String role) {
		if (logger.isDebugEnabled()) {
			logger.debug("entering getReviewer(String,String)");
			logger.debug("userid: \"" + userid + "\"");
			logger.debug("role: \"" + role + "\"");
		}
		WTUser u = null;
		WTUser rev = null;
		WTUser revTemp = null;
		TeamTemplate teamtemplate = null;
		boolean found = false;
		try {
			// get the user
			DirectoryContextProvider contextProvider = WTContainerHelper.service.getExchangeContainer()
					.getContextProvider();
			Enumeration en = OrganizationServicesHelper.manager.getUsers(userid, contextProvider);
			while (en.hasMoreElements()) {
				u = (WTUser) en.nextElement();
				logger.debug("WorkflowHelper.getReviewer: user=" + u.getName());
			}
			if (u != null) {
				rev = getReviewer(u, role);
			}
		} catch (Exception e) {
			e.printStackTrace();
			rev = null;
		}
		if (logger.isDebugEnabled()) {
			logger.debug("exiting getReviewer()");
			logger.debug("returning: " + (rev));
		}
		return (rev);
	}

	/**
	 * Search all team templates where the user belongs to and the given role
	 * ist also available. If nothing found return null; return null.
	 *
	 * @param String
	 *            user - the user's id
	 * @param String
	 *            role - the orle
	 * @return TeamTemplate - the Team Template
	 **/
	public static TeamTemplate getTeamTemplate(String userid, String role) {
		if (logger.isDebugEnabled()) {
			logger.debug("entering getTeamTemplate(String,String)");
			logger.debug("userid: \"" + userid + "\"");
			logger.debug("role: \"" + role + "\"");
		}
		WTUser u = null;
		WTUser rev = null;
		TeamTemplate teamtemplate = null;
		boolean userFound = false;
		boolean roleFound = false;
		try {
			// get the user
			Enumeration en = OrganizationServicesHelper.manager.findUser("uid", userid);
			while (en.hasMoreElements()) {
				u = (WTUser) en.nextElement();
				logger.debug("WorkflowHelper.getTeamTemplate: user=" + u.getName());
			}
			if (u != null) {
				if (logger.isDebugEnabled()) {
					logger.debug("exiting getTeamTemplate()");
				}
				return getTeamTemplate(u, role);
			}
		} catch (Exception e) {
			e.printStackTrace();
			teamtemplate = null;
		}
		if (logger.isDebugEnabled()) {
			logger.debug("exiting getTeamTemplate()");
			logger.debug("returning: " + (teamtemplate));
		}
		return (teamtemplate);
	}

	/**
	 * Search all team templates where the user belongs to and the given role
	 * ist also available. If nothing found return null;
	 *
	 * @param WTUser
	 *            user - the user's id
	 * @param String
	 *            role - the orle
	 * @return TeamTemplate - the Team Template
	 **/
	public static TeamTemplate getTeamTemplate(WTUser u, String role) {
		if (logger.isDebugEnabled()) {
			logger.debug("entering getTeamTemplate(WTUser,String)");
			logger.debug("u: " + u);
			logger.debug("role: \"" + role + "\"");
		}
		TeamTemplate teamtemplate = null;
		boolean userFound = false;
		boolean roleFound = false;
		try {
			if (u != null) {
				Vector teams = TeamHelper.service.findTeamTemplates();
				TeamTemplate teamtemp = null;
				Vector v2 = null;
				RolePrincipalMap rpm = null;
				WTPrincipal p = null;
				for (int i = 0; i < teams.size(); i++) {
					// go through all roles and find the user
					teamtemp = (TeamTemplate) ((TeamTemplateReference) teams.get(i)).getObject();
					logger.debug("WorkflowHelper.getTeamTemplate: teamtemp=" + teamtemp);
					if (teamtemp != null) {
						// mvh: use different API here, e.g.:
						// findRolePrincipalMap(Role role, WTPrincipal
						// principal, WTRoleHolder2 roleHolder)
						QueryResult qr = TeamHelper.service.findRolePrincipalMap(wt.project.Role.toRole(role), u,
								teamtemp);
						if (qr.hasMoreElements()) {
							teamtemplate = teamtemp;
							break;
						}
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			teamtemplate = null;
		}
		if (logger.isDebugEnabled()) {
			logger.debug("exiting getTeamTemplate()");
			logger.debug("returning: " + (teamtemplate));
		}
		return (teamtemplate);
	}

	/**
	 * Get wtpart for a given number and version
	 *
	 * @param String
	 *            num - number to serach
	 * @param String
	 *            vers - version to serach
	 * @return WTPart return part or null
	 **/
	public static WTPart getWTPart(String num, String vers) {
		if (logger.isDebugEnabled()) {
			logger.debug("entering getWTPart(String,String)");
			logger.debug("num: \"" + num + "\"");
			logger.debug("vers: \"" + vers + "\"");
		}
		WTPart p = null;
		QueryResult res = null;
		try {
			Class cl = Class.forName("wt.part.WTPart");
			QuerySpec querySpec = new QuerySpec();
			int linkIndex;
			SearchCondition condition;
			ClassAttribute classAttribute;
			RelationalExpression expression;
			java.lang.Object obj = null;
			int classIndex0 = querySpec.appendClassList(cl, true);

			classAttribute = new ClassAttribute(cl, wt.vc.Iterated.LATEST_ITERATION);
			expression = ConstantExpression.newExpression("1", classAttribute.getColumnDescriptor().getJavaType());
			condition = new SearchCondition(classAttribute, SearchCondition.EQUAL, expression);
			querySpec.appendWhere(condition, classIndex0);

			querySpec.appendAnd();
			classAttribute = new ClassAttribute(cl, wt.part.WTPart.NUMBER);
			expression = ConstantExpression.newExpression(num, classAttribute.getColumnDescriptor().getJavaType());
			condition = new SearchCondition(classAttribute, SearchCondition.LIKE, expression);
			querySpec.appendWhere(condition, classIndex0);

			querySpec.appendAnd();
			classAttribute = new ClassAttribute(cl, "versionInfo.identifier.versionId");
			expression = ConstantExpression.newExpression(vers, classAttribute.getColumnDescriptor().getJavaType());
			condition = new SearchCondition(classAttribute, SearchCondition.EQUAL, expression);
			querySpec.appendWhere(condition, classIndex0);

			res = wt.fc.PersistenceHelper.manager.find(querySpec);
			while (res.hasMoreElements()) {
				p = (wt.part.WTPart) (((Object[]) res.nextElement())[0]);
			}

		} catch (WTException wte) {
			wte.printStackTrace();
			logger.error("WorkflowHelper.getWTPart Exception: " + wte.toString());
		} catch (java.lang.ClassNotFoundException e) {
			e.printStackTrace();
			logger.error("WorkflowHelper.getWTPart Exception: " + e.toString());
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("WorkflowHelper.getWTPart Exception: " + e.toString());
		}
		if (logger.isDebugEnabled()) {
			logger.debug("exiting getWTPart()");
			logger.debug("returning: " + p);
		}
		return p;
	}

	/**
	 * Get EPMDocument for a given number and version
	 *
	 * @param String
	 *            num - number to serach
	 * @param String
	 *            vers - version to serach
	 * @return EPMDocument return epmdoc or null
	 **/
	public static EPMDocument getEPMDocument(String num, String vers) {
		if (logger.isDebugEnabled()) {
			logger.debug("entering getEPMDocument(String,String)");
			logger.debug("num: \"" + num + "\"");
			logger.debug("vers: \"" + vers + "\"");
		}
		EPMDocument ep = null;
		QueryResult res = null;
		try {
			Class cl = Class.forName("wt.epm.EPMDocument");
			QuerySpec querySpec = new QuerySpec();
			int linkIndex;
			SearchCondition condition;
			ClassAttribute classAttribute;
			RelationalExpression expression;
			java.lang.Object obj = null;
			int classIndex0 = querySpec.appendClassList(cl, true);

			classAttribute = new ClassAttribute(cl, wt.vc.Iterated.LATEST_ITERATION);
			expression = ConstantExpression.newExpression("1", classAttribute.getColumnDescriptor().getJavaType());
			condition = new SearchCondition(classAttribute, SearchCondition.EQUAL, expression);
			querySpec.appendWhere(condition, classIndex0);

			querySpec.appendAnd();
			classAttribute = new ClassAttribute(cl, wt.epm.EPMDocument.NUMBER);
			expression = ConstantExpression.newExpression(num, classAttribute.getColumnDescriptor().getJavaType());
			condition = new SearchCondition(classAttribute, SearchCondition.LIKE, expression);
			querySpec.appendWhere(condition, classIndex0);

			querySpec.appendAnd();
			classAttribute = new ClassAttribute(cl, "versionInfo.identifier.versionId");
			expression = ConstantExpression.newExpression(vers, classAttribute.getColumnDescriptor().getJavaType());
			condition = new SearchCondition(classAttribute, SearchCondition.EQUAL, expression);
			querySpec.appendWhere(condition, classIndex0);

			res = wt.fc.PersistenceHelper.manager.find(querySpec);
			while (res.hasMoreElements()) {
				ep = (EPMDocument) (((Object[]) res.nextElement())[0]);
			}

		} catch (WTException wte) {
			wte.printStackTrace();
			logger.error("WorkflowHelper.getEPMDocument Exception: " + wte.toString());
		} catch (java.lang.ClassNotFoundException e) {
			e.printStackTrace();
			logger.error("WorkflowHelper.getEPMDocument Exception: " + e.toString());
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("WorkflowHelper.getEPMDocument Exception: " + e.toString());
		}
		if (logger.isDebugEnabled()) {
			logger.debug("exiting getEPMDocument()");
			logger.debug("returning: " + ep);
		}
		return ep;
	}

	/**
	 * Get wtdocument for a given number and version
	 *
	 * @param String
	 *            num - number to serach
	 * @param String
	 *            vers - version to serach
	 * @return WTDocument return part or null
	 **/
	public static WTDocument getWTDocument(String num, String vers) {
		if (logger.isDebugEnabled()) {
			logger.debug("entering getWTDocument(String,String)");
			logger.debug("num: \"" + num + "\"");
			logger.debug("vers: \"" + vers + "\"");
		}
		WTDocument d = null;
		QueryResult res = null;
		try {
			Class cl = Class.forName("wt.doc.WTDocument");
			QuerySpec querySpec = new QuerySpec();
			int linkIndex;
			SearchCondition condition;
			ClassAttribute classAttribute;
			RelationalExpression expression;
			java.lang.Object obj = null;
			int classIndex0 = querySpec.appendClassList(cl, true);

			classAttribute = new ClassAttribute(cl, wt.vc.Iterated.LATEST_ITERATION);
			expression = ConstantExpression.newExpression("1", classAttribute.getColumnDescriptor().getJavaType());
			condition = new SearchCondition(classAttribute, SearchCondition.EQUAL, expression);
			querySpec.appendWhere(condition, classIndex0);

			querySpec.appendAnd();
			classAttribute = new ClassAttribute(cl, wt.doc.WTDocument.NUMBER);
			expression = ConstantExpression.newExpression(num, classAttribute.getColumnDescriptor().getJavaType());
			condition = new SearchCondition(classAttribute, SearchCondition.LIKE, expression);
			querySpec.appendWhere(condition, classIndex0);

			querySpec.appendAnd();
			classAttribute = new ClassAttribute(cl, "versionInfo.identifier.versionId");
			expression = ConstantExpression.newExpression(vers, classAttribute.getColumnDescriptor().getJavaType());
			condition = new SearchCondition(classAttribute, SearchCondition.EQUAL, expression);
			querySpec.appendWhere(condition, classIndex0);

			res = wt.fc.PersistenceHelper.manager.find(querySpec);
			while (res.hasMoreElements()) {
				d = (wt.doc.WTDocument) (((Object[]) res.nextElement())[0]);
			}

		} catch (WTException wte) {
			wte.printStackTrace();
			logger.error("WorkflowHelper.getWTDocument Exception: " + wte.toString());
		} catch (java.lang.ClassNotFoundException e) {
			e.printStackTrace();
			logger.error("WorkflowHelper.getWTDocument Exception: " + e.toString());
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("WorkflowHelper.getWTDocument Exception: " + e.toString());
		}
		if (logger.isDebugEnabled()) {
			logger.debug("exiting getWTDocument()");
			logger.debug("returning: " + d);
		}
		return d;
	}

	/**
	 * Check wether epmdoc is generic
	 *
	 * @param epm
	 *            EPMDocument the epmdoc
	 * @return boolean true if objects has instances
	 **/
	public static boolean isGeneric(EPMDocument epmdoc) {
		if (logger.isDebugEnabled()) {
			logger.debug("entering isGeneric(EPMDocument)");
			logger.debug("epmdoc: " + epmdoc);
		}
		boolean isGeneric = false;
		try {
			QueryResult res = wt.epm.structure.EPMStructureHelper.service
					.navigateVariant((EPMDocumentMaster) epmdoc.getMaster(), null, true);
			if (res.hasMoreElements())
				isGeneric = true;
		} catch (WTException wte) {
			wte.printStackTrace();
			logger.error("WorkflowHelper.isGeneric Exception: " + wte.toString());
		}
		if (logger.isDebugEnabled()) {
			logger.debug("exiting isGeneric()");
			logger.debug("returning: " + (isGeneric));
		}
		return (isGeneric);
	}

	/**
	 * Set state a vector of objects
	 *
	 * @param epm
	 *            EPMDocument the generic
	 **/
	public static void setStateForObjects(State s, Vector v) {
		if (logger.isDebugEnabled()) {
			logger.debug("entering setStateForObjects(State,Vector)");
			logger.debug("s: " + s);
			logger.debug("v: " + v);
		}
		if (s != null) {
			for (int i = 0; i < v.size(); i++) {
				try {
					wt.lifecycle.LifeCycleHelper.service.setLifeCycleState((wt.lifecycle.LifeCycleManaged) v.get(i), s);
				} catch (WTException wte) {
					wte.printStackTrace();
					logger.error("WorkflowHelper.setStateForObjects Exception: " + wte.toString());
				}
			}
		}
		if (logger.isDebugEnabled()) {
			logger.debug("exiting setStateForObjects()");
		}
	}

	/**
	 * Get WTPart for a given epmdocument. When setting navigateOverModel=true,
	 * you navigate from a CADDRAWING over the CADASSEMBLY/CADCOMPONENT to the
	 * WTPart. Otherwise you try to find the WTPart with a direct link.
	 *
	 * @param epmDocument
	 *            EPMDocument object
	 * @param navigateOverModel
	 *            boolean navigate direct or over model
	 * @return boolean true if version match
	 **/
	public static Vector getWTPartForEPMDoc(EPMDocument epm) {
		if (logger.isDebugEnabled()) {
			logger.debug("entering getWTPartForEPMDoc(EPMDocument)");
			logger.debug("epm: " + epm);
		}
		QueryResult qr = null;
		Vector models = new Vector();
		Vector parts = new Vector();
		WTPart p = null;
		logger.debug("ext.tools.WorkflowHelper.getWTPartForEPMDoc(): >>>>");

		try {
			if (epm.getDocType().getStringValue().equals("wt.epm.EPMDocumentType.CADDRAWING")) {
				// navigate over model, get the drawing models (3D-model)
				models = getCompForDrw(epm, models);
			} else {
				// is already a drawingmodel
				models.add(epm);
			}

			// navigate from models to wtparts
			for (int i = 0; i < models.size(); i++) {
				logger.debug("ext.tools.WorkflowHelper.getWTPartForEPMDoc(): loop over "
						+ ((EPMDocument) models.get(i)).getIdentity());
				// naviagte over the "active" link to the wtpart
				qr = PersistenceHelper.manager.navigate((EPMDocument) models.get(i),
						wt.epm.build.EPMBuildHistory.BUILT_ROLE, wt.epm.build.EPMBuildHistory.class);
				while (qr.hasMoreElements()) {
					p = (WTPart) qr.nextElement();
					if (VersionControlHelper.isLatestIteration(p)) {
						parts.add(p);
						logger.debug("WorkflowHelper.getWTPartForEPMDoc: add " + p.getIdentity());
					}
				}
			}
		} catch (WTException e) {
			logger.error("WorkflowHelper.getWTPartForEPMDoc: " + e.getMessage());
		}

		logger.debug("ext.tools.WorkflowHelper.getWTPartForEPMDoc(): <<<<");
		if (logger.isDebugEnabled()) {
			logger.debug("exiting getWTPartForEPMDoc()");
			logger.debug("returning: " + parts);
		}
		return parts;
	}

	/**
	 * Get WTPart for a given epmdocument by navigating over "passive" link. The
	 * passive link is the wt.epm.structure.EPMDescribeLink.
	 *
	 * @param epmDocument
	 *            EPMDocument object
	 * @return WTPart return the part
	 **/
	public static Vector getWTPartForEPMDocPassiveLink(EPMDocument epm) {
		if (logger.isDebugEnabled()) {
			logger.debug("entering getWTPartForEPMDocPassiveLink(EPMDocument)");
			logger.debug("epm: " + epm);
		}
		Vector v = new Vector();
		QueryResult qr = null;

		try {
			qr = PersistenceHelper.manager.navigate(epm, wt.epm.structure.EPMDescribeLink.DESCRIBES_ROLE,
					wt.epm.structure.EPMDescribeLink.class);
			while (qr.hasMoreElements())
				v.add(qr.nextElement());
		} catch (WTException e) {
			logger.error("WorkflowHelper.getWTPartForEPMDocPassiveLink: " + e.getMessage());
		}

		if (logger.isDebugEnabled()) {
			logger.debug("exiting getWTPartForEPMDocPassiveLink()");
			logger.debug("returning: " + v);
		}
		return v;
	}

	/**
	 * Get the component (EPMDocument type CADASSEMBLY or CADCOMPONENT) for a
	 * given drawing. The number of the drw (minus extension) is used to filter
	 * the correct version. Latest is also used to filter.
	 *
	 * @param epm
	 *            EPMDocument object
	 * @return EPMDocument the component
	 **/
	public static EPMDocument getCompForDrw(EPMDocument drw) {
		if (logger.isDebugEnabled()) {
			logger.debug("entering getCompForDrw(EPMDocument)");
			logger.debug("drw: " + drw);
		}
		EPMDocument comp = null;
		QueryResult qr = null;
		String n;

		// navigate over model
		try {
			if (drw.getDocType().getStringValue().equals("wt.epm.EPMDocumentType.CADDRAWING")) {
				// naviagte from drw to prt/asm
				qr = wt.epm.structure.EPMStructureHelper.service.navigateReferencesToIteration(drw, (QuerySpec) null,
						true, new wt.vc.config.LatestConfigSpec());
				// cycle over result to get the component
				while (qr.hasMoreElements()) {
					comp = (EPMDocument) qr.nextElement();
					// only compare versions of components
					if (comp.getDocType().getStringValue().equals("wt.epm.EPMDocumentType.CADASSEMBLY")
							|| comp.getDocType().getStringValue().equals("wt.epm.EPMDocumentType.CADCOMPONENT")) {
						// only if number of cad docs (less than extension) are
						// equal check the version
						n = drw.getNumber().substring(0, drw.getNumber().lastIndexOf("."));
						if (comp.getNumber().indexOf(n) >= 0) {
							if (logger.isDebugEnabled()) {
								logger.debug("exiting getCompForDrw()");
								logger.debug("returning: " + (comp));
							}
							return (comp);
						}
					}
				}
			}
		} catch (WTException e) {
			logger.error("WorkflowHelper.getCompForDrw: " + e.getMessage());
		}
		if (logger.isDebugEnabled()) {
			logger.debug("exiting getCompForDrw()");
			logger.debug("returning: " + null);
		}
		return null;
	}

	/**
	 * Check lifecycle-status of an epmdoc and all sub components. Status should
	 * be either RELEASED_PUB, RELEASED_INT, OBSOLETE, REPLACED
	 *
	 * @param lm
	 *            LifeCycleManaged object
	 * @return boolean true if lc are correct
	 **/
	public static boolean checkLCStatus(LifeCycleManaged lm) {
		if (logger.isDebugEnabled()) {
			logger.debug("entering checkLCStatus(LifeCycleManaged)");
			logger.debug("lm: " + lm);
		}
		boolean status_ok = false;
		try {
			for (int i = 0; i < validReleaseStates.length; i++)
				if (validReleaseStates[i] == lm.getLifeCycleState())
					status_ok = true;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("WorkflowHelper.checkLCStatus Exception: " + e.getMessage());
			// S.append(e.getMessage());
		}
		if (logger.isDebugEnabled()) {
			logger.debug("exiting checkLCStatus()");
			logger.debug("returning: " + (status_ok));
		}
		return (status_ok);
	}

	/**
	 * Create change request for a given change issue (problem report)
	 *
	 * @param WTChangeIssue
	 *            ci - problem report
	 * @param String
	 *            orderNumber - order number of change request
	 * @return WTChangeRequest2 - the created change request
	 **/
	public static WTChangeRequest2 createChangeRequest(WTChangeIssue ci, String orderNumber)
			throws WTException, Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("entering createChangeRequest(WTChangeIssue,String)");
			logger.debug("ci: " + ci);
			logger.debug("orderNumber: \"" + orderNumber + "\"");
		}
		WTChangeRequest2 cr = null;
		boolean found = false;

		try {
			Hashtable h = new Hashtable();
			h.put("where", "OrderNumber='" + orderNumber + "'");
			h.put("type", "wt.change2.WTChangeRequest2");
			ReferenceFactory rf = new ReferenceFactory();
			Group g = null;

			// ghimmelsbach, 20040630
			// this is not needed, as in any case a ECR must be created. Order
			// Number must not be unique
			if (false) {
				// search for existing change request with order number
				g = invokeTask("/ext/tools/queryChangeRequest", h, "cr");

				// if change request exists attach problem report to it,
				// otherwise create a new one
				if (g != null && g.getElementCount() > 0) {
					for (int i = 0; i < g.getElementCount(); i++) {
						Element elem = g.getElementAt(i);
						cr = (WTChangeRequest2) ToolUtils.objFromObid(elem.getUfid());
						break;
					}
				}
			}
			// end ghimmelsbach, 20040630

			if (cr == null) {
				/*
				 * has bee moved to task createChangeRequest
				 * cr=WTChangeRequest2.newWTChangeRequest2(ci.getName());
				 * cr.setDescription(ci.getDescription());
				 * cr.setCategory(ci.getCategory());
				 * cr.setRequestPriority(wt.change2.RequestPriority.MEDIUM);
				 * cr.setComplexity(wt.change2.Complexity.SIMPLE);
				 * com.ptc.windchill.pdmlink.repository.common.
				 * PDMLinkRepositoryHelper.setRepository(cr,
				 * com.ptc.windchill.pdmlink.repository.common.
				 * PDMLinkRepositoryHelper.getRepository(ci),true);
				 * //wt.folder.FolderHelper.assignLocation(cr,
				 * ci.getFolderingInfo().getFolder()); // Save all cr =
				 * (wt.change2.WTChangeRequest2)ChangeHelper2.service.
				 * saveChangeRequest(cr);
				 */
				// create change request
				h = new Hashtable();
				h.put("ci_ref", rf.getReferenceString(ci));
				h.put("field", "OrderNumber='" + orderNumber + "'");
				g = invokeTask("/ext/tools/createChangeRequest", h, "cr");
				if (g != null && g.getElementCount() > 0) {
					for (int i = 0; i < g.getElementCount(); i++) {
						Element elem = g.getElementAt(i);
						cr = (WTChangeRequest2) ToolUtils.objFromObid(elem.getUfid());
						break;
					}
				}

				/*
				 * has been moved to task createChangeRequest // get changeables
				 * from ci and add them to cr QueryResult qr =
				 * ChangeHelper2.service.getChangeables(ci);
				 * //RelevantRequestData2 rd=null; if (qr.hasMoreElements() &&
				 * cr!=null){ RelevantRequestData2 rd = new
				 * RelevantRequestData2();//.newRelevantRequestData2((
				 * Changeable2)qr.nextElement(),cr);
				 * ChangeHelper2.service.storeAssociations(rd.getClass(), cr,
				 * qr.getObjectVectorIfc().getVector()); }
				 */

			}
			// link ci and cr
			/*
			 * has been moved to task createChangeRequest if (cr!=null &&
			 * ci!=null) ChangeHelper2.service.saveFormalizedBy(cr, ci);
			 */
		} catch (WTException e) {
			e.printStackTrace();
			logger.error("WorkflowHelper.createChangeRequest WTException: " + e.getMessage());
			throw (new WTException(e));
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("WorkflowHelper.createChangeRequest Exception: " + e.getMessage());
			throw (new Exception(e.toString()));
		}
		if (logger.isDebugEnabled()) {
			logger.debug("exiting createChangeRequest()");
			logger.debug("returning: " + cr);
		}
		return cr;
	}

	/**
	 * Create change request for a given change issue (problem report)
	 *
	 * @param WTChangeIssue
	 *            ci - problem report
	 * @return WTChangeRequest2 - the created change request
	 **/
	public static WTChangeRequest2 createChangeRequest(WTChangeIssue ci) throws WTException, Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("entering createChangeRequest(WTChangeIssue)");
			logger.debug("ci: " + ci);
		}
		WTChangeRequest2 cr = null;
		boolean found = false;

		try {
			Hashtable h = new Hashtable();
			ReferenceFactory rf = new ReferenceFactory();
			Group g = null;
			h = new Hashtable();
			h.put("ci_ref", rf.getReferenceString(ci));
			g = invokeTask("/ext/tools/createChangeRequest", h, "cr");
			if (g != null && g.getElementCount() > 0) {
				for (int i = 0; i < g.getElementCount(); i++) {
					Element elem = g.getElementAt(i);
					cr = (WTChangeRequest2) ToolUtils.objFromObid(elem.getUfid());
					break;
				}
			}
		} catch (WTException e) {
			e.printStackTrace();
			logger.error("WorkflowHelper.createChangeRequest WTException: " + e.getMessage());
			throw (new WTException(e));
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("WorkflowHelper.createChangeRequest Exception: " + e.getMessage());
			throw (new Exception(e.toString()));
		}
		if (logger.isDebugEnabled()) {
			logger.debug("exiting createChangeRequest()");
			logger.debug("returning: " + cr);
		}
		return cr;
	}

	/**
	 * Create change order for a given change request
	 *
	 * @param WTChangeRequest2
	 *            cr - the change request
	 * @return WTChangeOrder2 - the created change order
	 **/
	public static WTChangeOrder2 createChangeOrder(WTChangeRequest2 cr) throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("entering createChangeOrder(WTChangeRequest2)");
			logger.debug("cr: " + cr);
			logger.debug("exiting createChangeOrder()");
		}
		return (createChangeOrder(cr, 30));
	}

	/**
	 * Create change order for a given change request and set need date
	 *
	 * @param WTChangeRequest2
	 *            cr - the change request
	 * @param int
	 *            diff - need date is set to today+diff (in days)
	 * @return WTChangeOrder2 - the created change order
	 **/
	public static WTChangeOrder2 createChangeOrder(WTChangeRequest2 cr, int diff) throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("entering createChangeOrder(WTChangeRequest2,int)");
			logger.debug("cr: " + cr);
			logger.debug("diff: " + diff);
			logger.debug("exiting createChangeOrder()");
		}
		return (createChangeOrder(cr, null, 30));
	}

	/**
	 * Create change order for a given change request and set need date
	 *
	 * @param WTChangeRequest2
	 *            cr - the change request
	 * @param String
	 *            name - name of change order
	 * @param int
	 *            diff - need date is set to today+diff (in days)
	 * @return WTChangeOrder2 - the created change order
	 **/
	public static WTChangeOrder2 createChangeOrder(WTChangeRequest2 cr, String name, int diff) throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("entering createChangeOrder(WTChangeRequest2,String,int)");
			logger.debug("cr: " + cr);
			logger.debug("name: \"" + name + "\"");
			logger.debug("diff: " + diff);
		}
		WTChangeOrder2 co = null;
		boolean found = false;
		logger.debug("WorkflowHelper.createChangeOrder  cr = " + cr.getDisplayIdentifier() + " >>>>");
		try {
			Hashtable h = new Hashtable();
			ReferenceFactory rf = new ReferenceFactory();
			h.put("cr_ref", rf.getReferenceString(cr));
			h.put("type", "wt.change2.WTChangeOrder2");
			h.put("diff", (new Integer(diff)).toString());
			co = createChangeOrder(h);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("WorkflowHelper.createChangeOrder Exception: " + e.getMessage());
			throw (new Exception(e.toString()));
		}
		logger.debug("WorkflowHelper.createChangeOrder  co "
				+ (co != null ? co.getDisplayIdentifier().toString() : "not created") + " <<<<");
		if (logger.isDebugEnabled()) {
			logger.debug("exiting createChangeOrder()");
			logger.debug("returning: " + co);
		}
		return co;
	}

	/**
	 * Create change order for a given change request and set need date
	 *
	 * @param Hashtable
	 *            h - Hashtable with values for change order
	 * @return WTChangeOrder2 - the created change order
	 **/
	public static WTChangeOrder2 createChangeOrder(Hashtable h) throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("entering createChangeOrder(Hashtable)");
			logger.debug("h: " + h);
		}
		WTChangeOrder2 co = null;
		boolean found = false;
		try {
			// create ecn
			ReferenceFactory rf = new ReferenceFactory();
			Group g = null;
			g = invokeTask("/ext/tools/createChangeOrder", h, "co");
			if (g != null && g.getElementCount() > 0) {
				for (int i = 0; i < g.getElementCount(); i++) {
					Element elem = g.getElementAt(i);
					co = (WTChangeOrder2) ToolUtils.objFromObid(elem.getUfid());
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("WorkflowHelper.createChangeOrder Exception: " + e.getMessage());
			throw (new Exception(e.toString()));
		}
		logger.debug("WorkflowHelper.createChangeOrder  co "
				+ (co != null ? co.getDisplayIdentifier().toString() : "not created") + " <<<<");
		if (logger.isDebugEnabled()) {
			logger.debug("exiting createChangeOrder()");
			logger.debug("returning: " + co);
		}
		return co;
	}

	/**
	 * Create change activity for a given change order
	 *
	 * @param WTChangeOrder2
	 *            cr - the change request
	 * @return WTChangeActivity2 - the created change order
	 **/
	public static WTChangeActivity2 createChangeActivity(WTChangeOrder2 co) throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("entering createChangeActivity(WTChangeOrder2)");
			logger.debug("co: " + co);
			logger.debug("exiting createChangeActivity()");
		}
		return (createChangeActivity(co, true));
	}

	/**
	 * Create change activity for a given change order
	 *
	 * @param WTChangeOrder2
	 *            cr - the change request
	 * @param boolean
	 *            addChangeables - if true, add changeables from ChangeRequest
	 *            also to change activity
	 * @return WTChangeActivity2 - the created change order
	 **/
	public static WTChangeActivity2 createChangeActivity(WTChangeOrder2 co, boolean addChangeables) throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("entering createChangeActivity(WTChangeOrder2,boolean)");
			logger.debug("co: " + co);
			logger.debug("addChangeables: " + addChangeables);
		}
		WTChangeActivity2 ca = null;
		WTChangeRequest2 cr = null;
		boolean found = false;
		try {
			ca = WTChangeActivity2.newWTChangeActivity2(co.getName());
			ca.setDescription(co.getDescription());
			ca.setNeedDate(co.getNeedDate());
			// com.ptc.windchill.pdmlink.repository.common.PDMLinkRepositoryHelper.setRepository(ca,
			// com.ptc.windchill.pdmlink.repository.common.PDMLinkRepositoryHelper.getRepository(co),true);
			// Save all
			ca = (WTChangeActivity2) ChangeHelper2.service.saveChangeActivity(co, ca);
			// create default values
			Hashtable h = new Hashtable();
			ReferenceFactory rf = new ReferenceFactory();
			Group g = null;
			h.put("object_ref", rf.getReferenceString(ca));
			h.put("type", "wt.change2.WTChangeActivity2");
			g = invokeTask("/ext/tools/setDefaults2ChangeObj", h, "ca");
			if (addChangeables) {
				// get changeables from cr and add them to ca
				QueryResult qr = ChangeHelper2.service.getChangeRequest(co);
				while (qr.hasMoreElements()) {
					cr = (WTChangeRequest2) qr.nextElement();
				}
				if (qr != null) {
					qr = ChangeHelper2.service.getChangeables(cr);
					if (qr.hasMoreElements()) {
						AffectedActivityData link = new AffectedActivityData();
						link.setInventoryDisposition(InventoryDisposition.toInventoryDisposition("CONVERT"));
						link.setDescription("autom. created");
						ChangeHelper2.service.storeAssociations(link.getClass(), ca,
								qr.getObjectVectorIfc().getVector());
					}
				}
			}
			// update team
			ca = (WTChangeActivity2) PersistenceHelper.manager.refresh(ca);
			WTPrincipal p = getUserByRole(Role.toRole("CHANGE ADMINISTRATOR I"), co);
			updateTeam(Role.toRole("REVIEWER"), p, ca);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("WorkflowHelper.createChangeActivity Exception: " + e.getMessage());
			throw (new Exception(e.toString()));
		}
		if (logger.isDebugEnabled()) {
			logger.debug("exiting createChangeActivity()");
			logger.debug("returning: " + ca);
		}
		return ca;
	}

	/**
	 * Create change activity
	 *
	 * @param WTChangeOrder2
	 *            co - Hashtable with values for change activity
	 * @param Hashtable
	 *            h - Hashtable with values for change activity
	 * @param Vector
	 *            v - Vector with changeables
	 * @return WTChangeOrder2 - the created change activity
	 **/
	public static WTChangeActivity2 createChangeActivity(WTChangeOrder2 co, Hashtable h) throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("entering createChangeActivity(WTChangeOrder2,Hashtable)");
			logger.debug("co: " + co);
			logger.debug("h: " + h);
		}
		WTChangeActivity2 ca = null;
		boolean found = false;
		try {
			// create ecn
			ReferenceFactory rf = new ReferenceFactory();
			h.put("changeorder", rf.getReferenceString(co));
			Group g = null;
			g = invokeTask("/ext/tools/createChangeActivity", h, "ca");
			if (g != null && g.getElementCount() > 0) {
				for (int i = 0; i < g.getElementCount(); i++) {
					Element elem = g.getElementAt(i);
					ca = (WTChangeActivity2) ToolUtils.objFromObid(elem.getUfid());
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("WorkflowHelper.createChangeActivity Exception: " + e.getMessage());
			throw (new Exception(e.toString()));
		}
		logger.debug("WorkflowHelper.createChangeActivity  ca "
				+ (ca != null ? ca.getDisplayIdentifier().toString() : "not created") + " <<<<");
		if (logger.isDebugEnabled()) {
			logger.debug("exiting createChangeActivity()");
			logger.debug("returning: " + ca);
		}
		return ca;
	}

	/**
	 * Get a change activity for a given object. Check if this object itself,
	 * its related WTPart or WTDocument are related to a CA. Check also if the
	 * predecessor of the WTPart and WTDocument are related to a CA.
	 *
	 * @param WTObject
	 *            o - Object to add to a ca
	 * @return WTChangeActivity2 - the created change activity
	 **/
	public static WTChangeActivity2 getChangeActivity(WTObject o) throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("entering getChangeActivity(WTObject)");
			logger.debug("o: " + o);
		}
		WTChangeActivity2 ca = null;
		Hashtable h = new Hashtable();
		try {
			// create ecn
			ReferenceFactory rf = new ReferenceFactory();
			h.put("object_ref", rf.getReferenceString(o));
			Group g = null;
			g = invokeTask("/ext/tools/getChangeActivity", h, "ca");
			if (g != null && g.getElementCount() > 0) {
				Element elem = g.getElementAt(0);
				ca = (WTChangeActivity2) ToolUtils.objFromObid(elem.getUfid());
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw (new Exception("Error during getting Change Activity."));
		}
		logger.debug("WorkflowHelper.getChangeActivity ca "
				+ (ca != null ? ca.getDisplayIdentifier().toString() : "not created") + " <<<<");
		if (logger.isDebugEnabled()) {
			logger.debug("exiting getChangeActivity()");
			logger.debug("returning: " + ca);
		}
		return ca;
	}

	/**
	 * Create a new Change Order and Change activity for a given object.
	 *
	 * @param WTObject
	 *            o - Object to add to a ca
	 * @return WTObject[] - 1. element is CO, 2. element is CA
	 **/
	public static WTObject[] createCOCA(WTObject obj, String description, int diff, Hashtable coAttribs)
			throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("entering createCOCA(WTObject,String,int,Hashtable)");
			logger.debug("obj: " + obj);
			logger.debug("description: \"" + description + "\"");
			logger.debug("diff: " + diff);
			logger.debug("coAttribs: " + coAttribs);
		}
		Transaction tx = null;
		WTChangeActivity2 ca = null;
		WTChangeOrder2 co = null;
		WTObject[] res = new WTObject[2];
		Hashtable h = new Hashtable();
		String num = null;
		try {
			/********************************
			 * do all as one transaction
			 ********************************/
			tx = new Transaction();
			tx.start();
			ReferenceFactory rf = new ReferenceFactory();
			if (obj instanceof WTDocument) {
				num = ((WTDocument) obj).getNumber();
			} else if (obj instanceof WTPart) {
				num = ((WTPart) obj).getNumber();
			} else if (obj instanceof EPMDocument) {
				num = ((EPMDocument) obj).getNumber();
			}

			/********************************
			 * create a change order
			 ********************************/
			co = WTChangeOrder2.newWTChangeOrder2(num);
			co.setDescription(description);
			// calculate need date
			GregorianCalendar c = new GregorianCalendar();
			c.set(Calendar.MONTH, ((c.get(Calendar.MONTH)) + 1));
			c.set(Calendar.DAY_OF_MONTH, (c.get(Calendar.DAY_OF_MONTH)));
			c.set(Calendar.YEAR, (c.get(Calendar.YEAR)));
			long targetDate = System.currentTimeMillis() + (1000L * 60 * 60 * 24 * diff);
			java.sql.Timestamp t = new java.sql.Timestamp(targetDate);
			co.setNeedDate(t);
			// com.ptc.windchill.pdmlink.repository.common.PDMLinkRepositoryHelper.setRepository(co,
			// com.ptc.windchill.pdmlink.repository.common.PDMLinkRepositoryHelper.getRepository((wt.admin.DomainAdministered)obj),true);
			// Save change order
			co = (WTChangeOrder2) PersistenceHelper.manager.store(co);
			logger.debug("WorkflowHelper.createCOCA: change order: "
					+ (co != null ? co.getDisplayIdentifier().toString() : "not created"));

			/********************************
			 * create a change activity
			 ********************************/
			ca = WTChangeActivity2.newWTChangeActivity2(co.getName());
			ca.setDescription(co.getDescription());
			ca.setNeedDate(co.getNeedDate());
			// com.ptc.windchill.pdmlink.repository.common.PDMLinkRepositoryHelper.setRepository(ca,
			// com.ptc.windchill.pdmlink.repository.common.PDMLinkRepositoryHelper.getRepository(co),true);
			// Save change activity
			ca = (WTChangeActivity2) ChangeHelper2.service.saveChangeActivity(co, ca);
			logger.debug("WorkflowHelper.createCOCA: change activity: "
					+ (ca != null ? ca.getDisplayIdentifier().toString() : "not created"));

			/********************************
			 * update change order and activity to add IBA respondig to type
			 * definition
			 ********************************/
			updateObject(co, coAttribs);
			// updateObject(co,"01_Change_Description","NEW PART NUMBER");
			updateObject(ca, null, null);

			res[0] = co;
			res[1] = ca;
			tx.commit();
		} catch (WTException e) {
			tx.rollback();
			e.printStackTrace();
			logger.error("WorkflowHelper.createCOCA Exception: " + e.getMessage());
			throw (new Exception(e.toString()));
		} catch (Exception e) {
			tx.rollback();
			e.printStackTrace();
			logger.error("WorkflowHelper.createCOCA Exception: " + e.getMessage());
			throw (new Exception(e.toString()));
		}
		if (logger.isDebugEnabled()) {
			logger.debug("exiting createCOCA()");
			logger.debug("returning: " + res);
		}
		return res;
	}

	/**
	 * Add object to a change activity. If the CA+ECN does not yet exist, create
	 * it.
	 *
	 * @param WTObject
	 *            o - Object to add to a ca
	 * @param Vector
	 *            v - Additional objects to add to ca
	 * @return WTChangeActivity2 - the created change activity
	 **/
	public static WTChangeActivity2 addAsResultingItem(WTObject o, Vector v) throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("entering addAsResultingItem(WTObject,Vector)");
			logger.debug("o: " + o);
			logger.debug("v: " + v);
		}
		WTChangeActivity2 ca = null;
		Hashtable h = new Hashtable();
		try {
			// create ecn
			ReferenceFactory rf = new ReferenceFactory();
			h.put("object_ref", rf.getReferenceString(o));
			if (v != null && v.size() > 0) {
				String add = "";
				for (int i = 0; i < v.size(); i++) {
					if (v.get(i) != null)
						add = add + "," + rf.getReferenceString((WTObject) v.get(i));
				}
				h.put("additional", add);
			}

			Group g = null;
			g = invokeTask("/ext/tools/addAsResultingItem", h, "ca");
			if (g != null && g.getElementCount() > 0) {
				for (int i = 0; i < g.getElementCount(); i++) {
					Element elem = g.getElementAt(i);
					ca = (WTChangeActivity2) ToolUtils.objFromObid(elem.getUfid());
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("WorkflowHelper.addAsResultingItem Exception: " + e.getMessage());
			throw (new Exception("Error during creation of addAsResultingItem."));
		}
		logger.debug("WorkflowHelper.addAsResultingItem  ca "
				+ (ca != null ? ca.getDisplayIdentifier().toString() : "not created") + " <<<<");
		if (logger.isDebugEnabled()) {
			logger.debug("exiting addAsResultingItem()");
			logger.debug("returning: " + ca);
		}
		return ca;
	}

	/**
	 * Add objects to an existing change activity.
	 *
	 * @param WTChangeActivity2
	 *            - Object to add to a ca
	 * @param Vector
	 *            v - objects to add to ca
	 **/
	public static void addAsResultingItemToCA(WTChangeActivity2 ca, Vector v) throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("entering addAsResultingItemToCA(WTChangeActivity2,Vector)");
			logger.debug("ca: " + ca);
			logger.debug("v: " + v);
		}
		Hashtable h = new Hashtable();
		try {
			if (v.size() > 0) {
				ChangeRecord2 link = new ChangeRecord2();
				link.setDescription("autom. created");
				ChangeHelper2.service.storeAssociations(link.getClass(), ca, v);
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("WorkflowHelper.addAsResultingItemToCA Exception: " + e.getMessage());
			throw (new Exception(e.toString()));
		}
		if (logger.isDebugEnabled()) {
			logger.debug("WorkflowHelper.addAsResultingItemToCA: added object to ca.");
		}
		if (logger.isDebugEnabled()) {
			logger.debug("exiting addAsResultingItemToCA()");
		}
	}

	/**
	 * Create a typed document with a webject/task
	 *
	 * <ie:webject name="Create-Object" type="ACT">
	 * <ie:param name="TYPE" data="${@FORM[]logicalForm[]}"/>
	 * <ie:param name="FIELD" data="name=${@FORM[]name[]}"/>
	 * <ie:param name="FIELD" data="number=${@FORM[]number[]}"/>
	 * <ie:param name="FIELD" data="folder=${@FORM[]folder[]}"/>
	 * <ie:param name="FIELD" data=
	 * "docType=${@FORM[]documentTypeInternalValue[]}"/>
	 * <ie:param name="FIELD" data=
	 * "department=${@FORM[]departmentInternalValue[]}"/>
	 * <ie:param name="FIELD" data="title=${@FORM[]title[]}"/>
	 * <ie:param name="FIELD" data="description=${@FORM[]description[]}"/>
	 * <ie:param name="FIELD" data="<%=fields.toString ()%>" delim=","/>
	 * <ie:param name="ATTRIBUTE" data="${@FORM[]attribute[*]}" delim=","
	 * default="obid,name,number"/>
	 * <ie:param name="GROUP_OUT" data="${@FORM[]group_out[0]}" default=
	 * "document"/> </ie:webject>
	 * 
	 * @param Hashtable
	 *            h - contains all parameters
	 * @return WTDocument - the created document
	 **/
	public static WTDocument createVaultDrawing(String num, String version, String name, String folder, String cont,
			RevisionControlled p) throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("entering createVaultDrawing(String,String,String,String,String,RevisionControlled)");
			logger.debug("num: \"" + num + "\"");
			logger.debug("version: \"" + version + "\"");
			logger.debug("name: \"" + name + "\"");
			logger.debug("folder: \"" + folder + "\"");
			logger.debug("cont: \"" + cont + "\"");
			logger.debug("p: " + p);
		}
		WTDocument d = null;

		Hashtable h = new Hashtable();
		h.put("name", name);
		h.put("number", num);
		h.put("folder", folder);
		h.put("logicalForm", "NeutralFormatDoc2D");
		h.put("documentTypeInternalValue", "$$Document");
		h.put("departmentInternalValue", "ENG");
		h.put("title", name);
		h.put("description", name);
		h.put("ContainerRef", cont);
		// try{
		ReferenceFactory rf = new ReferenceFactory();
		Group g = invokeTask("/ext/tools/createDocument", h, "tiff");
		if (g != null && g.getElementCount() > 0) {
			for (int i = 0; i < g.getElementCount(); i++) {
				Element elem = g.getElementAt(i);
				d = (WTDocument) ToolUtils.objFromObid(elem.getUfid());
				break;
			}
			if (g.getElementCount() == 0)
				d = getWTDocument(num, null);
		} else {
			d = getWTDocument(num, null);
		}

		// 20061030 mkr; loop to create all previous versions too!
		// set correct version, limit tries ...
		int max = 100, ntries = 0;
		if (d != null)
			while (ntries++ < max && versionLessThan(d, p)) {
				d = reviseTiff(d);
				logger.debug("revise to adjust version created: " + d.getDisplayIdentifier());
				// mkr: find part and link doc to it ...
				WTPart p1 = WorkflowHelper.getWTPart(d.getNumber(), d.getVersionIdentifier().getValue());
				WorkflowHelper.linkDoc2WTPart(d, p1);
				logger.debug("linked doc to part: " + p1);
			}
		if (d == null || ntries == max) {
			throw (new Exception("Could not create new Document " + num + " (tries=" + ntries + ")."));
		}

		if (logger.isDebugEnabled()) {
			logger.debug("exiting createVaultDrawing()");
			logger.debug("returning: " + d);
		}
		return d;
	}

	/**
	 * Create a wtpart with a webject/task
	 *
	 * <ie:webject name="Create-Object" type="ACT">
	 * <ie:param name="TYPE" data="${@FORM[]class[]}"/>
	 * <ie:param name="FIELD" data="name=${@FORM[]name[]}"/>
	 * <ie:param name="FIELD" data="number=${@FORM[]number[]}"/>
	 * <ie:param name="FIELD" data="folder=${@FORM[]folder[]}"/>
	 * <ie:param name="FIELD" data=
	 * "docType=${@FORM[]documentTypeInternalValue[]}"/>
	 * <ie:param name="FIELD" data=
	 * "department=${@FORM[]departmentInternalValue[]}"/>
	 * <ie:param name="FIELD" data="title=${@FORM[]title[]}"/>
	 * <ie:param name="FIELD" data="description=${@FORM[]description[]}"/>
	 * <ie:param name="FIELD" data="partType=${@FORM[]parttype[]}"/>
	 * <ie:param name="FIELD" data="view.id=${@FORM[]viewObjectRef[]}"/>
	 * <ie:param name="FIELD" data="source=${@FORM[]source[]}"/>
	 * <ie:param name="FIELD" data="<%=fields.toString ()%>" delim=","/>
	 * <ie:param name="ATTRIBUTE" data="${@FORM[]attribute[*]}" delim=","
	 * default="obid,name,number"/>
	 * <ie:param name="GROUP_OUT" data="${@FORM[]group_out[0]}" default=
	 * "document"/> </ie:webject>
	 * 
	 * @param Hashtable
	 *            h - contains all parameters
	 * @return WTDocument - the created document
	 **/
	public static WTPart createNewPart(String num, String name, String folder) throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("entering createNewPart(String,String,String)");
			logger.debug("num: \"" + num + "\"");
			logger.debug("name: \"" + name + "\"");
			logger.debug("folder: \"" + folder + "\"");
		}
		WTPart d = null;

		Hashtable h = new Hashtable();
		h.put("class", "wt.part.WTPart");
		h.put("name", name);
		h.put("number", num);
		h.put("folder", folder);
		h.put("documentTypeInternalValue", "$$Document");
		h.put("departmentInternalValue", "ENG");
		h.put("title", name);
		h.put("description", name);
		h.put("partType", "component");
		// h.put("view.id","");
		h.put("source", "make");
		try {
			Group g = invokeTask("/ext/tools/createPart", h, "part");
			if (g != null && g.getElementCount() > 0) {
				for (int i = 0; i < g.getElementCount(); i++) {
					Element elem = g.getElementAt(i);
					d = (WTPart) ToolUtils.objFromObid(elem.getUfid());
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("WorkflowHelper.createNewPart Exception: " + e.getMessage());
			throw (new Exception(e.toString()));
		}

		if (logger.isDebugEnabled()) {
			logger.debug("exiting createNewPart()");
			logger.debug("returning: " + d);
		}
		return d;
	}

	/**
	 * invoke a tasks
	 *
	 * @param String
	 *            taskURI - name of task (uri)
	 * @param Hashtable
	 *            h - contains all parameters
	 * @param String
	 *            groupName - name of group to return
	 * @return Group - group with result
	 **/
	public static Group invokeTask(String taskURI, Hashtable h, String groupName) throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("entering invokeTask(String,Hashtable,String)");
			logger.debug("taskURI: \"" + taskURI + "\"");
			logger.debug("h: " + h);
			logger.debug("groupName: \"" + groupName + "\"");
		}
		Group g = null;
		String instance = wt.util.WTProperties.getLocalProperties().getProperty("wt.federation.ie.VMName");
		Task t = new Task(taskURI, instance);

		Enumeration e = h.keys();
		Object n = null;
		while (e.hasMoreElements()) {
			n = e.nextElement();
			t.addParam((String) n, h.get(n));
		}
		t.addParam("GROUP_OUT", groupName);
		t.invoke();
		g = t.getGroup(groupName);
		if (logger.isDebugEnabled()) {
			logger.debug("exiting invokeTask()");
			logger.debug("returning: " + g);
		}
		return g;
	}

	/**
	 * Update a team for an object. If role exists, add user otherwise add role
	 * to team and add user.
	 *
	 * @param Role
	 *            r - the role
	 * @param WTPrincipal
	 *            p - user or group to add
	 * @param TeamManaged
	 *            o - the object
	 * @return void
	 **/
	public static void updateTeam(Role r, WTPrincipal p, TeamManaged o) {
		if (logger.isDebugEnabled()) {
			logger.debug("entering updateTeam(Role,WTPrincipal,TeamManaged)");
			logger.debug("r: " + r);
			logger.debug("p: " + p);
			logger.debug("o: " + o);
		}
		try {
			Team team = null;
			boolean found = false;
			wt.team.TeamReference teamreference = o.getTeamId();
			team = (Team) teamreference.getObject();
			team.addPrincipal(r, p);
			team = (Team) PersistenceHelper.manager.refresh(team);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("WorkflowHelper.updateTeam Exception: " + e.getMessage());
		}
		if (logger.isDebugEnabled()) {
			logger.debug("exiting updateTeam()");
		}
	}

	/**
	 * Get a user from a team of an object determined by a role.
	 *
	 * @param Role
	 *            r - the role
	 * @param TeamManaged
	 *            o - the object
	 * @return WTPrincipal - user or group
	 **/
	public static WTPrincipal getUserByRole(Role r, TeamManaged o) {
		if (logger.isDebugEnabled()) {
			logger.debug("entering getUserByRole(Role,TeamManaged)");
			logger.debug("r: " + r);
			logger.debug("o: " + o);
		}
		WTPrincipal p = null;
		try {
			Team team = null;
			boolean found = false;
			wt.team.TeamReference teamreference = o.getTeamId();
			team = (Team) teamreference.getObject();
			Vector vector = team.getRoles();
			for (Enumeration enumeration = vector.elements(); enumeration.hasMoreElements();) {
				Role role = (Role) enumeration.nextElement();
				if (role.equals(r)) {
					for (Enumeration enumeration1 = team.getPrincipalTarget(role); enumeration1.hasMoreElements();) {
						WTPrincipalReference wtprincipalreference = (WTPrincipalReference) enumeration1.nextElement();
						if (wtprincipalreference != null)
							p = wtprincipalreference.getPrincipal();
						break;
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("WorkflowHelper.getUserByRole Exception: " + e.getMessage());
		}
		if (logger.isDebugEnabled()) {
			logger.debug("exiting getUserByRole()");
			logger.debug("returning: " + p);
		}
		return p;
	}

	/**
	 * Change Version of an object.
	 *
	 * @param Versioned
	 *            o - the object
	 **/
	public static void setVersion(Versioned o, String newversion) {
		if (logger.isDebugEnabled()) {
			logger.debug("entering setVersion(Versioned,String)");
			logger.debug("o: " + o);
			logger.debug("newversion: \"" + newversion + "\"");
		}
		logger.debug("WorkflowHelper.setVersion  for " + o + " to " + newversion + " >>>>");
		try {
			// get all iterations of the specific version
			QueryResult qr = wt.vc.VersionControlHelper.service.allIterationsFrom((Iterated) o);
			while (qr.hasMoreElements()) {
				WTObject i = (WTObject) qr.nextElement();
				// check same version
				if (wt.vc.VersionControlHelper.inSameBranch((Iterated) i, (Iterated) o)) {
					MultilevelSeries multilevelseries = MultilevelSeries.newMultilevelSeries("wt.vc.VersionIdentifier",
							newversion);
					VersionIdentifier versionidentifier = VersionIdentifier.newVersionIdentifier(multilevelseries);
					VersionControlHelper.setVersionIdentifier((Versioned) i, versionidentifier);
					PersistenceServerHelper.manager.update(i);
				}
			}
		} catch (WTPropertyVetoException e) {
			logger.error("WorkflowHelper.setVersion Exception: " + e);
		} catch (WTException e) {
			logger.error("WorkflowHelper.setVersion Exception: " + e);
		}
		logger.debug("WorkflowHelper.setVersion  <<<<");
		if (logger.isDebugEnabled()) {
			logger.debug("exiting setVersion()");
		}
	}

	/**
	 * Update object, check out is not performed. Make sure the attribute is
	 * registered in codebase\LogigalAttributes.xml (in rev 6.2.6)
	 *
	 * @param WTObject
	 *            o - the object
	 * @param String
	 *            name - parameter name
	 * @param String
	 *            value - parameter value
	 **/
	public static void updateObject(WTObject o, String name, String value) throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("entering updateObject(WTObject,String,String)");
			logger.debug("o: " + o);
			logger.debug("name: \"" + name + "\"");
			logger.debug("value: \"" + value + "\"");
		}
		try {
			// create default values
			Hashtable h = new Hashtable();
			ReferenceFactory rf = new ReferenceFactory();
			Group g = null;
			h.put("object_ref", rf.getReferenceString(o));
			h.put("type", o.getClass().getName());
			if (name != null)
				h.put("field", name + "='" + value + "'");
			g = invokeTask("/ext/tools/updateObject", h, "o");
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("WorkflowHelper.updateObject Exception: " + e.getMessage());
			throw (new Exception(e.toString()));
		}
		if (logger.isDebugEnabled()) {
			logger.debug("exiting updateObject()");
		}
	}

	/**
	 * Update object, check out is not performed. Make sure the attribute is
	 * registered in codebase\LogigalAttributes.xml (in rev 6.2.6)
	 *
	 * @param WTObject
	 *            o - the object
	 * @param Hashtable
	 *            fields - parameters and values
	 **/
	public static void updateObject(WTObject wto, Hashtable fields) throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("entering updateObject(WTObject,Hashtable)");
			logger.debug("wto: " + wto);
			logger.debug("fields: " + fields);
		}
		try {
			// create default values
			Hashtable h = new Hashtable();
			ReferenceFactory rf = new ReferenceFactory();
			Group g = null;
			h.put("object_ref", rf.getReferenceString(wto));
			h.put("type", wto.getClass().getName());
			if (fields != null) {
				String s = null;
				Object o = null;
				for (Enumeration e = fields.keys(); e.hasMoreElements();) {
					o = e.nextElement();
					if (o != null) {
						if (s == null)
							s = o.toString() + "=" + fields.get(o).toString();
						else
							s = s + "~" + o.toString() + "=" + fields.get(o).toString();
					}
				}
				h.put("field", s);
			}
			g = invokeTask("/ext/tools/updateObject", h, "o");
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("WorkflowHelper.updateObject Exception: " + e.getMessage());
			throw (new Exception(e.toString()));
		}
		if (logger.isDebugEnabled()) {
			logger.debug("exiting updateObject()");
		}
	}

	/**
	 * Get affected data BEFORE for a change activity
	 *
	 * @param ChangeActivityIfc
	 *            ca - the change activity
	 * @return QueryResult - affected data BEFORE change
	 **/
	public static QueryResult getChangeablesBefore(ChangeActivityIfc ca) {
		if (logger.isDebugEnabled()) {
			logger.debug("entering getChangeablesBefore(ChangeActivityIfc)");
			logger.debug("ca: " + ca);
		}
		QueryResult qr = null;
		try {
			qr = ChangeHelper2.service.getChangeablesBefore(ca);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("WorkflowHelper.getChangeablesBefore Exception: " + e.getMessage());
		}
		if (logger.isDebugEnabled()) {
			logger.debug("exiting getChangeablesBefore()");
			logger.debug("returning: " + qr);
		}
		return qr;
	}

	/**
	 * Get affected data AFTER for a change activity
	 *
	 * @param ChangeActivityIfc
	 *            ca - the change activity
	 * @return QueryResult - affected data AFTER change
	 **/
	public static QueryResult getChangeablesAfter(ChangeActivityIfc ca) {
		if (logger.isDebugEnabled()) {
			logger.debug("entering getChangeablesAfter(ChangeActivityIfc)");
			logger.debug("ca: " + ca);
		}
		QueryResult qr = null;
		try {
			qr = ChangeHelper2.service.getChangeablesAfter(ca);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("WorkflowHelper.getChangeablesAfter Exception: " + e.getMessage());
		}
		if (logger.isDebugEnabled()) {
			logger.debug("exiting getChangeablesAfter()");
			logger.debug("returning: " + qr);
		}
		return qr;
	}

	/**
	 * Check if all changeale data is released. Check this for affected data
	 * before and after the change.
	 *
	 * @param ChangeActivityIfc
	 *            ca - the change activity
	 * @return boolean - true if all is released
	 **/
	public static boolean isChangeableReleased(ChangeActivityIfc ca) {
		if (logger.isDebugEnabled()) {
			logger.debug("entering isChangeableReleased(ChangeActivityIfc)");
			logger.debug("ca: " + ca);
		}
		boolean rel = true;
		QueryResult qr = null;
		RevisionControlled o = null;
		try {
			qr = getChangeablesAfter(ca);
			while (qr.hasMoreElements()) {
				o = (RevisionControlled) qr.nextElement();
				if (!checkLCStatus(o))
					rel = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("WorkflowHelper.isChangeableReleased Exception: " + e.getMessage());
		}
		if (logger.isDebugEnabled()) {
			logger.debug("exiting isChangeableReleased()");
			logger.debug("returning: " + rel);
		}
		return rel;
	}

	/**
	 * Compare version of objects
	 *
	 * @param Versioned
	 *            a - object a
	 * @param Versioned
	 *            b - object b
	 * @return boolean true if a less than b
	 **/
	public static boolean versionLessThan(Versioned a, Versioned b) throws VersionControlException {
		if (logger.isDebugEnabled())
			logger.debug("WorkflowHelper.versionLessThan: a=" + a + " ("
					+ VersionControlHelper.getVersionIdentifier(a).getSeries() + ") b=" + b + " ("
					+ VersionControlHelper.getVersionIdentifier(b).getSeries() + ")");
		return (VersionControlHelper.getVersionIdentifier(a).getSeries()
				.lessThan(VersionControlHelper.getVersionIdentifier(b).getSeries()));
	}

	/**
	 * Create a tiff and add it to a vaultdrawing
	 *
	 * @param Versioned
	 *            a - object a
	 * @param Versioned
	 *            b - object b
	 * @return boolean true if a less than b
	 **/
	public static WTDocument createTiffForDrw(EPMDocument drw) throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("entering createTiffForDrw(EPMDocument)");
			logger.debug("drw: " + drw);
		}
		WTDocument d = null;

		try {
			ReferenceFactory rf = new ReferenceFactory();
			Hashtable h = new Hashtable();
			h.put("object_ref", rf.getReferenceString(drw));
			Group g = invokeTask("/ext/tools/createTiffForDrw", h, "tiff");
			if (g != null && g.getElementCount() > 0) {
				for (int i = 0; i < g.getElementCount(); i++) {
					Element elem = g.getElementAt(i);
					d = (WTDocument) ToolUtils.objFromObid(elem.getUfid());
					break;
				}
			}
		} catch (Exception e) {
			// e.printStackTrace();
			logger.error("WorkflowHelper.createTiffForDrw: " + e.getMessage());
			throw (new Exception(e.toString()));
		}

		if (logger.isDebugEnabled()) {
			logger.debug("exiting createTiffForDrw()");
			logger.debug("returning: " + d);
		}
		return d;

	}

	/**
	 * Get the components (EPMDocument type CADASSEMBLY or CADCOMPONENT) for a
	 * given drawing. All "drawing models are retrieved" and returned. Include
	 * also variants.
	 *
	 * @param ReviewReport2
	 *            r
	 * @return ReviewReport2
	 **/
	public static Vector getCompForDrw(EPMDocument drw, Vector models) {
		if (logger.isDebugEnabled()) {
			logger.debug("entering getCompForDrw(EPMDocument,Vector)");
			logger.debug("drw: " + drw);
			logger.debug("models: " + models);
		}
		QueryResult qr = null;
		ArrayList al = null;
		EPMDocument comp = null;
		EPMDocument latest = null;
		Object l = null;
		logger.debug("ext.tools.WorkflowHelper.getCompForDrw(): >>>>");

		// navigate over model
		try {
			if (drw.getDocType().getStringValue().equals("wt.epm.EPMDocumentType.CADDRAWING")) {
				// get the link and check deptype
				qr = PersistenceHelper.manager.navigate(drw, "RoleBObject", EPMReferenceLink.class, false);
				while (qr.hasMoreElements()) {
					l = qr.nextElement();
					if (l instanceof EPMReferenceLink) {
						logger.debug("epmdoc <" + ((EPMReferenceLink) l).getOtherObject(drw) + "> connected with: "
								+ ((EPMReferenceLink) l).getDepType());
						// depType == -1 --> internal refrences
						// deptype == 4 --> drawing model, anything else???
						// depType == 8 --> ???
						// depType == 16 --> drawing format
						// depType == 2048 --> ???
						// if (((EPMReferenceLink)l).getDepType() != -1 ||
						// ((EPMReferenceLink)l).getDepType() != 16){
						if (((EPMReferenceLink) l).getDepType() == 4) {
							if (((EPMReferenceLink) l).getOtherObject(drw) instanceof Mastered) {
								QueryResult vers = VersionControlHelper.service
										.allVersionsOf((Mastered) ((EPMReferenceLink) l).getOtherObject(drw));
								latest = (EPMDocument) vers.nextElement();
								while (vers.hasMoreElements()) {
									comp = (EPMDocument) vers.nextElement();
									if (comp.getVersionIdentifier().getValue()
											.compareTo(latest.getVersionIdentifier().getValue()) > 0)
										latest = comp;
								}
								logger.debug("   <" + latest.getDisplayIdentifier() + "> is linked to drw");
								models.add(latest);
							}
						}
					} else {
						logger.debug("no link.");
					}
				}
			}
		} catch (WTException e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		logger.debug("ext.tools.WorkflowHelper.getCompForDrw(): <<<<");
		if (logger.isDebugEnabled()) {
			logger.debug("exiting getCompForDrw()");
			logger.debug("returning: " + models);
		}
		return models;
	}

	public static String linkDoc2WTPart(WTDocument doc, EPMDocument e) throws Exception {
		if (logger.isDebugEnabled()) {
			logger.debug("entering linkDoc2WTPart(WTDocument,EPMDocument)");
			logger.debug("doc: " + doc);
			logger.debug("e: " + e);
		}
		Hashtable h = new Hashtable();
		h.put("doc", "" + doc);
		h.put("epm", "" + e);
		Group g = invokeTask("/ext/sulis/linkDoc2Part.xml", h, "out");
		if (logger.isDebugEnabled()) {
			logger.debug("exiting linkDoc2WTPart()");
		}
		return ToolUtils.nn(g.getSuccess(), "ERROR");
	}

	/**
	 * Returns workflow variable value of given primary business object
	 * 
	 * @param pbo
	 *            - primary business object
	 * @param variableName
	 *            - variable name
	 * @return variable value
	 */
	public static Object getProcessVariable(Persistable pbo, String variableName) throws WfException, WTException {
		if (logger.isDebugEnabled()) {
			logger.debug("entering getProcessVariable(Persistable,String)");
			logger.debug("pbo: " + pbo);
			logger.debug("variableName: \"" + variableName + "\"");
			logger.debug("Inside getprocessvar : " + pbo + " " + variableName);
		}
		Object wfProcess = getAssociatedRunningProcess(pbo);
		if (logger.isDebugEnabled()) {
			logger.debug("WFProcess : " + wfProcess);
		}
		if (wfProcess == null) {
			if (logger.isDebugEnabled()) {
				logger.debug("WFProcess is null...");
				logger.debug("exiting getProcessVariable()");
				logger.debug("returning: " + true);
			}
			return true;
		}
		ProcessData pd = ((_WfExecutionObject) wfProcess).getContext();
		WfVariable variable = pd.getVariable(variableName);
		if (logger.isDebugEnabled()) {
			logger.debug("ProcessData : " + pd);
			logger.debug("variable : " + variable);
			logger.debug("exiting getProcessVariable()");
		}
		return variable.getValue();
	}

	/**
	 * Returns associated running process of given primary business object.
	 * 
	 * @param pbo
	 *            - primary business object
	 * @return running process object for given pbo or null if the process is
	 *         not present
	 */
	public static Object getAssociatedRunningProcess(Persistable pbo) throws WfException, WTException {

		if (logger.isDebugEnabled()) {
			logger.debug("entering getAssociatedRunningProcess(Persistable)");
			logger.debug("pbo: " + pbo);
		}
		Object wfProcess = null;
		WfState state = WfState.OPEN_RUNNING;

		QueryResult associatedProcesses = WfEngineHelper.service.getAssociatedProcesses(pbo, state, null);
		while (associatedProcesses.hasMoreElements()) {
			wfProcess = associatedProcesses.nextElement();
		}

		if (logger.isDebugEnabled()) {
			logger.debug("exiting getAssociatedRunningProcess()");
			logger.debug("returning: " + wfProcess);
		}
		return wfProcess;
	}

	/**
	 * Returns the user that completed the latest activity in the workflow
	 * 
	 * @param pbo
	 *            - primary business object
	 * @return user that completed latest activity in the workflow
	 */
	public static WTPrincipal getLastCompletedWorkItemPrincipal(Persistable pbo) throws WfException, WTException {

		if (logger.isDebugEnabled()) {
			logger.debug("entering getLastCompletedWorkItemPrincipal(Persistable)");
			logger.debug("pbo: " + pbo);
		}
		Object wfProcess = getAssociatedRunningProcess(pbo);
		ReferenceFactory rf = new ReferenceFactory();
		ObjectReference reference = (ObjectReference) rf.getReference((Persistable) wfProcess);

		if (logger.isDebugEnabled()) {
			logger.debug("exiting getLastCompletedWorkItemPrincipal()");
		}
		return EPMChangeUtils.getCompletedByParentUser(reference);
	}
	public static void setTaskAttributes(boolean approvalReady, boolean immediateRelease, String reworkComment, String specialInstructions) {
		HashMap<String,Object> resultMap = new java.util.HashMap<String,Object>();
		resultMap.put("KB_APPROVAL_READY", approvalReady);
		resultMap.put("KB_IMMEDIATE_RELEASE", immediateRelease);
		if (!KBUtils.isEmpty(reworkComment)) {
			resultMap.put("KB_REWORK_COMMENT", reworkComment);
		}
		if (!KBUtils.isEmpty(specialInstructions)) {
			resultMap.put("KB_SPECIAL_INSTRUCTIONS", specialInstructions);
		}
	}

	public static void setTaskAttributes(boolean approvalReady, String reworkComment, String specialInstructions) {
		HashMap<String,Object> resultMap = new java.util.HashMap<String,Object>();
		resultMap.put("KB_APPROVAL_READY", approvalReady);
		if (!KBUtils.isEmpty(reworkComment)) {
			resultMap.put("KB_REWORK_COMMENT", reworkComment);
		}
		if (!KBUtils.isEmpty(specialInstructions)) {
			resultMap.put("KB_SPECIAL_INSTRUCTIONS", specialInstructions);
		}
	}

}
