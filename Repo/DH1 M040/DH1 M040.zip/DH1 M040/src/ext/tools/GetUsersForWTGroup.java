package ext.tools;

// used for Report Builder
// https://support.ptc.com/appserver/cs/view/solution.jsp?n=CS22167

import java.util.Enumeration;

import wt.fc.ObjectIdentifier;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.org.OrganizationServicesHelper;
import wt.org.WTGroup;
import wt.org.WTUser;
import wt.util.WTException;
public class GetUsersForWTGroup {
	public static String getMembers(Object oid) throws WTException {

		String users=null;
		int number=1;
		System.out.println("\n\n\t\tGetUsersOfGroup:::OID is "+oid);
		ObjectIdentifier obid= ObjectIdentifier.newObjectIdentifier(oid.toString());
		WTGroup grp = (WTGroup)PersistenceHelper.manager.refresh(obid);
		//System.out.println("Found Doc-->"+doc.getNumber());

        Enumeration grpmembers=OrganizationServicesHelper.manager.members(grp, false);
        while (grpmembers.hasMoreElements()) {
			Object object = (Object) grpmembers.nextElement();
			if(object.getClass().isAssignableFrom(WTUser.class)){
				WTUser user=(WTUser)object;
				if(users==null){
					users=number+". "+user.getName();
					number+=1;
				}else{
					users=users+"\n"+number+". "+user.getName();
					number+=1;
				}

			}

		}

		return users;
	}

}

