/*
class maintained by martl@sulis.de

purpose: print values from wt.properties to stdout.

This program is free software; you can redistribute it and/or modify it under the terms of the
GNU Lesser General Public License as published by the Free Software Foundation;
see http://www.gnu.org/licenses/lgpl.html (und deutsch: http://www.gnu.de/lgpl-ger.html)

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
See the GNU Lesser General Public License for more details.

*/

package ext.tools;
import wt.util.*;
import wt.method.*;
/**
  * print values from wt.properties to stdout.
  *
  * @author mkraegeloh
  * @version 1.0
  */

class WtProp implements RemoteAccess{
   public static final String CVSVersion = "$Header: WtProp.java 1.2.2.2 2017/09/01 19:11:29IST ext-nosekm Exp  $";
/**
  * loop arguments (property names) and output their value.
  *
  * @param args	
  * @exception Exception	
  * @return void	
*/
public static void main (String[] args) throws Exception{
  WTContext.init(args);
  WTProperties props = WTProperties.getLocalProperties();
  for(int i=0;i<args.length;i++)
     System.out.println(props.getProperty(args[i],""));
}
}
