// Decompiled by Jad v1.5.7d. Copyright 2000 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/SiliconValley/Bridge/8617/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   KillAllProcesses.java

package ext.tools;

import java.io.PrintStream;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.util.Enumeration;

import org.apache.log4j.Logger;

import wt.fc.*;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.query.QuerySpec;
import wt.session.*;
import wt.util.WTException;
import wt.workflow.engine.WfProcess;

public class KillAllProcesses
    implements RemoteAccess
{

	private static final Logger loggerSession = Logger.getLogger("com.ptc.Session");
	
    public KillAllProcesses()
    {
    }


    private static void deleteProcess(WfProcess process, String kill_flag)
        throws WTException
    {
      boolean kill = false;
      if( kill_flag != null && kill_flag.equalsIgnoreCase("true") ) kill = true;
        SessionContext old_session = SessionContext.newContext();
        try
        {
            SessionHelper.manager.setAdministrator();
            loggerSession.warn("KillAllProcesses.deleteProcess() START Switched user to: " + SessionHelper.getPrincipal().getName());
           if( kill ){
            System.out.println("Kill process:"+process.getName());
            PersistenceHelper.manager.delete(process);
           }
           else{

            try{
              System.out.println("Complete process:"+process.getName());
              wt.workflow.engine.WfTransition tr = wt.workflow.engine.WfTransition.toWfTransition("COMPLETE");
              process.changeState( tr );
            }
            catch( Exception ex ){
              System.out.println("Complete process failed ==> kill:"+process.getName());
              PersistenceHelper.manager.delete(process);
            }
           }
        
        }
        finally
        {
            SessionContext.setContext(old_session);
            loggerSession.warn("KillAllProcesses.deleteProcess() END Switched back to: " + SessionHelper.getPrincipal().getName());
        }
    }

    public static int doKill(String template_name, String kill_flag)
        throws WTException
    {
        int np = 0;
        QuerySpec qs = new QuerySpec(wt.workflow.engine.WfProcess.class);
         // search for class
         qs.appendWhere(new wt.query.SearchCondition(
          wt.workflow.engine.WfProcess.class,
          "name",
          wt.query.SearchCondition.LIKE,
          "%"+template_name+"%"));
        
        System.out.println("doKill1, begin, template_name=" + template_name);
        Enumeration processEnum = PersistenceHelper.manager.find(qs);
        System.out.println("doKill, processes found");
        while(processEnum.hasMoreElements()) 
        {
            WfProcess process = (WfProcess)processEnum.nextElement();
            if(!process.isNested())
            {
                if(template_name != null && process.getName().length() >= template_name.length())
                    System.out.println("Compare: template_name=" + template_name + ", process=" + process.getName().substring(0, template_name.length()));
                boolean kill = false;
                if(template_name == null)
                    kill = true;
                else
                if(template_name != null && process.getName().length() >= template_name.length() && process.getName().substring(0, template_name.length()).equals(template_name))
                    kill = true;
                if(kill)
                {
                    System.out.println("Kill #" + np + " !");
                    process = (WfProcess)PersistenceHelper.manager.prepareForModification(process);
                    deleteProcess(process,kill_flag);
                    np++;
                }
            }
        }
        System.out.println("doKill, end");
        return np;
    }

    public static void main(String args[])
    {
        String template_to_kill = null;
        String kill_flag = "false";
        try
        {
            int i = 0;
            for(int c = args.length; i < c; i++)
            {
                if(args[i].equals("-template"))
                {
                    System.out.println("-template found");
                    template_to_kill = args[i + 1];
                    System.out.println(args[i + 1]);
                }
                if(args[i].equals("-kill_flag"))
                {
                    System.out.println("-kill_flag found");
                    kill_flag = args[i + 1];
                    System.out.println(args[i + 1]);
                }
                if(args[i].equals("-help"))
                {
                    System.out.println("Usage: java ext.fmo.utilties.KillAllProcesses -template Submit -kill_flag true/false");
                    System.out.println("   or: java ext.fmo.utilties.KillAllProcesses");
                }
            }

            if( template_to_kill == null || template_to_kill.length()==0 ){
                    System.out.println("Usage: java ext.fmo.utilties.KillAllProcesses -template Submit -kill_flag true/false");
                    System.out.println("   or: java ext.fmo.utilties.KillAllProcesses");
            }

            System.out.println(template_to_kill);
            System.out.println(kill_flag);
            Class argTypes[] = {
                String.class,
                String.class
            };
            Object arguments[] = {
                template_to_kill,
                kill_flag
            };
            try
            {
                int np = ((Integer)RemoteMethodServer.getDefault().invoke("doKill", CLASSNAME, null, argTypes, arguments)).intValue();
                System.out.println("Deleted " + np + " (non-nested) processes");
                System.exit(0);
            }
            catch(InvocationTargetException e)
            {
                Throwable targetE = e.getTargetException();
                if(targetE instanceof WTException)
                {
                    throw (WTException)targetE;
                } else
                {
                    Object param[] = {
                        "doKill"
                    };
                    throw new WTException(targetE, "wt.fc.fcResource", "0", param);
                }
            }
            catch(RemoteException rme)
            {
                Object param[] = {
                    "doKill"
                };
                throw new WTException(rme, "wt.fc.fcResource", "0", param);
            }
        }
        catch(WTException wte)
        {
            System.out.println(wte.getLocalizedMessage());
            System.exit(1);
        }
    }

    private static final String FC_RESOURCE = "wt.fc.fcResource";
    private static final String CLASSNAME;

    static 
    {
        CLASSNAME = KillAllProcesses.class.getName();
    }
}
