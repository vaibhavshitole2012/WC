/*
class maintained by martl@sulis.de

purpose: arrange setup so main() of given class is invoked with windchill credentials set.

This program is free software; you can redistribute it and/or modify it under the terms of the
GNU Lesser General Public License as published by the Free Software Foundation;
see http://www.gnu.org/licenses/lgpl.html (und deutsch: http://www.gnu.de/lgpl-ger.html)

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
See the GNU Lesser General Public License for more details.

*/
package ext.tools;

import java.io.*;
import java.lang.reflect.*;
import java.net.*;
import java.text.*;
import java.util.*;

/**
  * set user and password, then call main() on class passed as argument.
  *
  * @author mkraegeloh
  * @version 1.0
  * 20090324 mkr; add support to enhance classpath
  * 20090605 mkr; version 1.02 and fix help
  * 20090702 mkr; version 1.03 fix -cp handling
  * 20091126 mkr; 1.4 maj/min
  * 20100127 mkr; 1.5 fix load order to match with how windchill loads - different servlet.jar files cause serialization problems for wt/la/rla calls
  * 20101102 mkr; 1.6 use log4j if available.
  * 20110801 mkr; 1.7 cp2 to add jars at the *end* of the classpath.
  * 20120327 mkr; 1.8 print warning instead of exception on bad classpath entries
  * 20120919 mkr; 1.9 fix help, add -m MS-Name
  * 20120928 mkr; 1.10 add srclib/tool to dirs of classpath
  * 20121024 mkr; 1.11 set authenticator
  */

public class WtWrap {
   public static final int MAJOR = 1;
   public static final int MINOR = 11;
   static String[] dirsToAdd = new String[] { "codebase/WEB-INF/lib", "srclib/tool", "lib", "srclib", "srclib/ie", "srclib/wnc" }; // no tools.jar
   static boolean debug = false;
   static Method logMethod = null;
   static Object logObj = null;
   public static SimpleDateFormat DBGT = new SimpleDateFormat("dd.MM.yyyy hh:mm:ss.SSS");

   /**
     *  set user and password, then call main() on class passed as argument.
     *
     * @param a   the program args - starting with user, password, class, remaining args are passed to main()
     * @exception Exception   
     * @return void     
   */
   public static void main(String[] a) throws Exception {
      debug("Version: " + MAJOR + "." + MINOR);
      int off = 0;
      ArrayList<String> cp = new ArrayList<String>();
      ArrayList<String> cp2 = new ArrayList<String>();
      String IMFrom = "" + WtWrap.class.getResource("/ext/tools/WtWrap.class");
      String classToUse = null, user = null, pass = null, msn = null;
      while (off < a.length - 1) {
         if (a[off].equals("-d")) {
            debug = true;
            off++;
         }
         else if (off < a.length - 1 && a[off].equals("-m")) {
            msn = a[off + 1];
            off += 2;
         }
         else if (off < a.length - 1 && a[off].equals("-cp")) {
            cp.add(a[off + 1]);
            off += 2;
         }
         else if (off < a.length - 1 && a[off].equals("-cp2")) {
            cp2.add(a[off + 1]);
            off += 2;
         }
         else if (off < a.length - 1 && a[off].equals("-wt")) {
            inflateWTClassPath(Thread.currentThread().getContextClassLoader(), a[off + 1], cp, cp2);
            off += 2;
         }
         else
            break;
      }
      if (IMFrom.startsWith("jar:") && IMFrom.endsWith("ync.jar!/ext/tools/WtWrap.class")) { // help TASync in jar
         if (a.length == off)
            classToUse = "ext.sulis.tasync.UI";
         else {
            classToUse = "ext.sulis.tasync.TASync";
            if (!a[off].startsWith("-h")) {
               user = a[off++];
               pass = a[off++];
            }
            if (a.length > off && a[off].equals("-r")) {
               classToUse = "ext.tools.RunListAll";
               off++;
            }
         }
         debug("jar mode ...");
         System.setProperty("fromJar", "true");
         System.setProperty("jarFile", IMFrom.replaceFirst(".*:(.*)!.*", "$1"));
      }
      else {
         if (a.length < off + 3) {
            System.err.println("usage: wtwrap [-d] [-m MS-Name] [-cp dir/jar] [-cp2 dir/jar] [-wt WT_HOME] userid passwd class [args]");
            System.err.println("       use of -d sets debug=true");
            System.err.println("       use of -m sets the name of the MethodServer to use (e.g., BackgroundMethodServer)");
            System.err.println("       use of -cp adds the argument (directory or jar file) in front of the classpath when using -wt)");
            System.err.println("          (can be repeated)");
            System.err.println("       use of -cp2 adds the argument (directory or jar file) at the end of the classpath when using -wt)");
            System.err.println("          (can be repeated)");
            System.err.println("       use of -wt sets classpath to codebase and all jar files in:");
            for (int di = 0; di < +dirsToAdd.length; di++)
               System.err.println("       - " + dirsToAdd[di]);
            System.err.println("Version: " + MAJOR + "." + MINOR);
            System.exit(0);
         }
         user = a[off++];
         pass = a[off++];
         classToUse = a[off++];
      }
      if (user != null && pass != null) {
         debug("auth as " + user);
         authenticate(user, pass, msn);
      }
      // find class to call
      debug("find class: " + classToUse);
      Class c = Class.forName(classToUse);
      String[] b = new String[a.length - off];
      Method m = c.getMethod("main", new Class[] { b.getClass() });
      // prepare args array
      for (int j = 0, i = off; i < a.length;)
         b[j++] = a[i++];
      // and go ...
      debug("invoke main on " + classToUse);
      m.invoke(c, new Object[] { b });
      return; // System.exit(0);
   }

   public static void authenticate(String user, String pass) throws Exception {
      authenticate(user, pass, null);
   }

   public static void authenticate(final String user, final String pass, String msn) throws Exception {
      // authenticate
      Class c = Class.forName("wt.method.RemoteMethodServer");
      Object rms;
      Method m;
      if (msn == null) {
         m = c.getMethod("getDefault", new Class[0]);
         rms = m.invoke(null, (Object[]) null);
         debug("default RMS=" + rms);
      }
      else {
         m = c.getMethod("getInstance", new Class[] { URL.class, String.class });
         rms = m.invoke(null, new Object[] { null, msn });
         debug(msn + " RMS=" + rms);
      }
      m = c.getMethod("setUserName", new Class[] { String.class });
      m.invoke(rms, (Object[]) new String[] { user });
      m = c.getMethod("setPassword", new Class[] { String.class });
      m.invoke(rms, (Object[]) new String[] { pass });
      System.setProperty("com.ptc.net.auth.user", user);
      System.setProperty("com.ptc.net.auth.password", pass);
      debug("auth done.");
   }

   /**
    * use as WtWrap.inflateWTClassPath(Thread.currentThread().getContextClassLoader(), System.getProperty("wt","/wt"));
    */
   public static void inflateWTClassPath(ClassLoader classLoader, String wtHome, ArrayList<String> cp, ArrayList<String> cp2) throws Exception {
      if (!(classLoader instanceof URLClassLoader))
         throw new Exception("not a URLClassLoader; " + classLoader.getClass().getName());
      Method addUrl = URLClassLoader.class.getDeclaredMethod("addURL", new Class[] { URL.class });
      addUrl.setAccessible(true);
      if (cp == null)
         cp = new ArrayList<String>();
      if (cp2 == null)
         cp2 = new ArrayList<String>();
      if (wtHome != null) {
         System.setProperty("codebase", wtHome + "/codebase"); // for ext.tools
         cp.add(wtHome + "/codebase");
      }
      File f;
      for (int i = 0; i < cp.size(); i++) {
         f = new File(cp.get(i));
         if (!f.exists())
            System.err.println("bad CLASSPATH entry: " + cp.get(i));
         //throw new Exception("bad CLASSPATH entry: " + cp.get(i));
         addUrl.invoke(classLoader, new Object[] { f.toURI().toURL() });
      }
      if (wtHome != null)
         for (int di = 0; di < dirsToAdd.length; di++) {
            File dir = new File(wtHome + "/" + dirsToAdd[di]);
            File[] jf = dir.listFiles(new FileFilter() {
               public boolean accept(File f) {
                  return f.getAbsolutePath().endsWith(".jar");
               }
            });
            if (jf == null) {
               System.err.println("cannot list jar dir \"" + dir.getAbsolutePath() + "\", skipping");
               continue;
            }
            for (int i = 0; i < jf.length; i++) {
               addUrl.invoke(classLoader, new Object[] { jf[i].toURI().toURL() });
            }
         }
      for (int i = 0; i < cp2.size(); i++) {
         f = new File(cp2.get(i));
         if (!f.exists())
            System.err.println("bad CLASSPATH entry: " + cp2.get(i));
         //throw new Exception("bad CLASSPATH entry: " + cp2.get(i));
         addUrl.invoke(classLoader, new Object[] { f.toURI().toURL() });
      }

      debug("inflate cp done.");
   }

   private static void debug(String msg) {
      if (logMethod == null) {
         try {
            Class loggerClass = Class.forName("org.apache.log4j.Logger");
            logMethod = loggerClass.getMethod("getLogger", new Class[] { String.class });
            logObj = logMethod.invoke(null, "ext.tools.WtWrap");
            logMethod = loggerClass.getMethod("debug", new Class[] { Object.class });
         }
         catch (Exception err) {
            //err.printStackTrace();
            if (debug)
               System.err.println("no log4j - logs using System.err.println");
            try {
               logMethod = System.out.getClass().getMethod("println", new Class[] { String.class });
            }
            catch (Exception err2) {
               throw new RuntimeException(err2);
            }
         }
      }
      if (debug) {
         if (logObj == null) {
            System.err.println(DBGT.format(new Date()) + " " + msg);
         }
         else {
            try {
               logMethod.invoke(logObj, msg);
            }
            catch (Exception err3) {
               System.err.println("err " + err3 + " printing " + msg);
            }
         }
      }
   }
}
