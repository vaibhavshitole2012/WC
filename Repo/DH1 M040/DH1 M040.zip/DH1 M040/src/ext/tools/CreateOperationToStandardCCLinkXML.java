package ext.tools;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.log4j.Logger;

import wt.log4j.LogR;

public class CreateOperationToStandardCCLinkXML {

	public static final String DELIMITER = ",";
	private static String sourceFilePath;

	protected static final Logger LOGGER = LogR.getLogger(CreateOperationToStandardCCLinkXML.class.getName());

	public static void main(String[] args) throws Exception {
		// sourceFilePath = "C:\\Users\\bilk\\Desktop\\operation.csv";
		if (args.length == 0) {
			System.out.println("usage example:");
			System.out.println(
					"java ext.tools.CreateOperationToStandardCCLinkXML reportImport.csv > loadOperationToStandardCCLinkXML.xml");
			System.out.println("reportImport.csv generated CC report exported to csv file");
			System.out.println("loadOperationToStandardCCLinkXML.xml - file name with converted xml result");
			System.exit(0);
		}
		sourceFilePath = args[0];
		String xml = getXML();
		System.out.println(xml);
	}

	private static String getXML() throws Exception {

		File csvFile = new File(sourceFilePath);
		BufferedReader reader = null;
		try {
			reader = new BufferedReader(new InputStreamReader(new FileInputStream(csvFile)));
		} catch (FileNotFoundException e) {
			LOGGER.debug("File " + sourceFilePath + " not found.");
			System.exit(1);
		}
		LOGGER.debug("Reading file");
		int lineNumber = 0;
		try {
			reader.readLine();
			lineNumber++;
		} catch (IOException e) {
			e.printStackTrace();
		}
		String line = null;
		try {
			line = reader.readLine();
			lineNumber++;
		} catch (IOException e) {
			e.printStackTrace();
		}

		String xml = getXMLHeader();
		while (line != null) {
			String[] fields = line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1);
			for (int i = 0; i < fields.length; i++) {
				String string = fields[i];
				if (!isEmpty(string)) {
					string = string.replaceAll("\"", "");
					fields[i] = string;
				}

			}
			String operationNumber = fields[0];
			if (isEmpty(operationNumber)) {
				throw new Exception("Operation Number field cannot be empty. Please check line " + lineNumber
						+ " in file " + sourceFilePath);
			}
			String standardCCNumber = fields[1];
			if (isEmpty(operationNumber)) {
				throw new Exception("Standard CC Master Number field cannot be empty. Please check line " + lineNumber
						+ " in file " + sourceFilePath);
			}
			xml += getBeginTAG();
			xml += getOperationTAG(operationNumber);
			xml += getStandardCCTAG(standardCCNumber);
			xml += getEndTAG();
			try {
				line = reader.readLine();
				lineNumber++;
			} catch (IOException e) {
				e.printStackTrace();
			}

		}

		try {
			reader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		LOGGER.debug("Done reading file");
		xml += getXMLfooter();
		return xml;
	}

	private static String getStandardCCTAG(String standardCCNumber) {
		String tag = "\t\t<csvstandardCCNumber>" + standardCCNumber + "</csvstandardCCNumber>\n";
		return tag;
	}

	private static String getOperationTAG(String operationNumber) {
		String tag = "\t\t<csvoperationNumber>" + operationNumber + "</csvoperationNumber>\n";
		return tag;
	}

	private static String getXMLHeader() {
		String header = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				+ "<!DOCTYPE NmLoader SYSTEM \"standardX24.dtd\">\n" + "<NmLoader>\n";
		return header;
	}

	private static String getXMLfooter() {
		String footer = "</NmLoader>";
		return footer;
	}

	private static String getBeginTAG() {
		String header = "\t<csvMPMOperationToStandardCCLink handler=\"ext.kb.loadFromFile.MPMStandardCCLoader.createMPMOperationToStandardCCLink\">\n";
		return header;
	}

	private static String getEndTAG() {
		String header = "\t</csvMPMOperationToStandardCCLink>\n";
		return header;
	}

	private static boolean isEmpty(String string) {

		if (string == null || string.trim().length() == 0) {
			return true;
		}
		return false;
	}
}