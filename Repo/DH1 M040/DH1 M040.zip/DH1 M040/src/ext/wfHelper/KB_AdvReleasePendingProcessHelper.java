package ext.wfHelper;

import java.beans.PropertyVetoException;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URI;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;

import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import com.ptc.core.components.util.OidHelper;
import com.ptc.core.lwc.server.PersistableAdapter;
import com.ptc.generic.iba.AttributeService;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.windchill.enterprise.attachments.server.AttachmentsHelper;
import com.ptc.windchill.enterprise.history.MaturityHistoryInfo;
import com.ptc.windchill.enterprise.wvs.newrep.commands.ModelHandlers.ConfigSpecType;
import com.ptc.wpcfg.utilities.PrincipalHelper;
import com.ptc.wvs.client.beans.PublishConfigSpec;
import com.ptc.wvs.common.ui.VisualizationHelper;
import com.ptc.wvs.server.publish.PublishJob;
import com.ptc.wvs.server.publish.PublishParams;
import com.ptc.wvs.server.publish.WVSProcessingJob;
import com.ptc.wvs.server.util.FileHelper;

import ext.kb.publish.PublishUtils;
import ext.kb.util.IBAHelper;
import ext.kb.util.KBConstants;
import ext.kb.util.KBType;
import ext.kb.util.KBTypeIdProvider;
import ext.kb.util.KBUtils;
import ext.kb.util.ObjectRevisionHelper;
import ext.kb.workflow.EPMDocumentMaturityHistoryInfoResolver;
import wt.change2.ChangeActivityIfc;
import wt.change2.ChangeHelper2;
import wt.change2.WTChangeActivity2;
import wt.change2.WTChangeOrder2;
import wt.content.ApplicationData;
import wt.content.ContentHelper;
import wt.content.ContentItem;
import wt.content.ContentRoleType;
import wt.content.ContentServerHelper;
import wt.doc.WTDocument;
import wt.epm.EPMDocument;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.fc.collections.WTHashSet;
import wt.fc.collections.WTSet;
import wt.filter.NavigationCriteria;
import wt.inf.container.WTContained;
import wt.inf.container.WTContainer;
import wt.lifecycle.LifeCycleHelper;
import wt.lifecycle.LifeCycleManaged;
import wt.lifecycle.State;
import wt.log4j.LogR;
import wt.org.WTUser;
import wt.pdmlink.PDMLinkProduct;
import wt.queue.ProcessingQueue;
import wt.queue.QueueHelper;
import wt.representation.PublishedContentLink;
import wt.representation.Representation;
import wt.representation.RepresentationHelper;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.util.WTProperties;
import wt.util.WTPropertyVetoException;
import wt.util.WTRuntimeException;
import wt.vc.VersionControlHelper;
import wt.vc.baseline.BaselineHelper;
import wt.vc.baseline.ManagedBaseline;

/**
 * Class handle actions related to KB_AdvReleasePending workflow.
 */
@Deprecated // R1 customization
public class KB_AdvReleasePendingProcessHelper {

	protected static final org.apache.log4j.Logger LOGGER = LogR
			.getLogger(KB_AdvReleasePendingProcessHelper.class.getName());

	private static Set<String> standardWorkerProductsSet;

	private static WTProperties wtprop;
	private static final String EXCEPTION_MSG = "Exception occured: ";
	static {
		try {
			wtprop = WTProperties.getLocalProperties();
		} catch (IOException e) {
			LOGGER.error(EXCEPTION_MSG, e);
			throw new ExceptionInInitializerError(e);
		}

		// get release queue set name
		RELEASED_QUEUE_SET = wtprop.getProperty("ext.generic.publish.queuesets.releasequeueset");

		STANDARD_QUEUE_SET = wtprop.getProperty("ext.generic.publish.queuesets.standardqueueset");

		standardWorkerProductsSet = new HashSet<String>();

		String standardWorkerProducts = wtprop.getProperty("ext.workflow.standardWorkerProducts");

		if (standardWorkerProducts != null && standardWorkerProducts.isEmpty() == false) {
			String[] standardWorkerProductsArray = standardWorkerProducts.split("\\|");
			standardWorkerProductsSet.addAll(Arrays.asList(standardWorkerProductsArray));
		}

		MAX_WAIT_ITERATION = Integer.parseInt(wtprop.getProperty("ext.workflow.maxwaititeration"));

		DXF_EXTENSION = "." + wtprop.getProperty("ext.workflow.dxfextension");
		ZIP_EXTENSION = "." + wtprop.getProperty("ext.workflow.zipextension");
		PDF_EXTENSION = "." + wtprop.getProperty("ext.workflow.pdfextension");
		HPGL_EXTENSION = "." + wtprop.getProperty("ext.workflow.hpglextension");
		FEEDBACK_EXTENSION = "." + wtprop.getProperty("ext.workflow.feedbackextension");
		// load path for dxf and txt
		TRANSFER_TEMP_DIR_PATH_DXF = wtprop.getProperty("ext.workflow.transferdirpath.temp.dxf");
		TRANSFER_TEMP_DIR_PATH_PDF = wtprop.getProperty("ext.workflow.transferdirpath.temp.pdf");

		REMOVE_COMMAND = wtprop.getProperty("ext.workflow.command.remove");
		COPY_COMMAND = wtprop.getProperty("ext.workflow.command.copy");

		UNIPLOT_SUCCESS_MSG = wtprop.getProperty("ext.workflow.command.validation.uniplot");

		SKIP_CADIM = Boolean.valueOf(wtprop.getProperty("ext.workflow.skipcadim")).booleanValue();
		SKIP_UNIPLOT = Boolean.valueOf(wtprop.getProperty("ext.workflow.skipuniplot")).booleanValue();
	}

	/**
	 * PATH_TO string used in commands. Should be replaced with file.
	 */
	private static final String PATH_TO = "PATH_TO";

	/**
	 * Command to removing files.
	 */
	private static final String REMOVE_COMMAND;

	/**
	 * Command to coping files.
	 */
	private static final String COPY_COMMAND;

	/**
	 * Decide if sending files to CADIM should be skipped.
	 */
	private static final boolean SKIP_CADIM;

	/**
	 * Decide if sending files to UNIPLOT should be skipped.
	 */
	private static final boolean SKIP_UNIPLOT;

	/**
	 * LST files extension.
	 */
	private static final String LST_EXTENSION = ".lst";

	/**
	 * This string should be returned by transfer to Uniplot process if success.
	 */
	private static final String UNIPLOT_SUCCESS_MSG;

	/**
	 * Transfer directory path for DXF and txt files.
	 */
	private static final String TRANSFER_TEMP_DIR_PATH_DXF;

	/**
	 * Transfer directory path for PDF and txt files.
	 */
	private static final String TRANSFER_TEMP_DIR_PATH_PDF;

	/**
	 * DXF files extension.
	 */
	public static final String DXF_EXTENSION;
	/**
	 * ZIP files extension.
	 */
	public static final String ZIP_EXTENSION;
	/**
	 * Feedback files extension.
	 */
	public static final String FEEDBACK_EXTENSION;

	/**
	 * PDF files extension.
	 */
	public static final String PDF_EXTENSION;

	/**
	 * HPGL files extension.
	 */
	public static final String HPGL_EXTENSION;

	/**
	 * Value of max wait iteration.
	 */
	private static final int MAX_WAIT_ITERATION;

	/**
	 * Release queue sets name.
	 */
	private static final String RELEASED_QUEUE_SET;

	/**
	 * Standard queue sets name.
	 */
	private static final String STANDARD_QUEUE_SET;

	private static int BUFFER = 32 * 1024;

	/** The logger. */
	private static Logger logger = Logger.getLogger(KB_AdvReleasePendingProcessHelper.class.getName());

	private static String sDfx;

	/**
	 * Update DesignCADDoc attributes value. The initiator and the actual date
	 * for the promotion (set state) of the objects will be used for the IBAs
	 * KB_RELEASED_BY and KB_RELEASED_DATE.
	 * 
	 * @param pbo
	 *            DesignCADDoc object (worklfow primary business object)
	 * @return [ error message or null in case of no errors, email of user that
	 *         set object to Release Pending]
	 */
	public static String[] updateDrawings(EPMDocument pbo) {

		if (!KBUtils.isDrawing(pbo)) {
			logger.log(Level.FINEST, "EPMDocument: name=" + pbo.getName() + " , number=" + pbo.getNumber()
					+ ", is not Drawing. Processing ended.");
			return new String[] { null, null };
		}

		// The initiator and the actual date for the promotion (set state) of
		// the objects will be used for the IBAs KB_RELEASED_BY and
		// KB_RELEASED_DATE.
		String releasedBy = null;
		String releasedDate = null;

		String releaseByEmail = null;
		try {
			MaturityHistoryInfo maturityHistoryInfo = EPMDocumentMaturityHistoryInfoResolver
					.latestMaturityHistoryInfo(pbo);

			if (maturityHistoryInfo != null) {

				String maturityHistoryInfoLCState = maturityHistoryInfo.getLifecycleStateStr();

				if (!KBConstants.RELEASEPENDING_STATE.equals(maturityHistoryInfoLCState)) {
					String errorMsg = "Latest MaturityHistoryInfo object, for EPMDocument: name=" + pbo.getName()
							+ ", number=" + pbo.getNumber() + ", state should be " + KBConstants.RELEASEPENDING_STATE
							+ " but it is " + maturityHistoryInfoLCState;
					logger.log(Level.SEVERE, errorMsg);
					return new String[] { errorMsg, releaseByEmail };
				}

				releasedBy = maturityHistoryInfo.getPromotedBy();

				try {
					Object user = PrincipalHelper.getPrincipal(releasedBy).getObject();
					WTUser wtUser = (WTUser) user;
					releaseByEmail = wtUser.getEMail();
				} catch (WTRuntimeException e) {
					logger.log(Level.SEVERE, e.getMessage());
					LOGGER.error(EXCEPTION_MSG, e);
				} catch (WTException e) {
					logger.log(Level.SEVERE, e.getMessage());
					e.printStackTrace();
				}

				if (releaseByEmail == null) {
					logger.log(Level.SEVERE, "E-Mail of user who set state to Release Pending is empty.");
				}

				// setting IBA's should be skipped for users from list in
				// preferences
				if (KBUtils.isSpecialUser(releasedBy)) {
					logger.info("Setting IBA'a KB_RELEASED_BY and KB_RELEASED_DATE omitted for user " + releasedBy);
					return new String[] { null, releaseByEmail };
				}

				if (maturityHistoryInfo.getPromotedDate() != null
						&& maturityHistoryInfo.getPromotedDate().size() != 0) {
					Timestamp promoteDate = maturityHistoryInfo.getPromotedDate().get(0);
					String dateFormat = IBAHelper.readIBA(pbo, KBConstants.KB_DATE_FORMAT_IBA);
					SimpleDateFormat format = null;
					if (dateFormat != null && !dateFormat.equals("")) {
						format = new SimpleDateFormat(dateFormat);
					} else {
						format = new SimpleDateFormat(KBConstants.WORKFLOWDATEFORMAT);
					}
					releasedDate = format.format(promoteDate);
				} else {
					String errorMsg = "Unable to find promotion date for EPMDocument: name=" + pbo.getName()
							+ ", number=" + pbo.getNumber();
					logger.log(Level.SEVERE, errorMsg);
					return new String[] { errorMsg, releaseByEmail };
				}

			} else {
				String errorMsg = "MaturityHistoryInfo object was not found for EPMDocument: name=" + pbo.getName()
						+ ", number=" + pbo.getNumber();
				logger.log(Level.SEVERE, errorMsg);
				return new String[] { errorMsg, releaseByEmail };
			}

			IBAHelper.updateIBAAttributeValueWithoutCheckout(pbo, KBConstants.KB_RELEASED_DATE_IBA, releasedDate);
			logger.info("EPMDocument: name=" + pbo.getName() + " , number=" + pbo.getNumber() + ", IBA:"
					+ KBConstants.KB_RELEASED_DATE_IBA + " set. Value=" + releasedDate);

			String releasedByKb = KBUtils.getUserIdFormWindchillId(releasedBy);
			if (releasedByKb == null) {
				String errorMsg = "ID for user=" + releasedBy + " not found";
				logger.log(Level.SEVERE, errorMsg);
				return new String[] { errorMsg, releaseByEmail };
			}

			IBAHelper.updateIBAAttributeValueWithoutCheckout(pbo, KBConstants.KB_RELEASED_BY_IBA, releasedByKb);
			logger.info("EPMDocument: name=" + pbo.getName() + " , number=" + pbo.getNumber() + " , IBA:"
					+ KBConstants.KB_RELEASED_BY_IBA + " set. Value=" + releasedByKb);

		} catch (Exception e) {
			logger.log(Level.SEVERE, e.getMessage());
			LOGGER.error(EXCEPTION_MSG, e);
			return new String[] { "Error: " + e.getMessage(), releaseByEmail };
		}

		return new String[] { null, releaseByEmail };
	}

	/**
	 * This robot (expression) sets object to the state Released. For drawing
	 * object the drawing baseline will be validated and all referenced objects
	 * which have the lifecycle state Approved or Release Pending will be set to
	 * state Released too.
	 * 
	 * @param pbo
	 * @return error message
	 */
	public static String setStateReleased(EPMDocument pbo) {

		String revision = null;

		try {
			LifeCycleHelper.service.setLifeCycleState(pbo, State.toState(KBConstants.RELEASED_RELEASED));

			if (!KBUtils.isDrawing(pbo)) {
				return null;
			}

			revision = (String) KBUtils.getMBAValue(pbo, "revision");
			ManagedBaseline baseline = KBUtils.getCorrespondingBaseline(pbo, revision);

			if (baseline != null) {
				QueryResult items = BaselineHelper.service.getBaselineItems(baseline);

				while (items.hasMoreElements()) {
					Object item = items.nextElement();
					if (item instanceof LifeCycleManaged) {
						LifeCycleManaged lifeCycleManagedItem = (LifeCycleManaged) item;
						String itemState = lifeCycleManagedItem.getLifeCycleState().toString();
						if (KBConstants.APPROVED_STATE.equals(itemState)
								|| KBConstants.RELEASEPENDING_STATE.equals(itemState)) {
							LifeCycleHelper.service.setLifeCycleState(lifeCycleManagedItem,
									State.toState(KBConstants.RELEASED_RELEASED));
						}
					}
				}
			}

		} catch (WTException e) {
			logger.log(Level.SEVERE, e.getMessage());
			LOGGER.error(EXCEPTION_MSG, e);
			return e.getMessage();
		}

		return null;
	}

	/**
	 * This robot (expression) validates drawing for the previous revision. If
	 * the previous revision object has the state Released the robot sets this
	 * version to the state Invalid.
	 * 
	 * @param pbo
	 * @return error message
	 */
	public static String setStateInvalidForLastDrwVersion(EPMDocument pbo) {

		if (!KBUtils.isDrawing(pbo)) {
			return null;
		}

		EPMDocument previousVersion = null;
		try {
			previousVersion = getEPMPreviousVersion(pbo);
			if (previousVersion == null) {
				return null;
			}
			String previousVersionState = previousVersion.getLifeCycleState().toString();
			if (KBConstants.RELEASED_RELEASED.equals(previousVersionState)) {
				LifeCycleHelper.service.setLifeCycleState(previousVersion, State.toState(KBConstants.INVALID_INVALID));
			}
		} catch (WTException e) {
			logger.log(Level.SEVERE, e.getMessage());
			LOGGER.error(EXCEPTION_MSG, e);
			return e.getMessage();
		}

		return null;
	}

	/**
	 * Returns latest iteration of previous version of given object.
	 * 
	 * @param epm
	 * @return
	 * @throws WTException
	 */
	public static EPMDocument getEPMPreviousVersion(EPMDocument epm) throws WTException {
		EPMDocument epmPreviousVersion = null;

		QueryResult epmAllVersions = VersionControlHelper.service.allVersionsFrom(epm);

		if (epmAllVersions != null) {
			while (epmAllVersions.hasMoreElements()) {
				EPMDocument nextEpm = (EPMDocument) epmAllVersions.nextElement();

				if (!PersistenceHelper.isEquivalent(epm, nextEpm)) {
					epmPreviousVersion = nextEpm;
					break;
				}
			}
		}

		return epmPreviousVersion;
	}

	/**
	 * Invokes Release CAD worker.
	 * 
	 * @param pbo
	 * @return String array. index 0 = error msg, index 1 created representation
	 *         name, index 2 = CAD worker invoke date (dd-MM-yy HH:mm:ss)
	 */
	public static String[] invokeDedicatedCadWorker(EPMDocument pbo) {

		if (!KBUtils.isDrawing(pbo)) {
			return null;
		}

		String useRepName = null;
		String invokeDate = null;
		try {
			String queueName = "PublisherQueue" + RELEASED_QUEUE_SET + "1";

			ProcessingQueue queue = QueueHelper.manager.getQueue(queueName);

			ReferenceFactory referenceFactory = new ReferenceFactory();
			String containerOid = referenceFactory.getReferenceString(pbo.getContainerReference());

			PublishConfigSpec pcs = new PublishConfigSpec();
			pcs.setConfigSpec(ConfigSpecType.BASELINE.getIndex());

			String revision = (String) KBUtils.getMBAValue(pbo, "revision");
			ManagedBaseline baseline = KBUtils.getCorrespondingBaseline(pbo, revision);
			if (baseline == null) {
				String msg = "Baseline " + KBUtils.getNumberWithoutExtension(pbo) + "_"
						+ KBUtils.getNumberFromRevision(revision) + " not found.";
				logger.log(Level.SEVERE, msg);
				return new String[] { msg, null, null };
			}
			String blOid = OidHelper.getOidAsString(baseline);
			pcs.setBaseline(blOid);

			String oid = OidHelper.getOidAsString(pbo);
			Locale locale = SessionHelper.getLocale();
			pcs.activateConfigSpec(oid, locale);

			pcs.setStructureType(1);
			pcs.activateStructureType();

			boolean forceRepublish = true;
			NavigationCriteria navigationCriteria = pcs.getEPMActiveNavigationCriteria(true, containerOid);
			NavigationCriteria partNavigationCriteria = pcs.getPartActiveNavigationCriteria(containerOid);
			boolean defaultRep = false;
			useRepName = PublishUtils.createRepName();
			String useRepDescription = "Release_CAD_Worker_representation";
			int structureType = pcs.getStructureType();
			PublishParams publishParams = null;
			boolean republish = true;

			PublishJob publishJob = new PublishJob(forceRepublish, pbo, navigationCriteria, partNavigationCriteria,
					defaultRep, useRepName, useRepDescription, structureType, publishParams, republish);
			publishJob.setRequestQueue(queueName);
			publishJob.setRequestQueuePriority("H");
			publishJob.setRequestQueueSet(RELEASED_QUEUE_SET);

			Class[] arg_types = { WVSProcessingJob.class };
			Object[] args = { publishJob };
			queue.addEntry(SessionHelper.manager.getAdministrator(), "doJob", "com.ptc.wvs.server.publish.PublishJob",
					arg_types, args);

			Timestamp date = new Timestamp(System.currentTimeMillis());
			SimpleDateFormat format = new SimpleDateFormat("dd-MM-yy HH:mm:ss");
			invokeDate = format.format(date);

			logger.info("Release CAD worker publish job invoked for EPMDocument with number=" + pbo.getNumber()
					+ ". Entry added to queue:" + queueName);

		} catch (Exception e) {
			logger.log(Level.SEVERE, e.getMessage());
			LOGGER.error(EXCEPTION_MSG, e);
			return new String[] { "Error: " + e.getMessage(), null, null };
		}

		return new String[] { null, useRepName, invokeDate };
	}

	/*
	 * Checks if the Standard Worker shall be invoked for a given drawing.
	 * 
	 */
	public static Boolean shallStandardWorkerBeInvoked(WTContained contained) {
		WTContainer container = contained.getContainer();

		if (container instanceof PDMLinkProduct && standardWorkerProductsSet.contains(container.getName()))
			return true;
		else
			return false;
	}

	/**
	 * Invokes Standard CAD worker.
	 */
	public static String[] invokeStandardCadWorker(EPMDocument pbo) {

		if (!KBUtils.isDrawing(pbo)) {
			return null;
		}

		String useRepName = null;
		String invokeDate = null;
		try {
			String queueName = "PublisherQueue" + STANDARD_QUEUE_SET + "1";

			ProcessingQueue queue = QueueHelper.manager.getQueue(queueName);

			ReferenceFactory referenceFactory = new ReferenceFactory();
			String containerOid = referenceFactory.getReferenceString(pbo.getContainerReference());

			PublishConfigSpec pcs = new PublishConfigSpec();
			pcs.setConfigSpec(ConfigSpecType.BASELINE.getIndex());

			String revision = (String) KBUtils.getMBAValue(pbo, "revision");
			ManagedBaseline baseline = KBUtils.getCorrespondingBaseline(pbo, revision);
			if (baseline == null) {
				String msg = "Baseline " + KBUtils.getNumberWithoutExtension(pbo) + "_"
						+ KBUtils.getNumberFromRevision(revision) + " not found.";
				logger.log(Level.SEVERE, msg);
				return new String[] { msg, null, null };
			}
			String blOid = OidHelper.getOidAsString(baseline);
			pcs.setBaseline(blOid);

			String oid = OidHelper.getOidAsString(pbo);
			Locale locale = SessionHelper.getLocale();
			pcs.activateConfigSpec(oid, locale);

			pcs.setStructureType(1);
			pcs.activateStructureType();

			boolean forceRepublish = true;
			NavigationCriteria navigationCriteria = pcs.getEPMActiveNavigationCriteria(true, containerOid);
			NavigationCriteria partNavigationCriteria = pcs.getPartActiveNavigationCriteria(containerOid);
			boolean defaultRep = true;
			useRepName = pbo.getCADName();
			String useRepDescription = "Standard_CAD_Worker_representation";
			int structureType = pcs.getStructureType();
			PublishParams publishParams = null;
			boolean republish = false;

			PublishJob publishJob = new PublishJob(forceRepublish, pbo, navigationCriteria, partNavigationCriteria,
					defaultRep, useRepName, useRepDescription, structureType, publishParams, republish);
			publishJob.setRequestQueue(queueName);
			publishJob.setRequestQueuePriority("H");
			publishJob.setRequestQueueSet(STANDARD_QUEUE_SET);

			Class[] arg_types = { WVSProcessingJob.class };
			Object[] args = { publishJob };
			queue.addEntry(SessionHelper.manager.getAdministrator(), "doJob", "com.ptc.wvs.server.publish.PublishJob",
					arg_types, args);

			Timestamp date = new Timestamp(System.currentTimeMillis());
			SimpleDateFormat format = new SimpleDateFormat("dd-MM-yy HH:mm:ss");
			invokeDate = format.format(date);

			logger.info("Standard CAD worker publish job invoked for EPMDocument with number=" + pbo.getNumber()
					+ ". Entry added to queue:" + queueName);

		} catch (Exception e) {
			logger.log(Level.SEVERE, e.getMessage());
			LOGGER.error(EXCEPTION_MSG, e);
			return new String[] { "Error: " + e.getMessage(), null, null };
		}

		return new String[] { null, useRepName, invokeDate };
	}

	/**
	 * This method removes last DXF and HPGL sheet files from Release
	 * representation.
	 * 
	 * @param pbo
	 * @return
	 */
	public static String deleteLastPage(EPMDocument pbo, String repName) {
		LOGGER.debug("IN deleteLastPage...");

		if (!KBUtils.isDrawing(pbo)) {
			LOGGER.debug("\tOBJECT IS NOT DRAWING!");
			LOGGER.debug("OUT deleteLastPage...");
			return null;
		}

		try {

			String revision = (String) KBUtils.getMBAValue(pbo, "revision");
			LOGGER.debug("\trevision = " + revision);
			ManagedBaseline baseline = KBUtils.getCorrespondingBaseline(pbo, revision);

			if (baseline == null) {
				LOGGER.debug("\tbaseline = null");
				String msg = "No baseline for the Drawing; number=" + pbo.getNumber();
				logger.log(Level.SEVERE, msg);
				LOGGER.debug("OUT deleteLastPage...");
				return msg;
			}

			// if no "*stueli.frm" format no removing last page
			if (KBUtils.containsDrawingFormat(baseline) == false) {
				LOGGER.debug("\tNO stueli.frm!");
				LOGGER.debug("OUT deleteLastPage...");
				return null;
			}

			ReferenceFactory referenceFactory = new ReferenceFactory();
			WTSet representations = RepresentationHelper.service.getRepresentations(referenceFactory.getReference(pbo),
					repName);
			LOGGER.debug("\tLooking for representation with name = " + repName);

			// find Release CAD worker representation
			Representation releaseRep = null;
			for (Object object : representations) {
				releaseRep = (Representation) ((ObjectReference) object).getObject();
			}

			if (releaseRep == null) {
				LOGGER.debug("\tNo representation found!");
				String msg = "Representation from Release CAD worker not found.";
				logger.log(Level.SEVERE, msg);
				LOGGER.debug("OUT deleteLastPage...");
				return msg;
			}

			// get Release rep content (representation files)
			ContentItem ci = null;
			ApplicationData ap = null;

			releaseRep = (Representation) ContentHelper.service.getContents(releaseRep);
			Vector content = ContentHelper.getContentList(releaseRep);

			ApplicationData lastDxf = null;
			int lastDxfPageNo = 0;

			ApplicationData lastHpgl = null;
			int lastHpglPageNo = 0;

			// find last DXF and HPGL files
			for (int i = 0; i < content.size(); i++) {
				ci = (ContentItem) content.elementAt(i);
				if (ci instanceof ApplicationData) {
					ap = (ApplicationData) ci;

					// sample name for first sheet: drw0001_drw.dxf
					// template <drw name>_<drw extension>.dxf
					// sample name for sheet no > 1: drw0001_drw_2.dxf
					// template <drw name>_<drw extension>_<sheet no>.dxf
					if (ap.getFileName().toLowerCase().endsWith(DXF_EXTENSION)) {
						String[] nameParts = ap.getFileName().split("_");
						String lastNamePart = nameParts[nameParts.length - 1];
						String sheetNoString = lastNamePart.split("\\.")[0];
						int sheetNo = 0;
						try {
							sheetNo = Integer.parseInt(sheetNoString);
						} catch (NumberFormatException e) {
							// this is first sheet (ie. drw0001_drw.dxf)
							sheetNo = 1;
						}
						if (sheetNo > lastDxfPageNo) {
							lastDxfPageNo = sheetNo;
							lastDxf = ap;
						}
					}
					// sample name: drw0001_drw_1_x.hp2
					// template <drw name>_<drw extension>_<sheet no>_x_.hp2
					else if (ap.getFileName().toLowerCase().endsWith(HPGL_EXTENSION)) {
						String[] nameParts = ap.getFileName().split("_");
						int sheetNo = 0;
						try {
							String sheetNoString = nameParts[nameParts.length - 2];
							sheetNo = Integer.parseInt(sheetNoString);
						} catch (Exception e) {
							// catch NumberFormat and IndexOutOfBound Exceptions
							String msg = "Unknown file name format for HPGL file: " + ap.getFileName();
							logger.log(Level.SEVERE, msg);
							LOGGER.error(EXCEPTION_MSG, e);
							return msg;
						}
						if (sheetNo > lastHpglPageNo) {
							lastHpglPageNo = sheetNo;
							lastHpgl = ap;
						}
					}
				}
			}

			// if we have only one page or no pages return error msg
			if (lastDxfPageNo < 2 || lastHpglPageNo < 2) {
				String msg = "Only " + lastDxfPageNo + " " + DXF_EXTENSION + " and " + lastHpglPageNo + " "
						+ HPGL_EXTENSION + " files found befor removing last sheet files.";
				logger.log(Level.SEVERE, msg);
				return msg;
			}

			WTSet wtset = new WTHashSet();
			wtset.add(lastHpgl);
			wtset.add(lastDxf);

			LOGGER.debug("\tDELETING " + lastDxf.getFileName() + " and " + lastHpgl.getFileName());
			ContentServerHelper.service.deleteContent(releaseRep, lastHpgl);
			ContentServerHelper.service.deleteContent(releaseRep, lastDxf);

			logger.info("Files: " + lastDxf.getFileName() + " and " + lastHpgl.getFileName()
					+ " from Release CAD worker representation with name=" + repName
					+ " deleted for EPMDocument with number=" + pbo.getNumber());

		} catch (Exception e) {
			logger.log(Level.SEVERE, e.getMessage());
			LOGGER.error(EXCEPTION_MSG, e);
			return "Error: " + e.getMessage();
		}

		LOGGER.debug("OUT deleteLastPage...");
		return null;
	}

	public static String transferDxfToCadim(EPMDocument pbo, String releaseByEmail) {

		if (SKIP_CADIM) {
			logger.info("Sending files to CADIM skipped.");
			return null;
		}

		if (releaseByEmail == null || releaseByEmail.isEmpty()) {
			String msg = "E-Mail of user who set state to Release Pending is empty.";
			logger.log(Level.SEVERE, msg);
			return msg;
		}

		List<String> txtFullFilesToTransferNames = new LinkedList<String>();
		List<String> dxfFullFilesToTransferNames = new LinkedList<String>();

		String pboCadNameWithoutExtension = pbo.getCADName().substring(0, pbo.getCADName().lastIndexOf("."));

		// create transfer folder root is not exist
		String transferFolderPathDxf = TRANSFER_TEMP_DIR_PATH_DXF;
		File transferFolderFileDxf = new File(transferFolderPathDxf);
		transferFolderFileDxf.mkdir();

		Representation releaseRep = null;
		ApplicationData dxfAppData = null;

		try {
			// get release rep
			VisualizationHelper visualizationHelper = new VisualizationHelper();
			Representation representation = visualizationHelper.getRepresentation(pbo);

			ContentItem ci = null;
			ApplicationData ap = null;

			// get Release rep content (representation files)
			if (representation != null)
				releaseRep = (Representation) ContentHelper.service.getContents(representation);
			Vector content = new Vector();
			if (releaseRep != null)
				content = ContentHelper.getContentList(releaseRep);

			// find dxf files
			logger.info("content size ---> transferDxfToCadim." + content.size());
			for (int i = 0; i < content.size(); i++) {
				ci = (ContentItem) content.elementAt(i);
				if (ci instanceof ApplicationData) {
					ap = (ApplicationData) ci;
					logger.info("ApplicationData dxf files ---> transferDxfToCadim." + ap);
					logger.info("ApplicationData dxf files ---> transferDxfToCadim." + ap.getFileName().toLowerCase());
					if (ap.getFileName().toLowerCase().endsWith(DXF_EXTENSION)
							|| ap.getFileName().toLowerCase().endsWith(ZIP_EXTENSION)) {
						dxfAppData = ap;
					}
				}
			}

			if (dxfAppData == null) {
				String msg = "No DXF files found.";
				logger.log(Level.SEVERE, msg);
				return msg;
			}

			// prepare LWC object to load IBAs values
			PersistableAdapter obj = new PersistableAdapter(pbo, null, null, null);
			obj.load("KB_DRW_NUM", "KB_LANGUAGE");

			// ZEICHNUNGSNUMMER
			String drwNo = (String) obj.get("KB_DRW_NUM");

			// PROI_REVISION
			String revision = (String) KBUtils.getMBAValue(pbo, "revision");

			// FREMDSPRACHE
			String language = (String) obj.get("KB_LANGUAGE");

			// USERNAME
			String userName = "PLOTENGINE";

			// MAIL_TO
			String mailTo = releaseByEmail;

			// get sheet no
			Vector<File> filesVector = new Vector<File>();
			if (dxfAppData.getFileName().toLowerCase().endsWith(ZIP_EXTENSION)) {
				filesVector = unZipFile(ContentServerHelper.service.getStoredItemFile(dxfAppData).getPhysicalFile(),		
						TRANSFER_TEMP_DIR_PATH_DXF);
				logger.info("ZIP EXTENSION");
			} else if (dxfAppData.getFileName().toLowerCase().endsWith(DXF_EXTENSION)) {

				String dxfAndTxtFileName = pboCadNameWithoutExtension + "_1";

				String dxfFileName = dxfAndTxtFileName + KB_AdvReleasePendingProcessHelper.DXF_EXTENSION;
				File dxfFileToTransfer = new File(transferFolderPathDxf + File.separator + dxfFileName);
				dxfFileToTransfer.createNewFile();
				saveAppDataToFile(dxfAppData, dxfFileToTransfer);
				filesVector.add(dxfFileToTransfer);
				logger.info("DXF EXTENSION");
			}
			for (File file : filesVector) {

				String[] nameParts = file.getName().split("_");
				String lastNamePart = nameParts[nameParts.length - 1];
				String sheetNoString = lastNamePart.split("\\.")[0];
				logger.info("nameParts : " + nameParts + ", lastNamePart : " + lastNamePart + ", sheetNoString : "
						+ sheetNoString);
				int sheetNo = 0;
				try {
					sheetNo = Integer.parseInt(sheetNoString);
				} catch (NumberFormatException e) {
					// this is first sheet (ie. drw0001_drw.dxf)
					sheetNo = 1;
				}

				// file name without extension for dxf and txt files
				logger.info("----->>> file name without extension for dxf and txt files");
				String dxfAndTxtFileName = pboCadNameWithoutExtension + "_" + sheetNo;

				// dxf file name to transfer name
				logger.info("----->>> dxf file name to transfer name");
				String dxfFileName = dxfAndTxtFileName + KB_AdvReleasePendingProcessHelper.DXF_EXTENSION;
				String dxfFeedbackFileName = dxfAndTxtFileName + KB_AdvReleasePendingProcessHelper.FEEDBACK_EXTENSION;

				// create dxf file to transfer
				logger.info("----->>> create dxf file to transfer");

				// prepare txt file content
				logger.info("----->>> prepare txt file content");
				// these attributes are different for each sheet

				// PAGE_NUM
				String pageNo = Integer.toString(sheetNo);

				// DXFFILE
				String dxfFile = dxfFileName;

				// prepare txt files content
				StringBuilder builder = new StringBuilder();
				builder.append(drwNo);
				builder.append("#");
				builder.append(revision);
				builder.append("#");
				builder.append(language);
				builder.append("#");
				builder.append(pageNo);
				builder.append("#");
				builder.append(dxfFile);
				builder.append("#");
				builder.append(userName);
				builder.append("#");
				builder.append(mailTo);
				builder.append("#");
				builder.append(dxfFeedbackFileName);

				// txt file name
				String txtFileName = dxfAndTxtFileName + ".txt";

				// create text file
				logger.info("----->>> create text file");
				FileWriter fileWriter = null;
				BufferedWriter bufferedWriter = null;
				try {
					File txtFile = new File(transferFolderPathDxf + File.separator + txtFileName);
					txtFile.createNewFile();
					fileWriter = new FileWriter(txtFile);
					bufferedWriter = new BufferedWriter(fileWriter);
					bufferedWriter.write(builder.toString());
				} finally {
					bufferedWriter.close();
					fileWriter.close();
				}

				// execute *txt transfer command
				logger.info("----->>> execute *txt transfer command");
				String pathToFileTxt = transferFolderPathDxf + File.separator + txtFileName;
				txtFullFilesToTransferNames.add(pathToFileTxt);

				// execute *dxf transfer command
				logger.info("----->>> execute *dfx transfer command");
				String pathToFileDxf = transferFolderPathDxf + File.separator + dxfFileName;
				dxfFullFilesToTransferNames.add(pathToFileDxf);

				logger.info("Files .txt and DXF with base name =" + pboCadNameWithoutExtension
						+ " created succesfully in directory: " + TRANSFER_TEMP_DIR_PATH_DXF);
				logger.info(
						"Transferring files .txt and DXF with base name =" + pboCadNameWithoutExtension + " started");

			}
			if (dxfFullFilesToTransferNames.size() != txtFullFilesToTransferNames.size()) {
				String msg = "Created " + dxfFullFilesToTransferNames.size() + " DXF files and "
						+ txtFullFilesToTransferNames.size() + " .txt files. Count of files should be the same.";
				logger.log(Level.SEVERE, msg);
				return msg;
			}

			for (int i = 0; i < dxfFullFilesToTransferNames.size(); i++) {

				String pathToFileTxt = txtFullFilesToTransferNames.get(i);
				String pathToFileDxf = dxfFullFilesToTransferNames.get(i);
			}

			logger.info("Transferring files .txt and DXF with base name =" + pboCadNameWithoutExtension + " succeed.");

		} catch (Exception e) {
			logger.log(Level.SEVERE, e.getMessage());
			LOGGER.error(EXCEPTION_MSG, e);
			return "Error: " + e.getMessage();
		}
		return null;
	}

	public static String transferPdfToCadim(EPMDocument pbo, String releaseByEmail) {

		if (SKIP_CADIM) {
			logger.info("Sending files to CADIM skipped.");
			return null;
		}

		if (releaseByEmail == null || releaseByEmail.isEmpty()) {
			String msg = "E-Mail of user who set state to Release Pending is empty.";
			logger.log(Level.SEVERE, msg);
			return msg;
		}

		String pboCadNameWithoutExtension = pbo.getCADName().substring(0, pbo.getCADName().lastIndexOf("."));

		String transferFolderPathPdf = TRANSFER_TEMP_DIR_PATH_PDF;
		File transferFolderFilePdf = new File(transferFolderPathPdf);
		transferFolderFilePdf.mkdir();

		Representation releaseRep = null;
		ApplicationData pdfAppData = null;

		try {
			VisualizationHelper visualizationHelper = new VisualizationHelper();
			Representation representation = visualizationHelper.getRepresentation(pbo);

			ContentItem ci = null;
			ApplicationData ap = null;

			// get Release rep content (representation files)
			if (representation != null)
				releaseRep = (Representation) ContentHelper.service.getContents(representation);
			Vector content = new Vector();
			if (releaseRep != null)
				content = ContentHelper.getContentList(releaseRep);

			// find pdf file
			logger.info("Rozmiar contentu pdf files ---> transferPdfToCadim." + content.size());
			for (int i = 0; i < content.size(); i++) {
				ci = (ContentItem) content.elementAt(i);
				if (ci instanceof ApplicationData) {
					ap = (ApplicationData) ci;
					logger.info("ApplicationData pdf files ---> transferPdfToCadim." + ap);
					logger.info("ApplicationData pdf files ---> transferPdfToCadim." + ap.getFileName().toLowerCase());
					logger.info(
							"ApplicationData pdf files ---> transferPdfToCadim ---- > PDFEXTENTION:" + PDF_EXTENSION);
					if (ap.getFileName().toLowerCase().endsWith(PDF_EXTENSION)) {
						pdfAppData = ap;
					}
				}
			}

			if (pdfAppData == null) {
				String msg = "No PDF files found.";
				logger.log(Level.SEVERE, msg);
				return msg;
			}

			PersistableAdapter obj = new PersistableAdapter(pbo, null, null, null);
			obj.load("KB_DRW_NUM", "KB_LANGUAGE");

			// ZEICHNUNGSNUMMER
			String drwNo = (String) obj.get("KB_DRW_NUM");

			// PROI_REVISION
			String revision = (String) KBUtils.getMBAValue(pbo, "revision");

			// FREMDSPRACHE
			String language = (String) obj.get("KB_LANGUAGE");

			// USERNAME
			String userName = "PLOTENGINE";

			// MAIL_TO
			String mailTo = releaseByEmail;

			int sheetNo = 1;

			// file name without extension for dxf and txt files
			String pdfAndTxtFileName = pboCadNameWithoutExtension + "_" + sheetNo;

			// pdf file name to transfer name
			String pdfFileName = pdfAndTxtFileName + KB_AdvReleasePendingProcessHelper.PDF_EXTENSION;
			String pdfFeedbackFileName = pdfAndTxtFileName + KB_AdvReleasePendingProcessHelper.FEEDBACK_EXTENSION;
			logger.info("pdfFileName ---> transferPdfToCadim." + pdfFileName);

			// create pdf file to transfer
			File pdfFileToTransfer = new File(transferFolderPathPdf + File.separator + pdfFileName);
			logger.info("pdfFileToTransfer ---> transferPdfToCadim." + pdfFileToTransfer);
			pdfFileToTransfer.createNewFile();
			saveAppDataToFile(pdfAppData, pdfFileToTransfer);

			// prepare txt file content
			// these attributes are different for each sheet

			// PAGE_NUM
			String pageNo = Integer.toString(sheetNo);

			// PDFFILE
			String pdfFile = pdfFileName;

			// prepare txt files content
			StringBuilder builder = new StringBuilder();
			builder.append(drwNo);
			builder.append("#");
			builder.append(revision);
			builder.append("#");
			builder.append(language);
			builder.append("#");
			builder.append(pageNo);
			builder.append("#");
			builder.append(pdfFile);
			builder.append("#");
			builder.append(userName);
			builder.append("#");
			builder.append(mailTo);
			builder.append("#");
			builder.append(pdfFeedbackFileName);

			// txt file name
			String txtFileName = pdfAndTxtFileName + ".txt";

			// create text file
			FileWriter fileWriter = null;
			BufferedWriter bufferedWriter = null;
			try {
				File txtFile = new File(transferFolderPathPdf + File.separator + txtFileName);
				txtFile.createNewFile();
				fileWriter = new FileWriter(txtFile);
				bufferedWriter = new BufferedWriter(fileWriter);
				bufferedWriter.write(builder.toString());
			} finally {
				bufferedWriter.close();
				fileWriter.close();
			}

			// execute *txt transfer command
			String pathToFileTxt = transferFolderPathPdf + File.separator + txtFileName;

			// execute *pdf transfer command
			String pathToFilePdf = transferFolderPathPdf + File.separator + pdfFileName;

			logger.info("Files .txt and PDF with base name =" + pboCadNameWithoutExtension
					+ " created succesfully in directory: " + TRANSFER_TEMP_DIR_PATH_PDF);
			logger.info("Transferring files .txt and PDF with base name =" + pboCadNameWithoutExtension + " started");

		} catch (

		Exception e) {
			logger.log(Level.SEVERE, e.getMessage());
			LOGGER.error(EXCEPTION_MSG, e);
			return "Error: " + e.getMessage();
		}
		return null;
	}

	public static String transferDfxPdfToCadim(WTChangeActivity2 changeItem) throws WTException {
		String releaseByEmail = "test@Knorr-Bremse.com";
		if (changeItem instanceof ChangeActivityIfc) {
			ChangeActivityIfc changeNotice = (ChangeActivityIfc) changeItem;

			QueryResult resulting = ChangeHelper2.service.getChangeablesAfter(changeNotice);

			while (resulting.hasMoreElements()) {

				Object o = resulting.nextElement();

				if (o instanceof EPMDocument) {
					EPMDocument doc = (EPMDocument) o;
					if (!isPhantomTrue(doc)) {
						sDfx = transferDxfToCadim(doc, releaseByEmail);
						String sPdf = transferPdfToCadim(doc, releaseByEmail);
					}
				}
			}
		}
		return null;
	}

	public static boolean skipTransferToCadim(Persistable changeItem) throws WTException {
		boolean skipTransfer = false;
		String containerName = AttributeService.getAttribute(changeItem, "containerName");
		if (standardWorkerProductsSet != null && standardWorkerProductsSet.contains(containerName)) {
			skipTransfer = true;
		}
		logger.info("skipTransferToCadim: " + skipTransfer);
		return skipTransfer;
	}

	public static String checkTransfer(WTChangeActivity2 changeItem) throws WTException {
		String feedbackMsg = "";
		if (changeItem instanceof ChangeActivityIfc) {
			ChangeActivityIfc changeNotice = (ChangeActivityIfc) changeItem;

			QueryResult resulting = ChangeHelper2.service.getChangeablesAfter(changeNotice);

			while (resulting.hasMoreElements()) {

				Object o = resulting.nextElement();
				String pdfTransferFeedback = "";
				String dxfTransferFeedback = "";

				if (o instanceof EPMDocument) {
					EPMDocument doc = (EPMDocument) o;
					if (!isPhantomTrue(doc) && KBTypeIdProvider.isDescendant(doc, "KBCADDRW")) {
						pdfTransferFeedback = checkPDFTransfer(doc);
						dxfTransferFeedback = checkDXFTransfer(doc);

						if ("WAIT".equals(pdfTransferFeedback) || "WAIT".equals(dxfTransferFeedback)) {
							return "WAIT";
						} else if ("GO".equals(pdfTransferFeedback) && "GO".equals(dxfTransferFeedback)) {
							continue;
						}
						if (!"WAIT".equals(pdfTransferFeedback) && !"GO".equals(pdfTransferFeedback)) {
							feedbackMsg += pdfTransferFeedback + "\n";
						}
						if (!"WAIT".equals(dxfTransferFeedback) && !"GO".equals(dxfTransferFeedback)) {
							feedbackMsg += dxfTransferFeedback + "\n";
						}
					}
				}
			}
		}
		if (feedbackMsg.isEmpty()) {
			logger.info("returning checkTransfer feedbackMSG : " + feedbackMsg);
			return "GO";
		}
		logger.info("checkTransfer feedbackMSG : " + feedbackMsg);
		return feedbackMsg;
	}

	public static String deleteFeedbackFiles(WTChangeActivity2 changeItem) throws WTException {
		String feedbackMsg = "";
		if (changeItem instanceof ChangeActivityIfc) {
			ChangeActivityIfc changeNotice = (ChangeActivityIfc) changeItem;

			QueryResult resulting = ChangeHelper2.service.getChangeablesAfter(changeNotice);

			while (resulting.hasMoreElements()) {

				Object o = resulting.nextElement();
				String pdfTransferFeedback = "";
				String dxfTransferFeedback = "";

				if (o instanceof EPMDocument) {
					EPMDocument doc = (EPMDocument) o;
					if (!isPhantomTrue(doc) && KBTypeIdProvider.isDescendant(doc, "KBCADDRW")) {
						deleteDXFfeedbackFiles(doc);
						deletePDFfeedbackFiles(doc);
					}
				}
			}
		}
		if (feedbackMsg.isEmpty()) {
			logger.info("returning checkTransfer feedbackMSG : " + feedbackMsg);
			return "GO";
		}
		logger.info("checkTransfer feedbackMSG : " + feedbackMsg);
		return feedbackMsg;
	}

	/**
	 * Execute given command as system process and log results.
	 * 
	 * @param command
	 * @throws Exception
	 */
	private static void executeProcess(String command) throws Exception {
		StringBuilder processInput = new StringBuilder();
		executeProcess(command, processInput);
	}

	/**
	 * Execute given command as system process and log results. Command should
	 * not start with quote. Parameters value can be in quote.
	 * 
	 * @param command
	 * @param processInput
	 * @throws Exception
	 */
	private static void executeProcess(String command, StringBuilder processInput) throws Exception {

		logger.info("Command to run:" + command);

		if (command == null || command.isEmpty()) {
			logger.info("Given command is empty. Nothing to do.");
			return;
		}

		BufferedReader bufferedErrorStreamReader = null;
		BufferedReader bufferedInputStreamReader = null;
		BufferedReader bufferedOutputStreamReader = null;

		try {
			// if command contain quote character it must be passed as String
			// array. Elements in quotes are single param.
			String[] commandParts = command.split("\"");

			List<String> commandPartsList = new LinkedList<String>();
			for (int index = 0; index < commandParts.length; index++) {
				String commandPart = commandParts[index];
				commandPart = commandPart.trim();

				if (index % 2 == 0) {
					String[] splitedCommandPart = commandPart.split(" ");
					for (String part : splitedCommandPart) {
						part = part.trim();
						commandPartsList.add(part);
					}
				} else {
					commandPartsList.add(commandPart);
				}
			}

			String[] commandInParts = new String[commandPartsList.size()];
			commandPartsList.toArray(commandInParts);

			logger.info("Given command splitted to " + commandInParts.length + " parts.");
			logger.info("Command in parts to execute: " + commandPartsList);

			final Process process = Runtime.getRuntime().exec(commandInParts);
			int returnCode = process.waitFor();

			// get and log error stream
			StringBuilder processErrorsOutput = new StringBuilder();
			bufferedErrorStreamReader = new BufferedReader(new InputStreamReader(process.getErrorStream()));
			String line;
			while ((line = bufferedErrorStreamReader.readLine()) != null) {
				processErrorsOutput.append("\n");
				processErrorsOutput.append(line);
			}
			logger.info("Process errors output:" + processErrorsOutput.toString());

			// get and log input stream
			bufferedInputStreamReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
			while ((line = bufferedInputStreamReader.readLine()) != null) {
				processInput.append("\n");
				processInput.append(line);
			}
			logger.info("Process input:" + processInput.toString());

			// get and log output stream
			StringBuilder processOutput = new StringBuilder();
			bufferedOutputStreamReader = new BufferedReader(new InputStreamReader(process.getInputStream()));
			while ((line = bufferedOutputStreamReader.readLine()) != null) {
				processOutput.append("\n");
				processOutput.append(line);
			}
			logger.info("Process output:" + processOutput.toString());

			if (returnCode == 0) {
				logger.info("Command: \"" + command + "\" finished with return code 0 - succeed.");
			} else {
				String msg = "Command: \"" + command + "\" finished with return code " + returnCode
						+ "  - error. Check logs. \nErrors output: " + processErrorsOutput.toString();
				logger.log(Level.SEVERE, msg);
				throw new Exception(msg);
			}

		} finally {
			if (bufferedErrorStreamReader != null) {
				bufferedErrorStreamReader.close();
			}
			if (bufferedInputStreamReader != null) {
				bufferedInputStreamReader.close();
			}
			if (bufferedOutputStreamReader != null) {
				bufferedOutputStreamReader.close();
			}
		}
	}

	/**
	 * Saves ApplicationData file to given file in files system.
	 * 
	 * @param applicationData
	 * @param file
	 * @throws IOException
	 */
	private static void saveAppDataToFile(ApplicationData applicationData, File file) throws IOException {

		InputStream is = FileHelper.getEdFileStream(applicationData);
		BufferedOutputStream fOut = null;
		try {
			fOut = new BufferedOutputStream(new FileOutputStream(file));
			byte[] buffer = new byte[32 * 1024];
			int bytesRead = 0;
			while ((bytesRead = is.read(buffer)) != -1) {
				fOut.write(buffer, 0, bytesRead);
			}
		} finally {
			try {
				if (is != null) {
					is.close();
				}
			} finally {
				if (fOut != null) {
					fOut.close();
				}
			}
		}
	}

	/**
	 * The rollback robot has to remove the IBA values for KB_RELEASED_BY,
	 * KB_RELEASED_DATE and delete created representation.
	 * 
	 * @return error msg
	 */
	public static String rollback(EPMDocument pbo, String repName) {

		try {

			IBAHelper.updateIBAAttributeValueWithoutCheckout(pbo, KBConstants.KB_RELEASED_BY_IBA, "");
			logger.info("Value of IBA " + KBConstants.KB_RELEASED_BY_IBA + " for EPMDocument with number="
					+ pbo.getNumber() + " removed");

			IBAHelper.updateIBAAttributeValueWithoutCheckout(pbo, KBConstants.KB_RELEASED_DATE_IBA, "");
			logger.info("Value of IBA " + KBConstants.KB_RELEASED_DATE_IBA + " for EPMDocument with number="
					+ pbo.getNumber() + " removed");

			if (repName != null) {
				// removing representation
				ReferenceFactory referenceFactory = new ReferenceFactory();
				WTSet reps = RepresentationHelper.service.getRepresentations(referenceFactory.getReference(pbo),
						repName);
				for (Object object : reps) {
					Representation releaseRep = (Representation) ((ObjectReference) object).getObject();
					RepresentationHelper.service.deleteRepresentation(releaseRep, true);
					logger.info("Release CAD worker representation with name=" + repName
							+ " deleted for EPMDocument with number=" + pbo.getNumber());
				}
			}

			// set state of DRW to Approved
			LifeCycleHelper.service.setLifeCycleState(pbo, State.toState(KBConstants.APPROVALPENDING_STATE));

		} catch (Exception e) {
			logger.log(Level.SEVERE, e.getMessage());
			LOGGER.error(EXCEPTION_MSG, e);
			return "Error: " + e.getMessage();
		}

		return null;
	}

	/**
	 * Check if representation with given name for given EPM exists.
	 * 
	 * @param pbo
	 * @param repName
	 * @return true if exists, false otherwise
	 */
	public static boolean isRepresentationReady(EPMDocument pbo, String repName) {

		ReferenceFactory referenceFactory = new ReferenceFactory();
		WTSet representations;
		try {
			representations = RepresentationHelper.service.getRepresentations(referenceFactory.getReference(pbo),
					repName);
		} catch (WTException e) {
			logger.log(Level.SEVERE, e.getMessage());
			LOGGER.error(EXCEPTION_MSG, e);
			return false;
		}

		if (representations.size() > 0) {
			logger.info("Representation with name " + repName + " from Release CAD worker found.");
			return true;

		}

		logger.info("Representation with name " + repName + " from Release CAD worker not found.");
		return false;
	}

	/**
	 * Returns value of max wait iteration loaded from property
	 * ext.workflow.maxwaititeration.
	 * 
	 * @return
	 */
	public static int getMaxWaitIteration() {
		return MAX_WAIT_ITERATION;
	}

	public static String checkDXFTransfer(EPMDocument pbo) {

		if (SKIP_CADIM) {
			logger.info("checkDXFTransfer feedbackMSG : " + "GO");
			return "GO";
		}

		String feedbackMsg = "";
		String pboCadNameWithoutExtension = pbo.getCADName().substring(0, pbo.getCADName().lastIndexOf("."));

		// create transfer folder root is not exist
		String transferFolderPathDxf = TRANSFER_TEMP_DIR_PATH_DXF;

		Representation releaseRep = null;
		ApplicationData dxfAppData = null;

		try {
			// get release rep
			VisualizationHelper visualizationHelper = new VisualizationHelper();
			Representation representation = visualizationHelper.getRepresentation(pbo);

			ContentItem ci = null;
			ApplicationData ap = null;

			// get Release rep content (representation files)
			if (representation != null)
				releaseRep = (Representation) ContentHelper.service.getContents(representation);
			Vector content = new Vector();
			if (releaseRep != null)
				content = ContentHelper.getContentList(releaseRep);

			// find dxf files
			logger.info("content size ---> transferDxfToCadim." + content.size());
			for (int i = 0; i < content.size(); i++) {
				ci = (ContentItem) content.elementAt(i);
				if (ci instanceof ApplicationData) {
					ap = (ApplicationData) ci;
					logger.info("ApplicationData dxf files ---> transferDxfToCadim." + ap);
					logger.info("ApplicationData dxf files ---> transferDxfToCadim." + ap.getFileName().toLowerCase());
					if (ap.getFileName().toLowerCase().endsWith(DXF_EXTENSION)
							|| ap.getFileName().toLowerCase().endsWith(ZIP_EXTENSION)) {
						dxfAppData = ap;
					}
				}
			}

			if (dxfAppData == null) {
				logger.info("checkDXFTransfer feedbackMSG : " + "GO");
				return "GO";
			}

			Vector<File> filesVector = new Vector<File>();
			if (dxfAppData.getFileName().toLowerCase().endsWith(ZIP_EXTENSION)) {
				filesVector = getZipFiles(ContentServerHelper.service.getStoredItemFile(dxfAppData).getPhysicalFile());
				logger.info("ZIP EXTENSION");
			} else if (dxfAppData.getFileName().toLowerCase().endsWith(DXF_EXTENSION)) {
				String dxfAndTxtFileName = pboCadNameWithoutExtension + "_1";
				String dxfFileName = dxfAndTxtFileName + KB_AdvReleasePendingProcessHelper.DXF_EXTENSION;
				File dxfFileToTransfer = new File(transferFolderPathDxf + File.separator + dxfFileName);
				dxfFileToTransfer.createNewFile();
				filesVector.add(dxfFileToTransfer);
				logger.info("DXF EXTENSION");
			}
			for (File file : filesVector) {

				String[] nameParts = file.getName().split("_");
				String lastNamePart = nameParts[nameParts.length - 1];
				String sheetNoString = lastNamePart.split("\\.")[0];
				int sheetNo = 0;
				try {
					sheetNo = Integer.parseInt(sheetNoString);
				} catch (NumberFormatException e) {
					// this is first sheet (ie. drw0001_drw.dxf)
					sheetNo = 1;
				}
				// file name without extension for dxf and txt files
				logger.info("----->>> file name without extension for dxf and txt files");
				String dxfAndTxtFileName = pboCadNameWithoutExtension + "_" + sheetNo;
				String dxfFeedbackFileName = dxfAndTxtFileName + KB_AdvReleasePendingProcessHelper.FEEDBACK_EXTENSION;
				logger.info("dxfAndTxtFileName : " + dxfAndTxtFileName);
				logger.info("dxfFeedbackFileName : " + dxfFeedbackFileName);
				FileReader fileReader = null;
				BufferedReader bufferedReader = null;
				File feedbackFileName = null;
				try {
					feedbackFileName = new File(transferFolderPathDxf + File.separator + dxfFeedbackFileName);
					logger.info("Checking if feedback file : " + transferFolderPathDxf + File.separator
							+ dxfFeedbackFileName + " exists");
					if (!feedbackFileName.exists()) {
						logger.info("Feedback file does not exist - result - WAIT");
						return "WAIT";
					}
					logger.info("Reading file : " + feedbackFileName);
					fileReader = new FileReader(feedbackFileName);
					bufferedReader = new BufferedReader(fileReader);

					String line = "";
					String temp = "";
					while ((line = bufferedReader.readLine()) != null) {
						logger.info(line);
						temp += line;

					}
					if (temp.isEmpty()) {
						logger.info("Feedback message is empty !");
						continue;
					}
					if (!temp.isEmpty()) {
						feedbackMsg += temp + "\n";
					}
				} finally {
					if (bufferedReader != null) {
						bufferedReader.close();
					}
					if (fileReader != null) {
						fileReader.close();
					}
				}
			}
		} catch (Exception e) {
			logger.log(Level.SEVERE, e.getMessage());
			LOGGER.error(EXCEPTION_MSG, e);
			return "Error: " + e.getMessage();
		}
		if (feedbackMsg.isEmpty()) {
			logger.info("checkDXFTransfer feedbackMSG : " + "GO");
			return "GO";
		}
		logger.info("checkDXFTransfer feedbackMSG : " + feedbackMsg);
		return feedbackMsg;
	}

	public static void deleteDXFfeedbackFiles(EPMDocument pbo) {

		if (SKIP_CADIM) {
			logger.info("There is no feedback files (DXF transfer) to delete");
			return;
		}

		String pboCadNameWithoutExtension = pbo.getCADName().substring(0, pbo.getCADName().lastIndexOf("."));

		// create transfer folder root is not exist
		String transferFolderPathDxf = TRANSFER_TEMP_DIR_PATH_DXF;

		Representation releaseRep = null;
		ApplicationData dxfAppData = null;

		try {
			// get release rep
			VisualizationHelper visualizationHelper = new VisualizationHelper();
			Representation representation = visualizationHelper.getRepresentation(pbo);

			ContentItem ci = null;
			ApplicationData ap = null;

			// get Release rep content (representation files)
			if (representation != null)
				releaseRep = (Representation) ContentHelper.service.getContents(representation);
			Vector content = new Vector();
			if (releaseRep != null)
				content = ContentHelper.getContentList(releaseRep);

			// find dxf files
			logger.info("content size ---> transferDxfToCadim." + content.size());
			for (int i = 0; i < content.size(); i++) {
				ci = (ContentItem) content.elementAt(i);
				if (ci instanceof ApplicationData) {
					ap = (ApplicationData) ci;
					logger.info("ApplicationData dxf files ---> transferDxfToCadim." + ap);
					logger.info("ApplicationData dxf files ---> transferDxfToCadim." + ap.getFileName().toLowerCase());
					if (ap.getFileName().toLowerCase().endsWith(DXF_EXTENSION)
							|| ap.getFileName().toLowerCase().endsWith(ZIP_EXTENSION)) {
						dxfAppData = ap;
					}
				}
			}
			if (dxfAppData == null) {
				logger.info("There is no feedback files (DXF transfer) to delete");
				return;
			}
			Vector<File> filesVector = new Vector<File>();
			if (dxfAppData.getFileName().toLowerCase().endsWith(ZIP_EXTENSION)) {
				filesVector = getZipFiles(ContentServerHelper.service.getStoredItemFile(dxfAppData).getPhysicalFile());
				logger.info("ZIP EXTENSION");
			} else if (dxfAppData.getFileName().toLowerCase().endsWith(DXF_EXTENSION)) {
				String dxfAndTxtFileName = pboCadNameWithoutExtension + "_1";
				String dxfFileName = dxfAndTxtFileName + KB_AdvReleasePendingProcessHelper.DXF_EXTENSION;
				File dxfFileToTransfer = new File(transferFolderPathDxf + File.separator + dxfFileName);
				dxfFileToTransfer.createNewFile();
				filesVector.add(dxfFileToTransfer);
				logger.info("ZIP EXTENSION");
			}
			for (File file : filesVector) {

				// get sheet no
				String[] nameParts = file.getName().split("_");
				String lastNamePart = nameParts[nameParts.length - 1];
				String sheetNoString = lastNamePart.split("\\.")[0];
				int sheetNo = 0;
				try {
					sheetNo = Integer.parseInt(sheetNoString);
				} catch (NumberFormatException e) {
					// this is first sheet (ie. drw0001_drw.dxf)
					sheetNo = 1;
				}
				// file name without extension for dxf and txt files
				logger.info("----->>> file name without extension for dxf and txt files");
				String dxfAndTxtFileName = pboCadNameWithoutExtension + "_" + sheetNo;
				String dxfFeedbackFileName = dxfAndTxtFileName + KB_AdvReleasePendingProcessHelper.FEEDBACK_EXTENSION;
				logger.info("dxfAndTxtFileName : " + dxfAndTxtFileName);
				logger.info("dxfFeedbackFileName : " + dxfFeedbackFileName);
				FileReader fileReader = null;
				BufferedReader bufferedReader = null;
				File feedbackFileName = null;
				try {
					feedbackFileName = new File(transferFolderPathDxf + File.separator + dxfFeedbackFileName);
					logger.info("Checking if feedback file : " + transferFolderPathDxf + File.separator
							+ dxfFeedbackFileName + " exists");
					if (!feedbackFileName.exists()) {
						logger.info("Feedback file does not exist");
						continue;
					} else {
						feedbackFileName.delete();
						logger.info(dxfFeedbackFileName + " - removed");
					}
				} finally {
					if (bufferedReader != null) {
						bufferedReader.close();
					}
					if (fileReader != null) {
						fileReader.close();
					}
				}
			}
		} catch (Exception e) {
			logger.log(Level.SEVERE, e.getMessage());
			LOGGER.error(EXCEPTION_MSG, e);
		}
	}

	public static String checkPDFTransfer(EPMDocument pbo) {

		if (SKIP_CADIM) {
			logger.info("checkPDFTransfer feedbackMSG : " + "GO");
			return "GO";
		}
		String feedbackMsg = "";

		String pboCadNameWithoutExtension = pbo.getCADName().substring(0, pbo.getCADName().lastIndexOf("."));
		String transferFolderPathPdf = TRANSFER_TEMP_DIR_PATH_PDF;

		Representation releaseRep = null;
		ApplicationData pdfAppData = null;

		try {
			VisualizationHelper visualizationHelper = new VisualizationHelper();
			Representation representation = visualizationHelper.getRepresentation(pbo);

			ContentItem ci = null;
			ApplicationData ap = null;

			// get Release rep content (representation files)
			if (representation != null)
				releaseRep = (Representation) ContentHelper.service.getContents(representation);
			Vector content = new Vector();
			if (releaseRep != null)
				content = ContentHelper.getContentList(releaseRep);

			// find pdf file
			logger.info("Rozmiar contentu pdf files ---> transferPdfToCadim." + content.size());
			for (int i = 0; i < content.size(); i++) {
				ci = (ContentItem) content.elementAt(i);
				if (ci instanceof ApplicationData) {
					ap = (ApplicationData) ci;
					logger.info("ApplicationData pdf files ---> transferPdfToCadim." + ap);
					logger.info("ApplicationData pdf files ---> transferPdfToCadim." + ap.getFileName().toLowerCase());
					logger.info(
							"ApplicationData pdf files ---> transferPdfToCadim ---- > PDFEXTENTION:" + PDF_EXTENSION);
					if (ap.getFileName().toLowerCase().endsWith(PDF_EXTENSION)) {
						pdfAppData = ap;
					}
				}
			}

			if (pdfAppData == null) {
				logger.info("checkPDFTransfer feedbackMSG : " + "GO");
				return "GO";
			}

			logger.info("pdfApplicationData ---> transferPdfToCadim." + pdfAppData);
			ApplicationData pdfApplicationData = pdfAppData;

			// get sheet no
			String[] nameParts = pdfApplicationData.getFileName().split("_");
			String lastNamePart = nameParts[nameParts.length - 1];
			String sheetNoString = lastNamePart.split("\\.")[0];
			int sheetNo = 0;
			try {
				sheetNo = Integer.parseInt(sheetNoString);
			} catch (NumberFormatException e) {
				// this is first sheet (ie. drw0001_drw.pdf)
				sheetNo = 1;
			}

			// file name without extension for dxf and txt files
			String pdfAndTxtFileName = pboCadNameWithoutExtension + "_" + sheetNo;
			String pdfFeedbackFileName = pdfAndTxtFileName + KB_AdvReleasePendingProcessHelper.FEEDBACK_EXTENSION;
			logger.info("pdfAndTxtFileName : " + pdfAndTxtFileName);
			logger.info("pdfFeedbackFileName : " + pdfFeedbackFileName);
			FileReader fileReader = null;
			BufferedReader bufferedReader = null;
			File feedbackFileName = null;
			try {
				feedbackFileName = new File(transferFolderPathPdf + File.separator + pdfFeedbackFileName);
				logger.info("Checking if feedback file : " + transferFolderPathPdf + File.separator
						+ pdfFeedbackFileName + " exists");
				if (!feedbackFileName.exists()) {
					logger.info("Feedback file does not exist - result - WAIT");
					return "WAIT";
				}
				logger.info("Reading file : " + feedbackFileName);
				fileReader = new FileReader(feedbackFileName);
				bufferedReader = new BufferedReader(fileReader);

				String line = "";
				while ((line = bufferedReader.readLine()) != null) {
					logger.info(line);
					if (!line.isEmpty()) {
						feedbackMsg += line + "\n";
					}
				}
			} finally {
				if (bufferedReader != null) {
					bufferedReader.close();
				}
				if (fileReader != null) {
					fileReader.close();
				}
			}

		} catch (Exception e) {
			logger.log(Level.SEVERE, e.getMessage());
			LOGGER.error(EXCEPTION_MSG, e);
			return "Error: " + e.getMessage();
		}
		if (feedbackMsg.isEmpty()) {
			logger.info("checkPDFTransfer feedbackMSG : " + "GO");
			return "GO";
		}
		logger.info("checkPDFTransfer feedbackMSG : " + feedbackMsg);
		return feedbackMsg;
	}

	public static void deletePDFfeedbackFiles(EPMDocument pbo) {

		if (SKIP_CADIM) {
			logger.info("There is no feedback files (PDF transfer) to delete");
			return;
		}

		String pboCadNameWithoutExtension = pbo.getCADName().substring(0, pbo.getCADName().lastIndexOf("."));
		String transferFolderPathPdf = TRANSFER_TEMP_DIR_PATH_PDF;

		Representation releaseRep = null;
		ApplicationData pdfAppData = null;

		try {
			VisualizationHelper visualizationHelper = new VisualizationHelper();
			Representation representation = visualizationHelper.getRepresentation(pbo);

			ContentItem ci = null;
			ApplicationData ap = null;

			// get Release rep content (representation files)
			if (representation != null)
				releaseRep = (Representation) ContentHelper.service.getContents(representation);
			Vector content = new Vector();
			if (releaseRep != null)
				content = ContentHelper.getContentList(releaseRep);

			// find pdf file
			logger.info("Rozmiar contentu pdf files ---> transferPdfToCadim." + content.size());
			for (int i = 0; i < content.size(); i++) {
				ci = (ContentItem) content.elementAt(i);
				if (ci instanceof ApplicationData) {
					ap = (ApplicationData) ci;
					logger.info("ApplicationData pdf files ---> transferPdfToCadim." + ap);
					logger.info("ApplicationData pdf files ---> transferPdfToCadim." + ap.getFileName().toLowerCase());
					logger.info(
							"ApplicationData pdf files ---> transferPdfToCadim ---- > PDFEXTENTION:" + PDF_EXTENSION);
					if (ap.getFileName().toLowerCase().endsWith(PDF_EXTENSION)) {
						pdfAppData = ap;
					}
				}
			}

			if (pdfAppData == null) {
				logger.info("There is no feedback files (PDF transfer) to delete");
				return;
			}

			ApplicationData pdfApplicationData = pdfAppData;

			// get sheet no
			String[] nameParts = pdfApplicationData.getFileName().split("_");
			String lastNamePart = nameParts[nameParts.length - 1];
			String sheetNoString = lastNamePart.split("\\.")[0];
			int sheetNo = 0;
			try {
				sheetNo = Integer.parseInt(sheetNoString);
			} catch (NumberFormatException e) {
				// this is first sheet (ie. drw0001_drw.pdf)
				sheetNo = 1;
			}

			// file name without extension for dxf and txt files
			String pdfAndTxtFileName = pboCadNameWithoutExtension + "_" + sheetNo;
			String pdfFeedbackFileName = pdfAndTxtFileName + KB_AdvReleasePendingProcessHelper.FEEDBACK_EXTENSION;
			logger.info("pdfAndTxtFileName : " + pdfAndTxtFileName);
			logger.info("pdfFeedbackFileName : " + pdfFeedbackFileName);
			FileReader fileReader = null;
			BufferedReader bufferedReader = null;
			File feedbackFileName = null;
			try {
				feedbackFileName = new File(transferFolderPathPdf + File.separator + pdfFeedbackFileName);
				logger.info("Checking if feedback file : " + transferFolderPathPdf + File.separator
						+ pdfFeedbackFileName + " exists");
				if (!feedbackFileName.exists()) {
					logger.info("Feedback file does not exist");
					return;
				} else {
					feedbackFileName.delete();
					logger.info(pdfFeedbackFileName + " - removed");
				}
			} finally {
				if (bufferedReader != null) {
					bufferedReader.close();
				}
				if (fileReader != null) {
					fileReader.close();
				}
			}

		} catch (Exception e) {
			logger.log(Level.SEVERE, e.getMessage());
			LOGGER.error(EXCEPTION_MSG, e);
		}
	}

	public static WTDocument getPublishedDocument(EPMDocument epmDocument) throws WTException {
		WTDocument document = null;
		QueryResult representables = PersistenceHelper.manager.navigate(epmDocument,
				PublishedContentLink.PUBLISHED_CONTENT_HOLDER_ROLE, PublishedContentLink.class, true);
		if (representables.hasMoreElements()) {
			Object nextElement = representables.nextElement();
			if (nextElement instanceof WTDocument) {
				document = (WTDocument) nextElement;
			}
		}
		return document;
	}

	public static void cutOffDxfFiles(WTChangeActivity2 changeItem) throws WTException, PropertyVetoException {

		if (changeItem instanceof ChangeActivityIfc) {
			ChangeActivityIfc changeNotice = (ChangeActivityIfc) changeItem;

			QueryResult resulting = ChangeHelper2.service.getChangeablesAfter(changeNotice);

			while (resulting.hasMoreElements()) {

				Object o = resulting.nextElement();

				if (o instanceof EPMDocument) {
					EPMDocument doc = (EPMDocument) o;
					logger.info("Processing cutOffDxfFiles for : " + doc.getName() + " - " + doc.getNumber());
					cutOffDxfFiles(doc);
				}
				if (KBType.isDescendedFrom(o, "com.ptc.KBNeutralData")) {
					WTDocument doc = (WTDocument) o;
					logger.info("Processing cutOffDxfFiles for : " + doc.getName() + " - " + doc.getNumber());
					cutOffDxfFiles(doc, changeItem);
					renameDxfFiles(doc);
				}
			}
		}
	}

	private static void renameDxfFiles(WTDocument doc) throws WTException, PropertyVetoException {
		logger.info("Renaming dxfFiles for : " + doc.getName() + " - " + doc.getNumber());
		QueryResult attachments = AttachmentsHelper.service.getAttachments(doc, ContentRoleType.SECONDARY);
		while(attachments.hasMoreElements()){
			Object attachment = attachments.nextElement();
			if(attachment instanceof ApplicationData){
				ApplicationData applicationData = (ApplicationData) attachment;
				String fileName = applicationData.getFileName();
				logger.info("dxf File: " + fileName);
				if (fileName.contains("/")){
					String newName = fileName.replace("/", "_");
					applicationData.setFileName(newName);
					applicationData = ContentHelper.service.updateAppData(doc, applicationData, true);
					logger.info("dxf File renamed successfully " + applicationData.getFileName());
				}
			}
		}

	}

	public static void unzipingDxfFiles(WTChangeActivity2 changeItem) throws WTException, WTPropertyVetoException {
		if (changeItem instanceof ChangeActivityIfc) {
			ChangeActivityIfc changeNotice = (ChangeActivityIfc) changeItem;

			QueryResult resulting = ChangeHelper2.service.getChangeablesAfter(changeNotice);

			while (resulting.hasMoreElements()) {

				Object o = resulting.nextElement();
				if (o instanceof EPMDocument) {
					EPMDocument doc = (EPMDocument) o;
					logger.info("Processing cutOffDxfFiles for : " + doc.getName() + " - " + doc.getNumber());
					unzipingDxfFiles(doc);
				}
			}
		}
	}

	public static void unzipingDxfFiles(EPMDocument document) throws WTException {
		WTDocument publishedDocument = getPublishedDocument(document);
		if (publishedDocument != null) {
			logger.info("Exist Neutral Data " + publishedDocument.getNumber());
		}
		QueryResult epmReps = RepresentationHelper.service.getRepresentations(document);
		try {
			if (epmReps != null) {
				logger.info("number of Representation " + epmReps.size());
				while (epmReps.hasMoreElements()) {
					Representation representation = (Representation) epmReps.nextElement();
					representation = (Representation) ContentHelper.service.getContents(representation);
					if (representation != null) {
						Enumeration<?> e = ContentHelper.getApplicationData(representation).elements();
						while (e.hasMoreElements()) {
							Object app_object = e.nextElement();
							if (app_object instanceof ApplicationData) {
								ApplicationData app_data = (ApplicationData) app_object;
								String fileName = app_data.getFileName();
								if (fileName.endsWith("zip")) {
									File zipFile = ContentServerHelper.service.getStoredItemFile(app_data).getPhysicalFile();
									logger.info("Representation zipFileName: " + zipFile.getName());
									String path = zipFile.getPath();
									logger.info("Representation zipPath: " + path);
									String parentPath = zipFile.getParentFile().getPath();
									logger.info("Removing " + fileName + " from representation");
									Set<File> unZipFiles = getUnZipFiles(path, parentPath);
									logger.info("Number of Unziped Files: " + unZipFiles.size());
									for (File dxfFile : unZipFiles) {
										try {
											publishedDocument = (WTDocument) ObjectRevisionHelper
													.getLatestVersionByPersistable(publishedDocument);
											logger.info("number of published document" + publishedDocument.getNumber());
											String revision = AttributeService.getAttribute(publishedDocument,
													"revision");
											logger.info("revision of published document" + revision);
											createAttachment(publishedDocument, dxfFile);
										} catch (PropertyVetoException exc) {
											logger.info("problem during creation of attachment" + exc);
										}
									}
								} else {
									logger.info("Skipped file : " + fileName);
								}
							}
						}
					}
				}
			} else {
				logger.info("not found any representation ");
			}
		} catch (Exception e) {
			logger.info("Unziping dxfFiles failed " + e);
		}
	}

	public static void createAttachment(WTDocument doc, File file)
			throws WTException, PropertyVetoException, IOException {
		logger.info("Creating atachment for " + doc.getNumber() + "FileName" + file.getName());
		String docNumber = doc.getNumber();
		String prefix = "dxf_" + docNumber + "_drw";
		String revision = AttributeService.getAttribute(doc, "revision");
		logger.info("docNumber: " + docNumber + "prefix: " + prefix + "revision: " + revision);
		try (FileInputStream fis = new FileInputStream(file)) {
			ApplicationData content = ApplicationData.newApplicationData(doc);
			String filename = file.getName();
			String[] split = filename.split(prefix);
			String suffif = (split.length > 1) ? split[1] : "";
			String path = file.getPath();
			content.setFileName(docNumber + "_" + revision + suffif);
			content.setUploadedFromPath(path);
			content.setRole(ContentRoleType.toContentRoleType("SECONDARY"));
			content.setFileSize(file.length());
			content = ContentServerHelper.service.updateContent(doc, content, fis);
			ContentServerHelper.service.updateHolderFormat(doc);
			doc = (WTDocument) PersistenceHelper.manager.refresh((Persistable) doc, true, true);
			logger.info("Attachment created sucesfully for " + docNumber + "FileName:" + content.getFileName());
		} catch (IOException e) {
			logger.info("problem with creating attachment: " + e);

		}
	}

	public static Set<File> getUnZipFiles(String zipFilePath, String destDirectory) {
		logger.info("Starting unziping zipFile");
		Set<File> files = new HashSet<>();
		File destDir = new File(destDirectory);
		if (!destDir.exists()) {
			destDir.mkdir();
		}
		try (ZipInputStream zipIn = new ZipInputStream(new FileInputStream(zipFilePath))) {
			ZipEntry entry = zipIn.getNextEntry();
			logger.info("Checking entry: " + entry.getName());
			// iterates over entries in the zip file
			while (entry != null) {
				String filePath = destDirectory + File.separator + entry.getName();
				if (!entry.isDirectory()) {
					// if the entry is a file, extracts it
					extractFile(zipIn, filePath);
					File dir = new File(filePath);
					files.add(dir);
					logger.info("Added unzpided dxf file to List" + dir.getName());
				} else {
					// if the entry is a directory, make the directory
					File dir = new File(filePath);
					dir.mkdir();
				}
				zipIn.closeEntry();
				entry = zipIn.getNextEntry();
			}
		} catch (IOException ex) {
			logger.info("problem with uziping Files attachment: " + ex);
		}
		logger.info("returned file Size" + files.size());
		return files;
	}

	/**
	 * Extracts a zip entry (file entry)
	 * 
	 * @param zipIn
	 * @param filePath
	 * @throws IOException
	 */
	private static void extractFile(ZipInputStream zipIn, String filePath) throws IOException {
		int bufferSize = 4096;
		BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(filePath));
		byte[] bytesIn = new byte[bufferSize];
		int read = 0;
		while ((read = zipIn.read(bytesIn)) != -1) {
			bos.write(bytesIn, 0, read);
		}
		bos.close();
	}

	public static void cutOffDxfFiles(EPMDocument document) throws WTException {

		QueryResult epmReps = RepresentationHelper.service.getRepresentations(document);
		Long numberOfPages = getNumberOfPages(document);
		if (numberOfPages != null && numberOfPages >= 1) {
			try {
				if (epmReps != null) {
					while (epmReps.hasMoreElements()) {
						Representation representation = (Representation) epmReps.nextElement();
						representation = (Representation) ContentHelper.service.getContents(representation);
						if (representation != null) {
							Enumeration<?> e = ContentHelper.getApplicationData(representation).elements();
							while (e.hasMoreElements()) {
								Object app_object = e.nextElement();
								if (app_object instanceof ApplicationData) {
									ApplicationData app_data = (ApplicationData) app_object;
									String fileName = app_data.getFileName();
									if (fileName.endsWith(ZIP_EXTENSION)) {
										File file = ContentServerHelper.service.getStoredItemFile(app_data).getPhysicalFile();
										logger.info("Removing " + fileName + " from representation");
										ZipFile zipFile = new ZipFile(file);
										String path = file.getAbsolutePath();
										logger.info("path : " + path);
										Enumeration zipEntries = zipFile.entries();
										Map<String, String> zip_properties = new HashMap<>();
										zip_properties.put("create", "false");
										logger.info("zip_properties : " + zip_properties.toString());
										URI zip_disk = URI.create("jar:file://" + path);
										logger.info("zip_disk : " + zip_disk);
										try (FileSystem zipfs = FileSystems.newFileSystem(zip_disk, zip_properties)) {
											while (zipEntries.hasMoreElements()) {
												String zipEntryName = ((ZipEntry) zipEntries.nextElement()).getName();
												logger.info("zipEntryName : " + zipEntryName);
												if (shouldBeRemoved(zipEntryName, numberOfPages)) {
													Path pathInZipfile = zipfs.getPath(zipEntryName);
													logger.info("pathInZipfile : " + pathInZipfile);
													Files.delete(pathInZipfile);
													logger.info(pathInZipfile + "deleted");
												}
											}
										}
										if (zipFile != null) {
											zipFile.close();
										}
									} else {
										logger.info("Skipped file : " + fileName);
									}
								}
							}
						}
					}
				}
			} catch (WTException | PropertyVetoException | IOException e) {
				LOGGER.error(EXCEPTION_MSG + e);
			}
		}
	}

	public static void cutOffDxfFiles(WTDocument document, WTChangeActivity2 activity)
			throws WTException, WTPropertyVetoException {
		logger.info("Cutting off dxf file for Neutral Data");
		Long numberOfPages = getNumberOfPages(document);
		QueryResult attachments = AttachmentsHelper.service.getAttachments(document, ContentRoleType.SECONDARY);
		String revision = AttributeService.getAttribute(document, "revision");
		logger.info("revision = " + revision);
		String number = document.getNumber();
		logger.info("number = " + number);
		String irev = IBAHelper.readIBA(document, KBConstants.KB_INTERNAL_REVISION_IBA);
		String prefix = "";
		if(document.getLifeCycleState().toString().equals(KBConstants.INTERNAL_RELEASED) && StringUtils.isNotEmpty(irev)){
			prefix = number + "_" + revision +irev+ "_";
		}else{
			prefix = number + "_" + revision + "_";
		}
		prefix = prefix.replace("/", "_");
		Set<ApplicationData> dxfFiles = filterDxfFiles(prefix, attachments);
		QueryResult changeOrders = ChangeHelper2.service.getLatestChangeOrder(activity);
		WTChangeOrder2 order = null;
		if (changeOrders.hasMoreElements()) {
			order = (WTChangeOrder2) changeOrders.nextElement();
		}

		EPMDocument epmDocument = getRelatedRepresentable(document);
		ManagedBaseline baseline = null;
		if (epmDocument != null) {
			epmDocument = ObjectRevisionHelper.getLatestVersion(epmDocument);
			String revisionOfEpm = AttributeService.getAttribute(epmDocument, "revision");
			logger.info("revision of related drawing = " + revisionOfEpm);
			logger.info("number of related drawing = " + epmDocument.getNumber());
		}

		baseline = ext.kb.workflow.BaselineHelper.findReleasedBaseline(activity, order);
		boolean containsDrawingFormat = false;
		if (baseline == null) {
			logger.info("No baseline for the Drawing; number= " + document.getNumber());
		} else {
			logger.info("Baseline exists");
			containsDrawingFormat = KBUtils.containsDrawingFormat(baseline);
			logger.info("Contains drawing format: " + containsDrawingFormat);
		}

		logger.info("containsDrawingFormat: " + containsDrawingFormat);
		boolean needToRemoveAdditionalPages = containsDrawingFormat && numberOfPages != null && numberOfPages >= 1;
		boolean needToRemoveLastPage = (AttributeService.isEmpty(document, "KB_NUM_OF_PAGES") || numberOfPages == 0)&& containsDrawingFormat;
		if (needToRemoveAdditionalPages) {
			removeAdditionalPages(document, prefix, dxfFiles);
		}
		// if value of numberOfPages is 0 or not set (null or empty)
		else if (needToRemoveLastPage) {
			removeLastPage(document, prefix, dxfFiles);
		}
		// if no "*stueli.frm" format no removing last page
		if (!containsDrawingFormat) {
			logger.info("NO stueli.frm!");
		}
	}
	
	public static void cutOffDxfFiles(WTDocument document, EPMDocument epmdocument)
			throws WTException, PropertyVetoException {
		logger.info("Cutting off dxf file for Neutral Data");
		Long numberOfPages = getNumberOfPages(document);
		QueryResult attachments = AttachmentsHelper.service.getAttachments(document, ContentRoleType.SECONDARY);
		String revision = AttributeService.getAttribute(document, "revision");
		logger.info("revision = " + revision);
		String number = document.getNumber();
		logger.info("number = " + number);
		String irev = IBAHelper.readIBA(document, KBConstants.KB_INTERNAL_REVISION_IBA);
		String prefix = "";
		if(document.getLifeCycleState().toString().equals(KBConstants.INTERNAL_RELEASED) && StringUtils.isNotEmpty(irev)){
			prefix = number + "_" + revision +irev+ "_";
		}else{
			 prefix = number + "_" + revision + "_";
		}

		logger.info("irev = " + irev);
		prefix = prefix.replace("/", "_");
		Set<ApplicationData> dxfFiles = filterDxfFiles(prefix, attachments);

		boolean containsDrawingFormat = false;
		containsDrawingFormat = KBUtils.containsDrawingFormat(epmdocument);
		String revisionOfEpm = AttributeService.getAttribute(epmdocument, "revision");
		logger.info("revision of related drawing = " + revisionOfEpm);
		logger.info("number of related drawing = " + epmdocument.getNumber());

		logger.info("containsDrawingFormat: " + containsDrawingFormat);
		boolean needToRemoveAdditionalPagesPages = containsDrawingFormat && numberOfPages != null && numberOfPages >= 1;
		boolean needToRemoveLastPage = (AttributeService.isEmpty(document, "KB_NUM_OF_PAGES") || numberOfPages == 0)&& containsDrawingFormat;
		if (needToRemoveAdditionalPagesPages) {
			removeAdditionalPages(document, prefix, dxfFiles);
		}
		// if value of numberOfPages is 0 or not set (null or empty)
		else if (needToRemoveLastPage) {
			removeLastPage(document, prefix, dxfFiles);
		}
		// if no "*stueli.frm" format no remove last page
		if (!containsDrawingFormat) {
			logger.info("NO stueli.frm!");
		}
		renameDxfFiles(document);
	}

	public static void removeLastPage(WTDocument document, String prefix, Set<ApplicationData> dxfFiles)
			throws WTException, WTPropertyVetoException {
		if(dxfFiles.size() > 1){
			List<NmOid> removeList = new ArrayList<>();
			ApplicationData applicationData = getLastPage(dxfFiles, prefix);
			if(applicationData != null){
				logger.info("found last Page");
				removeList.add(new NmOid(applicationData));
				String fileName = applicationData.getFileName();
				logger.info("Filename for application data: " +fileName);
				AttachmentsHelper.service.removeAttachments(document, removeList);
				logger.info("delated last page from neutral data: " + applicationData.getFileName());
			}else{
				logger.info("Not found last Page");
			}
		}
	}

	public static void removeAdditionalPages(WTDocument document,String prefix, Set<ApplicationData> dxfFiles) throws WTException, WTPropertyVetoException {
		Long numberOfPages = getNumberOfPages(document);
		List<NmOid> removeList = new ArrayList<>();
		logger.info("number of pages: "+ numberOfPages);
		for (ApplicationData applicationData : dxfFiles) {
			String fileName = applicationData.getFileName();
			logger.info("filename for application data: " +fileName);
			long pageNumber = getPageNumber(prefix, fileName);
			if (pageNumber > numberOfPages) {
				removeList.add(new NmOid(applicationData));
				logger.info("added page to removelist" + applicationData.getFileName());
			}
		}
		AttachmentsHelper.service.removeAttachments(document, removeList);
		logger.info("Additional pages removed successfully");
		
	}
	

	
	public static ApplicationData getLastPage(Set<ApplicationData> dxfFiles, String prefix) {
		int numberOfPage = 0;
		ApplicationData lastAppData = null;
		for (ApplicationData applicationData : dxfFiles) {
			logger.info("numberOfPage: " +numberOfPage);
			String fileName = applicationData.getFileName();
			logger.info("filename: " +fileName);
			int beginIndex = prefix.length();
			int endIndex = fileName.indexOf(".dxf");
			String substring = fileName.substring(beginIndex, endIndex);
			int pageNumber = StringUtils.isNumericSpace(substring) ? Integer.parseInt(substring) : 0;
			logger.info("pageNumber: " +pageNumber);
			if(pageNumber >= numberOfPage){
				lastAppData =applicationData;
				numberOfPage = pageNumber;
			}
		}
		return lastAppData;
	}

	public static long getPageNumber(String prefix, String fileName) {
		long pageNumber = 0;
		String[] splited = fileName.split(prefix);
		String sufix = (splited.length > 1) ? splited[1] : null;
		if (sufix != null) {
			logger.info("suffix: " + sufix);
			String substring = StringUtils.removeEnd(sufix, ".dxf");
			logger.info("substring: " + substring);
			pageNumber = StringUtils.isNumericSpace(substring) ? Long.parseLong(substring) : 0;
		}
		return pageNumber;
	}

	private static Long getNumberOfPages(WTDocument document) {
		Long numberOfPages = null;
		Object pages = AttributeService.getAttribute(document, "KB_NUM_OF_PAGES");
		if (pages != null) {
			numberOfPages = Long.parseLong(pages.toString());
		}
		logger.info("getNumberOfPages returns : " + numberOfPages);
		return numberOfPages;
	}

	private static EPMDocument getRelatedRepresentable(WTDocument document) throws WTException {
		EPMDocument representable = null;
		QueryResult representables = PersistenceHelper.manager.navigate(document,
				PublishedContentLink.REPRESENTABLE_ROLE, PublishedContentLink.class, true);
		if (representables.hasMoreElements()) {
			Object nextElement = representables.nextElement();
			if (nextElement instanceof EPMDocument) {
				representable = (EPMDocument) nextElement;
			}
		}
		return representable;
	}

	public static Set<ApplicationData> filterDxfFiles(String prefix, QueryResult attachments) {
		logger.info("Filtereing dxf files");
		Set<ApplicationData> dxfFiles = new HashSet<>();
		while (attachments.hasMoreElements()) {
			Object appObject = attachments.nextElement();
			if (appObject instanceof ApplicationData) {
				ApplicationData appDdata = (ApplicationData) appObject;
				String fileName = appDdata.getFileName();
				logger.info("application data name: " + fileName);
				if (fileName.startsWith(prefix) && fileName.endsWith("dxf")) {
					logger.info("application data added to filtered files: " + fileName);
					dxfFiles.add(appDdata);
				}
			}
		}
		logger.info("Filtered files: " + dxfFiles + "Size: " + dxfFiles.size());
		return dxfFiles;
	}

	private static Long getNumberOfPages(EPMDocument document) {
		Long numberOfPages = null;
		Object pages = AttributeService.getAttribute(document, "KB_NUM_OF_PAGES");
		if (pages != null) {
			numberOfPages = Long.parseLong(pages.toString());
		}
		logger.info("getNumberOfPages returns : " + numberOfPages);
		return numberOfPages;
	}

	private static boolean shouldBeRemoved(String fileName, Long numberOfPages) {
		logger.info("Entered shouldBeRemoved method");
		logger.info("fileName : " + fileName);
		String[] nameParts = fileName.split("_");
		String lastNamePart = nameParts[nameParts.length - 1];
		logger.info("lastNamePart : " + lastNamePart);
		String sheetNoString = lastNamePart.split("\\.")[0];
		logger.info("sheetNoString : " + sheetNoString);
		int sheetNo = 0;
		try {
			sheetNo = Integer.parseInt(sheetNoString);
		} catch (NumberFormatException e) {
			sheetNo = 1;
		}

		if (sheetNo > numberOfPages) {
			logger.info("shouldBeRemoved returns : true");
			return true;
		}
		logger.info("shouldBeRemoved returns : false");
		return false;
	}

	private static Vector<File> unZipFile(File file, String paramString2) {
		try {
			File localFile2 = new File(paramString2);

			ZipFile localZipFile = new ZipFile(file, 1);

			Enumeration localEnumeration = localZipFile.entries();
			Vector<File> localVector = new Vector<File>();
			while (localEnumeration.hasMoreElements()) {
				ZipEntry localZipEntry = (ZipEntry) localEnumeration.nextElement();
				// rename files.
				String str = fixName(localZipEntry.getName().replace("_drw", ""));

				File localFile3 = new File(localFile2, str);

				File localFile4 = localFile3.getParentFile();

				localFile4.mkdirs();
				if (!localZipEntry.isDirectory()) {
					BufferedInputStream localBufferedInputStream = new BufferedInputStream(
							localZipFile.getInputStream(localZipEntry));

					byte[] arrayOfByte = new byte[BUFFER];

					FileOutputStream localFileOutputStream = new FileOutputStream(localFile3);
					BufferedOutputStream localBufferedOutputStream = new BufferedOutputStream(localFileOutputStream,
							BUFFER);
					int i;
					while ((i = localBufferedInputStream.read(arrayOfByte, 0, BUFFER)) != -1) {
						localBufferedOutputStream.write(arrayOfByte, 0, i);
					}
					localBufferedOutputStream.flush();
					localBufferedOutputStream.close();
					localBufferedInputStream.close();

					localVector.add(localFile3);
				}
			}
			localZipFile.close();

			return localVector;
		} catch (IOException localIOException) {
			LOGGER.error(EXCEPTION_MSG, localIOException);
		}
		return null;
	}

	private static Vector<File> getZipFiles(File file) {
		try {

			ZipFile localZipFile = new ZipFile(file, 1);

			Enumeration localEnumeration = localZipFile.entries();
			Vector<File> localVector = new Vector<File>();
			while (localEnumeration.hasMoreElements()) {
				ZipEntry localZipEntry = (ZipEntry) localEnumeration.nextElement();
				// rename files.
				String str = fixName(localZipEntry.getName().replace("_drw", ""));
				File localFile2 = new File(str);
				localVector.add(localFile2);
			}
			localZipFile.close();
			return localVector;
		} catch (IOException localIOException) {
			LOGGER.error(EXCEPTION_MSG, localIOException);
		}
		return null;
	}

	private static String fixName(String name) {
		String str = name.substring(name.indexOf("_") + 1);
		return str;
	}

	private static boolean isPhantomTrue(EPMDocument doc) {
		boolean result = false;
		if (doc != null) {
			if (!KBTypeIdProvider.isDescendant(doc, "KBCADDRW")) {
				Boolean kbPhantom = IBAHelper.readIBA(doc, KBConstants.KB_PHANTOM_IBA);
				result = ObjectUtils.equals(Boolean.TRUE, kbPhantom);
			}
		}
		return result;
	}

}

/**
 * Class with method compare ApplicationData objects by file name. Used to sort
 * sheets ApplicationData files in order 1,2,3,...,n.
 * 
 * @author pboguski
 * 
 */
class AppDataComparator implements Comparator<ApplicationData> {

	@Override
	public int compare(ApplicationData o1, ApplicationData o2) {

		int o1No = 0;
		int o2No = 0;

		// get o1 sheet number
		if (o1.getFileName().toLowerCase().endsWith(KB_AdvReleasePendingProcessHelper.DXF_EXTENSION)) {
			String[] nameParts = o1.getFileName().split("_");
			String lastNamePart = nameParts[nameParts.length - 1];
			String sheetNoString = lastNamePart.split("\\.")[0];
			try {
				o1No = Integer.parseInt(sheetNoString);
			} catch (NumberFormatException e) {
				// this is first sheet (ie. drw0001_drw.dxf)
				o1No = 1;
			}
		}
		// sample name: drw0001_drw_1_x.hp2
		// template <drw name>_<drw extension>_<sheet no>_x_.hp2
		else if (o1.getFileName().toLowerCase().endsWith(KB_AdvReleasePendingProcessHelper.HPGL_EXTENSION)) {
			String[] nameParts = o1.getFileName().split("_");
			String sheetNoString = nameParts[nameParts.length - 2];
			o1No = Integer.parseInt(sheetNoString);
		}

		// get o2 sheet number
		if (o2.getFileName().toLowerCase().endsWith(KB_AdvReleasePendingProcessHelper.DXF_EXTENSION)) {
			String[] nameParts = o2.getFileName().split("_");
			String lastNamePart = nameParts[nameParts.length - 1];
			String sheetNoString = lastNamePart.split("\\.")[0];
			try {
				o2No = Integer.parseInt(sheetNoString);
			} catch (NumberFormatException e) {
				// this is first sheet (ie. drw0001_drw.dxf)
				o2No = 1;
			}
		}
		// sample name: drw0001_drw_1_x.hp2
		// template <drw name>_<drw extension>_<sheet no>_x_.hp2
		else if (o2.getFileName().toLowerCase().endsWith(KB_AdvReleasePendingProcessHelper.HPGL_EXTENSION)) {
			String[] nameParts = o2.getFileName().split("_");
			String sheetNoString = nameParts[nameParts.length - 2];
			o2No = Integer.parseInt(sheetNoString);
		}

		return o1No - o2No;
	}

}
