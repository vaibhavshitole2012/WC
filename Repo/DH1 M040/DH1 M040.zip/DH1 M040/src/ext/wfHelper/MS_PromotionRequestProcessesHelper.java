package ext.wfHelper;

import java.util.Set;

import org.apache.log4j.Logger;

import wt.change2.ChangeHelper2;
import wt.change2.WTChangeOrder2;
import wt.doc.WTDocument;
import wt.epm.EPMDocument;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.fc.collections.WTHashSet;
import wt.log4j.LogR;
import wt.maturity.MaturityBaseline;
import wt.maturity.PromotionNotice;
import wt.util.WTException;
import wt.vc.baseline.BaselineHelper;
import wt.vc.config.ConfigSpec;

import com.ptc.wvs.server.publish.Publish;

public class MS_PromotionRequestProcessesHelper {
	private static final String CLASSNAME = MS_PromotionRequestProcessesHelper.class.getName();
	protected static final Logger LOGGER = LogR.getLogger(CLASSNAME);

	public static void publishPromotionNotice(PromotionNotice promotionNotice) throws WTException {
		LOGGER.debug("IN publishPromotionNotice...");

		MaturityBaseline maturityBaseline = promotionNotice.getConfiguration();

		WTHashSet potentialObjectsForRepublishing = new WTHashSet();

		QueryResult allBaselineItems = BaselineHelper.service.getBaselineItems(maturityBaseline);

		while (allBaselineItems.hasMoreElements()) {
			Persistable persistable = (Persistable) allBaselineItems.nextElement();
			if (persistable instanceof EPMDocument || persistable instanceof WTDocument) {
				LOGGER.debug("Adding " + persistable.getIdentity().toString() + " to the list...");
				potentialObjectsForRepublishing.add(persistable);
			}
		}

		String repName = promotionNotice.getPersistInfo().getObjectIdentifier().toString();
		String repDescription = promotionNotice.getName() + ", " + promotionNotice.getNumber();

		publishObjects(potentialObjectsForRepublishing, repName, repDescription);
	}

	public static void publishChangeNotice(WTChangeOrder2 changeNotice) throws WTException {
		WTHashSet potentialObjectsForRepublishing = new WTHashSet();

		QueryResult resultingItems = ChangeHelper2.service.getChangeablesAfter(changeNotice);

		while (resultingItems.hasMoreElements()) {
			Persistable persistable = (Persistable) resultingItems.nextElement();
			if (persistable instanceof EPMDocument || persistable instanceof WTDocument) {
				potentialObjectsForRepublishing.add(persistable);
			}
		}

		String repName = changeNotice.getPersistInfo().getObjectIdentifier().toString();
		String repDescription = changeNotice.getName() + ", " + changeNotice.getNumber();

		publishObjects(potentialObjectsForRepublishing, repName, repDescription);
	}

	public static void publishObjects(Set<ObjectReference> potentialObjectsForRepublishing, String repName, String repDescription) throws WTException {
		for (ObjectReference representable : potentialObjectsForRepublishing) {
			LOGGER.debug("Invoking publish for " + representable.toString());
			Publish.doPublish(false, true, representable.toString(), (ConfigSpec) null, (ConfigSpec) null, true, repName, repDescription, 3, null, 1);
		}
	}

}
