package ext.kb.ws;

public class SharedDocumentObject {
	String ObjectNumber; 
	String ObjectType; 
	String ObjectVersion;
	String Message;
		
	public void SharedDocumentObject(String ObjectNumber, String ObjectType, String ObjectVersion, String Message){
		this.ObjectNumber = ObjectNumber;
		this.ObjectType = ObjectType;
		this.ObjectVersion = ObjectVersion;
		this.Message = Message;
	}

	public String getObjectNumber() {
		return ObjectNumber;
	}

	public void setObjectNumber(String ObjectNumber) {
		this.ObjectNumber = ObjectNumber;
	}

	public String getObjectType() {
		return ObjectType;
	}

	public void setObjectType(String ObjectType) {
		this.ObjectType = ObjectType;
	}
	public String getObjectVersion() {
		return ObjectVersion;
	}

	public void setObjectVersion(String ObjectVersion) {
		this.ObjectVersion = ObjectVersion;
	}
	public String getMessage() {
		return Message;
	}

	public void setMessage(String Message) {
		this.Message = Message;
	}

}
