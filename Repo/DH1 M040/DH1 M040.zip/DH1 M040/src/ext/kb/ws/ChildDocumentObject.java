package ext.kb.ws;

public class ChildDocumentObject {
	String Number; 
	String CID; 
		
	public void ChildDocumentObject(String Number, String CID){
		this.Number = Number;
		this.CID = CID;
	}

	public String getNumber() {
		return Number;
	}

	public void setNumber(String Number) {
		this.Number = Number;
	}

	public String getCID() {
		return CID;
	}

	public void setCID(String CID) {
		this.CID = CID;
	}


}
