package ext.kb.ws;

public class CreateECTTableDataOutput {
	String partNumber; 
	String docNumber;
	String sign;
	String errorMessage;
	String type;
	String revision;
	String contentType;
		
	public void CreateTableDataOutput(String partNumber, String docNumber, String errorMessage, String sign, String type, String revision, String contentType){
		this.partNumber = partNumber;
		this.docNumber = docNumber;
		this.sign= sign;
		this.errorMessage = errorMessage;
		this.type = type;
		this.revision = revision;
		this.contentType = contentType;
	}

	public String getPartNumber() {
		return partNumber;
	}

	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	public String getError() {
		return errorMessage;
	}
	public void setError(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	
	public void setType(String type) {
		this.type = type;
	}
	public String getType() {
		return type;
	}
	
	public void setRevision(String revision) {
		this.revision = revision;
	}
	public String getRevision() {
		return revision;
	}
	
	public String getDocNumber() {
		return docNumber;
	}

	public void setDocNumber(String docNumber) {
		this.docNumber = docNumber;
	}
	public String getSign() {
		return sign;
	}

	public void setSign(String sign) {
		this.sign = sign;
	}
	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	}
