package ext.kb.ws;

public class MoveArticlePosition {
	String number; 
	String CID; 
		
	public void MoveArticlePosition(String partNumber, String partCID){
		this.number = partNumber;
		this.CID = partCID;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getCID() {
		return CID;
	}

	public void setCID(String partCID) {
		this.CID = partCID;
	}

}
