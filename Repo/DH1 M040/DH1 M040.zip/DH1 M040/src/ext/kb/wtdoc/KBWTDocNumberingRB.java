package ext.kb.wtdoc;

import wt.util.resource.RBComment;
import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("ext.kb.wtdoc.KBWTDocNumberingRB")
public class KBWTDocNumberingRB extends WTListResourceBundle{

	@RBEntry("Number {0} is already used. Please try once again!")
    @RBComment("When auto generated number is already used by another object")
    public static final String WTDOC_GENERATED_NUMBER_ALREADY_IN_USE = "wtdoc.number.already.in.use";
}
