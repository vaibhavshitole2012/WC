package ext.kb.workflow;

import org.apache.log4j.Logger;

import wt.change2.WTChangeIssue;
import wt.org.WTPrincipal;
import wt.team.Team;
import wt.team.TeamHelper;
import wt.util.WTException;

import com.ptc.generic.iba.AttributeService;

import ext.kb.util.KBConstants;
import ext.kb.util.KBTeamUtils;

public class KBPPRWorkflowHelper {

	private static final Logger logger = Logger.getLogger(KBPPRWorkflowHelper.class);

	public static void updateAssigneeRole(WTChangeIssue changeIssue) throws WTException {
		if (logger.isDebugEnabled()) {
			logger.debug("entering updateAssigneeRole(WTChangeIssue)");
			logger.debug("changeIssue: " + changeIssue);
		}
		Team team = (wt.team.Team) changeIssue.getTeamId().getObject();
		String kbAssignee = AttributeService.getAttribute(changeIssue, KBConstants.KBASSIGNEE_IBA);
		WTPrincipal principal = KBTeamUtils.getPrincipalFromLdapString(kbAssignee);

		if (principal != null)
			TeamHelper.service.addRolePrincipalMap(ext.kb.util.KBConstants.ASSIGNEE_ROLE, principal, team);
		if (logger.isDebugEnabled()) {
			logger.debug("exiting updateAssigneeRole()");
		}
	}
}
