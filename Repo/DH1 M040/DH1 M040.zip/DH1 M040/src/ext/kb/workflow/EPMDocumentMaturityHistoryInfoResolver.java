package ext.kb.workflow;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.ptc.windchill.enterprise.history.MaturityHistoryInfo;

import wt.epm.EPMDocument;
import wt.fc.QueryResult;
import wt.lifecycle.LifeCycleHelper;
import wt.lifecycle.LifeCycleHistory;
import wt.lifecycle.LifeCycleManaged;
import wt.lifecycle.State;
import wt.util.WTException;

/**
 * Class contains method to retrieving latest MaturityHistoryInfo (created by
 * set state) for EMPDocument object.
 * 
 * @author pboguski
 * 
 */
public class EPMDocumentMaturityHistoryInfoResolver {

	private static final Logger logger = Logger.getLogger(EPMDocumentMaturityHistoryInfoResolver.class);

	/**
	 * Returns latest MaturityHistoryInfo (created by set state) for EMPDocument
	 * object (only given iteration). MaturityHistoryInfo objects created by
	 * Promotion will not be returned.
	 * 
	 * @param EPMDocument
	 *            epm EMPDocument object
	 * @return MaturityHistoryInfo latest MaturityHistoryInfo (created by set
	 *         state) for given EMPDocument
	 * @exception wt.util.WTException
	 **/
	public static MaturityHistoryInfo latestMaturityHistoryInfo(EPMDocument epm) throws WTException {

		if (logger.isDebugEnabled()) {
			logger.debug("entering latestMaturityHistoryInfo(EPMDocument)");
			logger.debug("epm: " + epm);
		}
		QueryResult result = LifeCycleHelper.service.getHistory(epm);

		while (result.hasMoreElements()) {
			LifeCycleHistory lchObj = (LifeCycleHistory) result.nextElement();
			if (lchObj.getAction().equalsIgnoreCase("Enter_Phase")) {
				if (logger.isDebugEnabled()) {
					logger.debug("exiting latestMaturityHistoryInfo()");
				}
				return getMaturityData(lchObj, epm);
			}
		}

		if (logger.isDebugEnabled()) {
			logger.debug("exiting latestMaturityHistoryInfo()");
			logger.debug("returning: " + null);
		}
		return null;
	}

	/**
	 * Returns MaturityHistoryInfo data;
	 * 
	 * @param lchObj
	 * @param lcmObject
	 * @return
	 */
	private static MaturityHistoryInfo getMaturityData(LifeCycleHistory lchObj, LifeCycleManaged lcmObject)
			throws WTException {
		if (logger.isDebugEnabled()) {
			logger.debug("entering getMaturityData(LifeCycleHistory,LifeCycleManaged)");
			logger.debug("lchObj: " + lchObj);
			logger.debug("lcmObject: " + lcmObject);
		}
		MaturityHistoryInfo info = new MaturityHistoryInfo();
		List<Timestamp> promoteDate = new ArrayList<Timestamp>();

		State lifeCycleState = lchObj.getState();
		info.setIteration(lcmObject);
		info.setLifecycle(lchObj);
		info.setLifecycleStateStr(lifeCycleState.toString());

		promoteDate.add(lchObj.getModifyTimestamp());
		info.setPromotedDate(promoteDate);
		info.setPromotedBy(lchObj.getActorName());

		if (logger.isDebugEnabled()) {
			logger.debug("exiting getMaturityData()");
			logger.debug("returning: " + info);
		}
		return info;
	}
}
