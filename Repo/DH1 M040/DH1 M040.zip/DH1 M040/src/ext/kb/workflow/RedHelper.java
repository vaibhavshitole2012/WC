package ext.kb.workflow;

import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.log4j.Logger;

import wt.change2.ChangeRequest2;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.QueryKey;
import wt.fc.collections.WTArrayList;
import wt.fc.collections.WTCollection;
import wt.inf.sharing.DataSharingHelper;
import wt.inf.sharing.SharedContainerMap;
import wt.log4j.LogR;
import wt.org.WTPrincipal;
import wt.ownership.Ownership;
import wt.projmgmt.admin.Project2;
import wt.projmgmt.admin.Project2Reference;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;

import com.ptc.projectmanagement.plan.DateConstraint;
import com.ptc.projectmanagement.plan.Plan;
import com.ptc.projectmanagement.plan.PlanActivity;
import com.ptc.projectmanagement.plan.PlanHelper;
import com.ptc.projectmanagement.plan.Plannable;
import com.ptc.projectmanagement.plannable.PlannableHelper;
import com.ptc.prolog.pub.RunTimeException;

import ext.kb.util.DBUtils;
import ext.kb.util.KBTypeIdProvider;

public class RedHelper {

    public static final boolean OFFER_PHASE = false;
    
    public static final boolean ORDER_PHASE = true;
    
    private static final Logger LOG = LogR.getLogger(RedHelper.class.getName());

    private static final String SUMMARY_POST_FIX = " summary";

    public static void createProjectActivity(ChangeRequest2 cr, boolean isOrderPhase) throws Exception {

    	Project2 association = getAssociatedProject(cr);
        if (association == null) {
            throw new RunTimeException("Failed to look up project based on change request, please check if the request is shared to a project.");
        }
        Project2Reference projectRef = Project2Reference.newProject2Reference();
        projectRef.setObject(association);
        Plan plan = (Plan) PlanHelper.service.getPlan(projectRef);
        WTCollection planActivities = PlanHelper.service.getPlannableContents(plan);
        Iterator it = planActivities.iterator();
        Map<String, PlanActivity> existingActivities = new HashMap<String, PlanActivity>(planActivities.size());
        while (it.hasNext()) {
            ObjectReference ref = (ObjectReference) it.next();
            PlanActivity p = (PlanActivity) ref.getObject();
            existingActivities.put(p.getName(), p);
        }
        PlanActivity summary = existingActivities.get(cr.getNumber() + SUMMARY_POST_FIX);
        if (summary == null) {
            summary = addPlanActivity(projectRef, plan, association.getOwner(), cr.getNumber() + " summary",
                    "Automatically created task for time recording summary");
        }
        String subTaskName = cr.getNumber() + " Offer Phase Time recording";
        String description = "Automatically created task for time recording during offer phase";
        if (isOrderPhase) {
            subTaskName = cr.getNumber() + " Order Phase Time recording";
            description = "Automatically created task for time recording during order phase";
        } 
        if (existingActivities.get(subTaskName) == null) {
            addPlanActivity(projectRef, summary, association.getOwner(), subTaskName,
                    description);
        }
    }
    
    private static PlanActivity addPlanActivity(Project2Reference projectRef, Plannable parent, WTPrincipal owner,
            String name, String description) throws Exception {
        try {
            PlanActivity activity = PlanActivity.newPlanActivity(projectRef);
            activity.setName(name);
            activity.setDescription(description);
            activity.setOwnership(Ownership.newOwnership(owner));
            activity.setContainerReference(projectRef);
            activity.setConstraintType(DateConstraint.ASAP);
            activity.setLineNumber(PlannableHelper.service.getNextLineNumber(parent)); 
            // critical item, without this the task will not show up! 
            try {
                activity.setTypeDefinitionReference(wt.type.TypedUtilityServiceHelper.service
                        .getTypeDefinitionReference(KBTypeIdProvider.getType("KBPLANACTIVITY").getLeafName()));
                
            } catch (RemoteException e) {
                LOG.debug("Failed to set type definition, continue creating the task without this information", e);
            }
            PlanHelper.service.addToPlan(activity, parent);
            return activity;
        } catch (WTPropertyVetoException e) {
            LOG.error("Failed to set properties on plan activity: ", e);
        }
        return null;
    }

    public static Project2 getAssociatedProject(ChangeRequest2 cr) throws WTException{
    	 Project2 association = null;
         WTCollection col = new WTArrayList();
         col.add(cr);
         WTCollection results = DataSharingHelper.service.getSharedContainerMaps(col);
         Iterator sharedMapIterator = results.iterator();
         while (sharedMapIterator.hasNext()) {
             ObjectReference et = (ObjectReference) sharedMapIterator.next();
             SharedContainerMap o = (SharedContainerMap) et.getObject();
             QueryKey qk = o.getTargetContainerRef().getKey();
             Persistable object = o.getTargetContainerRef().getObject();

             if (object != null && object instanceof Project2) {
                 association = (Project2) object;
                 break;
             } else if (object == null && "wt.projmgmt.admin.Project2".equals(qk.getClassname())) {
                 association = DBUtils.queryObjectById(Project2.class, qk);
                 break;
             }
         }
         return association;
    }
}
