package ext.kb.workflow;

import org.apache.log4j.Logger;

import wt.change2.WTChangeIssue;
import wt.org.WTPrincipal;
import wt.team.Team;
import wt.team.TeamHelper;
import wt.util.WTException;

import com.ptc.generic.iba.AttributeService;

import ext.kb.util.KBConstants;
import ext.kb.util.KBTeamUtils;

public class KBGPRWorkflowHelper {
	
	private static final Logger LOG = Logger.getLogger(KBGPRWorkflowHelper.class);
	
	public static void updateCMRole(WTChangeIssue changeIssue) throws WTException {
		Team team = (wt.team.Team) changeIssue.getTeamId().getObject();
		if (LOG.isDebugEnabled()){
			LOG.debug("GPR changeIssue team: " + team.getName());
		}
		String kbAssignee = AttributeService.getAttribute(changeIssue, KBConstants.KBASSIGNEE_IBA);
		if (LOG.isDebugEnabled()){
			LOG.debug("GPR changeIssue KB_ASSIGNEE: " + kbAssignee);
		}
		try{
			WTPrincipal principal = KBTeamUtils.getPrincipalFromLdapString(kbAssignee);

			if (principal != null){
				TeamHelper.service.deleteRole(KBConstants.CHANGE_MANAGER_ROLE, team);
				TeamHelper.service.addRolePrincipalMap(KBConstants.CHANGE_MANAGER_ROLE, principal, team);
			}
		} catch (Exception e){
			e.printStackTrace();
			LOG.error("error adding principal to role", e);
		}
	}
	
}
