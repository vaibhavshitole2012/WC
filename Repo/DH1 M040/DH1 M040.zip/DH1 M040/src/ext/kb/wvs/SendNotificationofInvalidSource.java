package ext.kb.wvs;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

import ext.kb.resources.KBEmailNotificationRB;
import ext.kb.util.KBConstants;
import wt.configurablelink.ConfigurableRevisionLink;
import wt.doc.WTDocument;
import wt.doc.WTDocumentMaster;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.iba.definition.StringDefinition;
import wt.iba.value.StringValue;
import wt.inf.container.WTContainer;
import wt.inf.team.ContainerTeam;
import wt.inf.team.ContainerTeamHelper;
import wt.inf.team.ContainerTeamManaged;
import wt.lifecycle.LifeCycleHistory;
import wt.lifecycle.ObjectHistory;
import wt.log4j.LogR;
import wt.notify.NotificationHelper;
import wt.notify.SimpleEmailNotification;
import wt.notify.WTDistributionList;
import wt.org.WTPrincipalReference;
import wt.org.WTUser;
import wt.pds.StatementSpec;
import wt.project.Role;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.util.WTMessage;

public class SendNotificationofInvalidSource{

	private SendNotificationofInvalidSource(){

	}

	private static final Logger LOG = LogR.getLogger(SendNotificationofInvalidSource.class.getName());
	private static final String RESOURCE = "ext.kb.resources.KBEmailNotificationRB";
	private static final String IDA2A2="thePersistInfo.theObjectIdentifier.id";
	private static final String IDA3A5="roleAObjectRef.key.id";
	private static final String IDA3B5="roleBObjectRef.key.id";
	private static final String IDA3MASTERREFERENCE="masterReference.key.id";
	private static final String IDA3A6="definitionReference.key.id";
	private static final String IDA3A4="theIBAHolderReference.key.id";
	private static final String TRIPLE_0="000";
	private static final String ACTION="Enter_Phase";
	private static final String CREATESTAMPA2="thePersistInfo.createStamp";
	private static final String EMAILSTARTSTRING="Hello User,\n\n";
	private static final String NEWLINE="\n";

	public static void startProcessofInvalidSource() {
		QueryResult queryresult=queryInvalidSource();
		LOG.debug("final queryresult size :: "+queryresult.size());
		while(queryresult.hasMoreElements()) {
			Object[] persistable=(Object[]) queryresult.nextElement();
			WTDocument doc=(WTDocument) persistable[2];
			if(doc.getOrganizationName().equals(KBConstants.KB)) {
				List<WTDocument> vararray=getVariantlink(doc);
				if(!vararray.isEmpty()) {
					WTContainer container=doc.getContainer();
					WTDistributionList list=getContainerTeam(container);
					StringBuilder emailbody=new StringBuilder();
					emailbody.append(EMAILSTARTSTRING);
					String subject=WTMessage.getLocalizedMessage(RESOURCE, KBEmailNotificationRB.EMAIL_SUBJECT_INVALID_SOURCE, new Object[] {doc.getNumber(),doc.getVersionIdentifier().getValue()});

					emailbody.append(WTMessage.getLocalizedMessage(RESOURCE, KBEmailNotificationRB.EMAIL_BODY_INVALID_SOURCE, new Object[] {doc.getNumber(),doc.getVersionIdentifier().getValue()}));
					for (WTDocument vardoc : vararray) {
						emailbody.append(NEWLINE);
						emailbody.append(WTMessage.getLocalizedMessage(RESOURCE, KBEmailNotificationRB.EMAIL_BODY_INVALID_SOURCE_TEXT, new Object[] {vardoc.getNumber(),vardoc.getVersionIdentifier().getValue()}));
					}
					sendNotificationEmails(list,emailbody,subject);
				}
			}
		}


	}

	public static List<WTDocument> getVariantlink(WTDocument doc){
		ArrayList<WTDocument> arraylist=new ArrayList<>();
		QueryResult allvarlink=new QueryResult();
		try {
			allvarlink = PersistenceHelper.manager.navigate(doc,
					ConfigurableRevisionLink.ROLE_BOBJECT_ROLE, ConfigurableRevisionLink.class, true);

			LOG.debug("allvarlink size :: "+allvarlink.size());
			while (allvarlink.hasMoreElements()) {
				Object obj = allvarlink.nextElement();
				LOG.debug("allvarlink obj :: "+obj);
				if(obj instanceof WTDocument) {
					WTDocument vardoc=(WTDocument) obj;
					if(!vardoc.getLifeCycleState().toString().equals(KBConstants.INVALID)) {
						arraylist.add(vardoc);
					}
				}
			}
		} catch (WTException e) {
			LOG.error(e.getLocalizedMessage());
		}
		return arraylist;
	}

	private static void sendNotificationEmails(WTDistributionList list,StringBuilder emailbody,String subject){
		LOG.debug("sendNotificationEmails sent");
		SimpleEmailNotification simpleEmailNotification = new SimpleEmailNotification(list);
		try {
			simpleEmailNotification.setSender(((WTUser)SessionHelper.manager.getAdministrator()).getEMail());

			simpleEmailNotification.setSubject(subject);
			simpleEmailNotification.setBody(emailbody.toString());
			NotificationHelper.manager.send(simpleEmailNotification);
			LOG.debug("Email sent");
		} catch (WTException e) {
			LOG.error(e.getLocalizedMessage());
		}
	}

	public static WTDistributionList getContainerTeam(WTContainer container){
		WTDistributionList list=new WTDistributionList();
		ContainerTeamManaged containerTeamManaged = (ContainerTeamManaged) container;
		ContainerTeam team;
		try {
			team = ContainerTeamHelper.service.getContainerTeam(containerTeamManaged);

			Role containerManagerRole = KBConstants.DOCUMENT_MANAGEMENT_ROLE;
			List<WTPrincipalReference> participants = team.getAllPrincipalsForTarget(containerManagerRole);
			LOG.debug("getContainerTeam size :: "+participants.size());
			for (WTPrincipalReference p : participants) {
				LOG.debug("Principal :: "+p.getPrincipal().getName());
				list.addPrincipal(p.getPrincipal());
			}
		} catch (WTException e) {
			LOG.error(e.getLocalizedMessage());
		}
		return list;
	}

	private static QueryResult queryInvalidSource() {
		QueryResult result=new QueryResult();
		try {
			QuerySpec queryspec=new QuerySpec();
			int objecthistoryindex=queryspec.addClassList(ObjectHistory.class, true);
			int lifecyclehistoryindex=queryspec.addClassList(LifeCycleHistory.class, true);
			int wtdocindex=queryspec.addClassList(WTDocument.class, true);
			int wtdocmasterindex=queryspec.addClassList(WTDocumentMaster.class,true);
			int stringdefindex=queryspec.addClassList(StringDefinition.class, true);
			int stringvalueindex=queryspec.addClassList(StringValue.class, true);
			SearchCondition objectHistorytowtdoc = new SearchCondition(ObjectHistory.class, IDA3A5,WTDocument.class, IDA2A2);
			SearchCondition objectHistoryToLifecycleHistory = new SearchCondition(ObjectHistory.class, IDA3B5,LifeCycleHistory.class, IDA2A2);
			SearchCondition wtdocmastertowtdoc = new SearchCondition(WTDocumentMaster.class, IDA2A2,WTDocument.class, IDA3MASTERREFERENCE);
			SearchCondition stringvaluetostringdef = new SearchCondition(StringValue.class, IDA3A6,StringDefinition.class, IDA2A2);
			SearchCondition stringvaluetodocmaster = new SearchCondition(StringValue.class, IDA3A4,WTDocumentMaster.class, IDA2A2);
			SearchCondition attrname=new SearchCondition(StringDefinition.class,StringDefinition.NAME,SearchCondition.EQUAL,KBConstants.KBSAP_IDX_IBA);
			SearchCondition attrvalue=new SearchCondition(StringValue.class,StringValue.VALUE,SearchCondition.EQUAL,TRIPLE_0);
			SearchCondition lcphase=new SearchCondition(LifeCycleHistory.class,LifeCycleHistory.ACTION,SearchCondition.EQUAL,ACTION);
			SearchCondition lcstate=new SearchCondition(LifeCycleHistory.class,LifeCycleHistory.STATE,SearchCondition.EQUAL,KBConstants.INVALID);
			queryspec.setAdvancedQueryEnabled(true);
			queryspec.appendWhere(objectHistorytowtdoc, new int[] {objecthistoryindex,wtdocindex});
			queryspec.appendAnd();
			queryspec.appendWhere(objectHistoryToLifecycleHistory,new int[] {objecthistoryindex,lifecyclehistoryindex});
			queryspec.appendAnd();
			queryspec.appendWhere(wtdocmastertowtdoc,new int[] {wtdocmasterindex,wtdocindex});
			queryspec.appendAnd();
			queryspec.appendWhere(stringvaluetostringdef,new int[] {stringvalueindex,stringdefindex});
			queryspec.appendAnd();
			queryspec.appendWhere(stringvaluetodocmaster,new int[] {stringvalueindex,wtdocmasterindex});
			queryspec.appendAnd();
			queryspec.appendWhere(attrname,new int[] {stringdefindex});
			queryspec.appendAnd();
			queryspec.appendWhere(attrvalue,new int[] {stringvalueindex});
			queryspec.appendAnd();
			queryspec.appendWhere(lcphase,new int[] {lifecyclehistoryindex});
			queryspec.appendAnd();
			queryspec.appendWhere(lcstate,new int[] {lifecyclehistoryindex});
			queryspec.appendAnd();
			Date date=new Date(System.currentTimeMillis());
			LOG.debug("Current date :: "+date);
			Date onedaybackdate=new Date(System.currentTimeMillis() - 24 * 3600 * 1000);
			LOG.debug("onedaybackdate :: "+onedaybackdate);
			Timestamp ts=new Timestamp(date.getTime());
			Timestamp onedaybackdatets=new Timestamp(onedaybackdate.getTime());
			LOG.debug("curresnt ts :: "+ts);
			LOG.debug("onedaybackdatets :: "+onedaybackdatets);

			queryspec.appendWhere(new SearchCondition(LifeCycleHistory.class,CREATESTAMPA2,
					SearchCondition.GREATER_THAN, onedaybackdatets), new int[] {lifecyclehistoryindex});
			queryspec.appendAnd();
			queryspec.appendWhere(new SearchCondition(LifeCycleHistory.class,CREATESTAMPA2,
					SearchCondition.LESS_THAN, ts), new int[] {lifecyclehistoryindex});
			result=PersistenceHelper.manager.find((StatementSpec)queryspec);
		}catch(WTException e) {
			LOG.error(e.getLocalizedMessage());
		}
		return result;

	}



}
