/* bcwti
 *
 * Copyright (c) 2010 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */
package com.ptc.netmarkets.search;

import org.w3c.dom.*;
import org.xml.sax.SAXException;
import org.apache.log4j.Logger;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.ParserConfigurationException;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.TreeSet;
import java.net.URI;
import java.net.URISyntaxException;
import java.io.IOException;
import java.io.Serializable;

import com.ptc.netmarkets.search.beans.AttributeInfoBean;
import com.ptc.netmarkets.search.utils.SearchUtils;
import com.ptc.netmarkets.search.utils.IMacroHelper;
import com.ptc.netmarkets.search.utils.SearchMacroHelper;
import com.ptc.windchill.enterprise.search.server.SearchHelper;
import wt.log4j.LogR;
import wt.util.WTProperties;
import wt.util.WTException;
import wt.util.WTContext;


public class ParseXML implements Serializable {
    private static Document document;
    private static final String COMPONENT_ID_TAG = "ComponentID";
    private static final String OBJECT_TYPE_TAG = "ObjectType";
    private static final String ID_TAG = "id";
    private static final String SEARCH_CRITERIA_ATTR_TAG = "SearchCriteriaAttributes";
    private static final String ATTRIBUTE_TAG = "Attributes";
    private static final String NAME_TAG = "Name";
    private static final String DISPLAY_NAME_TAG = "DisplayName";
    private static final String IS_SEARCHABLE_TAG = "IsSearchable";
    private static final String HELP_TEXT_TAG = "HelpText";
    private static final String SHORT_HELP_TEXT_TAG = "ShortHelpText";
    private static final String SEARCH_TERM_PRODUCER_TAG = "SearchTermProducer";
    private static final String ENUMERATION_PRODUCER_TAG = "EnumerationProducer";
    private static final String STRING_TYPE = "java.lang.String";

    private static String pickerAttributesURL = "pickerAttributes.xml";
    private static HashMap referenceAttributeMap = new HashMap();
    private static final Logger log;
    private static final String CLASNAME = ParseXML.class.getName();

    private static HashMap<String, ObjectInfoBeansMap> pickerAttributeMap;

    static {
        try {
            log = LogR.getLogger(CLASNAME);
            WTProperties wtp = WTProperties.getLocalProperties();
           // String wncurl=wtp.getProperty(WTProperties.SERVER_CODEBASE_PROPERTY);
          //  pickerAttributesURL = wncurl+"/pickerAttributes.xml";
            referenceAttributeMap = (HashMap) SearchHelper.getReferenceAttributeCache();
        }catch(Exception ex) {
            throw new ExceptionInInitializerError(ex);
        }
    }

    public static synchronized void parseFile(String containerRef) {
        if(pickerAttributeMap == null || pickerAttributeMap.size() == 0) {
            pickerAttributeMap = new HashMap<String,ObjectInfoBeansMap>();
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        /*    URI uri = null;
            try {
                uri = new URI(pickerAttributesURL);
            }catch (URISyntaxException ue) {
                log.debug(ue.getLocalizedMessage(), ue);
                return;
            }*/
            try {
                DocumentBuilder builder =  factory.newDocumentBuilder();
                System.out.println("path is " + pickerAttributesURL);
                document = builder.parse(WTContext.getContext().getResourceAsStream(pickerAttributesURL));

              //  document = builder.parse(pickerAttributesURL);

                NodeList nodeList = document.getElementsByTagName(COMPONENT_ID_TAG);
                if(nodeList == null) return;

                int nodeListLen = nodeList.getLength();
                for(int i=0;i<nodeListLen;i++) {
                    Element componentTag  = (Element)nodeList.item(i);
                    String componentId =getIdNodeValue(componentTag);

                    ObjectInfoBeansMap objectInfoBeansMap = new ObjectInfoBeansMap();

                    // get OBJECT_TYPE_TAG elements
                    NodeList objectList = componentTag.getElementsByTagName(OBJECT_TYPE_TAG);
                    if(objectList == null) continue;

                    // get SEARCH_CRITERIA_ATTR_TAG elements
                    int objectListLen = objectList.getLength();
                    String objectType = "";

                    for(int objectCounter=0;objectCounter<objectListLen;objectCounter++) {
                        Element objectTag = (Element)objectList.item(objectCounter);
                        objectType = getIdNodeValue(objectTag);

                        ArrayList arrList = new ArrayList();
                        NodeList searchCriteraList = objectTag.getElementsByTagName(SEARCH_CRITERIA_ATTR_TAG);
                        if(searchCriteraList == null) continue;

                        // get ATTRIBUTE_TAG elements
                        int searchCriteriaListLen = searchCriteraList.getLength();
                        for(int searchAttrCounter = 0;searchAttrCounter< searchCriteriaListLen;searchAttrCounter++) {
                            Element searchCriteriaTag = (Element)searchCriteraList.item(searchAttrCounter);
                            NodeList attrList = searchCriteriaTag.getElementsByTagName(ATTRIBUTE_TAG);

                            if(attrList == null) continue;

                            int attrListLen = attrList.getLength();
                            for(int attrCounter =0;attrCounter< attrListLen;attrCounter++) {
                                Node attributeNode = (Node)attrList.item(attrCounter);
                                NodeList attrChildList = attributeNode.getChildNodes();
                                if(attrChildList == null) continue;

                                int childListLen = attrChildList.getLength();

                                AttributeInfoBean aib = new AttributeInfoBean();
                                for(int childCounter=0;childCounter< childListLen;childCounter++) {
                                    Node n = attrChildList.item(childCounter);
                                    if(n.getNodeName().equals(NAME_TAG)) {
                                        aib.setLogical(getNodeValue(n));
                                    }else if(n.getNodeName().equals(DISPLAY_NAME_TAG)) {
                                        aib.setDisplay(getNodeValue(n));
                                    }else if(n.getNodeName().equals(IS_SEARCHABLE_TAG)) {
                                        aib.setIsSearabhle(getNodeValue(n,"true"));
                                    }else if(HELP_TEXT_TAG.equals(n.getNodeName())) {
                                        aib.setHelpText(getNodeValue(n));
                                    }else if(SHORT_HELP_TEXT_TAG.equals(n.getNodeName())) {
                                        aib.setShortHelpText(getNodeValue(n));
                                    }else if(SEARCH_TERM_PRODUCER_TAG.equals(n.getNodeName())) {
                                        aib.setSearchTermProducer(getNodeValue(n));
                                    }else if(ENUMERATION_PRODUCER_TAG.equals(n.getNodeName())){
                                        aib.setEnumerationProducer(getNodeValue(n));
                                    }
                                }

                                aib.setType(STRING_TYPE); // By default set type to String Type

                                String logicalID = (String)aib.getLogical();
                                if(referenceAttributeMap.containsKey(logicalID) ) {
                                    String[] pickerValues = (String[])referenceAttributeMap.get(logicalID);
                                    int arrLen = pickerValues.length;
                                    aib.setAsPicker();
                                    aib.setPickerObjectType(pickerValues[0]);
                                    aib.setPickerDisplayAttribute(pickerValues[1]);
                                    if(arrLen >=4 ) {
                                        aib.setPickerType(pickerValues[3]);
                                    }
                                    if(arrLen >=7) {
                                        aib.setPickerRef(pickerValues[6]); // String at index 6 tells the type of picker, whether user picker or context picker etc..
                                    }
                                }
                                arrList.add(aib);
                            }
                        }
                        //Fixing blocking SPR  1456689 -- Any object type defined in PickerAttributes.xml, which doesn't
                        //exist in the Windchill codebase was throwing InfoNotFoundException here.
                        //e.g. AXLContext type in suma, wasn't available in the PDML-PJL system, however since there is no
                        //separate pickerAttributes.xml file for Suma which can merge only when SUma is installed, the common
                        //file which would be installed with any configuration of Windchill had this entry, and getting parsed here, the
                        //objectType was getting added in the Map, and later on getSearchableAttributesBy Type task was getting invoked
                        //on this type throwing the Info Resource Doesnt exist error. hence adding a validation for each object type here.
                        //Since this method gets called only once, the performance doesn't get hampered in the subsequent calls
                        boolean isTypeValidated = SearchUtils.validateWindchillTypeExistsInCodebase(objectType);
                        if(isTypeValidated){
                            objectInfoBeansMap.add(objectType,arrList);

                            IMacroHelper macroHelper = new SearchMacroHelper(containerRef);
                            macroHelper.registerExpression(objectType);

                            // Get the list of unique object types so that we can invoke task against only those object types that are present in pickerAttributes.xml
                            // TODO check whey we don't do expandMacro here and do it in localizeData method
                            String tempObjectType = SearchUtils.expandMacro(objectType,containerRef);
                        }else{
                            log.debug("ObjectType -- " + objectType + " doesn't exist in this Windchill codebase hence ignoring.");
                        }
                    }

                    //putting in hash map for particular component Id
                    pickerAttributeMap.put(componentId,objectInfoBeansMap);
                }
            }catch(SAXException sxe) {
                // Error generated during parsing
                Exception  x = sxe;
                if (sxe.getException() != null)
                    x = sxe.getException();
                log.debug("ParseXML.parseFile: SAXException while parsing pickerAttriubtes.xml: "+x.getMessage());
                StackTraceElement[] stackTraceArray = x.getStackTrace();
                StringBuilder sb = new StringBuilder();
                for(StackTraceElement stackTrace: stackTraceArray ) {
                    sb.append(stackTrace.toString());
                }
                log.debug("ParseXML.parseFile: StackTrace of error is: "+sb.toString());
            } catch(ParserConfigurationException pce) {
                log.debug("ParseXML.parseFile: ParserConfigurationException while parsing pickerAttriubtes.xml: "+pce.getMessage());
                StackTraceElement[] stackTraceArray = pce.getStackTrace();
                StringBuilder sb = new StringBuilder();
                for(StackTraceElement stackTrace: stackTraceArray ) {
                    sb.append(stackTrace.toString());
                }
                log.debug("ParseXML.parseFile: StackTrace of error is: "+sb.toString());

            }catch(IOException ioe) {
                log.debug("ParseXML.parseFile: IOException while parsing pickerAttriubtes.xml: "+ioe.getMessage());
                StackTraceElement[] stackTraceArray = ioe.getStackTrace();
                StringBuilder sb = new StringBuilder();
                for(StackTraceElement stackTrace: stackTraceArray ) {
                    sb.append(stackTrace.toString());
                }
                log.debug("ParseXML.parseFile: StackTrace of error is: "+sb.toString());

            }
        }
        //return pickerAttributeMap;
    }

    public static ArrayList<AttributeInfoBean> getAttributeInfoBeanList(String componentId, String objectType, String containerRef) throws WTException {
        if(pickerAttributeMap == null || pickerAttributeMap.size() == 0) {
            throw new WTException("You need to parse the XML file first");
        }
        ArrayList<AttributeInfoBean> attributeInfoBeanList = null;
//        HashMap<String, ArrayList<AttributeInfoBean>> attributeBeanMap = pickerAttributeMap.get(componentId);
        HashMap<String, ArrayList<AttributeInfoBean>> attributeBeanMap = null;
        ObjectInfoBeansMap objectInfoBeanMap = pickerAttributeMap.get(componentId);
        if(objectInfoBeanMap != null) {
            attributeBeanMap = objectInfoBeanMap.getObjectTypeMap();
        }
        attributeInfoBeanList = getAttributeInfoBeanList(objectType, attributeBeanMap, containerRef);
//        // No AttributeInfoBean list for this componentId, try it in default id for pickers i.e pickerSerch
//        if(attributeInfoBeanList == null || attributeInfoBeanList.size() == 0) {
//            attributeBeanMap = pickerAttributeMap.get(DEFAULT_COMP_ID);
//            attributeInfoBeanList = getAttributeInfoBeanList(objectType,attributeBeanMap,containerRef);
//        }
        if(attributeInfoBeanList == null || attributeInfoBeanList.size() == 0) {
            return null;
        }
        ArrayList<AttributeInfoBean> clonedList = null;
        // get deep copy of AttributeInfoBeanList so that we don't mess with original parsed XML file.
        try {
            clonedList= (ArrayList<AttributeInfoBean>)SearchUtils.getDeepCopy(attributeInfoBeanList);
        }catch(Exception ex) {
            throw new WTException(ex);
        }
        return clonedList;
    }

    public static HashMap<String, ArrayList<AttributeInfoBean>> getObjectTypeMap(String componentId) throws WTException {
        if(pickerAttributeMap == null || pickerAttributeMap.size() == 0) {
            throw new WTException("You need to parse the XML file first");
        }
        HashMap<String, ArrayList<AttributeInfoBean>> attributeBeanMap = null;
        ObjectInfoBeansMap objectInfoBeanMap = pickerAttributeMap.get(componentId);
        if(objectInfoBeanMap != null) {
            attributeBeanMap = objectInfoBeanMap.getObjectTypeMap();
        }
        HashMap<String, ArrayList<AttributeInfoBean>> clonedAttributeBeanMap = null;
        try {
            clonedAttributeBeanMap= (HashMap<String, ArrayList<AttributeInfoBean>>)SearchUtils.getDeepCopy(attributeBeanMap);
        }catch(Exception ex) {
            throw new WTException(ex);
        }
        return clonedAttributeBeanMap;
    }


    private static String getNodeValue(Node node, String defaultValue) {
        String nodeValue = defaultValue;
        if(node.hasChildNodes()) {
            Node childNode = node.getFirstChild();
            nodeValue= childNode.getNodeValue().trim();
        }
        return nodeValue;
    }

    private static String getNodeValue(Node node) {
        return getNodeValue(node, "");
    }

    private static ArrayList<AttributeInfoBean> getAttributeInfoBeanList(String objectType,HashMap<String, ArrayList<AttributeInfoBean>> attributeBeanMap, String containerRef) {
        ArrayList<AttributeInfoBean> attributeInfoBeanList = null;
        if(attributeBeanMap != null) {
            if(attributeBeanMap.containsKey(objectType)) {
                attributeInfoBeanList = attributeBeanMap.get(objectType);
            }
            if(attributeInfoBeanList == null || attributeInfoBeanList.size() == 0) {
                // try with objectType after inserting macro
                String tempObjectType = SearchUtils.insertMacro(objectType, containerRef);
                if(attributeBeanMap.containsKey(tempObjectType)) {
                    attributeInfoBeanList = attributeBeanMap.get(tempObjectType);
                }
            }
        }
        return attributeInfoBeanList;
    }

    private static String getIdNodeValue(Element element) {
        String value="";
        if(element.hasAttributes()) {
            NamedNodeMap nnm = element.getAttributes();
            Node attrNode = nnm.getNamedItem(ID_TAG);
            if(attrNode.getNodeType() == Node.ATTRIBUTE_NODE) {
                value = attrNode.getNodeValue();
            }
        }
        return value;
    }
}// class ends