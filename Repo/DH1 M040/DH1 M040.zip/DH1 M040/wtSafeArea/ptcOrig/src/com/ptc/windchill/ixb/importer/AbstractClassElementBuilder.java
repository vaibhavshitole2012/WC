/* bcwti
 *
 * Copyright (c) 2010 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */
package com.ptc.windchill.ixb.importer;

import java.rmi.RemoteException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import wt.enterprise.EnterpriseHelper;
import wt.facade.ixb.IxbHndHelperConstants;
import wt.filter.iba.OptionExclusionReference;
import wt.iba.definition.AttributeDefinition;
import wt.iba.definition.litedefinition.AttributeDefDefaultView;
import wt.iba.definition.service.IBADefinitionCache;
import wt.iba.definition.service.IBADefinitionHelper;
import wt.iba.value.IntegerValue;
import wt.inf.container.WTContainerHelper;
import wt.inf.container.WTContainerRef;
import wt.ixb.publicforhandlers.IxbHndHelper;
import wt.lifecycle.LifeCycleHelper;
import wt.lifecycle.LifeCycleTemplate;
import wt.lifecycle.PhaseTemplate;
import wt.log4j.LogR;
import wt.org.WTOrganization;
import wt.preference.PreferenceClient;
import wt.units.FloatingPointWithUnits;
import wt.util.WTException;
import wt.util.WTMessage;
import com.ptc.core.lwc.common.view.AttributeDefinitionReadView;
import com.ptc.core.lwc.common.view.TypeDefinitionReadView;
import com.ptc.core.lwc.server.TypeDefinitionServiceHelper;
import com.ptc.core.meta.common.AttributeTypeIdentifier;
import com.ptc.core.meta.common.DataTypesUtility;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.impl.WCTypeIdentifier;
import com.ptc.windchill.ixb.importer.part.WTPartElementBuilder;
import com.ptc.windchill.ixb.util.ImportXlsHelper;
import com.ptc.windchill.option.service.OptionUtility;

/**
 * Shares common attributes and methods to concrete class element builders.
 *
 * <BR>
 * <BR>
 * <B>Supported API: </B>false <BR>
 * <BR>
 * <B>Extendable: </B>false
 *
 * @version 1.0
 **/
public abstract class AbstractClassElementBuilder extends AbstractElementBuilder implements ClassElementBuilder {
    private static final String RESOURCE = "com.ptc.windchill.ixb.importer.importerResource";

    private static final String CLASSNAME = AbstractClassElementBuilder.class.getName();

    private DocumentBuilder documentBuilder;

    private Set<String> ibaNames;

    private Set<String> optionNames;

    protected static Set<String> NON_IBA_COLUMN_NAME_SET = new HashSet<String>();

    protected static final String DEFAULT_UNIT = "Default Unit";

    protected static final String STATE = "State";

    protected static final String VERSION = "Revision";

    protected static final String VIEW = "View";

    protected static final String NAME = "Name";

    protected static final String NUMBER = "Number";

    protected static final String FOLDER_PATH = "Location";

    protected static final String CONTAINER = "Container";

    protected static final String ORGANIZATION_ID = "Organization ID";

    protected static final String LIFECYCLE = "Lifecycle";

    protected static final String SECURITY_LABELS = "Security Labels";

    private static final Logger logger = LogR.getLogger(CLASSNAME);

    private static final String SECURITY_LABELS_SCHEME_SEPARATOR = ",";

    private static final String SECURITY_LABELS_NAME_VALUE_SEPARATOR = "=";

    public static final String IBA_VALUE_SEPARATOR = "\\|";

    public static final String DUMMYNUMBER_GENRATED = "dummyNumber_Genrated";

    /**
     * Initializes the builder. A builder must be initialized before being used.
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     *
     * @param prolog
     *            A prolog typically contains additional information about an ImportSheet, in the form of name value
     *            pairs.
     * @param header
     *            A header contains metadata about an ImportSheet - specifically, these are the column headers of the
     *            sheet.
     * @param sessionData
     *            session data
     * @exception wt.util.WTException
     **/
    @Override
    public void initialize(Map prolog, List header, SessionData sessionData) throws WTException {
        super.initialize(prolog, header, sessionData);
        try {
            this.documentBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        } catch (ParserConfigurationException e) {
            throw new WTException(e);
        }

        this.ibaNames = new HashSet<String>();
        this.optionNames = new HashSet<String>();
        WTContainerRef containerRef = sessionData.getContainerRef();
        for (Iterator i = header.iterator(); i.hasNext();) {
            String columnName = (String) i.next();
            if (columnName == null || columnName.trim().length() == 0) {
                continue;
            }
            if (columnName.startsWith("(") && columnName.endsWith(")")) {
                continue;
            }
            if (NON_IBA_COLUMN_NAME_SET.contains(columnName)) {
                continue;
            }
            if (OptionUtility.getOption(columnName, containerRef) != null) {
                this.optionNames.add(columnName);
            } else {
                this.ibaNames.add(columnName);
            }
        }
    }

    /**
     * Creates a new import element for the object represented by the row data.
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     *
     * @param rowData
     *            A row that represents an object. The data is in the form of a map where keys are attribute names
     *            corresponding to the table header column names, and values are string value of attributes.
     * @return ImportElement
     * @exception wt.util.WTException
     **/
    public abstract ImportElement newElement(Map rowData) throws WTException;

    /**
     * Creates a defaultUnit element and adds to the parent
     *
     * @param doc
     *            dom document
     * @param parent
     *            parent element to which the new element will be added to
     * @param rowData
     *            a map that contains key/value pairs for current context object
     * @throws WTException
     */
    protected void addDefaultUnitElement(Document doc, Element parent, Map rowData) throws WTException {
        Element defaultUnitElement = doc.createElement(ImportHndHelper.XML_TAG_DEFAULT_UNIT);
        String defaultUnit = (String) rowData.get(DEFAULT_UNIT);
        if (defaultUnit == null || defaultUnit.trim().length() == 0) {
            defaultUnitElement.appendChild(doc.createTextNode(ImportHndHelper.DEFAULT_QUANTITY_UNIT));
        } else {
            // TODO: is there a way to find the default unit? OIR?
        	//removed the toLowerCase for the SPR-2061246. So the default unit specified in the excel would be case sensitive.
            defaultUnitElement.appendChild(doc.createTextNode(defaultUnit.trim()));
        }
        parent.appendChild(defaultUnitElement);
    }

    /**
     * Creates a domainName element and adds to the parent
     *
     * @param doc
     *            dom document
     * @param parent
     *            parent element to which the new element will be added to
     * @param rowData
     *            a map that contains key/value pairs for current context object
     * @throws WTException
     */
    protected void addDomainNameElement(Document doc, Element parent, Map rowData) throws WTException {
        Element domainNameElement = doc.createElement(IxbHndHelper.XML_ATTR_DOMAIN);
        String domainName = getSessionData().getContainerRef().getReferencedContainer().getDefaultDomain().getName();
        if (!domainName.startsWith(ImportHndHelper.SEPARATOR_STRING))
            domainName = ImportHndHelper.SEPARATOR_STRING + domainName;
        domainNameElement.appendChild(doc.createTextNode(domainName.trim()));
        parent.appendChild(domainNameElement);
    }



    /**
     * Creates an externalTypeId element and adds to the parent
     *
     * @param doc
     *            dom document
     * @param parent
     *            parent element to which the new element will be added to
     * @param rowData
     *            a map that contains key/value pairs for current context object
     * @throws WTException
     */
    protected void addExternalTypeIdElement(Document doc, Element parent, Map rowData) throws WTException {
        String value = (String) rowData.get(TYPE);
        if (null != value && value.trim().length() > 0) {
            Element element = doc.createElement(IxbHndHelper.XML_EXTERNAL_TYPE_ID);
            String externalTypeId = ImportHndHelper.getExternalTypeId(value);
            logger.debug("makeExternalTypeIdElement(): id=" + value + " external id=" + externalTypeId);
            element.appendChild(doc.createTextNode(externalTypeId));
            parent.appendChild(element);
        }
    }

    /**
     * Creates a folderPath element and adds to the parent
     *
     * @param doc
     *            dom document
     * @param parent
     *            parent element to which the new element will be added to
     * @param rowData
     *            a map that contains key/value pairs for current context object
     * @throws WTException
     */
    protected void addFolderPathElement(Document doc, Element parent, Map rowData) throws WTException {

        String folderPath = (String) rowData.get(FOLDER_PATH);
        String PartNumber = (String) rowData.get(NUMBER);


        if (folderPath == null || folderPath.trim().length() == 0) {
            folderPath = getSessionData().getDirectoryPathCache();
        }
        if (folderPath == null || folderPath.trim().length() == 0) {
             folderPath = getSessionData().getContainerRef().getReferencedContainer().getDefaultCabinet().getFolderPath();
        }
        if(getSessionData().isPreview() && !folderPath.startsWith("/Default/"))
        {
        	if(!folderPath.equals("/Default")){
        		String fileName = getSessionData().getFileName();
                String sheetName = getSessionData().getSheetName();
                String rowNumber = getSessionData().getRowNumber();
                String message = new WTMessage(RESOURCE,importerResource.MSG_SHEET_INVALID_LOCATION, new Object[] {folderPath,PartNumber}).getLocalizedMessage(getSessionData().getJobLocale());
                ImportXlsHelper.reportError(ImportXlsHelper.getLocaleWarningStr(), fileName, sheetName, rowNumber, message);
        	}
        }
        Element folderPathElement = doc.createElement(IxbHndHelper.XML_ATTR_FOLDER);
        folderPathElement.appendChild(doc.createTextNode(folderPath));
        parent.appendChild(folderPathElement);
    }

    /**
     * <Purpose> Creates all (except "PartClassification") iba elements / standard attribute elements and adds to the parent.
     *
     * @param doc - dom document
     * @param parent - parent element to which the new elements will be added to
     * @param rowData - a map that contains key/value pairs for current context object
     * @throws WTException
     */
    protected void addBussinessFieldElements(Document doc, Element parent, Map rowData) throws WTException {

    	String objectTypeStr = getObjectTypeStr(rowData);
    	Set<String> clssificationIBA = new HashSet<String>();
    	Map<String, Set> classificationMap = new HashMap<String, Set>();
        for (String ibaName : getIbaNames()) {
        	AttributeTypeIdentifier attrubuteTypeIdentifier =   TypeDefinitionServiceHelper.service.getAttributeTypeIdentifier(ibaName, objectTypeStr);
        	if(attrubuteTypeIdentifier == null ){
        		clssificationIBA.add(ibaName);
        		continue;
        	}
        	AttributeDefinitionReadView attributeDefinitionReadView = TypeDefinitionServiceHelper.service.getAttributeDefView(attrubuteTypeIdentifier);
        	boolean isClassificationIBA = ImportHndHelper.isClassificationConstrained(attributeDefinitionReadView);

            String ibaType = ImportHndHelper.getIbaSdaTypeByPath(ibaName,objectTypeStr, getSessionData());
            String ibaValue = (String) rowData.get(ibaName);
            String dataTypeQlifier = ImportHndHelper.getDatatypeQualifier(attributeDefinitionReadView);

            //if IBA is classification node then get all the IBAs attached with node.
            if(isClassificationIBA){
            	String[] ibaValues = ibaValue.split(IBA_VALUE_SEPARATOR);
                for (String value : ibaValues) {
                	 Set<AttributeTypeIdentifier> classificationNodeIBA = new HashSet<AttributeTypeIdentifier>();
     	    		TypeDefinitionReadView typeView = TypeDefinitionServiceHelper.service.getTypeDefView(com.ptc.core.lwc.common.AttributeTemplateFlavor.LWCSTRUCT, ImportHndHelper.NAMESPACE, value);
     	    		if (typeView != null) {
     	    			classificationNodeIBA.addAll(typeView.getAttributeTypeIdentifiers());
     	    		}
     	    		Set<String> classIBA = new HashSet<String>();
     	    		Iterator itr = classificationNodeIBA.iterator();
     	    		while(itr.hasNext()){
     	    			AttributeTypeIdentifier atrs = (AttributeTypeIdentifier) itr.next();
     	    			String atrName = atrs.getAttributeName();
     	    			classIBA.add(atrName); 
     	    		}
     	    		classificationMap.put(value, classIBA);
                }

            }

            if (ibaValue != null && ibaValue.length() > 0) {
            	addBusinessFieldElement(doc, parent, ibaName, ibaValue, ibaType,  rowData,"type", dataTypeQlifier, objectTypeStr);
            }
        }
        //process all classification IBAs
        for (String ibaName : clssificationIBA) {
        	try {
        		boolean processFlag = false;
        		Set<String> classificationNodes = classificationMap.keySet();
        		String ibaValue = (String) rowData.get(ibaName);
        		for (String classificationNode : classificationNodes) {
        			Set<String> setVal = classificationMap.get(classificationNode);
        			if(setVal.contains(ibaName)){
        					processFlag =true;
        				break;
        			}
        		}
        		//Fix for SPR 2246514: When part is reclassified, the attributes from earlier classification remains on Part as ad-hoc attribute. 
        		//This ad-hoc attribute should be taken care while import from spreadsheet. So adding  attributes as ad-hoc either it is a classification
        		//attribute or has a valid AttributeDefDefaultView.
        		AttributeDefDefaultView attrDef = IBADefinitionHelper.service.getAttributeDefDefaultViewByPath(ibaName);
                if(processFlag || attrDef!=null ){
				
				  String attDataTypeDef =ImportHndHelper.getDatatype(attrDef.getAttributeDefinitionClassName());
	                
				  IBADefinitionCache IBA_DEF_CACHE = IBADefinitionCache.getIBADefinitionCache();
				  AttributeDefinition attDef = IBA_DEF_CACHE.getAttributeDefinition( ibaName );
				  String datatypeQualifier = ImportHndHelper.getDatatypeQualifier(attDef);
	                
				  String defClassName = attDataTypeDef.substring(attDataTypeDef.lastIndexOf(".") + 1);
				  defClassName = defClassName.replaceFirst("Definition", "Value");
				  String attDataType =ImportHndHelper.getDatatype(defClassName);
				  if(ibaValue!= null && !ibaValue.isEmpty())
				    addBusinessFieldElement(doc, parent, ibaName, ibaValue, attDataType,  rowData, "ad_hoc", datatypeQualifier,objectTypeStr);
        		}else if(ibaValue!= null && !ibaValue.isEmpty()){
        			throw new WTException(RESOURCE, importerResource.ERROR_IBA_ATTRIBUTE_NOT_FOUND, new Object[] {ibaName});
        		}
			} catch (RemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
    }


    /**
     * Creates an iba or excludedIba element and adds to the parent
     *
     * @param doc
     *            dom document
     * @param parent
     *            parent element to which the new element will be added to
     * @param ibaPath
     *            IBA path
     * @param ibaValue
     *            IBA value as a string
     * @param ibaType
     *            unqualified IBA value class name (for example, "BooleanValue")
     * @param isExcludedIba
     *            a boolean flag indicating whether the element is an iba or excludedIba
     * @throws WTException
     */

    protected void addBusinessFieldElement(Document doc, Element parent, String ibaPath, String ibaValue,
            String ibaType, Map rowData, String category, String datatypeQualifier, String objectTypeStr) throws WTException {
    	String clientName = PreferenceClient.WINDCHILL_CLIENT_NAME;

        if (logger.isTraceEnabled())
            logger.trace("ibaType: " + ibaType + " ibaValue: " + ibaValue);
        if (ibaType.equals(IntegerValue.class.getSimpleName())) {
            ibaValue = toIntegerString(ibaValue);
            if (logger.isTraceEnabled())
                logger.trace("new ibaValue: " + ibaValue);
        }

        Locale locale = getSessionData().getJobLocale();

        Element ibaElement = doc.createElement(IxbHndHelper.XML_BUSINESS_FIELD);

        Element ibabusinessFieldIDElement = doc.createElement(IxbHndHelper.XML_BUSINESS_FIELD_ID);

        Element ibasolutionElement = doc.createElement(IxbHndHelper.XML_SOLUTION);
        ibasolutionElement.appendChild(doc.createTextNode(clientName));
        ibabusinessFieldIDElement.appendChild(ibasolutionElement);

        if(category.equals("ad_hoc")){
        	Element ibanamespaceElement = doc.createElement(IxbHndHelper.XML_NAMESPACE);

            Element ibacategoryElement = doc.createElement(IxbHndHelper.XML_CATEGORY);
            ibacategoryElement.appendChild(doc.createTextNode(category));
            ibanamespaceElement.appendChild(ibacategoryElement);

//            Element ibanameElement = doc.createElement(IxbHndHelper.XML_NAMESPACE_NAME);
//            ibanameElement.appendChild(doc.createTextNode(ibaPath));
//            ibanamespaceElement.appendChild(ibanameElement); 

            ibabusinessFieldIDElement.appendChild(ibanamespaceElement);

            Element ibanameElement1 = doc.createElement(IxbHndHelper.XML_BUSINESS_FIELD_ID_NAME);
            ibanameElement1.appendChild(doc.createTextNode(ibaPath));
            ibabusinessFieldIDElement.appendChild(ibanameElement1);

            ibaElement.appendChild(ibabusinessFieldIDElement); 
        	
        }else{
        	Element ibanamespaceElement = doc.createElement(IxbHndHelper.XML_NAMESPACE);

            Element ibacategoryElement = doc.createElement(IxbHndHelper.XML_CATEGORY);
            ibacategoryElement.appendChild(doc.createTextNode(category));
            ibanamespaceElement.appendChild(ibacategoryElement);

            Element ibanameElement = doc.createElement(IxbHndHelper.XML_NAMESPACE_NAME);
            ibanameElement.appendChild(doc.createTextNode(objectTypeStr));
            ibanamespaceElement.appendChild(ibanameElement);

            ibabusinessFieldIDElement.appendChild(ibanamespaceElement);

            Element ibanameElement1 = doc.createElement(IxbHndHelper.XML_BUSINESS_FIELD_ID_NAME);
            ibanameElement1.appendChild(doc.createTextNode(ibaPath));
            ibabusinessFieldIDElement.appendChild(ibanameElement1);

            ibaElement.appendChild(ibabusinessFieldIDElement);
        }
        

        Element ibadatatypeElement1 = doc.createElement(IxbHndHelper.XML_DATATYPE);
        ibadatatypeElement1.appendChild(doc.createTextNode(ibaType));
        ibaElement.appendChild(ibadatatypeElement1);

        String[] values = ibaValue.split(IBA_VALUE_SEPARATOR);
        for (String value : values) {
        	if(ibaType.equals("wt.units.FloatingPointWithUnits") || ibaType.equals("com.ptc.core.meta.common.FloatingPoint")){
        		try {
        		if( ibaType.equals("wt.units.FloatingPointWithUnits")){
        			FloatingPointWithUnits floatingPointUnit;

						floatingPointUnit = DataTypesUtility.toFloatingPointWithUnits(value, locale);

        				value = floatingPointUnit.getValue()+ImportHndHelper.UFID_SEPARATOR+floatingPointUnit.getPrecision()+ImportHndHelper.UFID_SEPARATOR+floatingPointUnit.getUnits();
        		}
        		if( ibaType.equals("com.ptc.core.meta.common.FloatingPoint")){
        			FloatingPointWithUnits floatingPointUnit = DataTypesUtility.toFloatingPointWithUnits(value, locale);
    				value = floatingPointUnit.getValue()+ImportHndHelper.UFID_SEPARATOR+floatingPointUnit.getPrecision();
        		}
        		} catch (ParseException e) {
					// TODO Auto-generated catch block
        			throw new WTException(e);
				}
        	}
        	if(ibaType.equals("com.ptc.core.meta.common.Hyperlink")){
    			if(value != null && !value.isEmpty()){
        			if(value.endsWith(")") && value.contains("(")){
        				StringTokenizer tocken = new StringTokenizer(value, "(");
        				String url = (String) tocken.nextElement();
        				String val2 = (String) tocken.nextElement();
        				String lableUrl = val2.replace(")", "");
        				value = url+"|"+lableUrl;
        			}
    			}
    		}
        	Element ibavalueElement1 = doc.createElement(IxbHndHelper.XML_VALUE);
            ibavalueElement1.appendChild(doc.createTextNode(value));
            ibaElement.appendChild(ibavalueElement1);
        }
        if(datatypeQualifier != null && !datatypeQualifier.isEmpty()){
        	if(!category.equals("ad_hoc")){
        	Element ibavalueElement1 = doc.createElement(IxbHndHelper.XML_DATATYPE_QUALIFIER);
            ibavalueElement1.appendChild(doc.createTextNode(datatypeQualifier));
            ibaElement.appendChild(ibavalueElement1);
        	}else{
    				Element ibavalueElement1 = doc.createElement(IxbHndHelper.XML_DATATYPE_QUALIFIER);
    	            ibavalueElement1.appendChild(doc.createTextNode(datatypeQualifier));
    	            ibaElement.appendChild(ibavalueElement1);
        	}
        }
        parent.appendChild(ibaElement);
    }

    /**
     * Converts the string representing an integer IBA value to a real integer string by getting rid of decimal points,
     * etc.
     */
    private String toIntegerString(String number) throws WTException {
        if (number == null || number.trim().length() == 0)
            return number;
        try {
            Double value = Double.valueOf(number);
            double double_value = value.doubleValue();
            if (double_value > Long.MAX_VALUE || double_value < Long.MIN_VALUE) {
                throw new WTException("Number out of range: " + number + " [" + Long.MIN_VALUE + ", " + Long.MAX_VALUE
                        + "]");
            }
            return String.valueOf(value.longValue());
        } catch (NumberFormatException e) {
            throw new WTException(e);
        }
    }

    /**
     * Creates a lifecycleInfo element and adds to the parent. The element contains lifecycleTemplateName and
     * lifecycleState.
     *
     * @param doc
     *            dom document
     * @param parent
     *            parent element to which the new element will be added to
     * @param rowData
     *            a map that contains key/value pairs for current context object
     * @throws WTException
     */
    protected void addLifeCycleInfoElement(Document doc, Element parent, Map rowData) throws WTException {
        Element lifecycleInfoElement = doc.createElement(ImportHndHelper.XML_TAG_LIFECYCLEINFO);
        String typeId = (String) rowData.get(TYPE);
        String state = (String) rowData.get(STATE);
        String containerPath = (String) rowData.get(CONTAINER);
        if (containerPath == null || containerPath.trim().length() == 0) {
            containerPath = WTContainerHelper.getPath(getSessionData().getContainerRef());
        }
        // Call: 7771174 support for specifying lifecycle template in spreadsheet.
        // previously, we were retrieving the lifecycle template name from OIRs using simple assumptions.
        // these don't hold when more sophisticated OIRs with attribute value
        // based logic maybe involved.
        // the IXB framework bypasses OIRs so skipping this here in the spreadsheet code won't allow
        // for it to happen in a different place. the workaround is to allow customers to specify the
        // lifecycle template name directly in the spreadsheet.
        String lifecycleTemplateName = (String) rowData.get(LIFECYCLE);
        LifeCycleTemplate lifeCycleTemplate = null;
        if (lifecycleTemplateName == null || lifecycleTemplateName.trim().length() == 0) {
        	lifeCycleTemplate = ImportHndHelper.getLifecycleTemplate(containerPath, typeId, getSessionData());
        	lifecycleTemplateName = lifeCycleTemplate.getName();
        	//Adding life cycle state if user not provided the state in to spreadsheet.
        	if(state == null || state.isEmpty()){
	        	Vector phaseTemplates  = LifeCycleHelper.service.getPhaseTemplates(lifeCycleTemplate);
	        	PhaseTemplate phaseTemplate = (PhaseTemplate) phaseTemplates.firstElement();
	        	state = phaseTemplate.getPhaseState().toString();  
        	}

        }
        boolean hasLCT = lifecycleTemplateName != null && lifecycleTemplateName.trim().length() > 0;
        boolean hasLCS = state != null && state.trim().length() > 0;

        if (!hasLCT && !hasLCS) {
            return;
        }

        if (hasLCT) {
            Element lifecycleTemplateNameElement = doc.createElement(ImportHndHelper.XML_TAG_LIFECYCLE_TEMPLATE_NAME);
            lifecycleTemplateNameElement.appendChild(doc.createTextNode(lifecycleTemplateName));
            lifecycleInfoElement.appendChild(lifecycleTemplateNameElement);
        }

        if (hasLCS) {

            Element lifecycleStateElement = doc.createElement(ImportHndHelper.XML_TAG_LIFECYCLE_STATE);
            lifecycleStateElement.appendChild(doc.createTextNode(state));
            lifecycleInfoElement.appendChild(lifecycleStateElement);
        }

        parent.appendChild(lifecycleInfoElement);
    }

    /**
     * Creates a name element and adds to the parent
     *
     * @param doc
     *            dom document
     * @param parent
     *            parent element to which the new element will be added to
     * @param rowData
     *            a map that contains key/value pairs for current context object
     * @throws WTException
     */
    protected void addNameElement(Document doc, Element parent, Map rowData) throws WTException {
        Element nameElement = doc.createElement(IxbHndHelper.XML_ATTR_NAME);
        String name = (String) rowData.get(NAME);
        nameElement.appendChild(doc.createTextNode(name));
        parent.appendChild(nameElement);
    }

    /**
     * Creates a number element and adds to the parent
     *
     * @param doc
     *            dom document
     * @param parent
     *            parent element to which the new element will be added to
     * @param rowData
     *            a map that contains key/value pairs for current context object
     * @throws WTException
     */
    protected void addNumberElement(Document doc, Element parent, Map rowData) throws WTException {
    	 String number = (String) rowData.get(NUMBER);
         if (number == null || number.trim().length() == 0) {
             TypeIdentifier typeId = ImportHndHelper.getTypeIdentifier((String) rowData.get(TYPE));
             WTContainerRef targetContainerRef = getSessionData().getContainerRef();
             boolean isAutoNumber = EnterpriseHelper.isAutoNumber(typeId, targetContainerRef);
             if (!isAutoNumber) { // this should never happen since it's already been validated
                 throw new WTException(RESOURCE, importerResource.MSG_MISSING_NUMBER, new Object[] {
                         typeId.getTypename(), targetContainerRef.getName() });
             }
             if(getSessionData().isPreview()){
             	number = DUMMYNUMBER_GENRATED;
             	logger.debug("Number not set, setting dummy number for preview step In Import will generate autonumber " + typeId.getTypename() + ", obtained number: "
                     + number);
             }
             else{
//             	number = EnterpriseHelper.getNumber(typeId, targetContainerRef);
            	 number = DUMMYNUMBER_GENRATED;
             	logger.debug("Number not set, using autonumber for type " + typeId.getTypename() + ", obtained number: "
                     + number);
             }
         }
         Element numberElement = doc.createElement(IxbHndHelper.XML_ATTR_NUMBER);
         numberElement.appendChild(doc.createTextNode(number));
         parent.appendChild(numberElement);

    }

    /**
     * Creates an objectContainerPath element and adds to the parent
     *
     * @param doc
     *            dom document
     * @param parent
     *            parent element to which the new element will be added to
     * @param rowData
     *            a map that contains key/value pairs for current context object
     * @throws WTException
     */
    protected void addObjectContainerPathElement(Document doc, Element parent, Map rowData) throws WTException {
        String containerPath = WTContainerHelper.getPath(getSessionData().getContainerRef());
        Element objectContainerPathElement = doc.createElement(IxbHndHelper.XML_TAG_CONTAINER_PATH);
        objectContainerPathElement.appendChild(doc.createTextNode(containerPath));
        parent.appendChild(objectContainerPathElement);
    }

    /**
     * Creates an empty ObjectID element and adds to the parent
     *
     * @param doc
     *            dom document
     * @param parent
     *            parent element to which the new element will be added to
     * @param rowData
     *            a map that contains key/value pairs for current context object
     * @throws WTException
     */
    protected void addObjectIDElement(Document doc, Element parent, Map rowData) throws WTException {
        Element objectIDElement = doc.createElement(IxbHndHelper.XML_TAG_UPPER_OBJECT_ID);
        parent.appendChild(objectIDElement);
    }

    /**
     * get the WTOrganization from rowData
     *
     * @param rowData
     * @return
     * @throws WTException
     */
    protected WTOrganization getWTOrganization(Map rowData) throws WTException {
        String orgIdOrName = (String) rowData.get(ORGANIZATION_ID);
        logger.debug("AbstractClassElementBuilder.getWTOrganization(): orgIdOrName = "
                + orgIdOrName);
        WTOrganization org = null;
        if (orgIdOrName != null && orgIdOrName.trim().length() > 0) {
            org = ImportHndHelper.getWTOrganizationByIdOrName(orgIdOrName);
        } else {
            org = getSessionData().getContainerRef().getReferencedContainerReadOnly().getOrganization();
        }
        return org;
    }
    /**
     * Creates an organizationId element and adds to the parent
     *
     * @param doc
     *            dom document
     * @param parent
     *            parent element to which the new element will be added to
     * @param rowData
     *            a map that contains key/value pairs for current context object
     * @throws WTException
     */
    protected void addOrganizationIdElement(Document doc, Element parent, Map rowData) throws WTException {
        WTOrganization org = getWTOrganization(rowData);
        logger.debug("AbstractClassElementBuilder.addOrganizationIdElement(): org = " + org);
        String organizationId = ImportHndHelper.getOrganizationUniqueId(org);
        logger.debug("AbstractClassElementBuilder.addOrganizationIdElement(): organizationId = " + organizationId);
        Element organizationIdElement = doc.createElement(IxbHndHelper.XML_ATTR_ORGANIZATION_ID);
        organizationIdElement.appendChild(doc.createTextNode(organizationId));
        parent.appendChild(organizationIdElement);
    }

    protected void addReferenceValueElement(Document doc, Element parent) {
        Element ibaElement = doc.createElement(IxbHndHelper.XML_IBA);

        Element ibaPathElement = doc.createElement(IxbHndHelper.XML_IBA_PATH);
        ibaPathElement.appendChild(doc.createTextNode("EXCLUSION"));
        ibaElement.appendChild(ibaPathElement);

        Element ibaValueElement = doc.createElement(IxbHndHelper.XML_IBA_VALUE);
        ibaValueElement.appendChild(doc.createTextNode(OptionExclusionReference.OPTION_EXCLUSION_REFERENCE_KEY));
        ibaElement.appendChild(ibaValueElement);

        Element ibaTypeElement = doc.createElement(IxbHndHelper.XML_IBA_TYPE);
        ibaTypeElement.appendChild(doc.createTextNode("ReferenceValue"));
        ibaElement.appendChild(ibaTypeElement);

        Element ibaDependencyElement = doc.createElement(IxbHndHelper.XML_IBA_DEPENDENDENCY);
        ibaDependencyElement.appendChild(doc.createTextNode("Exclusion"));
        ibaElement.appendChild(ibaDependencyElement);

        parent.appendChild(ibaElement);
    }

    /**
     * Creates a SecurityLabels element and adds to the parent
     *
     * @param doc
     *            dom document
     * @param parent
     *            parent element to which the new element will be added to
     * @param rowData
     *            a map that contains key/value pairs for current context object
     * @throws WTException
     */
    protected void addSecurityLabelsElement(Document doc, Element parent, Map rowData) throws WTException {
        Element securityLabelsElement = doc.createElement(IxbHndHelper.XML_SECURITY_LABELS);
        String securityLabels = (String) rowData.get(SECURITY_LABELS);
        if (logger.isTraceEnabled())
            logger.trace("Security Labels = \"" + securityLabels + "\"");
        if (securityLabels == null || securityLabels.trim().length() == 0) {
            return;
        }

        String[] schemes = securityLabels.split(SECURITY_LABELS_SCHEME_SEPARATOR);
        if (schemes == null || schemes.length == 0) {
            return;
        }

        for (String scheme : schemes) {
            if (scheme == null || scheme.trim().length() == 0) {
                logger.debug("Empty scheme skipped");
                continue;
            }
            String[] nameValue = scheme.split(SECURITY_LABELS_NAME_VALUE_SEPARATOR);
            if (nameValue == null || nameValue.length != 2) {
                logger.debug("Invalid security label data ignored: \"" + scheme + "\"");
                continue;
            }
            if (logger.isTraceEnabled())
                logger.trace("scheme:" + scheme + " name:" + nameValue[0] + " value:" + nameValue[1]);
            Element securityLabelElement = doc.createElement(IxbHndHelper.XML_SECURITY_LABEL);
            securityLabelElement.setAttribute(IxbHndHelper.XML_ATTR_NAME, nameValue[0]);
            securityLabelElement.setAttribute(IxbHndHelper.XML_ATTR_SECURITY_LABEL_VALUE, nameValue[1]);
            if (logger.isTraceEnabled()) {
                logger.trace("has name attr: " + securityLabelElement.getAttribute(IxbHndHelper.XML_ATTR_NAME));
                logger.trace("has attrs: " + securityLabelElement.hasAttributes());
            }
            securityLabelsElement.appendChild(securityLabelElement);
        }

        parent.appendChild(securityLabelsElement);
    }

    /**
     * Creates a versionInfo element and adds to the parent. The element contains versionId, iterationId, versionLevel,
     * and series.
     *
     * @param doc
     *            dom document
     * @param parent
     *            parent element to which the new element will be added to
     * @param rowData
     *            a map that contains key/value pairs for current context object
     * @throws WTException
     */
    /**
     * @param doc
     * @param parent
     * @param rowData
     * @throws WTException
     */
    protected void addVersionInfoElement(Document doc, Element parent, Map rowData) throws WTException {
        String versionId = (String) rowData.get(VERSION);
        /*if (versionId == null || versionId.trim().length() == 0) {
            logger.debug("version id not found, skip creating version info element...");
            return;
        }*/
        
        String typeId = (String) rowData.get(TYPE);
        String containerPath = (String) rowData.get(CONTAINER);
        if (containerPath == null || containerPath.trim().length() == 0) {
            containerPath = WTContainerHelper.getPath(getSessionData().getContainerRef());
        }
        if (logger.isDebugEnabled())
            logger.debug("typeId=" + typeId + " container path=" + containerPath);

        Element versionInfoElement = doc.createElement(IxbHndHelper.XML_ATTR_VERSION_INFO);
        Element versionIdElement = doc.createElement(ImportHndHelper.XML_TAG_VERSION_ID);
        versionIdElement.appendChild(doc.createTextNode(versionId));
        versionInfoElement.appendChild(versionIdElement);
        Element iterationIdElement = doc.createElement(ImportHndHelper.XML_TAG_ITERATION_ID);
        // iterationIdElement.appendChild(doc.createTextNode(""));
        versionInfoElement.appendChild(iterationIdElement);
        Element versionLevelElement = doc.createElement(ImportHndHelper.XML_TAG_VERSION_LEVEL);
        // versionLevelElement.appendChild(doc.createTextNode(""));
        versionInfoElement.appendChild(versionLevelElement);
        //as series is not mandatory attribute in X-24 DTD so removing this. this might resolve the SPR 2182518 for upgrade server.
//        Element seriesElement = doc.createElement(ImportHndHelper.XML_TAG_VERSION_SERIES);
//        String series = ImportHndHelper.getVersionSeries(containerPath, typeId, getSessionData());
//        if (logger.isDebugEnabled())
//            logger.debug("series=" + series);
//        seriesElement.appendChild(doc.createTextNode(series));
//        versionInfoElement.appendChild(seriesElement);


        //if user gives only one value i.e. BRANCH_REVISION it will get ignored.
        String branchPoint = (String) rowData.get(WTPartElementBuilder.BRANCH_REVISION);
        if ( branchPoint != null && branchPoint.trim().length() != 0 ) {
        	 String derivedFrom = (String) rowData.get(WTPartElementBuilder.BRANCH_VIEW);

        	 if(derivedFrom != null && derivedFrom.trim().length() == 0 ){
        		 derivedFrom = IxbHndHelper.XML_VALUE_NULL;
        	 }

        	Element derivedFromElement = doc.createElement(ImportHndHelper.XML_TAG_BRANCHPOINT);
        	Element ObjectReference = doc.createElement(IxbHndHelperConstants.XML_TAG_OBJECT_REFERENCE);
        	derivedFromElement.appendChild(ObjectReference);
        	Element ufid = doc.createElement(IxbHndHelperConstants.XML_TAG_UFID);
        	ObjectReference.appendChild(ufid);
        	ufid.appendChild(doc.createTextNode(derivedFrom));
            versionInfoElement.appendChild(derivedFromElement);

        	Element branchPointElement = doc.createElement(ImportHndHelper.XML_TAG_DERIVEDFROM);
        	Element branchObjectReference = doc.createElement(IxbHndHelperConstants.XML_TAG_OBJECT_REFERENCE);
        	branchPointElement.appendChild(branchObjectReference);
        	Element branchufid = doc.createElement(IxbHndHelperConstants.XML_TAG_UFID);
        	branchObjectReference.appendChild(branchufid);
        	branchufid.appendChild(doc.createTextNode(branchPoint));
        	versionInfoElement.appendChild(branchPointElement);

        	Element predecessorElement = doc.createElement(ImportHndHelper.XML_TAG_PREDECESSOR);
        	Element predecessorObjectReference = doc.createElement(IxbHndHelperConstants.XML_TAG_OBJECT_REFERENCE);
        	predecessorElement.appendChild(predecessorObjectReference);
        	Element predecessorufid = doc.createElement(IxbHndHelperConstants.XML_TAG_UFID);
        	predecessorObjectReference.appendChild(predecessorufid);
            versionInfoElement.appendChild(predecessorElement);
        }
        //--
        parent.appendChild(versionInfoElement);

    }

    /**
     * Returns the document builder
     *
     * @return
     */
    protected DocumentBuilder getDocumentBuilder() {
        return this.documentBuilder;
    }

    /**
     * Validates the input row data and throws exception if the row data is invalid
     *
     * @param rowData
     * @throws WTException
     */
    protected abstract void validateRowData(Map rowData) throws WTException;

    /**
     * Returns the set of IBA attribute names
     */
    protected Set<String> getIbaNames() {
        return this.ibaNames;
    }

    /**
     * returns the set of option names in columns
     * @return
     */
    protected Set<String> getOptionNames() {
        return this.optionNames;
    }

    /**
     * <Purpose> Retrieves the object type of the externalTypeId which is passed in rowData map
     * @param rowData
     * @return actual object type
     * @throws WTException
     */
    private String getObjectTypeStr(Map rowData) throws WTException{
    	String value = (String) rowData.get(TYPE);
    	if(value == ""){
    		throw new WTException(RESOURCE, importerResource.ERROR_INVALID_TYPE, new Object[]{value});
    	}
    	String objectTypeStr = null;

    	if (null != value && value.trim().length() > 0) {
        	TypeIdentifier typeID = ImportHndHelper.getTypeIdentifier(value);
        	objectTypeStr = ((WCTypeIdentifier)typeID).getLeafName();
        }


        return objectTypeStr;
    }
}
