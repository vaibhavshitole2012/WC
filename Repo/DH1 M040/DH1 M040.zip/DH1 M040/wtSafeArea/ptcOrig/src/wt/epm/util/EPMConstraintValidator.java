/* bcwti
 *
 * Copyright (c) 2010 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */
/*
 * REVISION HISTORY ---
 * $$NONE
 * ssoni    10-May-2004 Created.
 * bkeesara 18-Jul-2005 Added isRemoveValid for Deleted Attributes.
 * avinod   19-Nov-2009      Changes made for New Typing System
 * ndeshmuk 24-May-2012 Removed method getBindingRule()
 */

package wt.epm.util;

import com.ptc.core.meta.common.AssociationIdentifier;
import com.ptc.core.meta.common.AttributeIdentifier;
import com.ptc.core.meta.common.AttributeTypeIdentifier;
import com.ptc.core.meta.common.impl.ModeledAttributeTypeIdentifier;
import com.ptc.core.meta.common.impl.ModeledAssociationTypeIdentifier;

import com.ptc.core.meta.container.common.AttributeContainer;
import com.ptc.core.meta.container.common.Constrainable;
import com.ptc.core.meta.container.common.ConstraintContainer;
import com.ptc.core.meta.container.common.ConstraintException;
import com.ptc.core.meta.container.common.ConstraintValidator;
import com.ptc.core.meta.container.common.impl.DefaultConstraintValidator;
import java.io.Serializable;
import java.lang.Object;
import java.lang.String;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import com.ptc.core.meta.common.ConstraintIdentifier;
import com.ptc.core.meta.container.common.ConditionalBindingRuleData;
import com.ptc.core.meta.container.common.ConstraintBindingRule;
import com.ptc.core.meta.container.common.ConstraintEnforcementRule;
import com.ptc.core.meta.container.common.ConstraintData;
import com.ptc.core.meta.container.common.State;

import wt.epm.util.log.EPMLogger;
import wt.method.MethodContext;


// NOTE: This class is copied from com.ptc.core.meta.container.common.impl.DefaultConstraintValidator
//       DefaultConstraintValidator return exception on occurrence of first constraint violation.
//       While EPMConstraintValidator validates and collects all constraint violations.
//       This is for only isValid methods.
//       In sync with DefaultConstraintValidator.java@@\main\10


public class EPMConstraintValidator implements ConstraintValidator, Serializable {


   // --- Attribute Section ---


   private static final String RESOURCE = "wt.epm.util.EPMResource";
   private static final String CLASSNAME = EPMConstraintValidator.class.getName();
   private static EPMConstraintValidator singleton;
   private Hashtable bindingRuleCache;
   private Hashtable enforcementRuleCache;

   private static final EPMLogger logger;

   static {
        try {
            logger = EPMLogger.getLogger(EPMConstraintValidator.class);
        }
        catch (Exception e) {
            throw new ExceptionInInitializerError(e);
        }
   }

   // --- Operation Section ---


   private EPMConstraintValidator() {
        bindingRuleCache = new Hashtable();
        enforcementRuleCache = new Hashtable();
   }

   public static EPMConstraintValidator getInstance() {
      if (singleton == null)
        singleton = new EPMConstraintValidator();
      return singleton;
   }

   /**
    * Based on the constraints in the_constraint_container, determines if
    * the attribute_identifier and the attribute_identifier's content can
    * be added to the_attribute_container.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     the_attribute_container
    * @param     the_constraint_container
    * @param     the_attribute_identifier
    * @param     the_attribute_content
    * @exception com.ptc.core.meta.container.common.ConstraintException
    **/

   public void isAddValid( AttributeContainer the_attribute_container, ConstraintContainer the_constraint_container, AttributeIdentifier the_attribute_identifier, Object the_attribute_content )
            throws ConstraintException {
      DefaultConstraintValidator.getInstance().isAddValid(the_attribute_container, the_constraint_container,
                    the_attribute_identifier, the_attribute_content);
   }

   /**
    * Based on the constraints in the_constraint_container, determines if
    * the attribute_identifier and the attribute_identifier's content can
    * be updated in the_attribute_container.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     the_attribute_container
    * @param     the_constraint_container
    * @param     the_attribute_identifier
    * @param     the_attribute_content
    * @exception com.ptc.core.meta.container.common.ConstraintException
    **/

   public void isUpdateValid( AttributeContainer the_attribute_container, ConstraintContainer the_constraint_container, AttributeIdentifier the_attribute_identifier, Object the_attribute_content )
            throws ConstraintException {
      DefaultConstraintValidator.getInstance().isUpdateValid(the_attribute_container, the_constraint_container,
                    the_attribute_identifier, the_attribute_content);
   }

   /**
    * Based on the constraints in the_constraint_container, determines if
    * the attribute_identifier and the attribute_identifier's content can
    * be removed from the_attribute_container.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     the_attribute_container
    * @param     the_constraint_container
    * @param     the_attribute_identifier
    * @param     the_attribute_content
    * @exception com.ptc.core.meta.container.common.ConstraintException
    **/

   public void isRemoveValid( AttributeContainer the_attribute_container, ConstraintContainer the_constraint_container, AttributeIdentifier the_attribute_identifier, Object the_attribute_content )
            throws ConstraintException {
      DefaultConstraintValidator.getInstance().isRemoveValid(the_attribute_container, the_constraint_container,
                    the_attribute_identifier, the_attribute_content);
   }

   /**
    * Based on the constraints in the_constraint_container, determines if
    * the attribute_identifier, and it's content is considered valid in
    * the_attribute_container.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     the_attribute_container
    * @param     the_constraint_container
    * @param     the_attribute_identifier
    * @param     the_attribute_content
    * @exception com.ptc.core.meta.container.common.ConstraintException
    **/

   public void isValid( AttributeContainer the_attribute_container, ConstraintContainer the_constraint_container, AttributeIdentifier the_attribute_identifier, Object the_attribute_content )
            throws ConstraintException {
        ConstraintException[] exceptions = internalIsValid(the_attribute_container, the_constraint_container, the_attribute_identifier, the_attribute_content);
        if ( exceptions != null ) {
            EPMMultiConstraintException ce = new EPMMultiConstraintException("Constraint Violation in isValid()");
            for (int i=0;i<exceptions.length;i++)
                ce.addConstraintException(exceptions[i]);
            throw ce;
        }
   }

   /**
    * Based on the constraints in the_constraint_container, determines if
    *  all the attributes and their content is considered valid in the_attribute_container.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     the_attribute_container
    * @param     the_constraint_container
    * @exception com.ptc.core.meta.container.common.ConstraintException
    **/

   public void isValid( AttributeContainer the_attribute_container, ConstraintContainer the_constraint_container )
            throws ConstraintException {
        EPMMultiConstraintException ce = null;
        if (the_attribute_container == null) return;
        if (the_constraint_container == null) return;
        AttributeIdentifier []attribute_ids = the_attribute_container.getAttributeIdentifiers();
        if (attribute_ids == null) return;
        Object the_content = null;
        for (int i=0; i<attribute_ids.length; i++) {
            the_content = the_attribute_container.get(attribute_ids[i]);
            ConstraintException[] exceptions = internalIsValid(the_attribute_container, the_constraint_container, attribute_ids[i], the_content);
            if ( exceptions != null ) {
                if ( ce == null )
                    ce = new EPMMultiConstraintException("Constraint Violation in isValid()");
                for (int j=0;j<exceptions.length;j++)
                    ce.addConstraintException(exceptions[j]);
            }
        }
        ConstraintException[] exceptions = internalIsValueRequiredValid(the_attribute_container,the_constraint_container);
        if (exceptions != null) {
            if ( ce == null )
                ce = new EPMMultiConstraintException("Constraint Violation in isValid()");
            for (int j=0;j<exceptions.length;j++)
                ce.addConstraintException(exceptions[j]);
        }
        attribute_ids = the_attribute_container.getAttributeIdentifiers(State.DELETED);
        if (attribute_ids == null) return;
        the_content = null;
        for (int i=0; i<attribute_ids.length; i++) {
            the_content = the_attribute_container.get(attribute_ids[i]);
            try {
                isRemoveValid(the_attribute_container, the_constraint_container, attribute_ids[i], the_content);
            } catch (ConstraintException rce) {
                    if ( ce == null )
                       ce = new EPMMultiConstraintException("Constraint Violation in isValid()");
                    ce.addConstraintException(rce);
            }
        }
        if ( ce != null )
            throw ce;
   }

   /**
    * Adds all the constraints in the constraint_container, for the given
    * attribute_type_identifier, to the Constrainable.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     the_constrainable
    * @param     the_attribute_container
    * @param     the_association_identifier
    * @param     the_attribute_type_identifier
    * @param     constraint_container
    **/

   public void modify( Constrainable the_constrainable, AttributeContainer the_attribute_container, AssociationIdentifier the_association_identifier, AttributeTypeIdentifier the_attribute_type_identifier, ConstraintContainer constraint_container ) {
        DefaultConstraintValidator.getInstance().modify(the_constrainable, the_attribute_container,
                    the_association_identifier, the_attribute_type_identifier, constraint_container);
   }

   private ConstraintEnforcementRule getEnforcementRule(String className) {
        ConstraintEnforcementRule enforcement_rule = null;
        enforcement_rule = (ConstraintEnforcementRule)enforcementRuleCache.get(className);
        if (enforcement_rule == null) {
            try {
                enforcement_rule = (ConstraintEnforcementRule)Class.forName(className).newInstance();
                if (enforcement_rule != null) enforcementRuleCache.put(className, enforcement_rule);
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InstantiationException e) {
                e.printStackTrace();
            }
        }
        return enforcement_rule;

   }

   private ConstraintException[] internalIsValid( AttributeContainer the_attribute_container, ConstraintContainer the_constraint_container, AttributeIdentifier the_attribute_identifier, Object the_attribute_content ) {
        List exceptions = new ArrayList(10);
        if (the_constraint_container == null) return null;  // true - no constraint on the container
        ConstraintIdentifier []constraint_identifiers = the_constraint_container.getConstraintIdentifiers(the_attribute_container,the_attribute_identifier,ConstraintContainer.ENABLED);
        if (constraint_identifiers == null) return null; // true - no constraint on the container
        for (int i=0; i<constraint_identifiers.length; i++) {
            ConstraintIdentifier const_id = constraint_identifiers[i];
            if (const_id != null) {
                String erClassName = const_id.getEnforcementRuleClassname();
                ConstraintEnforcementRule enforcement_rule = getEnforcementRule(erClassName);
                ConstraintData data = the_constraint_container.get(const_id);
                if (enforcement_rule != null) {
                    if (!enforcement_rule.isValid(the_attribute_container, the_attribute_identifier, the_attribute_content, (data==null)?null:data.getEnforcementRuleData())) {
                        ConstraintException ce = new ConstraintException("Constraint Violation in isValid()");
                        ce.setData(the_attribute_identifier, the_attribute_content, const_id, data);
                        exceptions.add(ce);
                    }
                }
            }

        }
        if ( exceptions.size() > 0 )
            return (ConstraintException[])exceptions.toArray(new ConstraintException[exceptions.size()]);
        return null;
   }

   private ConstraintException[] internalIsValueRequiredValid( AttributeContainer the_attribute_container, ConstraintContainer the_constraint_container )
          throws ConstraintException {
      if(the_attribute_container == null) return null;
      if(the_constraint_container == null) return null;
      if (EPMSoftTypeServerUtilities.SKIP_REQUIRED_ATTR_CHECK.equals(MethodContext.getContext().get(EPMSoftTypeServerUtilities.SKIP_REQUIRED_ATTR_CHECK))) {
        // Skip value required constraint check
        if (logger.isDebugEnabled())
          logger.debug("Skipping value required constraint checking");

        return null;
      }
      List exceptions = new ArrayList(10);
      ConstraintIdentifier[]constraint_identifiers = the_constraint_container.getConstraintIdentifiers(ConstraintContainer.ENABLED);
      if(constraint_identifiers==null) return null;
      for(int i=0; i<constraint_identifiers.length; i++) {
         ConstraintIdentifier const_id = constraint_identifiers[i];
         if(const_id!=null) {
            String erClassName = const_id.getEnforcementRuleClassname();
            if(erClassName.equals("com.ptc.core.meta.container.common.impl.ValueRequiredConstraint")) {
               ConstraintEnforcementRule enforcement_rule = getEnforcementRule(erClassName);
               ConstraintData data = the_constraint_container.get(const_id);
               if(enforcement_rule!=null && data!=null) {
                  Object brd = data.getBindingRuleData();
                  if(brd instanceof ConditionalBindingRuleData) {
                     if(((ConditionalBindingRuleData)brd).isConditionMet(the_attribute_container,null)) {
                        brd = ((ConditionalBindingRuleData)brd).getData();
                     }
                  }
                  if(brd instanceof AttributeTypeIdentifier && !(brd instanceof ModeledAttributeTypeIdentifier) && !(brd instanceof ModeledAssociationTypeIdentifier)) {

                     AttributeIdentifier dummy_ai = ((AttributeTypeIdentifier)brd).newAttributeIdentifier(null);
                     if(!enforcement_rule.isValid(the_attribute_container, dummy_ai, null, data.getEnforcementRuleData())) {
                        ConstraintException ce = new ConstraintException("Constraint Violation in isValid()");
                        ce.setData(dummy_ai, null, const_id, data);
                        //throw ce;
                        exceptions.add(ce);
                     }
                  }
               }
            }
         }
      }
      if ( exceptions.size() > 0 )
        return (ConstraintException[])exceptions.toArray(new ConstraintException[exceptions.size()]);
      return null;

   }
}
