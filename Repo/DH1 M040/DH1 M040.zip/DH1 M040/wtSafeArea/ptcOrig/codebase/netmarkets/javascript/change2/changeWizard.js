PTC.change = {};

PTC.change.RESULTING_OBJECTS_TABLE_ID = 'changeTask_resultingItems_table';

var CHG_RESOURCE = "com.ptc.windchill.enterprise.change2.change2ClientResource";

var changeEventHandler = function(){
    var eventList = [];
    return {
        observe: function(eventName, jsfunction){
            if (!eventList[eventName]) {
                eventList[eventName] = [];
                eventList[eventName][0] = jsfunction;
            }
            else {
                var len = eventList[eventName].length;
                eventList[eventName][len] = jsfunction;
            }
        },
        notify: function(eventName, evt){
            if (eventList[eventName] && eventList[eventName] !== null) {
                var result;
                var len = eventList[eventName].length;
                for (var i = 0; i < len; i++) {
                    var jsfunction = eventList[eventName][i];
                    if (jsfunction && jsfunction !== null) {
                        result = jsfunction(evt);
                        if(result === false) {
                            break;
                        }
                    }
                }
                return result;
            }
        },
        /* @private Used for testing */
        clear: function(){
            eventList = [];
        }
    };
}();

// Delete a change task from the Implementation Plan table in the Change Notice wizard
function removeChangeTask(event){
    var oid = PTC.menu.contextOid;
    jsca.log("Deleting change task: " + oid);
    if (oid && JCAConfirm(event, CHG_RESOURCE + ".CONFIRM_DELETE_CHANGE_TASK")) {
        // hidden variable to keep the Change Notice wizard open when
        // 1. change task is already reserved by another user or
        // 2. change task is already reserved by the current user and the Cancel option on the confirmation message is chosen 
        var hiddenInput = appendFormHiddenInput(getMainForm(), "removeChangeTask", 'true');

        // Request a reservation only if this is a persisted change task
        var changeMode = Ext.getDom('changeMode');
        if(changeMode === 'EDIT' && oid.indexOf("popCreateWizard_") === -1 && oid.indexOf("defaultChangeTask") === -1) {
            PTC.change.requestReservation(oid);
        }

        // the hidden variable value may get changed to false during the requestReservation call above
        var canRemove = hiddenInput.value;
        if(canRemove === 'true') {
            var tableId = iframeTableId;

            jsca.log("Emitting removeChangeTask event");
            changeEventHandler.notify('removeChangeTask',event);
            jsca.log("Deleting change task from table id: " + tableId);

            PTC.wizardIframes.submitHandler.removeIframeRowElement(oid, tableId, true);
        }
        getMainForm().removeChild(hiddenInput);
    }
    return false;
}

// Reserve a persisted change task being deleted
PTC.change.requestReservation = function(oid) {
    var config = {oid: oid, reservationType: "modify", enforcedByService: true, workflowOverride: true, adminOverride: false};
    PTC.reservation.requestReservation(config);
};

var OneOffVersionHandler = function(){
    var resultingTableId = "changeTask_resultingItems_table";
    return {
        setResultingTableId: function(tableId){
            resultingTableId = tableId;
        },
        showMessage: function(heading, msg){
            Ext.MessageBox.show({
                title: '',
                msg: heading + '<br><br>' + msg,
                buttons: Ext.MessageBox.OK,
                icon: Ext.MessageBox.WARNING
            });
        },
        handleError: function(resp, error){
            var header = bundleHandler.getBundleStringAndInserts(CHG_RESOURCE + ".NEWONEOFFVERSION_ACTION_HEADER_MSG");
            var msg = bundleHandler.getBundleStringAndInserts(CHG_RESOURCE + ".NEWONEOFFVERISON_ACTION_CANNOT_CREATE");
            OneOffVersionHandler.showMessage(header, msg);
            stopProgress();
            return false;
        },
        handleResponse: function(resp){
            var result = resp.responseJSON;
            if (result.msg && result.msg !== '') {
                header = bundleHandler.getBundleStringAndInserts(CHG_RESOURCE + ".NEWONEOFFVERSION_ACTION_HEADER_MSG");
                OneOffVersionHandler.showMessage(header, result.msg);
            }
            else 
                if (result.oids) {
                    var params = {
                        doAjaxUpdate: true,
                        preventDuplicates: true
                    };
                    rowHandler.addRows(result.oids, resultingTableId, null, params);
                }
            stopProgress();
            return false;
        },
        processSelected: function(event, resultingTableId){
            goProgress();
            if (resultingTableId) {
                OneOffVersionHandler.setResultingTableId(resultingTableId);
            }
            var tableId = tableUtils.findTableID(event);
            var selected = tableUtils.getTableSelectedRowsById(tableId);
            if (selected.length < 1) {
                JCAAlert("com.ptc.netmarkets.util.utilResource.NO_OBJECT_SELECTED");
                stopProgress();
                return false;
            }
            var oids = oidUtils.newOidSet(selected);
            var oidStr = oids.toString().replace(/#/g, "___");
            var options = {
                asynchronous: false,
                method: 'post',
                evalJSON: true,
                parameters: getFormData() + '&' + 'soidarray=' + encodeURIComponent(oidStr),
                onSuccess: OneOffVersionHandler.handleResponse,
                onFailure: OneOffVersionHandler.handleError,
                onException: OneOffVersionHandler.handleError
            };
            requestHandler.doRequest('netmarkets/jsp/changeTask/newOneOffVersionInChange.jsp', options);
            return false;
        }
    };
}();

var changeRowHandler = function(){
    var tableID = null;
    var selectedItems = null;
    var tableEvent = null;
    var tableEventName = null;
    
    function removeRow(){
        if (!selectedItems || selectedItems.length === 0) {
            JCAAlert('com.ptc.netmarkets.util.utilResource.NONE_CHECKED');
        }
        else {
            var result = changeEventHandler.notify(tableEventName, tableEvent);
            if(result !== false) {
                rowHandler.removeRowsFromParentTable(tableEvent);
                var soids = [];
                oidUtils.newOidSet(selectedItems).iterate(function(oid){
                    soids.push(oid);
                });
                PTC.util.tableDataManager.remove(tableID, soids);
            }
        }
    }
    function initialize(event, eventName){
        if (event && event !== null) {
            tableEvent = event;
            tableID = tableUtils.findTableID(event);
            if (tableID && tableID !== null) {
                selectedItems = getJCASelectedTableItems(tableID);
            }
            tableEventName = eventName;
        }
    }
    
    return {
        // This function is used to remove selected data and notify any observers for removeEventName.
        remove: function(event, removeEventName){
            initialize(event, removeEventName);
            removeRow();
        },
        
        // This function is used to delete any iframes associated to annotations for
        // an affected data.
        removeAffectedObjects: function(event){
            changeRowHandler.remove(event, 'removeAffectedData');
        },
        // This function is used to remove selected resulting data and notify any observers.
        removeResultingObjects: function(event){
            changeRowHandler.remove(event, 'removeResultingData');
        }
    };
}();

// Retrieve the update count for the current object.  Requires the page
// to contain the hidden FORM element with the objects OID parameter.
// @deprecated
function getUpdateCount(){
    var oid = Ext.getDom("changeWizardObjectRef");
    var status = 0;//by default no update
    if (oid) {
        var options = {
            asynchronous: false,
            parameters: 'oid=' + encodeURIComponent(oid.value)
        };
        var xmlhttp = requestHandler.doRequest('netmarkets/jsp/change/getUpdateCount.jsp', options);
        if (xmlhttp.readyState === 4 && (xmlhttp.status === 200 || xmlhttp.status === 0)) {
            response = xmlhttp.responseXML;
            status = response.getElementsByTagName("n")[0].firstChild.data;
        }
    }
    return status;
}

// Determine if the current object has been updated.
// @deprecated
function isPersistInfoCountUpdated(){
    var c = Ext.getDom("updateCount");
    if (c) {
        var prevCount = c.value;
        var count = getUpdateCount();
        return (parseInt(count, 10) > parseInt(prevCount, 10)) ? true : false;
    }
    return false;
}

// Setup the initial object event observers for the various step navigation.
// Upon navigating to the step validate the update count.
// @deprecated
function setInitialPersistInfoCount(){
    var count = Ext.getDom("updateCount");
    if (count) {
        count.value = getUpdateCount();
    }
}

// Validate the update count.  If they are not equal, then display a message
// and refresh/close the window.
// @deprecated
function validateCount(){
    if (isPersistInfoCountUpdated()) {
        JCAAlert(CHG_RESOURCE + ".CONFIRM_UPDATE_CHANGEITEM");
        window.location.reload(true);
        return false;
    }
    return true;
}

var ChangeUtils = function(){
    return {
        /* Gets the oid from the action oid from the url. */
        getOid: function(decode, useOpener){
            var params = null;
            var getParams = null;
            if(useOpener) {
                getParams = opener.location.href.split("?");
            } else {
                getParams = location.href.split("?");
            }
            params = Ext.urlDecode(getParams[getParams.length - 1]);
            var oid = null;
            if(params && params.oid && typeof params.oid === 'string') {
                oid = params.oid;
            } else {
                oid = params.oid[0];
            }
            return oid;
        },
        getCabinet: function(decode){
            var els = document.getElementsByName('selectedFolderFromFolderContext');
            if (els && els.length > 0) {
                return document.getElementsByName('selectedFolderFromFolderContext')[0].value;
            }
            return this.getOid(decode);
        },
        /* Gets the table id from the action oid from the url. */
        getTableID: function(unformatted){
            var params = location.search.parseQuery();
            return ChangeUtils.getTableIDFromParams(params, unformatted);
        },
        /* Gets the table id from the passed in params */
        getTableIDFromParams: function(params, unformatted){
            var tableID = null;
            if (params.tableID) {
                if (typeof params.tableID === 'string') {
                    tableID = params.tableID;
                }
                else {
                    tableID = params.tableID[0];
                }
            }
            if (unformatted) {
                tableID = tableUtils.getUnformattedTableId(tableID);
            }
            return tableID;
        },

        /* Gets the parameters for adding rows */
        getAddRowParams: function(list){
            var params;
            if (list.length <= 100) {
                params = {
                    doAjaxUpdate: true,
                    preventDuplicates: true
                };
            }
            else {
                params = {
                    refreshTable: true,
                    preventDuplicates: true
                };
            }
            return params;
        }
    };
}();

// This function is to add picked items from the picker to the table id that is
// passed in.
function pickerAddItems(objects, tableId){
    var myJSONObjects = objects.pickedObject;
    var list = [];
    
    for (var i = 0, l = myJSONObjects.length; i < l; i++) {
        list.push(myJSONObjects[i]["oid"]);
    }
    setTimeout(function(){
        var params = ChangeUtils.getAddRowParams(list);
        rowHandler.addRows(list, tableId, null, params);
    }, 1);
}

PTC.change.affectedObjectsTableId = "change_affectedData_table";

PTC.change.pickerConfig = [];

PTC.change.addPickerConfig = function(pickerId, tableId){
    PTC.change.pickerConfig[pickerId] = tableId;
};

// This is the call back function for addAffectedData and addResultingItems.
// It finds the appropriate table ID then calls pickerAddItems.  
PTC.change.pickerAddItems = function(objects, pickerId){
    var tableId = PTC.change.pickerConfig[pickerId];
    
    if (!tableId || "undefined" == typeof(tableId)) {
        tableId = PTC.change.affectedObjectsTableId;
        jsca.log("Unable to find table ID using: " + PTC.change.affectedObjectsTableId);
    }
    
    pickerAddItems(objects, tableId);
};

// Used by the ChangeWizardInitializeTag to override the PTC.wizard.saveTableData.writeAllTableRows
PTC.change.writeAllTableRows = function(original) {
    var supportedTables = ['change_affectedEndItems_table', 
                           'change_affectedData_table',
                           'issues_affectedData_table',
                           'changeRequest_affectedData_table',
                           'changeTask_affectedItems_table',
                           'changeTask_resultingItems_table',
                           'changeReview_affectedData_table'];
    var i = supportedTables.length;
    while (i--) {
        var t = tableUtils.getTable(supportedTables[i]);
        if (t) {
            t.submitAllTableData = null;
        }
    }
    original();
};

// Used to determine if at least one change task is required
PTC.change.changeTaskRequired = true;

// This method is used to validate that at least one change task exists on the 
// changeNotice implementation table and validates if number is present for the change tasks.
PTC.change.validateImplementationTable = function(){
    isValid = true;
    if(PTC.change.changeTaskRequired === false) {
        return isValid;
    }
    var tableID = "changeNotice.wizardImplementationPlan.table";
    isValid = PTC.change.validateTableEntryExists(tableID, "IMPLEMENTATION_TABLE_NO_TASKS");
    if (isValid) {

        // also validate if the change tasks have a number
        var rows = tableUtils.getTableRows(tableID);
        if(rows){
            var size = rows.getCount();
            for(var i=0;i<size;i++){
                var row = rows.get(i);
                var rowOid = row.get("oid");
                var changeTaskNumber = PTC.change.getNumber(row);

                if (changeTaskNumber === "") {
                    isValid = false;
                    break;
                }
            }
        }

        if (isValid === false) {
            JCAAlert(CHG_RESOURCE + "." + "CHANGE_TASK_NUMBER_REQUIRED");
        }

    }
    return isValid;
};

PTC.change.getNumber = function(row){
    var changeTaskNumber = "";

    var number = row.get("changeTask_number");
    if(number && number.gui.comparable !== undefined && number.gui.comparable !== null) {
       changeTaskNumber = number.gui.comparable;
    }

    return changeTaskNumber;
};

// If the alert message is null and a valid table entry does not exist the call method needs to handle alerting the user.
PTC.change.validateTableEntryExists = function(tableId, alertMsg){
    var isValid = true;
    var table = tableUtils.getTable(tableId);
    if (table !== null) {
        var rows = tableUtils.getTableRows(table);
        if (rows !== null && rows.items !== null && rows.items.length === 0) {
            isValid = false;
        }
    }
    
    if (isValid === false && alertMsg !== null) {
        // Need at least one change task, issue alert
        JCAAlert(CHG_RESOURCE + "." + alertMsg);
    }
    return isValid;
};


//Will return the objectHandle value
function getObjectHandle(){
    var objectHandle = getElementByName("objectHandle");
    if (objectHandle && objectHandle !== null) {
        return objectHandle.value;
    }
    else {
        return "";
    }
}


// This function to open up on a specified step in a wizard.
function change_goToWizardStep(changeWizardStep, tableId){
    var getStep = true;
    var id = ChangeUtils.getTableID();
    if (tableId && tableId !== null) {
        if (id && id !== null && id.indexOf(tableId) > 0) {
            getStep = true;
        }
        else {
            //If table does not match, checks if the table id for change wizards is different and this is to handle the change tables with configured table ids
            //In the above case the table id for the same component is different on info page and wizards.
            var openerTable = (opener && opener.tableUtils)? opener.tableUtils.getTable(id) : null;
            var chgWizTableId = (openerTable && openerTable.store && openerTable.store.chgWizTableId)? openerTable.store.chgWizTableId: "";
            if(chgWizTableId && chgWizTableId !== null && chgWizTableId.indexOf(tableId) > -1){
              getStep = true;
            }
            else {
              getStep = false;
            }
        }
    }
    
    if (getStep && changeWizardStep && changeWizardStep !== null) {
        setActiveStep(changeWizardStep + getObjectHandle(), "NEXT");
    }
}

// This function will handle post load of change edit wizard and
// enforce three things to happen in such order:
// 1) It will call firstPostload.
// 2) It will load all remaining non-required steps;
// 3) It will load the step defined for the postLoadStep.
// 4) Register the wrapper for PTC.reservation.close
function change_postLoadEvent(){
    var params = location.search.parseQuery();
    var postLoadStep = null;
    if (params.postLoadStep) {
        postLoadStep = params.postLoadStep;
    } else {
        var formParams = getMainForm();
        if(formParams && formParams.action) {
            var formPostLoadStep = formParams.action.parseQuery().postLoadStep;
            if(formPostLoadStep) {
                postLoadStep = formPostLoadStep;
            }
        }
    }
    if(postLoadStep !== null) {
        change_goToWizardStep(postLoadStep);
    }
    loadAllRemainingNonRequiredSteps();

    PTC.reservation.close = PTC.reservation.close.wrap(function(original) {
        // Do not close the wizard if the change task being deleted could not be or need not be reserved

        if(!Ext.getDom("removeChangeTask")) {
            wfWindowClose();
        } else {
            PTC.reservation.config.pop();
            PTC.reservation.storeConfig();
            Ext.getDom("removeChangeTask").value = 'false';
        }
    });
}

function change_postLoad(){
    goToNextStepIfNothingIsEditable = function(){/*do nothing*/
    };
    PTC.onReady(change_postLoadEvent);
}

// Functions that is used to render change management specific dialogs or uis
var ChangeConfirmDialogRenderer = function(){

    return {
        /*
         * Creates the extjs dialog given the dialog title, dialogContent and the buttons to be displayed.
         */
        createDialog: function(dialogTitle, dialogMsg, buttons){
        
            var dialog = new Ext.Window({
                autoCreate: true,
                title: dialogTitle,
                resizable: false,
                constrain: true,
                constrainHeader: true,
                minimizable: false,
                maximizable: false,
                stateful: false,
                modal: true,
                width: 500,
                height: 200,
                minHeight: 80,
                footer: true,
                closable: true,
                closeAction: 'hide',
                layout: 'hbox',
                autoScroll: true,
                items: [new Ext.Panel({
                    border: false,
                    margins: "20 10 0",
                    html: '<img src="netmarkets/themes/windchill/window/icon-question.gif">',
                    baseCls: 'x-window-plain'
                }), new Ext.Panel({
                    border: false,
                    margins: "5",
                    html: dialogMsg,
                    baseCls: 'x-window-plain'
                })],
                listeners:{
                    //adding hide event listener so that when the submit dialog X button or Cancel button is clicked  
                    //it will enable buttons and reset Next and Back button. 
                    'hide':function(win){
                        enableButtons();
                        resetNextBackButton(currentStepStrName);                    
                     }
                }
            
            });
            
            if (buttons) {
                for (var i = 0; i < buttons.length; i++) {
                    dialog.addButton({
                        text: '<b>' + buttons[i].name + '</b>',
                        handler: buttons[i].handler,
                        id: buttons[i].buttonId
                    });
                }
            }
            
            return dialog;
        },
        
        button: function(name, id, handler){
            this.name = name;
            this.buttonId = id;
            this.handler = handler;
        }
        
    };
}();

// Handler for processing the Submit Now/Later functionality in the change
// management wizards.
var ChangeManagementSubmitHandler = function(){
    var submitDialog;
    
    return {
        /*
         * Called when the user clicks the "Finish" button on the change management
         * wizards (That support Submit Now/Later functionality).  If the feature
         * is enabled in the page, then the status will be checked.  If the status
         * is valid, then the dialog will be shown.  If the status is not valid
         * this indicates a validation failure.
         */
        submitChangeWizard: function(){
            disableButtons();
            disableIEButtonsOnSubmit();
            var status = checkSubmitStatus();
            if (!status) {
                enableButtons();
                resetNextBackButton(currentStepStrName);
                return false;
            }
            
            var process = validateCount();
            if (process === false) {
                return process;
            }
            var submitNowEnabled = Ext.getDom('submitNowEnabled');
            if (submitNowEnabled !== null && submitNowEnabled.value === "true") {
                ChangeManagementSubmitHandler.createSubmitDialog();
            }
            else {
                process = onSubmit(true);
            }
            
            return process;
        },
        
        /*
         * handler for the Submit Now/Later/Cancel buttons.
         */
        buttonHandler: function(button){
            if (button && button !== null) {
                submitDialog.hide();
                goProgress();
                if (button.id == 'submitNowBtn') {
                    ChangeManagementSubmitHandler.processAndSubmit(true);
                }
                else 
                    if (button.id == 'submitLaterBtn') {
                        ChangeManagementSubmitHandler.processAndSubmit(false);
                    }
                    else 
                        if (button.id == 'cancelBtn') {                           
                            stopProgress();
                            return false;
                        }
            }
        },
        
        /*
         * Creates the dialog to check with the user if the change object have to be submitted now or later.
         */
        createSubmitDialog: function(){
            if (!submitDialog) {
                var submitNowButtonTxt = bundleHandler.get("com.ptc.windchill.enterprise.change2.change2ClientResource.SUBMIT_NOW_BUTTON");
                var submitLaterButtonTxt = bundleHandler.get("com.ptc.windchill.enterprise.change2.change2ClientResource.SUBMIT_LATER_BUTTON");
                var cancelButtonTxt = bundleHandler.get("com.ptc.core.ui.navigationRB.cancelDialogButton");
                var dialogTitle = bundleHandler.get("com.ptc.core.ui.componentRB.MESSAGE_DIALOG_TITLE");
                var dialogMsg = bundleHandler.get("com.ptc.windchill.enterprise.change2.change2ClientResource.SUBMIT_NOW_MESSAGE");
                
                var submitNowButton = new ChangeConfirmDialogRenderer.button(submitNowButtonTxt, 'submitNowBtn', ChangeManagementSubmitHandler.buttonHandler);
                var submitLaterButton = new ChangeConfirmDialogRenderer.button(submitLaterButtonTxt, 'submitLaterBtn', ChangeManagementSubmitHandler.buttonHandler);
                var cancelButton = new ChangeConfirmDialogRenderer.button(cancelButtonTxt, 'cancelBtn', ChangeManagementSubmitHandler.buttonHandler);
                
                var buttons = [submitNowButton, submitLaterButton, cancelButton];
                
                submitDialog = ChangeConfirmDialogRenderer.createDialog(dialogTitle, dialogMsg, buttons);
                
            }
            stopProgress();
            submitDialog.show();
            
            return submitDialog;
        },
        
        
        
        /* Set the submission selection based on the button clicked. */
        processAndSubmit: function(val){
            var sel = Ext.getDom('submissionSelection');
            if (sel && sel !== null) {
                sel.value = (val === true) ? "true" : "false";
            }
            
            onSubmit(true);
        }
    };
}();

var changeTaskReviewerHandler = function(){
    var EDIT_ATTRIBUTE_STEP = "editAttributesWizStep";
    var CREATE_ATTRIBUTE_STEP = "setAttributesWizStep";
    var BUTTON_SUFFIX = "_button";
    var INPUT_ID = "changeTask_ReviewerPicker_dn_Id";
    var ASSIGNEE = "assignee";
    var REVIEWER = "reviewer";
    var HIDDEN_ID = "changeTask_ReviewerPicker_dn";
    var REVIEW_REQUIRED = "reviewRequired";
    var BUTTON_ID = "changeTask_ReviewerPicker_dn_FIND_BTN";
    var generatedInputId = null;
    var initialTableHeaderValue = null;
    var INITIAL_REQUIRED_VALUE = "initialRequiredValue";
    var TEXT_SUFFIX = "___textbox";
    var OLD_SUFFIX = "___old";
    var script = "javascript";
    var DO_NOTHING = script + ":changeTaskReviewerHandler.doNothing();";
    
    var findButtonHref = null;
    
    
    function getButton(name){
        var button = Ext.getDom(getObjectHandle() + BUTTON_ID);
        return button;
    }
    
    function getInput(){
        if (!generatedInputId) {
            var inputElements = Ext.getDom(getCurrentStep()).getElementsByTagName("input");
            for (var i = 0, len = inputElements.length; i < len; i++) {
                if (inputElements[i].id && inputElements[i].id.indexOf(INPUT_ID + TEXT_SUFFIX) >= 0 && inputElements[i].id.indexOf(TEXT_SUFFIX + OLD_SUFFIX) < 0) {
                    generatedInputId = inputElements[i].id;
                    break;
                }
            }
        }
        return Ext.getDom(generatedInputId);
    }
    
    function updateInput(input, isEnabled) {
        var initialRequiredValueElement = getElementByName(getObjectHandle() + INITIAL_REQUIRED_VALUE);

        if(!initialRequiredValueElement){
            return;
        }

        var initialRequiredValue = initialRequiredValueElement.value;
        if(input !== null) {
           input.value = "";
           if (isEnabled) {
              input.className = initialRequiredValue;
           } else {
              input.className = '';
           }
           input.disabled = !isEnabled;
        }
    }
    
    function updateInputs(isEnabled){
        updateInput(getInput(), isEnabled);
        updateInput(Ext.getDom(getObjectHandle() + HIDDEN_ID), isEnabled);      
    }
    
    function updateRowHeader(isEnabled){
        // get object of reviewer input field. We need this to navigate till 
        // the reviewer attribute asterisk field, to remove it when review is not required.
        var tr = getInput();
        
        // In case of multi-participants change task this field will be null, hence we will return.
        if(!tr){
            return;
        }
        
        tr = tr.parentNode.parentNode.parentNode.parentNode;
        
        var th = null;
        var trChilds = tr.getElementsByTagName('td');
        for (var i = 0, len = trChilds.length; i < len; i++) {
            var child = trChilds[i];
            if (child.className && child.className === 'attributePanel-asterisk') {
                th = trChilds[i];
                break;
            }
        }
        if (!th) {
            return;
        }
        var initialRequiredValue = getElementByName(getObjectHandle() + INITIAL_REQUIRED_VALUE).value;
        initialTableHeaderValue = "";
        if (initialRequiredValue !== "") {
            initialTableHeaderValue = "*";
        }
        
        if (isEnabled) {
            th.innerHTML = initialTableHeaderValue;
        }
        else {
            th.innerHTML = '';
        }
        
    }
    
    function updateFindButton(isEnabled){
        var button = getButton(REVIEWER);
        
        if(!button) {
            return;
        }
        
        if (isEnabled && findButtonHref !== null) {
            button.href = findButtonHref;
        }
        else 
            if (!isEnabled) {
                findButtonHref = button.href;
                button.href = DO_NOTHING;
            }
        button.disabled = !isEnabled;
    }
    
    
    return {
    
        onload: function(){
            var reviewRequired = getElementByName(getObjectHandle() + REVIEW_REQUIRED);
            if (reviewRequired && reviewRequired !== null) {
                var checkBox = Ext.getDom(REVIEW_REQUIRED + "___checkBox");
                if (checkBox !== null && !checkBox.checked) {
                    setTimeout(function() {		
                    	changeTaskReviewerHandler.clickedReviewRequired(checkBox);
                    }, 250);
                }
            }
        },
        
        clickedReviewRequired: function(checkBox){
            reviewRequired = getElementByName(getObjectHandle() + REVIEW_REQUIRED);
            
            var isEnabled = false;
            if (checkBox !== null && checkBox.checked) {
                isEnabled = true;
            }
            reviewRequired.value = isEnabled;
            updateInputs(isEnabled);
            updateFindButton(isEnabled);
            updateRowHeader(isEnabled);
        },
        
        // Call PickerInputComponentCallback to pick reviewer only if
        // Find button is not greyed out (disabled)
        reviewerCallback: function(objects, pickerID, attr, displayFieldId){
            var button = getButton(REVIEWER);
            if (button !== null && button.disabled !== true) {
                PickerInputComponentCallback(objects, pickerID, attr, displayFieldId);
            }
        },
        
        doNothing: function(){
            // do nothing
        }
    };
}();

// Handler for processing the create and edit change task wizards
var changeTaskLoadHandler = function(){

    var IMPLEMENTATION_TABLE_ID = "changeNotice.wizardImplementationPlan.table";
    
    function commonConfig(){
        changeTaskReviewerHandler.onload();
        if (PTC.lightbox.isLightbox(self)) {
            setUserSubmitFunction(updateHiddenSequenceValue);
        }
    }
    
    
    //This function will set the hidden sequence id from
    //the perspective of the change task window.
    function setHiddenSequence(id, value){
        appendFormHiddenInput(Ext.getDom("mainform"), id, value);
    }
    
    //Returns the sequence id for the change task that was clicked.
    //The oid is generated from the iframe id which contains the information
    //regarding which oid was clicked.
    function getSequenceId(){
        var identifier = "_changeTaskSequence";
        var iframe_id = parent.PTC.wizardIframes.getWizardIframeId();
        var oid = PTC.wizardIframes.submitHandler.convertURLIframeOid(iframe_id);
        return oid + identifier;
    }
    
    //This function gets the sequence id for the change
    //task that is being edited, and stores its sequence value
    //within a hidden field.
    function updateHiddenSequenceValue(){
        var seqId = getSequenceId();
        if (seqId !== null) {
            var value = getSequenceValue(seqId);
            if (value !== null && value !== '') {
                setHiddenSequence(seqId, value);
            }
        }
    }
    
    //Get the value of the sequence typed by the user.
    function getSequenceValue(id){
        var value = '';
        var parentWindow = PTC.lightbox.getParentWindow();
        var ele = parentWindow.Ext.getDom(id);
        if (ele && ele !== null) {
            value = ele.value;
        }
        return value;
    }
    
    return {
        /* This function is for loading the Change task details step of a Create Wizard */
        create: function(){
            commonConfig();
            if (steps.length > 1) {
                loadAllRemainingNonRequiredSteps();
            }
            return true;
        },
        /* This function is for loading the Change task details step of a Edit Wizard */
        edit: function(){
            PTC.wizardIframes.submitHandler.initWizard();
            commonConfig();
            /* Selected objects from an change info page table on edit should not be required.  
             * Additionally causes issues with selections for wizard table actions. */
            $A(document.forms.mainform["soid"]).each( function (item) { item.disabled=true;});      
            $A(document.forms.mainform["wizardSelectedObjects"]).each( function (item) { item.disabled=true;});
            if (steps.length > 1) {
                disableOkButton();
                loadAllRemainingNonRequiredSteps();
            }
            return true;
        }
    };
}();

// This function is to add the hidden input element that holds the values of the
// objects in the change table that the popup wizard action was launched from and
// copy the hidden input element into the popup action wizard.
function getChangeTableElement(){
    var mform = getMainForm();
    var INITIAL_ROWS_PREFIX = 'initialRows_';
    var ADDED_ROWS_PREFIX = 'addRows_';
    var REMOVED_ROWS_PREFIX = 'rmRows_';
    
    var tableId = ChangeUtils.getTableID(true);
    var initialOidNode = opener.tableUtils.getInitialRows(tableId);
    var addedOidNode = opener.tableUtils.getAddedRows(tableId);
    var removedOidNode = opener.tableUtils.getRemovedRows(tableId);
    
    var initialOidValue = (initialOidNode && initialOidNode !== null) ? initialOidNode.value : '';
    var addedOidValue = (addedOidNode && addedOidNode !== null) ? addedOidNode.value : '';
    var removedOidValue = (removedOidNode && removedOidNode !== null) ? removedOidNode.value : '';
    
    appendFormHiddenInput(mform, INITIAL_ROWS_PREFIX + tableId, initialOidValue);
    appendFormHiddenInput(mform, ADDED_ROWS_PREFIX + tableId, addedOidValue);
    appendFormHiddenInput(mform, REMOVED_ROWS_PREFIX + tableId, removedOidValue);
}

// This function is to get the hidden input elements that holds the values of the
// objects in the change table.
function getChangeInputElementByName(doc, hiddenTableInputName){
    var elements = doc.getElementsByTagName("input");
    var length = elements.length;
    var hiddenTableInput = Array();
    var next = 0;
    for (var i = 0; i < length; i++) {
        if (elements[i].name == hiddenTableInputName) {
            hiddenTableInput[next++] = elements[i];
        }
    }
    return hiddenTableInput;
}

// validate change task create permissions
function validateHasCreatableChangeTask(){
    PTC.onReady(function(){
        var ele = Ext.getDom('hasCreatableChangeTasks');
        if (typeof typeEle !== 'undefined' && typeEle.length > 0 && ele && ele !== null && ele.value === 'false') {
            JCAAlert(CHG_RESOURCE + '.CREATECHANGENOTICE_NO_TASK_TYPES');
            wfWindowClose1();
        }
    });
}

PTC.change.linkAttributeHelper = function(){
    var DATA = "Data";
    var CHG_INIT_KEYS = "change_tableData";
    var SEP = "#";
    var tableIdArray = [];
    var dirtyStepTableIds = [];
    var registered = false;
    
    function getLinkId(obj, id){
        return obj + SEP + id;
    }
    
    function getOidComponentIdMap(id){
        var data = {
            oid: null,
            componentId: null
        };
        if (id && id.indexOf(SEP) > 0) {
            var obj = id.split(SEP);
            data.oid = obj[0];
            data.componentId = obj[1] + DATA;
        }
        return data;
    }
    
    function getElement(doc, obj, id){
        return doc.getElementById(getLinkId(obj, id));
    }
    
    // support for legacy x10 & x12
    function legacyUpdate(item){
        var id = getObjectHandle() + "#" + item.id;
        var elem = Ext.getDom(id);
        if (!elem) {
            elem = opener.document.getElementById(id);
        }
        if (elem) {
            elem.value = item.value;
        }
    }
    
    function update(item, tableId){
        var map = getOidComponentIdMap(item.id);
        var record = tableUtils._getTableRow(tableId, map.oid);
        if(record !== undefined){
            var dataColKeys = getDataColumnKeys(record);
            initRecord(dataColKeys, tableId, record, false);   
        }
        PTC.util.tableDataManager.put(tableId, map.oid, map.componentId, item.value);
    }
    
    function getDataColumnKeys(record){
        var dataColKeys = record.get(CHG_INIT_KEYS);
        var keys = [];
        if (dataColKeys && dataColKeys !== '') {
            keys = dataColKeys.split('#');
        }
        return keys;
    }
    
    function initRecord(keys, tableId, record, alwaysUpdate, win){
        if (!win) {
            win = window;
        }
        var oid = record.get('oid');
        for (var i = 0, l = keys.length; i < l; i++) {
            var key = keys[i];
            if (key.indexOf(DATA) < 0) {
                key = key + DATA;
            }
            var val = record.get(key);
            val = Ext.util.Format.htmlDecode(val);
            if (val === "&nbsp;" || val === undefined) {
                val = "";
            }
            var updateRecord = true;
            if (!alwaysUpdate) {
                updateRecord = false;
                var currentVal = win.PTC.util.tableDataManager.get(tableId, oid, key);
                if (!currentVal) {
                    if (window !== win) {
                        win.PTC.util.tableDataManager.put(tableId, oid, key, val);
                    }
                    updateRecord = true;
                }
                else 
                    if (window !== win) {
                        val = currentVal;
                        updateRecord = true;
                    }
            }
            if (updateRecord) {
                PTC.util.tableDataManager.put(tableId, oid, key, val);
            }
        }
    }
    
    function initTable(tableId, isSelectAction, alwaysUpdate){
        var table = tableUtils.getTable(tableId);
        var records = [];
        if (isSelectAction) {
            var selectionModel = table.getSelectionModel();
            records = selectionModel.getSelections();
        }
        else {
            var rows = tableUtils.getTableRows(table);
            records = rows.items;
        }
        var dataColKeys = null;
        for (var i = 0, l = records.length; i < l; i++) {
            var record = records[i];
            if (!dataColKeys) {
                dataColKeys = getDataColumnKeys(record);
            }
            initRecord(dataColKeys, tableId, record, alwaysUpdate);
        }
    }
    
    return {
        init: function(tableId){
            if(tableIdArray.join().indexOf(tableId) !== -1) {
                return;
            }
            tableIdArray.push(tableId);
            var table = tableUtils.getTable(tableId);
            table.on('domchange', PTC.change.linkAttributeHelper.updateItem);
            table.store.on("customfeedbackavailable", PTC.change.linkAttributeHelper.initialRowsFeedbackListner);
                        
            PTC.util.tableDataManager.registerTableListener(tableId);
            
            if(registered === false) {
                markDownstreamNonPreloadedWizStepsDirty = markDownstreamNonPreloadedWizStepsDirty.wrap(PTC.change.linkAttributeHelper.handleTypeChange);
                var domChanges = PTC.wizard.saveTableData.registerDomChangeEvents;
                PTC.wizard.saveTableData.registerDomChangeEvents = domChanges.wrap(function(original){
                    original();
                    for (var i = 0, l = tableIdArray.length; i < l; i++) {
                        var table = tableUtils.getTable(tableIdArray[i]);
                        if (table) {
                            table.on('domchange', PTC.change.linkAttributeHelper.updateItem);
                        }
                    }
                });
                registered = true;
            }            
        },
        
        handleTypeChange : function(original) {
            original();
            tableIdArray = [];
        },
        
        updateItem: function(table, item, record, cell){
            PTC.change.linkAttributeHelper.update(item, table.id);
        },
        
        processSelection: function(dispositions, dispositionObjs, tableId){
            dispositions.each(function(obj){
                var s = Ext.getDom(obj.name);
                if (s) {
                    var val = obj.value;
                    for (i = 0, l = dispositionObjs.length; i < l; i++) {
                        var item = {
                            id: getLinkId(dispositionObjs[i], obj.name),
                            value: val
                        };
                        opener.PTC.change.linkAttributeHelper.update(item, tableId);
                    }
                }
            });
            // update table
            opener.refreshCurrentElementID(tableId);
            wfWindowClose();
        },
        
        // Will update the element matching the given elements id with the prefix
        // value.  This is used on the "onBlur" events of the Description table (and
        // other tables.
        update: function(item, tableId){
            if (!tableId) {
                legacyUpdate(item);
            }
            else {
                update(item, tableId);
            }
        },
        
        updateClearChkbox: function(item, chkboxId){
            if (item) {
                var chkbox = Ext.getDom(chkboxId);
                if (chkbox) {
                    if (item.value === "") {
                        chkbox.disabled = false;
                    }
                    else {
                        chkbox.checked = false;
                        chkbox.disabled = true;
                    }
                }
            }
        },
        
        handleToolbarAction: function(event, isSelectAction, alwaysUpdate){
            var tableId = tableUtils.findTableID(event);
            if (tableId) {
                initTable(tableId, isSelectAction, alwaysUpdate);
            }
            PTC.util.tableDataManager.handleSubmit();
            return true;
        },
        
        handleSelectAction: function(event, alwaysUpdate){
            return this.handleToolbarAction(event, true, alwaysUpdate);
        },
        
        handleAction: function(tableId, alwaysUpdate){
            if (!tableId) {
                tableId = ChangeUtils.getTableID(true);
            }
            var oid = ChangeUtils.getOid(true);
            var record = opener.tableUtils._getTableRow(tableId, oid);
            if (record) {
                var dataColKeys = getDataColumnKeys(record);
                initRecord(dataColKeys, tableId, record, alwaysUpdate, opener);
                PTC.util.tableDataManager.handleSubmit();
            }
            return true;
        },
        
        handleDispositionAction: function(alwaysUpdate){
            var modeEle = Ext.getDom('operation');
            var handleAction = true;
            if (modeEle) {
                var operation = modeEle.value;
                if (operation === "EDIT") {
                    handleAction = false;
                }
                else 
                    if (operation === "VIEW") {
                        alwaysUpdate = true;
                    }
            }
            if (handleAction) {
                this.handleAction(null, alwaysUpdate);
            }
            return false;
        },
        
        initOids: function(keys, tableId, oids, alwaysUpdate){
            for (var i = 0, l = oids.length; i < l; i++) {
                var record = tableUtils._getTableRow(tableId, oids[i]);
                initRecord(keys, tableId, record, alwaysUpdate);
            }
        },
        
        getValue: function(tableId, record, key){
            var oid = record.get('oid');
            var attr = key + DATA;
            var value = PTC.util.tableDataManager.get(tableId, oid, attr);
            if (!value) {
                value = record.get(attr);
            }
            return value;
        }, 
		
		// To initialize special column data in table data manager for initially selected data in a table.
        initialRowsFeedbackListner: function (feedbacks) {
            var len = feedbacks.length;
            var tableId;
            var processedFeedbacks = false;
            for(var i=0; (i<len && processedFeedbacks === false); i++) {
                var feedback = feedbacks[i];
                if(feedback !== undefined && feedback.data !== undefined && feedback.type === 599) {
                    var data = feedback.data;
                    tableId = data.tableId; 
                    var initialSelData = Ext.util.JSON.decode(data.initialSelectionData);
                    for(var j = 0; j < initialSelData.length; j++) {
                        var obj = initialSelData[j];
                        PTC.util.tableDataManager.put(tableId, obj.oid, obj.key, obj.value); 
                        processedFeedbacks = true;	
                    }  
                			
                }
            }
            //Only expecting one feedback message from the builder which contains initial selection data for one table at a time.
            if(tableId){
                //once we update, then unregister the listener
                var table = PTC.jca.table.Utils.getTable(tableId);
                table.store.un("customfeedbackavailable", PTC.change.linkAttributeHelper.initialRowsFeedbackListner);
            }
            return true;
        }		
    };
}();

var ptcChgLAH = PTC.change.linkAttributeHelper;

// Will update the element matching the given elements id with the prefix
// value.  This is used on the "onBlur" events of the Description table (and
// other tables.
// @Deprecated use ptcChgLAH.update( Item )
function chg_ud(item){
    ptcChgLAH.update(item, null);
}

PTC.change.revise = function(){
    var RESULTING_TABLE_ID = "changeTask_resultingItems_table";
    var REV_FUNCTION_ID = 'ReviseCallBackFunction';
    var changeTableId = "changeTask_affectedItems_table";
    
    return {
        init: function(tableId){
            changeTableId = tableId;
            launchWindowForMultiSelectAction = PTC.change.revise.launchWindowForMultiSelectAction;
        },
        
        launchWindowForMultiSelectAction: function(newURL, winName, props){
            var aSource = 'ActionSource';
            var selected = tableUtils.getTableSelectedRowsById(changeTableId);
            var oids = oidUtils.newOidSet(selected);
            
            if (!$(aSource)) {
                appendFormHiddenInput($("mainform"), aSource, 'changeOidList');
                appendFormHiddenInput($("mainform"), 'changeOidList', oids);
            }
            else {
                // update changeOidList input
                $(aSource).value = 'changeOidList';
                $('changeOidList').value = oids;
            }
            
            var revFuncInput = Ext.getDom(REV_FUNCTION_ID);
            if (!revFuncInput) {
                appendFormHiddenInput($("mainform"), REV_FUNCTION_ID, REV_FUNCTION_ID);
            }
            else {
                revFuncInput.value = REV_FUNCTION_ID;
            }
            
            var jcaSelect = 'ignore_selected_oids';
            appendFormHiddenInput($("mainform"), jcaSelect, 'true');
            
            
            if (isSomethingChecked(changeTableId)) {
                submitFormToNewWindow(newURL, winName, props, "mainform");
            }
            else {
                JCAAlert("com.ptc.netmarkets.util.utilResource.NO_OBJECT_SELECTED");
            }
        },
        
        callBackFunction: function(revisedObjects){
            var table = tableUtils.getTable(changeTableId);
            var sm = table.getSelectionModel();
            sm.clearSelections();
            PTC.change.changeable.addRows(revisedObjects, RESULTING_TABLE_ID, 'revise');
        }
    };
}();


PTC.change.changeable = function(){

    var getRequestOptions = function(oids, tableId, componentId) {
        var addedParams = {
            chg_selectedOids: oids.join('#'),
            chg_componentId: componentId,
            chg_tableId: tableId
        };
        
        var options = {
            asynchronous: true,
            method: 'post',
            parameters: getFormData() + '&' + Ext.urlEncode(addedParams),
            onSuccess: PTC.change.changeable.handleResponse,
            onFailure: PTC.change.changeable.handleFailure
        };
        return options;
    };

    /**
     * Validate selected results
     */
    var validate = function(oids, tableId, componentId){
        var options = getRequestOptions(oids, tableId, componentId);
        return requestHandler.doRequest('ptc1/changeableValidation', options);
    };
    
    /**
     * Convert part end-items to Masters
     */
    var convertToMasters = function(oids, tableId, componentId){
        var options = getRequestOptions(oids, tableId, componentId);
        return requestHandler.doRequest('ptc1/partEndItemToPartMaster', options);
    };    
    
    return {
        addRows: function(oids, tableId, componentId){
            goProgress();
            if(componentId === 'affectedEndItemPicker') {
                convertToMasters(oids, tableId, componentId);
            } else {
                validate(oids, tableId, componentId);
            }
        },
        
        handleResponse: function(resp){
            stopProgress();
            var json = Ext.util.JSON.decode(resp.responseText);
            if (json.formResult) {
                json.formResult.evalScripts();
            }
            if (json.success === true && json.tableId) {
                pickerAddItems(json, json.tableId);
            }
        },

        handleFailure: function(request, err) {
            stopProgress();
            requestHandler.defaultExceptionHandler(request, err);
        },
        
        collectorCallBack: function(results, tableId){
            if (results && results.getOIDs()) {
                var resultList = results.getOIDs();
                PTC.change.changeable.addRows(resultList, tableId, 'collect');
            }
        },
        
        /**
         * Converts the selected part end-items to masters and adds masters to the table.
         */ 
        addEndItems : function(objects, pickerId) {
            var tableId = PTC.change.pickerConfig[pickerId];        
            var myJSONObjects = objects.pickedObject;
            var list = [];
    
            for (var i = 0, l = myJSONObjects.length; i < l; i++) {
               list.push(myJSONObjects[i]["oid"]);
            }            
            PTC.change.changeable.addRows(list, tableId, pickerId);
        }
    };
}();

PTC.change.setReleaseTarget = function(event){
    var table = tableUtils.getTable(PTC.change.RESULTING_OBJECTS_TABLE_ID);
    var selections = table.getSelectionModel().getSelections();
    
    if (selections.length > 0) {
        var options = {
            asynchronous: true,
            method: 'post',
            parameters: getFormData(),
            onSuccess: PTC.change.createReleaseTargetPicker
        };
        
        requestHandler.doRequest('ptc1/setReleaseTarget', options);
    }
    else {
        JCAAlert("com.ptc.netmarkets.util.utilResource.NO_OBJECT_SELECTED");
    }
};

PTC.change.createReleaseTargetPicker = function(resp){
    var data = Ext.util.JSON.decode(resp.responseText);
    
    if (data.success === false) {
        if (data.message) {
            data.message.evalScripts();
        }
        return;
    }
    var pickerWindow = new Ext.Window({
        id: 'releaseTargetPickerWindow',
        autoCreate: true,
        title: data.title,
        resizable: false,
        constrain: true,
        constrainHeader: true,
        minimizable: false,
        maximizable: false,
        stateful: false,
        modal: true,
        width: data.width,
        height: data.height,
        footer: true,
        closable: true,
        layout: 'fit',
        autoScroll: true,
        items: [new Ext.Panel({
            border: false,
            baseCls: 'x-window-plain',
            id: 'releaseTargetAttributePanel',
            items: [{
                xtype: 'component',
                cls: 'contentloading',
                style: 'height: 100%'
            }]
        })]
    });
    
    var buttons = data.buttons;
    for (var i = 0, l = buttons.length; i < l; i++) {
        var button = buttons[i];
        pickerWindow.addButton({
            text: button.text,
            id: button.id,
            handler: eval(button.handler)
        });
    }
    pickerWindow.show();
    
    refreshElement('releaseTargetAttributePanel', data.url, false, true);
};

PTC.change.closeReleaseTargetPicker = function(button){
    if (button.id === 'releaseTarget.okButton') {
        var targetSelected = Ext.getDom('setMultipleReleaseTargets');
        if (!targetSelected) {
            targetSelected = getElementByName('setMultipleReleaseTargets');
        }
        if (targetSelected && targetSelected.value) {
            var value = targetSelected.value;
            var table = tableUtils.getTable(PTC.change.RESULTING_OBJECTS_TABLE_ID);
            var selections = table.getSelectionModel().getSelections();
            var updatedOids = [];
            for (var i = 0, l = selections.length; i < l; i++) {
                var oid = selections[i].get('oid');
                PTC.util.tableDataManager.put(PTC.change.RESULTING_OBJECTS_TABLE_ID, oid, 'changeTargetTransitionData', value);
                updatedOids.push(oid);
            }
            var params = (selections.length > 50) ? {
                refreshTable: true
            } : {
                doAjaxUpdate: true
            };
            rowHandler.updateRows(updatedOids, PTC.change.RESULTING_OBJECTS_TABLE_ID, params);
        }
    }
    var lbWindow = Ext.getCmp('releaseTargetPickerWindow');
    lbWindow.close();
};

PTC.change.processChangeCompare = function(locale) {
    var changeSummaryTableId = 'changeNotice.changeSummary';
    var changeTaskReferenceData = 'changeTaskReferenceData';
    var linkTypeReferenceData = 'changeLinkReferenceData';
    var tableid = ChangeUtils.getTableID(true);
    var table = opener.tableUtils.getTable(tableid);
    var selections = table.getSelectionModel().getSelections();
    var scParams = '';

    var isInWizard = false;
    var operation = opener.getElementByName('operation');
    if(operation && operation.value !== null) {
        isInWizard = (operation.value === 'EDIT' || operation.value === 'CREATE');
    }
    if(!isInWizard && typeof opener.getObjectHandle === 'function') {
        var objHandleid = opener.getObjectHandle();
        if(objHandleid && objHandleid !== null) {
            var objHandle = opener.getElementByName(objHandleid+'operation');
            isInWizard = (objHandle.value === 'EDIT' || objHandle.value === 'CREATE');
        }
    }
    
    var rightClickOid = ChangeUtils.getOid();
    var isRightClick = (selections.length === 0 && rightClickOid);
    if(selections.length === 1 || isRightClick) {
        var params = null;
        var selectedChangeable = null;
        var changeActivity = null;
        if(selections.length > 0) {
            selectedChangeable = selections[0].get('oid');
            changeActivity = selections[0].get(changeTaskReferenceData);
        } else {
            selectedChangeable = rightClickOid;
        }
        if(isInWizard) {
            var potentialSelections = PTC.change.RESULTING_OBJECTS_TABLE_ID;
            if(tableid === PTC.change.RESULTING_OBJECTS_TABLE_ID) {
                potentialSelections = 'changeTask_affectedItems_table';
            }
            var tableToCompare = opener.tableUtils.getTable(potentialSelections);
            
            // affected objects table may not be present (ex: in add to change task wizard)
            if(tableToCompare) {
                var tableItems = opener.tableUtils.getTableRows(tableToCompare).items;
                var len = tableItems.length;
                var changeableList = '';
                for(var i=0; i<len; i++) {
                    var item = null;
                    if(tableItems[i].item) {
                        item = tableItems[i].item.oid;
                    } else {
                        item = tableItems[i].data.oid;
                    }
                    changeableList += item + ',';
                }
            }
            params = 'changeable=' + selectedChangeable + '&changeableList=' + changeableList;
        } else {
            if(tableid === changeSummaryTableId) {
                var linkType = null;
                if(isRightClick) {
                    var row = opener.tableUtils._getTableRow(tableid, rightClickOid);
                    if(row && row !== null) {
                        linkType = row.get(linkTypeReferenceData);
                        changeActivity = row.get(changeTaskReferenceData);
                    }
                } else {
                    linkType = selections[0].get(linkTypeReferenceData);
                }
                params = 'changeActivity=' + changeActivity + '&' +'linkType=' + linkType + '&' +'changeable=' + selectedChangeable;
            } else if(!changeActivity || changeActivity === null) {
                changeActivity = ChangeUtils.getOid(true, true);
                params = 'changeActivity=' + changeActivity + '&' +'tableid=' + tableid + '&' +'changeable=' + selectedChangeable;
            }
        }
        var options = {
            asynchronous: false,
            method: 'post',
            parameters: params
        };
        var resp = requestHandler.doRequest('ptc1/changeableCompareController',options);
        scParams = 'multiSelect=false&oid='+selectedChangeable;
        if(resp.responseText.indexOf('error') === -1 && resp.responseText !== '') {
            var decodedResult = Ext.util.JSON.decode(resp.responseText);
            var autoCompareResult = decodedResult.oid;
            if(autoCompareResult !== null && selectedChangeable.indexOf(autoCompareResult) === -1) {
                scParams = 'multiSelect=true&oid1='+selectedChangeable+'&oid2=' + autoCompareResult;
            }
        }
    } else if(selections.length === 2) {
        var oid1 = selections[0].get('oid');
        var oid2 = selections[1].get('oid');
        scParams = 'multiSelect=true&oid1='+oid1+'&oid2=' + oid2;
    }
    var structureCompareURL =  $('basehref').href + 'netmarkets/jsp/structureCompare/StructureCompare.jsp?'+scParams;
    window.location.href = structureCompareURL;
};

PTC.change.onTemplatePickerChange = function() {
   PTC.wizard.attributePanelLoader.goAttributeTableProgress();
   PTC.driverAttributes.onChangeHandler();
};

// PTC.change.handleFormResult reloads the opener window if the wizards are launched from work item info pages .
PTC.change.handleFormResult = function(orig, formResult) {
   orig(formResult);
   var tableId = ChangeUtils.getTableID();
   var tableUrl = (opener)? opener.PTC.jca.table.Utils.getTableUrl(tableId) : null;
   if(tableUrl){
      var tableUrlParams = tableUrl.parseQuery();
      //pboCompId is only set on the url of the tables launched from work items pages
      if(tableId && tableUrlParams && tableUrlParams.pboCompId){
         window.opener.PTC.navigation.reload();
      }
   }
   return true;
};

PTC.change.endItemStep = function() {
   var stepName = "affectedEndItemsStep";
   
   return {
      callBack : function(resp) {
         var jsonObj = Ext.util.JSON.decode(resp.responseText);
         var results = jsonObj.response;
         if (results !== null && results.status != null
                    && (results.status === "PERMITTED" || results.status === "ENABLED")) { 
            insertStep(stepName);
         }else {
            removeStep(stepName);
         }    
      },
      
      displayStep : function() {
        if(wizardSteps[stepName]){
           PTC.validation.callAJAXValidation(stepName, null, PTC.change.endItemStep.callBack, true);
         }
      },
      
      contextChanged : function(objects, pickerId){
         contextChanged(objects, pickerId);
         this.displayStep();   
      },
      
      callContextChange : function(pickerId){
         callContextChange(pickerId);
         this.displayStep();   
      }
   };
}();


/**
* This table plugin is responsible for handling refreshes to the table after changing views or other reloads.
*
* @class PTC.change.ChangeTablePlugin
* @extends Object
* Plugin (ptype = 'changeTablePlugin')
*
* @constructor
* @param {Object} config Configuration options
* @ptype changeTablePlugin
*/
PTC.change.ChangeTablePlugin = Ext.extend(Object, {

    constructor: function(config){
        config = config || {};
        Ext.apply(this, config);
    },

    init: function(table){
        PTC.change.linkAttributeHelper.init(table.id);
    }
});
Ext.preg('changeTablePlugin', PTC.change.ChangeTablePlugin);

/**
 * When launching a new wizard from an info page of a changeable a listener needs to be registered to update the
 * openerCompContext and openerElement in the case that the user checks in, checks out, or does an undo checkout
 * while the create change wizard is open.
 */
PTC.change.onInfoPageUpdate = function(refreshInfo) {
   PTC.change.onWorkableUpdate(refreshInfo, true);
};

/**
 * When launching a new wizard from a Workable a listener needs to be registered to update the
 * openerCompContext and openerElement in the case that the user checks in, checks out, or does an undo checkout
 * while the create change wizard is open.
 */
PTC.change.onWorkableUpdate = function(refreshInfo, isInfoPage) {
   if(getPopupOpenerWindow()) {
      var parentOid = null;
      var mainForm = getMainForm();
      
      if(refreshInfo.hasUpdatedOids() && mainForm.openerElemAddress) {
         var openerAddress = mainForm.openerElemAddress.value;
         if(openerAddress && openerAddress.length > 2) {
            var openerOid = openerAddress.substring(0, openerAddress.length-2);
            parentOid = refreshInfo.getUpdatedOid(openerOid);
         }          
      } 
      
      if(parentOid === null) {
         return;
      }
      
      if(isInfoPage === true && mainForm.openerCompContext) {
         mainForm.openerCompContext.value="tcomp$infoPage$"+parentOid+"$";
      }
      
      if(mainForm.openerElemAddress) {
         mainForm.openerElemAddress.value=parentOid+"!*";
      }
   }
};

