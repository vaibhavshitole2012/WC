﻿Il file ZIP contiene informazioni del package estratte da Windchill. È possibile visualizzare il contenuto del package tramite un visualizzatore Web non in linea disponibile nel file ZIP. È inoltre possibile accedere direttamente ai file del package e importarli nel sistema in uso.

Sebbene il processo possa variare a seconda della configurazione del sistema, per accedere alle informazioni del package, attenersi alla procedura di base riportata di seguito.

1. Utilizzare un'utilità ZIP quale WinZip per estrarre il package in una nuova cartelle del disco rigido.

2. Spostarsi nella posizione selezionata per il file ZIP del package. La cartella conterrà un elenco di dati. Per visualizzare il file ZIP del package, scegliere uno dei due modi descritti di seguito.
- Per visualizzare le informazioni del package nel browser Web, fare doppio clic su file index.html. A seconda della configurazione del sistema in uso, il package verrà aperto nel browser Web preferito.
- Se non si desidera visualizzare le informazioni del package tramite il visualizzatore non in linea, aprire la cartella Contents. La cartella contiene tutte le rappresentazioni, i file delle parti e gli allegati inclusi nel package. Si può utilizzare questa cartella per importare direttamente i file del package nel sistema.

3. In caso di apertura del file index.html, nel browser verrà visualizzata la pagina Package Details.

Per ulteriori informazioni sulle informazioni del package disponibili nella vista non in linea, fare clic sul pulsante della Guida situato nella parte superiore della pagina.
