This ZIP file contains package information extracted from Windchill. You can
browse the contents of this package using the web-based offline viewer available
in this ZIP file. You can also access package content files directly and import
them into your own system.

Although this process may differ depending on how your system is configured, the
following basic steps will help you to navigate to the package information:

1. Using a ZIP utility such as WinZip, extract this package to a new folder on
your hard drive.

2. Navigate to the location you selected for the package ZIP file. The folder
will contain a list of data. From here, there are two ways to view your package
ZIP file:

- To view the package information in your web browser, double-click the
index.html file. Depending on how your system is configured, this should open
the package in your preferred web browser.

- If you do not want to view the package information using the offline viewer,
open the Contents folder. This folder contains all representations, part files
and attachments contained in the package. You can use this folder to directly
import package files into your system.

3. If you opened the index.html file, the Package Details page will open in your
browser.

For more information about the package information available in the offline
view, click the help button available at the top of the page.
