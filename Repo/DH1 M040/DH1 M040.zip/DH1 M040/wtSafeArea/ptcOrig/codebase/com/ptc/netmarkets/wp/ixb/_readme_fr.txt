﻿Ce fichier ZIP contient des informations de lot extraites de Windchill. Vous pouvez parcourir le contenu de ce lot en utilisant le visualiseur Web hors ligne inclus dans ce fichier. Vous pouvez aussi accéder directement aux fichiers de contenu du lot et les importer dans votre application.

La procédure peut varier en fonction de la configuration de votre système mais les étapes de base suivantes vous permettront d'accéder aux informations de lot :

1. A l'aide d'un utilitaire de compression tel que WinZip, extrayez ce lot dans un nouveau dossier sur votre ordinateur.

2. Accédez à l'emplacement sélectionné pour le fichier ZIP. Une liste de plusieurs fichiers apparaitront dans le dossier. Deux options s'offrent à vous pour visualiser le contenu du fichier ZIP du lot :
- Pour afficher les informations du lot dans notre navigateur Web, double-cliquez sur le fichier index.html. Selon la configuration de votre système, le lot devrait s'ouvrir dans votre navigateur préféré.
- Si vous ne voulez pas afficher les informations du lot dans un visualiseur hors ligne, ouvrez le dossier Contents. Ce dossier contient tous les fichiers d'articles, représentations et pièces jointes inclus dans le lot. Vous pouvez utiliser le dossier pour importer directement les fichiers du lot dans votre système.

3. Si vous ouvrez sur le fichier index.html, la page Package Details apparaît dans le navigateur.
Pour plus de détails sur les informations de lot disponibles dans la vue hors ligne, cliquez sur le bouton Aide en haut de la page.
