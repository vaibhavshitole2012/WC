/* bcwti
 *
 * Copyright (c) 2010 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */
package com.ptc.windchill.enterprise.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.ptc.core.meta.common.AttributeTypeIdentifier;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.HTTPRequestData;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import com.ptc.windchill.enterprise.attachments.server.AttachmentsDownloadDirectionRequest;
import com.ptc.windchill.enterprise.attachments.server.AttachmentsDownloadDirectionRequestHolder;
import com.ptc.windchill.enterprise.attachments.server.AttachmentsDownloadDirectionResponse;
import com.ptc.windchill.enterprise.attachments.server.AttachmentsDownloadDirectionResponseHolder;
import com.ptc.windchill.enterprise.attachments.server.AttachmentsHelper;
import com.ptc.windchill.enterprise.util.AttachmentsWebHelper;

import wt.access.AccessControlHelper;
import wt.access.NotAuthorizedException;
import wt.access.SecurityLabeled;
import wt.access.SecurityLabeledDownloadAcknowledgment;
import wt.access.configuration.SecurityLabel;
import wt.access.configuration.SecurityLabelsConfiguration;
import wt.access.configuration.SecurityLabelsHelper;
import wt.audit.AuditHelper;
import wt.content.ContentItem;
import wt.content.ContentRoleType;
import wt.doc.WTDocument;
import wt.fc.EnumeratedType;
import wt.fc.EnumeratedTypeUtil;
import wt.fc.ObjectNoLongerExistsException;
import wt.fc.ReferenceFactory;
import wt.fc.WTReference;
import wt.fc.collections.WTKeyedHashMap;
import wt.fc.collections.WTKeyedMap;
import wt.httpgw.URLFactory;
import wt.log4j.LogR;
import wt.type.TypedUtility;
import wt.util.HTMLEncoder;
import wt.util.LocalizableMessage;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;

/***
 * <pre>
 * This Servlet is a control component that decides how a attachment download request should processed and forwarded.  The basic logic is
 *     If user preference is browser download Then
 *         forward to browser download.
 *     Else if user preference is DTI download Then
 *         If browser DTI plug-in is available Then
 *             forward to DTI download
 *         Else if unknow DTI plug-in availabity Then
 *             forward to detect it
 *         Else if DTI plug-in is not avaliable Then
 *             forward to ask user if istall it or not
 *         Else if DTI plug-in is not avaliable and user does not want to or can not install it Then
 *             forward to browser download
 *
 * This Servlet accepts following request parameters:
 *     {PARA_CONTENT_HOLDER_OID} OID of content holder to download, required, only one value can be provided.  In some special cases,
 *     we use this as item OID, to be compitable, we still support it.  However, (EXTRA_PATH_SINGLE) is the flag to ask such a support.
 *     {PARA_CONTENT_ITEM_OIDS} OIDs of content items to download, optional.
 *         If the value is {PARA_TYPE_PRIMARY}, or if {EXTRA_PATH_PRIMARY} matched, only primary content will be downloaded;
 *         else if the value is {PARA_TYPE_ALL}, or if (EXTRA_PATH_ALL} matched, both primary and secondary contents will be downloaded;
 *         or if (EXTRA_PATH_SINGLE} matched, {PARA_CONTENT_HOLDER_OID} value will be used as item OID and content holder OID will be got
 *         according to the item OID behind seen;
 *         otherise, the multiple content item OIDs can be accepted as long as these are delimed by {PARA_DELIM_OID}.  However, those items
 *             must belong to the content holder.
 *     {PARA_SELECTED_WINDCHILL_REFERENCES} optional.  Standard winchill references of selected items.  It contains content item oid that
 *         this servlet needs.  This is an alternative of {PARA_CONTENT_ITEM_OIDS}.  If {PARA_CONTENT_ITEM_OIDS} is provided, this parameter
 *         will be ignored.  If {EXTRA_PATH_SELECTED} is not matched, this parameter is ignored.
 *     {PARA_DTI_STATUS} Update browser DTI plug-in availability status, optional, can have use one of these values: {PARA_STATUS_INSTALLED},
 *         plug-in is available; {PARA_STATUS_NOT_INSTALLED}, plug-in is not available; PARA_STATUS_INSTALLATION_REJECTED}, plug-in is not
 *         available and user has rejected to install it for this session; {PARA_STATUS_INSTALLATION_REJECTED_ONCE}, plug-in is not
 *         available and user has rejected to install it for this request; {PARA_STATUS_FAILED}, plug-in is not available and failed to install it.
 *         Note that this parameter is intended for DTI auto-detection page, links / actions that triggerred by end-user should not use it.
 *     {PARA_JRE_STATUS} Update browser JRE plug-in availablity status for applet downloading, optional, can one of those status values
 *         described above.
 *         Note that this parameter is intended for JRE auto-detection page, links / actions that triggerred by end-user should not use it.
 *     &#64;see DownloadStateManager
 *     {PARA_CONTENT_OID_PREFIX} Optional, this is for downloading items of multiple holders.  Parameter names must be this prefix plus
 *         content holder OID, parameter values must be content item OIDs delimed by {PARA_DELIM_OID} and must belong to the holder.
 *
 * Note that, links or java scripts that are against this Servlet must pop up target window in order to have correct UI flow.
 *
 * This Servlet might end up with following forwarding results.
 *     {FORWARD_DIRECT_DOWNLOAD} Forword to display that handles browser downloading.  AttachmentsDownloadDirectionResponse (result) is also
 *         passed through attributes of HttpServletRequest keyed by {REQUEST_KEY_DOWNLOAD_DIRECTION}
 *     {FORWARD_DETECT_DTI} Forward to display that handles browser DTI plugin detection.
 *     {FORWARD_CONFIRM_DTI} Forward to display that asks user installing DTI plug-in or not.
 *     {FROWARD_DTI_DOWNLOAD} Forward to display that handles DTI download.  AttachmentsDownloadDirectionResponse (result) is also
 *         passed through attributes of both HttpServletRequest and HttpSession, and both are keyed by {REQUEST_KEY_DOWNLOAD_DIRECTION}
 *     {@link} DTIActionServlet
 *     {FORWARD_DETECT_JRE} Forward to display that handles browser JRE plug-in detection.
 *     {FORWARD_CONFIRM_JRE} Forward to display that confirms if user want to install JRE or not.
 *     {FORWARD_NONE_DOWNLOADABLE} none of user selected content items can be downloaded.
 *     {FORWARD_NOT_EXIST} path forwared to when the content no longer exists
 *     {FORWARD_ERROR} Forward to display that handle error.  Exception is passed by HttpServletRequest attribute keyed by
 *         {REQUEST_KEY_ATTACHMENTS_EXCEPTION}
 *
 *     {EXTRA_PATH_ALL}, default is "/all", Extra servlet path info that indicates downloading all attachments items of the given content holders
 *         by their content holder OIDs.
 *     {EXTRA_PATH_PRIMARY} default is "/primary", Extra servlet path info that indicates downloading primary attachment item only of the given
 *         content holders by their holder OIDs.
 *     {EXTRA_PATH_SELECTED} default is "/selected", Extra servlet path info that indicates downloading multiple selected item of one content holders
 *         by given content item OIDs and the content holder OID.  Parameters names and format depend on JCA table.
 *     {EXTRA_PATH_SINGLE} default is "/single", Extra servlet path info that indicates downloading just one attachments item by given content item
 *         OID, note that, for this special case, content holder OID parameter is used for content item OID purpose.
 *     {EXTRA_PATH_DOCSBSELECTED} default is "/DOCSBselected", Extra servlet path info that indicates downloading multiple selected items from the new
 *         structure browser component. It usually passes the contents through PARA_SELECTED_WINDCHILL_REFERENCES
 *
 * Must configure forwarding path to map those results, and servlet extra path for distingush types of downloading requests.  The reasons we need
 * servlet path are common component table attachs multi-select parameters to all levels of actions, page level, table level and row level.  Plus
 * common component action do not allow dynamic parameter setting up.
 * The configurations are through servlet initial parameters in web.xml or so.  Here is a sample:
 *
 *     &lt;servlet&gt;
 *       &lt;description&gt;Windchill Attachment Download Direction Servlet&lt;/description&gt;
 *       &lt;servlet-name&gt;AttachmentsDownloadDirectionServlet&lt;/servlet-name&gt;
 *       &lt;servlet-class&gt;com.ptc.windchill.enterprise.servlets.AttachmentsDownloadDirectionServlet&lt;/servlet-class&gt;
 *       &lt;init-param&gt;
 *       &lt;param-name&gt;extra_path_all&lt;/param-name&gt;
 *       &lt;param-value&gt;/all&lt;/param-value&gt;
 *       &lt;/init-param&gt;
 *       &lt;init-param&gt;
 *       &lt;param-name&gt;extra_path_primary&lt;/param-name&gt;
 *       &lt;param-value&gt;/priamry&lt;/param-value&gt;
 *       &lt;/init-param&gt;
 *       &lt;init-param&gt;
 *       &lt;param-name&gt;extra_path_selected&lt;/param-name&gt;
 *       &lt;param-value&gt;/selected&lt;/param-value&gt;
 *       &lt;/init-param&gt;
 *       &lt;init-param&gt;
 *       &lt;param-name&gt;forward-direct-download&lt;/param-name&gt;
 *       &lt;param-value&gt;/netmarkets/jsp/attachments/download/browser.jsp&lt;/param-value&gt;
 *       &lt;/init-param&gt;
 *       &lt;init-param&gt;
 *       &lt;param-name&gt;forward-detect-dti&lt;/param-name&gt;
 *       &lt;param-value&gt;/netmarkets/jsp/attachments/download/detect_dti.jsp&lt;/param-value&gt;
 *       &lt;/init-param&gt;
 *       &lt;init-param&gt;
 *       &lt;param-name&gt;forward-confirm-dti&lt;/param-name&gt;
 *       &lt;param-value&gt;/netmarkets/jsp/attachments/download/confirm_dti.jsp&lt;/param-value&gt;
 *       &lt;/init-param&gt;
 *       &lt;init-param&gt;
 *       &lt;param-name&gt;forward-dti-download&lt;/param-name&gt;
 *       &lt;param-value&gt;/servlet/DTIActionServlet&lt;/param-value&gt;
 *       &lt;/init-param&gt;
 *       &lt;init-param&gt;
 *       &lt;param-name&gt;forward-detect-jre&lt;/param-name&gt;
 *       &lt;param-value&gt;/netmarkets/jsp/attachments/download/detect_jre.jsp&lt;/param-value&gt;
 *       &lt;/init-param&gt;
 *       &lt;init-param&gt;
 *       &lt;param-name&gt;forward-confirm-jre&lt;/param-name&gt;
 *       &lt;param-value&gt;/netmarkets/jsp/attachments/download/confirm_jre.jsp&lt;/param-value&gt;
 *       &lt;/init-param&gt;
 *       &lt;init-param&gt;
 *       &lt;param-name&gt;forward-applet-download&lt;/param-name&gt;
 *       &lt;param-value&gt;/netmarkets/jsp/attachments/download/applet.jsp&lt;/param-value&gt;
 *       &lt;/init-param&gt;
 *       &lt;init-param&gt;
 *       &lt;param-name&gt;forward-none-downloadable&lt;/param-name&gt;
 *       &lt;param-value&gt;/netmarkets/jsp/attachments/download/none_downloadable.jsp&lt;/param-value&gt;
 *       &lt;/init-param&gt;
 *       &lt;init-param&gt;
 *       &lt;param-name&gt;forward-error&lt;/param-name&gt;
 *       &lt;param-value&gt;/netmarkets/jsp/attachments/download/error.jsp&lt;/param-value&gt;
 *       &lt;/init-param&gt;
 *     &lt;/servlet&gt;
 *
 * This Servlet also always pass its own request URI through HttpServletRequest attribute keyed by {REQUEST_KEY_URI}.
 * The URI is for JSPs and Servlets downstream to construct links or so that come back this Servlet.
 * </pre>
 */
public final class AttachmentsDownloadDirectionServlet extends HttpServlet {

	private static final Logger clientLogger = LogR.getLogger("com.ptc.windchill.enterprise.servlets");

	private static final long serialVersionUID = 1L;

	public static final String EXTRA_PATH_ALL = "extra_path_all";

	public static final String EXTRA_PATH_PRIMARY = "extra_path_primary";

	public static final String EXTRA_PATH_SELECTED = "extra_path_selected";

	public static final String EXTRA_PATH_SINGLE = "extra_path_single";

	public static final String FORWARD_DIRECT_DOWNLOAD = "forward-direct-download";

	public static final String FORWARD_DETECT_DTI = "forward-detect-dti";

	public static final String FORWARD_CONFIRM_DTI = "forward-confirm-dti";

	public static final String FORWARD_DTI_DOWNLOAD = "forward-dti-download";

	public static final String FORWARD_DETECT_JRE = "forward-detect-jre";

	public static final String FORWARD_CONFIRM_JRE = "forward-confirm-jre";

	public static final String FORWARD_NONE_DOWNLOADABLE = "forward-none-downloadable";

	public static final String FORWARD_NOT_EXIST = "forward-not-exist";

	public static final String FORWARD_ERROR = "forward-error";

	public static final String PARA_DTI_STATUS = "adti";

	public static final String PARA_JRE_STATUS = "ajre";
	public static final String PARA_ACK_STATUS = "ack";
	public static final String PARA_STATUS_INSTALLED = DownloadStateManager.STR_STATUS_INSTALLED;

	public static final String PARA_STATUS_NOT_INSTALLED = DownloadStateManager.STR_STATUS_NOT_INSTALLED;

	public static final String PARA_STATUS_INSTALLATION_REJECTED = DownloadStateManager.STR_STATUS_INSTALLATION_REJECTED;

	public static final String PARA_STATUS_INSTALLATION_REJECTED_ONCE = DownloadStateManager.STR_STATUS_INSTALLATION_REJECTED_ONCE;

	public static final String PARA_STATUS_INSTALLATION_FAILED = DownloadStateManager.STR_STATUS_INSTALLATION_FAILED;
	public static final String PARA_ACK_STATUS_ACCEPT = "true";
	public static final String PARA_ACK_STATUS_REJECTED = "false";
	public static final String PARA_ACK_DOWNLOAD = "true";
	public static final String PARA_CACHING_URL = "url";

	public static final String PARA_CONTENT_OID_PREFIX = "coid_";

	public static final String PARA_CONTENT_HOLDER_OID = "oid";

	public static final String PARA_CONTENT_HOLDER_CHOID = "chOid";

	public static final String PARA_CONTENT_ITEM_OIDS = "cioids";

	public static final String PARA_SELECTED_WINDCHILL_REFERENCES = "soid";

	public static final String PARA_TYPE_PRIMARY = "primary";

	public static final String PARA_TYPE_ALL = "all";

	public static final String PARA_DELIM_OID = "||";

	public static final String REQUEST_KEY_DOWNLOAD_DIRECTION = "attachements-download-direction";

	public static final String REQUEST_KEY_ATTACHMENTS_EXCEPTION = "attachements-exception";

	public static final String REQUEST_KEY_URI = "attachments-download-uri";
	public static final String SECURITY_LABEL_MAP = "security-label-map";

	public static final String DOWNLOAD_STATE_FORMAT = "downloadStateFormat";

	private static final String PREF_KEY_MECHANISM = "/com/ptc/windchill/enterprise/attachments/downloadMechanism";

	private static final String SESSION_ACK = "sessiomAcknowledge";

	private static ReferenceFactory refFactory = new ReferenceFactory();
	private String paraACK = "";

	private static SecurityLabelsConfiguration labelConfig = null;

	@SuppressWarnings("unchecked")
	protected void processRequest(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setAttribute(REQUEST_KEY_URI, request.getRequestURI());
		/*
		 * boolean isUserAuthorizedToDownload = true; try { boolean
		 * isNeededToCheckActionAuthorization =
		 * ext.kb.accesscontrol.AccessControlHelper.isNeededToCheckDownloadAccess(
		 * request); if(isNeededToCheckActionAuthorization){ isUserAuthorizedToDownload
		 * = ext.kb.accesscontrol.AccessControlHelper.
		 * isUserAuthorizedToDownloadSharedObject(request); } } catch (WTException e) {
		 * String strForwardPath = getInitParameter(FORWARD_ERROR,
		 * "/netmarkets/jsp/attachments/download/error.jsp");
		 * clientLogger.error("Additional Download access check failed due to: ", e);
		 * response.setHeader("Cache-Control", "no-cache");
		 * request.getRequestDispatcher(strForwardPath).forward(request, response); }
		 *
		 * if(!isUserAuthorizedToDownload){ String strForwardPath =
		 * getInitParameter(FORWARD_NONE_DOWNLOADABLE,
		 * "/netmarkets/jsp/attachments/download/none_downloadable.jsp");
		 * response.setHeader("Cache-Control", "no-cache");
		 * request.getRequestDispatcher(strForwardPath).forward(request, response);
		 * return; }
		 */
		String paraDTI = HTMLEncoder.encodeForHTMLAttribute(request.getParameter(PARA_DTI_STATUS));
		String paraJRE = HTMLEncoder.encodeForHTMLAttribute(request.getParameter(PARA_JRE_STATUS));
		String paraAction = request.getParameter("subAction");
		// introduced the variable forceDTI to check if the sub action is
		// 'emailAttachments' from the email document
		// and so forcing the DTI download for the document's attachment.
		boolean forceDTI = false;
		if (paraAction != null && "emailAttachments".equals(paraAction)) {
			forceDTI = true;
			paraDTI = AttachmentsDownloadDirectionServlet.PARA_STATUS_INSTALLED;
		}

		String strForwardPath = null;

		try {
			AttachmentsDownloadDirectionRequest addRequest = null;
			AttachmentsDownloadDirectionResponse addResponse = null;

			// decision making
			DownloadStateManager states = DownloadStateManager.getDownloadStateManager(request);

			if (paraDTI != null && paraDTI.length() > 0 || forceDTI) {
				states.setDTIStatus(DownloadStateManager.transformStatus(paraDTI));
			}
			if (paraJRE != null && paraJRE.length() > 0) {
				states.setJREStatus(DownloadStateManager.transformStatus(paraJRE));
			}

			int iPref = getUserDownloadPreference(request);
			if (iPref == DownloadStateManager.I_PREFERENCE_BROWSER && !forceDTI) {
				Map<String, Object[]> slMap = new HashMap<>();

				addRequest = decodeRequest(request);
				addRequest.setDownloadType(AttachmentsDownloadDirectionRequest.I_TYPE_BROWSER);
				addResponse = AttachmentsHelper.service.downloadAttachmentDirections(addRequest);

				if (isSecurityLableInstalled()) {
					HttpSession session = request.getSession(true);
					Set downloadSessionAttribute = (Set) session.getAttribute(SESSION_ACK);
					if (downloadSessionAttribute == null) {
						downloadSessionAttribute = new HashSet<String>();
					}

					if (paraACK != null && paraACK.equals(PARA_ACK_STATUS_ACCEPT)
							&& downloadSessionAttribute.contains(request.getQueryString())) {
						downloadSessionAttribute.remove(request.getQueryString());
						session.setAttribute(SESSION_ACK, downloadSessionAttribute);
						if (getNumberOfItems(addResponse) > 0) {
							request.setAttribute(REQUEST_KEY_DOWNLOAD_DIRECTION, addResponse);
							strForwardPath = getInitParameter(FORWARD_DIRECT_DOWNLOAD,
									"/netmarkets/jsp/attachments/download/browser.jsp");
							// auditing the acceptance of acknowledgement
							dispatchSecurityLabelDownloadAckEvent(request);
						} else {
							strForwardPath = getInitParameter(FORWARD_NONE_DOWNLOADABLE,
									"/netmarkets/jsp/attachments/download/none_downloadable.jsp");
						}
					} else if (paraACK != null && paraACK.equals(PARA_ACK_STATUS_REJECTED)) {
						downloadSessionAttribute.remove(request.getQueryString());
						session.setAttribute(SESSION_ACK, downloadSessionAttribute);
						strForwardPath = getInitParameter(FORWARD_NONE_DOWNLOADABLE,
								"/netmarkets/jsp/attachments/download/none_downloadable.jsp");
					} else {
						if (getNumberOfItems(addResponse) > 0) {
							request.setAttribute(REQUEST_KEY_DOWNLOAD_DIRECTION, addResponse);

							URLFactory urlFactory = new URLFactory();
							String requestUri = request.getRequestURI();
							String resource = urlFactory.determineResource(requestUri);
							String queryString = request.getQueryString();
							String finalURL = urlFactory.getHREF(resource, queryString);
							clientLogger.debug(
									"resource:" + resource + "  queryString:" + queryString + "  finalURL:" + finalURL);

							request.setAttribute(PARA_CACHING_URL, finalURL);
							securityLabelSet(request, slMap);
							request.setAttribute(SECURITY_LABEL_MAP, slMap);
							request.setAttribute(DOWNLOAD_STATE_FORMAT, iPref);
							downloadSessionAttribute.add(request.getQueryString());
							session.setAttribute(SESSION_ACK, downloadSessionAttribute);
							if (slMap.isEmpty()) {
								strForwardPath = getInitParameter(FORWARD_DIRECT_DOWNLOAD,
										"/netmarkets/jsp/attachments/download/browser.jsp");
							} else {
								strForwardPath = getInitParameter(FORWARD_DIRECT_DOWNLOAD,
										"/netmarkets/jsp/attachments/download/openAcknowledgeConfirm.jsp");
							}
						} else {
							strForwardPath = getInitParameter(FORWARD_NONE_DOWNLOADABLE,
									"/netmarkets/jsp/attachments/download/none_downloadable.jsp");
						}
					}
				} else {
					if (getNumberOfItems(addResponse) > 0) {
						request.setAttribute(REQUEST_KEY_DOWNLOAD_DIRECTION, addResponse);
						strForwardPath = getInitParameter(FORWARD_DIRECT_DOWNLOAD,
								"/netmarkets/jsp/attachments/download/browser.jsp");
					} else {
						strForwardPath = getInitParameter(FORWARD_NONE_DOWNLOADABLE,
								"/netmarkets/jsp/attachments/download/none_downloadable.jsp");
					}
				}

			} else if (iPref == DownloadStateManager.I_PREFERENCE_DTI || forceDTI) {
				switch (states.getDTIStatus()) {
				case DownloadStateManager.I_STATUS_INSTALLED:
					addRequest = decodeRequest(request);
					addRequest.setDownloadType(AttachmentsDownloadDirectionRequest.I_TYPE_DTI);
					addResponse = AttachmentsHelper.service.downloadAttachmentDirections(addRequest);
					if (getNumberOfItems(addResponse) > 0) {
						populatePreferenceValues(request, addResponse);
						request.setAttribute(REQUEST_KEY_DOWNLOAD_DIRECTION, addResponse);
						request.getSession(true).setAttribute(REQUEST_KEY_DOWNLOAD_DIRECTION, addResponse); // for
						// closing
						// popup
						strForwardPath = getInitParameter(FORWARD_DTI_DOWNLOAD,
								"/netmarkets/jsp/attachments/download/dti.jsp");
					} else {
						strForwardPath = getInitParameter(FORWARD_NONE_DOWNLOADABLE,
								"/netmarkets/jsp/attachments/download/none_downloadable.jsp");
					}
					break;
				case DownloadStateManager.I_STATUS_UNKNOWN:
					strForwardPath = getInitParameter(FORWARD_DETECT_DTI,
							"/netmarkets/jsp/attachments/download/detect_dti.jsp");
					break;
				case DownloadStateManager.I_STATUS_NOT_INSTALLED:
					states.setDTIStatus(DownloadStateManager.I_STATUS_UNKNOWN);
					strForwardPath = getInitParameter(FORWARD_CONFIRM_DTI,
							"/netmarkets/jsp/attachments/download/confirm_dti.jsp");

					break;
				case DownloadStateManager.I_STATUS_INSTALLATION_REJECTED:
				case DownloadStateManager.I_STATUS_INSTALLATION_FAILED:
					addRequest = decodeRequest(request);
					addRequest.setDownloadType(AttachmentsDownloadDirectionRequest.I_TYPE_BROWSER);
					addResponse = AttachmentsHelper.service.downloadAttachmentDirections(addRequest);
					if (getNumberOfItems(addResponse) > 0) {
						request.setAttribute(REQUEST_KEY_DOWNLOAD_DIRECTION, addResponse);
						strForwardPath = getInitParameter(FORWARD_DIRECT_DOWNLOAD,
								"/netmarkets/jsp/attachments/download/browser.jsp");
					} else {
						strForwardPath = getInitParameter(FORWARD_NONE_DOWNLOADABLE,
								"/netmarkets/jsp/attachments/download/none_downloadable.jsp");
					}
					break;
				case DownloadStateManager.I_STATUS_INSTALLATION_REJECTED_ONCE:
					addRequest = decodeRequest(request);
					addRequest.setDownloadType(AttachmentsDownloadDirectionRequest.I_TYPE_BROWSER);
					addResponse = AttachmentsHelper.service.downloadAttachmentDirections(addRequest);
					if (getNumberOfItems(addResponse) > 0) {
						request.setAttribute(REQUEST_KEY_DOWNLOAD_DIRECTION, addResponse);
						strForwardPath = getInitParameter(FORWARD_DIRECT_DOWNLOAD,
								"/netmarkets/jsp/attachments/download/browser.jsp");
					} else {
						strForwardPath = getInitParameter(FORWARD_NONE_DOWNLOADABLE,
								"/netmarkets/jsp/attachments/download/none_downloadable.jsp");
					}
					states.setDTIStatus(DownloadStateManager.I_STATUS_NOT_INSTALLED);
					break;
				} // end switch dti
			} // end if iPref
		} catch (ServletException sex) {
			strForwardPath = getInitParameter(FORWARD_NONE_DOWNLOADABLE,
					"/netmarkets/jsp/attachments/download/none_downloadable.jsp");
		} catch (NotAuthorizedException naex) {
			strForwardPath = getInitParameter(FORWARD_NONE_DOWNLOADABLE,
					"/netmarkets/jsp/attachments/download/none_downloadable.jsp");
		} catch (ObjectNoLongerExistsException nexex) {
			strForwardPath = getInitParameter(FORWARD_NOT_EXIST, "/netmarkets/jsp/attachments/download/not_exist.jsp");
		} catch (Exception ex) {
			clientLogger.error(REQUEST_KEY_ATTACHMENTS_EXCEPTION, ex);
			request.setAttribute(REQUEST_KEY_ATTACHMENTS_EXCEPTION, ex);
			strForwardPath = getInitParameter(FORWARD_ERROR, "/netmarkets/jsp/attachments/download/error.jsp");
		} finally {
			response.setHeader("Cache-Control", "no-cache");
			request.getRequestDispatcher(strForwardPath).forward(request, response);
		} // end try
	}

	private boolean isSecurityLableInstalled() throws IOException, WTException {

		return SecurityLabelsHelper.isSecurityLabelFeatureEnabled();

	}

	private void securityLabelSet(HttpServletRequest request, Map<String, Object[]> slMap)
			throws IOException, WTException {
		String[] paraHolderOIDs = request.getParameterValues(PARA_CONTENT_HOLDER_OID);
		getSecrutiyLabels(paraHolderOIDs, slMap, request);
	}

	private void getSecrutiyLabels(String[] paraHolderOIDs, Map<String, Object[]> slMap, HttpServletRequest request)
			throws WTException, IOException {

		if (labelConfig == null) {
			labelConfig = SecurityLabelsConfiguration.getSecurityLabelsConfiguration();
		}
		Map<String, SecurityLabel> securityLabels = labelConfig.getSecurityLabels();

		for (String sReference : paraHolderOIDs) {
			WTReference holderWtRef = null;

			holderWtRef = refFactory.getReference(sReference);
			holderWtRef.refresh();

			String labelKey;
			String labelValue;

			Object holder = holderWtRef.getObject();
			if (holder instanceof ContentItem) {
				String chOid = request.getParameter(PARA_CONTENT_HOLDER_CHOID);
				if (chOid != null) {
					holderWtRef = refFactory.getReference(chOid);
					holderWtRef.refresh();
					holder = holderWtRef.getObject();
				}
			}

			if (holder instanceof SecurityLabeled) {
				ArrayList<SecurityLabeledDownloadAcknowledgment> sldaList = AccessControlHelper.manager
						.getSecurityLabeledDownloadAcknowledgments((SecurityLabeled) holder);

				for (SecurityLabeledDownloadAcknowledgment slda : sldaList) {
					labelKey = slda.getSecurityLabelName();
					SecurityLabel mySecurityLabel = securityLabels.get(labelKey);
					labelValue = slda.getSecurityLabelValue();
					if (!labelValue.equals("NULL")) {
						if (slMap.get(labelKey) == null) {
							Object[] objArr = new Object[] { mySecurityLabel, labelValue,
									slda.getLocalizableMessage() };
							slMap.put(labelKey, objArr);
						}
					}
				}
			}
		}
	}

	private Set<String> getLabelsToAcknowledge(String wtAckSLProperty) {

		Set<String> labelsToAcknowledge = new HashSet<>();
		if (wtAckSLProperty != null) {
			String[] slStrArr = wtAckSLProperty.split(",");
			for (String str : slStrArr) {
				labelsToAcknowledge.add(str);
			}
		}

		return labelsToAcknowledge;
	}

	public static Map getSecurityLabelMap(String oid, Map<String, Object[]> labelMap, Locale locale)
			throws WTException, WTPropertyVetoException {
		Map name2Desc = new HashMap();

		Set<String> labelKeySet = labelMap.keySet();

		for (String labelKey : labelKeySet) {

			SecurityLabel label = (SecurityLabel) labelMap.get(labelKey)[0];
			String labelValue = (String) labelMap.get(labelKey)[1];
			LocalizableMessage localMessage = (LocalizableMessage) labelMap.get(labelKey)[2];

			try {

				NmCommandBean pcommandBean = new NmCommandBean();

				HTTPRequestData requestData = new HTTPRequestData();
				requestData.setParameterMap(new HashMap());
				pcommandBean.setRequestData(requestData);

				NmOid nmOid = new NmOid(oid);
				ArrayList<NmOid> nmOidLst = new ArrayList<>();
				nmOidLst.add(nmOid);

				// Getting the localized name of the securtiy label
				AttributeTypeIdentifier ati = label.getSecurityLabelAttributeTypeId();
				LocalizableMessage localizableLabelName = TypedUtility.getLocalizableMessage(ati);
				String securityLabelName = localizableLabelName.getLocalizedMessage(locale);

				// Getting the localized value set on security label and its localized
				// description.
				String enumeratedTypeClass = label.getSecurityLabelValueResourceClass();
				EnumeratedType localizableLabelValue = EnumeratedTypeUtil.toEnumeratedType(enumeratedTypeClass,
						labelValue);
				String securityLabelValueName = localizableLabelValue.getDisplay(locale);
				String securityLabelValueDesc = localMessage.getLocalizedMessage(locale);

				name2Desc.put(securityLabelName + " - " + securityLabelValueName, securityLabelValueDesc);

			} catch (WTException wte) {
				String msg = "Exception occurred getting security label description in AttachmentsDownloadDirectionServlet.java.";
				throw new WTException(wte, msg);
			}

		}

		return name2Desc;
	}

	private AttachmentsDownloadDirectionRequest decodeRequest(HttpServletRequest request)
			throws WTException, ServletException {
		String paraHolderOID = request.getParameter(PARA_CONTENT_HOLDER_OID);
		String paraItemOID = request.getParameter(PARA_CONTENT_ITEM_OIDS);
		String parasOID = request.getParameter(PARA_SELECTED_WINDCHILL_REFERENCES);

		// decode request
		AttachmentsDownloadDirectionRequest addRequest = new AttachmentsDownloadDirectionRequest();

		/*
		 * Code Modified for downloading selected documents from the Document Structure
		 * Browser.
		 */
		if (parasOID != null
				&& getInitParameter(EXTRA_PATH_SELECTED, "/DOCSBselected").equalsIgnoreCase(request.getPathInfo())) {

			String[] contents = parasOID.split(";");

			if (contents.length < 1) {
				throw new ServletException(
						this.getClass().getName() + " error: multi-select has not selected any downloadable content"); // fake
																														// goto
			}

			String[] itemOIDs = new String[contents.length];
			for (int iv = 0; iv < contents.length; iv++) {
				NmOid nmoid = NmOid.newNmOid("OR:" + contents[iv].trim());
				itemOIDs[iv] = nmoid.getReferenceString();
				AttachmentsDownloadDirectionRequestHolder pholder = new AttachmentsDownloadDirectionRequestHolder(
						AttachmentsDownloadDirectionRequestHolder.I_SCOPE_PRIMARY, null);
				addRequest.setAttachmentsDownloadDirectionRequestHolder(itemOIDs[iv], pholder);
			}

			return addRequest;
		}
		/*
		 * Modification Completed
		 */

		if (paraHolderOID != null && paraHolderOID.length() > 0) {
			AttachmentsDownloadDirectionRequestHolder holder = null;
			if (getInitParameter(EXTRA_PATH_PRIMARY, "/primary").equalsIgnoreCase(request.getPathInfo())) {
				String[] paraHolderOIDs = request.getParameterValues(PARA_CONTENT_HOLDER_OID);
				for (int ih = 0; ih < paraHolderOIDs.length; ih++) {
					holder = new AttachmentsDownloadDirectionRequestHolder(
							AttachmentsDownloadDirectionRequestHolder.I_SCOPE_PRIMARY, null);
					addRequest.setAttachmentsDownloadDirectionRequestHolder(paraHolderOIDs[ih], holder);
				} // end for ih
			} else if (getInitParameter(EXTRA_PATH_SINGLE, "/single").equalsIgnoreCase(request.getPathInfo())) {
				// item info page use oid as item oid rather than holder oid
				String itemSingles[] = new String[1];
				itemSingles[0] = paraHolderOID;
				holder = new AttachmentsDownloadDirectionRequestHolder(
						AttachmentsDownloadDirectionRequestHolder.I_SCOPE_SOME_ITEMS, itemSingles);
				addRequest.setAttachmentsDownloadDirectionRequestHolder(
						AttachmentsDownloadDirectionRequest.UNKNOWN_HOLDER_OID, holder);
			} else if (getInitParameter(EXTRA_PATH_SELECTED, "/selected").equalsIgnoreCase(request.getPathInfo())) {
				NmCommandBean commandBean = new NmCommandBean();
				commandBean.setRequest(request);
				List selectedOIDs = commandBean.getSelectedOidForPopup();
				if (null == selectedOIDs || selectedOIDs.size() < 1) {
					throw new ServletException(this.getClass().getName()
							+ " error: multi-select has not selected any downloadable content"); // fake goto
				}
				String[] itemOIDs = new String[selectedOIDs.size()];
				for (int iv = 0; iv < selectedOIDs.size(); iv++) {
					NmOid nmoid = (NmOid) selectedOIDs.get(iv);
					itemOIDs[iv] = nmoid.getReferenceString();
				} // end for iv
				holder = new AttachmentsDownloadDirectionRequestHolder(
						AttachmentsDownloadDirectionRequestHolder.I_SCOPE_SOME_ITEMS, itemOIDs);
				addRequest.setAttachmentsDownloadDirectionRequestHolder(paraHolderOID, holder);
				if (null != commandBean.getSessionBean()) {
					commandBean.getSessionBean().getStorage().remove("multiSelect");
				}
			} else if (getInitParameter(EXTRA_PATH_ALL, "/all").equalsIgnoreCase(request.getPathInfo())) {
				String[] paraHolderOIDs = request.getParameterValues(PARA_CONTENT_HOLDER_OID);
				for (int ih = 0; ih < paraHolderOIDs.length; ih++) {
					holder = new AttachmentsDownloadDirectionRequestHolder(
							AttachmentsDownloadDirectionRequestHolder.I_SCOPE_ALL, null);
					addRequest.setAttachmentsDownloadDirectionRequestHolder(paraHolderOIDs[ih], holder);
				} // end for ih
			} else {
				if (paraItemOID == null || PARA_TYPE_PRIMARY.equalsIgnoreCase(paraItemOID)) {
					holder = new AttachmentsDownloadDirectionRequestHolder(
							AttachmentsDownloadDirectionRequestHolder.I_SCOPE_PRIMARY, null);
				} else if (paraItemOID.length() == 0 || PARA_TYPE_ALL.equalsIgnoreCase(paraItemOID)) {
					holder = new AttachmentsDownloadDirectionRequestHolder(
							AttachmentsDownloadDirectionRequestHolder.I_SCOPE_ALL, null);
				} else {
					String[] itemOIDs = request.getParameterValues(PARA_CONTENT_ITEM_OIDS);
					itemOIDs = splitValues(itemOIDs, PARA_DELIM_OID);
					holder = new AttachmentsDownloadDirectionRequestHolder(
							AttachmentsDownloadDirectionRequestHolder.I_SCOPE_SOME_ITEMS, itemOIDs);
				} // end if itemOID
				addRequest.setAttachmentsDownloadDirectionRequestHolder(paraHolderOID, holder);
			} // end if ref
		} else if (getInitParameter(EXTRA_PATH_SELECTED, "/selected").equalsIgnoreCase(request.getPathInfo())) {
			NmCommandBean pcommandBean = new NmCommandBean();
			pcommandBean.setRequest(request);
			List pselectedOIDs = pcommandBean.getSelectedOidForPopup();
			if (pselectedOIDs.size() < 1) {
				throw new ServletException(this.getClass().getName()
						+ " error: primary multi-select has not selected any downloadable content"); // fake goto
			}
			String[] holderOIDs = new String[pselectedOIDs.size()];
			for (int iv = 0; iv < pselectedOIDs.size(); iv++) {
				NmOid pnmoid = (NmOid) pselectedOIDs.get(iv);
				holderOIDs[iv] = pnmoid.getReferenceString();
				AttachmentsDownloadDirectionRequestHolder pholder = new AttachmentsDownloadDirectionRequestHolder(
						AttachmentsDownloadDirectionRequestHolder.I_SCOPE_PRIMARY, null);
				addRequest.setAttachmentsDownloadDirectionRequestHolder(holderOIDs[iv], pholder);
			} // end for iv
			if (pcommandBean.getSessionBean() != null) {
				pcommandBean.getSessionBean().getStorage().remove("multiSelect"); // TODO It is only for non JCA tables
				// and it should be hiden behind
				// command bean
			}
		} else {
			Enumeration paraNames = request.getParameterNames();
			while (paraNames.hasMoreElements()) {
				String paraName = (String) paraNames.nextElement();
				if (paraName.startsWith(PARA_CONTENT_OID_PREFIX)) {
					String holderOID = paraName.substring(PARA_CONTENT_OID_PREFIX.length());
					String itemOID = request.getParameter(paraName);
					AttachmentsDownloadDirectionRequestHolder holder = null;
					if (itemOID == null || PARA_TYPE_PRIMARY.equalsIgnoreCase(itemOID)
							|| getInitParameter(EXTRA_PATH_PRIMARY, "/primary")
									.equalsIgnoreCase(request.getPathInfo())) {
						holder = new AttachmentsDownloadDirectionRequestHolder(
								AttachmentsDownloadDirectionRequestHolder.I_SCOPE_PRIMARY, null);
					} else if (itemOID.length() == 0 || PARA_TYPE_ALL.equalsIgnoreCase(itemOID)
							|| getInitParameter(EXTRA_PATH_ALL, "/all").equalsIgnoreCase(request.getPathInfo())) {
						holder = new AttachmentsDownloadDirectionRequestHolder(
								AttachmentsDownloadDirectionRequestHolder.I_SCOPE_ALL, null);
					} else {
						String[] itemOIDs = request.getParameterValues(paraName);
						itemOIDs = splitValues(itemOIDs, PARA_DELIM_OID);
						holder = new AttachmentsDownloadDirectionRequestHolder(
								AttachmentsDownloadDirectionRequestHolder.I_SCOPE_SOME_ITEMS, itemOIDs);
					} // end if itemOID
					addRequest.setAttachmentsDownloadDirectionRequestHolder(holderOID, holder);
				} // end if
			} // end while
		} // end if paraHolderOID

		return addRequest;
	}

	private int getUserDownloadPreference(HttpServletRequest request) throws WTException {
		String prefValue = AttachmentsWebHelper.getPreferenceValue(PREF_KEY_MECHANISM, request);

		clientLogger.debug("getUserDownloadPreference");
		int iDownloadType = DownloadStateManager.I_PREFERENCE_BROWSER;
		if (prefValue.equalsIgnoreCase("BROWSER")) {
			iDownloadType = DownloadStateManager.I_PREFERENCE_BROWSER;
		} else if (prefValue.equalsIgnoreCase("DTI")) {
			/*
			 * DTI download is applicable only for the following conditions 1. ContentHolder
			 * object is wt.doc.WTDocument 2. For WTDocuments only applicable for primary
			 * attachments For all other ContentHolders/ secondary attachments use Browser
			 * download if DTI pref is set
			 */
			String paraHolderOID = request.getParameter(PARA_CONTENT_HOLDER_OID);

			if (paraHolderOID != null) {
				paraHolderOID.indexOf("wt.doc.WTDocument");
			}

			boolean isInstanceOfWTDocument = false;
			clientLogger.debug("Checking for isInstanceOfWTDocument on paraHolderOID:: " + paraHolderOID);
			WTReference holderWtRef = refFactory.getReference(paraHolderOID);
			Object holder = holderWtRef.getObject();
			if (holder instanceof WTDocument) {
				clientLogger.debug("isInstanceOfWTDocument is true...");
				isInstanceOfWTDocument = true;
			}

			if (isInstanceOfWTDocument) {
				// For WTDocument check for the role
				String role = HTMLEncoder.encodeForHTMLAttribute(request.getParameter("role"));

				// if the role is primary then only use DTI download else use browser based
				// download
				if (role != null && role.equals(ContentRoleType.PRIMARY.toString())
						|| getInitParameter(EXTRA_PATH_PRIMARY, "/primary").equalsIgnoreCase(request.getPathInfo())) {
					iDownloadType = DownloadStateManager.I_PREFERENCE_DTI;
				} else {
					iDownloadType = DownloadStateManager.I_PREFERENCE_BROWSER;
				}
			} else {
				// For all other Content Holders other than WTDocument use Browser based
				// download if DTI download pref
				// is set
				iDownloadType = DownloadStateManager.I_PREFERENCE_BROWSER;
			}
		} // end if prefValue
		clientLogger.debug("Returning getUserDownloadPreference:: " + iDownloadType);
		return iDownloadType;
	}

	private AttachmentsDownloadDirectionResponse populatePreferenceValues(HttpServletRequest request,
			AttachmentsDownloadDirectionResponse addResponse) throws WTException {
		String prefOperation = AttachmentsWebHelper
				.getPreferenceValue(AttachmentsDownloadDirectionResponse.PREF_KEY_OPERATION, request);
		String prefDefaultPath = AttachmentsWebHelper
				.getPreferenceValue(AttachmentsDownloadDirectionResponse.PREF_KEY_DEFAULT_DIR, request);

		addResponse.setAssociatedPreference(AttachmentsDownloadDirectionResponse.PREF_KEY_OPERATION, prefOperation);
		addResponse.setAssociatedPreference(AttachmentsDownloadDirectionResponse.PREF_KEY_DEFAULT_DIR, prefDefaultPath);

		return addResponse;
	}

	private String getInitParameter(String strName, String strDefault) {
		String strValue = getInitParameter(strName);
		if (strValue == null || strValue.length() < 1) {
			strValue = strDefault;
		}
		return strDefault;
	}

	private int getNumberOfItems(AttachmentsDownloadDirectionResponse addResponse) {
		int iCount = 0;
		String[] holderOIDs = addResponse.getAllContentHolderOIDs();
		for (int ih = 0; holderOIDs != null && ih < holderOIDs.length; ih++) {
			AttachmentsDownloadDirectionResponseHolder addRpHolder = addResponse.getHolder(holderOIDs[ih]);
			iCount += addRpHolder.getNumberOfItems();
		} // end for ih
		return iCount;
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		paraACK = "";
		processRequest(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		paraACK = request.getParameter(PARA_ACK_STATUS);
		processRequest(request, response);
	}

	public static String[] splitValues(String[] strNotSplit, String delim) {
		if (strNotSplit == null) {
			return null;
		}

		Vector<String> vectorSplit = new Vector<>();
		for (int ix = 0; ix < strNotSplit.length; ix++) {
			StringTokenizer st = new StringTokenizer(strNotSplit[ix], delim);
			while (st.hasMoreTokens()) {
				vectorSplit.add(st.nextToken());
			}
		} // end for ix
		String[] strSplit = new String[vectorSplit.size()];
		strSplit = vectorSplit.toArray(strSplit);
		return strSplit;
	}

	// this is for auditing the accept download
	private void dispatchSecurityLabelDownloadAckEvent(HttpServletRequest request) throws WTException {
		String[] paraHolderOIDs = request.getParameterValues(PARA_CONTENT_HOLDER_OID);
		WTKeyedMap slObjectAcksMap = new WTKeyedHashMap();

		for (String sReference : paraHolderOIDs) {
			WTReference holderWtRef = null;
			holderWtRef = refFactory.getReference(sReference);
			Object holder = holderWtRef.getObject();
			if (holder instanceof ContentItem) {
				String chOid = request.getParameter(PARA_CONTENT_HOLDER_CHOID);
				if (chOid != null) {
					holderWtRef = refFactory.getReference(chOid);
					holderWtRef.refresh();
					holder = holderWtRef.getObject();
				}
			}

			if (holder instanceof SecurityLabeled) {
				ArrayList<SecurityLabeledDownloadAcknowledgment> sldaList = AccessControlHelper.manager
						.getSecurityLabeledDownloadAcknowledgments((SecurityLabeled) holder);
				slObjectAcksMap.put(holder, sldaList);
			}
		}

		AuditHelper.service.dispatchSecurityLabelDownloadAckEvent(slObjectAcksMap);

	}

} // end class
