/* bcwti
 *
 * Copyright (c) 2010 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */
package com.ptc.windchill.ixb.importer.part;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import wt.configuration.TraceCode;
import wt.enterprise.EnterpriseHelper;
import wt.generic.GenericType;
import wt.inf.container.WTContainerRef;
import wt.ixb.impl.doc.IxbDomDocument;
import wt.ixb.publicforhandlers.IxbHndHelper;
import wt.log4j.LogR;
import wt.org.WTOrganization;
import wt.part.WTPartMaster;
import wt.services.applicationcontext.implementation.DefaultServiceProvider;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.WTPropertyVetoException;

import com.ptc.core.meta.common.IdentifierFactory;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.windchill.ixb.importer.AbstractClassElementBuilder;
import com.ptc.windchill.ixb.importer.ImportAction;
import com.ptc.windchill.ixb.importer.ImportElement;
import com.ptc.windchill.ixb.importer.ImportElementAction;
import com.ptc.windchill.ixb.importer.ImportHndHelper;
import com.ptc.windchill.ixb.importer.SessionData;
import com.ptc.windchill.ixb.importer.importerResource;
import com.ptc.windchill.ixb.util.ImportXlsHelper;

/**
 * Class element builder for WTPart and its soft types
 *
 * <BR><BR><B>Supported API: </B>false
 * <BR><BR><B>Extendable: </B>false
 *
 * @version   1.0
 **/
public class WTPartElementBuilder extends AbstractClassElementBuilder {
   private static final String RESOURCE = "com.ptc.windchill.ixb.importer.part.partResource";
   private static final String CLASSNAME = WTPartElementBuilder.class.getName();

   private static final String IMPORTER_RESOURCE = "com.ptc.windchill.ixb.importer.importerResource";
   protected static final String ACTION = "Action";
   protected static final String WTPART = "wt.part.WTPart";
   protected static final String PART_TYPE = "Assembly Mode";
   protected static final String PART_SOURCE = "Source";
   protected static final String END_ITEM = "End Item";
   public static final String BRANCH_VIEW = "Predecessor View";
   public static final String BRANCH_REVISION = "Predecessor Revision";
   protected static final String DEFAULT_TRACE_CODE = "Trace Code";
   protected static final String GENERIC_TYPE = "Generic Type";
   protected static final String JOB_AUTHORIZATION_NUMBER = "Job Authorization Number";
   protected static final String CONTRACT_NUMBER = "Contract Number";
   protected static final String PHASE = "Phase";
   protected static final String PHANTOM = "Phantom";
   protected static final String GATHERING_PART = "Gathering Part";
   protected static final String DEFAULT_UNIT = "Default Unit";
   protected static final String SERVICEABLE = "Serviceable";
   protected static final String SERVICE_KIT = "Service Kit";
   private static final Logger logger = LogR.getLogger(CLASSNAME);
   private static final String MANUFACTURER_PART_TYPE = "com.ptc.windchill.suma.part.ManufacturerPart";
   private static final String VENDOR_PART_TYPE = "com.ptc.windchill.suma.part.VendorPart";

    private static final String COLLAPSIBLE = "Collapsible";

   //protected static Set<String> NON_IBA_COLUMN_NAME_SET = new HashSet<String>();
   static {
      NON_IBA_COLUMN_NAME_SET.add(TYPE);
      NON_IBA_COLUMN_NAME_SET.add(ORGANIZATION_ID);
      NON_IBA_COLUMN_NAME_SET.add(NAME);
      NON_IBA_COLUMN_NAME_SET.add(NUMBER);
      NON_IBA_COLUMN_NAME_SET.add(PART_TYPE);
      NON_IBA_COLUMN_NAME_SET.add(FOLDER_PATH);
      NON_IBA_COLUMN_NAME_SET.add(VIEW);
      NON_IBA_COLUMN_NAME_SET.add(VERSION);
      NON_IBA_COLUMN_NAME_SET.add(LIFECYCLE);
      NON_IBA_COLUMN_NAME_SET.add(STATE);
      NON_IBA_COLUMN_NAME_SET.add(PART_SOURCE);
      NON_IBA_COLUMN_NAME_SET.add(DEFAULT_UNIT);
      NON_IBA_COLUMN_NAME_SET.add(END_ITEM);
      NON_IBA_COLUMN_NAME_SET.add(DEFAULT_TRACE_CODE);
      NON_IBA_COLUMN_NAME_SET.add(GENERIC_TYPE);
      NON_IBA_COLUMN_NAME_SET.add(JOB_AUTHORIZATION_NUMBER);
      NON_IBA_COLUMN_NAME_SET.add(CONTRACT_NUMBER);
      NON_IBA_COLUMN_NAME_SET.add(PHASE);
      NON_IBA_COLUMN_NAME_SET.add(PHANTOM);
      NON_IBA_COLUMN_NAME_SET.add(SECURITY_LABELS);
      NON_IBA_COLUMN_NAME_SET.add(SERVICEABLE);
      NON_IBA_COLUMN_NAME_SET.add(SERVICE_KIT);
      NON_IBA_COLUMN_NAME_SET.add(BRANCH_VIEW);
      NON_IBA_COLUMN_NAME_SET.add(BRANCH_REVISION);
      NON_IBA_COLUMN_NAME_SET.add(GATHERING_PART);
      NON_IBA_COLUMN_NAME_SET.add(DEFAULT_UNIT);
        NON_IBA_COLUMN_NAME_SET.add(COLLAPSIBLE);
   };

   /**
    * Creates a new import element for the object represented by the row
    * data.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     rowData
    * @return    ImportElement
    * @exception wt.util.WTException
    **/
   public ImportElement newElement( Map rowData )
            throws WTException {
      validateRowData(rowData);
      ImportElement importElement = makeImportElement(rowData);
      importElement.setOrganization(getOrganization(rowData));
      return importElement;
   }

   /**
    * Initializes the builder. A builder must be initialized before being
    * used.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     prolog  A prolog typically contains additional information about an ImportSheet, in the form of name value pairs.
    * @param     header  A header contains metadata about an ImportSheet - specifically, these are the column headers of the sheet.
    * @param     sessionData  session data
    * @exception wt.util.WTException
    * @see com.ptc.windchill.ixb.importer.ElementBuilder#initialize(java.util.Map, java.util.List, com.ptc.windchill.ixb.importer.SessionData)
    */
   public void initialize(Map prolog, List header, SessionData sessionData) throws WTException {
      super.initialize(prolog, header, sessionData);
   }

   /**
    * Creates an import element based on the row data
    * @param rowData
    * @return the newly created import element
    * @throws WTException
    */
   protected ImportElement makeImportElement(Map rowData) throws WTException {
      try {
         Document doc = getDocumentBuilder().newDocument();
         Element rootElement = doc.createElement(IxbHndHelper.XML_WTPART);
         addCommonWTPartElements(doc, rootElement, rowData);

         doc.appendChild(rootElement);
         IxbDomDocument ixbDoc = new IxbDomDocument();
         ixbDoc.initialize(rootElement);

         // There is no action in the parts input file
         ImportElement importElement = new ImportElement(ixbDoc, (ImportElementAction) null);
         importElement.setPathToTrackable(IxbHndHelper.XML_ATTR_NUMBER);
         return importElement;
      }
      catch (WTPropertyVetoException e) {
         throw new WTException(e);
      }
   }




   /**
    * Adds elements that are common to WTPart and its sub classes to the parent element
    * @param doc
    * @param element
    * @param rowData
    * @throws WTException
    */
   protected void addCommonWTPartElements(Document doc, Element parent, Map rowData) throws WTException {
      addObjectIDElement(doc, parent, rowData);
      addObjectContainerPathElement(doc, parent, rowData);
      addOrganizationIdAndNameElement(doc, parent, rowData);
      addNumberElement(doc, parent, rowData);
      addNameElement(doc, parent, rowData);
      addDefaultUnitElement(doc, parent, rowData);
      addGatheringPartElement(doc, parent, rowData);
      addEndItemElement(doc, parent, rowData);
      addDefaultTraceCodeElement(doc, parent, rowData);
        addCollapsibleElement(doc, parent, rowData);
      addSecurityLabelsElement(doc, parent, rowData);
      addGenericTypeElement(doc, parent, rowData);
      addPartTypeElement(doc, parent, rowData);
      addPartSourceElement(doc, parent, rowData);
      addDomainNameElement(doc, parent, rowData);
      addFolderPathElement(doc, parent, rowData);
      addViewElement(doc, parent, rowData);
      addVersionInfoElement(doc, parent, rowData);
      addLifeCycleInfoElement(doc, parent, rowData);
      addExternalTypeIdElement(doc, parent, rowData);
      addJobAuthorizationNumberElement(doc, parent, rowData);
      addContractNumberElement(doc, parent, rowData);
      addPhaseElement(doc, parent, rowData);
      addPhantomElement(doc, parent, rowData);
      addServiceableElement(doc, parent, rowData);
      addServicekitElement(doc, parent, rowData);
      Element bussinessFields  = doc.createElement(IxbHndHelper.XML_BUSINESS_FIELDS);
      addBussinessFieldElements(doc, bussinessFields , rowData);
      parent.appendChild(bussinessFields );
      addSecurityLabelsElement(doc, parent, rowData);

   }



    /**
     * Creates collapsible element and adds it to the parent.
     * 
     * @param doc
     * @param parent
     * @param rowData
     */
    private void addCollapsibleElement(Document doc, Element parent, Map rowData) {
        String collapcible = (String) rowData.get(COLLAPSIBLE);
        if (collapcible == null || collapcible.trim().length() == 0) {
            if (logger.isTraceEnabled())
                logger.trace("No value for " + COLLAPSIBLE);
        } else {
            if (logger.isTraceEnabled())
                logger.trace("Value of Collapsible element - " + collapcible);
            Element collapsibleElement = doc.createElement(IxbHndHelper.XML_ATTR_COLLAPSIBLE);
            collapsibleElement.appendChild(doc.createTextNode(collapcible.trim()));
            parent.appendChild(collapsibleElement);
        }
    }

    /**
     * Creates an Gathering Part element and adds it to the parent. The default endItem value is false.
     * 
     * @param doc
     * @param parent
     * @param rowData
     * @throws WTException
     */
   protected void addGatheringPartElement(Document doc, Element parent, Map rowData) throws WTException {
      String gatheringPart = (String) rowData.get(GATHERING_PART);
      boolean isGatheringPart = false;
      if (gatheringPart == null || gatheringPart.trim().length() == 0) {
         logger.trace("this part does not contain value for \"" + GATHERING_PART + "\" using false ");
      }
      else {
         try {
            isGatheringPart = Boolean.parseBoolean(gatheringPart);
         }
         catch (NumberFormatException e) {
            throw new WTException(e);
         }
      }

      Element gatheringPartElement = doc.createElement(IxbHndHelper.XML_ATTR_HIDE_PART_IN_STRUCTURE);
      gatheringPartElement.appendChild(doc.createTextNode(isGatheringPart ? "true" : "false"));
      parent.appendChild(gatheringPartElement);
   }


   /**
    * Creates an endItem element and adds it to the parent.
    * The default endItem value is false.
    * @param doc
    * @param parent
    * @param rowData
    * @throws WTException
    */
   protected void addEndItemElement(Document doc, Element parent, Map rowData) throws WTException {
      String endItem = (String) rowData.get(END_ITEM);
      boolean isEndItem = false;
      //Fix for SPR 2251055
      if (endItem == null || endItem.trim().length() == 0 || (!endItem.equalsIgnoreCase("true") && !endItem.equalsIgnoreCase("false"))) {
         logger.trace("this part does not contain value for \"" + END_ITEM + "\" using false ");
         String fileName = getSessionData().getFileName();
         String sheetName = getSessionData().getSheetName();
         String rowNumber = getSessionData().getRowNumber();
         String message = new WTMessage(IMPORTER_RESOURCE,importerResource.MSG_SHEET_INVALID_END_ITEM, new Object[] {}).getLocalizedMessage(getSessionData().getJobLocale());
         ImportXlsHelper.reportError(ImportXlsHelper.getLocaleWarningStr(), fileName, sheetName, rowNumber, message);
      }
      else {
         try {
            isEndItem = Boolean.parseBoolean(endItem);
         }
         catch (NumberFormatException e) {
            throw new WTException(e);
         }
      }
      Element endItemElement = doc.createElement(IxbHndHelper.XML_ATTR_END_ITEM);
      endItemElement.appendChild(doc.createTextNode(isEndItem ? "true" : "false"));
      parent.appendChild(endItemElement);

   }

   /**
    * Creates an defaultTraceCode element and adds it to the parent.
    * The default value of this element is "Untraced"
    * @param doc
    * @param parent
    * @param rowData
    * @throws WTException
    */
   protected void addDefaultTraceCodeElement(Document doc, Element parent, Map rowData) throws WTException {
      String defaultTraceCode = (String) rowData.get(DEFAULT_TRACE_CODE);
      if (defaultTraceCode == null || defaultTraceCode.trim().length() == 0) {
         if (logger.isTraceEnabled()) logger.trace("no value for \"" + DEFAULT_TRACE_CODE + "\" using " + TraceCode.UNTRACED);
         defaultTraceCode = TraceCode.UNTRACED.toString();
      }
      else if (defaultTraceCode.length() > 1 && defaultTraceCode.startsWith("0")) {
         if (logger.isTraceEnabled()) logger.trace(DEFAULT_TRACE_CODE + " is " + defaultTraceCode + ", using " + TraceCode.UNTRACED);
         defaultTraceCode = TraceCode.UNTRACED.toString();
      }

      Element defaultTraceCodeElement = doc.createElement(IxbHndHelper.XML_ATTR_DEFAULT_TRACE_CODE);
      defaultTraceCodeElement.appendChild(doc.createTextNode(defaultTraceCode));
      parent.appendChild(defaultTraceCodeElement);
   }

   /**
    * Creates an genericType element and adds it to the parent
    * This method will add excludedIba elements to the parent element.
    * @param doc
    * @param parent
    * @param rowData
    * @throws WTException
    */
   protected void addGenericTypeElement(Document doc, Element parent, Map rowData) throws WTException {
      // TODO: need to check existance of Generic Type in validator
      // after this is officially added to spreadsheet format
      String genericType = (String) rowData.get(GENERIC_TYPE);
      if (genericType == null || genericType.trim().length() == 0) {
         logger.trace("this part does not contain Generic Type, using default one");
         genericType = GenericType.STANDARD.toString();
      }

      Element genericTypeElement = doc.createElement(IxbHndHelper.XML_ATTR_GENERIC_TYPE);
      genericTypeElement.appendChild(doc.createTextNode(genericType));
      parent.appendChild(genericTypeElement);
   }

   /**
    * Creates a "Job Authorization Number" element and adds it to the parent.
    * The job authorization number is not required, so there is no default value.
    * @param doc
    * @param parent
    * @param rowData
    * @throws WTException
    */
   protected void addJobAuthorizationNumberElement(Document doc, Element parent, Map rowData)
   throws WTException {
      String jobAuthorizationNumber = (String) rowData.get(JOB_AUTHORIZATION_NUMBER);
      if (null == jobAuthorizationNumber || jobAuthorizationNumber.trim().length() == 0) {
         logger.trace("There is no job authorization number specified");
      }
      else {
         jobAuthorizationNumber = jobAuthorizationNumber.trim();
         logger.trace("The job authorization number is " + jobAuthorizationNumber);
         Element jobAuthorizationNumberElement = doc.createElement(IxbHndHelper.XML_ATTR_JOB_AUTHORIZATION_NUMBER);
         jobAuthorizationNumberElement.appendChild(doc.createTextNode(jobAuthorizationNumber));
         parent.appendChild(jobAuthorizationNumberElement);
      }
   }

   /**
    * Creates a "Contract Number" element and adds it to the parent.
    * The contract number is not required, so there is no default value.
    * @param doc
    * @param parent
    * @param rowData
    * @throws WTException
    */
   protected void addContractNumberElement(Document doc, Element parent, Map rowData)
   throws WTException {
      String contractNumber = (String) rowData.get(CONTRACT_NUMBER);
      if (null == contractNumber || contractNumber.trim().length() == 0) {
         logger.trace("There is no contract number specified");
      }
      else {
         contractNumber = contractNumber.trim();
         logger.trace("The contract number is " + contractNumber);
         Element contractNumberElement = doc.createElement(IxbHndHelper.XML_ATTR_CONTRACT_NUMBER);
         contractNumberElement.appendChild(doc.createTextNode(contractNumber));
         parent.appendChild(contractNumberElement);
      }
   }

   /**
    * Creates a "Phase" element and adds it to the parent.
    * The phase is not required, so there is no default value.
    * @param doc
    * @param parent
    * @param rowData
    * @throws WTException
    */
   protected void addPhaseElement(Document doc, Element parent, Map rowData)
   throws WTException {
      String phase = (String) rowData.get(PHASE);
      if (null == phase || phase.trim().length() == 0) {
         logger.trace("There is no contract number specified");
      }
      else {
         phase = phase.trim();
         logger.trace("The phase is " + phase);
         Element phaseElement = doc.createElement(IxbHndHelper.XML_ATTR_PHASE);
         phaseElement.appendChild(doc.createTextNode(phase));
         parent.appendChild(phaseElement);
      }
   }

   /**
    * Creates a "Phantom" element and adds it to the parent.
    * The Phantom is not required, so there is no default value.
    * @param doc
    * @param parent
    * @param rowData
    * @throws WTException
    */
   protected void addPhantomElement(Document doc, Element parent, Map rowData)
   throws WTException {
      String phantom = (String) rowData.get(PHANTOM);
      boolean isPhantom = false;
      if (phantom == null || phantom.trim().length() == 0) {
         logger.trace("this part does not contain value for \"" + PHANTOM + "\" using false ");
      }
      else {
         try {
        	 isPhantom = Boolean.parseBoolean(phantom);
         }
         catch (NumberFormatException e) {
            throw new WTException(e);
         }
      }

      Element phantomElement = doc.createElement(IxbHndHelper.XML_ATTR_PHANTOM);
      phantomElement.appendChild(doc.createTextNode(isPhantom ? "true" : "false"));
      parent.appendChild(phantomElement);
   }

   /**
    * Creates a partType element and adds to the parent
    * @param doc dom document
    * @param parent parent element to which the new element will be added to
    * @param rowData a map that contains key/value pairs for current context object
    * @throws WTException
    */
   protected void addPartTypeElement(Document doc, Element parent, Map rowData) throws WTException {
      Element partTypeElement = doc.createElement(IxbHndHelper.XML_ATTR_PARTTYPE);
      String partType = (String) rowData.get(PART_TYPE);
      if (partType == null || partType.trim().length() == 0) {
         partType = IxbHndHelper.XML_VALUE_NULL;
      }
      partTypeElement.appendChild(doc.createTextNode(partType));
      parent.appendChild(partTypeElement);
   }

   /**
    * Creates a view element and adds to the parent.
    * @param doc dom document
    * @param parent parent element to which the new element will be added to
    * @param rowData a map that contains key/value pairs for current context object
    * @throws WTException
    */
   protected void addViewElement(Document doc, Element parent, Map rowData) throws WTException {
      String view = (String) rowData.get(VIEW);
      Element viewElement = doc.createElement(IxbHndHelper.XML_ATTR_VIEW);
      if (view == null || view.trim().length() == 0)
         viewElement.appendChild(doc.createTextNode(IxbHndHelper.XML_VALUE_NULL));
      else
      viewElement.appendChild(doc.createTextNode(view));
      parent.appendChild(viewElement);
   }

   /**
    * Creates a partSource element and adds to the parent
    * @param doc dom document
    * @param parent parent element to which the new element will be added to
    * @param rowData a map that contains key/value pairs for current context object
    * @throws WTException
    */
   protected void addPartSourceElement(Document doc, Element parent, Map rowData) throws WTException {
      String partSource = (String) rowData.get(PART_SOURCE);
      if (partSource == null || partSource.trim().length() == 0) {
         partSource = IxbHndHelper.XML_VALUE_NULL;
      }

      // SPR Task 4647927 : Manufacturer or Vendor Part should not have source other than "buy"
      String partType = (String) rowData.get(TYPE);
      if ((partType.contains(VENDOR_PART_TYPE) || partType.contains(MANUFACTURER_PART_TYPE)) && !(partSource.equalsIgnoreCase("buy"))){
           throw new WTException(IMPORTER_RESOURCE, importerResource.SOURCE_CANNOT_BE_CHANGED_SUMA_PARTS,new Object[]{});
      }
      // End of SPR Task 4647927

      Element partSourceElement = doc.createElement(IxbHndHelper.XML_ATTR_SOURCE);
      partSourceElement.appendChild(doc.createTextNode(partSource));
      parent.appendChild(partSourceElement);
   }
   /**
    * Creates a "Serviceable" element and adds it to the parent.
    * The Serviceable is not required, so there is no default value.
    * @param doc
    * @param parent
    * @param rowData
    * @throws WTException
    */
   protected void addServiceableElement(Document doc, Element parent, Map rowData)
   throws WTException {
      String serviceable = (String) rowData.get(SERVICEABLE);
      boolean isServiceable;
      Element serviceableElement = doc.createElement(IxbHndHelper.XML_ATTR_SERVICEABLE);
      if (serviceable == null || serviceable.trim().length() == 0) {
          logger.trace("this part does not contain value for \"" + SERVICEABLE + "\" using null ");
          serviceableElement.appendChild(doc.createTextNode(IxbHndHelper.XML_VALUE_NULL));
      }
      else {
          isServiceable = Boolean.parseBoolean(serviceable);
          serviceableElement.appendChild(doc.createTextNode(isServiceable ? "true" : "false"));
      }

      parent.appendChild(serviceableElement);
   }

   /**
    * Creates a "Service Kit" element and adds it to the parent.
    * The Service Kit is not required, so there is no default value.
    * @param doc
    * @param parent
    * @param rowData
    * @throws WTException
    */
   protected void addServicekitElement(Document doc, Element parent, Map rowData)
   throws WTException {
      String servicekit = (String) rowData.get(SERVICE_KIT);
      boolean isServicekit;
      Element servicekitElement = doc.createElement(IxbHndHelper.XML_ATTR_SERVICE_KIT);
      if (servicekit == null || servicekit.trim().length() == 0) {
          logger.trace("this part does not contain value for \"" + SERVICE_KIT + "\" using null ");
          servicekitElement.appendChild(doc.createTextNode(IxbHndHelper.XML_VALUE_NULL));
      }
      else {
          isServicekit = Boolean.parseBoolean(servicekit);
          servicekitElement.appendChild(doc.createTextNode(isServicekit ? "true" : "false"));
      }

      parent.appendChild(servicekitElement);
   }

   /**
    * Returns WTOrganization based on row data
    * @param rowData
    * @throws WTException
    */
   protected WTOrganization getOrganization(Map rowData) throws WTException {
      String orgId = (String) rowData.get(ORGANIZATION_ID);
      if (orgId == null || orgId.trim().length() == 0) {
         return getSessionData().getContainerRef().getReferencedContainerReadOnly().getOrganization();
      }
      return ImportHndHelper.getWTOrganizationByIdOrName(orgId);
   }

   /**
    * Validates the input row data
    * @param rowData
    * @throws WTException
    */
   protected void validateRowData(Map rowData) throws WTException {
      HashSet missingColumns = new HashSet();
      //Fix for SPR 2250973 (remove validation error is Revision is not provided)
      String[] columns = new String[] {TYPE, NAME};
      for (int i=0; i<columns.length; i++) {
         if (rowData.containsKey(columns[i])) {
            String value = (String)rowData.get(columns[i]);
            if (null == value || value.trim().length() == 0)
               missingColumns.add(columns[i]);
         }
         else
            missingColumns.add(columns[i]);
      }
      if (missingColumns.size() > 0) {
         String columnNames = "";
         for (Iterator iterator = missingColumns.iterator(); iterator.hasNext();) {
            String columnName = (String)iterator.next();
            if (columnNames.equals(""))
               columnNames += columnName;
            else
               columnNames += ", " + columnName;
         }
         throw new WTException(RESOURCE, partResource.ERROR_MISSING_PART_ATTRIBUTES, new Object[]{columnNames});
      }

      String number = (String)rowData.get(NUMBER);
      String type = (String) rowData.get(TYPE);
      if (number == null || number.trim().length() == 0) {
         WTContainerRef targetContainerRef = getSessionData().getContainerRef();
         TypeIdentifier partTypeId = ImportHndHelper.getTypeIdentifier((String) rowData.get(TYPE));
         boolean isAutoNumber = EnterpriseHelper.isAutoNumber(partTypeId, targetContainerRef);
         if (!isAutoNumber) {
            throw new WTException(IMPORTER_RESOURCE, importerResource.MSG_MISSING_NUMBER, new Object[] {partTypeId.getTypename(), targetContainerRef.getName()});
         }
      }

      if (getSessionData().isPreview()) {

          // validating the part import action before caching the parts
          validatePartImportAction(rowData);

          // add the part info to the part candidate cache
         HashSet wtPartImportCandidates = getSessionData().getWTPartImportCandidateCache();
         // Part number is optional in part import spreadsheet file
         long organizationId = getOrganization(rowData).getPersistInfo().getObjectIdentifier().getId();
         if (null != number && number.trim().length() > 0) {
            String name = (String) rowData.get(NAME);
            String version = (String)rowData.get(VERSION);
            String view = (String)rowData.get(VIEW);
            IdentifierFactory LOGICAL_IDENTIFIER_FACTORY = (IdentifierFactory) DefaultServiceProvider
     	           .getService(IdentifierFactory.class, "logical");
            TypeIdentifier typeID = (TypeIdentifier) LOGICAL_IDENTIFIER_FACTORY.get(type);
            String typeName = typeID.getTypename();
            if(typeName.contains(MANUFACTURER_PART_TYPE) || typeName.contains(VENDOR_PART_TYPE)){
                wtPartImportCandidates.add(new WTPartImportCandidate(number.toUpperCase(),
                     name, type, organizationId, null, null));
            }else{
            	// Part number always use capital case
                wtPartImportCandidates.add(new WTPartImportCandidate(number.toUpperCase(),
                     name, type, organizationId, version, view));
            }

         }
      }
   }

   /**
    * validate the part import action
    *
    * @param partExists
    * @return
    * @throws WTException
    */
   private void validatePartImportAction(Map rowData) throws WTException {
       ImportAction importAction = getSessionData().getImportAction();
       String partName = (String) rowData.get(NAME);
       String partNumber =  (String) rowData.get(NUMBER);
       WTContainerRef containerRef = getSessionData().getContainerRef();
       WTOrganization organization = getWTOrganization(rowData);
       WTPartMaster existingPart = ImportHndHelper.getPartMaster(partNumber, organization, containerRef);
       boolean partExists = existingPart != null;

       if(!(importAction.equals(ImportAction.ADD_AND_UPDATE)
               || (importAction.equals(ImportAction.UPDATE_ONLY) && partExists)
               || (importAction.equals(ImportAction.ADD_ONLY) && !partExists)
               || (importAction.equals(ImportAction.UPDATE_CHECKED_OUT_PARTS) && partExists))){

           Object [] additionalErrorInfo = {ImportXlsHelper.getLocaleWarningStr()};
           WTException e = new WTException(WTMessage.getLocalizedMessage(RESOURCE, partResource.IGNORE_ROW_ITEM, new String[] {partNumber + ", " + partName},getSessionData().getJobLocale()));

           throw new WTException(e, additionalErrorInfo);

       }

   }

}
