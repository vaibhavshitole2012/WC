package ext.kb.accesscontrol;

import static mockit.Deencapsulation.*;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import mockit.Mocked;
import mockit.NonStrictExpectations;

import org.junit.Test;

import wt.access.AccessControlManager;
import wt.access.AccessPermission;
import wt.fc.ObjectReference;
import wt.fc.QueryResult;
import wt.part.WTPart;
import wt.type.TypedUtilityService;
import wt.type.TypedUtilityServiceHelper;

import com.ptc.core.meta.common.impl.WCTypeIdentifier;

import ext.kb.util.IBAHelper;

public class AccessControlHelperTest {

    @Mocked TypedUtilityService serv;
    @Mocked AccessControlManager access;
    
    @Test
    @SuppressWarnings("unused")
    public void testIsGeklaAuthorized() throws Exception {
        
        assertFalse(AccessControlHelper.isGeklaAuthorized(null));
        new NonStrictExpectations() {
            {
                setField(TypedUtilityServiceHelper.class, "service", serv);
                serv.getTypeIdentifier(withAny(new ObjectReference()));
                returns(new WCTypeIdentifier("com.ptc.windchill.uwgm.soap.impl.uwgmdb.Folder_i"));
                
            }
        };
        assertFalse(AccessControlHelper.isGeklaAuthorized(new WTPart()));
        
        new NonStrictExpectations() {
            IBAHelper utils;
            ext.kb.util.KBUtils otherUtils;
            {
                
            	setField(TypedUtilityServiceHelper.class, "service", serv);
                serv.getTypeIdentifier(withAny(new ObjectReference()));
                returns(new WCTypeIdentifier("wt.part.WTPart|com.ptc.KBMechanicalPart|com.ptc.KBArticle"));
                
                IBAHelper.getStringIBAValue(withAny(new WTPart()), withAny(""));
                returns("11");
                
                QueryResult r = new QueryResult();
                r.getObjectVectorIfc().addElement(new WTPart());
                ext.kb.util.KBUtils.getItem(withAny(WTPart.class), "obid", "11");
                returns(r);
                
                setField(wt.access.AccessControlHelper.class, "manager", access);
                access.checkAccess(withAny(new Object()), AccessPermission.DOWNLOAD);
                returns(true);
                
            }
        };
        assertTrue(AccessControlHelper.isGeklaAuthorized(new WTPart()));
        
        new NonStrictExpectations() {
            {
                access.checkAccess(withAny(new Object()), AccessPermission.DOWNLOAD);
                returns(false);
            }
        };
        assertFalse(AccessControlHelper.isGeklaAuthorized(new WTPart()));
        
    }

}
