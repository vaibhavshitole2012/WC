package ext.kb.tableview;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import java.util.List;
import java.util.Locale;

import org.junit.Test;

import com.ptc.core.htmlcomp.createtableview.Attribute.TextAttribute;

import ext.kb.util.KBUtils;

public class AdditionalInventoriesChangeTaskAffectedItemsTableViewsTest {

	@Test
	public void test() {
		AdditionalInventoriesChangeTaskAffectedItemsTableViews view = new AdditionalInventoriesChangeTaskAffectedItemsTableViews();
		//Could add more test to check other locales have values as well
		List<?> def = view.getSpecialTableColumnsAttrDefinition(Locale.ENGLISH);
		//5 columns for dispositions, 4 for other misc purpose coming from the base view
		assertEquals(9, def.size());
		TextAttribute attr = (TextAttribute)def.get(7);
		assertEquals("inAssembledPartsDisposition", attr.getId());
		assertFalse(KBUtils.isEmpty(attr.getLabel()));
		attr = (TextAttribute)def.get(8);
		assertEquals("withCustomerDisposition", attr.getId());
	}
}
