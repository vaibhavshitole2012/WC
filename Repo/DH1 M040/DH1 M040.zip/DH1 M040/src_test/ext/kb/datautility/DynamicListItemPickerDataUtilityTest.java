package ext.kb.datautility;

import static org.junit.Assert.*;

import java.util.Map;

import org.junit.Test;

import com.ptc.core.components.rendering.guicomponents.PickerInputComponent;

import wt.pdmlink.PDMLinkProduct;

public class DynamicListItemPickerDataUtilityTest {

    DynamicListItemPickerDataUtility util = new DynamicListItemPickerDataUtility();
    
    @Test
    public void testGetDataValueStringObjectModelContext() throws Exception {
        PDMLinkProduct product = new PDMLinkProduct();
        Object result = util.getDataValue("", product, null);
        assertNotNull(result);
        //check your configuration, if KB dependant items have not been deployed this test will fail
        assertTrue(PickerInputComponent.class.getName().equals(result.getClass().getName()));
    }

    @Test
    public void testGetPickerConfigs() {
        Map<String, String> configs = DynamicListItemPickerDataUtility.getPickerConfigs("testId", "object", true);

        assertEquals("search", configs.get("pickerType"));
        assertEquals( "true", configs.get("required"));
        assertEquals("40", configs.get("width"));
        assertEquals("true", configs.get("showSuggestion"));
        assertEquals("2", configs.get("suggestMinChars"));
        //mapping to mapping settings
        assertEquals("Foundation.geklaPickerComponentId", configs.get("typeComponentId"));
        assertEquals("gekLaPicker", configs.get("componentId"));
        assertEquals("geklaPicker", configs.get("suggestServiceKey"));
        assertEquals("geklaPickerCallback", configs.get("pickerCallback"));
        //parameter based settings
        assertEquals("object", configs.get("objectType"));
        assertEquals("testId", configs.get("pickerId"));
    }

}
