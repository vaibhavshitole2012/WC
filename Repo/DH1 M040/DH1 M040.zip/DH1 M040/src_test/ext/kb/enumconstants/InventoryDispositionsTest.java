package ext.kb.enumconstants;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Test;

import wt.change2.InventoryDisposition;
import ext.kb.enumconstant.InventoryDispositions;

public class InventoryDispositionsTest {

	@Test
	public void testValueOf() {
		assertEquals(InventoryDispositions.DISPOSAL, InventoryDispositions.valueOf("wt.change2.InventoryDisposition.DISPOSAL"));
		assertEquals(InventoryDispositions.NOT_AFFECTED, InventoryDispositions.valueOf("wt.change2.InventoryDisposition.NOTAFFECTED"));
		assertEquals(InventoryDispositions.RECONDITION, InventoryDispositions.valueOf("wt.change2.InventoryDisposition.RECONDITION"));
		assertEquals(InventoryDispositions.SPECIAL_CASES, InventoryDispositions.valueOf("wt.change2.InventoryDisposition.SPECIALCASES"));
		assertEquals(InventoryDispositions.USE_UP, InventoryDispositions.valueOf("wt.change2.InventoryDisposition.USEUP"));
		assertNull(InventoryDispositions.valueOf("NOTknown"));
	}

	@Test
	public void testGetInventoryDispositionSet() {
		List<InventoryDisposition> dispositions = InventoryDispositions.getInventoryDispositionSet(); 
		assertEquals(5,  dispositions.size());
		assertTrue(dispositions.contains(InventoryDispositions.DISPOSAL));
		assertTrue(dispositions.contains(InventoryDispositions.NOT_AFFECTED));
		assertTrue(dispositions.contains(InventoryDispositions.RECONDITION));
		assertTrue(dispositions.contains(InventoryDispositions.USE_UP));
		assertTrue(dispositions.contains(InventoryDispositions.SPECIAL_CASES));
	}

	@Test
	public void testStaticConstants(){
		List<String> columns = InventoryDispositions.ADDITIONAL_INVENTORY_DISPOSITIONS;
		assertEquals(2, columns.size());
		assertTrue(columns.contains("inAssembledPartsDisposition"));
		assertTrue(columns.contains("withCustomerDisposition"));
		
		columns = InventoryDispositions.ALL_DISPOSITIONS;
		assertEquals(5, columns.size());
		assertTrue(columns.contains("inAssembledPartsDisposition"));
		assertTrue(columns.contains("withCustomerDisposition"));
		assertTrue(columns.contains("onOrderDisposition"));
		assertTrue(columns.contains("inventoryDisposition"));
		assertTrue(columns.contains("finishedDisposition"));
	}
}
