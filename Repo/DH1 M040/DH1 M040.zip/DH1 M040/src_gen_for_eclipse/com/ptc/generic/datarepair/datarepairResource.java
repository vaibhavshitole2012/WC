package com.ptc.generic.datarepair;

/**
 * Faked
 * Created on 26.06.2018 08:41:55<p>
 * @author ext-wangc
 *
 */
public class datarepairResource {
	public static final String ERROR_DATA_NOT_EXISTING	="Data {0} does not exist.";
}
