package com.ptc.generic.mail;


public class GenericMailHelper {

    
    public static final com.ptc.generic.mail.GenericMailService service = wt.services.ServiceFactory.getService(com.ptc.generic.mail.GenericMailService.class);

}
