package ext.kb.wtdoc;


public class KBWTDocNumberingHelper {

    
    public static final ext.kb.wtdoc.KBWTDocNumberingService service = wt.services.ServiceFactory.getService(ext.kb.wtdoc.KBWTDocNumberingService.class);

}
