package com.ptc.generic.epm;


public class EPMAssociateHelper {

    
    public static final com.ptc.generic.epm.EPMAssociateService service = wt.services.ServiceFactory.getService(com.ptc.generic.epm.EPMAssociateService.class);

}
