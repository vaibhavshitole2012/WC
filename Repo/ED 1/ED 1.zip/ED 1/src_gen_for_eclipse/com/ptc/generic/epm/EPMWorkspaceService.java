package com.ptc.generic.epm;



@wt.method.RemoteInterface
public interface EPMWorkspaceService extends wt.method.RemoteAccess {

    
    public wt.epm.workspaces.EPMWorkspace findOrCreateTempWS(wt.inf.container.WTContainer container)
        throws wt.util.WTException;

    
    public wt.epm.workspaces.EPMWorkspace findOrCreateWorkspace(java.lang.String wsName, wt.inf.container.WTContainer container, boolean isExactSearch)
        throws wt.util.WTException;

    
    public wt.epm.workspaces.EPMWorkspace findWorkspace(java.lang.String wsName, wt.org.WTPrincipal currentUser)
        throws wt.util.WTException;

    
    public wt.epm.workspaces.EPMWorkspace findWorkspace(java.lang.String wsName, wt.org.WTPrincipal currentUser, wt.inf.container.WTContainer container, boolean isExactSearch)
        throws wt.util.WTException;

    
    public wt.epm.workspaces.EPMWorkspace getWorkspace(java.lang.String workspaceName, wt.part.WTPart phase, boolean createWorkspace)
        throws wt.util.WTException;

    
    public wt.fc.WTReference findTempWS(wt.inf.container.WTContainer container)
        throws wt.util.WTException;

    
    public void deleteWorkspace(wt.epm.workspaces.EPMWorkspace ws)
        throws wt.util.WTException;

    
    public wt.epm.EPMDocument checkout(wt.epm.EPMDocument doc)
        throws wt.util.WTException;

    
    public java.util.Collection<wt.vc.baseline.Baselineable> checkout(wt.vc.baseline.Baselineable[] objs, wt.inf.container.WTContainer container)
        throws wt.util.WTException;

    
    public wt.epm.EPMDocument checkin(wt.epm.EPMDocument doc)
        throws wt.util.WTException;

    
    public java.util.Collection<wt.vc.baseline.Baselineable> checkin(wt.vc.baseline.Baselineable[] objs, wt.inf.container.WTContainer container, java.lang.String comment)
        throws wt.util.WTException;

    
    public com.ptc.windchill.uwgm.proesrv.RequestContext getRequestContext()
        throws wt.util.WTException;

}
