package com.ptc.generic.vc;


@wt.method.RemoteInterface
public interface VCService extends wt.method.RemoteAccess {

    
    public wt.vc.Versioned getLatestIterationForGivenVersion(wt.vc.Mastered m, java.lang.String version)
        throws wt.util.WTException;

}
