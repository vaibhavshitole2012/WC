package ext.kb.ws;

import java.io.IOException;
import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.xml.bind.JAXBException;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.deploy.util.PartMoveUtil;
import com.ptc.core.lwc.server.PersistableAdapter;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.TypeIdentifierHelper;
import com.ptc.core.meta.common.impl.WCTypeIdentifier;
import com.ptc.jws.servlet.JaxWsWebService;
import com.ptc.wpcfg.utilities.PrincipalHelper;

import ext.kb.project.ProjectHelper;
import ext.kb.service.WebServiceHelper;
import ext.kb.util.IBAHelper;
import ext.kb.util.KBConstants;
import ext.kb.util.KBUtils;
import ext.kb.util.MaterialHelper;
import ext.kb.util.NamingHelper;
import ext.kb.util.ObjectRevisionHelper;
import wt.configuration.TraceCode;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.folder.Folder;
import wt.folder.FolderHelper;
import wt.iba.definition.litedefinition.AttributeDefDefaultView;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerRef;
import wt.inf.library.WTLibrary;
import wt.lifecycle.LifeCycleHelper;
import wt.lifecycle.State;
import wt.log4j.LogR;
import wt.org.WTOrganization;
import wt.org.WTPrincipalReference;
import wt.part.QuantityUnit;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.pdmlink.PDMLinkProduct;
import wt.pds.StatementSpec;
import wt.pom.Transaction;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.series.MultilevelSeries;
import wt.type.TypeDefinitionReference;
import wt.type.TypedUtilityServiceHelper;
import wt.util.WTException;
import wt.util.WTProperties;
import wt.util.WTPropertyVetoException;
import wt.vc.IterationIdentifier;
import wt.vc.VersionControlHelper;
import wt.vc.VersionIdentifier;
import wt.vc.wip.WorkInProgressHelper;
import wt.queue.ProcessingQueue;

@WebService()
public class KBUpdatePartService extends JaxWsWebService {
	private static final Logger LOGGER = LogR.getLogger(KBUpdatePartService.class.getName());
	private static final Logger logWriter = LogR.getLogger("ext.kb.ws.KBUpdatePartService_Log");

	@WebMethod(operationName = "updatePart")
	public List<String> updatePart(@WebParam(name = "partID") String partID,
			@WebParam(name = "ibas") HashMap<String, String> ibas, @WebParam(name = "name") String name,
			@WebParam(name = "number") String number,
			@WebParam(name = "responsibleDepartment") String responsibleDepartment,
			@WebParam(name = "defaultTraceCode") String defaultTraceCode,
			@WebParam(name = "defaultUnit") String defaultUnit,
			@WebParam(name = "hidePartInStructure") String hidePartInStructure,
			@WebParam(name = "revisionIdentifier") String revisionIdentifier,
			@WebParam(name = "creatorName") String creatorName,
			@WebParam(name = "checkinComment") String checkinComment,
			@WebParam(name = "targetState") String targetState, @WebParam(name = "masterSystem") String masterSystem,
			@WebParam(name = "Old_CID") String Old_CID) throws WTException, WTPropertyVetoException, JAXBException,
			ParseException, IOException, ClassNotFoundException




//test



	{
		WTPart resPart = null;
		WTPart latestPartIteration = null;
		WTPart workingCopyPart = null;
		WTPartMaster parentMaster = null;
		Timestamp oldCadimTransferDate;
		Transaction trx = null;
		List<String> result = new ArrayList<String>();
		
		String commonAttributes = "collapsible|serviceable|servicekit|hidePartInStructure|defaultUnit|defaultTraceCode|containerReference|revision|state.lifeCycleId|state.state|thePersistInfo.createStamp|thePersistInfo.modifyStamp";
		int partFound = 0;
		WTProperties properties = WTProperties.getServerProperties();
		String defaultDomain = properties.getProperty("KBDefaultExternalDomain", "CADIM DOMAIN");
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");

		try {

			trx = new Transaction();
			trx.start();
			
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			Date date = new Date();
			String formatedDate = sdf.format(date);
			Timestamp transferDate = new Timestamp(dateFormat.parse(ibas.get("KB_CADIM_TRANSFER_DATE")).getTime());
			logWriter.info("Processing Update request on " + formatedDate + " for part where number is " + number
					+ " and name is " + name + " responsibleDepartment = " + responsibleDepartment
					+ " defaultTraceCode = " + defaultTraceCode + " defaultUnit = " + defaultUnit
					+ " hidePartInStructure " + hidePartInStructure + " creatorName " + creatorName + " checkinComment "
					+ checkinComment + " Old_CID " + Old_CID);

			String C_ID = ibas.get("KB_CADIM_CID");
			if(LOGGER.isDebugEnabled()){
				LOGGER.debug("KB_CADIM_CID is ===" + C_ID);
			}	
			QuerySpec resQS = WebServiceHelper.findPartByNumberAndCadim(partID, C_ID);
			QueryResult resQR = PersistenceHelper.manager.find((StatementSpec) resQS);
			int size = resQR.size();
			if(LOGGER.isDebugEnabled()){
				LOGGER.debug("resQR: " + resQR);
				LOGGER.debug("size: " + size);
				LOGGER.debug("Old_CID ===" + Old_CID);
				LOGGER.debug("Old_CID == null ===" + (Old_CID != null));
			}
			
			// to get translation ID from ibas - start
			String translationID = "";
			String namingPartValue = "";
			if (ibas.keySet().contains(KBConstants.TRANSLATION_ID_IBA)) {
				translationID = ibas.get(KBConstants.TRANSLATION_ID_IBA);
				// Getting Description 1 EN value using NamingEntry and translation ID
				if (translationID != null && !translationID.equalsIgnoreCase("")) {
					if(LOGGER.isDebugEnabled()){
						LOGGER.debug("translationID has been obtained. Translation ID is :" + translationID);
					}
					WTPart namingPart = NamingHelper.getNamingEntryByNumber(translationID);
					if(LOGGER.isDebugEnabled()){
						LOGGER.debug("Naming catalog part obtained is :" + namingPart);
					}
					if (namingPart != null) {
						namingPartValue = namingPart.getName();
						if(LOGGER.isDebugEnabled()){
							LOGGER.debug("Naming catalog part name is :" + namingPartValue);
						}
					}
				}
			}
		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("TranslationID is : " + translationID);
		}
			// to get translation ID from ibas - stop

			if (size > 0) {
				if(LOGGER.isDebugEnabled()){
					LOGGER.debug("Part found with number " + partID + " and CID " + C_ID + " Part will be iterated");
				}
				logWriter.info("Part found with number " + partID + " and CID " + C_ID + " Part will be Iterated");
				Persistable resObj[] = (Persistable[]) resQR.nextElement();
				logWriter.info("resObj: " + resObj);
				logWriter.info("resObj: " + resObj[0]);
				resPart = (WTPart) resObj[0];
				logWriter.info("resPart: " + resPart);
				WTPart latestPartRevision = (WTPart) ObjectRevisionHelper.getLatestVersionByPersistable(resPart);
				latestPartIteration = (WTPart) VersionControlHelper.getLatestIteration(latestPartRevision);
				//retrieving design view part
				 latestPartIteration = (WTPart)WebServiceHelper.getDesignViewPart((WTPart)latestPartIteration);
					if(latestPartIteration == null)
						throw new WTException("Design view Part with number "+latestPartRevision.getNumber()+" not found");
				oldCadimTransferDate = IBAHelper.readIBA(latestPartIteration, "KB_CADIM_TRANSFER_DATE");
				if(LOGGER.isDebugEnabled()){
					LOGGER.debug("Part found with KB_CADIM_TRANSFER_DATE " + oldCadimTransferDate);
				}
				logWriter.info("Part found with KB_CADIM_TRANSFER_DATE " + oldCadimTransferDate);
				if (oldCadimTransferDate.after(transferDate)) {
					if(LOGGER.isDebugEnabled()){
						LOGGER.debug("Trigger date is earlier that CADIM Update date Skipping the trigger");
					}
					logWriter.info("Trigger date is earlier that CADIM Update date Skipping the trigger");
					throw new WTException("Trigger date " + transferDate + "is earlier that CADIM Update date "
							+ oldCadimTransferDate + " forpart version "
							+ latestPartIteration.getVersionIdentifier().getValue() + " and Iteration  "
							+ latestPartIteration.getIterationIdentifier().getValue() + " Skipping the trigger");
				}
				parentMaster = (WTPartMaster) latestPartIteration.getMaster();
				String partRevInfo = latestPartIteration.getVersionIdentifier().getValue();
				if(LOGGER.isDebugEnabled()){
					LOGGER.debug("revisionIdentifier " + revisionIdentifier);
				}
				logWriter.info("revisionIdentifier " + revisionIdentifier);
				if(LOGGER.isDebugEnabled()){
					LOGGER.debug("partRevInfo " + partRevInfo);
				}
				logWriter.info("partRevInfo " + partRevInfo);
				if (!revisionIdentifier.equalsIgnoreCase(partRevInfo)) {
					if(LOGGER.isDebugEnabled()){
						LOGGER.debug("revisionIdentifier " + revisionIdentifier + " is greater than part rev " + partRevInfo
							+ " so new revision will be created");
					}
					logWriter.info("revisionIdentifier " + revisionIdentifier + " is greater than part rev "
							+ partRevInfo + " so new revision will be created");
					latestPartIteration.getMaster().setSeries("wt.series.HarvardSeries.KB_Revision");
					MultilevelSeries multilevelseries = MultilevelSeries
							.newMultilevelSeries("wt.series.HarvardSeries.KB_Revision", revisionIdentifier);
					VersionIdentifier versionidentifier = VersionIdentifier.newVersionIdentifier(multilevelseries);
					IterationIdentifier iterationIdentifier = (IterationIdentifier) IterationIdentifier
							.newIterationIdentifier("0");
					latestPartIteration = (WTPart) VersionControlHelper.service.newVersion(latestPartIteration,
							versionidentifier, iterationIdentifier);
					logWriter.info("New Part Revision created. Creator is " + creatorName);
					if(LOGGER.isDebugEnabled()){
						LOGGER.debug("Created by ==" + creatorName);
					}
					if (creatorName != null) {
						WTPrincipalReference principalReference = PrincipalHelper.getPrincipal(creatorName);
						if (principalReference != null)
							VersionControlHelper.assignIterationCreator(latestPartIteration, principalReference);
						else {
							WTPrincipalReference principalReference1 = PrincipalHelper.getPrincipal("INTERFACE_SAP");
							VersionControlHelper.assignIterationCreator(latestPartIteration, principalReference1);
						}
					}
					latestPartIteration = (WTPart) PersistenceHelper.manager.save(latestPartIteration);
					latestPartIteration = (WTPart) PersistenceHelper.manager.refresh(latestPartIteration);
					latestPartIteration = (WTPart) IBAHelper.setIba(latestPartIteration, "KB_CADIM_CID", C_ID);
					PersistenceServerHelper.manager.update(latestPartIteration);
				
				}
			} else {
				if(LOGGER.isDebugEnabled()){
					LOGGER.debug("No Part found with number " + partID + " and CID " + C_ID
						+ " Going to search part with Old_CID");
				}
				logWriter.info("No Part found with number " + partID + " and CID " + C_ID
						+ " Going to search part with Old_CID");
				QuerySpec newQS = WebServiceHelper.findPartByNumberAndCadim(partID, Old_CID);
				QueryResult newQR = PersistenceHelper.manager.find((StatementSpec) newQS);
				int size1 = newQR.size();
				if(LOGGER.isDebugEnabled()){
					LOGGER.debug("size: " + size1);
				}
				if (size1 > 0) {
					Persistable newObj[] = (Persistable[]) newQR.nextElement();
					resPart = (WTPart) newObj[0];
					System.out.println("resPart: " + resPart);
					WTPart latestPartRevision = (WTPart) ObjectRevisionHelper.getLatestVersionByPersistable(resPart);
					latestPartIteration = (WTPart) VersionControlHelper.getLatestIteration(latestPartRevision);
					//retrieving design view part
					 latestPartIteration = (WTPart)WebServiceHelper.getDesignViewPart((WTPart)latestPartIteration);
						if(latestPartIteration == null)
							throw new WTException("Design view Part with number "+latestPartRevision.getNumber()+" not found");
					oldCadimTransferDate = IBAHelper.readIBA(latestPartIteration, "KB_CADIM_TRANSFER_DATE");
					if(LOGGER.isDebugEnabled()){
						LOGGER.debug("Part found with KB_CADIM_TRANSFER_DATE " + oldCadimTransferDate);
					}
					logWriter.info("Part found with KB_CADIM_TRANSFER_DATE " + oldCadimTransferDate);
					if (oldCadimTransferDate.after(transferDate)) {
						if(LOGGER.isDebugEnabled()){
							LOGGER.debug("Trigger date is earlier that CADIM Update date Skipping the trigger");
						}
						logWriter.info("Trigger date is earlier that CADIM Update date Skipping the trigger");
						throw new WTException("Trigger date " + transferDate + "is earlier that CADIM Update date "
								+ oldCadimTransferDate + " forpart version "
								+ latestPartIteration.getVersionIdentifier().getValue() + " and Iteration  "
								+ latestPartIteration.getIterationIdentifier().getValue() + " Skipping the trigger");
					}
					// latestPartIteration = (WTPart)
					// VersionControlHelper.service.newVersion(latestPartIteration);
					String oldPartRevInfo = latestPartIteration.getVersionIdentifier().getValue();
					if(LOGGER.isDebugEnabled()){
						LOGGER.debug("revisionIdentifier of old part" + revisionIdentifier);
					}
					logWriter.info("revisionIdentifier " + revisionIdentifier);
					if(LOGGER.isDebugEnabled()){
						LOGGER.debug("oldPartRevInfo " + oldPartRevInfo);
					}
					logWriter.info("oldPartRevInfo " + oldPartRevInfo);
					if (!revisionIdentifier.equalsIgnoreCase(oldPartRevInfo)) {
						latestPartIteration.getMaster().setSeries("wt.series.HarvardSeries.KB_Revision");
						MultilevelSeries multilevelseries = MultilevelSeries
								.newMultilevelSeries("wt.series.HarvardSeries.KB_Revision", revisionIdentifier);
						VersionIdentifier versionidentifier = VersionIdentifier.newVersionIdentifier(multilevelseries);
						IterationIdentifier iterationIdentifier = (IterationIdentifier) IterationIdentifier
								.newIterationIdentifier("0");
						latestPartIteration = (WTPart) VersionControlHelper.service.newVersion(latestPartIteration,
								versionidentifier, iterationIdentifier);
						logWriter.info("New Part Revision created. Creator is " + creatorName);
						if(LOGGER.isDebugEnabled()){
							LOGGER.debug("Created by ==" + creatorName);
						}
						if (creatorName != null) {
							WTPrincipalReference principalReference = PrincipalHelper.getPrincipal(creatorName);
							if (principalReference != null)
								VersionControlHelper.assignIterationCreator(latestPartIteration, principalReference);
							else {
								WTPrincipalReference principalReference1 = PrincipalHelper
										.getPrincipal("INTERFACE_SAP");
								VersionControlHelper.assignIterationCreator(latestPartIteration, principalReference1);
							}
						}
						latestPartIteration = (WTPart) PersistenceHelper.manager.save(latestPartIteration);
						latestPartIteration = (WTPart) PersistenceHelper.manager.refresh(latestPartIteration);
						latestPartIteration = (WTPart) IBAHelper.setIba(latestPartIteration, "KB_CADIM_CID", C_ID);
						PersistenceServerHelper.manager.update(latestPartIteration);
						if(LOGGER.isDebugEnabled()){
							LOGGER.debug("containerName name ===" + latestPartIteration.getContainerName());
						}
						logWriter.info("containerName name ===" + latestPartIteration.getContainerName());
						if(LOGGER.isDebugEnabled()){
							LOGGER.debug(
								" part domain before \"" + latestPartIteration.getDomainRef().getName() + "\" domain");
						}
						logWriter.info(
								" part domain before \"" + latestPartIteration.getDomainRef().getName() + "\" domain");
						// WebServiceHelper.setCadimDomain(latestPartIteration,
						// defaultDomain,latestPartIteration.getContainerName());
						if(LOGGER.isDebugEnabled()){
							LOGGER.debug(
								" part domain After \"" + latestPartIteration.getDomainRef().getName() + "\" domain");
						}
						logWriter.info(
								" part domain After \"" + latestPartIteration.getDomainRef().getName() + "\" domain");
						parentMaster = (WTPartMaster) latestPartIteration.getMaster();

				
					}
				} else {
					partFound = 1;
					throw new WTException(" Part with number " + partID + " and  Old CID " + Old_CID + " or new CID "
							+ C_ID + "  not found");
				}
			}

			boolean partCheckedOut = WorkInProgressHelper.isCheckedOut(latestPartIteration);
			if (!partCheckedOut) {
				if(LOGGER.isDebugEnabled()){
					LOGGER.debug("latestPartIteration: " + latestPartIteration);
					LOGGER.debug("parentMaster: " + parentMaster);
				}
				parentMaster.setDefaultTraceCode(TraceCode.toTraceCode(defaultTraceCode));
				if(LOGGER.isDebugEnabled()){
					LOGGER.debug("After defaultTraceCode set ");
				}
				parentMaster.setDefaultUnit(QuantityUnit.toQuantityUnit(defaultUnit));
				if(LOGGER.isDebugEnabled()){
					LOGGER.debug("After defaultUnit set ");
				}
				parentMaster.setHidePartInStructure(Boolean.valueOf(hidePartInStructure));
				if(LOGGER.isDebugEnabled()){
					LOGGER.debug("After hidePartInStructure set ");
					LOGGER.debug("number: " + number);
					LOGGER.debug("name: " + name);
					LOGGER.debug("Revision is " + latestPartIteration.getVersionIdentifier().getValue());
					LOGGER.debug("Iteration is " + latestPartIteration.getIterationIdentifier().getValue());
					LOGGER.debug("b4 set name number ");
				}
				String orgName = latestPartIteration.getOrganizationName();
				if(LOGGER.isDebugEnabled()){
					LOGGER.debug("Org name is ===" + orgName);
				}
				String partName = latestPartIteration.getName();
				if(LOGGER.isDebugEnabled()){
					LOGGER.debug("partName is ===" + partName);
				}
				String partNumber = latestPartIteration.getNumber();
				if(LOGGER.isDebugEnabled()){
					LOGGER.debug("partNumber is ===" + partNumber);
				}
				WTOrganization wtorg = MaterialHelper.getWTOrganization(orgName);
				parentMaster = (WTPartMaster) PersistenceHelper.manager.save(parentMaster);
				TypeIdentifier targetType = wt.type.TypedUtilityServiceHelper.service
						.getTypeIdentifier(latestPartIteration);
				PersistableAdapter persistanceAdapter = new PersistableAdapter((Persistable) latestPartIteration,
						((WCTypeIdentifier) targetType).getLeafName(), null, null);
				WorkInProgressHelper.service.checkout(latestPartIteration,
						WorkInProgressHelper.service.getCheckoutFolder(),
						"Checked out to synchronize update from CADIM");
				workingCopyPart = (WTPart) WorkInProgressHelper.service.workingCopyOf(latestPartIteration);
				PersistableAdapter workingPartAdapter = new PersistableAdapter((Persistable) workingCopyPart,
						((WCTypeIdentifier) targetType).getLeafName(), null, null);
				persistanceAdapter.load(ibas.keySet());
				workingPartAdapter.load(ibas.keySet());
				for (Entry<String, String> attEntry : ibas.entrySet()) {
					AttributeDefDefaultView attributeDefinition = IBAHelper
							.getAttributeDefDefaultView(attEntry.getKey());
					if(LOGGER.isDebugEnabled()){
						LOGGER.debug("Attribute Definition ==" + attributeDefinition);
						LOGGER.debug("Attribute name AND VALUE is" + attEntry.getKey() + " " + attEntry.getValue());
					}
					logWriter.info("Attribute name is" + attEntry.getKey());
					// setting description 1 EN from translation ID - start
					if ( (KBConstants.DESCRIPTION_EN.equalsIgnoreCase(attEntry.getKey()) && ! namingPartValue.isEmpty()) ||
							(KBConstants.DESCRIPTION_NATIVE.equalsIgnoreCase(attEntry.getKey()) && ! namingPartValue.isEmpty())
							) {
							attEntry.setValue(namingPartValue);
							AttributeDefDefaultView attributeDefDefaultView = IBAHelper
									.getAttributeDefDefaultView(attEntry.getKey());
							Object attrValue = WebServiceHelper.parseAttributeValue(attributeDefDefaultView,
									attEntry.getValue());						
							if (!commonAttributes.contains(attEntry.getKey())) {
								if(LOGGER.isDebugEnabled()){
									LOGGER.debug("Setting attribute "+attEntry.getKey()+" value as----> : " + namingPartValue+ attEntry.getValue());
								}
								workingPartAdapter.set(attEntry.getKey(), attrValue);
							}
							// setting description 1 EN from translation ID - end
					}else if (attEntry.getValue() != null && !attEntry.getValue().equals("")) {
						if(LOGGER.isDebugEnabled()){
								LOGGER.debug(" Attribute Value is not null it is " + attEntry.getValue());
						}
							logWriter.info(" Attribute Value is not null it is " + attEntry.getValue());
							if (KBConstants.KBMATERIAL_IBA.equalsIgnoreCase(attEntry.getKey())) {
								if(LOGGER.isDebugEnabled()){
									LOGGER.debug("Updating KB_MATERIAL");
								}
								String value = KBUtils.convertMaterialNameNumber(workingCopyPart, attEntry.getValue());
								if(LOGGER.isDebugEnabled()){
									LOGGER.debug("VALUE :::::::::: " + value);
								}
								if (StringUtils.isEmpty(value)){
									value = MaterialHelper.queryMaterialNumberByName(attEntry.getValue());
								}
								AttributeDefDefaultView attributeDefDefaultView = IBAHelper
										.getAttributeDefDefaultView(attEntry.getKey());
								Object attrValue = WebServiceHelper.parseAttributeValue(attributeDefDefaultView, value);
								if(LOGGER.isDebugEnabled()){
									LOGGER.debug("Attribute name is" + attEntry.getKey() + " Attribute Value is " + attrValue);
								}
								if (!commonAttributes.contains(attEntry.getKey())) {
									if(LOGGER.isDebugEnabled()){
										LOGGER.debug("Attribute name isnot contained in common attributes");
										LOGGER.debug(
											"Attribute name is" + attEntry.getKey() + " Attribute Value is " + attrValue);
									}
									workingPartAdapter.set(attEntry.getKey(), attrValue);
								}
							} else {

							AttributeDefDefaultView attributeDefDefaultView = IBAHelper
									.getAttributeDefDefaultView(attEntry.getKey());
							Object attrValue = WebServiceHelper.parseAttributeValue(attributeDefDefaultView,
									attEntry.getValue());
							if(LOGGER.isDebugEnabled()){
								LOGGER.debug("Attribute name is" + attEntry.getKey() + " Attribute Value is " + attrValue);
							}
							if (!commonAttributes.contains(attEntry.getKey())) {
								if(LOGGER.isDebugEnabled()){
									LOGGER.debug("Attribute name isnot contained in common attributes");
									LOGGER.debug(
										"Attribute name is" + attEntry.getKey() + " Attribute Value is " + attrValue);
								}
								workingPartAdapter.set(attEntry.getKey(), attrValue);
							}
						}
					} else //if (KBConstants.KBMATERIAL_IBA.equalsIgnoreCase(attEntry.getKey())) 
					{
						if(LOGGER.isDebugEnabled()){
							LOGGER.debug(" Attribute Value is null " + attEntry.getValue());
						}
						logWriter.info(" Attribute Value is null " + attEntry.getValue());

						if (!commonAttributes.contains(attEntry.getKey())) {
							if(LOGGER.isDebugEnabled()){
								LOGGER.debug("Attribute name isnot contained in common attributes ");
							}
							logWriter.info("Attribute name is" + attEntry.getKey() + " Attribute Value is blank");
							workingPartAdapter.set(attEntry.getKey(), "");
						}
					}
				}
				workingPartAdapter.apply();
				PersistenceHelper.manager.save(workingCopyPart);
				workingCopyPart = (WTPart) WorkInProgressHelper.service.checkin(workingCopyPart, checkinComment);
				if(LOGGER.isDebugEnabled()){
					LOGGER.debug("After check in ");
					LOGGER.debug("containerName name ===" + workingCopyPart.getContainerName());
					LOGGER.debug(" part domain before \"" + workingCopyPart.getDomainRef().getName() + "\" domain");
				}
				logWriter.info("containerName name ===" + workingCopyPart.getContainerName());
				logWriter.info(" part domain before \"" + workingCopyPart.getDomainRef().getName() + "\" domain");
				if(LOGGER.isDebugEnabled()){
					LOGGER.debug(" part domain After \"" + workingCopyPart.getDomainRef().getName() + "\" domain");
				}
				logWriter.info(" part domain After \"" + workingCopyPart.getDomainRef().getName() + "\" domain");
				if(LOGGER.isDebugEnabled()){
					LOGGER.debug("Created by ==" + creatorName);
				}
				if (creatorName != null) {
					WTPrincipalReference principalReference = PrincipalHelper.getPrincipal(creatorName);
					if (principalReference != null) {
						if(LOGGER.isDebugEnabled()){
							LOGGER.debug("Setting Modified By " + principalReference.getDisplayName());
						}
						VersionControlHelper.setIterationModifier(workingCopyPart, principalReference);
						if(LOGGER.isDebugEnabled()){
							LOGGER.debug("After Setting Modified By for version "
								+ workingCopyPart.getVersionInfo().getIdentifier().getValue() + " and iteration "
								+ workingCopyPart.getIterationInfo().getIdentifier().getValue());
						}
					} else {
						WTPrincipalReference principalReference1 = PrincipalHelper.getPrincipal("INTERFACE_SAP");
						VersionControlHelper.setIterationModifier(workingCopyPart, principalReference1);
					}
				}
				PersistenceHelper.manager.save(workingCopyPart);

				if (targetState != null&& !targetState.equalsIgnoreCase(workingCopyPart.getLifeCycleState().toString())) {
					LifeCycleHelper.service.setLifeCycleState(workingCopyPart, State.toState(targetState));
					logWriter.info("targetState is " + targetState + " for version "
							+ workingCopyPart.getVersionInfo().getIdentifier().getValue() + " and iteration "
							+ workingCopyPart.getIterationInfo().getIdentifier().getValue());
				}
				if(LOGGER.isDebugEnabled()){
					LOGGER.debug("Documents State :: " + targetState);
				}
				if(targetState!=null) {
				int	intState=Integer.parseInt(targetState);
				if(intState>=1030) {
					if(LOGGER.isDebugEnabled()){
						LOGGER.debug("Sharing object to project");
					}
					String queueName = properties.getProperty("ext.kb.ws.shareToProjectQueueName", "ShareToProjectQueue");
					LOGGER.debug("Queue name [{" + queueName + "}]");
					ProcessingQueue queue = ShareToProjectQueueHelper.getQueue(queueName);
					if (queue == null) {
						LOGGER.error("Queue with name [{" + queueName + "}] was not found");
					} else {
						ShareToProjectQueueHelper.addQueueEntry(queue, latestPartIteration);
					}
					if(LOGGER.isDebugEnabled()){
						LOGGER.debug("Shared to project");
					}
					}
				}
				String containerName = resPart.getContainerName();
				if(LOGGER.isDebugEnabled()){
					LOGGER.debug("Container name==" + containerName);
				}
				String partPath = resPart.getFolderPath();
				String partLocation = resPart.getLocation();
				if(LOGGER.isDebugEnabled()){
					LOGGER.debug("partPath name==" + partPath);
					LOGGER.debug("partLocation name==" + partLocation);
					LOGGER.debug("responsibleDepartment name==" + responsibleDepartment);
				}
				if (!responsibleDepartment.equalsIgnoreCase(containerName)) {
					WTContainer productContainer = getContainerProduct(responsibleDepartment);
					WTLibrary library = null;
					if (productContainer == null) {
						library = getLibraryContainer(responsibleDepartment);
						if (library != null) {
							if(LOGGER.isDebugEnabled()){
								LOGGER.debug("Target Container ==="+library.getName());
							}
							logWriter.info("Target Container ===" + library.getName());
						} else {
							if(LOGGER.isDebugEnabled()){
								LOGGER.debug("Target Container not found");
							}
							logWriter.info("Target Container not found");
						}
					} else {
						if(LOGGER.isDebugEnabled()){
							LOGGER.debug("Target Container ==="+productContainer.getName());
						}
						logWriter.info("Target Container ===" + productContainer.getName());
					}
					
					WTContainerRef contRef = WTContainerRef.newWTContainerRef(productContainer != null ? productContainer : library);
					try {
						Folder f = FolderHelper.service.getFolder(partLocation, contRef);
						PartMoveUtil.moveAllViewVersionsToContainer(productContainer != null ? productContainer : library, partLocation, resPart);
						logWriter.info("Moved part to " + responsibleDepartment + partLocation);

					} catch (WTException e) {
						String message = "Destination folder -  " + partLocation
								+ " not found moving to 20 BA - Extended";
						if(LOGGER.isDebugEnabled()){
							LOGGER.debug(message);
						}
						logWriter.info(message);
						PartMoveUtil.moveAllViewVersionsToContainer(productContainer != null ? productContainer : library, "/Default/20 BA - Extended", resPart);
						logWriter.info("Moved part to " + responsibleDepartment + " /Default/20 BA - Extended");
					}
					WTPart part = (WTPart) VersionControlHelper.getLatestIteration(workingCopyPart);
					logWriter.info(" Changing domain for version " + part.getVersionInfo().getIdentifier().getValue()
							+ " and iteration " + part.getIterationInfo().getIdentifier().getValue());
					if(LOGGER.isDebugEnabled()){
						LOGGER.debug("containerName name ===" + part.getContainerName());
						LOGGER.debug(" part domain before \"" + part.getDomainRef().getName() + "\" domain");
					}
					logWriter.info("containerName name ===" + part.getContainerName());
					logWriter.info(" part domain before \"" + part.getDomainRef().getName() + "\" domain");
					if(LOGGER.isDebugEnabled()){
						LOGGER.debug(" part domain After \"" + part.getDomainRef().getName() + "\" domain");
					}
					logWriter.info(" part domain After \"" + part.getDomainRef().getName() + "\" domain");
				}
				if (masterSystem != null && masterSystem.equalsIgnoreCase("WCT")) {
					WTPartMaster master = (WTPartMaster) latestPartIteration.getMaster();
					IBAHelper.updateIBAAttributeValueWithoutCheckout(master, "KB_MASTERSYSTEM", "WCT");
					WTPart part = (WTPart) VersionControlHelper.getLatestIteration(latestPartIteration);
					if(LOGGER.isDebugEnabled()){
						LOGGER.debug("After setting master system");
					}
					updatePartType(part);
					if(LOGGER.isDebugEnabled()){
						LOGGER.debug(" Changed parttype " + part.getNumber());
					}
					logWriter.info("Changed parttype " + part.getNumber());
					String articleLocation = part.getLocation();
					WTContainerRef contRef = part.getContainerReference();
					if(LOGGER.isDebugEnabled()){
						LOGGER.debug("containerName name ===" + part.getContainerName());
					}
					logWriter.info("containerName name ===" + part.getContainerName());
					if(LOGGER.isDebugEnabled()){
						LOGGER.debug("going to move related AXL parts ");
					}
					logWriter.info("going to move related AXL parts ");
					WebServiceHelper.moveAXLParts(part);
					if(LOGGER.isDebugEnabled()){
						LOGGER.debug("After moving related AXL parts ");
					}
					logWriter.info("After moving related AXL parts ");
					if(LOGGER.isDebugEnabled()){
						LOGGER.debug("going to create MLK supplier Mapping ");
					}
					logWriter.info("going to create MLK supplier Mapping ");
					String basicText = WebServiceHelper.createMLKSupplierMapping(part);
					if(LOGGER.isDebugEnabled()){
						LOGGER.debug("After create MLK supplier Mapping basic Text == " + basicText);
					}
					logWriter.info("After create MLK supplier Mapping basicText == " + basicText);
					if (basicText != "") {
						part = (WTPart) IBAHelper.setIba(part, "KB_BASIC_TEXT", basicText);
						if(LOGGER.isDebugEnabled()){
							LOGGER.debug("After setting Basic text " + basicText);
						}
						logWriter.info("After setting Basic text " + basicText);
					}
					String presentFolder = part.getFolderPath();
					String[] folderPath = presentFolder.split("/");
					if(LOGGER.isDebugEnabled()){
						LOGGER.debug(" presentFolder" + presentFolder);
					}
					logWriter.info(" presentFolder " + presentFolder);
					String targetFolder = "/" + folderPath[1] + "/" + folderPath[2] + "/Data";
					if(LOGGER.isDebugEnabled()){
						LOGGER.debug(" targetFolder" + targetFolder);
					}
					logWriter.info(" targetFolder " + targetFolder);
					PartMoveUtil.moveAllViewVersionsToContainer(contRef.getContainer(), targetFolder, part);
					if(LOGGER.isDebugEnabled()){
						LOGGER.debug(" Moved " + part.getNumber() + " to folder " + targetFolder);
					}
					logWriter.info(" Moved " + part.getNumber() + " to folder " + targetFolder);
					
					
				}
				if(LOGGER.isDebugEnabled()){
					LOGGER.debug("trx===" + trx);
				}
				logWriter.info("trx===" + trx);
				trx.commit();
				trx = null;
				result.add("ReturnCode: 0");
				result.add("Text: Success");
				logWriter.info("result from the service is " + result);
				return result;
			} else {
				throw new WTException(" Part with number " + partID + " and CID " + C_ID + " is checked out");
			}

		} catch (IOException e) {
			String message = "IOException during log file creation exception is " + e;
			result.add("ReturnCode: 1");
			result.add("Text: " + message);
			// return message;
			logWriter.info("result from the service is " + result);
			return result;
		} catch (WTException e) {
			if (WorkInProgressHelper.isCheckedOut(latestPartIteration))
				latestPartIteration = (WTPart) WorkInProgressHelper.service
						.undoCheckout(WorkInProgressHelper.service.workingCopyOf(latestPartIteration));
			String message = "WTException during update IBA's exception is " + e;
			if (partFound == 0) {
				result.add("ReturnCode: 1");
			} else {
				result.add("ReturnCode: 2");
			}
			result.add("Text: " + message);
			logWriter.info("result from the service is " + result);
			return result;

		} catch (WTPropertyVetoException e) {
			if (WorkInProgressHelper.isCheckedOut(latestPartIteration))
				latestPartIteration = (WTPart) WorkInProgressHelper.service
						.undoCheckout(WorkInProgressHelper.service.workingCopyOf(latestPartIteration));
			String message = "WTPropertyVetoException during update IBA's exception is " + e;
			result.add("ReturnCode: 1");
			result.add("Text: " + message);
			logWriter.info("result from the service is " + result);
			return result;
		} finally {
			System.out.println("trx in finally===" + trx);
			if (trx != null) {
				trx.rollback();
			}
			
		}
	}

	private static WTContainer getContainerProduct(String container) {

		WTContainer cont = null;

		try {

			int[] fromIndicies = { 0, -1 };

			QuerySpec querySpec = new QuerySpec(PDMLinkProduct.class);
			querySpec.appendWhere(
					new SearchCondition(PDMLinkProduct.class, PDMLinkProduct.NAME, SearchCondition.EQUAL, container),
					fromIndicies);
			Enumeration contEnum = PersistenceHelper.manager.find((StatementSpec) querySpec);
			if (contEnum.hasMoreElements()) {
				cont = (WTContainer) contEnum.nextElement();
				System.out.println("container ===" + cont);

			}

		} catch (WTException e) {
			e.printStackTrace();
		}
		return cont;
	}

	private static WTLibrary getLibraryContainer(String sContainer) throws WTException {

		WTLibrary library = null;

		try {
			QuerySpec qs = new QuerySpec(WTLibrary.class);
			SearchCondition sc = new SearchCondition(WTLibrary.class, WTLibrary.NAME, "=", sContainer);
			qs.appendWhere(sc, new int[0]);
			QueryResult qr = PersistenceHelper.manager.find((StatementSpec) qs);
			if (qr.hasMoreElements()) {
				library = (WTLibrary) qr.nextElement();
			}
		} catch (WTException e) {
			LOGGER.error(e);
		}

		return library;
	}
	
	private static void updatePartType(WTPart latestPartIteration) throws WTException {
		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("updatePartType "+latestPartIteration);
		}
	    logWriter.info("updatePartType "+latestPartIteration);
		 String partCategory = IBAHelper.readIBA(latestPartIteration, "KB_PART_CATEGORY");
		 if(LOGGER.isDebugEnabled()){
			 LOGGER.debug("partCategory "+partCategory);
		 }
         logWriter.info("partCategory "+partCategory);
         boolean partIsFromKBOrg = false;
         if(LOGGER.isDebugEnabled()){
        	 LOGGER.debug("latestPartIteration.getOrganizationName() "+latestPartIteration.getOrganizationName());
         }
         if(latestPartIteration.getOrganizationName().equalsIgnoreCase("KB")){
        	 partIsFromKBOrg = true;
         }
         if(LOGGER.isDebugEnabled()){
        	 LOGGER.debug("partIsFromKBOrg -> "+partIsFromKBOrg);
         }
         if(partCategory.equals("1")||partCategory.equals("2")||partCategory.equals("3"))
         {
        	 changeTypeOfPart(latestPartIteration, "com.ptc.KBAssemblyComponent");
        	 if(LOGGER.isDebugEnabled()){
        		 LOGGER.debug("Type of WTPart - " + latestPartIteration.getName() + " , numbner : " + latestPartIteration.getNumber()
  					+ " , version : " + latestPartIteration.getVersionIdentifier().getValue() + "."
  					+ latestPartIteration.getIterationIdentifier().getValue() + " OID "
  					+ PersistenceHelper.getObjectIdentifier(latestPartIteration).getId() + " was changed to com.ptc.KBAssyComp");
        	 }
        	 logWriter.info("Type of WTPart - " + latestPartIteration.getName() + " , numbner : " + latestPartIteration.getNumber()
				+ " , version : " + latestPartIteration.getVersionIdentifier().getValue() + "."
				+ latestPartIteration.getIterationIdentifier().getValue() + " OID "
				+ PersistenceHelper.getObjectIdentifier(latestPartIteration).getId() + " was changed to com.ptc.KBAssyComp");
         }
         else if(partCategory.equals("4"))
         {
        	 if(LOGGER.isDebugEnabled()){
        		 LOGGER.debug("Before changing type of part");
        	 }
        	 logWriter.info("Before changing type of part");
        	changeTypeOfPart(latestPartIteration, "com.ptc.KBStandardPart");
        	if(LOGGER.isDebugEnabled()){
        		LOGGER.debug("Type of WTPart - " + latestPartIteration.getName() + " , numbner : " + latestPartIteration.getNumber()
 					+ " , version : " + latestPartIteration.getVersionIdentifier().getValue() + "."
 					+ latestPartIteration.getIterationIdentifier().getValue() + " OID "
 					+ PersistenceHelper.getObjectIdentifier(latestPartIteration).getId() + " was changed to com.ptc.KBStandardPart");
        	}
        	 logWriter.info("Type of WTPart - " + latestPartIteration.getName() + " , numbner : " + latestPartIteration.getNumber()
				+ " , version : " + latestPartIteration.getVersionIdentifier().getValue() + "."
				+ latestPartIteration.getIterationIdentifier().getValue() + " OID "
				+ PersistenceHelper.getObjectIdentifier(latestPartIteration).getId() + " was changed to com.ptc.KBStandardPart");
         }
         else if(partCategory.equals("5"))
         {
        	 changeTypeOfPart(latestPartIteration, "com.ptc.KBRaw");
        	 if(LOGGER.isDebugEnabled()){
        		 LOGGER.debug("Type of WTPart - " + latestPartIteration.getName() + " , numbner : " + latestPartIteration.getNumber()
  					+ " , version : " + latestPartIteration.getVersionIdentifier().getValue() + "."
  					+ latestPartIteration.getIterationIdentifier().getValue() + " OID "
  					+ PersistenceHelper.getObjectIdentifier(latestPartIteration).getId() + " was changed to com.ptc.KBRaw");
        	 }
        	 logWriter.info("Type of WTPart - " + latestPartIteration.getName() + " , numbner : " + latestPartIteration.getNumber()
				+ " , version : " + latestPartIteration.getVersionIdentifier().getValue() + "."
				+ latestPartIteration.getIterationIdentifier().getValue() + " OID "
				+ PersistenceHelper.getObjectIdentifier(latestPartIteration).getId() + " was changed to com.ptc.KBRaw");
         }
         else if(partCategory.equals("9"))
         {
        	 if(partIsFromKBOrg)
        	 {
        		 changeTypeOfPart(latestPartIteration, "com.ptc.KBAssemblyComponent");
        	 }else
        	 {
        		changeTypeOfPart(latestPartIteration, "com.ptc.KBCommercial");
        	 }
        	 if(LOGGER.isDebugEnabled()){
        		 LOGGER.debug("Type of WTPart - " + latestPartIteration.getName() + " , numbner : " + latestPartIteration.getNumber()
  					+ " , version : " + latestPartIteration.getVersionIdentifier().getValue() + "."
  					+ latestPartIteration.getIterationIdentifier().getValue() + " OID "
  					+ PersistenceHelper.getObjectIdentifier(latestPartIteration).getId() + " was changed to com.ptc.KBCommercial");
        	 }
        	 logWriter.info("Type of WTPart - " + latestPartIteration.getName() + " , numbner : " + latestPartIteration.getNumber()
				+ " , version : " + latestPartIteration.getVersionIdentifier().getValue() + "."
				+ latestPartIteration.getIterationIdentifier().getValue() + " OID "
				+ PersistenceHelper.getObjectIdentifier(latestPartIteration).getId() + " was changed to com.ptc.KBCommercial");
         }
         else if(partCategory.equals("10"))
         {
        	 changeTypeOfPart(latestPartIteration, "com.ptc.KBKitBOM");
        	 if(LOGGER.isDebugEnabled()){
        		 LOGGER.debug("Type of WTPart - " + latestPartIteration.getName() + " , numbner : " + latestPartIteration.getNumber()
  					+ " , version : " + latestPartIteration.getVersionIdentifier().getValue() + "."
  					+ latestPartIteration.getIterationIdentifier().getValue() + " OID "
  					+ PersistenceHelper.getObjectIdentifier(latestPartIteration).getId() + " was changed to com.ptc.KBKitBOM");
        	 }
        	 logWriter.info("Type of WTPart - " + latestPartIteration.getName() + " , numbner : " + latestPartIteration.getNumber()
				+ " , version : " + latestPartIteration.getVersionIdentifier().getValue() + "."
				+ latestPartIteration.getIterationIdentifier().getValue() + " OID "
				+ PersistenceHelper.getObjectIdentifier(latestPartIteration).getId() + " was changed to com.ptc.KBKitBOM");
         }
         else if(partCategory.equals("6"))
         {
        	 changeTypeOfPart(latestPartIteration, "com.ptc.KBSemiFinished");
        	 if(LOGGER.isDebugEnabled()){
        		 LOGGER.debug("Type of WTPart - " + latestPartIteration.getName() + " , numbner : " + latestPartIteration.getNumber()
  					+ " , version : " + latestPartIteration.getVersionIdentifier().getValue() + "."
  					+ latestPartIteration.getIterationIdentifier().getValue() + " OID "
  					+ PersistenceHelper.getObjectIdentifier(latestPartIteration).getId() + " was changed to com.ptc.KBSemiFinished");
        	 }
        	 logWriter.info("Type of WTPart - " + latestPartIteration.getName() + " , numbner : " + latestPartIteration.getNumber()
				+ " , version : " + latestPartIteration.getVersionIdentifier().getValue() + "."
				+ latestPartIteration.getIterationIdentifier().getValue() + " OID "
				+ PersistenceHelper.getObjectIdentifier(latestPartIteration).getId() + " com.ptc.KBSemiFinished");
         }
         else if(partCategory.equals("7"))
         {
        	 changeTypeOfPart(latestPartIteration, "com.ptc.KBAuxMaterial");
        	 if(LOGGER.isDebugEnabled()){
        		 LOGGER.debug("Type of WTPart - " + latestPartIteration.getName() + " , numbner : " + latestPartIteration.getNumber()
  					+ " , version : " + latestPartIteration.getVersionIdentifier().getValue() + "."
  					+ latestPartIteration.getIterationIdentifier().getValue() + " OID "
  					+ PersistenceHelper.getObjectIdentifier(latestPartIteration).getId() + " was changed to com.ptc.KBAuxMaterial");
        	 }
        	 logWriter.info("Type of WTPart - " + latestPartIteration.getName() + " , numbner : " + latestPartIteration.getNumber()
				+ " , version : " + latestPartIteration.getVersionIdentifier().getValue() + "."
				+ latestPartIteration.getIterationIdentifier().getValue() + " OID "
				+ PersistenceHelper.getObjectIdentifier(latestPartIteration).getId() + " was changed to com.ptc.KBAuxMaterial");
         }
         else if(partCategory.equals("8"))
         {
        	 if(partIsFromKBOrg) {
        		 changeTypeOfPart(latestPartIteration, "com.ptc.KBToolsFixtures");
            	 if(LOGGER.isDebugEnabled()){
            		 LOGGER.debug("Type of WTPart - " + latestPartIteration.getName() + " , number : " + latestPartIteration.getNumber()
      					+ " , version : " + latestPartIteration.getVersionIdentifier().getValue() + "."
      					+ latestPartIteration.getIterationIdentifier().getValue() + " OID "
      					+ PersistenceHelper.getObjectIdentifier(latestPartIteration).getId() + " was changed to com.ptc.KBToolsFixtures");
            	 }
            	 logWriter.info("Type of WTPart - " + latestPartIteration.getName() + " , number : " + latestPartIteration.getNumber()
    				+ " , version : " + latestPartIteration.getVersionIdentifier().getValue() + "."
    				+ latestPartIteration.getIterationIdentifier().getValue() + " OID "
    				+ PersistenceHelper.getObjectIdentifier(latestPartIteration).getId() + " was changed to com.ptc.KBToolsFixtures");
        	 }
        	 else {
        		 changeTypeOfPart(latestPartIteration, "com.ptc.KBTool");
            	 if(LOGGER.isDebugEnabled()){
            		 LOGGER.debug("Type of WTPart - " + latestPartIteration.getName() + " , number : " + latestPartIteration.getNumber()
      					+ " , version : " + latestPartIteration.getVersionIdentifier().getValue() + "."
      					+ latestPartIteration.getIterationIdentifier().getValue() + " OID "
      					+ PersistenceHelper.getObjectIdentifier(latestPartIteration).getId() + " was changed to com.ptc.KBTool");
            	 }
            	 logWriter.info("Type of WTPart - " + latestPartIteration.getName() + " , number : " + latestPartIteration.getNumber()
    				+ " , version : " + latestPartIteration.getVersionIdentifier().getValue() + "."
    				+ latestPartIteration.getIterationIdentifier().getValue() + " OID "
    				+ PersistenceHelper.getObjectIdentifier(latestPartIteration).getId() + " was changed to com.ptc.KBTool");
        	 }
        	
         }
	}
	
	public static WTPart changeTypeOfPart(WTPart part, String newTypeName){
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("entering changeTypeOfPart(WTPart,String)");
			LOGGER.debug("part: " + part);
			LOGGER.debug("newTypeName: \"" + newTypeName + "\"");
		}
		TypeIdentifier typeIdentifier = TypeIdentifierHelper.getTypeIdentifier(newTypeName);
		TypeDefinitionReference tdr;
		try {
			tdr = TypedUtilityServiceHelper.service.getTypeDefinitionReference(typeIdentifier.getTypename());
			part.setTypeDefinitionReference(tdr);
			PersistenceServerHelper.manager.update(part);
			part = (WTPart) PersistenceHelper.manager.refresh(part);
			LOGGER.debug("Type of WTPart - " + part.getName() + " , numbner : " + part.getNumber()
					+ " , version : " + part.getVersionIdentifier().getValue() + "."
					+ part.getIterationIdentifier().getValue() + " OID "
					+ PersistenceHelper.getObjectIdentifier(part).getId() + " was changed to " + newTypeName);
			logWriter.info("Type of WTPart - " + part.getName() + " , numbner : " + part.getNumber()
					+ " , version : " + part.getVersionIdentifier().getValue() + "."
					+ part.getIterationIdentifier().getValue() + " OID "
					+ PersistenceHelper.getObjectIdentifier(part).getId() + " was changed to " + newTypeName);

		} catch (RemoteException | WTException exc) {
			exc.printStackTrace();
		} catch (WTPropertyVetoException exc) {
			exc.printStackTrace();
		}
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("exiting changeTypeOfPart()");
			LOGGER.debug("returning: " + part);
		}
		return part;
	}

}
