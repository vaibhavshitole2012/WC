package com.sf.sapchill.ws.client;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

import com.ptc.jws.client.handler.Credentials;

import com.sf.sapchill.ws.SAPChillService;
import com.sf.sapchill.ws.SAPChillServiceService;
// import the classes generated when compiling your client

public class SAPChillServiceClient {
    private static final String NL = System.getProperty("line.separator");

    public static void main(String[] args) throws java.lang.Exception {
        String mode = null;
        String url = null;
        String user = null;
        String password = null;
        String organization = null;
        String number = null;
        String xmlFilePath = null;
        String response = null;


        if (args.length < 4) {
            System.out.println(
                "Usage:SAPChillServiceClient mode url user password organization number/xmlFilePath"
                    + NL
                    + "where mode is either"
                    + NL
                    + "readWTPart, readWTDocument, readWTPartBom, createOrUpdateWTDocument, updateWTPartWithoutIterating, updateWTDocumentWithoutIterating, createOrUpdateWTPartBOM, readVersionInfo");
            return;
        }

        /*  ok, now we can authenticate */
        mode = args[0];
        url = args[1];
        user = args[2];
        password = args[3];

        SAPChillService port = authenticate(url, user, password);

        // either mode is readVersionInfo
        if ("readVersionInfo".equalsIgnoreCase(mode)) {
            String versionInfoClient = readVersionInfoInManifest();
            String versionInfoServer = port.getSoftwareVersionInfo();

            response = versionInfoClient + NL + versionInfoServer;
        }
        else if (args.length != 6) {
            System.out.println(
                "Usage:SAPChillServiceClient mode url user password organization number/xmlFilePath"
                    + NL
                    + "where mode is either"
                    + NL
                    + "readWTPart, readWTDocument, readWTPartBom, createOrUpdateWTDocument, updateWTPartWithoutIterating, updateWTDocumentWithoutIterating, createOrUpdateWTPartBOM, readVersionInfo");
            return;
        }
        else {

            organization = args[4];

            if ("readWTPart".equalsIgnoreCase(mode)) {
                number = args[5];
                response = port.readWTPart(user, organization, number);
            }
            else if ("readWTDocument".equalsIgnoreCase(mode)) {
                number = args[5];
                response = port.readWTDocument(user, organization, number);
            }
            else if ("readWTPartDocuments".equalsIgnoreCase(mode)) {
                number = args[5];
                response = port.readWTPartDocuments(user, organization, number);
            }
            else if ("readWTPartBom".equalsIgnoreCase(mode)) {
                number = args[5];
                response = port.readWTPartBom(user, organization, number);
            }
            else if ("createOrUpdateWTDocument".equalsIgnoreCase(mode)) {
                xmlFilePath = args[5];
                String xml = readFile(xmlFilePath, StandardCharsets.UTF_8);
                response = port.createOrUpdateWTDocument(user, organization, xml);
            }
            else if ("updateWTPartWithoutIterating".equalsIgnoreCase(mode)) {
                xmlFilePath = args[5];
                String xml = readFile(xmlFilePath, StandardCharsets.UTF_8);
                response = port.updateWTPartWithoutIterating(user, organization, xml);
            }
            else if ("updateWTDocumentWithoutIterating".equalsIgnoreCase(mode)) {
                xmlFilePath = args[5];
                String xml = readFile(xmlFilePath, StandardCharsets.UTF_8);
                response = port.updateWTDocumentWithoutIterating(user, organization, xml);
            }
            else if ("createOrUpdateWTPartBOM".equalsIgnoreCase(mode)) {
                xmlFilePath = args[5];
                String xml = readFile(xmlFilePath, StandardCharsets.UTF_8);
                response = port.createOrUpdateWTPartBOM(user, organization, xml);
            }
            else {
                response = "Please use one of the following options: "
                    + "readWTPart, readWTDocument, readWTPartBom, createOrUpdateWTDocument, updateWTPartWithoutIterating, updateWTDocumentWithoutIterating, createOrUpdateWTPartBOM, readVersionInfo";
            }

        }

        System.out.println(response);
    }

    public static SAPChillService authenticate(String url, String user, String password)
            throws MalformedURLException {
        Credentials.setUsername(user);
        Credentials.setPassword(password);
        URL wsdlLocation = new URL(url);
        SAPChillServiceService service = new SAPChillServiceService(wsdlLocation);
        return service.getSAPChillServicePort();
    }

    public static String readVersionInfoInManifest() {

        // build an object whose class is in the target jar
        SAPChillServiceClient object = new SAPChillServiceClient();

        // navigate from its class object to a package object
        Package objPackage = object.getClass().getPackage();

        String version = objPackage.getImplementationVersion();
        String title = objPackage.getImplementationTitle();
        String vendor = objPackage.getImplementationVendor();
        return "Title: " + title + ", Version: " + version + ", Vendor: " + vendor;
    }

    private static String readFile(String path, Charset encoding) throws IOException {
        byte[] encoded = Files.readAllBytes(Paths.get(path));
        return new String(encoded, encoding);
    }
}
