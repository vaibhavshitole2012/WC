package com.sf.sapchill.ws;

import java.io.StringWriter;
import java.util.Locale;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import com.ptc.jws.servlet.JaxWsWebService;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import wt.log4j.LogR;
import wt.org.WTPrincipal;
import wt.session.SessionHelper;
import wt.util.WTContext;
import wt.util.WTException;

import com.sf.imapeb.model.WTDocumentMetaData;
import com.sf.imapeb.model.WTPartBom;
import com.sf.imapeb.model.WTPartMetaData;
import com.sf.imapeb.utilities.VersionInfo;
import com.sf.imapeb.wt.ReadWTPartLinkedDocuments;
import com.sf.imapeb.wt.WTDocumentCreateOrUpdate;
import com.sf.imapeb.wt.WTDocumentReader;
import com.sf.imapeb.wt.WTDocumentUpdator;
import com.sf.imapeb.wt.WTPartBOMCreatorOrUpdator;
import com.sf.imapeb.wt.WTPartBomReader;
import com.sf.imapeb.wt.WTPartReader;
import com.sf.imapeb.wt.WTPartUpdator;

/**
 * Windchill web service
 * <ol>
 * <li>create or update WTPart BOM</li>
 * <li>read WTPart</li>
 * </ol>
 * Created on 28.01.2016.
 *
 * @author wang
 * @version $Revision: 1.1 $ $Date: 2020/11/30 10:47:28IST $ $Author: Birajdar, Snehal (birajdsn) $
 */
@WebService()
public class SAPChillService extends JaxWsWebService {
    private static Logger log = LogR.getLogger(SAPChillService.class.getName());
    private static final String NL = System.getProperty("line.separator");
    private static String AUTHENTICATED = "AUTHENTICATED";
    private static String SAPCHILL_VERSION = "Title: SAPChillService, Version: 1.7.7, Vendor: Software Factory GmbH";
    
    /**
     * Web method readWTDocument.
     *
     * @param number
     * @param filePath
     * @param user
     * @return
     * @throws WTException
     */
    @WebMethod(operationName = "readWTDocument")
    public String readWTDocument(@WebParam(name = "user") String user,
            @WebParam(name = "organisation") String organisation,
            @WebParam(name = "number") String number) {
    
        final String methodName = "readWTDocument";
    
        final String authentication = startAndAuthenticate(methodName, organisation, user, number);
        if (!authentication.contentEquals(AUTHENTICATED)) {
            return authentication;
        }
    
        WTDocumentReader reader = new WTDocumentReader(number, organisation);
        WTDocumentMetaData wtDocumentMetaData = reader.read();
    
        String xmlAsString = createXMLAsString(methodName, WTDocumentMetaData.class,
            wtDocumentMetaData);

        log.info("Web service method " + methodName + " returns" + NL + xmlAsString);
        return xmlAsString;
    }

    /**
     * Web method readWTPart. Read the attributes value for a WTPart. The return value is
     * data for a WTPart in XML structure as string.
     *
     * @param number
     * @param organisation
     * @param user
     * @return
     * @throws WTException
     */
    @WebMethod(operationName = "readWTPart")
    public String readWTPart(@WebParam(name = "user") String user,
            @WebParam(name = "organisation") String organisation,
            @WebParam(name = "number") String number) {

        final String methodName = "readWTPart";

        final String authentication = startAndAuthenticate(methodName, organisation, user, number);
        if (!authentication.contentEquals(AUTHENTICATED)) {
            return authentication;
        }

        WTPartReader reader = new WTPartReader(number, organisation);
        WTPartMetaData wtPartMetaData = reader.read();

        String xmlAsString = createXMLAsString(methodName, WTPartMetaData.class, wtPartMetaData);

        log.info("Web service method " + methodName + " returns" + NL + xmlAsString);
        return xmlAsString;
    }

    /**
     * Web method readWTPartBom. Read the single level BOM for a WTPart.
     *
     * @param number
     * @param organisation
     * @param user
     * @return bom as XML string
     */
    @WebMethod(operationName = "readWTPartBom")
    public String readWTPartBom(@WebParam(name = "user") String user,
            @WebParam(name = "organisation") String organisation,
            @WebParam(name = "number") String number) {

        final String methodName = "readWTPartBom";

        final String authentication = startAndAuthenticate(methodName, organisation, user, number);
        if (!authentication.contentEquals(AUTHENTICATED)) {
            return authentication;
        }

        WTPartBomReader reader = new WTPartBomReader(number, organisation);
        WTPartBom wtPartBom = reader.read();

        String xmlAsString = createXMLAsString(methodName, WTPartBom.class, wtPartBom);

        log.info("Web service method " + methodName + " returns" + NL + xmlAsString);
        return xmlAsString;
    }

    /**
     * Web method readWTPartDocuments. Receive related WT-Documents for a WT-Part incl.
     * link types
     *
     * @param number
     * @param organisation
     * @param user
     * @return
     */
    @WebMethod(operationName = "readWTPartDocuments")
    public String readWTPartDocuments(@WebParam(name = "user") String user,
            @WebParam(name = "organisation") String organisation,
            @WebParam(name = "number") String number) {

        final String methodName = "readWTPartDocuments";

        final String authentication = startAndAuthenticate(methodName, organisation, user, number);
        if (!authentication.contentEquals(AUTHENTICATED)) {
            return authentication;
        }

        JSONArray jsonArray = null;
        ReadWTPartLinkedDocuments reader = new ReadWTPartLinkedDocuments(number, organisation);
        jsonArray = reader.read();

        final String jsonString = jsonArray.toJSONString();

        log.info("Web service method " + methodName + " returns:" + NL + jsonString);
        return jsonString;
    }


    /**
     * Web method for createOrUpdateWTDocument.
     *
     * @param user
     * @param organisation
     * @param partBom (XML structure as string)
     * @return
     */
    @WebMethod(operationName = "createOrUpdateWTDocument")
    public String createOrUpdateWTDocument(@WebParam(name = "user") String user,
            @WebParam(name = "organisation") String organisation,
            @WebParam(name = "xml") String xml) {

        final String methodName = "createOrUpdateWTDocument";

        final String authentication = startAndAuthenticate(methodName, organisation, user, xml);
        if (!authentication.contentEquals(AUTHENTICATED)) {
            return authentication;
        }

        final WTDocumentCreateOrUpdate wtDocumentCreateOrUpdate = new WTDocumentCreateOrUpdate(
                organisation, xml);
        final boolean result = wtDocumentCreateOrUpdate.createOrUpdate();
        final String message = wtDocumentCreateOrUpdate.getMessage();

        return createJsonMessage(methodName, result, message);
    }

    /**
     * Web method createOrUpdateWTPartBOM. Create (resp. replace) the single level BOM for
     * a WTPart (WTPartUsageLinks)
     *
     * @param user
     * @param organisation
     * @param bomXml (XML structure as string)
     * @return
     */
    @WebMethod(operationName = "createOrUpdateWTPartBOM")
    public String createOrUpdateWTPartBOM(@WebParam(name = "user") String user,
            @WebParam(name = "organisation") String organisation,
            @WebParam(name = "bomXml") String bomXml) {

        final String methodName = "createOrUpdateWTPartBOM";

        final String authentication = startAndAuthenticate(methodName, organisation, user, bomXml);
        if (!authentication.contentEquals(AUTHENTICATED)) {
            return authentication;
        }

        final WTPartBOMCreatorOrUpdator wtPartBOMCreatorOrUpdator = new WTPartBOMCreatorOrUpdator(
                null, organisation, bomXml);
        final boolean result = wtPartBOMCreatorOrUpdator.createOrUpdate();
        final String message = wtPartBOMCreatorOrUpdator.getMessage();

        return createJsonMessage(methodName, result, message);
    }

    /*
     * Web method updateWTDocumentWithoutIterating. 
     * Update attributes of a WT-Document and add or replace primary content without iterating the document.
     *    
     * @param user
     * @param organisation
     * @param xml (XML contains master attributes to change)
     * @return
     */
    @WebMethod(operationName = "updateWTDocumentWithoutIterating")
    public String updateWTDocumentWithoutIterating(@WebParam(name = "user") String user,
            @WebParam(name = "organisation") String organisation,
            @WebParam(name = "xml") String xml) {
    
        final String methodName = "updateWTDocumentWithoutIterating";
    
        final String authentication = startAndAuthenticate(methodName, organisation, user, xml);
        if (!authentication.contentEquals(AUTHENTICATED)) {
            return authentication;
        }
    
        final WTDocumentUpdator wtDocumentUpdator = new WTDocumentUpdator(null, organisation,xml);
        final boolean result = wtDocumentUpdator.update();
        final String message = wtDocumentUpdator.getMessage();
    
        return createJsonMessage(methodName, result, message);
    }

    /*
     * Web method updateWTPartWithoutIterating. Update attributes of a WT-Part.
     * Mainly used for custom master attributes but can update also versioned IBAs.   
     * 
     * @param user
     * @param organisation
     * @param xml (XML contains master attributes to change)
     * @return
     */
    @WebMethod(operationName = "updateWTPartWithoutIterating")
    public String updateWTPartWithoutIterating(@WebParam(name = "user") String user,
            @WebParam(name = "organisation") String organisation,
            @WebParam(name = "xml") String xml) {

        final String methodName = "updateWTPartWithoutIterating"; 

        final String authentication = startAndAuthenticate(methodName, organisation, user, xml);
        if (!authentication.contentEquals(AUTHENTICATED)) {
            return authentication;
        }
        
        final WTPartUpdator wtPartUpdator = new WTPartUpdator(null, organisation,xml);
        final boolean result = wtPartUpdator.update();
        final String message = wtPartUpdator.getMessage();
        
        return createJsonMessage(methodName, result, message);
    }

    @WebMethod(operationName = "getSoftwareVersionInfo")
    public String getSoftwareVersionInfo() {
        final String methodName = "getSoftwareVersionInfo";

        String versionInfoImapEB = VersionInfo.readVersionInfoInManifest();

        String versionInfoServer = SAPCHILL_VERSION + NL + versionInfoImapEB;

        log.info("Web service method " + methodName + " returns" + NL + versionInfoServer);
        return versionInfoServer;
    }
    
    /**
     * Authenticates to method server with a given user name. It is not for remote access
     * to Windchill.
     *
     * @param username a Windchill user name
     * @throws WTException
     */
    private static boolean authenticate(String username) {
        log.debug("Authenticating with " + username);
    
        WTContext.getContext().setLocale(Locale.UK);
    
        try {
            WTPrincipal newPrincipal = SessionHelper.manager.setPrincipal(username);
            log.trace("newPrincipal:" + newPrincipal);
            WTPrincipal newPrincipal2 = SessionHelper.manager.getPrincipal();
            log.trace("newPrincipal2:" + newPrincipal2);
            return newPrincipal != null;
    
        } catch (WTException e1) {
            log.error(e1);
            return false;
        }
    }

    private static String startAndAuthenticate(final String methodName,
            final String organisation, final String user, final String metadata) {
    
        log.info("Web service method "
            + methodName
            + " called with user="
            + user
            + ", organisation="
            + organisation
            + ", metadata="
            + metadata);
    
        final String jsonMessage;
    
        if (user == null || user.isEmpty()) {
            final String message = "User name is null or empty.";
            jsonMessage = "{\"success\":false,\"msg\":\"" + message + "\"}";
        }
        else if (!authenticate(user)) {
            final String message = "Windchill authentication failed with user " + user;
            log.error(message);
            jsonMessage = "{\"success\":false,\"msg\":\"" + message + "\"}";
        }
        else {
            jsonMessage = AUTHENTICATED;
        }
        return jsonMessage;
    }

    private static String createJsonMessage(String methodName, boolean result, String message) {
    
        try {
            final JSONObject jsonData = new JSONObject();
            final String jsonAsString;
    
            jsonData.put("success", result);
            jsonData.put("msg", message);
    
            jsonAsString = jsonData.toJSONString();
            log.info("JSON result: " + jsonAsString);
            return jsonAsString;
    
        } catch (JSONException e1) {
            message = methodName + " failed for unknown reason when creating json message!";
            final String jsonMessage = "{\"success\":false,\"msg\":\"" + message + "\"}";
            return jsonMessage;
        }
    }

    private static String createXMLAsString(String methodName, Class<?> clazz, Object obj) {

        String xmlAsString;
        final StringWriter stringWriter = new StringWriter();

        JAXBContext jaxbContext;
        try {
            jaxbContext = JAXBContext.newInstance(clazz);
            Marshaller marshaller = jaxbContext.createMarshaller();
            marshaller.marshal(obj, stringWriter);
            xmlAsString = stringWriter.toString();

            log.trace("xmlAsString: " + xmlAsString);

            xmlAsString = xmlAsString.replaceAll("\\<\\?xml(.+?)\\?\\>", "").trim();
            xmlAsString = "<?xml version=\"1.0\" encoding=\"utf-8\"?>" + xmlAsString;
            xmlAsString = xmlAsString.replaceFirst("xmlnsxsi", "xmlns:xsi");
        } catch (JAXBException e) {
            log.error(methodName + ": failed for unknown reason when creating resulting XML");
            xmlAsString = "";
        }

        return xmlAsString;
    }
}
