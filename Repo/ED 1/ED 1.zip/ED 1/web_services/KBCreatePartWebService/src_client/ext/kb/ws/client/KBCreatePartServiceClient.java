package ext.kb.ws.client;

import java.util.HashMap;
import java.util.Map;




// import the classes generated when compiling your client
import com.ptc.jws.client.handler.*;

import ext.kb.ws.KBCreatePartService;
import ext.kb.ws.KBCreatePartServiceService;
import ext.kb.ws.KBCreatePartServiceServiceFactory;

public class KBCreatePartServiceClient
{
    public static void main ( String [] args ) throws java.lang.Exception
    {
        // depending on your security requirements you may need to specify credentials up
        // front, or on the command-line where most policies will prompt for them
        Credentials.setUsername ( args[0] );
        Credentials.setPassword ( args[1] );
        // TODO implement your client
        
        KBCreatePartServiceService service = new KBCreatePartServiceService();
        KBCreatePartService port =  service.getKBCreatePartServicePort ();
        HashMap<String,String> arguments = new HashMap<String,String>();
        String wtContainerPath = "/wt.inf.container.OrgContainer=HVAC/wt.pdmlink.PDMLinkProduct=MAD-AC-D01";
        String folderPath = "/Default/20 Public Space";
        String type = "com.ptc.KBAssyComp";
        String name = "TestPart";
        String number = "123456";
        arguments.put("KB_CADIM_CID","100000");
        arguments.put("KB_GEKLA","680A");
        arguments.put("KB_DESCRIPTION_EN","testing 123");
        arguments.put("KB_DESCRIPTION_NATIVE","testing 456");
        //invoke an action
        String createdPartNumber = port.createPart(name,number,wtContainerPath,folderPath,type,arguments);
        System.out.println("createdPartNumber==="+createdPartNumber);
        
    }
}