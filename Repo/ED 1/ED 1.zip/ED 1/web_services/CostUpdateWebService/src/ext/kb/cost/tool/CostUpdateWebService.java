package ext.kb.cost.tool;

import javax.jws.Oneway;
import javax.jws.WebMethod;
import javax.jws.WebService;

import com.ptc.jws.servlet.JaxWsWebService;

@WebService()
public class CostUpdateWebService extends JaxWsWebService
{
    @WebMethod(operationName="updateCost")
    @Oneway
    public void updateCost (String inputFile, String logDir)
    {
        try {
            MaterialCostUpdateTool.updateProcurementParts(inputFile, logDir);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}