package ext.kb.ws;

import java.io.IOException;
import java.rmi.RemoteException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.xml.bind.JAXBException;

import org.apache.log4j.Logger;

import wt.change2.Category;
import wt.change2.ChangeHelper2;
import wt.change2.ChangeRequest2;
import wt.change2.Changeable2;
import wt.change2.RelevantRequestData2;
import wt.change2.WTChangeRequest2;
import wt.change2.WTChangeRequest2Master;
import wt.doc.WTDocument;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.iba.value.IBAHolder;
import wt.inf.container.WTContainer;
import wt.lifecycle.LifeCycleState;
import wt.lifecycle.State;
import wt.log4j.LogR;
import wt.org.WTOrganization;
import wt.part.WTPart;
import wt.pdmlink.PDMLinkProduct;
import wt.pds.StatementSpec;
import wt.pom.Transaction;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.type.TypedUtilityServiceHelper;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.vc.Mastered;
import wt.vc.VersionControlHelper;

import com.ptc.jws.servlet.JaxWsWebService;

import ext.kb.service.WebServiceHelper;
import ext.kb.util.IBAHelper;
import ext.kb.util.KBTypeIdProvider;

@WebService()
public class KBCreateECRService extends JaxWsWebService {
	private static final Logger LOGGER = LogR
			.getLogger(KBCreateECRService.class.getName());
	private static final Logger logWriter = LogR.getLogger("ext.kb.ws.KBCreateECRService_Log");

	@WebMethod(operationName = "createECR")
	public List<String> createECR(@WebParam(name = "ecrName") String ecrName,
			@WebParam(name = "ecrNumber") String ecrNumber,
			@WebParam(name = "ecrDescription") String ecrDescription,
			@WebParam(name = "ecrContainer") String ecrContainer,
			@WebParam(name = "ecrOrganization") String ecrOrganization) throws WTException,
			WTPropertyVetoException, JAXBException, IOException

			{

		Transaction trx = null;

		List<String> result = new ArrayList<String>();
		try {

			trx = new Transaction();
			trx.start();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
            Date date = new Date();
            String formatedDate = sdf.format(date);
            logWriter.info("Processing Create ECR request on "+formatedDate+" for object where number is "+ecrNumber+" and name is "+ecrName+" description is = "+ecrDescription+" Organization is "+ecrOrganization+" container is "+ecrContainer);

            
			List<Changeable2> affected = new ArrayList<Changeable2>();
						
			WTChangeRequest2 ecr = WTChangeRequest2.newWTChangeRequest2();
			ecr.setTypeDefinitionReference(TypedUtilityServiceHelper.service
					.getTypeDefinitionReference(KBTypeIdProvider.getType("ECR").getLeafName()));
			ecr.setName(ecrName);
			ecr.setNumber(ecrNumber);
			ecr.setDescription(ecrDescription);
			WTContainer cont = getContainerProduct(ecrContainer);
			ecr.setContainer(cont);
			WTOrganization org = getOrganization(ecrOrganization);
			ecr.setOrganization(org);
			ecr.setCategory(Category.toCategory("UNDEFINED"));
			//LifeCycleState lc = LifeCycleState.newLifeCycleState();
			//lc.setState(State.toState("IMPLEMENTATION"));
			//ecr.setState(lc);
			QuerySpec qsECR = new QuerySpec(WTChangeRequest2.class);
			LOGGER.debug("ecrNumber" + ecrNumber);
			qsECR.appendWhere(new SearchCondition(WTChangeRequest2.class, WTPart.NUMBER, SearchCondition.EQUAL, ecrNumber, false));
			QueryResult qrECR = PersistenceHelper.manager.find((StatementSpec) qsECR);
			LOGGER.debug("qrchild.size(): " + qrECR.size());
			if(qrECR.size()>0)
			{
				WTChangeRequest2 existingECR =  (WTChangeRequest2)qrECR.nextElement();
				//existingECR.setName(ecrName);
				//existingECR.setNumber(ecrNumber);
				WTChangeRequest2Master existingECRMaster  = (WTChangeRequest2Master) ChangeHelper2.service.changeChangeItemMasterIdentity((Mastered) existingECR.getMasterReference().getObject(), ecrName, ecrNumber, org);
				existingECR.setDescription(ecrDescription);
				LOGGER.debug("ECR existis going to update description ");
				logWriter.info("ECR existis going to update description ");
				//existingECR = (WTChangeRequest2) PersistenceHelper.manager.refresh(existingECR);
				PersistenceServerHelper.manager.update(existingECR);
				LOGGER.debug("After ECR update description ");
				logWriter.info("ECR existis going to update description ");
			}
			else
			{
			
				LOGGER.debug("ECR does not exist going to save ECR");
				logWriter.info("ECR does not exist going to save ECR");
				ecr = (WTChangeRequest2) ChangeHelper2.service.saveChangeRequest(ecr);
				LOGGER.debug("After saving ECR");
				logWriter.info("After saving ECR");
			}
			
			IBAHelper.setIba((IBAHolder) ecr, "KB_REQUIRED_CUSTOMER_SPEC", Boolean.FALSE);
			IBAHelper.setIba((IBAHolder) ecr, "KB_REQUIRED_KB_SPEC", Boolean.FALSE);
			IBAHelper.setIba((IBAHolder) ecr, "KB_RELIABILITY", Boolean.FALSE);
			IBAHelper.setIba((IBAHolder) ecr, "KB_MASTERSYSTEM", "CDM");
			LOGGER.debug("After saving ECR Attributes");
			logWriter.info("After saving ECR Attributes");

			/*for(int i=0;i<affectedObjects.length;i++)
			{
			if (affectedObjects[i][0].equalsIgnoreCase("WTPart")) {

				QuerySpec partQS = WebServiceHelper.findPartByNumberAndCadim(affectedObjects[i][1], affectedObjects[i][2]);
				QueryResult partQR = PersistenceHelper.manager
						.find((StatementSpec) partQS);
				if(partQR.size()>0)
				{
				Persistable resObj[] = (Persistable[]) partQR.nextElement();
				LOGGER.debug("resObj: " + resObj[0]);
				WTPart resPart = (WTPart) resObj[0];
				LOGGER.debug("resPart ===" + resPart);
				WTPart latestPartIteration = (WTPart) VersionControlHelper
						.getLatestIteration(resPart);
				LOGGER.debug("part ===" + latestPartIteration);
				affected.add(latestPartIteration);

				}
				else{
					throw new WTException("Part with number "+affectedObjects[i][1]+" and CID "+affectedObjects[i][2]+" not found");
				}
			}

			if (affectedObjects[i][0].equalsIgnoreCase("WTDocument")) {
				QuerySpec docQS = WebServiceHelper.findDocumentByNumberAndCadim(affectedObjects[i][1], affectedObjects[i][2]);
				QueryResult docQR = PersistenceHelper.manager
						.find((StatementSpec) docQS);
				if(docQR.size()>0)
				{
				Persistable resObj[] = (Persistable[]) docQR.nextElement();
				LOGGER.debug("resObj: " + resObj[0]);
				WTDocument resDoc = (WTDocument) resObj[0];
				LOGGER.debug("resDoc ===" + resDoc);
				WTDocument latestDocIteration = (WTDocument) VersionControlHelper
						.getLatestIteration(resDoc);
				LOGGER.debug("doc ===" + latestDocIteration);
				affected.add(latestDocIteration);

				}
				else{
					throw new WTException("Document with number "+affectedObjects[i][1]+" and CID "+affectedObjects[i][2]+" not found");
				}
			}
			}
			Iterator <Changeable2> it = affected.iterator();
			while (it.hasNext()) {
				Changeable2 obj = it.next();
				RelevantRequestData2 affData = RelevantRequestData2.newRelevantRequestData2(obj, ecr);
				PersistenceHelper.manager.save(affData);
				LOGGER.debug("After Saving AffectedActivityData");
			}*/
			
			LOGGER.debug("trx===" + trx);
			trx.commit();
			trx = null;
			result.add("ReturnCode: 0");
            result.add("Text: Success");
            logWriter.info("result from the service is "+result);
			return result;
		} catch (WTException e) {
			String message = "WTException during set ECT creation exception is " + e;
			result.add("ReturnCode: 1");
            result.add("Text: "+message);
            logWriter.info("result from the service is "+result);
			return result;

		} catch (WTPropertyVetoException e) {
			String message = "WTPropertyVetoException during ECT creation^1 exception is " + e;
			result.add("ReturnCode: 1");
            result.add("Text: "+message);
            logWriter.info("result from the service is "+result);
			return result;
		} finally {
			LOGGER.debug("trx in finally===" + trx);
			if (trx != null) {
				trx.rollback();
			}
		}
	}
	
	private static WTOrganization getOrganization(String epmOrg) {

		WTOrganization org = null;

		try {

			int[] fromIndicies = { 0, -1 };
			QuerySpec querySpec = new QuerySpec(WTOrganization.class);
			querySpec.appendWhere(new SearchCondition(WTOrganization.class,
					WTOrganization.NAME, SearchCondition.EQUAL, epmOrg),
					fromIndicies);
			Enumeration orgEnum = PersistenceHelper.manager
					.find((StatementSpec) querySpec);
			if (orgEnum.hasMoreElements()){
				org = (WTOrganization) orgEnum.nextElement();
			}
		}catch(WTException e){
			e.printStackTrace();
			}
		return org;
	}
	
	private static WTContainer getContainerProduct(String container) {
		WTContainer cont = null;
		try{
			int[] fromIndicies = { 0, -1 };
			QuerySpec querySpec = new QuerySpec(PDMLinkProduct.class);
			querySpec.appendWhere(new SearchCondition(PDMLinkProduct.class,
					PDMLinkProduct.NAME, SearchCondition.EQUAL, container),
					fromIndicies);
			Enumeration contEnum = PersistenceHelper.manager
					.find((StatementSpec) querySpec);
			if (contEnum.hasMoreElements()){
				cont = (WTContainer) contEnum.nextElement();
			}
		}catch(WTException e){
			e.printStackTrace();
		}
		return cont;
	}

}