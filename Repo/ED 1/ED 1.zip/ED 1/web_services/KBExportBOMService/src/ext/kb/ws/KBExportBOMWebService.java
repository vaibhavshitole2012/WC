package ext.kb.ws;

import java.util.ArrayList;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

import com.ptc.jws.servlet.JaxWsWebService;

import ext.kb.bom.BOMHelper;
import ext.kb.bom.OutputBOMDetails;
import ext.kb.bom.ParentPartObject;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;

@WebService()
public class KBExportBOMWebService extends JaxWsWebService {
	
	@WebMethod(operationName="getBOM")
    public ArrayList<OutputBOMDetails> getBOM(@WebParam(name="ParentPartObject") ArrayList<ParentPartObject> parentPartDetails)
    {
    	ArrayList outobj=new ArrayList();
		try {
			outobj = BOMHelper.startProcess(parentPartDetails);
		} catch (WTException | WTPropertyVetoException e) {
			e.printStackTrace();
		}
    	return outobj;
    }

}
