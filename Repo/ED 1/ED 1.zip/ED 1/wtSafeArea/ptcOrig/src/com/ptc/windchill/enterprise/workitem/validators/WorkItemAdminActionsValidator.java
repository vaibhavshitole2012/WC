/* bcwti
 *
 * Copyright (c) 2010 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */
package com.ptc.windchill.enterprise.workitem.validators;

import java.util.Locale;

import org.apache.log4j.Logger;

import wt.fc.Persistable;
import wt.fc.WTReference;
import wt.inf.container.WTContainerHelper;
import wt.inf.container.WTContainerRef;
import wt.log4j.LogR;
import wt.org.WTPrincipalReference;
import wt.util.WTException;
import wt.workflow.engine.WfActivity;
import wt.workflow.work.WfAssignmentState;
import wt.workflow.work.WorkItem;

import com.ptc.core.ui.validation.DefaultUIComponentValidator;
import com.ptc.core.ui.validation.UIValidationCriteria;
import com.ptc.core.ui.validation.UIValidationKey;
import com.ptc.core.ui.validation.UIValidationResult;
import com.ptc.core.ui.validation.UIValidationResultSet;
import com.ptc.core.ui.validation.UIValidationStatus;

/**
 * This class determines if the WorkItems admins actions like 
 * Reassign, Accept, Update deadline actions for a WorkItem type
 * object is applicabe to the current user.
 * @author Sandeep Patil
 */

public class WorkItemAdminActionsValidator extends DefaultUIComponentValidator{
	
	private static final Logger logger;

	static {
		try {
			logger = LogR.getLogger(WorkItemAdminActionsValidator.class.getName());
		} catch (Exception e) {
			throw new ExceptionInInitializerError(e);
		}
	}
	
	public UIValidationResultSet performFullPreValidation (UIValidationKey validationKey,
			UIValidationCriteria validationCriteria, Locale locale) throws WTException {
		
		logger.debug("==>Entering WorkItemReassignValidator.performFullPreValidation() " +
				" validationKey " + validationKey +
				" validationCriteria " + validationCriteria +
				" locale " + locale);

		UIValidationResultSet resultSet = new UIValidationResultSet();
		UIValidationResult result = getValidationResult(validationKey, validationCriteria);
		resultSet.addResult(result);

		return resultSet;
	}
	
	private UIValidationResult getValidationResult(UIValidationKey validationKey, 
			UIValidationCriteria validationCriteria) throws WTException{

		final String actionUpdateDeadline = "updateDeadline";
		final String actionAccept = "accept";
		final String actionUnaccept = "unaccept";
		UIValidationResult result = new UIValidationResult(validationKey, 
				UIValidationStatus.HIDDEN, null); //default is Hidden
		try{
			WTPrincipalReference currPrincipalRef = validationCriteria.getUser();
			WTReference currContextRef = validationCriteria.getContextObject();
			result = new UIValidationResult(validationKey, UIValidationStatus.HIDDEN, currContextRef);

			logger.debug("==>Entering WorkItemReassignValidator.getValidationResult() " +
					" currPrincipalRef " + currPrincipalRef +
					" currContextRef " + currContextRef);

			Persistable currPersistable = currContextRef.getObject();
			if( currPersistable instanceof WorkItem ){
				WorkItem currWorkItem = (WorkItem)currPersistable;
				if( !currWorkItem.isComplete() ){
					//workitem should be incomplete
					if( !isAdmin(currWorkItem, currPrincipalRef) ){
						//if non admin
						if( !actionUpdateDeadline.equals(validationKey.getComponentID())
								&& currPrincipalRef.equals(currWorkItem.getOwnership().getOwner())){
							//Enabled for workitem owners, admin and action is not updateDeadline
							result = new UIValidationResult(validationKey, UIValidationStatus.ENABLED, currContextRef);
						}
					}else{
						//admin should be able to see
						result = new UIValidationResult(validationKey, UIValidationStatus.ENABLED, currContextRef);
					}
					if (actionAccept.equals(validationKey.getComponentID())) {
						WfAssignmentState status = currWorkItem.getStatus();
						if (status.equals(WfAssignmentState.ACCEPTED)) {
							result = new UIValidationResult(validationKey, UIValidationStatus.HIDDEN, currContextRef);
						}
					}
					if (actionUnaccept.equals(validationKey.getComponentID())) {
						WfAssignmentState status = currWorkItem.getStatus();
						if (status.equals(WfAssignmentState.POTENTIAL)) {
							result = new UIValidationResult(validationKey, UIValidationStatus.HIDDEN, currContextRef);
						}
					}
				}
			}
		}catch(WTException wte){
			logger.debug("Problem validating action in " +
					"WorkItemReassignValidator.getValidationResult() " +
					" validationKey = " + validationKey +
					" validationCriteria = " + validationCriteria);
			wte.printStackTrace();
			logger.error(wte);
		}
		
		return result;
	}
	
	private boolean isAdmin(WorkItem currWorkItem, WTPrincipalReference principalRef)
	throws WTException{
		WTContainerRef currContainerRef = getContainerRef(currWorkItem);
		boolean isAdminUser = 
			WTContainerHelper.service.isAdministrator( currContainerRef, principalRef.getPrincipal());
		return isAdminUser;
	}
	
	private WTContainerRef getContainerRef( WorkItem currWorkItem ){
		WfActivity currActivity = (WfActivity)currWorkItem.getSource().getObject();
		WTContainerRef currContainerRef = currActivity.getContainerReference();
		return currContainerRef;
	}

}
