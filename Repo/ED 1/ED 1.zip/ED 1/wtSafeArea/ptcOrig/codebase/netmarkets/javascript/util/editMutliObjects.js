var tableID;
var TABLE_PREFIX = 'table__';
var TABLE_SUFFIX = '_TABLE';
var headerlabels;
var headercount;
var oldComponentSuffix = "___old";
var tableUtil = window.opener.PTC.jca.table.Utils;
var tableObj;
var columnObjs;
var storeValues;
var optValue;
var cachedAllRows;
var allStored = false;

/**
 * 
 * getAllColHeaderValues() function fetches and table header labels and its
 * index at which they are displayed
 */
function getAllColHeaderValues() {
	tableID = tableUtils.getUnformattedTableId(extractParamValue(
			window.location.href, "tableID"));
	tableObj = tableUtil.getTable(tableID);
	columnObjs = tableUtil.getColumns(tableObj);

	var headerLength = columnObjs.length;
	headercount = headerLength;
	headerlabels = new Array(headerLength);

	for (var i = 0; i < headerLength; i++)
		headerlabels[i] = new Array(1);

	for (var header = 0; header < columnObjs.length; header++) {
		headerlabels[header][0] = header;
		headerlabels[header][1] = tableUtil.getHeaderLabel(columnObjs[header]);

	}
	try {
		storeOrignalValues();
	} catch (e) {// catch and log errors
		PTC.log.error(e);
	}
}

/**
 * This function cache the original value of the attributes from the selected
 * rows, so that on cancel original values can be populated.
 */
function storeOrignalValues() {
	var totalrows = tableUtil.getRowData(tableObj);
	var count = 0;
	var obj;

	columnObjs = tableUtil.getColumns(tableObj);
	cachedAllRows = tableObj.getView().getCachedAllRows(null, null);
	var headerLength = columnObjs.length;
	storeValues = new Array(headerLength);

	for (var i = 0; i < totalrows.length; i++) {
		var selectionModel = tableObj.getSelectionModel();
		var sel = selectionModel.isSelected(i);
		if (sel) {
			if (!tableObj.getView().isRowRendered(i, cachedAllRows)) {
				tableObj.getView().focusRow(i, true);
			}
			storeValues[i] = new Array();
			for (var j = 0; j < headerLength; j++) {
				var htmlComponent = tableObj.getView().getCell(i, j);

				/* Combo Box */
				var selectTags = htmlComponent.getElementsByTagName("select");
				if (selectTags.length > 0) {
					var selectTag = selectTags.item(0);
					var selectTagName = selectTag.name;
					storeValues[i][j] = selectTag.selectedIndex;
				}
				/* Textarea */
				var textAreaTags = htmlComponent
						.getElementsByTagName('textarea');
				if (textAreaTags.length == 1) {
					var textAreaTag = textAreaTags.item(0);
					var textAreaTagName = textAreaTag.name;
					storeValues[i][j] = textAreaTag.value;

				} else if (textAreaTags.length > 0) {
					var textAreaTag = textAreaTags.item(1);
					var textAreaTagName = textAreaTag.name;
					storeValues[i][j] = textAreaTag.value;
				}

				/* Radio */
				var inputTags = htmlComponent.getElementsByTagName('input');
				var radioP = false;
				if (inputTags.length > 0) {
					var radioValues = new Array(inputTags.length);
					for (var y = 0; y < inputTags.length; y++) {
						if (inputTags[y].type == 'radio'
								|| inputTags[y].type == "checkbox") {
							radioValues[y] = inputTags[y].checked;
							radioP = true;
						} else if (inputTags[y].type == "text") {
							radioValues[y] = inputTags[y].value;
							radioP = true;
						}
					}
					if (radioP) {
						storeValues[i][j] = radioValues;
						radioP = false;
					}

				}

			}
		}

	}
	allStored = true;
}

/**
 * getEditableValues() function searches for 'editableColumnNames' hidden field
 * and populate the 'Set' dropdown with the editable columns headers
 */

function getEditableValues() {
	getAllColHeaderValues();

	if (!allStored) { // refresh page with new parameter added. if this
		// parameter is already set, do not refresh page.
		if (window.location.search.indexOf("reloaded=true") <= 0) {
			var url = window.location.href;
			if (url.indexOf('?') > -1) {
				url += '&reloaded=true'
			} else {
				url += '?reloaded=true'
			}
			window.location.href = url;
		}
	}

	var SplitNames;
	var inputTags = window.opener.document.getElementById(TABLE_PREFIX
			+ tableID + TABLE_SUFFIX).parentNode.getElementsByTagName("input");

	for (var i = 0; i < inputTags.length; i++) {
		if (inputTags.item(i).id == "editableColumnNames"
				&& inputTags.item(i).type == "hidden") {
			SplitNames = inputTags.item(i).value.split('~!CS!~');
			break;
		}
	}

	if (SplitNames != '') {
		for (var i = 0; i < SplitNames.length - 1; i++) {
			var opt = document.createElement("OPTION");
			var t = document.createTextNode(SplitNames[i]);
			document.getElementById('editablecolumns').options.add(opt);
			var splitNameID = SplitNames[i].split("!/~!!");
			opt.text = splitNameID[0];
			opt.value = splitNameID[1];
			opt.setAttribute('defaultvalue', splitNameID[2]);
			headertemplabels = new Array();

			var flag = true;
			var count = 0;
			for (j = 0; j < headerlabels.length; j++) {
				if (opt.text == headerlabels[j][1] && flag == true) {
					opt.setAttribute('tableIndex', headerlabels[j][0]);
					flag = false;
				} else {
					headertemplabels[count] = new Array(2);
					headertemplabels[count][0] = headerlabels[j][0];
					headertemplabels[count][1] = headerlabels[j][1];
					count++;
				}

			}

			var length = headertemplabels.length;
			headerlabels = new Array(length);
			for (k = 0; k < length; k++)
				headerlabels[k] = new Array(2);

			for (p = 0; p < length; p++) {
				headerlabels[p][0] = headertemplabels[p][0];
				headerlabels[p][1] = headertemplabels[p][1];
			}
		}
		document.getElementById('editablecolumns').selectedIndex = 0;
		getComponent(document.getElementById('editablecolumns'));
	} else {
		JCAAlert("com.ptc.windchill.enterprise.object.editPropertiesRB.NO_EDITABLE_FIELDS_FOUND")
		window.close(obj);
	}
}

/**
 * getComponent(obj) function is called when user changes combobox value of
 * "Set" in Edit Attribute Value Dialog. This function fetches component based
 * on value set in "Set" combobox and displays.
 */
function getComponent(obj) {
	// console.info ("START getComponent() : Displayed Component changed");
	var optValue = obj.value;
	var componentDefaultValue = obj.options[obj.selectedIndex]
			.getAttribute('defaultvalue');
	var componenttableIndexValue = obj.options[obj.selectedIndex]
			.getAttribute('tableIndex');

	var totalrows = tableUtil.getRowData(tableObj);
	var rowObject = totalrows.item(0);
	var componentHtml;
	for (var i = 0; i < totalrows.length; i++) {
		var selectionModel = tableObj.getSelectionModel();
		var sel = selectionModel.isSelected(i);
		if (sel) {
			componentHtml = tableObj.getView().getCell(i,
					componenttableIndexValue).innerHTML;
			// Check , if are getting component or not. Use case is for edit
			// multi object: soft type and with out soft type
			if (componentHtml != null || componentHtml != undefined) {
				break;
			}
		}
		// TODO: : Do not travese all the row, break when ever you get the compo
	}
	// This check is required when a view is applicable only for Parent Part not
	// for the child parts then rows against the
	// selected child part from the folder browser table get hidden in Edit
	// Multi object with class name 'h' <tr class="h">
	if (componentHtml.toLowerCase().contains('<button')) {
		var idx = componentHtml.indexOf("<button");
		if (idx < 0)
			idx = componentHtml.indexOf("<BUTTON");
		var idxend = componentHtml.indexOf("</button>");
		if (idxend < 0)
			idxend = componentHtml.indexOf("</BUTTON>");
		var before = componentHtml.substring(0, idx);
		var after = "</div>";
		componentHtml = before.concat(after);
	}

	document.getElementById("htmlCmponent").innerHTML = componentHtml;
	var htmlObj = gethtmlComponent();
	if (htmlObj) {
		if (htmlObj.length > 0) {
			checkCompFound = true;
			setDefaultOtherThanButton();

		}
	}
	if (checkCompFound == false)
		document.getElementById("htmlCmponent").innerHTML = "<font class='tableItemCount'>"
				+ document.getElementById('componetnotfound').value + "</font>";
	// console.info ("COMPONENT FOUND IN ROW NUMBER :" + ++len);
}
/**
 * setIdtoSelColum() sets a unique ID to components of a cell of selected table
 * row whose value should be changed after Ok or Apply.
 */
function setIdtoSelColum(htmlcollection) {
	for (var id = 0; id < htmlcollection.length; id++) {
		if (htmlcollection.item(id).parentNode.style.display != "none") {
			var str = "uniqueId_input_" + id;
			htmlcollection.item(id).setAttribute("uniqueId", str);
			// console.info ( "DIV ID : "
			// +htmlcollection.item(id).parentNode.id);
		}
	}
	return htmlcollection;
}

/*
 * This function will just update table store so that when ever table is re-rendered, its values are preserved.
 * In other words, with this API we are also updating model of MVC structure. 
 */
function updateTableData(htmlElement) {
	opener.PTC.wizard.saveTableData.domChangeEventListener.call(tableObj, null, htmlElement);
}
/**
 * applyValue() applies the value to the component of parent window
 */
function applyValue() {
	var obj = document.getElementById('editablecolumns')
	var optValue = obj.value;
	var componentDefaultValue = obj.options[obj.selectedIndex]
			.getAttribute('defaultvalue');
	var componenttableIndexValue = obj.options[obj.selectedIndex]
			.getAttribute('tableIndex');
	var totalrows = tableUtil.getRowData(tableObj);
	var rowObject = totalrows.item(0);
	var componentHtml;
	var count = 0;
	var component = gethtmlComponent();
	var selectedIndex = new Array();
	var selectionModel = tableObj.getSelectionModel();
	for (var i = 0; i < totalrows.length; i++) {
		var sel = selectionModel.isSelected(i);
		if (sel) {
			selectedIndex[count] = i;
			count++;
		}
	}

	for (var iter = 0; iter < component.length; iter++) {
		if (component[iter].type == "text") {
			var columnValue = component[iter].value;
			for (var z = 0; z < selectedIndex.length; z++) {
				var cellContents = tableObj.getView().getCell(selectedIndex[z],
						componenttableIndexValue);
				var compName = component[iter].getAttribute('uniqueId');
				var htmlcollection = cellContents.getElementsByTagName('input');
				htmlcollection = setIdtoSelColum(htmlcollection);
				for (var k = 0; k < htmlcollection.length; k++) {
					if (htmlcollection.item(k).type == 'text') {
						if (htmlcollection.item(k).getAttribute('uniqueId') == compName) {
							htmlcollection.item(k).value = columnValue;
							htmlcollection.item(k).title = component[iter].title;
							updateTableData(htmlcollection.item(k));
							// console.info ("TEXT CASE :
							// "+htmlcollection.item(k).id);
						}
					} else if (htmlcollection.item(k).type == 'radio') {
						// console.info ("RADIO CASE :
						// "+htmlcollection.item(k).id);
						var tagValue;
						if (component[iter].type == 'radio')
							tagValue = columnValue;
						if (htmlcollection.item(k).value.toLowerCase() == tagValue.toLowerCase()) {
							htmlcollection.item(k).checked = true;
						} else {
							htmlcollection.item(k).checked = false;
						}
						updateTableData(htmlcollection.item(k));
					}
				}
			}
		}

		else if (component[iter].type == "hidden") // Update type hidden but
		// should not contain
		// "___old" in name
		{
			var columnValue = component[iter].value;
			var typeName = component[iter].name;
			if (!typeName.contains("IBA")) { // check added for the IBA's
				// SPR#4490561 as the hidden
				// feild for IBA's was changing
				// the DB_VAL and UOM.
				for (var z = 0; z < selectedIndex.length; z++) {
					var cellContents = tableObj.getView().getCell(
							selectedIndex[z], componenttableIndexValue);
					var compName = component[iter].getAttribute('uniqueId');
					var htmlcollection = cellContents
							.getElementsByTagName('input');
					htmlcollection = setIdtoSelColum(htmlcollection);
					for (var k = 0; k < htmlcollection.length; k++) {
						if (htmlcollection.item(k).type == 'hidden') {
							if (htmlcollection.item(k).getAttribute('uniqueId') == compName) {
								htmlcollection.item(k).value = columnValue;
								htmlcollection.item(k).title = component[iter].title;
								updateTableData(htmlcollection.item(k));
								// console.info ("TEXT CASE :
								// "+htmlcollection.item(k).id);
							}
						}
					}
				}
			}

		}
		// Drop Down
		else if (component[iter].type == "select-one") {
			var columnValue = component[iter].selectedIndex;
			var compName = component[iter].getAttribute('uniqueId');
			for (var z = 0; z < selectedIndex.length; z++) {
				componentHtml = tableObj.getView().getCell(selectedIndex[z],
						componenttableIndexValue);
				var htmlcollection = componentHtml
						.getElementsByTagName('select');
				htmlcollection = setIdtoSelColum(htmlcollection);
				for (var k = 0; k < htmlcollection.length; k++) {
					if (htmlcollection.item(k).getAttribute('uniqueId') == compName) {
						htmlcollection.item(k).selectedIndex = columnValue;
						updateTableData(htmlcollection.item(k));
					}
				}
				// htmlcollection[0].selectedIndex = columnValue;
			}
		} /* TextArea */
		else if (component[iter].type == "textarea") {
			var columnValue = component[iter].value;
			for (var z = 0; z < selectedIndex.length; z++) {
				var cellContents = tableObj.getView().getCell(selectedIndex[z],
						componenttableIndexValue);
				var compName = component[iter].getAttribute('uniqueId');
				var htmlcollection = cellContents
						.getElementsByTagName('textarea');
				htmlcollection = setIdtoSelColum(htmlcollection);
				for (var k = 0; k < htmlcollection.length; k++) {
					if (htmlcollection.item(k).type == 'textarea') {
						if (htmlcollection.item(k).getAttribute('uniqueId') == compName) {
							htmlcollection.item(k).value = columnValue;
							updateTableData(htmlcollection.item(k));
						}
					}
				}
			}
		}
		/* Checkbox */
		else if (component[iter].type == "checkbox") {
			var columnValue = component[iter].checked;
			// console.info ("columnValue="+columnValue);
			for (var z = 0; z < selectedIndex.length; z++) {
				var cellContents = tableObj.getView().getCell(selectedIndex[z],
						componenttableIndexValue);
				var compName = component[iter].getAttribute('uniqueId');
				var htmlcollection = cellContents.getElementsByTagName('input');
				htmlcollection = setIdtoSelColum(htmlcollection);
				for (var k = 0; k < htmlcollection.length; k++) {
					if (htmlcollection.item(k).type == 'checkbox') {
						if (htmlcollection.item(k).getAttribute('uniqueId') == compName) {
							htmlcollection.item(k).checked = columnValue;
							updateTableData(htmlcollection.item(k));
						}
					}
				}
			}
		}
		/* Radio */
		else if (component[iter].type == 'radio' && component[iter].checked) {
			var tagValue = component[iter].value;
			// console.info (" tagValue : "+tagValue);
			for (var z = 0; z < selectedIndex.length; z++) {
				componentHtml = tableObj.getView().getCell(selectedIndex[z],
						componenttableIndexValue);
				var compName = component[iter].getAttribute('uniqueId');
				var htmlcollection = componentHtml
						.getElementsByTagName('input');
				htmlcollection = setIdtoSelColum(htmlcollection);
				for (var k = 0; k < htmlcollection.length; k++) {
					// console.info ("else if RADIO... "
					// +htmlcollection.item(k).type);
					if (htmlcollection.item(k).type == 'radio') {
						if (htmlcollection.item(k).value.toLowerCase() == tagValue
								.toLowerCase()) {
							htmlcollection.item(k).checked = true;
							updateTableData(htmlcollection.item(k));
						}// else is not required since radio buttons belongs
						// to a group, select one option will deselect
						// others automatically
					}
				}
			}
		}
	}

}
/*
 * gethtmlComponent() returns the displaying component from "Edit Attribute
 * Value" wizard
 */
function gethtmlComponent() {
	var childnodes = document.getElementById("htmlCmponent");
	var component = new Array();
	var scntr = 0;
	var tctr = 0;

	if (childnodes.getElementsByTagName('select').length > 0) {
		var selectCollection = childnodes.getElementsByTagName('select');
		for (var select = 0; select < selectCollection.length; select++) {
			if (selectCollection.item(select).parentNode) {
				if (selectCollection.item(select).parentNode.style.display != "none") // Style
					// is
					// checked
					// for
					// multiValued
					// components
					if (selectCollection.item(select).type != 'hidden') {
						var idStr = "uniqueId_input_" + select;
						selectCollection.item(select).setAttribute("uniqueId",
								idStr);
						component[scntr++] = selectCollection.item(select);
					}
			}
		}
	} else if (childnodes.getElementsByTagName('textarea').length > 0) {
		var textAreaCollection = childnodes.getElementsByTagName('textarea');
		for (var sel = 0; sel < textAreaCollection.length; sel++) {
			if (textAreaCollection.item(sel).parentNode) {
				if (textAreaCollection.item(sel).parentNode.style.display != "none") // Style
					// is
					// checked
					// for
					// multiValued
					// components
					if (textAreaCollection.item(sel).type != 'hidden') {
						var idStr = "uniqueId_input_" + sel;
						textAreaCollection.item(sel).setAttribute("uniqueId",
								idStr);
						component[tctr++] = textAreaCollection.item(sel);
					}
			}
		}
	}
	// Don't keep below if in else if condition. This if condition adding
	// htmlcomponent in component[] array without hidden having "___old" in
	// name.
	if (childnodes.getElementsByTagName('input').length > 0) {
		var collection = childnodes.getElementsByTagName('input');
		var ictr = scntr + tctr;
		for (var k = 0; k < collection.length; k++) {
			if (collection.item(k).parentNode.style.display != "none") // Style
			// is
			// checked
			// for
			// multiValued
			// components
			{
				var idStr = "uniqueId_input_" + k;
				collection.item(k).setAttribute("uniqueId", idStr);
				var nameLength = collection.item(k).name.length;
				var oldCompLength = oldComponentSuffix.length;
				var nameSubString = collection.item(k).name.substring(
						nameLength - oldCompLength, nameLength);

				// console.log ("nameSubString : " +nameSubString);

				if (nameSubString != oldComponentSuffix) // SPR: 1554960-01
				// Include hidden
				// fields they also
				// get update.
				{
					component[ictr++] = collection.item(k);

				}
			}
		}
	}
	return component;
}
/**
 * setDefault() sets the default value of component after click on Set Default
 * button.
 */
function setDefault() {
	var displayedComp = gethtmlComponent();
	if (displayedComp.length != 0)
		setDefaultValue(displayedComp, '');
	// document.getElementById("htmlCmponent").innerHTML = "<font
	// class='tableItemCount'>"+document.getElementById('componetnotfound').value+"</font>";
}
/**
 * setDefaultOtherThanButton() sets the empty value of component.
 */
function setDefaultOtherThanButton() {

	var displayedComp = gethtmlComponent();

	if (displayedComp.length != 0)

		setDefaultValue(displayedComp, 'formOtherThanDefaultButton');

	// document.getElementById("htmlCmponent").innerHTML = "<font
	// class='tableItemCount'>"+document.getElementById('componetnotfound').value+"</font>";

}

function setDefaultValue(component, dummyValue) {
	// console.info ("START setDefaultValue component.lenght :" +
	// component.length);
	var obj = document.getElementById('editablecolumns');
	var componentDefaultValue = obj.options[obj.selectedIndex]
			.getAttribute('defaultvalue');
	if (dummyValue == 'formOtherThanDefaultButton') {
		componentDefaultValue = "";
	}
	var urlComponent = componentDefaultValue.indexOf('/~UT~')
	/* URL Component */
	if (urlComponent > -1) {
		var urlValue = componentDefaultValue.split('/~UT~');
		// console.info ("URL : "+urlValue[0]+" Value: "+urlValue[1]);
		component[0].value = urlValue[0];
		component[1].value = urlValue[1];
	}
	/* Text Box */
	else if (component[0].type == "text") {
		component[0].value = componentDefaultValue;
	}
	/* Text Area */
	if (component[0].type == "textarea")
		component[0].value = componentDefaultValue;
	/* combo Box */
	if (component[0].type == "select-one") {
		if (componentDefaultValue == "")
			component[0].selectedIndex = 0;
		else
			component[0].value = componentDefaultValue;
	}
	/* Radio Button */
	if (component[0].type == "radio") {
		var radioTags = document.getElementById("htmlCmponent")
				.getElementsByTagName("input");
		for (i = 0; i < radioTags.length; i++) {
			var radioValue = radioTags.item(i).value;

			if ((radioValue.toLowerCase() == componentDefaultValue
					.toLowerCase())
					&& radioTags.item(i).type == "radio"
					&& !(radioTags.item(i).parentNode.style.display == "none")) {
				radioTags.item(i).checked = true;
				break;
			}
		}
	}
}

function applyAndClose() {
	applyValue();
	window.close();
}
/*
 * resetValues() calls on cancel action and reset all values
 */
function resetValues() {
	// console.info (" tagValue : "+tagValue);
	if (allStored) {
		var selectedIndex = new Array();
		var totalrows = tableUtil.getRowData(tableObj);
		var count = 0;
		var selectionModel = tableObj.getSelectionModel();
		for (var i = 0; i < totalrows.length; i++) {
			var sel = selectionModel.isSelected(i);
			if (sel) {
				selectedIndex[count] = i;
				count++;
			}
		}
		for (var z = 0; z < selectedIndex.length; z++) {
			for (var x = 0; x < headercount; x++) {
				var htmlCompo = tableObj.getView().getCell(selectedIndex[z], x);
				/* Radio Button */
				var inputTags = htmlCompo.getElementsByTagName('input');
				if (inputTags.length > 0) {
					var radioValues = storeValues[selectedIndex[z]][x];
					for (var j = 0; j < inputTags.length; j++) {
						if (inputTags[j].type == 'radio'
								|| inputTags[j].type == "checkbox") {
							var radioTag = inputTags.item(j);
							var radioTagName = radioTag.name;
							radioTag.checked = radioValues[j];
						} else if (inputTags[j].type == "text") {
							var radioTag = inputTags.item(j);
							var radioTagName = radioTag.name;
							radioTag.value = radioValues[j];
						}
					}
				}
				var selectTags = htmlCompo.getElementsByTagName("select");
				for (var j = 0; j < selectTags.length; j++) {
					var selectTag = selectTags.item(j);
					var selectTagName = selectTag.name;
					selectTag.selectedIndex = storeValues[selectedIndex[z]][x];
				}
				/* Textarea */
				var textAreaTags = htmlCompo.getElementsByTagName('textarea');
				if (textAreaTags.length == 1) {
					var textAreaTag = textAreaTags.item(0);
					var textAreaTagName = textAreaTag.name;
					textAreaTag.value = storeValues[selectedIndex[z]][x];
				} else if (textAreaTags.length > 0) {
					var textAreaTag = textAreaTags.item(1);
					var textAreaTagName = textAreaTag.name;
					textAreaTag.value = storeValues[selectedIndex[z]][x];
				}
			}
		}
	}
	window.close();
}
String.prototype.contains = function(t) {
	return this.indexOf(t) >= 0 ? true : false
}
