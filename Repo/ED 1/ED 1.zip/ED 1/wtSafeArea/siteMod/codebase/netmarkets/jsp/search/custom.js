// Write your custom js functions here
// Please specify your custom js functions in netmarket/javascript/util/validate.js

function geklaPickerCallback(objects, pickerID)
{ 
   var updateHiddenField = document.getElementById(pickerID);
   var parent = updateHiddenField.parentNode.parentNode.parentNode;
   var attrMap = parent.getElementsByTagName("button")[0].getAttribute("pickerjson");
   var attrArray = attrMap.split(",")
   var updateDisplayField;
   var compId;
   for (var i=0; i<attrArray.length; i++) {
		var index = attrArray[i].search("displayFieldId"); //alternate could be pickerId as well
		if (index>0 && index<=2) {
				updateDisplayField = attrArray[i].substring(attrArray[i].indexOf(":")+2, attrArray[i].length-1);
		}
		index = attrArray[i].search("openerCompContext");
		if (index>0 && index<=2) {
				compId = attrArray[i].substring(attrArray[i].indexOf(":")+2, attrArray[i].length-1);
		}
   }
   var x = compId.concat(updateDisplayField).replace(/"/g, "");
   var x2 = x.concat(pickerID);
   var field = document.getElementById(x2);//mandatory field is marked like this
   if (field == null)
		field = document.getElementById(x);//not mandatory field
   var myJSONObjects = objects.pickedObject;
   for(var i=0; i< myJSONObjects.length;i++) {
     var oid = myJSONObjects[i].oid;
     // Here �name� is the displayAttribute requested 
     var displayAttr = eval("myJSONObjects[i].number");
     updateHiddenField.value=displayAttr;
     field.value=displayAttr;
   }
}

function cataloguePickerCallback(objects, pickerID)
{ 
   var updateHiddenField = document.getElementById(pickerID);
   var parent = updateHiddenField.parentNode.parentNode.parentNode;
   var attrMap = parent.getElementsByTagName("button")[0].getAttribute("pickerjson");
   var attrArray = attrMap.split(",")
   var updateDisplayField;
   var compId;

   for (var i=0; i<attrArray.length; i++) {
		var index = attrArray[i].search("displayFieldId"); //alternate could be pickerId as well
		if (index>0 && index<=2) {
				updateDisplayField = attrArray[i].substring(attrArray[i].indexOf(":")+2, attrArray[i].length-1);
		}
		index = attrArray[i].search("openerCompContext");
		if (index>0 && index<=2) {
				compId = attrArray[i].substring(attrArray[i].indexOf(":")+2, attrArray[i].length-1);
		}
   }
   var x = compId.concat(updateDisplayField).replace(/"/g, "");
   var x2 = x.concat(pickerID);
   var field = document.getElementById(x2);//mandatory field is marked like this
   if (field == null)
		field = document.getElementById(x);//not mandatory field
   var myJSONObjects = objects.pickedObject;
   for(var i=0; i< myJSONObjects.length;i++) {
     var oid = myJSONObjects[i].oid;
     // Here �name� is the displayAttribute requested 
     var displayAttr = eval("myJSONObjects[i].sourceLanguage");
     field.value=displayAttr;
	 var oid = eval("myJSONObjects[i].oid");
	 var hiddenOid = oid.substring(oid.lastIndexOf(":")+1, oid.length);
     updateHiddenField.value=hiddenOid;
   }
}

function namingEntryCallbackJSP(objects, pickerID)
{
	var updateHiddenField = document.getElementById(pickerID);
	var updateDisplayField = document.getElementById(pickerID +	"$label$");
	var myJSONObjects = objects.pickedObject;
	var KB_DESCRIPTION_EN = 'KB_DESCRIPTION_EN';
	for(var i=0; i< myJSONObjects.length;i++) {
		var number = eval("myJSONObjects[i].number");
		var displayAttr = myJSONObjects[i][KB_DESCRIPTION_EN];
		var keys = Object.keys(myJSONObjects[i]);
		for (var j = 0, len = keys.length; j < len; j++) {	
			if(/KB_DESCRIPTION_/.test(keys[j]) && keys[j]!==KB_DESCRIPTION_EN){
				if(myJSONObjects[i][keys[j]]){
					displayAttr = myJSONObjects[i][keys[j]];
				}
				break;
			}
		}
		updateHiddenField.value = number;
		updateDisplayField.value = displayAttr;
		var htmlComponent = document.getElementById('htmlCmponent');
		htmlComponent.value = displayAttr;
	}
}

function standardCallbackJSP(objects, pickerID)
{
	var updateHiddenField = document.getElementById(pickerID);
	var updateDisplayField = document.getElementById(pickerID +	"$label$");
	var myJSONObjects = objects.pickedObject;
	for(var i=0; i< myJSONObjects.length;i++) {
		var number = eval("myJSONObjects[i].number");
		var displayAttr = eval("myJSONObjects[i].name");
		updateHiddenField.value = number;
		updateDisplayField.value = displayAttr;
		var htmlComponent = document.getElementById('htmlCmponent');
		htmlComponent.value = displayAttr;
	}
}

function geklaCallbackJSP(objects, pickerID)
{
	var updateHiddenField = document.getElementById(pickerID);
	var updateDisplayField = document.getElementById(pickerID +	"$label$");
	var myJSONObjects = objects.pickedObject;
	for(var i=0; i< myJSONObjects.length;i++) {
		var number = eval("myJSONObjects[i].number");
		updateHiddenField.value = number;
		updateDisplayField.value = number;
		var htmlComponent = document.getElementById('htmlCmponent');
		htmlComponent.value = number;
	}
}

function namingEntryCallback(objects, pickerID)
{ 
   var updateHiddenField = document.getElementById(pickerID);
   var parent = updateHiddenField.parentNode.parentNode.parentNode;
   var attrMap = parent.getElementsByTagName("button")[0].getAttribute("pickerjson");
   var attrArray = attrMap.split(",")
   var updateDisplayField;
   var compId;
   for (var i=0; i<attrArray.length; i++) {
		var index = attrArray[i].search("displayFieldId"); //alternate could be pickerId as well
		if (index>0 && index<=2) {
				updateDisplayField = attrArray[i].substring(attrArray[i].indexOf(":")+2, attrArray[i].length-1);
		}
		index = attrArray[i].search("openerCompContext");
		if (index>0 && index<=2) {
				compId = attrArray[i].substring(attrArray[i].indexOf(":")+2, attrArray[i].length-1);
		}
   }
   var x = compId.concat(updateDisplayField).replace(/"/g, "");
   var x2 = x.concat(pickerID);
   var field = document.getElementById(x2);//mandatory field is marked like this
   if (field == null)
		field = document.getElementById(x);//not mandatory field
   var namingEntryJSON = objects.pickedObject;
   var descKey = null;
   var oidKey = null;
   var oid = null;
   var KB_DESCRIPTION_EN = 'KB_DESCRIPTION_EN';
   for(var i=0; i< namingEntryJSON.length;i++) {
	 field.value = namingEntryJSON[i][KB_DESCRIPTION_EN];
	 var keys = Object.keys(namingEntryJSON[i]);
	 for (var j = 0, len = keys.length; j < len; j++) {	
		if(/KB_DESCRIPTION_/.test(keys[j]) && keys[j]!==KB_DESCRIPTION_EN){
			if(namingEntryJSON[i][keys[j]]){
				field.value = namingEntryJSON[i][keys[j]];
			}
			break;
		}
	}
	/* var masterReference = eval("namingEntryJSON[i].masterReference");
	 var masterOid = masterReference.substring(masterReference.indexOf(":")+1, masterReference.length);
	 masterOid = masterOid.substring(masterOid.indexOf(":")+1, masterOid.length);
	 masterOid = masterOid.substring(0, masterOid.indexOf(":"));
	 var hiddenOid = oid.substring(oid.lastIndexOf(":")+1, oid.length);
     updateHiddenField.value=masterOid;

	 var oid = eval("namingEntryJSON[i].thePersistInfo.theObjectIdentifier.id");
	 oid = oid.replace(/\s+/g, '');
	 var hiddenOid = oid;
	 */
     updateHiddenField.value=namingEntryJSON[0]['number'];

   }
}

function materialPickerCallback(objects, pickerID)
{
   var updateHiddenField = document.getElementById(pickerID);
   var parent = updateHiddenField.parentNode.parentNode.parentNode;
   var attrMap = parent.getElementsByTagName("button")[0].getAttribute("pickerjson");
   var attrArray = attrMap.split(",")
   var updateDisplayField;
   var compId;
   for (var i=0; i<attrArray.length; i++) {
		var index = attrArray[i].search("displayFieldId"); //alternate could be pickerId as well
		if (index>0 && index<=2) {
				updateDisplayField = attrArray[i].substring(attrArray[i].indexOf(":")+2, attrArray[i].length-1);
		}
		index = attrArray[i].search("openerCompContext");
		if (index>0 && index<=2) {
				compId = attrArray[i].substring(attrArray[i].indexOf(":")+2, attrArray[i].length-1);
		}
   }
   var x = compId.concat(updateDisplayField).replace(/"/g, "");
   var x2 = x.concat(pickerID);
   var field = document.getElementById(x2);//mandatory field is marked like this
   if (field == null)
		field = document.getElementById(x);//not mandatory field
   var materialJSON = objects.pickedObject;
   field.value = materialJSON[0]['name'];
   updateHiddenField.value = materialJSON[0]['number'];
}

function coatingPickerCallback(objects, pickerID)
{
   var updateHiddenField = document.getElementById(pickerID);
   var parent = updateHiddenField.parentNode.parentNode.parentNode;
   var attrMap = parent.getElementsByTagName("button")[0].getAttribute("pickerjson");
   var attrArray = attrMap.split(",")
   var updateDisplayField;
   var compId;
   for (var i=0; i<attrArray.length; i++) {
		var index = attrArray[i].search("displayFieldId"); //alternate could be pickerId as well
		if (index>0 && index<=2) {
				updateDisplayField = attrArray[i].substring(attrArray[i].indexOf(":")+2, attrArray[i].length-1);
		}
		index = attrArray[i].search("openerCompContext");
		if (index>0 && index<=2) {
				compId = attrArray[i].substring(attrArray[i].indexOf(":")+2, attrArray[i].length-1);
		}
   }
   var x = compId.concat(updateDisplayField).replace(/"/g, "");
   var x2 = x.concat(pickerID);
   var field = document.getElementById(x2);//mandatory field is marked like this
   if (field == null)
		field = document.getElementById(x);//not mandatory field
   var materialJSON = objects.pickedObject;
   field.value = materialJSON[0]['name'];
   updateHiddenField.value = materialJSON[0]['number'];
}


function coatingPickerCallback(objects, pickerID, attr,displayFieldId)
{
   
   var displayFieldValue = ""; 
   var hiddenFieldValue = ""; 
   var updateHiddenField=document.getElementsByName(pickerID)[0];
   var updateDisplayFieldId;
   
   var parent = updateHiddenField.parentNode.parentNode.parentNode;
   var attrMap = parent.getElementsByTagName("button")[0].getAttribute("pickerjson");
   var attrArray = attrMap.split(",")
   
   var compId;
   for (var i=0; i<attrArray.length; i++) {
		var index = attrArray[i].search("displayFieldId"); //alternate could be pickerId as well
		if (index>0 && index<=2) {
			updateDisplayFieldId = attrArray[i].substring(attrArray[i].indexOf(":")+2, attrArray[i].length-1);
		}
		index = attrArray[i].search("openerCompContext");
		if (index>0 && index<=2) {
				compId = attrArray[i].substring(attrArray[i].indexOf(":")+2, attrArray[i].length-1);
		}
   }
   
   updateDisplayFieldId = compId.concat(updateDisplayFieldId).replace(/"/g, "");
   var updateMandatoryDisplayFieldId = updateDisplayFieldId.concat(pickerID);
   var updateDisplayField = document.getElementById(updateMandatoryDisplayFieldId);//mandatory field is marked like this
   if (updateDisplayField == null)
	   updateDisplayField = document.getElementById(updateDisplayFieldId);//not mandatory field   
   if(updateDisplayField)PTC.util._setMainFormStartingElement(updateDisplayField);
   
   var coatingJSON=objects.pickedObject;
   for(var i=0;i<coatingJSON.length;i++){
       var displayAttr=coatingJSON[i]['name'];
       var hiddenAttr=coatingJSON[i]['number'];
       
       if (displayFieldValue == "")
       {
    	   displayFieldValue = displayAttr; 
    	   hiddenFieldValue = hiddenAttr;
       } 
       else 
       {
    	   displayFieldValue = displayFieldValue + ";" + displayAttr; 
    	   hiddenFieldValue = hiddenFieldValue + ";" + hiddenAttr;
       }
   } 
   updateDisplayField.value=displayFieldValue
   updateHiddenField.value=hiddenFieldValue;

   
}

