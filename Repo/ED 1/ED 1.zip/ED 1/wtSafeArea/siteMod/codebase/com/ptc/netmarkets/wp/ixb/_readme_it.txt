====================================================================================================
ENTHALTENE SPRACHEN - INCLUDED LANGUAGES - IDIOMAS INCLUIDOS - LANGUES INCLUSES - LINGUE INCLUSE:
====================================================================================================

I.    DEUTSCH
II.   ENGLISH
III.  ESPA�OL
IV.   FRAN�AIS
V.    ITALIANO

====================================================================================================
I.    DEUTSCH
====================================================================================================

Diese ZIP-Datei enth�lt aus PLM extrahierte Paketinformationen.
----------------------------------------------------------------------------------------------------
Inhalt:
-   Ordner CONTENTS enth�lt Datens�tze
-   Ordner Resources enth�lt einen web-basierten Offline-Viewer, der Ihnen erm�glicht direkt auf
    die Dateninhalte der ZIP-Datei zu zugreifen.
-   Datei index.html enth�lt Details zum Paketinhalt.
        Folgende Ansichten k�nnen eingestellt werden:
        1. Alle in dieser Lieferung enthaltenen Inhalte
        2. Nur Produktstruktur-Inhalte

Zugriff auf die Daten:
-   durch �ffnen des Ordners CONTENT 
-   durch �ffnen der Datei index.html und Navigation in der �bersicht. Durch Anklicken des Info-
    Symbols (blau) gelangt man auf das Objekt und die Daten werden im Offline-Viewer ge�ffnet.

----------------------------------------------------------------------------------------------------
Nutzungsdetails:
Der Prozess kann abh�ngig von der Konfiguration Ihres Systems variieren. Die folgenden
grundlegenden Schritte helfen Ihnen bei der Navigation zu den Paketinformationen:

1.  Verwenden Sie ein ZIP-Dienstprogramm, wie z.B. WinZip, um dieses Paket in einen neuen Ordner
    auf Ihrer Festplatte zu extrahieren.

2.  Navigieren Sie zum ausgew�hlten Speicherort der ZIP-Paketdatei. Der Ordner enth�lt eine Liste
    mit Daten. Es gibt zwei M�glichkeiten um den Inhalt der ZIP-Paketdatei anzuzeigen:

    - Doppelklicken Sie auf die Datei index.html um die Paketinformationen in Ihrem Webbrowser
      anzuzeigen. Abh�ngig von Ihrer Systemkonfiguration wird das Paket in dem von Ihnen
      gew�hlten Webbrowser ge�ffnet.
    - �ffnen Sie den Ordner Contents wenn Sie die Paketinformationen nicht mithilfe des Offline-
      Viewers anzeigen m�chten. Dieser Ordner enth�lt alle im Paket enthaltenen Darstellungen,
      Teiledateien und Anh�nge. Sie k�nnen diesen Ordner verwenden um Paketdateien direkt in
      Ihr System zu importieren.

3.  Wenn Sie die Datei index.html �ffnen wird die Seite Package Details in Ihrem Browser ge�ffnet.

Klicken Sie auf die Hilfeschaltfl�che oben auf der Seite um weitere Informationen zu den in der
Offline-Anzeige verf�gbaren Paketinformationen zu erhalten.


====================================================================================================
II.   ENGLISH
====================================================================================================

This zip file contains extracted package information from PLM.
----------------------------------------------------------------------------------------------------
Contents:
-   The CONTENTS folder contains data records
-   The Resources folder contains a web-based offline viewer which allows you direct access to the
    data content of the zip file.
-   The index.html file contains details on the package contents.
        The following views can be created:
        1. All contents in this delivery
        2. Only contents on product structure

Access the data:
-   By opening the CONTENT folder
-   By opening the index.html file and navigating to the overview. Clicking on the Info Symbols
    (blue) shows the object and the data is opened in the offline viewer.

----------------------------------------------------------------------------------------------------
Usage details:
The process may vary depending on your system configuration. The following basic steps will help
you navigate to the package information:

1.  Use a zip utility such as WinZip to extract this package in a new folder on your hard drive.

2.  Navigate to the chosen storage location of the zip package file. The folder contains a list
    of data. There are two options for displaying the contents of the zip package file:
    - Double-click on the index.html file to display the package information in your web
      browser. The package will be opened in your chosen web browser depending on your system
      configuration.
    - Open the CONTENTS folder if you want to display the package information without the means
      of the offline viewer. This folder contains all illustrations, part files and appendices
      contained in the package. You can use this folder to import package files directly into
      your system.

3.  When you open the index.html file, the Package Details page will be opened in your browser.

Click on the help button on the top of the page to receive further information on the package
information available in the offline display.


====================================================================================================
III.  ESPA�OL
====================================================================================================

Este archivo ZIP contiene informaci�n del paquete extra�da del PLM.
----------------------------------------------------------------------------------------------------
Contenido:
-   La carpeta CONTENTS contiene conjuntos de datos.
-   La carpeta Resources contiene un visualizador fuera de l�nea basado en la web que le permite
    acceder directamente al contenido de los datos del archivo ZIP.
-   El archivo index.html contiene detalles sobre el contenido del paquete.
        Es posible ajustar las siguientes vistas:
        1. Todos los contenidos incluidos en este env�o.
        2. Solo contenidos de la estructura del producto.

Acceso a los datos:
-   Abriendo la carpeta CONTENT. 
-   Abriendo el archivo index.html y navegando en la vista general. Haciendo clic en el s�mbolo de
    informaci�n (azul) se accede al objeto y se abren los datos en el visualizador fuera de l�nea.

----------------------------------------------------------------------------------------------------
Detalles de utilizaci�n:
El proceso puede variar en funci�n de la configuraci�n de su sistema. Los siguientes pasos b�sicos
le ayudar�n durante la navegaci�n a la informaci�n del paquete:

1.  Utilice un programa utilitario ZIP, como por ejemplo WinZip, para extraer el paquete en una
    nueva carpeta en su disco duro.

2.  Navegue hasta la ubicaci�n de almacenamiento seleccionada del archivo del paquete ZIP.
    La carpeta contiene una lista con datos. Existen dos opciones para visualizar el contenido
    del archivo del paquete ZIP:
    - Haga doble clic en el archivo index.html para visualizar la informaci�n del paquete en su
      navegador web. En funci�n de la configuraci�n de su sistema, el paquete se abre en el
      navegador web que haya seleccionado.
    - Abra la carpeta Contents si no desea visualizar la informaci�n del paquete con el
      visualizador fuera de l�nea. Esta carpeta contiene todas las representaciones, archivos
      de piezas y archivos adjuntos incluidos en el paquete. Puede utilizar esta carpeta para
      importar archivos del paquete directamente en su sistema.

3.  Al abrir el archivo index.html, se abre la p�gina Package Details en su navegador.

Haga clic en el bot�n de ayuda superior de la p�gina para obtener m�s informaci�n sobre la
informaci�n del paquete disponible en el visualizador fuera de l�nea.


====================================================================================================
IV.   FRAN�AIS
====================================================================================================

Ce fichier ZIP contient des informations de paquet extraites du PLM.
----------------------------------------------------------------------------------------------------
Contenu:
-   Le dossier CONTENTS contient des enregistrements
-   Le dossier RESOURCES contient une visionneuse hors ligne bas�e sur le web qui vous permet
    d'acc�der directement aux contenus des donn�es du fichier ZIP.
-   Le fichier index.html contient les d�tails du contenu du paquet.
        Les vues suivantes peuvent �tre r�gl�es:
        1. Tous les contenus inclus dans cette livraison
        2. Uniquement des contenus de structure du produit

Acc�s aux donn�es:
-   en ouvrant le dossier CONTENTS 
-   en ouvrant le fichier index.html et en naviguant dans la vue d'ensemble. En cliquant sur
    l'ic�ne Info (bleu), on parvient � l'objet et les donn�es sont ouvertes dans la visionneuse
    hors ligne.

----------------------------------------------------------------------------------------------------
D�tails d'utilisation:
Le processus peut varier en fonction de la configuration de votre syst�me. Les �tapes
fondamentales suivantes vous aident � naviguer vers les informations du paquet:

1.  Utilisez un programme de service ZIP, comme p. ex. WinZip pour extraire ce paquet dans un
    nouveau dossier sur votre disque dur.

2.  Naviguez vers l'emplacement s�lectionn� du fichier de paquetage ZIP. Le dossier contient une
    liste de donn�es. Il y a deux possibilit�s pour afficher le contenu du fichier de paquetage ZIP:
    - En double-cliquant sur le fichier index.html pour afficher les informations du paquet dans
      votre navigateur web. Selon la configuration de votre syst�me, le paquet est ouvert dans le
      navigateur web que vous avez s�lectionn�.
    - Ouvrez le dossier Contents si vous ne souhaitez pas afficher les informations du paquet �
      l'aide de la visionneuse hors ligne. Ce dossier contient toutes les repr�sentations,
      fichiers de pi�ces et annexes contenus dans le paquet. Vous pouvez utiliser ce dossier
      pour importer directement des fichiers du paquet dans votre syst�me.

3.  Si vous ouvrez le fichier index.html, la page D�tails du paquet s'ouvre dans votre navigateur.

Cliquez sur le bouton d'aide en haut de la page pour obtenir d'autres informations sur les
informations de paquet disponibles dans l'affichage hors ligne.


====================================================================================================
V.    ITALIANO
====================================================================================================

Questo file ZIP contiene informazioni sui pacchetti estratti dal PLM.
----------------------------------------------------------------------------------------------------
Sommario:
-   La cartella CONTENTS contiene record di dati
-   La cartella Resources contiene un visualizzatore offline basato sul web che consente di accedere
    direttamente al contenuto dei dati del file ZIP.
-   Il file index.html contiene dettagli sul contenuto del pacchetto.
        � possibile impostare le seguenti visualizzazioni:
        1. Tutti i contenuti di questa fornitura
        2. Solo contenuti di struttura del prodotto

Accesso ai dati:
-   aprendo la cartella CONTENT 
-   aprendo il file index.html e navigando nella panoramica. Cliccando sul simbolo info (blu) si
    accede all'oggetto e i dati vengono aperti nel visualizzatore offline.

----------------------------------------------------------------------------------------------------
Dettagli di utilizzo:
Il processo pu� variare a seconda della configurazione del vostro sistema. I seguenti passaggi
fondamentali vi aiuteranno a navigare verso le informazioni del pacchetto:

1.  Utilizzare un programma di utilit� ZIP, come WinZip, per estrarre questo pacchetto in una nuova
    cartella sul disco rigido.

2.  Navigare verso la posizione di memoria selezionata del file di pacchetto ZIP. La cartella
    contiene un elenco di dati. Ci sono due possibilit� per visualizzare il contenuto del file di
    pacchetto ZIP:
    - Fare doppio clic sul file index.html per visualizzare le informazioni del pacchetto nel
      browser web. A seconda della configurazione del sistema, il pacchetto si aprir� nel browser
      web selezionato.
    - Aprire la cartella Contents se non si desidera visualizzare le informazioni del pacchetto
      utilizzando il visualizzatore offline. Questa cartella contiene tutte le rappresentazioni,
      i file di parti e gli allegati contenuti nel pacchetto. � possibile utilizzare questa
      cartella per importare i file del pacchetto direttamente nel sistema.

3.  Quando si apre il file index.html, la pagina Dettagli pacchetto si apre nel browser.

Fare clic sul tasto Aiuto nella parte superiore della pagina per ulteriori informazioni sul
pacchetto disponibile nel display offline.
