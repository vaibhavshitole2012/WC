/* bcwti
 *
 * Copyright (c) 2010 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */
package com.ptc.netmarkets.wp.ixb;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;

import com.ptc.core.htmlcomp.util.TypeHelper;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.generic.iba.AttributeService;
import com.ptc.netmarkets.wp.ixb.WPZipContent.MemoryLink;
import com.ptc.netmarkets.wp.ixb.WPZipContent.MemoryObject;
import com.ptc.netmarkets.wp.ixb.util.WPIxbHndHelper;

import wt.epm.structure.EPMDescribeLink;
import wt.facade.ixb.IxbElement;
import wt.fc.Persistable;
import wt.introspection.LinkInfo;
import wt.introspection.WTIntrospector;
import wt.part.WTPartDescribeLink;
import wt.part.WTPartReferenceLink;
import wt.part.WTPartUsageLink;
import wt.util.WTException;

/**
 * The Class ProductStructureView.
 */
public class ProductStructureView extends PackageView<MemoryObject> {

	private static final Logger LOG = Logger.getLogger(ProductStructureView.class.getName());
	
    /** The zip content. */
    private final WPZipContent zipContent;

    /** The type icon cache. */
    private final TypeIconCache typeIconCache;

    /** If the delivery glyph column should be displayed. */
    private final boolean displayDeliveryGlyphColumn;

    private ViewAttributeService attributeService;
    /**
     * Instantiates a new product structure view.
     *
     * @param zipContent the zip content
     * @param typeIconCache the type icon cache
     * @throws WTException the wT exception
     */
    ProductStructureView(WPZipContent zipContent, TypeIconCache typeIconCache, boolean displayDeliveryGlyphColumn) throws WTException {
        super(zipContent);
        this.zipContent = zipContent;
        this.typeIconCache = typeIconCache;
        this.displayDeliveryGlyphColumn = displayDeliveryGlyphColumn;
        Persistable packageObject = zipContent.getPackageMemoryObject().getObjectReference().getObject();
        this.attributeService = new ViewAttributeService(AttributeService.getAttribute(packageObject, "KB_PACKAGE_PROFILE"), this);
        populate();
    }

    @Override
    protected Comparator<Member<MemoryObject>> getCircularMemberComparator() {
        return ViewTreeHelper.getCircularMemberComparatorForMemoryObjects();
    }

    @Override
    protected String getFileName() {
        return "productStructure";
    }

    @Override
    protected String getViewLabelKey() {
        return wpIxbResource.VIEW_LABEL_FOR_PRODUCT_STRUCTURE_TABLE;
    }

    @Override
    int getColumnIndexToPlaceStructureIn() {
        return displayDeliveryGlyphColumn ? 2 : 1;
    }

    @Override
    protected String[] getTableHeaderColumnLabels(LocalizedResourceCache localizedResources) throws WTException {
        List<String> tableHeaderLabels = new ArrayList<String>();

        if (this.displayDeliveryGlyphColumn) {
            tableHeaderLabels.add(null); // Object Delivery Status Glyph
        }
        tableHeaderLabels.add(null); //VIEW_TABLE_TYPE_ICON
        tableHeaderLabels.add(localizedResources.getLabel(wpIxbResource.TABLE_COLUMN_NUMBER_LABEL));
        
        tableHeaderLabels.add(null); // VIEW_TABLE_I_ICON
       /* tableHeaderLabels.add("level");
        tableHeaderLabels.add("revision");
        tableHeaderLabels.add(localizedResources.getLabel(wpIxbResource.TABLE_COLUMN_NAME_LABEL));
        if(WPIxbHndHelper.isOrganizationDisplayEnabled()) {
            tableHeaderLabels.add(WPIxbHndHelper.getOrgIDDisplayLabel());
        }
        tableHeaderLabels.add(localizedResources.getLabel(wpIxbResource.TABLE_COLUMN_VERSION_LABEL));
        tableHeaderLabels.add(localizedResources.getLabel(wpIxbResource.TABLE_COLUMN_CONTEXT_LABEL));*/
        tableHeaderLabels.addAll(attributeService.getTableHeaders());
        return tableHeaderLabels.toArray(new String[tableHeaderLabels.size()]);
    }

    @Override
    protected Collection<Member<MemoryObject>> getTreeMembers() throws WTException {
        return null;
    }

    @Override
    protected Collection<Link<MemoryObject>> getTreeMemberLinks() throws WTException {
        List<Link<MemoryObject>> parentChildLinks = new ArrayList<>();

        parentChildLinks.addAll(getLinkForClass(WTPartUsageLink.class));
        parentChildLinks.addAll(getLinkForClass(WTPartReferenceLink.class));
        parentChildLinks.addAll(getLinkForClass(EPMDescribeLink.class));
        parentChildLinks.addAll(getLinkForClass(WTPartDescribeLink.class));
        return parentChildLinks;
    }

    private List<Link<MemoryObject>> getLinkForClass(Class cls) throws WTException {
        TypeIdentifier linkTi = TypeHelper.getTypeIdentifier(cls);
        LinkInfo linkInfo = WTIntrospector.getLinkInfo(cls);

        String parentRoleName = linkInfo.getRoleA().getName();
        String childRoleName = linkInfo.getRoleB().getName();

        Collection<String> fileNamesForLinks = this.zipContent.getMetaDataFileNamesDescendedFrom(linkTi);
        List<Link<MemoryObject>> parentChildLinks = new ArrayList<>(fileNamesForLinks.size());

        for (String fileName : fileNamesForLinks) {
            MemoryLink memLink = this.zipContent.getMemoryLinkByFileName(fileName);
            Set<MemoryObject> childObjs = memLink.getMemberObjectsByRole(childRoleName);
            for (MemoryObject parentObj : memLink.getMemberObjectsByRole(parentRoleName)) {
                if (childObjs.size() > 1) {
                    Link<MemoryObject> link = new Link<>(new ProductStructureMember(parentObj), new ProductStructureMemberMaster(childObjs.iterator().next()));
                    parentChildLinks.add(link);
                    for (MemoryObject childObj : childObjs) {
                        link = new Link<>(new ProductStructureMember(childObj), null);
                        parentChildLinks.add(link);
                    }
                } else {
                    for (MemoryObject childObj : childObjs) {
                        Link<MemoryObject> link = new Link<>(new ProductStructureMember(parentObj), new ProductStructureMember(childObj));
                        parentChildLinks.add(link);
                    }
                }
            }
        }
        return parentChildLinks;
    }

    /**
     * The Class ProductStructureMember.
     */
    class ProductStructureMemberMaster extends TableMember {

        /**
         * Instantiates a new product structure member.
         *
         * @param mObj the m obj
         */
        protected ProductStructureMemberMaster(MemoryObject mObj) {
            super(mObj);
        }

        @Override
        public String[] initCompatableValue() {
            return new String[] {
                    getBackingObject().getNumber(),
                    getBackingObject().getName()
            };
        }

        @Override
        protected IxbElement[] getColumnData(LocalizedResourceCache localizedResources) throws WTException {
            List<IxbElement> columnData = new ArrayList<IxbElement>(8);

            if (displayDeliveryGlyphColumn) {
                columnData.add(null);
            }

            columnData.add(getColumnDataMasterTypeIcon(getBackingObject(), typeIconCache, localizedResources.getLocale()));
            columnData.add(getNewIxbElement("span", getBackingObject().getNumber()));
            columnData.add(null);
            columnData.add(getNewIxbElement("span", getBackingObject().getName()));
            if(WPIxbHndHelper.isOrganizationDisplayEnabled()) {
                columnData.add(getNewIxbElement("span", getBackingObject().getOwningOrganization()));
            }
            columnData.add(null);
            columnData.add(getNewIxbElement("span", getBackingObject().getContainerName()));

            return columnData.toArray(new IxbElement[columnData.size()]);
        }

    }

    /**
     * The Class ProductStructureMember.
     */
    class ProductStructureMember extends TableMember {

        /**
         * Instantiates a new product structure member.
         *
         * @param mObj the m obj
         */
        protected ProductStructureMember(MemoryObject mObj) {
            super(mObj);
        }

        @Override
        public String[] initCompatableValue() {
            return new String[] {
                    getBackingObject().getNumber(),
                    getBackingObject().getName(),
                    getBackingObject().getRevision(),
                    getBackingObject().getIteration(),
                    getBackingObject().getView(),
                    getBackingObject().getFileName()
            };
        }

        @Override
        protected IxbElement[] getColumnData(LocalizedResourceCache localizedResources) throws WTException {
            List<IxbElement> columnData = new ArrayList<IxbElement>();
            attributeService.setMemoryObject(getBackingObject());
            if (displayDeliveryGlyphColumn) {
                columnData.add(InteractiveManifest.getObjectDeliveryStatusGlyph(zipContent, localizedResources, getBackingObject()));
            }

            columnData.add(getColumnDataTypeIcon(getBackingObject(), typeIconCache, localizedResources.getLocale()));
            columnData.add(getNewIxbElement("span", getBackingObject().getNumber()));
            columnData.add(getColumnDataDetailsIcon(getBackingObject(), localizedResources));
            /*columnData.add(getNewIxbElement("span", getBackingObject().getRevision()));
            columnData.add(getNewIxbElement("span", getBackingObject().getRevision()));
            columnData.add(getNewIxbElement("span", getBackingObject().getName()));
            if(WPIxbHndHelper.isOrganizationDisplayEnabled()) {
                columnData.add(getNewIxbElement("span", getBackingObject().getOwningOrganization()));
            }
            columnData.add(getNewIxbElement("span", getVersion(getBackingObject(), localizedResources)));
            columnData.add(getNewIxbElement("span", getBackingObject().getContainerName()));*/

            columnData.addAll(attributeService.getTableData());
            return columnData.toArray(new IxbElement[columnData.size()]);
        }

    }

}