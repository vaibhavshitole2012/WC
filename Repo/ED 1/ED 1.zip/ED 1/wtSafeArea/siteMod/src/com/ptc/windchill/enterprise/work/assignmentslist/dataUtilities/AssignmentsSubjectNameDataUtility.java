/* bcwti
 *
 * Copyright (c) 2010 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */

package com.ptc.windchill.enterprise.work.assignmentslist.dataUtilities;

import java.util.Collections;
import java.util.List;
import java.util.Locale;

import org.apache.log4j.Logger;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.dataUtilities.NameNumberDataUtility;
import com.ptc.core.components.rendering.GuiComponent;
import com.ptc.core.components.rendering.guicomponents.AttributeGuiComponent;
import com.ptc.core.components.rendering.guicomponents.GUIComponentArray;
import com.ptc.core.components.rendering.guicomponents.NmActionGuiComponent;
import com.ptc.core.components.rendering.guicomponents.TextDisplayComponent;
import com.ptc.core.components.rendering.guicomponents.UrlDisplayComponent;
//import com.ptc.windchill.enterprise.workflow.guicomponents.UrlDisplayComponent;
import com.ptc.core.ui.validation.ActionValidationDataUtilityHelper;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmURLFactoryBean;
import com.ptc.netmarkets.util.misc.NetmarketURL;
import com.ptc.netmarkets.util.misc.NmAction;
import com.ptc.windchill.enterprise.work.assignmentslist.server.CachedAttrForAssignments;

import wt.access.AccessControlHelper;
import wt.access.AccessControlServerHelper;
import wt.access.AccessPermission;
import wt.access.NotAuthorizedException;
import wt.access.agreement.AuthorizationAgreement;
import wt.annotation.AnnotationSet;
import wt.change2.WTChangeActivity2;
import wt.change2.WTChangeInvestigation;
import wt.change2.WTChangeIssue;
import wt.change2.WTChangeOrder2;
import wt.change2.WTChangeProposal;
import wt.change2.WTChangeRequest2;
import wt.change2.WTVariance;
import wt.doc.WTDocument;
import wt.enterprise.Managed;
import wt.epm.EPMDocument;
import wt.fc.Named;
import wt.fc.WTObject;
import wt.fc.WTReference;
import wt.identity.IdentityFactory;
import wt.inf.container.WTContained;
import wt.inf.library.WTLibrary;
import wt.log4j.LogR;
import wt.maturity.PromotionNotice;
import wt.org.WTUser;
import wt.part.WTPart;
import wt.pdmlink.PDMLinkProduct;
import wt.services.ac.DefaultServices;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.WTRuntimeException;
import wt.workflow.delegate.AssignmentSubjectNameGUIDelegate;
import wt.workflow.work.WorkItem;
import com.ptc.windchill.enterprise.work.assignmentslist.server.AssignmentsTableUtilityHelper;


/**
 * AssignmentsSubjectNameDataUtility is the data utility class for Assignments subject Name column in the table UI.
 *
 */
public class AssignmentsSubjectNameDataUtility extends NameNumberDataUtility {

	private static final String ACCESS_RESOURCE = "wt.access.accessResource";
	private static final String WORKFLOW_RESOURCE = "com.ptc.netmarkets.work.workResource";
	CachedAttrForAssignments objCachedAttrForAssignments;
	private static final Logger log;
    private ModelContext modelContext;

	static {
		try {
			log = LogR.getLogger(AssignmentsSubjectNameDataUtility.class.getName());
		} catch (Exception e) {
			throw new ExceptionInInitializerError(e);
		}
	}

	public AssignmentsSubjectNameDataUtility() {

	}

	/**
	 * Data utility method for initialising contents of Table rows.
	 *
	 * @param component_id
	 *            'id' attribute of the table.
	 * @param datum
	 *            row object of the table.
	 * @param mc
	 *            ModelContext object.
	 * @throws WTException
	 */
	public void setModelData(String component_id, List Object,
			ModelContext mc) throws WTException {

		objCachedAttrForAssignments = AssignmentsTableUtilityHelper.getCachedAttrForAssignmentsInstance(Object);

	}

	@Override
	public Object getDataValue(final String componentId, final Object datum, final ModelContext mc)
            throws WTException
	{
                modelContext=mc;
                //locale = mc.getNmCommandBean() == null ? Locale.getDefault() : mc.getNmCommandBean().getLocale();
                return  handleAssignmentSubject(componentId, datum, mc);       

    }
	

	/*
	 * Handle ASSIGNMENT_SUBJECT
	 */
	private Object handleAssignmentSubject(String component_id, Object datum,ModelContext mc)
			throws WTException {
	    Object result=null;
		AttributeGuiComponent displayComp = new TextDisplayComponent("");
		GUIComponentArray gui = new GUIComponentArray();
        if (log.isDebugEnabled()) {
                log.debug(
                        "In AssignmentsSubjectNameDataUtility.getDataValue() > handleAssignmentSubject() : objCachedAttrForAssignments = "
                                + objCachedAttrForAssignments);
            }
        
		try {
			if (datum instanceof WorkItem) {
				WorkItem currentWorkItem = (WorkItem) datum;
				result = getWorkItemSubjectDisplayName(currentWorkItem,component_id);
			}
			else {
				AssignmentSubjectNameGUIDelegate delegate = (AssignmentSubjectNameGUIDelegate) DefaultServices.getService(datum, AssignmentSubjectNameGUIDelegate.class, "DEFAULT");
				if (delegate != null){
					displayComp = (AttributeGuiComponent) delegate.getAssignmentSubjectGUI((WTObject) datum);
					gui.addGUIComponent(displayComp);
	                result=gui;
				}
			}
		}
		catch (Exception e) {
			if (e instanceof wt.access.NotAuthorizedException)
				throw new WTRuntimeException(e); // The framework will render it as secured information when it catches this exception
			log.error("Some proble fetching object for " + datum);
		}
		if(result==null){
            result = gui;            
        }

		return result;

	}

	public Object getWorkItemSubjectDisplayName(WorkItem currentWorkItem,String component_id)
			throws WTException {
	    GUIComponentArray gui = new GUIComponentArray();
		AttributeGuiComponent guiComp = null;

		Locale currentLocale = SessionHelper.manager.getLocale();

		try {

			WTObject businessObject = null;
			// Disabling auditing of the NOT_AUTHORIZED event as we are handling NotAuthorizedException in catch block.
			AccessControlServerHelper.disableNotAuthorizedAudit();

			WTUser user = (WTUser) SessionHelper.manager.getPrincipal();

			try {
                WTReference brof = currentWorkItem.getPrimaryBusinessObject();
                 if (brof != null && brof.getKey().getClassname() != null){
                     businessObject = (WTObject) objCachedAttrForAssignments.getFromSourceCache(brof);
                     if(businessObject==null)
                         businessObject = (WTObject) brof.getObject();
                 }            
			 } catch (Exception e) {
			     e.printStackTrace();
			 }

			if (businessObject == null) {
				guiComp = new TextDisplayComponent("");
				gui.addGUIComponent(guiComp);
			}
			else
			{
				if ((!AccessControlHelper.manager.hasAccess(user, businessObject, AccessPermission.READ)))
				{
					String str = WTMessage.getLocalizedMessage(ACCESS_RESOURCE, wt.access.accessResource.SECURED_INFORMATION, null, SessionHelper.getLocale());
					TextDisplayComponent textComp = new TextDisplayComponent(str);
					textComp.setValue(str);
					guiComp = textComp;
					gui.addGUIComponent(guiComp);

				}
				else if (businessObject instanceof WTContained) {
				    gui.addGUIComponent(getURLObject(businessObject,currentWorkItem,component_id));
				} else {
					// Subject is a suprise
					String label = businessObject.getDisplayIdentity().getDisplayIdentifier().getLocalizedMessage(currentLocale);
					guiComp = new TextDisplayComponent(label);
					gui.addGUIComponent(guiComp);
				}

			}

		}
		catch (WTRuntimeException rte) {
			// runtime exceptions are thrown if the subject has been deleted
			// or the user doesn't have acces to the PBO
			log.debug("AssignmentsSubjectNameDataUtility.getWorkItemSubjectDisplayName- User does not have access to PBO or it has been deleted");
			String str = "";
			TextDisplayComponent textComp = new TextDisplayComponent(str);
			if (rte.getNestedThrowable() instanceof NotAuthorizedException) {
				str = WTMessage.getLocalizedMessage(ACCESS_RESOURCE, wt.access.accessResource.SECURED_INFORMATION, null, SessionHelper.getLocale());
			} else if (rte.getNestedThrowable() instanceof wt.fc.ObjectNoLongerExistsException) {
				str = WTMessage.getLocalizedMessage(WORKFLOW_RESOURCE, com.ptc.netmarkets.work.workResource.INVALID_REFERENCE, null, SessionHelper.getLocale());
			} else {
				log.error("Exception while getting Work Item subject display name..", rte);
			}
			textComp.setValue(str);
			guiComp = textComp;
			gui.addGUIComponent(guiComp);
		}
		finally {
			// Re-enable auditing after processing the exception
			AccessControlServerHelper.reenableNotAuthorizedAudit();
		}

		return gui;
	}

	public GuiComponent getURLObject(WTObject wtObject,WorkItem currentWorkItem,String component_id) throws WTException {

	    Object obj=null;
		log.debug("::DEBUG :: Entering AssignmentsSubjectNameDataUtility.getURLObject()");
		String label = "";
		GuiComponent guiComp = null;
		Object modelObject= modelContext.getModelObject();
        modelContext.setModelObject(currentWorkItem);
        ActionValidationDataUtilityHelper validation_bean = new ActionValidationDataUtilityHelper("object", "view");
        validation_bean.validate(Collections.singletonList((Object)wtObject), modelContext);
        setValidationBean(component_id, validation_bean);
        String myLabel = getLabel(wtObject);
        log.debug("::DEBUG :: myLabel " + myLabel);
        
        label = wtObject.getDisplayIdentity().getLocalizedMessage(SessionHelper.manager.getLocale());
        if (myLabel != null && !label.contains(myLabel))
            label += "," + myLabel;
        log.debug("::DEBUG :: label " + label);
        
        Object hyperLinkObj=createHyperlink(component_id,currentWorkItem,modelContext,label);  
        
        log.debug("::DEBUG :: hyperLinkObj " + hyperLinkObj);
        
        if(hyperLinkObj instanceof NmAction){
            NmActionGuiComponent actionComponent = new NmActionGuiComponent((NmAction) hyperLinkObj);
            actionComponent.setInternalValue(label);
            guiComp=actionComponent;
            log.debug("::DEBUG :: Returning actionComponent for the subject " + wtObject);
            log.debug("::DEBUG :: actionComponent " + actionComponent);
        } else
        {
        NmOid contentOid = new NmOid(wtObject.getPersistInfo().getObjectIdentifier());
        NmURLFactoryBean urlFactoryBean = new NmURLFactoryBean();
        urlFactoryBean.setRequestURI(NetmarketURL.BASEURL);
        String link = NetmarketURL.buildURL(urlFactoryBean, NmAction.Type.OBJECT, NmAction.Command.VIEW, contentOid, null);
        boolean checkXSS = true;
        if (wtObject instanceof AnnotationSet) {
            link = NetmarketURL.buildURL(urlFactoryBean, "pdmObject", "CLASSICPIE", contentOid, null);
            checkXSS = false; //pop up action
        }
        log.debug("::DEBUG :: Returning URL for the link " + link);
        //guiComp = com.ptc.netmarkets.projmgmt.NmProjMgmtHelper.getUrlDisplayComponent(label, link, checkXSS);
        UrlDisplayComponent displayPboLink = new UrlDisplayComponent(label, label, link);
        displayPboLink.setCheckXSS(checkXSS);
        guiComp = displayPboLink;
        log.debug("::DEBUG :: Returning URL for the subject " + wtObject);
        }
        log.debug("::DEBUG :: Exiting AssignmentsSubjectNameDataUtility.getURLObject()");
        return guiComp;
    }

	private static String getLabel(WTObject wtObject)throws WTException {
		String myLabel = null;

		if (wtObject instanceof WTPart) {
			myLabel = ((WTPart) wtObject).getName();
		} else if (wtObject instanceof WTDocument) {
			myLabel = ((WTDocument) wtObject).getName();
		} else if (wtObject instanceof EPMDocument) {
			myLabel = ((EPMDocument) wtObject).getName();
		} else if (wtObject instanceof PDMLinkProduct) {
			myLabel = ((PDMLinkProduct) wtObject).getName();
		} else if (wtObject instanceof WTLibrary) {
			myLabel = ((WTLibrary) wtObject).getName();
		} else if (wtObject instanceof WTChangeIssue) {
			myLabel = ((WTChangeIssue) wtObject).getName();
		} else if (wtObject instanceof WTChangeOrder2) {
			myLabel = ((WTChangeOrder2) wtObject).getName();
		} else if (wtObject instanceof WTChangeRequest2) {
			myLabel = ((WTChangeRequest2) wtObject).getName();
		} else if (wtObject instanceof WTChangeActivity2) {
			myLabel = ((WTChangeActivity2) wtObject).getName();
		} else if (wtObject instanceof WTChangeProposal) {
			myLabel = ((WTChangeProposal) wtObject).getName();
		} else if (wtObject instanceof WTChangeInvestigation) {
			myLabel = ((WTChangeInvestigation) wtObject).getName();
		} else if (wtObject instanceof PromotionNotice) {
			myLabel = ((PromotionNotice) wtObject).getName();
		} else if (wtObject instanceof WTVariance) {
			myLabel = ((WTVariance) wtObject).getName();
		} else if (wtObject instanceof AnnotationSet) {
			myLabel = ((AnnotationSet) wtObject).getName();
			//link = NetmarketURL.buildURL(urlFactoryBean, "pdmObject", "CLASSICPIE", contentOid, null);
		} else if (wtObject instanceof AuthorizationAgreement) {
			myLabel = ((AuthorizationAgreement) wtObject).getName();
		} else if (wtObject instanceof Managed) {
			myLabel = ((Managed) wtObject).getName();
		} else if (wtObject instanceof Named) {
			myLabel = ((Named) wtObject).getName();
		} else if (wtObject instanceof WTContained) {
			myLabel = IdentityFactory.getDisplayIdentity(wtObject).getLocalizedMessage(SessionHelper.manager.getLocale());
		}

		return myLabel;
	}
	
	@Override
    protected String getColumnId() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    protected GuiComponent createInputComponent(String component_id,
            Object datum, ModelContext mc) throws WTException {
        // TODO Auto-generated method stub
        return null;
    }

}
