package com.ptc.netmarkets.object.mvc.builders;

import com.ptc.jca.mvc.components.AbstractJcaComponentConfig;
import com.ptc.jca.mvc.components.JcaColumnConfig;
import com.ptc.jca.mvc.components.JcaComponentParams;
import com.ptc.mvc.components.AbstractComponentBuilder;
import com.ptc.mvc.components.ColumnConfig;
import com.ptc.mvc.components.ComponentBuilder;
import com.ptc.mvc.components.ComponentConfig;
import com.ptc.mvc.components.ComponentConfigFactory;
import com.ptc.mvc.components.ComponentParams;
import com.ptc.mvc.components.TableConfig;
import com.ptc.mvc.util.ClientMessageSource;
import com.ptc.netmarkets.model.NmObjectHelper;
import com.ptc.netmarkets.util.beans.NmClipboardBean;
import com.ptc.netmarkets.util.beans.NmClipboardItemInfo;
import com.ptc.netmarkets.util.beans.NmClipboardUtility;
import com.ptc.netmarkets.util.beans.NmHelperBean;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import wt.fc.Persistable;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerRef;
import wt.log4j.LogR;
import wt.part.WTPartUsageLink;
import wt.session.SessionServerHelper;
import wt.util.WTException;

@ComponentBuilder({"netmarkets.object.clipboard"})
public class ClipboardTableBuilder extends AbstractComponentBuilder {
    private final ClientMessageSource messageSource = this.getMessageSource("com.ptc.netmarkets.util.beans.beansResource");
    private static final Logger log = LogR.getLogger(ClipboardTableBuilder.class.getName());
    private static final String USAGE_LINK_TYPE = WTPartUsageLink.class.getName();
    protected List<String> excludeTypes;

    public ClipboardTableBuilder() {
        this.excludeTypes = Arrays.asList(USAGE_LINK_TYPE);
    }

    public List buildComponentData(ComponentConfig componentConfig, ComponentParams componentParams) throws WTException {
        NmHelperBean nmHelperBean = ((JcaComponentParams) componentParams).getHelperBean();
        NmClipboardBean nmClipboardBean = nmHelperBean.getNmClipboardBean();
        NmClipboardUtility.validateClipboardItems(nmClipboardBean);
        return this.filterInflatedClipboardItems(nmClipboardBean);
    }

    public ComponentConfig buildComponentConfig(ComponentParams componentParams) throws WTException {
        NmHelperBean nmHelperBean = ((JcaComponentParams) componentParams).getHelperBean();
        nmHelperBean.getRequest().setAttribute("showContextInfo", "false");
        ComponentConfigFactory componentConfigFactory = this.getComponentConfigFactory();

        TableConfig tableConfig = componentConfigFactory.newTableConfig();
        tableConfig.setId("clipboardList");
        tableConfig.setTypes(new String[]{Persistable.class.getName()});
        tableConfig.setLabel(this.messageSource.getMessage("3"));
        ((AbstractJcaComponentConfig) tableConfig).setDescriptorProperty("variableRowHeight", true);
        tableConfig.setActionModel("clipboard_toolbar");
        tableConfig.setSelectable(true);
        tableConfig.addComponent(componentConfigFactory.newColumnConfig("clipboard_mostRecent", true));
        tableConfig.addComponent(componentConfigFactory.newColumnConfig("clipboard_clippingReason", true));
        tableConfig.addComponent(componentConfigFactory.newColumnConfig("clipboard_type_icon", true));
        tableConfig.addComponent(componentConfigFactory.newColumnConfig("clipboard_number", this.messageSource.getMessage("4"), true));
        tableConfig.addComponent(componentConfigFactory.newColumnConfig("orgid", true));
        ColumnConfig columnConfigVersion = componentConfigFactory.newColumnConfig("version", this.messageSource.getMessage("6"), true);
        columnConfigVersion.setNeed("iterationDisplayIdentifier");
        tableConfig.addComponent(columnConfigVersion);
        ColumnConfig columnConfigBackingVersion = componentConfigFactory.newColumnConfig("backingVersionOid", false);
        columnConfigBackingVersion.setDataUtilityId("clipboardVersionColumn");
        columnConfigBackingVersion.setDataStoreOnly(true);
        tableConfig.addComponent(columnConfigBackingVersion);
        ColumnConfig columnConfigActions = componentConfigFactory.newColumnConfig("nmActions", false);
        ((JcaColumnConfig) columnConfigActions).setDescriptorProperty("actionModel", "clipboard_row_actions");
        tableConfig.addComponent(columnConfigActions);
        ColumnConfig columnConfigName = componentConfigFactory.newColumnConfig("clipboard_name", this.messageSource.getMessage("8"), true);
        columnConfigName.setNeed("name");
        tableConfig.addComponent(columnConfigName);
        tableConfig.addComponent(componentConfigFactory.newColumnConfig("download_permission","Download Permission", true));

        boolean showThumbnail = true;
        WTContainer wtContainer = this.getViewingContainer(nmHelperBean);
        if (wtContainer != null) {
            WTContainerRef wtContainerRef = WTContainerRef.newWTContainerRef(wtContainer);
            showThumbnail = NmClipboardUtility.isShowThumbnailEnabled(wtContainerRef);
        } else {
            showThumbnail = NmClipboardUtility.isShowThumbnailEnabled((WTContainerRef) null);
        }

        if (showThumbnail) {
            ColumnConfig columnConfigThumbnail = componentConfigFactory.newColumnConfig("clipboard_thumbnail", this.messageSource.getMessage("9"), true);
            columnConfigThumbnail.setNeed("thumbnail");
            columnConfigThumbnail.setExactWidth(true);
            ((JcaColumnConfig) columnConfigThumbnail).setDescriptorProperty("justify", "center");
            tableConfig.addComponent(columnConfigThumbnail);
        }

        ColumnConfig columnConfigDescription = componentConfigFactory.newColumnConfig("clipboard_description", this.messageSource.getMessage("10"), true);
        columnConfigDescription.setNeed("description");
        tableConfig.addComponent(columnConfigDescription);
        ColumnConfig columnConfigContainerName = componentConfigFactory.newColumnConfig("clipboard_parent", this.messageSource.getMessage("11"), true);
        columnConfigContainerName.setNeed("containerName");
        tableConfig.addComponent(columnConfigContainerName);
        tableConfig.setHelpContext("ClipboardTableRef");
        tableConfig.setView("/netmarkets/object/clipboard_table.jsp");
        if (log.isDebugEnabled()) {
            log.debug("Configured tableConfig : " + tableConfig);
        }

        return tableConfig;
    }

    protected List<NmClipboardItemInfo> filterInflatedClipboardItems(NmClipboardBean var1) throws WTException {
        List inflatedClipboardItems = NmObjectHelper.service.getInflatedClipboardItems(var1);
        ArrayList list = new ArrayList();
        if (log.isDebugEnabled()) {
            log.debug("Objects list before filtering: " + inflatedClipboardItems);
        }

        Iterator iterator = inflatedClipboardItems.iterator();

        while (iterator.hasNext()) {
            Object o = iterator.next();
            if (log.isDebugEnabled()) {
                log.debug("Clipboard item to check: " + o);
            }

            if (o instanceof NmClipboardItemInfo) {
                NmClipboardItemInfo nmClipboardItemInfo = (NmClipboardItemInfo) o;
                if (nmClipboardItemInfo.getPersistable() == null) {
                    if (log.isDebugEnabled()) {
                        log.debug("Clipboard items persistable is null.");
                    }
                } else if (this.excludeTypes.contains(nmClipboardItemInfo.getPersistable().getClass().getName())) {
                    if (log.isDebugEnabled()) {
                        log.debug("Clipboard item have excluded type: " + nmClipboardItemInfo.getPersistable().getClass().getName());
                    }
                } else {
                    if (log.isDebugEnabled()) {
                        log.debug("Clipboard item added to filtered list.");
                    }

                    list.add(nmClipboardItemInfo);
                }
            }
        }

        if (log.isDebugEnabled()) {
            log.debug("Objects list after filtering: " + list);
        }

        return list;
    }

    private WTContainer getViewingContainer(NmHelperBean var1) throws WTException {
        WTContainer wtContainer = null;
        boolean accessEnforced = SessionServerHelper.manager.setAccessEnforced(false);

        try {
            wtContainer = var1.getNmCommandBean().getViewingContainer();
        } finally {
            SessionServerHelper.manager.setAccessEnforced(accessEnforced);
        }

        return wtContainer;
    }
}
