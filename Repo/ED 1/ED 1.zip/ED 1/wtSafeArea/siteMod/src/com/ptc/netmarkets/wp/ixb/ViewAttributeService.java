/**
 * 
 */
package com.ptc.netmarkets.wp.ixb;

import com.ptc.generic.iba.AttributeService;
import com.ptc.netmarkets.wp.ixb.WPZipContent.MemoryLink;
import com.ptc.netmarkets.wp.ixb.WPZipContent.MemoryObject;
import ext.kb.dynamiclist.naming.CoatingCatalogueEnumerationInfoProvider;
import ext.kb.dynamiclist.naming.MaterialCatalogueEnumerationInfoProvider;
import ext.kb.dynamiclist.naming.NameCatalogueEnumerationInfoProvider;
import ext.kb.namecatalogue.NameCatalogueLanguage;
import ext.kb.util.KBConstants;
import ext.kb.util.KBDocumentUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import wt.facade.ixb.IxbElement;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.part.WTPart;
import wt.part.WTPartUsageLink;
import wt.util.WTException;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @author bankowskie
 *
 */
public class ViewAttributeService {
	
	private static final Logger LOG = Logger.getLogger(ViewAttributeService.class.getName());
	
	private static final String HTML = "HTML";
	private static final String SUPPL = "SUPPL";
	PackageView view;
	String packageProfile;
	MemoryObject memo;
	Map<String, Boolean> profileGroup = new HashMap<>();
	List<Attribute> attributes = new ArrayList<>();
	
	public ViewAttributeService(String packageProfile, PackageView view) {
		this.packageProfile = packageProfile;
		this.view = view;
		profileGroup.put("PROFILE_CUSTOMER_DOCUMENTATION", false);
		profileGroup.put("PROFILE_MANUFACTURING_DOCUMENTATION", true);
		profileGroup.put("PROFILE_PURCHASING_DOCUMENTATION", true);
		profileGroup.put("PROFILE_TECHNICAL_WRITER_DOCUMENTATION", true);
		profileGroup.put("PROFILE_TOT_DOCUMENTATION", false);
		profileGroup.put("PROFILE_ALL", true);
		profileGroup.put("", false);
		profileGroup.put(null, false);
		attributes.add((new Attribute("KB_DOCUMENT_ID", false){
            @Override
            public String getDisplayValue() {
                return "Document ID";
            }
        }));
		attributes.add(new Attribute("Version", false) {
			@Override
			public String getDisplayValue() {
				return "Version";
			}
			
			@Override
			public String getValue() {
				StringBuilder displayVersion = new StringBuilder();
		        displayVersion.append(memo.getRevision());
		        String iteration = memo.getIteration();
	            if (iteration != null && !iteration.isEmpty()) {
	                displayVersion.append('.');
	                displayVersion.append(iteration);
	            }
	            if(displayVersion.toString().equalsIgnoreCase("null"))
	                return "";
	            else
	                return displayVersion.toString();
			}
		});
		attributes.add(new Attribute("Revision", false) {
			@Override
			public String getValue() {
				return memo.getRevision();
			}
			
			@Override
			public String getDisplayValue() {
				return "Revision";
			}
		});
		attributes.add(new Attribute("KB_INTERNAL_REVISION", false));
		attributes.add(new Attribute("state.state", false));
		attributes.add(new Attribute("Find Number", false) {
			@Override
			public String getValue() {
				try {
					Persistable parentObject = getParentObject();
					if(parentObject != null && parentObject instanceof WTPart) {
						WTPartUsageLink usageLink = getUsageLink(parentObject);
						return usageLink != null ? usageLink.getFindNumber() : StringUtils.EMPTY;
					}
				} catch(WTException e) {
					
				}
				return StringUtils.EMPTY;
			}
	
			@Override
			public String getDisplayValue() {
				return name;
			}
		});
		attributes.add(new Attribute("Reference Designator", false) {
			@Override
			public String getValue() {
				try {
					Persistable parentObject = getParentObject();
					if(parentObject != null && parentObject instanceof WTPart) {
						WTPartUsageLink usageLink = getUsageLink(parentObject);
						return usageLink != null ? getReferenceDesignatorRange(usageLink) : StringUtils.EMPTY;
					}
				} catch(WTException e) {
					
				}
				return StringUtils.EMPTY;
			}
	
			private String getReferenceDesignatorRange(WTPartUsageLink link) {
				Object attribute = AttributeService.getAttribute(link, "referenceDesignatorRange");
				return attribute != null ? attribute.toString() : StringUtils.EMPTY;
			}
			
			@Override
			public String getDisplayValue() {
				return name;
			}
		});
		attributes.add(new Attribute("Electrical Reference", false) {
			@Override
			public String getValue() {
				try {
					Persistable parentObject = getParentObject();
					if(parentObject != null && parentObject instanceof WTPart) {
						WTPartUsageLink usageLink = getUsageLink(parentObject);
						return usageLink != null ? getElectricalReference(usageLink) : StringUtils.EMPTY;
					}
				} catch(WTException e) {
					
				}
				return StringUtils.EMPTY;
			}
			
			private String getElectricalReference(WTPartUsageLink link) {
				Object attribute = AttributeService.getAttribute(link, "KB_ELECTR_REF");
				return attribute != null ? attribute.toString() : StringUtils.EMPTY;
			}
	
			@Override
			public String getDisplayValue() {
				return name;
			}
		});
		attributes.add(new Attribute("Free Text", false) {
			@Override
			public String getValue() {
				try {
					Persistable parentObject = getParentObject();
					if(parentObject != null && parentObject instanceof WTPart) {
						WTPartUsageLink usageLink = getUsageLink(parentObject);
						return usageLink != null ? getFreeText(usageLink) : StringUtils.EMPTY;
					}
				} catch(WTException e) {
					
				}
				return StringUtils.EMPTY;
			}
	
			private String getFreeText(WTPartUsageLink link) {
				Object attribute = AttributeService.getAttribute(link, "KB_FREE_TEXT");
				return attribute != null ? attribute.toString() : StringUtils.EMPTY;
			}
			
			@Override
			public String getDisplayValue() {
				return name;
			}
		});
		attributes.add(new Attribute("Quantity", false) {
			@Override
			public String getValue() {
				try {
					Persistable parentObject = getParentObject();
					if(parentObject != null && parentObject instanceof WTPart) {
						WTPartUsageLink usageLink = getUsageLink(parentObject);
						return usageLink != null ? String.valueOf(usageLink.getQuantity().getAmount()) : StringUtils.EMPTY;
					}
				} catch(WTException e) {
					
				}
				return StringUtils.EMPTY;
			}
	
			@Override
			public String getDisplayValue() {
				return name;
			}
		});
		attributes.add(new Attribute("defaultUnit", false));
		attributes.add(new Attribute("KB_DOC_CONTENT_TYPE", false) {
			@Override
			public String getValue() {
				try {
					String attribute = AttributeService.getAttribute(findConcreteObjectInMemory(), name);
					if(attribute == null) return StringUtils.EMPTY;
					TreeMap<String, String> docContentEnum = KBDocumentUtils.getEnumerationKeysAndValues(KBConstants.DOC_CONTENT_TYPE_ENUMERATION);
					String displayValue = docContentEnum != null ? docContentEnum.get(attribute) : StringUtils.EMPTY;
					return displayValue != null? displayValue : StringUtils.EMPTY;
				} catch (WTException e) {
					LOG.error("Unable to get doc content type", e);
				}
				return StringUtils.EMPTY;
			}
		});
		attributes.add(new Attribute("KB_LANGUAGE", false));
		attributes.add(new Attribute("KB_DESCRIPTION_EN", false));
		attributes.add(new Attribute("KB_DESCRIPTION2_EN", false));
		attributes.add(new Attribute("KB_TRANSLATION_ID", false) {
			@Override
			public String getValue() {
				Object attribute = AttributeService.getAttribute(findConcreteObjectInMemory(), name);
				String lang = NameCatalogueLanguage.getKBLanguagePreference();
				return attribute != null ? NameCatalogueEnumerationInfoProvider
						.getNameCatalogueEnumerationInfoProvider()
						.getNamingEntryNameById((String)attribute, lang) : StringUtils.EMPTY;
			}
		});
		attributes.add(new Attribute("KB_TRANSLATION2_ID", false) {
			@Override
			public String getValue() {
				Object attribute = AttributeService.getAttribute(findConcreteObjectInMemory(), name);
				String lang = NameCatalogueLanguage.getKBLanguagePreference();
				return attribute != null ? NameCatalogueEnumerationInfoProvider
						.getNameCatalogueEnumerationInfoProvider()
						.getNamingEntryNameById((String)attribute, lang) : StringUtils.EMPTY;
			}
		});
		attributes.add(new Attribute("KB_ECT_NUMBER_ALIAS", true));
		attributes.add(new Attribute("KB_SUPPL_TEXT", false));
		attributes.add(new Attribute("KB_ADDIT_TEXT", false));
		attributes.add(new Attribute("KB_TYPE_DESIGNATION", false));
		attributes.add(new Attribute("KB_DEPARTMENT_CALCULATED", false));
		attributes.add(new Attribute("KB_MATERIAL", true) {
			@Override
			public String getValue() {
				Object attribute = AttributeService.getAttribute(findConcreteObjectInMemory(), name);
				return attribute != null ? new MaterialCatalogueEnumerationInfoProvider()
						.getMaterialNameByKey((String)attribute)  : StringUtils.EMPTY;
			}
		});
		attributes.add(new Attribute("KB_MATERIAL_ADDITIONAL", true));
		attributes.add(new Attribute("KB_MAT_CLASS", true));
		attributes.add(new Attribute("KB_SURFACE", true) {
			@Override
			public String getValue() {
				Object attribute = AttributeService.getAttribute(findConcreteObjectInMemory(), name);
				return attribute != null ? getValues(((String)attribute).split(";"))  : StringUtils.EMPTY;
			}
			
			public String getValues(String[] attrs) {
				StringBuilder valueBuilder = new StringBuilder();
				CoatingCatalogueEnumerationInfoProvider provider = new CoatingCatalogueEnumerationInfoProvider();
				for(String attr : attrs) {
					valueBuilder.append(provider.getNameByKey((String)attr)).append(" ");
				}
				return valueBuilder.toString();
			}
		});
		attributes.add(new Attribute("KB_ROHS", true));
		attributes.add(new Attribute("KB_TOLERANCE", true));
		attributes.add(new Attribute("KB_CCC", true));
		attributes.add(new Attribute("KB_BOND_CLASS", true));
		attributes.add(new Attribute("KB_WELD_CLASS", true));
		attributes.add(new Attribute("KB_WEIGHT", false));
		attributes.add(new Attribute("KB_WEIGHT_UNIT", false));
	}
	
	public void setMemoryObject(MemoryObject memo) {
		this.memo = memo;
	}
	
	public List<String> getTableHeaders() {
		return attributes.stream()
						 .filter(Attribute::shouldBeVisible)
						 .map(Attribute::getDisplayValue)
						 .collect(Collectors.toList());
	}
	
	public List<IxbElement> getTableData() {		
		return attributes
				.stream()
				.filter(Attribute::shouldBeVisible)
				.map(attr -> {
					 try {
						 String value = attr.getValue();
						 LOG.debug("Returning value: " + value + " of attr: "+ attr.getDisplayValue());
						return view.getNewIxbElement("span", value);
					 } catch (WTException e) {
						
					 }
					 return null;})
				.collect(Collectors.toList());
	}
			
	private Persistable findConcreteObjectInMemory() {
		Persistable object = memo.getObjectReference().getObject();
		LOG.debug("Found object in memory: "+object.getIdentity());
		return object;
	}
	
	public int getLevel(MemoryObject memo) {
		LOG.debug("About to get level of " + memo.getName());
		int level = 0;
		List<MemoryLink> relatedLinks = memo.getRelatedLinks();
		LOG.debug("relatedLinks = " + relatedLinks);
		relatedLinks = removeDuplicates(relatedLinks); // remove duplicates
		LOG.debug("removed duplicates. relatedLinks = " + relatedLinks);
		if (relatedLinks.isEmpty())
			return level;
		for (MemoryLink link : relatedLinks) {
			if (memo.getObjectReference().getObject() instanceof WTPart) {
				Set<MemoryObject> parentObjects = link.getParentObjects();
				LOG.debug("Found part, will go through parents");
				level = goThroughParents(memo, level, parentObjects);
			} else {
				Set<MemoryObject> otherSideObjects = link.getOtherSideObjects(memo);
				LOG.debug("Found non-part, will go thourgh parents of related WTParts");
				for (MemoryObject otherSideObject : otherSideObjects) {
					if (otherSideObject.getObjectReference().getObject() instanceof WTPart) {
						return getLevel(otherSideObject) + 1;
					}
				}
			}
		}
		return level;
	}

	private List<MemoryLink> removeDuplicates(List<MemoryLink> relatedLinks) {
		ArrayList<MemoryLink> filteredLinks = new ArrayList<>();
		for (MemoryLink memoryLink : relatedLinks) {
			if (filteredLinks.isEmpty()) {
				filteredLinks.add(memoryLink);
			} else {
				boolean isInFilteredList = false;
				for (MemoryLink filteredLink : filteredLinks) {
					if (filteredLink.isEqualsTo(memoryLink)) {
						isInFilteredList = true;
						break;
					}
				}
				if (!isInFilteredList) {
					filteredLinks.add(memoryLink);
				}
			}
		}
		return filteredLinks;
	}

	private int goThroughParents(MemoryObject memo, int level, Set<MemoryObject> parentObjects) {
		LOG.debug("Going through parents of " + memo.getName() + ", current level: "+ level);
		while(!parentObjects.isEmpty()) {
			Set<MemoryObject> newParents = new HashSet<>();
			for(MemoryObject parent : parentObjects) {
				if(!memo.equals(parent) && parent.getObjectReference().getObject() instanceof WTPart) {
					LOG.debug("Found valid parent " + parent.getName());
					LOG.debug("Increasing level and gathering parents of parent.");
					level ++;
					newParents.addAll(gatherPotentialParents(parent));
				}
			}
			parentObjects = newParents;
		}
		return level;
	}

	private Set<MemoryObject> gatherPotentialParents(MemoryObject parent) {
		Set<MemoryObject> newParents = new HashSet<>();
		List<MemoryLink> parentLinks = parent.getRelatedLinks();
		for(MemoryLink parentLink : parentLinks) {
			Set<MemoryObject> potentialParents = parentLink.getParentObjects();
			for(MemoryObject potentialParent : potentialParents) {
				if(!parent.equals(potentialParent) && potentialParent.getObjectReference().getObject() instanceof WTPart) {
					LOG.debug("Adding potential parent: " + potentialParent.getName() + " of "+parent.getName());
					newParents.add(potentialParent);
				}
			}
		}
		return newParents;
	}
	
	private class Attribute {
		String name;
		boolean isSuppl;
		
		public Attribute(String name, boolean isSuppl) {
			this.name = name;
			this.isSuppl = isSuppl;
		}
		
		public String getValue() {
			Object attribute = AttributeService.getAttribute(findConcreteObjectInMemory(), name);
			
			return attribute != null ? concatValue(attribute) : StringUtils.EMPTY;

		}
		
		private String concatValue(Object attribute) {
			StringBuilder builder = new StringBuilder();
			if(attribute.getClass().isArray()) {
				Object[] arr = (Object[]) attribute;
				for(Object obj : arr) {
					builder.append(obj.toString() + " ");
				}
			} else {
				builder.append(attribute.toString());
			}
			return builder.toString();
		}

		public String getDisplayValue() {
			List<String> typesToCheck = Arrays.asList(
					"com.ptc.KBAssemblyComponent", 
					"com.ptc.KBTechnicalDocument", 
					"com.ptc.KBTestReport", 
					"com.ptc.KBTechnicalDrawing", 
					"com.ptc.DesignCADDoc");
			Optional<String> maybeDisplayValue = typesToCheck.stream()
							   .map(type -> AttributeService.getAttributeDisplayValue(type, name))
							   .filter(Objects::nonNull)
							   .findFirst();
			return maybeDisplayValue.isPresent() ? maybeDisplayValue.get() : StringUtils.EMPTY;
		}

		public boolean shouldBeVisible() {
			boolean shouldBeVisible = isSuppl ? profileGroup.get(packageProfile) : true;
			LOG.debug(this.name + " should be visible? " + shouldBeVisible);
			return shouldBeVisible;
		}
		
		public Persistable getParentObject() {
			List<MemoryLink> relatedLinks = memo.getRelatedLinks();
			for(MemoryLink link : relatedLinks) {
				if("uses".equals(link.getRoleByMemberObject(memo))
				   && link.getFileName().contains("WTPartUsageLink")) {
					Set<MemoryObject> otherSideObjects = link.getOtherSideObjects(memo);
					if(otherSideObjects.iterator().hasNext()) {
						return otherSideObjects.iterator().next().getObjectReference().getObject();	
					}
				} 
			}
			return null;
		}
				
		public WTPartUsageLink getUsageLink(Persistable parentObject) throws WTException {
			LOG.debug("Looking for usage links related to "+parentObject.getIdentity());
			QueryResult qr = PersistenceHelper.manager.navigate(((WTPart)findConcreteObjectInMemory()).getMaster() , WTPartUsageLink.USED_BY_ROLE, WTPartUsageLink.class, false);
			while(qr.hasMoreElements()) {
				WTPartUsageLink foundUsageLink = (WTPartUsageLink) qr.nextElement();
				if(foundUsageLink.getUsedBy().equals(parentObject)) {
					LOG.debug("Returning found usage link " + foundUsageLink.getIdentity());
					return foundUsageLink;
				}		
			}
			return null;
		}

	}
}
