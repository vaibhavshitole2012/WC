package ext.kb.datautility;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import wt.pdmlink.PDMLinkProduct;
import wt.projmgmt.execution.ProjectWorkItem;
import wt.workflow.work.WorkItem;

import com.ptc.core.components.factory.dataUtilities.DefaultDataUtility;

public class DataUtilityHelperTest {

    @Test
    public void testGetProperty() {
        assertTrue(DataUtilityHelper.getProperty("catalina.home").endsWith("tomcat"));
        assertEquals("", DataUtilityHelper.getProperty("random.property"));
        
    }

    @Test
    public void testValidObjectType() {
        
        DefaultDataUtility d = new DefaultDataUtility();
        assertTrue(DataUtilityHelper.isValidObjectType(WorkItem.class, new ProjectWorkItem().getClass(), d));
        assertFalse(DataUtilityHelper.isValidObjectType(WorkItem.class, new PDMLinkProduct().getClass(), d));
    }

}
