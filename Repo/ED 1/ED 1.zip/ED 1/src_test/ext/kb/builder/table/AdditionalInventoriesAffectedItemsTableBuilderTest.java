package ext.kb.builder.table;

import static org.junit.Assert.*;

import org.junit.Test;

import com.ptc.core.htmlcomp.tableview.ConfigurableTable;

import ext.kb.enumconstant.InventoryDispositions;
import ext.kb.tableview.AdditionalInventoriesChangeTaskAffectedItemsTableViews;

public class AdditionalInventoriesAffectedItemsTableBuilderTest {

	AdditionalInventoriesAffectedItemsTableBuilder builder = new AdditionalInventoriesAffectedItemsTableBuilder();
	
	@Test
	public void testGetDispositionComponentIds() {
		assertEquals(InventoryDispositions.ALL_DISPOSITIONS.size(), builder.getDispositionComponentIds().size());
	}

	@Test
	public void testBuildConfigurableTable() throws Exception {
		ConfigurableTable table = builder.buildConfigurableTable("");
		if (!AdditionalInventoriesChangeTaskAffectedItemsTableViews.class.getName().equals(table.getClass().getName()))
			throw new RuntimeException("Table view is not correct");
	}

}
