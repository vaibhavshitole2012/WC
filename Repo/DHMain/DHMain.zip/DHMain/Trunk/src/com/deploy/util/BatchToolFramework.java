package com.deploy.util;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.Appender;
import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Layout;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;

import com.ptc.core.meta.type.mgmt.server.impl.WTTypeDefinition;

import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.collections.WTArrayList;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerHelper;
import wt.inf.container.WTContainerRef;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.org.WTPrincipal;
import wt.pds.StatementSpec;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.util.WTProperties;
import wt.vc.Iterated;
import wt.vc.IterationInfo;

// TODO: Auto-generated Javadoc
/**
 * The Class BatchToolFramework.
 */
public abstract class BatchToolFramework implements RemoteAccess {
	
	/**
	 * The tool class name.
	 */
	protected static String toolClassName;

	/**
	 * The tool usage information.
	 */
	protected String usage = "Not implemented yet!";
	
	/**
	 * The args.
	 */
	protected String[] args;
	
	/**
	 * The logger.
	 */
	protected static Logger logger = null;

	/**
	 * Instantiates a new batch tool framework.
	 *
	 * @param args the args
	 */
	public BatchToolFramework(String[] args) {
		this.args = args;
	}

	public Map<String, String> arguments = new HashMap<String, String>();
	
	/**
	 * The main method.
	 *
	 * @param args the arguments
	 * @throws Exception the exception
	 */
	public static void main(String[] args) throws Exception {
		
		// initialize logger and static field
		toolClassName = getInvokedClassname();
		logger = Logger.getLogger(toolClassName);
		Layout layout = new PatternLayout("%m%n");
		Appender console = new ConsoleAppender(layout);
		logger.addAppender(console);
		Level level = Level.INFO;
		logger.setLevel(level);
		// create an instance of batch tool class
		Class<?> batchToolClass = Class.forName(toolClassName);
		Constructor<?> toolConstructor = batchToolClass
				.getDeclaredConstructor(new Class[] { String[].class });
		Object toolInstance = toolConstructor
				.newInstance(new Object[] { args });
		Method runMethod = batchToolClass.getMethod("run", new Class[]{});
		// invoke the method containing tool's business logic
		runMethod.invoke(toolInstance, new Object[]{});
	}

	/**
	 * Run.
	 */
	public void run() throws Exception {
		logger.info(toolClassName + " is starting...");
		if ((!validateArgs()) || (!validateCredentials())) {
			printUsage();
			logger.info(toolClassName + " ends with status 1");
			System.exit(1);
		}
		initializeArgsMap();

		// Authenticate to Windchill as wcadmin
		String login = arguments.get("-u")==null?args[0]:arguments.get("-u");
		String password = arguments.get("-p")==null?args[1]:arguments.get("-p");
		authenticate(login, password);

		// start processing part
		process();
		logger.info(toolClassName + " is ending with status 0");
		System.exit(0);
	}

	/**
	 * Authenticate.
	 *
	 * @param username the username
	 * @param password the password
	 */
	private void authenticate(String username, String password) {
		RemoteMethodServer remoteMethodServer = RemoteMethodServer.getDefault();
		remoteMethodServer.setUserName(username);
		remoteMethodServer.setPassword(password);
		try {
			WTPrincipal currentUser = SessionHelper.manager.getPrincipal();
			WTContainerRef siteContainerRef = WTContainerHelper.service
					.getExchangeRef();
			if (siteContainerRef != null
					&& WTContainerHelper.service.isAdministrator(
							siteContainerRef, currentUser)) {
				return;
			}
			logger.info("Invalid user! " + toolClassName
					+ " may be launched by Windchill Administrator only \n"
					+ toolClassName + " ends with status 1");
			System.exit(1);
		} catch (WTException e) {
			logger.error("Authentication failed! " + e.getLocalizedMessage()
					+ "\n" + toolClassName + " ends with status 1");
			logger.error(" Exception :" + e.toString());
			System.exit(1);
		}
	}

	/**
	 * Gets the tool classname.
	 *
	 * @return the tool classname
	 */
	public String getToolClassname() {
		return toolClassName;
	}

	/**
	 * Process.
	 */
	public abstract void process() throws Exception;

	/**
	 * Prints the usage.
	 */
	protected void printUsage() {
		System.out.println(usage);
	}

	/**
	 * Validate args.
	 *
	 * @return true, if successful
	 */
	protected abstract boolean validateArgs();

	/**
	 * Validate credentials.
	 *
	 * @return true, if successful
	 */
	private boolean validateCredentials() {
		if (args.length >= 2) {
			return true;
		}
		logger.warn("First two parameters should be Windchill login and password!");
		return false;
	}

	/**
	 * Gets the invoked classname.
	 *
	 * @return the invoked classname
	 * @throws Exception the exception
	 */
	private static String getInvokedClassname() throws Exception {
		// use reflection in order to hide the restricted access to
		// sun.misc.VMSupport class
		Class<?> vmSupportClass = Class.forName("sun.misc.VMSupport");
		Method getAgentPropertiesMethod = vmSupportClass.getMethod(
				"getAgentProperties", new Class[]{});
		Properties agentProperties = (Properties) getAgentPropertiesMethod
				.invoke(null, new Object[]{});
		return agentProperties.get("sun.java.command").toString().split(" ")[0];
	}

	/**
	 * Query softype.
	 *
	 * @param classObject the class object
	 * @param softType the soft type
	 * @return the list
	 * @throws WTException the wT exception
	 */
	protected WTArrayList querySoftype(Class<? extends Object> classObject, String softType)
			throws WTException {
		QueryResult typeresult = null;
		if (softType != null && !softType.equals("")) {
			QuerySpec typespec = new QuerySpec(WTTypeDefinition.class);
			typespec.appendWhere(new SearchCondition(WTTypeDefinition.class,
					WTTypeDefinition.NAME, SearchCondition.EQUAL, softType), new int[]{0});
			typeresult = PersistenceHelper.manager
					.find((StatementSpec) typespec);
		}
		// if the type exists, proceed for searching related objects
		WTArrayList foundObjects = new WTArrayList();
		while (typeresult != null && typeresult.hasMoreElements()) {
			WTTypeDefinition typedef = (WTTypeDefinition) typeresult
					.nextElement();
			QuerySpec objectspec = new QuerySpec(classObject);
			objectspec.appendWhere(new SearchCondition(classObject,
					"typeDefinitionReference.key", SearchCondition.EQUAL,
					typedef.getPersistInfo().getObjectIdentifier()),  new int[]{0});
			objectspec.appendAnd();
			objectspec.appendWhere(new SearchCondition(classObject,
					Iterated.ITERATION_INFO + "." + IterationInfo.LATEST,
					SearchCondition.IS_TRUE), new int[]{0});
			foundObjects.addAll(PersistenceHelper.manager
					.find((StatementSpec) objectspec));
		}
		if (softType == null || softType.equals("")) {
			QuerySpec objectspec = new QuerySpec(classObject);
			objectspec.appendWhere(new SearchCondition(classObject,
					Iterated.ITERATION_INFO + "." + IterationInfo.LATEST,
					SearchCondition.IS_TRUE), new int[]{0});
			foundObjects.addAll(PersistenceHelper.manager
					.find((StatementSpec) objectspec));
		}
		return foundObjects;
	}

	protected void initializeArgsMap() {
		if (args.length % 2 == 0) {
			for (int i = 0; i < args.length; i++) {
				arguments.put(args[i++], args[i]);
			}
		}
	}

	protected static WTContainer queryContainerByName(String containerName)
			throws WTException {
		QuerySpec queryContainers = new QuerySpec(WTContainer.class);
		queryContainers.appendWhere(new SearchCondition(WTContainer.class,
				WTContainer.NAME, SearchCondition.EQUAL, containerName),
				new int[] { 0 });
		QueryResult foundContainers = PersistenceHelper.manager
				.find((StatementSpec) queryContainers);
		if (foundContainers.size() > 1) {
			throw new WTException("More than one container found!");
		} else if (foundContainers.size() == 0) {
			throw new WTException("Container not found!");
		}
		return (WTContainer) foundContainers.nextElement();
	}
	
	protected static BufferedReader getFile(String filePath) throws FileNotFoundException{
		BufferedReader br = new BufferedReader(new FileReader(filePath));
		return br;
	}


	@SuppressWarnings("rawtypes")
	public void executeOnBGMS( String className, String methodName, Class[] clsArray,Object[] objArray) throws IOException, InvocationTargetException {
		URL serverURL = WTProperties.getServerCodebase();
		String serviceName = "BackgroundMethodServer";
		RemoteMethodServer remoteMethodServer = RemoteMethodServer.getInstance(serverURL, serviceName);
		remoteMethodServer.setUserName(args[0]);
		remoteMethodServer.setPassword(args[1]);
		remoteMethodServer.invoke(methodName, className, null, clsArray, objArray);
	}

	
}
