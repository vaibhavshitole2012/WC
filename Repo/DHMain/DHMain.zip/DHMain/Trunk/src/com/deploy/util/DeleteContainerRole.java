package com.deploy.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import wt.inf.container.WTContainer;
import wt.inf.team.ContainerTeam;
import wt.inf.team.ContainerTeamHelper;
import wt.inf.team.ContainerTeamManaged;
import wt.org.WTPrincipalReference;
import wt.project.Role;
import wt.util.WTException;

public class DeleteContainerRole extends BatchToolFramework {

	public DeleteContainerRole(String[] args) {
		super(args);
		usage = "Usage: ext.mtb.batchtools.DeleteContainerRole <login> <password> <containerName> <containerRoleNames>\n"
				+ "- delete roles from specific container.\n"
				+ "<login> - login of Windchill administrator\n"
				+ "<password> - password of Windchill administrator\n"
				+ "<containerPath> - Path to file with Containers name\n"
				+ "<containerRolePath> - Path to file with Roles name\n"
				+ "EXAMPLE: windchill com.deploy.util.DeleteContainerRole wcadmin <password> \"/opt/ptc/wt111/windchill/tmp/ContainerTemplateUpdater/container.txt\" \"/opt/ptc/wt111/windchill/tmp/ContainerTemplateUpdater/roles.txt\"\n";
	}

	@Override
	public void process() throws IOException, WTException {

		File folder = new File("/opt/ptc/wt111/windchill/extension/ContainerTemplateUpdater");
		if (!folder.exists()) {
		folder.mkdir();
		}

		File file = new File("/opt/ptc/wt111/windchill/extension/ContainerTemplateUpdater/principalFromRoles.txt");
		if (!file.exists()) {
		file.createNewFile();
		}
		WTContainer container = null;
		Role role = null;
		BufferedWriter writer = new BufferedWriter(new FileWriter(file));
			BufferedReader containerFile = null;
			BufferedReader rolesFile = null;
				containerFile = getFile(args[2]);
				rolesFile = getFile(args[3]);
				String containerName = null;
				String roleName = null;
				while ((containerName = containerFile.readLine()) != null) {
					try {
					String[] line = containerName.split(",");
					containerName = line[0];
					container = queryContainerByName(containerName);
					logger.info("Container: " + container.getDisplayIdentity());
					} catch (WTException e1) {
					e1.printStackTrace();
					logger.error("Invalid container name: " + args[2]);
					logger.error(" Exception :" + e1.toString());
					System.exit(1);
					}
					writer.append(containerName + ";" + '\n');
					rolesFile = getFile(args[3]);
					while ((roleName = rolesFile.readLine()) != null) {
						try {
						role = Role.toRole(roleName.trim());
						writer.append(roleName + ":");
						ContainerTeam containerTeam = ContainerTeamHelper.service.getContainerTeam((ContainerTeamManaged)container);
						ArrayList allPrincipalsForTarget = containerTeam.getAllPrincipalsForTarget(role);
						for(Object principal : allPrincipalsForTarget){
							WTPrincipalReference user = (WTPrincipalReference) principal;
							String userName = user.getName();
							writer.append(userName + ",");
						}
						writer.newLine();
						logger.info("Role: " + role.getDisplay());
					} catch (Exception e1) {
						e1.printStackTrace();
						logger.error("Invalid role name: " + roleName);
						logger.error(" Exception :" + e1.toString());
						System.exit(1);
					}
						try {
							ContainerTeam containerTeam = (ContainerTeam) ContainerTeamHelper.service
									.getContainerTeam((ContainerTeamManaged) container);
							ContainerTeamHelper.service.removeRole(containerTeam, role);
						} catch (WTException e) {
							logger.error("Unable to remove the role " + role.getDisplay()
									+ " from container: " + container.getName());
							logger.error(" Exception :" + e.toString());
							System.exit(1);
						}
				}
					writer.newLine();
		}
				writer.close();
	}


	@Override
	protected boolean validateArgs() {
		if (args.length == 4) {
			return true;
		} else {
			return false;
		}
	}

}
