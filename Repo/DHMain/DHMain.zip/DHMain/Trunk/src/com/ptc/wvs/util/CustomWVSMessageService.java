package com.ptc.wvs.util;

import java.io.Serializable;
import java.util.Iterator;
import java.util.Set;
import java.util.HashSet;
import java.util.StringTokenizer;

import com.ptc.wvs.common.util.WVSProperties;
import com.ptc.wvs.common.ui.Publisher;
import wt.lifecycle.LifeCycleServiceEvent;
import wt.services.ServiceEventListenerAdapter;
import wt.services.ManagerException;
import wt.services.StandardManager;
import wt.services.ManagerService;
import wt.services.StandardManagerServiceEvent;
import wt.wvs.WVSLogger;
import wt.util.WTException;
import wt.fc.Persistable;
import wt.doc.WTDocument;
import wt.epm.EPMDocument;
import wt.events.KeyedEvent;
import wt.fc.ReferenceFactory;
import wt.fc.collections.WTCollection;
import wt.lifecycle.LifeCycleManaged;
import wt.vc.config.ConfigSpec;

public class CustomWVSMessageService extends StandardManager implements WVSMessageService, Serializable {

    private static final String CLASSNAME = CustomWVSMessageService.class.getName();
    private static final WVSLogger logger = WVSLogger.getLogger(CustomWVSMessageService.class, WVSLogger.PUBLISH_GROUP);
    private static final long serialVersionUID = 1L;

    private static Set<String> lifecycles = new HashSet<String>();
    private static String lifecycleList = WVSProperties.getPropertyValue("publish.service.notifyOnException.enable");

	@SuppressWarnings("deprecation")
    public String getConceptualClassname() { return CLASSNAME; }

	private static boolean isNotifyOnException() {
		if ( lifecycleList != null && lifecycleList.length() > 0 ) {
			return true;
		}
		return false;
	}

    private static Set<String> getLifecycles() {
		try {
			if ( lifecycleList != null && lifecycleList.trim().length() > 0 ) {
				StringTokenizer tok = new StringTokenizer(lifecycleList.trim(), ",");
				while (tok.hasMoreTokens()) {
					lifecycles.add(tok.nextToken().toUpperCase());
				}				
			}			
		} catch (Exception e) {
			System.out.println("ERROR: getLifecycles()");
			e.printStackTrace();
		}
		return lifecycles;
    }

   protected void performStartupProcess() throws ManagerException
   {
      super.performStartupProcess();
      getManagerService().addEventListener(
         new ServiceEventListenerAdapter(this.getConceptualClassname()) {
            public void notifyVetoableMultiObjectEvent( Object event ) {

				boolean notifyOnException = isNotifyOnException();
				if(!(event instanceof KeyedEvent) || !notifyOnException) return;
				KeyedEvent eventObject = (KeyedEvent)event;
				Object target = eventObject.getEventTarget ();

                process( (LifeCycleServiceEvent)event, target );
            }
         }, LifeCycleServiceEvent.generateEventKey(LifeCycleServiceEvent.STATE_CHANGE)
      );

      logger.debug("Start Message Service");
   }

   public void shutdown() throws ManagerException {
		super.shutdown();
   }

   public void registerEvents( ManagerService managerService ) {
   }

   public static CustomWVSMessageService newCustomWVSMessageService() throws WTException 
   {
      CustomWVSMessageService instance = new CustomWVSMessageService();
      instance.initialize();
      return instance;
   }

   @SuppressWarnings("rawtypes")
   protected void process(LifeCycleServiceEvent event, Object target) {

      try {
         logger.debug("GOT STATE CHANGE EVENT");
         logger.debug(event);

		 Boolean publishableLifecycle = false;
		 boolean result = false;
		 Publisher pub = new Publisher();
		 ReferenceFactory rf = new ReferenceFactory();

		 // INSERT CUSTOM EVENT PROCESSING HERE
		 if (target instanceof wt.fc.collections.WTCollection) {
			 Iterator objsIt = ((WTCollection)target).persistableIterator();

			 while (objsIt.hasNext()) {
	 			 Persistable p = (Persistable) objsIt.next();
				 String currentState = ((LifeCycleManaged)p).getLifeCycleState().toString();

				 // see if the lifecycle of this object is in the list of valid lifecycles
				 if (getLifecycles().contains(currentState)) {
					 logger.debug("The lifecycle (" + currentState + ") is in the list of valid lifecycles");
					 publishableLifecycle = true;
				 } else {
					 logger.debug("The lifecycle (" + currentState + ") is NOT in the list of valid lifecycles");
 					 publishableLifecycle = false;
				 }

				 if (!publishableLifecycle) continue;

				 String objRef = rf.getReferenceString(p);				 
				 if ( p instanceof EPMDocument ) {
					 EPMDocument epmDoc = (EPMDocument)p;
					 /**
						 * Attempts to publish a Representable generating a Representation
						 *
						 * @param     viewableLink           If true and the data has already been published, the viewable data will be passed back to allow access by getViewableLink
						 * @param     forceRepublish         Overwrites an existing representation should one already exist
						 * @param     objectReference        Reference of the Representable to be published
						 * @param     navigationCriteria     The EPM navigation criteria to be used during the product structure tree walk, if null, as-stored or latest is used.
						 * @param     partNavigationCriteria The Part navigation criteria to be used during the product structure tree walk, if null, latest is used.
						 * @param     defaultRep             Should the created representation be the default or not.  The first representation in always default.
						 * @param     repName                Name of The representation to be created, if null default name will be used
						 * @param     repDescription         Description of the representation to be created , if null no description will be used
						 * @param     structureType          The type of structure walk to be performed, NONE, EPM, PART, EPM_PLUS_PARTS
						 * @param     actionString           Option String, see PublisherAction class, if no options can be null
						 * @param     jobSource              Source that submitted the job, 0=unknown, 1=manual, 2=checkin, 3=schedule
						 *
						 * @return    boolean         true if the representation that the publish job would create already exists (and forceRepublish is false). In this case if viewableLink is true
						 *                            then the information to view the existing representation can be obtained with getViewableLink().  If the publish job has not be submitted because
						 *                            the object being publish was marked not to be published then isMarkedNotPublishable() will return true.  false if the business object does not have
						 *                            a representation already existed.
						 *
						 * <BR><BR><B>Supported API: </B>true
						 *
						 **/					

					 //EPM is EPMDocument structure traversal, for when publishing EPMDocuments
					 result = pub.doPublish(false, true, objRef, (ConfigSpec) null, (ConfigSpec) null, true, null, null, Publisher.EPM, null, 0);
				 }

				 if ( p instanceof WTDocument ) {
					 //NONE is no structure traversal, for when publishnig WTDocuments for example
					 result = pub.doPublish(false, true, objRef, (ConfigSpec) null, (ConfigSpec) null, true, null, null, Publisher.NONE, null, 0);
				 }

			 }
		 }

	  } catch(Exception e) { e.printStackTrace(); }
   }


}
