/*
 *  bcwti
 * 
 *  Copyright (c) 2010 Parametric Technology Corporation (PTC). All Rights
 *  Reserved.
 * 
 *  This software is the confidential and proprietary information of PTC.
 *  You shall not disclose such confidential information and shall use it
 *  only in accordance with the terms of the license agreement.
 * 
 *  ecwti
 */
package com.ptc.generic.userprefs;

import com.ptc.generic.userprefs.UserPrefsHelper;
import com.ptc.generic.userprefs.UserPrefsService;
import com.ptc.generic.userprefs.annotations.InstancePreloadedPreference;
import com.ptc.generic.userprefs.annotations.PreloadedPreference;
import com.ptc.generic.userprefs.annotations.VolatilePreference;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.util.*;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import wt.method.RemoteMethodServer;
import wt.preference.PreferenceDefinition;
import wt.util.WTException;

/**
 * Central class for user preferences management. You should not call
 * any user preferences server side API directly but use this class instead.
 *
 * <b>It manages preferences cache</b> so client does not need to do
 * server calls when accessing same preference again and again.
 * <p>It's implemented as enum to assure only one instance.</p>
 * <p><b>Access via UserPrefsManager.INSTANCE</b></p>
 * <p>
 * <b>You have to declare all user preferences you use in UserPreference enum.</b>
 * It then can be annotated so it's cached or reloaded on every client initialization
 * </p>
 * @see UserPreference
 * @since 4.0
 * @author Marek Piechut <mpiechut@ptc.com>
 */
public enum UserPrefsManager {

    /**
     * Access all methods via this instance
     */
    INSTANCE;
    /**
     * User preferences category name for general ECA preferences
     **/
    private static final Logger logger = Logger.getLogger(UserPrefsManager.class);
    private static final Map<PreferenceIfc, String> PREFS_CACHE = new HashMap<PreferenceIfc, String>();
    private static final boolean SERVER = RemoteMethodServer.ServerFlag;

    /**
     * Initializes cache with pre-loaded data
     */
    static {
        try {
            if (!SERVER) {
                logger.debug("Pre-loading startup preferences");
                preloadPreferences(PreloadedPreference.class);
            }
        } catch (WTException ex) {
            logger.error("Could not pre-load user preferences. No value will be cached on startup", ex);
        }
    }

    /**
     * Searches preferences in user context for given name for ECA client
     * (appending ECA path)
     * Can also retrieve multivalued preference if it was stored in such way.
     * 
     * @param preference Preference to retrieve value for (<b>take from UserPreference</b>)
     * @see UserPreference
     * @return User preference value or it's default value if not found
     */
    public String getUserPreference(PreferenceIfc preference) {
        String name = preference.getName();
        // <editor-fold defaultstate="collapsed" desc="Logging">
        if (logger.isDebugEnabled()) {
            logger.debug("Retrieving value for user preference: " + name + " default value: " + preference.getDefaultValue());
        }// </editor-fold>

        String value = null;

        if (!(isVolatile(preference) || SERVER)) {
            logger.debug("Preference not volatile and on client, will try cache");
            value = PREFS_CACHE.get(preference);
            // <editor-fold defaultstate="collapsed" desc="Logging">
            if (logger.isDebugEnabled()) {
                if(value != null) {
                    logger.debug("Preference found in cache: " + name + " = " + value);
                }
            }// </editor-fold>
        }

        if (value == null) {
            logger.debug("Value not found in cache or volatile. Trying server");
            try {
                value = UserPrefsHelper.service.getUserPreference(name, preference.getClient().name());
            } catch (WTException ex) {
                logger.error("Could not retrieve user preference from server", ex);
            }

            if (value == null || StringUtils.isBlank(value)) {
                logger.debug("No value in cache and on server, returning default");
                value = preference.getDefaultValue();
            }

            if (value != null) {
                // <editor-fold defaultstate="collapsed" desc="Logging">
                if (logger.isDebugEnabled()) {
                    logger.debug("Caching value for preference: " + name + " = " + value);
                }// </editor-fold>
                PREFS_CACHE.put(preference, value);
            }
        }
        return value;
    }

    /**
     * Check if passed user preference is volatile and should not be retrieved
     * from cache but always from server
     *
     * @param preference Preference to check for VolatilePreference annotation
     * @see VolatilePreference
     * @return True if preference should not be taken from cache
     */
    private boolean isVolatile(PreferenceIfc preference) {
        boolean isVolatile = false;
        if (preference instanceof UserPreference) {
            try {
                Field field = UserPreference.class.getField(((UserPreference) preference).name());
                isVolatile = field.isAnnotationPresent(VolatilePreference.class);
            } catch (Exception ex) {
                logger.error("Could not check if property is volatile. Will use caching", ex);
            }
        }

        return isVolatile;
    }

    /**
     * Sets user preference to passed value in current user context and
     * ECA client. Creates new preference if not yet created. It will also
     * update local cache.
     *
     * Name of preferences should be taken from UserPreference enum
     *
     * @see UserPreference
     * @param preference Preference to save value for
     * @param value New value for preference
     * @throws WTException
     */
    public void setUserPreference(PreferenceIfc preference, String value) throws WTException {
        String name = preference.getName();
        // <editor-fold defaultstate="collapsed" desc="Logging">
        if (logger.isDebugEnabled()) {
            logger.debug("Setting user preference: " + name + " to value: " + value);
        }// </editor-fold>

        try {
            // Call the UserPrefsHelper to get the value. 
            UserPrefsHelper.service.setUserPreference(name, preference.getClient().getClientName(), preference.getCategory(), value, preference.getDefaultValue(), PreferenceDefinition.VISIBILITY_USER);
        } catch (WTException ex) {
            logger.error("Could not save user preference to server", ex);
            throw ex;
        }

        if (!(isVolatile(preference) || SERVER)) {
            PREFS_CACHE.put(preference, value);
            logger.debug("Preference cached");
        }
        logger.debug("Preference saved.");
    }

    /**
     * Saves boolean value for user preference. All preferences are stored as
     * Strings in database
     * Calls setUserPreference(UserPreference preference, String value) converting
     * boolean to String first.
     * @param preference preference to save value for
     * @param value new value for preference
     * @throws WTException 
     */
    public void setUserPreference(PreferenceIfc preference, boolean value)
            throws WTException {
        String stringValue = Boolean.toString(value);
        setUserPreference(preference, stringValue);
    }

    /**
     * Pre-loads all preferences declared in UserPreference
     * as PreloadedPreference and puts them in cache
     *
     * @param annotatedWith Preferences marked with this annotation will be pre-loaded
     * @see PreloadedPreference
     * @see UserPreference
     */
    private static void preloadPreferences(Class<? extends Annotation> annotatedWith)
            throws WTException {
        Field[] declaredFields = UserPreference.class.getFields();
        List<PreferenceIfc> preloadedPreferences = new LinkedList<PreferenceIfc>();
        Collection<String> names = new LinkedList<String>();

        for (Field field : declaredFields) {
            if (field.isAnnotationPresent(annotatedWith)) {
                try {
                    UserPreference pref = (UserPreference) field.get(null);
                    preloadedPreferences.add(pref);
                    names.add(pref.getName());
                } catch (Exception ex) {
                    logger.error("Error processing preference " + field.getName() + ". It will not be pre-loaded", ex);
                }
            }
        }

        // <editor-fold defaultstate="collapsed" desc="Logging">
        if (logger.isDebugEnabled()) {
            logger.debug("Querying server for " + names.size() + " preferences");
        }// </editor-fold>
        Map<String, Object> loadedPrefs = UserPrefsHelper.service.getUserPreferences(names, UserPrefsService.ECA_CLIENT_NAME);

        StringBuilder loggingBuilder = new StringBuilder("Caching preferences:\n");

        for (PreferenceIfc pref : preloadedPreferences) {
            Object value = loadedPrefs.get(pref.getName());
            String preferenceString = value == null ? pref.getDefaultValue() : value.toString();
            PREFS_CACHE.put(pref, preferenceString);
            // <editor-fold defaultstate="collapsed" desc="Logging">
            if (logger.isDebugEnabled()) {
                loggingBuilder.append('\t');
                loggingBuilder.append(pref.getName());
                loggingBuilder.append(" : ");
                loggingBuilder.append(value);
                loggingBuilder.append('\n');
            }// </editor-fold>
        }
        // <editor-fold defaultstate="collapsed" desc="Logging">
        if (logger.isDebugEnabled()) {
            logger.debug(loggingBuilder);
            logger.debug("Requested non null preferences cached");
        }// </editor-fold>
    }

    /**
     * Reload preferences marked with InstancePreloadedPreference annotation.
     * This method should be called when new JECLApplet is created.
     *
     * @throws WTException Thrown when server call for preferences thrown an exception
     * @see InstancePreloadedPreference
     */
    public static void reloadInstancePreferences() throws WTException {
        preloadPreferences(InstancePreloadedPreference.class);
    }

    /**
     * This method will delete value for passed user preference on server
     * and local cache in USER context.
     *
     * @see UserPreference
     * @param preference preference that should be deleted
     * @throws WTException when server call failed
     */
    public void deleteUserPreference(PreferenceIfc preference) throws WTException {
        String name = preference.getName();
        // <editor-fold defaultstate="collapsed" desc="Logging">
        if (logger.isInfoEnabled()) {
            logger.info("Removing " + name + " preference value");
        }// </editor-fold>

        UserPrefsHelper.service.deleteUserPreference(name, preference.getClient().getClientName(), true);
        logger.debug("Removed from server");

        PREFS_CACHE.remove(preference);
        logger.debug("Removed from local cache");
    }

    /**
     * Clears cache and reloads all pre-loaded preferences
     */
    public void resetCache() {
        logger.info("Reloading preferences cache");

        logger.debug("Clearing old cache");
        PREFS_CACHE.clear();

        logger.debug("Pre-loading startup preferences");
        try {
            if (!SERVER) {
                preloadPreferences(PreloadedPreference.class);
            }
        } catch (WTException ex) {
            logger.error("Could not pre-load startup preferences. Cache will be filled on preferences request", ex);
        }
    }

    /**
     * Update default value of user preference in database so it's the same as
     * declared in UserPreference (call this after you have changed default
     * in enum and want it updated on server)
     * 
     * @param preference preference to update default value for
     * @param client preference client name
     * @throws WTException
     * 
     * @see UserPrefsService#ECA_CLIENT_NAME
     */
    public void updateDefaultValue(PreferenceIfc preference)
            throws WTException {
        UserPrefsHelper.service.changeDefaultValue(preference.getName(), preference.getCategory().name(),
                preference.getClient().getClientName(), preference.getDefaultValue(), preference.getVisibility());
    }
}