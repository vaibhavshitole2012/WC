package com.ptc.generic.content;


import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Iterator;
import java.util.Vector;

import com.ptc.generic.content.AdvContentService;

import wt.content.ApplicationData;
import wt.content.ContentHelper;
import wt.content.ContentHolder;
import wt.content.ContentItem;
import wt.content.ContentRoleType;
import wt.services.ServiceFactory;
import wt.util.WTException;


public class AdvContentHelper {


   // --- Attribute Section ---


   public static final AdvContentService service = ServiceFactory.getService(AdvContentService.class);


   /**
    * Gets PRIMARY content (ApplicationData) of given ContentHolder
    * @param contentHolder
    * @return
    * @throws WTException
    */
   public static ApplicationData getPrimaryApplicationData(ContentHolder contentHolder) throws WTException {
       ApplicationData primaryApplicationData = null;
       try {
           // get ALL contents of given ContentHolder
           contentHolder = ContentHelper.service.getContents(contentHolder);
           Vector<?> vectorContent = ContentHelper.getContentListAll(contentHolder);
           // navigate through them and get instances of ApplicationData
           for (Iterator<?> it = vectorContent.iterator(); it.hasNext();) {
               ContentItem contentItem = (ContentItem) it.next();
               if (contentItem instanceof ApplicationData) {
                   ApplicationData applicationData = (ApplicationData) contentItem;
                   // if PRIMARY content was found stop looping and return
                   if (ContentRoleType.PRIMARY.equals(applicationData.getRole())) {
                       primaryApplicationData = applicationData;
                       break;
                   }
               }
           }
       } catch (Exception ex) {
           if (ex instanceof WTException)
               throw (WTException) ex;
           else
               throw new WTException(ex);
       }
       return primaryApplicationData;
   }

   /**
    * Compares two primary contents of given ContentHolders.
    * Compare criteria contains two conditions:
    * - modify timestamp
    * - file size
    * @param firstContentHolder
    * @param secondContentHolder
    * @return
    * @throws Exception
    */
   public static boolean compareContentsOfEPMs(ContentHolder firstContentHolder, ContentHolder secondContentHolder)
           throws Exception {
       // get primary contents of given ContentHolders
       ApplicationData applicationDataOne = AdvContentHelper.getPrimaryApplicationData(firstContentHolder);
       ApplicationData applicationDataTwo = AdvContentHelper.getPrimaryApplicationData(secondContentHolder);
       // calculate the result
       return applicationDataOne.getModifyTimestamp().equals(applicationDataTwo.getModifyTimestamp()) && applicationDataOne.getFileSize() == applicationDataTwo.getFileSize();
   }

    private static final int BUFFER_SIZE = 1024;

    /**
     * Saves passed in stream to file on disk.
     * It takes care of buffering so passed in stream can be plain InputStream
     * 
     * <b>stream is closed after finishing</b>
     * @param stream stream to read data from
     * @param output file to save stream to
     * @throws Exception
     * @see BufferedInputStream
     * @see InputStream
     */
    public static void saveFile(InputStream stream, File output) throws Exception {
        byte data[] = new byte[BUFFER_SIZE];
        BufferedInputStream bis = new BufferedInputStream(stream, BUFFER_SIZE);
        BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(output), BUFFER_SIZE);

        try {
            for (int count = bis.read(data, 0, BUFFER_SIZE); count >= 0; count = bis.read(data, 0, BUFFER_SIZE)) {
                bos.write(data, 0, count);
            }
            bos.flush();
        } finally {
            bis.close();
            bos.close();
        }
    }
}
