Installation :
* put the file ReAssignLifeCycle.class in <codebase>/com/ptc/ssp/util/   (create folders first)

To use the tool :
* launch a  "windchill shell" on the server
* type "windchill com.ptc.ssp.util.ReAssignLifeCycle"  
	it will show you the usage

The parameters offered allow to use this tool in an incremental way by launching it many time with different parameters in order to progressivelly 
change the lifecycle of objects in different containers, for different original states, ... You can use a shell commande (.bat or .sh).  


Note : the tool is providing lot of output that allow you to control the result of its execution. Use redirection of the commande line to a file to capture the logs.


Contact : Nicolas Jodet, njodet@ptc.com