package com.ptc.ssp.util;


import java.util.*;

import wt.enterprise.RevisionControlled;
import wt.fc.*;
import wt.inf.container.*;
import wt.lifecycle.*;
import wt.org.WTPrincipal;
import wt.query.*;
import wt.util.*;
import wt.vc.wip.*;

public class ReAssignLifeCycle {


    private static boolean VERBOSE;
    static {
        try {
            VERBOSE = WTProperties.getLocalProperties().getProperty("com.ptc.ssp.util.ReAssignLifeCycle.verbose", false);
        }
        catch (java.io.IOException e) {
            e.printStackTrace();
        }
    }


    public static void main (String[] args) {
   	 Vector v = null;
   	 try {
   		 v = AuthenticationHelper.authenticateUser(args, true); //remove -u .. -p .. -url .. args
   		 if(v==null || v.size()==0) {
   			 throw new WTException("got empty Vector when calling authenitcateUser()");
   		 }
   		 WTPrincipal user = (WTPrincipal)v.elementAt(0);
   		 System.out.println("authenticated as: " + user.getName());
   	 } catch (WTException w) {
   		 System.out.println("could not authenticate user. Exception:" + w.getLocalizedMessage());
   		 w.printStackTrace();
   		 System.exit(1);
   	 }

   	 // init WTContext and set locale
   	 WTContext.init(args);
   	 System.out.println("v.size=" + v.size());


   	 if (v.size() !=7) {
   		 printUsage();
   		 System.exit (1);
   	 }
   	 String typeObj = null;
   	 String actualState = null;
   	 String targetState = null;
   	 String lifecyclename = null;
   	 Boolean forceLatestIteration = null;
   	 String container_path = null;
   	 String classNameStr = null;
   	 String fullTypeName = null;
   	 try {
   		 typeObj = (String)v.elementAt(1);
   		 actualState = (String)v.elementAt(2);
   		 targetState = (String)v.elementAt(3);
   		 lifecyclename = (String)v.elementAt(4);
   		 forceLatestIteration = Boolean.valueOf((String)v.elementAt(5));
   		 container_path = (String)v.elementAt(6);

   		 if (typeObj.equals("PART")) {
   			 classNameStr = "wt.part.WTPart";
   		 } else if (typeObj.equals("CADDOC")) {
   			 classNameStr = "wt.epm.EPMDocument";
   		 } else if (typeObj.equals("DOCUMENT")) {
   			 classNameStr = "wt.doc.WTDocument";
   		 } else if (typeObj.length()!=0) {
   			 //try to interpret given arg as a softtype name
   			 fullTypeName = SoftTypeHelper.getFullTypeName(typeObj);
   			 System.out.println("fullTypeName=" + fullTypeName);
   			 classNameStr = SoftTypeHelper.getWTClassname(fullTypeName);
   			 System.out.println("classNameStr=" + classNameStr);
   		 } else {
   			 printUsage();
   			 System.exit (1);
   		 }
   	 }
   	 catch (Throwable e) {
   		 printUsage();
   		 e.printStackTrace();
   	 }

   	 //calculate vars that are needed by several methods
   	 try {
   		 Class theClass = Class.forName(classNameStr);
   		 WTContainerRef wtcontainerref = WTContainerHelper.service.getByPath(container_path);
   		 if (wtcontainerref == null) {
   			 System.out.println(" ReAssignLifeCycle => ERROR : Container not found.");
   			 return;
   		 }

   		 //search objects where LC should be re-assigned
   		 QueryResult qr = collectObjects(theClass, fullTypeName, wtcontainerref);

   		 //re-assign LC on found objects
   		 reassignLF(wtcontainerref, qr, actualState,targetState,lifecyclename,forceLatestIteration);
   	 } catch(Exception e) {
   		 e.printStackTrace();
   		 System.exit(1);
   	 }
   	 System.exit (1);
    }



    public static void reassignLF( WTContainerRef wtcontainerref, Enumeration qr, String validState, String targetState,
                                    String lifecyclename, Boolean forceLatestIteration) {

        long qrSize=0;
        long processedLFCount=0;
        long processedStateCount=0;
        long notProcessedCount=0;
        long notProcessedCOCount=0;
        long notProcessedErrorCount=0;

        try {
            // Init parameters to do the job
            
            
            
            LifeCycleTemplateReference newLFRef = LifeCycleHelper.service.getLifeCycleTemplateReference(lifecyclename, wtcontainerref) ;
            if (newLFRef == null) {
                System.out.println(" ReAssignLifeCycle => ERROR : LifeCycle not found.");
                return;
            }
            LifeCycleTemplate newLF= (LifeCycleTemplate)newLFRef.getObject();
            if (WorkInProgressHelper.isCheckedOut((Workable)newLF) || WorkInProgressHelper.isWorkingCopy((Workable)newLF)) {
                System.out.println(" ReAssignLifeCycle => ERROR : LifeCycle template is checkedout.");
                return;
            }
            String newLFName = newLFRef.getName();
            Vector newLFStates = LifeCycleHelper.service.findStates((LifeCycleTemplate)newLFRef.getObject());



            // Process objects found in the queryresult
            while (qr.hasMoreElements()) {
                LifeCycleManaged lfmanaged=null;
                boolean error=false;
                String errorMessage=null;
                try {
                    lfmanaged = (LifeCycleManaged)qr.nextElement();
                    String actualState = lfmanaged.getState().toString();
                    printOut(" ReAssignLifeCycle => actualState="+actualState);

				    logInfo("\nINFO : object in process is " + getObjDisplayInfo((RevisionControlled)lfmanaged));
				    // Test if object is checkedout or working copy. If yes log error and skip.
                    if (WorkInProgressHelper.isCheckedOut((Workable)lfmanaged) || WorkInProgressHelper.isWorkingCopy((Workable)lfmanaged)) {
                        logInfo("\tERROR : object is checkedout or is workingcopy.");
                        logInfo("\t\t[NOT PROCESSED] : " + getObjDisplayInfo((RevisionControlled)lfmanaged));
                        notProcessedCOCount++;
                        continue;
                    }

				    // We must process only objects with state equals to validState passed in command or if validState=ALL
				    if (validState.equals("ALL") || actualState.equals(validState)) {
					    lfmanaged = (LifeCycleManaged)PersistenceHelper.manager.refresh(lfmanaged);
					    LifeCycleTemplateReference actualLFTemplate = lfmanaged.getLifeCycleTemplate();
					    String actualLFName = actualLFTemplate.getName();
					    printOut(" ReAssignLifeCycle => actualLFName="+actualLFName);

					    // We must test if the actual lifecycle assigned to the object is the same than the one passed in the command
					    //  and also to check if it's the latest iteration.
					    // We process if : (names are different) or (names are equal and LF obj Ids are different and forceLatestIteration is true)
					    boolean processLF=false;
					    if (!(actualLFName.equals(newLFName))) {
					        logInfo("\tINFO : lifecycle names are different, ready to proceed with new lifecycle.");
					        processLF = true;
					    }
					    else if (!(actualLFTemplate.toString().equals(newLFRef.toString())) &&
					             forceLatestIteration.equals(Boolean.TRUE)) {
					        logInfo("\tINFO : same lifecycle name but object not using latest lifecycle template iteration, ready to proceed with latest iteration.");
					        processLF = true;
					    }
					    else {
					        logInfo("\tINFO : object is already using the latest iteration of the lifecycle, or forceLatestIteration is FALSE.");
					        logInfo("\t\t[NOT PROCESSED] : " + getObjDisplayInfo((RevisionControlled)lfmanaged));
					        notProcessedCount++;
					    }
    					if (processLF) {
					        LifeCycleHelper.service.reassign(lfmanaged, newLFRef);
					        logInfo("\t\t[PROCESSED] : lifecycle [" + newLFName + "] reassigned to object [" + getObjDisplayInfo((RevisionControlled)lfmanaged) +"].");
        					processedLFCount++;
					        if (!targetState.equals("FIRST")) {
					            String newStateStr=targetState.equals("SAME")?actualState:targetState;
					            State newState = State.toState(newStateStr);
					            // test if state is valid for this lifecycle
					            if (!LifeCycleHelper.service.isState((LifeCycleTemplate)newLFRef.getObject(),newState)) {
					                logInfo("\t\t[NOT PROCESSED] : state [" + newStateStr + "]is not valid in new lifecycle.");
					            }
					            // test if state if the first state of the lifecycle. Don't process setLifeCycleState is yes.
					            printOut(" ReAssignLifeCycle => first state of new lifecycle=" + (newLFStates.get(0)).toString());
					            if (!(newLFStates.get(0)).toString().equals(newStateStr)) {
					                // Need to wait in order the workflow launched by the reassgin is running.
					                Thread.sleep(200);

					                LifeCycleHelper.service.setLifeCycleState(lfmanaged,newState,true);
					                logInfo("\t\t[PROCESSED] : state [" + newStateStr + "] set to object [" + getObjDisplayInfo((RevisionControlled)lfmanaged) +"].");
					                processedStateCount++;
					            }
					        }
					    }
				    } // end if(actualState.equals("ALL...
				    else {
				        logInfo("\tINFO : object is not in a state valid for proceeding (based on command parameters).");
				        logInfo("\t\t[NOT PROCESSED] : lifecycle or state not set to " + getObjDisplayInfo((RevisionControlled)lfmanaged));
				        notProcessedCount++;
				    }
				}
				catch (LifeCycleException e) {
				    error=true;
				    errorMessage = e.getLocalizedMessage();
				}
				catch (WTInvalidParameterException e) {
				    error=true;
				    errorMessage = e.getLocalizedMessage();
				}
				finally {
				    if (error) {
				        logInfo("\tERROR : an error occured during reassign of lifecycle or during setState.");
				        logInfo("\t\terror message = " + errorMessage);
				        logInfo("\t\t[NOT PROCESSED] : " + getObjDisplayInfo((RevisionControlled)lfmanaged));
				        notProcessedErrorCount++;
				        continue;  // just for understanding of the code !
				    }
				}
            } // end while
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            logInfo("\nINFO : results");
            logInfo("\t Objects to treat = " + qrSize);
            logInfo("\t Objects with lifecycle reassigned = " + processedLFCount);
            logInfo("\t Objects with state set = " + processedStateCount);
            logInfo("\t Objects not processed because not in scope of command = " + notProcessedCount);
            logInfo("\t Objects not processed because checkedout/workingcopy = " + notProcessedCOCount);
            logInfo("\t Objects not fully processed (lifecycle + state) because of error = " + notProcessedErrorCount);
        }
    } // end public static void reassignLF(...

    //this method could be overwritten by subclasses that have different mechanisms to find the objects that need a new lifecycle
    public static QueryResult collectObjects(Class theClass, String fullTypeName, WTContainerRef wtcontainerref) throws Exception {
       WTContainer container = wtcontainerref.getReferencedContainer();
       // Build the Query to search for appropriate object in appropriate container
       QuerySpec qs = new QuerySpec(theClass);
       if (container != null) {
           ClassAttribute docContainer = new ClassAttribute(theClass,(String)(theClass.getField("CONTAINER_ID").get(null)));
           qs.appendWhere(new SearchCondition(docContainer, SearchCondition.EQUAL, new ConstantExpression(new Long(PersistenceHelper.getObjectIdentifier(container).getId()))), new int[] {0});
           ClassAttribute cl = new ClassAttribute(theClass,(String)(theClass.getField("LATEST_ITERATION").get(null)));
		    RelationalExpression exp = ConstantExpression.newExpression("1",cl.getColumnDescriptor().getJavaType());
		    SearchCondition cond = new SearchCondition(cl,SearchCondition.EQUAL,exp);
		    qs.appendAnd();
		    qs.appendWhere(cond);
       }
       if(fullTypeName!=null && fullTypeName.length()!=0) {
      	 qs = SoftTypeHelper.appendSearchCondition(qs, fullTypeName, true, true, theClass);
       }
       QueryResult qr = PersistenceHelper.manager.find(qs);
       printOut(" ReAssignLifeCycle => qr.size()=" + qr.size());
       return qr;
    }
    
    public static String getObjDisplayInfo(RevisionControlled obj) {
	    //7.0 code : String ret = "[" + obj.getClass().getName() + "] "+ obj.getName() + " [" + obj.getVersionLineage().getValue() + "] " + obj.getState() ;
	   String ret = obj.getIdentity() + " [" + obj.getVersionIdentifier().getValue() + "," + obj.getIterationIdentifier().getValue() + "] " + obj.getState();
	    return ret;
	}


    public static void printOut(String str) {
        if (VERBOSE)
            System.out.println(str);
    }

    private static void logInfo (String message) {
        // TO DO : implement log file
        System.out.println(message);
    }

    protected static void printUsage() {
        System.out.println ("Usage 'windchill com.ptc.ssp.util.ReAssignLifeCycle [PART|CADDOC|DOCUMENT] <actual state to consider | ALL> <target state to set | SAME | FIRST> <new lifecycle name> <force latest lifecycle iteration> <container_path>");
        System.out.println (" Ex 1 :  windchill com.ptc.ssp.util.ReAssignLifeCycle CADDOC INWORK FIRST Default true /wt.inf.container.OrgContainer=PTC/wt.inf.library.WTLibrary=MYLIB ");
        System.out.println (" Ex 2 :  windchill com.ptc.ssp.util.ReAssignLifeCycle PART \"DEFINING REQUIREMENTS\" SAME Default true /wt.inf.container.OrgContainer=PTC/wt.pdmlink.PDMLinkProduct=MYPRODUCT ");
        System.out.println (" Ex 3 :  windchill com.ptc.ssp.util.ReAssignLifeCycle DOCUMENT ALL RELEASED ACME_lifecycle false /wt.inf.container.OrgContainer=PTC/wt.pdmlink.PDMLinkProduct=MYPRODUCT ");
    }

} // end class
