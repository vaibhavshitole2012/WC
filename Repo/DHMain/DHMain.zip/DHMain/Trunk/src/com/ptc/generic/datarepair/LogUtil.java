/**
 * Logging Util for repair Tools
 * @author andrzejn
 */

package com.ptc.generic.datarepair;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Calendar;
import java.util.GregorianCalendar;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.WTProperties;


public class LogUtil {
    //private static BufferedWriter logWriter;
    private static final String RESOURCE = datarepairResource.class.getName();
    protected static BufferedWriter initLogFile(String fileName, String folderName) throws IOException {


        String WT_LOGS = null;
        WTProperties wtprops;
        String logFilePath= null;
        BufferedWriter writer = null;
        try {
            wtprops = WTProperties.getLocalProperties();
            WT_LOGS = wtprops.getProperty("wt.logs.dir");

        } catch (IOException ex) {
            ex.printStackTrace();
        }
        Calendar k = Calendar.getInstance();
        GregorianCalendar gk = new GregorianCalendar();
        File newFolder = new File(WT_LOGS + File.separator + folderName);
        if (newFolder.exists()) {
        } else {
            boolean sucess = new File(WT_LOGS + File.separator + folderName).mkdir();
        }
        logFilePath = WT_LOGS + File.separator + folderName + File.separator + fileName + "-" + gk.get(Calendar.YEAR) + "-" + (gk.get(Calendar.MONTH)+1) + "-" + gk.get(Calendar.DAY_OF_MONTH) + "-" + Integer.toString(k.get(Calendar.HOUR_OF_DAY)) + Integer.toString(k.get(Calendar.MINUTE)) + Integer.toString(k.get(Calendar.SECOND)) + "-log.txt";
        writer = new BufferedWriter(new FileWriter(logFilePath));
            
        return writer;
    }

    protected static void logToFile(String message, BufferedWriter logWriter) {
      
        if (logWriter != null) {
            try {
                logWriter.write(message);
                logWriter.newLine();
            } catch (IOException exception) {
                System.out.println("Unable to write to log file (message='" + message + "')");
            }
        }
    }

    protected static void closeLogFile(BufferedWriter logWriter) {
        if (logWriter != null) {
            try {
                logWriter.close();
            } catch (IOException e) {
                System.out.println("Unable to close log file");
            }
        }
    }

    protected static void logEverywhere(String msg, BufferedWriter logWriter) {
        System.out.println(msg);
        logToFile(msg, logWriter);
    }
    protected  static File getFile(String fileWithFolder) throws WTException {
		File file = new File(fileWithFolder);
		if (!file.exists()) {
			throw new WTException(WTMessage.getLocalizedMessage(RESOURCE, datarepairResource.ERROR_DATA_NOT_EXISTING, new Object[]{fileWithFolder}));
		}
		return file;
	}

	protected static BufferedReader getBufferedReader(String fileWithFolder) throws WTException, FileNotFoundException {
		File file = getFile(fileWithFolder);
		BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
		return reader;
	}
}
