package com.ptc.ssp.wt.identity;

public interface NumberService {

	public String getNumber();
	
}
