package com.ptc.ssp.util;

// java imports
import java.util.*;
import java.util.regex.*;

// windchill imports
import wt.access.*;
import wt.admin.*;
import wt.fc.*;
import wt.lifecycle.*;
import wt.method.*;
import wt.util.*;

/**
 * This class fills a feature gap in Windchill, by allowing one to view all
 * access control rules in a single text file.
 * <br />
 * It output all access control policies for a Windchill system and arranges
 * them by administrative domains.
 * <br />
 * Usage:
 * <br />
 * Execute from a Windchill shell:
 * windchill com.ptc.ssp.util.ACLReportHelper output.txt
 */
public class ACLReportHelper implements RemoteAccess
{
   private static final String DIVIDER = "===========================================================================";
   private static final String CLASS_NAME = ACLReportHelper.class.getName();
   private static final String REGEXP1 = " [+,-] ";
   private static final Pattern PATTERN = Pattern.compile(REGEXP1); 

   /**
    * Gets the access rules for the specified domain ref.
    * @param StandardControlManager accessControlManager - Used to get the access rules.
    * @param AdminDomainRef adminDomainRef - The domain to the the access rules for.
    * @return Enumeration - The access control rules.  Or null if there was an error.
    */
   public static Enumeration getAccessPolicyRules(AdminDomainRef adminDomainRef ) throws WTException {
   	try {
   		if(RemoteMethodServer.ServerFlag)
   			return _getAccessPolicyRules(adminDomainRef);
   		else
   			return (Enumeration)RemoteMethodServer.getDefault().invoke( "_getAccessPolicyRules", CLASS_NAME, null, new Class[] { AdminDomainRef.class }, new Object[] { adminDomainRef });
   	} catch(Exception e) {
   		if(e instanceof WTException) {
   			throw (WTException) e;
   		} else {
   			throw new WTException(e);
   		}
   	}
   }
   public static Enumeration _getAccessPolicyRules( /*StandardAccessControlManager accessControlManager,*/ AdminDomainRef adminDomainRef ) {
   	Enumeration enumeration = null;
   	try {
   		enumeration = AccessControlHelper.manager.getAccessPolicyRules( adminDomainRef );
   	} catch( Exception e ) {
   		e.printStackTrace();
   	}
   	return enumeration;
   }

   /**
    * Gets the path name in displayable for for the given domain reference.
    * @param AdminDomainRef adminDomainRef - The domain reference to get path name for.
    * @returns String - The path name.  Or null if there was an error.
    */
   public static String getLogDomainPath( AdminDomainRef adminDomainRef ) throws WTException {
   	try {
   		if(RemoteMethodServer.ServerFlag)
   			return _getLogDomainPath(adminDomainRef);
   		else
   			return (String)RemoteMethodServer.getDefault().invoke( "_getLogDomainPath", CLASS_NAME, null, new Class[] { AdminDomainRef.class }, new Object[] { adminDomainRef });
   	} catch(Exception e) {
   		if(e instanceof WTException) {
   			throw (WTException) e;
   		} else {
   			throw new WTException(e);
   		}
   	}
   }
   public static String _getLogDomainPath( AdminDomainRef adminDomainRef ) {
      String retStr = null;
      try {
         retStr = AdministrativeDomainServerHelper.manager.getLogDomainPath( adminDomainRef );
      } catch( Exception e ) {
         e.printStackTrace();
      }
      return retStr;
   }
   
   public static AdHocAclSpec getAclSpecEntrySet( PhaseTemplate phaseTemplate )
   throws WTException {
      QueryResult queryresult = PersistenceHelper.manager.navigate(phaseTemplate, "aclSpec", wt.lifecycle.AdHocAclLink.class);
      //this link can have at maximum one element on the other side
      if(queryresult.hasMoreElements()) {
         return (AdHocAclSpec)queryresult.nextElement();
      } else {
         return null;
      }
   }


   //apr.toString() consists of .getSelector() + .getEntrySet()
   //unfortunately .getEntrySet() is protected inside AccessPolicyRule
   //therefore we need to split the String representation with regexps
   public static Map splitAPR(AccessPolicyRule apr) throws WTException {
   	Map m = new HashMap();
   	
   	String logDomainPath = getLogDomainPath(apr.getDomainRef());
   	//with ' ' at the end we get better sorting
   	logDomainPath = logDomainPath + " ";
      m.put("logDomainPath", logDomainPath);
   	
   	//not used:
   	//m.put("selector", apr.getSelector());
   	m.put("selector.ownerRef", apr.getSelector().getOwnerRef());
   	m.put("selector.typeId", apr.getSelector().getTypeId());
   	m.put("selector.stateName", apr.getSelector().getStateName());
      
   	String line = apr.toString();
      //accessPolicyRule.getDomainRef();
      line = line.replaceAll("\n", "\t");
      line = line.replaceAll("\t\t", "\t");

      Matcher matcher = PATTERN.matcher(line);
      String part1 = null;
      String part2 = null;
      // Find the first match (we have at least one of this.
      if (matcher.find()) {
        part1 = line.substring(0, matcher.start());
        part1 = part1.replaceAll("AdministrativeDomain:(\\d*), ", "AdministrativeDomain:$1\t");
        if(part1.indexOf(",")!=-1) {
      	  part1 = part1.replaceAll(",", "\t");
        } else {
      	  part1 = part1 + "\t";
        }
        //examples: part1 is equal to above selector
        //part1=wt.admin.AdministrativeDomain:16548, wt.vc.baseline.ManagedBaseline, GESPERRT
        //part1=wt.admin.AdministrativeDomain:16548, wt.vc.baseline.ManagedBaseline
        //m.put("domainRef", part1);
        part2 = line.substring(matcher.start()+1);
      }
      
      Vector v = new Vector();
      // find the next matches, sometimes we have several rules for the same domain/object combination
      Matcher matcher2 = PATTERN.matcher(part2);
      String part3 = null;
      int lastMatchStart = 0;
      while (matcher2.find()) {
         part3 = part2.substring(lastMatchStart, matcher2.start());
         part3 = part3.replaceAll(": ", "\t");
         lastMatchStart = matcher2.start()+1;
         v.add(part3);
      }
      String rest = part2.substring(lastMatchStart);
      rest = rest.replaceAll(": ", "\t");
      v.add(rest);
      m.put("entrySets", v);
      return m;
   }
} // end class ACLReportHelper
