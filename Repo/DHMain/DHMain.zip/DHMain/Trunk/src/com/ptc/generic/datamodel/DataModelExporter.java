package com.ptc.generic.datamodel;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.Vector;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import wt.fc.ObjectIdentifier;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.collections.WTCollection;
import wt.folder.Cabinet;
import wt.folder.CabinetReference;
import wt.folder.Folder;
import wt.folder.FolderHelper;
import wt.folder.SubFolder;
import wt.folder.SubFolderReference;
import wt.iba.definition.BooleanDefinition;
import wt.iba.definition.FloatDefinition;
import wt.iba.definition.IntegerDefinition;
import wt.iba.definition.RatioDefinition;
import wt.iba.definition.ReferenceDefinition;
import wt.iba.definition.StringDefinition;
import wt.iba.definition.TimestampDefinition;
import wt.iba.definition.URLDefinition;
import wt.iba.definition.UnitDefinition;
import wt.iba.definition.litedefinition.AttributeDefDefaultView;
import wt.iba.definition.litedefinition.ReferenceDefView;
import wt.inf.container.ContainerSpec;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerHelper;
import wt.inf.container.WTContainerRef;
import wt.inf.library.WTLibrary;
import wt.lifecycle.LifeCycleHelper;
import wt.lifecycle.LifeCycleTemplate;
import wt.lifecycle.PhaseLink;
import wt.lifecycle.PhaseTemplate;
import wt.log4j.LogR;
import wt.method.RemoteAccess;
import wt.org.WTGroup;
import wt.pdmlink.PDMLinkProduct;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.services.ServiceFactory;
import wt.session.SessionHelper;
import wt.units.service.QuantityOfMeasureDefaultView;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.version.WindchillVersion;

import com.ptc.core.lwc.common.AttributeTemplateFlavor;
import com.ptc.core.lwc.common.BaseDefinitionService;
import com.ptc.core.lwc.common.PropertyDefinitionConstants;
import com.ptc.core.lwc.common.TypeDefinitionService;
import com.ptc.core.lwc.common.view.AttributeDefaultValueReadView;
import com.ptc.core.lwc.common.view.AttributeDefinitionReadView;
import com.ptc.core.lwc.common.view.AttributeDefinitionViewComparator;
import com.ptc.core.lwc.common.view.ConstraintDefinitionReadView;
import com.ptc.core.lwc.common.view.ConstraintDefinitionViewComparator;
import com.ptc.core.lwc.common.view.ConstraintRuleDefinitionReadView;
import com.ptc.core.lwc.common.view.DatatypeReadView;
import com.ptc.core.lwc.common.view.DisplayStyleReadView;
import com.ptc.core.lwc.common.view.EnumerationDefinitionReadView;
import com.ptc.core.lwc.common.view.EnumerationDefinitionViewComparator;
import com.ptc.core.lwc.common.view.EnumerationEntryReadView;
import com.ptc.core.lwc.common.view.EnumerationMembershipReadView;
import com.ptc.core.lwc.common.view.GroupDefinitionReadView;
import com.ptc.core.lwc.common.view.GroupMemberViewComparator;
import com.ptc.core.lwc.common.view.GroupMembershipReadView;
import com.ptc.core.lwc.common.view.LayoutComponentReadView;
import com.ptc.core.lwc.common.view.LayoutDefinitionReadView;
import com.ptc.core.lwc.common.view.LayoutDefinitionViewComparator;
import com.ptc.core.lwc.common.view.PropertyDefinitionReadView;
import com.ptc.core.lwc.common.view.PropertyHolderHelper;
import com.ptc.core.lwc.common.view.PropertyHolderReadView;
import com.ptc.core.lwc.common.view.PropertyHolderSortOrderComparator;
import com.ptc.core.lwc.common.view.PropertyValueReadView;
import com.ptc.core.lwc.common.view.ReadViewIdentifier;
import com.ptc.core.lwc.common.view.ScreenDefinitionReadView;
import com.ptc.core.lwc.common.view.TypeDefinitionReadView;
import com.ptc.core.lwc.common.view.TypeDefinitionViewComparator;
import com.ptc.core.lwc.server.LWCAbstractAttributeTemplate;
import com.ptc.core.lwc.server.LWCBasicConstraint;
import com.ptc.core.lwc.server.LWCEnumerationBasedConstraint;
import com.ptc.core.lwc.server.LWCFilterBasedConstraint;
import com.ptc.core.lwc.server.LWCHardAttDefinition;
import com.ptc.core.lwc.server.LWCTypeDefinition;
import com.ptc.core.lwc.server.LoaderHelper;
import com.ptc.core.lwc.server.LocalizationInfo;
import com.ptc.core.lwc.server.TypeDefinitionServiceHelper;
import com.ptc.core.lwc.server.serverResource;
import com.ptc.core.lwc.server.cache.TypeDefinitionManager;
import com.ptc.core.lwc.server.ix.DefinitionExportConfig;
import com.ptc.core.meta.common.AnalogSet;
import com.ptc.core.meta.common.DataTypesExternalizer;
import com.ptc.core.meta.common.DataTypesUtility;
import com.ptc.core.meta.common.DiscreteSet;
import com.ptc.core.meta.common.EmptySet;
import com.ptc.core.meta.common.TypeInstanceIdentifier;
import com.ptc.core.meta.common.impl.TypeIdentifierSet;
import com.ptc.core.meta.common.impl.WCTypeInstanceIdentifier;
import com.ptc.core.meta.container.common.impl.DiscreteSetConstraint;
import com.ptc.core.meta.container.common.impl.ImmutableConstraint;
import com.ptc.core.meta.container.common.impl.LowerCaseConstraint;
import com.ptc.core.meta.container.common.impl.RangeConstraint;
import com.ptc.core.meta.container.common.impl.SingleValuedConstraint;
import com.ptc.core.meta.container.common.impl.StringByteLengthConstraint;
import com.ptc.core.meta.container.common.impl.StringLengthConstraint;
import com.ptc.core.meta.container.common.impl.SuggestedValuesConstraint;
import com.ptc.core.meta.container.common.impl.TypeIdentifierSetConstraint;
import com.ptc.core.meta.container.common.impl.UpperCaseConstraint;
import com.ptc.core.meta.container.common.impl.ValueRequiredConstraint;
import com.ptc.core.meta.type.mgmt.server.impl.TypeDomainHelper;
import com.ptc.windchill.instassm.IAException;
import com.ptc.windchill.instassm.InstalledTempPatch;
import com.ptc.windchill.instassm.ReleaseId;
import com.ptc.windchill.instassm.ReleaseIdException;

public final class DataModelExporter implements RemoteAccess {
	private static final String CLASSNAME = DataModelExporter.class.getName();
	
	private static final String XLSX_EXTENTION = ".xlsx";

	private static final Logger logger = LogR.getLogger(CLASSNAME);

	static final String ALL_BASE_DEFINITIONS = "ALL_BASE_DEFINITIONS";
	
	static final int compCol = 38;

	// in export file, the icon root is the Windchill codebase
	//private static final String DEFAULT_ICON_ROOT = "";

	// The folder name to save the exported content. (exported for
	// ClassificationImportHelper.java)
	public static final String DEFAULT_CONTENT_FOLDER = DefinitionExportConfig.DEFAULT_CONTENT_FOLDER;

	private static final TypeDefinitionService TYPE_DEF_SERVICE = TypeDefinitionServiceHelper.service;

	private static final BaseDefinitionService BASE_DEF_SERVICE = ServiceFactory
			.getService(BaseDefinitionService.class);

	//private static final IBADefinitionDBService IBA_DEF_SERVICE = new IBADefinitionDBService();
	private static final TypeDefinitionManager TYPE_DEF_MGR = TypeDefinitionManager
			.getTypeDefinitionManagerInstance();

	final static String EQUAL = "=";

    final static String NULL_VALUE = "NULL"; // use "NULL" to indicate subtype doesn't define its own value and also doesn't want inherited values

    static final String SCREEN_DEFINITION_PREFIX = "SCREEN" + EQUAL;

    final static String SEMI_COLON = ";";
    
    static final String ATT_DEFAULT_ENDING = " " + SEMI_COLON + " ";

    static final String ATT_DEFAULT_ENDING2 = " " + SEMI_COLON;

    static final String PROFILE_PREFIX = "PROFILE" + EQUAL;

    static final String SEPARATOR_LOAD_ID_PREFIX = "SEPARATOR" + EQUAL;

    static final String CONSTRAINT_LOAD_ID_PREFIX = ConstraintDefinitionReadView.CONSTRAINT_LOAD_ID_PREFIX;

    static final String CONDITION_LOAD_ID_PREFIX = ConstraintDefinitionReadView.CONDITION_LOAD_ID_PREFIX;

    static final String DTD_LOCALE_PREFIX = "locale_";

    static final String STRUCT_ENUM_ATT_TEMPLATE_ROOT_PKG = "com.ptc.structEnumAttTemplate";
	// will be initialized during initExport()
	// holds icon files that are referenced by the properties
	//private static Set<String> expIconNames = null;

	// holds Property Definition referenced
	//private static Set<PropertyDefinitionReadView> expPropDefs = null;

	// holds Datatype Definition referenced
	//private static Set<DatatypeReadView> expDatatypeDefs = null;

	// holds Screen Definition referenced
	//private static Set<ScreenDefinitionReadView> expScreenDefs = null;

	// holds Display Style referenced
	//private static Set<DisplayStyleReadView> expDisplayStyles = null;

	// holds Organizer referenced
	//private static Set<OrganizerReadView> expOrganizers = null;

	// holds enumeration definition referenced
	private static Set<EnumerationDefinitionReadView> expEnumDefs = null;

	// holds constraint rule definition referenced
	//private static Set<ConstraintRuleDefinitionReadView> expConstraintRuleDefs = null;

	// holds global attributes (IBA) that are referenced by the types'
	// attributes
	private static HashMap<String, AttributeDefDefaultView> expIBAs = null;

	// holds global attributes (IBA)'s organizer that hold the IBAs
	//private static HashMap<String, AttributeOrgDefaultView> expIBAOrganizers = null;

	// holds QoM that are referenced by the types' attributes
	//private static HashMap<String, QuantityOfMeasureDefaultView> expQoMs = null;

	// input configuration from XML file and command line
	private static DefinitionExportConfig config = null;

	private static Set<LocalizationInfo> typeInfos = null;

	//private static String CODEBASE_LOCATION = null;

	/** Path to the default export directory. */
	public static final String DEFAULT_EXPORT_DIR = DefinitionExportConfig.DEFAULT_EXPORT_DIR;

	//private static XMLGenerator typeXMLGen = null;

	private static Map<ScreenDefinitionReadView, TypeIdentifierSet> SCREEN_TYPEIDENTIFIERSET_MAP = new HashMap<>(5);
	private static Map<ConstraintRuleDefinitionReadView, TypeIdentifierSet> CONSTRAINTRULE_TYPEIDENTIFIERSET_MAP = new HashMap<>(5);

	private static XSSFWorkbook workbook = null;	//current workbook to export one set of export element
	private static XSSFSheet coverSheet = null;		//current worksheet to hold all cover sheet information
	private static int coverSheetIndex = 1;
	
	private static XSSFSheet objectTypeSheet = null;	//current worksheet to hold all object types and their parent information.
	private static int objectTypeSheetIndex = 1;	//to indicate which row is current row for object types.
	
	private static XSSFSheet objectAttributeSheet = null;  // all object attribute definitions in one single sheet
	private static int objectAttributeSheetIndex =1; //to indicate object attribute sheet row number
	
	private static XSSFSheet objectAttributeConstraintSheet = null; //all object attribute constraints in one single sheet
	private static int objectAttributeConstraintSheetIndex = 1;	//to indicate object attribute constraint row number
	
	private static XSSFSheet objectTypeLayoutSheet = null;
	private static int objectTypeLayoutSheetIndex = 1;
	
	private static XSSFSheet objectIBASheet = null;  //all used IBA in one single sheet
	private static int objectIBASheetIndex = 1;
	
	private static XSSFSheet globalEnumerationSheet = null;  //all used global enumeration in one single sheet.
	private static int globalEnumerationIndex = 1; //
	
	private static XSSFSheet containerFolderSheet = null;  //all used containers with folders in one single sheet.
	private static int containerFolderIndex = 1; //
	
	private static XSSFSheet lifecyclesSheet = null;  //all used containers with folders in one single sheet.
	private static int lifecyclesIndex = 1; //
	
	/**
	 * Map containing property definition's and their type filter. The value
	 * will be null if a property definition does not have a type filter
	 * defined. This needs to be recalculated every time an export is done to
	 * make sure it doesn't have stale data. It should be used during export to
	 * avoid having to recreate the filter set for each property value. It
	 * should only be populated if we're in verify mode.
	 * 
	 * @see #config.validateTypes()
	 */
	private static Map<PropertyDefinitionReadView, TypeIdentifierSet> PROP_DEF_TYPEIDENTIFIERSET_MAP = new HashMap<>(
			5);

	private static Map<DatatypeReadView, TypeIdentifierSet> TYPE_IDENTIFIER_FILTERSET_MAP = new HashMap<>(
			5);

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public static boolean beginExportDefinition(Hashtable nv,
			Hashtable cmd_line, Vector return_objects) {
		// load and validate the input parameters
		config = DefinitionExportConfig.getInstance(nv, cmd_line);
		if (config == null)
			return false;

		if (config.validateTypes()) {
			//System.out.println("Hashtable nv=" + nv);
			//System.out.println("Hashtable cmd_line=" + cmd_line);
			try {
				Set<ScreenDefinitionReadView> allScreens = BASE_DEF_SERVICE.getAllScreenDefViews();
				SCREEN_TYPEIDENTIFIERSET_MAP.clear();
				Map<ScreenDefinitionReadView, TypeIdentifierSet> tempScreenTypeIdentifierSetMap = new HashMap<>(5);
				
				for (ScreenDefinitionReadView screen : allScreens) {
					PropertyValueReadView typeFilterProp = BASE_DEF_SERVICE.getScreenDefView(screen.getName())
							.getPropertyValueByName(PropertyDefinitionConstants.TYPE_FILTER_PROPERTY);
					
					TypeIdentifierSet typeFilterSet = null;
					if (typeFilterProp != null) {
						typeFilterSet = (TypeIdentifierSet) TypeIdentifierSet
								.fromPropertyString(typeFilterProp.getValueAsString());
					}
					tempScreenTypeIdentifierSetMap.put(screen, typeFilterSet);
				}
				SCREEN_TYPEIDENTIFIERSET_MAP = tempScreenTypeIdentifierSetMap;

				Set<ConstraintRuleDefinitionReadView> allConstraintRules = BASE_DEF_SERVICE.getAllConstraintRuleDefViews();
				CONSTRAINTRULE_TYPEIDENTIFIERSET_MAP.clear();
				Map<ConstraintRuleDefinitionReadView, TypeIdentifierSet> tempConstraintRuleTypeIdentifierSetMap = new HashMap<>(5);
				
				for (ConstraintRuleDefinitionReadView constraintRule : allConstraintRules) {
					PropertyValueReadView typeFilterProp = constraintRule
							.getPropertyValueByName(PropertyDefinitionConstants.TYPE_FILTER_PROPERTY);
					
					TypeIdentifierSet typeFilterSet = null;
					if (typeFilterProp != null) {
						typeFilterSet = (TypeIdentifierSet) TypeIdentifierSet
								.fromPropertyString(typeFilterProp.getValueAsString());
					}
					tempConstraintRuleTypeIdentifierSetMap.put(constraintRule,
							typeFilterSet);
				}
				CONSTRAINTRULE_TYPEIDENTIFIERSET_MAP = tempConstraintRuleTypeIdentifierSetMap;

				// get all the property definition's type filters and store them
				// in a map, so that we don't have to
				// recalculate the sets every time we have to verify a property
				// is valid.
				final Set<PropertyDefinitionReadView> allPropDefs = BASE_DEF_SERVICE.getAllPropertyDefViews();
				final Map<PropertyDefinitionReadView, TypeIdentifierSet> tempPropDefTypeIdentifierSetMap = new HashMap<>(5);
				for (PropertyDefinitionReadView aPropDef : allPropDefs) {
					final PropertyValueReadView typeFilterPropVal = aPropDef
							.getPropertyValueByName(PropertyDefinitionConstants.TYPE_FILTER_PROPERTY);
					TypeIdentifierSet typeFilterSet = null;
					if (typeFilterPropVal != null) {
						typeFilterSet = (TypeIdentifierSet) TypeIdentifierSet
								.fromPropertyString(typeFilterPropVal
										.getValueAsString());
					}
					tempPropDefTypeIdentifierSetMap.put(aPropDef, typeFilterSet);
				}
				PROP_DEF_TYPEIDENTIFIERSET_MAP = tempPropDefTypeIdentifierSetMap;

				// get all the type identifier filters and put into a map for
				// faster lookup
				Set<DatatypeReadView> allReadViews = BASE_DEF_SERVICE.getAllDatatypeViews();
				final Map<DatatypeReadView, TypeIdentifierSet> readViewMap = new HashMap<>(5);
				for (DatatypeReadView aReadView : allReadViews) {
					final PropertyValueReadView typeFilterPropVal = aReadView
							.getPropertyValueByName(PropertyDefinitionConstants.TYPE_FILTER_PROPERTY);
					TypeIdentifierSet typeFilterSet = null;
					if (typeFilterPropVal != null) {
						typeFilterSet = (TypeIdentifierSet) TypeIdentifierSet
								.fromPropertyString(typeFilterPropVal.getValueAsString());
					}
					readViewMap.put(aReadView, typeFilterSet);
				}
				TYPE_IDENTIFIER_FILTERSET_MAP = readViewMap;

			} catch (WTException e) {
				logger.error(
						"(beginExportDefinition): Failed to get screen definitions",
						e);
				return false;
			}

		}

		// massaging the input provided by the user for multi-file output
		ArrayList<DefinitionExportConfig.ExportElement> exportElements = config.getExportElements();

		if (config.exportAncestorTypes() && exportElements.size() > 1) {
			logger.error(" (beginExportDefinition): If a value is specified for csvExportFilterTypes, then csvExportAncestorTypes must be set to false.");
			return false;
		}

		boolean success = false;
		int fileCountIndex = 0;
		String fileName = config.getFileName();
		int index = fileName.indexOf(".");
		String originalFileName = (index < 0) ? fileName : fileName.substring(
				0, index);
		String fileExt = (index < 0) ? "" : fileName.substring(index); // includes the "."
		String excelFileName = originalFileName + XLSX_EXTENTION;
		
		if(expIBAs==null){
			expIBAs = new HashMap<String,AttributeDefDefaultView>();
		}
		
		if(expEnumDefs==null){
			//expEnumDefs = new TreeSet<EnumerationDefinitionReadView>();
			expEnumDefs = new TreeSet<>(
					EnumerationDefinitionViewComparator.getInstance());
		}
		
		for (DefinitionExportConfig.ExportElement elt : exportElements) {
			if (fileCountIndex > 0) {
				// by construction, "elt.exportTypes" has exactly 1 element for
				// any exportTypes list after
				// the first one. See
				// DefinitionExportConfig.buildExportElements().
				fileName = originalFileName + "_" + elt.exportTypes.get(0) + fileExt;
				excelFileName = originalFileName + "_"+  elt.exportTypes.get(0) + XLSX_EXTENTION;
			}
			/*
			success = exportOptions(fileName, config.getExportDirectory(),
					config.getDefClass(), elt.exportTypes, elt.filterTypes); */
			success = exportExcelOptions(excelFileName,config.getExportDirectory(),
					config.getDefClass(),elt.exportTypes,elt.filterTypes);
			resetRowIndexes();
			if (!success) {
				break;
			}

			fileCountIndex++;
		}
		return success;
	}

	public static boolean beginExportTypeAttribute(Hashtable nv,
												   Hashtable cmd_line, Vector return_objects) {
		// load and validate the input parameters
		config = DefinitionExportConfig.getInstance(nv, cmd_line);
		if (config == null)
			return false;

		if (config.validateTypes()) {
			//System.out.println("Hashtable nv=" + nv);
			//System.out.println("Hashtable cmd_line=" + cmd_line);
			try {
				Set<ScreenDefinitionReadView> allScreens = BASE_DEF_SERVICE.getAllScreenDefViews();
				SCREEN_TYPEIDENTIFIERSET_MAP.clear();
				Map<ScreenDefinitionReadView, TypeIdentifierSet> tempScreenTypeIdentifierSetMap = new HashMap<>(5);

				for (ScreenDefinitionReadView screen : allScreens) {
					PropertyValueReadView typeFilterProp = BASE_DEF_SERVICE.getScreenDefView(screen.getName())
							.getPropertyValueByName(PropertyDefinitionConstants.TYPE_FILTER_PROPERTY);

					TypeIdentifierSet typeFilterSet = null;
					if (typeFilterProp != null) {
						typeFilterSet = (TypeIdentifierSet) TypeIdentifierSet
								.fromPropertyString(typeFilterProp.getValueAsString());
					}
					tempScreenTypeIdentifierSetMap.put(screen, typeFilterSet);
				}
				SCREEN_TYPEIDENTIFIERSET_MAP = tempScreenTypeIdentifierSetMap;

				Set<ConstraintRuleDefinitionReadView> allConstraintRules = BASE_DEF_SERVICE.getAllConstraintRuleDefViews();
				CONSTRAINTRULE_TYPEIDENTIFIERSET_MAP.clear();
				Map<ConstraintRuleDefinitionReadView, TypeIdentifierSet> tempConstraintRuleTypeIdentifierSetMap = new HashMap<>(5);

				for (ConstraintRuleDefinitionReadView constraintRule : allConstraintRules) {
					PropertyValueReadView typeFilterProp = constraintRule
							.getPropertyValueByName(PropertyDefinitionConstants.TYPE_FILTER_PROPERTY);

					TypeIdentifierSet typeFilterSet = null;
					if (typeFilterProp != null) {
						typeFilterSet = (TypeIdentifierSet) TypeIdentifierSet
								.fromPropertyString(typeFilterProp.getValueAsString());
					}
					tempConstraintRuleTypeIdentifierSetMap.put(constraintRule,
							typeFilterSet);
				}
				CONSTRAINTRULE_TYPEIDENTIFIERSET_MAP = tempConstraintRuleTypeIdentifierSetMap;

				// get all the property definition's type filters and store them
				// in a map, so that we don't have to
				// recalculate the sets every time we have to verify a property
				// is valid.
				final Set<PropertyDefinitionReadView> allPropDefs = BASE_DEF_SERVICE.getAllPropertyDefViews();
				final Map<PropertyDefinitionReadView, TypeIdentifierSet> tempPropDefTypeIdentifierSetMap = new HashMap<>(5);
				for (PropertyDefinitionReadView aPropDef : allPropDefs) {
					final PropertyValueReadView typeFilterPropVal = aPropDef
							.getPropertyValueByName(PropertyDefinitionConstants.TYPE_FILTER_PROPERTY);
					TypeIdentifierSet typeFilterSet = null;
					if (typeFilterPropVal != null) {
						typeFilterSet = (TypeIdentifierSet) TypeIdentifierSet
								.fromPropertyString(typeFilterPropVal
										.getValueAsString());
					}
					tempPropDefTypeIdentifierSetMap.put(aPropDef, typeFilterSet);
				}
				PROP_DEF_TYPEIDENTIFIERSET_MAP = tempPropDefTypeIdentifierSetMap;

				// get all the type identifier filters and put into a map for
				// faster lookup
				Set<DatatypeReadView> allReadViews = BASE_DEF_SERVICE.getAllDatatypeViews();
				final Map<DatatypeReadView, TypeIdentifierSet> readViewMap = new HashMap<>(5);
				for (DatatypeReadView aReadView : allReadViews) {
					final PropertyValueReadView typeFilterPropVal = aReadView
							.getPropertyValueByName(PropertyDefinitionConstants.TYPE_FILTER_PROPERTY);
					TypeIdentifierSet typeFilterSet = null;
					if (typeFilterPropVal != null) {
						typeFilterSet = (TypeIdentifierSet) TypeIdentifierSet
								.fromPropertyString(typeFilterPropVal.getValueAsString());
					}
					readViewMap.put(aReadView, typeFilterSet);
				}
				TYPE_IDENTIFIER_FILTERSET_MAP = readViewMap;

			} catch (WTException e) {
				logger.error(
						"(beginExportDefinition): Failed to get screen definitions",
						e);
				return false;
			}

		}

		// massaging the input provided by the user for multi-file output
		ArrayList<DefinitionExportConfig.ExportElement> exportElements = config.getExportElements();

		if (config.exportAncestorTypes() && exportElements.size() > 1) {
			logger.error(" (beginExportDefinition): If a value is specified for csvExportFilterTypes, then csvExportAncestorTypes must be set to false.");
			return false;
		}

		boolean success = false;
		int fileCountIndex = 0;
		String fileName = config.getFileName();
		int index = fileName.indexOf(".");
		String originalFileName = (index < 0) ? fileName : fileName.substring(
				0, index);
		String fileExt = (index < 0) ? "" : fileName.substring(index); // includes the "."
		String excelFileName = originalFileName + XLSX_EXTENTION;

		if(expIBAs==null){
			expIBAs = new HashMap<String,AttributeDefDefaultView>();
		}

		if(expEnumDefs==null){
			//expEnumDefs = new TreeSet<EnumerationDefinitionReadView>();
			expEnumDefs = new TreeSet<>(
					EnumerationDefinitionViewComparator.getInstance());
		}

		for (DefinitionExportConfig.ExportElement elt : exportElements) {
			if (fileCountIndex > 0) {
				// by construction, "elt.exportTypes" has exactly 1 element for
				// any exportTypes list after
				// the first one. See
				// DefinitionExportConfig.buildExportElements().
				fileName = originalFileName + "_" + elt.exportTypes.get(0) + fileExt;
				excelFileName = originalFileName + "_"+  elt.exportTypes.get(0) + XLSX_EXTENTION;
			}
			/*
			success = exportOptions(fileName, config.getExportDirectory(),
					config.getDefClass(), elt.exportTypes, elt.filterTypes); */
			success = exportTypeAttributeOption(excelFileName, config.getExportDirectory(),
					config.getDefClass(), elt.exportTypes, elt.filterTypes);
			resetRowIndexes();
			if (!success) {
				break;
			}

			fileCountIndex++;
		}
		return success;
	}

	private static boolean exportTypeAttributeOption(String excelFileName, String location, String defClass,
													 ArrayList<String> defList, ArrayList<String> defFilterTypesList) {
		try {
			initExcelExport(excelFileName, location, false);
			if (LWCAbstractAttributeTemplate.class.isAssignableFrom(Class.forName(defClass))) {
				if (LWCTypeDefinition.class.getName().equals(defClass)) {
					exportExcelTypeDefinitions(AttributeTemplateFlavor.LWCTYPE, null, defList, defFilterTypesList, false);
				}
			}
			endExcelExport(excelFileName,location);
		} catch (ParserConfigurationException ex) {
			logger.error("(beginExportDefinition): Error while trying to initialize export. ", ex);
			return false;
		} catch (Exception ex) {
			logger.error("(beginExportDefinition): Error while trying to export definitions. ", ex);
			return false;
		}
		return true;
	}

	private static boolean exportExcelOptions(String excelFileName, String location,
			String defClass, ArrayList<String> defList,
			ArrayList<String> defFilterTypesList) {

		boolean status = false;

		try {
			// initialize the export
			//initExport();
			initExcelExport( excelFileName,  location, true);

			// real export begins

			// export icon Root
			//writeIconRoot();
			/*
			if (LWCStructEnumAttTemplate.class.getName().equals(defClass)) {
				logger.error("Struct Enum case will not be handled!");
				writeContentRoot(); // we don't want to deal with Struct Enum Attribute, therefore, entire block has to be disabled.
			}*/

			if (LWCAbstractAttributeTemplate.class
					.isAssignableFrom(Class.forName(defClass))) {
				//String nameSpace = config.getNameSpace();
				if (LWCTypeDefinition.class.getName().equals(defClass)) {
					
					exportExcelTypeDefinitions(AttributeTemplateFlavor.LWCTYPE,	null, defList, defFilterTypesList, true);
					
				} else {
					logger.error("(beginExportDefinition): Definition class requested is invalid: \""
							+ defClass
							+ "\". It has to be the classname of LWCTypeDefinition but not stru enum.");
					return status;
				}
				//exportType = true;
			}else {
				logger.error("(beginExportDefinition): Definition class requested is invalid: \""
						+ defClass
						+ "\". It has to be the classname of LWCTypeDefinition.");
				return status;
			}

			// finish the export
			//endExport(location, excelFileName.replace(XLSX_EXTENTION, ".xml"), exportType);
			exportIBA();
			exportExcelGlobalEnumeration();
			exportExcelContainerFolder();
			exportExcelLifecycle();
			endExcelExport(excelFileName,location);

		} catch (ParserConfigurationException ex) {
			logger.error(
					"(beginExportDefinition): Error while trying to initialize export. ",
					ex);
			return status;
		} catch (Exception ex) {
			logger.error(
					"(beginExportDefinition): Error while trying to export definitions. ",
					ex);
			return status;
		}
		status = true;
		return status;
	}
	
    static String getRbInfoLocationForNonTypedAttTemplate( String nameSpace )
            throws WTException
        {
            // remove domain if it's equal to exchange domain
            nameSpace = getConciseTypeName( nameSpace, null );
            return STRUCT_ENUM_ATT_TEMPLATE_ROOT_PKG + "." + nameSpace;
        }
    static String getClassPkgString( String classname )
            throws ClassNotFoundException
        {
            return Class.forName( classname ).getPackage().getName();
        }
    
	private static void exportExcelTypeDefinitions(AttributeTemplateFlavor flavor,
			String nameSpace, List<String> nameList,
			List<String> filteredTypesList, boolean isFullExport) throws Exception {
		typeInfos = new HashSet<>();
		String rootPkg;
		if (AttributeTemplateFlavor.LWCTYPE.equals(flavor)) {
			//Desheng, yes, this is the only case we need to handle.
			rootPkg = null;
		} else {
			rootPkg = getRbInfoLocationForNonTypedAttTemplate(nameSpace);
			logger.error("only type definition will be handled in this tool!");
			return;
		}

		if (nameList.isEmpty()) {
			//This tool will not allow empty name lists for all object types but it will be supported in code anyway.
			// begin type hierarchy directive
			System.out.println("Name list is empty, let's start for all!");
			
			//writeBeginTypeHierarchyElem(flavor, nameSpace);

			Set<TypeDefinitionReadView> roots = TYPE_DEF_SERVICE
					.getRootTypeDefViews(flavor, nameSpace);
			if (roots != null && !roots.isEmpty()) {
				for (TypeDefinitionReadView root : roots) {
					typeInfos.add(exportExcelTypeDefinition(root, rootPkg, isFullExport));
					// returned order is descending order, i.e. from parent to
					// children
					Set<TypeDefinitionReadView> descendants = TYPE_DEF_SERVICE
							.getDescendantTypeDefViews(root);
					if (root.isModeled()) {
						rootPkg = getClassPkgString(root.getName());
					}
					for (TypeDefinitionReadView descendant : descendants) {
						typeInfos.add(exportExcelTypeDefinition(descendant,
								getCurTypeRootPkg(descendant, rootPkg), isFullExport));
					}
				}
			} else {
				if (logger.isDebugEnabled()) {
					logger.debug("(getTypeDefinitions): Root types are empty!");
				}
			}

			// end type hierarchy directive
			/*writeEmptyElem(XML_END_TYPE_HIERARCHY_TAG,
					XML_END_TYPE_HIERARCHY_HANDLER);*/

		} else {
			TreeSet<TypeDefinitionReadView> typeList = new TreeSet<>(
					TypeDefinitionViewComparator.getInstance());
			TreeSet<TypeDefinitionReadView> tempList = new TreeSet<>(
					TypeDefinitionViewComparator.getInstance());
			final List<String> fullNameList = getFullNameList(nameList, flavor);

			//System.out.println("Name list is not empty! let's start one by one");
			
			for (String name : fullNameList) {
				TypeDefinitionReadView selfView;
				selfView = TYPE_DEF_SERVICE.getTypeDefView(flavor, nameSpace,
						name);
				System.out.print("Start with name:"+name);
				
				if (selfView != null) {
					System.out.println("...found view!");
					
					// the type is higher in the hierarchy tree, thus only keep
					// the hierarchy up to this type
					if (typeList.contains(selfView)) {
						tempList.clear();
						tempList.addAll(typeList.subSet(typeList.first(), true,
								selfView, true));
						typeList.clear();
						typeList.addAll(tempList);
					} else { // check whether the type is lower in a branch
								// (descendant) of some type's hierarchy tree
						Set<TypeDefinitionReadView> ancestors = TYPE_DEF_SERVICE
								.getAncestorTypeDefViews(selfView);
						boolean isDescendant = false;
						for (TypeDefinitionReadView type : typeList) {
							if (ancestors.contains(type)
									&& fullNameList.contains(type.getName())) {
								isDescendant = true;
								break;
							}
						}

						// if lower in the branch, skip; otherwise add the type
						// and its ancestors to the list
						if (!isDescendant) {
							typeList.add(selfView);
							if (config.exportAncestorTypes()) {
								typeList.addAll(ancestors);
							}
						}
					}
				}
			}
			ArrayList<TypeDefinitionReadView> filteredParentTypeList = new ArrayList<>();
			Set<TypeDefinitionReadView> filteredDescendantsViews = new TreeSet<>(
					TypeDefinitionViewComparator.getInstance());

			// setting values for the type and any descendants that need to be
			// excluded from the main file
			if (!filteredTypesList.isEmpty()) {
				List<String> filteredFullNameList = new ArrayList<>(
						filteredTypesList.size());

				// retrieving the full name of the type that was passed in
				for (String filteredName : filteredTypesList) {
					filteredFullNameList.add(LoaderHelper
							.getFullTypeName(filteredName));
				}

				for (String filteredName : filteredFullNameList) {
					// adding the sub-type to a list to loop through to be
					// excluded from the main type file
					TypeDefinitionReadView filteredView = TYPE_DEF_SERVICE
							.getTypeDefView(flavor, nameSpace, filteredName);
					filteredParentTypeList.add(filteredView);

					if (filteredView != null) {
						// adding the descendants of the sub-type to be excluded
						// from the main type file
						filteredDescendantsViews.addAll(TYPE_DEF_SERVICE
								.getDescendantTypeDefViews(filteredView));
					}
				}
			}

			for (TypeDefinitionReadView type : typeList) {
				TypeDefinitionReadView nearestModeledAncestorType = TYPE_DEF_MGR
						.getNearestModeledAncestor(type);
				if (nearestModeledAncestorType == null) {
					nearestModeledAncestorType = TYPE_DEF_SERVICE
							.getRootTypeDefView(type);
				}

				if (nearestModeledAncestorType != null
						&& nearestModeledAncestorType.isModeled()) {
					rootPkg = getClassPkgString(nearestModeledAncestorType
									.getName());
				}

				// only those types specified in the list will have the full
				// hierarchy tree exported
				boolean hierarchy = fullNameList.contains(type.getName());

				typeInfos.add(exportExcelTypeDefinition(type,
						getCurTypeRootPkg(type, rootPkg), isFullExport));

				if (hierarchy) {
					// although the manager returns descendants in descending
					// order, i.e. from parent to children
					// but for comparison purpose, we need to ensure that the
					// descendants are listed in
					// a fixed order too so using TreeSet....
					Set<TypeDefinitionReadView> descendants = new TreeSet<>(
							TypeDefinitionViewComparator.getInstance());
					descendants.addAll(TYPE_DEF_SERVICE
							.getDescendantTypeDefViews(type));

					// remove the the filtered view(s) from the descendants set
					for (TypeDefinitionReadView filteredView : filteredParentTypeList) {
						if (descendants.contains(filteredView)) {
							descendants.remove(filteredView);
						}
					}

					// remove the children of the filtered view from the
					// descendants set
					for (TypeDefinitionReadView filteredDescendantView : filteredDescendantsViews) {
						descendants.remove(filteredDescendantView);
					}

					for (TypeDefinitionReadView descendant : descendants) {
						typeInfos.add(exportExcelTypeDefinition(descendant,
								getCurTypeRootPkg(descendant, rootPkg), isFullExport));
					}

					/*writeEmptyElem(XML_END_TYPE_HIERARCHY_TAG,
							XML_END_TYPE_HIERARCHY_HANDLER);*/
				}
			}
		} // end of if (nameList.isEmpty())
	}// end of exportTypeDefinitions


	
	private static void exportIBA() throws Exception{
		if(expIBAs==null || expIBAs.size()==0)
			return;
		
		String compHash = "";
		for(AttributeDefDefaultView att: expIBAs.values()){
			XSSFRow newRow=objectIBASheet.createRow(objectIBASheetIndex++);
			int colIndex=1;
			newRow.createCell(colIndex++).setCellValue(att.getName());	//IBA Name
			
			newRow.createCell(colIndex++).setCellValue(att.getHierarchyDisplayName());	//IBA Hierarchy Name
			newRow.createCell(colIndex++).setCellValue(BASE_DEF_SERVICE.getDefinizerOrganizerPath(att));	//IBA Path
			newRow.createCell(colIndex++).setCellValue(att.getDisplayName());	//IBA Display Name
			
			newRow.createCell(colIndex++).setCellValue(att.getDescription()); // IBA description
			
			String defClass = att.getAttributeDefinitionClassName();
			String dataType="";
            // datatype
            if (FloatDefinition.class.getName().equals(defClass)){
            	dataType="FLOAT";
            }else if (IntegerDefinition.class.getName().equals(defClass)){
            	dataType="INT";
            }else if (RatioDefinition.class.getName().equals(defClass)){
            	dataType="RATIO";
            }else if (StringDefinition.class.getName().equals(defClass)){
            	dataType="STR";
            }else if (TimestampDefinition.class.getName().equals(defClass)){
            	dataType="TIME";
            }else if (BooleanDefinition.class.getName().equals(defClass)){
            	dataType="BOOL";
            }else if (URLDefinition.class.getName().equals(defClass)){
            	dataType="URL";
            }else if (ReferenceDefinition.class.getName().equals(defClass)){
            	dataType="REF"+"|"+((ReferenceDefView) att).getReferencedClassname();
            }else if (UnitDefinition.class.getName().equals(defClass)){
            	dataType="UNIT";
            }            
            newRow.createCell(colIndex++).setCellValue(dataType);	//IBA type
            compHash = att.getName() + att.getHierarchyDisplayName() + (BASE_DEF_SERVICE.getDefinizerOrganizerPath(att)) + 
            		   att.getDisplayName() + att.getDescription() + dataType;
            newRow.createCell(colIndex++).setCellValue(compHash);
		}
		
	}
	
	private static void endExcelExport(String excelFileName,String location){
		if (!location.endsWith(File.separator)){
			location = location + File.separator;
		}
		String fullName = location + excelFileName;
		FileOutputStream out=null;
		try {
			out = new FileOutputStream(fullName);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			if(out!=null)
				workbook.write(out);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			if(out!=null)
				out.close();
			if(workbook!=null)
				workbook.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
    /**
     * Writes the content root element. Assume all content files reside under the same root.
     */
	/*
    private static void writeContentRoot()
    {
        // init data
        Map<String, String> contentRoot = new HashMap<>();
        contentRoot.put(XML_CONTENT_ROOT, config.getContentDirectory().replace('\\', '/'));

        // create element
        typeXMLGen.createDefinitionElem(XML_CONTENT_ROOT_TAG, XML_CONTENT_ROOT_HANDLER, contentRoot);
    }
	*/

	/**
	 * Exports the type definitions specified, along with their ancestors, and
	 * their descendants. Export data for a type definition include the type
	 * definition's characteristics, its properties, its attributes, its
	 * layouts, and etc. Every type definition and its descendants are exported,
	 * being wrapped around with begin/end type hierarchy directives. If
	 * <code>nameList</code> is empty, all existing type definitions are
	 * exported.
	 *
	 * @param flavor
	 *            The attribute template flavor to look for
	 * @param nameSpace
	 *            The nameSpace to look for the attribute templates
	 * @param nameList
	 *            A list of names of the type definition
	 * @throws java.lang.Exception
	 */
    /*
	private static void exportTypeDefinitions(AttributeTemplateFlavor flavor,
			String nameSpace, List<String> nameList,
			List<String> filteredTypesList) throws Exception {
		typeInfos = new HashSet<>();
		String rootPkg;
		if (AttributeTemplateFlavor.LWCTYPE.equals(flavor)) {
			//Desheng, yes, this is the only case we need to handle.
			rootPkg = null;
		} else {
			rootPkg = LoaderHelper.getRbInfoLocationForNonTypedAttTemplate(nameSpace);
			logger.error("only type definition will be handled in this tool!");
		}

		if (nameList.isEmpty()) {
			//This tool will not allow empty name lists for all object types but it will be supported in code anyway.
			// begin type hierarchy directive
			System.out.println("Name list is empty, let's start for all!");
			
			writeBeginTypeHierarchyElem(flavor, nameSpace);

			Set<TypeDefinitionReadView> roots = TYPE_DEF_SERVICE
					.getRootTypeDefViews(flavor, nameSpace);
			if (roots != null && !roots.isEmpty()) {
				for (TypeDefinitionReadView root : roots) {
					typeInfos.add(exportTypeDefinition(root, rootPkg));
					// returned order is descending order, i.e. from parent to
					// children
					Set<TypeDefinitionReadView> descendants = TYPE_DEF_SERVICE
							.getDescendantTypeDefViews(root);
					if (root.isModeled()) {
						rootPkg = LoaderHelper
								.getClassPkgString(root.getName());
					}
					for (TypeDefinitionReadView descendant : descendants) {
						typeInfos.add(exportTypeDefinition(descendant,
								getCurTypeRootPkg(descendant, rootPkg)));
					}
				}
			} else {
				if (logger.isDebugEnabled()) {
					logger.debug("(getTypeDefinitions): Root types are empty!");
				}
			}

			// end type hierarchy directive
			writeEmptyElem(XML_END_TYPE_HIERARCHY_TAG,
					XML_END_TYPE_HIERARCHY_HANDLER);

		} else {
			TreeSet<TypeDefinitionReadView> typeList = new TreeSet<>(
					TypeDefinitionViewComparator.getInstance());
			TreeSet<TypeDefinitionReadView> tempList = new TreeSet<>(
					TypeDefinitionViewComparator.getInstance());
			final List<String> fullNameList = getFullNameList(nameList, flavor);

			//System.out.println("Name list is not empty! let's start one by one");
			
			for (String name : fullNameList) {
				TypeDefinitionReadView selfView;
				selfView = TYPE_DEF_SERVICE.getTypeDefView(flavor, nameSpace,
						name);
				System.out.print("Start with name:"+name);
				
				if (selfView != null) {
					System.out.println("...found view!");
					
					// the type is higher in the hierarchy tree, thus only keep
					// the hierarchy up to this type
					if (typeList.contains(selfView)) {
						tempList.clear();
						tempList.addAll(typeList.subSet(typeList.first(), true,
								selfView, true));
						typeList.clear();
						typeList.addAll(tempList);
					} else { // check whether the type is lower in a branch
								// (descendant) of some type's hierarchy tree
						Set<TypeDefinitionReadView> ancestors = TYPE_DEF_SERVICE
								.getAncestorTypeDefViews(selfView);
						boolean isDescendant = false;
						for (TypeDefinitionReadView type : typeList) {
							if (ancestors.contains(type)
									&& fullNameList.contains(type.getName())) {
								isDescendant = true;
								break;
							}
						}

						// if lower in the branch, skip; otherwise add the type
						// and its ancestors to the list
						if (!isDescendant) {
							typeList.add(selfView);
							if (config.exportAncestorTypes()) {
								typeList.addAll(ancestors);
							}
						}
					}
				}
			}
			ArrayList<TypeDefinitionReadView> filteredParentTypeList = new ArrayList<>();
			Set<TypeDefinitionReadView> filteredDescendantsViews = new TreeSet<>(
					TypeDefinitionViewComparator.getInstance());

			// setting values for the type and any descendants that need to be
			// excluded from the main file
			if (!filteredTypesList.isEmpty()) {
				List<String> filteredFullNameList = new ArrayList<>(
						filteredTypesList.size());

				// retrieving the full name of the type that was passed in
				for (String filteredName : filteredTypesList) {
					filteredFullNameList.add(LoaderHelper
							.getFullTypeName(filteredName));
				}

				for (String filteredName : filteredFullNameList) {
					// adding the sub-type to a list to loop through to be
					// excluded from the main type file
					TypeDefinitionReadView filteredView = TYPE_DEF_SERVICE
							.getTypeDefView(flavor, nameSpace, filteredName);
					filteredParentTypeList.add(filteredView);

					if (filteredView != null) {
						// adding the descendants of the sub-type to be excluded
						// from the main type file
						filteredDescendantsViews.addAll(TYPE_DEF_SERVICE
								.getDescendantTypeDefViews(filteredView));
					}
				}
			}

			for (TypeDefinitionReadView type : typeList) {
				TypeDefinitionReadView nearestModeledAncestorType = TYPE_DEF_MGR
						.getNearestModeledAncestor(type);
				if (nearestModeledAncestorType == null) {
					nearestModeledAncestorType = TYPE_DEF_SERVICE
							.getRootTypeDefView(type);
				}

				if (nearestModeledAncestorType != null
						&& nearestModeledAncestorType.isModeled()) {
					rootPkg = LoaderHelper
							.getClassPkgString(nearestModeledAncestorType
									.getName());
				}

				// only those types specified in the list will have the full
				// hierarchy tree exported
				boolean hierarchy = fullNameList.contains(type.getName());

				if (hierarchy) {
					System.out.println(" it is a hierarchy and let's start writeBeginTypeHierarchyElem");
					writeBeginTypeHierarchyElem(flavor, nameSpace);
				}else{
					System.out.println("Not Hierarchy? need check!");
				}

				typeInfos.add(exportTypeDefinition(type,
						getCurTypeRootPkg(type, rootPkg)));

				if (hierarchy) {
					// although the manager returns descendants in descending
					// order, i.e. from parent to children
					// but for comparison purpose, we need to ensure that the
					// descendants are listed in
					// a fixed order too so using TreeSet....
					Set<TypeDefinitionReadView> descendants = new TreeSet<>(
							TypeDefinitionViewComparator.getInstance());
					descendants.addAll(TYPE_DEF_SERVICE
							.getDescendantTypeDefViews(type));

					// remove the the filtered view(s) from the descendants set
					for (TypeDefinitionReadView filteredView : filteredParentTypeList) {
						if (descendants.contains(filteredView)) {
							descendants.remove(filteredView);
						}
					}

					// remove the children of the filtered view from the
					// descendants set
					for (TypeDefinitionReadView filteredDescendantView : filteredDescendantsViews) {
						descendants.remove(filteredDescendantView);
					}

					for (TypeDefinitionReadView descendant : descendants) {
						typeInfos.add(exportTypeDefinition(descendant,
								getCurTypeRootPkg(descendant, rootPkg)));
					}

					writeEmptyElem(XML_END_TYPE_HIERARCHY_TAG,
							XML_END_TYPE_HIERARCHY_HANDLER);
				}
			}
		} // end of if (nameList.isEmpty())
	}// end of exportTypeDefinitions

*/

	/**
	 * Gets the list of full names for the names provided. This essentially
	 * prepends, where appropriate, the inverse of the domain name to the names
	 * supplied in nameList.
	 * 
	 * @param nameList
	 *            The list of names to get the full names of. Must not be null.
	 * @param flavor
	 *            The attribute template flavor the names are for.
	 * @return The list of full names.
	 */
	private static List<String> getFullNameList(final List<String> nameList,
			final AttributeTemplateFlavor flavor) {
		final List<String> fullNameList;
		if (AttributeTemplateFlavor.LWCSTRUCT.equals(flavor)) {
			fullNameList = nameList; // structured enumeration should not get
										// the domain name prefixed.
		} else {
			fullNameList = new ArrayList<>(nameList.size());
			// if types are in the same branch, merge them by leaving in the
			// list the highest in the hierarchy tree.
			// It's ok because the type's descendants will be exported.
			for (String name : nameList) {
				fullNameList.add(LoaderHelper.getFullTypeName(name));
			}
		}
		return fullNameList;
	}

	/**
	 * If curType is a modeled type, its rootPkg is its own class hierarchy.
	 * Otherwise if curType is a soft type, its rootPkg is the rootPkg of its
	 * root type.
	 *
	 * @param curType
	 *            The view of the current type
	 * @param rootPkg
	 *            The rootPkg of its root type.
	 * @return
	 */
	private static String getCurTypeRootPkg(TypeDefinitionReadView curType,
			String rootPkg) throws Exception {
		final String curTypeRootPkg;
		if (curType.isModeled()) {
			curTypeRootPkg = getClassPkgString(curType.getName());
		} else {
			curTypeRootPkg = rootPkg;
		}

		return curTypeRootPkg;
	}

    /**
     * Gets the shorthand typename of the specified String. If its internet domain prefix is an exact match for the site
     * internet domain, then it's stripped off of the type name.
     * @param typeName The name
     * @param containerRef
     * @return
     * @throws Exception
     */
    static String getConciseTypeName( String typeName, WTContainerRef containerRef )
        throws WTException
    {
        if ( typeName == null || typeName.isEmpty() )
        {
            throw new IllegalArgumentException( "Invalid typeName '" + typeName + "'!" );
        }

//        int index = typeName.lastIndexOf( "." );
//        if ( index > 0 )
//        {
//            String typeDomain = typeName.substring( 0, index );
//            String exchangeDomain = TypeDomainHelper.getExchangeDomain();
//            if ( typeDomain.equals( exchangeDomain ) )
//            {
//                if ( (containerRef == null) || exchangeDomain.equals( TypeDomainHelper.getDomain( containerRef ) ) )
//                {
//                    return typeName.substring( typeName.lastIndexOf( "." ) + 1 );
//                }
//            }
//        }

        return typeName;
    }

	private static LocalizationInfo exportExcelTypeDefinition(
			TypeDefinitionReadView view, String pkg, boolean isFullExport) throws Exception {
		LocalizationInfo typeInfo = null;
		if (config.getExportMode() != 0) {
			typeInfo = LocalizationInfo.newTypeLocalizationInfo(
					getConciseTypeName(view), pkg, view.isModeled());
		}
		
		//System.out.println("exportTypeDefinition, view Name:"+view.getName());
		//System.out.println("Object Type Sheet Index is:"+objectTypeSheetIndex);

		// export type characteristics
		//writeBeginTypeElem(view);

		// export type properties
		//exportProperties(view, typeInfo, XML_TYPE_PROPERTY_VALUE_HANDLER, view);
		
		//export type characteristics and properties in one sheet.
		if (isFullExport)
			exportExcelObjectTypeDefinition(view,typeInfo);

		// export type attributes
		//exportTypeAttributes(view, typeInfo);
		
		exportExcelObjectTypeAttributes(view,typeInfo, isFullExport); //included constraint output

		// export type layouts
		//exportTypeLayouts(view, typeInfo);
		if (isFullExport)
			exportExcelObjectTypeLayouts(view,typeInfo);
		
		// end of type export
		//writeEmptyElem(XML_END_TYPE_TAG, XML_END_TYPE_HANDLER);
		
		//objectTypeSheetIndex++;
		//System.out.println("Now Object Type Sheet index is:"+objectTypeSheetIndex);

		return typeInfo;
	}

	// non-inherited layout
		// |_ non-inherited property
		// |_ non-inherited group
		// |_ non-inherited property
		// |_ non-inherited member
		// |_ non-inherited property
		//
		// inherited layout
		// |_ inherited property
		// |_ non-inherited property
		// |_ inherited group
		// | |_ inherited property
		// | |_ non-inherited property
		// | |_ inherited member
		// | | |_ inherited property
		// | | |_ non-inherited property
		// | |_ non-inherited member (including separator)
		// | |_ non-inherited property
		// |_ non-inherited group
		// |_ non-inherited property
		// |_ non-inherited member
		// |_ non-inherited property
		//
	private static void exportExcelObjectTypeLayouts(TypeDefinitionReadView view,
			LocalizationInfo typeInfo) throws Exception {
		ObjectIdentifier typeId = view.getOid();
		String compHash = "";
		final Set<LayoutDefinitionReadView> layouts=new TreeSet<>(LayoutDefinitionViewComparator.getInstance());
		layouts.addAll(view.getAllLayouts());
		
		if(!layouts.isEmpty()){
			//start to record layout if it is not empty
			//setup object type attribute sheet
			
			String objectName=view.getName();
			String objectDisplayName = view.getDisplayName();
			
			//int layoutIndex=1;
			for(LayoutDefinitionReadView layout: layouts){
				if(config.validateTypes()){
					Collection<ScreenDefinitionReadView> screens = layout.getAllScreens();
					boolean validated=true;
					for(ScreenDefinitionReadView screen: screens){
						TypeIdentifierSet typeFilterSet = SCREEN_TYPEIDENTIFIERSET_MAP.get(screen);
						if(typeFilterSet == null){
							continue;
						}
						if(!typeFilterSet.contains(view.getTypeIdentifier())){
							validated=false;
							break;
						}
					}
					if(!validated){
						continue;
					}
				}
				//Layout is ready to parser
				String screenNames="";
				String profileNames="";
				String defaultGroup="";
				String layoutContext="";
				String layoutName="";
				
				layoutName=layout.getName();		//layout Name
				Collection<ScreenDefinitionReadView> screens = layout.getAllScreens();
		        if (!screens.isEmpty()){
		            StringBuilder builder = new StringBuilder();
		            for (ScreenDefinitionReadView screen : screens){
		                builder.append(screen.getName()).append(",");
		            }
		            builder.deleteCharAt(builder.lastIndexOf(","));
		            screenNames= builder.toString();	//layout screens, could be multiple
		        }
		        
		        Collection<WTGroup> profiles = layout.getAllProfiles();
		        if (!profiles.isEmpty()){
		            StringBuilder builder = new StringBuilder();
		            for (WTGroup group : profiles) {
		                builder.append(group.getName()).append(",");
		            }
		            builder.deleteCharAt(builder.lastIndexOf(","));
		            profileNames=builder.toString();	//profile names, could be multiple
		        }
		        
		        defaultGroup=layout.getDefaultGroup()==null?"":layout.getDefaultGroup();	//default group
		        AttributeTemplateFlavor flavor = AttributeTemplateFlavor.getAttributeTemplateFlavor(layout.getContextId().getClassname());
		        TypeDefinitionReadView typeContext = TYPE_DEF_SERVICE.getTypeDefView(flavor,
		                Long.valueOf(layout.getContextId().getId()));
		        if (typeContext != null) {
		            layoutContext= getConciseTypeName(typeContext);	//context of layout
		        }
		      
                final Set<LayoutComponentReadView> groups = new TreeSet<>(PropertyHolderSortOrderComparator.getInstance());
                groups.addAll(layout.getAllLayoutComponents());
                if (!groups.isEmpty()){
                    for (LayoutComponentReadView group : groups){
                    	GroupDefinitionReadView groupDef=null;
                    	if(group instanceof GroupDefinitionReadView){
                    		groupDef=(GroupDefinitionReadView)group;
                    	}else{
                    		continue;
                    	}
                    	
                        /*LocalizationInfo groupInfo = null;
                        if (config.getExportMode() != 0) {
                            groupInfo = LocalizationInfo.newGroupLocalizationInfo(groupDef.getName(), layoutInfo);
                        }*/
                        
                        String groupName="";
                        String groupStatic="";
                        String groupStyle="";
                        String layoutInherited="";
                        
                        groupName=groupDef.getName();
                        groupStatic= String.valueOf(groupDef.isStatic());
                        DisplayStyleReadView style=groupDef.getDisplayStyle();
                        if(style!=null)
                        	groupStyle=style.getName();
                        
                        // non-inherited group
                        if (typeId.equals(groupDef.getContextId())){
                        	layoutInherited="Defined";
                        }else{
                        	layoutInherited="Inherited";
                        }
                        	
                    	final Set<GroupMembershipReadView> memberships = new TreeSet<>( GroupMemberViewComparator.getInstance() );
                        memberships.addAll(groupDef.getAllMembers());
                        if (!memberships.isEmpty()){
                            for (GroupMembershipReadView membership : memberships){
                                if (membership.getMember() instanceof AttributeDefinitionReadView){
                                   AttributeDefinitionReadView attRv = (AttributeDefinitionReadView) membership.getMember();
                                    // mode 2 will not validate
                                    if (config.validateTypes() && !isValidAttributeForContext(attRv, view)) {
                                        continue;
                                    }
                                    //start to export attribute membership
                                    String memberTypeContext=attRv.getContextTypeView().getName();
                                    String memberName=attRv.getName();
                                    
                                    XSSFRow newRow=objectTypeLayoutSheet.createRow(objectTypeLayoutSheetIndex++);
                                    int colIndex=1;
                                    compHash = objectName + objectDisplayName + layoutInherited + layoutName + screenNames +
                                    		   profileNames + defaultGroup + layoutContext + groupName + groupStatic + groupStyle +
                                    		   memberTypeContext + memberName;
                                    
                                    newRow.createCell(colIndex++).setCellValue(objectName);
                                    newRow.createCell(colIndex++).setCellValue(objectDisplayName);
                                    
                                    newRow.createCell(colIndex++).setCellValue(layoutInherited);
                                    newRow.createCell(colIndex++).setCellValue(layoutName);
                                    newRow.createCell(colIndex++).setCellValue(screenNames);
                                    newRow.createCell(colIndex++).setCellValue(profileNames);
                                    newRow.createCell(colIndex++).setCellValue(defaultGroup);
                                    newRow.createCell(colIndex++).setCellValue(layoutContext);
                                    newRow.createCell(colIndex++).setCellValue(groupName);
                                    newRow.createCell(colIndex++).setCellValue(groupStatic);
                                    newRow.createCell(colIndex++).setCellValue(groupStyle);
                                    newRow.createCell(colIndex++).setCellValue(memberTypeContext);
                                    newRow.createCell(colIndex++).setCellValue(memberName);
                                    newRow.createCell(colIndex++).setCellValue(compHash);
                                }	//end of membership check
                            }	//end of membership loop
                        }	//end of memberships check
                    }	//end of group loop
                }	//end of groups check
			}	//end of layout loop
		}	//end of groups check.
	}
		


	
	/**
	 * Evaluate whether the filter for the current context is valid. The modeled
	 * attribute also is evaluated with the same way.
	 * 
	 * @param context
	 *            The type context to validate for.
	 * @param att
	 *            The attribute's read view
	 * @return true if the propertyis valid, i.e. it passes the filter or no
	 *         filtering is active
	 * @throws WTException
	 *             If there were any errors getting the context's type
	 *             identifier.
	 */
	private static boolean isValidAttributeForContext(
			final AttributeDefinitionReadView att,
			final TypeDefinitionReadView context) throws WTException {
		if (att == null) {
			return false;
		}
		if (context == null) {
			return true;
		}

		final DatatypeReadView datatypeRv = att.getDatatype();
		final PropertyValueReadView typeFilter = datatypeRv
				.getPropertyValueByName(PropertyDefinitionConstants.TYPE_FILTER_PROPERTY);
		if (typeFilter == null) {
			return true;
		}
		final TypeIdentifierSet filterSet = TYPE_IDENTIFIER_FILTERSET_MAP
				.get(datatypeRv);
		return filterSetTest(filterSet, context);
	}

	private static boolean filterSetTest(final TypeIdentifierSet filterSet,
			final TypeDefinitionReadView context) {
		if (filterSet == null) {
			return true; // no filter means everything is valid
		}
		return filterSet.contains(context.getTypeIdentifier());
	}


	private static String constructDefaults(
			Collection<AttributeDefaultValueReadView> defaults,
			ObjectIdentifier typeContext) throws WTException {
		if (defaults.isEmpty()) {
			return null;
		}

		ArrayList<String> values = new ArrayList<>();
		for (AttributeDefaultValueReadView defaultValue : defaults) {
			if (!defaultValue.getContextId().equals(typeContext)) {
				continue;
			}

			Serializable value = defaultValue.getValue();
			String valueString = DataTypesExternalizer.toExternalForm(value);
			values.add(valueString);
			if (logger.isDebugEnabled()) {
				logger.debug("(constructDefaults): value=" + valueString);
			}
		}

		if (!values.isEmpty()) {
			if (logger.isDebugEnabled()) {
				logger.debug("(constructDefaults): defaults="
						+ DataTypesUtility.combine(values
								.toArray(new String[values.size()])));
			}

			return DataTypesUtility.combine(values.toArray(new String[values
					.size()]));
		} else {
			return null;
		}
	}


	/**
	 * Evaluate whether or not the specified property value is valid, according
	 * to it's property definition's type filter, in the specified type context.
	 * 
	 * @param propHolder
	 *            the holder readview of this property value. Must not be null.
	 * @param propValue
	 *            The property value to validate.
	 * @param context
	 *            The type context to validate for. Must not be null.
	 *
	 * @return Whether or not the property value is valid.
	 * @throws WTException
	 *             If there were any errors getting the context's type
	 *             identifier.
	 */
	private static boolean isValidPropValForContext(
			final PropertyHolderReadView propHolder,
			final PropertyValueReadView propValue,
			final TypeDefinitionReadView context) throws WTException {
		if (propValue == null) {
			return false;
		}
		if (context == null) {
			return true;
		}

		final PropertyDefinitionReadView propDef = propValue.getPropDef();
		// check if this property def is overridable
		if (!propDef.isOverridable()) {
			// it isn't, so let's check if the property holder is inherited
			final ReadViewIdentifier propHolderRootContext = propHolder
					.getReadViewIdentifier().getRootContextIdentifier();
			if (propHolderRootContext != null
					&& !context.getOid().equals(propHolderRootContext.getOid())) {
				// the property holder is inherited, so let's check if the
				// property value is not inherited
				if (context.getOid().equals(propValue.getContextId())) {
					// So we are trying override a property value that is not
					// overridable.
					// In this case we shouldn't export it.
					// (normally this shouldn't happen, but in case it does, we
					// don't want to include this in the export loadfile.)
					logger.error("Skipping exporting an overridden property value that is not overridable: "
							+ propValue.getName() + ".");
					return false;
				}
			}
		}

		final TypeIdentifierSet filterSet = PROP_DEF_TYPEIDENTIFIERSET_MAP
				.get(propDef);
		return filterSetTest(filterSet, context);
	}
	/**
	 * Exports all the attributes for the given type.
	 *
	 * If the attribute is inherited and nothing is overriden in the current
	 * type context, then the attribute will not need to be exported and is
	 * skipped.
	 *
	 * @param context
	 *            the type currently being exported
	 * @param typeInfo
	 * @throws Exception
	 */
	private static void exportExcelObjectTypeAttributes(TypeDefinitionReadView context,
			LocalizationInfo typeInfo, boolean isFullExport) throws Exception {
		
		final Set<AttributeDefinitionReadView> attributes = new TreeSet<>(
				AttributeDefinitionViewComparator.getInstance());
		Collection<AttributeDefinitionReadView> exportedAttributes = new ArrayList<AttributeDefinitionReadView>(
				context.getAllAttributes().size());
		attributes.addAll(context.getAllAttributes());
		
		//String objectName = context.getName();
		//String objectDisplayName = context.getDisplayName();
		
		//initAttrubiteSheetTitle(attributeSheet);
		
		//setup attributes constraints sheet
		//XSSFSheet attributeConstraitSheet = workbook.createSheet(getValidSheetName(workbook,sheetInitName+" Constraints"));
		//initAttributeConstraintSheetTitle(attributeConstraitSheet);
		
		for (AttributeDefinitionReadView att : attributes) {
			//exportAnAttribute(att, context, typeInfo, exportedAttributes);
			exportExcelAnAttribute(context,att,typeInfo,exportedAttributes, isFullExport);
		}
	}
	
	private static void exportExcelAnAttribute(TypeDefinitionReadView context,AttributeDefinitionReadView att,
			LocalizationInfo typeInfo,	Collection<AttributeDefinitionReadView> exportedAttributes, boolean isFullExport)
			throws WTException, Exception {
		
		/*
		 //this logical needs more check, why!
		if (exportedAttributes.contains(att)) {
			// attribute was already exported, don't export it again
			//System.out.println("exportExcelAnAttribute found exported attribute:"+att.getName());
			return;
		}
		exportedAttributes.add(att);*/
		
		if (context.getOid().equals(att.getTypeDefId())) {
			//object specific attributes
			if (config.validateTypes() && !isValidAttributeForContext(att, context)) { // this property value is not valid
						// in the current type context, so don't export it. LOG that this one was skipped due to filter
				final String typeName = context.getName();
				final String attributeName = att.getName();
				
				System.out.println("exportExcelAnAttribute " + "Exporting type " + typeName
					+"the attribute on that type " + attributeName
							+ " is excluded by filter and won't be exported!");
				if (logger.isDebugEnabled()) {
					
					logger.debug("(exportTypeAttributes): ");
					logger.debug("Exporting type " + typeName);
					logger.debug("the attribute on that type " + attributeName
							+ " is excluded by filter and won't be exported!");
				}
				return;
			} else {
				AttributeDefinitionReadView sourceTextAttReadView = att.getSourceTextAttribute();
				if (sourceTextAttReadView != null) {
					// make sure that the source text attribute is exported
					// before translated text attribute
					exportExcelAnAttribute(context,sourceTextAttReadView, typeInfo,
							exportedAttributes, isFullExport);
					return;
				}else{
					exportExcelAttCharacteristics(context,att,typeInfo, "Defined", isFullExport);
					return;
				}
				//
			}
		} else {
			Collection<AttributeDefaultValueReadView> defaults = att.getAllDefaultValues();
			boolean inherited = false;
			for (AttributeDefaultValueReadView defaultVal : defaults) {
				if (!context.getOid().equals(defaultVal.getContextId())) {
					inherited=true;
				}
			}
			if(inherited){
				exportExcelAttCharacteristics(context,att,typeInfo,"Inherited with change", isFullExport);
				return;
			}
		}

		LocalizationInfo attInfo = null;
		if (config.getExportMode() != 0) {
			attInfo = LocalizationInfo.newAttributeLocalizationInfo(att
					.getName(), typeInfo, LWCHardAttDefinition.class.getName()
					.equals(att.getAttDefClass()));
			PropertyValueReadView value = att
					.getPropertyValueByName(PropertyDefinitionConstants.SYSTEM_HIDDEN_PROPERTY);
			if (value != null && (value.getValue() instanceof Boolean)
					&& ((Boolean) value.getValue()).booleanValue()) {
				attInfo.setHidden(true);
				attInfo.setComments("This attribute is hidden from Type Manager UI.");
				exportExcelAttCharacteristics(context,att,typeInfo,"Hidden", isFullExport);
				return;
			}
		}
		// attribute property
		Collection<PropertyValueReadView> properties = att.getAllProperties();
		if (!properties.isEmpty()) {
			boolean inherited = false;
			for (PropertyValueReadView propValue : properties) {
				if (config.validateTypes()
						&& !isValidPropValForContext(att, propValue, context)) { 
					continue;
				}				// only export property values that are not inherited
				if (!context.getOid().equals(propValue.getContextId())) {
					inherited=true;
				}
			}
			if(inherited){
				exportExcelAttCharacteristics(context,att,typeInfo,"Inherited", isFullExport);
			}
		}

	}
	
	
	private static void exportExcelAttConstraintToAttributeSheet(TypeDefinitionReadView context,
            AttributeDefinitionReadView attView, LocalizationInfo typeInfo,
            boolean isCondition, int colIndex,XSSFRow newRow, String defined, String compHash)throws Exception{
	    String valueRequired = new String();
	    String stringByte = new String();
	    String stringLength = new String();
	    String singleValued = new String();
	    String immutable = new String();
	    String hiddenConst = new String();
	    String hiddenValueConst = new String();
	    String lowerCase = new String();
	    String upperCase = new String();
	    String rangeConst = new String();
	    String discreteSetConst = new String();
	    String suggestedValuesConst = new String();
	    String typeIden = new String();
	    String globalEnum = new String();
	    String inheritedInfo = new String();
        final Set<ConstraintDefinitionReadView> constraints = new TreeSet<>( 
                ConstraintDefinitionViewComparator.getInstance() );
        if (isCondition) {
            constraints.addAll(attView.getAllConditions());
        }
        else {
            constraints.addAll(attView.getAllConstraints());
        }

        final Set<ConstraintDefinitionReadView> constraintsToExport = new TreeSet<>( 
                ConstraintDefinitionViewComparator.getInstance() );
        
        for (ConstraintDefinitionReadView constraint : constraints){
            /*
            if (constraint.isModeled()) {
                //System.out.println(" it is Modeled, bypass!");
                continue;
            }*/

            String propertyHolderName;
            TypeIdentifierSet typeFilterSet;
            String resourceKey;

            if (config.validateTypes() ) { // mode0, mode1, mode3
                if (isCondition) {
                    String attName = constraint.getAttName();
                    AttributeDefinitionReadView attRv = context.getAttributeByName(attName);
                    try {
                        if (!isValidAttributeForContext(attRv, context)) {
                            //System.out.println("Doesn't mattch condition!");
                            continue;
                        }
                    } catch (WTException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                        //System.out.println("Error happen, bypass!");
                        continue;
                    }
                }
                if (isVisibilityConstraint(constraint)){
                    ScreenDefinitionReadView screen = (ScreenDefinitionReadView)constraint.getRuleDataObj().getFilter();
                    typeFilterSet = SCREEN_TYPEIDENTIFIERSET_MAP.get(screen);
                    propertyHolderName = PropertyHolderHelper.getDisplayName(screen, Locale.US);
                    resourceKey= serverResource.INVALID_VISIBILITY_CONSTRAINT;
                }
                else {
                    ConstraintRuleDefinitionReadView constraintRuleView = constraint.getRule();
                    typeFilterSet = CONSTRAINTRULE_TYPEIDENTIFIERSET_MAP.get(constraintRuleView);
                    propertyHolderName = PropertyHolderHelper.getDisplayName(constraintRuleView, Locale.US);
                    resourceKey= serverResource.INVALID_CONSTRAINT_RULE;
                }
                
//                if (typeFilterSet!=null && !typeFilterSet.contains(context.getTypeIdentifier())) {
//                    String attName;
//                    if (attView.getPropertyValueByName(PropertyDefinitionConstants.DISPLAY_NAME_PROPERTY) != null){
//                        attName = attView.getPropertyValueByName(PropertyDefinitionConstants.DISPLAY_NAME_PROPERTY).getValueAsString(Locale.US, true);
//                    }else{
//                        attName = attView.getName();
//                    }
//                    logger.error( WTMessage.getLocalizedMessage(serverResource.class.getName(), resourceKey,
//                                 new Object[]{attName, propertyHolderName}, Locale.US) );
//                    
//                    //System.out.println(attName+" has been filtered!");
//                    continue;
//                }
            }
            
            if (!constraintsToExport.contains(constraint)/* && context.getOid().equals(constraint.getContextId())*/){
                constraintsToExport.add(constraint);
                //System.out.println("Added one!");
            }
        }
        
        for (ConstraintDefinitionReadView constraint : constraintsToExport) {
            String specialText="Inherited";
 
            try {
                if (context.getOid().equals(constraint.getContextId())
                        || (isCondition && exportInheritedCondition(constraint, context.getOid()))) 
                {
                    // non-inherited constraint
                    //writeBeginConstraintElem(attInfo, constraint, isCondition, typeContext);
                    specialText="Defined";
                }
            } catch (Exception e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
                specialText="Defined";
            }
            
            if (constraint.isModeled())
                specialText = "Modeled";


            if("ValueRequiredConstraint".equals(getLastSegment(constraint.getRule().getRuleClassname(),"."))) {
                valueRequired = valueRequired +" "+ getRuleData(constraint,isCondition);
                if(defined != null)
                inheritedInfo = inheritedInfo + "\n" + specialText + ": " + getLastSegment(constraint.getRule().getRuleClassname(),".");
                newRow.createCell(colIndex+1).setCellValue(valueRequired);
                compHash += valueRequired;
            }

//            if("StringByteLengthConstraint".equals(getLastSegment(constraint.getRule().getRuleClassname(),"."))) {
//                stringByte = stringByte +" "+ getRuleData(constraint,isCondition);
//                
//                newRow.createCell(colIndex+2).setCellValue(stringByte);
//            }

            if("StringLengthConstraint".equals(getLastSegment(constraint.getRule().getRuleClassname(),"."))) {
                stringLength = stringLength + " " + getRuleData(constraint,isCondition);
                if(defined != null)
                inheritedInfo = inheritedInfo + "\n" + specialText + ": " + getLastSegment(constraint.getRule().getRuleClassname(),".");
                newRow.createCell(colIndex+2).setCellValue(stringLength);
                compHash += stringLength;
            }

            if("SingleValuedConstraint".equals(getLastSegment(constraint.getRule().getRuleClassname(),"."))) {
                singleValued = singleValued + " " + getRuleData(constraint,isCondition);
                if(defined != null)
                inheritedInfo = inheritedInfo + "\n" + specialText + ": " + getLastSegment(constraint.getRule().getRuleClassname(),".");
                newRow.createCell(colIndex+3).setCellValue(singleValued);
                compHash += singleValued;
            }

            if("ImmutableConstraint".equals(getLastSegment(constraint.getRule().getRuleClassname(),"."))) {
                immutable = immutable + " " + getRuleData(constraint,isCondition);
                if(defined != null)
                inheritedInfo = inheritedInfo + "\n" + specialText + ": " + getLastSegment(constraint.getRule().getRuleClassname(),".");
                newRow.createCell(colIndex+4).setCellValue(immutable);
                compHash += immutable;
            }
            
            if("HiddenConstraint".equals(getLastSegment(constraint.getRule().getRuleClassname(),"."))) {
                hiddenConst = hiddenConst + " " + getRuleData(constraint,isCondition);
                if(defined != null)
                inheritedInfo = inheritedInfo + "\n" + specialText + ": " + getLastSegment(constraint.getRule().getRuleClassname(),".");
                newRow.createCell(colIndex+5).setCellValue(hiddenConst);
                compHash += hiddenConst;
            }
            if("ValueHiddenConstraint".equals(getLastSegment(constraint.getRule().getRuleClassname(),"."))) {
                hiddenValueConst = hiddenValueConst + " " + getRuleData(constraint,isCondition);
                if(defined != null)
                inheritedInfo = inheritedInfo + "\n" + specialText + ": " + getLastSegment(constraint.getRule().getRuleClassname(),".");
                newRow.createCell(colIndex+6).setCellValue(hiddenValueConst);
                compHash += hiddenValueConst;
            }
            
            if("LowerCaseConstraint".equals(getLastSegment(constraint.getRule().getRuleClassname(),"."))) {
                lowerCase = lowerCase + " " + getRuleData(constraint,isCondition);
                if(defined != null)
                inheritedInfo = inheritedInfo + "\n" + specialText + ": " + getLastSegment(constraint.getRule().getRuleClassname(),".");
                newRow.createCell(colIndex+7).setCellValue(lowerCase);
                compHash += lowerCase;
            }
            
            if("UpperCaseConstraint".equals(getLastSegment(constraint.getRule().getRuleClassname(),"."))) {
                upperCase = upperCase + " " + getRuleData(constraint,isCondition);
                if(defined != null)
                inheritedInfo = inheritedInfo + "\n" + specialText + ": " + getLastSegment(constraint.getRule().getRuleClassname(),".");
                newRow.createCell(colIndex+8).setCellValue(upperCase);
                compHash += upperCase;
            }
            if("RangeConstraint".equals(getLastSegment(constraint.getRule().getRuleClassname(),"."))) {
                rangeConst = rangeConst + "\n" + getRuleData(constraint,isCondition);
                if(defined != null)
                inheritedInfo = inheritedInfo + "\n" + specialText + ": " + getLastSegment(constraint.getRule().getRuleClassname(),".");
                newRow.createCell(colIndex+9).setCellValue(rangeConst);
                compHash += rangeConst;
            }
            if("TypeIdentifierSetConstraint".equals(getLastSegment(constraint.getRule().getRuleClassname(),"."))) {
                typeIden = typeIden + " " + getRuleData(constraint,isCondition);
                if(defined != null)
                inheritedInfo = inheritedInfo + "\n" + specialText + ": " + getLastSegment(constraint.getRule().getRuleClassname(),".");
                newRow.createCell(colIndex+10).setCellValue(typeIden);
                compHash += typeIden;
            }
            
            if("DiscreteSetConstraint".equals(getLastSegment(constraint.getRule().getRuleClassname(),"."))) {
                discreteSetConst = getRuleData(constraint,isCondition) + "\n" + discreteSetConst;
                if(defined != null)
                inheritedInfo = inheritedInfo + "\n" + specialText + ": " + getLastSegment(constraint.getRule().getRuleClassname(),".");
                newRow.createCell(colIndex+11).setCellValue(discreteSetConst);
                compHash += discreteSetConst;
            }
            
            if("SuggestedValuesConstraint".equals(getLastSegment(constraint.getRule().getRuleClassname(),"."))) {
                suggestedValuesConst = suggestedValuesConst + " " + getRuleData(constraint,isCondition);
                if(defined != null)
                inheritedInfo = inheritedInfo + "\n" + specialText + ": " + getLastSegment(constraint.getRule().getRuleClassname(),".");
                newRow.createCell(colIndex+12).setCellValue(suggestedValuesConst);
                compHash += suggestedValuesConst;
            }
            //newRow.createCell(colIndex++).setCellValue(getRuleData(constraint,isCondition));

            EnumerationDefinitionReadView enumView=constraint.getEnumDef();
            if (enumView!=null && enumView.getName()!=null){
                globalEnum = enumView.getName();
                newRow.createCell(colIndex+13).setCellValue(globalEnum);
                compHash += globalEnum;
            }
            if (enumView!=null && enumView.getName()==null){
                if (enumView.getMasterId()!=null){
                    enumView = BASE_DEF_SERVICE.getEnumDefView(enumView.getMasterId().getId());
                    String enumName = enumView.getName()==null?"<No Name>":enumView.getName();
                    globalEnum = enumName;
                    newRow.createCell(colIndex+13).setCellValue(globalEnum);
                    compHash += globalEnum;
                }else{
                    globalEnum = " No Enum Master:";
                    newRow.createCell(colIndex+13).setCellValue(globalEnum);
                    compHash += globalEnum;
                }
            }
            if(defined != null)
            newRow.createCell(colIndex).setCellValue(inheritedInfo);
            compHash += inheritedInfo;
//            newRow.createCell(colIndex++).setCellValue(getRuleData(constraint,isCondition));
        }
        newRow.createCell(compCol).setCellValue(compHash);
	}
	
	
	
	private static void exportExcelAttConstraintCharacteristics(TypeDefinitionReadView context,
			AttributeDefinitionReadView attView, LocalizationInfo typeInfo,
			boolean isCondition)throws Exception{
		
		final Set<ConstraintDefinitionReadView> constraints = new TreeSet<>( 
				ConstraintDefinitionViewComparator.getInstance() );
        if (isCondition) {
            constraints.addAll(attView.getAllConditions());
        }
        else {
            constraints.addAll(attView.getAllConstraints());
        }

        final Set<ConstraintDefinitionReadView> constraintsToExport = new TreeSet<>( 
				ConstraintDefinitionViewComparator.getInstance() );
        
        for (ConstraintDefinitionReadView constraint : constraints){
        	/*
        	if (constraint.isModeled()) {
            	//System.out.println(" it is Modeled, bypass!");
                continue;
            }*/

            String propertyHolderName;
            TypeIdentifierSet typeFilterSet;
            String resourceKey;

            if (config.validateTypes() ) { // mode0, mode1, mode3
                if (isCondition) {
                    String attName = constraint.getAttName();
                    AttributeDefinitionReadView attRv = context.getAttributeByName(attName);
                    try {
						if (!isValidAttributeForContext(attRv, context)) {
							//System.out.println("Doesn't mattch condition!");
						    continue;
						}
					} catch (WTException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						//System.out.println("Error happen, bypass!");
						continue;
					}
                }
                if (isVisibilityConstraint(constraint)){
                    ScreenDefinitionReadView screen = (ScreenDefinitionReadView)constraint.getRuleDataObj().getFilter();
                    typeFilterSet = SCREEN_TYPEIDENTIFIERSET_MAP.get(screen);
                    propertyHolderName = PropertyHolderHelper.getDisplayName(screen, Locale.US);
                    resourceKey= serverResource.INVALID_VISIBILITY_CONSTRAINT;
                }
                else {
                    ConstraintRuleDefinitionReadView constraintRuleView = constraint.getRule();
                    typeFilterSet = CONSTRAINTRULE_TYPEIDENTIFIERSET_MAP.get(constraintRuleView);
                    propertyHolderName = PropertyHolderHelper.getDisplayName(constraintRuleView, Locale.US);
                    resourceKey= serverResource.INVALID_CONSTRAINT_RULE;
                }
                
                if (typeFilterSet!=null && !typeFilterSet.contains(context.getTypeIdentifier())) {
                    String attName;
                    if (attView.getPropertyValueByName(PropertyDefinitionConstants.DISPLAY_NAME_PROPERTY) != null){
                        attName = attView.getPropertyValueByName(PropertyDefinitionConstants.DISPLAY_NAME_PROPERTY).getValueAsString(Locale.US, true);
                    }else{
                        attName = attView.getName();
                    }
                    logger.error( WTMessage.getLocalizedMessage(serverResource.class.getName(), resourceKey,
                                 new Object[]{attName, propertyHolderName}, Locale.US) );
                    
                    //System.out.println(attName+" has been filtered!");
                    continue;
                }
            }
            
            if (!constraintsToExport.contains(constraint) && context.getOid().equals(constraint.getContextId())){
            	constraintsToExport.add(constraint);
            	//System.out.println("Added one!");
            }
        }
        
        for (ConstraintDefinitionReadView constraint : constraintsToExport) {
            String specialText="Inherited";
            
            try {
				if (context.getOid().equals(constraint.getContextId())
				        || (isCondition && exportInheritedCondition(constraint, context.getOid()))) 
				{
				    // non-inherited constraint
				    //writeBeginConstraintElem(attInfo, constraint, isCondition, typeContext);
				    specialText="Defined";
				}
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
				specialText="Defined";
			}
            
            if (constraint.isModeled())
            	specialText = "Modeled";

            XSSFRow newRow=objectAttributeConstraintSheet.createRow(objectAttributeConstraintSheetIndex++);
            int colIndex = 1;
            newRow.createCell(colIndex++).setCellValue(getConciseTypeName(context));	//object internal name
            newRow.createCell(colIndex++).setCellValue(context.getDisplayName());	//object display name
            
            newRow.createCell(colIndex++).setCellValue(specialText);
            //newRow.createCell(colIndex++).setCellValue(context.getDisplayName());	//type display name
            newRow.createCell(colIndex++).setCellValue(attView.getName());			//internal Name
            newRow.createCell(colIndex++).setCellValue(attView.getDisplayName());	//attribute display name
            //newRow.createCell(colIndex++).setCellValue(contextType);
            newRow.createCell(colIndex++).setCellValue(getLastSegment(constraint.getRule().getRuleClassname(),".")); //rule
            newRow.createCell(colIndex++).setCellValue(getLastSegment(constraint.getRule().getDefClassname(),".")); //base

            //newRow.createCell(colIndex++).setCellValue(getRuleData(constraint,isCondition));
            
            EnumerationDefinitionReadView enumView=constraint.getEnumDef();
            if (enumView!=null && enumView.getName()!=null){
            	newRow.createCell(colIndex++).setCellValue(enumView.getName());
            }else if (enumView!=null && enumView.getName()==null){
            	if (enumView.getMasterId()!=null){
            		enumView = BASE_DEF_SERVICE.getEnumDefView(enumView.getMasterId().getId());
            		newRow.createCell(colIndex++).setCellValue(enumView.getName()==null?"<No Name>":enumView.getName());
            	}else{
            		newRow.createCell(colIndex++).setCellValue("No Enum Master");
            	}
            }else{
            	colIndex++;
            }
            newRow.createCell(colIndex++).setCellValue(getRuleData(constraint,isCondition));
        }
	}
	
	private static String getRuleData(ConstraintDefinitionReadView view, boolean isCondition){
		try{
			ConstraintRuleDefinitionReadView rule = view.getRule();
	        if (rule==null)
	        	return "";
	        
	        if (rule.getDefClassname().equals(LWCBasicConstraint.class.getName())){
	            try{
	            	if (rule.getRuleClassname().equals(StringLengthConstraint.class.getName())){
	            		
	            		//String Length
	            		if(view.getRuleData() instanceof AnalogSet){
	            			AnalogSet aset=(AnalogSet)(view.getRuleData());
	            			String returnString="Range: ";
	            			for(wt.util.range.Range range: aset.getRanges()){
	            				//System.out.println(view.getAttName()+" ->Rang:"+ range.toString());
	            				returnString += range.toString()+";";
	            			}
	            			return returnString.substring(0, returnString.length()-1);
	            		}else{
	            			return "StringLengthConstraint:"+view.getRuleData().getClass().getName();
	            		}
	            		
	            	} else if(rule.getRuleClassname().equals(DiscreteSetConstraint.class.getName())){
	            		if (view.getRuleData() instanceof DiscreteSet){
	            			DiscreteSet dset=(DiscreteSet)(view.getRuleData());
	            			String returnString="";
	            			
	            			for (Object obj:dset.getElements()){
	            				returnString += obj.toString() +"|";
	            			}
	            			return returnString.substring(0, returnString.length()-1);
	            		}else{
	            			return "DiscreteSet data!"+view.getRuleData().getClass().getName();
	            		}
	            		
	            		
	            	} else if (rule.getRuleClassname().equals(SingleValuedConstraint.class.getName())){
	            		if(view.getRuleData() instanceof EmptySet){
		            		EmptySet eset=(EmptySet)(view.getRuleData());
		            		if(eset.isNegated())
		            			return "true";
		            		else
		            			return "false";
		            	}else{
		            		return "true";
		            	}
	            		
	            	} else if (rule.getRuleClassname().equals(StringByteLengthConstraint.class.getName())){
	            		if(view.getRuleData() instanceof AnalogSet){
	            			AnalogSet aset=(AnalogSet)(view.getRuleData());
	            			String returnString="Range: ";
	            			for(wt.util.range.Range range: aset.getRanges()){
	            				//System.out.println(view.getAttName()+" ->Rang:"+ range.toString());
	            				returnString += range.toString()+";";
	            			}
	            			return returnString.substring(0, returnString.length()-1);
	            		}else{
	            			return "StringByteLengthConstraint:"+view.getRuleData().getClass().getName();
	            		}
	            	
	            	} else if (rule.getRuleClassname().equals(ValueRequiredConstraint.class.getName())){
	            		if(view.getRuleData() instanceof EmptySet){
		            		EmptySet eset=(EmptySet)(view.getRuleData());
		            		if(eset.isNegated())
		            			return "true";
		            		else
		            			return "false";
		            	}else{
		            		return "true";
		            	}
		            } else if(rule.getRuleClassname().equals(ImmutableConstraint.class.getName())){
		            	if(view.getRuleData() instanceof EmptySet){
		            		EmptySet eset=(EmptySet)(view.getRuleData());
		            		if(eset.isNegated())
		            			return "true";
		            		else
		            			return "false";
		            	}else{
		            		return "true";
		            	}
	            		
	            	}else if(rule.getRuleClassname().equals(RangeConstraint.class.getName())){
	            		//DiscreteSetConstraint
	            		if(view.getRuleData() instanceof AnalogSet){
	            			AnalogSet aset=(AnalogSet)(view.getRuleData());
	            			String returnString="Range: ";
	            			for(wt.util.range.Range range: aset.getRanges()){
	            				//System.out.println(view.getAttName()+" ->Rang:"+ range.toString());
	            				returnString += range.toString()+";";
	            			}
	            			return returnString.substring(0, returnString.length()-1);
	            		}
	            		
	            	}else if(rule.getRuleClassname().equals(UpperCaseConstraint.class.getName())){
	            		if(view.getRuleData() instanceof EmptySet){
		            		EmptySet eset=(EmptySet)(view.getRuleData());
		            		if(eset.isNegated())
		            			return "true";
		            		else
		            			return "false";
		            	}else{
		            		return "true";
		            	}
	            	}else if(rule.getRuleClassname().equals(LowerCaseConstraint.class.getName())){
	            		if(view.getRuleData() instanceof EmptySet){
		            		EmptySet eset=(EmptySet)(view.getRuleData());
		            		if(eset.isNegated())
		            			return "true";
		            		else
		            			return "false";
		            	}else{
		            		return "true";
		            	}
	            	}else if(rule.getRuleClassname().equals(SuggestedValuesConstraint.class.getName())){
	            		if (view.getRuleData() instanceof DiscreteSet){
	            			DiscreteSet dset=(DiscreteSet)(view.getRuleData());
	            			String returnString="";
	            			
	            			for (Object obj:dset.getElements()){
	            				returnString += obj.toString() +"|";
	            			}
	            			return returnString.substring(0, returnString.length()-1);
	            		}else{
	            			return "SuggestedValuesConstraint data!"+view.getRuleData().getClass().getName();
	            		}
	            		
	            		
	            	}
	            	
	            	if (view.getRuleData() != null){
		            	 if ((TypeInstanceIdentifier.class.getName().equals(rule.getDatatype().getName()) ||
		                     WCTypeInstanceIdentifier.class.getName().equals( rule.getDatatype().getName()))
		                        && (TypeIdentifierSetConstraint.class.getName().equals(rule.getRuleClassname())
		                        || DiscreteSetConstraint.class.getName().equals(rule.getRuleClassname()))){
		                	
		                    if (TypeIdentifierSetConstraint.class.getName().equals(rule.getRuleClassname())) {
		                        return removeDomainFromTypeNames(((ConstraintDefinitionReadView.ReferenceConstraintRuleDataCarrier) view
		                                        .getRuleData()).toString());
		                    }
		                    else {
		                        return ((ConstraintDefinitionReadView.ReferenceConstraintRuleDataCarrier) view.getRuleData())
		                                        .toString();
		                    }
		                }else {
		                    return rule.getRuleClassname()+"||"+DataTypesExternalizer.toExternalForm(view.getRuleData());
		                }
		            }else {
		                return "";
		            }
	            }catch ( Exception wte ) {
	                logger.error( wte, wte );
	                return "";
	            }
	            
	        } else if (rule.getDefClassname().equals(LWCFilterBasedConstraint.class.getName())) {
	            if (view.getFilter() instanceof ScreenDefinitionReadView) {
	                return SCREEN_DEFINITION_PREFIX
	                        + ((ScreenDefinitionReadView) view.getFilter()).getName();
	            } else if (view.getFilter() instanceof WTGroup) {
	                return PROFILE_PREFIX + ((WTGroup) view.getFilter()).getName();
	            }
	        } else if (rule.getDefClassname().equals(LWCEnumerationBasedConstraint.class.getName())) {
	            EnumerationDefinitionReadView enumView = view.getEnumDef();
	            if (enumView != null) {
	            	if(enumView.getName()!=null){
	            		expEnumDefs.add(enumView);
	            		return getEnumValues(enumView);
	            	}else if (enumView.getName()==null && enumView.getMasterId()!=null) {
	            	    String enumValues = getEnumValues(enumView);
	            	    enumView = BASE_DEF_SERVICE.getEnumDefView(enumView.getMasterId().getId());
	            	    if (enumView != null){
	                        expEnumDefs.add(enumView);
	                        //newRow.createCell(colIndex++).setCellValue("External Enum:"+constraint.getEnumDef().toString());
	                        return enumValues;
	                    }else{
	                        return "Enumeration without Definition!";
	                    }
	            	}
	                
	            }else{
	            	return "Enumeration without instance!";
	            }
	        }
	        return "UnDefined";
	        
		}catch(Exception e){
			e.printStackTrace();
			return "Exception";
		}
	}

    public static String getEnumValues(EnumerationDefinitionReadView enumView) {
        Collection<EnumerationMembershipReadView> memberships=enumView.getAllMemberships();
        String additionalNote=enumView.getName()==null?"<No Name>:":enumView.getName()+":";
        
        for (EnumerationMembershipReadView membership : memberships){
            EnumerationEntryReadView entry = membership.getMember();
        
            for (PropertyValueReadView propValue : entry.getAllProperties()){
            	if (propValue.getName().equalsIgnoreCase("selectable")){
            	    if(propValue.getValueAsString().equals("true")){
            	        additionalNote += entry.getName()+";";
            	        break;
            	    }        		
            		
            	}
            }
            
        }
        return (additionalNote.substring(0,additionalNote.length()-1));
    }
	
	private static void exportExcelAttCharacteristics(TypeDefinitionReadView context,
			AttributeDefinitionReadView att, LocalizationInfo typeInfo,String specialText, boolean isFullExport)
			throws Exception {
		// non-inherited attribute
		//writeBeginAttributeElem(att, typeContext);
		XSSFRow newRow = objectAttributeSheet.createRow(objectAttributeSheetIndex++);
		int colIndex=1;
		//populate all attribute properties
		String displayName="";
		String displayNameUS="";
		String displayNameDE="";
		String structureFilterable="";
		String inputFieldType="";
		String description="";
		String defaultValueDisplayMode="";
		String systemReadOnly="";
		String systemHidden="";
		String toolTip="";
		String selectionListStyle="";
		String mapping="";
		//String jcaID="";
		String compHash = "";
		
		String objectName=getConciseTypeName(context); //context.getName();
		String objectDisplayName = context.getDisplayName();
		
		Collection<PropertyValueReadView> properties = att.getAllProperties();
		if (!properties.isEmpty()) {
			for (PropertyValueReadView propValue : properties) {
				/*
				if (config.validateTypes()
						&& !isValidPropValForContext(att, propValue, context)) { 
					continue;
				}*/
				//String propString=propValue.getName()+":"+propValue.getValueAsString();
				String propName=propValue.getName();
				if(propName.equalsIgnoreCase("displayName")){
					displayName=propValue.getValueAsString();
					displayNameUS=propValue.getValueAsString(Locale.US, true);
					displayNameDE=propValue.getValueAsString(Locale.GERMAN, true);
				}
				else if (propName.equalsIgnoreCase("structure_filterable"))
					structureFilterable=propValue.getValueAsString();
				else if (propName.equalsIgnoreCase("INPUT_FIELD_TYPE"))
					inputFieldType=propValue.getValueAsString();
				else if (propName.equalsIgnoreCase("description"))
					description=propValue.getValueAsString();
				else if (propName.equalsIgnoreCase("default_value_display_mode"))
					defaultValueDisplayMode=propValue.getValueAsString();
				else if (propName.equalsIgnoreCase("systemreadonly"))
					systemReadOnly=propValue.getValueAsString();
				else if (propName.equalsIgnoreCase("systemHidden"))
					systemHidden=propValue.getValueAsString();
				else if (propName.equalsIgnoreCase("tooltip"))
					toolTip=propValue.getValueAsString();
				else if (propName.equalsIgnoreCase("selection_list_style"))
					selectionListStyle=propValue.getValueAsString();
				else if(propName.equalsIgnoreCase("mapping"))
					mapping=propValue.getValueAsString();
				/*else if (propName.equalsIgnoreCase("JCA_ID"))
					jcaID=propValue.getValueAsString();*/
				
				//newRow.createCell(colIndex).setCellValue(propString);
				//colIndex++;
			}
		}
		
		/*
		ObjectIdentifier oid = att.getOid();
		if (oid != null) {
			//typeData.put(XML_OBJECT_ID, oid.getStringValue());
			newRow.createCell(0).setCellValue(specialText+" "+oid.getStringValue());
		}*/
		//typeData.put(XML_NAME, view.getName());
		newRow.createCell(colIndex++).setCellValue(objectName);	//Object internal Name
		newRow.createCell(colIndex++).setCellValue(objectDisplayName);		//display name
		newRow.createCell(colIndex++).setCellValue(specialText);
		
		newRow.createCell(colIndex++).setCellValue(att.getName());	//internal Name
		newRow.createCell(colIndex++).setCellValue(displayName);		//display name
		newRow.createCell(colIndex++).setCellValue(displayNameUS);
		newRow.createCell(colIndex++).setCellValue(displayNameDE);//display name DE
		
		//typeData.put(XML_ATTRIBUTE_DEFINITION_CLASSNAME, view.getAttDefClass());
//		newRow.createCell(colIndex++).setCellValue(getLastSegment(att.getAttDefClass(),"."));	//def class
		//typeData.put(XML_DATATYPE, view.getDatatype().getName());
		newRow.createCell(colIndex++).setCellValue(getLastSegment(att.getDatatype().getName(),".")); //data type
		
		compHash = objectName + objectDisplayName + specialText + att.getName() + displayName + displayNameUS + displayNameDE + (getLastSegment(att.getDatatype().getName(),"."));

		AttributeDefDefaultView iba = att.getIBARefView();
		if (iba != null) {
			//typeData.put(XML_ATTRIBUTE_IBA, iba.getName());
			newRow.createCell(colIndex++).setCellValue(iba.getName());	//IBA Name
			compHash += iba.getName();
			expIBAs.put(iba.getName(), iba);
		} else {
			//typeData.put(XML_ATTRIBUTE_IBA, null);
			colIndex++;
		}

		QuantityOfMeasureDefaultView qoM = att.getQoM();	//QoM Name
		if (qoM != null) {
			//typeData.put(XML_ATTRIBUTE_QOM, qoM.getName());
			newRow.createCell(colIndex++).setCellValue(qoM.getName());
			compHash += qoM.getName();
		} else {
			//typeData.put(XML_ATTRIBUTE_QOM, null);
			colIndex++;
		}

//		DisplayStyleReadView style = att.getViewDisplayStyle();
//		if (style != null) {
//			//typeData.put(XML_ATTRIBUTE_VIEW_DISPLAYSTYLE, style.getName());
//			newRow.createCell(colIndex++).setCellValue(style.getName());	//view style
//		}else{
//			colIndex++;
//		}

//		style = att.getEditDisplayStyle();
//		if (style != null) {
//			//typeData.put(XML_ATTRIBUTE_EDIT_DISPLAYSTYLE, style.getName());
//			newRow.createCell(colIndex++).setCellValue(style.getName());	//edit style
//		}else{
//			colIndex++;
//		}

		Collection<AttributeDefaultValueReadView> defaults = att.getAllDefaultValues();
		String defaultValues = constructDefaults(defaults, context.getOid());
		if (defaultValues != null) {
			//typeData.put(XML_ATTRIBUTE_DEFAULTS, defaultValues);
			newRow.createCell(colIndex++).setCellValue(getLastSegment(defaultValues,"."));	//default Value
			compHash += (getLastSegment(defaultValues,"."));
		} else {
			//typeData.put(XML_ATTRIBUTE_DEFAULTS, null);
			colIndex++;
		}

		AttributeDefinitionReadView sourceTextAttr = att.getSourceTextAttribute();
		if (sourceTextAttr != null) {
			//typeData.put(XML_ATTRIBUTE_SOURCE_TEXT_ATTR,sourceTextAttr.getName());
			newRow.createCell(colIndex++).setCellValue(sourceTextAttr.getName());	//source Name
			compHash += sourceTextAttr.getName();
		}else{
			colIndex++;
		}

		String translationDictionary = att.getTranslationDictionary();
		if (translationDictionary != null) {
			//typeData.put(XML_ATTRIBUTE_TRANSLATION_DICTIONARY,translationDictionary);
			newRow.createCell(colIndex++).setCellValue(translationDictionary);	//translation dictionary
			compHash += translationDictionary;
		}else{
			colIndex++;
		}
		
		/* don't need IBA reference
		if (att.getAttDefClass().equals(LoaderHelper.IBA_ATTRIBUTE_DEFINITION)) {
			AttributeDefDefaultView ibaDef = att.getIBARefView();
			newRow.createCell(colIndex++).setCellValue(ibaDef.getName()+"|"+getLastSegment(ibaDef.toString(),"."));	//IBA Reference
		}else{
			colIndex++;
		}*/
		
		/*
		if (att.getQoM() != null) {
			QuantityOfMeasureDefaultView qomDef = att.getQoM();
			//expQoMs.put(qomDef.getName(), qomDef);
			newRow.createCell(13).setCellValue(qomDef.getName()+"\t"+qomDef.toString());
		}*/

		// export display styles
		/*
		addDisplayStyleToExport(att.getViewDisplayStyle());
		addDisplayStyleToExport(att.getEditDisplayStyle());*/
		
		newRow.createCell(colIndex++).setCellValue(structureFilterable);
		newRow.createCell(colIndex++).setCellValue(inputFieldType);
		newRow.createCell(colIndex++).setCellValue(description);
		newRow.createCell(colIndex++).setCellValue(defaultValueDisplayMode);
		newRow.createCell(colIndex++).setCellValue(systemReadOnly);
		newRow.createCell(colIndex++).setCellValue(systemHidden);
		newRow.createCell(colIndex++).setCellValue(selectionListStyle);
		newRow.createCell(colIndex++).setCellValue(toolTip);
		newRow.createCell(colIndex++).setCellValue(mapping);
		
		//newRow.createCell(colIndex++).setCellValue(jcaID);
		
		compHash = compHash + structureFilterable + inputFieldType +description + defaultValueDisplayMode + systemReadOnly +
				   systemHidden + selectionListStyle + toolTip + mapping;
		newRow.createCell(compCol).setCellValue(compHash);
		//System.out.println(objectAttributeSheetIndex+" Row value:"+newRow.toString());
		//objectAttributeSheetIndex++;
		
		
		//export constraints of this attribute
//		exportExcelAttConstraintToAttributeSheet(context,att,typeInfo,true,colIndex,newRow);
        if (isFullExport)
		    exportExcelAttConstraintToAttributeSheet(context,att,typeInfo,false,colIndex,newRow,"Defined", compHash);
		Set<TypeDefinitionReadView> views = TYPE_DEF_SERVICE.getAncestorTypeDefViews(context);
		Iterator<TypeDefinitionReadView> iter = views.iterator();
//		TypeDefinitionReadView parentView = TYPE_DEF_SERVICE.getParentTypeDefView(arg0);
		if (isFullExport)
		    while (iter.hasNext()) {
		        TypeDefinitionReadView parentView = TYPE_DEF_SERVICE.getParentTypeDefView(iter.next());
		        exportExcelAttConstraintToAttributeSheet(parentView,att,typeInfo,false,colIndex,newRow,null, compHash);
		    }
//		below methods are for separate sheet
//		exportExcelAttConstraintCharacteristics(context,att,typeInfo,true);
//		exportExcelAttConstraintCharacteristics(context,att,typeInfo,false);
	}
	
	private static void exportExcelGlobalEnumeration() throws Exception{
		if(expEnumDefs==null || expEnumDefs.size()==0)
			return;
		String enumName="";
		String enumValue="";
		String enumSelectable="";
		String compHash = "";
		
		for(EnumerationDefinitionReadView enumView:expEnumDefs){
			if (enumView.getName()==null && enumView.getMasterId()!=null)
        		enumView = BASE_DEF_SERVICE.getEnumDefView(enumView.getMasterId().getId());
        	
        	if (enumView != null && enumView.getName()!=null ){
            	//newRow.createCell(colIndex++).setCellValue("External Enum:"+constraint.getEnumDef().toString());
            	Collection<EnumerationMembershipReadView> memberships=enumView.getAllMemberships();
            	enumName=enumView.getName();
            	
            	for (EnumerationMembershipReadView membership : memberships){
                    EnumerationEntryReadView entry = membership.getMember();
                    enumValue= entry.getName();
                    String displayName = null;
                    for (PropertyValueReadView propValue : entry.getAllProperties()){
                    	if (propValue.getName().equalsIgnoreCase("selectable")){
                    		enumSelectable= propValue.getValueAsString();
                    		
                    	}
                    	if (propValue.getName().equalsIgnoreCase("displayName")){
                            displayName = propValue.getValueAsString();
                            
                        }
                    }
                    
                    XSSFRow newRow=globalEnumerationSheet.createRow(globalEnumerationIndex++);
                    int colIndex = 1;
                    compHash = enumName + enumValue + displayName + enumSelectable;
                    newRow.createCell(colIndex++).setCellValue(enumName);
                    newRow.createCell(colIndex++).setCellValue(enumValue);
                    newRow.createCell(colIndex++).setCellValue(displayName);
                    newRow.createCell(colIndex++).setCellValue(enumSelectable);
                    newRow.createCell(colIndex++).setCellValue(compHash);
                    
                }
            }
        }
	}
	
	public static ArrayList<String> getFolderStructure(WTContainer container) throws WTException {		
		ArrayList<String> dirs = new ArrayList<String>();
		dirs.add("/Default");

		if (container != null) {
			Folder rootFolder = FolderHelper.service.getFolder("/Default", WTContainerRef.newWTContainerRef(container));
			WTCollection acol = FolderHelper.service.getAllDescendantFolders(CabinetReference.newCabinetReference((Cabinet)rootFolder));
			Iterator acolIter = acol.iterator();
			while (acolIter.hasNext()) {
				Object obj = acolIter.next();
				if (obj instanceof SubFolderReference) {
					dirs.add(((SubFolder)((SubFolderReference)obj).getObject()).getFolderPath());
				}
			}
		}
		return dirs;
	}
	
	private static void exportExcelContainerFolder() throws Exception{		
		ArrayList<String> dirs = null;
		String compHash = "";

		WTContainerRef wtContainerRef = WTContainerHelper.service.getByPath("/");
        ContainerSpec csProd = new ContainerSpec(PDMLinkProduct.class);
        csProd.addSearchContainer(WTContainerRef.newWTContainerRef(wtContainerRef));
        QueryResult qrProd = WTContainerHelper.service.getContainers(csProd);
        
        while (qrProd.hasMoreElements()) {
        	WTContainer contProd = (WTContainer) qrProd.nextElement();        	
        	dirs = getFolderStructure(contProd);
            
        	if (dirs != null) {        		
        		for (String dirStr : dirs) {
        			XSSFRow newRow = containerFolderSheet.createRow(containerFolderIndex++);
	        		int colIndex = 1;
	        		compHash = contProd.getContainerName() + "Product" + contProd.getName() + contProd.getOwner().getName() + 
	        				  contProd.getDescription() + contProd.getCreator().getName() + dirStr;
	                newRow.createCell(colIndex++).setCellValue(contProd.getContainerName());
	                newRow.createCell(colIndex++).setCellValue("Product");
	                newRow.createCell(colIndex++).setCellValue(contProd.getName());
	                newRow.createCell(colIndex++).setCellValue(contProd.getOwner().getName());
	                newRow.createCell(colIndex++).setCellValue(contProd.getDescription());
	                newRow.createCell(colIndex++).setCellValue(contProd.getCreator().getName());            
	        		newRow.createCell(colIndex++).setCellValue(dirStr);
	        		newRow.createCell(colIndex++).setCellValue(compHash);
        		}
        	}
        	else {
        		XSSFRow newRow = containerFolderSheet.createRow(containerFolderIndex++);
        		int colIndex = 1;
        		compHash = contProd.getContainerName() + "Product" + contProd.getName() + contProd.getOwner().getName() + 
      				  contProd.getDescription() + contProd.getCreator().getName();
                newRow.createCell(colIndex++).setCellValue(contProd.getContainerName());
                newRow.createCell(colIndex++).setCellValue("Product");
                newRow.createCell(colIndex++).setCellValue(contProd.getName());
                newRow.createCell(colIndex++).setCellValue(contProd.getOwner().getName());
                newRow.createCell(colIndex++).setCellValue(contProd.getDescription());
                newRow.createCell(colIndex++).setCellValue(contProd.getCreator().getName());
                newRow.createCell(colIndex++).setCellValue(compHash);
        	}        	
        }
        
        //Library
        dirs = null;
        ContainerSpec csLib = new ContainerSpec(WTLibrary.class);
        csLib.addSearchContainer(WTContainerRef.newWTContainerRef(wtContainerRef));
        QueryResult qrLib = WTContainerHelper.service.getContainers(csLib);
      
        
        while (qrLib.hasMoreElements()) {
        	WTContainer contLib = (WTContainer) qrLib.nextElement();        	
        	dirs = getFolderStructure(contLib);
            
        	if (dirs != null) {        		
        		for (String dirStr : dirs) {
        			XSSFRow newRow = containerFolderSheet.createRow(containerFolderIndex++);
	        		int colIndex = 1;
	        		compHash = contLib.getContainerName() + "Library" + contLib.getName() + contLib.getOwner().getName() + 
	        				contLib.getDescription() + contLib.getCreator().getName() + dirStr;
	                newRow.createCell(colIndex++).setCellValue(contLib.getContainerName());
	                newRow.createCell(colIndex++).setCellValue("Library");
	                newRow.createCell(colIndex++).setCellValue(contLib.getName());
	                newRow.createCell(colIndex++).setCellValue(contLib.getOwner().getName());
	                newRow.createCell(colIndex++).setCellValue(contLib.getDescription());
	                newRow.createCell(colIndex++).setCellValue(contLib.getCreator().getName());            
	        		newRow.createCell(colIndex++).setCellValue(dirStr);
	        		newRow.createCell(colIndex++).setCellValue(compHash);
        		}
        	}
        	else {
        		XSSFRow newRow = containerFolderSheet.createRow(containerFolderIndex++);
        		int colIndex = 1;
        		compHash = contLib.getContainerName() + "Library" + contLib.getName() + contLib.getOwner().getName() + 
        				contLib.getDescription() + contLib.getCreator().getName();
                newRow.createCell(colIndex++).setCellValue(contLib.getContainerName());
                newRow.createCell(colIndex++).setCellValue("Library");
                newRow.createCell(colIndex++).setCellValue(contLib.getName());
                newRow.createCell(colIndex++).setCellValue(contLib.getOwner().getName());
                newRow.createCell(colIndex++).setCellValue(contLib.getDescription());
                newRow.createCell(colIndex++).setCellValue(contLib.getCreator().getName());
                newRow.createCell(colIndex++).setCellValue(compHash);
        	}        	
        }	
	}
	
	private static void exportExcelLifecycle() throws Exception{		
		Vector lifecycle = null;
		Long idPhaseTmpl;
		String compHash = "";

		WTContainerRef wtContainerRef = WTContainerHelper.service.getByPath("/");
        //csProd.addSearchContainer(WTContainerRef.newWTContainerRef(wtContainerRef));
        lifecycle = LifeCycleHelper.service.findAllTemplates(wtContainerRef);
        Iterator lcIter = lifecycle.iterator();
		while (lcIter.hasNext()) {
			LifeCycleTemplate obj = (LifeCycleTemplate)lcIter.next();			
			idPhaseTmpl = obj.getPersistInfo().getObjectIdentifier().getId();
			
			QuerySpec querySpec = new QuerySpec();	
			
			int indexPhaseTemplate = querySpec.appendClassList(PhaseTemplate.class, true);
			int indexPhaseLink = querySpec.appendClassList(PhaseLink.class, false);
			querySpec.appendWhere(new SearchCondition(PhaseTemplate.class,"thePersistInfo.theObjectIdentifier.id",PhaseLink.class,"roleBObjectRef.key.id"),new int[]{indexPhaseTemplate,indexPhaseLink});
			querySpec.appendAnd();
			querySpec.appendWhere(new SearchCondition(PhaseLink.class,"roleAObjectRef.key.id", SearchCondition.EQUAL, idPhaseTmpl),new int[]{indexPhaseLink});
			
			QueryResult queryResult = PersistenceHelper.manager.find(querySpec);
			while(queryResult.hasMoreElements()){
				Object[] o = (Object[])queryResult.nextElement();
				PhaseTemplate phaseTmpl = (PhaseTemplate)o[indexPhaseTemplate];
				
				XSSFRow newRow = lifecyclesSheet.createRow(lifecyclesIndex++);
        		int colIndex = 1;
        		compHash = obj.getName() + obj.getDescription() + phaseTmpl.getName();
                newRow.createCell(colIndex++).setCellValue(obj.getName());
                newRow.createCell(colIndex++).setCellValue(obj.getDescription());
                newRow.createCell(colIndex++).setCellValue(phaseTmpl.getName());
                newRow.createCell(colIndex++).setCellValue(compHash);
			}
		}
	}
	
	private static String getLastSegment(String source,String key){
		int lastIndex = source.lastIndexOf(key);
		if(lastIndex>0 && lastIndex<source.length()){
			return source.substring(lastIndex+1);
		}else{
			return source;
		}
	}
	


    /**
     * Gets the characteristics of this constraint definition.
     *
     * @param view
     *            The constraint definition
     * @return An ordered (order is based on the DTD) list of characteristics. If a sub-element doesn't have a value, it
     *         will not be included in the list.
     *//*
    private static Map<String, String> getCharacteristics(ConstraintDefinitionReadView view, boolean isCondition)
            throws Exception
    {
        Map<String, String> typeData = new LinkedHashMap<>(9);

        ObjectIdentifier oid = view.getOid();
        final String viewLoadId = getConstraintLoadId( view );
        if (config.genDebugExports())
        {
            if (oid != null) {
                typeData.put(XML_OBJECT_ID, oid.getStringValue());
            }
        }

        if (isCondition)
        {
            if (view.getConditionFor() != null)
            {
                // add csvloadID to type data
                final String prefixedLoadId = addPrefixIfNeeded(LoaderHelper.CONDITION_LOAD_ID_PREFIX, viewLoadId);
                typeData.put(XML_LOADID, prefixedLoadId);

                // add csvconditionForLoadID to type data
                final String conditionForLoadId = getConstraintLoadId( view.getConditionFor() );
                final String prefixedConditionLoadId = addPrefixIfNeeded(LoaderHelper.CONSTRAINT_LOAD_ID_PREFIX, conditionForLoadId);
                typeData.put(XML_CONSTRAINT_CONDITIONFOR_LOADID, prefixedConditionLoadId);
            }
            else {
                logger.warn("Condition constraint '"
                        + view.getAttName()
                        + "."
                        + oid
                        + "' can't retrieve its conditionFor data! This will cause an issue when this exported file is loaded.");
            }
        }
        else {
            // exported constraint should always have a load ID. see SPR 2188457
            final String prefixedLoadId = addPrefixIfNeeded(LoaderHelper.CONSTRAINT_LOAD_ID_PREFIX, viewLoadId);
            typeData.put(XML_LOADID, prefixedLoadId);
            if (!view.getAllConditions().isEmpty())
            {
                // sort the load ids so their output in a consistent order
                final SortedSet<String> ids = new TreeSet<>();
                for (ConstraintDefinitionReadView condition : view.getAllConditions())
                {
                    final String conditionLoadId = getConstraintLoadId( condition );
                    final String prefixedConditionLoadId = addPrefixIfNeeded(LoaderHelper.CONDITION_LOAD_ID_PREFIX, conditionLoadId);
                    ids.add(prefixedConditionLoadId);
                }
                final StringBuilder sortedIds = new StringBuilder();
                boolean first = true;
                for ( String anId : ids )
                {
                    if ( first )
                    {
                        first = false;
                    }
                    else
                    {
                        sortedIds.append( "," );
                    }
                    sortedIds.append( anId );
                }
                typeData.put(XML_CONSTRAINT_CONDITION_LOADID, sortedIds.toString());
            }
        }

        final ObjectIdentifier contextId = view.getContextId();
        final AttributeTemplateFlavor templateFlavor =
            AttributeTemplateFlavor.getAttributeTemplateFlavor( contextId.getClassname() );
        TypeDefinitionReadView typeContext = TYPE_DEF_SERVICE.getTypeDefView(templateFlavor, Long.valueOf(contextId.getId()));
        if (typeContext != null) {
            typeData.put(XML_TYPE_CONTEXT, getConciseTypeName(typeContext));
        }

        ConstraintRuleDefinitionReadView rule = view.getRule();
        // add rule to the constraint rule export list
        // and datatype reference by the rule to the datatype export list
        //expConstraintRuleDefs.add(rule);
        if (rule.getDatatype() != null) {
            expDatatypeDefs.add(rule.getDatatype());
        }
        typeData.put(XML_CONSTRAINTRULE_RULECLASSNAME, rule.getRuleClassname());
        typeData.put(XML_CONSTRAINTRULE_DEFCLASSNAME, rule.getDefClassname());
        if (rule.getDefClassname().equals(LWCBasicConstraint.class.getName()))
        {
            try
            {
            if (view.getRuleData() != null)
            {
                if ((TypeInstanceIdentifier.class.getName().equals(rule.getDatatype().getName()) ||
                     WCTypeInstanceIdentifier.class.getName().equals( rule.getDatatype().getName()))
                        && (TypeIdentifierSetConstraint.class.getName().equals(rule.getRuleClassname())
                        || DiscreteSetConstraint.class.getName().equals(rule.getRuleClassname())))
                {
                    if (TypeIdentifierSetConstraint.class.getName().equals(rule.getRuleClassname())) {
                        typeData.put(
                                XML_CONSTRAINT_RULEDATA,
                                removeDomainFromTypeNames(((ConstraintDefinitionReadView.ReferenceConstraintRuleDataCarrier) view
                                        .getRuleData()).toString()));
                    }
                    else {
                        typeData.put(XML_CONSTRAINT_RULEDATA,
                                ((ConstraintDefinitionReadView.ReferenceConstraintRuleDataCarrier) view.getRuleData())
                                        .toString());
                    }
                }
                else {
                    typeData.put(XML_CONSTRAINT_RULEDATA, DataTypesExternalizer.toExternalForm(view.getRuleData()));
                }
            }
            else {
                typeData.put(XML_CONSTRAINT_RULEDATA, null);
            }
            }catch ( Exception wte ) {
                logger.error( wte, wte );
                throw wte;
            }
            typeData.put(XML_CONSTRAINTRULE_DEFQUALIFIER, rule.getDefQualifier());
        } else if (rule.getDefClassname().equals(LWCFilterBasedConstraint.class.getName())) {
            if (view.getFilter() instanceof ScreenDefinitionReadView) {
                expScreenDefs.add((ScreenDefinitionReadView) view.getFilter());
                typeData.put(XML_CONSTRAINT_RULEDATA, LoaderHelper.SCREEN_DEFINITION_PREFIX
                        + ((ScreenDefinitionReadView) view.getFilter()).getName());
            } else if (view.getFilter() instanceof WTGroup) {
                typeData.put(XML_CONSTRAINT_RULEDATA,
                        LoaderHelper.PROFILE_PREFIX + ((WTGroup) view.getFilter()).getName());
            }
        } else if (rule.getDefClassname().equals(LWCEnumerationBasedConstraint.class.getName())) {
            EnumerationDefinitionReadView enumDefView = view.getEnumDef();
            String ruleDataValue = null;
            if (enumDefView != null) {
                // this can be null or it could contain the internal names of the entries that were selected
                // by the local enumeration this is only done by local enumerations based on global enumerations
                // that only change the selected entries (e.g. cascading attribute rules)
                final Serializable ruleData = view.getRuleDataObj().getRuleData();
                if ( ruleData != null )
                {
                    if ( ruleData instanceof DiscreteSet )
                    {
                        final DiscreteSet localSelectedEntries = (DiscreteSet) ruleData;
                        ruleDataValue = localSelectedEntries.toExternalForm();
                    }
                }
                // add to the enum export list
                exportReferencedGlobalEnumDef(enumDefView);

                // we'll export the "reference" to the global enumeration later
            }
            typeData.put(XML_CONSTRAINT_RULEDATA, ruleDataValue);
        }
        return typeData;
    }*/
    

    /**
     * Adds requested prefix to the loadId, but first strips off previous CONDITION= or CONSTRAINT= prefix if it was
     * there (so we don't end up with "CONSTRAINT=CONSTRAINT=...").
     *
     * @param prefix
     *            the prefix to prepend to the loadId. Should not be null.
     * @param loadId
     *            the loadId to add the prefix to. May be null.
     * @return load Id with prefix prepended if loadId != null. Will return null if loadId is null.
     *//*
    private static String addPrefixIfNeeded(final String prefix, final String loadId) {
        if (loadId != null) {
            String noPrefixLoadId = loadId;
            // first strip off an existing "CONSTRAINT=" or a "CONDITION=" prefix if it exists
            if (loadId.startsWith(LoaderHelper.CONSTRAINT_LOAD_ID_PREFIX) ||
                    loadId.startsWith(LoaderHelper.CONDITION_LOAD_ID_PREFIX)) {
                noPrefixLoadId = loadId.substring(loadId.indexOf(LoaderHelper.EQUAL) + 1);
            }
            // prepend the requested prefix
            return prefix + noPrefixLoadId;
        }
        else {
            // if loadId is null then return null
            return null;
        }
    }*/

    /**
     * Gets the shorthand typename of the types in this rule data's external form. If the type name's internet domain
     * prefix is an exact match for the site internet domain, then it's stripped off of the type name.
     *
     * @param externalform
     * @return
     * @throws Exception
     */
    static String removeDomainFromTypeNames(String externalform)
            throws Exception
    {
        DiscreteSet dataSet = (DiscreteSet) DataTypesExternalizer.fromExternalForm(externalform);
        String exchangeDomain = TypeDomainHelper.getExchangeDomain();
        ArrayList<String> updated = new ArrayList<>();
        Object[] objs = dataSet.getElements();
        for (Object obj : objs)
        {
            if (obj instanceof String)
            {
                final String tmp = (String) obj;
                final int dotIndex = tmp.lastIndexOf(".");
                String domain = dotIndex >= 0 ? tmp.substring(0, dotIndex) : "";
                if (exchangeDomain.equals(domain)) {
                    updated.add(tmp.substring(dotIndex + 1));
                }
                else if (domain.equals(TypeIdentifierSet.MATCH_DESCENDENT_TYPE + exchangeDomain)) {
                    updated.add(TypeIdentifierSet.MATCH_DESCENDENT_TYPE + tmp.substring(dotIndex + 1));
                }
                else {
                    updated.add(tmp);
                }
            }
        }

        DiscreteSet updatedSet = new DiscreteSet(updated.toArray(new Object[updated.size()]),
                dataSet.isNegated());
        return DataTypesExternalizer.toExternalForm(updatedSet);
    }

    /**
     * Get a load id to use for the given constraint.
     * @param constraintRv The constraint to get a load id for.
     * @return A load id for the constraint.  May return null.
     *//*
    private static String getConstraintLoadId( final ConstraintDefinitionReadView constraintRv )
    {
        final String loadId;
        if ( constraintRv == null )
        {
            loadId = null;
        }
        else
        {
            if ( constraintRv.getLoadID() == null || constraintRv.getLoadID().isEmpty() )
            {
                if ( constraintRv.getOid() == null )
                {
                    loadId = null;
                }
                else
                {
                    loadId = constraintRv.getOid().getStringValue();
                }
            }
            else
            {
                loadId = constraintRv.getLoadID();
            }
        }
        return loadId;
    }*/


	/**
	 * Adds the given enum and its organizer(s) to the export list(s) if its a
	 * global enum (a named enumeration). Does nothing if given enum is null or
	 * if given enum's name is null.
	 *
	 * @param enumDefView
	 *            enum def to add. May be null.
	 *//*
	private static void exportReferencedGlobalEnumDef(
			EnumerationDefinitionReadView enumDefView) throws Exception {
		if (enumDefView != null && enumDefView.getName() != null) {
			Set<EnumerationDefinitionReadView> enumSet = new HashSet<>();
			enumSet.add(enumDefView);
			expOrganizers.addAll(getOrganizersFromEnums(enumSet));
			expEnumDefs.add(enumDefView);
		}
	}*/

	private static boolean exportInheritedCondition(
			ConstraintDefinitionReadView condition, ObjectIdentifier typeContext)
			throws Exception {
		ConstraintDefinitionReadView conditionFor = condition.getConditionFor();
		// cache doesn't ensure that condition's conditionFor field necessarily
		// contain *all* of the "real" constraint's meta data but it ensures
		// that condition's copy
		// has the same ReadViewIdentifier as the "real" constraint so it can be
		// used to trace down the real one.
		// Thus some work around here....
		ReadViewIdentifier id = conditionFor.getReadViewIdentifier();
		ConstraintDefinitionReadView realConstraint = (ConstraintDefinitionReadView) TYPE_DEF_SERVICE
				.getReadView(id);
		for (PropertyValueReadView propValue : realConstraint
				.getAllProperties()) {
			if (typeContext.equals(propValue.getContextId())) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Return true if the given constraint is visibility constraint. Otherwise,
	 * return false.
	 * 
	 * @param constraint
	 * @return
	 */
	private static boolean isVisibilityConstraint(
			final ConstraintDefinitionReadView constraint) {
		ConstraintDefinitionReadView.RuleDataObject ruleDataObj = constraint
				.getRuleDataObj();
		if (ruleDataObj == null) {
			return false;
		}
		Object filter = ruleDataObj.getFilter();
		if (filter == null) {
			return false;
		}
		if (filter instanceof ScreenDefinitionReadView) {
			return true;
		}
		return false;
	}



	private static void exportExcelObjectTypeDefinition(TypeDefinitionReadView view, LocalizationInfo typeInfo)
			throws Exception {
		//start with objectTypeSheetIndex current value and ++1 at the end.
		//now, let's document object type properties (not attributes!)
        Collection<PropertyValueReadView> properties = view.getAllProperties();
        
        //int cellColIndex=6;
        
        String displayName="";
        String displayNameUS = "";
        String description="";
        String icon="";
        String instantiable="";
        String subtypeable="";
        String toolTip="";        
        
		if (!properties.isEmpty()) {
			for (PropertyValueReadView property : properties) {
				if (config.validateTypes()
						&& !isValidPropValForContext(view, property, view)) { 
					//if this properties is not valid for this view, let's bypass it.
					//shall we log it? decide it later.
					continue;
				}

				String propName = property.getName();
				String propValue = property.getValueAsString();	//this will get default value. 
				//String propValue = property.getValueAsString(Locale.US, true);	//try to get US local value in priority.
				
				if (propName.equalsIgnoreCase("displayname")){
					displayName=propValue;
					displayNameUS=property.getValueAsString(Locale.US, true);
				}
				else if (propName.equalsIgnoreCase("description"))
					description=propValue;
				else if (propName.equalsIgnoreCase("icon"))
					icon = propValue;
				else if (propName.equalsIgnoreCase("instantiable"))
					instantiable=propValue;
				else if (propName.equalsIgnoreCase("subtypeable"))
					subtypeable=propValue;
				else if (propName.equalsIgnoreCase("tooltip"))
					toolTip=propValue;
				
			}
		}
		
		XSSFRow objRow = objectTypeSheet.createRow(objectTypeSheetIndex++);
		
        int colIndex = 1;
        //objRow.createCell(colIndex++).setCellValue(excel_object_id);
        //objRow.createCell(colIndex++).setCellValue("");	//better to indicate whether it is a OOTB or customized object;
        String typeName = getConciseTypeName(view);
        String compHash = "";
        if (typeName.contains("."))
        {
        	objRow.createCell(colIndex++).setCellValue(typeName); //Name
        	objRow.createCell(colIndex++).setCellValue(displayName);	//display Name
            objRow.createCell(colIndex++).setCellValue(displayNameUS);	//display Name in US
            
        	objRow.createCell(colIndex++).setCellValue(WTContainerHelper.isExchangeRef(view.getOrgRef()) ? null
                    : TypeDomainHelper.getDomain(view.getOrgRef())); //CONTAINER_DOMAIN
        	compHash = typeName + displayName + displayNameUS + (WTContainerHelper.isExchangeRef(view.getOrgRef()) ? null
                    : TypeDomainHelper.getDomain(view.getOrgRef()));        	
        } else {
            objRow.createCell(colIndex++).setCellValue(typeName.substring(typeName.lastIndexOf(".") + 1)); //Name
            objRow.createCell(colIndex++).setCellValue(displayName);	//display Name
            objRow.createCell(colIndex++).setCellValue(displayNameUS);	//display Name in US
            
        	objRow.createCell(colIndex++).setCellValue(""); //CONTAINER_DOMAIN
        	compHash = (typeName.substring(typeName.lastIndexOf(".") + 1)) + displayName + displayNameUS;        	
        }        
        
        TypeDefinitionReadView parentView = TYPE_DEF_SERVICE.getParentTypeDefView(view);
        String parentName = null;
        if (parentView != null) {
            parentName = getConciseTypeName(parentView);
            objRow.createCell(colIndex++).setCellValue(parentName==null?"":parentName); //type_parent
            compHash = compHash + (parentName==null?"":parentName);
            //objRow.createCell(colIndex++).setCellValue(parentName==null?"":parentView.getPropertyValueByName("displayName")); 
            	//type_parent name
        }else{
        	colIndex++;	//avoid cell jump;
        }
        
        AttributeTemplateFlavor flavor = view.getAttTemplateFlavor();
        compHash = compHash + (flavor.name()) + (view.getNamespace()) + description + icon + instantiable + subtypeable + toolTip;
        objRow.createCell(colIndex++).setCellValue(flavor.name()); //ATT_TEMPLATE
        objRow.createCell(colIndex++).setCellValue(view.getNamespace()); //NAME_SPACE
        
        objRow.createCell(colIndex++).setCellValue(description);
        objRow.createCell(colIndex++).setCellValue(icon);
        objRow.createCell(colIndex++).setCellValue(instantiable);
        objRow.createCell(colIndex++).setCellValue(subtypeable);
        objRow.createCell(colIndex++).setCellValue(toolTip);
        objRow.createCell(colIndex++).setCellValue(compHash);
	}
	

	/**
	 * Gets the shorthand typename of the specified type view. If its internet
	 * domain prefix is an exact match for the site internet domain, then it's
	 * stripped off of the type name.
	 *
	 * @param view
	 * @return
	 * @throws Exception
	 */
	private static String getConciseTypeName(TypeDefinitionReadView view)
			throws Exception {
		return getConciseTypeName(view.getName(), view.getOrgRef());
	}


	private static void initCoverSheet() throws IOException{
		  coverSheet = workbook.createSheet("Cover");
	    
		XSSFRow coverRow = coverSheet.createRow(0);
	    XSSFCell coverCell = coverRow.createCell(1);
	    coverCell.setCellValue("Data Model File Cover Sheet");
	    
	    coverSheetIndex++;	//give a blank row
	    coverRow = coverSheet.createRow(coverSheetIndex++);
	    coverRow.createCell(0).setCellValue("Create time:");
	    Calendar cal = Calendar.getInstance();
	        SimpleDateFormat sdf = new SimpleDateFormat("YYYY-MMM-DD HH:mm:ss");
	        System.out.println( sdf.format(cal.getTime()) );
	        
	    coverRow.createCell(1).setCellValue(sdf.format(cal.getTime()) );
	    
	    coverRow = coverSheet.createRow(coverSheetIndex++);
	    coverRow.createCell(0).setCellValue("Creator:");
	    String author;
	    try {
	      author=SessionHelper.getPrincipal().getName();
	    } catch (WTException e) {
	      // TODO Auto-generated catch block
	      e.printStackTrace();
	      author="Unknow";
	    }
	    
	    coverRow.createCell(1).setCellValue(author);
	    coverRow=coverSheet.createRow(coverSheetIndex++);
	    coverRow.createCell(0).setCellValue("Build Number:");
	    //setup build number later.
	    outputBuildInformation();
	    
	    coverSheetIndex++;
	    coverRow=coverSheet.createRow(coverSheetIndex++);
	    coverRow.createCell(0).setCellValue("Temporary Patches:");
	    outputTemporaryPatches();
	}
	
	@SuppressWarnings("deprecation")
	private static void outputTemporaryPatches() throws IOException{
		try {
			InstalledTempPatch[] tps = WindchillVersion.getInstalledTempPatches();
			
			if(tps.length==0){
				XSSFRow newRow = coverSheet.createRow(coverSheetIndex++);
				newRow.createCell(1).setCellValue(" There are no patches installed.");
			}else{
				XSSFRow newRow = coverSheet.createRow(coverSheetIndex++);
				int colIndex = 6;	//based on Ruud's request, change field from B to G
				newRow.createCell(colIndex++).setCellValue("Label");
				newRow.createCell(colIndex++).setCellValue("Description");
				newRow.createCell(colIndex++).setCellValue("Install Date");
				
				for(int i=0;i<tps.length;i++){
					newRow=coverSheet.createRow(coverSheetIndex++);
					colIndex = 6;	//based on Ruud's request, change field from B to G
					newRow.createCell(colIndex++).setCellValue(tps[i].getName());
					newRow.createCell(colIndex++).setCellValue(tps[i].getDescription());
					java.util.Date d = tps[i].getInstallDate();
					
					newRow.createCell(colIndex++).setCellValue(d==null?" ": d.toLocaleString());
				}
				
			}
		} catch (IAException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	private static void outputBuildInformation() throws IOException{
		try {
			ReleaseId[] rel_ids = WindchillVersion.getInstalledAssemblyReleaseIds();
			XSSFRow newRow = coverSheet.createRow(coverSheetIndex++);
			
			if(rel_ids.length==0){
				newRow.createCell(1).setCellValue(" There are no versioned assemblies installed");
			}else{
				int colIndex = 6;	//based on Ruud's request, change field from A to G
				newRow.createCell(colIndex++).setCellValue("--");
				newRow.createCell(colIndex++).setCellValue("Supported Datacode");
				newRow.createCell(colIndex++).setCellValue("Release Number");
				newRow.createCell(colIndex++).setCellValue("Release ID");
				newRow.createCell(colIndex++).setCellValue("Sequence");
				newRow.createCell(colIndex++).setCellValue("Display Label");
				
				for(int i=0;i<rel_ids.length;i++){
					newRow = coverSheet.createRow(coverSheetIndex++);
					colIndex = 6;	//based on Ruud's request, change field from A to G
					boolean isCompleted=WindchillVersion.isComplete(rel_ids[i]);
					
					newRow.createCell(colIndex++).setCellValue(isCompleted?" ":"%");
					newRow.createCell(colIndex++).setCellValue(WindchillVersion.getSupportDateCodeFor(rel_ids[i]));
					newRow.createCell(colIndex++).setCellValue(WindchillVersion.getSupportReleaseNumberFor(rel_ids[i]));
					newRow.createCell(colIndex++).setCellValue(rel_ids[i].toString());
					newRow.createCell(colIndex++).setCellValue(WindchillVersion.getInstallerSequenceFor(rel_ids[i]));
					newRow.createCell(colIndex++).setCellValue(WindchillVersion.getDisplayLabelFor(rel_ids[i]));
				}
			}
		} catch (ReleaseIdException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	private static void initObjectTypeSheet() throws IOException{
		  objectTypeSheet = workbook.createSheet("Object Types");
		  XSSFRow newRow = objectTypeSheet.createRow(0);
	    int colIndex=0;
	    newRow.createCell(colIndex++).setCellValue("STATUS");
	    newRow.createCell(colIndex++).setCellValue("Internal Name");
	    newRow.createCell(colIndex++).setCellValue("Display Name");
	    newRow.createCell(colIndex++).setCellValue("Display Name(US)");
	    newRow.createCell(colIndex++).setCellValue("Container");
	    newRow.createCell(colIndex++).setCellValue("Parent");
	    newRow.createCell(colIndex++).setCellValue("Template");
	    newRow.createCell(colIndex++).setCellValue("Name Space");
	    newRow.createCell(colIndex++).setCellValue("Description");
	    newRow.createCell(colIndex++).setCellValue("ICON");
	    newRow.createCell(colIndex++).setCellValue("Instantiable");
	    newRow.createCell(colIndex++).setCellValue("Subtypeable");
	    newRow.createCell(colIndex++).setCellValue("Tool Tip");
	    newRow.createCell(colIndex++).setCellValue("Compare column");
		}
	
		private static void initObjectAttributeSheet(boolean isFullExport) throws IOException{
			objectAttributeSheet = workbook.createSheet("Object Attributes");
			XSSFRow newRow=objectAttributeSheet.createRow(0);
			
			int colIndex=0;
			newRow.createCell(colIndex++).setCellValue("STATUS");
			newRow.createCell(colIndex++).setCellValue("Object Name");
			newRow.createCell(colIndex++).setCellValue("Object Display Name");
			
			newRow.createCell(colIndex++).setCellValue("Attribute Source");
			newRow.createCell(colIndex++).setCellValue("Internal Name");
			newRow.createCell(colIndex++).setCellValue("Display Name");
			newRow.createCell(colIndex++).setCellValue("Display Name(US)");
			newRow.createCell(colIndex++).setCellValue("Display Name(DE)");
//			newRow.createCell(colIndex++).setCellValue("Definition");
			newRow.createCell(colIndex++).setCellValue("Data Type");
			newRow.createCell(colIndex++).setCellValue("IBA Name");
			newRow.createCell(colIndex++).setCellValue("QoM Name");
//			newRow.createCell(colIndex++).setCellValue("View Style");
//			newRow.createCell(colIndex++).setCellValue("Edit Style");
			newRow.createCell(colIndex++).setCellValue("Default Value");
			newRow.createCell(colIndex++).setCellValue("Source Attribute");
			newRow.createCell(colIndex++).setCellValue("Translation Dictionary");
//			newRow.createCell(colIndex++).setCellValue("IBA Reference");
			newRow.createCell(colIndex++).setCellValue("Structure Filterable");
			newRow.createCell(colIndex++).setCellValue("Input Field Type");
			newRow.createCell(colIndex++).setCellValue("Description");
			newRow.createCell(colIndex++).setCellValue("Default Value Display Mode");
			newRow.createCell(colIndex++).setCellValue("System Read Only");
			newRow.createCell(colIndex++).setCellValue("System Hidden");
			newRow.createCell(colIndex++).setCellValue("Selection List Style");
			newRow.createCell(colIndex++).setCellValue("Tool Tip");
			newRow.createCell(colIndex++).setCellValue("Mapping");
//		added Feb 9 by nsulinski
			if (isFullExport) {
				newRow.createCell(colIndex++).setCellValue("Constraint Source");
				newRow.createCell(colIndex++).setCellValue("ValueRequiredConstraint");
//			    newRow.createCell(colIndex++).setCellValue("StringByteLengthConstraint");
				newRow.createCell(colIndex++).setCellValue("StringLengthConstraint");
				newRow.createCell(colIndex++).setCellValue("SingleValuedConstraint");
				newRow.createCell(colIndex++).setCellValue("ImmutableConstraint");
				newRow.createCell(colIndex++).setCellValue("HiddenConstraint");
				newRow.createCell(colIndex++).setCellValue("ValueHiddenConstraint");
				newRow.createCell(colIndex++).setCellValue("LowerCaseConstraint");
				newRow.createCell(colIndex++).setCellValue("UpperCaseConstraint");
				newRow.createCell(colIndex++).setCellValue("RangeConstraint");
				newRow.createCell(colIndex++).setCellValue("TypeIdentifierSetConstraint");
				newRow.createCell(colIndex++).setCellValue("DiscreteSetConstraint");
				newRow.createCell(colIndex++).setCellValue("SuggestedValuesConstraint");
				newRow.createCell(colIndex++).setCellValue("Global Enumeration");
				//newRow.createCell(colIndex++).setCellValue("JCA ID");
				newRow.createCell(colIndex++).setCellValue("Compare column");
			}
		}
		private static void initObjectAttributeConstraintSheet() throws IOException{
			objectAttributeConstraintSheet = workbook.createSheet("Object Constraints");
			XSSFRow titleRow = objectAttributeConstraintSheet.createRow(0);
			
			int colIndex=0;
			titleRow.createCell(colIndex++).setCellValue("STATUS");
			titleRow.createCell(colIndex++).setCellValue("Object Name");
			titleRow.createCell(colIndex++).setCellValue("Object Display Name");
			
			titleRow.createCell(colIndex++).setCellValue("Source");
			//titleRow.createCell(colIndex++).setCellValue("Object Type");
			titleRow.createCell(colIndex++).setCellValue("Attribute Internal Name");
			titleRow.createCell(colIndex++).setCellValue("Attribute Display Name");
			//titleRow.createCell(colIndex++).setCellValue("Context");
			titleRow.createCell(colIndex++).setCellValue("Constraint Type");
			titleRow.createCell(colIndex++).setCellValue("Base Type");
			titleRow.createCell(colIndex++).setCellValue("Global Enumeration Name");	//added Feb.1st
			titleRow.createCell(colIndex++).setCellValue("Rule Data");
			//titleRow.createCell(colIndex++).setCellValue("Additional Note");
			titleRow.createCell(colIndex++).setCellValue("Compare column");
	    
		}
		private static void initObjectTypeLayoutSheet() throws IOException{
			objectTypeLayoutSheet = workbook.createSheet("Object Layout");
	        XSSFRow titleRow=objectTypeLayoutSheet.createRow(0);
	        int colIndex=0;
	        titleRow.createCell(colIndex++).setCellValue("STATUS");
	        titleRow.createCell(colIndex++).setCellValue("Object Name");
	        titleRow.createCell(colIndex++).setCellValue("Object Display Name");
	        
	        titleRow.createCell(colIndex++).setCellValue("Inherited");
	        titleRow.createCell(colIndex++).setCellValue("Layout Name");
	        titleRow.createCell(colIndex++).setCellValue("Screens");
	        titleRow.createCell(colIndex++).setCellValue("Profiles");
	        titleRow.createCell(colIndex++).setCellValue("Default Group");
	        titleRow.createCell(colIndex++).setCellValue("Layout Context");
	        titleRow.createCell(colIndex++).setCellValue("Group Name");
	        titleRow.createCell(colIndex++).setCellValue("Group Static");
	        titleRow.createCell(colIndex++).setCellValue("Group Style");
	        titleRow.createCell(colIndex++).setCellValue("Attribute Context");
	        titleRow.createCell(colIndex++).setCellValue("Attribute");
	        titleRow.createCell(colIndex++).setCellValue("Compare column");
	        
	        		
		}
		private static void initObjectIBASheet() throws IOException{
			objectIBASheet = workbook.createSheet("IBA Definition");
			XSSFRow newRow=objectIBASheet.createRow(0);
			
			int colIndex=0;
			newRow.createCell(colIndex++).setCellValue("STATUS");  
			newRow.createCell(colIndex++).setCellValue("IBA Name");	//IBA Name
			
			newRow.createCell(colIndex++).setCellValue("IBA Hierarchy");	//IBA Hierarchy Name
			newRow.createCell(colIndex++).setCellValue("Path");	//IBA Path
			newRow.createCell(colIndex++).setCellValue("Display Name");	//IBA Display Name
			
			newRow.createCell(colIndex++).setCellValue("Description"); // IBA description
			newRow.createCell(colIndex++).setCellValue("Type"); // IBA Type
			newRow.createCell(colIndex++).setCellValue("Compare column");
		}
		
		private static void initGlobalEnumerationSheet() throws IOException{
		  globalEnumerationSheet = workbook.createSheet("Global Enumeration");
		  int colIndex=0;
	    
		  XSSFRow titleRow = globalEnumerationSheet.createRow(0);
		  titleRow.createCell(colIndex++).setCellValue("STATUS");
		  titleRow.createCell(colIndex++).setCellValue("Enumeration Name");
		  titleRow.createCell(colIndex++).setCellValue("Enumeration Value");
		  titleRow.createCell(colIndex++).setCellValue("Display Value");
		  titleRow.createCell(colIndex++).setCellValue("Selectable");
		  titleRow.createCell(colIndex++).setCellValue("Compare column");
		}
		
		private static void initContainerFolderSheet() throws IOException{
			containerFolderSheet = workbook.createSheet("Container Folders");
			int colIndex=0;
		    
			  XSSFRow titleRow = containerFolderSheet.createRow(0);
			  titleRow.createCell(colIndex++).setCellValue("STATUS");
			  titleRow.createCell(colIndex++).setCellValue("Organization");
			  titleRow.createCell(colIndex++).setCellValue("Container Type");
			  titleRow.createCell(colIndex++).setCellValue("Container Name");
			  titleRow.createCell(colIndex++).setCellValue("Container Owner");
			  titleRow.createCell(colIndex++).setCellValue("Description");
			  titleRow.createCell(colIndex++).setCellValue("Created By");
			  titleRow.createCell(colIndex++).setCellValue("Folder Name");
			  titleRow.createCell(colIndex++).setCellValue("Compare column");
			}
		
		private static void initLifecyclesSheet() throws IOException{
			lifecyclesSheet = workbook.createSheet("Lifecycles");
			int colIndex=0;
		    
			  XSSFRow titleRow = lifecyclesSheet.createRow(0);
			  titleRow.createCell(colIndex++).setCellValue("STATUS");
			  titleRow.createCell(colIndex++).setCellValue("Lifecycle Name");
			  titleRow.createCell(colIndex++).setCellValue("Lifecycle Description");
			  titleRow.createCell(colIndex++).setCellValue("Lifecycle State");
			  titleRow.createCell(colIndex++).setCellValue("Compare column");
			}
		
		private static void initExcelExport(String excelFileName,String location, boolean isFullExport) throws IOException{
			if (!location.endsWith(File.separator)){
				location = location + File.separator;
			}
			String fullName = location + excelFileName;
			System.out.println("Fullname will be:"+fullName);
			/*
			expIBAs = new HashMap<>(50);
			
			expEnumDefs = new TreeSet<>(
					EnumerationDefinitionViewComparator.getInstance());*/
			
			workbook = new XSSFWorkbook();
			if (isFullExport) {
				initCoverSheet();
				//initIndexSheet();
				initObjectTypeSheet();
				initObjectAttributeSheet(true);
//			Not needed for KB Report
//			initObjectAttributeConstraintSheet(); 
				initObjectTypeLayoutSheet();
				initObjectIBASheet();
				initGlobalEnumerationSheet();
				initContainerFolderSheet();
				initLifecyclesSheet();
			} else {
				initObjectAttributeSheet(false);
			}
			//need one more method to fulfill index page.
		}

	private static void resetRowIndexes() {
		coverSheetIndex = 1;
		objectTypeSheetIndex = 1;
		objectAttributeSheetIndex = 1;
		objectAttributeConstraintSheetIndex = 1;
		objectTypeLayoutSheetIndex = 1;
		objectIBASheetIndex = 1;
		globalEnumerationIndex = 1;
	}

}

