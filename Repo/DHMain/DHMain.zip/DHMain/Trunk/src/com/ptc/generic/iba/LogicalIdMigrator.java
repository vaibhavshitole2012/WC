package com.ptc.generic.iba;

import java.rmi.RemoteException;

import wt.auth.Authentication;
import wt.iba.definition.AttributeHierarchyChild;
import wt.iba.definition.AttributeOrganizer;
import wt.iba.definition.litedefinition.AttributeDefDefaultView;
import wt.iba.definition.litedefinition.AttributeOrgNodeView;
import wt.iba.definition.service.IBADefinitionCache;
import wt.iba.definition.service.IBADefinitionHelper;
import wt.iba.definition.service.IBADefinitionObjectsFactory;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.org.WTPrincipal;
import wt.util.WTContext;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;

import com.ptc.generic.AuthHelper;

/**
 * Migrator that sets the logicalIdentifier on all attributes (on Site level) that don't have a logical identifier.
 * Usage: windchill com.ptc.generic.iba.LogicalIdMigrator -u <windchill admin> -p <password>
 * 
 * @author lberger@ptc.com
 */
public class LogicalIdMigrator implements RemoteAccess {
	
	public static final String svnRev = "$Revision: 1.1.1.3 $ $Date: 2015/12/10 21:01:36IST $";
	public static final String svnUrl = "$URL: http://127.0.0.1/svn/KB_04082016/components/Generic-Utilities/src/com/ptc/generic/iba/LogicalIdMigrator.java $";
	
	public static final String CLASSNAME = LogicalIdMigrator.class.getName();

	private static final IBADefinitionCache IBA_DEFINITION_CACHE = IBADefinitionCache.getIBADefinitionCache();

	private static boolean testOnly = false;
	private static boolean junitExecution = false;
	private static boolean emptyLogicalIDfound = false;

	public static void main(String[] args) {
		// init WTContext and set locale
		WTContext.init(args);

		try {
			//aweyerer: this did not work in the cluster configuration
			//this class should also run when no user/pwd is given (then using the authentication window)
			//WTPrincipal user = AuthHelper.authenticateUser(args);
			int argLength = args.length;
			String username = null;
			String pass = null;
			for (int j = 0; j < argLength; j++) {
				if (args[j].equals("-u")) {
					if (++j < argLength) {
						username = new String(args[j]);
					}
				} else if (args[j].equals("-p")) {
					if (++j < argLength) {
						pass = new String(args[j]);
					}
				} else if (args[j].equals("+t")) {
					testOnly = true;
				} else if (args[j].equals("-junit")) {
					testOnly = true;
					junitExecution = true;
				}
			}

			if (username != null && pass != null) {
				// try to authenticate
				WTPrincipal user = AuthHelper.authenticateUser(args);
				System.out.println("authenticated as: " + user.getName());
			} else {
				System.out.println("Kein username via '-u xyz' �bergeben. Authentifizierung erfolgt bei Bedarf �ber das Authentication-Window.");
				Authentication.getUserName();
			}
		} catch (WTException w) {
			System.out.println("could not authenticate user. Exception:" + w.getLocalizedMessage());
			w.printStackTrace();
			System.exit(1);
		} catch (RemoteException w) {
			System.out.println("could not authenticate user. Exception:" + w.getLocalizedMessage());
			w.printStackTrace();
			System.exit(1);
		}

		try {
			String output = LogicalIdMigrator.migrate();
			System.out.println(output);
			
			if (output != null && output.contains("logicalIdentifier is empty")) {
				emptyLogicalIDfound = true;
				System.out.println("Empty logical ID detected!");
			}

		} catch (WTException w) {
			w.printStackTrace();
			System.exit(1);
		} 
				
		// if executed via shell do System.exit, if executed inside junit this would always lead to an error.
		if (!junitExecution) {
			System.exit(0);	
		}
	}
	
	public static String migrate() throws WTException {
		try {
			if (testOnly) {
				System.out.println("running in MODE: only checks, NO fixes");
			}
			
			if (RemoteMethodServer.ServerFlag) {
				return _migrate(testOnly);
			} else {
				return (String) RemoteMethodServer.getDefault().invoke("_migrate", "com.ptc.generic.iba.LogicalIdMigrator", null,
						new Class[] { Boolean.class }, new Object[] { Boolean.valueOf(testOnly) });
			}
		} catch (Exception e) {
			if (e instanceof WTException) {
				throw (WTException) e;
			} else {
				throw new WTException(e);
			}
		}
	}

	public static String _migrate(Boolean doTestOnly) {
		StringBuffer sb = new StringBuffer();
		try {
			// 8.0: AttributeOrganizer[] ao = theIBADefinitionDBService.getAttributeOrganizerRoots();
			AttributeHierarchyChild[] ao = IBA_DEFINITION_CACHE.getAttributeOrganizerRoots();

			for (int i = 0; i < ao.length; i++) {
				sb = _migrateAttribOrganizer(sb, ao[i], doTestOnly);
			} // end for i
		} catch (Throwable t) {
			t.printStackTrace();
			sb.append("ERROR. Migration stopped. Reason:\n");
			sb.append(t.getLocalizedMessage() + "\n");
		}
		return sb.toString();
	}

	private static StringBuffer _migrateAttribOrganizer(StringBuffer sb, AttributeHierarchyChild ao, Boolean doTestOnly) throws WTException {
		// in 8.0 we got AttributeOrganiser as param
		// now in 9.1 we get AttributeHierarchyChild as param
		
		final String emptyLogicalId = "    logicalIdentifier is empty\n";

		try {
			sb.append("ORGANISER:" + ao.getName() + "\n");
			AttributeOrgNodeView tempNode = IBADefinitionObjectsFactory.newAttributeOrgNodeView(ao);
			AttributeHierarchyChild[] child = IBA_DEFINITION_CACHE.getAttributeChildren(tempNode.getObjectID());
			String attrName = null;
			String logId = null;
			String foundMessage = null;
			for (int j = 0; child != null && j < child.length; j++) {
				// System.out.println("child=" + child[j]);
				if (child[j] instanceof AttributeOrganizer) {
					// recurse into this folder
					_migrateAttribOrganizer(sb, (AttributeOrganizer) child[j], doTestOnly);
				} else {
					// System.out.println("child=" + child[j]);
					AttributeDefDefaultView addv = IBADefinitionObjectsFactory.newAttributeDefDefaultView(child[j]);
					addv = IBADefinitionHelper.service.refreshAttributeDefDefaultView(addv);
					attrName = addv.getName();
					logId = addv.getLogicalIdentifier();
					foundMessage = "  FOUND: attrName=" + attrName + "/" + addv.getDescription() + "/" + addv.getDisplayName() + "/"
							+ addv.getHierarchyDisplayName() + " logId=" + logId + "\n";
					sb.append(foundMessage);
					// if (attrName!=null && !attrName.equals("ida2a2") &&
					// (logId==null || logId.length()==0)) {
					if (attrName != null && (logId == null || logId.length() == 0)) {
						sb.append(emptyLogicalId);

						if (!doTestOnly) {
							addv.setLogicalIdentifier(attrName);
							IBADefinitionHelper.service.updateAttributeDefinition(addv);
							addv = IBADefinitionHelper.service.refreshAttributeDefDefaultView(addv);
							logId = addv.getLogicalIdentifier();
							sb.append("    logicalIdentifier was updated to " + logId + "\n");
						}
					}
				}
			} // end for j
		} catch (WTPropertyVetoException wtpve) {
			throw new WTException(wtpve);
		} catch (RemoteException e) {
			throw new WTException(e);
		}
		return sb;
	}
	
	public static boolean isEmptyLogicalIDfound() {
		return emptyLogicalIDfound;
	}
}
