package com.ptc.generic.validators;

import com.ptc.generic.validators.validatorsResource;

import wt.util.WTMessage;
import wt.vc.VersionControlHelper;
import wt.vc.wip.Workable;

/**
 * Checks if the latest iteration of the object is passed
 *
 * @author cherrmann
 *
 */
public class GenericIsLatestIterationValidator<T extends Workable> implements GenericValidator<T> {

	private ValidationResult validationResult;
	private String errorMessage;
	private boolean invertResult;

	/**
	 * GenericIsLatestIterationValidator
	 */
	public GenericIsLatestIterationValidator() {
		this(WTMessage.getLocalizedMessage(VALIDATION_RESOURCE, validatorsResource.INVALID_IS_NOT_LATEST, null));
	}

	/**
	 * GenericIsLatestIterationValidator
	 *
	 * @param errorMessage default error message
	 */
	public GenericIsLatestIterationValidator(String errorMessage){
		this(errorMessage, false);
	}

	/**
	 * GenericIsLatestIterationValidator
	 *
	 * @param errorMessage default error message
	 * @param invertResult inverts the validation
	 */
	public GenericIsLatestIterationValidator(String errorMessage, boolean invertResult){
		this.errorMessage = errorMessage;
		this.invertResult = invertResult;
	}


	/**
	 * Checks if the given object is the latest iteration.
	 * Result can be inverted by setting invertResult to true.
	 *
	 * @param object an object of type Workable
	 * @return true if the given object is the latest iteration of this object
	 * @see com.ptc.generic.validators.GenericValidator#validate(java.lang.Object)
	 */
	public boolean validate(Workable object) {
		resetValidationResult();

		boolean result = false;

		if (object != null){
			if (VersionControlHelper.isLatestIteration(object)) {
				result = true;
			}
		} else {
			this.validationResult = new ValidationResult(INVALID_PARAMETER_WAS_NULL, false);
		}

		if (invertResult){
			result ^= true;
		}

		if (this.validationResult == null){
			if (result){
				this.validationResult = new ValidationResult(SUCCESS_MESSAGE, true);
			} else {
				this.validationResult = new ValidationResult(errorMessage, false);
			}
		}

		return this.validationResult.getIsValid();
	}

	public ValidationResult getValidationResult() {
		return this.validationResult;
	}

	public void resetValidationResult(){
		this.validationResult = null;
	}

}
