package com.ptc.generic.validators;

import java.text.MessageFormat;

import com.ptc.generic.validators.validatorsResource;

import wt.inf.container.WTContained;
import wt.inf.team.ContainerTeamHelper;
import wt.inf.team.ContainerTeamManaged;
import wt.org.OrganizationServicesHelper;
import wt.org.WTGroup;
import wt.org.WTPrincipal;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.WTRuntimeException;

/**
 * @author cherrmann
 *
 */
public class GenericMemberOfContainerTeamRoleValidator<T extends WTContained> implements GenericValidator<T> {

	private ValidationResult validationResult;
	private String errorMessage;
	private static final String defaultErrorMessage = WTMessage.getLocalizedMessage(VALIDATION_RESOURCE, validatorsResource.INVALID_NOT_MEMBER_OF_GROUP, null);
	//private static final String groupNotExistantErrorMessage = WTMessage.getLocalizedMessage(VALIDATION_RESOURCE, validatorsResource.INVALID_GROUP_NOT_EXISTANT, null);

	private String[] roleNames;
	private WTPrincipal user;

	/**
	 * @param user
	 * @param groupNames
	 */
	public GenericMemberOfContainerTeamRoleValidator(WTPrincipal user, String... roleNames) {
		this(null, user, roleNames);
	}

	/**
	 * @param errorMessage
	 * @param user
	 * @param groupNames
	 */
	public GenericMemberOfContainerTeamRoleValidator(String errorMessage, WTPrincipal user, String... roleNames){
		this.user = user;
		this.roleNames = roleNames;
		this.errorMessage = errorMessage;
	}

	/**
	 * Checks if the specified user is part of at least one of the specified roles in the passed objects team context
	 *
	 * @param object an object of the WTContained type
	 * @return true if the specified user is a member of at least one of the specified roles in the given container context
	 * @see com.ptc.generic.validators.GenericValidator#validate(java.lang.Object)
	 */
	public boolean validate(WTContained object) {
		resetValidationResult();

		boolean atLeastMemberOfOneRole = false;
		if (object != null){
			try {
				if (this.roleNames != null && this.user != null){
					WTContained wtcObject = object;
					if (!(object instanceof ContainerTeamManaged)) {
						wtcObject = (ContainerTeamManaged) wtcObject.getContainer();
					}
					for (int i = 0; i < roleNames.length; i++){

							WTGroup group = ContainerTeamHelper.service.findContainerTeamGroup((ContainerTeamManaged) wtcObject, ContainerTeamHelper.ROLE_GROUPS, roleNames[i]);
							if (group != null){
								if (OrganizationServicesHelper.manager.isMember(group, user)){
									atLeastMemberOfOneRole = true;
								}
							}
					}
					if (!atLeastMemberOfOneRole){
						if (errorMessage == null){
							String groups = "";
							if (groups.length() > 0){
								groups = roleNames[0];
							} else {
								groups = "<null>";
							}
							for (int i = 1; i < roleNames.length; i++){
								groups += ", " + roleNames[i];
							}

							this.validationResult = new ValidationResult(MessageFormat.format(defaultErrorMessage, user.getPrincipalDisplayIdentifier(), groups, wtcObject.getContainerName()), false);
						} else {
							this.validationResult = new ValidationResult(errorMessage, false);
						}
					}
				}
			} catch (WTException e) {
				this.validationResult = new ValidationResult(MessageFormat.format(EXCEPTION_THROWN, e.getLocalizedMessage()), false, null, e);
				e.printStackTrace();
			} catch (WTRuntimeException e) {
				this.validationResult = new ValidationResult(MessageFormat.format(EXCEPTION_THROWN, e.getLocalizedMessage()), false, null, e);
				e.printStackTrace();
			}
		} else {
			this.validationResult = new ValidationResult(INVALID_PARAMETER_WAS_NULL, false);
		}

		if (this.validationResult == null){
			this.validationResult = new ValidationResult(SUCCESS_MESSAGE, true);
		}

		return this.validationResult.getIsValid();
	}

	public ValidationResult getValidationResult() {
		return this.validationResult;
	}

	public void resetValidationResult(){
		this.validationResult = null;
	}

}
