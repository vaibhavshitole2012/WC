/* bcwti
 *
 * Copyright (c) 2012 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */
package com.ptc.generic;

import java.sql.Timestamp;

import org.apache.log4j.Logger;

import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.org.WTPrincipal;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.queue.*;
import wt.services.ManagerServiceFactory;
import wt.session.SessionContext;
import wt.session.SessionHelper;
import wt.util.WTException;

/**
 * Some queue handling utility methods. Should be used only from inside other
 * server-side code
 *
 * layer: server-side business layer
 *
 * @author lberger
 */
public class QueueServerLogic {

	public static final String svnUrl = "$URL: http://127.0.0.1/svn/KB_04082016/components/Generic-Utilities/src/com/ptc/generic/QueueServerLogic.java $";
	public static final String svnRev = "$Revision: 1.1.1.3 $ $Date: 2015/12/10 21:01:36IST $";
	
	private static final String CLASSNAME = QueueServerLogic.class.getName();
	private static final Logger logger = Logger.getLogger(CLASSNAME);

	/**
	 * Queries if a ScheduleQueue with the given queueName exists if not,
	 * creates it.
	 *
	 * @param queueName
	 * @throws WTException
	 */
	public static ScheduleQueue createScheduleQueueIfNecessary(String queueName) throws WTException {
		ScheduleQueue sq = (ScheduleQueue) QueueHelper.manager.getQueue(queueName, ScheduleQueue.class);
		logger.debug("ScheduledQueue '" + queueName + "' exists? sq=" + sq);

		//create queue itself if necessary
		if (sq == null) {
			sq = QueueHelper.manager.createScheduleQueue(queueName);
			logger.debug("created ScheduledQueue '" + queueName + "': sq=" + sq);
		}

		return sq;
	}

	/**
	 * Checks if a ScheduleQueueEntry with given className, methodName, and
	 * statusInfo exists Currently does not filter on given queueName
	 *
	 * @param queueName
	 * @param className
	 * @param methodName
	 * @param statusInfo
	 * @return
	 */
	public static QueryResult scheduleQueueEntriesExist(String queueName, String className, String methodName, String statusInfo) throws WTException {
		//TODO: we should also use queueName as criteria to filter further in Oracle. At the moment, entries are found in all queues
		QuerySpec qs = new QuerySpec(ScheduleQueueEntry.class);
		qs.appendWhere(new SearchCondition(ScheduleQueueEntry.class, ScheduleQueueEntry.TARGET_METHOD, SearchCondition.EQUAL, methodName));
		qs.appendAnd();
		qs.appendWhere(new SearchCondition(ScheduleQueueEntry.class, ScheduleQueueEntry.TARGET_CLASS, SearchCondition.EQUAL, className));
		qs.appendAnd();
		qs.appendWhere(new SearchCondition(ScheduleQueueEntry.class, ScheduleQueueEntry.STATUS_INFO + "." + StatusInfo.CODE, SearchCondition.EQUAL, statusInfo));
		logger.trace("Query to check queue entry - " + qs);
		
		final SessionContext oldSessionContext = SessionContext.newContext();
		QueryResult qr = null;
		
		try {
			// switching to admin user in order to avoid an AuthenticationException
			SessionHelper.manager.setAdministrator();
			qr = PersistenceHelper.manager.find(qs);
		} catch (final WTException ex) {
			logger.error(ex.getLocalizedMessage(), ex);
		} finally {
			SessionContext.setContext(oldSessionContext);
		}

		if (qr == null) {
			qr = new QueryResult();	
		}
		logger.debug("for '" + className + "." + methodName + "' in status '" + statusInfo + "' found entries: " + qr.size());
		return qr;
	}

	/**
	 *
	 *
	 * @param nextTime
	 * @param message
	 * @throws WTException
	 */
	public static void addNewScheduleQueueEntry(ScheduleQueue sq, String className, String methodName, Timestamp nextTime, String message) throws WTException {
		//Adding an entry
		Class[] argTypes = {String.class};
		Object[] args = {message};

		WTPrincipal administrator = SessionHelper.manager.getAdministrator();
		WTPrincipal previous = SessionContext.setEffectivePrincipal(administrator);
		try {
			sq.addEntry(administrator, methodName, className, argTypes, args, nextTime);
			logger.debug("added new queueEntry to call '" + className + "." + methodName + "' nextScheduledTime=" + nextTime);
		} finally {
			SessionContext.setEffectivePrincipal(previous);
		}
	}
	
	/**
	 * Returns a <b>ProcessingQueue</b> with given {@code queueName).<br>
     * Creates new one if queue with this name does not exist.
	 * 
	 * @param queueName
	 * @return
	 * @throws WTException 
	 */
	public static ProcessingQueue getProcessingQueue(String queueName) throws WTException {
		ProcessingQueue processingQueue = QueueHelper.manager.getQueue(queueName);

        if (processingQueue == null) {
            
            QueueService manager = (QueueService)ManagerServiceFactory.getDefault().getManager(QueueService.class);
        	if(manager instanceof StandardQueueService){
        		processingQueue = ((StandardQueueService) manager).createQueue(queueName, true);
        	} else {
        		processingQueue = QueueHelper.manager.createQueue(queueName);
        	}
        	
            //processingQueue = (ProcessingQueue) PersistenceHelper.manager.save(processingQueue);
            logger.debug("Queue " + processingQueue.getName() + " created.");
        } else {
            logger.debug("Queue " + processingQueue.getName() + " exists already.");
        }
        
        return processingQueue;
	}
	
	/**
	 * Adds new entry to a processing queue with given {@code queueName} in
	 * order to execute a method with given {@code methodName} from class with
	 * given {@code className}.
	 * 
	 * @param queueName
	 * @param methodName
	 * @param className
	 * @param argTypes
	 * @param args
	 * @throws WTException 
	 */
	public static void addNewProcessingQueueEntry(String queueName, String methodName, String className, Class<?>[] argTypes, Object[] args)
			throws WTException {
		WTPrincipal administrator = SessionHelper.manager.getAdministrator();
		WTPrincipal previousPrince = SessionContext.setEffectivePrincipal(administrator);
		try {
			ProcessingQueue processingQueue = getProcessingQueue(queueName);
			processingQueue.addEntry(administrator, methodName, className, argTypes, args);
		} finally {
			SessionContext.setEffectivePrincipal(previousPrince);
		}
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("NOT YET IMPLEMENTED");
	}
}