package com.ptc.generic.validators;

/**
 * ValidationResult
 * Used by GenericValidators to pass a status and message as result.
 *
 * @author cherrmann
 *
 */
public class ValidationResult {

	private String statusMessage;
	private boolean valid;
	private Object resultObject = null;
	private Throwable exception = null;
	private boolean hasException = false;

	/**
	 * ValidationResult
	 *
	 * @param statusMessage
	 * @param valid
	 */
	public ValidationResult(String statusMessage, boolean valid) {
		this.statusMessage = statusMessage;
		this.valid = valid;
	}

	/**
	 * ValidationResult
	 *
	 * @param statusMessage
	 * @param valid
	 * @param resultObject
	 */
	public ValidationResult(String statusMessage, boolean valid, Object resultObject) {
		this(statusMessage, valid);
		this.resultObject = resultObject;
	}

	/**
	 * ValidationResult
	 *
	 * @param statusMessage
	 * @param valid
	 * @param resultObject
	 * @param exception
	 */
	public ValidationResult(String statusMessage, boolean valid, Object resultObject, Throwable exception) {
		this(statusMessage, valid, resultObject);
		this.exception = exception;
		this.hasException = true;
	}

	/**
	 * Get the validation status message
	 *
	 * @return
	 */
	public String getStatusMessage() {
		return this.statusMessage;
	}

	/**
	 * Get the validation result
	 *
	 * @return
	 */
	public boolean getIsValid() {
		return this.valid;
	}

	/**
	 * Get the result object
	 *
	 * @return
	 */
	public Object getResultObject() {
		return resultObject;
	}

	/**
	 * Is an exception attached to this result?
	 *
	 * @return
	 */
	public boolean hasException(){
		return hasException;
	}

	/**
	 * Get the attached exception
	 *
	 * @return
	 */
	public Throwable getException(){
		return exception;
	}

	@Override
	public String toString() {
		return "Valid: " + this.valid + ", Status: " + this.statusMessage + ", hasException: " + this.hasException + ", Exception: " + this.exception != null ? this.exception.getLocalizedMessage() : "";
	}

}
