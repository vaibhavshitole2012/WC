package com.ptc.windchill.uwgm.cadx.saveas;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import wt.epm.EPMDocument;
import wt.epm.structure.EPMDependencyLink;
import wt.fc.BinaryLink;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.part.WTPart;
import wt.part.WTPartUsageLink;
import wt.templateutil.processor.HTTPState;
import wt.util.WTException;

import com.ptc.core.htmlcomp.jstable.JSTableFormHelper;
import com.ptc.core.logging.Log;
import com.ptc.core.logging.LogFactory;
import com.ptc.windchill.uwgm.cadx.request.AbstractWithWorkspaceRequestAdapter;
import com.ptc.windchill.uwgm.cadx.saveas.SaveAsRequestAdapterHelper;
import com.ptc.windchill.uwgm.soap.impl.uwgm.Requests_i;
import com.ptc.windchill.uwgm.soap.impl.uwgmdb.Workspace_i;
import com.ptc.windchill.uwgm.soap.impl.uwgmsvc.EpmSaveAsInstructionX20_i;
import com.ptc.windchill.uwgm.soap.impl.uwgmsvc.PartSaveAsInstructionX20_i;
import com.ptc.windchill.uwgm.soap.impl.uwgmsvc.SaveAsToWorkspace_i;

import ext.kb.util.KBUtils;

public class KBSaveAsToWorkspaceRequestAdapter extends AbstractWithWorkspaceRequestAdapter {
    @SuppressWarnings("unused")
    private static final String saveAsToWorkspaceRequestID = "CADX_SAVE_AS_TO_WORKSPACE_REQUEST";
    private Map<EPMDocument, String> docToOid;
    private Map<String, EPMDocument> oidToDoc;
    private Map<WTPart, String> partToOid;
    private Map<String, WTPart> oidToPart;
    private List<BinaryLink> dependencyLinks;
    private List<BinaryLink> usageLinks;
    private static Log log = LogFactory.getLog(KBSaveAsToWorkspaceRequestAdapter.class);

    public KBSaveAsToWorkspaceRequestAdapter() {
        this.docToOid = new HashMap<>();
        this.oidToDoc = new HashMap<>();
        this.partToOid = new HashMap<>();
        this.oidToPart = new HashMap<>();

        this.dependencyLinks = new ArrayList<>();
        this.usageLinks = new ArrayList<>();
    }

    protected Requests_i createCadxUwgmRequest(Properties paramProperties, HTTPState paramHTTPState) throws WTException {
    	SaveAsRequestAdapterHelper adapterHelper = new SaveAsRequestAdapterHelper(true);
    	
        SaveAsToWorkspace_i localSaveAsToWorkspace_i = SaveAsToWorkspace_i.create();
        localSaveAsToWorkspace_i.setId("CADX_SAVE_AS_TO_WORKSPACE_REQUEST");

        Workspace_i localWorkspace_i = createUwgmWorkspace(paramProperties);
        localSaveAsToWorkspace_i.setWorkspace(localWorkspace_i);

        JSTableFormHelper localJSTableFormHelper = new JSTableFormHelper(paramProperties);

        List localList = localJSTableFormHelper.getSubmitObjects();
        if (localList != null) {
            Iterator localIterator = localList.iterator();
            while (localIterator.hasNext()) {
                Persistable localPersistable = (Persistable) localIterator.next();
                ObjectReference localObjectReference = ObjectReference.newObjectReference(localPersistable);
                String str = KBUtils.REFERENCE_FACTORY.getReferenceString(localObjectReference);
                Object localObject;
                if (localPersistable instanceof EPMDocument) {
                    localObject = (EPMDocument) localPersistable;
                    if (log.isTraceEnabled())
                        log.trace("Found document " + ((EPMDocument) localObject).getCADName() + " oid = " + str);
                    this.docToOid.put((EPMDocument)localObject, str);
                    this.oidToDoc.put(str, (EPMDocument)localObject);
                } else if (localPersistable instanceof WTPart) {
                    localObject = (WTPart) localPersistable;
                    if (log.isTraceEnabled()) {
                        log.trace("Creating PartSaveAsInstruction for part " + ((WTPart) localObject).getNumber()
                                + " oid = " + str);
                    }

                    this.partToOid.put((WTPart)localObject, str);
                    this.oidToPart.put(str, (WTPart)localObject);
                } else if (localPersistable instanceof BinaryLink) {
                    localObject = (BinaryLink) localPersistable;
                    if (log.isTraceEnabled()) {
                        log.trace("Found binaryLink = " + localObject);
                    }
                    if (localObject instanceof EPMDependencyLink) {
                        if (log.isTraceEnabled())
                            log.trace("BinaryLink " + localObject + " is an EPMDependencyLink");
                        this.dependencyLinks.add((BinaryLink)localObject);
                    } else if (localObject instanceof WTPartUsageLink) {
                        if (log.isTraceEnabled()) {
                            log.trace("BinaryLink " + localObject + " is a WTPartUsageLink");
                        }
                        this.usageLinks.add((BinaryLink)localObject);
                    }
                }

            }

        }

        createEpmSaveAsInstructions(adapterHelper, localJSTableFormHelper, localSaveAsToWorkspace_i);

        createPartSaveAsInstructions(adapterHelper, localJSTableFormHelper, localSaveAsToWorkspace_i);

        createEpmReplaceInstructions(adapterHelper, localSaveAsToWorkspace_i);

        createPartReplaceInstructions(adapterHelper, localSaveAsToWorkspace_i);

        return ((Requests_i) adapterHelper.createRequestList(localSaveAsToWorkspace_i));
    }

    private void createEpmSaveAsInstructions(SaveAsRequestAdapterHelper paramSaveAsRequestAdapterHelper,
            JSTableFormHelper paramJSTableFormHelper, SaveAsToWorkspace_i paramSaveAsToWorkspace_i) throws WTException {
        if (!(this.docToOid.isEmpty())) {
            if (log.isTraceEnabled()) {
                log.trace("CAD documents to be copied = " + this.docToOid.keySet());
            }
            int i = 0;

            for (Map.Entry localEntry : this.docToOid.entrySet()) {
                EPMDocument localEPMDocument = (EPMDocument) localEntry.getKey();
                String str = (String) localEntry.getValue();

                paramSaveAsRequestAdapterHelper.cacheMasterID(localEPMDocument, str);

                if (paramSaveAsRequestAdapterHelper.isDocMarkedForReplace(paramJSTableFormHelper, str)) {
                    if (log.isTraceEnabled())
                        ;
                    log.trace("Marked for replace: CAD document " + localEPMDocument.getCADName() + " oid = " + str);
                }

                if (log.isTraceEnabled()) {
                    log.trace("Creating EpmSaveAsInstruction for CAD document " + localEPMDocument.getCADName() + " oid = "
                            + str);
                }
               	EpmSaveAsInstructionX20_i localEpmSaveAsInstructionX20_i = paramSaveAsRequestAdapterHelper
               			.createEpmSaveAsInstructionX26M020(localEPMDocument, paramJSTableFormHelper, str, true);
                paramSaveAsToWorkspace_i.appendToSaveAsInstructions(localEpmSaveAsInstructionX20_i);
                paramSaveAsToWorkspace_i.appendToFolderedIterations(localEpmSaveAsInstructionX20_i.getFolderedIteration());

                ++i;
            }

            if (log.isTraceEnabled())
                log.trace("Created " + i + " EpmSaveAsInstructions");
        } else if (log.isTraceEnabled()) {
            log.trace("No EpmSaveAsInstructions need to be created");
        }
    }

    private void createPartSaveAsInstructions(SaveAsRequestAdapterHelper paramSaveAsRequestAdapterHelper,
            JSTableFormHelper paramJSTableFormHelper, SaveAsToWorkspace_i paramSaveAsToWorkspace_i) throws WTException {
        if (!(this.partToOid.isEmpty())) {
            if (log.isTraceEnabled()) {
                log.trace("Parts to be copied = " + this.partToOid.keySet());
            }
            int i = 0;

            for (Map.Entry localEntry : this.partToOid.entrySet()) {
                WTPart localWTPart = (WTPart) localEntry.getKey();
                String str = (String) localEntry.getValue();

                paramSaveAsRequestAdapterHelper.cacheMasterID(localWTPart, str);

                if (paramSaveAsRequestAdapterHelper.isPartMarkedForReplace(paramJSTableFormHelper, str)) {
                    if (log.isTraceEnabled())
                        ;
                    log.trace("Marked for replace: Part " + localWTPart.getNumber() + " oid = " + str);
                }

                if (log.isTraceEnabled()) {
                    log.trace("Creating PartSaveAsInstruction for part " + localWTPart.getNumber() + " oid = " + str);
                }

                PartSaveAsInstructionX20_i localPartSaveAsInstructionX20_i = paramSaveAsRequestAdapterHelper
                        .createPartSaveAsInstructionX20(localWTPart, paramJSTableFormHelper, str, true);

                paramSaveAsToWorkspace_i.appendToSaveAsInstructions(localPartSaveAsInstructionX20_i);
                paramSaveAsToWorkspace_i.appendToFolderedIterations(localPartSaveAsInstructionX20_i.getFolderedIteration());

                ++i;
            }

            if (log.isTraceEnabled())
                log.trace("Created " + i + " PartSaveAsInstructions");
        } else if (log.isTraceEnabled()) {
            log.trace("No PartSaveAsInstructions need to be created");
        }
    }

    private void createEpmReplaceInstructions(SaveAsRequestAdapterHelper paramSaveAsRequestAdapterHelper,
            SaveAsToWorkspace_i paramSaveAsToWorkspace_i) throws WTException {
        Set<String> localSet1 = paramSaveAsRequestAdapterHelper.getReplaceDocOIDs();
        if ((localSet1 == null) || (localSet1.isEmpty())) {
            if (log.isTraceEnabled())
                log.trace("No EpmReplaceInstructions required");
            if ((this.dependencyLinks == null) || (this.dependencyLinks.isEmpty())) {
                return;
            }
        }

        Set<EPMDocument> localSet2 = this.docToOid.keySet();
        if ((localSet2 == null) || (localSet2.isEmpty())) {
            if (log.isTraceEnabled())
                log.trace("No EpmReplaceInstructions required");
            if ((this.dependencyLinks == null) || (this.dependencyLinks.isEmpty())) {
                return;
            }

        }

        Set<EPMDocument> localSet3 = extractDocs(localSet1);
        List<BinaryLink> localList = paramSaveAsRequestAdapterHelper.fetchDependencyLinks(localSet2, localSet3);
        this.dependencyLinks.addAll(localList);
        if ((this.dependencyLinks == null) || (this.dependencyLinks.isEmpty())) {
            if (log.isTraceEnabled())
                log.trace("No links found. Hence no EpmReplaceInstructions required.");
            return;
        }

        createEpmReplaceInstructionsFromLinks(paramSaveAsRequestAdapterHelper, paramSaveAsToWorkspace_i);
    }

    private void createEpmReplaceInstructionsFromLinks(SaveAsRequestAdapterHelper paramSaveAsRequestAdapterHelper,
            SaveAsToWorkspace_i paramSaveAsToWorkspace_i) throws WTException {
        if (log.isTraceEnabled()) {
            log.trace("Dependency links = " + this.dependencyLinks);
        }
        for (BinaryLink localBinaryLink : this.dependencyLinks) {
            if (log.isTraceEnabled())
                log.trace("Creating EpmReplaceInstruction for dependency link " + localBinaryLink);
            paramSaveAsToWorkspace_i.appendToReplaceInstructions(paramSaveAsRequestAdapterHelper
                    .createEpmReplaceInstruction(localBinaryLink));
        }

        if (log.isTraceEnabled())
            log.trace("Created " + this.dependencyLinks.size() + " EpmReplaceInstructions");
    }

    private void createPartReplaceInstructions(SaveAsRequestAdapterHelper paramSaveAsRequestAdapterHelper,
            SaveAsToWorkspace_i paramSaveAsToWorkspace_i) throws WTException {
        if (!(this.usageLinks.isEmpty())) {
            createPartReplaceInstructionsFromLinks(paramSaveAsRequestAdapterHelper, paramSaveAsToWorkspace_i);
            return;
        }

        Set<String> localSet1 = paramSaveAsRequestAdapterHelper.getReplacePartOIDs();
        if ((localSet1 == null) || (localSet1.isEmpty())) {
            if (log.isTraceEnabled())
                log.trace("No PartReplaceInstructions required");
            return;
        }

        Set<WTPart> localSet2 = this.partToOid.keySet();
        if ((localSet2 == null) || (localSet2.isEmpty())) {
            if (log.isTraceEnabled())
                log.trace("No PartReplaceInstructions required");
            return;
        }

        Set<WTPart> localSet3 = extractParts(localSet1);
        this.usageLinks = paramSaveAsRequestAdapterHelper.fetchUsageLinks(localSet2, localSet3);
        if ((this.usageLinks == null) || (this.usageLinks.isEmpty())) {
            if (log.isTraceEnabled())
                log.trace("No links found. Hence no PartReplaceInstructions required.");
            return;
        }

        createPartReplaceInstructionsFromLinks(paramSaveAsRequestAdapterHelper, paramSaveAsToWorkspace_i);
    }

    private void createPartReplaceInstructionsFromLinks(SaveAsRequestAdapterHelper paramSaveAsRequestAdapterHelper,
            SaveAsToWorkspace_i paramSaveAsToWorkspace_i) throws WTException {
        if (log.isTraceEnabled()) {
            log.trace("Usage links = " + this.usageLinks);
        }
        for (BinaryLink localBinaryLink : this.usageLinks) {
            if (log.isTraceEnabled())
                log.trace("Creating PartReplaceInstruction for usage link " + localBinaryLink);
            paramSaveAsToWorkspace_i.appendToReplaceInstructions(paramSaveAsRequestAdapterHelper
                    .createPartReplaceInstruction(localBinaryLink));
        }

        if (log.isTraceEnabled())
            log.trace("Created " + this.usageLinks.size() + " PartReplaceInstructions");
    }

    private Set<EPMDocument> extractDocs(Set<String> paramSet) {
        if ((paramSet == null) || (paramSet.isEmpty())) {
            return Collections.emptySet();
        }
        HashSet<EPMDocument> localHashSet = new HashSet<>(paramSet.size());
        for (String str : paramSet) {
            localHashSet.add(this.oidToDoc.get(str));
        }
        return localHashSet;
    }

    private Set<WTPart> extractParts(Set<String> paramSet) {
        if ((paramSet == null) || (paramSet.isEmpty())) {
            return Collections.emptySet();
        }
        HashSet<WTPart> localHashSet = new HashSet<>(paramSet.size());
        for (String str : paramSet) {
            localHashSet.add(this.oidToPart.get(str));
        }
        return localHashSet;
    }
}
