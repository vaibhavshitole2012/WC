/*
 *  bcwti
 * 
 *  Copyright (c) 2010 Parametric Technology Corporation (PTC). All Rights
 *  Reserved.
 * 
 *  This software is the confidential and proprietary information of PTC.
 *  You shall not disclose such confidential information and shall use it
 *  only in accordance with the terms of the license agreement.
 * 
 *  ecwti
 */
package com.ptc.generic.userprefs.annotations;

import com.ptc.generic.userprefs.UserPrefsManager;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * This annotation declares that given preference should be cached on startup
 * of ECA client. 
 * 
 * @see UserPrefsManager
 * @since 4.0
 * @author Marek Piechut <mpiechut@ptc.com>
 */
@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
public @interface PreloadedPreference {
}
