package com.ptc.generic.userprefs;

/**
 * //TODO Klassenfunktion dokumentieren.
 *
 * @author etrauca
 * @since 20.07.2010
 */
public interface PreferenceIfc {

    public String getName();
    public String getDefaultValue();
    public UserPrefCategory getCategory();
    public int getVisibility();
    public UserPrefClient getClient();
}
