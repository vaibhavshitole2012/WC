package com.ptc.generic.csv;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

class ExcelCSVLexer {
	private static int[] zzUnpackAction() {
		int ai[] = new int[19];
		int i = 0;
		i = zzUnpackAction(
				"\002\000\002\001\001\002\002\003\001\004\001\005\001\006\002\007\001\b\001\t\001\001\001\n\001\001\001\013\001\f",
				i, ai);
		return ai;
	}

	private static int zzUnpackAction(String s, int i, int ai[]) {
		int j = 0;
		int k = i;
		for (int l = s.length(); j < l;) {
			int i1 = s.charAt(j++);
			char c = s.charAt(j++);
			do
				ai[k++] = c;
			while (--i1 > 0);
		}
		return k;
	}

	private static int[] zzUnpackRowMap() {
		int ai[] = new int[19];
		int i = 0;
		i = zzUnpackRowMap(
				"\000\000\000\005\000\n\000\017\000\024\000\031\000\036\000\036\000#\000(\000-\000\036\000\036\0002\0007\000\036\000<\000A\000F",
				i, ai);
		return ai;
	}

	private static int zzUnpackRowMap(String s, int i, int ai[]) {
		int j = 0;
		int k = i;
		for (int l = s.length(); j < l;) {
			int i1 = s.charAt(j++) << 16;
			ai[k++] = i1 | s.charAt(j++);
		}
		return k;
	}

	private static int[] zzUnpackTrans() {
		int ai[] = new int[75];
		int i = 0;
		i = zzUnpackTrans(
				"\001\005\001\006\001\007\001\b\001\t\001\n\001\013\001\f\001\r\001\016\001\017\001\006\001\007\001\020\001\017\001\021\001\006\001\007\002\021\001\005\003\000\001\005\002\000\001\007\007\000\004\t\001\022\001\n\003\000\001\n\002\000\001\f\002\000\004\016\001\023\001\017\003\000\001\017\001\021\002\000\002\021\004\000\001\t\004\000\001\016",
				i, ai);
		return ai;
	}

	private static int zzUnpackTrans(String s, int i, int ai[]) {
		int j = 0;
		int k = i;
		for (int l = s.length(); j < l;) {
			int i1 = s.charAt(j++);
			int j1 = s.charAt(j++);
			j1--;
			do
				ai[k++] = j1;
			while (--i1 > 0);
		}
		return k;
	}

	private static int[] zzUnpackAttribute() {
		int ai[] = new int[19];
		int i = 0;
		i = zzUnpackAttribute(
				"\002\000\004\001\002\t\003\001\002\t\002\001\001\t\003\001",
				i, ai);
		return ai;
	}

	private static int zzUnpackAttribute(String s, int i, int ai[]) {
		int j = 0;
		int k = i;
		for (int l = s.length(); j < l;) {
			int i1 = s.charAt(j++);
			char c = s.charAt(j++);
			do
				ai[k++] = c;
			while (--i1 > 0);
		}
		return k;
	}

	public static void main(String args[]) {
		try {
			Object obj;
			if (args.length > 0) {
				File file = new File(args[0]);
				if (file.exists()) {
					if (file.canRead())
						obj = new FileInputStream(file);
					else
						throw new IOException((new StringBuffer()).append(
								"Could not open ").append(args[0]).toString());
				} else {
					throw new IOException((new StringBuffer()).append(
							"Could not find ").append(args[0]).toString());
				}
			} else {
				obj = System.in;
			}
			ExcelCSVLexer excelcsvlexer = new ExcelCSVLexer(
					((InputStream) (obj)));
			String s;
			while ((s = excelcsvlexer.getNextToken()) != null)
				System.out.println((new StringBuffer()).append("").append(
						excelcsvlexer.getLineNumber()).append(" ").append(s)
						.toString());
		} catch (IOException ioexception) {
			System.out.println(ioexception.getMessage());
		}
	}

	private void ensureCharacterMapIsInstance() {
		if (ZZ_CMAP == zzcmap_instance) {
			zzcmap_instance = new char[ZZ_CMAP.length];
			System.arraycopy(ZZ_CMAP, 0, zzcmap_instance, 0, ZZ_CMAP.length);
		}
	}

	private boolean charIsSafe(char c) {
		return zzcmap_instance[c] == ZZ_CMAP[97]
				|| zzcmap_instance[c] == ZZ_CMAP[9];
	}

	private void updateCharacterClasses(char c, char c1) {
		ensureCharacterMapIsInstance();
		zzcmap_instance[c1] = zzcmap_instance[c];
		switch (c) {
		case 34:
		case 44:
			zzcmap_instance[c] = ZZ_CMAP[97];
			break;
		default:
			zzcmap_instance[c] = ZZ_CMAP[c];
			break;
		}
	}

	public void changeDelimiter(char c) throws BadDelimiterException {
		if (c == delimiter)
			return;
		if (!charIsSafe(c)) {
			throw new BadDelimiterException((new StringBuffer()).append(c)
					.append(" is not a safe delimiter.").toString());
		}
        updateCharacterClasses(delimiter, c);
        delimiter = c;
        return;
	}

	public void changeQuote(char c) throws BadQuoteException {
		if (c == quote)
			return;
		if (!charIsSafe(c)) {
			throw new BadQuoteException((new StringBuffer()).append(c).append(
					" is not a safe quote.").toString());
		}
        updateCharacterClasses(quote, c);
        quote = c;
        return;
	}

	private String unescape(String s) {
		if (s.indexOf('"', 1) == s.length() - 1)
			return s.substring(1, s.length() - 1);
		StringBuffer stringbuffer = new StringBuffer(s.length());
		for (int i = 1; i < s.length() - 1; i++) {
			char c = s.charAt(i);
			char c1 = s.charAt(i + 1);
			if (c == '"' && c1 == '"') {
				i++;
				stringbuffer.append("\"");
			} else {
				stringbuffer.append(c);
			}
		}
		return stringbuffer.toString();
	}

	public void setCommentStart(String s) {
		commentDelims = s;
	}

	public int getLineNumber() {
		return lines;
	}

	ExcelCSVLexer(Reader reader) {
		zzcmap_instance = ZZ_CMAP;
		zzLexicalState = 0;
		zzBuffer = new char[16384];
		zzAtBOL = true;
		delimiter = ',';
		quote = '"';
		commentDelims = "";
		addLine = 1;
		lines = 0;
		zzReader = reader;
	}

	ExcelCSVLexer(InputStream inputstream) {
		this((new InputStreamReader(inputstream)));
	}

	private static char[] zzUnpackCMap(String s) {
		char ac[] = new char[65536];
		int i = 0;
		int j = 0;
		while (i < 18) {
			int k = s.charAt(i++);
			char c = s.charAt(i++);
			do
				ac[j++] = c;
			while (--k > 0);
		}
		return ac;
	}

	private boolean zzRefill() throws IOException {
		if (zzStartRead > 0) {
			System.arraycopy(zzBuffer, zzStartRead, zzBuffer, 0, zzEndRead
					- zzStartRead);
			zzEndRead -= zzStartRead;
			zzCurrentPos -= zzStartRead;
			zzMarkedPos -= zzStartRead;
			zzPushbackPos -= zzStartRead;
			zzStartRead = 0;
		}
		if (zzCurrentPos >= zzBuffer.length) {
			char ac[] = new char[zzCurrentPos * 2];
			System.arraycopy(zzBuffer, 0, ac, 0, zzBuffer.length);
			zzBuffer = ac;
		}
		int i = zzReader.read(zzBuffer, zzEndRead, zzBuffer.length - zzEndRead);
		if (i < 0) {
			return true;
		}
        zzEndRead += i;
        return false;
	}

	public final void yyclose() throws IOException {
		zzAtEOF = true;
		zzEndRead = zzStartRead;
		if (zzReader != null)
			zzReader.close();
	}

	public final void yyreset(Reader reader) {
		zzReader = reader;
		zzAtBOL = true;
		zzAtEOF = false;
		zzEndRead = zzStartRead = 0;
		zzCurrentPos = zzMarkedPos = zzPushbackPos = 0;
		yyline = yychar = yycolumn = 0;
		zzLexicalState = 0;
	}

	public final int yystate() {
		return zzLexicalState;
	}

	public final void yybegin(int i) {
		zzLexicalState = i;
	}

	public final String yytext() {
		return new String(zzBuffer, zzStartRead, zzMarkedPos - zzStartRead);
	}

	public final char yycharat(int i) {
		return zzBuffer[zzStartRead + i];
	}

	public final int yylength() {
		return zzMarkedPos - zzStartRead;
	}

	private void zzScanError(int i) {
		String s;
		try {
			s = ZZ_ERROR_MSG[i];
		} catch (ArrayIndexOutOfBoundsException arrayindexoutofboundsexception) {
			s = ZZ_ERROR_MSG[0];
		}
		throw new Error(s);
	}

	public void yypushback(int i) {
		if (i > yylength())
			zzScanError(2);
		zzMarkedPos -= i;
	}

	public String getNextToken() throws IOException {
		int l = zzEndRead;
		char ac[] = zzBuffer;
		char ac1[] = zzcmap_instance;
		int ai[] = ZZ_TRANS;
		int ai1[] = ZZ_ROWMAP;
		int ai2[] = ZZ_ATTRIBUTE;
		do {
			int k = zzMarkedPos;
			int i = -1;
			int j = zzCurrentPos = zzStartRead = k;
			zzState = zzLexicalState;
			char c;
			int j1;
			label0: do {
				do {
					if (j < l) {
						c = ac[j++];
					} else {
						if (zzAtEOF) {
							c = '\uFFFF';
							break label0;
						}
						zzCurrentPos = j;
						zzMarkedPos = k;
						boolean flag = zzRefill();
						j = zzCurrentPos;
						k = zzMarkedPos;
						ac = zzBuffer;
						l = zzEndRead;
						if (flag) {
							c = '\uFFFF';
							break label0;
						}
						c = ac[j++];
					}
					int i1 = ai[ai1[zzState] + ac1[c]];
					if (i1 == -1)
						break label0;
					zzState = i1;
					j1 = ai2[zzState];
				} while ((j1 & 1) != 1);
				i = zzState;
				k = j;
			} while ((j1 & 8) != 8);
			zzMarkedPos = k;
			switch (i >= 0 ? ZZ_ACTION[i] : i) {
			case 2:
				lines += addLine;
				addLine = 0;
				String s = yytext();
				if (commentDelims.indexOf(s.charAt(0)) == -1) {
					yybegin(2);
					return s;
				}
				yybegin(3);
				break;
			case 8:
				yybegin(1);
				return "";
			case 3:
				addLine++;
				yybegin(0);
				break;
			case 4:
				lines += addLine;
				addLine = 0;
				yybegin(1);
				return "";
			case 11:
				lines += addLine;
				addLine = 0;
				yybegin(2);
				return unescape(yytext());
			case 6:
				yybegin(2);
				return yytext();
			case 7:
				yybegin(0);
				addLine++;
				return "";
			case 5:
				lines += addLine;
				addLine = 0;
				yybegin(0);
				return yytext();
			case 10:
				yybegin(1);
				break;
			case 12:
				yybegin(2);
				return unescape(yytext());
			case 9:
				yybegin(0);
				return yytext();
			default:
				if (c == '\uFFFF' && zzStartRead == zzCurrentPos) {
					zzAtEOF = true;
					switch (zzLexicalState) {
					case 1:
						yybegin(0);
						addLine++;
						return "";
					default:
						return null;
					case 20:
						break;
					}
				} else {
					zzScanError(1);
				}
				break;
			case 1:
			case 13:
			case 14:
			case 15:
			case 16:
			case 17:
			case 18:
			case 19:
			case 20:
			case 21:
			case 22:
			case 23:
			case 24:
				break;
			}
		} while (true);
	}

	public static final int YYEOF = -1;

	private static final int ZZ_BUFFERSIZE = 16384;

	public static final int BEFORE = 1;

	public static final int YYINITIAL = 0;

	public static final int COMMENT = 3;

	public static final int AFTER = 2;

	private static final String ZZ_CMAP_PACKED = "\n\000\001\002\002\000\001\001\024\000\001\004\t\000\001\003\uFFD3\0";

	private static final char ZZ_CMAP[] = zzUnpackCMap("\n\000\001\002\002\000\001\001\024\000\001\004\t\000\001\003\uFFD3\0");

	private static final int ZZ_ACTION[] = zzUnpackAction();

	private static final String ZZ_ACTION_PACKED_0 = "\002\000\002\001\001\002\002\003\001\004\001\005\001\006\002\007\001\b\001\t\001\001\001\n\001\001\001\013\001\f";

	private static final int ZZ_ROWMAP[] = zzUnpackRowMap();

	private static final String ZZ_ROWMAP_PACKED_0 = "\000\000\000\005\000\n\000\017\000\024\000\031\000\036\000\036\000#\000(\000-\000\036\000\036\0002\0007\000\036\000<\000A\000F";

	private static final int ZZ_TRANS[] = zzUnpackTrans();

	private static final String ZZ_TRANS_PACKED_0 = "\001\005\001\006\001\007\001\b\001\t\001\n\001\013\001\f\001\r\001\016\001\017\001\006\001\007\001\020\001\017\001\021\001\006\001\007\002\021\001\005\003\000\001\005\002\000\001\007\007\000\004\t\001\022\001\n\003\000\001\n\002\000\001\f\002\000\004\016\001\023\001\017\003\000\001\017\001\021\002\000\002\021\004\000\001\t\004\000\001\016";

	private char zzcmap_instance[];

	private static final int ZZ_UNKNOWN_ERROR = 0;

	private static final int ZZ_NO_MATCH = 1;

	private static final int ZZ_PUSHBACK_2BIG = 2;

	private static final String ZZ_ERROR_MSG[] = {
			"Unkown internal scanner error", "Error: could not match input",
			"Error: pushback value was too large" };

	private static final int ZZ_ATTRIBUTE[] = zzUnpackAttribute();

	private static final String ZZ_ATTRIBUTE_PACKED_0 = "\002\000\004\001\002\t\003\001\002\t\002\001\001\t\003\001";

	private Reader zzReader;

	private int zzState;

	private int zzLexicalState;

	private char zzBuffer[];

	private int zzMarkedPos;

	private int zzPushbackPos;

	private int zzCurrentPos;

	private int zzStartRead;

	private int zzEndRead;

	private int yyline;

	private int yychar;

	private int yycolumn;

	private boolean zzAtBOL;

	private boolean zzAtEOF;

	private char delimiter;

	private char quote;

	private String commentDelims;

	private int addLine;

	private int lines;
	static {
	}
}
