/*
 * bcwti Copyright (c) 2013 Parametric Technology Corporation (PTC). All Rights Reserved. This software is the confidential and proprietary information of PTC.
 * You shall not disclose such confidential information and shall use it only in accordance with the terms of the license agreement. ecwti
 */
package com.ptc.generic.part;

import java.rmi.RemoteException;
import java.util.Arrays;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.folder.Folder;
import wt.folder.FolderEntry;
import wt.folder.FolderHelper;
import wt.iba.value.service.IBAValueDBService;
import wt.inf.container.WTContainerHelper;
import wt.inf.container.WTContainerRef;
import wt.method.RemoteAccess;
import wt.part.QuantityUnit;
import wt.part.Source;
import wt.part.WTPart;
import wt.pds.StatementSpec;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.type.TypeDefinitionReference;
import wt.type.TypedUtilityServiceHelper;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.WTPropertyVetoException;
import wt.vc.config.LatestConfigSpec;
import wt.vc.wip.WorkInProgressHelper;

import com.ptc.generic.FcHelper;
import com.ptc.generic.iba.IBAUtil;
import com.ptc.ssp.util.SoftTypeHelper;

import ext.kb.util.ObjectRevisionHelper;

/**
 * @author pielab
 */
public class PartHelper implements RemoteAccess {

	public static final String svnUrl = "$URL: http://127.0.0.1/svn/KB_04082016/components/Generic-Utilities/src/com/ptc/generic/part/PartHelper.java $";
	public static final String svnRev = "$Revision: 1.1.1.6 $ $Date: 2018/05/24 18:09:31IST $";
	private static final String CLASSNAME = PartHelper.class.getName();
	private static final Logger logger = Logger.getLogger(CLASSNAME);
	private static final IBAValueDBService ibaService = new IBAValueDBService();

	public static WTPart createWTPart(String name, String number, String type, String wtContainerPath, String folderPath, Source source) throws WTException,
			WTPropertyVetoException, RemoteException {
		WTPart part = WTPart.newWTPart();
		part.setName(name);
		part.setNumber(number);
		if (type == null) {
			type = WTPart.class.getName();
		}
		TypeDefinitionReference reference = TypedUtilityServiceHelper.service.getTypeDefinitionReference(type);
		part.setTypeDefinitionReference(reference);
		WTContainerRef containerReference = WTContainerHelper.service.getByPath(wtContainerPath);
		part.setContainerReference(containerReference);
		Folder folder = FolderHelper.service.getFolder(folderPath, containerReference);
		FolderHelper.assignLocation((FolderEntry) part, folder);
		part.setDefaultUnit(QuantityUnit.getQuantityUnitDefault());
		part.setSource(source);
		return (WTPart) PersistenceHelper.manager.store(part);
	}
	
	public static void deleteWTPart(String number, String version, String iteration) throws WTException {
		PersistenceHelper.manager.delete(getPart(number, version, iteration));
	}
	
	public static void deleteWTPart(String number) throws WTException {
		deleteWTPart(number, null, null);
	}

	public static WTPart getPart(String number, String version, String iteration) throws WTException {
		if (StringUtils.isBlank(number)) {
			return null;
		}
		LatestConfigSpec configSpec = null;
		QuerySpec qs = new QuerySpec();
		int wtPartIndex = qs.appendClassList(WTPart.class, true);
		qs.appendWhere(new SearchCondition(WTPart.class, WTPart.NUMBER, SearchCondition.EQUAL, number.toUpperCase(), false), new int[] { wtPartIndex });
		if (StringUtils.isNotBlank(version)) {
			qs.appendAnd();
			qs.appendWhere(new SearchCondition(WTPart.class, "versionInfo.identifier.versionId", SearchCondition.EQUAL, version, false),
					new int[] { wtPartIndex });
			if (StringUtils.isNotBlank(iteration)) {
				qs.appendAnd();
				qs.appendWhere(new SearchCondition(WTPart.class, "iterationInfo.identifier.iterationId", SearchCondition.EQUAL, iteration, false),
						new int[] { wtPartIndex });
			} else {
				qs.appendAnd();
				qs.appendWhere(new SearchCondition(WTPart.class, "iterationInfo.latest", SearchCondition.IS_TRUE), new int[] { wtPartIndex });
			}
		} else {
			configSpec = new LatestConfigSpec();
			qs = configSpec.appendSearchCriteria(qs);
		}
		if (logger.isDebugEnabled()) {
			logger.debug("getPart(" + number + ", " + version + ", " + iteration + ")");
			logger.debug("getPart() SQL: " + qs);
		}
		QueryResult qr = PersistenceHelper.manager.find((StatementSpec) qs);
		if (logger.isDebugEnabled()) {
			logger.debug("Query found " + qr.size() + " matching parts.");
		}
		if(qr.size() > 0){
			WTPart part = (WTPart) ((Persistable[]) qr.nextElement())[0];
			if(qr.size() > 1){
				part = (WTPart) ObjectRevisionHelper.getLatestVersionByPersistable(part);
			}
			if (WorkInProgressHelper.isCheckedOut(part)) {
				throw new WTException(WTMessage.getLocalizedMessage("wt.vc.wip.wipResource", "1", null));
			} else {
				return part;
			}
		} else {
			return null;
		}
	}
	
	public static WTPart setIBA(WTPart part, Map<String, Object> attributes) throws WTException, WTPropertyVetoException {
		for (Entry<String, Object> entry : attributes.entrySet()) {
			IBAUtil.createIBAStringValue(part, entry.getKey(), entry.getValue().toString());
		}
		ibaService.updateAttributeContainer(part, null, null, null);
		return part;
	}
	
	/**
     * converts the given object o (either String, WTReference, or WTPart) to a WTPart
     * does not check if object has correct softtype
     * method should only be used on server!
     *
     * @param o
     * @return a WTPart
     * @throws WTException if the given object can not be converted to a WTPart
     */
    public static WTPart convertToWTPart(Object o) throws WTException {
        return convertToWTPart(o, (String)null);
    }

    /**
     * converts the given object o (either String, WTReference, or WTPart) to a WTPart
     * if shortSofttypeName is not null, then checks if the converted object is of the given softtype
     * method should only be used on server!
     *
     * @param o
     * @param shortSofttypeName short name of softtype without full hierarchy, e.g. VWConstants.SOFTTYPE_THEOTEIL
     * @return a WTPart
     * @throws WTException if the given object can not be converted to a WTPart, or if the WTPart has not the required softtype
     */
    public static WTPart convertToWTPart(Object o, String shortSofttypeName) throws WTException {
        if(shortSofttypeName==null || shortSofttypeName.length()==0) {
            return convertToWTPart(o, new String[0]);
        } else {
            return convertToWTPart(o, new String[]{shortSofttypeName});
        }
    }

    /**
     * converts the given object o (either String, WTReference, or WTPart) to a WTPart
     * if shortSofttypeNames isn't empty, then check if the converted object is of one of the given softtypes
     * method should only be used on server!
     *
     * @param o
     * @param shortSofttypeNames array of short names of softtype without full hierarchy, e.g. VWConstants.SOFTTYPE_BAUSTUFE, VWConstants.SOFTTYPE_SN
     * @return a WTPart
     * @throws WTException if the given object can not be converted to a WTPart, or if the WTPart has not the required softtype
     */
    public static WTPart convertToWTPart(Object o, String[] shortSofttypeNames) throws WTException {
        //not nice to set o to a new object class several times, but then the whole stuff below becomes quite easy
        WTPart part = null;
        try {
            
            o = FcHelper.convertToPersistable(o);
            if (o instanceof WTPart) {
                part = (WTPart) o;
            } else {
                throw new WTException("Given object does not represent a WTPart: o=" + o + " o.class=" + o.getClass().getName());
            }

            //check for softtype if it was given
            if(shortSofttypeNames!=null && shortSofttypeNames.length!=0) {
                //there are softtype names given
                boolean foundCorrectST = false;
                for(String stname : shortSofttypeNames) {
                    if(SoftTypeHelper.isType(part,  stname)) {
                        foundCorrectST = true;
                        break;
                    }
                }
                if(!foundCorrectST) {
                	final String allowedSofttypes = Arrays.toString(shortSofttypeNames);
					final String actualTypeName = SoftTypeHelper.getTypeName(part);
					logger.error("Allowed = " + allowedSofttypes + "\nActual = " + actualTypeName);
					throw new WTException("Allowed = " + allowedSofttypes + "\nActual = " + actualTypeName);
                }
            }
        } catch(Exception e) {
            if(e instanceof WTException) {
                throw (WTException)e;
            }
            else {
                throw new WTException(e);
            }
        }
        return part;
    }
	
}