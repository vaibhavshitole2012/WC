package com.ptc.generic;

import java.io.*;
import java.nio.charset.Charset;

/**
 * This is a very simple diff tool to compare text files line by line
 * DO NOT USE in production, unless you have reviewed the code fully by yourself.
 * It is a quick hack for some automated testcases that we do not run on production systems
 * 
 * @author L.Berger
 * initial version: 20.07.2009
 *
 */
public class FileDiff {
	
	public static final String svnRev = "$Revision: 1.1.1.3 $ $Date: 2015/12/10 21:01:36IST $";
	public static final String svnUrl = "$URL: http://127.0.0.1/svn/KB_04082016/components/Generic-Utilities/src/com/ptc/generic/FileDiff.java $";	
	
	public enum CompareSettings {COMPARE_WHITESPACE, IGNORE_WHITESPACE_FRONT_AND_END};
	private static final Charset ENCODING = Charset.forName("Cp1252");
	
	public static void main(String args[]) {
		if(args.length!=2) {
			throw new RuntimeException("2 args needed");
		}
		if(diff(args[0], args[1])) {
			System.out.println("files are identical");
		} else {
			System.out.println("files are different");
		}
	}

	/**
	 * 
	 * @param filename1
	 * @param filename2
	 * @return true if files are equal
	 */
	public static boolean diff(String filename1, String filename2) {
		try{
			DataInputStream dis1 = getDIS(filename1);
			DataInputStream dis2 = getDIS(filename2);
			BufferedReader br1 = new BufferedReader(new InputStreamReader(dis1, ENCODING));
			BufferedReader br2 = new BufferedReader(new InputStreamReader(dis2, ENCODING));
			String strLine1;
			String strLine2;
			//Read File Line By Line
			while ((strLine1 = br1.readLine()) != null)   {
				//do we also have a line in file2?
				if((strLine2 = br2.readLine())==null) {
					return false;
				}
				if(!strLine1.equals(strLine2)) {
					return false;
				}
			}
			
			//check if file2 has more lines
			if((strLine2 = br2.readLine())!=null) {
				return false;
			}
			
			//Close the input stream
			br1.close();
			br2.close();
			return true;
		}catch (Exception e){//Catch exception if any
			System.err.println("Error: " + e.getMessage());
			return false;
		}
	}

	/**
	 * 
	 * @param filename1
	 * @param filename2
	 * @return 0 if files are equal, otherwise line number within the first file where the error occurred.
	 *   -1 if if first file has more lines than second one. 
	 *   -2 if second file has more lines than the first one.
	 *   -3 in case of exception
	 */ 
	public static int diffLineSpecific(String filename1, String filename2) {
		return diffLineSpecific(filename1, filename2, CompareSettings.COMPARE_WHITESPACE);
	}
	public static int diffLineSpecific(String filename1, String filename2, CompareSettings cs) {
		try{
			DataInputStream dis1 = getDIS(filename1);
			DataInputStream dis2 = getDIS(filename2);
			BufferedReader br1 = new BufferedReader(new InputStreamReader(dis1, ENCODING));
			BufferedReader br2 = new BufferedReader(new InputStreamReader(dis2, ENCODING));
			String strLine1;
			String strLine2;
			int lineCount = 1;
			//Read File Line By Line
			while ((strLine1 = br1.readLine()) != null)   {
				//do we also have a line in file2?
				if((strLine2 = br2.readLine())==null) {
					return -1;
				}
				if(CompareSettings.IGNORE_WHITESPACE_FRONT_AND_END.equals(cs)) {
					strLine1 = strLine1.trim();
					strLine2 = strLine2.trim();
				}
				if(!strLine1.equals(strLine2)) {
					return lineCount;
				}
				lineCount++;
			}
			
			//check if file2 has more lines
			if((strLine2 = br2.readLine())!=null) {
				return -1;
			}
			
			//Close the input stream
			br1.close();
			br2.close();
			return 0;
		}catch (Exception e){//Catch exception if any
			System.err.println("Error: " + e.getMessage());
			return -3;
		}
	}
	
	private static DataInputStream getDIS(String filename) throws Exception {
		// Open the file that is the first 
		// command line parameter
		FileInputStream fstream = new FileInputStream(filename);
		// Get the object of DataInputStream
		return new DataInputStream(fstream);
	}
}