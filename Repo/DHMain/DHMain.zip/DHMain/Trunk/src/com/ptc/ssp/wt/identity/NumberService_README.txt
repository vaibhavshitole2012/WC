
Set following properties:
<!-- Task called at startup to PopulateNumberCache -->
	<Property name="wt.federation.task.startup" overridable="true" targetFile="codebase/wt.properties" value="com/ptc/ssp/wt/identity/PopulateNumberCache.xml"/>
<!-- Oracle Sequence which is to be supported by Number Cache -->
	<Property name="com.ptc.ssp.wt.identity.OracleSequenceName" overridable="true" targetFile="codebase/wt.properties" value="EPM_seq"/>
<!-- Number Prefix which is to be supported by Number Cache -->
	<Property name="com.ptc.ssp.wt.identity.CachedNumberPrefix" overridable="true" targetFile="codebase/wt.properties" value="P"/>
<!-- Count of digits to be supported by Number Cache, e.g. P1234567890 , P1234567890-0001 will be considered same as P1234567890 -->
	<Property name="com.ptc.ssp.wt.identity.MeaningfulDigits" overridable="true" targetFile="codebase/wt.properties" value="10"/>
<!-- Cache will be filled at startup and latest at Lopp start time -->
	<Property name="com.ptc.ssp.wt.identity.InitializeCacheLoopStartTime" overridable="true" targetFile="codebase/wt.properties" value="20:00:00"/>
<!-- Maximum time after Cache will be recalculated -->
	<Property name="com.ptc.ssp.wt.identity.InitializeCacheLoopSeconds" overridable="true" targetFile="codebase/wt.properties" value="86400"/>

Update OIR with Numbering Rule:

	<!-- set the number to a generated number using PTC SSP Number Cache-->
	<AttrValue id="number" algorithm="com.ptc.ssp.wt.rule.GenericRuleAlgorithm" ignore="false" force="false" final="false">
		<Arg>com/ptc/ssp/wt/rule/GenerateNumber.xml</Arg>
		<Arg>ANY:0:number</Arg>
	</AttrValue>
				
Details:
OIR calls
Class com.ptc.ssp.wt.rule.GenericRuleAlgorithm, which calls 
Task com/ptc/ssp/wt/rule/GenerateNumber.xml, which calls:
Class com.ptc.ssp.wt.identity.NumberService to
provide a number from cache or if no cache from sequence.

At startup, each MethodServer executes
Task com/ptc/ssp/wt/identity/PopulateNumberCache.xml, which calls
Class com.ptc.ssp.wt.identity.NumberCacheInitializer, which is a timer which calls
Class com.ptc.ssp.wt.identity.NumberService to
initialize the cache.
