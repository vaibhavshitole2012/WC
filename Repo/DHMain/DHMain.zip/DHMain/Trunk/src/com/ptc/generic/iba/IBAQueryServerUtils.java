package com.ptc.generic.iba;

import java.sql.Timestamp;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.map.MultiValueMap;

import com.ptc.core.meta.server.IBAModel;
import com.ptc.core.meta.common.FloatingPoint;
import com.ptc.generic.fc.ImprovedQuerySpec;
import com.ptc.generic.iba.IBAUtil;
import com.ptc.generic.query.QueryServerUtils;

import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.iba.definition.AbstractAttributeDefinition;
import wt.iba.definition.AttributeDefinition;
import wt.iba.definition.BooleanDefinition;
import wt.iba.definition.FloatDefinition;
import wt.iba.definition.IntegerDefinition;
import wt.iba.definition.StringDefinition;
import wt.iba.definition.TimestampDefinition;
import wt.iba.value.AbstractValue;
import wt.iba.value.BooleanValue;
import wt.iba.value.FloatValue;
import wt.iba.value.IBAHolder;
import wt.iba.value.IntegerValue;
import wt.iba.value.StringValue;
import wt.iba.value.TimestampValue;
import wt.pds.StatementSpec;
import wt.query.ConstantExpression;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTAttributeNameIfc;
import wt.util.WTException;
import wt.util.WTProperties;

public class IBAQueryServerUtils {
	
	
	public static enum OP {
	    EQUAL {
	        @Override
			public String toString() {
	            return SearchCondition.EQUAL;
	        }
	    },
	    NOT_EQUAL {
	        @Override
			public String toString() {
	            return SearchCondition.NOT_EQUAL;
	        }
	    },
	    LIKE {
	        @Override
			public String toString() {
	            return SearchCondition.LIKE;
	        }
	    },
	    NOT_LIKE {
	        @Override
			public String toString() {
	            return SearchCondition.NOT_LIKE;
	        }
	    },
	    NULL {
	    	@Override
			public String toString() {
	            return SearchCondition.IS_NULL;
	        }
	    },
	    NOT_NULL {
	        @Override
			public String toString() {
	            return SearchCondition.NOT_NULL;
	        }
	    },
	    GREATER_THAN_OR_EQUAL {
	        @Override
			public String toString() {
	            return SearchCondition.GREATER_THAN_OR_EQUAL;
	        }
	    },
	    LESS_THAN_OR_EQUAL {
	        @Override
			public String toString() {
	            return SearchCondition.LESS_THAN_OR_EQUAL;
	        }
	    },
	    GREATER_THAN {
	        @Override
			public String toString() {
	            return SearchCondition.GREATER_THAN;
	        }
	    },
	    LESS_THAN {
	        @Override
			public String toString() {
	            return SearchCondition.LESS_THAN;
	        }
	    },
	    IS_TRUE {
	    	@Override
			public String toString() {
	            return SearchCondition.IS_TRUE;
	        }
	    },
	    IS_FALSE {
	    	@Override
			public String toString() {
	            return SearchCondition.IS_FALSE;
	        }
	    };
	
	    /**
	     * Method description
	     *
	     *
	     * @return
	     */
	    @Override
		public abstract String toString();
	}

	/**
	 * Typed multi value map extended from<br>
	 * <code>org.apache.commons.collections.map.MultiValueMap</code><br>
	 * It's explicitely used for addIBACondition() method. 
	 * 
	 * @version Enter version here..., 14/01/13
	 * @author Alfred Weyerer
	 */
	public static class OPValueMap<O, V> extends MultiValueMap {

		/* (non-Javadoc)
		 * @see org.apache.commons.collections.map.MultiValueMap#put(java.lang.Object, java.lang.Object)
		 */
		@Override
		public Object put(Object key, Object value) {
			if(key instanceof OP){
				if(((OP)key).equals(OP.IS_FALSE)) {
					return super.put(key, new Boolean(false));
				}
				if(((OP)key).equals(OP.IS_TRUE)) {
					return super.put(key, new Boolean(true));
				}
			}
			return super.put(key, value);
		}
		
	}

	private static Map<Class<? extends AbstractAttributeDefinition>, Class<? extends AbstractValue>> ibaDefinitionValueClassMap = new HashMap<Class<? extends AbstractAttributeDefinition>, Class<? extends AbstractValue>>();
	private static final String QUERY_PREFIX = "IBA";
	private static char WILDCARD_ESCAPE;
	private static final String IBA_DEFINITIONID = StringValue.DEFINITION_REFERENCE + '.' + WTAttributeNameIfc.REF_OBJECT_ID;
    private static final String IDA2A2 = "thePersistInfo.theObjectIdentifier.id";
    private static final String IBA_HOLDERREF = "theIBAHolderReference.key.id";
	private static final String ATTR_VALUE = StringValue.VALUE;
    
	private static final char SEARCH_ANY_CHARS = '*'; 
	private static final char ORACLE_ANY_CHARS = '%'; 
	private static final char SEARCH_ANY_CHAR = '?';
	private static final char ORACLE_ANY_CHAR = '_';
	
	static {
        ibaDefinitionValueClassMap.put(StringDefinition.class, StringValue.class);
        ibaDefinitionValueClassMap.put(IntegerDefinition.class, IntegerValue.class);
        ibaDefinitionValueClassMap.put(FloatDefinition.class, FloatValue.class);
        ibaDefinitionValueClassMap.put(BooleanDefinition.class, BooleanValue.class);
        ibaDefinitionValueClassMap.put(TimestampDefinition.class, TimestampValue.class);

        try {
            WTProperties properties = WTProperties.getLocalProperties();

            WILDCARD_ESCAPE = properties.getProperty("wt.query.escapeWildCard", "/").charAt(0);
        } catch (Throwable t) {
            System.err.println(t.getLocalizedMessage());
        }
    }
	
	/**
	 * Use the IBA cache to get the ID of a IBA Definition
	 * 
	 * Works with all kind of IBAs
	 * 
	 * @param name the name of the IBA
	 * @return the id of the IBA
	 * @throws WTException
	 */
	//TODO ECA5.0: review this method, it was added by merging enhancing from ECA4.2-Bugfixing
	//             maybe the below methods (using IBAUtil.getXYDefinition(name)) are then obsolete?
	public static long getIdIBADefinition(String name) throws WTException {
		AbstractAttributeDefinition def = IBAModel.getIBADefinitionByHid(name);
		return def.getPersistInfo().getObjectIdentifier().getId();
	}


	public static Map<Long, String> initializeStringDefinitionMap(String[] ibaNames) throws WTException {
		Map<Long, String> mapStringDefinition = new HashMap<Long, String>();
		for (String ibaName : ibaNames) {
			long ibaDefinitionId = getIdIBADefinition(ibaName);
			mapStringDefinition.put(Long.valueOf(ibaDefinitionId), ibaName);
		}

		return mapStringDefinition;
	}
	
	/**
	 * Loop through the map and returns a list of StringDefinition-Ids
	 * 
	 * @param mapStringDefinitionIds a map key is the id of the StringDefinition, value is the name of the StringDefinition
	 * @return a list of StringDefinition Ids
	 */
	public static long[] getStringDefinitionIds(Map<Long, String> mapStringDefinitionIds) {
		long[] oids = new long[mapStringDefinitionIds.keySet().size()];

		int i = 0;
		for (Long oid : mapStringDefinitionIds.keySet()) {
			oids[i++] = oid.longValue();
		}

		return oids;
	}

	/**
	 * Execute an query which search for String IBA Holders with a specific
	 * value
	 * 
	 * @param ibaQueryParameters
	 *            defines the select attributes, the iba holder class and the
	 *            iba value
	 * @return a query result which contains a list of IBA Holders with a
	 *         specific value
	 * @throws WTException
	 */
	public static QueryResult executeQuerySpecIBAValues(IBAQueryParameters ibaQueryParameters) throws WTException {
		StatementSpec qs = IBAQueryServerUtils.getQSIBAValues(ibaQueryParameters);
		QueryResult qr = PersistenceHelper.manager.find(qs);
		return qr;
	}

	/**
	 * Returns a query which search for <br>
	 * - a specific IBA name (only StringIBAs are supported) <br>
	 * - a specific IBA Holder classname <br>
	 * - and IBAHolder id
	 * 
	 * @param ibaHolderQueryParameters
	 *            the query spec
	 * @return
	 * @throws WTException
	 */
	public static ImprovedQuerySpec getQSIBAValues(IBAQueryParameters ibaHolderQueryParameters) throws WTException {

		// SELECT idA3A4 FROM wt.iba.value.StringValue A0
		// => Select the value from StringValue
		// WHERE (A0.idA3A6 = 22725)
		// => where Id-String-Definition = Id-partIterationRef
		// AND (A0.classnamekeyA4 = 'wt.part.WTPartUsageLink')
		// => and Classname-IBA-Holder = wt.part.WTPartUsageLink
		// AND (A0.ida3a6 IN ('36868','35622'))
		// => and Id-IBAHolder

		ImprovedQuerySpec qs = new ImprovedQuerySpec();
		qs.setAdvancedQueryEnabled(true);
		QueryServerUtils.setAliasPrefix(qs, QUERY_PREFIX);
		int idxStringValue = qs.appendClassList(StringValue.class, false);

		// define the attributes to select
		QueryServerUtils.appendSelectAttributes(qs, ibaHolderQueryParameters, idxStringValue);

		// the StringDefinition id
		QueryServerUtils.appendSCIBADefinitionIdIn(qs, ibaHolderQueryParameters, idxStringValue);

		// the classname of the IBA Holder
		qs.appendAnd();
		QueryServerUtils.appendSCIBAHolderClassName(qs, ibaHolderQueryParameters, idxStringValue);

		// an array of IBA Holder ids
		qs.appendAnd();
		QueryServerUtils.appendSCIBAHolderIdIn(qs, ibaHolderQueryParameters, idxStringValue);

		return qs;
	}
	
	public static ImprovedQuerySpec getQSIBAValuesBoolean(IBAQueryParameters ibaHolderQueryParameters) throws WTException {

		// SELECT idA3A4 FROM wt.iba.value.StringValue A0
		// => Select the value from StringValue
		// WHERE (A0.idA3A6 = 22725)
		// => where Id-String-Definition = Id-partIterationRef
		// AND (A0.classnamekeyA4 = 'wt.part.WTPartUsageLink')
		// => and Classname-IBA-Holder = wt.part.WTPartUsageLink
		// AND (A0.ida3a6 IN ('36868','35622'))
		// => and Id-IBAHolder

		ImprovedQuerySpec qs = new ImprovedQuerySpec();
		qs.setAdvancedQueryEnabled(true);
		QueryServerUtils.setAliasPrefix(qs, QUERY_PREFIX);
		int idxBooleanValue = qs.appendClassList(BooleanValue.class, false);

		// define the attributes to select
		QueryServerUtils.appendSelectAttributes(qs, ibaHolderQueryParameters, idxBooleanValue);

		// the StringDefinition id
		QueryServerUtils.appendSCIBADefinitionIdIn(qs, ibaHolderQueryParameters, idxBooleanValue);

		// the classname of the IBA Holder
		qs.appendAnd();
		QueryServerUtils.appendSCIBAHolderClassNameBoolean(qs, ibaHolderQueryParameters, idxBooleanValue);

		// an array of IBA Holder ids
		qs.appendAnd();
		QueryServerUtils.appendSCIBAHolderIdIn(qs, ibaHolderQueryParameters, idxBooleanValue);

		return qs;
	}

	/**
	 * Returns a query which search for <br>
	 * - a specific IBA name (only StringIBAs are supported) <br>
	 * - a specific IBA Holder classname <br>
	 * - and a specific value for an IBA (UPPERCASE)
	 * 
	 * @param ibaHolderQueryParameters
	 *            the query spec
	 * @return
	 * @throws WTException
	 */
	public static ImprovedQuerySpec getQSIBAHoldersForIBAValue(IBAQueryParameters ibaHolderQueryParameters)
			throws WTException {

		// SELECT idA3A4 FROM wt.iba.value.StringValue A0
		// => Select ID-IBA-Holder from StringValue
		// WHERE (A0.idA3A6 = 22725)
		// => where Id-String-Definition = Id-partIterationRef
		// AND (A0.classnamekeyA4 = 'wt.part.WTPartUsageLink')
		// => and Classname-IBA-Holder = wt.part.WTPartUsageLink
		// AND (A0.value IN ('WT.PART.WTPART:36868','WT.PART.WTPART:35622'))
		// => and value in list of part iterations

		ImprovedQuerySpec qs = new ImprovedQuerySpec();
		qs.setAdvancedQueryEnabled(true);
		QueryServerUtils.setAliasPrefix(qs, QUERY_PREFIX);
		int idxStringValue = qs.appendClassList(StringValue.class, false);

		// define the attributes to select
		QueryServerUtils.appendSelectAttributes(qs, ibaHolderQueryParameters, idxStringValue);

		// the StringDefinition id
		QueryServerUtils.appendSCIBADefinitionIdIn(qs, ibaHolderQueryParameters, idxStringValue);

		// the classname of the IBA Holder
		qs.appendAnd();
		QueryServerUtils.appendSCIBAHolderClassName(qs, ibaHolderQueryParameters, idxStringValue);

		// an array of possible IBA values in uppercases
		qs.appendAnd();
		QueryServerUtils.appendSCIBAValueIn(qs, ibaHolderQueryParameters, idxStringValue);

		return qs;
	}

	/**
	 * Returns a query which search for <br>
	 * - a specific IBA name (only StringIBAs are supported) <br>
	 * - a specific IBA Holder classname <br>
	 * - a list of IBA Holder Ids <br>
	 * - and a specific value for an IBA (UPPERCASE)
	 * 
	 * @param ibaHolderQueryParameters
	 *            the query spec
	 * @return a query spec
	 * @throws WTException
	 */
	public static ImprovedQuerySpec getQSIbaValuesForIBAHoldersWithValuesIn(IBAQueryParameters ibaHolderQueryParameters)
			throws WTException {

		// SELECT idA3A4 FROM wt.iba.value.StringValue A0
		// => Select ID-IBA-Holder from StringValue
		// WHERE (A0.idA3A6 = 22725)
		// => where Id-String-Definition = Id-partIterationRef
		// AND (A0.classnamekeyA4 = 'wt.part.WTPartUsageLink')
		// => and Classname-IBA-Holder = wt.part.WTPartUsageLink
		// AND (A0.ida3a6 IN ('36868','35622'))
		// => and Id-IBAHolder
		// AND (A0.value IN ('WT.PART.WTPART:36868','WT.PART.WTPART:35622'))
		// => and value in list of part iterations

		ImprovedQuerySpec qs = getQSIBAValues(ibaHolderQueryParameters);

		// an array of possible IBA values in uppercases
		qs.appendAnd();
		QueryServerUtils.appendSCIBAValueIn(qs, ibaHolderQueryParameters, qs.getClassIndex(StringValue.class.getName()));

		return qs;
	}
	
	/**
	 * Returns a query which search for <br>
	 * - a specific IBA name (only StringIBAs are supported) <br>
	 * - a specific IBA Holder classname <br>
	 * - a list of IBA Holder Ids <br>
	 * - and a list of value for an IBA (UPPERCASE) with which the String Value
	 * 
	 * @param ibaHolderQueryParameters
	 *            the query spec
	 * @return a query spec
	 * @throws WTException
	 */
	public static ImprovedQuerySpec getQSIbaValuesForIBAHoldersWithValuesLike(IBAQueryParameters ibaHolderQueryParameters)
			throws WTException {

		// SELECT idA3A4 FROM wt.iba.value.StringValue A0
		// => Select ID-IBA-Holder from StringValue
		// WHERE (A0.idA3A6 = 22725)
		// => where Id-String-Definition = Id-partIterationRef
		// AND (A0.classnamekeyA4 = 'wt.part.WTPartUsageLink')
		// => and Classname-IBA-Holder = wt.part.WTPartUsageLink
		// AND (A0.ida3a6 IN ('36868','35622'))
		// => and Id-IBAHolder
		// AND (A0.value like 'X%')
		// => and value in list of part iterations

		ImprovedQuerySpec qs = getQSIBAValues(ibaHolderQueryParameters);

		// an array of possible IBA values in uppercases
		qs.appendAnd();
		QueryServerUtils.appendSCIBAValueLike(qs, ibaHolderQueryParameters, qs.getClassIndex(StringValue.class.getName()));

		return qs;
	}
	
	/**
	 * Appends a search condition based on given IBA attribute name and value(s).
     * 
	 * @param qs source and target QuerySpec
	 * @param ibaHierachicalId IBA attribute hierarchical name
	 * @param values OPValueMap is a MutiKeyMap including the operator and value pairs: <code>[operator (OP enum), value(s) (as simple object type)]</code>
     * @param clazz IBAHolder class 
	 *
	 * @return
	 *
	 * @throws WTException
	 */
	public static QuerySpec addIBACondition(QuerySpec qs, String ibaName, OPValueMap<OP, Object> values, Class<? extends IBAHolder> clazz) throws WTException {
        if (values.isEmpty()) {
            return qs;
        }
        
        AttributeDefinition iba = IBAUtil.getDefinition(ibaName);
        
        if (iba == null) {
            return qs;
        }

        Class<? extends AbstractValue> valueCl;
		try {
			valueCl = IBAUtil.getIBAValueClass(iba);
		} catch (Exception e) { throw new WTException(e);}

        int valueInd = qs.appendClassList(valueCl, false);
        int ind[] = new int[]{valueInd};

        if (qs.getWhereClause().getAllSearchConditions() != null) {
            qs.appendAnd();
        }

        qs.appendWhere(new SearchCondition(valueCl, IBA_DEFINITIONID, SearchCondition.EQUAL, PersistenceHelper.getObjectIdentifier(iba).getId()), ind);
        qs.appendAnd();
        qs.appendWhere(new SearchCondition(valueCl, IBA_HOLDERREF, clazz, IDA2A2), new int[]{valueInd, 0});
                
        if (!values.values().isEmpty()) {
            qs.appendAnd();
            qs.appendOpenParen();
        }
        
        // get all the set of operations
        @SuppressWarnings("unchecked") Set<OP> keys = values.keySet();

        for (Iterator<OP> opIterator = keys.iterator(); opIterator.hasNext();) {
            OP op = opIterator.next();
            Collection<?> valueS = (Collection<?>) values.get(op);

            for (Iterator<?> valIterator = valueS.iterator(); valIterator.hasNext();) {
                Object value = valIterator.next();
                SearchCondition sc;

                if ((value instanceof String) && (valueCl == StringValue.class)) {
                    sc = getWildcardEscapedCondition(new SearchCondition(valueCl, ATTR_VALUE, op.toString(), ((String) value).toUpperCase()), (String) value);
                } else if ((value instanceof Long) && (valueCl == IntegerValue.class)) {
                    sc = new SearchCondition(valueCl, ATTR_VALUE, op.toString(), (Long) value);
                } else if ((value instanceof Integer) && (valueCl == IntegerValue.class)) {
                    sc = new SearchCondition(valueCl, ATTR_VALUE, op.toString(), ((Integer) value).longValue());
                } else if ((value instanceof Double) && (valueCl == FloatValue.class)) {
                    sc = new SearchCondition(valueCl, ATTR_VALUE, op.toString(), (Double) value);
                } else if ((value instanceof Float) && (valueCl == FloatValue.class)) {
                    sc = new SearchCondition(valueCl, ATTR_VALUE, op.toString(), ((Float) value).doubleValue());
                } else if ((value instanceof FloatingPoint) && (valueCl == FloatValue.class)) {
                    sc = new SearchCondition(valueCl, ATTR_VALUE, op.toString(), ((FloatingPoint) value).getValue());
                } else if ((value instanceof Boolean) && (valueCl == BooleanValue.class)) {
                	if(op.equals(OP.IS_FALSE) || op.equals(OP.IS_TRUE)) {
						sc = new SearchCondition(valueCl, ATTR_VALUE, op.toString());
					} else {
						sc = new SearchCondition(valueCl, ATTR_VALUE, ((Boolean) value).booleanValue()
	                            ? SearchCondition.IS_TRUE
	                            : SearchCondition.IS_FALSE);
					}
                } else if ((value instanceof Timestamp) && (valueCl == TimestampValue.class)) {
                    sc = new SearchCondition(valueCl, ATTR_VALUE, op.toString(), (Timestamp) value);
                } else {
                    //Skip
                    continue;
                }

                qs.appendWhere(sc, ind);

                if (opIterator.hasNext() || valIterator.hasNext()) {
                    qs.appendOr();
                } else {
                    qs.appendCloseParen();
                }
            }
        }
        
        return qs;
	}
	
	private static SearchCondition getWildcardEscapedCondition(SearchCondition sc, String value) throws WTException {
		if (sc.getOperator().equals(SearchCondition.LIKE) || sc.getOperator().equals(SearchCondition.NOT_LIKE)) {
			String escapeValue = value;

			if ((value.indexOf(ORACLE_ANY_CHARS) > -1) || (value.indexOf(ORACLE_ANY_CHAR) > -1)) {
				escapeValue = "";

				for (int i = 0; i < value.length(); i++) {
					char curChar = value.charAt(i);

					if ((curChar == ORACLE_ANY_CHARS) || (curChar == ORACLE_ANY_CHAR)) {
						escapeValue += WILDCARD_ESCAPE;
					}

					escapeValue += curChar;
				}
			}

			escapeValue = escapeValue.replace(SEARCH_ANY_CHARS, ORACLE_ANY_CHARS);
			escapeValue = escapeValue.replace(SEARCH_ANY_CHAR, ORACLE_ANY_CHAR);

			if (!escapeValue.equals(value)) {
				String leftHandSide = sc.getLeftHandSide().toString();

				if (leftHandSide.toUpperCase().indexOf("UPPER(") > -1) {
					escapeValue = escapeValue.toUpperCase();
				} else if (leftHandSide.toUpperCase().indexOf("LOWER(") > -1) {
					escapeValue = escapeValue.toLowerCase();
				}

				sc = new SearchCondition(sc.getLeftHandSide(), sc.getOperator(), new ConstantExpression((Object) escapeValue));

				if (escapeValue.length() > value.length()) {
					try {
						sc.setOption("ESCAPE ('" + WILDCARD_ESCAPE + "')");
					} catch (Exception e) {
						System.err.println(e.getLocalizedMessage());
					}
				}
			}
		}

		return sc;
	}

}
