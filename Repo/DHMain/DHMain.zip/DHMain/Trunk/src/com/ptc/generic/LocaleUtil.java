/*
 * LocaleUtil.java
 *
 * Created on 28. Juli 2003, 13:26
 */

package com.ptc.generic;

import wt.util.WTContext;
import java.util.Locale;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Category;
/**
 *
 * @author  avs
 */
public class LocaleUtil
{
    private static final String CLASSNAME = LocaleUtil.class.getName();
    private static final Category logCategory = Category.getInstance( CLASSNAME );
    
    
    public static final Locale getLocale( HttpServletRequest request )
    {
        Locale locale = null;
        
        try
        {
            locale = request.getLocale();
        }
        catch( Exception e )
        {
            locale = null;
            logCategory.info( "could not get locale from request " + request, e );
        }
        
        locale = LocaleUtil.getLocale( locale );
        
        return( locale );
    }
    
    public static final Locale getDefaultLocale()
    {
        return( Locale.GERMAN );
    }
    
    public static final Locale getLocaleFromContext()
    {
        Locale locale = null;
        
        try
        {
            locale = WTContext.getContext().getLocale();
        }
        catch( Exception e )
        {
            locale = null;
            logCategory.info( "could not get locale from context ", e );
        }
        
        locale = LocaleUtil.getLocale( locale );

        return( locale );
    }

    public static final Locale getLocale( Locale locale )
    {
        if( locale == null )
        {
            return( LocaleUtil.getDefaultLocale() );
        }
        else
        {
            return( locale );
        }
    }
}
