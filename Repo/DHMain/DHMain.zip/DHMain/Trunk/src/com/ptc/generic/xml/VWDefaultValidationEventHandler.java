package com.ptc.generic.xml; 


import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.ValidationEvent;
import javax.xml.bind.ValidationEventHandler;

import org.apache.log4j.Logger;


public class VWDefaultValidationEventHandler implements ValidationEventHandler { 

	private static final Logger logger = Logger.getLogger(VWDefaultValidationEventHandler.class.getName());
	
	//list that holds the ValidationEvents that this handler caught
	private List<ValidationEvent> caughtEvents;
	
	//private constructor to enforce usage of newDefaultValidationEventHandler()
	private VWDefaultValidationEventHandler() {
		caughtEvents = new ArrayList<ValidationEvent>();
	}

	public static VWDefaultValidationEventHandler newVWDefaultValidationEventHandler() {
		VWDefaultValidationEventHandler eh = new VWDefaultValidationEventHandler();
		return eh;
	}

	/**
	 * implementation of javax.xml.bind.ValidationEventHandler
	 * logs the event and adds it to list of caught events
	 */
	public boolean handleEvent(ValidationEvent event) {
		logger.debug("caught: " + this.toDebugString(event));
		
		//add event to list
		caughtEvents.add(event);

		return true; //in order for processing to continue even when ValidationEvent occured
	}
	
	/**
	 * @return a new ArrayList containing the caught ValidationEvents
	 */
	public List<ValidationEvent> getCaughtEvents() {
		return new ArrayList<ValidationEvent>(caughtEvents);
	}
	
	public String toDebugString(ValidationEvent event) {
		StringBuffer sb = new StringBuffer();
		sb.append("ValidationEvent["); 
		sb.append("severity=" + event.getSeverity()); 
		sb.append(" msg=" + event.getMessage()); 
		sb.append(" linkedEx=" + event.getLinkedException()); 
		sb.append(" loc.line=" + event.getLocator().getLineNumber()); 
		sb.append(" loc.col=" + event.getLocator().getColumnNumber()); 
		sb.append(" off=" + event.getLocator().getOffset()); 
		sb.append(" obj=" + event.getLocator().getObject()); 
		sb.append(" node=" + event.getLocator().getNode()); 
		sb.append(" url=" + event.getLocator().getURL()); 
		sb.append("]"); 
		return sb.toString();
	}

	/**
	 * @return
	 */
	public boolean hasCaughtEvents() {
		return !caughtEvents.isEmpty();
	}
}