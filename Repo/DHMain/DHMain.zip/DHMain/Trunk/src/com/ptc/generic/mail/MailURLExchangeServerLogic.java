/* bcwti
 *
 *  Copyright (c) 2012 Parametric Technology Corporation (PTC). All Rights
 *  Reserved.
 *
 *  This software is the confidential and proprietary information of PTC.
 *  You shall not disclose such confidential information and shall use it
 *  only in accordance with the terms of the license agreement.
 *
 *  ecwti
 */
package com.ptc.generic.mail;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.util.Enumeration;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.text.AttributeSet;
import javax.swing.text.MutableAttributeSet;
import javax.swing.text.html.HTML;
import javax.swing.text.html.HTML.Attribute;
import javax.swing.text.html.HTML.Tag;
import javax.swing.text.html.HTMLEditorKit;

import org.apache.log4j.Logger;

import wt.util.WTProperties;

import com.ptc.generic.GenericProperties;

/**
 * @author cherrmann
 */
public class MailURLExchangeServerLogic {
    public static final String svnRev = "$Revision: 1.1.1.3 $ $Date: 2015/12/10 21:01:36IST $";
    public static final String svnUrl = "$URL: http://127.0.0.1/svn/KB_04082016/components/Generic-Utilities/src/com/ptc/generic/mail/MailURLExchangeServerLogic.java $";

    private static final String CLASSNAME = MailURLExchangeServerLogic.class.toString();
    private static final Logger logger = Logger.getLogger(CLASSNAME);

    private static String HOST_URL;
    private static String HOST_URL_PRI;
    private static String HOST_URL_ALT;
    private static String PRIMARY_COMMENT;
    private static String SECONDARY_COMMENT;

    private static String REGEX = "\\(?\\b(https?://|www[.])[-A-Za-z0-9+&@#/%?=~_()|!:,.;]*[-A-Za-z0-9+&@#/%=~_()|]";
    private static Pattern urlPattern = Pattern.compile(REGEX);

    static {
        try {
            WTProperties wtProperties = WTProperties.getLocalProperties();
            HOST_URL = wtProperties.getProperty("wt.server.codebase", "");

            GenericProperties vwProperties = GenericProperties.getProperties("wt.properties");
            HOST_URL_PRI = vwProperties.getProperty("ext.custom.MailPrimaryServerCodebase", "");
            HOST_URL_ALT = vwProperties.getProperty("ext.custom.MailSecondaryServerCodebase", "");
            PRIMARY_COMMENT = vwProperties.getProperty("ext.custom.MailPrimaryComment", "");
            SECONDARY_COMMENT = vwProperties.getProperty("ext.custom.MailSecondaryComment", "");

        } catch (Throwable t) {
            logger.error("Error reading properties");
            throw new ExceptionInInitializerError(t);
        }
    }

    public static String parseContentAndAddURLForPFN(String text) throws IOException {
        if (text == null) return null;

        if (text.toLowerCase().contains("<a href=")) {
            return parseHTMLContentAndAddURLForPFN(text);
        } else {
            return parseTextContentAndAddURLForPFN(text);
        }
    }

    protected static String parseHTMLContentAndAddURLForPFN(String html) throws IOException {
        ParserGetter kit = new ParserGetter();
        HTMLEditorKit.Parser parser = kit.getParser();

        StringReader r = new StringReader(html);
        StringWriter w = new StringWriter();
        HTMLEditorKit.ParserCallback callback = new URLModifierParserCallback(HOST_URL, HOST_URL_PRI, HOST_URL_ALT, PRIMARY_COMMENT, SECONDARY_COMMENT, w);
        parser.parse(r, callback, true);
        return w.toString();
    }

    protected static String parseTextContentAndAddURLForPFN(String text) {
    	
        String hostURL = HOST_URL;
        String primaryURL = HOST_URL_PRI;
        String secondaryURL = HOST_URL_ALT;
        String primaryComment = PRIMARY_COMMENT;
        String secondaryComment = SECONDARY_COMMENT;

        boolean writeAdditionalURL = false;
    	
        if (secondaryURL != null && secondaryURL.length() > 0){
        	if (primaryURL == null || primaryURL.length() == 0) {
        		writeAdditionalURL = false;
        		primaryURL = secondaryURL;
        		primaryComment = secondaryComment;
        	} else {
        		writeAdditionalURL = true;
        	}
        }
    	
    	
        String textToManipulate = text;
        // find and manipulate plain text urls!
        Matcher matcher = urlPattern.matcher(textToManipulate);
        while (matcher.find()){
            String foundURL = matcher.group();
            String newURL = foundURL.replace(hostURL, primaryURL + " " + primaryComment);
            if (writeAdditionalURL){
            	newURL += " / " + foundURL.replace(hostURL, secondaryURL + " " + secondaryComment);
            }
            textToManipulate = textToManipulate.replace(foundURL, newURL);
        }

        return textToManipulate;
    }
}

class URLModifierParserCallback extends HTMLEditorKit.ParserCallback {

    private Writer out;
    private String HOST_URL = "";
    private String HOST_URL_PRI = "";
    private String HOST_URL_ALT = "";
    private String PRIMARY_COMMENT = "";
    private String SECONDARY_COMMENT = "";

    boolean isURLTag = false;
    boolean writeAdditionalURL = false;
    boolean isAdditionalURL = false;
    MutableAttributeSet curURLTagAttributes = null;
    String curURLTagText = null;

    public URLModifierParserCallback(String urlToReplace, String primaryURL, String secondaryURL, String primaryComment, String secondaryComment, Writer out) {
        this.HOST_URL = urlToReplace;
        this.HOST_URL_PRI = primaryURL;
        this.HOST_URL_ALT = secondaryURL;
        this.PRIMARY_COMMENT = primaryComment;
        this.SECONDARY_COMMENT = secondaryComment;
        this.out = out;
        
        if (secondaryURL != null && secondaryURL.length() > 0){
        	if (primaryURL == null || primaryURL.length() == 0) {
        		this.writeAdditionalURL = false;
        		this.HOST_URL_PRI = secondaryURL;
        		this.PRIMARY_COMMENT = secondaryComment;
        	} else {
        		this.writeAdditionalURL = true;
        	}
        }
    }

    public void handleStartTag(HTML.Tag tag, MutableAttributeSet attributes, int position) {
        if (tag == HTML.Tag.A) {
            String curHREF = attributes.getAttribute(Attribute.HREF).toString();
            boolean isMailTo = curHREF == null || (curHREF != null && curHREF.startsWith("mailto"));
            boolean isWNCURL = curHREF != null && curHREF.contains(HOST_URL);
            if (!isMailTo && isWNCURL) {
                isURLTag = true;
                curURLTagAttributes = (MutableAttributeSet) attributes.copyAttributes();
                
                curHREF = curURLTagAttributes.getAttribute(Attribute.HREF).toString();
                String newHREF = curHREF.replace(HOST_URL, HOST_URL_PRI);
                curURLTagAttributes.addAttribute(Attribute.HREF, newHREF);
                attributes = curURLTagAttributes;
            }
        }
        writeStartTag(tag, attributes);
    }

    private void writeStartTag(HTML.Tag tag, MutableAttributeSet attributes){
        try {
            out.write("<" + tag);
            this.writeAttributes(attributes);
            out.write(">");
            out.flush();
        } catch (IOException ex) {
            System.err.println(ex);
        }
    }

    private void writeAttributes(AttributeSet attributes) throws IOException {

        Enumeration<?> e = attributes.getAttributeNames();
        while (e.hasMoreElements()) {
            Object name = e.nextElement();
            String value = attributes.getAttribute(name).toString();
            out.write(" " + name + "=\"" + value + "\"");
        }
    }

    public void handleEndTag(HTML.Tag tag, int position) {
        writeEndTag(tag);

        if (tag == HTML.Tag.A && isURLTag && writeAdditionalURL) {
        	isAdditionalURL = true;
            // we need to append the tag here!

            if (curURLTagAttributes != null){
                String curHREF = curURLTagAttributes.getAttribute(Attribute.HREF).toString();
                String newHREF = curHREF.replace(HOST_URL_PRI, HOST_URL_ALT);
                curURLTagAttributes.addAttribute(Attribute.HREF, newHREF);
            }
            
            writeText(" / ");
            writeStartTag(tag, curURLTagAttributes);
            String subText = curURLTagText;
            if (SECONDARY_COMMENT != null && SECONDARY_COMMENT.length() > 0) {
            	subText += " " + SECONDARY_COMMENT;
            }
            handleTextInternal(subText, position);
            writeEndTag(tag);
            curURLTagText = null;
            isAdditionalURL = false;
        }
        
        isURLTag = false;
        curURLTagAttributes = null;
    }

    public void handleText(char[] text, int position) {
        handleTextInternal(new String(text), position);
    }

    private void handleTextInternal(String text, int position) {
        if (isURLTag && !isAdditionalURL){
        	curURLTagText = text;
        	if (PRIMARY_COMMENT != null && PRIMARY_COMMENT.length() > 0){
        		text += " " + PRIMARY_COMMENT;
        	}
        } else {
            text = MailURLExchangeServerLogic.parseTextContentAndAddURLForPFN(text);
        }

        writeText(text);
    }

    private void writeText(String text) {
        try {
            out.write(text);
            out.flush();
        } catch (IOException ex) {
            System.err.println(ex);
        }
    }

    private void writeEndTag(HTML.Tag tag) {
        try {
            out.write("</" + tag + ">");
            out.flush();
        } catch (IOException ex) {
            System.err.println(ex);
        }
    }

    public void flush() {
        try {
            out.flush();
        } catch (IOException e) {
            System.err.println(e);
        }
    }

    public void handleSimpleTag(Tag tag, MutableAttributeSet attributes, int pos) {
        writeStartTag(tag, attributes);
        writeEndTag(tag);
    }

    public void handleEndOfLineString(String eol) {
        try {
            out.write(eol);
            out.flush();
        } catch (IOException e) {
            System.err.println(e);
        }
    }

    public void handleComment(char[] data, int pos) {
        try {
            out.write("<!--");
            out.write(data);
            out.write("-->\n");
            out.flush();
        } catch (IOException e) {
            System.err.println(e);
        }
    }
}

class ParserGetter extends HTMLEditorKit {
    private static final long serialVersionUID = -4369550828259833586L;

    public HTMLEditorKit.Parser getParser() {
        return super.getParser();
    }
}

