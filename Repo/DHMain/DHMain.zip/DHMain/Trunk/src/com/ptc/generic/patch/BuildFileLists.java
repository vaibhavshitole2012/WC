/*
 * bcwti
 *
 * Copyright (c) 2013 PTC Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */
package com.ptc.generic.patch;

import java.io.*;
import java.util.StringTokenizer;

/**
 * @author Benjamin Mueller (bmueller@ptc.com)
 * @version 20130906
 * @see VW_ECA-17627
 * @since ECA 5.0 / RCL 2.0
 * 
 * TODO: make sure that all written files only contain files that exists
 */
public class BuildFileLists {

	public static final String svnRev = "$Revision: 1.1.1.3 $ $Date: 2015/12/10 21:01:36IST $";
	public static final String svnUrl = "$URL: http://127.0.0.1/svn/KB_04082016/components/Generic-Utilities/src/com/ptc/generic/patch/BuildFileLists.java $";

	private static FileWriter backupWriter;
	private static BufferedWriter backupBw;
	private static FileWriter copyWriter;
	private static BufferedWriter copyBw;
	private static FileWriter deleteWriter;
	private static BufferedWriter deleteBw;
	
	private static String destPathFolder;
	private static final String newLine = System.getProperty("line.separator");

	public static void main(final String[] args) throws IOException {

		if (args == null || args.length != 7) {
			// TODO print usage
		}
		
		destPathFolder = args[0];
		if (!destPathFolder.endsWith("\\") && !destPathFolder.endsWith("/")) {
			destPathFolder += "/";
		}
		final String svnStatusFile = args[1];
		final String backupFileName = args[2];
		final String deleteFileName = args[3];
		final String copyFileSet = args[4];
		final String teivonFileName = args[5];
		final String genericFileName = args[6];

		final FileReader fr = new FileReader(svnStatusFile);
		final BufferedReader br = new BufferedReader(fr);
		
		final FileReader frTeivon = new FileReader(teivonFileName);
		final BufferedReader brTeivon = new BufferedReader(frTeivon);
		
		final FileReader frGeneric = new FileReader(genericFileName);
		final BufferedReader brGeneric = new BufferedReader(frGeneric);

		backupWriter = new FileWriter(backupFileName, false);
		backupBw = new BufferedWriter(backupWriter);
		copyWriter = new FileWriter(copyFileSet, false);
		copyBw = new BufferedWriter(copyWriter);
		deleteWriter = new FileWriter(deleteFileName, false);
		deleteBw = new BufferedWriter(deleteWriter);
		
		processFile(br);
		processFile(brTeivon);
		processFile(brGeneric);

		br.close();
		fr.close();
		
		brTeivon.close();
		frTeivon.close();
		
		brGeneric.close();
		frGeneric.close();

		copyBw.close();
		copyWriter.close();

		backupBw.close();
		backupWriter.close();

		deleteBw.close();
		deleteWriter.close();
	}
	
	private static String adjustFilenameToTargetMaschine(String fullqualifiedFileName) {
				
		fullqualifiedFileName = fullqualifiedFileName.replace("\\", "/");
		fullqualifiedFileName = fullqualifiedFileName.substring(destPathFolder.length());
		fullqualifiedFileName = fullqualifiedFileName.replaceFirst("/src/", "/codebase/");
		if (fullqualifiedFileName.endsWith(".java")) {
			fullqualifiedFileName = fullqualifiedFileName.substring(0, fullqualifiedFileName.length() - 5) + ".class";
		}
		fullqualifiedFileName = fullqualifiedFileName.replace("//", "/");
		
		return fullqualifiedFileName;
	}
	
	private static void processFile(final BufferedReader br) throws IOException {
		String currentLine = null;
		StringTokenizer st = null;
		String currentToken = null;
        String previousToken = null;
		boolean isDelete = false;
		File fileTest = null;
		boolean isAdirectory = false;
		boolean isNewFile = false;
		String tmpString = null;
		while ((currentLine = br.readLine()) != null) {
			st = new StringTokenizer(currentLine);

			while (st.hasMoreTokens()) {
				if ("M".equals(previousToken) || "D".equals(previousToken) || "A".equals(previousToken)) {
                    currentToken = st.nextToken(newLine);
                    currentToken = currentToken.substring(7);
                } else {
                    currentToken = st.nextToken();
                }
                previousToken = currentToken;

				if (!isDelete && currentToken.equals("D")) {
					isDelete = true;
				} else if (currentToken.equals("A")) {
					isNewFile = true;
				} else {
					if (currentToken.trim().length() > 4) {
						fileTest = new File(currentToken);
						isAdirectory = fileTest.isDirectory();

						if (isDelete) {
							tmpString = adjustFilenameToTargetMaschine(currentToken);
							tmpString = tmpString.replace("/VW/ECA/components/Teivon-Core/trunk/", "");
							tmpString = tmpString.replace("/VW/ECA/components/Generic-Core/trunk/", "");

							deleteBw.write(tmpString);
							deleteBw.write(newLine);
							isDelete = false;
						} else {
							if (!isAdirectory) {
								try {
                                    tmpString = currentToken.substring(destPathFolder.length());
                                } catch (Exception ex) {
                                    continue;
                                }
								tmpString = tmpString.replace("/VW/ECA/components/Teivon-Core/trunk/", "");
								tmpString = tmpString.replace("/VW/ECA/components/Generic-Core/trunk/", "");

								copyBw.write(tmpString);
								copyBw.write(newLine);
							}
						}
						if (!isAdirectory && !isNewFile) {
							tmpString = adjustFilenameToTargetMaschine(currentToken);
							tmpString = tmpString.replace("/VW/ECA/components/Teivon-Core/trunk/", "");
							tmpString = tmpString.replace("/VW/ECA/components/Generic-Core/trunk/", "");

							backupBw.write(tmpString);
							backupBw.write(newLine);
						}
					}
					isNewFile = false;
				}
			}
		}
	}
}
