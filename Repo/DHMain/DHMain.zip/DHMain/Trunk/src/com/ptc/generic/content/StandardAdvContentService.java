package com.ptc.generic.content;

import java.beans.PropertyVetoException;
import java.io.*;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Vector;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpResponse;
import org.apache.log4j.Logger;
import org.apache.xmlrpc.webserver.HttpServletResponseImpl;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;

import com.ptc.service.annotations.GenerateService;
import com.ptc.windchill.enterprise.wvs.saveWVSObject.utils.SaveWVSObjectHelper;
import com.ptc.wvs.server.util.PublishUtils;
import com.ptc.generic.AuthHelper;
import com.ptc.generic.content.AdvContentService;
import com.ptc.generic.content.contentResource;

import wt.content.*;
import wt.epm.EPMDocument;
import wt.fc.LobLocator;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fv.*;
import wt.httpgw.HTTPServletResponse;
import wt.httpgw.URLFactory;
import wt.pom.Transaction;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.services.StandardManager;
import wt.session.SessionHelper;
import wt.session.SessionServerHelper;
import wt.util.*;

@GenerateService(generateHelper=false) 
public class StandardAdvContentService extends StandardManager implements AdvContentService {
    
	private static final long serialVersionUID = -2654628990473310567L;
	// --- Attribute Section ---
    private static final String RESOURCE = "com.ptc.generic.content.contentResource";
    private static final String CLASSNAME = StandardAdvContentService.class.getName();
    
    private static Logger logger = Logger.getLogger(CLASSNAME);
    
    
    // --- Operation Section ---
    
    /**
     * Standard-Factory f�r Klasse.
     *
     * @return    StandardAdvContentService
     * @exception wt.util.WTException
     **/
    public static StandardAdvContentService newStandardAdvContentService() throws WTException {
        StandardAdvContentService instance = new StandardAdvContentService();
        instance.initialize();
        return instance;
    }
    
    /**
     * @param     appdata
     * @param     filePath
     * @exception wt.util.WTException
     **/
    @Override
	public void writeContentStream( ApplicationData appdata, String filePath ) throws WTException {
        try {
            InputStream cntIn = findContentStream(appdata);
            FileOutputStream cntOut = new FileOutputStream(filePath);
            byte[] buf = new byte[2048];
            int num = cntIn.read(buf);
            while (num > -1) {
                cntOut.write(buf, 0, num);
                num = cntIn.read(buf);
            }
            cntOut.flush();
            cntOut.close();
        } catch (FileNotFoundException e) {
            throw new WTException(e);
        } catch (WTException e) {
            throw new WTException(e);
        } catch (IOException e) {
            throw new WTException(e);
        }
    }
    
    /**
     * @param     appdata
     * @return    InputStream
     * @exception wt.util.WTException
     **/
    @Override
	public InputStream findContentStream( ApplicationData appdata ) throws WTException {
        Streamed streamed = (Streamed)PersistenceHelper.manager.refresh(appdata.getStreamData().getObjectId());
        
        boolean flag = false;
        LobLocator loblocator = null;
        
        if(streamed instanceof StreamData) {
            flag = true;
            loblocator = ((StreamData)streamed).getLobLoc();
        }
        if(flag) {
            appdata = (ApplicationData)PersistenceHelper.manager.refresh(appdata);
            streamed = (Streamed)wt.fc.PersistenceHelper.manager.refresh(appdata.getStreamData().getObjectId());
            try {
                loblocator.setObjectIdentifier(((ObjectReference)streamed).getObjectId());
                ((StreamData)streamed).setLobLoc(loblocator);
            } catch (Exception exception) {
            }
        }
        return streamed.retrieveStream();
    }
    
    /**
     * Attaches a file to a e.g. document
     *
     * @param     cHolder
     * @param     file
     * @param     contentRoleType
     * @return    boolean
     * @exception wt.util.WTException
     **/
    @Override
	public boolean uploadContent( ContentHolder cHolder, File file, ContentRoleType contentRoleType ) throws WTException {
        boolean flag = false;
        validateContentRoleType(cHolder, contentRoleType);
        Transaction trans = new Transaction();
        trans.start();
        try {
            ApplicationData app = ApplicationData.newApplicationData(cHolder);
            String filePath = file.getAbsolutePath();
            app.setUploadedFromPath(filePath);
            app.setFileName(getFileNameFromPath(filePath));
            app.setRole(contentRoleType);
            ContentServerHelper.service.updateContent(cHolder, app, filePath);
            flag = true;
        } catch (WTPropertyVetoException wtpve) {
            trans.rollback();
            logger.warn(wtpve.getMessage(), wtpve);
            throw new WTException(wtpve);
        } catch (PropertyVetoException pve) {
            trans.rollback();
            logger.warn(pve.getMessage(), pve);
            throw new WTException(pve);
        } catch (java.io.IOException ioe) {
            trans.rollback();
            logger.warn(ioe.getMessage(), ioe);
            throw new WTException(ioe);
        }
        trans.commit();
        return flag;
    }
    
    /**
     * Attaches a xml document to a e.g. document
     *
     * @param     cHolder
     * @param     doc
     * @param     fileName
     * @param     contentRoleType
     * @return    boolean
     * @exception wt.util.WTException
     * @exception java.io.IOException
     **/
    @Override
	public boolean uploadXMLDocument( ContentHolder cHolder, org.jdom.Document doc, String fileName, ContentRoleType contentRoleType ) throws WTException, IOException {
        logger.debug("uploadXMLDocument() - start");
        boolean flag;
        
        // Check if fileName not null
        if (fileName == null || fileName.equals("")) {
            throw new WTException("Der �bergebene Dateiname ist leer.");
        }
        
        ByteArrayOutputStream byteOut = null;
        OutputStreamWriter writer = null;
        ByteArrayInputStream byteIn = null;
        try {
            // An OutputStreamWriter is a bridge from character streams to byte streams: Characters written
            // to it are translated into bytes according to the specified character encoding ISO-8859-1.
            // In this case the resulting bytes are written into a byte array with initial size 8192.
            // The data can be retrieved using toByteArray().
            byteOut = new ByteArrayOutputStream(8192);
            writer = new OutputStreamWriter(byteOut, "ISO-8859-1");
            
            // Write document to xml in nice format
            XMLOutputter out = new XMLOutputter();
            Format format = Format.getPrettyFormat();
            format.setEncoding("ISO-8859-1");
            out.setFormat(format);
            out.output(doc, writer);
            writer.close();
            
            byteIn = new ByteArrayInputStream(byteOut.toByteArray());
            flag = uploadContent(cHolder, fileName, byteIn, contentRoleType);
            
        } finally {
            if (writer != null) {
                writer.close();
            }
            if (byteIn != null) {
                byteIn.close();
            }
            if (byteOut != null) {
                byteOut.close();
            }
        }
        logger.debug("uploadXMLDocument() - end");
        return flag;
    }
    
    /**
     * Attaches a file to a e.g. document
     *
     * @param     cHolder
     * @param     fileName
     * @param     contentRoleType
     * @return    String
     * @exception wt.util.WTException
     **/
    @Override
	public String getVaultFolderPath( ContentHolder cHolder, String fileName, ContentRoleType contentRoleType ) throws WTException {
        String folderPath = null;
        try {
            logger.debug("getVaultFolderPath() - start");
            ApplicationData appData = null;
            if ((ContentRoleType.PRIMARY).equals(contentRoleType)) { // primary content
                FormatContentHolder formatContentHolder = (FormatContentHolder) wt.content.ContentHelper.service.getContents(cHolder);
                ContentItem contentItem = wt.content.ContentHelper.getPrimary(formatContentHolder);
                appData = ((ApplicationData) contentItem);
            } else if ((ContentRoleType.SECONDARY).equals(contentRoleType)) { // secondary secondary
                ContentHolder contentHolder = wt.content.ContentHelper.service.getContents(cHolder);
                Vector appDataV = wt.content.ContentHelper.getApplicationData(contentHolder);
                
                // At the moment only one applicationData object for the given
                // content holder is supported as this is sufficient for AVM.
                if (appDataV.size() > 1) {
					throw new WTException(
                            "Only one ApplicationData is supported for content holder '" + contentHolder + ", but got " + appDataV.size());
				}
                
                // filter appData here
                Enumeration appDataE = appDataV.elements();
                while (appDataE.hasMoreElements()) {
                    appData = (ApplicationData) appDataE.nextElement();
                    if (fileName != null && fileName.equals(appData.getFileName())) {
						break;
					}
                }
            } else {
				throw new WTException("Got unsupported contentRoleType " + contentRoleType);
			}
            
            
            Vector folderPathV = getFileLocation(appData, cHolder);
            logger.info("folderPathV = " + folderPathV);
            if (folderPathV == null || folderPathV.size() == 0) {
				throw new WTException("Could not find direct file location for " + contentRoleType + " content of '" + cHolder + "'");
			} else if (folderPathV.size() > 1) {
				throw new WTException("Direct file location must be unique but got " + folderPathV.size() + " possible values " + folderPathV);
			} else {
                for (int i = 0; i < folderPathV.size(); i++) {
                    folderPath = (String) folderPathV.elementAt(i);
                    
                    // filter folderPath here
                    
                }
            }
            logger.debug("getVaultFolderPath() - end");
        } catch (WTException e) {
            logger.warn(e.getMessage(), e);
            throw new WTException(e);
        } catch (PropertyVetoException e) {
            logger.warn(e.getMessage(), e);
            throw new WTException(e);
        }
        return folderPath;
    }
    
    @Override
	public Vector getFileLocation(ApplicationData applicationdata, ContentHolder contentholder) {
		logger.debug("Getting file location from application data " + applicationdata + " and " +
				" content holder " + contentholder);
    	Vector vector;
		if (applicationdata == null) {
			logger.warn("applicationdata is null");
			vector = new Vector();
		} else {
			vector = new Vector(5);
			ObjectReference objectreference = applicationdata.getStreamData();
			if (objectreference == null) {
				logger.warn("objectreference is null");
				return vector;
			}
			Streamed streamed = (Streamed) objectreference.getObject();
			if (streamed == null) {
				logger.warn("streamed is null");
				return vector;
			}
			if (streamed instanceof FvItem) {
				logger.debug("streamed is an FvItem");
				FvItem fvitem = (FvItem) streamed;
				Vector vector1 = new Vector();
				logger.debug("Setting access enforced to false");
				boolean flag = SessionServerHelper.manager.setAccessEnforced(false);
				FvFolder fvfolder = (FvFolder) fvitem.getFolder();
				if (fvfolder == null) {
					logger.warn("fvfolder is null");
					Vector vector2 = vector;
					return vector2;
				}
				FvVault fvvault = (FvVault) fvfolder.getVault();
				if (fvvault == null) {
					logger.warn("fvvault is null");
					Vector vector3 = vector;
					return vector3;
				}
				vector1 = getMountsToFolder(fvfolder);
				logger.debug("There are " + vector1.size() + " mounts to folder " + fvfolder);

				for (int j = 0; j < vector1.size(); j++) {
					FvMount fvmount = (FvMount) vector1.elementAt(j);
					logger.debug("fvmount: " + fvmount.getPath());
					FvHost fvhost = fvmount.getHost();
					try {
						if (RMIServer.isLocalHost(fvhost.getHostName())) {
							String s1 = "";
							// s1 = s1 + fvhost.getHostName();
							// s1 = s1 + "/";
							s1 = s1 + fvmount.getPath();
							// s1 = s1 + "/";
							s1 = s1 + File.separator;
							s1 = s1 + fvitem.getName();
							vector.addElement(s1);
						}
					} catch (UnknownHostException e) {
						logger.warn("Unknown host. It may be configured as a dummy for test systems.");
						logger.warn("Trying another host for next mount, if any. Stacktrace:");
						e.printStackTrace();						
					} catch (IOException e) {
						e.printStackTrace();
					} finally {
						flag = SessionServerHelper.manager.setAccessEnforced(flag);
					}
				}
			}
		}

		return vector;
	}

    @Override
	public boolean uploadContent(ContentHolder cHolder, String fileName, String contentCategory, InputStream inputstream, ContentRoleType contentRoleType) throws WTException {
        boolean flag = false;
        validateContentRoleType(cHolder, contentRoleType);
        Transaction trans = new Transaction();
        trans.start();
        try {
            ApplicationData app = ApplicationData.newApplicationData(cHolder);
            app.setFileName(fileName);
            app.setUploadedFromPath("");
            if (contentCategory != null) {
            	app.setCategory(contentCategory);
            }
            // app.setFileSize(file.length());
            app.setRole(contentRoleType);
            if ((ContentRoleType.PRIMARY).equals(contentRoleType)) {
                ContentServerHelper.service.updatePrimary((FormatContentHolder) cHolder, app, inputstream);
            } else {
                ContentServerHelper.service.updateContent(cHolder, app, inputstream);
            }
            flag = true;
        } catch (WTPropertyVetoException wtpve) {
            trans.rollback();
            logger.warn(wtpve.getMessage(), wtpve);
            throw new WTException(wtpve);
        } catch (PropertyVetoException pve) {
            trans.rollback();
            logger.warn(pve.getMessage(), pve);
            throw new WTException(pve);
        } catch (java.io.IOException ioe) {
            trans.rollback();
            logger.warn(ioe.getMessage(), ioe);
            throw new WTException(ioe);
        }
        trans.commit();
        return flag;
	}
    
	@Override
	public boolean uploadContent(ContentHolder cHolder, String fileName, InputStream inputstream, ContentRoleType contentRoleType) throws WTException {
		return uploadContent(cHolder, fileName, null, inputstream, contentRoleType);
	}
    
    /**
     * Validates the specified contentRoleType for the given content holder. Only the ContentRoleTypes
     * ContentRoleType.PRIMARY and ContentRoleType.SECONDARY are supported. Otherwise an exception is thrown.
     * If the contentRoleType is ContentRoleType.PRIMARY and primary contents already exists an
     * exception is thrown as well.
     *
     * @param cHolder the content holder
     * @param contentRoleType the content role type (e.g. PRIMARY, SECONDARY)
     * @throws WTException
     */
    private void validateContentRoleType(ContentHolder cHolder, ContentRoleType contentRoleType) throws WTException {
        // check contentRoleType
        if ((ContentRoleType.PRIMARY).equals(contentRoleType)) {
            if (checkIfPrimaryContentExists(cHolder)) {
                throw new WTException(WTMessage.getLocalizedMessage(RESOURCE, contentResource.ERROR_PRIMARY_CONTENT_ALREADY_EXISTS, null));
            }
        } else if ((ContentRoleType.SECONDARY).equals(contentRoleType)) {
            // perform any additional checks here
        } else {
            throw new WTException(WTMessage.getLocalizedMessage(RESOURCE, contentResource.ERROR_UNSUPPORTED_ROLE_TYPE, new Object[] {contentRoleType}));
        }
    }
    
    /**
     * Checks if primary content already exists for the specified content holder.
     *
     * @param cHolder the content holder
     * @return true if primary content already exist, false otherwise
     * @throws WTException
     */
    @Override
	public boolean checkIfPrimaryContentExists(ContentHolder cHolder) throws WTException {
        boolean hasPrimary = false;
        ContentItem item;
        try {
            cHolder = ContentHelper.service.getContents(cHolder);
        } catch (PropertyVetoException pve) {
            logger.error(pve.getLocalizedMessage(), pve);
        }
        Vector contents = ContentHelper.getContentListAll(cHolder);
        Enumeration contentE = contents.elements();
        while (contentE.hasMoreElements()) {
            item = (ContentItem) contentE.nextElement();
            if (item instanceof ApplicationData) {
                if (item.getRole().equals(ContentRoleType.PRIMARY)) {
					hasPrimary = true;
				}
                break;
            }
        }
        return hasPrimary;
    }
    
    private Vector getMountsToFolder(FileFolder filefolder) {
        Vector vector = new Vector();
        try {
            QuerySpec queryspec = new QuerySpec(wt.fv.FvMount.class);
            long id = PersistenceHelper.getObjectIdentifier(filefolder).getId();
            SearchCondition sc = new SearchCondition(wt.fv.FvMount.class, "roleAObjectRef.key.id", "=", id);
            queryspec.appendWhere(sc, 0);
            FvMount fvmount;
            for (QueryResult queryresult = PersistenceHelper.manager.find(queryspec);
            queryresult.hasMoreElements();
            vector.addElement(fvmount)) {
				fvmount = (FvMount) queryresult.nextElement();
			}
        } catch (Exception exception) {
        }
        return vector;
    }
    
    private String getFileNameFromPath(String filePath) throws WTException {
        File file = new File(filePath);
        return file.getName();
    }
    
	/**
	 * Method to delete the file with the given name from the target.
	 * 
	 * @param target
	 * @param fileName If null delete all attachments for the given ContentRoleType
	 * @param contentRoleType
	 * @since 5.0
	 * @throws WTException
	 */
	public void deleteContent(final EPMDocument target, final String fileName, final ContentRoleType contentRoleType) throws WTException {
		
		// check for existing content
		final QueryResult existingContent = ContentHelper.service.getContentsByRole((FormatContentHolder) target, contentRoleType, false);

		if (existingContent != null) {

			ApplicationData appData = null;
			while (existingContent.hasMoreElements()) {

				appData = (ApplicationData) existingContent.nextElement();
				if (fileName == null || appData.getFileName().equalsIgnoreCase(fileName)) {
					try {
						ContentServerHelper.service.deleteContent(target, (ContentItem) appData);
						logger.debug("deleting existing content " + appData.getFileName());
					} catch (final WTPropertyVetoException e) {
						logger.error(e.getLocalizedMessage(), e);
					} catch (final WTRuntimeException e) {
						logger.error(e.getLocalizedMessage(), e);
					}
				}
			}
		}
	}
	
	/**
	 * Returns the download URL for given secondary content of the given EPMDocument.
	 * 
	 * @param pbo
	 * @param filename
	 * @return URL or empty String
	 */
	public String getDownloadUrlForContent(final EPMDocument pbo, String filename, ContentRoleType contentRoleType) {

		String datasetURL = "";

		if (pbo != null && StringUtils.isNotBlank(filename)) {

			// check for existing content
			QueryResult existingContent = null;
			try {
				existingContent = ContentHelper.service.getContentsByRole((FormatContentHolder) pbo, contentRoleType, false);
			} catch (final WTException e) {
				logger.error(e.getLocalizedMessage(), e);
			}

			if (existingContent != null) {

				ApplicationData appData = null;
				while (existingContent.hasMoreElements()) {

					appData = (ApplicationData) existingContent.nextElement();
					if (appData.getFileName().equalsIgnoreCase(filename)) {
						try {
							final URL url = ContentHelper.service.getDownloadURL(pbo, appData);

							// return first match with given filename
							return url.toString();
						} catch (final WTException e) {
							logger.error(e.getLocalizedMessage(), e);
						}
					}
				}
			}
		}
		return datasetURL;
	}
	
	public String getSaveAsURL(String coid, String fileName, String fileType) throws WTException {
		logger.debug("entering saveAsURL with id=" + coid);
		URLFactory urlFactory = new URLFactory();
		
		Persistable p = PublishUtils.getObjectFromRef("wt.content.ApplicationData:" + coid);
		if(p instanceof ApplicationData){
			ApplicationData appData = (ApplicationData)p;
			QueryResult localQueryResult = PersistenceHelper.manager.navigate(appData, "theContentHolder", HolderToContent.class, false);
			if (localQueryResult.size() < 1) {
				logger.warn("persistable is NOT null, but the user does not have enough privileges. ID=" + appData.getIdentity());
				throw new WTException("Object exists with ID=" + coid + ", but you do not have enough privileges.");
			}
			if(fileName == null || fileName.equals(""))
				fileName = appData.getFileName();
			if((fileType == null || fileType.equals("")) && fileName != null)
				fileType = com.ptc.ddl.util.FileHelper.getExtension(fileName);
		}
		if (p == null){
			logger.warn("persistable is null. No object exists with this id:" + coid);
			throw new WTException("Object does not exist with ID=" + coid + ".");
		}
		HashMap<String, String> saveAsParams = new HashMap<String, String>();
		saveAsParams.put("oid", PublishUtils.getRefFromObject(p));
		saveAsParams.put("fileType", fileType);
		saveAsParams.put("annotations", "true");
		String url = urlFactory.getHREF(SaveWVSObjectHelper.getSaveWVSObjectGatewayURL() + "/" + fileName, saveAsParams, true);
		logger.debug("returning saveAsURL: " + url);
		return url;
	}
	
}
