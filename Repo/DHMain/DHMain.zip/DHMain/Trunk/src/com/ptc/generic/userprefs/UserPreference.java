/*
 *  bcwti
 *
 *  Copyright (c) 2010 Parametric Technology Corporation (PTC). All Rights
 *  Reserved.
 *
 *  This software is the confidential and proprietary information of PTC.
 *  You shall not disclose such confidential information and shall use it
 *  only in accordance with the terms of the license agreement.
 *
 *  ecwti
 */
package com.ptc.generic.userprefs;

import com.ptc.generic.userprefs.annotations.InstancePreloadedPreference;
import com.ptc.generic.userprefs.annotations.PreloadedPreference;
import com.ptc.generic.userprefs.annotations.VolatilePreference;

import wt.preference.PreferenceDefinition;

/**
 * Allowed preferences that can be used in UserPrefsManager and stored on Windchill
 * system.
 *
 * Each preference can be marked with one of annotations (will be used by UserPrefsManager):
 * <ul>
 *  <li>PreloadedPreference if preference should be cached on client on startup</li>
 *  <li>InstancePreloadedPreference if preference should be cached on client and reloaded on every applet startup</li>
 *  <li>VolatilePreference if preference should be retrieved from server on every call and never cached</li>
 * </ul>
 *
 * @see UserPrefsManager
 * @see PreloadedPreference
 * @see InstancePreloadedPreference
 * @see VolatilePreference
 *
 * @author Marek Piechut <mpiechut@ptc.com>
 */
public enum UserPreference implements PreferenceIfc {
//TODO ECA 4.0: Mark preferences with proper annotations: ones that are used on startup should be pre-loaded

    @PreloadedPreference
    AUTO_CHECKOUT_DOUBLE_CLICK("autoCheckoutDoubleClick", "true"),
    @PreloadedPreference
    AUTOCHECKOUT_CONFIRMATION("user.AUTO_CHECKOUT_CONFIRMATION", "true"),
    @PreloadedPreference
    BACKGROUNDCOLOUR_COLUMN_WAS_EDITED("backgroundColour.columnWasEdited.selected", "#FFE4B5"),
    @PreloadedPreference
    BACKGROUNDCOLOUR_EDITABLE_HIGHLIGHT_YELLOW("backgroundColour.editableColumn.highlightedYellow", "#FFFFA0"),
    @PreloadedPreference
    BACKGROUNDCOLOUR_EDITABLECOLUMN_NOTSELECTED("backgroundColour.editableColumn.notSelected", "#F0F8FF"),
    @PreloadedPreference
    BACKGROUNDCOLOUR_EDITABLECOLUMN_SELECTED("backgroundColour.editableColumn.selected", "#E6E6FB"),
    @PreloadedPreference
    BACKGROUNDCOLOUR_TREENODE_ROW_WAS_EDITED("backgroundColour.treeColumn.selected.rowWasEdited", "#FFE4B5"),
    @InstancePreloadedPreference
    BACKGROUNDHEADERCOLOUR_PART("backgroundColour.headerColumn.part", "#B3CCFF"),
    @InstancePreloadedPreference
    BACKGROUNDHEADERCOLOUR_PIC("backgroundColour.headerColumn.pic", "#C299AD"),
    DEFAULT_COLUMN_WIDTH("user.DEFAULT_COLUMN_WIDTH", "20"),
    @PreloadedPreference
    DEPTH("user.DEPTH", "max"),
    @PreloadedPreference
    DETACH_SN_CONFIRMATION("user.DETACH_SN", "true"),
    @PreloadedPreference
    DRAG_AND_DROP_ACTIVE("user.DRAG_AND_DROP_ACTIVE", "true"),
    @PreloadedPreference
    DROP_CONFIRMATION("user.DROP_TARGET_CONFIRMATION", "true"),
    EXPORT_USN("user.exportUSNtoAVM", "true"),
    @PreloadedPreference
    FONTCOLOUR_COLUMNWASEDITED_WRONGVALUE("fontColour.columnWasEdited.wrongValue", "#FF0000"),
    @PreloadedPreference
    MENGENCONTAINER_EXPANDED("user.MENGENCONTAINER_EXPANDED", "false"),
    PRINT_MENGENCONTAINER("user.PRINT_MENGENCONTAINER", ""),
    PRINT_ORIENTATION("user.PRINT_ORIENTATION", "landscape"), //since ECA5.0 we shouldn't store the localized value into the prefs
    PRINT_PAGESIZE("user.PRINT_PAGESIZE", "A4"), //since ECA5.0 we shouldn't store the localized value into the prefs
    @PreloadedPreference
    SUCCESS_MESSAGE_WINDOW("user.SUCCESS_MESSAGE_WINDOW", "false"),
    @PreloadedPreference
    VIEW("user.VIEW", "Konstruktion"),
    PRINT_TLNODE("user.PRINT_TLNODE", "false"),
    PRINT_PDF_FONTSIZE("user.PRINT_PDF_FONTSIZE", "10"),
    PRINT_IGNORE_SN("user.PRINT_IGNORE_SN", "true"),
    PRINT_MARKED_AREA("user.PRINT_MARKED_AREA", "false"),
    PRINT_NAME_DRUCKEN("user.PRINT_NAME_DRUCKEN", "true"),
    PRINT_PFEILUNG_DRUCKEN("user.PRINT_PFEILUNG_DRUCKEN", "false"),
    SHOW_WHATS_NEW("user.SHOW_WHATS_NEW_RELEASE", ""),
    CSV_EXPORT_HEADLINES("user.csvExportHeadlines", "true"),
    EXPORT_BAUKASTENS("user.exportBaukastens", "true"),
    ECA_EXPORT_USN_PFEILUNG("user.csvExportUSNPfeilung", "false"),
    @PreloadedPreference
    HIGHLIGHTCOLOR_MEHRFACHHEIT("highlightColour.mehrfachheit", "#B3AAFF"),
    @PreloadedPreference
    PRFILTER_SHOW_SN_MODE("user.PRFILTER_SHOW_SN_MODE", "1"),
    @PreloadedPreference
    BACKGROUNDCOLOUR_MARKED_COLUMN("backgroundColour.markedCell", "YELLOW=#FFFF91;RED=#C00000;ORANGE=#FFC000;GREEN=#91FF91;MAGENTA=#FF6AFF;BLUE=#0070C0;GRAY=#D5D9D8"),
    @PreloadedPreference
    BACKGROUNDCOLOUR_VERWENDUNG("highlightColour.verwendung", "#F2F2F2"),
    @InstancePreloadedPreference
    ACL_DISPLAY_ROLES("/ext/vw/ec/generic/acl/", "displayRoles", null),
    DISPLAY_HIDDEN_BAUSTUFEN("/com/vw/product/userPreferences", "user.DISPLAY_HIDDEN_BAUSTUFEN", "true"),
    RACFUSER("//", "RACFUser", "", UserPrefCategory.ECA, PreferenceDefinition.VISIBILITY_USER, UserPrefClient.WINDCHILL),
    @InstancePreloadedPreference
    ERROR_REPORTING_SMTP_SERVER("error.reporting.smtp.server", ""),
    @InstancePreloadedPreference
    ERROR_REPORTING_SMTP_USER("error.reporting.smtp.user", ""),
    @InstancePreloadedPreference
    ERROR_REPORTING_EMAIL("error.reporting.email", ""),
    @InstancePreloadedPreference
    ERROR_REPORTING_NAME("error.reporting.user", ""),
    @PreloadedPreference
    SHOW_PARTS_IN_TREE("user.PARTS_IN_TREE", "true"),
    @PreloadedPreference
    COLUMN_FILTER_CONNECTOR("column.filter.connector", "OR"),
    @InstancePreloadedPreference
    PRE_SELECT_KVS_CHECKBOX_IN_UBERGABE_WIZARD("uebergabe.kvs.checkbox.default.selected", "true"),
    @InstancePreloadedPreference
    PRE_SELECT_KVS_CHECKBOX_IN_CHANGE_WIZARD("change.kvs.checkbox.default.selected", "false"),
    @InstancePreloadedPreference
    PRE_SELECT_SIMPLE_REP_MASTER("user.PRE_SELECT_SIMPLE_REP_MASTER", "true"),
    @InstancePreloadedPreference
    SHOW_MESSAGE_FILTERED_STRUCTURE("user.SHOW_MESSAGE_FILTERED_STRUCTURE", "true"),
    /**
     * Filter for HTML UI baustufen table
     * It has to be volatile because caching it will do funny things in tomcat (single cache - many users)
     */
    @VolatilePreference
    BAUSTUFEN_TABLE_FILTER("", "baustufen.table.filter", null, UserPrefCategory.BAUSTUFEN_TABLE, PreferenceDefinition.VISIBILITY_USER),
    /**
     * HTML UI baustufen table preference switching display of hidden phases
     * It has to be volatile because caching it will do funny things in tomcat (single cache - many users)
     */
    @VolatilePreference
    BAUSTUFEN_TABLE_SHOW_HIDDEN("", "baustufen.table.show.hidden", null, UserPrefCategory.BAUSTUFEN_TABLE, PreferenceDefinition.VISIBILITY_USER),
    @VolatilePreference
    INDAGG_AUTOINDIVIDUALISE_ENABLED("","/com/vw/baustufe/indagg/delivery/autoindividualise/enable", "true"),
    /**
     * Filter for HTML UI baustufen table
     * It has to be volatile because caching it will do funny things in tomcat (single cache - many users)
     */
    @VolatilePreference
    INDAGG_TABLE_FILTER("", "indag.table.filter", null, UserPrefCategory.BAUSTUFEN_TABLE, PreferenceDefinition.VISIBILITY_USER),

    @PreloadedPreference
    ROLE_ANALYSIS_LIMIT("/com/vw/generic/access/userPreferences/", "role.analysis.default.limit", "5000", UserPrefCategory.ECA, PreferenceDefinition.VISIBILITY_ORG),
    
    @PreloadedPreference
    EXPAND_TBK("expandTBK", "true"),
    @InstancePreloadedPreference
    MAX_EXPANSION_STATES("/ext/vw/eclist/userPreferences/", "maxExpansionStates", "10", UserPrefCategory.ECA,
    PreferenceDefinition.VISIBILITY_USER, UserPrefClient.WINDCHILL),
    @PreloadedPreference
    USE_EXPANSION_STATES("useExpansionStates", "false"), 
    
    @InstancePreloadedPreference
    EC_LIST_LOG_LEVELS("/ext/vw/eclist/userPreferences/", "eclistlogginglevels", "", UserPrefCategory.ECA,
    PreferenceDefinition.VISIBILITY_USER, UserPrefClient.WINDCHILL),
    
    @PreloadedPreference
    MEASUREMENT_SYSTEM("/wt/units/display/", "displayUnitsSystem", "MKS_EUR", null, PreferenceDefinition.VISIBILITY_USER, UserPrefClient.WINDCHILL),
    LOCAL_PROC_SITE_PREF("", "localProcurementSite", "", null, PreferenceDefinition.VISIBILITY_USER, UserPrefClient.WINDCHILL);
    
    
    /**
     * This prefix will be added to preference name in enum constructor.
     * (compatibility with migrated 8.0 preferences)
     */
    public static final String ECA_PREFIX = "/ext/vw/eclist/userPreferences/";
    private final String name;
    private final String defaultValue;
    private final UserPrefCategory category;
    private final int visibility;
    private final UserPrefClient client;

    /**
     * Creates new ECA user preference. Appends ECA prefix to all preferences
     * and sets ECA category
     * (path from old 8.0 preferences)
     * @param name name of preference (ECA_PREFIX prefix will be added)
     * @param defaultValue default value (will be set on preference definition)
     * @see UserPreference#ECA_PREFIX
     */
    private UserPreference(String name, String defaultValue) {
        this(ECA_PREFIX, name, defaultValue);
    }

    /**
     * Creates new ECA user preference. Adds passed prefix to all preferences (instead of ECA_PREFIX)
     * and sets ECA category
     * @param prefix prefix to add to name
     * @param name name of preference
     * @param defaultValue default value (will be set on preference definition)
     */
    private UserPreference(String prefix, String name, String defaultValue) {
        this(prefix, name, defaultValue, UserPrefCategory.ECA);
    }

    /**
     * Creates new ECA user preference. Adds passed prefix to all preferences (instead of ECA_PREFIX)
     * and sets passed category
     * @param prefix prefix to add to name
     * @param name name of preference
     * @param defaultValue default value (will be set on preference definition)
     * @param category category to save preference in
     */
    private UserPreference(String prefix, String name, String defaultValue, UserPrefCategory category) {
        this(prefix, name, defaultValue, category, PreferenceDefinition.VISIBILITY_USER);
    }

    /**
     * Creates new preference. Use when you need to set definition visibility to something else then user
     *
     * @param prefix prefix to add to name
     * @param name name of preference
     * @param defaultValue default value (will be set on preference definition)
     * @param category category to save preference in
     * @param visibility visibility of preference (in what context it's visible/can be overridden)
     * @see PreferenceDefinition#VISIBILITY_USER
     * @see PreferenceDefinition#VISIBILITY_CONTAINER
     * @see PreferenceDefinition#VISIBILITY_ORG
     * @see PreferenceDefinition#VISIBILITY_SITE
     */
    private UserPreference(String prefix, String name, String defaultValue, UserPrefCategory category, int visibility) {
        this(prefix, name, defaultValue, category, visibility, UserPrefClient.ECA);
    }

    private UserPreference(String prefix, String name, String defaultValue, UserPrefCategory category, int visibility, UserPrefClient client) {
        this.name = prefix + name;
        this.defaultValue = defaultValue;
        this.category = category;
        this.visibility = visibility;
        this.client = client;
    }

    /**
     * Get name of preference (full name with prefix)
     * @return
     */
    public String getName() {
        return name;
    }

    /**
     * Get default value that this preference should have
     * @return
     */
    public String getDefaultValue() {
        return defaultValue;
    }

    /**
     * Get category this preference should be saved at
     * @return
     */
    public UserPrefCategory getCategory() {
        return category;
    }

    /**
     * Preference definition visibility
     * @return
     */
    public int getVisibility() {
        return visibility;
    }

    public UserPrefClient getClient() {
        return client;
    }
}
