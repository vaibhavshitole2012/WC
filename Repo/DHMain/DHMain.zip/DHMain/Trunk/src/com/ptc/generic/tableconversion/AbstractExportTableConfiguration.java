/** 

Abstract super class for table configuration implementations.
Not all attributes must be supported in the derived subclasses.
But if the setter must be used generic they must be placed here.

@author Lothar Germund, PLUS-Systeme GmbH
@since 19.10.2010
*/
package com.ptc.generic.tableconversion;


/**
 * Abstract super class for table configuration implementations.
 * @author DVORGER
 */
public abstract class AbstractExportTableConfiguration implements com.ptc.generic.tableconversion.TableConfiguration {
    
    // constants for cellFilter, the constants can be or'ed (c1 | c2 | ...)
    // nothing must be 0!
    public final static int CELLFILTER_NOTHING         = 0;
    // filter as bit mask, use for future value next power of 2 value (32,64,128,...)
    public final static int CELLFILTER_TO_STRING       = 1;
    public final static int CELLFILTER_SPEC_ATTRIBUTES = 2; // includes CELLFILTER_HEADER_ROW and CELLFILTER_DEFAULT
    public final static int CELLFILTER_HTML_ENTITIES   = 4;
    public final static int CELLFILTER_HEADER_ROW      = 8;
    public final static int CELLFILTER_APOSTROPHE_FOR_NUMERIC_IN_STRING = 16; // CSV special
    public final static int CELLFILTER_DEFAULT         = 32; // uses DisplayHelper.isDefault() to check for "empty"
    
    // constants for simple layouts
    public final static String LAYOUT_NORMAL = "normal";
    public final static String LAYOUT_HEADER = "header";
    
    // constants for encodings
    public final static String ENCODING_WINDOWS_GER = "Cp1252";
    public final static String ENCODING_UTF8        = "UTF-8";
    
    // special String value which is no legal cell value but used to cascade filters
    public final static String UNKNOWN_DISPLAYVALUE = "+~#~#UNKNOWN#~#~-";

    private String sheetName  = "sheet1";
    private String layoutName = LAYOUT_NORMAL;
    private String encoding   = ENCODING_WINDOWS_GER;
    private boolean freezeFirstRow = false; // true = scrollbar don't scroll the header away, it's freezed

    private String queryName = null;
    private int cellFilter = CELLFILTER_NOTHING;
    private int rows = 0;
    private int columns = 0;
    private boolean runInMethodServer = false;
    
    // support for JSP response object
    private String responseContentType = "";
    private String fileExtensionName = "";

    
    /**
     * @param sheetName the sheetName to set
     */
    public void setSheetName(String sheetName) {
        this.sheetName = sheetName;
    }

    
    /**
     * @return the sheetName
     */
    public String getSheetName() {
        return sheetName;
    }

    
    /**
     * @param layoutName the layoutName to set
     */
    public void setLayoutName(String layoutName) {
        this.layoutName = layoutName;
    }

    
    /**
     * @return the layoutName
     */
    public String getLayoutName() {
        return layoutName;
    }

    
    /**
     * @param encoding the encoding to set
     */
    public void setEncoding(String encoding) {
        this.encoding = encoding;
    }

    
    /**
     * @return the encoding
     */
    public String getEncoding() {
        return encoding;
    }


    /**
     * @param freezeFirstRow the freezeFirstRow to set
     */
    public void setFreezeFirstRow(boolean freezeFirstRow) {
        this.freezeFirstRow = freezeFirstRow;
    }


    /**
     * @return the freezeFirstRow
     */
    public boolean isFreezeFirstRow() {
        return freezeFirstRow;
    }

    
    /**
     * @param queryName the queryName to set
     */
    public void setQueryName(String queryName) {
        this.queryName = queryName;
    }

    
    /**
     * @return the queryName
     */
    public String getQueryName() {
        return queryName;
    }

    
    /**
     * @param cellFilter the cellFilter to set, the renderer implementation may set additional filters (must have filters)
     */
    public void setCellFilter(int cellFilter) {
        this.cellFilter = cellFilter;
    }

    
    /**
     * @return the cellFilter
     */
    public int getCellFilter() {
        return cellFilter;
    }

    
    /**
     * @param rows the rows to set
     */
    public void setRows(int rows) {
        this.rows = rows;
    }

    
    /**
     * @return the rows
     */
    public int getRows() {
        return rows;
    }

    
    /**
     * @param columns the columns to set
     */
    public void setColumns(int columns) {
        this.columns = columns;
    }

    
    /**
     * @return the columns
     */
    public int getColumns() {
        return columns;
    }

    
    /**
     * @param runInMethodServer the runInMethodServer to set
     */
    public void setRunInMethodServer(boolean runInMethodServer) {
        this.runInMethodServer = runInMethodServer;
    }

    
    /**
     * @return the runInMethodServer
     */
    public boolean isRunInMethodServer() {
        return runInMethodServer;
    }


    /**
     * @param responseContentType the responseContentType to set
     */
    public void setResponseContentType(String responseContentType) {
        this.responseContentType = responseContentType;
    }


    /**
     * @return the responseContentType
     */
    public String getResponseContentType() {
        return responseContentType;
    }


    /**
     * @param fileExtensionName the fileExtensionName to set
     */
    public void setFileExtensionName(String fileExtensionName) {
        this.fileExtensionName = fileExtensionName;
    }


    /**
     * @return the fileExtensionName
     */
    public String getFileExtensionName() {
        return fileExtensionName;
    }

}
