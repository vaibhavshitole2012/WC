package com.ptc.generic.validators;

import java.text.MessageFormat;

import com.ptc.generic.validators.validatorsResource;

import wt.inf.container.WTContained;
import wt.inf.team.ContainerTeamHelper;
import wt.inf.team.ContainerTeamManaged;
import wt.org.WTGroup;
import wt.util.WTException;
import wt.util.WTMessage;

/**
 * GenericContainerTeamRoleNotEmptyValidator
 *
 * Validates a windchill container if a set of container team roles exist in the container team
 *
 * @author cherrmann
 *
 */
public class GenericContainerTeamRoleNotEmptyValidator<T extends WTContained> implements GenericValidator<T> {

	private ValidationResult validationResult;
	private String errorMessage;
	private static final String defaultErrorMessage = WTMessage.getLocalizedMessage(VALIDATION_RESOURCE, validatorsResource.INVALID_GROUP_IS_EMPTY, null);
	private static final String groupNotExistantErrorMessage = WTMessage.getLocalizedMessage(VALIDATION_RESOURCE, validatorsResource.INVALID_GROUP_NOT_EXISTANT, null);

	private String[] roleNames;

	/**
	 * GenericContainerTeamRoleNotEmptyValidator
	 *
	 * @param roleNames a list of group names which should not be empty
	 */
	public GenericContainerTeamRoleNotEmptyValidator(String... groupNames) {
		this(null, groupNames);
	}

	/**
	 * GenericContainerTeamRoleNotEmptyValidator
	 *
	 * @param errorMessage default error message
	 * @param roleNames a list of group names which should not be empty
	 */
	public GenericContainerTeamRoleNotEmptyValidator(String errorMessage, String[] roleNames){
		this.roleNames = roleNames;
		this.errorMessage = errorMessage;
	}

	/**
	 * Checks if <b>all</b> the given roles are not empty in the passed container.
	 *
	 * @param object an object of type WTContained
	 * @return true if all the given groups are not empty
	 * @see com.ptc.generic.validators.GenericValidator#validate(java.lang.Object)
	 */
	public boolean validate(WTContained object) {
		resetValidationResult();

		if (object != null){
			if (this.roleNames != null){
				WTContained wtcObject = (WTContained) object;
				for (int i = 0; i < roleNames.length; i++){
					try {
						WTGroup group = ContainerTeamHelper.service.findContainerTeamGroup((ContainerTeamManaged) wtcObject.getContainer(), ContainerTeamHelper.ROLE_GROUPS, roleNames[i]);
						if (group != null){
							if (!group.members().hasMoreElements()){
								if (errorMessage == null){
									this.validationResult = new ValidationResult(MessageFormat.format(defaultErrorMessage, roleNames[i]), false);
								} else {
									this.validationResult = new ValidationResult(errorMessage, false);
								}
								break;
							}
						} else {
							this.validationResult = new ValidationResult(MessageFormat.format(groupNotExistantErrorMessage, roleNames[i]), false);
							break;
						}
					} catch (WTException e) {
						this.validationResult = new ValidationResult(MessageFormat.format(EXCEPTION_THROWN, e.getLocalizedMessage()), false, null, e);
						e.printStackTrace();
					}
				}
			}
		} else {
			this.validationResult = new ValidationResult(INVALID_PARAMETER_WAS_NULL, false);
		}

		if (this.validationResult == null){
			this.validationResult = new ValidationResult(SUCCESS_MESSAGE, true);
		}

		return this.validationResult.getIsValid();
	}

	public ValidationResult getValidationResult() {
		return this.validationResult;
	}

	public void resetValidationResult(){
		this.validationResult = null;
	}

}
