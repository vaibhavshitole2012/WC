/* bcwti
 *
 * Copyright (c) 2008 Parametric Technology Corporation (PTC). All Rights
 * Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */
package com.ptc.generic.team;

import com.ptc.generic.FcHelper;
import com.ptc.service.annotations.GenerateService;
import com.ptc.service.annotations.InterfaceConstant;
import com.ptc.generic.team.TeamService;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.*;

import org.apache.log4j.Logger;

import wt.access.AccessControlHelper;
import wt.access.AccessPermission;
import wt.access.AclEntrySet;
import wt.enterprise.RevisionControlled;
import wt.fc.*;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerHelper;
import wt.lifecycle.LifeCycleHelper;
import wt.lifecycle.LifeCycleManaged;
import wt.method.MethodContext;
import wt.org.*;
import wt.part.WTPart;
import wt.project.Role;
import wt.query.*;
import wt.services.StandardManager;
import wt.session.SessionHelper;
import wt.team.*;
import wt.util.WTAttributeNameIfc;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.vc.Iterated;
import wt.vc.VersionControlHelper;

/**
 *
 * <p>
 * Use the <code>newStandardVWTeamService</code> static factory method(s),
 * not the <code>StandardTeamService</code> constructor, to construct
 * instances of this class.  Instances must be constructed using the static
 * factory(s), in order to ensure proper initialization of the instance.
 * <p>
 *
 *
 * @version   1.0
 **/
@GenerateService(generateHelper = false, interfaceConstants={
    @InterfaceConstant(type=String.class, name="ADD", value="\"addUserToRole\""),
    @InterfaceConstant(type=String.class, name="REMOVE", value="\"removeUserFromRole\"")
})
public class StandardTeamService extends StandardManager implements TeamService, Serializable {

   private static final String RESOURCE = "com.ptc.generic.team.teamResource";
   private static final String CLASSNAME = StandardTeamService.class.getName();

   
    private static Logger logger = Logger.getLogger(CLASSNAME);
    private static final int ID_CHUNK_SIZE = 1000;
    private static ReferenceFactory rf = new ReferenceFactory();

   /**
    * Default factory for the class.
    *
    * @return    StandardTeamService
    * @exception wt.util.WTException
    **/
   public static StandardTeamService newStandardVWTeamService()
            throws WTException {

       StandardTeamService instance = new StandardTeamService();
      instance.initialize();
      return instance;
   }
   
   /**
    * Reads the role key from user pref, convert it into a Role
    * Returns the result in a vector.
    *
    * @param     roleNames  String with role keys, separated through ,
    * @return    Vector
    * @exception wt.util.WTException
    **/
   public Vector getVectorOfRolesFromString( String roleNames )
            throws WTException {
        
        String delim = ",";
        Vector vectorOfRoles = new Vector();
        
        //Check parameter
        if(roleNames == null || roleNames.length() == 0) {
            throw new WTException("Given param 'inString' was null or empty");
        }
        if (logger.isDebugEnabled()) {
            logger.debug("roles: " + roleNames + " " + "delim: " + delim);
        }
        
        //Add roles to vector
        StringTokenizer tokenizer = new StringTokenizer(roleNames, delim);
        while(tokenizer.hasMoreTokens()) {
            String roleKey = tokenizer.nextToken();
            Role role      = Role.toRole(roleKey);
            vectorOfRoles.add(role);
            
            if (logger.isDebugEnabled()) {
                logger.debug("roleKey: " + roleKey);
            }
        }
        return vectorOfRoles;
      
   }

   /**
    * @param     role
    * @param     teamIds
    * @return    HashMap
    * @exception wt.util.WTException
    **/
   public HashMap getRoleUsers( Role role, long [] teamIds )
            throws WTException {
        
        logger.debug("starting getRolePrincipalMaps...");
        long t1 = System.currentTimeMillis();
        Vector rpmaps = new Vector();
        
        BigInteger idChunkSize = BigInteger.valueOf(ID_CHUNK_SIZE);
        BigInteger teamIdCount = BigInteger.valueOf(teamIds.length);
        
        BigInteger loopCount = teamIdCount.divide(idChunkSize);
        BigInteger rest = teamIdCount.mod(idChunkSize);
        //logger.debug("teamIdCount="+teamIdCount+" loopcount="+loopCount+"
        // rest="+rest);
        
        int loops = loopCount.intValue();
        for(int i = 0; i < loops; i++) {
            long[] teamIdChunk = new long[ID_CHUNK_SIZE];
            //logger.debug("start="+i*ID_CHUNK_SIZE);
            System.arraycopy(teamIds, i * ID_CHUNK_SIZE, teamIdChunk, 0, ID_CHUNK_SIZE);
            Vector chunk = getRolePricipalMapChunk(role, teamIdChunk);
            rpmaps.addAll(chunk);
        }
        
        if(rest.intValue() > 0) {
            long[] teamIdChunk = new long[rest.intValue()];
            //logger.debug("rest start="+loops*ID_CHUNK_SIZE+ "
            // teamIdChunkSize="+teamIdChunk.length);
            System.arraycopy(teamIds, loops * ID_CHUNK_SIZE, teamIdChunk, 0, teamIdChunk.length);
            Vector chunk = getRolePricipalMapChunk(role, teamIdChunk);
            rpmaps.addAll(chunk);
        }
        
        long t2 = System.currentTimeMillis();
        logger.debug("Time=" + Long.toString(t2 - t1));
        
        // put WTPrincipalReferences into hashmap
        // the key is the WTPrincipalReferences and the value is an array of Objects with size=2:
        // on position [0] of this array is the ECLTreeItem (filled with the WTUser) and
        // on position [1] of this array is the number of how often this WTUser was already found (for the KURSIV lines in GUI)
        HashMap principalMap = new HashMap();
        Object[] objArray = null;
        Integer count = null;
        for(int m = 0; m < rpmaps.size(); m++) {
            RolePrincipalMap roleprincipalmap = (RolePrincipalMap)rpmaps.get(m);
            WTPrincipalReference wtPrincipalRef = roleprincipalmap.getPrincipalParticipant();
            
            if(wtPrincipalRef != null) {
                WTPrincipal principal = (WTPrincipal)wtPrincipalRef.getObject();
                objArray = (Object[]) principalMap.get(wtPrincipalRef);
                count = null;
                if(objArray!=null && (count = (Integer)objArray[1])!=null) {
                    principalMap.put(wtPrincipalRef, new Object[] {principal, Integer.valueOf(count.intValue() + 1)});
                } else {
                    principalMap.put(wtPrincipalRef, new Object[] {principal, Integer.valueOf(1)});
                }
            } else {
                //skip this role, there's no WTPrincipal in it
                continue;
            }
        }
        return principalMap;
   }

   /**
    * Returns a vector of principals
    *
    * @param     searchUser
    * @param     userName
    * @param     userFullName
    * @param     searchGroup
    * @param     groupName
    * @param     container
    * @return    Vector
    * @exception wt.util.WTException
    **/
   public Vector searchUsersAndGroups( boolean searchUser, String userName, String userFullName, boolean searchGroup, String groupName, WTContainer container )
            throws WTException {
      
    String attributeName = null;
    String pattern = null;

   	if(logger.isDebugEnabled()) {
   		logger.debug("searchUser=" + searchUser);
   		logger.debug("userName=" + userName);
   		logger.debug("userFullName=" + userFullName);
   		logger.debug("searchGroup=" + searchGroup);
   		logger.debug("groupName=" + groupName);
   		logger.debug("container=" + container);
   	}
   	
        Vector searchResult = new Vector();
        
   	//decision from Carsten G�bel, 20070611: we should search on ALL users/groups, not only in the given container

   	if(searchUser) {
        if (!userName.equals("")) {
            attributeName = WTUser.NAME;
            pattern = userName;
        } else {
            attributeName = WTUser.FULL_NAME;
            pattern = userFullName;
        }
        DirectoryContextProvider contextProvider = WTContainerHelper.service.getExchangeContainer().getContextProvider();
	   	Enumeration eUsers = OrganizationServicesHelper.manager.findLikeUsers(attributeName, pattern, contextProvider);
	   	while(eUsers.hasMoreElements()) {
	   		WTPrincipal p = (WTPrincipal) eUsers.nextElement();
	   		logger.debug("found user: " + p);
	   		searchResult.add(p);
	   	}
   	}
   	
   	if(searchGroup) {
   		Enumeration<WTPrincipal> eGroups = null;

   		if(groupName == null || groupName.length()==0) {
            groupName = "*";
   		}
        DirectoryContextProvider contextProvider = WTContainerHelper.service.getExchangeContainer().getContextProvider();
   		eGroups = OrganizationServicesHelper.manager.findLikeGroups(groupName, contextProvider);

	   	while(eGroups.hasMoreElements()) {
	   		WTPrincipal p = eGroups.nextElement();
	   		if(p instanceof WTGroup && !(p instanceof WTOrganization)) {
		   		logger.debug("found group: " + p);
		   		searchResult.add(p);
	   		}
	   	}
   	}
   	
   	//old (search only in container, and there are still bugs in this):
   	/*
        
        ContainerTeam containerteam = ContainerTeamHelper.service.getContainerTeam((ContainerTeamManaged)container);
        HashMap hmTeamMembers = containerteam.getAllMembers();
               
        //search Users and groups
        Pattern userNamePattern = null;
        if (userName != null && !userName.equals("")) {
            userName = userName.replaceAll("\\*", ".*").replaceAll("\\?", ".");
            userNamePattern = userNamePattern.compile(userName, Pattern.CASE_INSENSITIVE);
        }
        Pattern userFullNamePattern = null;
        if (userFullName != null && !userFullName.equals("")) {
            userFullName = userFullName.replaceAll("\\*", ".*").replaceAll("\\?", ".");
            userFullNamePattern = userFullNamePattern.compile(userFullName, Pattern.CASE_INSENSITIVE);
        }
        Pattern groupNamePattern = null;
        if (groupName != null && !groupName.equals("")) {
            groupName = groupName.replaceAll("\\*", ".*").replaceAll("\\?", ".");
            groupNamePattern = groupNamePattern.compile(groupName, Pattern.CASE_INSENSITIVE);
        }
       
        //search user
        Iterator iterator = hmTeamMembers.keySet().iterator();
        while (iterator.hasNext()) {
            WTPrincipalReference principalRef = (WTPrincipalReference)iterator.next();
            WTPrincipal principal = (WTPrincipal)principalRef.getObject();
            
            if (searchUser && principal instanceof WTUser) {
                if ( ( userName == null || userName.equals("") || ( userNamePattern != null && userNamePattern.matcher(((WTUser)principal).getName()).matches() ))
                &&   ( userFullName == null || userFullName.equals("") || (userFullNamePattern != null && userFullNamePattern.matcher(((WTUser)principal).getFullName()).matches()))) {
                    searchResult.add(principal);
                }
            }
            if (searchUser && principal instanceof WTGroup) {
                //Todo: Search Criteria
                searchResult.addAll(getGroupMembers(principal));
                
            }
            if (searchGroup && principal instanceof WTGroup) {
                if ( groupName == null || groupName.equals("") || groupNamePattern.matcher( ((WTGroup)principal).getName()).matches())  {
                    searchResult.add(principal);
                }
            }
        }
        */
   	
        return searchResult;
   }
   
   /**
    * @param     vPersistableOids
    * @param     hmActions
    * @param     role
    * @exception wt.util.WTException
    **/
   public void changeTeamRoleMembers( Vector vPersistableOids, HashMap hmActions, Role role )
            throws WTException {
      
        //Convert oids to persistables
        Vector vPersistables = new Vector();
        for (int i = 0; i < vPersistableOids.size(); i++) {
            Persistable persistable = FcHelper.convertToPersistable((String) vPersistableOids.get(i));
            vPersistables.add(persistable);
        }
        
        HashMap hmWTPrincipals = new HashMap();
        String errorMessage = "";
        
        //For each object, perform the necessary updates
        WTPrincipal wtPrincipal       = null;
        TeamManaged teamManagedObject = null;
        Team team                     = null;
        boolean teamChanged           = false;
        ReferenceFactory rf           = new ReferenceFactory();        
        
        for(int i = 0, n = vPersistables.size(); i < n; i++) {
            teamChanged = false;
            
            if(vPersistables.elementAt(i) instanceof TeamManaged) {
                teamManagedObject = (TeamManaged) vPersistables.elementAt(i);
            } else {
                throw new WTException("tried to update a team on a NON-TeamManaged persistable");
            }
            
            team = wt.team.TeamHelper.service.getTeam(teamManagedObject);
            if(logger.isDebugEnabled()) {
                logger.debug("object=" + teamManagedObject + " team=" + team);
            }
            
            //now loop over the roleTableModel and make the appropriate changes
            Iterator<String> iteratorActions = hmActions.keySet().iterator();
            while (iteratorActions.hasNext()) {
                String keyOid = iteratorActions.next();
                String action = (String) hmActions.get(keyOid);
                
                //get WTPrincipal that is represented by the current line
                if(hmWTPrincipals.containsKey(keyOid)) {
                    wtPrincipal = (WTPrincipal) hmWTPrincipals.get(keyOid);
                } else {
                    wtPrincipal = (WTPrincipal) rf.getReference(keyOid).getObject();
                    hmWTPrincipals.put(keyOid, wtPrincipal);
                }
                if(logger.isDebugEnabled()) {
                    logger.debug("wtPrincipal=" + wtPrincipal.getName());
                }
                
				String teamManagedObjectInfo = null;
                
                if ( teamManagedObject instanceof WTPart ) {
                	teamManagedObjectInfo = ((WTPart) teamManagedObject).getName() + " [nummer: " + ((WTPart) teamManagedObject).getNumber() + "]";
                } else {
                	teamManagedObjectInfo = teamManagedObject.toString();
                }
                
                //Add user
                if(action.equals(ADD)) {
                    //entry is green
                    logger.debug("principal is green");
                    teamChanged = addPrincipalToRole(teamManagedObject, team, wtPrincipal, role, false);
                    if (!teamChanged) {
                        errorMessage += "Der Benutzer " + wtPrincipal.getName() + " konnte nicht zur Rolle " + role.getDisplay() + " des Objektes " + teamManagedObjectInfo + " hinzugef�gt werden.\n";
                    }
                    
                    //Remove user
                } else if(action.equals(REMOVE)) {
                    //entry is red
                    logger.debug("going to remove principal from role");
                    
                    teamChanged = removePrincipalFromRole(teamManagedObject, team, wtPrincipal, role, false);
                    
                    if (!teamChanged) {
                        errorMessage += "Der Benutzer " + wtPrincipal.getName() + " konnte nicht aus der Rolle " + role.getDisplay() + " des Objektes " + teamManagedObjectInfo + " entfernt werden.\n";
                    }
                } else {
                    //unsupported flag
                }
            }
            
            if(teamChanged) {
                //Update the Ad hoc ACL entries
                updateAcl((Persistable)teamManagedObject);
                MethodContext.getContext().remove(wt.team.StandardTeamService.TEAM);
                LifeCycleHelper.service.augmentRoles(team);
            }
        }
        
        if (errorMessage != null && !errorMessage.equals("")) {
            throw new WTException(errorMessage + "Die anderen Obekte konnte das System aktualisieren.");
        }
      
   }
   
   /**
    * @param     teamManaged
    * @param     team
    * @param     principal
    * @param     role
    * @param     updateACL
    * @return    boolean
    * @exception wt.util.WTException
    **/
   public boolean addPrincipalToRole( TeamManaged teamManaged, Team team, WTPrincipal principal, Role role, boolean updateACL )
            throws WTException {
        
        boolean teamChanged = false;
        //check if the principal is already in the role
        //this is a bit slower, than checking only if the KURSIV flag was set, but it's more secure
        QueryResult qr = wt.team.TeamHelper.service.findRolePrincipalMap(role, principal, team);
        if(! qr.hasMoreElements()) {
            //Team.addPrincipal(Role role, WTPrincipal wtprincipal)
            // -> TeamHelper.service.addRolePrincipalMap(role, wtprincipal, the team);
            logger.debug("going to add principal to role");
            wt.team.TeamHelper.service.addRolePrincipalMap(role, principal, team);
            teamChanged = true;
        } else {
            logger.debug("principal was already set in role");
        }
        
        if(updateACL) {
            //Update the Ad hoc ACL entries
            updateAcl((Persistable)teamManaged);
            MethodContext.getContext().remove(wt.team.StandardTeamService.TEAM);
            LifeCycleHelper.service.augmentRoles((LifeCycleManaged) teamManaged);
        }
        
        return teamChanged;
   }

   /**
    * @param     teamManaged
    * @param     team
    * @param     principal
    * @param     role
    * @param     updateACL
    * @return    boolean
    * @exception wt.util.WTException
    **/
   public boolean removePrincipalFromRole( TeamManaged teamManaged, Team team, WTPrincipal principal, Role role, boolean updateACL )
            throws WTException {
      
	   	wt.team.TeamHelper.service.deleteRolePrincipalMap(role, principal, team);
               /* LM: if a principal is deleted from "Responsible" delete principal from submitter, too
                this ignores the case that principal may be added to submitter by RoleRoleMapping AND
                manually */
        if (Role.toRole("RESPONSIBLE").equals(role)) {
            QueryResult qrrs = wt.team.TeamHelper.service.findRolePrincipalMap(Role.toRole("SUBMITTER"), principal, team);
            if (qrrs.hasMoreElements()) // if Principal is in submitter role
            {
                logger.debug("Found principal in role submitter to, going to delete it from principal");
                wt.team.TeamHelper.service.deleteRolePrincipalMap(Role.toRole("SUBMITTER"), principal, team);
            }
        }
        
        if(updateACL) {
            //Update the Ad hoc ACL entries
            updateAcl((Persistable)teamManaged);
            MethodContext.getContext().remove(wt.team.StandardTeamService.TEAM);
            LifeCycleHelper.service.augmentRoles((LifeCycleManaged) teamManaged);
        }
        
        return true;
   }
   
   /**
    * Migration der Teileteams
    *
    * @param     teamManaged
    * @exception wt.util.WTException
    **/
   public void copyAdHocAcls2OldIterations( TeamManaged teamManaged )
            throws WTException {
      
	   	RevisionControlled tmrc = (RevisionControlled)teamManaged;
		AclEntrySet acles = tmrc.getEntrySet();
		if(acles != null) {
			System.out.println("updating acls of old iterations of: "+tmrc+" with: "+acles.toString());
			QueryResult qr = VersionControlHelper.service.allIterationsFrom(tmrc);
			while(qr.hasMoreElements()) {
				RevisionControlled rc = (RevisionControlled)qr.nextElement();
				//System.out.println("rc: "+rc);
				// not sure if it retrieves only all iterations of given version as we only want to copy adhoccls to iterations of the same version
				//System.out.println("vi: "+rc.getVersionIdentifier().getValue()+"."+rc.getIterationIdentifier().getValue()+" - latest: "+rc.isLatestIteration());
				if(!rc.isLatestIteration() && rc.getVersionIdentifier().getValue().equals(tmrc.getVersionIdentifier().getValue())) {
					rc.setEntrySet(acles);
					PersistenceServerHelper.manager.update(rc,false);
					rc = (RevisionControlled)PersistenceHelper.manager.refresh(rc);
					AclEntrySet newacles = rc.getEntrySet();
					logger.debug("updated acl of: "+rc+" - "+newacles.toString());
				}
			}
		} else {
			logger.debug("cannot update acls of old iterations of: "+tmrc+" - acl is null");
		}
   }

   /**
    * @param     p
    * @param     t
    * @return    Persistable
    * @exception wt.util.WTException
    **/
   public Persistable setModifyStamp( Persistable p, Timestamp t )
            throws WTException {
      
       if(p != null) {
           PersistInfo pInfo = p.getPersistInfo();
           pInfo.setModifyStamp(t);
           p.setPersistInfo(pInfo);
           PersistenceServerHelper.manager.update(p,false);
       }
       /*
	    try {
		   	String className = p.getClass().getName();
		    String idA2A2 = String.valueOf(p.getPersistInfo().getObjectIdentifier().getId());
		    ClassInfo classinfo = WTIntrospector.getClassInfo(className); 
		    String tableName = classinfo.getDatabaseInfo().getBaseTableInfo().getTablename();
		
		    String modifyStampField = "modifyStampA2";
		
		    String sql = "update "+tableName+" set " +
		    modifyStampField+"= ? " +
		    " where ida2a2= ? ";
		
		    System.out.println("cg - sql: "+sql);
		    MethodContext methodcontext = null;
		    try {
		        methodcontext = MethodContext.getContext(); 
		    } catch (MethodServerException e) {
		        methodcontext = new MethodContext(null, null);
		    }
		    WTConnection wtconnection = (WTConnection)methodcontext.getConnection();
		    Connection connection =  wtconnection.getConnection();
		    PreparedStatement statement = (PreparedStatement)LoadServerHelper.getCacheValue(sql);
		    if (statement == null) {
		        statement = connection.prepareStatement(sql);    
		        LoadServerHelper.putCacheValue(sql, statement);
		    } 
		    statement.clearParameters();
		    int i=0;
			statement.setTimestamp(++i, t);
		
		    statement.setLong(++i, Long.decode(idA2A2).longValue());
		
		    statement.execute();
		    //statement.close();
		    connection.commit();
	    } catch (Exception e) {
		    throw new WTException(e);
	    }
	    */
        return p;
   }
   
   /**
    * Creates a role-principal mapping of roleholder membership.
    * This method is similar to wt.team.StandardTeamService.populateRolePrincipalHash()
    * which is unfortunately private in PDMLink 8.0 M050 OOTB and it requires
    * a Team object. We wanted to have a method that only requires the oid
    * of a Team object.
    *
    * @param     oid
    * @return    Map
    * @exception wt.util.WTException
    **/
   public Map populateRolePrincipalMap( Long oid )
            throws WTException {
      
   	
   	//lberger 20081122: this method body was copied from PDMLink 8.0 M050 wt.team.StandardTeamService.populateRolePrincipalHash( WTRoleHolder2 roleHolder, boolean returnDisabled )

   HashMap map=new HashMap();
 	   try {
 
 		   String principalClass=RolePrincipalMap.PRINCIPAL_PARTICIPANT + "." + ObjectReference.KEY + "." + "classname"; //"principalParticipant.key.classname"
 		   String principalOid=RolePrincipalMap.PRINCIPAL_PARTICIPANT + "." + ObjectReference.KEY + ".id";
 		   String roleHolderOid=RolePrincipalMap.WTROLE_HOLDER2_REFERENCE + "." + ObjectReference.KEY; //theWTRoleHolder2Reference.key"
 		   String principalDisabled = WTPrincipal.DISABLED;
 		   QuerySpec qs = new QuerySpec();
 		   int rpmIndex=qs.appendClassList(RolePrincipalMap.class, false);
 		   int prinIndex = qs.appendFrom(new ClassViewExpression(WTPrincipal.class));
 		   qs.appendSelectAttribute(wt.team.RolePrincipalMap.ROLE, rpmIndex, false);
 		   qs.appendSelectAttribute(principalClass, rpmIndex, false);
 		   qs.appendSelectAttribute(principalOid, rpmIndex, false);
 		   qs.appendSelectAttribute(principalDisabled, prinIndex, false);
 
 		   qs.appendWhere(new SearchCondition(RolePrincipalMap.class,
 				   roleHolderOid + ".id",
 				   SearchCondition.EQUAL,
 				   oid),
 				   new int[] { rpmIndex });
 
 		   qs.appendAnd();
 		   SearchCondition qsPRINCIPAL_RPM_SC2 = new SearchCondition
 		   (RolePrincipalMap.class,
 				   RolePrincipalMap.PRINCIPAL_PARTICIPANT + "." + WTAttributeNameIfc.REF_OBJECT_ID,
 				   WTPrincipal.class,
 				   WTAttributeNameIfc.ID_NAME);
 		   qsPRINCIPAL_RPM_SC2.setOuterJoin(SearchCondition.RIGHT_OUTER_JOIN);
 		   qs.appendWhere(qsPRINCIPAL_RPM_SC2, new int[] { rpmIndex, prinIndex });
 
 	       QueryResult results = PersistenceHelper.manager.find((wt.pds.StatementSpec)qs);
 		   List list=null;
 		   WTPrincipalReference pRef=null;
 
 		   while (results.hasMoreElements()) {
 			   Object[] rpm=(Object[])results.nextElement();
 			   Role role= (Role)rpm[0];
 			   Object oid_obj=rpm[2];
 			   if (oid_obj != null) {
 				   String class_name=(String)rpm[1];
 				   long oid2=((java.math.BigDecimal)rpm[2]).longValue();
 				   pRef=WTPrincipalReference.newWTPrincipalReference(
 						   ObjectIdentifier.newObjectIdentifier(Class.forName(class_name),oid2));
 
 				   boolean enforce = wt.session.SessionServerHelper.manager.setAccessEnforced (false);
 				   try {
 					   java.math.BigDecimal objDisabled = (java.math.BigDecimal)rpm[3]; //it can be a empty role!!
 					   if( objDisabled != null ){
 						   long disableVal = objDisabled.longValue(); //see if principal ref is null
 						   if (disableVal != 0) { //if disabled then value in WTUSer db table is 1
 						   	//lberger 20081122: don't understand the below exactly
 						   	//we are calling this method without a WTRoleHolder2 roleHolder
 						   	//savest seems to be to assume that we should not have an entry for this in the map
 						   	pRef=null;
 						   	/*
 							   if (!(roleHolder instanceof ContainerTeam)) {
 								   //delete the RolePrincipalMap and set pRef to null.
 
 								   deleteRolePrincipalMap(role, (WTPrincipal)pRef.getObject(), roleHolder);
 							   }
 							   if (!returnDisabled || !(roleHolder instanceof ContainerTeam))
 								   pRef=null;
 								   */
 						   }
 					   }
 				   }
 				   finally {
 					   wt.session.SessionServerHelper.manager.setAccessEnforced (enforce);
 				   }
 			   } else {
 				   pRef=null;
 			   }
 
 			   addToMap(map, role, pRef);
 		   } //end while
 	   }
 	   catch(WTPropertyVetoException wtpv){
                logger.error(wtpv.getLocalizedMessage(), wtpv);
 	   }
 	   catch (WTException e) {
                logger.error(e.getLocalizedMessage(), e);
 	   }
 	   catch (ClassNotFoundException e) {
                logger.error(e.getLocalizedMessage(), e);
 	   }
 
 	   return map;
   }

   /**
    * @param     set
    * @param     roleNames
    * @return    Map
    * @exception wt.util.WTException
    **/
   public Map getRolePrincipalMapsForTeams( Collection<String> set, Set<String> roleNames )
            throws WTException {
      
   	//params:
   	//set is a set of Long (e.g.: new Long(PersistenceHelper.getObjectIdentifier(team).getId()))
   	
   	//lberger 20081125: this method body was copied from PDMLink 8.0 M050 private wt.team.StandardTeamService.getRolePrincipalMapsForTeams( Set set )
   	//lberger 20100928: code is still the same in PDMLink 9.1 M050
    	   Map map = new HashMap((int)(set.size()/.75 +1));

    	   try {

    		   String principalClass=RolePrincipalMap.PRINCIPAL_PARTICIPANT + "." + ObjectReference.KEY + "." + "classname"; //"principalParticipant.key.classname"
    		   String principalOid=RolePrincipalMap.PRINCIPAL_PARTICIPANT + "." + ObjectReference.KEY + ".id";
    		   String roleHolderOid=RolePrincipalMap.WTROLE_HOLDER2_REFERENCE + "." + ObjectReference.KEY; //theWTRoleHolder2Reference.key"
    		   QuerySpec qs = new QuerySpec();
    		   int index=qs.appendClassList(RolePrincipalMap.class, false);
    		   qs.appendSelectAttribute(wt.team.RolePrincipalMap.ROLE, index, false);
    		   qs.appendSelectAttribute(principalClass, index, false);
    		   qs.appendSelectAttribute(principalOid, index, false);
    		   qs.appendSelectAttribute(roleHolderOid + ".id", index, false);

    		   Object[] teamOids = set.toArray();
    		   
    		   //lberger 20100928: changed OR to IN clause
            TableColumn tc = new TableColumn("A0", "ida3a4");
            SearchCondition scIN = new SearchCondition(tc, SearchCondition.IN, new ArrayExpression(teamOids));
            qs.appendSearchCondition(scIN);
    		   
            //OOTB was:
    		   /*
    		   for (int i=0; i < teamOids.length; i++) {
    		   	//System.out.println("teamOids[i]=" + teamOids[i] + " c=" + teamOids[i].getClass().getName());
    			   //ObjectIdentifier teamId = (ObjectIdentifier)teamOids[i];
    		   	Long teamId = (Long)teamOids[i];
    			   if (i > 0)
    				   qs.appendOr();
    			   qs.appendSearchCondition(new SearchCondition(RolePrincipalMap.class,
    					   roleHolderOid + ".id",
    					   SearchCondition.EQUAL,
    					   teamId));
    		   }
				*/
    		   
            //lberger 20100930: added criteria for the given role names
            if(roleNames!=null && !roleNames.isEmpty()) {
            	qs.appendAnd();
       		   Object[] roleNamesArray = roleNames.toArray();
               TableColumn tcRN = new TableColumn("A0", "role");
               SearchCondition scRN = new SearchCondition(tcRN, SearchCondition.IN, new ArrayExpression(roleNamesArray));
               qs.appendSearchCondition(scRN);
            }
            
            //lstrobin 20140127: principalOid IS NOT NULL
            // 'ida3b4' is the column with principal oid
            qs.appendAnd();
            TableColumn principalOidTC = new TableColumn("A0", "ida3b4");
            SearchCondition principalNotNullCondition = new SearchCondition(principalOidTC,SearchCondition.NOT_NULL);
            qs.appendSearchCondition(principalNotNullCondition);
            
    		   QueryResult results = PersistenceHelper.manager.find(qs);
    		   
    		   if (logger.isDebugEnabled()) {
    			   if (results != null) {
    				   logger.debug("number of elements in the query result: " + results.size());    				   
    			   } else {
    				   logger.debug("query result is NULL");
    			   }
    		   }
    		   
    		   List list=null;
    		   WTPrincipalReference pRef=null;
    		   TeamReference tRef = null;
    		   Map temp = null;

    		   while (results.hasMoreElements()) {
    			   Object[] rpm=(Object[])results.nextElement();
    			   Role role= (Role)rpm[0];
    			   Object oid_obj=rpm[2];
    			   long teamOid = ((BigDecimal)rpm[3]).longValue();
    			   ObjectIdentifier teamId = ObjectIdentifier.newObjectIdentifier(Team.class, teamOid);

    			   if (oid_obj != null) {
    				   String class_name=(String)rpm[1];
    				   long oid=((BigDecimal)rpm[2]).longValue();
    				   pRef=WTPrincipalReference.newWTPrincipalReference(
    						   ObjectIdentifier.newObjectIdentifier(Class.forName(class_name),oid));

    				   //lberger 20081125: below is the code from OOTB. But we don't want to modify anything on the team obejct
    				   //this change results in the following:
    				   // even if a user is disabled, it would show up in the EC-Applet
    				   
    				   //bad performance: 
    				   // - WTPrincipalReference.isDisabled() does a DB query (if WTPrincipalReference has not been retrieved
    				   // - TeamReference.getObject() does a DB query
    				   
    				   /*
    				   if (pRef.isDisabled()) {
    					   boolean enforce = wt.session.SessionServerHelper.manager.setAccessEnforced (false);
    					   try {
    						   tRef = TeamReference.newTeamReference(teamId);
    						   deleteRolePrincipalMap(role, (WTPrincipal)pRef.getObject(), (Team)tRef.getObject());
    					   }
    					   finally {
    						   wt.session.SessionServerHelper.manager.setAccessEnforced (enforce);
    					   }
    					   pRef=null;
    				   }
    				   */
    			   }
                           else {
    				   pRef=null;
                           }

    			   if (map.get(teamId) != null) {
    				   temp = (Map) map.get(teamId);
                           } else {
    				   temp = new HashMap();
    				   map.put(teamId, temp);
    			   }

    			   //if given roleSet was null, then we should retrieve ALL roles
    			   //OR only add the roles we are interested in into the map
    			   if(roleNames==null || (roleNames.contains(role.toString()) && pRef!=null)) {
    			   addToMap(temp, role, pRef);
    			   }
    		   }
    	   }
    	   catch (WTException e) {
               logger.error(e.getLocalizedMessage(), e);
    	   }
    	   catch (ClassNotFoundException e) {
               logger.error(e.getLocalizedMessage(), e);
    	   }
    	   
    	   return map;
   }

   /**
    * @param     groupName
    * @param     principals
    * @param     context
    * @return    WTGroup
    * @exception wt.util.WTException
    **/
   public WTGroup createGroup( String groupName, WTPrincipal[] principals, DirectoryContextProvider context )
            throws WTException {
      
       WTGroup group = WTGroup.newWTGroup(groupName, context);
       group = (WTGroup) OrganizationServicesHelper.manager.createPrincipal(group);
       group.addMembers(principals);
       return group;
   }

   /**
    * removes all members of the given role from the given team object
    *
    * @param     team
    * @param     role
    * @exception wt.util.WTException
    **/
   public void cleanRole( Team team, Role role )
            throws WTException {
      
      Enumeration<WTPrincipalReference> iterator = (Enumeration<WTPrincipalReference>)team.getPrincipalTarget(role);
      
      while(iterator.hasMoreElements()) {
          WTPrincipalReference userRef = iterator.nextElement();
          team.deletePrincipalTarget(role, userRef.getPrincipal());
      }
   }

    public Vector getRolePricipalMapChunk( Role role, long[] teamId )
    throws WTException {
        logger.debug("starting getRolePricipalMapChunk...");
        // instance of return vector
        Vector rpmaps = new Vector();
        
        // queryspec for navigating via RolePrincipalLink to RolePrincipalMap
        // returns only RolePrincipalMap objects
        QuerySpec queryspec = new QuerySpec();
        int rolePrincipalLinkIndex = queryspec.appendClassList(wt.team.RolePrincipalLink.class, false);
        int rolePrincipalMapIndex = queryspec.appendClassList(wt.team.RolePrincipalMap.class, true);
        
        // SearchCondition for an array of teamIds
        SearchCondition searchcondition1 = new SearchCondition(wt.team.RolePrincipalLink.class, WTAttributeNameIfc.ROLEB_OBJECT_ID, teamId);
        queryspec.appendWhere(searchcondition1, rolePrincipalLinkIndex);
        
        // restriction to a special role
        SearchCondition searchcondition2 = new SearchCondition(RolePrincipalMap.class, RolePrincipalMap.ROLE, SearchCondition.EQUAL, role);
        queryspec.appendAnd();
        queryspec.appendWhere(searchcondition2, rolePrincipalMapIndex);
        
        // navigate from RolePrincipalLink to RolePrincipalMap
        TableExpression[] tables4 = new TableExpression[2];
        String aliases4[] = new String[2];
        tables4[0] = queryspec.getFromClause().getTableExpressionAt(rolePrincipalLinkIndex);
        aliases4[0] = queryspec.getFromClause().getAliasAt(rolePrincipalLinkIndex);
        tables4[1] = queryspec.getFromClause().getTableExpressionAt(rolePrincipalMapIndex);
        aliases4[1] = queryspec.getFromClause().getAliasAt(rolePrincipalMapIndex);
        SearchCondition correlatedJoin4 = new SearchCondition(RolePrincipalLink.class, WTAttributeNameIfc.ROLEA_OBJECT_ID, RolePrincipalMap.class, WTAttributeNameIfc.ID_NAME);
        queryspec.appendAnd();
        queryspec.appendWhere(correlatedJoin4, tables4, aliases4);
        
        //logger.debug(queryspec.toString());
        
        QueryResult result = PersistenceHelper.manager.find(queryspec);
        logger.debug("Get result of size: " + result.size());
        
        // put result into vector
        while(result.hasMoreElements()) {
            Object[] o = (Object[])result.nextElement();
            //logger.debug(o[0]);
            RolePrincipalMap roleprincipalmap = (RolePrincipalMap)o[0];
            rpmaps.add(roleprincipalmap);
        }
        return rpmaps;
    }
    
    private static DirectorySubtree getSubtree(WTContainer containerteammanaged, String s)
    throws WTException {
        DirectorySubtree directorysubtree = WTContainerHelper.service.getSubtree(containerteammanaged);
        if(isAccessNode(s)) {
            directorysubtree.addNode("accessGroups", wt.org.DirectoryInfrastructureNode.class);
        }
        directorysubtree.addNode(s, wt.org.DirectoryInfrastructureNode.class);
        return directorysubtree;
    }
    
    private static boolean isAccessNode(String s) {
        return s.equals("roles") || s.equals("otherGroups") || s.equals("orgs");
    }
    
    private static Vector getGroupMembers(final WTPrincipal principal) throws WTException {
        Vector result = new Vector();
        Enumeration groupMembers = ((WTGroup)principal).members();
        while (groupMembers.hasMoreElements()) {
            WTPrincipal member = (WTPrincipal) groupMembers.nextElement();
            if (member instanceof WTGroup) {
                result.addAll(getGroupMembers(member));
            }
            if (member instanceof WTUser) {
                result.add(member);
            }
        }
        
        return result;
    }
    
    public Persistable updateAcl( Persistable anObject )
    throws WTException {
        
        long t1 = System.currentTimeMillis();
        
        if(anObject instanceof TeamManaged) {
            
            //boolean isCheckedOut;
            boolean isLatestIteration;
            boolean hasAdministrativeRight;
            
            WTUser actUser = (WTUser)SessionHelper.getPrincipal();
            
            // �ndern der Rollenberechtigung nur f�r LifeCycleManaged
            if(anObject instanceof LifeCycleManaged) {
                // kein �ndern der Berechtigungen f�r ausgecheckte Objekte
                //(aw: rever readed)isCheckedOut = anObject instanceof Workable
                // && WorkInProgressHelper.isCheckedOut((Workable)anObject);
                //if (!isCheckedOut) {
                // kein �ndern der Berechtigungen, falls es sich nicht um die
                // letzte Iteration handelt
                isLatestIteration = anObject instanceof Iterated && VersionControlHelper.isLatestIteration((Iterated)anObject);
                if(isLatestIteration) {
                    // kein �ndern, falls keine Administrativen Rechte
                    // existieren
                    hasAdministrativeRight = AccessControlHelper.manager.hasAccess(actUser, anObject, AccessPermission.ADMINISTRATIVE);
                    
                    if(hasAdministrativeRight) {
                        //vor dem Aktualisieren das Objekt neu aus der
                        // Datenbank holen
                        //wichtig: ansonsten gibt es Fehler beim Einchecken
                        anObject = PersistenceHelper.manager.refresh(anObject);
                        
                        logger.debug("changed: " + anObject);
                        //Berechtigung �ndern
                        LifeCycleHelper.service.augmentRoles((LifeCycleManaged)anObject);
                    }
                } // isLatestIteration
                //} // !isCheckedOut
            }
        }
        long t2 = System.currentTimeMillis();
        long t = t2 - t1;
        logger.debug("Time updateAcl: " + t);
        return anObject;
    }
    
    //lberger 20081122: copied from wt.team.StandardTeamService because we need it inside populateRolePrincipalMap()
    private void addToMap(Map map, Role role, Object object) {
     List list = (List)map.get(role);
     if (list == null) {
        list = new ArrayList();
        map.put(role,list);
     }
     if (object != null && !list.contains(object)) {
        list.add(object);
     }
  }
    
    /**
     * Create new list with WTPrincipalReferences to all members of passed in group.
     * @param group
     * @return
     * @throws WTException 
     */
    public LinkedList<WTPrincipalReference> toReferences(WTGroup group)
            throws WTException {
        LinkedList<WTPrincipalReference> references = new LinkedList<WTPrincipalReference>();
        Enumeration members = group.members();
        while (members.hasMoreElements()) {
            WTPrincipal principal = (WTPrincipal) members.nextElement();
            WTPrincipalReference ref = WTPrincipalReference.newWTPrincipalReference(principal);
            references.add(ref);
        }

        return references;
    }
}
