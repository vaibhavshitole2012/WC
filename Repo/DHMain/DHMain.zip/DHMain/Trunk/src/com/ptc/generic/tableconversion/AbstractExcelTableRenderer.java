/** 

Class with excel table render implementation.

@author of extensions for universal rendering: Lothar Germund, PLUS-Systeme GmbH
@since 19.10.2010
*/
package com.ptc.generic.tableconversion;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.*;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;

public abstract class AbstractExcelTableRenderer extends AbstractExportTableRenderer
{
    
    protected ExcelConfigurationImpl config;
    private static final Logger logger = Logger.getLogger(AbstractExcelTableRenderer.class);
    private static final Logger logPerformance = Logger.getLogger(AbstractExcelTableRenderer.class + "#PERFORMANCE");


    /**
     * Don't use this constructor, so it's private and it throws an exception.
     * Avoid construction without a configuration.
     *
     * @throws RenderException
     */
    private AbstractExcelTableRenderer() throws RenderException {
        super(BASICAPI_STREAMREF);
        throw new RenderException("Don't use the default constructor, use the one with config parameter");
    }


    /**
     * Constructor which has a filled configuration parameter.
     *
     * @param config
     */
    public AbstractExcelTableRenderer(ExcelConfigurationImpl config)
    {
        super(BASICAPI_STREAMREF);
        this.config = config;
    }


    /**
     * Getter for TableConfiguration
     */
    public ExcelConfigurationImpl getTableConfiguration() {
        return this.config;
    }


    /**
     * removes some special characters which are not allowed in sheet title
     *
     * @param input
     * @return
     */
    private static String removeSpecialChars(String input) {
        input = input.replace('/', '-');
        input = input.replace('\\', '-');
        input = input.replace('*', '-');
        input = input.replace('[', '-');
        input = input.replace(']', '-');
        return input;
    }


    /**
     * Initializing for excel rendering process.
     * Set additional configuration data and optionally filters/translates the cells.
     *
     * @param tableCells
     */
    private void initRendering(Cell[][] tableCells) {
        int rowCount    = trimRowcount(tableCells);
        int columnCount = (rowCount > 0) ? tableCells[0].length : 0;

        config.setRows(rowCount);
        config.setColumns(columnCount);
        config.setSheetName(removeSpecialChars(config.getSheetName()));

        // set "must have" filters
        int cellFilter = config.getCellFilter();
        if ((cellFilter & AbstractExportTableConfiguration.CELLFILTER_SPEC_ATTRIBUTES) != 0) {
            cellFilter |= AbstractExportTableConfiguration.CELLFILTER_HEADER_ROW;
            cellFilter |= AbstractExportTableConfiguration.CELLFILTER_DEFAULT;
        }
        config.setCellFilter(cellFilter);

        boolean withHeader = ((cellFilter & AbstractExportTableConfiguration.CELLFILTER_HEADER_ROW) != 0);

        if ((rowCount > 0) && (config.getCellFilter() != AbstractExportTableConfiguration.CELLFILTER_NOTHING)) {
            String query = config.getQueryName();
            Cell[] headerRow = tableCells[0];

            // header row contains the column names at this point, so the header cells must be String types

            Object oValue;

            // filter data cells (may contain rows with null cells)
            for (int row = (withHeader) ? 1 : 0; row < rowCount; row++) { // data rows
                Cell[] currRow = tableCells[row];
                for (int i = 0; i < columnCount; i++) {
                    Cell currCell = currRow[i];
                    if (currCell != null) {
                        oValue = filterCell(currCell.getValue(), (String) (headerRow[i].getValue()), true); // header cell is used for formatting options
                        currCell.setValue(oValue);
                    }
                }
            }

            if (withHeader) {
                // transform header row (filtered display names)
                for (int i = 0; i < columnCount; i++) {
                    String name = this.getHeaderName(headerRow[i].getValue(), query);
                    oValue = filterCell(name, name, false);
                    headerRow[i].setValue(oValue);
                }
            }
        }
        else {
            // all cells contain the final display values (or empty matrix)
        }
    }



    /**
     * Helper to set type and value for the cell parameter. The type is derived from 'oValue'.
     *
     * @param x
     * @param y
     * @param bodyCell
     * @param oValue
     * @return see ExcelConfigurationImpl STYLE_TYPE_CLASS constants
     */
    protected int setCellValue(int x, int y, HSSFCell bodyCell, Object oValue) throws RenderException {
        int styleTypeClass = ExcelConfigurationImpl.STYLE_TYPE_CLASS_NORMAL;

        if (oValue == null) {
            bodyCell.setCellType(HSSFCell.CELL_TYPE_BLANK);
            bodyCell.setCellValue(new HSSFRichTextString(""));
        }
        else if (oValue instanceof String) {
            bodyCell.setCellType(HSSFCell.CELL_TYPE_STRING);
            bodyCell.setCellValue(new HSSFRichTextString((String)oValue));
        }
        else if (oValue instanceof Double) {
            bodyCell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
            bodyCell.setCellValue(((Double)oValue).doubleValue());
        }
        else if (oValue instanceof Float) {
            bodyCell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
            //double d = ((Float)oValue).doubleValue(); // not exactly the same value, so use String
            String s = ((Float)oValue).toString();
            //bodyCell.setCellValue(new HSSFRichTextString(s));
            double d = Double.parseDouble(s);
            bodyCell.setCellValue(d);
        }
        else if (oValue instanceof Integer) {
            bodyCell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
            bodyCell.setCellValue(((Integer)oValue).intValue());
        }
        else if (oValue instanceof Long) {
            bodyCell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
            double d = ((Long)oValue).doubleValue();
            bodyCell.setCellValue(d);
        }
        else if (oValue instanceof Boolean) {
            bodyCell.setCellType(HSSFCell.CELL_TYPE_STRING);
            String s = ((Boolean)oValue).toString();
            bodyCell.setCellValue(new HSSFRichTextString(s));
        }
        else if (oValue instanceof Timestamp) {
            bodyCell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
            bodyCell.setCellValue((Timestamp)oValue); // Timestamp is subclass of Date
            styleTypeClass = ExcelConfigurationImpl.STYLE_TYPE_CLASS_DATE;
        }
        else if (oValue instanceof Date) {
            bodyCell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
            bodyCell.setCellValue((Date)oValue);
            styleTypeClass = ExcelConfigurationImpl.STYLE_TYPE_CLASS_DATE;
        }
        else if (oValue instanceof Calendar) {
            bodyCell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
            bodyCell.setCellValue((Calendar)oValue);
            styleTypeClass = ExcelConfigurationImpl.STYLE_TYPE_CLASS_DATE;
        }
        else {
            logger.warn("setCellValue(): Cell " + x + "/" + y + " (x/y) contains an unknown type.");
            bodyCell.setCellType(HSSFCell.CELL_TYPE_STRING);
            String s = oValue.toString();
            bodyCell.setCellValue(new HSSFRichTextString(s));
        }
        return styleTypeClass;
    }



    /**
     * Renders an excel output stream from the cell table, uses the stream parameter.
     *
     * @param outStream
     *            stream for writing the result
     * @param tableCells
     * @throws RenderException
     */
    private void renderLocal(OutputStream outStream, Cell[][] tableCells) throws RenderException {
        int styleTypeClass;
        int rowCount = config.getRows();

        HSSFWorkbook workbook = new HSSFWorkbook();
        config.setWorkbook(workbook);
        HSSFSheet sheet = workbook.createSheet(config.getSheetName());

        if (config.isFreezeFirstRow()) {
            //freeze the first row
            sheet.createFreezePane(0, 1);
        }

        // give the cells to the API
        for (int x = 0; x < rowCount; x++) {
            HSSFRow excelRow = sheet.createRow((short) x);
            Cell[] row = tableCells[x];

            for (int y = 0; y < row.length; y++) {
                Cell columnCell = row[y];

                if (columnCell != null) {
                    HSSFCell bodyCell = excelRow.createCell(y);

                    // set cell value, type and style
                    Object oValue = columnCell.getValue();
                    oValue = postInitValueFiltering(oValue, columnCell, config);
                    styleTypeClass = setCellValue(x, y, bodyCell, oValue);
                    bodyCell.setCellStyle(config.getCellStyle(x, y, styleTypeClass));

                    //Style override
                    bodyCell = applyExternalCellMods(columnCell, bodyCell, config);
                }
            }
        }

        // set the optimal column width
        short columnCount = (short) config.getColumns();
        for (short i = 0; i < columnCount; i++) {
            sheet.autoSizeColumn(i);
        }
        
        doPreWriteFormatting(workbook);

        // API-call, render everything to the stream
        try {
            workbook.write(outStream);
        } catch (IOException e) {
            throw new RenderException(e.getMessage());
        }
    }

    public abstract void doPreWriteFormatting(HSSFWorkbook workbook);

    /**
     * Override this Method if you want to do special Modifications for a Cell.
     * @param columnCell
     * @param bodyCell
     * @param config
     */
    protected HSSFCell applyExternalCellMods(Cell columnCell, HSSFCell bodyCell, ExcelConfigurationImpl config) {
        /*
         * DO NOTHING HERE: IT IS ONLY A HIDDEN CONNECTOR TO DO CELL MODIFICATIONS!
         * If you want to use this Method: Override this Method in your Non-abstract-Child-Class.
         */
        return bodyCell;
    }

    /**
     * Override this Method if you want to do special Modifications to a Value that is not persisted to the Cell-Objects
     * @param toFilter
     * @param columnCell
     * @param config
     */
    protected Object postInitValueFiltering(Object toFilter, Cell columnCell, ExcelConfigurationImpl config) {
        /*
         * DO NOTHING HERE: IT IS ONLY A HIDDEN CONNECTOR TO DO CELL MODIFICATIONS!
         * If you want to use this Method: Override this Method in your Non-abstract-Child-Class.
         */
        return toFilter;
    }


    /**
     * "main" method.
     * Renders the cell matrix (table) to a given output stream (byte stream). One method is basic and the others derived from it.
     * Depending from the construction parameter implement this method or call only basicRenderToStreamSourceArray(...).
     *
     * @param outStream
     * @param tableCells
     * @throws RenderException
     */
    public void renderToStream(OutputStream outStream, Cell[][] tableCells) throws RenderException {
        long start = System.currentTimeMillis();
        initRendering(tableCells);
        long startExcel = System.currentTimeMillis();

        try {
            // the work
            renderLocal(outStream, tableCells);
        } catch (RenderException ex) {
            logger.error("renderToStream(): can not render", ex);
        }

        if (logPerformance.isDebugEnabled()) {
            try {
                long stop = System.currentTimeMillis();
                long timePerHundredEntries;
                logPerformance.debug("renderToStream(): Runtime for init render part= " + (startExcel - start));
                logPerformance.debug("renderToStream(): Runtime for excel render part= " + (stop - startExcel));
                timePerHundredEntries = ((stop - start) * 100) / tableCells.length;
                logPerformance.debug("renderToStream(): Average runtime for 100 entries= " + timePerHundredEntries);
            } catch (Throwable t) {
            }
        }
    }



    /**
     * "main" method.
     * Renders the cell matrix (table) and returns a byte array. One method is basic and the others derived from it.
     * Depending from the construction parameter implement this method or call only basicRenderToArraySourceStream(...).
     *
     * @param tableCells
     * @return
     * @throws RenderException
     */
    public byte[] renderToArray(Cell[][] tableCells) throws RenderException {
        return basicRenderToArraySourceStream(tableCells);
    }



    /**
     * Renders the cell matrix (table) and returns a byte array output stream.
     * Better usage: Use renderToArrayStream (same parameters) or renderToArray with byte[] return value.
     *
     * @param tableCells
     * @return
     * @throws RenderException
     */
    public ByteArrayOutputStream renderTable(Cell[][] tableCells) throws RenderException {
        return renderToArrayStream(tableCells);
    }

    
    
    /**
     * returns cellType for coordinate
     * 
     * @param row
     * @param column
     * @TODO here: calculate Celltype from given index with configuration
     * @return
     */
}
