/* bcwti
 *
 * Copyright (c) 2010 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */
package com.ptc.cat.ui.client.action;

import com.ptc.cat.entity.client.structure.StructureModel;
import com.ptc.cat.entity.client.util.EntityUtils;
import com.ptc.cat.ui.client.internal.action.DefaultActionDefinition;

public class CustomMultiLevelBOMAction extends LaunchURLAction {

    public CustomMultiLevelBOMAction(ActionDefinition definition) {
        super(definition);
    }

    @Override
    protected void populateActionDefinition(ActionDefinition action_definition) {
        DefaultActionDefinition actionDefinition = (DefaultActionDefinition) action_definition;

        String actionName = "MultiLevelBOM";

        actionDefinition.setName(actionName);

    }

    @Override
    protected String getStructureModelOid(StructureModel model) {
        return EntityUtils.getPersistableIdentifier(model.getChildIdentifier());
    }
}