package com.ptc.generic.epm;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

import com.ptc.windchill.uwgm.common.associate.Association;

import wt.epm.EPMDocument;
import wt.fc.BinaryLink;
import wt.fc.WTObject;
import wt.part.WTPart;
import wt.util.WTException;

public class EPMAssociation extends Association  implements Serializable {
	
	

	//meaning:
	// CLEAN: as in database, not modified in any way
	// NEW:   a new Association that is not yet persistent
	// TO_BE_REMOVED: an existing Association that should be removed from the database
	// MODIFIED: an existing Association that need to be modified in the database
	public enum ModificationType {CLEAN, NEW, TO_BE_REMOVED, MODIFIED};
	public enum BuildType {OWNER, IMAGE, CONTIBUTING_IMAGE, CONTIBUTING_CONTENT, CONTENT};
	
	private EPMAssociation.ModificationType modificationType;
	private BinaryLink link = null;
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3438439768785383915L;
	private void writeObject(ObjectOutputStream out) throws IOException {
		out.writeObject(getDoc());
		out.writeObject(getPart());
		out.writeObject(getAssocType());
		out.writeInt(getBuildFlags());
		out.writeObject(link);
		out.writeObject(modificationType);
	}
	private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
		setDoc((EPMDocument) in.readObject());
		setPart((WTPart) in.readObject());
		assocType = (Type) in.readObject();
		setBuildFlags(in.readInt());
		link = (BinaryLink) in.readObject();
		modificationType = (ModificationType) in.readObject();	
	}
	
	
	public EPMAssociation(EPMDocument epmDoc, WTPart wtpart,Type type, boolean isRoleStruct, boolean isRoleRep, boolean isRoleAttr, BinaryLink aBuildRuleOrHistory){
		super(epmDoc,wtpart,type,isRoleStruct,isRoleRep,isRoleAttr);
		link = aBuildRuleOrHistory;
	}
	/**
	 * Use getLink() instead.
	 * @return BinaryLink
	 * @deprecated
	 */
	public BinaryLink getBuildRuleOrHistory() {
		return link;
	}
	
	public EPMAssociation.ModificationType getModificationType() {
		return modificationType;
	}

	public void setModificationType(EPMAssociation.ModificationType modificationType) {
		this.modificationType = modificationType;
	}

	public BinaryLink getLink() {
		return link;
	}

	public void setLink(BinaryLink link) {
		this.link = link;
	}
	
	/*
	 * New Associations
	 */
	public static EPMAssociation newAssociation(Association assoc, EPMAssociation.ModificationType type, BinaryLink link) {
		EPMAssociation epmassoc = new EPMAssociation(assoc.getDoc(), assoc.getPart(), assoc.getAssocType(), assoc.isRoleStruct(), assoc.isRoleRep(), assoc.isRoleAttr(), link);
		epmassoc.setModificationType(type);
		epmassoc.setLink(link);
		return epmassoc;
	}
	
	private static EPMAssociation newOwner(WTPart part, EPMDocument doc) {
		EPMAssociation assoc = new EPMAssociation(doc, part, Type.ACTIVE, true, true, true, null);
		assoc.modificationType = ModificationType.NEW;
		return assoc;
	}
	
	private static EPMAssociation newContent(WTPart part, EPMDocument doc) {
		EPMAssociation assoc = new EPMAssociation(doc, part, Type.PASSIVE, false, false, false, null);
		assoc.modificationType = ModificationType.NEW;
		return assoc;
	}
	
	private static EPMAssociation newImage(WTPart part, EPMDocument doc) {
		EPMAssociation assoc = new EPMAssociation(doc, part, Type.ACTIVE, false, true, false, null);
		assoc.modificationType = ModificationType.NEW;
		return assoc;
	}
	
	private static EPMAssociation newContributingImage(WTPart part, EPMDocument doc) {
		EPMAssociation assoc = new EPMAssociation(doc, part, Type.ACTIVE, false, true, true, null);
		assoc.modificationType = ModificationType.NEW;
		return assoc;
	}
	
	private static EPMAssociation newContributingContent(WTPart part, EPMDocument doc) {
		EPMAssociation assoc = new EPMAssociation(doc, part, Type.ACTIVE, false, false, true, null);
		assoc.modificationType = ModificationType.NEW;
		return assoc;
	}
	
	public static EPMAssociation newAssociation(WTPart part, EPMDocument epmdoc, BuildType buildType) {
		switch (buildType) {
		case OWNER:
			return newOwner(part, epmdoc);
		case CONTENT:
			return newContent(part, epmdoc);
		case IMAGE:
			return newImage(part, epmdoc);
		case CONTIBUTING_IMAGE:
			return newContributingImage(part, epmdoc);
		case CONTIBUTING_CONTENT:
			return newContributingContent(part, epmdoc);
		}
		return newContent(part, epmdoc);
	}
	
	/**
	 * Check association type
	 */
	public boolean isOwner() {
		try {
			int buildFlags = getBuildFlags();
			return EPMHelper.isRoleStruct(buildFlags) && EPMHelper.isRoleRep(buildFlags) && EPMHelper.isRoleAttr(buildFlags);
		} catch (Exception e) {
			return false;
		}
	}
		
	public boolean isImage() {
		try {
			int buildFlags = getBuildFlags();
			return !EPMHelper.isRoleStruct(buildFlags) && EPMHelper.isRoleRep(buildFlags) && !EPMHelper.isRoleAttr(buildFlags);
		} catch (Exception e) {
			return false;
		}
	}
	
	public boolean isContributingImage() {
		try {
			int buildFlags = getBuildFlags();
			return !EPMHelper.isRoleStruct(buildFlags) && EPMHelper.isRoleRep(buildFlags) && EPMHelper.isRoleAttr(buildFlags);
		} catch (Exception e) {
			return false;
		}
	}
	
	public boolean isContributingContent() {
		try {
			int buildFlags = getBuildFlags();
			return !EPMHelper.isRoleStruct(buildFlags) && !EPMHelper.isRoleRep(buildFlags) && EPMHelper.isRoleAttr(buildFlags);
		} catch (Exception e) {
			return false;
		}
	}
	
	public boolean isContent() {
		try {
			int buildFlags = getBuildFlags();
			return !EPMHelper.isRoleStruct(buildFlags) && !EPMHelper.isRoleRep(buildFlags) && !EPMHelper.isRoleAttr(buildFlags);
		} catch (Exception e) {
			return false;
		}
	}
	
	public BuildType getBuildType() {
		if (isOwner()) return BuildType.OWNER;
		else if (isImage()) return BuildType.IMAGE;
		else if (isContributingImage()) return BuildType.CONTIBUTING_IMAGE;
		else if (isContributingContent()) return BuildType.CONTIBUTING_CONTENT;
		else if (isContent()) return BuildType.CONTENT;
		else return null;
	}
	
	public boolean isActive() {
	    return Type.ACTIVE.equals(getAssocType());
	}
	
	public boolean isNew() {
	       return ModificationType.NEW.equals(getModificationType());
	}
	
	public static BuildType toBuildType(String s) throws WTException {
	   if(s==null || s.length()==0) {
		   throw new WTException("given buildType String was null or empty");
	   }
	   
	   if("OWNER".equalsIgnoreCase(s)) {
		   return BuildType.OWNER;
	   } else if("CONTENT".equalsIgnoreCase(s)) {
		   return BuildType.CONTENT;
	   } else if("CONTIBUTING_CONTENT".equalsIgnoreCase(s)) {
		   return BuildType.CONTIBUTING_CONTENT;
	   } else if("CONTIBUTING_IMAGE".equalsIgnoreCase(s)) {
		   return BuildType.CONTIBUTING_IMAGE;
	   } else if("IMAGE".equalsIgnoreCase(s)) {
		   return BuildType.IMAGE;
	   } else {
		   throw new WTException("given buildType '" + s + "' does not match any of the allowed build types");
	   }
   }
}
