package com.ptc.cat.ops.client.external;

import com.ptc.cat.entity.client.EntityCore;
import com.ptc.cat.entity.client.Identifier;
import com.ptc.cat.ops.client.ServerParams;
import com.ptc.cat.ops.client.internal.AbstractOperation;

/**
 * Client side GWT operation
 * 
 * @author wachurad
 *
 */
public class AutoFillEmptyNumbersOperation extends AbstractOperation {

	private static final String LABEL = "AutoFill Empty Numbers Operation";
	
	private Identifier rootWorkingCopyID;
	
	public AutoFillEmptyNumbersOperation(EntityCore entityCore, Identifier rootWorkingCopyID) {
		super(entityCore);
		this.rootWorkingCopyID = rootWorkingCopyID;
	}

	@Override
	public boolean accumulateChanges() {
		return true;
	}

	@Override
	public boolean automaticallySyncOperationResult() {
		return true;
	}

	@Override
	public String getLabel() {
		return LABEL;
	}

	@Override
	public boolean performRedo() {
		return false;
	}
	
	@Override
	public ServerParams createServerParams() {
		ServerParams params = super.createServerParams();
		params.addIdentifier(rootWorkingCopyID);
		return params;
	}

}
