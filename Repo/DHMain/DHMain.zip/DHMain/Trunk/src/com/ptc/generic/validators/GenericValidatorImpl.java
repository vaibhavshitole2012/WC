package com.ptc.generic.validators;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Implementation of GenericValidator interface.
 * This class can be used to validate a list of GenericValidators.
 * It provides some basic functionality to get results and
 * modify the validation process.
 *
 * @author cherrmann
 *
 */
public class GenericValidatorImpl<T> implements GenericValidator<T> {

	private List<GenericValidator<T>> validators;
	private ValidationResult validationResult;
	private boolean forceValidateAll = false;

	/**
	 * @param validators
	 */
	public GenericValidatorImpl(List<GenericValidator<T>> validators) {
		this(validators, false);
	}

	/**
	 * @param validators
	 * @param forceValidateAll
	 */
	public GenericValidatorImpl(List<GenericValidator<T>> validators, boolean forceValidateAll) {
		this.validators = validators;
		this.forceValidateAll = forceValidateAll;
	}
    
    public GenericValidatorImpl(GenericValidator<T>... validators) {
        this(false, validators);
    }
    
    public GenericValidatorImpl(boolean forceValidateAll, GenericValidator<T>... validators) {
        this.forceValidateAll = forceValidateAll;
        this.validators = Arrays.asList(validators);
    }

	/**
	 * Validates the given object.
	 * If forceValidateAll is true, all validators are run regardless of the result.
	 * In the other case the validation stops after the first failure.
	 *
	 * @param oid
	 * @return
	 */
	public boolean validate(T object) {
		resetValidationResult();

		boolean valid = true;
		String statusMessage = null;
		Object resultObject = null;

		if (validators != null){
			for (GenericValidator<T> curValidator : this.validators) {
				if (!curValidator.validate(object)){
					statusMessage = curValidator.getValidationResult().getStatusMessage();
					resultObject = curValidator.getValidationResult().getResultObject();
					valid = false;
					if (!forceValidateAll){
						break;
					}
				}
			}
		}

		this.validationResult = new ValidationResult(statusMessage, valid, resultObject);

		return valid;
	}

	public ValidationResult getValidationResult() {
		return validationResult;
	}

	/**
	 * Returns the ValidationResult of a specific validator class from the current validators set.
	 * 
	 * @param genericValidator
	 * @return
	 */
	public <R extends GenericValidator<T>> ValidationResult getValidationResult(Class<R> genericValidator) {
		ValidationResult result = null;
		
		GenericValidator<T> validator = getSpecificValidatorType(genericValidator);
		if (validator != null){
			result = validator.getValidationResult();
		}
		
		return result;
	}
	
	/**
	 * Return the setting for forced validation of all validators.
	 *
	 * @return forceValidateAll
	 */
	public boolean isForceValidateAll() {
		return forceValidateAll;
	}

	/**
	 * If enabled, validation is not stopped after failure.
	 * All validations are run.
	 *
	 * @param forceValidateAll
	 */
	public void setForceValidateAll(boolean forceValidateAll) {
		this.forceValidateAll = forceValidateAll;
	}

	/**
	 * Returns the current set of validators
	 *
	 * @return validators
	 */
	public List<GenericValidator<T>> getValidators(){
		return this.validators;
	}

	/**
	 * Set the validators
	 *
	 * @param validators
	 */
	public void setValidators(List<GenericValidator<T>> validators){
		this.validators = validators;
	}

	/**
	 * Returns all validators which passed the validation.
	 *
	 * @return
	 */
	public List<GenericValidator<T>> getPassedValidations(){
		List<GenericValidator<T>> passedValidators = new ArrayList<GenericValidator<T>>();
		if (this.validators != null) {
			for (GenericValidator<T> curValidator : this.validators) {
				ValidationResult result = curValidator.getValidationResult();
				if (result != null && result.getIsValid()){
					passedValidators.add(curValidator);
				}
			}
		}
		return passedValidators;
	}

	/**
	 * Returns all validators which failed during validation.
	 *
	 * @return
	 */
	public List<GenericValidator<T>> getFailedValidations(){
		List<GenericValidator<T>> failedValidators = new ArrayList<GenericValidator<T>>();
		if (this.validators != null) {
			for (GenericValidator<T> curValidator : this.validators) {
				ValidationResult result = curValidator.getValidationResult();
				if (result != null && !result.getIsValid()){
					failedValidators.add(curValidator);
				}
			}
		}
		return failedValidators;
	}

	/**
	 * Returns all validators where the validation result is null.
	 *
	 * @return
	 */
	public List<GenericValidator<?>> getNotRunValidations(){
		List<GenericValidator<?>> notRunValidators = new ArrayList<GenericValidator<?>>();
		if (this.validators != null) {
			for (GenericValidator<?> curValidator : this.validators) {
				ValidationResult result = curValidator.getValidationResult();
				if (result == null){
					notRunValidators.add(curValidator);
				}
			}
		}
		return notRunValidators;
	}

	/**
	 * Gets validators from this validation set.
	 *
	 * Returns a list of all validators which match the passed class.
	 * Validators which extend the passed class will be returned as well.
	 *
	 * @param genericValidator
	 * @return
	 */
	public List<GenericValidator<T>> getSpecificValidatorTypeList(Class<? extends GenericValidator<T>> genericValidator){
		List<GenericValidator<T>> validators = new ArrayList<GenericValidator<T>>();
		if (this.validators != null) {
			for (GenericValidator<T> curValidator : this.validators) {
				if (curValidator.getClass().isAssignableFrom(genericValidator)){
					validators.add(curValidator);
				}
			}
		}
		return validators;
	}

	/**
	 * Returns a specific validator class from the current validators set.
	 *
	 * @param genericValidator
	 * @return
	 */
	public <R extends GenericValidator<T>> R getSpecificValidatorType(Class<R> genericValidator){
		if (this.validators != null) {
			for (GenericValidator<T> curValidator : this.validators) {
				if (curValidator.getClass().equals(genericValidator)){
					return (R) curValidator;
				}
			}
		}
		return null;
	}

	public void resetValidationResult(){
		this.validationResult = null;
		if (this.validators != null){
			for (GenericValidator<T> curValidator : this.validators) {
				curValidator.resetValidationResult();
			}
		}
	}
}
