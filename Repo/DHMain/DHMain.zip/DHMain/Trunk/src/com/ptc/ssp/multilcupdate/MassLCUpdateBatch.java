/*
 * bcwti
 *
 * Copyright (c) 2012 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */
package com.ptc.ssp.multilcupdate;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import wt.fc.ObjectReference;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.fc.WTReference;
import wt.fc.collections.WTArrayList;
import wt.fc.collections.WTList;
import wt.lifecycle.LifeCycleHelper;
import wt.lifecycle.LifeCycleManaged;
import wt.lifecycle.LifeCycleServerHelper;
import wt.lifecycle.LifeCycleState;
import wt.lifecycle.LifeCycleTemplate;
import wt.lifecycle.LifeCycleTemplateMaster;
import wt.lifecycle.LifeCycleTemplateReference;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.part.WTPart;
import wt.pds.StatementSpec;
import wt.query.CompositeWhereExpression;
import wt.query.ConstantExpression;
import wt.query.KeywordExpression;
import wt.query.LogicalOperator;
import wt.query.QueryException;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.query.SubSelectExpression;
import wt.type.TypeDefinitionReference;
import wt.type.TypedUtility;
import wt.util.WTAttributeNameIfc;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.WTPropertyVetoException;
import wt.vc.config.LatestConfigSpec;
import wt.vc.wip.WorkInProgressHelper;
import wt.vc.wip.Workable;

import com.ptc.core.meta.type.mgmt.server.TypeDefinition;
import com.ptc.core.meta.type.mgmt.server.impl.WTTypeDefinition;

/*

windchill com.ptc.ssp.multilcupdate.MassLCUpdateBatch -u user -p password
-m [report|update] (-o logic id) -f intermediateFile.txt (-l lifeCycleName) -batch size

report:
windchill com.ptc.ssp.multilcupdate.MassLCUpdateBatch -u wcadmin -p wcadmin -m report -o Baustufe -f c:/intermediateFile.txt -l ECAPhaseMasterlisteLC -batch 100
update:
windchill com.ptc.ssp.multilcupdate.MassLCUpdateBatch -u wcadmin -p wcadmin -m update -f c:/intermediateFile.txt -batch 100

*/

/**
 * MassLCUpdateBatch tool's main class. Checks, if all arguments provided by the
 * user are correct and if so, invokes remotely a method to update or report
 * valid objects.
 *
 * @author Piotr Sikorski (psikorski@ptc.com)
 * @see https://ssp.ptc.com/wiki/display/TechnicalCommunity/Mass+LifeCycle+Template+Updater
 * @see VW_ECA-2046
 * @version 20121001
 * @since 4.2
 */
public class MassLCUpdateBatch {

	public static final String svnUrl = "$URL: http://127.0.0.1/svn/KB_04082016/components/Generic-Utilities/src/com/ptc/ssp/multilcupdate/MassLCUpdateBatch.java $";
	public static final String svnRev = "$Revision: 1.1.1.3 $ $Date: 2015/12/02 15:46:10IST $";

	private static final String RESOURCE = "com.ptc.ssp.multilcupdate.multilcupdateResource";

	/** The Constant STATS_SUCCESS. */
	public static final String STATS_SUCCESS = "success";

	/** The Constant STATS_FAILURE. */
	public static final String STATS_FAILURE = "failure";

	/**
	 * Inner class, with functionality to update life cycle template (to its
	 * latest iteration) or check if there are any instances of objects, for a
	 * specified type
	 */
	public static final class Server implements RemoteAccess {

		private static final Logger logger = Logger.getLogger(MassLCUpdateBatch.class);

		private static Map findParentClass(QueryResult queryResult) {
			Map out = new HashMap();
			Class searchClass = null;
			TypeDefinition parent = null;
			if (queryResult.hasMoreElements()) {
				WTTypeDefinition type = (WTTypeDefinition) queryResult.nextElement();
				parent = type.getParent();
				boolean done = false;
				while (!done) {
					try {
						if (parent == null) {
							System.out.println("findParentClass: Parent is null!");
							System.out.println(WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.PARENT_NOT_FOUND, null));
							try {
								searchClass = Class.forName(type.getLogicalIdentifier());
								System.out.println("findParentClass: searchClass1 = " + searchClass);
							} catch (ClassNotFoundException e) {
								logger.error(WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.CLASS_NOT_FOUND, new String[] { type.getLogicalIdentifier() }) + e.getMessage());
								return null;
							}
						} else {
							System.out.println("findParentClass: parent = " + parent + " parentLogicalIdentifier = " + parent.getLogicalIdentifier() + " parentName = " + parent.getName());
						}
						if (searchClass == null) {
							if (parent != null) {
								try {
									final String identifier = parent.getLogicalIdentifier();
									if (identifier != null && identifier.length() > 0) {
										System.out.println("findParentClass: identifier = " + identifier);
										searchClass = Class.forName(identifier);
										System.out.println("findParentClass: searchClass2 = " + searchClass);
									}
								} catch (final NullPointerException npe) {
									logger.error("Class.forName did not found parent class!");
								}
							}
						} else {
							System.out.println("findParentClass: searchClass3 = " + searchClass);
						}
						done = true;
					} catch (ClassNotFoundException e) {
						System.out.println("ClassNotFoundException");
						if (parent != null) {
							logger.error(WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.CLASS_NOT_FOUND, new String[] { parent.getLogicalIdentifier() }) + e.getMessage());
							final TypeDefinition parentGetParent = parent.getParent();
							System.out.println("findParentClass: parent = " + parent + " parentLogicalIdentifier = " + parent.getLogicalIdentifier());
							System.out.println("findParentClass: parent.getParent() = " + parentGetParent + " parentGetParentLogicalIdentifier = " + parentGetParent.getLogicalIdentifier());
							parent = parentGetParent;
						}
					}
				}
				if (searchClass != null) {
					logger.debug("Found concrete class: " + searchClass.getName());
				}
				System.out.println("searchClass = " + searchClass + " parent = " + parent + " parentLogicalIdentifier = " + parent.getLogicalIdentifier() + " parentNmae " + parent.getName());
				if (searchClass != null && parent != null) {
					out.put(searchClass, parent);
				}
				return out;
			}
			return out;
		}

		private static Map findSearchClass(final String objectType, TypeDefinitionReference typeRef) throws WTException {
			Map out = isHardType(objectType);
			// argument is a hard modeled class
			if (out.size() == 1) {
				return out;
			}
			// look for soft type definition
			QuerySpec qs = new QuerySpec(WTTypeDefinition.class);
			SearchCondition searchCondition = new SearchCondition(WTTypeDefinition.class, WTTypeDefinition.LOGICAL_IDENTIFIER, SearchCondition.EQUAL,
					objectType);
			((QuerySpec) qs).appendWhere(searchCondition, new int[] {});
			LatestConfigSpec latestConfSpec = new LatestConfigSpec();
			qs = latestConfSpec.appendSearchCriteria((QuerySpec) qs);

			System.out.println("MassLCUpdateBatch: QuerySpec for findSearchClass\n");
			System.out.println(qs.toString());
			System.out.println("\n");

			QueryResult queryResult = PersistenceHelper.manager.find((StatementSpec) qs);
			// find concrete class - parent of soft type
			return findParentClass(queryResult);
		}

		private static QuerySpec getMainQuery(Class searchClass, Object parent, TypeDefinitionReference typeRef, String lcName)
				throws QueryException, WTPropertyVetoException {
			QuerySpec qs = new QuerySpec();
			int idxClass = qs.addClassList(searchClass, false);
			int idxLC = qs.appendClassList(LifeCycleTemplate.class, false);
			int idxLCT = qs.appendClassList(LifeCycleTemplateMaster.class, false);
			qs.appendSelectAttribute(WTAttributeNameIfc.ID_NAME, idxClass, false);
			qs.appendSelectAttribute(WTAttributeNameIfc.OID_CLASSNAME, idxClass, false);
			// find only latest iteration objects
			qs.appendWhere(new SearchCondition(searchClass, "iterationInfo.latest", SearchCondition.IS_TRUE), new int[] { idxClass });
			// find only templates which are not latest
			qs.appendAnd();
			qs.appendWhere(new SearchCondition(LifeCycleTemplate.class, "iterationInfo.latest", SearchCondition.IS_FALSE), new int[] { idxLC });
			// add reference for LCTemplate
			qs.appendAnd();
			qs.appendWhere(new SearchCondition(searchClass, "state.lifeCycleId.key.id", LifeCycleTemplate.class, WTAttributeNameIfc.ID_NAME),
					new int[] { idxClass, idxLC });
			qs.appendAnd();
			qs.appendWhere(new SearchCondition(LifeCycleTemplateMaster.class, WTAttributeNameIfc.ID_NAME, LifeCycleTemplate.class,
					LifeCycleTemplate.MASTER_REFERENCE + "." + WTAttributeNameIfc.REF_OBJECT_ID), new int[] { idxLCT, idxLC });
			// if we are working on soft type add proper search condition
			if (parent != null) {
				qs.appendAnd();
				if (logger.isDebugEnabled()) {
					logger.debug("Appending soft type filter");
				}
				qs.appendWhere(new SearchCondition(searchClass, "typeDefinitionReference.key.branchId", SearchCondition.EQUAL, typeRef.getKey()
						.getBranchId()), new int[] { idxClass });
			}
			// if life cycle name is set add proper where
			if (lcName != null) {
				if (logger.isDebugEnabled()) {
					logger.debug("Appending lifecycle template: " + lcName);
				}
				qs.appendAnd();
				qs.appendWhere(new SearchCondition(LifeCycleTemplateMaster.class, LifeCycleTemplateMaster.NAME, SearchCondition.EQUAL, lcName),
						new int[] { idxLCT });
			}
			// update query limit
			qs.setQueryLimit(-1);
			if (logger.isDebugEnabled()) {
				logger.debug("Querying for objects, it can take a while.");
			}
			KeywordExpression rowNum = KeywordExpression.ROWNUM;
			rowNum.setColumnAlias("rowNumber");
			qs.appendSelect(rowNum, false);
			return qs;
		}

		private static Map isHardType(final String objectType) {
			Class itemClass = null;
			Map out = new HashMap();
			try {
				itemClass = Class.forName(objectType);
			} catch (ClassNotFoundException e1) {
				// ignore - soft type
			}
			if (itemClass != null) {
				if (logger.isDebugEnabled()) {
					logger.debug("Found concrete class: " + itemClass.getName());
				}
				out.put(itemClass, null);
				return out;
			}
			return out;
		}

		private static QueryResult queryObjects(QuerySpec qs, Integer start, Integer offset) throws WTException, WTPropertyVetoException {

			QuerySpec mainQuery = new QuerySpec();
			mainQuery.setAdvancedQueryEnabled(true);
			mainQuery.appendFrom(new SubSelectExpression(qs));
			mainQuery.appendSelect(new KeywordExpression("IDA2A2"), false);
			mainQuery.appendSelect(new KeywordExpression("CLASSNAMEA2A2"), false);

			CompositeWhereExpression cw = new CompositeWhereExpression();
			cw.setOperator(LogicalOperator.AND);
			SearchCondition rownumConditionMin = new SearchCondition(new KeywordExpression("rowNumber"), SearchCondition.GREATER_THAN,
					new ConstantExpression(start));
			SearchCondition rownumConditionMax = new SearchCondition(new KeywordExpression("rowNumber"), SearchCondition.LESS_THAN_OR_EQUAL,
					new ConstantExpression(offset));
			cw.append(rownumConditionMin);
			cw.append(rownumConditionMax);
			mainQuery.appendWhere(cw, new int[] {});
			if (logger.isInfoEnabled()) {
				logger.info(WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.PROCESSING_BATCH, null) + start + " -> " + offset);
			}

			System.out.println("MainQuerySpec:\n");
			System.out.println(mainQuery.toString());
			System.out.println("\n");

			return PersistenceHelper.manager.find((StatementSpec) mainQuery);
		}

		/**
		 * Creates a report on what objects of the specified type, are eligible
		 * to have their used lifecycle template updated. The report is written
		 * to a file.
		 *
		 * @param fileName
		 *            path of the file to write in, list of objects to update
		 * @param objectType
		 *            type of objects which should have theirs life cycle
		 *            updated to latest version
		 * @param lcName
		 *            name of lifecycle
		 * @param batchSize
		 *            this argument defines a number of objects that will be
		 *            updated in single DB query
		 * @return Map with information about how many object were found
		 * @throws WTException
		 * @throws WTPropertyVetoException
		 */
		@SuppressWarnings({ "unchecked", "rawtypes" })
		public static Map reportLC(String fileName, String objectType, String lcName, Integer batchSize) throws WTException, WTPropertyVetoException {

			final long startTime = System.currentTimeMillis();

			Class searchClass = null;
			TypeDefinition parent = null;
			BufferedWriter out = null;
			Map outMap = new HashMap();
			int count = 0;
			String oid;
			LifeCycleManaged item;
			boolean hasMore = true;
			ReferenceFactory rf = new ReferenceFactory();
			Integer start = new Integer(0);
			int successful = 0;
			int failed = 0;

			TypeDefinitionReference typeRef = TypedUtility.getTypeDefinitionReference(objectType);

			if (typeRef == null) {
				logger.error(WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.OBJECT_NOT_FOUND, null) + objectType);
				return outMap;
			}

			try {
				out = new BufferedWriter(new FileWriter(fileName));
				// find concrete class for query
				Map map = findSearchClass(objectType, typeRef);
				if (map == null) {
					logger.error("map is null");
				} else if (map.size() == 0) {
					logger.error("Empty search result. Using fallback: hardcoded for : WTPart (Baustufe) without parent");
					map.put(WTPart.class, null);
				}
				if (map != null && map.size() > 0) {
					searchClass = (Class) (map.keySet().toArray())[0];
					final Object getSearchClass = map.get(searchClass);
					if (getSearchClass == null) {
						parent = null;
						System.out.println("set parent to null");
					} else {
						parent = (TypeDefinition) getSearchClass;
						System.out.println("set parent to = " + parent);
					}
				}
				if (searchClass == null) {
					logger.error("searchClass == null: " + WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.LOOKUP_ERROR, null));
					return outMap;
				}

				try {
					System.out.println("searchClass = " + searchClass.toString());
					Object[] array = map.keySet().toArray();
					for (Object object : array) {
						System.out.println(((Class) object).getName());
					}
				} catch (Exception e) {
					logger.error("Error inside debug code");
					logger.error(e.getLocalizedMessage(), e);
				}

				// generate query
				QuerySpec qs = getMainQuery(searchClass, parent, typeRef, lcName);
				do {
					Integer offset = new Integer(start.intValue() + batchSize.intValue());
					QueryResult queryResult = queryObjects(qs, start, offset);
					while (queryResult.hasMoreElements()) {
						Object[] items = (Object[]) queryResult.nextElement();
						// create obid
						oid = (String) items[1] + ":" + items[0];
						// Retrieve item to do more processing
						item = (LifeCycleManaged) ((ObjectReference) rf.getReference(oid)).getObject();
						out.write(item.toString());
						out.write(";");
						// write info about checkout status
						if (item instanceof Workable
								&& (WorkInProgressHelper.isWorkingCopy((Workable) item) || WorkInProgressHelper.isCheckedOut((Workable) item))) {
							out.write(CHECKOUT_MARKER);
						} else {
							out.write(CHECKIN_MARKER);
						}
						// write info about checkout state
						out.write(";");
						out.write(item.getState().toString());
						// if part write number, name, and version
						if (item instanceof WTPart) {
							out.write(";");
							out.write(((WTPart) item).getNumber());
							out.write(";");
							out.write(((WTPart) item).getName());
							out.write(";");
							out.write(((WTPart) item).getVersionIdentifier().getValue());
							out.write(";");
							out.write(((WTPart) item).getIterationIdentifier().getValue());
							out.write(";");
							out.write(((WTPart) item).getFolderPath());
						}
						count++;
						out.newLine();
					}
					if (queryResult.size() < batchSize.intValue()) {
						hasMore = false;
					}
					start = new Integer(start.intValue() + batchSize.intValue());
				} while (hasMore);
				outMap.put("count", new Integer(count));
				return outMap;
			} catch (WTException e) {
				logger.error("WTException: " + WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.LOOKUP_ERROR, null) + e.getMessage());
				logger.error(e.getLocalizedMessage(), e);
				return outMap;
			} catch (IOException e) {
				logger.error("IOException: " + WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.LOOKUP_ERROR, null) + e.getMessage());
				logger.error(e.getLocalizedMessage(), e);
				return outMap;
			} finally {
				if (out != null) {
					try {
						out.flush();
						out.close();
					} catch (IOException e) {
						logger.error(e.getLocalizedMessage(), e);
					}
				}
				final long endTime = System.currentTimeMillis();
				System.out.println("Total time for report creation: " + ((endTime - startTime) * 0.001));
			}
		}

		private static boolean updateCheckOutLC(WTList list, LifeCycleTemplate latestIteration) {
			// get latest iteration of LC
			WTList toUpdate = new WTArrayList();
			LifeCycleManaged item = null;

			try {
				long before = System.currentTimeMillis();
				for (Iterator i = list.iterator(); i.hasNext();) {
					item = (LifeCycleManaged) ((ObjectReference) i.next()).getObject();
					LifeCycleState prev = item.getState();
					item = LifeCycleServerHelper.service.doReassign(item, LifeCycleTemplateReference.newLifeCycleTemplateReference(latestIteration));

					if (!item.getLifeCycleState().equals(prev.getState())) {
						item.getState().setState(prev.getState());
						toUpdate.add(item);
					}

					if (logger.isDebugEnabled()) {
						logger.debug("Reassining lc for : " + item.getPersistInfo().getObjectIdentifier().getStringValue());
					}
				}
				PersistenceServerHelper.manager.update(toUpdate);
				logger.info(WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.UPDATE_DONE, null) + Math.round((System.currentTimeMillis() - before) / 1000) + "s");
				return true;

			} catch (Exception e) {
				if (item != null) {
					logger.error(WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.APPLY_ERROR_CO, null)
							 + item.getPersistInfo().getObjectIdentifier().getStringValue());
				}
				logger.error(e.getLocalizedMessage(), e);
				return false;
			}
		}

		private static Map commitLeftovers(Map commonSpace, LifeCycleTemplate latestIteration, Map checkOut, Map processedMap) {
			// commit if batch size was not reached
			Map out = new HashMap();
			int successful = 0;
			int failed = 0;
			Set states = commonSpace.keySet();
			for (Iterator i = states.iterator(); i.hasNext();) {
				String state = (String) i.next();
				WTList list = (WTList) commonSpace.get(state);
				if (list.size() > 0) {
					// logger.info("Number of parts (checked in) processed for state "
					// + state + ": " + (list.size()));
					if (updateLC(list, latestIteration)) {

						int nbOfProcessedParts = 0;
						if (processedMap.get(state + ";" + CHECKIN_MARKER) != null) {
							nbOfProcessedParts = ((Integer) processedMap.get(state + ";" + CHECKIN_MARKER)).intValue() + list.size();
						} else {
							nbOfProcessedParts = list.size();
						}
						processedMap.put(state + ";" + CHECKIN_MARKER, new Integer(nbOfProcessedParts));

						successful += list.size();
					} else {
						failed += list.size();
					}
				}
			}
			states = checkOut.keySet();
			for (Iterator i = states.iterator(); i.hasNext();) {
				String state = (String) i.next();
				WTList list = (WTList) checkOut.get(state);
				if (list.size() > 0) {
					// logger.info("Final parts (checked out) commited for state "
					// + state + ": " + (list.size()));

					int nbOfProcessedParts = 0;
					if (processedMap.get(state + ";" + CHECKOUT_MARKER) != null) {
						nbOfProcessedParts = ((Integer) processedMap.get(state + ";" + CHECKOUT_MARKER)).intValue() + list.size();
					} else {
						nbOfProcessedParts = list.size();
					}
					processedMap.put(state + ";" + CHECKOUT_MARKER, new Integer(nbOfProcessedParts));

					if (updateCheckOutLC(list, latestIteration)) {
						successful += list.size();
					} else {
						failed += list.size();
					}
				}
			}
			out.put(STATS_SUCCESS, new Integer(successful));
			out.put(STATS_FAILURE, new Integer(failed));
			return out;
		}

		/**
		 * Update objects with a new life cycle template they will use.
		 *
		 * @param fileName
		 *            - path of the file that contains list of objects to update
		 * @param batchSize
		 *            - this argument defines a number of objects that will be
		 *            updated in single DB query
		 * @return Map with information if the operation succeeded or failed
		 */
		public static Map updateLC(String fileName, Integer batchSize) {

			System.out.println(WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.STARTED, null));

			BufferedReader in = null;
			File inputFile = new File(fileName);
			ReferenceFactory rf = new ReferenceFactory();
			Map outMap = new HashMap();
			LifeCycleTemplate latestIteration = null;
			int successful = 0;
			int failed = 0;
			// state->list of objects <String,WTList>
			Map commonSpace = new HashMap();
			// state->list of objects <String,WTList>
			Map checkOut = new HashMap();
			// state+checkin status -> Integer
			Map processedMap = new HashMap();

			if (!inputFile.exists()) {
				logger.error(WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.FILE_NOT_EXIST, null) + inputFile.getPath());
				return outMap;
			}

			try {
				in = new BufferedReader(new FileReader(inputFile));
				String line = null;
				while ((line = in.readLine()) != null) {
					if (logger.isDebugEnabled()) {
						logger.debug("Line: " + line);
					}
					// ignore comments
					if (line.startsWith("#")) {
						continue;
					}

					// split into array, 2 fields are obligatory
					String[] inputs = line.split(";");
					if (inputs.length < 2) {
						logger.error(WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.CORRUPTED_ENTRY, null) + line);
						continue;
					}

					try {
						String state = null;
						WTReference reference = rf.getReference(inputs[0]);
						// all objects has the same LC
						if (latestIteration == null) {
							latestIteration = LifeCycleHelper.service
									.getLatestIteration((LifeCycleTemplateMaster) ((LifeCycleTemplate) ((LifeCycleManaged) reference.getObject())
											.getLifeCycleTemplate().getObject()).getMaster());
						}
						// check object state
						state = inputs[2];
						if (commonSpace.get(state) == null) {
							commonSpace.put(state, new WTArrayList());
						}
						if (checkOut.get(state) == null) {
							checkOut.put(state, new WTArrayList());
						}
						// check if object is checkout
						if (inputs[1].equals(CHECKOUT_MARKER)) {
							// add to update queue
							WTList list = (WTList) checkOut.get(state);
							list.add((LifeCycleManaged) reference.getObject());
						} else {
							// add to update queue
							WTList list = (WTList) commonSpace.get(state);
							list.add(reference);
						}
						// if batch is ready, update
						WTList listToCheck = ((WTList) commonSpace.get(state));
						if (listToCheck.size() >= batchSize.intValue()) {
							logger.info(WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.TRESHOLD, null)
									+ state + WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.PROCESSED, null)
									+ (successful + batchSize.intValue())
									+ WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.PARTS, null)
									+ batchSize.intValue() + ")");
							if (updateLC(listToCheck, latestIteration)) {

								int nbOfProcessedParts = 0;
								if (processedMap.get(state + ";" + CHECKIN_MARKER) != null) {
									nbOfProcessedParts = ((Integer) processedMap.get(state + ";" + CHECKIN_MARKER)).intValue() + listToCheck.size();
								} else {
									nbOfProcessedParts = listToCheck.size();
								}
								processedMap.put(state + ";" + CHECKIN_MARKER, new Integer(nbOfProcessedParts));

								successful += listToCheck.size();

							} else {
								failed += listToCheck.size();
							}
							listToCheck.clear();
						}
						listToCheck = ((WTList) checkOut.get(state));
						if (listToCheck.size() >= batchSize.intValue()) {
							logger.info(WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.TRESHOLD, null)
									+ state + WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.PROCESSED, null)
									+ (successful + batchSize.intValue())
									+ WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.PARTS, null)
									+ batchSize.intValue() + ")");
							if (updateCheckOutLC(listToCheck, latestIteration)) {

								int nbOfProcessedParts = 0;
								if (processedMap.get(state + ";" + CHECKOUT_MARKER) != null) {
									nbOfProcessedParts = ((Integer) processedMap.get(state + ";" + CHECKOUT_MARKER)).intValue() + listToCheck.size();
								} else {
									nbOfProcessedParts = listToCheck.size();
								}
								processedMap.put(state + ";" + CHECKOUT_MARKER, new Integer(nbOfProcessedParts));

								successful += listToCheck.size();
							} else {
								failed += listToCheck.size();
							}
							listToCheck.clear();
						}
					} catch (WTException e) {
						logger.error(WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.REFERENCE_ERROR, null) + inputs[0]);
						++failed;
						continue;
					}
				}
				// commit if batch size was not reached
				Map leftovers = commitLeftovers(commonSpace, latestIteration, checkOut, processedMap);
				successful += ((Integer) leftovers.get(STATS_SUCCESS)).intValue();
				failed += ((Integer) leftovers.get(STATS_FAILURE)).intValue();
				// return stats
				outMap.put(STATS_SUCCESS, new Integer(successful));
				outMap.put(STATS_FAILURE, new Integer(failed));
				if (logger.isInfoEnabled()) {
					logger.info(WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.OVERALL_STATUS, null));

					// Successfully processing by state/status
					Iterator it = processedMap.keySet().iterator();
					while (it.hasNext()) {
						String key = (String) it.next();
						String[] stateStatus = key.split(";");
						if (stateStatus[1].equals(CHECKIN_MARKER)) {
							logger.info(WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.PROCESSED_CI, null)
									+ stateStatus[0] + ": " + processedMap.get(key).toString());
						} else {
							logger.info(WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.PROCESSED_CO, null)
									+ stateStatus[0] + ": " + processedMap.get(key).toString());
						}
					}

					if (((Integer) outMap.get(MassLCUpdateBatch.STATS_FAILURE)).intValue() > 0) {
						logger.info(WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.FAILED, null)
								+ outMap.get(MassLCUpdateBatch.STATS_FAILURE)
								+ WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.DETAILS, null));
					}

					logger.info(WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.SUCCESSFULLY_UPDATED, null)
							+ outMap.get(MassLCUpdateBatch.STATS_SUCCESS)
							+ WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.OBJECTS, null));
				}
			} catch (FileNotFoundException e) {
				logger.error(WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.FILE_NOT_EXIST, null) + inputFile.getPath());
				return outMap;
			} catch (IOException e) {
				logger.error(WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.READING_ERROR, null) + e.getMessage());
				return outMap;
			} finally {
				try {
					if (in != null) {
						in.close();
						in = null;
					}
				} catch (IOException e) {
					logger.error(e.getLocalizedMessage(), e);
				}
			}
			return outMap;
		}

		private static boolean updateLC(WTList list, LifeCycleTemplate latestIteration) {
			try {
				if (logger.isDebugEnabled()) {
					logger.debug("Reassining lc for : " + list);
				}
				long before = System.currentTimeMillis();
				LifeCycleHelper.service.reassign(list, LifeCycleTemplateReference.newLifeCycleTemplateReference(latestIteration), null, true);
				System.out.println(WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.UPDATE_DONE_IN, null)
						+ Math.round((System.currentTimeMillis() - before) / 1000) + "s");
				return true;
			} catch (Exception e) {
				e.printStackTrace();
				logger.error(e.getLocalizedMessage(), e);
				return false;
			}
		}
	}

	public static final String CHECKOUT_MARKER = "c/o";

	public static final String CHECKIN_MARKER = "c/i";

	protected static final String SERVER_CLASS = MassLCUpdateBatch.class.getName() + "$Server";

	/**
	 * You can use the recovery tool in a report mode, in this case no
	 * modification is done. In a windchill shell, launch:<br/>
	 *
	 * windchill com.ptc.ssp.multilcupdate.MassLCUpdateBatch -m report -f [file]
	 * -u [user name] -p [password] - o[object type] -l [lifecycle
	 * name] -batch [optional size]<br/>
	 * <br/>
	 *
	 * Arguments signification:<br/>
	 *
	 * - [file]: absolute path of the file that will be populated with objects
	 * to update<br/>
	 *
	 * - [user name]: the user name<br/>
	 *
	 * - [password]: the password<br/>
	 *
	 * - [object type]: type of objects which should have theirs life cycle
	 * updated to latest version (hard modeled or softtype identifier)<br/>
	 *
	 * - [lifecycle name]: name of the lifecycle<br/>
	 *
	 * - [batch]: (optional) this argument defines a chunk of data that will be
	 * read in single query from DB, defaults to 1000<br/>
	 * <br/>
	 *
	 *
	 * If result of report mode is OK, in a windchill shell, launch:<br/>
	 *
	 * windchill com.ptc.ssp.multilcupdate.MassLCUpdateBatch -m update -f [file]
	 * -u [user name] -p [password] -batch [optional size]<br/>
	 * <br/>
	 *
	 * Arguments signification:<br/>
	 *
	 * - [file]: absolute path of the file that contains list of objects to
	 * update [user name]: the user name <br/>
	 *
	 * - [password]: the password<br/>
	 *
	 * - [batch]: (optional) this argument defines a number of objects that will
	 * be updated in single DB query. defaults to 1000<br/>
	 *
	 * @param args
	 */
	public static void main(String[] args) {
		long start = System.currentTimeMillis();

		boolean update = false;
		Object[] rmiArgs = null;
		Class[] rmiArgTypes = null;

		String mode = null;
		String username = null;
		String password = null;
		String file = null;

		String objectType = null;
		String lcName = null;
		int batchSize = 1000;

		// Get values from command line
		for (int i = 0; i < args.length - 1; i++) {
			if (args[i].equalsIgnoreCase("-u")) {
				username = args[++i];
			}
			if (args[i].equalsIgnoreCase("-p")) {
				password = args[++i];
			}
			if (args[i].equalsIgnoreCase("-m")) {
				mode = args[++i];
			}
			if (args[i].equalsIgnoreCase("-f")) {
				file = args[++i];
			}
			if (args[i].equalsIgnoreCase("-l")) {
				lcName = args[++i];
			}
			if (args[i].equalsIgnoreCase("-o")) {
				objectType = args[++i];
			}
			if (args[i].equalsIgnoreCase("-batch")) {
				try {
					batchSize = Integer.parseInt(args[++i]);
				} catch (NumberFormatException e) {
					System.out.println(WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.BATCH_INTEGER, null));
					printUsage();
					System.exit(1);
				}
			}
		}

		// Check values from command line, if wrong display usage and exit
		if (username == null || password == null || mode == null || file == null) {
			printUsage();
			System.exit(1);
		}

		update = mode.equals("update") ? true : false;
		String method = update ? "updateLC" : "reportLC";

		// Check if obligatory attributes were provided in report mode
		if (!update && (lcName == null || objectType == null)) {
			printUsage();
			System.exit(1);
		}

		if (update) {
			rmiArgs = new Object[2];
			rmiArgTypes = new Class[2];
			// file
			rmiArgs[0] = file;
			rmiArgTypes[0] = String.class;
			// batch size
			rmiArgs[1] = new Integer(batchSize);
			rmiArgTypes[1] = Integer.class;
		} else {
			rmiArgs = new Object[4];
			rmiArgTypes = new Class[4];
			// file
			rmiArgs[0] = file;
			rmiArgTypes[0] = String.class;
			// object type
			rmiArgs[1] = objectType;
			rmiArgTypes[1] = String.class;
			// lcname
			rmiArgs[2] = lcName;
			rmiArgTypes[2] = String.class;
			// batch size
			rmiArgs[3] = new Integer(batchSize);
			rmiArgTypes[3] = Integer.class;
		}

		if (update) {
			System.out.println(WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.UPDATE_USING_FILE, null) + file);
		} else {
			System.out.println(WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.CREATE_IN_FILE, null)
					+ file
					+ WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.FOR_OBJECT, null)
					+ objectType);
		}

		try {
			RemoteMethodServer rms = RemoteMethodServer.getDefault();
			rms.setPassword(password);
			rms.setUserName(username);
			System.out.println(WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.LOGGED_IN, null));
			System.out.println(WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.EXECUTING, null));

			Map out = (Map) rms.invoke(method, SERVER_CLASS, null, rmiArgTypes, rmiArgs);
			if (out != null) {
				if (mode.equals("report")) {
					System.out.println(WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.FOUND, null)
							+ out.get("count")
							+ WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.UPDATE_OBJECTS, null));
				} else {
					if (((Integer) out.get(MassLCUpdateBatch.STATS_FAILURE)).intValue() > 0) {
						System.out.println(WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.FAILED, null)
								+ out.get(MassLCUpdateBatch.STATS_FAILURE)
								+ WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.DETAILS, null));
					}
					System.out.println(WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.SUCCESSFULLY, null)
							+ out.get(MassLCUpdateBatch.STATS_SUCCESS)
							+ WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.UPDATED_OBJECTS, null));
				}
			}
			System.out.println(WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.DONE_IN, null)
					+ Math.round((System.currentTimeMillis() - start) / 1000) + " s");
			System.exit(0);
		} catch (RemoteException e) {
			System.err.println(WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.ERROR_OCCURED, null) + e.getMessage());
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			System.err.println(WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.ERROR_OCCURED, null) + e.getMessage());
			e.printStackTrace();
		}
	}

	private static void printUsage() {
		System.out.println(WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.REPORT_MODE, null));
		System.out.println(WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.REPORT_USAGE, null));
		System.out.println(WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.REPORT_EXAMPLE, null));
		System.out.println(WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.UPDATE_MODE, null));
		System.out.println(WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.UPDATE_USAGE, null));
		System.out.println(WTMessage.getLocalizedMessage(RESOURCE, multilcupdateResource.UPDATE_EXAMPLE, null));
	}
}
