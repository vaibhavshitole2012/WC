package com.ptc.cat.ops.server.external;

import wt.fc.ObjectReference;
import wt.part.WTPart;
import wt.util.WTException;

import com.google.gwt.gen2.logging.shared.Log;
import com.ptc.cat.entity.client.Identifier;
import com.ptc.cat.entity.server.EntityUtils;
import com.ptc.cat.ops.client.OperationResult;
import com.ptc.cat.ops.client.ServerParams;
import com.ptc.cat.ops.server.ServerOperation;

import ext.kb.businessrule.validation.BasePartUsageLinkProcessor;
import ext.kb.businessrule.validation.specific.AutoFillLineNumbersExecutable;

/**
 * Server side GWT operation
 * 
 * @author wachurad
 *
 */
public class AutoFillEmptyNumbersOperation implements ServerOperation {

	private BasePartUsageLinkProcessor processor = 
			new BasePartUsageLinkProcessor(new AutoFillLineNumbersExecutable());
	
	/**
	 * Called by WC GWT framework
	 * 
	 * @see com.ptc.cat.ops.client.external.AutoFillEmptyNumbersOperation.createServerParams()
	 */
	@Override
	public OperationResult run(ServerParams paramServerParams)
			throws WTException {
		//get part workingcopy ID
		Identifier workingCopyID = paramServerParams.getIdentifiers().get(0);
		Log.info("Part ID (w/c) to auto fill line numbers for" + workingCopyID);
		ObjectReference workingCopyRef = EntityUtils.toObjectReference(workingCopyID);
		processor.process((WTPart) workingCopyRef.getObject(), null);
		//we don't need specific data, so just return new result
		return new OperationResult();
	}

}
