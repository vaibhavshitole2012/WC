package com.ptc.ssp.util;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Vector;

import wt.method.RemoteMethodServer;
import wt.org.WTPrincipal;
import wt.session.*;
import wt.util.WTException;

import com.infoengine.util.Base64;

import org.apache.log4j.*;

/**
 * Helper class that can be used in Windchill commandline tools to take care of the initial authentication.
 * Example usage (inside other command line tools):
 * 
 * <pre>
 *	public static void main(String[] args) {
 *		try {
 *			WTPrincipal user = AuthenticationHelper.authenticateUser(args);
 *			System.out.println("authenticated as: " + user.getName());
 *		} catch (WTException w) {
 *			System.out.println("could not authenticate user. Exception:" + w.getLocalizedMessage());
 *			w.printStackTrace();
 *			System.exit(1);
 *		}
 *
 *		// init WTContext and set locale
 *		WTContext.init(args);
 *
 *		try {
 *		   //now do the real stuff.....
 *		} catch (WTException w) {
 *			w.printStackTrace();
 *			System.exit(1);
 *		}
 *		System.exit(0);
 *	}
 * </pre>
 *	
 * @author lberger@ptc.com
 */

public class AuthenticationHelper {

	private static final Logger logger = Logger.getLogger(AuthenticationHelper.class);
	
	
	
   /**
    * decodes the given encodedString with Base64.decode.
    * returns user and password in the returned array (user at [0], pwd at [1])
    *
    * @param String encodedString: syntax="BASIC encodedStringOf(user:pwd)" OR "encodedStringOf(user:pwd)"
    * @return String[]: returns null if encodedString==null
    */
   public static String[] calculateCredentials(String encodedString) {
      String[] authArr = new String[2];
      if (encodedString == null || encodedString.trim().length() == 0) {
         return null;
      }
      int i = encodedString.indexOf(" ");
      /*
       String s4=null;
       if(i>0) {
       //currently we don't check if encodedString starts with "BASIC "
       s4 = encodedString.substring(0, i);
       }
       */
      String s5 = encodedString.substring(i + 1);
      if (s5 != null) {
         //assume that encodedString contains: "BASIC encodedStringOf(user:pwd)"
         String s7 = new String(Base64.decode(s5.getBytes()));
         int j = s7.indexOf(":");
         if (j != -1) {
            authArr[0] = s7.substring(0, j);
            authArr[1] = s7.substring(j + 1);
         } else {
            authArr[0] = s7;
            authArr[1] = "";
         }
      } else {
         return null;
      }
      return authArr;
   }

	/**
	 * split given args like this: -u <username> -p <password> [-url <codebase>]
	 * and use these credential infos to authenticate against Windchill
	 * 
	 * @param args
	 * @return authenticated WTUser
	 * @throws WTException
	 */
   public static WTPrincipal authenticateUser(String[] args) throws WTException {
   	Vector v = authenticateUser(args, false); //default=false: don't remove any args 
   	if(v==null || v.size()==0) {
   		throw new WTException("got empty Vector when calling authenitcateUser()");
   	}
   	return (WTPrincipal)v.elementAt(0);
   }
   /**
    * removes the args concerning -u .. -p .. -url ..
    * 
    * @param args
    * @param bRemoveArgs
    * @return Vector: 1st element=WTPrincipal, 2nd/.... element=rest of args
    * @throws WTException
    */
   public static Vector authenticateUser(String[] args, boolean bRemoveArgs) throws WTException {
   	Vector v = new Vector();
   	v.add("DUMMY"); //will be replaced by WTPrincipal later
   	
		int argLength = args.length;
		String username = null;
		String pass = null;
		String urlString = null;

		try {
			for (int j = 0; j < argLength; j++) {
				if (args[j].equals("-u")) {
					if(!bRemoveArgs) 
						v.add(args[j]); 
					if (++j < argLength) {
						username = new String(args[j]);
						if(!bRemoveArgs) 
							v.add(args[j]); 
					}
				} else if (args[j].equals("-p")) {
					if(!bRemoveArgs) 
						v.add(args[j]); 
					if (++j < argLength) {
						pass = new String(args[j]);
						if(!bRemoveArgs) 
							v.add(args[j]); 
					}
				} else if (args[j].equals("-url")) {
					if(!bRemoveArgs) 
						v.add(args[j]); 
					if (++j < argLength) {
						urlString = new String(args[j]);
						if(!bRemoveArgs) 
							v.add(args[j]); 
					}
				} else {
						v.add(args[j]); 
				}
			} // end for
		} catch (Exception _ex) {
			System.out.println("Error reading command line arguments.");
			throw new WTException(_ex);
		}
		WTPrincipal u = authenticateUser(urlString, username, pass);
		v.set(0, u);
		if(logger.isDebugEnabled()) {
			logger.debug("v=" + v);
		}
		return v;
   }
   
   /**
    * try to authenticate with given credentials against local Windchill
    * 
    * @param username
    * @param pwd
    * @return authenticated WTUser
    * @throws WTException
    */
   public static WTPrincipal authenticateUser(String username, String pwd) throws WTException {
   	return authenticateUser(null, username, pwd);
   }

   /**
    * try to authenticate with given credentials against a remote Windchill (given via urlString)
    * 
    * @param urlString
    * @param username
    * @param pwd
    * @return authenticated WTUser
    * @throws WTException
    */
   public static WTPrincipal authenticateUser(String urlString, String username, String pwd) throws WTException {
	   return authenticateUser(urlString, username, pwd, false);
   }
   /**
    * try to authenticate with given credentials against a remote Windchill (given via urlString)
    * 
    * @param urlString
    * @param username
    * @param pwd
    * @param allowNewUser allow to set user even if local RemoteMethodServer already has an authenticated user
    * @return authenticated WTUser
    * @throws WTException
    */
   public static WTPrincipal authenticateUser(String urlString, String username, String pwd, boolean allowNewUser) throws WTException {
      //do not allow empty username
      if (username == null) {
         throw new WTException("empty username not allowed in AuthenticationHelper");
      }
      //we do allow empty passwords

      RemoteMethodServer server = null;
      if(urlString==null) {
         server = RemoteMethodServer.getDefault();
      } else {
	      URL url;
	      try {
	         url = new URL(urlString);
	         //System.out.println("url = " + url);
	      } catch (MalformedURLException e1) {
	         throw new WTException(e1);
	      }
	      server = RemoteMethodServer.getInstance(url, "MethodServer");
      }
      
      //if allowNewUser is false, then check if RMS is already authenticated
      if (server.getUserName() != null && !allowNewUser) {
      	logger.debug("we already have a username: server.getUserName()=" + server.getUserName());
         if (!server.getUserName().equals(username)) {
            //different user is authenticated !
            System.out.println("Different User is currently authenticated: " + server.getUserName() + ". Given username was " + username);
         }
      } else {
         server.setUserName(username);
         server.setPassword(pwd);
    	  SessionHelper.manager.setPrincipal(username);
      }

      WTPrincipal currentPrincipal = null;
      try {
         currentPrincipal = SessionHelper.manager.getPrincipal();
         logger.debug("found currentPrincipal=" + currentPrincipal);
      } catch (Exception e) {
         e.printStackTrace();
         throw new WTException("could not get authenticated user for username=" + username);
      }

      if(currentPrincipal==null) {
      	throw new WTException("could not authenticate user. currentPrincipal was null.");
      }

      return currentPrincipal;
   }
   
   public static void main(String args[]) {
   	try {
   		WTPrincipal u = AuthenticationHelper.authenticateUser(args);
   		System.out.println("authenticated as: " + u.getName());
   	} catch(Exception e) {
   		System.out.println("ERROR:");
   		e.printStackTrace();
   		System.exit(1);
   	}
   	System.exit(0);
   }
}
