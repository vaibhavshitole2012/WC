package com.ptc.generic;

import com.ptc.ssp.util.AuthenticationHelper;
import ext.kb.util.IBAHelper;
import ext.kb.util.KBUtils;
import org.apache.log4j.Logger;
import wt.fc.*;
import wt.iba.value.IBAHolder;
import wt.inf.container.WTContained;
import wt.lifecycle.LifeCycleManaged;
import wt.org.WTPrincipal;
import wt.org.WTPrincipalReference;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.pds.StatementSpec;
import wt.query.QueryException;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.session.SessionHelper;
import wt.util.WTAttributeNameIfc;
import wt.util.WTContext;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.vc.Iterated;
import wt.vc.VersionControlHelper;
import wt.vc.wip.WorkInProgressHelper;
import wt.vc.wip.Workable;
import wt.workflow.definer.ProcessDataInfo;
import wt.workflow.definer.WfProcessTemplate;
import wt.workflow.definer.WfTemplateObject;
import wt.workflow.engine.*;
import wt.workflow.work.*;

import java.util.*;

/**
 * contains methods for accessing and modifying workflow processes
 *
 * there are also the following useful methods inside ext.tools.WorkflowHelper:
 * - updateProcessVariable(wt.fc.Persistable obj,String name, Object value)
 *
 */
public class WfHelper {

    private static final Logger logger = Logger.getLogger(WfHelper.class);
	private static final ReferenceFactory RF = new ReferenceFactory();

	public static WfProcess startProcess(String templateName, LifeCycleManaged bo, String name, String description,
			HashMap wfVars, boolean bStartInContainerContext) throws WTException {
		WfProcessTemplate processTemplate = new WfProcessTemplate();
		WfProcess process = null;
		// -- Step 1. Retrieve the workflow template on which the process will
		// beRc
		// based.
		QuerySpec qs = new QuerySpec(WfProcessTemplate.class);
		qs.appendWhere(new SearchCondition(WfProcessTemplate.class, WfTemplateObject.NAME, SearchCondition.EQUAL,
				templateName));
		qs.appendAnd();
		qs.appendSearchCondition(new SearchCondition(WfProcessTemplate.class, "iterationInfo.latest", "TRUE"));

		Enumeration templateEnum = PersistenceHelper.manager.find(qs);
		if (templateEnum.hasMoreElements()) {
			processTemplate = (WfProcessTemplate) templateEnum.nextElement();
			processTemplate = (WfProcessTemplate) VersionControlHelper.getLatestIteration(processTemplate);

			// -- Step 2. Create a Process for the ProcessTemplate
			if (bStartInContainerContext && bo instanceof WTContained) {
				process = WfEngineHelper.service.createProcess(processTemplate, bo, ((WTContained) bo)
						.getContainerReference());
			} else {
				process = WfEngineHelper.service.createProcess(processTemplate, bo);
			}
			// -- Step 3.1 Set basic values
			process.setName(name);
			process.setDescription(description);
			process.setPriority(2);
			// -- Step 3.2 Save the process
			process = (WfProcess) PersistenceHelper.manager.save(process);
			// -- Step 4 Get process context and populate variables in table
			ProcessDataInfo signature = processTemplate.getContextSignature();
			ProcessData input = ProcessData.newProcessData(signature);
			Iterator iWfVars = wfVars.keySet().iterator();
			while (iWfVars.hasNext()) {
				Object key = iWfVars.next();
				if (key instanceof String) {
					input.setValue((String) key, wfVars.get(key));
				} else {
					input.setValue(key.toString(), wfVars.get(key));
				}
			}
			// -- Step 5. Start the process.
			try {
			    process = WfEngineHelper.service.startProcess(process, input, 1);
			} catch (WTException e) {
			    logger.error("Could not start Workflow - caught Exception - Retry in 5s - " + e.getLocalizedMessage());
			    try { Thread.sleep(5000); } catch (InterruptedException ie) {}
			    logger.error("Retry start of workflow now.");
			    process = WfEngineHelper.service.startProcess(process, input, 1);
			}
		}
		return process;
	}

	public static WfProcess startProcess(String templateName, LifeCycleManaged bo, String name, String description,
			HashMap wfVars) throws WTException {
		return startProcess(templateName, bo, name, description, wfVars, false);
	}

	/**
	 * terminates running workflow processes where the given 'pbo' is the
	 * primary business object and that are named like the given 'wfName'
	 *
	 * @param wfName
	 * @param pbo
	 * @return
	 * @throws WTException
	 */
	public static Vector terminateProcesses(String wfName, Persistable pbo) throws WTException {
		Vector v = new Vector(); // contains the WfProcesses that were
									// terminated

		// find running WFs with certain process name for given PBO
		Enumeration eProcesses = WfEngineHelper.service.getAssociatedProcesses(pbo, WfState.OPEN_RUNNING);
		while (eProcesses.hasMoreElements()) {
			WfProcess aWfProcess = (WfProcess) eProcesses.nextElement();
			if (aWfProcess.getName().equals(wfName)) {
				v.add((WfProcess) WfEngineHelper.service.changeState(aWfProcess, WfTransition.TERMINATE));
			}
		}
		return v;
	}

	/**
	 * searches running workflow processes where the given 'pbo' is the primary
	 * business object and that are named like the given 'wfName' if no process
	 * is found, exception is thrown if more than one process is found,
	 * exception is thrown if exactly one process is found, all process
	 * variables with their values are returned as Map
	 *
	 * @param wfName
	 * @param obj
	 * @param procvarName
	 * @throws WTException
	 */
	public static Map getProcessVariables(String wfName, Persistable pbo) throws WTException {
		Map returnMap = new HashMap();
		boolean bProcessFound = false;

		// find running WFs with certain process name for given PBO
		Enumeration eProcesses = WfEngineHelper.service.getAssociatedProcesses(pbo, WfState.OPEN_RUNNING);
		while (eProcesses.hasMoreElements()) {
			WfProcess aWfProcess = (WfProcess) eProcesses.nextElement();
			if (aWfProcess.getName().equals(wfName)) {
				if (bProcessFound) {
					throw new WTException("more than one WfProcess found named '" + wfName + "' on PBO=" + pbo);
				}
				bProcessFound = true;
				ProcessData pd = (ProcessData) aWfProcess.getContext();
				WfVariable[] wfvars = pd.getVariableList();
				for (int i = 0; i < wfvars.length; i++) {
					returnMap.put(wfvars[i].getName(), wfvars[i].getValue());
				}
			}
		}
		if (!bProcessFound) {
			throw new WTException("no WfProcess found named '" + wfName + "' on PBO=" + pbo);
		}

		return returnMap;
	}

	/**
	 * searches running workflow processes where the given 'pbo' is the primary
	 * business object and that are named like the given 'wfName' if no process
	 * is found, exception is thrown if more than one process is found,
	 * exception is thrown if exactly one process is found, the value of the
	 * process variable named like given 'procvarName' is returned
	 *
	 * @param wfName
	 * @param obj
	 * @param procvarName
	 * @throws WTException
	 */
	public static Object getProcessVariable(String wfName, Persistable pbo, String procvarName) throws WTException {
		Object returnValue = null;
		boolean bProcessFound = false;

		// find running WFs with certain process name for given PBO
		Enumeration eProcesses = WfEngineHelper.service.getAssociatedProcesses(pbo, WfState.OPEN_RUNNING);
		while (eProcesses.hasMoreElements()) {
			WfProcess aWfProcess = (WfProcess) eProcesses.nextElement();
			if (aWfProcess.getName().equals(wfName)) {
				if (bProcessFound) {
					throw new WTException("more than one WfProcess found named '" + wfName + "' on PBO=" + pbo);
				}
				bProcessFound = true;
				ProcessData pd = (ProcessData) aWfProcess.getContext();
				returnValue = pd.getValue(procvarName);
			}
		}
		if (!bProcessFound) {
			throw new WTException("no WfProcess found named '" + wfName + "' on PBO=" + pbo);
		}

		return returnValue;
	}
	
	/**
	 * set name of the process
	 * 
	 * @param process
	 * @param name
	 */
	public static void setProcessName(ObjectReference process, String name){
		Object object = process.getObject();
		if(object instanceof WfProcess){
			WfProcess selfProcess = (WfProcess) object ;
			selfProcess.setName(name);
			try {
				PersistenceHelper.manager.save(selfProcess);
			} catch (WTException e) {
				logger.error("failed to set process name - this might only lead to a wrong label of a workflow task, no functional problem here");
				e.printStackTrace();
			}
		}
	}

	public static void main(String args[]) {
		try {
			WTPrincipal user = AuthenticationHelper.authenticateUser(args);
			System.out.println("authenticated as: " + user.getName());
		} catch (WTException w) {
			System.out.println("could not authenticate user. Exception:" + w.getLocalizedMessage());
			w.printStackTrace();
			System.exit(1);
		}

		String action = null;
		String wftpname = null;
		String wfname = null;
		String sPbo = null;
		String sPart = null;
		boolean useContext=false; //default
		for (int j = 0; j < args.length; j++) {
			if (args[j].equals("-action")) {
				if (++j < args.length) {
					action = args[j];
				}
			} else if (args[j].equals("-wftpname")) {
				if (++j < args.length) {
					wftpname = args[j];
				}
			} else if (args[j].equals("-wfname")) {
				if (++j < args.length) {
					wfname = args[j];
				}
			} else if (args[j].equals("-pbo")) {
				if (++j < args.length) {
					sPbo = args[j];
				}
				// this code is for a specific usecase, but it should have no
				// influence to the general mechanism
			} else if (args[j].equals("-part")) {
				if (++j < args.length) {
					sPart = args[j];
				}
			} else if(args[j++].equals("+useContext")) {
			   useContext=true;
			}
		}

		if(wfname==null || wfname.length()==0) {
			System.out.println("ERROR: no wfname given");
			printUsage(); //includes System.exit(1);
		}
		if(sPbo==null || sPbo.length()==0) {
			System.out.println("ERROR: no pbo given");
			printUsage(); //includes System.exit(1);
		}

		// init WTContext and set locale
		WTContext.init(args);

		try {
			WTReference ref = RF.getReference(sPbo);
			if(ref==null) {
				throw new WTException("ref for sPbo is null");
			}
			Persistable pbo = ref.getObject();
			if(!(pbo instanceof LifeCycleManaged)) {
				throw new WTException("pbo is not LifeCycleManaged");
			}

			// this code is for a specific usecase, but it should have no
			// influence to the general mechanism
			Persistable part = null;
			if(sPart!=null && sPart.length()!=0) {
				ref = RF.getReference(sPart);
				if(ref!=null) {
					part = ref.getObject();
					if(!(part instanceof WTPart)) {
						throw new WTException("part is not WTPart");
					}
				}
			}
			System.out.println("action=" + action);
			if (action.equalsIgnoreCase("START")) {
				if (wftpname == null || wftpname.length() == 0) {
					System.out.println("ERROR: no wftpname given");
					printUsage(); // includes System.exit(1);
				}
			HashMap wfVars = new HashMap();
			wfVars.put("primaryBusinessObject", pbo);
				// this code is for a specific usecase, but it should have no
				// influence to the general mechanism
			if(part!=null) {
				wfVars.put("part", part);
			}
				WfProcess process = WfHelper.startProcess(wftpname, (LifeCycleManaged) pbo, wfname, "started: "
						+ System.currentTimeMillis(), wfVars, useContext);
			System.out.println("process was started: " + process);
			} else if (action.equalsIgnoreCase("TERMINATE")) {
				Vector v = WfHelper.terminateProcesses(wfname, pbo);
				for (int i = 0, n = v.size(); i < n; i++) {
					System.out.println("PROCESS WAS TERMINATED: " + v.elementAt(i));
				}
			} else if (action.equalsIgnoreCase("SHOWVARS")) {
				Map m = WfHelper.getProcessVariables(wfname, pbo);
				System.out.println("PROCESS VARS: " + m);
			}
		} catch (WTException w) {
			w.printStackTrace();
			printUsage();
		}
		System.exit(0);
	}

	public static void printUsage() {
		System.out.println("windchill com.ptc.generic.WfHelper -u <username> -p <pwd> -action [START|TERMINATE|SHOWVARS] -wftpname <wf template name> -wfname <wf name> -pbo <oid> [+useContext]");
		System.out.println("  example: create + start a WfProcess (started on Site context):");
		System.out.println("    windchill com.ptc.generic.WfHelper -u PA01 -p ptc -action START -wftpname \"My WF Template\" -wfname \"WF Name\" -pbo \"wt.part.WTPart:1234\"");
		System.out.println("  example: create + start a WfProcess in the context of the primaryBusinessObject:");
		System.out.println("    windchill com.ptc.generic.WfHelper -u PA01 -p ptc -action START -wftpname \"My WF Template\" -wfname \"WF Name\" -pbo \"wt.part.WTPart:1234\" +useContext");
		System.out.println("  example: terminate a running WfProcess named 'myProcess' that has the given PBO");
		System.out.println("    windchill com.ptc.generic.WfHelper -u wcadmin -p wcadmin -action TERMINATE -wfname \"myProcess\" -pbo \"wt.part.WTPart:1234\"");
		System.out.println("  example: show all process-variables of the running WfProcess named 'myProcess' that has the given PBO");
		System.out.println("    windchill com.ptc.generic.WfHelper -u wcadmin -p wcadmin -action SHOWVARS -wfname \"myProcess\" -pbo \"wt.part.WTPart:1234\"");
		System.exit(1);
	}

	/**
	 * Rename a workflow activity Add a prefix
	 *
	 * @param objectReference
	 *            the workflow activity
	 * @param prefix
	 *            the prefix
	 * @throws WTException
	 */
	public static void renameWfActivity(ObjectReference objectReference, String prefix) throws WTException {

		// get Activity
		Object object = objectReference.getObject();
		if (object instanceof WfActivity) {
			WfActivity myActivity = (WfActivity) objectReference.getObject();
			// get ID of PBO
			myActivity.setName(prefix + ": " + myActivity.getName());
			// save the activity
			PersistenceHelper.manager.save(myActivity);
		}

	}

	/**
	 * Rename a workflow activity Add a prefix
	 *
	 * @param objectReference
	 *            the workflow activity
	 * @param prefix
	 *            the prefix
	 * @throws WTException
	 */
	public static void setWfActivityName(ObjectReference objectReference, String newName) throws WTException {

		// get Activity
		Object object = objectReference.getObject();
		if (object instanceof WfActivity) {
			WfActivity myActivity = (WfActivity) objectReference.getObject();
			// get ID of PBO
			myActivity.setName(newName);
			// save the activity
			PersistenceHelper.manager.save(myActivity);
		}

	}

	/**
	 * Set a workflow activitys instructions
	 *
	 * @param objectReference
	 *            the workflow activity
	 * @param prefix
	 *            the prefix
	 * @throws WTPropertyVetoException
	 * @throws WTException
	 */
	public static void setWfActivityInstructions(WfAssignedActivity wfAssignedActivity, String newInstructions) throws WTPropertyVetoException, WTException {
		if (wfAssignedActivity instanceof WfAssignedActivity) {
			WfAssignedActivity myActivity = (WfAssignedActivity) wfAssignedActivity;
			// get ID of PBO
			myActivity.setInstructions(newInstructions);
			// save the activity
			PersistenceHelper.manager.save(myActivity);
		}

	}



    /**
     * Tries to find processes in given state, equal to given name, related to given
     * business object.
     *
     * @param wfProcessName
     * @param primaryBusinessObject
     * @param state
     * @return
     * @throws QueryException
     * @throws WTException
     */
    public static QueryResult findWfProcesses(String wfProcessName, Persistable primaryBusinessObject, WfState state)
            throws WTException {
        return (findWfProcesses(wfProcessName, primaryBusinessObject, state, SearchCondition.EQUAL));
    }

    /**
     * Tries to find processes in given state, equal or like to given name, related to given
     * business object.
     *
     * @param wfProcessName
     * @param primaryBusinessObject
     * @param state
     * @param processNameSearchingMode (ex. SearchCondition.EQUAL)
     * @return
     * @throws QueryException
     * @throws WTException
     */
    public static QueryResult findWfProcesses(String wfProcessName, Persistable primaryBusinessObject, WfState state, String processNameSearchingMode)
            throws WTException {

        boolean append = false;
        QuerySpec querySpec = new QuerySpec(WfProcess.class);
        try {
            // first condition - find processes with given name
            if (wfProcessName != null) {
                SearchCondition wfProcessNameSC = new SearchCondition(WfProcess.class, WfExecutionObject.NAME,
                        processNameSearchingMode, wfProcessName);
                querySpec.appendWhere(wfProcessNameSC, new int[]{0});
                append = true;
            }

            // second condition - find processes related to given business
            // object
            if (primaryBusinessObject != null) {
                String pboReference = null;
                // in Uebergabe prozess it should be always WTPart.
                // WTPart could be iterated in meantime.
                // Get the part master of it. The same part master has
                // been stored during creation of process.
                if (primaryBusinessObject instanceof WTPart) {
                    WTPart part = (WTPart) primaryBusinessObject;
                    pboReference = RF.getReferenceString((WTPartMaster) part.getMaster());
                } else {
                    pboReference = RF.getReferenceString(primaryBusinessObject);
                    if (primaryBusinessObject instanceof Workable) {
                        if (WorkInProgressHelper.isWorkingCopy((Workable) primaryBusinessObject)) {
                                Persistable obj = VersionControlHelper.service.predecessorOf((Iterated) primaryBusinessObject);
                                if (obj != null) {
                                    pboReference = RF.getReferenceString(obj);
                                }
                        }
                    }
                }
                SearchCondition relatedPBO = new SearchCondition(WfProcess.class, "businessObjReference",
                        SearchCondition.EQUAL, pboReference);
                if (append) {
                    querySpec.appendAnd();
                }
                querySpec.appendWhere(relatedPBO, new int[]{0});
                append = true;
            }

            // third condition - find process in given state
            if (state != null) {
                SearchCondition wfState = new SearchCondition(WfProcess.class, WfExecutionObject.STATE,
                        SearchCondition.EQUAL, state);
                if (append) {
                    querySpec.appendAnd();
                }
                querySpec.appendWhere(wfState, new int[]{0});
            }
        } catch (QueryException qEx) {
            throw new WTException(qEx);
        }

        return PersistenceHelper.manager.find((StatementSpec) querySpec);
    }

    /**
     * Tries to find processes in given state, like given name, related to given
     * business object.
     *
     * @param wfProcessName
     * @param primaryBusinessObject
     * @param state
     * @return
     * @throws QueryException
     * @throws WTException
     */
    public static QueryResult findWfProcessesLike(String wfProcessName, Persistable primaryBusinessObject, WfState state)
            throws WTException {
        return (findWfProcesses(wfProcessName, primaryBusinessObject, state, SearchCondition.LIKE));
    }

    /**
     * Get choice that current logged in user made in passed in activity.
     * It will only return one and last choice for current user
     * (from SessionHelper.manager.getPrincipalReference())
     *
     * @param activity Activity to get user vote from
     * @return User vote value or null if no vote found
     * (vote will be a Routing Event value from workflow)
     * @throws WTException
     */
    public static String getCurrentUserChoice(WfAssignedActivity activity)
            throws WTException {
        String choice = null;
        WTPrincipalReference principalReference = SessionHelper.manager.getPrincipalReference();
        // <editor-fold defaultstate="collapsed" desc="Logging">
        if (logger.isDebugEnabled()) {
            logger.debug("Get " + principalReference.getName() + "user choice for activity: " + activity.getName());
        }// </editor-fold>
        Enumeration<WfAssignment> assignments = activity.getAssignments();
        while (assignments.hasMoreElements()) {
            WfAssignment assignment = assignments.nextElement();
            Enumeration<WfBallot> ballots = assignment.getBallots();
            while (ballots.hasMoreElements()) {
                WfBallot ballot = ballots.nextElement();
                if (principalReference.equals(ballot.getVoter())) {
                    List<String> eventList = ballot.getEventList();
                    if (eventList != null && !eventList.isEmpty()) {
                        choice = eventList.get(0);
                    }
                }
            }
        }

        // <editor-fold defaultstate="collapsed" desc="Logging">
        if (logger.isDebugEnabled()) {
            logger.debug("User choice was: " + choice);
        }// </editor-fold>
        return choice;
    }
    
    /**
     * Tries to find an open work item for a current user using the given
     * parameters:<br><code>processId</code> to define a right process an
     * assigned activity with a given <code>taskName</code> corresponds to.
     * 
     * @param processId
     * @param taskName
     * @return
     * @throws WTException
     * @throws WTPropertyVetoException 
     */
    public static QueryResult getAssignedTasks(String processId, String taskNameSuffix) throws WTException, WTPropertyVetoException {
        
        Long processID = Long.parseLong(processId);
        Long userID = new Long(SessionHelper.getPrincipal().getPersistInfo().getObjectIdentifier().getId());

        return getAssignedTaskOfUser(taskNameSuffix, processID, userID);
    }

	public static QueryResult getAssignedTaskOfUser(String taskNameSuffix, Long processID, Long userID)
			throws QueryException, WTException {
		QuerySpec querySpec = new QuerySpec();

        int workItemIndex = querySpec.appendClassList(WorkItem.class, true);
        int assignedActivityIndex = querySpec.appendClassList(WfAssignedActivity.class, false);
             
        querySpec.appendWhere(new SearchCondition(WfAssignedActivity.class, WfAssignedActivity.NAME, SearchCondition.LIKE, "%" + taskNameSuffix + "%"), new int[]{assignedActivityIndex});
        querySpec.appendAnd();
        querySpec.appendWhere(new SearchCondition(WfAssignedActivity.class, "parentProcessRef.key.id", SearchCondition.EQUAL, processID), new int[]{assignedActivityIndex});
        querySpec.appendAnd();
        querySpec.appendWhere(new SearchCondition(WorkItem.class, "ownership.owner.key.id", SearchCondition.EQUAL, userID), new int[]{workItemIndex});
        querySpec.appendAnd();
        querySpec.appendWhere(new SearchCondition(WfAssignedActivity.class, WTAttributeNameIfc.ID_NAME, WorkItem.class, "source.key.id"), new int[]{assignedActivityIndex, workItemIndex});
        querySpec.appendAnd();
        querySpec.appendWhere(new SearchCondition(WorkItem.class, WorkItem.STATUS, SearchCondition.EQUAL, WfAssignmentState.POTENTIAL), new int[]{workItemIndex});

        return PersistenceHelper.manager.find((StatementSpec) querySpec);
	}
}