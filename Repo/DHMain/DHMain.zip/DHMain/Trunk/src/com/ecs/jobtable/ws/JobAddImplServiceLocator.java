/**
 * JobAddImplServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ecs.jobtable.ws;

public class JobAddImplServiceLocator extends org.apache.axis.client.Service implements com.ecs.jobtable.ws.JobAddImplService {

	public JobAddImplServiceLocator() {
	}

	public JobAddImplServiceLocator(org.apache.axis.EngineConfiguration config) {
		super(config);
	}

	public JobAddImplServiceLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
		super(wsdlLoc, sName);
	}

	// Use to get a proxy class for JobAddImplPort
	private java.lang.String JobAddImplPort_address = "http://mucs70029.corp.knorr-bremse.com:1080/pid/addjob";

	public java.lang.String getJobAddImplPortAddress() {
		return JobAddImplPort_address;
	}

	// The WSDD service name defaults to the port name.
	private java.lang.String JobAddImplPortWSDDServiceName = "JobAddImplPort";

	public java.lang.String getJobAddImplPortWSDDServiceName() {
		return JobAddImplPortWSDDServiceName;
	}

	public void setJobAddImplPortWSDDServiceName(java.lang.String name) {
		JobAddImplPortWSDDServiceName = name;
	}

	public com.ecs.pi.ERPXPDM20.SOAPRequest_Out_Async_MI getJobAddImplPort() throws javax.xml.rpc.ServiceException {
		java.net.URL endpoint;
		try {
			endpoint = new java.net.URL(JobAddImplPort_address);
		} catch (java.net.MalformedURLException e) {
			throw new javax.xml.rpc.ServiceException(e);
		}
		return getJobAddImplPort(endpoint);
	}

	public com.ecs.pi.ERPXPDM20.SOAPRequest_Out_Async_MI getJobAddImplPort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
		try {
			com.ecs.jobtable.ws.JobAddImplPortBindingStub _stub = new com.ecs.jobtable.ws.JobAddImplPortBindingStub(portAddress, this);
			_stub.setPortName(getJobAddImplPortWSDDServiceName());
			return _stub;
		} catch (org.apache.axis.AxisFault e) {
			return null;
		}
	}

	public void setJobAddImplPortEndpointAddress(java.lang.String address) {
		JobAddImplPort_address = address;
	}

	/**
	 * For the given interface, get the stub implementation. If this service has
	 * no port for the given interface, then ServiceException is thrown.
	 */
	public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
		try {
			if (com.ecs.pi.ERPXPDM20.SOAPRequest_Out_Async_MI.class.isAssignableFrom(serviceEndpointInterface)) {
				com.ecs.jobtable.ws.JobAddImplPortBindingStub _stub = new com.ecs.jobtable.ws.JobAddImplPortBindingStub(new java.net.URL(JobAddImplPort_address), this);
				_stub.setPortName(getJobAddImplPortWSDDServiceName());
				return _stub;
			}
		} catch (java.lang.Throwable t) {
			throw new javax.xml.rpc.ServiceException(t);
		}
		throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
	}

	/**
	 * For the given interface, get the stub implementation. If this service has
	 * no port for the given interface, then ServiceException is thrown.
	 */
	public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
		if (portName == null) {
			return getPort(serviceEndpointInterface);
		}
		java.lang.String inputPortName = portName.getLocalPart();
		if ("JobAddImplPort".equals(inputPortName)) {
			return getJobAddImplPort();
		} else {
			java.rmi.Remote _stub = getPort(serviceEndpointInterface);
			((org.apache.axis.client.Stub) _stub).setPortName(portName);
			return _stub;
		}
	}

	public javax.xml.namespace.QName getServiceName() {
		return new javax.xml.namespace.QName("http://ws.jobtable.ecs.com/", "JobAddImplService");
	}

	private java.util.HashSet ports = null;

	public java.util.Iterator getPorts() {
		if (ports == null) {
			ports = new java.util.HashSet();
			ports.add(new javax.xml.namespace.QName("http://ws.jobtable.ecs.com/", "JobAddImplPort"));
		}
		return ports.iterator();
	}

	/**
	 * Set the endpoint address for the specified port name.
	 */
	public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {

		if ("JobAddImplPort".equals(portName)) {
			setJobAddImplPortEndpointAddress(address);
		} else { // Unknown Port Name
			throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
		}
	}

	/**
	 * Set the endpoint address for the specified port name.
	 */
	public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
		setEndpointAddress(portName.getLocalPart(), address);
	}

}
