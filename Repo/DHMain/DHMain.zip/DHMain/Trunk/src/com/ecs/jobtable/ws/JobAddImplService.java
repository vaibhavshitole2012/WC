/**
 * JobAddImplService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ecs.jobtable.ws;

public interface JobAddImplService extends javax.xml.rpc.Service {
	public java.lang.String getJobAddImplPortAddress();

	public com.ecs.pi.ERPXPDM20.SOAPRequest_Out_Async_MI getJobAddImplPort() throws javax.xml.rpc.ServiceException;

	public com.ecs.pi.ERPXPDM20.SOAPRequest_Out_Async_MI getJobAddImplPort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
