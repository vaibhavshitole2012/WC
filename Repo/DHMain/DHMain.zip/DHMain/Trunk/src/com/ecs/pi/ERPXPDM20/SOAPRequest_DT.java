/**
 * SOAPRequest_DT.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ecs.pi.ERPXPDM20;

public class SOAPRequest_DT  implements java.io.Serializable {
    private java.lang.String system;

    private java.lang.String objectType;

    private java.lang.String objectID;

    private java.lang.String action;

    private java.lang.String userID;

    private java.lang.String email;

    private java.lang.String[] target;

    private java.lang.String jobID;

    private java.lang.String dynpar01;

    private java.lang.String dynpar02;

    private java.lang.String dynpar03;

    private java.lang.String dynpar04;

    private java.lang.String dynpar05;

    private java.lang.String dynpar06;

    private java.lang.String jobStatus;

    private java.lang.String comments;

    public SOAPRequest_DT() {
    }

    public SOAPRequest_DT(
           java.lang.String system,
           java.lang.String objectType,
           java.lang.String objectID,
           java.lang.String action,
           java.lang.String userID,
           java.lang.String email,
           java.lang.String[] target,
           java.lang.String jobID,
           java.lang.String dynpar01,
           java.lang.String dynpar02,
           java.lang.String dynpar03,
           java.lang.String dynpar04,
           java.lang.String dynpar05,
           java.lang.String dynpar06,
           java.lang.String jobStatus,
           java.lang.String comments) {
           this.system = system;
           this.objectType = objectType;
           this.objectID = objectID;
           this.action = action;
           this.userID = userID;
           this.email = email;
           this.target = target;
           this.jobID = jobID;
           this.dynpar01 = dynpar01;
           this.dynpar02 = dynpar02;
           this.dynpar03 = dynpar03;
           this.dynpar04 = dynpar04;
           this.dynpar05 = dynpar05;
           this.dynpar06 = dynpar06;
           this.jobStatus = jobStatus;
           this.comments = comments;
    }

    /**
     * Gets the system value for this SOAPRequest_DT.
     * 
     * @return system
     */
    public java.lang.String getSystem() {
        return system;
    }


    /**
     * Sets the system value for this SOAPRequest_DT.
     * 
     * @param system
     */
    public void setSystem(java.lang.String system) {
        this.system = system;
    }


    /**
     * Gets the objectType value for this SOAPRequest_DT.
     * 
     * @return objectType
     */
    public java.lang.String getObjectType() {
        return objectType;
    }


    /**
     * Sets the objectType value for this SOAPRequest_DT.
     * 
     * @param objectType
     */
    public void setObjectType(java.lang.String objectType) {
        this.objectType = objectType;
    }


    /**
     * Gets the objectID value for this SOAPRequest_DT.
     * 
     * @return objectID
     */
    public java.lang.String getObjectID() {
        return objectID;
    }


    /**
     * Sets the objectID value for this SOAPRequest_DT.
     * 
     * @param objectID
     */
    public void setObjectID(java.lang.String objectID) {
        this.objectID = objectID;
    }


    /**
     * Gets the action value for this SOAPRequest_DT.
     * 
     * @return action
     */
    public java.lang.String getAction() {
        return action;
    }


    /**
     * Sets the action value for this SOAPRequest_DT.
     * 
     * @param action
     */
    public void setAction(java.lang.String action) {
        this.action = action;
    }


    /**
     * Gets the userID value for this SOAPRequest_DT.
     * 
     * @return userID
     */
    public java.lang.String getUserID() {
        return userID;
    }


    /**
     * Sets the userID value for this SOAPRequest_DT.
     * 
     * @param userID
     */
    public void setUserID(java.lang.String userID) {
        this.userID = userID;
    }


    /**
     * Gets the email value for this SOAPRequest_DT.
     * 
     * @return email
     */
    public java.lang.String getEmail() {
        return email;
    }


    /**
     * Sets the email value for this SOAPRequest_DT.
     * 
     * @param email
     */
    public void setEmail(java.lang.String email) {
        this.email = email;
    }


    /**
     * Gets the target value for this SOAPRequest_DT.
     * 
     * @return target
     */
    public java.lang.String[] getTarget() {
        return target;
    }


    /**
     * Sets the target value for this SOAPRequest_DT.
     * 
     * @param target
     */
    public void setTarget(java.lang.String[] target) {
        this.target = target;
    }

    public java.lang.String getTarget(int i) {
        return this.target[i];
    }

    public void setTarget(int i, java.lang.String _value) {
        this.target[i] = _value;
    }


    /**
     * Gets the jobID value for this SOAPRequest_DT.
     * 
     * @return jobID
     */
    public java.lang.String getJobID() {
        return jobID;
    }


    /**
     * Sets the jobID value for this SOAPRequest_DT.
     * 
     * @param jobID
     */
    public void setJobID(java.lang.String jobID) {
        this.jobID = jobID;
    }


    /**
     * Gets the dynpar01 value for this SOAPRequest_DT.
     * 
     * @return dynpar01
     */
    public java.lang.String getDynpar01() {
        return dynpar01;
    }


    /**
     * Sets the dynpar01 value for this SOAPRequest_DT.
     * 
     * @param dynpar01
     */
    public void setDynpar01(java.lang.String dynpar01) {
        this.dynpar01 = dynpar01;
    }


    /**
     * Gets the dynpar02 value for this SOAPRequest_DT.
     * 
     * @return dynpar02
     */
    public java.lang.String getDynpar02() {
        return dynpar02;
    }


    /**
     * Sets the dynpar02 value for this SOAPRequest_DT.
     * 
     * @param dynpar02
     */
    public void setDynpar02(java.lang.String dynpar02) {
        this.dynpar02 = dynpar02;
    }


    /**
     * Gets the dynpar03 value for this SOAPRequest_DT.
     * 
     * @return dynpar03
     */
    public java.lang.String getDynpar03() {
        return dynpar03;
    }


    /**
     * Sets the dynpar03 value for this SOAPRequest_DT.
     * 
     * @param dynpar03
     */
    public void setDynpar03(java.lang.String dynpar03) {
        this.dynpar03 = dynpar03;
    }


    /**
     * Gets the dynpar04 value for this SOAPRequest_DT.
     * 
     * @return dynpar04
     */
    public java.lang.String getDynpar04() {
        return dynpar04;
    }


    /**
     * Sets the dynpar04 value for this SOAPRequest_DT.
     * 
     * @param dynpar04
     */
    public void setDynpar04(java.lang.String dynpar04) {
        this.dynpar04 = dynpar04;
    }


    /**
     * Gets the dynpar05 value for this SOAPRequest_DT.
     * 
     * @return dynpar05
     */
    public java.lang.String getDynpar05() {
        return dynpar05;
    }


    /**
     * Sets the dynpar05 value for this SOAPRequest_DT.
     * 
     * @param dynpar05
     */
    public void setDynpar05(java.lang.String dynpar05) {
        this.dynpar05 = dynpar05;
    }


    /**
     * Gets the dynpar06 value for this SOAPRequest_DT.
     * 
     * @return dynpar06
     */
    public java.lang.String getDynpar06() {
        return dynpar06;
    }


    /**
     * Sets the dynpar06 value for this SOAPRequest_DT.
     * 
     * @param dynpar06
     */
    public void setDynpar06(java.lang.String dynpar06) {
        this.dynpar06 = dynpar06;
    }


    /**
     * Gets the jobStatus value for this SOAPRequest_DT.
     * 
     * @return jobStatus
     */
    public java.lang.String getJobStatus() {
        return jobStatus;
    }


    /**
     * Sets the jobStatus value for this SOAPRequest_DT.
     * 
     * @param jobStatus
     */
    public void setJobStatus(java.lang.String jobStatus) {
        this.jobStatus = jobStatus;
    }


    /**
     * Gets the comments value for this SOAPRequest_DT.
     * 
     * @return comments
     */
    public java.lang.String getComments() {
        return comments;
    }


    /**
     * Sets the comments value for this SOAPRequest_DT.
     * 
     * @param comments
     */
    public void setComments(java.lang.String comments) {
        this.comments = comments;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof SOAPRequest_DT)) return false;
        SOAPRequest_DT other = (SOAPRequest_DT) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.system==null && other.getSystem()==null) || 
             (this.system!=null &&
              this.system.equals(other.getSystem()))) &&
            ((this.objectType==null && other.getObjectType()==null) || 
             (this.objectType!=null &&
              this.objectType.equals(other.getObjectType()))) &&
            ((this.objectID==null && other.getObjectID()==null) || 
             (this.objectID!=null &&
              this.objectID.equals(other.getObjectID()))) &&
            ((this.action==null && other.getAction()==null) || 
             (this.action!=null &&
              this.action.equals(other.getAction()))) &&
            ((this.userID==null && other.getUserID()==null) || 
             (this.userID!=null &&
              this.userID.equals(other.getUserID()))) &&
            ((this.email==null && other.getEmail()==null) || 
             (this.email!=null &&
              this.email.equals(other.getEmail()))) &&
            ((this.target==null && other.getTarget()==null) || 
             (this.target!=null &&
              java.util.Arrays.equals(this.target, other.getTarget()))) &&
            ((this.jobID==null && other.getJobID()==null) || 
             (this.jobID!=null &&
              this.jobID.equals(other.getJobID()))) &&
            ((this.dynpar01==null && other.getDynpar01()==null) || 
             (this.dynpar01!=null &&
              this.dynpar01.equals(other.getDynpar01()))) &&
            ((this.dynpar02==null && other.getDynpar02()==null) || 
             (this.dynpar02!=null &&
              this.dynpar02.equals(other.getDynpar02()))) &&
            ((this.dynpar03==null && other.getDynpar03()==null) || 
             (this.dynpar03!=null &&
              this.dynpar03.equals(other.getDynpar03()))) &&
            ((this.dynpar04==null && other.getDynpar04()==null) || 
             (this.dynpar04!=null &&
              this.dynpar04.equals(other.getDynpar04()))) &&
            ((this.dynpar05==null && other.getDynpar05()==null) || 
             (this.dynpar05!=null &&
              this.dynpar05.equals(other.getDynpar05()))) &&
            ((this.dynpar06==null && other.getDynpar06()==null) || 
             (this.dynpar06!=null &&
              this.dynpar06.equals(other.getDynpar06()))) &&
            ((this.jobStatus==null && other.getJobStatus()==null) || 
             (this.jobStatus!=null &&
              this.jobStatus.equals(other.getJobStatus()))) &&
            ((this.comments==null && other.getComments()==null) || 
             (this.comments!=null &&
              this.comments.equals(other.getComments())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getSystem() != null) {
            _hashCode += getSystem().hashCode();
        }
        if (getObjectType() != null) {
            _hashCode += getObjectType().hashCode();
        }
        if (getObjectID() != null) {
            _hashCode += getObjectID().hashCode();
        }
        if (getAction() != null) {
            _hashCode += getAction().hashCode();
        }
        if (getUserID() != null) {
            _hashCode += getUserID().hashCode();
        }
        if (getEmail() != null) {
            _hashCode += getEmail().hashCode();
        }
        if (getTarget() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getTarget());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getTarget(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getJobID() != null) {
            _hashCode += getJobID().hashCode();
        }
        if (getDynpar01() != null) {
            _hashCode += getDynpar01().hashCode();
        }
        if (getDynpar02() != null) {
            _hashCode += getDynpar02().hashCode();
        }
        if (getDynpar03() != null) {
            _hashCode += getDynpar03().hashCode();
        }
        if (getDynpar04() != null) {
            _hashCode += getDynpar04().hashCode();
        }
        if (getDynpar05() != null) {
            _hashCode += getDynpar05().hashCode();
        }
        if (getDynpar06() != null) {
            _hashCode += getDynpar06().hashCode();
        }
        if (getJobStatus() != null) {
            _hashCode += getJobStatus().hashCode();
        }
        if (getComments() != null) {
            _hashCode += getComments().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(SOAPRequest_DT.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://ecs.com/pi/ERPXPDM20", "SOAPRequest_DT"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("system");
        elemField.setXmlName(new javax.xml.namespace.QName("", "system"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("objectType");
        elemField.setXmlName(new javax.xml.namespace.QName("", "objectType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("objectID");
        elemField.setXmlName(new javax.xml.namespace.QName("", "objectID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("action");
        elemField.setXmlName(new javax.xml.namespace.QName("", "action"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userID");
        elemField.setXmlName(new javax.xml.namespace.QName("", "userID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("email");
        elemField.setXmlName(new javax.xml.namespace.QName("", "email"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("target");
        elemField.setXmlName(new javax.xml.namespace.QName("", "target"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("jobID");
        elemField.setXmlName(new javax.xml.namespace.QName("", "jobID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dynpar01");
        elemField.setXmlName(new javax.xml.namespace.QName("", "dynpar01"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dynpar02");
        elemField.setXmlName(new javax.xml.namespace.QName("", "dynpar02"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dynpar03");
        elemField.setXmlName(new javax.xml.namespace.QName("", "dynpar03"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dynpar04");
        elemField.setXmlName(new javax.xml.namespace.QName("", "dynpar04"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dynpar05");
        elemField.setXmlName(new javax.xml.namespace.QName("", "dynpar05"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dynpar06");
        elemField.setXmlName(new javax.xml.namespace.QName("", "dynpar06"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("jobStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("", "jobStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("comments");
        elemField.setXmlName(new javax.xml.namespace.QName("", "comments"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }
}
