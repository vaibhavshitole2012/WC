/**
 * SOAPResponse_DT.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ecs.pi.ERPXPDM20;

public class SOAPResponse_DT implements java.io.Serializable {
	private java.lang.String jobID;

	private java.lang.String error;

	private java.lang.String errorType;

	public SOAPResponse_DT() {
	}

	public SOAPResponse_DT(java.lang.String jobID, java.lang.String error, java.lang.String errorType) {
		this.jobID = jobID;
		this.error = error;
		this.errorType = errorType;
	}

	/**
	 * Gets the jobID value for this SOAPResponse_DT.
	 * 
	 * @return jobID
	 */
	public java.lang.String getJobID() {
		return jobID;
	}

	/**
	 * Sets the jobID value for this SOAPResponse_DT.
	 * 
	 * @param jobID
	 */
	public void setJobID(java.lang.String jobID) {
		this.jobID = jobID;
	}

	/**
	 * Gets the error value for this SOAPResponse_DT.
	 * 
	 * @return error
	 */
	public java.lang.String getError() {
		return error;
	}

	/**
	 * Sets the error value for this SOAPResponse_DT.
	 * 
	 * @param error
	 */
	public void setError(java.lang.String error) {
		this.error = error;
	}

	/**
	 * Gets the errorType value for this SOAPResponse_DT.
	 * 
	 * @return errorType
	 */
	public java.lang.String getErrorType() {
		return errorType;
	}

	/**
	 * Sets the errorType value for this SOAPResponse_DT.
	 * 
	 * @param errorType
	 */
	public void setErrorType(java.lang.String errorType) {
		this.errorType = errorType;
	}

	private java.lang.Object __equalsCalc = null;

	public synchronized boolean equals(java.lang.Object obj) {
		if (!(obj instanceof SOAPResponse_DT))
			return false;
		SOAPResponse_DT other = (SOAPResponse_DT) obj;
		if (obj == null)
			return false;
		if (this == obj)
			return true;
		if (__equalsCalc != null) {
			return (__equalsCalc == obj);
		}
		__equalsCalc = obj;
		boolean _equals;
		_equals = true && ((this.jobID == null && other.getJobID() == null) || (this.jobID != null && this.jobID.equals(other.getJobID()))) && ((this.error == null && other.getError() == null) || (this.error != null && this.error.equals(other.getError())))
				&& ((this.errorType == null && other.getErrorType() == null) || (this.errorType != null && this.errorType.equals(other.getErrorType())));
		__equalsCalc = null;
		return _equals;
	}

	private boolean __hashCodeCalc = false;

	public synchronized int hashCode() {
		if (__hashCodeCalc) {
			return 0;
		}
		__hashCodeCalc = true;
		int _hashCode = 1;
		if (getJobID() != null) {
			_hashCode += getJobID().hashCode();
		}
		if (getError() != null) {
			_hashCode += getError().hashCode();
		}
		if (getErrorType() != null) {
			_hashCode += getErrorType().hashCode();
		}
		__hashCodeCalc = false;
		return _hashCode;
	}

	// Type metadata
	private static org.apache.axis.description.TypeDesc typeDesc = new org.apache.axis.description.TypeDesc(SOAPResponse_DT.class, true);

	static {
		typeDesc.setXmlType(new javax.xml.namespace.QName("http://ecs.com/pi/ERPXPDM20", "SOAPResponse_DT"));
		org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
		elemField.setFieldName("jobID");
		elemField.setXmlName(new javax.xml.namespace.QName("", "jobID"));
		elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
		elemField.setMinOccurs(0);
		elemField.setNillable(false);
		typeDesc.addFieldDesc(elemField);
		elemField = new org.apache.axis.description.ElementDesc();
		elemField.setFieldName("error");
		elemField.setXmlName(new javax.xml.namespace.QName("", "error"));
		elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
		elemField.setMinOccurs(0);
		elemField.setNillable(false);
		typeDesc.addFieldDesc(elemField);
		elemField = new org.apache.axis.description.ElementDesc();
		elemField.setFieldName("errorType");
		elemField.setXmlName(new javax.xml.namespace.QName("", "errorType"));
		elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
		elemField.setMinOccurs(0);
		elemField.setNillable(false);
		typeDesc.addFieldDesc(elemField);
	}

	/**
	 * Return type metadata object
	 */
	public static org.apache.axis.description.TypeDesc getTypeDesc() {
		return typeDesc;
	}

	/**
	 * Get Custom Serializer
	 */
	public static org.apache.axis.encoding.Serializer getSerializer(java.lang.String mechType, java.lang.Class _javaType, javax.xml.namespace.QName _xmlType) {
		return new org.apache.axis.encoding.ser.BeanSerializer(_javaType, _xmlType, typeDesc);
	}

	/**
	 * Get Custom Deserializer
	 */
	public static org.apache.axis.encoding.Deserializer getDeserializer(java.lang.String mechType, java.lang.Class _javaType, javax.xml.namespace.QName _xmlType) {
		return new org.apache.axis.encoding.ser.BeanDeserializer(_javaType, _xmlType, typeDesc);
	}

}
