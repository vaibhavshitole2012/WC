package ext.kb.businessrule.validation;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.collections.map.HashedMap;
import org.apache.log4j.Logger;

import wt.change2.ChangeRecord2;
import wt.change2.WTChangeActivity2;
import wt.enterprise.RevisionControlled;
import wt.epm.EPMDocConfigSpec;
import wt.epm.EPMDocument;
import wt.epm.EPMDocumentMaster;
import wt.epm.structure.EPMStructureHelper;
import wt.epm.workspaces.EPMAsStoredConfigSpec;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.fc.collections.WTCollection;
import wt.fc.collections.WTHashSet;
import wt.lifecycle.LifeCycleManaged;
import wt.lifecycle.State;
import wt.log4j.LogR;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.WTPropertyVetoException;
import wt.vc.Iterated;
import wt.vc.VersionControlHelper;
import wt.vc.config.ConfigSpec;

import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.core.businessRules.feedback.RuleFeedbackType;
import com.ptc.core.businessRules.validation.BOMReleaseRuleValidator;
import com.ptc.core.businessRules.validation.RuleValidationCriteria;
import com.ptc.core.businessRules.validation.RuleValidationKey;
import com.ptc.core.businessRules.validation.RuleValidationObject;
import com.ptc.core.businessRules.validation.RuleValidationResult;
import com.ptc.core.businessRules.validation.RuleValidationStatus;
import com.ptc.core.htmlcomp.util.VersionComparator;
import com.ptc.generic.iba.AttributeService;
import com.ptc.windchill.enterprise.businessRules.businessRulesClientResource;

import ext.kb.businessrule.util.KBBusinessRuleUtil;
import ext.kb.businessrule.validation.dto.KBRuleValidationResult;
import ext.kb.change2.helper.ChangeNoticeUtils;
import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.KBConstants;
import ext.kb.util.KBTypeIdProvider;
import ext.kb.util.KBUtils;
import ext.kb.workflow.ChangeTaskUtils;

public class KB_ORG_AS_STORED_BOMReleaseRuleValidator extends BOMReleaseRuleValidator {

	private static final String TARGET_STATES_MAP = "TARGET_STATES_MAP";
	private static final Logger logger = LogR.getLogger(KB_ORG_AS_STORED_BOMReleaseRuleValidator.class.getName());
	private static final String RESOURCE = "com.ptc.windchill.enterprise.businessRules.businessRulesClientResource";

	@SuppressWarnings("unchecked")
	@Override
	public RuleValidationResult performValidation(RuleValidationKey validationKey,
			RuleValidationObject validationObject, RuleValidationCriteria criteria) throws WTException {
		if (logger.isDebugEnabled()) {
			logger.debug("entering performValidation(RuleValidationKey,RuleValidationObject,RuleValidationCriteria)");
			logger.debug("validationKey: " + validationKey);
		}
		
		// We will use a null status to indicate we need to continue validating
		// the given object, success that the next
		// child object should be processed, and failure if there is a failure.

		ChangeRecord2 record = (ChangeRecord2) validationObject.getTargetObjectLink().getObject();
		WTChangeActivity2 changeActivity2 = (WTChangeActivity2) record.getRoleAObjectRef().getObject();
		Boolean asStoredConfiguration = false;
		Object ibaValue = AttributeService.getAttribute(changeActivity2, "KB_USE_ASSTORED_CONFIGURATION");
		if (ibaValue != null) {
			asStoredConfiguration = (Boolean) ibaValue;
		}
		Persistable persistable = validationObject.getTargetObject().getObject();
		
		Map<Object, State> objStateMap = (Map<Object, State>) validationKey.getProcessingMapValue(TARGET_STATES_MAP);

		if (logger.isDebugEnabled()) {
			logger.debug("validationObject: " + KBUtils.getIdentityWithStateAndRevision((RevisionControlled) persistable));
			logger.debug("criteria: " + criteria);
			logger.debug("targetState: " + objStateMap.get(persistable));
			logger.debug("KB_USE_AS-STORED_CONFIGURATION: " + asStoredConfiguration);
		}
		RuleValidationResult result = new RuleValidationResult(null);
		result.setValidationKey(validationKey);
		result.setTargetObject(validationObject.getTargetObject());
//		KBRuleValidationResult localValidationResult = new KBRuleValidationResult(result);
		// check if the target state is 1035 - no children validation needed
		// then
		boolean isInternalRelease = KBConstants.INTERNAL_RELEASED_STATE.equals(objStateMap.get(persistable));
		boolean isCAD = KBTypeIdProvider.isDescendant(persistable, "KBCADDOC");
		if (ibaValue == null || !asStoredConfiguration || isInternalRelease || !isCAD) {
			if (logger.isDebugEnabled()) {
				logger.debug("returning SUCCESS without further validation");
			}
			result.setStatus(RuleValidationStatus.SUCCESS);
			return result;
		}

		Set<State> validSuccessorStates = new HashSet<State>();
		validSuccessorStates.addAll((Set<State>) validationKey.getProcessingMapValue(VALID_DEPENDENT_STATE));
		validSuccessorStates.remove(State.toState("1020"));
		validSuccessorStates.remove(State.toState("1015"));
		// Set<State> validSuccessorStates = new HashSet<State>();
		// validSuccessorStates.add(KBConstants.RELEASED_STATE);
//		Set<State> invalidPredecessorStates = new HashSet<State>();
//		invalidPredecessorStates.addAll((Set<State>) validationKey.getProcessingMapValue(INVALID_DEPENDENT_STATE));
//		invalidPredecessorStates.add(State.toState("1020"));
//		invalidPredecessorStates.add(State.toState("1015"));

		Set<State> validDependentStates = (Set<State>) validationKey.getProcessingMapValue(VALID_DEPENDENT_STATE);
		Set<State> invalidDependentStates = (Set<State>) validationKey.getProcessingMapValue(INVALID_DEPENDENT_STATE);
		WTCollection children = new WTHashSet();

		EPMDocConfigSpec configSpec = new EPMDocConfigSpec();
		boolean asStoredConfigExists = true;
//		LatestConfigSpec asd = new LatestConfigSpec();
		try {
			EPMAsStoredConfigSpec asStored = EPMAsStoredConfigSpec.newEPMAsStoredConfigSpec((EPMDocument) persistable);
			logger.debug("asStored configuration found:" + asStored);
			
			if (asStored!=null) {
				configSpec.setAsStoredConfig(asStored);
				configSpec.setAsStoredActive(true);
			} else {
				configSpec.setLatestActive();
				asStoredConfigExists = false;
			}
		} catch (WTPropertyVetoException e1) {
			configSpec.setLatestActive();
			asStoredConfigExists = false;
		}
		logger.debug("asStored configuration found:" + asStoredConfigExists);
		if (!asStoredConfigExists && KBTypeIdProvider.isDescendant(persistable, "KBCADDRW")) {
			logger.error("No asStored configuration found.");
			KBBusinessRuleUtil.setCustomFailureResult(RESOURCE, result, businessRulesClientResource.NO_AS_STRORED_SPEC,
					KBUtils.getIdentityWithStateAndRevision((RevisionControlled) persistable), validSuccessorStates);
			return result;
		}
		
		ArrayList<ConfigSpec> configSpecList = new ArrayList<ConfigSpec>();
		configSpecList.add(configSpec);
		
		QueryResult dependatnObjectQueryResult = null;
		if (KBTypeIdProvider.isDescendant(persistable, "KBCADDRW")) {
			dependatnObjectQueryResult = EPMStructureHelper.service.navigateReferencesToIteration((EPMDocument) persistable, null, true, configSpec);
		} else if (KBTypeIdProvider.isDescendant(persistable, "KBCADDOC")) {
			dependatnObjectQueryResult = EPMStructureHelper.service.navigateUsesToIteration((EPMDocument)persistable, null, true, configSpec);
		}
		
		QueryResult changeContext = ChangeTaskUtils.getActivitiesFromChangeContext(changeActivity2);
		WTHashSet resultingObjectsInContext = ChangeTaskUtils.getResultingObjects(changeContext);
		
		if (dependatnObjectQueryResult != null) {
			while (dependatnObjectQueryResult.hasMoreElements()) {
				Object dependantObj = dependatnObjectQueryResult.nextElement();
				if (dependantObj instanceof EPMDocument) {
					EPMDocument dependantEPM = (EPMDocument) dependantObj;
					if (!children.contains(dependantEPM)) {
						children.add(dependantEPM);
						if (logger.isDebugEnabled()) {
							logger.debug("Added:" + KBUtils.getIdentityWithStateAndRevision(dependantEPM));
						}
					}
				}
			}	
		}
		 if (logger.isDebugEnabled()){
			 logger.debug("children size=" + children.size());
		}

//		List<EPMDocument> objectsToCheckSuccessorRevisions = new ArrayList<EPMDocument>();
		Iterator<EPMDocument> iter = children.persistableIterator(EPMDocument.class, true);
		while (iter.hasNext()) {
//			RuleValidationResult currentResult = new RuleValidationResult(null);
			EPMDocument lcm = iter.next();
//			validateDependentKB(lcm, currentResult, validDependentStates, invalidDependentStates, objStateMap);

			ChangeRecord2 cr = ChangeNoticeUtils.getChangeRecord(lcm);
			 RuleFeedbackMessage error = null;
			 String objectnumber = lcm.getNumber();
			 
			 //	a) if this is a result object in the same Change Context --> validate�its release target ������
			 if (cr != null && resultingObjectsInContext.contains(lcm)){
				 String targetTransition = "";
				 if (cr.getTargetTransition() != null){
					 targetTransition = cr.getTargetTransition().toString();
				 }
				 if (logger.isDebugEnabled()){
					 logger.debug(objectnumber + " dependent object is IN the Change Context, validating target transition " + targetTransition);
				 }
				 if (targetTransition.isEmpty() || !KBBusinessRuleUtil.isStateValid(targetTransition, validDependentStates, invalidDependentStates)){
					 if (logger.isDebugEnabled()){
						 logger.debug("INVALID targetTransition: " + targetTransition);
					 }
					 error = new RuleFeedbackMessage(new WTMessage("ext.kb.resources.BusinessRuleRB", BusinessRuleRB.KB_CHILD_INVALID_TARGET_STATE, new Object[] {objectnumber,targetTransition}), RuleFeedbackType.ERROR);
				 }	
			 } else {
				 // else validate�its current state
				 if (logger.isDebugEnabled()){
					 logger.debug(objectnumber + " dependent object is NOT in the Change Context, validating current state " + lcm.getState().toString());
				 }
				 if (lcm.getState().toString().compareTo("1080")<0){
					 //	b) else if BOM Component is in state > 1020 --> validate�its state
					 if (!KBBusinessRuleUtil.isStateValid(lcm.getState().toString(), validDependentStates, invalidDependentStates)){
						 if (logger.isDebugEnabled()){
							 logger.debug("current state is INVALID");
						 }
						 error = new RuleFeedbackMessage(new WTMessage("ext.kb.resources.BusinessRuleRB", BusinessRuleRB.KB_CHILD_INVALID_STATE, new Object[] {objectnumber,lcm.getState().toString()}), RuleFeedbackType.ERROR);
					 }
				 } else {
					// validating successor. valid if it is in 1050.
					QueryResult allVersionsof = VersionControlHelper.service.allVersionsOf(lcm);
					boolean successorInValidStateExists = false;
					while (allVersionsof.hasMoreElements()) {
						EPMDocument compareToVersionOfEpm = (EPMDocument) allVersionsof.nextElement();
						State successorState = compareToVersionOfEpm.getLifeCycleState();
						boolean isLatest = compareToVersionOfEpm.isLatestIteration();
						int compareResult = VersionComparator.getInstance(true).compare(compareToVersionOfEpm, lcm);
						// validPredecessorStates should contain on 1050 at this point, so this is the only valid successor state
						if (validSuccessorStates.contains(successorState) && isLatest && compareResult >0) {
							successorInValidStateExists = true;
						}
					}
					
					if (!successorInValidStateExists) {
						if (logger.isDebugEnabled()) {
							logger.debug("The dependent object does not have valid successors.");
						}
						error = new RuleFeedbackMessage(new WTMessage("ext.kb.resources.BusinessRuleRB", BusinessRuleRB.KB_CHILD_INVALID_STATE, new Object[] {objectnumber,lcm.getState().toString()}), RuleFeedbackType.ERROR);
					} else {
						if (logger.isDebugEnabled()) {
							logger.debug("The dependent object does have valid successors.");
						}
					}
				 }
			 }
			
			 if (error != null){
				 result.setStatus(RuleValidationStatus.FAILURE);
				 result.setTargetObject(validationObject.getTargetObject());
				 result.setValidationKey(validationKey);
				 result.addFeedbackMessage(error);
			 }
		}
			 
			
			
			
			
			
//			// result status == null -> predecessor/successor should be checked
//			if (currentResult.getStatus() == null) {
//				if (KBConstants.RELEASED_STATE.equals(objStateMap.get(persistable))
//						&& KBConstants.INVALID_STATE.equals(lcm.getState().getState())) {
//					objectsToCheckSuccessorRevisions.add(lcm);
//					logger.debug("Parent target lc 1050 and child lc 1080 - checking successor");
//				}
//			} else if (RuleValidationStatus.FAILURE.equals(currentResult.getStatus())) {
//				ValidationReport report = new ValidationReport(lcm, ProblemWith.SELF);
//				localValidationResult.addValidationReport(report);
//			}
//		}
//		logger.debug("result.getStatus():" + localValidationResult.getStatus());
//		for (LifeCycleManaged lf : objectsToCheckSuccessorRevisions) {
//			RuleValidationResult tmpResult = new RuleValidationResult(null);
//			WTSet objectHolder = new WTHashSet();
//			objectHolder.add(lf);
//			validateSuccessorRevisionsKB(tmpResult, validSuccessorStates, invalidSuccessorStates, objectHolder,
//					objStateMap);
//			if (RuleValidationStatus.FAILURE.equals(tmpResult.getStatus())) {
//				ValidationReport report = new ValidationReport(lf, ProblemWith.REVISIONS);
//				localValidationResult.addValidationReport(report);
//			}
//		}
//
//		List<ValidationReport> validationReports = localValidationResult.getValidationReports();
//		final int nrOfConflicts = validationReports.size();
//		if (nrOfConflicts > 0) {
//
//			if (CollectionUtils.isEmpty(validationReports)) {
//				return new RuleValidationResult(RuleValidationStatus.SUCCESS);
//			}
//
//			for (ValidationReport report : localValidationResult.getValidationReports()) {
//				if (report.getTargetObject() instanceof RevisionControlled) {
//
//					RevisionControlled rc = (RevisionControlled) report.getTargetObject();
//					String objectNumber = KBUtils.getObjectNumber(rc);
//					String state = rc.getState().getState().getDisplay(KBUtils.getCurrentLocale());
//					String errorKey = BusinessRuleRB.KB_CHILD_INVALID_STATE;
//					if (ProblemWith.REVISIONS.equals(report.getProblemWith())) {
//						errorKey = BusinessRuleRB.KB_REVISIONS_INVALID_STATE;
//					}
//
//					RuleFeedbackMessage localRuleFeedbackMessage = new RuleFeedbackMessage(
//							new WTMessage("ext.kb.resources.BusinessRuleRB", errorKey, new Object[] { objectNumber, state }),
//							RuleFeedbackType.ERROR);
//					result.addFeedbackMessage(localRuleFeedbackMessage);
//					result.setStatus(RuleValidationStatus.FAILURE);
//				}
//			}
//		} else {
//			result.setStatus(RuleValidationStatus.SUCCESS);
//		}
		if (logger.isDebugEnabled()) {
			logger.debug("exiting performValidation()");
			logger.debug("returning: " + result);
		}
		return result;
	}

	private void validateSuccessorRevisionsKB(RuleValidationResult localValidationResult,
			Set<State> validPredecessorStates, Set<State> invalidPredecessorStates,
			WTCollection objectsToCheckPreviousRevisions, Map<Object, State> objStateMap) {

		if (logger.isDebugEnabled()) {
			logger.debug("Entering validateSuccessorRevisionsKB");
		}
		Iterator iterator = objectsToCheckPreviousRevisions.iterator();
		while (iterator.hasNext()) {
			ObjectReference documentRef = (ObjectReference) iterator.next();
			if (documentRef.getObject() instanceof EPMDocument) {
				EPMDocument validatedEpm = (EPMDocument) documentRef.getObject();

				try {
					QueryResult allVersionsof = VersionControlHelper.service.allVersionsOf(validatedEpm);
					boolean successorInValidStateExists = false;
					while (allVersionsof.hasMoreElements()) {
						EPMDocument compareToVersionOfEpm = (EPMDocument) allVersionsof.nextElement();
						State successorState = compareToVersionOfEpm.getLifeCycleState();
						boolean isLatest = compareToVersionOfEpm.isLatestIteration();
						int compareResult = VersionComparator.getInstance(true).compare(compareToVersionOfEpm, validatedEpm);
						if (validPredecessorStates.contains(successorState) && isLatest && compareResult == 1) {
							successorInValidStateExists = true;
						}
					}

					if (!successorInValidStateExists) {
						KBBusinessRuleUtil.setCustomFailureResult(RESOURCE, localValidationResult,
								businessRulesClientResource.CHILD_INVALID_STATE_CUSTOM, KBUtils.getIdentityWithStateAndRevision(validatedEpm),
								validPredecessorStates);
						if (logger.isDebugEnabled()) {
							logger.debug("The dependent object does not have valid successors.");
						}
					} else {
						if (logger.isDebugEnabled()) {
							logger.debug("The dependent object does have valid successors.");
						}
					}

				} catch (WTException e) {
					e.printStackTrace();
				}
			}
		}

	}

	/**
	 * result's status will be set to failure if the object is in an invalid
	 * state, success if the object is in a valid state, and null if it is in
	 * neither an invalid or valid state
	 */
	void validateDependentKB(LifeCycleManaged lcm, RuleValidationResult result, Set<State> validDependentStates,
			Set<State> invalidDependentStates, Map<Object, State> objStateMap) {

		if (logger.isDebugEnabled()) {
			logger.debug("entering validateDependent()");
			logger.debug("lcm: " + KBUtils.getIdentityWithStateAndRevision((RevisionControlled) lcm));
			logger.debug("result: " + result);
			logger.debug("validDependentStates: " + validDependentStates);
			logger.debug("invalidDependentStates: " + invalidDependentStates);
			logger.debug("objStateMap: " + objStateMap);
		}
		Map<EPMDocumentMaster, State> masterToStateMap = new HashedMap();

		Iterator<Entry<Object, State>> it = objStateMap.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry<Object, State> pair = (Map.Entry<Object, State>) it.next();
			Object key = pair.getKey();
			State value = pair.getValue();
			if (key instanceof EPMDocument) {
				EPMDocumentMaster master = (EPMDocumentMaster) ((EPMDocument) key).getMaster();
				masterToStateMap.put(master, value);
				if (logger.isDebugEnabled()) {
					logger.debug("Added to master map " + master + " state: " + value);
				}
			}
		}
		State childTargetState = masterToStateMap.get((EPMDocumentMaster) ((EPMDocument) lcm).getMaster());
		if (childTargetState == null) {
			childTargetState = objStateMap.containsKey(lcm) ? objStateMap.get(lcm) : lcm.getLifeCycleState();
		}
		if (logger.isDebugEnabled()) {
			logger.debug("childTargetState " + childTargetState);
		}

		if (invalidDependentStates != null && invalidDependentStates.contains(childTargetState)) {
			KBBusinessRuleUtil.setCustomFailureResult(RESOURCE, result, businessRulesClientResource.CHILD_INVALID_STATE_CUSTOM,
					KBUtils.getIdentityWithStateAndRevision((RevisionControlled) lcm), validDependentStates);
			if (logger.isDebugEnabled()) {
				logger.debug("The dependent object is in an invalid state: " + childTargetState);
			}
		} else if (validDependentStates != null && validDependentStates.contains(childTargetState)) {
			result.setStatus(RuleValidationStatus.SUCCESS);
			if (logger.isDebugEnabled()) {
				logger.debug("The dependent object is in a valid state: " + childTargetState);
			}
		}
		if (logger.isDebugEnabled()) {
			logger.debug("exiting validateDependent()");
		}

	}
}
