package ext.kb.change2.form;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.FormProcessingStatus;
import com.ptc.core.components.forms.FormResult;
import com.ptc.core.components.util.FeedbackMessage;
import com.ptc.generic.iba.AttributeService;
import com.ptc.windchill.enterprise.change2.forms.ChangeManagementFormProcessorHelper;
import com.ptc.windchill.enterprise.wizardParticipant.beans.RoleParticipantOid;
import com.ptc.windchill.enterprise.wizardParticipant.delegate.ParticipantSelectionDelegate;
import ext.kb.util.IBAHelper;
import ext.kb.util.KBTeamUtils;
import ext.kb.util.KBType;
import ext.kb.util.KBUtils;
import ext.kb.workflow.ChangeTaskUtils;
import org.apache.log4j.Logger;
import wt.change2.AffectedActivityData;
import wt.change2.ChangeHelper2;
import wt.change2.ChangeRecord2;
import wt.change2.WTChangeActivity2;
import wt.doc.WTDocument;
import wt.enterprise.RevisionControlled;
import wt.fc.Persistable;
import wt.inf.team.ContainerTeamManaged;
import wt.log4j.LogR;
import wt.org.OrganizationOwned;
import wt.org.WTPrincipal;
import wt.project.Role;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.vc.VersionToObjectLink;

import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import static ext.kb.util.KBConstants.*;

public class ChangeTaskFormProcessorHelper {

    protected static final Logger logger = LogR.getLogger(ChangeTaskFormProcessorHelper.class.getName());

    private static final String ASSIGNEE = "ASSIGNEE";
    private static final String ERROR_MESSAGE_ASSIGNEE = "Assignee for the Change Task is required";
    private static final String ERROR_MESSAGE_NAME_LENGTH = "Short description of the Change Task should not be longer than 160 characters";

    private static final Role ASSIGNEE_ROLE = Role.toRole(ASSIGNEE);
    public static final String ACTIVITY_REVIEWER = "changeTask_ReviewerPicker_dn";
    private static final String ERROR_MESSAGE_WF_APPROVER = "User must belong to WF Approver role";
    private static final String ERROR_MESSAGE_UNABLE_TO_SET_READY_FOR_APPROVAL_ATTRIBUTE = "There is an issue with " +
            "setting Ready for Approval value";
    private static final String KB_FIRST_REVISION = "0";
    public static final String CONTENT_TYPE_532 = "532";

    private ChangeTaskFormProcessorHelper() {
    }

    public static void validateChangeTaskName(ObjectBean bean, FormResult result) {
        WTChangeActivity2 changeActivity = (WTChangeActivity2) bean.getObject();
        if (changeActivity.getName().length() > 160) {
            addFeedbackMessage(ERROR_MESSAGE_NAME_LENGTH, result);
        }
    }

    public static void validateChangeTaskAssignee(ObjectBean bean, FormResult result) throws WTException {
        ParticipantSelectionDelegate selectionDelegate = ParticipantSelectionDelegate.newInstance(bean);
        HashMap<Role, Set<RoleParticipantOid>> userSelected = selectionDelegate.getUserSelected();
        logger.debug(String.format("Selected principals: %s", userSelected));

        if (!userSelected.keySet().contains(ASSIGNEE_ROLE)) {
            addFeedbackMessage(ERROR_MESSAGE_ASSIGNEE, result);
        }
    }

    private static void addFeedbackMessage(String message, FormResult result) {
        FeedbackMessage feedback = new FeedbackMessage();
        feedback.addMessage(message);
        result.addFeedbackMessage(feedback);
        result.setStatus(FormProcessingStatus.FAILURE);
    }

    public static boolean isUserInWFApproverRole(ObjectBean bean, FormResult result) throws WTException {
        WTChangeActivity2 activity = (WTChangeActivity2) bean.getObject();
        WTPrincipal approver = ChangeManagementFormProcessorHelper.getUser(ACTIVITY_REVIEWER, bean);
        boolean isWfApprover = KBTeamUtils.isUserInRole(approver, (ContainerTeamManaged) activity
                .getContainer(), CAD_APPROVE_ROLE);
        if (!isWfApprover) {
            addFeedbackMessage(ERROR_MESSAGE_WF_APPROVER, result);
        }
        return isWfApprover;
    }

    public static void handleReadyForApprovalValue(ObjectBean bean, FormResult result) {
        WTChangeActivity2 activity = (WTChangeActivity2) bean.getObject();
        Set<Object> resultingObjects = ChangeTaskUtils.getResultingObjects(activity, true);
        Iterator<Object> iterator = resultingObjects.iterator();
        while (iterator.hasNext()) {
            RevisionControlled revisionControlled = (RevisionControlled) iterator.next();
            String value = revisionControlled.getVersionIdentifier().getValue();
            if (!KB_FIRST_REVISION.equals(value)) {
                return;
            }
        }
        try {
            IBAHelper.setIba(activity, "KB_APPROVAL_READY", true);
        } catch (WTException | RemoteException | WTPropertyVetoException e) {
            e.printStackTrace();
            addFeedbackMessage(ERROR_MESSAGE_WF_APPROVER, result);
        }
    }

    public static void removeSystemBomFromAffected(WTChangeActivity2 changeTask) throws WTException {
        Set<Object> resultingObjects = ChangeTaskUtils.getAffectedObjects(changeTask, false);
        List<Object> filteredList = resultingObjects.stream()
                .filter(affectedLink -> isSystemBom((VersionToObjectLink) affectedLink))
                .collect(Collectors.toList());
        for (Object affected : filteredList) {
            ChangeHelper2.service.deleteAffectedActivityData((AffectedActivityData) affected);
        }
    }

    public static void removeSystemBomFromResulting(WTChangeActivity2 changeTask) throws WTException {
        Set<Object> resultingObjects = ChangeTaskUtils.getResultingObjects(changeTask, false);
        List<Object> filteredList = resultingObjects.stream()
                .filter(changeLink -> isSystemBom((VersionToObjectLink) changeLink))
                .collect(Collectors.toList());
        for (Object changeRecord : filteredList) {
            ChangeHelper2.service.deleteChangeRecord((ChangeRecord2) changeRecord);
        }
    }

    private static boolean isSystemBom(VersionToObjectLink link) {
        Persistable roleBObject = link.getRoleBObject();
        String contentType= AttributeService.getAttribute(roleBObject, DOC_CONTENT_TYPE);
        return roleBObject instanceof WTDocument && CONTENT_TYPE_532.equals(contentType) && KBType
                .isOfType(roleBObject, KBSALES_DOCUMENT) && KBUtils.isInOrg((OrganizationOwned) roleBObject, "KB");
    }

}
