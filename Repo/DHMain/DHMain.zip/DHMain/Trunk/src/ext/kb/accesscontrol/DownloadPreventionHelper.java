package ext.kb.accesscontrol;


import com.ptc.core.meta.common.TypeIdentifierHelper;
import com.ptc.windchill.wp.delivery.DeliveryRecord;
import ext.kb.util.KBConstants;
import ext.kb.util.KBUtils;
import org.apache.log4j.Logger;
import wt.access.AccessPermission;
import wt.admin.AdminDomainRef;
import wt.content.*;
import wt.doc.WTDocument;
import wt.enterprise.RevisionControlled;
import wt.epm.EPMDocument;
import wt.events.eventNotificationDelegates.StandardEventNotificationDelegate;
import wt.events.eventNotificationDelegates.StandardEventNotificationDelegateHeader;
import wt.fc.ObjectReference;
import wt.fc.ObjectVector;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.fc.collections.WTSet;
import wt.inf.container.WTContainer;
import wt.inf.sharing.DataSharingHelper;
import wt.inf.sharing.SharedContainerMap;
import wt.inf.team.ContainerTeam;
import wt.inf.team.ContainerTeamHelper;
import wt.inf.team.ContainerTeamManaged;
import wt.lifecycle.LifeCycleManaged;
import wt.log4j.LogR;
import wt.org.*;
import wt.part.WTPart;
import wt.project.Role;
import wt.project._Role;
import wt.sandbox.SandboxHelper;
import wt.services.ac.ACRuntimeException;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.WTProperties;
import wt.viewmarkup.DerivedImage;

import java.io.File;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public class DownloadPreventionHelper {
    private static final String KB_ALLOWED_ROLES_PROPERTY_NAME = "shared.objects.download.allowed.roles";
    private static final Logger LOGGER = LogR.getLogger(DownloadPreventionHelper.class.getName());
    private static DownloadPreventionHelper instance;
    private static List<Role> kbAllowedRoles = new ArrayList<>();

    /**
     * Allowed Roles for HVAC Organization, Property Name
     */
    private static final String HVAC_ALLOWED_ROLES_PROPERTY_NAME = "shared.objects.download.allowed.rolesHVAC";

    /**
     * Allowed Roles for HVAC Organization Collection.
     */
    private static List<Role> hvacAllowedRoles = new ArrayList<>();

    /**
     * Allowed Roles for MS Organization, Property Name.
     */
    private static final String MS_ALLOWED_ROLES_PROPERTY_NAME = "shared.objects.download.allowed.rolesMS";

    /**
     * Allowed Roles for MS Organization Collection.
     */
    private static List<Role> msAllowedRoles = new ArrayList<>();

    static {
        try {
            WTProperties props = WTProperties.getLocalProperties();
            String property = props.getProperty(KB_ALLOWED_ROLES_PROPERTY_NAME);
            if (!KBUtils.isEmpty(property)) {
                String[] splitedProperty = property.split(",");
                for (String value : splitedProperty) {
                    if (!KBUtils.isEmpty(value)) {
                        Role role = Role.toRole(value);
                        kbAllowedRoles.add(role);
                    }
                }
            }
            property = props.getProperty(HVAC_ALLOWED_ROLES_PROPERTY_NAME,
                    "PROJ-VIEWER,PROJECT MANAGER,MEMBERS,PROJECT-MEMBER,PROJECT-COLLABORATION-MANAGER");
            if (!KBUtils.isEmpty(property)) {
                String[] splitedProperty = property.split(",");
                for (String value : splitedProperty) {
                    if (!KBUtils.isEmpty(value)) {
                        Role role = Role.toRole(value);
                        hvacAllowedRoles.add(role);
                    }
                }
            }
            property = props.getProperty(MS_ALLOWED_ROLES_PROPERTY_NAME,
                    "COLLABORATION MANAGER,PROJ-AUTHOR,PROJ-DOC-AUTHOR");
            if (!KBUtils.isEmpty(property)) {
                String[] splitedProperty = property.split(",");
                for (String value : splitedProperty) {
                    if (!KBUtils.isEmpty(value)) {
                        Role role = Role.toRole(value);
                        msAllowedRoles.add(role);
                    }
                }
            }
        } catch (IOException ex) {
            throw new ACRuntimeException(
                    "ext.kb.listener.delegate.download.DownloadPreventionListenerDelegate startup failure, check property: shared.objects.download.allowed.roles");
        }

    }

    private DownloadPreventionHelper() {

    }

    public static DownloadPreventionHelper getInstance() {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("entering getInstance()");
        }
        if (instance == null) {
            new DownloadPreventionHelper();
        }
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("exiting getInstance()");
            LOGGER.debug("returning: " + instance);
        }
        return instance;
    }

    public static List<Role> getHvacAllowedRoles() {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("entering getHvacAllowedRoles()");
            LOGGER.debug("exiting getHvacAllowedRoles()");
            LOGGER.debug("returning: " + hvacAllowedRoles);
        }
        return hvacAllowedRoles;
    }

    public static List<Role> getKbAllowedRoles() {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("entering getKbAllowedRoles()");
            LOGGER.debug("exiting getKbAllowedRoles()");
            LOGGER.debug("returning: " + kbAllowedRoles);
        }
        return kbAllowedRoles;
    }

    public static List<Role> getMsAllowedRoles() {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("entering getMsAllowedRoles()");
            LOGGER.debug("exiting getMsAllowedRoles()");
            LOGGER.debug("returning: " + msAllowedRoles);
        }
        return msAllowedRoles;
    }


    public static boolean checkUserIsAllowedToDownload(Persistable contentHolder, WTPrincipal principal) throws WTException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("entering checkUserIsAllowedToDownload(Persistable,WTPrincipal)");
            LOGGER.debug("contentHolder: " + contentHolder);
            LOGGER.debug("principal: " + principal);
        }
        String organization = ((OrganizationOwned) contentHolder).getOrganization().toString();
        if ("KB".equals(organization)) {
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("exiting checkUserIsAllowedToDownload()");
            }
            return checkUserIsAllowedToDownload(contentHolder, principal, getKbAllowedRoles());
        } else if ("HVAC".equals(organization)) {
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("exiting checkUserIsAllowedToDownload()");
            }
            return checkUserIsAllowedToDownload(contentHolder, principal, getHvacAllowedRoles());
        } else if (KBConstants.MS.equals(organization)) {
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("exiting checkUserIsAllowedToDownload()");
            }
            return checkUserIsAllowedToDownload(contentHolder, principal, getMsAllowedRoles());
        } else {
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("exiting checkUserIsAllowedToDownload()");
                LOGGER.debug("returning: " + false);
            }
            return false;
        }
    }

    public static boolean checkUserIsAllowedToDownload(Persistable contentholder, WTPrincipal principal,
                                                       List<Role> allowedRoles) throws WTException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(
                    "entering checkUserIsAllowedToDownload(Persistable,WTPrincipal,List<Role>)");
            LOGGER.debug("contentholder: " + contentholder);
            LOGGER.debug("principal: " + principal);
            LOGGER.debug("allowedRoles: " + allowedRoles);
        }
        boolean shared = DataSharingHelper.isShared(contentholder);
        LOGGER.debug("Found version : " + contentholder);
        LOGGER.debug(" is shared? - " + shared);
        if (shared) {
            HashSet<WTContainer> projectlist = getSharedContainers(contentholder);
            LOGGER.debug("projectlist: " + projectlist.size() + " " + projectlist);

            if (!projectlist.isEmpty()) {
                boolean isUserInAllowedRole = false;
                for (WTContainer proj : projectlist) {
                    isUserInAllowedRole = isUserInAllowedRole(principal, (ContainerTeamManaged) proj, allowedRoles);
                    if (isUserInAllowedRole) {
                        LOGGER.debug("User is in allowed role");
                        if (LOGGER.isDebugEnabled()) {
                            LOGGER.debug("exiting checkUserIsAllowedToDownload()");
                            LOGGER.debug("returning: " + isUserInAllowedRole);
                        }
                        return isUserInAllowedRole;
                    }
                }
            }
        }
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("exiting checkUserIsAllowedToDownload()");
            LOGGER.debug("returning: " + false);
        }
        return false;
    }

    public static AdminDomainRef getSourceDomainRef(Persistable contentHolder) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("entering getSourceDomainRef(Persistable)");
            LOGGER.debug("contentHolder: " + contentHolder);
        }
        AdminDomainRef domainRef = null;
        if (contentHolder instanceof WTDocument) {
            domainRef = ((WTDocument) contentHolder).getDomainRef();

            LOGGER.debug("WTDoc : Admin Domain: " + domainRef.getDescription() + " WTDoc this: " + domainRef.getName());

            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("exiting getSourceDomainRef()");
                LOGGER.debug("returning: " + domainRef);
            }
            return domainRef;
        } else if (contentHolder instanceof DerivedImage) {
            domainRef = ((DerivedImage) contentHolder).getDomainRef();

            LOGGER.debug("DerivedImage Admin Domain: " + domainRef.getDescription() + " DerivedImage this: "
                    + domainRef.getName());

            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("exiting getSourceDomainRef()");
                LOGGER.debug("returning: " + domainRef);
            }
            return domainRef;
        } else if (contentHolder instanceof WTPart) {
            domainRef = ((WTPart) contentHolder).getDomainRef();

            LOGGER.debug("WTPart Admin Domain: " + domainRef.getDescription() + "WTPart this: " + domainRef.getName());

            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("exiting getSourceDomainRef()");
                LOGGER.debug("returning: " + domainRef);
            }
            return domainRef;
        } else {
            domainRef = ((EPMDocument) contentHolder).getDomainRef();

            LOGGER.debug("EPMDocument Admin Domain: " + domainRef.getDescription() + "EPMDocument this: "
                    + domainRef.getName());

            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("exiting getSourceDomainRef()");
                LOGGER.debug("returning: " + domainRef);
            }
            return domainRef;
        }
    }

    public static boolean isUserInRole(WTPrincipal user, ContainerTeamManaged container, Role role) throws WTException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("entering isUserInRole(WTPrincipal,ContainerTeamManaged,Role)");
            LOGGER.debug("user: " + user);
            LOGGER.debug("container: " + container);
            LOGGER.debug("role: " + role);
        }
        ContainerTeam containerTeam = ContainerTeamHelper.service.getContainerTeam(container);
        LOGGER.debug("container :: " + container + " :: Role :: " + role);
        ObjectVector objectvector = new ObjectVector();
        if (containerTeam == null) {
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("exiting isUserInRole()");
                LOGGER.debug("returning: " + false);
            }
            return false;
        }
        Map<?, ?> map = containerTeam.getRolePrincipalMap();
        findContainerTeamPrincipals(map, "roleGroups", objectvector, true);
        Enumeration<WTGroup> roleGroups = objectvector.elements();
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("exiting isUserInRole()");
        }
        return hasRole(roleGroups, user, role);

    }

    private static boolean isUserInAllowedRole(WTPrincipal principal, ContainerTeamManaged projectContainer,
                                               List<Role> allowedRoles) throws WTException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(
                    "entering isUserInAllowedRole(WTPrincipal,ContainerTeamManaged,List<Role>)");
            LOGGER.debug("principal: " + principal);
            LOGGER.debug("projectContainer: " + projectContainer);
            LOGGER.debug("allowedRoles: " + allowedRoles);
        }
        LOGGER.debug("isUserInAllowedRole allowedRoles ::" + DownloadPreventionHelper.getKbAllowedRoles());
        for (Role role : allowedRoles) {
            LOGGER.debug("isUserInAllowedRole :: " + role);
            if (isUserInRole(principal, projectContainer, role)) {
                LOGGER.debug("returning from isUserInAllowedRole --> TRUE");
                if (LOGGER.isDebugEnabled()) {
                    LOGGER.debug("exiting isUserInAllowedRole()");
                    LOGGER.debug("returning: " + true);
                }
                return true;
            }
        }
        LOGGER.debug("returning from isUserInAllowedRole --> FALSE");
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("exiting isUserInAllowedRole()");
            LOGGER.debug("returning: " + false);
        }
        return false;
    }

    /**
     * @param allowedRoles
     * @param document
     * @throws WTException
     */
    public static void checkAccess(List<Role> allowedRoles, final RevisionControlled document) throws WTException {

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("entering checkAccess(List<Role>,RevisionControlled)");
            LOGGER.debug("allowedRoles: " + allowedRoles);
            LOGGER.debug("document: " + document);
        }
        final WTPrincipal principal = SessionHelper.getPrincipal();
        boolean hasAccess = wt.access.AccessControlHelper.manager.hasAccess(principal,
                TypeIdentifierHelper.getType(document).toString(), getSourceDomainRef(document),
                document.getLifeCycleState(), AccessPermission.DOWNLOAD);
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("checking download access for " + principal.getName() + ". Can download ??" + hasAccess);
        }
        if (!hasAccess) {
            DownloadPreventionHelper.checkUserIsAllowedToDownload(document, principal, allowedRoles);
        }
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("exiting checkAccess()");
        }
    }


    private static void findContainerTeamPrincipals(Map<?, ?> map, String group, ObjectVector objectvector,
                                                    boolean flag) throws WTException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(
                    "entering findContainerTeamPrincipals(Map<?,?>,String,ObjectVector,boolean)");
            LOGGER.debug("map: " + map);
            LOGGER.debug("group: \"" + group + "\"");
            LOGGER.debug("objectvector: " + objectvector);
            LOGGER.debug("flag: " + flag);
        }
        Role role = _Role.toRole(group);
        List<?> list = (List<?>) map.get(role);
        if (list != null && !list.isEmpty()) {
            WTPrincipalReference wtprincipalreference = (WTPrincipalReference) list.get(0);
            if (flag) {
                WTPrincipal wtprincipal = wtprincipalreference.getPrincipal();
                Enumeration<?> enumeration = OrganizationServicesHelper.manager.members((WTGroup) wtprincipal, false);
                while (enumeration.hasMoreElements()) {
                    objectvector.addElement(enumeration.nextElement());
                }
            } else {
                objectvector.addElement(wtprincipalreference.getPrincipal());
            }
        }
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("exiting findContainerTeamPrincipals()");
        }
    }

    public static boolean hasRole(Enumeration<WTGroup> roleGroups, WTPrincipal user, Role role) throws WTException {

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("entering hasRole(Enumeration<WTGroup>,WTPrincipal,Role)");
            LOGGER.debug("roleGroups: " + roleGroups);
            LOGGER.debug("user: " + user);
            LOGGER.debug("role: " + role);
        }
        while (roleGroups.hasMoreElements()) {
            WTGroup group = roleGroups.nextElement();
            LOGGER.debug(_Role.toRole(group.getName()));
            if (role.equals(_Role.toRole(group.getName()))) {
                LOGGER.debug("Inside equal");
                if (LOGGER.isDebugEnabled()) {
                    LOGGER.debug("exiting hasRole()");
                }
                return group.isMember(user);
            }
        }
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("exiting hasRole()");
            LOGGER.debug("returning: " + false);
        }
        return false;
    }

    private static HashSet<WTContainer> getSharedContainers(Persistable contentHolder) throws WTException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("entering getSharedContainers(Persistable)");
            LOGGER.debug("contentHolder: " + contentHolder);
        }
        HashSet<WTContainer> sharedContainers = new HashSet<>();
        Collection<Persistable> col = SandboxHelper.service.getInteropObjects(contentHolder);
        if (col != null) {
            for (Persistable obj : col) {
                if (obj instanceof SharedContainerMap) {
                    SharedContainerMap scMap = (SharedContainerMap) obj;

                    LOGGER.debug("Container :: " + scMap.getTargetContainerRef().getReferencedContainer()
                            + " :: Container Org ::"
                            + scMap.getTargetContainerRef().getReferencedContainer().getOrganizationName());

                    sharedContainers.add(scMap.getTargetContainerRef().getReferencedContainer());
                    LOGGER.debug("Shared Container found: " + scMap.getTargetContainerRef().getReferencedContainer());

                }
            }
        }

        LOGGER.debug("Number of Shared containers found: " + sharedContainers.size());
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("exiting getSharedContainers()");
            LOGGER.debug("returning: " + sharedContainers);
        }
        return sharedContainers;
    }


    public static boolean skipListener(ContentServiceEvent cse) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("entering skipListener(ContentServiceEvent)");
            LOGGER.debug("cse: " + cse);
        }
        boolean skip = false;


        String eventKey = cse.getEventKey();
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("eventKey: " + eventKey);
            LOGGER.debug("objectTarget: " + cse.getEventTarget());

        }
        if ("*/wt.content.ContentServiceEvent/READ_CONTENT".equals(eventKey)) {
            try {
                Collection<StandardEventNotificationDelegate> standardEventNotificationDelegates = (Collection<StandardEventNotificationDelegate>) cse.getAllEventNotificationDelegates();
                if (!standardEventNotificationDelegates.isEmpty()) {
                    StandardEventNotificationDelegate next = standardEventNotificationDelegates.iterator().next();
                    StandardEventNotificationDelegateHeader header = next.getHeader();
                    if (header != null) {
                        ArrayList transactionDescription = header.getTransactionDescription();
                        if (transactionDescription.size() > 0) {
                            Iterator iterator = transactionDescription.iterator();
                            while (iterator.hasNext()) {
                                WTMessage message = (WTMessage) iterator.next();
                                String messageIdentifier = message.getMessageIdentifier();
                                if ("com.ptc.netmarkets.wp.wpResource/PACKAGE_EXPORT_SUMMARY_EVENT_MESSAGE".equals(messageIdentifier)) {
                                    skip = true;
                                }
                            }
                        }
                    }
                }
            } catch (WTException e) {
                e.printStackTrace();
            }
        } else if ("*/wt.content.ContentServiceEvent/PRE_DOWNLOAD".equals(eventKey)) {
            StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
            skip = Arrays.stream(stackTrace).map(stackTraceElement -> stackTraceElement.getClassName())
                    .anyMatch(s -> s.equals("com.ptc.windchill.wp.delivery.export.AbstractDeliveryExportDelegate"));
        }
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("return: " + skip);
            LOGGER.debug("exiting skipListener()");
            LOGGER.debug("returning: " + skip);
        }
        return skip;
    }

    private static void deleteContentFromZip(Path path, String name) throws IOException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("entering deleteContentFromZip(Path,String)");
            LOGGER.debug("path: " + path);
            LOGGER.debug("name: \"" + name + "\"");
        }
        try (FileSystem zipFileSystem = FileSystems.newFileSystem(path, null)) {
            Path pathInZipFile = zipFileSystem.getPath(name);
            Files.delete(pathInZipFile);
        }
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("exiting deleteContentFromZip()");
        }
    }


    public static void handleZipInDelivery(Iterator iterator) throws WTException, IOException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("entering handleZipInDelivery(Iterator)");
            LOGGER.debug("iterator: " + iterator);
        }
        ObjectReference objectReference = (ObjectReference) iterator.next();
        Object object = objectReference.getObject();
        DeliveryRecord deliveryRecord;
        if (object instanceof DeliveryRecord) {
            deliveryRecord = (DeliveryRecord) object;
        } else {
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("exiting handleZipInDelivery()");
            }
            return;
        }
        WTPrincipal principal = SessionHelper.getPrincipal();
        WTSet membersForSync = deliveryRecord.getMembersForSync();
        Set<String> excludedContents = new HashSet<>();
        Iterator membersForSyncIterator = membersForSync.stream().iterator();

        while (membersForSyncIterator.hasNext()) {
            ObjectReference deliveryContentMemberReference = (ObjectReference) membersForSyncIterator.next();
            Persistable deliveryContentMember = getDeliveryContentMember(deliveryContentMemberReference);
            boolean hasAccess = wt.access.AccessControlHelper.manager.hasAccess(principal,
                    TypeIdentifierHelper.getType(deliveryContentMember).toString(), DownloadPreventionHelper.getSourceDomainRef(deliveryContentMember),
                    ((LifeCycleManaged) deliveryContentMember).getLifeCycleState(), AccessPermission.DOWNLOAD);
            boolean isUSerAllowedToDownload = DownloadPreventionHelper.checkUserIsAllowedToDownload(deliveryContentMember, principal);
            if (hasAccess || isUSerAllowedToDownload) {
                if (LOGGER.isDebugEnabled()) {
                    LOGGER.debug("exiting handleZipInDelivery()");
                }
                return;
            } else {
                if (deliveryContentMember instanceof WTDocument) {
                    WTDocument doc = (WTDocument) deliveryContentMember;
                    String number = doc.getNumber();
                    number = number.substring(0, number.indexOf("-"));
                    if (LOGGER.isDebugEnabled()) {
                        LOGGER.debug("Number: " + number);
                    }
                    excludedContents.add(number);
                    excludedContents.add(number.toLowerCase());
                }
                if (deliveryContentMember instanceof EPMDocument) {
                    EPMDocument epm = (EPMDocument) deliveryContentMember;
                    String number = epm.getNumber();
                    number = number.substring(0, number.indexOf("-"));
                    if (LOGGER.isDebugEnabled()) {
                        LOGGER.debug("Number: " + number);
                    }
                    excludedContents.add(number);
                    excludedContents.add(number.toLowerCase());
                }
                excludedContents.add(".pvz");
            }
        }
        QueryResult contents = ContentHelper.service.getContentsByRole(deliveryRecord, ContentRoleType.SECONDARY);
        removePermittedFilesFromContent(excludedContents, contents);
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("exiting handleZipInDelivery()");
        }
    }

    private static Persistable getDeliveryContentMember(ObjectReference deliveryContentMemberReference) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("entering getDeliveryContentMember(ObjectReference)");
            LOGGER.debug("deliveryContentMemberReference: " + deliveryContentMemberReference);
        }
        Object deliveryContentObject = deliveryContentMemberReference.getObject();
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("exiting getDeliveryContentMember()");
        }
        return deliveryContentObject instanceof DerivedImage ?
                ((DerivedImage) deliveryContentObject).getRepresentable() : (Persistable) deliveryContentObject;
    }

    private static void removePermittedFilesFromContent(Set<String> excludedContents, QueryResult contents) throws WTException, IOException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("entering removePermittedFilesFromContent(Set<String>,QueryResult)");
            LOGGER.debug("excludedContents: " + excludedContents);
            LOGGER.debug("contents: " + contents);
        }
        if (contents.hasMoreElements()) {
            ApplicationData applicationData = (ApplicationData) contents.nextElement();
            File file = ContentServerHelper.service.getStoredItemFile(applicationData).getPhysicalFile();
            ZipFile zipFile = new ZipFile(file);
            String zipFileName = zipFile.getName();
            Path path = Paths.get(zipFileName);
            Enumeration<? extends ZipEntry> entries = zipFile.entries();
            Set<String> fileNames = new HashSet<>();
            while (entries.hasMoreElements()) {
                ZipEntry zipEntry = entries.nextElement();
                String name = zipEntry.getName();
                Iterator<String> excludedContentsIterator = excludedContents.iterator();
                while (excludedContentsIterator.hasNext()) {
                    if (name.contains(excludedContentsIterator.next())) {
                        fileNames.add(name);
                    }
                }
            }
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("Names: " + fileNames);
            }
            for (String name : fileNames) {
                DownloadPreventionHelper.deleteContentFromZip(path, name);
            }
        }
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("exiting removePermittedFilesFromContent()");
        }
    }
}
