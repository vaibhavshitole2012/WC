package ext.kb.cost;

import java.util.Iterator;

import wt.fc.ObjectReference;
import wt.fc.collections.WTCollection;
import wt.part.WTPart;
import wt.units.FloatingPointWithUnits;
import wt.util.WTException;
import ext.kb.util.KBConstants;
import ext.kb.util.KBTypeIdProvider;
import ext.kb.util.KBUtils;
import ext.kb.util.SupplierHelper;

import com.ptc.generic.iba.AttributeService;
import com.ptc.windchill.suma.axl.AXLHelper;
import com.ptc.windchill.suma.axl.AXLEntry;
import com.ptc.windchill.suma.axl.AXLPreference;
import com.ptc.windchill.suma.part.VendorPart;

public class CostUtil {

	public static boolean hasRequiredProcurementPart(WTPart part) {
		if (part != null) {
			try {
				if (KBUtils.isArticleCheckRequired(part) || KBTypeIdProvider.isDescendant(part, "STANDARDPART")) {
					WTCollection axlEntries = AXLHelper.service.getAVL(part, null, null);
					if (axlEntries.isEmpty()) {
						return false;
					}

					Iterator<?> entryIteraror = axlEntries.iterator();
					while (entryIteraror.hasNext()) {
						ObjectReference entryRef = (ObjectReference) entryIteraror.next();
						AXLEntry entry = (AXLEntry) entryRef.getObject();
						// this means Sourcing Status is required
						if (entry.getAvlPreference().equals(AXLPreference.PREFERRED)) {
							return true;
						}
					}
					return false;
				}
				throw new RuntimeException("Not correct part type to check for procurement part association");
			} catch (WTException e) {
				throw new RuntimeException(e);
			}
		} else {
			throw new NullPointerException("No part was provided as input parameter");
		}

	}

	public static boolean hasSGGK(WTPart resultingPart) {
		if (!KBTypeIdProvider.isDescendant(resultingPart, "ARTICLE")){
			return false;
		}
		VendorPart requiredProcPart = SupplierHelper.getProcurementPartByAxlPreference(resultingPart, AXLPreference.PREFERRED);
		if (requiredProcPart != null){
			FloatingPointWithUnits estGGK = AttributeService.getAttribute(requiredProcPart, KBConstants.EST_GGK_IBA);
			return estGGK != null;
		}
		return false;
	}
}
