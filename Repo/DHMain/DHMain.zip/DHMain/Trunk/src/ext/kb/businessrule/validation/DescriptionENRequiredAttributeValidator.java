package ext.kb.businessrule.validation;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.ptc.core.businessRules.attributes.AttributeRuleRB;
import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.generic.iba.AttributeService;

import ext.kb.util.KBConstants;
import ext.kb.util.KBTypeIdProvider;
import wt.epm.EPMDocument;
import wt.fc.Persistable;
import wt.log4j.LogR;
import wt.util.WTException;
import wt.util.WTMessage;

public class DescriptionENRequiredAttributeValidator extends KBValidation {

	protected static final Logger LOG = LogR.getLogger(DescriptionENRequiredAttributeValidator.class.getName());
	private static final String ATTRIBUTE_RULE_RESOURCE = "com.ptc.core.businessRules.attributes.AttributeRuleRB";

	@Override
	public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList) throws WTException {
		if (LOG.isDebugEnabled()) {
			LOG.debug("entering isRulesValid(Persistable,Map<String,Set<AttributeRuleSet>>,List<RuleFeedbackMessage>)");
			LOG.debug("paramPersistable: " + paramPersistable);
			LOG.debug("paramMap: " + paramMap);
			LOG.debug("paramList: " + paramList);
		}
		boolean isValid = true;

		boolean isKBArticle = KBTypeIdProvider.isDescendant(paramPersistable, "ARTICLE");
		boolean isKBDocument = KBTypeIdProvider.isDescendant(paramPersistable, "KBDOC");
		boolean isStandardOrCert = KBTypeIdProvider.isDescendant(paramPersistable, "CERTYFICATEDOC")
				|| KBTypeIdProvider.isDescendant(paramPersistable, "STANDARDDOC");
		boolean isEPMDocument = paramPersistable instanceof EPMDocument;
		boolean isValidType = isKBArticle || isKBDocument || isEPMDocument || isStandardOrCert;
		if (isValidType) {
			String descriptionEN = (String) AttributeService.getAttribute(paramPersistable, KBConstants.DESCRIPTION_EN);
			if (LOG.isInfoEnabled()) {
				LOG.info("Description EN: " + descriptionEN);
			}
			if (StringUtils.isEmpty(descriptionEN)) {
				paramList.add(new RuleFeedbackMessage(new WTMessage(ATTRIBUTE_RULE_RESOURCE,
						AttributeRuleRB.NOT_SET_ERROR_MSG, new Object[] { "Description EN" }), getFeedbackType()));
			}
			isValid = CollectionUtils.isEmpty(paramList);
		}

		if (LOG.isDebugEnabled()) {
			LOG.debug("exiting isRulesValid()");
			LOG.debug("returning: " + isValid);
		}
		return isValid;
	}
}
