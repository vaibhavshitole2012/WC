package ext.kb.bom;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.fc.WTReference;
import wt.occurrence.OccurrenceHelper;
import wt.part.LineNumber;
import wt.part.PartUsesOccurrence;
import wt.part.QuantityUnit;
import wt.part.WTPart;
import wt.part.WTPartHelper;
import wt.part.WTPartMaster;
import wt.part.WTPartSubstituteLink;
import wt.part.WTPartUsageLink;
import wt.pom.Transaction;
import wt.util.WTException;
import wt.util.WTProperties;
import wt.util.WTPropertyVetoException;
import wt.vc.VersionControlHelper;
import wt.vc.wip.WorkInProgressHelper;

import com.ptc.core.meta.common.TypeIdentifierHelper;

import ext.kb.service.WebServiceHelper;
import ext.kb.util.IBAHelper;
import ext.kb.util.KBConstants;
import ext.kb.util.KBUtils;

public class BOMHelper {
	private static final Logger LOGGER = Logger.getLogger(BOMHelper.class);
	private static String includeSubstitue = "false";


	static {
		try {
			WTProperties properties = WTProperties.getServerProperties();
			includeSubstitue = properties.getProperty("ext.kb.bom.includesubstitute");

		} catch ( IOException e) {
			LOGGER.error("Problem during read properties from wt.properties file");
		}
	}


	static PrintWriter logPw = null;
	static FileWriter fw = null;
	static BufferedWriter bw = null;

	public static ArrayList<OutputBOMDetails> startProcess(ArrayList<ParentPartObject> parentPartDetails) throws WTException, WTPropertyVetoException{
		LOGGER.debug("includeSubstitue : "+includeSubstitue);
		LOGGER.debug("ReferenceDesignatorHelper :: startProcess ::"+parentPartDetails.size());

		String wtHome = WebServiceHelper.getWindchillHome();
		LOGGER.debug("WT_HOME : "+wtHome);
		String LOG_FILE_NAME = wtHome+"/logs/interface";
		WebServiceHelper.createDirIfNotExisting(LOG_FILE_NAME);
		LOG_FILE_NAME = wtHome+"/logs/interface/ExportBOM.log";

		ArrayList<OutputBOMDetails> outobj=new ArrayList();
		Transaction trx=null;
		if(!outobj.isEmpty()){
			outobj.clear();
		}
		String parentpartnumber="";

		try {
			if(parentPartDetails.size()>0){
				trx=new Transaction();
				trx.start();
				File file = new File(LOG_FILE_NAME);
				file.setExecutable(true, false);
				file.setReadable(true, false);
				file.setWritable(true, false);
				LOGGER.debug("After getting log file ===" + file);
				fw = new FileWriter(LOG_FILE_NAME, true);
				bw = new BufferedWriter(fw);
				logPw = new PrintWriter(bw);

				for(int i=0;i<parentPartDetails.size();i++){
					ParentPartObject object=parentPartDetails.get(i);
					parentpartnumber=object.getParentpartnumber();
					LOGGER.debug("Parent Part number :: "+parentpartnumber);
					logPw.println("Parent Part number :: "+parentpartnumber);
					WTPart parentpart = (WTPart) getObjectByOid(parentpartnumber);
					if(parentpart!=null){
						LOGGER.debug("parentpart Object :: "+parentpart);
						logPw.println("parentpart Object :: "+parentpart);
						boolean isDesignOrNoViewArticle = false;
						if(("Design".equalsIgnoreCase(parentpart.getViewName())) || null == parentpart.getViewName()) {
							logPw.println("setting isDesignOrNoViewArticle "+isDesignOrNoViewArticle);
							isDesignOrNoViewArticle = true;
						}
						QueryResult usesQR=WTPartHelper.service.getUsesWTPartMasters(parentpart);
						LOGGER.debug("Usagelink size :: "+usesQR.size());
						logPw.println("Usagelink size :: "+usesQR.size());
						OutputBOMDetails parentdesobj=new OutputBOMDetails();
						parentdesobj.setParentpartnumber(parentpart.getNumber());
						while(usesQR.hasMoreElements()){
							OutputBOMDetails desobj=new OutputBOMDetails();
							ArrayList substitute = new ArrayList();
							WTPartUsageLink usagelink=(WTPartUsageLink) usesQR.nextElement();
							QueryResult occurenceresult=OccurrenceHelper.service.getUsesOccurrences(usagelink);

							LOGGER.debug("occurenceresult size :: "+occurenceresult.size());
							logPw.println("occurenceresult size :: "+occurenceresult.size());
							ArrayList<String> refdes=new ArrayList<String>();
							while(occurenceresult.hasMoreElements()){

								PartUsesOccurrence obj=(PartUsesOccurrence) occurenceresult.nextElement();
								LOGGER.debug("PartUsesOccurrence ::>>"+obj.getName());
								logPw.println("PartUsesOccurrence ::>>"+obj.getName());
								if(obj.getName()!=null){
									refdes.add(obj.getName());
								}
							}
							WTPartMaster child=usagelink.getUses();
							LOGGER.debug("child number ::"+child.getNumber());
							logPw.println("child number ::"+child.getNumber());
							LOGGER.debug("usagelink :: "+usagelink);
							logPw.println("usagelink :: "+usagelink);
							desobj.setChildpartnumber(child.getNumber());

							VersionControlHelper.service.allVersionsOf(child);
							WTPart childPart = (WTPart) KBUtils.getLatestIteration(child);
							if(isDesignOrNoViewArticle) {
								//retrieving design view part
								childPart = (WTPart)WebServiceHelper.getDesignViewPart(childPart);
							}
							if(childPart != null) {
								LOGGER.debug("ChildPart version : "+childPart.getIterationDisplayIdentifier());
								long obid = childPart.getPersistInfo().getObjectIdentifier().getId();
								LOGGER.debug("obid : "+obid);
								desobj.setObid(obid);
								String version = childPart.getVersionIdentifier().getValue();
								LOGGER.debug("version ; "+version);
								desobj.setVersion(childPart.getVersionIdentifier().getValue());
								String cadCID = IBAHelper.readIBA(childPart, KBConstants.CADIM_CID);
								desobj.setCADIM_CID(cadCID);
								String unit = (QuantityUnit.toQuantityUnit(childPart.getDefaultUnit().toString())).toString();
								LOGGER.debug("UOM : "+unit);
								desobj.setDefaultUnit(unit);
								String mSystem = IBAHelper.readIBA(childPart, KBConstants.KB_MASTERSYSTEM);
								desobj.setMasterSystem(mSystem);
								String partType = TypeIdentifierHelper.getType(childPart).getTypename();
								partType = partType.substring(partType.lastIndexOf("|")+1, partType.length());
								desobj.setType(partType);
								desobj.setState(childPart.getState().getState().toString());

								if(refdes.size()>0){
									desobj.setRefdesignator(refdes);
					} else{
						refdes.add("");
						desobj.setRefdesignator(refdes);
								}
								LineNumber linenumber=usagelink.getLineNumber();
								LOGGER.debug("linenumber : "+linenumber);
								if(linenumber!=null){
									desobj.setLinenumber(Long.toString(linenumber.getValue()));
								}
								else{
									desobj.setLinenumber("");
								}
								String findNumber = usagelink.getFindNumber();
								LOGGER.debug("findNumber : "+findNumber);
								if(findNumber!=null){
									desobj.setFindNumber(findNumber);
								}else{
									desobj.setFindNumber("");
								}
								double quantity = usagelink.getQuantity().getAmount();
								LOGGER.debug("quantity : "+quantity);
								//if(quantity!=null){
								desobj.setQuantity(quantity);
								/*}else{
							desobj.setQuantity(0.0);
						}*/

								String repairFlag = IBAHelper.readIBA(usagelink, KBConstants.KB_REPAIR_FLAG);
								LOGGER.debug("repairFlag : "+repairFlag);
								if(repairFlag!=null){
									desobj.setKB_REPAIR_FLAG(repairFlag);
								}else{
									desobj.setKB_REPAIR_FLAG("");
								}

								String freeText = IBAHelper.readIBA(usagelink, "KB_FREE_TEXT");
								LOGGER.debug("freeText : "+freeText);
								if(freeText!=null){
									desobj.setKB_FREE_TEXT(freeText);
								}else{
									desobj.setKB_FREE_TEXT("");
								}

								String delFlag = IBAHelper.readIBA(usagelink, "KB_DELIVERY_FLAG");
								LOGGER.debug("delFlag : "+delFlag);
								if(delFlag!=null){
									desobj.setKB_DELIVERY_FLAG(delFlag);
								}else{
									desobj.setKB_DELIVERY_FLAG("");
								}

								String remark1 = IBAHelper.readIBA(usagelink, "KB_REMARK_COL1");
								LOGGER.debug("remark1 : "+remark1);
								if(remark1!=null){
									desobj.setKB_REMARK_COL1(remark1);
								}else{
									desobj.setKB_REMARK_COL1("");
								}

								String remark2 = IBAHelper.readIBA(usagelink, "KB_REMARK_COL2");
								LOGGER.debug("remark2 : "+remark2);
								if(remark2!=null){
									desobj.setKB_REMARK_COL2(remark2);
								}else{
									desobj.setKB_REMARK_COL2("");
								}

								String remark3 = IBAHelper.readIBA(usagelink, "KB_REMARK_COL3");
								LOGGER.debug("remark3 : "+remark3);
								if(remark3!=null){
									desobj.setKB_REMARK_COL3(remark3);
								}else{
									desobj.setKB_REMARK_COL3("");
								}

								String remark4 = IBAHelper.readIBA(usagelink, "KB_REMARK_COL4");
								LOGGER.debug("remark4 : "+remark4);
								if(remark4!=null){
									desobj.setKB_REMARK_COL4(remark4);
								}else{
									desobj.setKB_REMARK_COL4("");
								}

								String eleRef = IBAHelper.readIBA(usagelink, "KB_ELECTR_REF");
								LOGGER.debug("eleRef : "+eleRef);
								if(eleRef!=null){
									desobj.setKB_ELECTR_REF(eleRef);
								}else{
									desobj.setKB_ELECTR_REF("");
								}

								if("true".equalsIgnoreCase(includeSubstitue)){
									QueryResult allLinks = PersistenceHelper.manager.navigate(usagelink,
											WTPartSubstituteLink.SUBSTITUTES_ROLE, WTPartSubstituteLink.class, true);
									LOGGER.debug("allLinks size : "+allLinks.size());

									while (allLinks.hasMoreElements()) {
										WTPartMaster obj = (WTPartMaster) allLinks.nextElement();
										WTPart subPart =(WTPart) KBUtils.getLatestIteration(obj);
										subPart.getNumber();
										LOGGER.debug("Got: " + subPart.getNumber());
										if(isDesignOrNoViewArticle){
											//retrieving design view part
											subPart = (WTPart)WebServiceHelper.getDesignViewPart(subPart);
										}
										if(subPart != null) {
											LOGGER.debug("SubPart version : "+subPart.getIterationDisplayIdentifier());
											Substitute subs = new Substitute();
											subs.setPartNumber(subPart.getNumber());
											obid = subPart.getPersistInfo().getObjectIdentifier().getId();
											LOGGER.debug("obid : "+obid);
											subs.setObid(obid);
											version = subPart.getVersionIdentifier().getValue();
											LOGGER.debug("version ; "+version);
											subs.setVersion(version);
											String cadimCID = IBAHelper.readIBA(subPart, KBConstants.CADIM_CID);
											subs.setCADIM_CID(cadimCID);
											String subUnit = (QuantityUnit.toQuantityUnit(subPart.getDefaultUnit().toString())).toString();
											LOGGER.debug("Substitute UOM : "+subUnit);
											subs.setDefaultUnit(subUnit);

											String masterSystem = IBAHelper.readIBA(subPart, KBConstants.KB_MASTERSYSTEM);
											subs.setMasterSystem(masterSystem);
											String type = TypeIdentifierHelper.getType(subPart).getTypename();
											type = type.substring(type.lastIndexOf("|")+1, type.length());
											subs.setPartType(type);
											substitute.add(subs);
										}
									}
									if(substitute!=null){
										desobj.setSubstitute(substitute);
									}
								}
								LOGGER.debug("desobj.setChildpartnumber :: "+desobj.getChildpartnumber());
								logPw.println("desobj.setChildpartnumber :: "+desobj.getChildpartnumber());
								LOGGER.debug("desobj.setRefdesignator :: "+desobj.getRefdesignator());
								logPw.println("desobj.setRefdesignator :: "+desobj.getRefdesignator());
								outobj.add(desobj);

							}
						}
						parentdesobj.setMessage("Success");
						parentdesobj.setReturncode("0");
						outobj.add(0,parentdesobj);
					}
					else{
						OutputBOMDetails desobj=new OutputBOMDetails();
						desobj.setParentpartnumber(parentpartnumber);
						desobj.setReturncode("1");
						desobj.setMessage("Failure : Parent part not found");
						outobj.add(desobj);

					}
				}
				trx.commit();
				trx=null;

			}
		}catch (WTException | IOException e) {
			OutputBOMDetails desobj=new OutputBOMDetails();
			desobj.setParentpartnumber(parentpartnumber);
			desobj.setReturncode("1");
			desobj.setMessage("Failure :"+e.getLocalizedMessage());
			outobj.add(desobj);
		}finally{


			if(trx!=null){
				trx.rollback();
				trx=null;
			}
			logPw.flush();
			logPw.close();



		}


		return outobj;

	}

	public static Persistable getObjectByOid(String oid) {
		Persistable obj = null;
		WTPart part=null;
		try {
			ReferenceFactory referencefactory = new ReferenceFactory();
			WTReference wtreference = referencefactory.getReference(oid);
			obj = wtreference.getObject();
			LOGGER.debug("getObjectByOid object :: "+obj);
			if(obj instanceof WTPart){
				part=(WTPart) obj;
				if(WorkInProgressHelper.isCheckedOut(part)){
					LOGGER.debug("Parent Part :: "+part.getNumber());
					LOGGER.debug("Version :: "+part.getVersionIdentifier().getValue()+"."+part.getIterationIdentifier().getValue());
					logPw.println("Parent Part :: "+part.getNumber());
					logPw.println("Version :: "+part.getVersionIdentifier().getValue()+"."+part.getIterationIdentifier().getValue());
					//	logger.debug("Workingcopy ::"+WorkInProgressHelper.service.workingCopyOf(part));
					//logger.debug("Original copy ::"+WorkInProgressHelper.service.originalCopyOf(part));
					LOGGER.debug("Isworkingcopy :: "+WorkInProgressHelper.isWorkingCopy(part));
					if(WorkInProgressHelper.isWorkingCopy(part)){
						part= (WTPart) WorkInProgressHelper.service.originalCopyOf(part);
					}
					return part;
				}
			}

		} catch ( WTException e) {
			LOGGER.debug("Could not find a object by OID" + e);
		}
		return obj;
	}

}
