package ext.kb.businessrule.validation;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.core.businessRules.feedback.RuleFeedbackType;

import ext.kb.resources.BusinessRuleRB;
import wt.change2.ChangeService2;
import wt.change2.WTChangeActivity2;
import wt.doc.WTDocument;
import wt.epm.EPMDocument;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.fc.WTObject;
import wt.part.WTPart;
import wt.services.ServiceFactory;
import wt.util.WTException;
import wt.util.WTMessage;

public class KBResultingAffectedUniquenessValidator extends KBValidation {
    private static ChangeService2 service = ServiceFactory.getService(ChangeService2.class);
    private static final Logger logger = Logger.getLogger(KBResultingAffectedUniquenessValidator.class);
    private static final String MESSAGE_RESOURCE = "ext.kb.resources.BusinessRuleRB";

    /*
     * Validates if the current resulting and affected object have more than one
     * revision
     */
    @Override
    public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
                                List<RuleFeedbackMessage> paramList) throws WTException {
        if (logger.isDebugEnabled()) {
            logger.debug("paramPersistable: " + paramPersistable);
            logger.debug("paramMap: " + paramMap);
            logger.debug("paramList: " + paramList);
        }
        boolean success = true;
        String message = "";
        List<WTMessage> affectedMessages = new ArrayList<>();
        List<WTMessage> resultingMessages = new ArrayList<>();
        List<String[]> wtPartAffectedArray = new ArrayList<>();
        List<String[]> wtDocumentAffectedArray = new ArrayList<>();
        List<String[]> wtEPMAffectedArray = new ArrayList<>();
        List<String[]> wtPartResultingArray = new ArrayList<>();
        List<String[]> wtDocumentResultingArray = new ArrayList<>();
        List<String[]> wtEPMResultingArray = new ArrayList<>();
        List<String[]> affecteDuplictaes = new ArrayList<>();
        List<String[]> resultingDuplicates = new ArrayList<>();

        if (paramPersistable instanceof WTChangeActivity2) {
            WTChangeActivity2 resItem = (WTChangeActivity2) paramPersistable;
            QueryResult affectedQuery = service.getChangeablesBefore(resItem);
            QueryResult resultingQuery = service.getChangeablesAfter(resItem);
            getObjectsFromQuery(wtPartAffectedArray, wtDocumentAffectedArray, wtEPMAffectedArray, affectedQuery);
            getObjectsFromQuery(wtPartResultingArray, wtDocumentResultingArray, wtEPMResultingArray, resultingQuery);
            getDuplicatesFromArray(wtPartAffectedArray, affecteDuplictaes);
            getDuplicatesFromArray(wtDocumentAffectedArray, affecteDuplictaes);
            getDuplicatesFromArray(wtEPMAffectedArray, affecteDuplictaes);
            getDuplicatesFromArray(wtPartResultingArray, resultingDuplicates);
            getDuplicatesFromArray(wtDocumentResultingArray, resultingDuplicates);
            getDuplicatesFromArray(wtEPMResultingArray, resultingDuplicates);
            if (!resultingDuplicates.isEmpty()) {
                prepareResultingErrorMessage(resultingMessages, resultingDuplicates);
            }
            if (!affecteDuplictaes.isEmpty()) {
                prepareAffectedErrorMessage(affectedMessages, affecteDuplictaes);
            }
        }
        message = createErrorMessage(message, affectedMessages);
        message = createErrorMessage(message, resultingMessages);

        if (!affectedMessages.isEmpty() || !resultingMessages.isEmpty()) {
            success = false;
            addBusinessRuleFeedbackMessage(paramList, message);
        }
        if (logger.isDebugEnabled()) {
            logger.debug("exiting isRulesValid()");
            logger.debug("returning: " + success);
        }
        return success;
    }

    private void addBusinessRuleFeedbackMessage(List<RuleFeedbackMessage> paramList, String message) {
        String header = new WTMessage(MESSAGE_RESOURCE, BusinessRuleRB.RESULTING_AFFECTED_HEADER, null).toString();
        WTMessage wtMessage = new WTMessage(MESSAGE_RESOURCE, BusinessRuleRB.RESULTING_AFFECTED_CONTENT,
                new Object[]{header + message});
        paramList.add(new RuleFeedbackMessage(wtMessage, RuleFeedbackType.ERROR));
    }

    private String createErrorMessage(String message, List<WTMessage> affectedMessages) {
        StringBuilder builder = new StringBuilder(message);
        if (!affectedMessages.isEmpty()) {
            for (WTMessage msg : affectedMessages) {
                builder.append(msg.getLocalizedMessage());
            }
        }
        return builder.toString();
    }

    private void prepareResultingErrorMessage(List<WTMessage> resultingMessages, List<String[]> duplicatesArray) {
        if (logger.isDebugEnabled()) {
            logger.debug("entering prepareResultingErrorMessage(List<RuleFeedbackMessage>,List<String[]>)");
            logger.debug("resultingMessages: " + resultingMessages);
            logger.debug("wtPartAffectedDuplicatesArray: " + duplicatesArray);
        }
        resultingMessages.add(new WTMessage(MESSAGE_RESOURCE, BusinessRuleRB.RESULTING, null));
        for (String[] duplicates : duplicatesArray) {
            resultingMessages.add(new WTMessage(MESSAGE_RESOURCE, BusinessRuleRB.DUPLICATED_RESULTING_OBJECTS,
                    new Object[] { duplicates[0], duplicates[1], duplicates[2], duplicates[3] }));

        }
        if (logger.isDebugEnabled()) {
            logger.debug("exiting prepareResultingErrorMessage()");
        }
    }

    private void prepareAffectedErrorMessage(List<WTMessage> affectedMessages, List<String[]> duplicatesArray) {
        if (logger.isDebugEnabled()) {
            logger.debug("entering prepareAffectedErrorMessage(List<RuleFeedbackMessage>,List<String[]>)");
            logger.debug("affectedMessages: " + affectedMessages);
            logger.debug("wtPartAffectedDuplicatesArray: " + duplicatesArray);
        }
        affectedMessages.add(new WTMessage(MESSAGE_RESOURCE, BusinessRuleRB.AFFECTED, null));
        for (String[] duplicates : duplicatesArray) {
            affectedMessages.add(new WTMessage(MESSAGE_RESOURCE, BusinessRuleRB.DUPLICATED_AFFECTED_OBJECTS,
                    new Object[] { duplicates[0], duplicates[1], duplicates[2], duplicates[3] }));

        }
        if (logger.isDebugEnabled()) {
            logger.debug("exiting prepareAffectedErrorMessage()");
        }
    }

    private void getDuplicatesFromArray(List<String[]> objectsArray, List<String[]> duplicatesArray) {
        if (logger.isDebugEnabled()) {
            logger.debug("entering getDuplicatesFromArray(List<String[]>,List<String[]>)");
            logger.debug("objectsArray: " + objectsArray);
            logger.debug("duplicatesArray: " + duplicatesArray);
        }
        for (String[] string : objectsArray) {
            String number = string[0];
            String revision = string[3];

            for (String[] duplicated : objectsArray) {
                if (number.equalsIgnoreCase(duplicated[0]) && !revision.equalsIgnoreCase(duplicated[3]) && !duplicatesArray.contains(duplicated)) {
                    duplicatesArray.add(duplicated);
                }
            }
        }
        if (logger.isDebugEnabled()) {
            logger.debug("exiting getDuplicatesFromArray()");
        }
    }

    private void getObjectsFromQuery(List<String[]> wtPartAffectedArray, List<String[]> wtDocumentAffectedArray,
                                     List<String[]> wtEPMAffectedArray, QueryResult affectedQuery) {
        if (logger.isDebugEnabled()) {
            logger.debug("entering getObjectsFromQuery(List<String[]>,List<String[]>,List<String[]>,QueryResult)");
            logger.debug("wtPartAffectedArray: " + wtPartAffectedArray);
            logger.debug("wtDocumentAffectedArray: " + wtDocumentAffectedArray);
            logger.debug("wtEPMAffectedArray: " + wtEPMAffectedArray);
            logger.debug("affectedQuery: " + affectedQuery);
        }
        while (affectedQuery.hasMoreElements()) {
            WTObject wtObject = (WTObject) affectedQuery.nextElement();
            if (wtObject instanceof WTPart) {
                getPartBasicAttributes(wtPartAffectedArray, wtObject);
            } else if (wtObject instanceof WTDocument) {
                getDocumentBasicAttributes(wtDocumentAffectedArray, wtObject);
            } else if (wtObject instanceof EPMDocument) {
                getEpmtBasicAttributes(wtEPMAffectedArray, wtObject);
            }
        }
        if (logger.isDebugEnabled()) {
            logger.debug("exiting getObjectsFromQuery()");
        }
    }

    private void getDocumentBasicAttributes(List<String[]> documentArray, WTObject wtObject) {
        if (logger.isDebugEnabled()) {
            logger.debug("entering getEpmtBasicAttributes(List<String[]>,WTObject)");
            logger.debug("documentArray: " + documentArray);
            logger.debug("object: " + wtObject);
        }
        WTDocument wtDocument = (WTDocument) wtObject;
        String[] attributes = new String[4];
        String number = "Document : " + wtDocument.getNumber();
        attributes[0] = number;
        String state = wtDocument.getLifeCycleState().getShortDescription();
        attributes[1] = state;
        String iteration = wtDocument.getIterationIdentifier().getValue();
        attributes[2] = iteration;
        String revision = wtDocument.getVersionIdentifier().getValue();
        attributes[3] = revision;
        documentArray.add(attributes);
        if (logger.isDebugEnabled()) {
            logger.debug("exiting getEpmtBasicAttributes()");
        }

    }

    private void getEpmtBasicAttributes(List<String[]> epmDocumentAffectedArray, WTObject wtObject) {
        if (logger.isDebugEnabled()) {
            logger.debug("entering getDocumentBasicAttributes(List<String[]>,WTObject)");
            logger.debug("epmDocumentAffectedArray: " + epmDocumentAffectedArray);
            logger.debug("wtObject: " + wtObject);
        }
        EPMDocument epmDocument = (EPMDocument) wtObject;
        String[] attributes = new String[4];
        String number = "EPMDocument : " + epmDocument.getNumber();
        attributes[0] = number;
        String state = epmDocument.getLifeCycleState().getShortDescription();
        attributes[1] = state;
        String iteration = epmDocument.getIterationIdentifier().getValue();
        attributes[2] = iteration;
        String revision = epmDocument.getVersionIdentifier().getValue();
        attributes[3] = revision;
        epmDocumentAffectedArray.add(attributes);
        if (logger.isDebugEnabled()) {
            logger.debug("exiting getDocumentBasicAttributes()");
        }

    }

    private void getPartBasicAttributes(List<String[]> wtPartAffectedArray, WTObject wtObject) {
        if (logger.isDebugEnabled()) {
            logger.debug("entering getPartBasicAttributes(List<String[]>,WTObject)");
            logger.debug("wtPartAffectedArray: " + wtPartAffectedArray);
            logger.debug("wtObject: " + wtObject);
        }
        WTPart part = (WTPart) wtObject;
        String[] attributes = new String[4];
        String number = "WTPart : " + part.getNumber();
        attributes[0] = number;
        String state = part.getLifeCycleState().getShortDescription();
        attributes[1] = state;
        String iteration = part.getIterationIdentifier().getValue();
        attributes[2] = iteration;
        String revision = part.getVersionIdentifier().getValue();
        attributes[3] = revision;
        wtPartAffectedArray.add(attributes);
        if (logger.isDebugEnabled()) {
            logger.debug("exiting getPartBasicAttributes()");
        }
    }
}
