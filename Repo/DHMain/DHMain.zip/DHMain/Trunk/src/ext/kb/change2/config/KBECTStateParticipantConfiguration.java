package ext.kb.change2.config;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import com.ptc.core.components.beans.CreateAndEditWizBean;
import com.ptc.core.components.beans.FormDataHolder;
import com.ptc.windchill.enterprise.wizardParticipant.configuration.DefaultParticipantConfiguration;

import ext.kb.util.KBConstants;
import wt.fc.collections.WTHashSet;
import wt.fc.collections.WTSet;
import wt.inf.container.WTContainerRef;
import wt.org.OrganizationOwned;
import wt.project.Role;
import wt.team.RolePoolMap;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;

/**
 * 
 * @author zycha
 *
 */
public class KBECTStateParticipantConfiguration extends DefaultParticipantConfiguration {
	private static final Logger LOGGER = Logger.getLogger(KBECTStateParticipantConfiguration.class.getName());

	@Override
	public Set<Role> excludedWorkflowRoles(FormDataHolder formData) throws WTException {
		HashSet<Role> hashset = new HashSet<Role>();
		hashset.add(Role.toRole("ADDITIONAL APPROVERS"));
		hashset.add(Role.toRole("MANUFACTURING ENGINEER"));
		hashset.add(Role.toRole("RELEASE MANAGER"));
		hashset.add(Role.toRole("WF-NOTIFICATION-RECIPENT"));
		hashset.add(Role.toRole("APPROVER"));
		hashset.add(Role.toRole("DATA MANAGEMENT"));
		hashset.add(KBConstants.BONDING_ENGINEER_ROLE);
		hashset.add(KBConstants.WELDING_ENGINEER_ROLE);
		return hashset;
	}

	@Override
	public Map<Role, Set<Role>> getInitialRoleSelections(FormDataHolder formData) throws WTException {
		HashMap<Role, Set<Role>> roleSelectionMap = (HashMap<Role, Set<Role>>) super.getInitialRoleSelections(formData);
		WTContainerRef containerRef = CreateAndEditWizBean.getContainerRef(formData);
		OrganizationOwned orgOwned = (OrganizationOwned) containerRef.getObject();

		if (KBConstants.KB.equals(orgOwned.getOrganizationName())) {
			roleSelectionMap.put(KBConstants.ASSIGNEE_ROLE, Collections.singleton(KBConstants.ASSIGNEE_ROLE));
			roleSelectionMap.put(KBConstants.REVIEWER_ROLE, Collections.singleton(KBConstants.CAD_APPROVER_ROLE));
		} else if (KBConstants.HVAC.equals(orgOwned.getOrganizationName())) {
			roleSelectionMap.put(KBConstants.ASSIGNEE_ROLE, Collections.singleton(KBConstants.ASSIGNEE_ROLE));
		}
		return roleSelectionMap; 
	}

	/**
	 * Adding roles to be selectable during ECTState creation
	 */
	@Override
	public Map<Role, WTSet> getWorkflowResourcePools(FormDataHolder paramFormDataHolder) throws WTException {
		Map<Role, WTSet> workflowResourcePools = super.getWorkflowResourcePools(paramFormDataHolder);
		WTSet wtSet = workflowResourcePools.get(KBConstants.ASSIGNEE_ROLE);
		if (wtSet == null) {
			wtSet = new WTHashSet();
		}

		RolePoolMap mapCADDesigner = RolePoolMap.newRolePoolMap();
		RolePoolMap mapElectricalEng = RolePoolMap.newRolePoolMap();
		RolePoolMap mapElectroniEng = RolePoolMap.newRolePoolMap();
		RolePoolMap mapSystemEngineer = RolePoolMap.newRolePoolMap();
		RolePoolMap mapProductManagement = RolePoolMap.newRolePoolMap();
		try {
			mapCADDesigner.setRole(KBConstants.CAD_DESIGNER);
			mapProductManagement.setRole(KBConstants.PRODUCT_MANAGEMENT_ROLE);
			mapSystemEngineer.setRole(Role.toRole("SYSTEM ENGINEER"));
			mapElectricalEng.setRole(Role.toRole("ELECTRICAL ENGINEER"));
			mapElectroniEng.setRole(Role.toRole("ELECTRONIC ENGINEER"));
		} catch (WTPropertyVetoException e) {
			LOGGER.error("getWorkflowResourcePools");
			LOGGER.error(e.getLocalizedMessage());
		}

		wtSet.add(mapCADDesigner);
		wtSet.add(mapElectricalEng);
		wtSet.add(mapElectroniEng);
		wtSet.add(mapSystemEngineer);
		wtSet.add(mapProductManagement);

		workflowResourcePools.put(KBConstants.ASSIGNEE_ROLE, wtSet);

		return workflowResourcePools;
	}

}
