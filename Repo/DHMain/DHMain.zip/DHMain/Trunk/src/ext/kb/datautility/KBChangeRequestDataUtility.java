/*@Author : KB Development Team
 * KBChangeRequestDataUtility is authored to display the value of Alias attribute ('KB_ECR_NUMBER') 
 * for only new change created in Windchill 11 system
 */


package ext.kb.datautility;

import org.apache.log4j.Logger;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.dataUtilities.DefaultDataUtility;
import com.ptc.core.lwc.common.OidHelper;
import com.ptc.core.meta.common.TypeIdentifierHelper;

import wt.change2.ChangeHelper2;
import wt.change2.ChangeOrder2;
import wt.change2.ChangeProcessLink;
import wt.change2.ChangeRequest2;
import wt.change2.FlexibleChangeLink;
import wt.change2.WTChangeActivity2;
import wt.change2.WTChangeOrder2;
import wt.change2.WTChangeRequest2;
import wt.change2.flexible.FlexibleChangeHelper;
import wt.fc.ObjectIdentifier;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.log4j.LogR;
import wt.pds.OidHolder;
import wt.query.QuerySpec;
import wt.util.WTException; 

public class KBChangeRequestDataUtility extends DefaultDataUtility  {
	
	private static final Logger LOG = LogR.getLogger(KBChangeRequestDataUtility.class.getName());
	
	@Override
	public Object getDataValue(String arg0, Object changeObj, ModelContext paramModelContext) throws WTException {
		LOG.debug("ENTER KBChangeRequestDataUtility || datautility ID : 'ecrName'");
		String ecrNumber = "";
		if(changeObj instanceof WTChangeActivity2)
		{
			WTChangeActivity2 activity = (WTChangeActivity2)changeObj;
			LOG.debug("activity Name" +activity.getNumber());
			QueryResult qr = ChangeHelper2.service.getChangeOrder(activity);
			while (qr.hasMoreElements()) {
				ChangeOrder2 ecn = (ChangeOrder2) qr.nextElement();
				LOG.debug("Linked ECN Name" +ecn.getNumber());
				QueryResult qrECR = ChangeHelper2.service.getChangeRequest(ecn);
				if(qr.size() == 0)
					return ecrNumber;
				while(qrECR.hasMoreElements()) {
					ChangeRequest2 ecr = (ChangeRequest2) qrECR.nextElement();
					ecrNumber = ecr.getNumber();
					LOG.debug("ecrNumber Name" +ecr.getNumber());
				}
			}
		} else if (changeObj instanceof WTChangeOrder2) {
			WTChangeOrder2 changeNotice = (WTChangeOrder2) changeObj;
			LOG.debug("Change NoticeObject => " + changeNotice.getNumber());
			QueryResult result = ChangeHelper2.service.getChangeRequest(changeNotice);
			if (result.size() > 0) {
				ChangeRequest2 ecr = (ChangeRequest2) result.nextElement();
				ecrNumber = ecr.getNumber();
				LOG.debug("Change RequestObject => " + ecr.getNumber());
			}
					
		}
		LOG.debug("EXIT KBChangeRequestDataUtility");
		return ecrNumber; 
	}
}
