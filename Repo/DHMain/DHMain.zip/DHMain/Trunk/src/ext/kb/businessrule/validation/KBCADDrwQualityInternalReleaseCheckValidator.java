package ext.kb.businessrule.validation;

import java.util.List;
import java.util.Map;
import java.util.Set;
import org.apache.log4j.Logger;
import wt.fc.Persistable;
import wt.log4j.LogR;
import wt.util.WTException;
import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;


public class KBCADDrwQualityInternalReleaseCheckValidator extends KBCADDrwQualityCheckValidator {

    protected static final Logger LOG = LogR.getLogger(KBCADDrwQualityInternalReleaseCheckValidator.class.getName());

    @Override
    public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
                                List<RuleFeedbackMessage> paramList) throws WTException {
        boolean isInternalRelease = true;
        boolean isValid = validateObject(paramPersistable, paramList, isInternalRelease);
        return isValid;

    }

}
