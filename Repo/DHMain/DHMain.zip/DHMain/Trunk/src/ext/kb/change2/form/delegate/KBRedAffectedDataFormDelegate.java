package ext.kb.change2.form.delegate;

import java.util.HashMap;
import java.util.List;

import wt.doc.WTDocument;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.util.WTMessage;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.FormProcessingStatus;
import com.ptc.core.components.forms.FormResult;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import com.ptc.windchill.enterprise.change2.forms.delegates.AffectedDataFormDelegate;

import ext.kb.resources.ActionsRB;
import ext.kb.util.KBTypeIdProvider;
import ext.kb.util.KBUtils;

public class KBRedAffectedDataFormDelegate extends AffectedDataFormDelegate {

    private static final String RESOURCE = "ext.kb.resources.ActionsRB";
    
    @Override
    public FormResult postProcess(NmCommandBean paramNmCommandBean, List<ObjectBean> paramList) throws WTException {
        @SuppressWarnings("unchecked")
        
        Object o = paramList.get(0).getObject();
        if  (KBTypeIdProvider.isDescendant(o, "RED")) {
        	HashMap<String, List<NmOid>> addedItemsMap = paramNmCommandBean.getAddedItems();
            List<NmOid> addedItems = addedItemsMap.get("changeRequest_affectedData_table");
            
            boolean docAttached = false;
            if (!KBUtils.isEmpty(addedItems)) {
                for (NmOid id : addedItems) {
                    if (WTDocument.class.getName().equals(id.getWtRef().getKey().getClassname())) {
                        docAttached = true;
                        break;
                    }
                }
            } 
            if (!docAttached) { // during edit the table contents are separated to initial items and additional items so need to check what was there first place
            	addedItems = paramNmCommandBean.getInitialItems().get("changeRequest_affectedData_table");
            	if (!KBUtils.isEmpty(addedItems)) {
                    for (NmOid id : addedItems) {
                        if (WTDocument.class.getName().equals(id.getWtRef().getKey().getClassname())) {
                            docAttached = true;
                            break;
                        }
                    }
                } 
            }
            
            if (!docAttached) {
                FormResult res = new FormResult(FormProcessingStatus.FAILURE);
                res.addException(new RuntimeException(WTMessage.getLocalizedMessage(RESOURCE,
                        ActionsRB.RED_AFFECTED_ITEM_MISSING, new Object[] { }, SessionHelper.getLocale())));
                return res;
            }
        }
        FormResult res = super.postProcess(paramNmCommandBean, paramList);
        return res;
    }
}
