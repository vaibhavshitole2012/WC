package ext.kb.builder.table;

import org.apache.log4j.Logger;

import com.ptc.mvc.components.ComponentConfig;
import com.ptc.mvc.components.ComponentParams;
import com.ptc.netmarkets.util.misc.NmActionServiceHelper;
import com.ptc.windchill.enterprise.wizardParticipant.mvc.DefineWorkflowParticipantsStepBuilder;

import ext.kb.util.KBUtils;
import wt.folder.Cabinet;
import wt.folder.SubFolder;
import wt.org.OrganizationOwned;
import wt.org.WTOrganization;
import wt.util.WTException;

public class KBDefineWorkflowParticipantsStepBuilder extends DefineWorkflowParticipantsStepBuilder {
	public static final String ACTION_MODEL_STRING = "predeccessorActions_toolbar";
	public static final Logger LOG = Logger.getLogger(KBDefineWorkflowParticipantsStepBuilder.class.getCanonicalName());

	@Override
	public ComponentConfig buildComponentConfig(ComponentParams paramComponentParams) throws WTException {
		LOG.debug("Into build component config");
		ComponentConfig componentConfig = super.buildComponentConfig(paramComponentParams);
		Object contextObject = paramComponentParams.getContextObject();
		LOG.debug("contextObject :: "+contextObject);
		WTOrganization org=null;
		if (contextObject instanceof OrganizationOwned) {
			LOG.debug("isorganizationowned");
			org=((OrganizationOwned) contextObject).getOrganization();
			LOG.debug("org :: "+org);
		}
		if(org !=null) {
			if(KBUtils.isKB(org) && doesActionModelExist(ACTION_MODEL_STRING)) {

				LOG.debug("Setting action model expand and collapse");
				componentConfig.setActionModel(ACTION_MODEL_STRING);

			}
		}
		else if(contextObject instanceof SubFolder) {
			SubFolder subfolder = (SubFolder) contextObject;
			org = subfolder.getContainer().getOrganization();
			LOG.debug("Container name for subfolder is : " + org.getName());

			if(KBUtils.isKB(org) && doesActionModelExist(ACTION_MODEL_STRING)) {
				LOG.debug("Setting action model : expand and collapse");
				componentConfig.setActionModel(ACTION_MODEL_STRING);
			}

		}else if(contextObject instanceof Cabinet) {
			Cabinet cabinet = (Cabinet) contextObject;
			org = cabinet.getContainer().getOrganization();
			LOG.debug("Container cabinet for subfolder is : " + org.getName());

			if(KBUtils.isKB(org) && doesActionModelExist(ACTION_MODEL_STRING)) {
				LOG.debug("Setting action model : expand and collapse");
				componentConfig.setActionModel(ACTION_MODEL_STRING);
			}

		}

		LOG.debug("Returning updated component config");
		return componentConfig;
	}

	/**
	 * this method checks if the action models exist with input parameter name
	 * returns true if action model exists, returns false otherwise
	 *
	 * @param paramString
	 * @return
	 */
	private boolean doesActionModelExist(String paramString) {
		LOG.debug("Does action model exist ?? : checking");
		try {
			NmActionServiceHelper.service.getSimpleActionModel(paramString);
		} catch (final Exception localException) {
			LOG.debug("Custom action model: '" + paramString + "' does not exist, using default action model.");
			LOG.debug("Does action model exist ?? : " + false);
			return false;
		}
		LOG.debug("Does action model exist ?? : " + true);
		return true;

	}

}
