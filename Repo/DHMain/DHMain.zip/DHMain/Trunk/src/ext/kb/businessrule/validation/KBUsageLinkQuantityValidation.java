package ext.kb.businessrule.validation;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.core.businessRules.feedback.RuleFeedbackType;
import com.ptc.core.businessRules.validation.RuleValidationKey;
import com.ptc.core.meta.common.TypeIdentifierHelper;

import ext.kb.resources.BusinessRuleRB;
import wt.fc.BinaryLink;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.part.WTPart;
import wt.part.WTPartHelper;
import wt.part.WTPartMaster;
import wt.part.WTPartUsageLink;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.vc.config.LatestConfigSpec;

public class KBUsageLinkQuantityValidation extends KBValidation {
	
	private static final Logger logger = Logger.getLogger(KBUsageLinkQuantityValidation.class);
	private static final String VALIDATION_RESULT = "VALIDATION_RESULT";
	@Override
	public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList, RuleValidationKey paramRuleValidationKey) throws WTException {
		if (logger.isDebugEnabled()) {
			logger.debug(
					"entering isRulesValid(Persistable,Map<String,Set<AttributeRuleSet>>,List<RuleFeedbackMessage>)");
			logger.debug("paramPersistable: " + paramPersistable);
			logger.debug("paramMap: " + paramMap);
			logger.debug("paramList: " + paramList);
		}
		
		boolean result = true;
		List<RuleFeedbackMessage> localValidationResult = new ArrayList<>();
		paramRuleValidationKey.addToProcessingMap(VALIDATION_RESULT, localValidationResult);
		
		if (!(paramPersistable instanceof WTPart)) {
			if (logger.isDebugEnabled()) {
				logger.debug("exiting isRulesValid()");
				logger.debug("returning: " + result);
			}
			return result;
		}
		WTPart part = (WTPart) paramPersistable;
		logger.debug("Part Number : "+part.getNumber());
		String parttype = TypeIdentifierHelper.getType(part).getTypename();
		logger.debug("Part Type : "+parttype);
		
		if(parttype!=null && !parttype.contains("com.ptc.KBArticle")){
			if (logger.isDebugEnabled()) {
				logger.debug("exiting isRulesValid() Part Type "+parttype);
				logger.debug("returning: " + result);
			}
			return result;
		}
		
		LatestConfigSpec config_spec = null;
		config_spec = new LatestConfigSpec();

		QueryResult queryresult = WTPartHelper.service.getUsesWTParts(part, config_spec);
		
		if(queryresult!=null){
			logger.debug("Structure Size : "+queryresult.size());
		}
		
		
		while(queryresult.hasMoreElements()){
			
			Persistable apersistable[] = (Persistable[])queryresult.nextElement();
			
			WTPartUsageLink usageLink = (WTPartUsageLink)apersistable[0];
			WTPartMaster childMaster = (WTPartMaster)usageLink.getRoleBObject();
			double qty = usageLink.getQuantity().getAmount();
			
			if(qty<0.001){
				logger.debug("Quantity : "+childMaster.getNumber()+" "+usageLink.getQuantity().getAmount());
				RuleFeedbackType feedbackType = RuleFeedbackType.ERROR;
				List<RuleFeedbackMessage> validationResult = (List<RuleFeedbackMessage>) paramRuleValidationKey
						.getProcessingMapValue(VALIDATION_RESULT);
				validationResult.add(new RuleFeedbackMessage(
						new WTMessage(RESOURCE, BusinessRuleRB.KB_USAGE_LINK_INVALID_QUANTITY, new String[] { childMaster.getNumber() }),
						feedbackType));			
				
			}
			
			
			
		}
		
		if (!CollectionUtils.isEmpty(localValidationResult)) {
			paramList.addAll(localValidationResult);
			result = false;
		}
			
		if (logger.isDebugEnabled()) {
			logger.debug("exiting isRulesValid()");
			logger.debug("returning: " + result);
		}
		return result;
		
	}
	@Override
	public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList) throws WTException {
		
		return false;
	}

	
	
	

}
