package ext.kb.businessAlgorithm;

import com.ptc.core.businessfield.server.businessObject.BusinessAlgorithm;
import com.ptc.core.businessfield.server.businessObject.BusinessAlgorithmContext;
import com.ptc.core.businessfield.server.businessObject.BusinessObject;
import com.ptc.core.lwc.server.PersistableAdapter;
import com.ptc.core.meta.common.DisplayOperationIdentifier;
import org.apache.log4j.Logger;
import wt.fc.Persistable;
import wt.fc.WTReference;
import wt.inf.container.ExchangeContainer;
import wt.inf.container.WTContained;
import wt.inf.container.WTContainer;
import wt.log4j.LogR;
import wt.util.WTException;

import java.util.Locale;

public class DepartmentCalculated implements BusinessAlgorithm {

    protected static final Logger LOG = LogR.getLogger(DepartmentCalculated.class.getName());

    @Override
    public Object execute(BusinessAlgorithmContext context, Object[] args) {
        String result = "";
        try {
            BusinessObject bus_obj = context.getCurrentBusinessObject();
            WTReference wtReference = bus_obj.getWTReference();
            Persistable object = wtReference != null ? wtReference.getObject() : null;
            result = object != null ? getDepartment(object) : "";
        } catch (Exception e) {
            LOG.error("There was error trying to receive KB_DEPARTMENT_CALCULATED" + e);
            e.printStackTrace();
        }
        return result;
    }

    private static String getDepartment(Object object) throws WTException {
        String department = "";
        WTContainer container = ((WTContained) object).getContainer();
        if (!(container instanceof ExchangeContainer)) {
            PersistableAdapter adapter = new PersistableAdapter(container, null, Locale.US,
                    new DisplayOperationIdentifier());
            adapter.load("KB_DEPARTMENT_CALCULATED");
            department = (String) adapter.get("KB_DEPARTMENT_CALCULATED");
        }
        return department;
    }

    @Override
    public Object getSampleValue() {
        return "";
    }
}
