package ext.kb.builder.compconfig;

import java.util.List;
import java.util.Locale;

import com.extjs.gxt.ui.client.Style;
import com.ptc.cat.config.client.*;
import com.ptc.cat.config.client.ActionConfig.ButtonType;
import com.ptc.cat.config.client.ColumnConfig;
import com.ptc.cat.config.client.TableConfig;
import com.ptc.generic.iba.AttributeService;
import com.ptc.mvc.components.*;
import com.ptc.windchill.enterprise.part.psb.server.PSBUsesConfigBuilder;

@ComponentBuilder(value = { "PSB.uses" }, type = ComponentBuilderType.CONFIG_ONLY)
@OverrideComponentBuilder
public class PSBUsesConfigBuilderExtension extends PSBUsesConfigBuilder {

    public static final String KB_FREE_TEXT = "KB_FREE_TEXT";

    @Override
	protected List<ActionConfig> getToolbarConfigOverrides(Locale paramLocale) {
		List<ActionConfig> actionConfigs = super.getToolbarConfigOverrides(paramLocale);
		actionConfigs.add(new DefaultActionConfig("autoFillEmptyNumbersGWT",
				ButtonType.BUTTON, null,
				Style.ButtonScale.SMALL));
		return actionConfigs;
	}

    @Override
    public ComponentConfig buildComponentConfig(ComponentParams params) {
        ComponentConfig componentConfig = super.buildComponentConfig(params);
        TableConfig tableConfig = ((DefaultComponentConfig) componentConfig).getTableConfig();
        ColumnConfigSet columnConfigSet = tableConfig.getColumnConfigSet();
        String displayName = AttributeService.getAttributeDisplayValue("wt.part.WTPartUsageLink", KB_FREE_TEXT);
        for (ColumnConfig columnConfig : columnConfigSet) {
            DefaultColumnConfig dfc = (DefaultColumnConfig) columnConfig;
            String id = columnConfig.getId();
            if(id.contains(KB_FREE_TEXT)){
                dfc.setLabel(displayName);
            }
        }
        return componentConfig;
    }
	
}
