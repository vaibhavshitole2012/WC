package ext.kb.businessrule.validation;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.fc.collections.WTCollection;
import wt.fc.collections.WTHashSet;
import wt.fc.collections.WTKeyedHashMap;
import wt.filter.NavigationCriteria;
import wt.filter.NavigationCriteriaHelper;
import wt.lifecycle.LifeCycleState;
import wt.log4j.LogR;
import wt.maturity.MaturityHelper;
import wt.maturity.PromotionNotice;
import wt.navigation.DTRequest;
import wt.navigation.DTRequest.DependencyTracing;
import wt.navigation.DTRequest.Scope;
import wt.navigation.DependencyHelper;
import wt.navigation.NavigationUnit;
import wt.navigation.SimpleDTRequest;
import wt.part.WTPart;
import wt.util.WTException;
import wt.util.WTMessage;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.core.businessRules.feedback.RuleFeedbackType;

import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.KBConstants;
import ext.kb.util.KBTypeIdProvider;

/**
* This class does not do any extra validation, but extends the OOTB business validation
* error message by explicitly listing the items, which made the validation failing.
* Not all of these items is listed,there are exceptional cases.
* Please check methods, where names with 'filter' prefix.
*/
public class KBSSLBOMReleaseRuleValidator extends KBValidation{

	protected static final Logger LOG = LogR.getLogger(KBSSLBOMReleaseRuleValidator.class.getName());
	
	public KBSSLBOMReleaseRuleValidator() {
        setFeedbackType(RuleFeedbackType.ERROR);
    }

    /*
     * This method executes 2 constraints on an EPMDocument
     * First it can have associated parts, when it is not marked as phantom,
     * secondly when it is of type Drawing it must have associtated parts
     */
    @Override
    public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
            List<RuleFeedbackMessage> paramList) throws WTException {

    	LOG.debug("paramList : " + paramList);
    	LOG.debug("paramMap : " + paramMap);
        boolean isRuleValid = true;
        LOG.debug("Evaluating SSLBOM rules, target object : " + paramPersistable);
        if (!KBTypeIdProvider.isDescendant(paramPersistable, "SSBOM")) {
        	return isRuleValid;
        }
        try {

			WTCollection seeds = new WTHashSet();
			seeds.add(paramPersistable);
			int recursion = -1;
			NavigationCriteria navCriteria = NavigationCriteriaHelper.service
					.getDefaultNavigationCriteria(seeds, null);
			DTRequest request = new SimpleDTRequest(seeds, navCriteria,
					Scope.SEED_CONTAINERS, recursion,
					DependencyTracing.ALL);
			request.setRetrieveLinks(true);
			request.addCollectionsByCollectionComponentId("COLLECT_ITEMS_FOR_BOM_RELEASE_RULE");
			DependencyHelper dependencyHelper = new DependencyHelper(
					request);
			WTKeyedHashMap promotionNoticeMap = MaturityHelper.service.getPromotionNoticesMap(seeds);
			WTHashSet set = (WTHashSet) promotionNoticeMap.values().iterator().next();
			LOG.debug("set : " + set);
			PromotionNotice promotionNotice = null;
			boolean validPromotionNoticeState = false;
			Iterator setIterator = set.iterator();
			while (!validPromotionNoticeState && setIterator.hasNext()) {
				ObjectReference objectReferenc = (ObjectReference) setIterator.next();
				promotionNotice = (PromotionNotice) objectReferenc.getObject();
				LOG.debug("promotionNotice.getLifeCycleState() : " + promotionNotice.getLifeCycleState());
				validPromotionNoticeState = KBConstants.OPEN.equals(promotionNotice.getLifeCycleState().toString());
			}
			
			QueryResult result = MaturityHelper.service.getPromotionTargets(promotionNotice);
			LOG.debug("promotion targets size: " + result.size());
			WTHashSet promotionTargetsSet = new WTHashSet();
			while (result.hasMoreElements()) {
				Persistable object = (Persistable) result.nextElement();
				promotionTargetsSet.add(object);
			}
			NavigationUnit[] navigationUnits = dependencyHelper
					.getCollectedNavigationUnits();
			LOG.debug("navigationUnits size: " + navigationUnits.length);
			for (NavigationUnit navigationUnit : navigationUnits) {
				Persistable child = navigationUnit.getEndNode();
				LOG.debug("child: " + child);
				LOG.debug("promotionTargetsSet.contains(child): " + promotionTargetsSet.contains(child));
				if (KBTypeIdProvider.isDescendant(child, "SSBOM") && !promotionTargetsSet.contains(child)) {
					WTPart childPart = (WTPart) child;
					LifeCycleState lcState = childPart.getState();
					boolean validState = KBConstants.RELEASED.equals(lcState.toString());
					LOG.debug("child: " + childPart.getIdentity() + ", state: " +lcState.toString() + " validState: " + validState);
					if (!validState){
						paramList.add(new RuleFeedbackMessage(new WTMessage(RESOURCE, BusinessRuleRB.KB_SYSTEM_PROMOTION_CHILD_INVALID_STATE, new Object[]{childPart.getIdentity(), lcState.toString()}),getFeedbackType()));
	                    isRuleValid = false;
					}
		        }
			}
    	
        } catch (Exception localException) {
            LOG.error("Unexpected error while validating attribute rule.", localException);
            isRuleValid = false;
        }

        if (LOG.isDebugEnabled()) {
            LOG.debug("All attribute rules passed for target object.");
        }

        return isRuleValid;

    }

}
