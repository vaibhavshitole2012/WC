package ext.kb.businessrule.validation;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;

import wt.change2.ChangeActivity2;
import wt.change2.ChangeException2;
import wt.change2.ChangeHelper2;
import wt.change2.ChangeOrder2;
import wt.change2.ChangeRecord2;
import wt.doc.WTDocument;
import wt.enterprise.RevisionControlled;
import wt.epm.EPMDocument;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.fc.WTReference;
import wt.fc.collections.WTArrayList;
import wt.fc.collections.WTCollection;
import wt.fc.collections.WTHashSet;
import wt.fc.collections.WTKeyedHashMap;
import wt.fc.collections.WTKeyedMap;
import wt.fc.collections.WTSet;
import wt.lifecycle.LifeCycleManaged;
import wt.lifecycle.State;
import wt.log4j.LogR;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.part.WTPartSubstituteLink;
import wt.part.WTPartUsageLink;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.WTRuntimeException;
import wt.vc.struct.StructHelper;

import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.core.businessRules.feedback.RuleFeedbackType;
import com.ptc.core.businessRules.validation.BOMReleaseRuleValidator;
import com.ptc.core.businessRules.validation.RuleValidationCriteria;
import com.ptc.core.businessRules.validation.RuleValidationKey;
import com.ptc.core.businessRules.validation.RuleValidationObject;
import com.ptc.core.businessRules.validation.RuleValidationResult;
import com.ptc.core.businessRules.validation.RuleValidationStatus;
import com.ptc.generic.iba.AttributeService;

import ext.kb.businessrule.validation.dto.KBRuleValidationResult;
import ext.kb.businessrule.validation.dto.ProblemWith;
import ext.kb.businessrule.validation.dto.ValidationReport;
import ext.kb.businessrule.validation.helper.KBBOMReleaseValidationHelper;
import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.KBConstants;
import ext.kb.util.KBDocumentUtils;
import ext.kb.util.KBTypeIdProvider;
import ext.kb.util.KBUtils;

/**
* This class does not do any extra validation, but extends the OOTB business validation
* error message by explicitly listing the items, which made the validation failing.
* Not all of these items is listed,there are exceptional cases.
* Please check methods, where names with 'filter' prefix.
*/
public class KBBOMReleaseRuleValidator extends BOMReleaseRuleValidator{

	protected static final Logger LOG = LogR.getLogger(KBBOMReleaseRuleValidator.class.getName());
	private static final String VALIDATION_HELPER_KEY = "VALIDATIONHELPER";
	
	private Set<State> specialTargetStates = new HashSet<>();
	{
		specialTargetStates.add(KBConstants.RELEASED_STATE);
		specialTargetStates.add(KBConstants.PRE_SERIES_RELEASED_STATE);
		
	}
	
	/* (non-Javadoc)
	 * @see com.ptc.core.businessRules.validation.BOMReleaseRuleValidator#performValidation(com.ptc.core.businessRules.validation.RuleValidationKey, com.ptc.core.businessRules.validation.RuleValidationObject, com.ptc.core.businessRules.validation.RuleValidationCriteria)
	 *
	 * Checks if the parent method resulted in validation problems.
	 * If so, provides a more detailed error message by checking 
	 * objects and all of their iterations in the BOM.
	 */
	@Override
	public RuleValidationResult performValidation(
			RuleValidationKey paramRuleValidationKey,
			RuleValidationObject paramRuleValidationObject,
			RuleValidationCriteria paramRuleValidationCriteria)
			throws WTException {
		ReferenceFactory rf = new ReferenceFactory();
		RuleValidationResult parentResult =  super.performValidation(paramRuleValidationKey,
				paramRuleValidationObject, paramRuleValidationCriteria);
		
		//in case of success, there is nothing to do
		if(!RuleValidationStatus.FAILURE.equals(parentResult.getStatus())){
			return parentResult;
		}		
		KBBOMReleaseValidationHelper helper = (KBBOMReleaseValidationHelper) paramRuleValidationKey.getProcessingMapValue(VALIDATION_HELPER_KEY);
		LOG.debug("paramRuleValidationObject:" + getIdentity((LifeCycleManaged) paramRuleValidationObject.getTargetObject().getObject()));
		KBRuleValidationResult localValidationResult = new KBRuleValidationResult(parentResult);
		@SuppressWarnings("unchecked")
		Set<State> validStates = (Set<State>)paramRuleValidationKey.getProcessingMapValue("validDependentState");
		LOG.debug("validStates : "+validStates);
		Set<State> invalidStates = (Set<State>)paramRuleValidationKey.getProcessingMapValue("invalidDependentState");
		LOG.debug("invalidStates : "+invalidStates);
		Map<Object,State> targetStatesByResultingObject = (Map)paramRuleValidationKey.getProcessingMapValue("TARGET_STATES_MAP");
		LOG.debug("targetStatesByResultingObject : "+targetStatesByResultingObject);
		
		
		
		
		
		
		
		List<LifeCycleManaged> previousRevisionCheckList = new ArrayList<LifeCycleManaged>();
		Set<RuleValidationObject> childObjects1 =paramRuleValidationObject.getChildObjects();
		WTKeyedMap map = paramRuleValidationObject.getChildToLinksMap();
		
		WTKeyedMap kMap = paramRuleValidationObject.getChildToLinksMap();
		LOG.debug("kMap size : "+kMap.size());
		Set set = kMap.keySet();
		HashSet subset = new HashSet();
		WTKeyedMap keyedMap = (WTKeyedMap) new WTKeyedHashMap();
		keyedMap.putAll(kMap);
		LOG.debug("keyedMap size : "+keyedMap.size());
		Iterator itr = set.iterator();
		while(itr.hasNext()){
			Object obj = itr.next();
			LOG.debug("OBJ : "+obj);
			LOG.debug("OBJ value : "+kMap.get(obj));
			HashSet linkObj = (HashSet) kMap.get(obj);
			//subset = linkObj;
			LOG.debug("linkObj "+linkObj);
			Iterator itr1 = linkObj.iterator();
			while(itr1.hasNext()){
				
				Object usageLink = itr1.next();
				if(usageLink instanceof WTPartUsageLink){
					WTPartUsageLink link = (WTPartUsageLink) usageLink;
					QueryResult allLinks = PersistenceHelper.manager.navigate(link,
							WTPartSubstituteLink.SUBSTITUTES_ROLE, WTPartSubstituteLink.class, false);
					LOG.debug("allLinks size : "+allLinks.size());
					while (allLinks.hasMoreElements()) {
						WTPartSubstituteLink sublink = (WTPartSubstituteLink) allLinks.nextElement();
						WTPartMaster master =(WTPartMaster) sublink.getRoleBObject();
						WTPart subPart = (WTPart) KBUtils.getLatestIteration(master);
						LOG.debug("subPart : "+subPart+" Number : "+subPart.getNumber());
						ReferenceFactory ref = new ReferenceFactory();
						childObjects1.add(new RuleValidationObject(ref.getReference(subPart),paramRuleValidationCriteria));
						LOG.debug("Added to childObjects1");
						paramRuleValidationObject.setChildObjects(childObjects1);
						LOG.debug("paramRuleValidationObject added");
						subset.add(sublink);
						keyedMap.put(subPart, subset);
						LOG.debug("Added to keyedMap");
						/*WTPartMaster master = (WTPartMaster) allLinks.nextElement();
						WTPart subPart =(WTPart) KBUtils.getLatestIteration(master);*/
						
						
						/*RuleValidationResult currentResult = new RuleValidationResult(null);
						callValidateDependent(subPart, currentResult, validStates, invalidStates, targetStatesByResultingObject);
						LOG.debug("currentResult : "+currentResult+" "+currentResult.getStatus());
						if (currentResult.getStatus() == null) {
							           if (callShouldCheckPreviousRevision(subPart, paramRuleValidationObject, paramRuleValidationKey)) {
							        	   previousRevisionCheckList.add(subPart);
							           } else {
							        	   
							              ValidationReport report = new ValidationReport(subPart, ProblemWith.SELF);
							              localValidationResult.addValidationReport(report);
							           }
						}else if(RuleValidationStatus.FAILURE.equals(currentResult.getStatus())){
							ValidationReport report = new ValidationReport(subPart, ProblemWith.SELF);
							localValidationResult.addValidationReport(report);
						}*/
					}
					
				}
			}
			
		}
		LOG.debug("Key Map size : "+keyedMap.size()+"    "+keyedMap);
		paramRuleValidationObject.setChildToLinksMap(keyedMap);
		
		Set<RuleValidationObject> childObjects = (Set<RuleValidationObject>)paramRuleValidationObject.getChildObjects();
		LOG.debug("childObjects:" + childObjects);
		for (Iterator<RuleValidationObject> it = childObjects.iterator(); it.hasNext();) {
				RuleValidationObject ruleValidationObject = it.next();
		        WTReference targetObj = ruleValidationObject.getTargetObject();
		        Object dependentObject = targetObj.getObject();
		        LOG.debug("dependentObject : "+dependentObject);
		        if (dependentObject instanceof LifeCycleManaged) {
		        	LifeCycleManaged lManaged = (LifeCycleManaged) dependentObject;
		        	LOG.debug("child: " + getIdentity(lManaged));
		        	RuleValidationResult currentResult = new RuleValidationResult(null);
					callValidateDependent(lManaged, currentResult, validStates, invalidStates, targetStatesByResultingObject);
					LOG.debug("currentResult : "+currentResult+" "+currentResult.getStatus());
					if (currentResult.getStatus() == null) {
						           if (callShouldCheckPreviousRevision(lManaged, paramRuleValidationObject, paramRuleValidationKey)) {
						        	   previousRevisionCheckList.add(lManaged);
						           } else {
						        	   
						              ValidationReport report = new ValidationReport(lManaged, ProblemWith.SELF);
						              localValidationResult.addValidationReport(report);
						           }
					}else if(RuleValidationStatus.FAILURE.equals(currentResult.getStatus())){
						ValidationReport report = new ValidationReport(lManaged, ProblemWith.SELF);
						localValidationResult.addValidationReport(report);
					}
			}
		        
		}
		
		
		
		
		LOG.debug("previousRevisionCheckList : "+previousRevisionCheckList);
		for(LifeCycleManaged lf : previousRevisionCheckList){
	       	RuleValidationResult tmpResult = new RuleValidationResult(null);
	       	WTSet  objectHolder = new WTHashSet();
	       	objectHolder.add(lf);
	       	callValidatePreviousRevisions(tmpResult, validStates, invalidStates, objectHolder, targetStatesByResultingObject);
	       	if(RuleValidationStatus.FAILURE.equals(tmpResult.getStatus())){
	       		 ValidationReport report = new ValidationReport(lf, ProblemWith.REVISIONS);
	       		 localValidationResult.addValidationReport(report);
	       	}
	    }
		
		List<ValidationReport> validationReports = localValidationResult.getValidationReports();
		final int nrOfConflicts = validationReports.size();
		if(nrOfConflicts > 0){
			//KNORRBREMSE_RAILPLM-3140 START
			filterTechDrawings(validationReports, paramRuleValidationObject, targetStatesByResultingObject, helper);
			//KNORRBREMSE_RAILPLM-3140 END

			//KNORRBREMSE_RAILPLM-3908 START
			filterTechDocuments(validationReports, paramRuleValidationObject, targetStatesByResultingObject);
			//KNORRBREMSE_RAILPLM-3908 END
			
			//KNORRBREMSE_RAILPLM-3328 START
			filterCadDrawingsWithoutContentLink(validationReports);
			//KNORRBREMSE_RAILPLM-3328 END
			
			
			// 186578 - KB - BOM Component state START
			filterChildArticleByTargetStateInKB(validationReports, paramRuleValidationObject, validStates, invalidStates);
			// 186578 - KB - BOM Component state END
			
			if(CollectionUtils.isEmpty(validationReports)){
				return new RuleValidationResult(RuleValidationStatus.SUCCESS);
			}
			
			for(ValidationReport report : localValidationResult.getValidationReports()){
				boolean substitute = false;
			 	if(report.getTargetObject() instanceof RevisionControlled){
				 		
			 		RevisionControlled rc = (RevisionControlled) report.getTargetObject();
			 		String objectNumber = KBUtils.getObjectNumber(rc);
				    String state = rc.getState().getState().getDisplay(KBUtils.getCurrentLocale());
				    String errorKey = BusinessRuleRB.KB_CHILD_INVALID_STATE;
			 		LOG.debug("RC : "+rc);
			 		if(keyedMap.containsKey(rc)){
			 			HashSet newSet = (HashSet) keyedMap.get(rc);
			 			Iterator newItr = newSet.iterator();
			 			while(newItr.hasNext()){
			 				Object object = newItr.next();
			 				if(object instanceof WTPartSubstituteLink){
			 					substitute = true;
			 				}
			 			}
			 		}
				    
				    if(ProblemWith.REVISIONS.equals(report.getProblemWith())){
				    	if(substitute){
				    		 errorKey = BusinessRuleRB.KB_SUB_REVISIONS_INVALID_STATE;
				    	}else{
				    		 errorKey = BusinessRuleRB.KB_REVISIONS_INVALID_STATE;
				    	}
				    	
				    } else if (ProblemWith.RELEASETARGET.equals(report.getProblemWith())){
				    	state = State.toState(report.getAdditionalInfo()).getDisplay(KBUtils.getCurrentLocale());
				    	if(substitute){
				    		errorKey = BusinessRuleRB.KB_SUB_INVALID_TARGET_STATE;
				    	}else{
				    		errorKey = BusinessRuleRB.KB_CHILD_INVALID_TARGET_STATE;
				    	}
				    } else if (ProblemWith.NORELEASETARGET.equals(report.getProblemWith())){
				    	
				    		errorKey = BusinessRuleRB.NO_TRANSITIONS_DEFINED;
				    	
				    	
				    }
					    
					RuleFeedbackMessage localRuleFeedbackMessage = new RuleFeedbackMessage(new WTMessage("ext.kb.resources.BusinessRuleRB", errorKey, new Object[] {objectNumber,state}), RuleFeedbackType.ERROR);
					parentResult.addFeedbackMessage(localRuleFeedbackMessage);
			 	}
			}
		}
			
		return parentResult;
	}

	/*
	 * Filters out Articles which are child objects of the target BOM and if they are included in the same ECN with the same targetState as the targetBOM
	 */
	private void filterChildArticleByTargetStateInKB(List<ValidationReport> validationReports, RuleValidationObject paramRuleValidationObject, Set<State> validStates, Set<State> invalidStates) throws ChangeException2, WTException {
		if (paramRuleValidationObject.getTargetObject().getObject() instanceof WTPart){
			WTPart targetBOM = (WTPart) paramRuleValidationObject.getTargetObject().getObject();
			boolean isEbomPart = KBUtils.isEbomPart(targetBOM);
			if(!isEbomPart) {
				LOG.debug("Found part is MBOM, will not take into account.");
				return;
			}
			if (targetBOM.getOrganization().getName().equals(KBConstants.KB)){
				if (LOG.isDebugEnabled()){
					LOG.debug("filtering out child objects - START");
				}
				ChangeRecord2 currentChangeRecord = ((ChangeRecord2) paramRuleValidationObject.getTargetObjectLink().getObject());
				//get the ECT
				ChangeActivity2 ectOfTargetBOM = currentChangeRecord.getChangeActivity2();
				Boolean immediateReleaseOfECTOfTargetBOM = AttributeService.getAttribute(ectOfTargetBOM, KBConstants.KB_IMMEDIATE_RELEASE_IBA);
				if (LOG.isDebugEnabled()){
					LOG.debug("Target BOM ECT number: " + ectOfTargetBOM.getNumber() + " target transition: " + currentChangeRecord.getTargetTransition());
					LOG.debug("targetBOM is on immediate release: " + immediateReleaseOfECTOfTargetBOM);
				}
				//  get the ECN
				QueryResult changeOrderResult = ChangeHelper2.service.getChangeOrder(ectOfTargetBOM);
				int nrOfChangeOrders = changeOrderResult == null ? 0 : changeOrderResult.size();
				if(nrOfChangeOrders > 0){
					ChangeOrder2 ecn = (ChangeOrder2)changeOrderResult.nextElement();
					// all the changeRecords in the ECN: 
					QueryResult changeRecords = ChangeHelper2.service.getChangeablesAfter(ecn, false);
					while (changeRecords.hasMoreElements()){
						ChangeRecord2 cr = (ChangeRecord2) changeRecords.nextElement();
						if (LOG.isDebugEnabled()){
							LOG.debug("changeActivity: " + cr.getChangeActivity2().getNumber() + " targetTransition: " + cr.getTargetTransition());
							LOG.debug("resultingObject: " + getIdentity((LifeCycleManaged)cr.getRoleBObject()));
						}
						if (cr.getRoleBObject() instanceof WTPart){
							WTPart resultingObject = (WTPart) cr.getRoleBObject();
							ArrayList<ValidationReport> tmpValidationReportList = new ArrayList<ValidationReport>(validationReports);
							for (ValidationReport vR : tmpValidationReportList) {
								if (LOG.isDebugEnabled()){
									LOG.debug("validation result targetobject: " + getIdentity((LifeCycleManaged)vR.getTargetObject()));
								}
								//if this resultingObject is the same as the conflicting one in the validationReports
								if (resultingObject.equals(vR.getTargetObject())){
									// then check if its target state is in the validState set and not in the invalidState set
									// if yes then removing from the validationReports
									if (cr.getTargetTransition() != null){
										
										boolean validateReleaseTarget = false; 
										//If the assembly is on an immediate release ECT: 
										//	- If a child is on the same ECT, validate its release target 
										//If the assembly is on an non-immediate release ECT: 
										//	- If a child is on any non-immediate ECT of the same ECN, validate its release target. 
										if (immediateReleaseOfECTOfTargetBOM){
											if (cr.getChangeActivity2().equals(ectOfTargetBOM)){
												if (LOG.isDebugEnabled()){
													LOG.debug("resultingObject and targetBOM are on the same ECT");
												}
												validateReleaseTarget = true;
											}
										} else {
											Boolean isImmediateECT = AttributeService.getAttribute(cr.getChangeActivity2(), KBConstants.KB_IMMEDIATE_RELEASE_IBA);
											if (LOG.isDebugEnabled()){
												LOG.debug("resultingObject is on an immediate release ECT: " + isImmediateECT);
											}
											if (!isImmediateECT){
												validateReleaseTarget = true;
											}
										}
										
										if (LOG.isDebugEnabled()){
											LOG.debug("validating: " + (validateReleaseTarget ? "target state" : "current state" ));
										}
										
										
										if (validateReleaseTarget){
											State resultingObjectTargetState = State.toState(cr.getTargetTransition().toString());
											if (LOG.isDebugEnabled()){
												LOG.debug("resultingObjectTargetState: " + resultingObjectTargetState.toString());
											}
											if (validStates.contains(resultingObjectTargetState) && !invalidStates.contains(resultingObjectTargetState)){
												if (LOG.isDebugEnabled()){
													LOG.debug("valid target state, removing from validation error report");
												}
												validationReports.remove(vR);
											} else {
												if (LOG.isDebugEnabled()){
													LOG.debug("INVALID target state, adding extra info to the validation error report to show it to the user");
												}
												vR.setProblemWith(ProblemWith.RELEASETARGET);
												vR.setAdditionalInfo(resultingObjectTargetState.toString());
											}
										}
									} else {
										vR.setProblemWith(ProblemWith.NORELEASETARGET);
									}
								}
							}
						}
					}
				}
				if (LOG.isDebugEnabled()){
					LOG.debug("filtering out child objects - END");
				}
			}
		}
	}

	/*As of this part of the class dirty reflection hack took place in order
	 * to avoid copying the whole (incl private methods)code from the superclass
	 * 
	 * */
	private void callValidateDependent(LifeCycleManaged paramLifeCycleManaged,
			RuleValidationResult paramRuleValidationResult,
			Set<State> validStates, Set<State> invalidStates,
			Map<Object, State> paramMap) {

		invokePrivateMethod("validateDependent", new Class[]{LifeCycleManaged.class,RuleValidationResult.class,Set.class, Set.class,Map.class}, new Object[]{paramLifeCycleManaged, paramRuleValidationResult,validStates,invalidStates,paramMap});
	}
	
	private boolean callShouldCheckPreviousRevision(LifeCycleManaged paramLifeCycleManaged, RuleValidationObject paramRuleValidationObject, RuleValidationKey paramRuleValidationKey) {
		LOG.debug("paramLifeCycleManaged : "+paramLifeCycleManaged+" paramRuleValidationObject : "+paramRuleValidationObject+" paramRuleValidationKey "+paramRuleValidationKey);
		boolean result = (boolean) invokePrivateMethod("shouldCheckPreviousRevision",new Class[]{LifeCycleManaged.class,RuleValidationObject.class,RuleValidationKey.class}, new Object[]{paramLifeCycleManaged, paramRuleValidationObject,paramRuleValidationKey});
		
		return result;
	}
	
	private void callValidatePreviousRevisions(RuleValidationResult paramRuleValidationResult, Set<State> validStates, Set<State> invalidStates, WTCollection paramWTCollection, Map<Object, State> paramMap) {

		invokePrivateMethod("validatePreviousRevisions",new Class[]{RuleValidationResult.class,Set.class,Set.class,WTCollection.class,Map.class}, new Object[]{paramRuleValidationResult, validStates,invalidStates,paramWTCollection,paramMap});
		
	}
	
	private Object invokePrivateMethod(final String methodName,final Class[]  paramClasses, final Object[] paramObjects){
		BOMReleaseRuleValidator r = new BOMReleaseRuleValidator();
		Method method = null;
		Object result = null;
		try {
			LOG.debug("methodName : "+methodName+" paramClasses : "+" paramObjects : "+paramObjects);
			method = r.getClass().getDeclaredMethod(methodName,paramClasses);
			LOG.debug("method : "+method);
			method.setAccessible(true);
			result = method.invoke(r,paramObjects);
		} catch (NoSuchMethodException | SecurityException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
			LOG.error("Unexpected exception ws thrown ",e);
			throw new WTRuntimeException(e);
		} 
		finally{
			if(method != null){
				method.setAccessible(false);
			}
		}
		return result;
	}
	
	private void filterTechDocuments(final List<ValidationReport> validationReports,final RuleValidationObject paramRuleValidationObject, final Map<Object,State> targetStates){
		Iterator<ValidationReport> it = validationReports.iterator();
		while (it.hasNext()){
			ValidationReport ruleConflictItem = it.next();
			boolean isTechDoc = KBDocumentUtils.isTechDocument(ruleConflictItem.getTargetObject());
			if(isTechDoc){
				it.remove();
			}
		}
	}
	
	private void filterTechDrawings(final List<ValidationReport> validationReports,final RuleValidationObject paramRuleValidationObject, final Map<Object,State> targetStates,
			KBBOMReleaseValidationHelper helper){
		Iterator<ValidationReport> it = validationReports.iterator();
		
		boolean hasWTPartProperTargetState = hasWTPartProperTargetState(paramRuleValidationObject, targetStates);
		if(!hasWTPartProperTargetState){
			return;
		}
		while (it.hasNext()){
			ValidationReport ruleConflictItem = it.next();
			boolean isTechDrawing = KBDocumentUtils.isTechDrawing(ruleConflictItem.getTargetObject());
			if(!isTechDrawing){
				continue;
			}
			WTDocument ruleConflictTechDrw = (WTDocument)ruleConflictItem.getTargetObject();
			
			boolean cadExistsWithSameNumber = helper.cadDocWithSameNumberExists(ruleConflictTechDrw);
			if(!cadExistsWithSameNumber){
				continue;
			}
			//if so far all the above conditions evaluated to true, we remove the object
			//causing the conflict from the conflict message list
			it.remove();
		}
	}

	private boolean hasWTPartProperTargetState(RuleValidationObject ruleValidationObject,Map<Object,State> targetStates){
		boolean hasWTPartProperTargetState = false;
		WTReference targetObject = ruleValidationObject.getTargetObject();
		Persistable targetPersistable = targetObject.getObject();
		State targetState = targetStates.get(targetPersistable);
		
		if(!(targetPersistable instanceof WTPart)){
			return hasWTPartProperTargetState;
		}
		
		if(!specialTargetStates.contains(targetState)){
			return hasWTPartProperTargetState;
		}
		return hasWTPartProperTargetState = true;
	}
	
	private void filterCadDrawingsWithoutContentLink(final List<ValidationReport> validationReports) throws WTException{
		
		Iterator<ValidationReport> it = validationReports.iterator();
		while (it.hasNext()){
			ValidationReport report = it.next();
			
			Object targetObject = report.getTargetObject();
			//Check if the dependent object is cad drawing
			if (!KBTypeIdProvider.isDescendant(targetObject, "KBCADDRW")) {
				continue;
			}
			EPMDocument epmDoc = (EPMDocument)targetObject;
			WTCollection epmDocHolder = new WTArrayList();
			epmDocHolder.add(epmDoc);
			WTKeyedMap contentLinks = StructHelper.service.navigateDescribes(epmDocHolder, wt.epm.structure.EPMDescribeLink.class, false);
			WTArrayList contentLinksOfEpmdocs = (WTArrayList) contentLinks.get(epmDoc);
			
			if(CollectionUtils.isNotEmpty(contentLinksOfEpmdocs)){
				continue;
			}
			//if so far all the above conditions evaluated to true, we remove the object
			//causing the conflict from the conflict message list
			it.remove();
		}
	}

	@Override
	public void prepareForValidation(RuleValidationKey ruleValidationKey,
			RuleValidationCriteria ruleValidationCriteria) throws WTException {
		
		super.prepareForValidation(ruleValidationKey, ruleValidationCriteria);
		KBBOMReleaseValidationHelper validationHelper = new KBBOMReleaseValidationHelper();
		validationHelper.prepareForValidation(ruleValidationKey);
		ruleValidationKey.addToProcessingMap(VALIDATION_HELPER_KEY, validationHelper);
	}
	
	public String getIdentity(LifeCycleManaged lfcmng){
		String type = null;
		if (KBTypeIdProvider.isDescendant(lfcmng, "KBCADDRW")) {
			type = "DWR:";
		} else if (KBTypeIdProvider.isDescendant(lfcmng, "KBCADDOC")) {
			type = "CAD:";
		} else if (KBTypeIdProvider.isDescendant(lfcmng, "ASSYCOMP")) {
			type = "PART:";
		} else if (KBTypeIdProvider.isDescendant(lfcmng, "KBDOC") || KBTypeIdProvider.isDescendant(lfcmng, "CERTYFICATEDOC") || KBTypeIdProvider.isDescendant(lfcmng, "STANDARDDOC")) {
			type = "WTDOC:";
		} else {
			type = "OTHER";
		}
		String identity = type + lfcmng.getIdentity() + ":" + lfcmng.getState();
		
		return identity;
	}
	
}
