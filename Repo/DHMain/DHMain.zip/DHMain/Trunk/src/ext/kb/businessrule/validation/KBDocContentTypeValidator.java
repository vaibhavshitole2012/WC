package ext.kb.businessrule.validation;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.drools.core.util.StringUtils;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.core.businessRules.feedback.RuleFeedbackType;
import com.ptc.core.businessRules.validation.RuleValidationKey;
import com.ptc.generic.iba.AttributeService;

import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.KBConstants;
import ext.kb.util.KBType;
import wt.fc.Persistable;
import wt.util.WTException;
import wt.util.WTMessage;

public class KBDocContentTypeValidator extends KBValidation {

	private static final String DOC_TYPE_997 = "997";
	private static final String DOC_TYPE_DASH = "---";

	@Override
	public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList, RuleValidationKey validationKey) throws WTException {
		boolean success = true;

		if (isValidForValidation(paramPersistable) && isDocContentTypeNotValid(paramPersistable)) {
			WTMessage message = new WTMessage(RESOURCE, BusinessRuleRB.KB_DOC_CONTENT_TYPE_RULE_ERROR_MSG, new Object[] {});
			RuleFeedbackMessage localRuleFeedbackMessage = new RuleFeedbackMessage(message,	RuleFeedbackType.ERROR);
			paramList.add(localRuleFeedbackMessage);
			success = false;
		}

		return success;
	}

	private boolean isValidForValidation(Persistable persistable) {
		return KBType.isDescendedFrom(persistable, "com.ptc.DesignCADDrw")
				|| KBType.isDescendedFrom(persistable, "com.ptc.KBTechnicalDrawing")
				|| KBType.isDescendedFrom(persistable, "com.ptc.KBTechnicalDocument");
	}

	private boolean isDocContentTypeNotValid(Persistable persistable) {
		String docContentType = AttributeService.getAttribute(persistable, KBConstants.DOC_CONTENT_TYPE);
		return StringUtils.isEmpty(docContentType)
				|| DOC_TYPE_997.equals(docContentType)
				|| DOC_TYPE_DASH.equals(docContentType);
	}

	@Override
	public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList) throws WTException {
		return false;
	}

}
