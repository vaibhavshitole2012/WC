package ext.kb.change2.form;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormResult;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.kb.project.ProjectHelper;
import org.apache.log4j.Logger;
import wt.change2.WTChangeActivity2;
import wt.fc.*;
import wt.fc.collections.WTArrayList;
import wt.folder.Folder;
import wt.folder.SubFolder;
import wt.inf.container.WTContainerRef;
import wt.inf.sharing.SharedContainerMap;
import wt.log4j.LogR;
import wt.projmgmt.admin.Project2;
import wt.util.WTException;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;

import static ext.kb.project.ProjectHelper.getNumber;

/**
 * Custom form processor created for Share to plant action/wizard
 *
 * @author ext-atres
 */
public class KBShareToPlantFromProcessor extends DefaultObjectFormProcessor {

    protected static final Logger LOG = LogR.getLogger(KBShareToPlantFromProcessor.class.getName());

    @Override
    public FormResult doOperation(final NmCommandBean cmdBean, final List<ObjectBean> objBeans) throws WTException {
        final ObjectIdentifier ectOid = cmdBean.getActionOid().getOidObject();
        final String projectID = cmdBean.getRequest().getParameter("contextPicker");
        LOG.debug("Project Oid" + projectID);
        final ObjectReference changeTaskReference = ObjectReference.newObjectReference(ectOid);
        final WTReference proReference = new ReferenceFactory().getReference(projectID);
        WTChangeActivity2 activity = (WTChangeActivity2) changeTaskReference.getObject();
        ArrayList selectedFromTable = cmdBean.getSelected();
        LOG.debug("selected Project " + getNumber(proReference.getObject()));
        if (!selectedFromTable.isEmpty()) {
            LOG.debug("updating selectedFromTable " + selectedFromTable);
            shareSelectedObjects((WTContainerRef) proReference, selectedFromTable);
        } else {
            LOG.debug("updating shareAllObjectFromTable ");
            shareAllObjectFromTable(proReference, activity);
        }
        return super.doOperation(cmdBean, objBeans);
    }

    private void shareAllObjectFromTable(WTReference projReference, WTChangeActivity2 activity) throws WTException {
        Set<Persistable> allObjectsFromTable = ProjectHelper
                .getAlreadySharedObjectsToProject(activity, (Project2) projReference.getObject());
        WTArrayList sharedMalList = ProjectHelper
                .getSharedContainerMapsForProject((Project2) projReference.getObject());
        for (Persistable persistable : allObjectsFromTable) {
            String number = getNumber(persistable);
            LOG.debug("Sharing object " + number);
            Folder sharedFolder = getSharedFolder(sharedMalList, number);
            ProjectHelper.updateItemInProject(persistable, (WTContainerRef) projReference, sharedFolder);
        }
    }

    private Folder getSharedFolder(WTArrayList sharedMalList, String number) throws WTException {
        for (Object o : sharedMalList) {
            ObjectReference objR = (ObjectReference) o;
            SharedContainerMap sharedMap = (SharedContainerMap) objR.getObject();
            Persistable sharedObject = sharedMap.getShared();
            String sharedObjectNumber = getNumber(sharedObject);
            if (sharedObjectNumber.equals(number)) {
                ObjectReference targetFolderRef = sharedMap.getTargetFolderRef();
                Folder targetFolder = (Folder) targetFolderRef.getObject();
                LOG.debug("target folder for object " + number + " is" + targetFolder.getFolderPath());
                return targetFolder;
            }
        }
        return null;
    }

    private void shareSelectedObjects(WTContainerRef projReference, Collection selectedFromTable) throws WTException {
        WTArrayList sharedMaps = ProjectHelper.getSharedContainerMapsForProject((Project2) projReference.getObject());
        for (Object selected : selectedFromTable) {
            NmOid nmoid = NmCommandBean.getOidFromObject(selected);
            Persistable refObject = (Persistable) nmoid.getRefObject();
            Folder sharedFolder = getSharedFolder(sharedMaps, getNumber(refObject));
            LOG.debug("Sharing object " + getNumber(refObject));
            ProjectHelper.updateItemInProject(refObject, projReference, sharedFolder);
        }
    }
}
