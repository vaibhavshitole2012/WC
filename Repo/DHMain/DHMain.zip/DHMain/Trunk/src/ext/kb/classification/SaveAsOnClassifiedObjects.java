package ext.kb.classification;

import java.rmi.RemoteException;
import java.util.Set;
import java.util.TreeMap;

import org.apache.log4j.Logger;

import com.ptc.core.meta.common.AttributeTypeIdentifier;
import com.ptc.generic.iba.AttributeService;

import ext.kb.listener.delegate.poststore.SaveAsListenerDelegate;
import ext.kb.util.IBAHelper;
import ext.kb.util.KBDocumentUtils;
import wt.enterprise.RevisionControlled;
import wt.facade.classification.ClassificationFacade;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.iba.definition.litedefinition.AttributeDefDefaultView;
import wt.iba.value.AbstractValue;
import wt.iba.value.DefaultAttributeContainer;
import wt.iba.value.IBAHolder;
import wt.iba.value.litevalue.AbstractValueView;
import wt.log4j.LogR;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;

public class SaveAsOnClassifiedObjects {
	private static final Logger LOGGER = LogR.getLogger(SaveAsOnClassifiedObjects.class.getName());
	private static final String KB_CSM_PART_CLASSIFICATION="KB_CSM_PART_CLASSIFICATION";
	private static final String KB_Standardizable="KB_Standardizable";
	private static final String KB_NonStandardizable="KB_NonStandardizable";
	private static final String KB_ParametricAssembly="KB_ParametricAssembly";
	private static final String KB_ParametricPart="KB_ParametricPart";
	private static final String KB_EKLA="KB_EKLA";
	private static final String KB_HVAC_PROC_SITES="KB_HVAC_PROC_SITES";
	private static final String KB_GROUP="KB_GROUP";
	private static final String KB_EKLA_O="O";
	private static final String KB_EKLA_H="H";
	private static final String KB_EKLA_Z="Z";
	private static final String KB_EKLA_NA="NA";
	
	public static void copyClassificationonTarget(RevisionControlled original,RevisionControlled saveAsCopy,Object classificationAttribute){
		LOGGER.debug("Classname ::"+classificationAttribute.getClass().getName());
		LOGGER.debug("CLass :: "+classificationAttribute.getClass());
		LOGGER.debug("Part" + original + " has classification: "+classificationAttribute);
		try{
		if(classificationAttribute instanceof String){
			LOGGER.debug("classificationAttribute ::"+classificationAttribute);
			String classificationattr=(String) classificationAttribute;
			LOGGER.debug("classificationattr ::"+classificationattr);
			IBAHelper.setIba((IBAHolder) saveAsCopy, KB_CSM_PART_CLASSIFICATION, classificationattr);
			TreeMap<String, String> kbstandardizableMap = KBDocumentUtils.getEnumerationKeysAndValues(KB_Standardizable);
			TreeMap<String, String> kbnonstandardizableMap = KBDocumentUtils.getEnumerationKeysAndValues(KB_NonStandardizable);
			TreeMap<String, String> kbparametricAssemblyMap = KBDocumentUtils.getEnumerationKeysAndValues(KB_ParametricAssembly);
			TreeMap<String, String> kbparametricPartMap = KBDocumentUtils.getEnumerationKeysAndValues(KB_ParametricPart);

			LOGGER.debug("kbstandardizableMap size :: "+kbstandardizableMap.size());
			if(kbstandardizableMap.containsKey(classificationattr)){
				IBAHelper.setIba((IBAHolder) saveAsCopy, KB_EKLA, KB_EKLA_O);
				clearIBAValue(saveAsCopy, KB_HVAC_PROC_SITES);
			}else if(kbnonstandardizableMap.containsKey(classificationattr)){
				IBAHelper.setIba((IBAHolder) saveAsCopy, KB_EKLA, KB_EKLA_NA);
				clearIBAValue(saveAsCopy, KB_HVAC_PROC_SITES);
			}else if(kbparametricAssemblyMap.containsKey(classificationattr)){
				String ekla=AttributeService.getAttribute(original, KB_EKLA);
				if(ekla.equals(KB_EKLA_NA) || ekla.equals(KB_EKLA_H) || ekla.equals(KB_EKLA_Z))
					IBAHelper.setIba((IBAHolder) saveAsCopy, KB_EKLA, KB_EKLA_NA);				
				clearIBAValue(saveAsCopy, KB_HVAC_PROC_SITES);

				
				}else if(kbparametricPartMap.containsKey(classificationattr)){
				String ekla=AttributeService.getAttribute(original, KB_EKLA);
				if(ekla.equals(KB_EKLA_H)){
					IBAHelper.setIba((IBAHolder) saveAsCopy, KB_EKLA, KB_EKLA_Z);
				}
				
				if(ekla.equals(KB_EKLA_Z)){
					IBAHelper.setIba((IBAHolder) saveAsCopy, KB_EKLA, KB_EKLA_O);
				}
				if(!ekla.equals(KB_EKLA_H)){
					clearIBAValue(saveAsCopy, KB_HVAC_PROC_SITES);
				}
			
			}
			clearOtherAttributes(classificationAttribute, original, saveAsCopy);
			} else if(classificationAttribute instanceof Object[]){							
				try
		        { 
		            throw new WTException("Part has multiple classification nodes"); 
		        } 
		        catch(WTException e) 
		        { 
		            System.out.println("Part has multiple classification nodes"); 
		            e.printStackTrace();
		        } 
				
			}
		
		
	} catch (RemoteException e) {
		LOGGER.error(e.getLocalizedMessage(),e);
	} catch (WTException e) {
		LOGGER.error(e.getLocalizedMessage(),e);
	} catch (WTPropertyVetoException e) {
		LOGGER.error(e.getLocalizedMessage(),e);
	}
		
	}
	
	private static void clearIBAValue(Persistable object,String ibaname) throws WTException, RemoteException {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("entering clearIBAValue(Persistable)");
			LOGGER.debug("object: " + object);
		}
		AttributeDefDefaultView attributeDefDefaultView = IBAHelper
				.getAttributeDefDefaultView(ibaname);
		DefaultAttributeContainer attributeContainer = IBAHelper.getRefreshableAttributeContainer((IBAHolder) object,
				true);
		AbstractValueView abstractValueViews[] = attributeContainer.getAttributeValues(attributeDefDefaultView);
		for (int i = 0; i < abstractValueViews.length; i++) {
			AbstractValue abstractValue = (AbstractValue) PersistenceHelper.manager
					.refresh(abstractValueViews[i].getObjectID());
			PersistenceHelper.manager.delete(abstractValue);
		}
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("exiting clearIBAValue()");
		}
	}
	
	private static void clearOtherAttributes(Object classificationAttribute,RevisionControlled original,RevisionControlled saveAsCopy){
		try{
		ClassificationFacade facadeInstance = ClassificationFacade.getInstance();
		Set<AttributeTypeIdentifier> atis = facadeInstance.getClassificationAttributes((String) classificationAttribute); 
		
		for(AttributeTypeIdentifier ati :atis){
		
		System.out.println(ati.getAttributeName());
		if(!(ati.getAttributeName().equals(KB_EKLA) || ati.getAttributeName().equals(KB_HVAC_PROC_SITES) || ati.getAttributeName().equals(KB_GROUP))){
			Object sourcevalue=AttributeService.getAttribute(original, ati.getAttributeName());
			System.out.println("sourcevalue :: "+sourcevalue);
			if(sourcevalue!=null){
			System.out.println("soucevalue :: "+sourcevalue.getClass().getName());
			
				clearIBAValue(saveAsCopy, ati.getAttributeName());
			
			}
		}
		}
		}catch(WTException e){
			LOGGER.error(e.getLocalizedMessage(),e);
		} catch (RemoteException e) {
			LOGGER.error(e.getLocalizedMessage(),e);
		}
		
	}

}
