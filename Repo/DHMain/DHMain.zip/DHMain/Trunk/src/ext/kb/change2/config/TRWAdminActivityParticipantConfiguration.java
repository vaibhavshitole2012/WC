/**
 * 
 */
package ext.kb.change2.config;

import java.util.HashSet;
import java.util.Set;

import org.apache.log4j.Logger;

import com.ptc.core.components.beans.FormDataHolder;
import com.ptc.windchill.enterprise.wizardParticipant.configuration.DefaultParticipantConfiguration;

import ext.kb.util.KBConstants;
import wt.project.Role;
import wt.util.WTException;

/**
 * @author ebankowski
 *
 */
public class TRWAdminActivityParticipantConfiguration extends DefaultParticipantConfiguration{
        private static final Logger LOGGER = Logger.getLogger(TRWAdminActivityParticipantConfiguration.class.getName());
       
        @Override
        public Set<Role> excludedWorkflowRoles(FormDataHolder formData) throws WTException {                 
                       HashSet<Role> hashset = new HashSet<Role>();
                       hashset.add(KBConstants.ASSIGNEE_ROLE);
                       hashset.add(Role.toRole("BONDING ENGINEER"));
                       hashset.add(Role.toRole("MANUFACTURING ENGINEER"));
                       hashset.add(Role.toRole("RELEASE MANAGER"));
                       hashset.add(Role.toRole("WELDING ENGINEER"));
                       hashset.add(Role.toRole("WF-NOTIFICATION-RECIPENT"));
                       return hashset;

        }
}

