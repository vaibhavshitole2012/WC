package ext.kb.businessrule.validation.dto;


public class ValidationReport {

	private Object targetObject = null;
	
	private ProblemWith problemWith = null;
	
	private String additionalInfo = null;
	
	public ValidationReport(){
		
	}
	
	public ValidationReport(Object aTargetObject,ProblemWith aProblemWith){
		this.targetObject = aTargetObject;
		this.problemWith = aProblemWith;
	}

	public Object getTargetObject() {
		return targetObject;
	}

	public void setTargetObject(Object targetObject) {
		this.targetObject = targetObject;
	}

	public ProblemWith getProblemWith() {
		return problemWith;
	}

	public void setProblemWith(ProblemWith problemWith) {
		this.problemWith = problemWith;
	}

	public String getAdditionalInfo() {
		return additionalInfo;
	}

	public void setAdditionalInfo(String additionalInfo) {
		this.additionalInfo = additionalInfo;
	}
}
