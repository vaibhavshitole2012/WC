package ext.kb.businessrule.validation;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Set;

import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.*;
import ext.wfHelper.KB_AdvReleasePendingProcessHelper;

import org.apache.log4j.Logger;
import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.core.businessRules.validation.RuleValidationCriteria;
import com.ptc.core.businessRules.validation.RuleValidationKey;

import ext.kb.piint.resource.PiInterfaceRB;
import ext.kb.piint.service.PiInterfaceService;
import ext.kb.piint.util.InterfaceWorkflowHelper;
import wt.change2.WTChangeActivity2;
import wt.doc.WTDocument;
import wt.doc.WTDocumentMaster;
import wt.epm.EPMDocument;
import wt.fc.Persistable;
import wt.log4j.LogR;
import wt.representation.PublishedContentLink;
import wt.services.ServiceFactory;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.WTProperties;
import wt.vc.Mastered;

public class KBDocNumberUniquenessValidator extends KBValidation {

    private static final String KBCADDOC = "KBCADDOC";
    private static final String KBCADDRW = "KBCADDRW";
    private static final String TECHDRWDOC = "TECHDRWDOC";
    private static final String NEUTRAL_DATA = "NEUTRALDATA";
    private static final String TECHNICAL_DRAWING_TYPE = "com.ptc.KBTechnicalDrawing";
    protected static final Logger LOG = LogR.getLogger(KBDocNumberUniquenessValidator.class.getName());
    protected static final String RESOURCE = "ext.kb.piint.resource.PiInterfaceRB";
    private static final String KB_ORG = "KB";
    private static final String WCT = "WCT";
    private static boolean interfacesActivated = false;
    private static final String CHECK_IF_EXIST_TECHDRW_PROPERTY = "ext.kb.KBDocNumberUniquenessValidator.checkIfExistTechDrw";

    static {
        WTProperties properties = null;
        try {
            properties = WTProperties.getServerProperties();
        } catch (IOException e) {
            LOG.error("Error in reading property file");
        }

        interfacesActivated = Boolean.valueOf(properties.getProperty("ext.kb.piint.activateInterfaces", "false"));
        LOG.debug("interfacesActivated===" + interfacesActivated);
    }

    @Override
    public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
    		List<RuleFeedbackMessage> paramList, RuleValidationKey validationKey) throws WTException {
    	
        boolean isRuleValid = true;
        Object processingMapValue = validationKey.getProcessingMapValue(ECT);
        Persistable currentECT = (Persistable) processingMapValue;
        boolean skipTransfer = KB_AdvReleasePendingProcessHelper.skipTransferToCadim(currentECT);

        if (shouldCheckIfExistTechDrw(CHECK_IF_EXIST_TECHDRW_PROPERTY) && paramPersistable instanceof EPMDocument) {
            EPMDocument drwToBeReleased = (EPMDocument) paramPersistable;
            boolean isKBOrg = KB_ORG.equalsIgnoreCase(drwToBeReleased.getOrganizationName());
            String number = drwToBeReleased.getNumber();
            LOG.debug("Looking for related technical drawing with number" + number);
            WTDocument document = KBUtils.findDocumentByNumber(number);
            document = document != null ? (WTDocument) ObjectRevisionHelper.getLatestVersionByPersistable(document) : null;
            if (isKBOrg && KBType.isOfType(document, TECHNICAL_DRAWING_TYPE)) {
                paramList.add(getErrorMessage(number, PiInterfaceRB.NUMBER_IS_USED_BY_TECHDRW));
                return false;
            }
        }

        if (!skipTransfer && interfacesActivated && paramPersistable instanceof EPMDocument) {
            try {
                EPMDocument drwToBeReleased = (EPMDocument) paramPersistable;
                boolean isKBCadDoc = KBTypeIdProvider.isDescendant(drwToBeReleased, KBCADDOC);
                boolean isKBCadDrw = KBTypeIdProvider.isDescendant(drwToBeReleased, KBCADDRW);
                boolean isKBOrg = KB_ORG.equalsIgnoreCase(drwToBeReleased.getOrganizationName());

                if ((isKBOrg && isKBCadDrw) || (!isKBOrg && isKBCadDoc)) {
                    isRuleValid = isObjectValid(paramList, drwToBeReleased);
                }
            } catch (Exception localException) {
                String number = ((EPMDocument) paramPersistable).getNumber();
                LOG.error("Unexpected error while validating attribute rule.", localException);
                LOG.error("Error message ===." + localException.getMessage());
                LOG.error("Number of EPMDocument with error ===." + number);
                paramList.add(getErrorMessage(number, PiInterfaceRB.PI_DOCUMENT_NUMBER_EXISTS_IN_DOWNSTREAMSYSTEM));
                isRuleValid = false;
            }
        }
        return isRuleValid;
    }

    private boolean shouldCheckIfExistTechDrw(String property) {
       boolean  interfacesActivated = false;
        try{
            WTProperties properties = WTProperties.getServerProperties();
            interfacesActivated = Boolean.valueOf(properties.getProperty("ext.kb.KBDocNumberUniquenessValidator.checkIfExistTechDrw", "false"));
        }catch (Exception ex){
            LOG.error("Error in reading property file: " + property);
        }
        return interfacesActivated;
    }

    private boolean isObjectValid(List<RuleFeedbackMessage> paramList, EPMDocument drwToBeReleased) throws WTException {
        boolean isObjectValid = true;
        List<WTDocument> published = DBUtils.navigateBetweenObjects(WTDocument.class, PublishedContentLink.class, drwToBeReleased, PublishedContentLink.PUBLISHED_CONTENT_HOLDER_ROLE);
        String docNumber = drwToBeReleased.getNumber();
        WTDocument latestIteration = (WTDocument) InterfaceWorkflowHelper.getLatestIteration(WTDocument.class, WTDocument.NUMBER, docNumber, null, null);
        LOG.debug("published documents number ===" + published.size());
        LOG.debug("docNumber ==" + docNumber);
        LOG.debug("WTDocument.CONTAINER_ID ==" + WTDocument.CONTAINER_ID);
        LOG.debug("containerRef.toString() ==" + drwToBeReleased.getContainerReference().toString());

        if (latestIteration != null && KBUtils.isEmpty(published)) {
        	
            isObjectValid = validateRelatedWTDocument(paramList, drwToBeReleased, latestIteration);
        }
        LOG.debug("KBTypeIdProvider.isDescendant(drwToBeReleased,KBCADDRW) :: "+KBTypeIdProvider.isDescendant(drwToBeReleased,KBCADDRW));
        if(KBTypeIdProvider.isDescendant(drwToBeReleased,KBCADDRW)){
        	String DOC_ID = IBAHelper.readIBA(drwToBeReleased, KBConstants.KBDOCUMENT_ID_IBA);
			String sapid=IBAHelper.readIBA(drwToBeReleased,KBConstants.KBSAP_IDX_IBA);
			String docnumber=DOC_ID+"-"+sapid;
			LOG.debug("docnumber :: " + docnumber + " " + DOC_ID + " " + DOC_ID.length());
			if(!drwToBeReleased.getNumber().equals(docnumber)){
				LOG.debug("drwToBeReleased.getNumber().equals(docnumber)");
				paramList.add(getErrorMessage(drwToBeReleased.getName(), PiInterfaceRB.INVALID_CAD_DRAWING_NUMBER));
				isObjectValid=false;
			} 
			// check for doc number length
			if (DOC_ID.length() > 19) {
				LOG.debug("Document number length is greater than 19.");
				paramList.add(new RuleFeedbackMessage(new WTMessage(KBValidation.RESOURCE,
						BusinessRuleRB.KB_EPM_HAS_TOO_LONG_NUMBER, new Object[] { docNumber }), getFeedbackType()));
				isObjectValid = false;
			}
			
        }
        if (isObjectValid && latestIteration == null && KBUtils.isEmpty(published)) {
            LOG.debug("Did not find doc with same number in the container.");
            PiInterfaceService service = ServiceFactory.getService(PiInterfaceService.class);
            service.performEPMDocumentNumberCheck(drwToBeReleased);
        }
        return isObjectValid;
    }

    private boolean validateRelatedWTDocument(List<RuleFeedbackMessage> paramList, EPMDocument drwToBeReleased, WTDocument latestIteration) {
        String masterSystem = IBAHelper.readIBA(latestIteration.getMaster(), KBConstants.KB_MASTERSYSTEM);
        boolean isObjectValid = true;
   
        LOG.debug("Found a document with same number in container");
        
        if (!(KBTypeIdProvider.isDescendant(latestIteration, TECHDRWDOC) || KBTypeIdProvider.isDescendant(latestIteration, NEUTRAL_DATA))) {
            LOG.debug("Did not find a techDrw or neutral data doc with same number in the container.");
            PiInterfaceService service = ServiceFactory.getService(PiInterfaceService.class);
            service.performEPMDocumentNumberCheck(drwToBeReleased);
        } else if (KBType.isOfType(latestIteration, TECHNICAL_DRAWING_TYPE) && !WCT.equals(masterSystem)) {
            paramList.add(getErrorMessage(drwToBeReleased.getNumber(), PiInterfaceRB.PI_DOCUMENT_NUMBER_EXISTS_WITH_INCORRECT_MASTERSYSTEM));
            isObjectValid = false;
        }
        return isObjectValid;
    }

    private RuleFeedbackMessage getErrorMessage(String docNumber, String errorMessage) {
        return new RuleFeedbackMessage(new WTMessage(RESOURCE, errorMessage, new Object[]{docNumber}),
                getFeedbackType());
    }
    
    @Override
    public void prepareForValidation(RuleValidationKey ruleValidationKey, RuleValidationCriteria ruleValidationCriteria) throws WTException {
        ruleValidationKey.addToProcessingMap(ECT, ruleValidationCriteria.getPrimaryBusinessObject());
    }
    
	@Override
	public boolean isRulesValid(Persistable paramPersistable,
			Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList) throws WTException {
		return false;
	}
	
}
