package ext.kb.change2.dataUtilities;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.rendering.GuiComponent;
import com.ptc.core.components.rendering.guicomponents.GUIComponentArray;
import com.ptc.core.components.rendering.guicomponents.PickerInputComponent;
import com.ptc.core.ui.resources.ComponentMode;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import com.ptc.windchill.enterprise.change2.AddToChangeTaskHelper;
import com.ptc.windchill.enterprise.change2.ChangeManagementClientHelper;
import com.ptc.windchill.enterprise.change2.ChangeManagementDescriptorConstants;
import com.ptc.windchill.enterprise.change2.dataUtilities.ChangePrincipalDataUtility;
import ext.kb.workflow.ChangeTaskUtils;
import wt.util.WTException;

import java.util.Map;

public class KBChangePrincipalDataUtility extends ChangePrincipalDataUtility {

    private static final String REVIEWER = ChangeManagementDescriptorConstants.ColumnIdentifiers.REVIEWER;

    @Override
    public Object getDataValue(String component_id, Object object, ModelContext mc) throws WTException {
        Object value = super.getDataValue(component_id, object, mc);

        if (REVIEWER.equals(component_id) && ChangeTaskUtils.isAllowedBlankReviewer()) {
            ComponentMode mode = ChangeManagementClientHelper.getMode(mc);
            NmCommandBean commandBean = mc.getNmCommandBean();
            if (ComponentMode.CREATE.equals(mode) && !AddToChangeTaskHelper
                    .isAddToChangeTaskWizard(commandBean)) {
                setEmptyReviewerByDefault((GUIComponentArray) value);
            }
        }
        return value;
    }

    private void setEmptyReviewerByDefault(GUIComponentArray value) {
        try {
            if (value.size() > 0 && value.get(0) instanceof PickerInputComponent) {
                PickerInputComponent picker = (PickerInputComponent) value.get(0);
                Map<String, String> pickerParamMap = picker.getPickerParamMap();
                pickerParamMap.put("defaultValue", null);
                picker.getDefaultValue();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }
}
