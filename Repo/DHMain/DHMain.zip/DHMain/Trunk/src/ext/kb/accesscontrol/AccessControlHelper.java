package ext.kb.accesscontrol;

import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.generic.iba.AttributeService;
import ext.kb.util.*;
import org.apache.log4j.Logger;
import wt.access.AccessPermission;
import wt.access.AccessPermissionSet;
import wt.access.AccessPolicyRule;
import wt.access.WTAclEntry;
import wt.admin.AdminDomainRef;
import wt.admin.AdministrativeDomain;
import wt.doc.WTDocument;
import wt.epm.EPMDocument;
import wt.fc.ObjectIdentifier;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerHelper;
import wt.inf.container.WTContainerRef;
import wt.inf.team.ContainerTeamManaged;
import wt.log4j.LogR;
import wt.org.*;
import wt.part.WTPart;
import wt.pdmlink.PDMLinkProduct;
import wt.project.Role;
import wt.projmgmt.admin.Project2;
import wt.services.ac.ACRuntimeException;
import wt.session.SessionHelper;
import wt.type.Typed;
import wt.type.TypedUtilityServiceHelper;
import wt.util.WTException;
import wt.util.WTProperties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.rmi.RemoteException;
import java.util.*;

/**
 * Helper class for KB authorization checks.
 *
 * @author kissn
 */
public class AccessControlHelper {

	protected static final Logger LOGGER = LogR.getLogger(AccessControlHelper.class.getName());

	private static final TypeIdentifier ARTICLE_TYPE = KBTypeIdProvider.getType("ARTICLE");

	private static final TypeIdentifier DOC_TYPE = KBTypeIdProvider.getType("KBCADDOC");

	private static final String WTCONTAINER_NAVIGATION_DELEGATE_CONTAINER_LOGIN_STAMPS = "WTContainerNavigationDelegate-ContainerLoginStamps";

	private static final String ALLOWED_ROLES_PROPERTY_NAME = "shared.objects.download.allowed.roles";

	private static ArrayList<Role> allowedRoles = new ArrayList<>();

	static {
		try {
			WTProperties props = WTProperties.getLocalProperties();
			String property = props.getProperty(ALLOWED_ROLES_PROPERTY_NAME);
			if (!KBUtils.isEmpty(property)) {
				String[] splitedProperty = property.split(",");
				for (String value : splitedProperty) {
					if (!KBUtils.isEmpty(value)) {
						Role role = Role.toRole(value);
						allowedRoles.add(role);
					}
				}
			}
		} catch (IOException ex) {
			throw new ACRuntimeException(
					"ext.kb.accesscontrol.AccessControlHelper startup failure, check property: shared.objects.download.allowed.roles");
		}

	}

	private AccessControlHelper() {
	}

	/**
	 * Extracts and checks gekla attribute of incoming object. Works for
	 * KBArticle and KBCADDoc.
	 *
	 * @param lcmTarget
	 * @return
	 */
	public static final boolean isGeklaAuthorized(Typed lcmTarget) {

		Object o = getAuthorizedGekla(lcmTarget);
		if (o == null || "-1".equals(o)) {
			return false;
		}
		return true;
	}

	/**
	 * Extracts and checks gekla attribute of incoming object. Works for
	 * KBArticle and KBCADDoc.
	 *
	 * @param lcmTarget
	 * @return
	 */
	public static final Object getAuthorizedGekla(Typed lcmTarget) {
		if (lcmTarget != null) {
			try {
				TypeIdentifier targetType = wt.type.TypedUtilityServiceHelper.service.getTypeIdentifier(lcmTarget);
				if (targetType.isDescendedFrom(ARTICLE_TYPE) || targetType.isDescendedFrom(DOC_TYPE)) {
					Object geklaId = AttributeService.getAttribute(lcmTarget, KBConstants.GEKLA_IBA);
					if (geklaId == null) {
						return "-1";
					}
					return checkAuthorizedGekla(String.valueOf(geklaId));
				}
			} catch (WTException e) {
				LOGGER.error("Authorization failed, denying access", e);
			}
		}
		return null;
	}

	/**
	 * Checks if user has permissions to the gekla represented by String.
	 *
	 * @param geklaNumber
	 * @return - Gekla object if user is permitted
	 * @throws WTException - if string value doesn't represent a gekla number
	 */
	public static final Object checkAuthorizedGekla(String geklaNumber) throws WTException {
		Object sourceGekla = null; // query based on lcmTarget
		LOGGER.debug("Querying database with id: " + geklaNumber);
		QueryResult query = ext.kb.util.KBUtils.getItem(WTPart.class, "master>number", geklaNumber);
		LOGGER.debug("Found " + query.size() + " items");
		while (query.hasMoreElements()) {
			WTPart part = (WTPart) query.nextElement();
			if(!part.isLatestIteration()){
				continue;
			}
			LOGGER.debug("sourceGekla:" + part.getName());
			if (part != null) {
				boolean isGekla = KBTypeIdProvider.isDescendant(part, "GEKLA");
				if (isGekla) {
					sourceGekla = part;
				}
			}
		}
		if (sourceGekla == null) {
			throw new RuntimeException("Please set a value for the GeKla Attribute, the entered value of '"
					+ geklaNumber + "' is not valid!");
		}
		boolean authorized = wt.access.AccessControlHelper.manager.checkAccess(sourceGekla, AccessPermission.DOWNLOAD); // this
		// can
		// throw
		// NotAuthorizedExceptions
		// as
		// well
		if (authorized) {
			return sourceGekla;
		}
		return null;
	}

	/**
	 * Checks if Download action was invoked on WTDoc or EPMDoc and project as
	 * context.
	 *
	 * @param request - HTTP request.
	 * @return true if user has Download access on source context or is in
	 * Project Viewer role in project.
	 */
	public static boolean isNeededToCheckDownloadAccess(HttpServletRequest request) throws WTException {
		Persistable contentHolder = getContentHolder(request);
		Persistable invokedFromContainer = getInvokedFromContainer(request);
		boolean isContentHolderDocumentOrCad = contentHolder instanceof WTDocument
				|| contentHolder instanceof EPMDocument;
		boolean isInvokedFromProject = invokedFromContainer instanceof Project2;
		boolean isInvokedFromProduct = invokedFromContainer instanceof PDMLinkProduct;
		
		if (isContentHolderDocumentOrCad && (isInvokedFromProject || isInvokedFromProduct)) {
			LOGGER.debug(
					"Need to check Download access. Content holder is WTDocument or EPMDocument. Download action invoked from Project/Product.");
			return true;
		} else {
			LOGGER.debug(
					"No need to perform Download action access check. Not valid type or action not invoked from Project/Product.");
			return false;
		}
	}

	/**
	 * Checks if user is able to Download shared to project object (from project
	 * context).
	 *
	 * @param request - HTTP request.
	 * @return true if user has Download access on source context or is in
	 * Project Viewer role in project.
	 */
	public static boolean isUserAuthorizedToDownloadSharedObject(HttpServletRequest request)
			throws WTException, RemoteException {
		Persistable contentHolder = getContentHolder(request);
		Persistable projectContainer = getInvokedFromContainer(request);
		WTPrincipal principal = SessionHelper.getPrincipal();
		WTContainer sourceContainer = getSourceContainer(contentHolder);
		boolean isUserInAllowedRole = isUserInAllowedRole(principal, (ContainerTeamManaged) projectContainer);

		boolean isAdmin = WTContainerHelper.service.isAdministrator(sourceContainer.getContainerReference(), principal,
				true);
		if (isAdmin || isUserInAllowedRole || hasUserDownloadAccessGrantedInProduct(contentHolder, sourceContainer)) {
			return true;
		} else {
			return false;
		}
	}

	private static boolean isUserInAllowedRole(WTPrincipal principal, ContainerTeamManaged projectContainer)
			throws WTException {
		for (Role role : allowedRoles) {
			if (KBTeamUtils.isUserInRole(principal, (ContainerTeamManaged) projectContainer, role))
				return true;
		}
		return false;
	}

	private static Persistable getContentHolder(HttpServletRequest request) throws WTException {
		ReferenceFactory referenceFactory = new ReferenceFactory();
		String contentHolderOid = request.getParameter("oid");
		return referenceFactory.getReference(contentHolderOid).getObject();
	}

	private static Persistable getInvokedFromContainer(HttpServletRequest request) throws WTException {
		ReferenceFactory referenceFactory = new ReferenceFactory();
		HttpSession session = request.getSession();
		Object attribute = session.getAttribute(WTCONTAINER_NAVIGATION_DELEGATE_CONTAINER_LOGIN_STAMPS);
		if (attribute instanceof HashMap) {
			Set keySet = ((HashMap) attribute).keySet();
			Object result = null;
			for (Object key : keySet) {
				if (key instanceof ObjectIdentifier) {
					result = referenceFactory.getReference(((ObjectIdentifier) key).getStringValue()).getObject();
					if (result instanceof Project2 || result instanceof PDMLinkProduct) {
						return (Persistable) result;
					}
				}
			}
		}
		return null;
	}

	private static WTContainer getSourceContainer(Persistable contentHolder) {
		AdminDomainRef sourceDomainRef = getSourceDomainRef(contentHolder);
		AdministrativeDomain sourceDomain = (AdministrativeDomain) sourceDomainRef.getObject();
		return sourceDomain.getContainer();
	}

	private static AdminDomainRef getSourceDomainRef(Persistable contentHolder) {
		if (contentHolder instanceof WTDocument) {
			return ((WTDocument) contentHolder).getDomainRef();
		} else {
			return ((EPMDocument) contentHolder).getDomainRef();
		}
	}

	private static List<WTRolePrincipal> getPrincipalRolesFromSourceContainer(WTContainer sourceContainer)
			throws WTException {
		WTPrincipal principal = SessionHelper.getPrincipal();
		WTContainerRef sourceContainerReference = sourceContainer.getContainerReference();
		Set<WTGroup> userGroupMemberships = KBTeamUtils.getUserGroupMemberships(principal,
				(ContainerTeamManaged) sourceContainer);
		List<WTRolePrincipal> principalRoles = new ArrayList<>();
		for (WTGroup group : userGroupMemberships) {
			if (group.isInternal()) {
				String groupName = group.getName();
				WTRolePrincipal rolePrincipal = OrganizationServicesHelper.manager.getRolePrincipal(groupName, sourceContainerReference, false, null);
				if(null != rolePrincipal) {
					LOGGER.debug(principal.getName() + " is in " + groupName + " role in " + sourceContainer.getContainerName());
					principalRoles.add(rolePrincipal);
				}
				
			}
		}
		return principalRoles;
	}

	private static boolean hasUserDownloadAccessGrantedInProduct(Persistable contentHolder, WTContainer sourceContainer)
			throws WTException, RemoteException {
		AdminDomainRef parentDomainRef = getSourceDomainRef(contentHolder);
		Enumeration accessPolicyRulesFromParentDomain = wt.access.AccessControlHelper.manager
				.getAccessPolicyRules(parentDomainRef);
		List<WTRolePrincipal> principalRoles = getPrincipalRolesFromSourceContainer(sourceContainer);
		while (accessPolicyRulesFromParentDomain.hasMoreElements()) {
			AccessPolicyRule accessPolicyRule = (AccessPolicyRule) accessPolicyRulesFromParentDomain.nextElement();
			Enumeration entries = wt.access.AccessControlHelper.manager.getEntries(accessPolicyRule);
			String typeId = accessPolicyRule.getSelector().getTypeId();
			String typeIdFromEntry = TypedUtilityServiceHelper.service.getExternalTypeIdentifier(typeId);
			if (KBType.isDescendedFrom(contentHolder, typeIdFromEntry) && isDownloadGranted(entries, principalRoles)) {
				return true;
			}
		}
		LOGGER.debug("User doesn't have granted Download permission in product.");
		return false;
	}

	private static boolean isDownloadGranted(Enumeration entries, List<WTRolePrincipal> principalRoles)
			throws WTException {
		while (entries.hasMoreElements()) {
			WTAclEntry entry = (WTAclEntry) entries.nextElement();
			if (isDownloadGrantedForAnyOfRoles(principalRoles, entry)) {
				return true;
			}
		}
		return false;
	}

	private static boolean isDownloadGrantedForAnyOfRoles(List<WTRolePrincipal> principalRoles, WTAclEntry entry)
			throws WTException {
		AccessPermissionSet permissionSet = entry.getPermissionSet();
		for (WTRolePrincipal role : principalRoles) {
			WTPrincipalReference wtPrincipalReference = WTPrincipalReference.newWTPrincipalReference(role);
			if (wtPrincipalReference.equals(entry.getPrincipalReference())
					&& permissionSet.contains(AccessPermission.DOWNLOAD)) {
				if(role != null) {
					LOGGER.debug(role.getDisplayName() + " role in source container has granted Download.");
					return true;
				}
			}
		}
		return false;
	}
}
