package ext.kb.builder.compconfig;

import java.util.List;
import java.util.Locale;

import com.ptc.cat.config.client.ActionConfig;
import com.ptc.cat.config.client.DefaultActionConfig;
import com.ptc.mvc.components.ComponentBuilder;
import com.ptc.mvc.components.ComponentBuilderType;
import com.ptc.mvc.components.OverrideComponentBuilder;
import com.ptc.windchill.enterprise.part.psb.server.PSBTreeConfigBuilder;

@ComponentBuilder(value="PSB.tree", type=ComponentBuilderType.CONFIG_ONLY)
@OverrideComponentBuilder
public class PSBTreeConfigBuilderExtension extends PSBTreeConfigBuilder  	 {

	@Override
	protected List<ActionConfig> getToolbarConfigOverrides(Locale locale) {
		List<ActionConfig> actionConfigs = super.getToolbarConfigOverrides(locale);
		actionConfigs.add(new DefaultActionConfig("weightReport", com.ptc.cat.config.client.ActionConfig.ButtonType.MENUITEM, null, null));
		actionConfigs.add(new DefaultActionConfig("bomCostRollupReport", com.ptc.cat.config.client.ActionConfig.ButtonType.MENUITEM, null, null));
		actionConfigs.add(new DefaultActionConfig("hvacDosReport", com.ptc.cat.config.client.ActionConfig.ButtonType.MENUITEM, null, null));
		actionConfigs.add(new DefaultActionConfig("hvacDosReportNew", com.ptc.cat.config.client.ActionConfig.ButtonType.MENUITEM, null, null));
		actionConfigs.add(new DefaultActionConfig("kbDosReport", com.ptc.cat.config.client.ActionConfig.ButtonType.MENUITEM, null, null));

		return actionConfigs;
	}
}
