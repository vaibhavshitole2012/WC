package ext.kb.action;

import wt.util.resource.RBEntry;
import wt.util.resource.RBPseudo;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("ext.kb.action.KBActionRB")
public final class KBActionRB extends WTListResourceBundle {

    @RBEntry("Set up CRB from ECB-CoC")
    public static final String PRIVATE_CONSTANT_11 = "KBWork.KBSetupParticipants1.description";

//    @RBEntry("Set up participants1")
//    public static final String PRIVATE_CONSTANT_12 = "KBWork.KBSetupParticipants1.title";

    @RBEntry("Set up CRB from ECB-CoC")
    public static final String PRIVATE_CONSTANT_13 = "KBWork.KBSetupParticipants1.tooltip";

    @RBEntry("group_added_from_user.png")
    @RBPseudo(false)
    public static final String PRIVATE_CONSTANT_14 = "KBWork.KBSetupParticipants1.icon";

    @RBEntry("Set up CRB from ECB-SfS")
    public static final String PRIVATE_CONSTANT_21 = "KBWork.KBSetupParticipants2.description";

//    @RBEntry("Set up participants2")
//    public static final String PRIVATE_CONSTANT_22 = "KBWork.KBSetupParticipants2.title";

    @RBEntry("Set up CRB from ECB-SfS")
    public static final String PRIVATE_CONSTANT_23 = "KBWork.KBSetupParticipants2.tooltip";

    @RBEntry("group_added_from_user.png")
    @RBPseudo(false)
    public static final String PRIVATE_CONSTANT_24 = "KBWork.KBSetupParticipants2.icon";

    @RBEntry("Set up 4 eye review")
    public static final String PRIVATE_CONSTANT_31 = "KBWork.KBSetupParticipants3.description";

//    @RBEntry("Set up participants3")
//    public static final String PRIVATE_CONSTANT_32 = "KBWork.KBSetupParticipants3.title";

    @RBEntry("Set up 4 eye review")
    public static final String PRIVATE_CONSTANT_33 = "KBWork.KBSetupParticipants3.tooltip";

    @RBEntry("group_added_from_user.png")
    @RBPseudo(false)
    public static final String PRIVATE_CONSTANT_34 = "KBWork.KBSetupParticipants3.icon";

    
    @RBEntry("Save as")
    public static final String PRIVATE_CONSTANT_41 = "changeNotice.kbSaveAs.description";

//    @RBEntry("Set up participants3")
//    public static final String PRIVATE_CONSTANT_32 = "KBWork.KBSetupParticipants3.title";

    @RBEntry("Save as")
    public static final String PRIVATE_CONSTANT_43 = "changeNotice.kbSaveAs.tooltip";

    @RBEntry("saveas.gif")
    @RBPseudo(false)
    public static final String PRIVATE_CONSTANT_44 = "changeNotice.kbSaveAs.icon";
    
    @RBEntry("Assign Procurement Site")
    public static final String PRIVATE_CONSTANT_51 = "axlentry.create_new_kb_procurement_part.description";

    @RBEntry("Assign Procurement Site")
    public static final String PRIVATE_CONSTANT_52 = "axlentry.create_new_kb_procurement_part.tooltip";
    
    @RBEntry("supplier.png")
    public static final String PRIVATE_CONSTANT_53 = "axlentry.create_new_kb_procurement_part.icon";
    
    
    @RBEntry("Setup Full Track ECB")
    public static final String PRIVATE_CONSTANT_61 = "KBWork.KBSetupFullTrackECB.description";

//    @RBEntry("Set up participants3")
//    public static final String PRIVATE_CONSTANT_32 = "KBWork.KBSetupParticipants3.title";

    @RBEntry("Setup Full Track ECB")
    public static final String PRIVATE_CONSTANT_63 = "KBWork.KBSetupFullTrackECB.tooltip";

    @RBEntry("group_added_from_user.png")
    @RBPseudo(false)
    public static final String PRIVATE_CONSTANT_64 = "KBWork.KBSetupFullTrackECB.icon";

}