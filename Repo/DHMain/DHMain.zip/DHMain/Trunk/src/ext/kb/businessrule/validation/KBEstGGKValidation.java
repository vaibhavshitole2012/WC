package ext.kb.businessrule.validation;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.ObjectUtils;
import org.apache.log4j.Logger;

import wt.fc.Persistable;
import wt.fc.WTReference;
import wt.lifecycle.State;
import wt.log4j.LogR;
import wt.part.WTPart;
import wt.units.FloatingPointWithUnits;
import wt.util.WTException;
import wt.util.WTMessage;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.core.businessRules.feedback.RuleFeedbackType;
import com.ptc.core.businessRules.validation.BOMReleaseRuleValidator;
import com.ptc.core.businessRules.validation.RuleValidationCriteria;
import com.ptc.core.businessRules.validation.RuleValidationKey;
import com.ptc.core.businessRules.validation.RuleValidationObject;
import com.ptc.core.businessRules.validation.RuleValidationResult;
import com.ptc.core.businessRules.validation.RuleValidationStatus;
import com.ptc.generic.iba.AttributeService;
import com.ptc.windchill.suma.axl.AXLPreference;
import com.ptc.windchill.suma.part.VendorPart;

import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.KBConstants;
import ext.kb.util.KBUtils;
import ext.kb.util.SupplierHelper;

public class KBEstGGKValidation extends KBValidation{

	protected static final Logger LOG = LogR.getLogger(KBEstGGKValidation.class.getName());
	
	//ootb validator is used to retrieve target states of resulting objects
	private final BOMReleaseRuleValidator bomRelRuleValidator;
	
	public KBEstGGKValidation(){
		bomRelRuleValidator = new BOMReleaseRuleValidator();
		
	}
	
	@Override
	public boolean isRulesValid(Persistable paramPersistable,
			Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> feedbackMessages) throws WTException {
		boolean isValid = true;
		
		WTPart part = (WTPart)paramPersistable;
		boolean isEbomPart = KBUtils.isEbomPart(part);
		if(!isEbomPart) {
			LOG.info("Found part is MBOM, will not take into account.");
			return isValid;
		}
		VendorPart vendorPart = SupplierHelper.getProcurementPartByAxlPreference(part,AXLPreference.PREFERRED);
		if(LOG.isDebugEnabled()){
			LOG.debug("Procurement Part exists on Preferred Site "+(vendorPart != null));
		}
		
		if(vendorPart == null){
			if(LOG.isDebugEnabled()){
				LOG.debug("No Procurement Part exists, rule returns with conflict");
			}
			addNoProcPartMessage(feedbackMessages);
			return isValid = false;
		}
		
		FloatingPointWithUnits estGGk = AttributeService.getAttribute(vendorPart, KBConstants.EST_GGK_IBA);
		if(LOG.isDebugEnabled()){
			LOG.debug("EST_GGK is:"+estGGk);
		}
		FloatingPointWithUnits ggk = AttributeService.getAttribute(vendorPart, KBConstants.GGK_IBA);
		if(LOG.isDebugEnabled()){
			LOG.debug("GGK is:"+ggk);
		}
		if(ggk != null || estGGk != null){
			return isValid;
		}
		
		if(LOG.isDebugEnabled()){
			LOG.debug("Neither EST_GGK nor GGK is set, rule returns with conflict");
		}
		
		addCostAttributesNotSetFeedbackMessage(feedbackMessages);
		return isValid = false;
	}

	
	private void addCostAttributesNotSetFeedbackMessage(List<RuleFeedbackMessage> paramList){
		 paramList
         .add(new RuleFeedbackMessage(new WTMessage(
                 RESOURCE, BusinessRuleRB.KB_GGK_AND_EST_GGK_NOT_SET_ERROR_MSG,null),
                 RuleFeedbackType.ERROR));
	}
	
	private void addNoProcPartMessage(List<RuleFeedbackMessage> paramList){
		 paramList
        .add(new RuleFeedbackMessage(new WTMessage(
                RESOURCE, BusinessRuleRB.KB_PROCUREMENT_PART_NOT_EXIST,null),
                RuleFeedbackType.ERROR));
	}
	
	@Override
	public RuleValidationResult performValidation(RuleValidationKey paramRuleValidationKey,
			RuleValidationObject paramRuleValidationObject, RuleValidationCriteria paramRuleValidationCriteria)
			throws WTException {
		
		WTReference targetObjectRef = paramRuleValidationObject.getTargetObject();
        Persistable targetObject = targetObjectRef.getObject();
        Map<Object,State> targetStatesByResultingObject = (Map)paramRuleValidationKey.getProcessingMapValue("TARGET_STATES_MAP");
        State targetState = targetStatesByResultingObject.get(targetObject);
        boolean isTargetState1050 = ObjectUtils.equals(targetState,KBConstants.RELEASED_STATE);
        boolean isTargetState1030 = ObjectUtils.equals(targetState,KBConstants.RELEASED_FOR_PLANNING_STATE);
        
        boolean targetStateMatches = isTargetState1030 || isTargetState1050;
        boolean isWTPart = targetObject instanceof WTPart;
        boolean isValidEbom = isWTPart ? KBUtils.isEbomPart((WTPart)targetObject) : false;

        if(LOG.isDebugEnabled()){
        	 LOG.debug("isWTPart is:"+isWTPart);
        	 LOG.debug("targetState is:"+targetState);
        	 LOG.error("targetStateMatches:"+targetStateMatches);
        	 LOG.debug("Is valid ebom: "+isValidEbom);
		}
        
        //If target state is 1030 or 1050 we execute the parent's performValidation method,
        //that will execute our business logic implemented in isValid method
        if(isWTPart && targetStateMatches && isValidEbom){
        	return super.performValidation(paramRuleValidationKey, paramRuleValidationObject, paramRuleValidationCriteria);
        }
        RuleValidationStatus ruleValidationStatus = RuleValidationStatus.SUCCESS;
        RuleValidationResult ruleValidationResult = new RuleValidationResult(ruleValidationStatus);
		return ruleValidationResult;
	}
	
	/*
	 *initialize TARGET_STATES_MAP in ruleValidationKey by release rule validator
	 */
	@Override
	public void prepareForValidation(RuleValidationKey ruleValidationKey, RuleValidationCriteria ruleValidationCrit) throws WTException {
		super.prepareForValidation(ruleValidationKey, ruleValidationCrit);
		bomRelRuleValidator.prepareForValidation(ruleValidationKey, ruleValidationCrit);
	}
}
