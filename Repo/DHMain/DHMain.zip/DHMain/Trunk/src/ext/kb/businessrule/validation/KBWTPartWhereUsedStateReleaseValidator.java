package ext.kb.businessrule.validation;

import com.ptc.core.businessRules.feedback.RuleFeedbackType;

public class KBWTPartWhereUsedStateReleaseValidator extends KBWTPartWhereUsedStateValidator { 
	
	public KBWTPartWhereUsedStateReleaseValidator() {
        setFeedbackType(RuleFeedbackType.ERROR);  
    } 

}  
