package ext.kb.businessrule.validation;

import java.util.List;
import java.util.Map;
import java.util.Set;

import ext.kb.util.KBType;
import wt.fc.Persistable;
import wt.util.WTException;
import wt.util.WTMessage;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.generic.iba.AttributeService;

import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.KBConstants;

public class KBGivenToCustomerValidation extends KBValidation {

    public static final String[] SUPPORTED_TYPES = new String[] { "com.ptc.KBTechnicalDocument",
            "com.ptc.KBTechnicalDrawing", "com.ptc.KBNeutralData", "com.ptc.KBSalesDrawing", "com.ptc.KBSalesDocument", "com.ptc.KBProjectInput" };
	
	@Override
	public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap, List<RuleFeedbackMessage> paramList) throws WTException {
        if (!isValidForValidation(paramPersistable)) {
            return true;
        }
		String givenToCustomer = AttributeService.getAttribute(paramPersistable, KBConstants.KB_GIVEN_TO_CUSTOMER_IBA);
		boolean result = "1".equals(givenToCustomer) || "2".equals(givenToCustomer);
		if (!result){
			paramList.add(new RuleFeedbackMessage(new WTMessage(RESOURCE, BusinessRuleRB.GIVEN_TO_CUSTOMER, new Object[]{}),
					getFeedbackType()));
		}
		return result;
	}

    private boolean isValidForValidation(Persistable persistable) {
        return KBType.isDescendedFromOneOfTypes(persistable, SUPPORTED_TYPES);
    }
}
