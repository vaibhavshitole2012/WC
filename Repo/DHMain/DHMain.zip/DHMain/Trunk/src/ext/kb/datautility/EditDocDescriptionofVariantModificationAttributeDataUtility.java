/**
 * class checks if the user is allowed to edit the IBA 'KB_DOCVAR_CUSTOMER_DESCRIPTION' - Description of Variant Modification
 * allowed users : admin, data manager, document manager
 * otherwise disable the IBA
 * INC #250769
 **/

package ext.kb.datautility;

import org.apache.log4j.Logger;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.dataUtilities.DefaultDataUtility;
import com.ptc.core.components.util.OidHelper;
import ext.kb.util.KBConstants;
import ext.kb.util.KBTeamUtils;
import ext.kb.util.KBTypeIdProvider;
import ext.kb.util.KBUtils;
import wt.doc.WTDocument;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerHelper;
import wt.inf.team.ContainerTeamManaged;
import wt.log4j.LogR;
import wt.org.WTPrincipal;
import wt.session.SessionHelper;
import wt.util.WTException;

public class EditDocDescriptionofVariantModificationAttributeDataUtility extends DefaultDataUtility {

	private static final Logger LOG = LogR
			.getLogger(EditDocDescriptionofVariantModificationAttributeDataUtility.class.getName());
	
	@Override
	public Object getDataValue(String paramString, Object paramObject,
			ModelContext paramModelContext) throws WTException {
		LOG.debug("INSIDE EditDocDescriptionofVariantModificationAttributeDataUtility");
		Object dataValue = getDataValueInternal(paramString, paramObject,
				paramModelContext);
		boolean isTechDoc = KBTypeIdProvider.isDescendant(paramObject,
				KBConstants.TECHNICAL_DOCUMENT_TYPE);
		boolean isTechDrwDoc = KBTypeIdProvider.isDescendant(paramObject,
				KBConstants.TECHNICAL_DRAWING_TYPE);
		boolean isCertificate = KBTypeIdProvider.isDescendant(paramObject,
				KBConstants.CERTYFICATE_TYPE);
		boolean isStandardDoc = KBTypeIdProvider.isDescendant(paramObject,
				KBConstants.STANDARD_TYPE);
		boolean isEditMode = KBUtils.isEditMode(paramModelContext
				.getDescriptorMode());
		LOG.debug("dataValue" + dataValue);
		LOG.debug("isTechDoc" + isTechDoc);
		LOG.debug("isTechDrwDoc" + isTechDrwDoc);
		LOG.debug("isCertificate" + isCertificate);
		LOG.debug("isStandardDoc" + isStandardDoc);
		LOG.debug("isEditMode" + isEditMode);
		if ((isTechDoc || isTechDrwDoc || isCertificate || isStandardDoc)  && isEditMode) {
			WTDocument document = (WTDocument) OidHelper
					.getPersistable(paramObject);
			boolean isAttributeEditable = DataUtilityHelper.isEditableOnDocument(document);
			LOG.debug("isAttributeEditable" + isAttributeEditable);
			DataUtilityHelper.setEditableFieldOnComponent(dataValue,
					isAttributeEditable);
		}
		return dataValue;
	}
	protected Object getDataValueInternal(String paramString,
			Object paramObject, ModelContext paramModelContext)
			throws WTException {
		return super.getDataValueInternal(paramString, paramObject,
				paramModelContext, false);
	}

	
}
