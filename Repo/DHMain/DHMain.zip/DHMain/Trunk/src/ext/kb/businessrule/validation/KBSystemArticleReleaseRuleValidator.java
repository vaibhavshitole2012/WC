package ext.kb.businessrule.validation;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.core.businessRules.feedback.RuleFeedbackType;
import com.ptc.core.businessRules.validation.RuleValidationCriteria;
import com.ptc.core.businessRules.validation.RuleValidationKey;
import ext.kb.businessrule.util.KBBusinessRuleUtil;
import ext.kb.businessrule.validation.helper.KBBOMReleaseValidationHelper;
import ext.kb.change2.helper.ChangeNoticeUtils;
import ext.kb.util.DBUtils;
import ext.kb.util.KBConstants;
import ext.kb.util.KBType;
import ext.kb.util.KBUtils;
import ext.kb.workflow.ChangeTaskUtils;
import org.apache.log4j.Logger;
import wt.change2.ChangeActivity2;
import wt.change2.ChangeRecord2;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.fc.collections.WTHashSet;
import wt.lifecycle.State;
import wt.log4j.LogR;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.part.WTPartUsageLink;
import wt.util.WTException;
import wt.util.WTProperties;

import java.io.IOException;
import java.util.*;

public class KBSystemArticleReleaseRuleValidator extends KBValidation {

    private static final Logger LOG = LogR.getLogger(KBSSLBOMReleaseRuleValidator.class.getName());

    private static final Set<State> VALID_STATES = new HashSet<>();
    private static final String VALID_STATES_PROPERTY_NAME = "KBSystemArticleReleaseRuleValidator.valid.states";
    private static final Set<State> INVALID_STATES = new HashSet<>();
    private static final String INVALID_STATES_PROPERTY_NAME = "KBSystemArticleReleaseRuleValidator.invalid.states";

    static {

        WTProperties properties = null;
        try {
            properties = WTProperties.getServerProperties();
        } catch (IOException e) {
            new WTException(e);
        }
        String validStates = properties.getProperty(VALID_STATES_PROPERTY_NAME);
        String invalidStates = properties.getProperty(INVALID_STATES_PROPERTY_NAME);
        HashSet<String> VALID_STATES_SET = new HashSet<String>(Arrays.asList(validStates.split(",", -1)));
        HashSet<String> INVALID_STATES_SET = new HashSet<String>(Arrays.asList(invalidStates.split(",", -1)));
        for (String validState : VALID_STATES_SET) {
            if (!KBUtils.isEmpty(validState)) {
                VALID_STATES.add(State.toState(validState));
            }
        }
        for (String invalidState : INVALID_STATES_SET) {
            if (!KBUtils.isEmpty(invalidState)) {
                INVALID_STATES.add(State.toState(invalidState));
            }
        }

    }

    public KBSystemArticleReleaseRuleValidator() {
        setFeedbackType(RuleFeedbackType.ERROR);
    }

    @SuppressWarnings("unchecked")
    @Override
    public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
                                List<RuleFeedbackMessage> paramList, RuleValidationKey paramRuleValidationKey) throws WTException {

        boolean success = true;
        ChangeActivity2 currentActivity = (ChangeActivity2) paramRuleValidationKey.getProcessingMapValue(ECT);

        QueryResult context = KBBusinessRuleUtil.getChangeContext(currentActivity);
        WTHashSet resultingObjectsInContext = ChangeTaskUtils.getResultingObjects(context);
        List<WTPartUsageLink> usageLinks = DBUtils.retrieveLinks(WTPartUsageLink.class, paramPersistable,
                WTPartUsageLink.ROLE_BOBJECT_ROLE);

        for (WTPartUsageLink link : usageLinks) {
            RuleFeedbackMessage error = validate(VALID_STATES, INVALID_STATES, resultingObjectsInContext, link);
            if (error != null) {
                success = false;
                paramList.add(error);
            }
        }

        LOG.debug("KBSystemArticleReleaseRuleValidator returning: " + success);
        return success;
    }

    private RuleFeedbackMessage validate(Set<State> validStates, Set<State> invalidStates,
                                         WTHashSet resultingObjectsInContext, WTPartUsageLink link) throws WTException {

        RuleFeedbackMessage error = null;
        WTPartMaster componentMaster = link.getUses();
        WTPart componentLatestIteration = (WTPart) KBUtils.getLatestIteration(componentMaster);
        if (!KBType.isDescendedFrom(componentLatestIteration, KBConstants.SYSTEM_ARTICLE_INTERNAL_NAME)) {
            return null;
        }

        ChangeRecord2 cr = ChangeNoticeUtils.getChangeRecord(componentLatestIteration);
        String objectnumber = componentLatestIteration.getNumber();

        if (cr != null && resultingObjectsInContext.contains(componentLatestIteration)) {
            error = KBBOMReleaseValidationHelper.validateChangeContext(validStates, invalidStates, cr, error, objectnumber);
        } else {
            error = KBBOMReleaseValidationHelper.validateOutsideChangeContext(validStates, invalidStates, componentLatestIteration, error, objectnumber);
        }
        return error;
    }

    @Override
    public void prepareForValidation(RuleValidationKey ruleValidationKey,
                                     RuleValidationCriteria paramRuleValidationCriteria) {

        ChangeActivity2 currentActivity = (ChangeActivity2) paramRuleValidationCriteria.getPrimaryBusinessObject();
        ruleValidationKey.addToProcessingMap(ECT, currentActivity);
    }

    @Override
    public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
                                List<RuleFeedbackMessage> paramList) throws WTException {
        return false;
    }

}