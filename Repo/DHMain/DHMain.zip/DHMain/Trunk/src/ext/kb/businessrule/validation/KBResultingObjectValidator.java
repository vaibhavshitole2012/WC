package ext.kb.businessrule.validation;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.core.businessRules.feedback.RuleFeedbackType;
import com.ptc.core.businessRules.validation.RuleValidationCriteria;
import com.ptc.core.businessRules.validation.RuleValidationKey;

import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.KBConstants;
import ext.kb.util.ObjectRevisionHelper;
import wt.change2.ChangeActivity2;
import wt.change2.ChangeHelper2;
import wt.change2.Changeable2;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.lifecycle.State;
import wt.util.WTException;
import wt.util.WTMessage;

public class KBResultingObjectValidator extends KBValidation {

	/*
	 * Validates if the current resulting object is not a resulting object in
	 * another change task that is not Cancelled or Production Released
	 * 
	 */
	@Override
	@SuppressWarnings("unchecked")
	public boolean isRulesValid(Persistable paramPersistable,
			Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList, RuleValidationKey validationKey) throws WTException {

		boolean success = true;
		ChangeActivity2 currentActivity = (ChangeActivity2) validationKey.getProcessingMapValue(ECT);

		if (paramPersistable instanceof Changeable2) {
			Changeable2 resItem = (Changeable2) paramPersistable;
			QueryResult currentObjectActivities = ChangeHelper2.service.getChangingChangeActivities(resItem);
            Persistable previousVersion = ObjectRevisionHelper.getPreviousVersionLatestIteration(resItem);
            QueryResult previousObjectActivities = previousVersion != null ? ChangeHelper2.service.getChangingChangeActivities((Changeable2) previousVersion) : null;

            if (isEmpty(previousObjectActivities) && isEmpty(currentObjectActivities)){
                return true;
            }

            boolean isValidCurrentObject = isValidObject(currentActivity, currentObjectActivities);
            boolean isValidPreviousVersion = isEmpty(previousObjectActivities)  || isValidObject(currentActivity, previousObjectActivities);
            if (!isValidCurrentObject) {
                RuleFeedbackMessage feedbackMessage = getRuleFeedbackMessage(BusinessRuleRB.KB_RESULTING_OBJECTS_ERROR_MSG);
                paramList.add(feedbackMessage);
            }
            if(!isValidPreviousVersion){
                RuleFeedbackMessage feedbackMessage = getRuleFeedbackMessage(BusinessRuleRB.KB_RESULTING_OBJECTS_PREVIOUS_VERSION_ERROR_MSG);
                paramList.add(feedbackMessage);
            }

            success = isValidCurrentObject && isValidPreviousVersion;
		}
		return success;
	}

    private RuleFeedbackMessage getRuleFeedbackMessage(String errorMessage) {
        WTMessage message = new WTMessage(RESOURCE, errorMessage, new Object[] {});
        return new RuleFeedbackMessage(message,	RuleFeedbackType.ERROR);
    }

    private boolean isEmpty(QueryResult queryResult) {
        return queryResult == null || queryResult.size() == 0;
    }

    private boolean isValidObject(ChangeActivity2 currentActivity, QueryResult queryResult) {
		boolean success = true;
		while (queryResult.hasMoreElements()) {
			ChangeActivity2 changeActivity = (ChangeActivity2) queryResult.nextElement();
			State caState = changeActivity.getState().getState();

			if (!currentActivity.equals(changeActivity) &&
					!(KBConstants.STATE_CANCELED.equals(caState)
					|| KBConstants.STATE_PRODUCTION_RELEASED.equals(caState))) {
				success = false;
				break;
			}
		}
		return success;
	}

	/*
	 * This method is responsible for collecting all the resulting objects
	 * transitions to a map
	 */
	@Override
	public void prepareForValidation(RuleValidationKey ruleValidationKey,
			RuleValidationCriteria paramRuleValidationCriteria) {

		ChangeActivity2 currentActivity = (ChangeActivity2) paramRuleValidationCriteria.getPrimaryBusinessObject();
		ruleValidationKey.addToProcessingMap(ECT, currentActivity);
	}

	@Override
	public boolean isRulesValid(Persistable paramPersistable,
			Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList) throws WTException {
		return false;
	}

}
