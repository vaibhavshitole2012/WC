package ext.kb.businessrule.validation;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.core.businessRules.feedback.RuleFeedbackType;
import com.ptc.core.businessRules.validation.RuleValidationKey;

import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.ObjectRevisionHelper;
import wt.fc.BinaryLink;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.part.LineNumber;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.part.WTPartUsageLink;
import wt.util.WTException;
import wt.util.WTMessage;

public class KBPartUsageLinkValidation extends KBValidation implements PartUsageLinkLogicExecutable {

	private static final Logger logger = Logger.getLogger(KBPartUsageLinkValidation.class);
	private static final String VALIDATION_RESULT = "VALIDATION_RESULT";

	/*
	 * Validates if a Bom and all of it's sub Boms have a valid, not empty
	 * findNumber in the WTPartUsageLink
	 */
	@Override
	public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList, RuleValidationKey paramRuleValidationKey) throws WTException {
		if (logger.isDebugEnabled()) {
			logger.debug(
					"entering isRulesValid(Persistable,Map<String,Set<AttributeRuleSet>>,List<RuleFeedbackMessage>)");
			logger.debug("paramPersistable: " + paramPersistable);
			logger.debug("paramMap: " + paramMap);
			logger.debug("paramList: " + paramList);
		}
		BasePartUsageLinkProcessor logicExecutor = new BasePartUsageLinkProcessor(this);
		boolean result = true;
		List<RuleFeedbackMessage> localValidationResult = new ArrayList<>();
		paramRuleValidationKey.addToProcessingMap(VALIDATION_RESULT, localValidationResult);

		if (!(paramPersistable instanceof WTPart)) {
			if (logger.isDebugEnabled()) {
				logger.debug("exiting isRulesValid()");
				logger.debug("returning: " + result);
			}
			return result;
		}
		WTPart part = (WTPart) paramPersistable;
		logicExecutor.process(part, paramRuleValidationKey);
		if (!CollectionUtils.isEmpty(localValidationResult)) {
			paramList.addAll(localValidationResult);
			result = false;
		}
		;
		if (logger.isDebugEnabled()) {
			logger.debug("exiting isRulesValid()");
			logger.debug("returning: " + result);
		}
		return result;
	}

	/*
	 * Checks if the link has a valid findNumber. If Not a feedbackMessage gets
	 * constructed
	 */
	@Override
	public void executeSpecific(final WTPartUsageLink link, final List<BinaryLink> linksOnSameLevel,
			RuleValidationKey paramRuleValidationKey) throws WTException {
		if (logger.isDebugEnabled()) {
			logger.debug("entering executeSpecific(WTPartUsageLink,List<BinaryLink>)");
			logger.debug("link: " + link);
			logger.debug("linksOnSameLevel: " + linksOnSameLevel);
		}
		validateFindNumber(link, paramRuleValidationKey);
		validateLineNumber(link, paramRuleValidationKey);
		if (logger.isDebugEnabled()) {
			logger.debug("exiting executeSpecific()");
		}
	}

	@SuppressWarnings("unchecked")
	private void validateFindNumber(final WTPartUsageLink link, RuleValidationKey paramRuleValidationKey)
			throws WTException {
		if (logger.isDebugEnabled()) {
			logger.debug("entering validateFindNumber(WTPartUsageLink)");
			logger.debug("link: " + link);
		}
		String findNumber = link.getFindNumber();
		if (StringUtils.isEmpty(findNumber)) {
			RuleFeedbackType feedbackType = checkLegacyFindNumber(link);
			WTPartMaster master = link.getUses();
			String identity = master.getIdentity();
			List<RuleFeedbackMessage> validationResult = (List<RuleFeedbackMessage>) paramRuleValidationKey
					.getProcessingMapValue(VALIDATION_RESULT);
			validationResult.add(new RuleFeedbackMessage(
					new WTMessage(RESOURCE, BusinessRuleRB.KB_USAGE_LINK_INVALID_FINDNUMBER, new String[] { identity }),
					feedbackType));
		}
		if (logger.isDebugEnabled()) {
			logger.debug("exiting validateFindNumber()");
		}
	}

	private RuleFeedbackType checkLegacyFindNumber(final WTPartUsageLink link) throws WTException {

		Persistable previousVersion = ObjectRevisionHelper.getPreviousVersionLatestIteration(link.getRoleAObject());
		if (previousVersion != null) {
			String componentId = link.getComponentId();
			QueryResult qr = PersistenceHelper.manager.navigate(previousVersion, WTPartUsageLink.USES_ROLE,
					WTPartUsageLink.class, false);
			while (qr.hasMoreElements()) {
				WTPartUsageLink prevLink = (WTPartUsageLink) qr.nextElement();
				if (componentId.equals(prevLink.getComponentId())) {
					String findNumber = prevLink.getFindNumber();
					if (StringUtils.isEmpty(findNumber)) {
						return RuleFeedbackType.WARNING;
					}
				}
			}
		}
		return RuleFeedbackType.ERROR;
	}

	@SuppressWarnings("unchecked")
	protected void validateLineNumber(WTPartUsageLink link, RuleValidationKey paramRuleValidationKey) throws WTException {
		if (logger.isDebugEnabled()) {
			logger.debug("entering validateLineNumber(WTPartUsageLink)");
			logger.debug("link: " + link);
		}
		LineNumber lineNumber = link.getLineNumber();
		if (lineNumber == null) {
			RuleFeedbackType feedbackType = checkLegacyLineNumber(link);
			WTPartMaster master = link.getUses();
			String identity = master.getIdentity();
			List<RuleFeedbackMessage> validationResult = (List<RuleFeedbackMessage>) paramRuleValidationKey
					.getProcessingMapValue(VALIDATION_RESULT);
			validationResult.add(new RuleFeedbackMessage(
					new WTMessage(RESOURCE, BusinessRuleRB.KB_USAGE_LINK_INVALID_LINENUMBER, new String[] { identity }),
					feedbackType));
		}
		if (logger.isDebugEnabled()) {
			logger.debug("exiting validateLineNumber()");
		}
	}

	private RuleFeedbackType checkLegacyLineNumber(final WTPartUsageLink link) throws WTException {

		Persistable previousVersion = ObjectRevisionHelper.getPreviousVersionLatestIteration(link.getRoleAObject());
		if (previousVersion != null) {
			String componentId = link.getComponentId();
			QueryResult qr = PersistenceHelper.manager.navigate(previousVersion, WTPartUsageLink.USES_ROLE,
					WTPartUsageLink.class, false);
			while (qr.hasMoreElements()) {
				WTPartUsageLink prevLink = (WTPartUsageLink) qr.nextElement();
				if (componentId.equals(prevLink.getComponentId())) {
					LineNumber lineNumber = prevLink.getLineNumber();
					if (lineNumber == null) {
						return RuleFeedbackType.WARNING;
					}
				}
			}
		}
		return RuleFeedbackType.ERROR;
	}

	/*
	 * Defines if the logicExecutor needs to check only the top level
	 */
	@Override
	public boolean isOnlyToplevel() {
		if (logger.isDebugEnabled()) {
			logger.debug("entering isOnlyToplevel()");
			logger.debug("exiting isOnlyToplevel()");
			logger.debug("returning: " + true);
		}
		return true;
	}

	@Override
	public void executeSpecificPreProcess(List<BinaryLink> links) throws WTException {

	}

	@Override
	public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList) throws WTException {
		return false;
	}

}
