package ext.kb.datautility;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.dataUtilities.DefaultDataUtility;
import com.ptc.core.components.rendering.guicomponents.AttributeDisplayCompositeComponent;
import com.ptc.core.components.rendering.guicomponents.AttributeInputCompositeComponent;
import com.ptc.core.components.rendering.guicomponents.GUIComponentArray;
import com.ptc.core.components.rendering.guicomponents.PickerInputComponent;
import com.ptc.core.components.rendering.guicomponents.TextDisplayComponent;
import com.ptc.core.components.rendering.guicomponents.UrlDisplayComponent;
import com.ptc.core.meta.common.AttributeTypeIdentifier;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.impl.InstanceBasedAttributeTypeIdentifier;
import com.ptc.core.meta.type.common.impl.DefaultTypeInstance;
import com.ptc.core.ui.resources.ComponentMode;
import com.ptc.windchill.enterprise.change2.dataUtilities.ChangePickerDataUtility;

import ext.kb.util.KBTeamUtils;
import ext.kb.util.KBUtils;
import wt.facade.netmarkets.NetmarketsHref;
import wt.org.WTUser;
import wt.util.WTException;

public class KBAssigneeDataUtility extends DefaultDataUtility {
	private static final Logger LOG = Logger.getLogger(KBAssigneeDataUtility.class);
	
	private ChangePickerDataUtility picker;
	
	private static final String PICKER_ID = "kbAssigneePicker";
	private static final String KB_ASSIGNEE = "KB_ASSIGNEE";
	
	public void setModelData(String paramString, List<?> paramList,
			ModelContext paramModelContext) throws WTException {
		if(KBUtils.isEditOrCreateMode(paramModelContext.getDescriptorMode())){
			this.picker = new ChangePickerDataUtility();
			this.picker.setModelData(paramString, paramList, paramModelContext);
		}
		else{
			super.setModelData(paramString, paramList, paramModelContext);
		}
	}

	public Object getDataValue(String paramString, Object paramObject,
			ModelContext paramModelContext) throws WTException {
		
		if(KBUtils.isEditOrCreateMode(paramModelContext.getDescriptorMode())){
			AttributeInputCompositeComponent comp = (AttributeInputCompositeComponent)super.getDataValue(paramString, paramObject, paramModelContext);
			configurePicker(paramModelContext);
			GUIComponentArray compArray = (GUIComponentArray)this.picker.getDataValue(paramString, paramObject,paramModelContext);
			
			int nrOfComponents = compArray == null ? 0: compArray.size();
			if(nrOfComponents >= 1){
				PickerInputComponent inputComp = (PickerInputComponent)compArray.get(0);
				inputComp.setColumnName(comp.getColumnName());
				if(ComponentMode.EDIT.equals(paramModelContext.getDescriptorMode())){
					DefaultTypeInstance typeInst = (DefaultTypeInstance)paramObject;
					TypeIdentifier targetType = wt.type.TypedUtilityServiceHelper.service.getTypeIdentifier(paramObject);
					AttributeTypeIdentifier attId = new InstanceBasedAttributeTypeIdentifier(KB_ASSIGNEE,targetType);   
					String ldapString = (String)typeInst.get(attId);
					
					WTUser principal = KBTeamUtils.getPrincipalFromLdapString(ldapString);
					if(principal != null){
						inputComp.setValue(principal.getFullName());
					}
				}
				inputComp.setRequired(false);
				return inputComp;
			}
			return comp;
		}else{
			
			AttributeDisplayCompositeComponent dispComponent = (AttributeDisplayCompositeComponent)super.getDataValue(paramString, paramObject, paramModelContext);
			TextDisplayComponent textComponent = (TextDisplayComponent)dispComponent.getValueDisplayComponent();
			String ldapString = textComponent.getValue();
			if(StringUtils.isEmpty(ldapString) || textComponent.isNBSP()){
				return dispComponent;
			}
			WTUser principal = KBTeamUtils.getPrincipalFromLdapString(ldapString);
			String fullName = principal == null ? StringUtils.EMPTY : principal.getFullName();
			NetmarketsHref localNetmarketsHref = new NetmarketsHref(principal);
			String href = localNetmarketsHref.getHref();
			UrlDisplayComponent comp = new UrlDisplayComponent(StringUtils.EMPTY,fullName,href);
			return comp;
		}
	}

	private void configurePicker(ModelContext paramModelContext) throws WTException {
		picker.buildUserPickerConfig(KB_ASSIGNEE, paramModelContext, true, false, null);
		paramModelContext.getDescriptor().getProperties().put("pickerId", PICKER_ID);
		
		paramModelContext.getDescriptor().getProperties().put("includeTypeInstanceId", "false");
		paramModelContext.getDescriptor().getProperties().put("pickerCallback", "PickerInputComponentCallback");
	}
}
