package ext.kb.builder.table;

import java.util.Locale;
import java.util.Properties;

import wt.util.WTException;

import com.ptc.core.htmlcomp.collection.presentation.UIExtCollectionJSTableProcessor;
import com.ptc.core.htmlcomp.jstable.JSStandardColumnDescriptorFactory;
import com.ptc.core.htmlcomp.jstable.JSTableDescriptor;

public class KBUIExtCollectionJSTableProcessor extends UIExtCollectionJSTableProcessor {
	
	@Override
	public JSTableDescriptor getTableDescriptor(String tableId, Properties parameters, Locale locale) throws WTException {
		JSTableDescriptor tableDesc = super.getTableDescriptor(tableId, parameters, locale);
		JSStandardColumnDescriptorFactory columnFactory = new JSStandardColumnDescriptorFactory();
		tableDesc.addColumn(columnFactory.newContextColumn(locale, false));
		tableDesc.addColumn(columnFactory.newLifeCycleStateColumn(locale, false));
		return tableDesc;
	}
}
