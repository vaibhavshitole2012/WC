package ext.kb.businessrule.validation;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.StringUtils;

import wt.fc.Persistable;
import wt.part.WTPart;
import wt.util.WTException;
import wt.util.WTMessage;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.core.lwc.common.view.AttributeDefinitionReadView;
import com.ptc.core.lwc.common.view.ConstraintDefinitionReadView;
import com.ptc.core.lwc.common.view.ConstraintDefinitionReadView.RuleDataObject;
import com.ptc.core.lwc.common.view.ConstraintRuleDefinitionReadView;
import com.ptc.core.meta.common.AnalogSet;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.container.common.impl.StringLengthConstraint;

import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.IBAHelper;
import ext.kb.util.KBConstants;
import org.apache.log4j.Logger;

public class KBBasicTextValidation extends KBValidation {

	private static final Logger logger = Logger.getLogger(KBBasicTextValidation.class);

	@Override
	public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList) throws WTException {

		if (logger.isDebugEnabled()) {
			logger.debug(
					"entering isRulesValid(Persistable,Map<String,Set<AttributeRuleSet>>,List<RuleFeedbackMessage>)");
			logger.debug("paramPersistable: " + paramPersistable);
			logger.debug("paramMap: " + paramMap);
			logger.debug("paramList: " + paramList);
		}
		boolean isRuleValid = true;
		try {
			if (paramPersistable instanceof WTPart) {
				WTPart paramPart = (WTPart) paramPersistable;
				Object value = IBAHelper.readIBA(paramPart, KBConstants.BASIC_TEXT_IBA);
				if (value != null) {
					TypeIdentifier targetType = wt.type.TypedUtilityServiceHelper.service
							.getTypeIdentifier(paramPersistable);
					AttributeDefinitionReadView rv = IBAHelper.getAttributeDefinitionReadView(targetType.getTypename(),
							KBConstants.BASIC_TEXT_IBA);
					Collection<ConstraintDefinitionReadView> rest = rv.getAllConstraints();
					String valueString = (String) value;
					int length = StringUtils.length(valueString);

					for (ConstraintDefinitionReadView v : rest) {
						ConstraintRuleDefinitionReadView rule = v.getRule();
						if (StringLengthConstraint.class.getName().equals(rule.getRuleClassname())) {

							RuleDataObject ruleDataObj = v.getRuleDataObj();
							AnalogSet set = (AnalogSet) ruleDataObj.getRuleData();
							Long maxLength = (Long) set.getBoundingRange().getUpperBoundValue();

							if (maxLength != null && length > maxLength.intValue()) {
								paramList.add(new RuleFeedbackMessage(new WTMessage(RESOURCE,
										BusinessRuleRB.KB_BASIC_TEXT_LENGHT_ERROR_MSG, new Long[] { maxLength }),
										getFeedbackType()));
								if (logger.isDebugEnabled()) {
									logger.debug("exiting isRulesValid()");
									logger.debug("returning: " + "isRuleValid = false");
								}
								return isRuleValid = false;
							}
						}
					}
				}
			}

		} catch (Exception localException) {
			logger.error("Unexpected error while validating attribute rule.", localException);
			isRuleValid = false;
		}

		if (logger.isDebugEnabled()) {
			logger.debug("All attribute rules passed for target object.");
			logger.debug("exiting isRulesValid()");
			logger.debug("returning: " + isRuleValid);
		}
		return isRuleValid;
	}
}
