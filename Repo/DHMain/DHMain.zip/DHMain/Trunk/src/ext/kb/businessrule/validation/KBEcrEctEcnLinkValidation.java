package ext.kb.businessrule.validation;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import wt.change2.ChangeActivity2;
import wt.change2.ChangeHelper2;
import wt.change2.ChangeRequest2;
import wt.change2.WTChangeActivity2;
import wt.change2.WTChangeOrder2;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.lifecycle.Transition;
import wt.util.WTException;
import wt.util.WTMessage;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.core.businessRules.feedback.RuleFeedbackType;
import com.ptc.core.businessRules.validation.RuleValidationCriteria;
import com.ptc.core.businessRules.validation.RuleValidationKey;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.TypeIdentifierHelper;

import ext.kb.businessrule.util.KBBusinessRuleUtil;
import ext.kb.change2.helper.ChangeNoticeUtils;
import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.KBConstants;
import ext.kb.workflow.ChangeRequestUtils;

public class KBEcrEctEcnLinkValidation extends KBValidation {

	private static final Logger LOG = Logger.getLogger(KBEcrEctEcnLinkValidation.class);
	
	private static final String RESOURCE = "ext.kb.resources.BusinessRuleRB";
	private static final String ERRORS = "ERRORS";
	
	
	@Override
	public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList, RuleValidationKey validationKey) throws WTException {
		if (LOG.isDebugEnabled()) {
			LOG.debug("entering  isRulesValid(Persistable, Map<String, Set<AttributeRuleSet>>, List<RuleFeedbackMessage>)");
		}
		ArrayList<RuleFeedbackMessage> errorsFromPreparePhase = (ArrayList<RuleFeedbackMessage>) validationKey.getProcessingMapValue(ERRORS);
		
		boolean isValid = true;
		if (!errorsFromPreparePhase.isEmpty()){
			isValid = false;
			paramList.addAll(errorsFromPreparePhase);
			errorsFromPreparePhase.clear();
		}
		if (LOG.isDebugEnabled()){
			LOG.debug("exiting isRulesValid(Persistable, Map, List), returning " + isValid);
		}
		return isValid;
	}
	
	@Override
	public void prepareForValidation(RuleValidationKey paramRuleValidationKey, RuleValidationCriteria paramRuleValidationCriteria) throws WTException {
		super.prepareForValidation(paramRuleValidationKey, paramRuleValidationCriteria);
		ChangeActivity2 ect = (ChangeActivity2) paramRuleValidationCriteria.getPrimaryBusinessObject();
		WTChangeOrder2 ecn = ChangeNoticeUtils.getECN((WTChangeActivity2) ect);
		TypeIdentifier ecnType = TypeIdentifierHelper.getType(ecn);
		TypeIdentifier ectType = TypeIdentifierHelper.getType(ect);
		if (LOG.isDebugEnabled()) {
			LOG.debug("ecnType=" + ecnType + ", ectType=" + ectType);
		}
		ArrayList<RuleFeedbackMessage> errorsFromPreparePhase = new ArrayList<RuleFeedbackMessage>();
		
		if (ecnType.equals(TypeIdentifierHelper.getTypeIdentifier("com.ptc.KBECNInternal"))){
			if (!ectType.equals(TypeIdentifierHelper.getTypeIdentifier("com.ptc.KBECTMinor"))){
				errorsFromPreparePhase.add(new RuleFeedbackMessage(new WTMessage(RESOURCE, BusinessRuleRB.KB_ECNINTERNAL_MUST_HAVE_ECTMINOR,  new Object[] {}), RuleFeedbackType.ERROR));
			}
		} else if (ecnType.equals(TypeIdentifierHelper.getTypeIdentifier("com.ptc.KBECNGeneral"))){
			//if NOT (all ECTs of type KBECTStateChange AND the release target of all resulting WTParts is 1058):
			QueryResult changeRecordsOfECN = ChangeHelper2.service.getChangeablesAfter(ecn, false);
			if (!KBBusinessRuleUtil.checkTargetTransitionOnECTsWithGivenType(changeRecordsOfECN, "com.ptc.KBECTState",  Transition.toTransition("1058"))){
				if (LOG.isDebugEnabled()){
					LOG.debug("CR validation needed");
				}
				ChangeRequest2 cr = ChangeRequestUtils.getChangeRequestFromChangeActivity((WTChangeActivity2) ect);
				if (LOG.isDebugEnabled()){
					LOG.debug(cr == null ? "CR is null" : ("CR state is:" + cr.getLifeCycleState().getAbbreviatedDisplay()));
				}
				if (cr == null || !cr.getLifeCycleState().equals(KBConstants.IMPLEMENTATION_STATE)){
					errorsFromPreparePhase.add(new RuleFeedbackMessage(new WTMessage(RESOURCE, BusinessRuleRB.KB_APPROVED_ECR_REQUIRED,  new Object[] {}), RuleFeedbackType.ERROR));
				}
			}
		}
		paramRuleValidationKey.addToProcessingMap(ERRORS, errorsFromPreparePhase);
	}

	@Override
	public boolean isRulesValid(Persistable paramPersistable,
			Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList) throws WTException {
		// TODO Auto-generated method stub
		return false;
	}
}
