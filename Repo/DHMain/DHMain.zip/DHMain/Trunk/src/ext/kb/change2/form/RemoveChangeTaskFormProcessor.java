package ext.kb.change2.form;

import java.util.ArrayList;
import java.util.List;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormProcessingStatus;
import com.ptc.core.components.forms.FormResult;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;

import wt.change2.WTChangeActivity2;
import wt.fc.PersistenceHelper;
import wt.fc.collections.WTHashSet;
import wt.fc.collections.WTSet;
import wt.util.WTException;

public class RemoveChangeTaskFormProcessor extends DefaultObjectFormProcessor {

	@Override
	public FormResult preProcess(NmCommandBean commandBean, List<ObjectBean> beans) throws WTException {
		FormResult result = new FormResult();

		ArrayList<NmOid> nmOidSelected = commandBean.getNmOidSelected();
		WTSet changeActivitySet = new WTHashSet();
		for (NmOid nmOid : nmOidSelected) {
			if (nmOid.getRefObject() != null) {
				WTChangeActivity2 changeActivity = (WTChangeActivity2) nmOid.getRefObject();
				changeActivitySet.add(changeActivity);
			}
		}
		if (!changeActivitySet.isEmpty()) {
			PersistenceHelper.manager.delete(changeActivitySet);
		}
		result.setStatus(FormProcessingStatus.SUCCESS);
		return result;
	}

}
