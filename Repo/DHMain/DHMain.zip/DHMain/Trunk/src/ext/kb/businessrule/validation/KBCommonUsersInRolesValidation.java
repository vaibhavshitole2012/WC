package ext.kb.businessrule.validation;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import wt.change2.ChangeRecord2;
import wt.fc.Persistable;
import wt.lifecycle.LifeCycleManaged;
import wt.org.WTPrincipal;
import wt.preference.PreferenceHelper;
import wt.util.WTException;
import wt.util.WTMessage;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.core.businessRules.validation.RuleValidationCriteria;
import com.ptc.core.businessRules.validation.RuleValidationKey;
import com.ptc.core.businessRules.validation.RuleValidationObject;
import com.ptc.core.businessRules.validation.RuleValidationResult;
import com.ptc.core.businessRules.validation.RuleValidationStatus;

import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.KBConstants;
import ext.kb.util.KBTeamUtils;

public class KBCommonUsersInRolesValidation extends KBValidation {

	private static final Logger logger = Logger.getLogger(KBCommonUsersInRolesValidation.class);

	
	@Override
	public RuleValidationResult performValidation(RuleValidationKey paramRuleValidationKey, RuleValidationObject paramRuleValidationObject,
			RuleValidationCriteria paramRuleValidationCriteria)
			throws WTException {
		RuleValidationResult parentResult = super.performValidation(paramRuleValidationKey,
				paramRuleValidationObject, paramRuleValidationCriteria);
		Object prefValue = PreferenceHelper.service.getValue(KBConstants.PREF_KB_ACTIVATE_COMMONUSERS_IN_ROLES_RULE, KBConstants.WINDCHILL);
		boolean needToExecBuildRules = prefValue != null && Boolean.TRUE.equals(prefValue);
		if (!needToExecBuildRules){
			if (logger.isDebugEnabled()) {
				logger.debug("No need to execute BR. Pref set to turn BR off. returning parentResult");
			}
			return parentResult;
		}
		try {
			Persistable object = paramRuleValidationObject.getTargetObjectLink().getObject();
			if(object instanceof ChangeRecord2){
			
				LifeCycleManaged lcm = ((ChangeRecord2) paramRuleValidationObject.getTargetObjectLink().getObject()).getChangeActivity2();
				Set<WTPrincipal> assignees = KBTeamUtils.getRoleMembers("ASSIGNEE", lcm);
				Set<WTPrincipal> reviewers = KBTeamUtils.getRoleMembers("REVIEWER", lcm);
				if (reviewers.removeAll(assignees)){
					parentResult.setStatus(RuleValidationStatus.FAILURE);
					parentResult.addFeedbackMessage(new RuleFeedbackMessage(new WTMessage(RESOURCE,
										BusinessRuleRB.KB_ASSIGNEE_APPROVER_DIFFERENT_PERSON, new Object[]{}),
										getFeedbackType()));
				}
			}

		} catch (Exception localException) {
			logger.error("Unexpected error while validating attribute rule.", localException);
		}
		return parentResult;
	}	

	@Override
	public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap, List<RuleFeedbackMessage> paramList) throws WTException {
		return true;
	}
}
