package ext.kb.businessrule.validation;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.core.businessRules.validation.RuleValidationCriteria;
import com.ptc.core.businessRules.validation.RuleValidationKey;
import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.DocumentVariantHelper;
import ext.kb.util.KBType;
import ext.kb.workflow.ChangeTaskUtils;
import org.apache.log4j.Logger;
import wt.change2.ChangeRecord2;
import wt.change2.WTChangeActivity2;
import wt.doc.WTDocument;
import wt.doc.WTDocumentUsageLink;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.fc.collections.WTArrayList;
import wt.fc.collections.WTKeyedMap;
import wt.lifecycle.Transition;
import wt.part.WTPartDescribeLink;
import wt.part.WTPartReferenceLink;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.vc.config.LatestConfigSpec;
import wt.vc.struct.StructHelper;

import java.util.List;
import java.util.Map;
import java.util.Set;

import static ext.kb.util.KBConstants.RELEASED;

public class KBDocumentIsUsedByValidator extends KBValidation {

    public static final String OR = " or ";
    String[] VALIDATED_TYPES = {"com.ptc.KBSalesDocument", "com.ptc.KBSalesDrawing"};
    private static final Logger logger = Logger.getLogger(KBDocumentIsUsedByValidator.class);

    @Override
    public boolean isRulesValid(Persistable persistable, Map<String, Set<AttributeRuleSet>> paramMap,
                                List<RuleFeedbackMessage> paramList, RuleValidationKey validationKey) throws WTException {
        boolean isValidForValidation = KBType.isDescendedFromOneOfTypes(persistable, VALIDATED_TYPES) && RELEASED
                .equalsIgnoreCase(getTargetState(persistable, validationKey));
        logger.debug("validation needed " + isValidForValidation);
        if (isValidForValidation) {
            WTDocument document = (WTDocument) persistable;
            boolean isSourceDocument = DocumentVariantHelper.isSourceDocument(document);
            logger.debug("document  " + document.getNumber() + "is source " + isSourceDocument);
            if (isSourceDocument) {
                validateSourceDocument(paramList, document);
            }
            if (!isSourceDocument) {
                validateVariant(paramList, document);
            }
        }
        return paramList.isEmpty();
    }

    private String getTargetState(Persistable persistable, RuleValidationKey validationKey) throws WTException {
        WTChangeActivity2 currentECT = (WTChangeActivity2) validationKey.getProcessingMapValue(ECT);
        ChangeRecord2 changeRecord = ChangeTaskUtils.getChangeRecord(persistable, currentECT);
        Transition targetTransition = changeRecord.getTargetTransition();
        String targetState = null;
        if (targetTransition != null) {
            targetState = changeRecord.getTargetTransition().toString();
        }
        logger.debug("ect number" + currentECT.getNumber() + "target state" + targetState);
        return targetState;
    }

    private void validateVariant(List<RuleFeedbackMessage> paramList, WTDocument document) {
        logger.debug("validate variant for Document " + document.getNumber());
        WTDocument sourceDocument = (WTDocument) DocumentVariantHelper.getSourceFromVariant(document);
        if (sourceDocument == null) {
            logger.debug("source missing for variant " + document.getNumber());
            paramList.add(getMessage(BusinessRuleRB.KB_DOCUMENT_IS_USED_BY_RULE_VARIANT_LINK_MESSAGE));
        }
    }

    private void validateSourceDocument(List<RuleFeedbackMessage> paramList, WTDocument document) throws WTException {
        WTArrayList wtArrayList = new WTArrayList();
        wtArrayList.addElement(document);
        WTKeyedMap describesParts = StructHelper.service.navigateDescribes(wtArrayList, WTPartDescribeLink.class, true);
        QueryResult referencedParts = StructHelper.service.navigateReferencedBy(document.getMaster(), WTPartReferenceLink.class, true);
        QueryResult parentDocs = StructHelper.service
                .navigateUsedByToIteration(document, WTDocumentUsageLink.class, true, new LatestConfigSpec());
        logger.debug("describesParts size" + describesParts.size());
        logger.debug("referencedParts size" + referencedParts.size());
        logger.debug("parentDocs size" + parentDocs.size());

        if (describesParts.isEmpty() && referencedParts.size() == 0 && parentDocs.size() == 0) {
            paramList.add(getMessage(BusinessRuleRB.KB_DOCUMENT_IS_USED_BY_RULE_MISSING_LINK_MESSAGE));
        }
    }

    private RuleFeedbackMessage getMessage(String message) {
        return new RuleFeedbackMessage(new WTMessage(RESOURCE, message, new Object[]{}), getFeedbackType());
    }

    @Override
    public boolean isRulesValid(Persistable paramPersistable,
                                Map<String, Set<AttributeRuleSet>> paramMap,
                                List<RuleFeedbackMessage> paramList) throws WTException {
        return false;
    }

    @Override
    public void prepareForValidation(RuleValidationKey validationKey, RuleValidationCriteria paramRuleValidationCriteria) {
        validationKey.addToProcessingMap(ECT, paramRuleValidationCriteria.getPrimaryBusinessObject());
    }
}
