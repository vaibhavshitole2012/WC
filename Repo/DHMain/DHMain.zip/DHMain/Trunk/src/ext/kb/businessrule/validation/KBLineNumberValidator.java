package ext.kb.businessrule.validation;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.core.businessRules.validation.RuleValidationKey;
import org.apache.log4j.Logger;
import wt.fc.BinaryLink;
import wt.fc.Persistable;
import wt.part.WTPartUsageLink;
import wt.util.WTException;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class KBLineNumberValidator extends KBPartUsageLinkValidation {

    private static final Logger logger = Logger.getLogger(KBPartUsageLinkValidation.class);

    /*
     * Validates if a Bom and all of it's sub Boms have a valid, not empty
     * lineNumber in the WTPartUsageLink
     */
    @Override
    public boolean isRulesValid(Persistable persistable, Map<String, Set<AttributeRuleSet>> paramMap,
                                List<RuleFeedbackMessage> paramList, RuleValidationKey paramRuleValidationKey) throws WTException {
        logger.debug("entering isRulesValid() - KBLineNumberValidator");
        boolean result = super.isRulesValid(persistable, paramMap, paramList, paramRuleValidationKey);
        logger.debug("exiting isRulesValid()");
        logger.debug("returning: " + result);
        return result;
    }

    /*
     * Checks if the link has a valid lineNumber. If Not a feedbackMessage gets
     * constructed
     */
    @Override
    public void executeSpecific(final WTPartUsageLink link, final List<BinaryLink> linksOnSameLevel,
                                RuleValidationKey paramRuleValidationKey) throws WTException {
        super.validateLineNumber(link, paramRuleValidationKey);
        if (logger.isDebugEnabled()) {
            logger.debug("exiting executeSpecific()");
        }
    }

    @Override
    public boolean isRulesValid(Persistable persistable, Map<String, Set<AttributeRuleSet>> paramMap,
                                List<RuleFeedbackMessage> paramList) throws WTException {
        return false;
    }
}
