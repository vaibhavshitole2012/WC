package ext.kb.accesscontrol;

import java.util.Set;

import wt.access.AccessPermission;

import com.ptc.netmarkets.util.beans.NmHelperBean;

public interface PermissionController {

    public Set<AccessPermission> getAllowedPermissions();

    public AccessPermission extractPermission(NmHelperBean attributeBean);

    public boolean hasPermission(Object accessControlled, AccessPermission permission);

}
