package ext.kb.datautility;

import org.apache.log4j.Logger;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.dataUtilities.DefaultDataUtility;
import ext.kb.util.KBConstants;
import ext.kb.util.KBTeamUtils;
import ext.kb.util.KBTypeIdProvider;
import ext.kb.util.KBUtils;
import wt.fc.ReferenceFactory;
import wt.log4j.LogR;
import wt.util.WTException;
import wt.session.SessionHelper;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerRef;
import wt.inf.team.ContainerTeamManaged;

public class CreateEditDocumentLangInWorkAttributeDataUtility extends DefaultDataUtility {

    private static final Logger LOG = LogR.getLogger(CreateEditDocumentLangInWorkAttributeDataUtility.class.getName());
    private final static String CONTAINER_OID = "ContainerOid";
    @Override
    public Object getDataValue(String paramString, Object paramObject, ModelContext paramModelContext)
			throws WTException {

		Object customValue = getDataValueInternal(paramString, paramObject, paramModelContext);
		boolean isKBDocument = KBTypeIdProvider.isDescendant(paramObject, KBConstants.KB_DOCUMENT_TYPE);
		boolean isRefDoc = KBTypeIdProvider.isDescendant(paramObject, KBConstants.REFERENCE_DOCUMENT_TYPE);
		boolean isEditMode = KBUtils.isEditMode(paramModelContext.getDescriptorMode());
		boolean isCreateMode = KBUtils.isCreateMode(paramModelContext.getDescriptorMode());

		if ((isKBDocument || isRefDoc) && (isEditMode || isCreateMode)) {
			WTContainerRef containerRef = getContainerReference(paramModelContext);
			boolean isAttributeEditable = shouldBeEditableOnDocument(containerRef.getContainer());
			LOG.debug("IsAttributeEditable------"+isAttributeEditable);
			DataUtilityHelper.setEditableFieldOnComponent(customValue, isAttributeEditable);
		}
		return customValue;
	}

    protected Object getDataValueInternal(String paramString, Object paramObject, ModelContext paramModelContext)
            throws WTException {
        return super.getDataValueInternal(paramString, paramObject, paramModelContext, false);
    }
	
    private WTContainerRef getContainerReference(ModelContext modelContext) throws WTException {
		WTContainerRef containerRef = modelContext.getNmCommandBean().getContainerRef();
		if (containerRef == null)
			containerRef = (WTContainerRef) new ReferenceFactory()
					.getReference(modelContext.getNmCommandBean().getRequest().getParameter(CONTAINER_OID));
		return containerRef;
	}
    
    /**
     * Checks edit possibility of given attribute depending on user assignment.
     *
     * @param container Edited document.
     * @return True or false depending on that which roles user is assigned to.
     * @throws WTException
     */
	public boolean shouldBeEditableOnDocument(WTContainer container) throws WTException {
        boolean isDocumentMgr = KBTeamUtils.isUserInRole(SessionHelper.getPrincipal(),
                                            (ContainerTeamManaged) container, KBConstants.DOCUMENT_MANAGEMENT_ROLE);
        boolean isDataMgr = KBTeamUtils.isUserInRole(SessionHelper.getPrincipal(),
                (ContainerTeamManaged) container, KBConstants.DATA_MANAGEMENT);
        boolean isSystemEng = KBTeamUtils.isUserInRole(SessionHelper.getPrincipal(),
                (ContainerTeamManaged) container, KBConstants.SYSTEM_ENGINEER);
        boolean isDesigner = isDesigner(container);
        LOG.debug("IsDocumentMgr------"+isDocumentMgr);
        LOG.debug("IsDataMgr------"+isDataMgr);
        LOG.debug("IsDesigner------"+isDesigner);
        if(isDataMgr||isDocumentMgr){
            return true;
        }else if(isDesigner || isSystemEng){
        	return false;
        }
        return true;
    }
	
	private static boolean isDesigner(WTContainer container) throws WTException{
        boolean isDesigner =  KBTeamUtils.isUserInRole(SessionHelper.getPrincipal(),
                (ContainerTeamManaged)container, KBConstants.DESIGNER_ROLE);
        boolean isDesignerLimited = KBTeamUtils.isUserInRole(SessionHelper.getPrincipal(),
        		(ContainerTeamManaged)container, KBConstants.DESIGNER_LIMITED_ROLE);
        boolean isSystemEngineer = KBTeamUtils.isUserInRole(SessionHelper.getPrincipal(),
        		(ContainerTeamManaged)container, KBConstants.SYSTEM_ENGINEER);
        return isDesigner || isDesignerLimited || isSystemEngineer;
    }
}
