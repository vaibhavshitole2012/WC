package ext.kb.builder.compconfig;

import java.util.ArrayList;
import java.util.List;

import com.ptc.cat.config.client.AttributeConfig;
import com.ptc.cat.config.client.ColumnConfig;
import com.ptc.cat.config.client.ColumnConfigSet;
import com.ptc.cat.config.client.DefaultColumnConfig;
import com.ptc.cat.config.client.DefaultComponentConfig;
import com.ptc.mvc.components.ComponentBuilder;
import com.ptc.mvc.components.ComponentBuilderType;
import com.ptc.mvc.components.ComponentConfig;
import com.ptc.mvc.components.ComponentParams;
import com.ptc.mvc.components.OverrideComponentBuilder;
import com.ptc.windchill.enterprise.part.structureCompare.server.SCLeftTreeConfigBuilder;

@ComponentBuilder(value = "SC.leftTree", type = ComponentBuilderType.CONFIG_ONLY)
@OverrideComponentBuilder
public class SCLeftTreeConfigBuilderExtension extends SCLeftTreeConfigBuilder {

	private static final String SORT_BY = "Sort by ";
	private static final String IBA_KB_GEKLA_L1 = "IBA|KB_GEKLA_L1";
	private static final String IBA_KB_GEKLA_L2 = "IBA|KB_GEKLA_L2";
	private static final String IBA_KB_GEKLA = "IBA|KB_GEKLA";
	private static final String IBA_KB_RELEASED_DATE = "IBA|KB_RELEASED_DATE";
	private static final String GEKLA_LABEL = "GeKla";
	private static final String RELEASED_DATE_LABEL = "Release Date";

	@Override
	public ComponentConfig buildComponentConfig(ComponentParams params) {
		DefaultComponentConfig config = (DefaultComponentConfig) super.buildComponentConfig(params);
		ColumnConfigSet columnConfigSet = config.getTableConfig().getColumnConfigSet();
		updateColumnAttributes(columnConfigSet, IBA_KB_GEKLA_L2, IBA_KB_RELEASED_DATE, RELEASED_DATE_LABEL);
		updateColumnAttributes(columnConfigSet, IBA_KB_GEKLA_L1, IBA_KB_GEKLA, GEKLA_LABEL);
		return config;
	}

	public static void updateColumnAttributes(ColumnConfigSet pColumnConfigSet, String pIdToReplace, String pIdToSet, String pLabel) {
		
		List<AttributeConfig> attributeConfig = null;
		for (ColumnConfig column : pColumnConfigSet) {
			if (pIdToReplace.equals(column.getId())) {
				attributeConfig = column.getAttributeConfigs();
			}
		}
		for (ColumnConfig column : pColumnConfigSet) {
			DefaultColumnConfig columnConfig = (DefaultColumnConfig) column;
			if (pIdToReplace.equals(columnConfig.getId())) {
				columnConfig.setId(pIdToSet);
				columnConfig.setLabel(pLabel);
				columnConfig.setToolTip(SORT_BY + pLabel);
				if (attributeConfig != null) {
					columnConfig.setAttributeConfigs(new ArrayList<AttributeConfig>(attributeConfig));
				}
				break;
			}
		}
	}

}
