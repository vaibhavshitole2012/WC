package ext.csc.support.domain.util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintStream;
import java.util.Hashtable;
import java.util.Vector;

public class KYCConvertCSV
{
  public static void main(String[] args)
  {
    if ((args.length < 2) || (args.length > 2)) {
      System.out.println("\n=================================================================================");
      System.out.println("This is a convert from previous Windchill CSV to Windchill 10 M010's CSV");
      System.out.println("USAGE: windchill ext.csc.support.domain.util.KYCConvertCSV [org_file] [new_file]");
      System.out.println("=================================================================================");

      System.exit(0);
    }

    File org_file = new File(args[0]);
    String[] fileNameType = args[0].split("[.]");
    if (!org_file.exists()) {
      System.out.println("\n=================================================================================");
      System.out.println("This is a convert from previous Windchill CSV to Windchill 10 M010's CSV");
      System.out.println("USAGE: windchill ext.csc.support.domain.util.KYCConvertCSV [org_file] [new_file]");
      System.out.println("=================================================================================");
      System.out.println("ERROR: org_file must be existed!");

      System.exit(0);
    }

    if ((fileNameType.length < 2) || (!fileNameType[1].equals("csv"))) {
      System.out.println("\n=================================================================================");
      System.out.println("This is a convert from previous Windchill CSV to Windchill 10 M010's CSV");
      System.out.println("USAGE: windchill ext.csc.support.domain.util.KYCConvertCSV [org_file] [new_file]");
      System.out.println("=================================================================================");
      System.out.println("ERROR: org_file must be CSV file!");

      System.exit(0);
    }

    fileNameType = args[1].split("[.]");
    File new_file = new File(args[1]);
    if ((fileNameType.length < 2) || (!fileNameType[1].equals("csv"))) {
      System.out.println("\n=================================================================================");
      System.out.println("This is a convert from previous Windchill CSV to Windchill 10 M010's CSV");
      System.out.println("USAGE: windchill ext.csc.support.domain.util.KYCConvertCSV [org_file] [new_file]");
      System.out.println("=================================================================================");
      System.out.println("ERROR: new_file must be CSV file extention!");

      System.exit(0);
    }

    if (new_file.exists()) {
      System.out.println("\n=================================================================================");
      System.out.println("This is a convert from previous Windchill CSV to Windchill 10 M010's CSV");
      System.out.println("USAGE: windchill ext.csc.support.domain.util.KYCConvertCSV [org_file] [new_file]");
      System.out.println("=================================================================================");
      System.out.println("ERROR: new_file is existing! You must use new file");

      System.exit(0);
    }

    KYCConvertCSV op = new KYCConvertCSV();
    try {
      op.convert(args[0], args[1]);
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  public void convert(String org, String conv) throws Exception {
    File org_file = new File(org);
    KYCXMLReader reader = new KYCXMLReader(org_file, KYCXMLReader.CSV, true);
    Vector data = reader.reading();

    File conv_file = new File(conv);

    BufferedWriter bw = new BufferedWriter(new FileWriter(conv_file));
    Hashtable one_line = null;
    StringBuffer allStr = new StringBuffer();

    String containerType = null;
    String containerName = null;
    String domain = null;
    String typeId = null;
    String permission = null;
    String principalType = null;
    String principal = null;
    String appliesTo = null;
    String grantStr = null;
    String state = null;

    for (int i = 0; i < data.size(); i++) {
      one_line = (Hashtable)data.get(i);
      containerType = (String)one_line.get("containerType");
      containerName = (String)one_line.get("containerName");
      domain = (String)one_line.get("domain");
      typeId = (String)one_line.get("typeId");
      permission = (String)one_line.get("permission");
      principalType = (String)one_line.get("principalType");
      principal = (String)one_line.get("principal");
      appliesTo = (String)one_line.get("appliesTo");
      grantStr = (String)one_line.get("permissionList");
      state = (String)one_line.get("state");

      allStr.append("AccessRuleKYC," + 
        containerType + "," + 
        containerName + "," + 
        domain + "," + 
        typeId + "," + 
        permission + "," + 
        principalType + "," + 
        principal + "," + 
        appliesTo + "," + 
        grantStr + "," + 
        state + "\n");

      bw.write(allStr.toString());
      allStr = new StringBuffer();
    }

    bw.close();
  }
}