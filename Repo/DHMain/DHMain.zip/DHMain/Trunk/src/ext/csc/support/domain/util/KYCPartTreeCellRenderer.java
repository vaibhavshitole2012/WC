package ext.csc.support.domain.util;

import com.ptc.windchill.wp.WorkPackage;
import java.awt.Color;
import java.awt.Component;
import java.awt.Image;
import java.beans.PropertyVetoException;
import java.lang.reflect.InvocationTargetException;
import java.net.URL;
import java.util.Hashtable;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JTree;
import javax.swing.tree.TreeCellRenderer;
import wt.admin.AdministrativeDomain;
import wt.clients.util.IconCache;
import wt.doc.WTDocument;
import wt.fc.IconDelegate;
import wt.fc.IconDelegateFactory;
import wt.fc.WTObject;
import wt.folder.Folder;
import wt.util.IconSelector;
import wt.util.WTException;
import wt.util.WTProperties;

public class KYCPartTreeCellRenderer
  implements TreeCellRenderer
{
  private static String renderType = "standard";
  boolean isLeaf;
  static String CODEBASE;
  static Hashtable imageTable = new Hashtable();

  private static String WATING_ICO = "1";
  private static String VAULT_ICO = "2";

  static
  {
    try {
      WTProperties wtproperties = WTProperties.getLocalProperties();
      CODEBASE = wtproperties.getProperty("wt.server.codebase", "");
    }
    catch (Exception wte) {
      wte.printStackTrace();
    }
  }

  public static void setRenderType(String type)
  {
    renderType = type;
  }

  public Component getTreeCellRendererComponent(JTree tree, Object value, boolean selected, boolean expanded, boolean leaf, int row, boolean hasFocus)
  {
    JLabel theLabel;
    try
    {
      ImageIcon theIcon = null;
      if ((value instanceof KYCWTObjectNode))
        theIcon = getImageIcon((KYCWTObjectNode)value);
      String checkString;
      if (theIcon == null)
      {
        String valueString = value.toString();
        checkString = valueString.substring(valueString.length() - 2, valueString.length());
        if (valueString.equals("ĂŻÂżÂ˝ĂŻÂżÂ˝ĂŻÂżÂ˝ĂŻÂżÂ˝ĂŻÂżÂ˝ĂŻÂżÂ˝ ĂŻÂżÂ˝Ă�Â´ĂŻÂżÂ˝ĂŻÂżÂ˝ĂŻÂżÂ˝ĂŻÂżÂ˝Ă”Â´ĂŹÂ´ĂŻÂżÂ˝."))
        {
          theIcon = getWorkingImage(WATING_ICO);
          theLabel = new JLabel(valueString.toString(), theIcon, 2);
        }
        else
        {
          if (checkString.equals(":@"))
          {
            valueString = valueString.substring(0, valueString.length() - 2);
            theIcon = getWorkingImage(VAULT_ICO);
            theLabel = new JLabel(valueString.toString(), theIcon, 2);
          }
          else {
            theLabel = new JLabel(valueString);
          }
        }
      } else { theLabel = new JLabel(value.toString(), theIcon, 2); }


      theLabel.setForeground(Color.black);

      if ((value instanceof KYCWTObjectNode)) {
        KYCWTObjectNode theNode = (KYCWTObjectNode)value;
        if ((renderType.equals("released")) && 
          (theNode.getObject() != null) && ((theNode.getObject() instanceof Folder))) {
          checkString = ((Folder)theNode.getObject()).toString();
        }

      }

      theLabel.setOpaque(selected);
    }
    catch (Exception e) {
      theLabel = new JLabel("Error!");
      e.printStackTrace();
    }

    return theLabel;
  }

  private ImageIcon getImageIcon(KYCWTObjectNode theObjectNode)
  {
    WTObject theObject = theObjectNode.getObject();
    URL imageURL = null;
    String className = theObject.getConceptualClassname();
    ImageIcon theIcon = null;
    String nodeStatus = theObjectNode.getProperty(KYCTreeLogic.OPEN_STATUS);

    if (nodeStatus == null) nodeStatus = "";

    try
    {
      IconCache iconCache = new IconCache();
      Image gotImage = null;

      if (((theObject instanceof AdministrativeDomain)) && (nodeStatus.equals("true"))) {
        WorkPackage folder = WorkPackage.newWorkPackage();
        gotImage = iconCache.getOpenIcon(folder);
      } else if (((theObject instanceof AdministrativeDomain)) && (!nodeStatus.equals("true"))) {
        WorkPackage folder = WorkPackage.newWorkPackage();
        gotImage = iconCache.getStandardIcon(folder);
      } else {
        WTDocument folder = WTDocument.newWTDocument();
        gotImage = iconCache.getStandardIcon(folder);
      }

      theIcon = new ImageIcon(gotImage);

      if (theIcon != null);
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }

    return theIcon;
  }

  private ImageIcon getWorkingImage(String flag)
  {
    URL imageURL = null;
    ImageIcon theIcon = null;
    String iconString = null;

    if (flag.equals(WATING_ICO))
      iconString = CODEBASE + "/wt/clients/images/searching.gif";
    else if (flag.equals(VAULT_ICO))
      iconString = CODEBASE + "/wt/clients/images/newvaulttl.gif";
    else {
      iconString = CODEBASE + "/wt/clients/images/WTUnknown.gif";
    }

    try
    {
      imageURL = new URL(iconString);

      theIcon = new ImageIcon(imageURL);
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }

    return theIcon;
  }

  private String getIconResource(WTObject wtobject)
    throws WTException, PropertyVetoException, InvocationTargetException, IllegalAccessException
  {
    String s = null;
    IconDelegateFactory icondelegatefactory = new IconDelegateFactory();
    IconDelegate icondelegate = icondelegatefactory.getIconDelegate(wtobject);

    for (IconSelector iconselector = icondelegate.getStandardIconSelector(); !iconselector.isResourceKey(); iconselector = icondelegate.getStandardIconSelector()) {
      icondelegate = icondelegate.resolveSelector(iconselector);
    }

    s = CODEBASE + "/" + icondelegate.getStandardIconSelector().getIconKey();
    return s;
  }
}