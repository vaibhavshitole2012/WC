package ext.csc.support.domain.util;

import java.io.File;
import java.util.Vector;
import javax.swing.filechooser.FileFilter;

class KYCDomainFileFilter extends FileFilter
{
  Vector exts = new Vector();
  String des;

  KYCDomainFileFilter(String ext)
  {
    this.exts.add(ext);
  }

  public boolean accept(File f) {
    if (f.isDirectory()) return true;
    String e = f.getName();
    e = e.substring(e.lastIndexOf(".") + 1);
    for (int i = 0; i < this.exts.size(); i++) {
      if (e.equals(this.exts.get(i))) return true;
    }
    return false;
  }

  public String getDescription() {
    return this.des;
  }

  public void setDescription(String des) {
    this.des = des;
  }

  public void addExtension(String ext) {
    this.exts.add(ext);
  }
}