package ext.csc.support.domain.util;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.PrintStream;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import wt.admin.AdministrativeDomain;

public class KYCTreePopup extends JPopupMenu
  implements ActionListener
{
  KYCWTObjectNode theNode;
  KYCWTObjectNode parentNode;
  KYCTreeLogic theLogic;
  private static String SAVE = "Save";
  private static String CANCEL = "Cancel";
  private static String DELETE = "Delete";
  private static String CHANGE_QTY = "Change Qty";
  private static String SUBMIT = "Release to Manufacturing";
  private static String COPY = "Copy";
  private static String PASTE = "Paste";
  private static String SEARCH_PASTE = "Search Paste";
  private static String VIEW_PROPERTY = "View Property";

  private static String NEW_FOLDER = "New Folder";
  private static String DELETE_FOLDER = "Delete Folder";
  private static String NEW_DOCUMENT = "New Document";
  private static String NEW_DRAWING = "New Drawing";
  private static String NEW_PART = "New Part";

  private static String VIEW_XML = "View XML";
  private static String VIEW_CSV = "View CSV";
  private static String EXPORT_XML = "Export XML";
  private static String EXPORT_CSV = "Export CSV";
  private static String CLEAR_CHILD = "Clear Child";

  public KYCTreePopup(KYCWTObjectNode theNode, KYCTreeLogic theLogic)
  {
    this.theNode = theNode;
    this.theLogic = theLogic;

    if ((theNode.getObject() instanceof AdministrativeDomain))
    {
      JMenuItem item;
      add(item = new JMenuItem("Create Sub Domain"));
      item.setActionCommand(KYCTreeLogic.CREATE_DOMAIN);
      item.addActionListener(this);

      add(item = new JMenuItem("Remove Domain"));
      item.setActionCommand(KYCTreeLogic.REMOVE_DOMAIN);
      item.addActionListener(this);

      addSeparator();

      add(item = new JMenuItem("Clear Access Rules"));
      item.setActionCommand(KYCTreeLogic.CLEAR_CHILD);
      item.addActionListener(this);

      addSeparator();

      add(item = new JMenuItem(VIEW_XML));
      item.setActionCommand(KYCTreeLogic.VIEW_XML);
      item.addActionListener(this);

      add(item = new JMenuItem(VIEW_CSV));
      item.setActionCommand(KYCTreeLogic.VIEW_CSV);
      item.addActionListener(this);

      addSeparator();

      add(item = new JMenuItem("Import XML Format"));
      item.setActionCommand(KYCTreeLogic.EXPORT_XML);
      item.addActionListener(this);

      add(item = new JMenuItem("Import CSV Format"));
      item.setActionCommand(KYCTreeLogic.EXPORT_CSV);
      item.addActionListener(this);

      addSeparator();

      add(item = new JMenuItem("Refresh"));
      item.setActionCommand(KYCTreeLogic.REFRESH);
      item.addActionListener(this);
    } else if ((theNode.getObject() instanceof KYCAccessPolicyInfo))
    {
      JMenuItem item;
      add(item = new JMenuItem("Remove Access"));
      item.setActionCommand(KYCTreeLogic.REMOVE_ACCESS);
      item.addActionListener(this);
    }
  }

  public void actionPerformed(ActionEvent event)
  {
    try
    {
      if (this.theNode == null) {
        return;
      }
      String actionName = event.getActionCommand();
      if (actionName.equals(KYCTreeLogic.VIEW_XML))
        this.theLogic.commitViewXML(this.theNode);
      else if (actionName.equals(KYCTreeLogic.VIEW_CSV))
        this.theLogic.commitViewCSV(this.theNode);
      else if (actionName.equals(KYCTreeLogic.EXPORT_XML))
        this.theLogic.commitLoadXML(this.theNode);
      else if (actionName.equals(KYCTreeLogic.EXPORT_CSV))
        this.theLogic.commitLoadCSV(this.theNode);
      else if (actionName.equals(KYCTreeLogic.CLEAR_CHILD))
        this.theLogic.commitClearChild(this.theNode);
      else if (actionName.equals(KYCTreeLogic.REFRESH))
        this.theLogic.refreshNode(this.theNode);
      else if (actionName.equals(KYCTreeLogic.CREATE_DOMAIN))
        this.theLogic.commitCreateDomain(this.theNode);
      else if (actionName.equals(KYCTreeLogic.REMOVE_DOMAIN))
        this.theLogic.commitDeleteDomain(this.theNode);
      else if (actionName.equals(KYCTreeLogic.REMOVE_ACCESS))
        this.theLogic.commitRemoveAccessRule(this.theNode);
      else
        System.out.println("NO ACTION");
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }
}