package ext.csc.support.domain.util;

import java.awt.Container;
import java.awt.EventQueue;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.GroupLayout.ParallelGroup;
import javax.swing.GroupLayout.SequentialGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.LayoutStyle;
import javax.swing.LayoutStyle.ComponentPlacement;
import wt.access.AccessControlHelper;
import wt.access.AccessControlManager;
import wt.access.AccessPolicyRule;
import wt.access.AclEntryLink;
import wt.access.WTAclEntry;
import wt.admin.AdminDomainRef;
import wt.admin.AdministrativeDomain;
import wt.admin.AdministrativeDomainHelper;
import wt.admin.AdministrativeDomainManager;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceManager;
import wt.fc.QueryResult;
import wt.inf.container.WTContainer;
import wt.util.WTException;

public class KYCViewDialog extends JDialog
{
  Frame parentFrame = null;
  String viewDialogType = null;
  KYCWTObjectNode targetNode = null;
  boolean DEBUG = true;
  private JButton jButton1;
  private JButton jButton2;
  private JCheckBox jCheckBox1;
  private JLabel jLabel1;
  private JScrollPane jScrollPane1;
  private JTextArea jTextArea1;
  public static String XML_TYPE = "XML_TYPE";
  public static String CSV_TYPE = "CSV_TYPE";

  public KYCViewDialog(Frame parent, boolean modal)
  {
    super(parent, modal);
    this.parentFrame = parent;
    initComponents();
  }

  public KYCViewDialog(Frame parent, boolean modal, KYCWTObjectNode theNode, String viewType) {
    super(parent, modal);
    this.viewDialogType = viewType;
    this.parentFrame = parent;
    this.targetNode = theNode;

    initComponents();

    if (viewType.equals(CSV_TYPE))
      this.jTextArea1.setText(getCSVFormat(theNode, true).toString());
    else
      this.jTextArea1.setText(getXMLFormat(theNode, true).toString());
  }

  private void initComponents()
  {
    this.jLabel1 = new JLabel();
    this.jScrollPane1 = new JScrollPane();
    this.jTextArea1 = new JTextArea();
    this.jButton1 = new JButton();
    this.jButton2 = new JButton();
    this.jCheckBox1 = new JCheckBox();

    setDefaultCloseOperation(2);

    this.jLabel1.setText("You can use following text by click Ctrl-C.");

    this.jTextArea1.setColumns(20);

    this.jTextArea1.setRows(5);
    this.jScrollPane1.setViewportView(this.jTextArea1);

    this.jButton1.setText("OK");
    this.jButton1.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent evt) {
        KYCViewDialog.this.jButton1ActionPerformed(evt);
      }
    });
    this.jButton2.setText("Save");
    this.jButton2.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent evt) {
        KYCViewDialog.this.jButton2ActionPerformed(evt);
      }
    });
    this.jCheckBox1.setText("Save for tool's format");

    GroupLayout layout = new GroupLayout(getContentPane());
    getContentPane().setLayout(layout);
    layout.setHorizontalGroup(
      layout.createParallelGroup(GroupLayout.Alignment.LEADING)
      .addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
      .addContainerGap()
      .addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING)
      .addComponent(this.jScrollPane1, GroupLayout.Alignment.LEADING, -1, 768, 32767)
      .addGroup(layout.createSequentialGroup()
      .addComponent(this.jLabel1, -2, 392, -2)
      .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 279, 32767)
      .addComponent(this.jCheckBox1)
      .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
      .addComponent(this.jButton2, -2, 89, -2)
      .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(this.jButton1, -2, 97, -2)))
      .addContainerGap()));

    layout.setVerticalGroup(
      layout.createParallelGroup(GroupLayout.Alignment.LEADING)
      .addGroup(layout.createSequentialGroup()
      .addContainerGap()
      .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
      .addComponent(this.jLabel1)
      .addComponent(this.jButton2)
      .addComponent(this.jCheckBox1)
      .addComponent(this.jButton1))
      .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
      .addComponent(this.jScrollPane1, -1, 480, 32767)
      .addContainerGap()));

    pack();
  }

  private void jButton1ActionPerformed(ActionEvent evt)
  {
    setVisible(false);
  }

  private void jButton2ActionPerformed(ActionEvent evt)
  {
    JFileChooser jfc = new JFileChooser();
    if (this.viewDialogType.equals(CSV_TYPE)) {
      if (this.jCheckBox1.isSelected()) {
        KYCDomainFileFilter fileFilter = new KYCDomainFileFilter("ksv");
        fileFilter.setDescription("KYC CSV File");
        jfc.setFileFilter(fileFilter);
      } else {
        KYCDomainFileFilter fileFilter = new KYCDomainFileFilter("csv");
        fileFilter.setDescription("CSV File");
        jfc.setFileFilter(fileFilter);
      }
    }
    else if (this.jCheckBox1.isSelected()) {
      KYCDomainFileFilter fileFilter = new KYCDomainFileFilter("kml");
      fileFilter.setDescription("KYC XML File");
      jfc.setFileFilter(fileFilter);
    } else {
      KYCDomainFileFilter fileFilter = new KYCDomainFileFilter("xml");
      fileFilter.setDescription("XML File");
      jfc.setFileFilter(fileFilter);
    }

    int result = jfc.showSaveDialog(this);
    if (result == 1) return;

    File selectedFile = jfc.getSelectedFile();
    String fileName = selectedFile.getName();
    String fileNamePath = selectedFile.getAbsolutePath();

    String[] fileNameType = fileName.split("[.]");
    if (fileNameType.length == 1) {
      if (this.viewDialogType.equals(CSV_TYPE)) {
        if (this.jCheckBox1.isSelected())
          selectedFile = new File(fileNamePath + ".ksv");
        else
          selectedFile = new File(fileNamePath + ".csv");
      }
      else if (this.jCheckBox1.isSelected())
        selectedFile = new File(fileNamePath + ".kml");
      else {
        selectedFile = new File(fileNamePath + ".xml");
      }

    }
    else if ((!fileName.substring(fileName.lastIndexOf(".") + 1).equals("csv")) && 
      (!fileName.substring(fileName.lastIndexOf(".") + 1).equals("xml")) && 
      (!fileName.substring(fileName.lastIndexOf(".") + 1).equals("ksv")) && 
      (!fileName.substring(fileName.lastIndexOf(".") + 1).equals("kml"))) {
      if (this.viewDialogType.equals(CSV_TYPE)) {
        if (this.jCheckBox1.isSelected())
          selectedFile = new File(fileNamePath + ".ksv");
        else
          selectedFile = new File(fileNamePath + ".csv");
      }
      else if (this.jCheckBox1.isSelected())
        selectedFile = new File(fileNamePath + ".kml");
      else {
        selectedFile = new File(fileNamePath + ".xml");
      }

    }

    if (selectedFile.exists()) {
      int rValue = JOptionPane.showConfirmDialog(this, "[" + selectedFile.getAbsolutePath() + "]\nWould you like to override?", "File Exist", 0);

      if (rValue == 0)
        if (!selectedFile.canWrite())
          JOptionPane.showMessageDialog(this, "This file can not update.\nPlease check access contorl", "File error", 0);
        else
          try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(selectedFile));
            if ((this.jCheckBox1.isSelected()) && (this.viewDialogType.equals(CSV_TYPE)))
              bw.write(getCSVFormat(this.targetNode, false).toString());
            else if ((this.jCheckBox1.isSelected()) && (this.viewDialogType.equals(XML_TYPE)))
              bw.write(getXMLFormat(this.targetNode, false).toString());
            else {
              bw.write(this.jTextArea1.getText());
            }
            bw.close();
          } catch (IOException ioe) {
            ioe.printStackTrace();
          }
    }
    else
    {
      try {
        BufferedWriter bw = new BufferedWriter(new FileWriter(selectedFile));
        if ((this.jCheckBox1.isSelected()) && (this.viewDialogType.equals(CSV_TYPE)))
          bw.write(getCSVFormat(this.targetNode, false).toString());
        else if ((this.jCheckBox1.isSelected()) && (this.viewDialogType.equals(XML_TYPE)))
          bw.write(getXMLFormat(this.targetNode, false).toString());
        else {
          bw.write(this.jTextArea1.getText());
        }
        bw.close();
      } catch (IOException ioe) {
        ioe.printStackTrace();
      }
    }
    setVisible(false);
  }

  public static void main(String[] args)
  {
    EventQueue.invokeLater(new Runnable() {
      public void run() {
        KYCViewDialog dialog = new KYCViewDialog(new JFrame(), true);
        dialog.addWindowListener(new WindowAdapter() {
          public void windowClosing(WindowEvent e) {
            System.exit(0);
          }
        });
        dialog.setVisible(true);
      }
    });
  }

  public StringBuffer getXMLFormat(KYCWTObjectNode theNode, boolean windchillLoader) {
    StringBuffer allStr = new StringBuffer();
    try {
      AdministrativeDomain aDomain = (AdministrativeDomain)theNode.getObject();
      allStr.append("<?xml version=\"1.0\" ?>\n");
      allStr.append("<!DOCTYPE NmLoader SYSTEM \"standardX10.dtd\">\n\n");
      allStr.append("<NmLoader>\n\n");

      AdminDomainRef domainRef = new AdminDomainRef();
      domainRef.setObject(aDomain);

      Enumeration collection = AccessControlHelper.manager.getAccessPolicyRules(domainRef);

      QueryResult result = null;
      AccessPolicyRule policy = null;
      Hashtable aclHash = null;
      Enumeration elements = null;
      Vector aclSet = null;
      KYCAccessPolicyInfo aPolicyInfo = null;
      WTAclEntry aEntry = null;

      String containerType = null;
      String containerName = null;
      String domain = null;
      String typeId = null;
      String fullTypeId = null;
      String permission = null;
      String principalType = null;
      String principal = null;
      String permissionList = null;
      String state = null;
      String appliesTo = null;

      String plusPermossionSet = "";
      String minusPermissionSet = "";

      WTContainer container = aDomain.getContainer();
      containerType = container.getConceptualClassname();
      containerName = container.getName();

      String tempDomain = AdministrativeDomainHelper.manager.getDomainPath(domainRef);
      domain = tempDomain.substring(tempDomain.indexOf("]") + 1);

      while (collection.hasMoreElements()) {
        policy = (AccessPolicyRule)collection.nextElement();
        if (domainRef.toString().equals(policy.getDomainRef().toString())) {
          result = PersistenceHelper.manager.navigate(policy, "entry", AclEntryLink.class);

          if ((result != null) && (result.size() > 0)) {
            aclHash = filteringPermission(result);
            elements = aclHash.elements();
            while (elements.hasMoreElements()) {
              aclSet = (Vector)elements.nextElement();
              aPolicyInfo = new KYCAccessPolicyInfo(policy, aclSet);

              typeId = aPolicyInfo.getTypeObjectName();
              fullTypeId = aPolicyInfo.getFullTypeObjectName();
              principalType = aPolicyInfo.getPrincipalType();
              principal = aPolicyInfo.getPrincipal();
              state = aPolicyInfo.getStateName();
              appliesTo = aPolicyInfo.getAppliesToFile();

              Vector aPermissionSet = aPolicyInfo.getPermissionSet();

              String grantStr = (String)aPermissionSet.get(0);
              if ((grantStr != null) && (grantStr.length() > 0)) {
                allStr.append("<csvAccessRuleKYC handler=\"ext.csc.support.domain.util.KYCLoadAccessRule.addAccessRule\" >\n");
                if (windchillLoader) {
                  allStr.append("    <csvcontainerType>" + containerType + "</csvcontainerType>\n");
                  allStr.append("    <csvcontainerName>" + containerName + "</csvcontainerName>\n");
                  allStr.append("    <csvdomain>" + domain + "</csvdomain>\n");
                }

                allStr.append("    <csvtypeId>" + fullTypeId + "</csvtypeId>\n");

                allStr.append("    <csvpermission>+</csvpermission>\n");
                allStr.append("    <csvprincipalType>" + principalType + "</csvprincipalType>\n");
                allStr.append("    <csvprincipal>" + principal + "</csvprincipal>\n");
                allStr.append("    <csvpermissionList>" + grantStr + "</csvpermissionList>\n");
                allStr.append("    <csvstate>" + state + "</csvstate>\n");
                allStr.append("    <csvappliesTo>" + appliesTo + "</csvappliesTo>\n");
                allStr.append("</csvAccessRuleKYC>\n\n");
              }

              String denyStr = (String)aPermissionSet.get(1);
              if ((denyStr != null) && (denyStr.length() > 0)) {
                allStr.append("<csvAccessRuleKYC handler=\"ext.csc.support.domain.util.KYCLoadAccessRule.addAccessRule\" >\n");
                if (windchillLoader) {
                  allStr.append("    <csvcontainerType>" + containerType + "</csvcontainerType>\n");
                  allStr.append("    <csvcontainerName>" + containerName + "</csvcontainerName>\n");
                  allStr.append("    <csvdomain>" + domain + "</csvdomain>\n");
                }

                allStr.append("    <csvtypeId>" + fullTypeId + "</csvtypeId>\n");

                allStr.append("    <csvpermission>-</csvpermission>\n");
                allStr.append("    <csvprincipalType>" + principalType + "</csvprincipalType>\n");
                allStr.append("    <csvprincipal>" + principal + "</csvprincipal>\n");
                allStr.append("    <csvpermissionList>" + denyStr + "</csvpermissionList>\n");
                allStr.append("    <csvstate>" + state + "</csvstate>\n");
                allStr.append("    <csvappliesTo>" + appliesTo + "</csvappliesTo>\n");
                allStr.append("</csvAccessRuleKYC>\n\n");
              }

              String absoluteStr = (String)aPermissionSet.get(2);
              if ((absoluteStr != null) && (absoluteStr.length() > 0)) {
                allStr.append("<csvAccessRuleKYC handler=\"ext.csc.support.domain.util.KYCLoadAccessRule.addAccessRule\" >\n");
                if (windchillLoader) {
                  allStr.append("    <csvcontainerType>" + containerType + "</csvcontainerType>\n");
                  allStr.append("    <csvcontainerName>" + containerName + "</csvcontainerName>\n");
                  allStr.append("    <csvdomain>" + domain + "</csvdomain>\n");
                }

                allStr.append("    <csvtypeId>" + fullTypeId + "</csvtypeId>\n");

                allStr.append("    <csvpermission>ab-</csvpermission>\n");
                allStr.append("    <csvprincipalType>" + principalType + "</csvprincipalType>\n");
                allStr.append("    <csvprincipal>" + principal + "</csvprincipal>\n");
                allStr.append("    <csvpermissionList>" + absoluteStr + "</csvpermissionList>\n");
                allStr.append("    <csvstate>" + state + "</csvstate>\n");
                allStr.append("    <csvappliesTo>" + appliesTo + "</csvappliesTo>\n");
                allStr.append("</csvAccessRuleKYC>\n\n");
              }
            }
          }
        }

      }

      allStr.append("</NmLoader>\n");
    } catch (WTException wte) {
      wte.printStackTrace();
    }
    return allStr;
  }

  public StringBuffer getCSVFormat(KYCWTObjectNode theNode, boolean windchillLoader) {
    StringBuffer allStr = new StringBuffer();
    try {
      AdministrativeDomain aDomain = (AdministrativeDomain)theNode.getObject();
      allStr.append("#\n# GENERATED CSV FORMAT ABOUT ACCESS RULE FOR " + aDomain.getName() + " DOMAIN BY YCKIM \n#\n");

      AdminDomainRef domainRef = new AdminDomainRef();
      domainRef.setObject(aDomain);

      Enumeration collection = AccessControlHelper.manager.getAccessPolicyRules(domainRef);

      QueryResult result = null;
      AccessPolicyRule policy = null;
      Hashtable aclHash = null;
      Enumeration elements = null;
      Vector aclSet = null;
      KYCAccessPolicyInfo aPolicyInfo = null;
      WTAclEntry aEntry = null;

      String containerType = null;
      String containerName = null;
      String domain = null;
      String typeId = null;
      String permission = null;
      String principalType = null;
      String principal = null;
      String permissionList = null;
      String state = null;
      String appliesTo = null;

      String plusPermossionSet = "";
      String minusPermissionSet = "";

      WTContainer container = aDomain.getContainer();
      containerType = container.getConceptualClassname();
      containerName = container.getName();

      String tempDomain = AdministrativeDomainHelper.manager.getDomainPath(domainRef);
      domain = tempDomain.substring(tempDomain.indexOf("]") + 1);

      while (collection.hasMoreElements()) {
        policy = (AccessPolicyRule)collection.nextElement();
        if (domainRef.toString().equals(policy.getDomainRef().toString())) {
          result = PersistenceHelper.manager.navigate(policy, "entry", AclEntryLink.class);

          if ((result != null) && (result.size() > 0)) {
            aclHash = filteringPermission(result);
            elements = aclHash.elements();
            while (elements.hasMoreElements()) {
              aclSet = (Vector)elements.nextElement();
              aPolicyInfo = new KYCAccessPolicyInfo(policy, aclSet);

              typeId = aPolicyInfo.getFullTypeObjectName();
              principalType = aPolicyInfo.getPrincipalType();
              principal = aPolicyInfo.getPrincipal();
              state = aPolicyInfo.getStateName();
              appliesTo = aPolicyInfo.getAppliesToFile();

              Vector aPermissionSet = aPolicyInfo.getPermissionSet();

              String grantStr = (String)aPermissionSet.get(0);
              if ((grantStr != null) && (grantStr.length() > 0)) {
                if (windchillLoader) {
                  allStr.append("AccessRuleKYC," + 
                    containerType + "," + 
                    containerName + "," + 
                    domain + "," + 
                    typeId + "," + 
                    "+" + "," + 
                    principalType + "," + 
                    principal + "," + 
                    appliesTo + "," + 
                    grantStr + "," + 
                    state + "\n");
                }
                else {
                  allStr.append("AccessRuleKYC," + 
                    typeId + "," + 
                    "+" + "," + 
                    principalType + "," + 
                    principal + "," + 
                    appliesTo + "," + 
                    grantStr + "," + 
                    state + "\n");
                }

              }

              String denyStr = (String)aPermissionSet.get(1);
              if ((denyStr != null) && (denyStr.length() > 0)) {
                if (windchillLoader) {
                  allStr.append("AccessRuleKYC," + 
                    containerType + "," + 
                    containerName + "," + 
                    domain + "," + 
                    typeId + "," + 
                    "-" + "," + 
                    principalType + "," + 
                    principal + "," + 
                    appliesTo + "," + 
                    denyStr + "," + 
                    state + "\n");
                }
                else {
                  allStr.append("AccessRuleKYC," + 
                    typeId + "," + 
                    "-" + "," + 
                    principalType + "," + 
                    principal + "," + 
                    appliesTo + "," + 
                    denyStr + "," + 
                    state + "\n");
                }

              }

              String absoluteStr = (String)aPermissionSet.get(2);
              if ((absoluteStr != null) && (absoluteStr.length() > 0)) {
                if (windchillLoader) {
                  allStr.append("AccessRuleKYC," + 
                    containerType + "," + 
                    containerName + "," + 
                    domain + "," + 
                    typeId + "," + 
                    "ab-" + "," + 
                    principalType + "," + 
                    principal + "," + 
                    appliesTo + "," + 
                    absoluteStr + "," + 
                    state + "\n");
                }
                else {
                  allStr.append("AccessRuleKYC," + 
                    typeId + "," + 
                    "ab-" + "," + 
                    principalType + "," + 
                    principal + "," + 
                    appliesTo + "," + 
                    absoluteStr + "," + 
                    state + "\n");
                }
              }
            }
          }
        }
      }
    }
    catch (WTException wte)
    {
      wte.printStackTrace();
    }
    return allStr;
  }

  public Hashtable filteringPermission(QueryResult result) throws WTException {
    Hashtable returnHash = new Hashtable();
    Vector aclVector = new Vector();

    WTAclEntry aclEntry = null;
    while (result.hasMoreElements()) {
      aclEntry = (WTAclEntry)result.nextElement();

      if (returnHash.get(aclEntry.getPrincipalReference()) == null) {
        aclVector = new Vector();
        aclVector.add(aclEntry);
        returnHash.put(aclEntry.getPrincipalReference(), aclVector);
      } else {
        aclVector = (Vector)returnHash.get(aclEntry.getPrincipalReference());
        aclVector.add(aclEntry);
        returnHash.put(aclEntry.getPrincipalReference(), aclVector);
      }
    }

    return returnHash;
  }
}