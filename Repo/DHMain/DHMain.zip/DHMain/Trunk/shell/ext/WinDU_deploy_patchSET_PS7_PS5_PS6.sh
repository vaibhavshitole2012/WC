#!/bin/bash

export PATCHLOG_FILE=$WT_HOME/logs/WinDU_patchSET_Script_$(date +%Y%m%d%H%M%S).log

export DEPLOYPATH=/misc/ptc/WinDU/100
export START_PATCH=$(date +%Y.%m.%d_%H:%M:%S)

echo "----------------------------------------------------" >> $PATCHLOG_FILE
echo "Starting PatchSet:" $START_PATCH >> $PATCHLOG_FILE
echo "----------------------------------------------------" >> $PATCHLOG_FILE

java -jar $DEPLOYPATH/10.0-M0X0_WINDU_WINRU_SUPPORT_PS5/10.0-M0X0_WINDU_WINRU_SUPPORT_PS5.jar -a $WT_HOME >> $PATCHLOG_FILE
java -jar $DEPLOYPATH/10.0-M0X0_WINDU_WINRU_SUPPORT_PS5/10.0-M0X0_WINDU_WINRU_SUPPORT_PS5.jar -g $WT_HOME >> $PATCHLOG_FILE
java -jar $DEPLOYPATH/10.0-M0X0_WINDU_WINRU_PS6/10.0-M0X0_WINDU_WINRU_PS6.jar -a $WT_HOME >> $PATCHLOG_FILE
java -jar $DEPLOYPATH/10.0-M0X0_WINDU_WINRU_PS6/10.0-M0X0_WINDU_WINRU_PS6.jar -g $WT_HOME >> $PATCHLOG_FILE
java -jar $DEPLOYPATH/10.0-M040_PS7/10.0-M040_PS7.jar -a $WT_HOME >> $PATCHLOG_FILE
java -jar $DEPLOYPATH/10.0-M040_PS7/10.0-M040_PS7.jar -g $WT_HOME >> $PATCHLOG_FILE

export STOP_PATCH=$(date +%Y.%m.%d_%H:%M:%S) 

echo "----------------------------------------------------" >> $PATCHLOG_FILE
echo "Stoping PatchSet:" $STOP_PATCH >> $PATCHLOG_FILE
echo "----------------------------------------------------" >> $PATCHLOG_FILE

echo "Started PatchSet:" $START_PATCH >> $PATCHLOG_FILE
echo "Stopped PatchSet:" $STOP_PATCH >> $PATCHLOG_FILE
