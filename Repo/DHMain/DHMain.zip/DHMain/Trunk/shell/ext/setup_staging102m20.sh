#cd /misc/ptc/staging_102m20
#mkdir MED-2101-CD-102_F000_INFO_MOD
#cd /misc/ptc/staging_102m20/MED-2101-CD-102_F000_INFO_MOD
#jar -xvf /misc/ptc/WT102M020/MED-2101-CD-102_F000_INFO_MOD.zip

#!/bin/bash

STAGINGZIP=/misc/ptc/WT102M020
STAGING=/misc/ptc/staging_102m20

        for i in $( ls $STAGINGZIP ); do
            echo item: $i
	    mkdir $STAGING/$i
	    cd $STAGING/$i
	    jar -xvf $STAGINGZIP/$i
	    chmod 775 -R $STAGINGZIP/$i
        done

STAGINGZIPCPS=/misc/ptc/WT102M020/CPS
STAGINGCPS=/misc/ptc/staging_102m20_CPS

        for i in $( ls $STAGINGZIP ); do
            echo item: $i
	    mkdir $STAGING/$i
	    cd $STAGING/$i
	    jar -xvf $STAGINGZIP/$i
	    chmod 775 -R $STAGINGZIP/$i
        done