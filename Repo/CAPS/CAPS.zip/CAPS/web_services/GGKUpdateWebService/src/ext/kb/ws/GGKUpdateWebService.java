package ext.kb.ws;

import com.ptc.jws.servlet.JaxWsWebService;

import java.io.IOException;
import java.text.MessageFormat;

import javax.jws.Oneway;
import javax.jws.WebMethod;
import javax.jws.WebService;

import org.apache.log4j.Logger;

import wt.log4j.LogR;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.util.WTRuntimeException;
import ext.kb.service.GGKUpdateHelper;

@WebService()

public class GGKUpdateWebService extends JaxWsWebService {
	 
	
	private static Logger log = LogR.getLogger(GGKUpdateWebService.class.getName());
	@WebMethod(operationName="updateGGK")
	    public void updateGGK (String inputFile, String logDir)
	    {
	        try {
	           GGKUpdateHelper.updateProcurementParts(inputFile, logDir);
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }

}
