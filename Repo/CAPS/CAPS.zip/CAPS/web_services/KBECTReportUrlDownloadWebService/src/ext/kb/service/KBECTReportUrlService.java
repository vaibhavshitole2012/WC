package ext.kb.service;

import java.beans.PropertyVetoException;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.attribute.PosixFilePermission;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import org.apache.log4j.Logger;
import org.jfree.util.Log;

import com.ptc.windchill.enterprise.query.server.queryResource;

import ext.kb.util.KBConstants;
import wt.change2.ChangeActivity2;
import wt.change2.ChangeActivityIfc;
import wt.change2.ChangeHelper2;
import wt.content.ApplicationData;
import wt.content.ContentHolder;
import wt.content.ContentRoleType;
import wt.content.ContentServerHelper;
import wt.doc.WTDocument;
import wt.fc.ObjectIdentifier;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.fc.WTReference;
import wt.log4j.LogR;
import wt.org.WTPrincipal;
import wt.part.WTPart;
import wt.session.SessionHelper;
import wt.util.WTContext;
import wt.util.WTException;
import wt.util.WTProperties;
import wt.util.WTRuntimeException;

/**
 * This service exposes a static method {@link getContentUrls} that is called
 * from a Web service running on the same method server. <br>
 * 
 */
public class KBECTReportUrlService {
	protected static final Logger log = LogR.getLogger(KBECTReportUrlService.class.getName());
	public static final String ALLOWED_FILE_TYPES = "FileTypes";
		
    /**
     * Retrieves the content URLs for the given object id.
     * 
     * @param oid: wt.epm.EPMDocument:123456
     * @return a list of URLs:
     *         <ol>
     *         <li>Primary content</li>
     *         <li>default representation</li>
     *         <li>attachments</li>
     *         </ol>
     * @throws WTException
     * @throws WTRuntimeException
     * @throws IOException
     * @throws PropertyVetoException
     * @throws WTKContentUploadException
     * @throws WTKContentException
     */
    public static List<String> getECTReportUrl(String oid, String user,String mastersystem) throws WTRuntimeException,
            WTException, PropertyVetoException, IOException {
    	final List<String> result = new ArrayList<>();

    	try {
        log.debug("KBContentUrlService.getContentUrls called with OID " + oid);

        authenticate3(user);

        final ContentHolder holder = obtainHolder(oid);
        if (holder == null) {
            return null;
        }
        
        //final List<String> result = new ArrayList<>();
       
	        final List<String> attUrls = fetchAttachmentUrls(holder,oid,mastersystem);
	        for (int i = 0; i < attUrls.size(); i++) {
	            result.add(i, attUrls.get(i) == null ? "" : attUrls.get(i));
        }
	        if(result.isEmpty()) {
	        	result.add("No contents attached to ECT");
	        }
    	}catch(WTRuntimeException | WTException | PropertyVetoException | IOException e) {
    		if(!result.isEmpty()){
        		result.clear();
        	}
        	result.add("Return Code :1");
        	result.add(e.getLocalizedMessage());
    	}
        
         
        return result;
    }

    private static List<String> fetchAttachmentUrls(ContentHolder holder,String oid,String mastersystem) throws WTException,
            PropertyVetoException, IOException {
        List<String> result = new ArrayList<>();
    	WTProperties props = WTProperties.getLocalProperties();
    	String WINDCHILL_SERVER = props.getProperty("wt.rmi.server.hostname");
    	String PORT = props.getProperty("wt.webserver.port");
    	String WEB_APP = props.getProperty("wt.webapp.name");
 
    	log.debug("WINDCHILL_SERVER===" + WINDCHILL_SERVER);
    	log.debug("PORT===" + PORT);
    	log.debug("WEB_APP===" + WEB_APP);

        final Set<ApplicationData> appDatas = KBECTReportHelper.retrieveAttachmentContainer(holder);
        Iterator<ApplicationData> iterator = appDatas.iterator();
        QueryResult queryResult = ChangeHelper2.service.getChangeablesAfter((ChangeActivityIfc) holder, true);
        List<Object> objectList = new ArrayList<>();
        while (queryResult.hasMoreElements()) {
        	objectList.add(queryResult.nextElement());
        }

		while (iterator.hasNext()) {
			ApplicationData appData = iterator.next();
			if (appData == null) {
				log.debug("Secondary content for holder <" + holder + "> not found.");
				continue;
			}

			log.debug("Content Role is " + appData.getRole());
			if (!ContentRoleType.SECONDARY.equals(appData.getRole())) {
				log.debug("Not secondary content but <" + appData.getRole() + ">. Skipped.");
				continue;
			}

			String fileType = "";
			ObjectIdentifier coid = appData.getPersistInfo().getObjectIdentifier();
			String fileName = appData.getFileName();
			log.debug("fileName " + fileName);
			if (fileName != null) {
				fileType = com.ptc.ddl.util.FileHelper.getExtension(fileName);
				log.debug("fileType " + fileType);
			}

			String vrid = "OR:" + oid.trim();
			Persistable persistable = new ReferenceFactory().getReference(vrid).getObject();
			if (persistable instanceof ChangeActivity2) {
				String ECTNumber = ((ChangeActivity2) persistable).getNumber();
				log.debug("ECTNumber   ===" + ECTNumber);
				log.debug("coid " + coid);
				log.debug("coid.toString() " + coid.toString());
				if (fileName.startsWith("ECT-") || fileName.startsWith("SCT-")) {
					
					String[] splitCoid = coid.toString().split(":");
					int size = splitCoid.length;
					log.debug("splitCoid.length " + size);
					String intCoid = splitCoid[size - 1];
					log.debug("intCoid " + intCoid);
					log.debug("Holder details : " + holder.getClass().toString());
					String originalFileName = "";
					// Getting resulting objects - to get actual object numbers
					log.debug("Objects in change task: " + queryResult.size());
					Iterator objIterator = objectList.iterator();
					while (objIterator.hasNext()) {
						Object object = objIterator.next();
						log.debug("Object is : " + object.getClass());
						if (object instanceof WTPart) {
							WTPart part = (WTPart) object;
							String articleDetails = part.getNumber().replaceAll("[^a-zA-Z0-9\\-]", "_")
									+ KBConstants.UNDERSCORE_DELIMITER + part.getVersionIdentifier().getValue()
									+ KBConstants.DOT_DELIMITER;
							log.debug("Article details formed from Article : " + articleDetails);
							// checking if the object number (modified) exists in the attachment
							if (fileName.contains(articleDetails)) {
								// modified number is in attachment, so getting the actual number
								// original file name format is (eg.) : ECT-0056036_Article_H0122068_A.pdf
								log.debug("Article number after changing: " + articleDetails);
								log.debug("Actual article number: " + part.getNumber());
								originalFileName = KBConstants.PIPE_DELIMITER + ECTNumber
										+ KBConstants.UNDERSCORE_DELIMITER + "Article"
										+ KBConstants.UNDERSCORE_DELIMITER + part.getNumber()
										+ KBConstants.UNDERSCORE_DELIMITER + part.getVersionIdentifier().getValue()
										+ "." + fileType;
								break;
							}
						} else if (object instanceof WTDocument) {
							WTDocument doc = (WTDocument) object;
							String docDetails = doc.getNumber().replaceAll("[^a-zA-Z0-9\\-]", "_")
									+ KBConstants.UNDERSCORE_DELIMITER + doc.getVersionIdentifier().getValue()
									+ KBConstants.DOT_DELIMITER;
							// checking if the object number (modified) exists in the attachment
							if (fileName.contains(docDetails)) {
								// modified number is in attachment, so getting the actual number
								log.debug("Document number after changing: " + docDetails);
								log.debug("Actual Document number: " + doc.getNumber());
								originalFileName = KBConstants.PIPE_DELIMITER + ECTNumber
										+ KBConstants.UNDERSCORE_DELIMITER + "Document"
										+ KBConstants.UNDERSCORE_DELIMITER + doc.getNumber()
										+ KBConstants.UNDERSCORE_DELIMITER + doc.getVersionIdentifier().getValue()
										+ "." + fileType;
								break;
							}
						}
					}

					log.debug("Original file name : " + originalFileName);
					String url = "http://" + WINDCHILL_SERVER + ":" + PORT + "/" + WEB_APP
							+ "/ptc1/download/KB_File_Download?coid=" + intCoid + "|" + fileName + "|" + fileType
							+ originalFileName;

					log.debug("Found attachment content url: " + url);

					if ("CADIM".equalsIgnoreCase(mastersystem)) {
						WTProperties propertiess = WTProperties.getLocalProperties();
						String value = propertiess.getProperty("CADIM_TRANSFER_LOCATION");
						log.debug("CADIM_TRANSFER_LOCATION: " + value);
						writeECTReportFileToServer(new File(value), ECTNumber, appData);
						log.debug("After Writing Content FIle to server " + value);
					}

					result.add(url);
				}
			}
		}

        log.debug("secondary attachments " + result.size());
        return result;
    }

    private static ContentHolder obtainHolder(String oid) throws WTRuntimeException, WTException {
        String vrid = "OR:" + oid.trim();
        final WTReference reference = new ReferenceFactory().getReference(vrid);
        if (reference == null) {
            log.error("Cannot find WTReference form OID " + oid);
            return null;
        }

        final Persistable persistable = reference.getObject();
        if (persistable == null) {
            log.error("Cannot find Persistble form OID " + oid);
            return null;
        }

        if (persistable instanceof ContentHolder) {
            return (ContentHolder) persistable;
        }
        log.error("Not a ContentHolder: " + persistable);
        return null;
    }
	
    /**
     * Authenticates to method server with a given user name. It is not for
     * remote access to Windchill.
     *
     * @param username a Windchill user name
     * @throws WTException
     */
    private static void authenticate3(String username) throws WTException {
        log.debug("Authenticating with " + username);

        WTContext.getContext().setLocale(Locale.UK);

        try {
            WTPrincipal newPrincipal = SessionHelper.manager.setPrincipal(username);
            log.trace("newPrincipal:" + newPrincipal);
            WTPrincipal newPrincipal2 = SessionHelper.manager.getPrincipal();
            log.trace("newPrincipal2:" + newPrincipal2);

        } catch (WTException e1) {
            log.error(e1);
        }

    }
    
    private static void writeECTReportFileToServer(File dirPath, String oid, ApplicationData ci ) throws WTException, PropertyVetoException, IOException {
    	//ObjectIdentifier docOID = ObjectIdentifier.newObjectIdentifier(oid);
    	String fileType="";
    	//log.debug("docOID== "+docOID);
    	Set<PosixFilePermission> permission = new HashSet<PosixFilePermission>();
    	permission.add(PosixFilePermission.OWNER_READ);
    	permission.add(PosixFilePermission.OWNER_WRITE);
    	permission.add(PosixFilePermission.OWNER_EXECUTE);
    	permission.add(PosixFilePermission.GROUP_READ);
    	permission.add(PosixFilePermission.GROUP_WRITE);
    	permission.add(PosixFilePermission.GROUP_EXECUTE);
    	permission.add(PosixFilePermission.OTHERS_READ);
    	permission.add(PosixFilePermission.OTHERS_WRITE);
    	permission.add(PosixFilePermission.OTHERS_EXECUTE);
    	File subFolder = new File(dirPath, oid);
    	    	
    	if(!subFolder.exists())
    	{
        if (!subFolder.mkdir()) {
            throw new IOException("Failed to create directory " + subFolder);
        }
        Files.setPosixFilePermissions(subFolder.toPath(),permission);
    	}
    	      	ContentServerHelper.service.writeContentStream((ApplicationData) ci, new File(subFolder,((ApplicationData) ci).getFileName()).getCanonicalPath());
            	log.debug("Before setting permission "+new File(subFolder,((ApplicationData) ci).getFileName()).toPath());
            	Files.setPosixFilePermissions(new File(subFolder,((ApplicationData) ci).getFileName()).toPath(), permission);
            	log.debug("After writing content stream ");
   }
}
