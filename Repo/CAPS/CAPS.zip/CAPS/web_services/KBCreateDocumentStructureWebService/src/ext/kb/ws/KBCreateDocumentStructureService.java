package ext.kb.ws;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.xml.bind.JAXBException;

import org.apache.log4j.Logger;

import wt.doc.WTDocument;
import wt.doc.WTDocumentMaster;
import wt.doc.WTDocumentUsageLink;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.log4j.LogR;
import wt.part.WTPartDescribeLink;
import wt.pds.StatementSpec;
import wt.pom.Transaction;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.vc.VersionControlHelper;

import com.ptc.jws.servlet.JaxWsWebService;

import ext.kb.service.WebServiceHelper;
import ext.kb.util.DBUtils;
import ext.kb.util.ObjectRevisionHelper;
import ext.kb.ws.ChildDocumentObject;

@WebService()
public class KBCreateDocumentStructureService extends JaxWsWebService
{
	private static final Logger LOGGER = LogR.getLogger(KBCreateBOMService.class.getName());
	@WebMethod(operationName="createDocumentStructure")
    public List<String> createDocumentStructure (@WebParam(name="parentID") String parentID,@WebParam(name="parent_CID") String parent_CID, @WebParam(name="childIDs") ArrayList<ChildDocumentObject> childIDs) throws WTException,WTPropertyVetoException, JAXBException, IOException
    
    {

    	Transaction trx = null;
    	List<String> result = new ArrayList<String>();
    	String wtHome = WebServiceHelper.getWindchillHome();
		LOGGER.debug("WT_HOME : "+wtHome);
		String LOG_FILE_NAME = wtHome+"/logs/interface";
		WebServiceHelper.createDirIfNotExisting(LOG_FILE_NAME);
		LOG_FILE_NAME = wtHome+"/logs/interface/Cadim2WctCreateDocumentStructure.log";
    	//String LOG_FILE_NAME = "/opt/ptc/wt111/Cadim2WctCreateDocumentStructure.log";
	    PrintWriter logPw = null;
	    FileWriter fw = null;
	    BufferedWriter bw = null;
        
        try {
            
        trx = new Transaction();
        trx.start();
        File file = new File(LOG_FILE_NAME);
		file.setExecutable(true, false);
        file.setReadable(true, false);
        file.setWritable(true, false);
        LOGGER.debug("After getting log file ==="+file);
        fw = new FileWriter(LOG_FILE_NAME,true);
        bw = new BufferedWriter(fw);
        logPw = new PrintWriter(bw);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        String dummyDocNumber = "HD0000221-000";
        Date date = new Date();
        String formatedDate = sdf.format(date);
        
        logPw.println(" Processing create Document Structure on "+formatedDate+" request parent number is "+parentID+" parent_CID is "+parent_CID);

    	QuerySpec resQS = WebServiceHelper.findDocumentByNumberAndCadim(parentID,parent_CID);
		QueryResult resQR = PersistenceHelper.manager.find((StatementSpec) resQS);
    	int size = resQR.size();
    	 if(size > 0)
		 {
		 Persistable resObj [] = (Persistable [])resQR.nextElement();
		 LOGGER.debug("resObj: " + resObj);

		 logPw.println("resObj: " + resObj[0]);
		 WTDocument resDoc = (WTDocument)resObj[0];
		 LOGGER.debug("resDoc: " + resDoc);
		 logPw.println("resDoc: " + resDoc);
		 WTDocument latestDocRevision = (WTDocument)ObjectRevisionHelper.getLatestVersionByPersistable(resDoc);
		 WTDocument latestDocIteration = (WTDocument)VersionControlHelper.getLatestIteration(latestDocRevision);
		 LOGGER.debug("latestDocIteration version: " + latestDocIteration.getVersionIdentifier().getValue()+" iteration is "+latestDocIteration.getIterationIdentifier().getValue());
		 logPw.println("latestDocIteration version: " + latestDocIteration.getVersionIdentifier().getValue()+" iteration is "+latestDocIteration.getIterationIdentifier().getValue());
	 

		ArrayList<WTDocumentUsageLink> usageLinksList = (ArrayList<WTDocumentUsageLink>) DBUtils.retrieveLinks(WTDocumentUsageLink.class, latestDocIteration, WTDocumentUsageLink.ROLE_BOBJECT_ROLE);
		LOGGER.debug("usageLinksList size " + usageLinksList.size());
		logPw.println("usageLinksList size " + usageLinksList.size());
		for (WTDocumentUsageLink wtDocUsageLink : usageLinksList) {
			LOGGER.debug("B4 deleting usageLinksList " );
			logPw.println("B4 deleting usageLinksList " );
			PersistenceServerHelper.manager.remove(wtDocUsageLink);
			LOGGER.debug("After deleting wtDocUsageLink ");
			logPw.println("After deleting wtDocUsageLink ");
		}
			ArrayList<WTDocumentUsageLink> usageLinksList1 = (ArrayList<WTDocumentUsageLink>) DBUtils.retrieveLinks(WTDocumentUsageLink.class, latestDocIteration, WTDocumentUsageLink.ROLE_BOBJECT_ROLE);
			LOGGER.debug("usageLinksList1 size " + usageLinksList1.size());
			WTDocumentMaster parentMaster = (WTDocumentMaster) latestDocIteration.getMaster();
			LOGGER.debug("parent number: " + latestDocIteration.getNumber());
			logPw.println("parent number: " + latestDocIteration.getNumber());
			LOGGER.debug("childID.size(): " + childIDs.size());
			logPw.println("childID.size(): " + childIDs.size());
		for(int i=0;i<childIDs.size();i++)
		{
			
			ChildDocumentObject cdo = (ChildDocumentObject) childIDs.get(i);
			LOGGER.debug("child Doc number" + cdo.getNumber());
			logPw.println("child Doc CID" + cdo.getCID());
			logPw.println("child Doc number" + cdo.getNumber());
			LOGGER.debug("child Doc CID" + cdo.getCID());
			QuerySpec childDocQS = WebServiceHelper.findDocumentByNumberAndCadim(cdo.getNumber(),cdo.getCID());
			QueryResult childDocQR = PersistenceHelper.manager.find((StatementSpec) childDocQS);
	    	int childDocSize = childDocQR.size();
			LOGGER.debug("childDocQR.size(): " + childDocQR.size());
			logPw.println("childDocQR.size(): " + childDocQR.size());
			if(childDocQR.size()>0)
			{
				Persistable childDocObj [] = (Persistable [])childDocQR.nextElement();
				LOGGER.debug("resObj: " + childDocObj[0]);
				WTDocument childDoc = (WTDocument)childDocObj[0];
				WTDocument latestChildDocRevision = (WTDocument)ObjectRevisionHelper.getLatestVersionByPersistable(childDoc);
				WTDocument latestChildDocIteration = (WTDocument)VersionControlHelper.getLatestIteration(latestChildDocRevision);
				LOGGER.debug("latestChildDocIteration version: " + latestChildDocIteration.getVersionIdentifier().getValue()+" iteration is "+latestChildDocIteration.getIterationIdentifier().getValue());
				logPw.println("latestChildDocIteration version: " + latestChildDocIteration.getVersionIdentifier().getValue()+" iteration is "+latestChildDocIteration.getIterationIdentifier().getValue());
				WTDocumentMaster childMaster = (WTDocumentMaster) latestChildDocIteration.getMaster();
				WTDocumentUsageLink newWTDocumentUsageLink = WTDocumentUsageLink.newWTDocumentUsageLink(latestDocIteration, childMaster);
				LOGGER.debug("newWTPartUsageLink " + newWTDocumentUsageLink);
				logPw.println("newWTPartUsageLink " + newWTDocumentUsageLink);
				PersistenceServerHelper.manager.insert(newWTDocumentUsageLink);	
				LOGGER.debug("After link Attributes "); 
				logPw.println("After setting link Attributes ");
	     					
			}	
			else{
	    		 //throw new WTException("Child Document with number "+cdo.getNumber()+" and CID "+cdo.getC_ID()+" not found");
	    		 LOGGER.debug("Document with number"+ cdo.getNumber() + " Not found going to create describe link with Dummy Document");
					logPw.println("Document with number"+ cdo.getNumber() + " Not found going to create describe link with Dummy Document");
					QuerySpec dummyDoc = new QuerySpec();
					int docIndex = dummyDoc.appendClassList(WTDocument.class, true);
					int docMasterIndex = dummyDoc.appendClassList(WTDocumentMaster.class,false);
					dummyDoc.appendWhere(new SearchCondition(WTDocument.class,
							"masterReference.key.id", WTDocumentMaster.class,
							"thePersistInfo.theObjectIdentifier.id"), new int[] {
							docIndex, docMasterIndex });
					dummyDoc.appendAnd();
					dummyDoc.appendWhere(new SearchCondition(WTDocumentMaster.class, "number",
							SearchCondition.EQUAL, dummyDocNumber),
							new int[] { docMasterIndex });
					QueryResult dummyDocQR = PersistenceHelper.manager.find((StatementSpec) dummyDoc);
					LOGGER.debug("dummyDocQr size = "+dummyDocQR.size());
					logPw.println("dummyDocQr size = "+dummyDocQR.size());
					Persistable dummyDocObj[] = (Persistable[]) dummyDocQR.nextElement();
					LOGGER.debug("dummyDocObj[0] " + dummyDocObj[0]);
					WTDocument dummyDocument = (WTDocument) dummyDocObj[0];
					//WTDocument dummyDocument = (WTDocument) dummyDocQR.nextElement();
					WTDocumentMaster dummyDocumentMaster = (WTDocumentMaster) dummyDocument.getMaster();
					WTDocumentUsageLink newWTDocumentUsageLink = WTDocumentUsageLink.newWTDocumentUsageLink(latestDocIteration, dummyDocumentMaster);
					LOGGER.debug("newWTPartUsageLink " + newWTDocumentUsageLink);
					PersistenceServerHelper.manager.insert(newWTDocumentUsageLink);	
					LOGGER.debug("After creating Describe link for dummy doc number "+ dummyDocument.getNumber());
					logPw.println("After creating Describe link for dummy doc number "+ dummyDocument.getNumber());
	    	 }
			
		}

		trx.commit();
        trx = null;    
        result.add("0");
        result.add("Success");
        LOGGER.info(result);
        logPw.println("Result of the resquest is "+result);
		return result;
		 }
    	 else{
    		 throw new WTException("Parent Document Not found");
    	 }
        }
        catch (WTException e) {
            String message = "WTException during Document Structure Creation exception is "+e ;
            result.add("1");
            result.add(message);
            LOGGER.info(result);
            logPw.println("Result of the resquest is "+result);
			return result;
            
        } catch (WTPropertyVetoException e) {
     	   String message = "WTException during Document Structure Creation exception is "+e ;
     	  result.add("1");
          result.add(message);
          LOGGER.info(result);
          logPw.println("Result of the resquest is "+result);
		  return result;
        } 
        finally {
        	LOGGER.debug("trx in finally==="+trx );
            if (trx != null) {
                trx.rollback();
            }
            logPw.flush();
            logPw.close();
        }
    }
}