package ext.kb.part;

import java.util.ArrayList;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

import com.ptc.jws.servlet.JaxWsWebService;

import ext.kb.part.OutputRefDesignatorObject;
import ext.kb.part.RefDesignatorObject;
import ext.kb.part.ReferenceDesignatorHelper;
import wt.util.WTException;

@WebService()
public class KBReferenceDesignatorWebService extends JaxWsWebService
{
    @WebMethod(operationName="getReferenceDesignator")
    public ArrayList<OutputRefDesignatorObject> getReferenceDesignator(@WebParam(name="RefDesignatorObject") ArrayList<RefDesignatorObject> RefDesignatorDetails)
    {
    	ArrayList outobj=new ArrayList();
		try {
			outobj = ReferenceDesignatorHelper.startProcess(RefDesignatorDetails);
		} catch (WTException e) {
			e.printStackTrace();
		}
    	return outobj;
    }
}