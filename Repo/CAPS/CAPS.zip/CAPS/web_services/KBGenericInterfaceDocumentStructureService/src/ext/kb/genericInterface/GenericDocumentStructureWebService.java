package ext.kb.genericInterface;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

import com.ptc.jws.servlet.JaxWsWebService;

import ext.kb.genericInterface.documentstructure.DocStructObject;
import ext.kb.genericInterface.documentstructure.GenericInterfaceforDocStructure;

@WebService()
public class GenericDocumentStructureWebService extends JaxWsWebService
{
	@WebMethod(operationName="callDocumentStructureOperation")
	public ArrayList<DocStructObject> callDocumentStructureOperation(@WebParam(name = "docstruct") ArrayList<DocStructObject> docstructure) throws NoSuchMethodException, SecurityException,
	ClassNotFoundException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		ArrayList<DocStructObject> response =GenericInterfaceforDocStructure.performOperationonDocStructure(docstructure);		
		return response;
	}


}