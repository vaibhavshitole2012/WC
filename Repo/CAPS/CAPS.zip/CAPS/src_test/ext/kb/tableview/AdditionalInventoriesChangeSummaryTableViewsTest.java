package ext.kb.tableview;

import static org.junit.Assert.*;

import java.util.List;
import java.util.Locale;

import org.junit.Test;

import com.ptc.core.htmlcomp.createtableview.Attribute.TextAttribute;

import ext.kb.enumconstant.InventoryDispositions;
import ext.kb.util.KBUtils;


public class AdditionalInventoriesChangeSummaryTableViewsTest {

	AdditionalInventoriesChangeSummaryTableViews view = new AdditionalInventoriesChangeSummaryTableViews();
	
	@Test
	public void testGetSpecialTableColumnsAttrDefinitionLocale() {
		//Could add more test to check other locales have values as well
		List<?> def = view.getSpecialTableColumnsAttrDefinition(Locale.ENGLISH);
		assertEquals(18, def.size());
		TextAttribute attr = (TextAttribute)def.get(16);
		assertEquals("inAssembledPartsDisposition", attr.getId());
		assertFalse(KBUtils.isEmpty(attr.getLabel()));
		attr = (TextAttribute)def.get(17);
		assertEquals("withCustomerDisposition", attr.getId());
	}

	@Test
	public void testGetDefaultColumnsString() {
		List<String> columns = view.getDefaultColumns(AdditionalInventoriesChangeSummaryTableViews.AFFECTED_PARTS_VIEW);
		assertTrue(columns.contains(InventoryDispositions.WITH_CUSTOMERS));
		assertTrue(columns.contains(InventoryDispositions.IN_ASSEMLED_PARTS));
		assertEquals(17, columns.size());
		
		columns = view.getDefaultColumns(AdditionalInventoriesChangeSummaryTableViews.RELEASE_CONTENT_VIEW);
		assertEquals(16, columns.size());
		columns = view.getDefaultColumns("x");
		assertEquals(13, columns.size());
	}
}
