package ext.kb.part.form;

import static mockit.Deencapsulation.*;

import java.util.ArrayList;
import java.util.List;

import mockit.Mocked;
import mockit.NonStrictExpectations;

import org.junit.Test;

import wt.fc.ObjectReference;
import wt.part.WTPart;
import wt.type.TypedUtilityService;
import wt.type.TypedUtilityServiceHelper;

import com.ptc.core.components.beans.ObjectBean;

import ext.kb.util.KBTypeIdProvider;

public class KBMechanicalPartFormProcessorTest {
    
    @Mocked TypedUtilityService serv;
    
    /*
     ObjectBean localObjectBean = (ObjectBean) paramList.get(0);
        if ((localObjectBean.getObject() != null) && (localObjectBean.getObject() instanceof WTPart) ) {
            try {
                TypeIdentifier targetType = wt.type.TypedUtilityServiceHelper.service.getTypeIdentifier(localObjectBean.getObject());
                if (targetType.isDescendedFrom(KBUtils.kbTypeId().kbArticle())) {
                    String classification = ext.util.KBUtils.getStringIBAValue((IBAHolder)localObjectBean.getObject(), KBMAT_CLASS);
                    // in case the classification is not set need to look up the default value based on the material
                    if (KBUtils.isEmpty(classification)) {
                        String partId = ext.util.KBUtils.getStringIBAValue((IBAHolder)localObjectBean.getObject(), "KBMATERIAL");
                        String matClass = ext.util.KBUtils.getStringIBAValue((IBAHolder)PersistableHelper.findPersistable(partId.replaceAll("_", ":")), KBMAT_CLASS);
                        ext.util.KBUtils.setIba((WTPart)localObjectBean.getObject(), KBMAT_CLASS, matClass);
                    }
                }
            } catch (RemoteException e) {
                LOG.error("Failed to add Material classification value, ", e);
            } catch (WTPropertyVetoException e) {
                LOG.error("Failed to add Material classification value, ", e);
            }
        }
        return super.doOperation(paramNmCommandBean, paramList); 
     */
    
    @Test
    public void testDoOperation() throws Exception {
        KBArticleFormProcessor proc = new KBArticleFormProcessor();
        List<ObjectBean> paramList = new ArrayList<ObjectBean>();
        WTPart part = new WTPart();
        ObjectBean b = ObjectBean.newInstance();
        b.setObject(part);
        paramList.add(b);
        
        new NonStrictExpectations() {
            {
                setField(TypedUtilityServiceHelper.class, "service", serv);
                serv.getTypeIdentifier(withAny(new ObjectReference()));
                //returns(new WCTypeIdentifier("wt.part.WTPart|com.ptc.KBMechanicalPart|com.ptc.KBStandardPart"));
                returns(KBTypeIdProvider.getType("ASSYCOMP"));
            }
        };
        proc.doOperation(null, paramList);
    }

}
