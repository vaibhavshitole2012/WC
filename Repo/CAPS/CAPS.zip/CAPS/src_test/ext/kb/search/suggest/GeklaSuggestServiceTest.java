package ext.kb.search.suggest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.junit.Test;

import wt.fc.ObjectIdentifier;

import com.ptc.core.components.suggest.SuggestParms;
import com.ptc.core.components.suggest.SuggestResult;
import com.ptc.core.lwc.common.dynamicEnum.EnumerationEntryInfo;
import com.ptc.core.lwc.common.view.PropertyDefinitionReadView;
import com.ptc.core.lwc.common.view.PropertyValueReadView;

import ext.kb.dynamiclist.CatalogueContainer;
import ext.kb.dynamiclist.infoengine.InfoEngineCatalogueContainer;

public class GeklaSuggestServiceTest {
    
    GeklaSuggestService service = new GeklaSuggestService();
    
    @Test
    public void testCreateSuggestions() throws Exception {
        
        SuggestParms param = SuggestParms.valueOf("txp", 12);
        Collection<SuggestResult> suggests = service.createSuggestions(createEntries(), param);
        assertNotNull(suggests);
        assertEquals(10, suggests.size());
    }

    private List<CatalogueContainer> createEntries() throws Exception {
        List<CatalogueContainer> listEntries = new ArrayList<CatalogueContainer>();
        for (int i = 0; i < 10; i++) {
            listEntries.add(createEntry(i, Integer.toString(i)));
        }
        Collection<PropertyValueReadView> c = new ArrayList<PropertyValueReadView>();
        c.add(new PropertyValueReadView(new ObjectIdentifier("com.ptc.KBArticle:1"), new PropertyDefinitionReadView("com.ptc.KBArticle", EnumerationEntryInfo.DISPLAY_NAME, "java.lang.String"), "xp", null, null, false, null, false));
        c.add(new PropertyValueReadView(new ObjectIdentifier("com.ptc.KBArticle:2"), new PropertyDefinitionReadView("com.ptc.KBArticle", EnumerationEntryInfo.DESCRIPTION, "java.lang.String"), "xp", null, null, false, null, false));
        listEntries.add(new InfoEngineCatalogueContainer(11, "11", "xp11", "11", "11"));
        return listEntries;
    }
    
    private CatalogueContainer createEntry(int order, String name) throws Exception {
        
        InfoEngineCatalogueContainer cont = new InfoEngineCatalogueContainer(order, name, "txp"+name, name, name);
        return cont;
    }
}
