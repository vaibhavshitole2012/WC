package ext.kb.builder.data;

import static mockit.Deencapsulation.invoke;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import mockit.Mocked;
import mockit.NonStrictExpectations;

import org.junit.BeforeClass;
import org.junit.Test;

import wt.fc.ObjectReference;
import wt.fc.ReferenceFactory;
import wt.util.WTException;

import com.infoengine.object.factory.Att;
import com.infoengine.object.factory.Element;
import com.ptc.core.components.util.OidHelper;
import com.ptc.mvc.client.feedback.ClientFeedback;
import com.ptc.windchill.enterprise.search.mvc.service.SearchResultItem;
import com.ptc.windchill.enterprise.search.mvc.service.SearchService;
import com.ptc.windchill.enterprise.search.mvc.service.WindchillSearchService.SearchResultElementItem;
import com.ptc.windchill.enterprise.search.mvc.service.WindchillSearchService.WindchillSearchResultItem;
import com.ptc.windchill.enterprise.search.server.SearchCriteriaInfo;

import ext.kb.accesscontrol.PermissionController;

public class AccessControlledSearchDataBuilderTest {

    static AccessControlledSearchDataBuilder builder = new AccessControlledSearchDataBuilder();
    
    @Mocked static PermissionController permController;
    @Mocked static SearchService searchService;
    
    @BeforeClass
    public static void setup() {
        builder.setSearchService(searchService);
    }
    
    @Test
    public void testBuildRawData() {
        //fail("Not yet implemented");
    }

    @Test
    public void testGetSearchCriteria() {
        //fail("Not yet implemented");
    }

    @Test
    public void testIsTypeFoldered() {
        assertFalse((Boolean)invoke(builder, "isTypeFoldered", String.class));
        assertFalse((Boolean)invoke(builder, "isTypeFoldered", "java.lang.String"));
        assertTrue((Boolean)invoke(builder, "isTypeFoldered", "wt.facade.persistedcollection.ManagedCollection"));
        assertTrue((Boolean)invoke(builder, "isTypeFoldered", "WCTYPE|wt.part.WTPart|com.ptc.Administrative"));
        
    }

    @Test
    public void testBuildSortList() {
        //fail("Not yet implemented");
    }

    @Test
    public void testBuildRawDataAsync() {
        //fail("Not yet implemented");
    }

    @Test
    public void testSetExcludeRefs() {
        SearchCriteriaInfo info = new SearchCriteriaInfo();
        invoke(builder, "setExcludeRefs", info, Object.class);
        assertEquals(0, info.getExcludeRefs().length);
        invoke(builder, "setExcludeRefs", info, "");
        assertNull(info.getExcludeRefs());
        invoke(builder, "setExcludeRefs", info, "x1,x2,x3");
        assertEquals(3, info.getExcludeRefs().length);
        assertEquals("x2", info.getExcludeRefs()[1]);
        invoke(builder, "setExcludeRefs", info, new String [] {"i1", "i2"});
        assertEquals(2, info.getExcludeRefs().length);
        assertEquals("i2", info.getExcludeRefs()[1]);
    }
    
    @Test
    public void testCreateFeedback() {
        List<ClientFeedback> paramList = new ArrayList<ClientFeedback>();
        invoke(builder, "createFeedback", "paramString", "paramObject", paramList);
        assertEquals(1, paramList.size());
        assertEquals("paramStringparamObject", paramList.get(0).getMessage());
    }

    @Test
    public void testGetItem() throws WTException {
        SearchResultItem res = null;
        Object result = invoke(builder, "getItem", SearchResultElementItem.class);//somewhat confusing, passing in the class is counted as null argument
        assertNull(result);
        
        Element element = new Element("id", new Att("myAtt"));
        res = new SearchResultElementItem(element);
        result = invoke(builder, "getItem", res);
        assertNotNull(result);
        assertNotNull(((Element)result).getAtt("myAtt"));
        
        new NonStrictExpectations() {
            ReferenceFactory factory;
            @SuppressWarnings("unused")//need to declare here to mock object correctly
            OidHelper helper;
            {
                OidHelper.getObidFromUfid(withAny(""));
                returns("");
                factory.getReference(withAny(""));
                returns (new ObjectReference());
            }
        };
        
        res = new WindchillSearchResultItem("newId");
        result = invoke(builder, "getItem", res);
        assertNotNull(result);
        assertNotNull((ObjectReference)result);
    }

}
