package com.ptc.generic.content;


@wt.method.RemoteInterface
public interface AdvContentService extends wt.method.RemoteAccess {

    
    public void writeContentStream(wt.content.ApplicationData appdata, java.lang.String filePath)
        throws wt.util.WTException;

    
    public java.io.InputStream findContentStream(wt.content.ApplicationData appdata)
        throws wt.util.WTException;

    
    public boolean uploadContent(wt.content.ContentHolder cHolder, java.io.File file, wt.content.ContentRoleType contentRoleType)
        throws wt.util.WTException;

    
    public boolean uploadXMLDocument(wt.content.ContentHolder cHolder, org.jdom.Document doc, java.lang.String fileName, wt.content.ContentRoleType contentRoleType)
        throws wt.util.WTException, java.io.IOException;

    
    public java.lang.String getVaultFolderPath(wt.content.ContentHolder cHolder, java.lang.String fileName, wt.content.ContentRoleType contentRoleType)
        throws wt.util.WTException;

    public java.util.Vector getFileLocation(wt.content.ApplicationData applicationdata, wt.content.ContentHolder contentholder);

    public boolean uploadContent(wt.content.ContentHolder cHolder, java.lang.String fileName, java.lang.String contentCategory, java.io.InputStream inputstream, wt.content.ContentRoleType contentRoleType)
        throws wt.util.WTException;

    public boolean uploadContent(wt.content.ContentHolder cHolder, java.lang.String fileName, java.io.InputStream inputstream, wt.content.ContentRoleType contentRoleType)
        throws wt.util.WTException;

    
    public boolean checkIfPrimaryContentExists(wt.content.ContentHolder cHolder)
        throws wt.util.WTException;

    
    public void deleteContent(wt.epm.EPMDocument target, java.lang.String fileName, wt.content.ContentRoleType contentRoleType)
        throws wt.util.WTException;

    
    public java.lang.String getDownloadUrlForContent(wt.epm.EPMDocument pbo, java.lang.String filename, wt.content.ContentRoleType contentRoleType);

    public java.lang.String getSaveAsURL(java.lang.String coid, java.lang.String fileName, java.lang.String fileType)
        throws wt.util.WTException;

}
