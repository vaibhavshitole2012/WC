package com.ptc.generic.workinprogress;


@wt.method.RemoteInterface
public interface WIPService extends wt.method.RemoteAccess {

    
    public java.util.HashMap getWorkingCopies(java.util.Vector oids)
        throws wt.util.WTException;

    
    public java.util.HashMap getOrigCopies(java.util.Vector oids, java.lang.Class cClassType, int mode)
        throws wt.util.WTException;

    
    public java.lang.String getOrigCopyOid(java.lang.String oid);

    
    public wt.fc.Persistable getWorkingCopy(wt.vc.wip.Workable w, boolean bCheckOutIfNecessary, java.lang.String note)
        throws wt.util.WTException;

    
    public wt.fc.Persistable checkOut(wt.vc.wip.Workable w, java.lang.String note)
        throws wt.util.WTException;

    
    public wt.fc.Persistable checkIn(wt.vc.wip.Workable w, java.lang.String note)
        throws wt.util.WTException;

    
    public wt.fc.Persistable undoCheckOut(wt.vc.wip.Workable w)
        throws wt.util.WTException;

    
    public wt.vc.Iterated getMyLatestIteration(wt.vc.Iterated w)
        throws wt.util.WTException;

}
