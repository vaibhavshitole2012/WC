package com.ptc.generic.workinprogress;

import wt.util.resource.*;

@RBUUID("com.ptc.generic.workinprogress.workinprogressResource")
public final class workinprogressResource extends WTListResourceBundle {
   /**
    * 
    * Copyright (c) 2001 - 2006 Parametric Technology Corporation (PTC). All Rights Reserved.
    * 
    * This software is the confidential and proprietary information of PTC.
    * You shall not disclose such confidential information and shall use it
    * only in accordance with the terms of the license agreement.
    * 
    * English
    **/
   @RBEntry("Checkout failed.")
   public static final String CHECKOUT_FAILED = "CHECKOUT_FAILED";

   @RBEntry("No Vector with oids of original copies was given to WIPHelper.service.workingCopiesOf().")
   public static final String NO_ORIGCOPIES_GIVEN = "NO_ORIGCOPIES_GIVEN";

   @RBEntry("Object is checked out and there it can not be checked out again.")
   public static final String OBJECT_IS_CHECKEDOUT_NOCHECKOUT = "OBJECT_IS_CHECKEDOUT_NOCHECKOUT";

   @RBEntry("Object is not a working copy and can not be checked out. ")
   public static final String OBJECT_IS_NO_WORKINGCOPY_NOCHECKIN = "OBJECT_IS_NO_WORKINGCOPY_NOCHECKIN";

   @RBEntry("Object is not a working copy and therefore the check out action can not be revoked. ")
   public static final String OBJECT_IS_NO_WORKINGCOPY_NO_UNDOCHECKOUT = "OBJECT_IS_NO_WORKINGCOPY_NO_UNDOCHECKOUT";

   @RBEntry("Object is already a working copy und therefore it can not be checked out.")
   public static final String OBJECT_IS_WORKINGCOPY_NOCHECKOUT = "OBJECT_IS_WORKINGCOPY_NOCHECKOUT";
}
