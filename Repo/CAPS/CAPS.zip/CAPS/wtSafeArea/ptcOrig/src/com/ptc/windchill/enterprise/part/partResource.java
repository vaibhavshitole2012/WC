/* bcwti
 *
 * Copyright (c) 2010 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */
package com.ptc.windchill.enterprise.part;

import wt.util.resource.RBArgComment0;
import wt.util.resource.RBArgComment1;
import wt.util.resource.RBArgComment2;
import wt.util.resource.RBComment;
import wt.util.resource.RBEntry;
import wt.util.resource.RBPseudo;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("com.ptc.windchill.enterprise.part.partResource")
public final class partResource extends WTListResourceBundle {
   @RBEntry("Name")
   @RBComment("This string is used for the name label in the jsp page")
   public static final String NAME_COLUMN_LABEL = "0";

   @RBEntry("Number")
   @RBComment("This string is used for the number label in the jsp page")
   public static final String NUMBER_COLUMN_LABEL = "1";

   @RBEntry("Organization")
   @RBComment("This string is used for the Organization label in the jsp page")
   public static final String ORGANIZATION_COLUMN_LABEL = "2";

   @RBEntry("Context")
   @RBComment("This string is used for thecontainer column label in the jsp page")
   public static final String CONTEXT_COLUMN_LABEL = "3";

   @RBEntry("Two-Way")
   @RBComment("This string is used for the twoway label in the jsp page")
   public static final String TWOWAY_COLUMN_LABEL = "4";

   @RBEntry("Alternates")
   @RBComment("This string is used for the Alternates table label in the jsp page")
   public static final String ALTERNATES_TABLE_LABEL = "ALTERNATES_TABLE_LABEL";

   @RBEntry("Substitutes")
   @RBComment("This string is used for the Substitutes table label in the jsp page")
   public static final String SUBSTITUTES_TABLE_LABEL = "SUBSTITUTES_TABLE_LABEL";

   @RBEntry("Alternate For")
   @RBComment("This string is used for the \"Alternate For\" table title. Probably should match the \"part.alternates.description\"")
   public static final String ALTERNATESFOR_LABEL = "5";

   @RBEntry("Substitute For")
   @RBComment("This string is used for the Substitutes label in the jsp page")
   public static final String SUBSTITUTESFOR_LABEL = "6";

   @RBEntry("Replacements")
   @RBComment("This string is used for the Alternates and Substitutes label in the jsp page")
   public static final String ALTERNATES_SUBSTITUTES_LABEL = "9";

   @RBEntry("Specify Replacements for")
   @RBComment("This string is used for the Alternates and Substitutes label in the jsp wizard page")
   public static final String SPECIFY_ALTERNATES_SUBSTITUTES_LABEL = "10";

   @RBEntry("in")
   @RBComment("This string is used for the Alternates and Substitutes label in the jsp wizard page")
   public static final String SPECIFY_IN_LABEL = "11";

   @RBEntry("Remove")
   @RBComment("Used to remove alternates and subtitutes")
   public static final String PRIVATE_CONSTANT_0 = "part.remove_alternates_substitutes.description";

   @RBEntry("Remove Selected")
   @RBComment("Tooltip for icon to remove alternates and substitutes")
   public static final String PRIVATE_CONSTANT_1 = "part.remove_alternates_substitutes.tooltip";

   @RBEntry("remove16x16.gif")
   @RBComment("Icon to remove alternates and substitutes")
   public static final String PRIVATE_CONSTANT_2 = "part.remove_alternates_substitutes.icon";

   @RBEntry("Assembly Number")
   @RBComment("This string is used for the assembly number label in the jsp page")
   public static final String ASSEMBLY_NUMBER_COLUMN_LABEL = "12";

   @RBEntry("Assembly Name")
   @RBComment("This string is used for the assembly name label in the jsp page")
   public static final String ASSEMBLY_NAME_COLUMN_LABEL = "13";

   @RBEntry("Assembly Organization")
   @RBComment("This string is used for the assembly organization label in the jsp page")
   public static final String ASSEMBLY_ORG_COLUMN_LABEL = "14";

   @RBEntry("Actions")
   @RBComment("This string is used for the action label in the jsp page")
   public static final String ACTIONS_COLUMN_LABEL = "15";

   @RBEntry("Find Alternate Part")
   @RBComment("This string is used for the header in the search picker")
   public static final String ADD_ALTERNATE_PART_HEADER = "18";

   @RBEntry("Find Substitute Part")
   @RBComment("This string is used for the header in the search picker")
   public static final String ADD_SUBSTITUTE_PART_HEADER = "19";

   @RBEntry("Part Version")
   @RBComment("This string is used for the column header for part version")
   public static final String PART_VERSION_COLUMN_LABEL = "20";

   @RBEntry("State")
   @RBComment("This string is used for the column header for state.state")
   public static final String STATE_COLUMN_LABEL = "21";

   @RBEntry("Primary Member Number")
   @RBComment("his string is used for the column header for primary member object number")
   public static final String PRIMARY_MEMBER_NUMBER_COLUMN_LABEL = "22";

   @RBEntry("Mode")
   @RBComment("his string is used for the column header for mode")
   public static final String MODE_COLUMN_LABEL = "23";

   @RBEntry("Last Modified")
   @RBComment("his string is used for the column header for Last Modified")
   public static final String LAST_UPDATED_COLUMN_LABEL = "24";

   @RBEntry("Baselines")
   @RBComment("his string is used for the related baseline table name")
   public static final String RELATED_BASELINE_TABLE_LABEL = "25";

   @RBEntry("Quantity")
   @RBComment("Quantity column")
   public static final String QUANTITY = "26";

   @RBEntry("Units")
   @RBComment("Units column")
   public static final String UNITS = "27";

   @RBEntry("Child Parts")
   @RBComment("Name of the tabular input table")
   public static final String TABLE_NAME_TABULAR_INPUT = "28";

   @RBEntry("Find Number")
   @RBComment("Item Find Number Column")
   public static final String ITEM_FIND_NUMBER = "29";

   @RBEntry("Line Number")
   @RBComment("Line Number Column")
   public static final String LINE_NUMBER = "30";

   @RBEntry("Trace Code")
   @RBComment("Trace Code Column")
   public static final String TRACE_CODE = "31";

   @RBEntry("BOM Note")
   @RBComment("BOM Note Column")
   public static final String BOM_NOTE = "32";

   @RBEntry("You do not have permission to modify part {0}")
   public static final String NO_MODIFY_PERMISSION = "33";

   @RBEntry("Adding a child to a part master from another container is not allowed.")
   @RBComment("Message that displays when a user trys to add a child to part master that lives in another container.")
   public static final String ADDING_TO_MASTER_NOT_ALLOWED = "34";

   @RBEntry("Object is checked out by a different user.")
   public static final String OBJECT_CHECKED_OUT = "35";

   @RBEntry("Adding a part from a different container to a product structure is not allowed, unless the part is shared.")
   public static final String DIFFERING_CONTAINERS_OP_NOT_ALLOWED = "36";

   @RBEntry("Added uses relationship to: {0}")
   public static final String ADDED_USES = "37";

   @RBEntry("No Parts are currently found to remove")
   public static final String NO_PARTS_TO_REMOVE = "38";

   @RBEntry("Removed uses relationship to: {0}")
   public static final String REMOVED_USES = "39";

   @RBEntry("Error: you need to enter values for fields with asterisks by their names.")
   @RBComment("Message that appears when user tries to leave a page without filling in a required (asterisked) field.")
   public static final String MISSING_REQUIRED_FIELD = "48";

   @RBEntry("An error occurred while editing common attributes of the object.")
   @RBComment("This string is used in case of error while editing common attributes of the object.")
   public static final String EDIT_COMMON_ATTRS_ERROR = "49";

   @RBEntry("Stop Effectivity Propagation")
   @RBComment("Stop Effectivity Propagation Column")
   public static final String STOP_EFFECTIVITY_PROPAGATION = "50";

   @RBEntry("Collapsible")
   @RBComment("This is a label for Collapsible column")
   public static final String COLLAPSIBLE = "51";

   @RBEntry("All")
   @RBComment("This string is used for the Replacemant Table for all view in the jsp page")
   public static final String ALL_VIEW = "52";

   @RBEntry("Search by Number:")
   @RBComment("This is a string used for Quick Search Filed label")
   public static final String QUICK_SEARCH_LABEL = "53";

   @RBEntry("10")
   @RBComment("This is a max search results shown in autosuggest")
   public static final String MAX_SEARCH_RESULTS = "54";

   @RBEntry("Reference Designator")
   @RBComment("Reference Designator Column")
   public static final String REFERENCE_DESIGNATOR = "55";

   @RBEntry("All Versions (Member)")
   @RBComment("View that shows all it's verson iterations are member of")
   public static final String ALL_VERSION_MEMBER = "56";

   @RBEntry("Revision (Member)")
   @RBComment("View that shows all it's revisions are member of")
   public static final String REVISION_MEMBER = "57";

   @RBEntry("Version (Member)")
   @RBComment("View that shows all it's iterations are member of")
   public static final String VERSION_MEMBER = "58";

   @RBEntry("All Versions (Primary)")
   @RBComment("View that shows all it's verson iterations are top object (context) of")
   public static final String ALL_VERSION_TOP = "59";

   @RBEntry("Revision (Primary)")
   @RBComment("View that shows all it's revisions are top object (context) of")
   public static final String REVISION_TOP = "60";

   @RBEntry("Versions (Primary)")
   @RBComment("View that shows all it's iteration is top object (context) of")
   public static final String VERSION_TOP = "61";

   @RBEntry("Assembly Version")
   @RBComment("This string is used for the assembly Version column label in the jsp page")
   public static final String ASSEMBLY_VERSION_COLUMN_LABEL = "62";

   @RBEntry("Classification")
   @RBComment("Label for the Classification")
   public static final String CLASSIFICATION_LABEL = "63";

   @RBEntry("Location")
   @RBComment("Label for the Location")
   public static final String LOCATION_LABEL = "64";

   @RBEntry("Manufacturer ID")
   @RBComment("Label for the Manufacturer ID")
   public static final String MANUFACTURERID_LABEL = "65";

   @RBEntry("Vendor ID")
   @RBComment("Label for the Vendor ID")
   public static final String VENDORID_LABEL = "66";

   @RBEntry("Can not set Quantity = 0 for unit of measurement other than 'each'")
   @RBComment("Error message for quantity 0 and unit other than each")
   public static final String QUANTITY_VALIDATION_FOR_UNIT = "68";

   @RBEntry("Type")
   @RBComment("Label for the Part Type. For e.g. for a part of type wt.part.WTPart, it is 'Part'")
   public static final String TYPE_NAME_LABEL = "70";

   @RBEntry("Replacement Type")
   @RBComment("Label for the Replacement Type")
   public static final String REPLACEMENT_TYPE_LABEL = "71";

   @RBEntry("*Name")
   @RBComment("This string is used for the name required label in the jsp page")
   public static final String NAME_R_COLUMN_LABEL = "72";

   @RBEntry("*Number")
   @RBComment("This string is used for the number required label in the jsp page")
   public static final String NUMBER_R_COLUMN_LABEL = "73";

   @RBEntry("'{0}' has been checked out.")
   @RBComment("This string is used for inform user that the part has been checkout when invoked from tabular input.")
   @RBArgComment0("item id of the checked out part")
   public static final String PART_CHECKED_OUT = "74";

   @RBEntry("Last Modified")
   @RBComment("This string is used for the column header for last modified")
   public static final String LAST_MODIFIED_COLUMN_LABEL = "75";

   @RBEntry("Error: unable to assign view for the part. All versions of the part do not belong to the same view.")
   @RBComment("Message that appears when user tries to launch Assign View action and the part has versions with different views.")
   public static final String ASSIGN_VIEW_ERROR = "76";

   @RBEntry("Created")
   @RBComment("This string is used for the column header for created column")
   public static final String CREATED_LABEL = "77";

   @RBEntry("Modified By")
   @RBComment("This string is used for the column header for modified by column")
   public static final String MODIFIEDBY_LABEL = "78";

   @RBEntry("Manufacturer")
   @RBComment("This string is used as a label for Manufacturer column in part info page")
   public static final String MFG_LABEL = "79";

   @RBEntry("Vendor")
   @RBComment("This string is used as a label for Vendor column in part info page")
   public static final String VENDOR_LABEL = "80";

   @RBEntry("Parts")
   @RBComment("Name of the multi part identity attributes table")
   public static final String TABLE_NAME_MULTI_PART_IDENTITY = "81";

   @RBEntry("Quantity should be numeric, and greater than or equal to zero.\n\n\t{0}")
   @RBComment("Error message if the quantity entered is zero or less than zero. Arguments identifies the part identity (number, org) for which the error occurred.")
   public static final String QUANTITY_VALIDATION = "82";

   @RBEntry("Line Number should be positive numeric value and less than 10 digits.\n\n\t{0}.")
   @RBComment("Error message if the line number entered is alphanumeric. Arguments identifies the part identity (number, org) for which the error occurred.")
   public static final String LINE_NUMBER_VALIDATION = "83";

   @RBEntry("Cannot decrease the quantity as occurrences exist with valid reference designators. Please adjust the reference designators first.")
   @RBComment("Message for quantity validation.")
   public static final String QUANTITY_VALIDATION_MSG = "84";

   @RBEntry("CONFIRM: Adjust Quantity?\n\nThe reference designator count specified {0} is more than the current quantity {1}, maximum quantity limit is {2}.\n\n Do you want to adjust the quantity to match the count of reference designators?\n\nClick OK to change the quantity or click Cancel to undo the reference designator changes.")
   @RBComment("Message for reference designator validation.")
   public static final String REFDESIGNATOR_MORE_VALIDATION_MSG = "85";

   @RBEntry("Some objects on the clipboard are not parts")
   @RBComment("Message for validationg paste action.")
   public static final String INVALID_PASTE_TYPE_ERRMSG = "86";

   @RBEntry("There are no objects on the clipboard to paste")
   @RBComment("Message for validationg paste action.")
   public static final String NULLOBJ_PASTE_ERRMSG = "87";

   @RBEntry("Object(s) created successfully")
   @RBComment("This string is used as the success message for multi-part create wizard.")
   public static final String MULTI_PART_CREATE_SUCCESSFUL_MSG = "88";

   @RBEntry("ATTENTION: Required Information Is Missing \n\n One or more required fields of \"{0}\" are empty.\nEnter information for all fields indicated by an asterisk (*).")
   @RBComment("Message that appears when user tries to launch Assign View action and the part has versions with different views.")
   public static final String CREATE_MULTI_PART_NAME_NUMBER_VALIDATION_ERROR = "89";

   @RBEntry("The Life Cycle and Team template could not be determined based on the object initialization rules. Either no entries are defined for the template or no valid templates could be found based on the object initialization rule entries.")
   @RBComment("Message for validating lifecycle and team template.")
   public static final String INVALID_TEMPLATES = "90";

   @RBEntry("The Life Cycle template could not be determined based on the object initialization rules. Either no entries are defined for the template or no valid templates could be found based on the object initialization rule entries.")
   @RBComment("Message for validating lifecycle template.")
   public static final String INVALID_LIFECYCLE_TEMPLATE = "91";

   @RBEntry("The Team template could not be determined based on the object initialization rules. Either no entries are defined for the template or no valid templates could be found based on the object initialization rule entries.")
   @RBComment("Message for validating team template.")
   public static final String INVALID_TEAM_TEMPLATE = "92";

   @RBEntry("Quantity must be a positive integer value when the unit is 'each'.\n\n{0}")
   @RBComment("Error message for quantity when unit is each. Arguments identifies the part (number, org) for which the error occurred.")
   public static final String QUANTITY_VALIDATION_FOR_EACH_UNIT = "93";

   @RBEntry("The value \"{0}\" for Find Number must be unique within a subassembly")
   @RBComment("Error message")
   public static final String FIND_NUMBER_NOT_UNIQUE = "94";

   @RBEntry("The value \"{0}\" for Line Number must be unique within a subassembly")
   @RBComment("Error message")
   public static final String LINE_NUMBER_NOT_UNIQUE = "95";

   @RBEntry("The value \"{0}\" for Reference Designator must be unique within a subassembly")
   @RBComment("Error message")
   public static final String REF_DESIG_NOT_UNIQUE = "96";

   @RBEntry("The value \"{0}\" for reference designator is not valid. The characters '{1}' and '{2}' are reserved and cannot be used as a part of the reference designator.")
   @RBComment("Error message")
   public static final String REF_DESIG_INVALID = "97";

   @RBEntry("CONFIRM: Adjust Quantity?\n\nThe reference designator count specified {0} is less than the current quantity {1}, maximum quantity limit is {2}.\n\n Do you want to adjust the quantity to match the count of reference designators?\n\nClick OK to change the quantity or click Cancel to undo the reference designator changes.")
   @RBComment("Message for reference designator validation.")
   public static final String REFDESIGNATOR_LESS_VALIDATION_MSG = "98";

   @RBEntry("New Parts")
   @RBComment("Name of the multi part attributes table")
   public static final String TABLE_NAME_MULTI_PART = "99";

   @RBEntry("*Assembly Mode")
   @RBComment("This string is used for the assembly mode required label in the jsp page")
   public static final String TYPE_R_COLUMN_LABEL = "100";

   @RBEntry("*Default Trace Code")
   @RBComment("This string is used for the trace code required label in the jsp page")
   public static final String TRACE_CODE_R_COLUMN_LABEL = "101";

   @RBEntry("Default Trace Code")
   @RBComment("This string is used for the trace code label in jsp pages. Note that it does not have * in the label")
   public static final String TRACE_CODE_COLUMN_LABEL = "TRACE_CODE_COLUMN_LABEL";

   @RBEntry("*Default Units")
   @RBComment("This string is used for the default units required label in the jsp page")
   public static final String UNITS_R_COLUMN_LABEL = "102";

   @RBEntry("*Gathering Part")
   @RBComment("This string is used for the Gathering Part required label in the jsp page")
   public static final String GATHERING_PART = "GATHERING_PART";

   @RBEntry("*Life Cycle Template")
   @RBComment("This string is used for the lifecycle template required label in the jsp page")
   public static final String LIFECYCLE_TEMPLATE_R_COLUMN_LABEL = "103";

   @RBEntry("*Location")
   @RBComment("This string is used for the location required label in the jsp page")
   public static final String LOCATION_R_COLUMN_LABEL = "104";

   @RBEntry("*Source")
   @RBComment("This string is used for the source required label in the jsp page")
   public static final String SOURCE_COLUMN_LABEL = "105";

   @RBEntry("Select only parts or only documents.")
   @RBComment("Error message displayed when invalid objects are selected for edit multi action")
   public static final String SELECT_VALID_TYPES = "106";

   @RBEntry("Cannot add \"{0}\" to itself in a structure")
   @RBComment("Error message")
   public static final String PART_REFLEXIVE_LINK = "107";

   @RBEntry("Find Part")
   @RBComment("This string is used for the Find Part title in Item Picker")
   public static final String FIND_PART = "FIND_PART";

   @RBEntry("Process Plans")
   @RBComment("Used in the 3rd level nav bar under 'Related items' and as the table title")
   public static final String PRIVATE_CONSTANT_3 = "part.relatedMPMProcessPlans.description";

   /**
    * Column headers for the related MPM Process Plans table (3rd level nav)
    **/
   @RBEntry("Version")
   public static final String PRIVATE_CONSTANT_4 = "part.relatedMPMProcessPlans.VERSION";

   @RBEntry("Context")
   public static final String PRIVATE_CONSTANT_5 = "part.relatedMPMProcessPlans.CONTEXT";

   @RBEntry("State")
   public static final String PRIVATE_CONSTANT_6 = "part.relatedMPMProcessPlans.STATE";

   @RBEntry("Team")
   public static final String PRIVATE_CONSTANT_7 = "part.relatedMPMProcessPlans.TEAM";

   @RBEntry("Last Modified")
   public static final String PRIVATE_CONSTANT_8 = "part.relatedMPMProcessPlans.LAST_UPDATED";

   /**
    * Part Info, Actions dropdown, New View Version action
    **/
   @RBEntry("New View Version")
   @RBComment("Used as a label for new view version action popup")
   public static final String PRIVATE_CONSTANT_9 = "part.newViewVersion.title";

   @RBEntry("New View Version")
   @RBComment("Used in the action list for part details page")
   public static final String PRIVATE_CONSTANT_10 = "part.newViewVersion.description";

   @RBEntry("Create a new view version for the part")
   @RBComment("Used as tooltip for new view version action")
   public static final String PRIVATE_CONSTANT_11 = "part.newViewVersion.tooltip";

   @RBEntry("height=240,width=600")
   @RBPseudo(false)
   @RBComment("DO NOT TRANSLATE")
   public static final String PRIVATE_CONSTANT_12 = "part.newViewVersion.moreurlinfo";

   @RBEntry("version_view_create.gif")
   @RBPseudo(false)
   @RBComment("Icon that appears in the page info page action drop down list")
   public static final String PRIVATE_CONSTANT_13 = "part.newViewVersion.icon";

   @RBEntry("An unexpected failure occurred. Please see log for details.")
   @RBComment("This text is used as a part of an exception (that should never occur).")
   public static final String PRIVATE_CONSTANT_14 = "part.newViewVersion.UNEXPECTED_FAILURE";

   @RBEntry("Select View")
   @RBComment("Used as a label for new view version wizard step")
   public static final String PRIVATE_CONSTANT_15 = "part.newViewVersion_step.description";

   @RBEntry("Select a view that must be assigned to the new version of the part")
   @RBComment("Used for tooltip in the new view version wizard step")
   public static final String PRIVATE_CONSTANT_16 = "part.newViewVersion_step.tooltip";

   @RBEntry("Select View")
   @RBComment("Text used in the niew view version wizard step")
   public static final String PRIVATE_CONSTANT_17 = "part.newViewVersion_step.SELECT_VIEW";

   /**
    * Part Info, Actions dropdown, One Off Version action
    **/
   @RBEntry("New One Off Version")
   @RBComment("Used as a label for New One Off Version action popup")
   public static final String PRIVATE_CONSTANT_18 = "part.oneOffVersion.title";

   @RBEntry("New One Off Version")
   @RBComment("Used in the action list for part details page")
   public static final String PRIVATE_CONSTANT_19 = "part.oneOffVersion.description";

   @RBEntry("Create a New One Off Version for the part")
   @RBComment("Used as tooltip for New One Off Version action")
   public static final String PRIVATE_CONSTANT_20 = "part.oneOffVersion.tooltip";

   @RBEntry("height=240,width=600")
   @RBPseudo(false)
   @RBComment("DO NOT TRANSLATE")
   public static final String PRIVATE_CONSTANT_21 = "part.oneOffVersion.moreurlinfo";

   @RBEntry("one_off_view.gif")
   @RBPseudo(false)
   @RBComment("Icon that appears in the page info page action drop down list")
   public static final String PRIVATE_CONSTANT_22 = "part.oneOffVersion.icon";

   @RBEntry("New One Off Version")
   @RBComment("Used as a label for New One Off Version wizard step")
   public static final String PRIVATE_CONSTANT_23 = "part.oneOffVersion_step.description";

   @RBEntry("New One Off Version")
   @RBComment("Used for tooltip in the New One Off Version wizard step")
   public static final String PRIVATE_CONSTANT_24 = "part.oneOffVersion_step.tooltip";

   /**
    * Create Part Wizard action
    **/
   @RBEntry("New Part")
   @RBComment("Used as the label for the New Part Wizard")
   public static final String PRIVATE_CONSTANT_25 = "part.createPartWizard.description";

   @RBEntry("New Part")
   @RBComment("Used as the label for the New Part Wizard")
   public static final String PRIVATE_CONSTANT_26 = "part.createPartWizard.title";

   @RBEntry("New Part")
   @RBComment("Used as the tooltip for the New Part Wizard")
   public static final String PRIVATE_CONSTANT_27 = "part.createPartWizard.tooltip";

   @RBEntry("height=750,width=650")
   @RBPseudo(false)
   @RBComment("DO NOT TRANSLATE")
   public static final String PRIVATE_CONSTANT_28 = "part.createPartWizard.moreurlinfo";

   @RBEntry("newpart.gif")
   @RBPseudo(false)
   @RBComment("Icon that appears in toolbars for creating a new part")
   public static final String PRIVATE_CONSTANT_29 = "part.createPartWizard.icon";

   /**
    * Create Part Wizard labels
    **/
   @RBEntry("Define Part")
   @RBComment("Label for define item step in the Create Part Wizard")
   public static final String PRIVATE_CONSTANT_35 = "part.createPartWizard.DEFINE_ITEM_WIZ_STEP_LABEL";

   @RBEntry("Set Identity Attributes")
   @RBComment(" Label for Set Identity Attributes step in Create Multiple Part wizard")
   public static final String PRIVATE_CONSTANT_36 = "part.createPartWizard.SET_IDENTITY_ATTRIBUTES_WIZ_STEP_LABEL";

   @RBEntry("Set Attributes")
   @RBComment("Label for set attributes step in the Create Part Wizard")
   public static final String PRIVATE_CONSTANT_37 = "part.createPartWizard.SET_ATTRIBUTES_WIZ_STEP_LABEL";

   @RBEntry("Set Additional Attributes")
   @RBComment("Label for set attributes step in the Create Multiple Part Wizard")
   public static final String PRIVATE_CONSTANT_38 = "part.createPartWizard.SET_ATTRIBUTES_WIZ_STEP_MULTI_CREATE_LABEL";

   @RBEntry("Access Control")
   @RBComment("Label for access control step in the Create Part Wizard")
   public static final String PRIVATE_CONSTANT_40 = "part.createPartWizard.ACCESS_CONTROL_WIZ_STEP_LABEL";

   @RBEntry("Create as End Item")
   @RBComment("Used as label for define item step in the Create Part Wizard")
   public static final String PRIVATE_CONSTANT_41 = "part.createPartDefineItemWizStep.END_ITEM";

   @RBEntry("New CAD Document")
   @RBComment("Label for New CAD Document step in the Create Part Wizard")
   public static final String PRIVATE_CONSTANT_42 = "part.createPartWizard.NEW_CAD_DOC_WIZ_STEP_LABEL";

   @RBEntry("Assign Item Choices")
   @RBComment("Used as label for assign item choices in the Create Part Wizard")
   public static final String PRIVATE_CONSTANT_43 = "part.createPartWizard.EDIT_ITEM_OPTION_RULES_WIZ_STEP_LABEL";

   /**
    * Create Part Wizard action resources when create part is invoked from a workspace
    * These labels should be the same as Create Part Wizard action above
    **/
   @RBEntry("New Part")
   @RBComment("Should be same as part.createPartWizard")
   public static final String PRIVATE_CONSTANT_44 = "part.createPartFromWorkspace.description";

   @RBEntry("New Part")
   @RBComment("Should be same as part.createPartWizard")
   public static final String PRIVATE_CONSTANT_45 = "part.createPartFromWorkspace.title";

   @RBEntry("New Part")
   @RBComment("Should be same as part.createPartWizard")
   public static final String PRIVATE_CONSTANT_46 = "part.createPartFromWorkspace.tooltip";

   @RBEntry("height=750,width=650")
   @RBPseudo(false)
   @RBComment("Should be same as part.createPartWizard")
   public static final String PRIVATE_CONSTANT_47 = "part.createPartFromWorkspace.moreurlinfo";

   @RBEntry("newpart.gif")
   @RBPseudo(false)
   @RBComment("Icon that appears in toolbars for new part action")
   public static final String PRIVATE_CONSTANT_48 = "part.createPartFromWorkspace.icon";

   /**
    * Edit Part Wizard action
    **/
   @RBEntry("Edit")
   @RBComment("Used as the label for the edit action for a part")
   public static final String PRIVATE_CONSTANT_49 = "part.edit.description";

   @RBEntry("Edit Part")
   @RBComment("Used as the label for the edit action for a part")
   public static final String PRIVATE_CONSTANT_50 = "part.edit.title";

   @RBEntry("Edit Part")
   @RBComment("Used as the tooltip for the edit action for a part")
   public static final String PRIVATE_CONSTANT_51 = "part.edit.tooltip";

   @RBEntry("multi_update.gif")
   @RBPseudo(false)
   @RBComment("Icon for the edit part action (for toolbars)")
   public static final String PRIVATE_CONSTANT_52 = "part.edit.icon";

   @RBEntry("height=500,width=600")
   @RBPseudo(false)
   @RBComment("DO NOT TRANSLATE")
   public static final String PRIVATE_CONSTANT_53 = "part.edit.moreurlinfo";

   @RBEntry("Edit")
   @RBComment("Used as the label for the edit action for a part")
   public static final String PRIVATE_CONSTANT_54 = "part.editFromAttributesTable.description";

   @RBEntry("Edit Part")
   @RBComment("Used as the label for the edit action for a part")
   public static final String PRIVATE_CONSTANT_55 = "part.editFromAttributesTable.title";

   @RBEntry("Edit Part")
   @RBComment("Used as the tooltip for the edit action for a part")
   public static final String PRIVATE_CONSTANT_56 = "part.editFromAttributesTable.tooltip";

   @RBEntry("multi_update.gif")
   @RBPseudo(false)
   @RBComment("Icon for the edit part action (for toolbars)")
   public static final String PRIVATE_CONSTANT_57 = "part.editFromAttributesTable.icon";

   @RBEntry("height=500,width=600")
   @RBPseudo(false)
   @RBComment("DO NOT TRANSLATE")
   public static final String PRIVATE_CONSTANT_58 = "part.editFromAttributesTable.moreurlinfo";

   @RBEntry("Check Out and Edit")
   @RBComment("Used as the label for the Check Out and Edit action for a part")
   public static final String PRIVATE_CONSTANT_59 = "part.checkoutAndEditFromAttributesTable.description";

   @RBEntry("Edit Part")
   @RBComment("Used as the label for the Check Out and Edit action for a part")
   public static final String PRIVATE_CONSTANT_60 = "part.checkoutAndEditFromAttributesTable.title";

   @RBEntry("Check Out and Edit Part")
   @RBComment("Used as the tooltip for the Check Out and Edit action for a part")
   public static final String PRIVATE_CONSTANT_61 = "part.checkoutAndEditFromAttributesTable.tooltip";

   @RBEntry("multi_update.gif")
   @RBPseudo(false)
   @RBComment("Icon for the checkout and edit part action (for toolbars)")
   public static final String PRIVATE_CONSTANT_62 = "part.checkoutAndEditFromAttributesTable.icon";

   @RBEntry("height=500,width=600")
   @RBPseudo(false)
   @RBComment("DO NOT TRANSLATE")
   public static final String PRIVATE_CONSTANT_63 = "part.checkoutAndEditFromAttributesTable.moreurlinfo";

   @RBEntry("Check Out and Edit")
   @RBComment("Used as the label for the Check Out and Edit action for a part")
   public static final String PRIVATE_CONSTANT_64 = "part.checkoutAndEdit.description";

   @RBEntry("Edit Part")
   @RBComment("Used as the label for the Check Out and Edit action for a part")
   public static final String PRIVATE_CONSTANT_65 = "part.checkoutAndEdit.title";

   @RBEntry("Check Out and Edit Part")
   @RBComment("Used as the tooltip for the Check Out and Edit action for a part")
   public static final String PRIVATE_CONSTANT_66 = "part.checkoutAndEdit.tooltip";

   @RBEntry("multi_update.gif")
   @RBPseudo(false)
   @RBComment("Icon for the checkout and edit part action (for toolbars)")
   public static final String PRIVATE_CONSTANT_67 = "part.checkoutAndEdit.icon";

   @RBEntry("height=500,width=600")
   @RBPseudo(false)
   @RBComment("DO NOT TRANSLATE")
   public static final String PRIVATE_CONSTANT_68 = "part.checkoutAndEdit.moreurlinfo";

   @RBEntry("Edit")
   @RBComment("Used as the label for the edit action for a new part in workspace")
   public static final String PRIVATE_CONSTANT_69 = "part.editNewPartInWorkspace.description";

   @RBEntry("Edit Part")
   @RBComment("Used as the label for the edit action for a new part in workspace")
   public static final String PRIVATE_CONSTANT_70 = "part.editNewPartInWorkspace.title";

   @RBEntry("Edit Part")
   @RBComment("Used as the tooltip for the edit action for a new part in workspace")
   public static final String PRIVATE_CONSTANT_71 = "part.editNewPartInWorkspace.tooltip";

   @RBEntry("multi_update.gif")
   @RBPseudo(false)
   @RBComment("Icon for the edit part action (for toolbars)")
   public static final String PRIVATE_CONSTANT_72 = "part.editNewPartInWorkspace.icon";

   @RBEntry("height=500,width=600")
   @RBPseudo(false)
   @RBComment("DO NOT TRANSLATE")
   public static final String PRIVATE_CONSTANT_73 = "part.editNewPartInWorkspace.moreurlinfo";

   @RBEntry("Edit")
   @RBComment("Used as the label for the edit action for a part checked out in workspace")
   public static final String PRIVATE_CONSTANT_74 = "part.editCheckedOutPartInWorkspace.description";

   @RBEntry("Edit Part")
   @RBComment("Used as the label for the edit action for a new part in workspace")
   public static final String PRIVATE_CONSTANT_75 = "part.editCheckedOutPartInWorkspace.title";

   @RBEntry("Edit Part")
   @RBComment("Used as the tooltip for the edit action for a new part in workspace")
   public static final String PRIVATE_CONSTANT_76 = "part.editCheckedOutPartInWorkspace.tooltip";

   @RBEntry("multi_update.gif")
   @RBPseudo(false)
   @RBComment("Icon for the edit part action (for toolbars)")
   public static final String PRIVATE_CONSTANT_77 = "part.editCheckedOutPartInWorkspace.icon";

   @RBEntry("height=500,width=600")
   @RBPseudo(false)
   @RBComment("DO NOT TRANSLATE")
   public static final String PRIVATE_CONSTANT_78 = "part.editCheckedOutPartInWorkspace.moreurlinfo";

   /**
    * General Related Documents, CAD Docs from Part Details page
    **/
   @RBEntry("Described By Documents")
   @RBComment("Related Items 3rd level nav Part Info page Documents")
   public static final String PRIVATE_CONSTANT_79 = "part.relatedPartsDocuments.description";

   @RBEntry("Reference Documents")
   @RBComment("Related Items 3rd level nav Part Info page Documents")
   public static final String PRIVATE_CONSTANT_80 = "part.relatedPartsReferences.description";

   @RBEntry("CAD/Dynamic Documents")
   @RBComment("Related Items 3rd level nav Part Info page CAD Documents")
   public static final String PRIVATE_CONSTANT_81 = "part.relatedPartsCADDocuments.description";

   @RBEntry("CAD Documents")
   @RBComment("Related Items 3rd level nav CAD Doc Info page CAD Documents")
   public static final String PRIVATE_CONSTANT_82 = "part.relatedCADDocsCADDocuments.description";

   @RBEntry("Parts")
   @RBComment("Related Items 3rd level nav CAD Doc Info page parts")
   public static final String PRIVATE_CONSTANT_83 = "part.relatedCADDocsParts.description";

   /**
    * Related Documents from Part Details page
    **/
   @RBEntry("Reference Documents")
   @RBComment("used for the part info and doc info page references documents")
   public static final String REFERENCES_DOC_TABLE_HEADER = "REFERENCES_DOC_TABLE_HEADER";

   @RBEntry("Described By Documents")
   @RBComment("used for the part info page described by documents")
   public static final String DESCRIBED_BY_DOC_TABLE_HEADER = "DESCRIBED_BY_DOC_TABLE_HEADER";

   @RBEntry("CAD/Dynamic Documents")
   @RBComment("used for the part info page described CAD")
   public static final String DESCRIBED_BY_CAD_DOC_TABLE_HEADER = "DESCRIBED_BY_CAD_DOC_TABLE_HEADER";

   @RBEntry("Default")
   @RBComment("part info page default table view name")
   public static final String RELATED_DOC_TABLE_VIEW_DEFAULT_NAME = "RELATED_DOC_TABLE_VIEW_DEFAULT_NAME";

   @RBEntry("Default Table View name")
   @RBComment(" part info page description default table view name")
   public static final String RELATED_DOC_TABLE_VIEW_DEFAULT_DESCIP = "RELATED_DOC_TABLE_VIEW_DEFAULT_DESCIP";

   @RBEntry("CONFIRMATION: Part will be Checked-Out.  The object you wish to edit will be checked out to you for editing.")
   public static final String PART_AUTO_CHECKOUT_MSG = "PART_AUTO_CHECKOUT_MSG";

   @RBEntry("Part will be Checked-Out.  The object you wish to edit will be checked out to you for editing.")
   public static final String PSB_PART_AUTO_CHECKOUT_MSG = "PSB_PART_AUTO_CHECKOUT_MSG";

   @RBEntry("Classifications")
   @RBComment("Classifications table header.")
   public static final String Classifications = "CLASSIFICATIONS";

   @RBEntry("Classification Attributes")
   @RBComment("Classifications Attributes step table header.")
   public static final String CLASSIFICATION_ATTRS_TABLE_HEADER = "CLASSIFICATION_ATTRS_TABLE_HEADER";

   @RBEntry("Remove")
   @RBComment("Used as the toolbar description for Remove References")
   public static final String PRIVATE_CONSTANT_84 = "part.related_delete_references.description";

   @RBEntry("Remove Selected")
   @RBComment("Used for tooltip for the Remove References")
   public static final String PRIVATE_CONSTANT_85 = "part.related_delete_references.tooltip";

   @RBEntry("remove16x16.gif")
   @RBPseudo(false)
   @RBComment("Used for the icon for the Remove References")
   public static final String PRIVATE_CONSTANT_86 = "part.related_delete_references.icon";

   @RBEntry("Remove")
   @RBComment("Used as the toolbar description for Remove Described By Link")
   public static final String PRIVATE_CONSTANT_87 = "part.related_delete_described.description";

   @RBEntry("Remove Selected")
   @RBComment("Used as the tooltip for Remove Described By Link")
   public static final String PRIVATE_CONSTANT_88 = "part.related_delete_described.tooltip";

   @RBEntry("remove16x16.gif")
   @RBPseudo(false)
   @RBComment("Used as the icon for Remove Described By Link")
   public static final String PRIVATE_CONSTANT_89 = "part.related_delete_described.icon";

   @RBEntry("Copy")
   @RBComment("Used as the toolbar description for copy to clipboard")
   public static final String PRIVATE_CONSTANT_90 = "part.related_copy_references.description";

   @RBEntry("Copy Selected Object")
   @RBComment("Used as the tooltip for copy to clipboard")
   public static final String PRIVATE_CONSTANT_91 = "part.related_copy_references.tooltip";

   @RBEntry("copy.gif")
   @RBPseudo(false)
   @RBComment("Used as the icon for copy to clipboard")
   public static final String PRIVATE_CONSTANT_92 = "part.related_copy_references.icon";

   @RBEntry("export_collapse.gif")
   @RBPseudo(false)
   @RBComment("Used as the disabled icon for copy to clipboard")
   public static final String PRIVATE_CONSTANT_93 = "part.related_copy_references.disabled_icon";

   @RBEntry("Paste")
   @RBComment("Used as the toolbar description for paste from clipboard")
   public static final String PRIVATE_CONSTANT_94 = "part.related_paste_references.description";

   @RBEntry("Paste")
   @RBComment("Used as the tooltip for paste from clipboard")
   public static final String PRIVATE_CONSTANT_95 = "part.related_paste_references.tooltip";

   @RBEntry("paste.gif")
   @RBPseudo(false)
   @RBComment("Used as the icon for paste from clipboard")
   public static final String PRIVATE_CONSTANT_96 = "part.related_paste_references.icon";

   @RBEntry("Paste")
   @RBComment("Used as the toolbar description for paste from clipboard")
   public static final String PRIVATE_CONSTANT_97 = "part.related_paste_described.description";

   @RBEntry("Paste")
   @RBComment("Used as the tooltip for paste from clipboard")
   public static final String PRIVATE_CONSTANT_98 = "part.related_paste_described.tooltip";

   @RBEntry("paste.gif")
   @RBPseudo(false)
   @RBComment("Used as the icon for paste from clipboard")
   public static final String PRIVATE_CONSTANT_99 = "part.related_paste_described.icon";

   @RBEntry("Paste Selection")
   @RBComment("Used as the toolbar description for paste Select from clipboard")
   public static final String PRIVATE_CONSTANT_100 = "part.related_paste_select_references.description";

   @RBEntry("Paste Selection")
   @RBComment("Used as the tooltip for paste Select from clipboard")
   public static final String PRIVATE_CONSTANT_101 = "part.related_paste_select_references.tooltip";

   @RBEntry("paste_select.gif")
   @RBPseudo(false)
   @RBComment("Used as the icon for paste Select from clipboard")
   public static final String PRIVATE_CONSTANT_102 = "part.related_paste_select_references.icon";

   @RBEntry("height=550,width=700")
   @RBPseudo(false)
   @RBComment("Used as the popup size for paste Select from clipboard")
   public static final String PRIVATE_CONSTANT_103 = "part.related_paste_select_references.moreurlinfo";

   @RBEntry("Paste Selection of References Document")
   @RBComment("Used as the title for paste Select from clipboard")
   public static final String PRIVATE_CONSTANT_104 = "part.related_paste_select_references.title";

   @RBEntry("Paste Selection")
   @RBComment("Used as the toolbar description for paste Select from clipboard")
   public static final String PRIVATE_CONSTANT_105 = "part.related_paste_select_described.description";

   @RBEntry("Paste Selection")
   @RBComment("Used as the tooltip for paste Select from clipboard")
   public static final String PRIVATE_CONSTANT_106 = "part.related_paste_select_described.tooltip";

   @RBEntry("paste_select.gif")
   @RBPseudo(false)
   @RBComment("Used as the icon for paste Select from clipboard")
   public static final String PRIVATE_CONSTANT_107 = "part.related_paste_select_described.icon";

   @RBEntry("height=550,width=700")
   @RBPseudo(false)
   @RBComment("Used as the popup size for paste Select from clipboard")
   public static final String PRIVATE_CONSTANT_108 = "part.related_paste_select_described.moreurlinfo";

   @RBEntry("Paste Selection of Described By Document")
   @RBComment("Used as the title for paste Select from clipboard")
   public static final String PRIVATE_CONSTANT_109 = "part.related_paste_select_described.title";

   @RBEntry("Add")
   @RBComment("Used as the toolbar description for add documents link")
   public static final String PRIVATE_CONSTANT_110 = "part.related_add_references.description";

   @RBEntry("Add Existing Document")
   @RBComment("Used as the tooltip for add documents link")
   public static final String PRIVATE_CONSTANT_111 = "part.related_add_references.tooltip";

   @RBEntry("add16x16.gif")
   @RBPseudo(false)
   @RBComment("Used as the icon for add documents link")
   public static final String PRIVATE_CONSTANT_112 = "part.related_add_references.icon";

   @RBEntry("height=950,width=1000")
   @RBPseudo(false)
   @RBComment("Used as the popup size for add documents link")
   public static final String PRIVATE_CONSTANT_113 = "part.related_add_references.moreurlinfo";

   @RBEntry("Add References Document")
   @RBComment("Used as the title for add documents link")
   public static final String PRIVATE_CONSTANT_114 = "part.related_add_references.title";

   @RBEntry("Add")
   @RBComment("Used as the toolbar description for add documents link")
   public static final String PRIVATE_CONSTANT_115 = "part.related_add_described.description";

   @RBEntry("Add Existing Document")
   @RBComment("Used as the tooltip for add documents link")
   public static final String PRIVATE_CONSTANT_116 = "part.related_add_described.tooltip";

   @RBEntry("add16x16.gif")
   @RBPseudo(false)
   @RBComment("Used as the icon for add documents link")
   public static final String PRIVATE_CONSTANT_117 = "part.related_add_described.icon";

   @RBEntry("height=950,width=1000")
   @RBPseudo(false)
   @RBComment("Used as the popup size for add documents link")
   public static final String PRIVATE_CONSTANT_118 = "part.related_add_described.moreurlinfo";

   @RBEntry("Add Described By Document")
   @RBComment("Used as the title for add documents link")
   public static final String PRIVATE_CONSTANT_119 = "part.related_add_described.title";

   /**
    * Related Parts from Document Details page
    **/
   @RBEntry("Describes Parts")
   @RBComment("This string is used for the document info page describes parts table header")
   public static final String DESCRIBES_PARTS_TABLE_HEADER = "DESCRIBES_PARTS_TABLE_HEADER";

   @RBEntry("Referenced By Parts")
   @RBComment("This string is used for the document info page referenced by parts table header")
   public static final String REFERENCED_BY_PARTS_TABLE_HEADER = "REFERENCED_BY_PARTS_TABLE_HEADER";

   @RBEntry("Add")
   @RBComment("Used as the toolbar description for add parts link")
   public static final String PRIVATE_CONSTANT_120 = "part.related_add_references_docpart.description";

   @RBEntry("Add Referenced By Part")
   @RBComment("Used as the tooltip for add parts link")
   public static final String PRIVATE_CONSTANT_121 = "part.related_add_references_docpart.tooltip";

   @RBEntry("add16x16.gif")
   @RBPseudo(false)
   @RBComment("Used as the icon for add documents link")
   public static final String PRIVATE_CONSTANT_122 = "part.related_add_references_docpart.icon";

   @RBEntry("height=950,width=1000")
   @RBPseudo(false)
   @RBComment("Used as the popup size for add documents link")
   public static final String PRIVATE_CONSTANT_123 = "part.related_add_references_docpart.moreurlinfo";

   @RBEntry("Add Referenced By Part")
   @RBComment("Used as the title for add documents link")
   public static final String PRIVATE_CONSTANT_124 = "part.related_add_references_docpart.title";

   @RBEntry("Add")
   @RBComment("Used as the toolbar description for add parts link")
   public static final String PRIVATE_CONSTANT_125 = "part.related_add_described_docpart.description";

   @RBEntry("Add Describes Part")
   @RBComment("Used as the tooltip for add parts link")
   public static final String PRIVATE_CONSTANT_126 = "part.related_add_described_docpart.tooltip";

   @RBEntry("add16x16.gif")
   @RBPseudo(false)
   @RBComment("Used as the icon for add documents link")
   public static final String PRIVATE_CONSTANT_127 = "part.related_add_described_docpart.icon";

   @RBEntry("height=950,width=1000")
   @RBPseudo(false)
   @RBComment("Used as the popup size for add documents link")
   public static final String PRIVATE_CONSTANT_128 = "part.related_add_described_docpart.moreurlinfo";

   @RBEntry("Add Describes Part")
   @RBComment("Used as the title for add documents link")
   public static final String PRIVATE_CONSTANT_129 = "part.related_add_described_docpart.title";

   @RBEntry("Associate New")
   @RBComment("Used as the toolbar description for New on part info page")
   public static final String PRIVATE_CONSTANT_130 = "part.related_part_create_wizard_doc_described.description";

   @RBEntry("Create and associate a new describes part")
   @RBComment("Used as the tooltip for New on part info page")
   public static final String PRIVATE_CONSTANT_131 = "part.related_part_create_wizard_doc_described.tooltip";

   @RBEntry("newpart.gif")
   @RBPseudo(false)
   @RBComment("Used as the icon for New on part info page")
   public static final String PRIVATE_CONSTANT_132 = "part.related_part_create_wizard_doc_described.icon";

   @RBEntry("New Part")
   @RBComment("Used as the title for Associate New on part info page")
   public static final String PRIVATE_CONSTANT_133 = "part.related_part_create_wizard_doc_described.title";

   @RBEntry("height=700,width=800")
   @RBPseudo(false)
   @RBComment("Used as the popup size for New on part info page")
   public static final String PRIVATE_CONSTANT_134 = "part.related_part_create_wizard_doc_described.moreurlinfo";

   @RBEntry("Associate New")
   @RBComment("Used as the toolbar description for New on part info page")
   public static final String PRIVATE_CONSTANT_135 = "part.related_part_create_wizard_doc_references.description";

   @RBEntry("Create and associate a new referenced by part")
   @RBComment("Used as the tooltip for New on part info page")
   public static final String PRIVATE_CONSTANT_136 = "part.related_part_create_wizard_doc_references.tooltip";

   @RBEntry("newpart.gif")
   @RBPseudo(false)
   @RBComment("Used as the icon for New on part info page")
   public static final String PRIVATE_CONSTANT_137 = "part.related_part_create_wizard_doc_references.icon";

   @RBEntry("New Part")
   @RBComment("Used as the title for Associate New on for part info page")
   public static final String PRIVATE_CONSTANT_138 = "part.related_part_create_wizard_doc_references.title";

   @RBEntry("height=700,width=800")
   @RBPseudo(false)
   @RBComment("Used as the popup size for New on part info page")
   public static final String PRIVATE_CONSTANT_139 = "part.related_part_create_wizard_doc_references.moreurlinfo";

   @RBEntry("Paste Selection")
   @RBComment("Used as the toolbar description for paste Select from clipboard")
   public static final String PRIVATE_CONSTANT_140 = "part.related_paste_select_references_part.description";

   @RBEntry("Paste Selection of Referenced By Part from Clipboard")
   @RBComment("Used as the tooltip for paste Select from clipboard")
   public static final String PRIVATE_CONSTANT_141 = "part.related_paste_select_references_part.tooltip";

   @RBEntry("paste_select.gif")
   @RBPseudo(false)
   @RBComment("Used as the icon for paste Select from clipboard")
   public static final String PRIVATE_CONSTANT_142 = "part.related_paste_select_references_part.icon";

   @RBEntry("height=550,width=700")
   @RBPseudo(false)
   @RBComment("Used as the popup size for paste Select from clipboard")
   public static final String PRIVATE_CONSTANT_143 = "part.related_paste_select_references_part.moreurlinfo";

   @RBEntry("Paste Selection of Referenced By Part")
   @RBComment("Used as the title for paste Select from clipboard")
   public static final String PRIVATE_CONSTANT_144 = "part.related_paste_select_references_part.title";

   @RBEntry("Paste Selection")
   @RBComment("Used as the toolbar description for paste Select from clipboard")
   public static final String PRIVATE_CONSTANT_145 = "part.related_paste_select_described_part.description";

   @RBEntry("Paste Selection of Describes Part from Clipboard")
   @RBComment("Used as the tooltip for paste Select from clipboard")
   public static final String PRIVATE_CONSTANT_146 = "part.related_paste_select_described_part.tooltip";

   @RBEntry("paste_select.gif")
   @RBPseudo(false)
   @RBComment("Used as the icon for paste Select from clipboard")
   public static final String PRIVATE_CONSTANT_147 = "part.related_paste_select_described_part.icon";

   @RBEntry("height=550,width=700")
   @RBPseudo(false)
   @RBComment("Used as the popup size for paste Select from clipboard")
   public static final String PRIVATE_CONSTANT_148 = "part.related_paste_select_described_part.moreurlinfo";

   @RBEntry("Paste Selection of Describes Part")
   @RBComment("Used as the title for paste Select from clipboard")
   public static final String PRIVATE_CONSTANT_149 = "part.related_paste_select_described_part.title";

   @RBEntry("Paste")
   @RBComment("Used as the toolbar description for paste from clipboard")
   public static final String PRIVATE_CONSTANT_150 = "part.related_paste_references_part.description";

   @RBEntry("Paste Referenced By Part from Clipboard")
   @RBComment("Used as the tooltip for paste from clipboard")
   public static final String PRIVATE_CONSTANT_151 = "part.related_paste_references_part.tooltip";

   @RBEntry("paste.gif")
   @RBPseudo(false)
   @RBComment("Used as the icon for paste from clipboard")
   public static final String PRIVATE_CONSTANT_152 = "part.related_paste_references_part.icon";

   @RBEntry("Paste")
   @RBComment("Used as the toolbar description for paste from clipboard")
   public static final String PRIVATE_CONSTANT_153 = "part.related_paste_described_part.description";

   @RBEntry("Paste Describes Part from Clipboard")
   @RBComment("Used as the tooltip for paste from clipboard")
   public static final String PRIVATE_CONSTANT_154 = "part.related_paste_described_part.tooltip";

   @RBEntry("paste.gif")
   @RBPseudo(false)
   @RBComment("Used as the icon for paste from clipboard")
   public static final String PRIVATE_CONSTANT_155 = "part.related_paste_described_part.icon";

   @RBEntry("Remove")
   @RBComment("Used as the toolbar description for Remove Referenced By Link")
   public static final String PRIVATE_CONSTANT_156 = "part.related_delete_references_part.description";

   @RBEntry("Remove Referenced By Part")
   @RBComment("Used for tooltip for the Remove Referenced By Link")
   public static final String PRIVATE_CONSTANT_157 = "part.related_delete_references_part.tooltip";

   @RBEntry("remove16x16.gif")
   @RBPseudo(false)
   @RBComment("Used for the icon for the Remove Referenced By Link")
   public static final String PRIVATE_CONSTANT_158 = "part.related_delete_references_part.icon";

   @RBEntry("Remove")
   @RBComment("Used as the toolbar description for Remove Describes Link")
   public static final String PRIVATE_CONSTANT_159 = "part.related_delete_described_part.description";

   @RBEntry("Remove Describes Part")
   @RBComment("Used as the tooltip for Remove Describes Link")
   public static final String PRIVATE_CONSTANT_160 = "part.related_delete_described_part.tooltip";

   @RBEntry("remove16x16.gif")
   @RBPseudo(false)
   @RBComment("Used as the icon for Remove Describes Link")
   public static final String PRIVATE_CONSTANT_161 = "part.related_delete_described_part.icon";

   @RBEntry("Copy")
   @RBComment("Used as the toolbar description for copy to clipboard")
   public static final String PRIVATE_CONSTANT_162 = "part.related_copy_references_part.description";

   @RBEntry("Copy to Clipboard")
   @RBComment("Used as the tooltip for copy to clipboard")
   public static final String PRIVATE_CONSTANT_163 = "part.related_copy_references_part.tooltip";

   @RBEntry("copy.gif")
   @RBPseudo(false)
   @RBComment("Used as the icon for copy to clipboard")
   public static final String PRIVATE_CONSTANT_164 = "part.related_copy_references_part.icon";

   @RBEntry("export_collapse.gif")
   @RBPseudo(false)
   @RBComment("Used as the disabled icon for copy to clipboard")
   public static final String PRIVATE_CONSTANT_165 = "part.related_copy_references_part.disabled_icon";

   /**
    * This is where the association should be coming from but there is a build order issue
    * /wt_ma_services/modules/UwgmCadx/src/com\ptc/windchill/uwgm/cadx/associate/associateResource.rbInfo
    * ASSOCTYPE_ACTIVE = Owner
    * ASSOCTYPE_PASSIVE = Content
    * ASSOCTYPE_CALCULATED = Calculated
    **/
   @RBEntry("Owner")
   public static final String ASSOCTYPE_ACTIVE = "ASSOCTYPE_ACTIVE";

   @RBEntry("Content")
   public static final String ASSOCTYPE_PASSIVE = "ASSOCTYPE_PASSIVE";

   @RBEntry("Calculated")
   public static final String ASSOCTYPE_CALCULATED = "ASSOCTYPE_CALCULATED";

   /**
    * End Related documents and parts
    **/
   @RBEntry("AML/AVL")
   @RBComment("Used as the label for the AML AVL action for a part")
   public static final String PRIVATE_CONSTANT_166 = "part.AXL.description";

   @RBEntry("AML/AVL")
   @RBComment("Used as the label for the AML AVL action for a part")
   public static final String PRIVATE_CONSTANT_167 = "part.AXL.title";

   @RBEntry("AML/AVL")
   @RBComment("Used as the label for the AML AVL action for a part")
   public static final String PRIVATE_CONSTANT_168 = "part.AXL.tooltip";

   @RBEntry("height=500,width=475")
   @RBPseudo(false)
   @RBComment("DO NOT TRANSLATE")
   public static final String PRIVATE_CONSTANT_169 = "part.AXL.moreurlinfo";

   @RBEntry("Edit Common Attributes")
   @RBComment("Used as the label for the Edit Common Attributes action for a part")
   public static final String PRIVATE_CONSTANT_170 = "part.editPartCommonAttrsWizard.description";

   @RBEntry("Edit Common Attributes")
   @RBComment("Used as the label for the Edit Common Attributes action for a part")
   public static final String PRIVATE_CONSTANT_171 = "part.editPartCommonAttrsWizard.title";

   @RBEntry(" Edit Common Attributes")
   @RBComment("Used as the tooltip for the Edit Common Attributes action for a part")
   public static final String PRIVATE_CONSTANT_172 = "part.editPartCommonAttrsWizard.tooltip";

   @RBEntry("attribute_edit.gif")
   @RBPseudo(false)
   @RBComment("Icon for the edit part common attributes action (for toolbars)")
   public static final String PRIVATE_CONSTANT_173 = "part.editPartCommonAttrsWizard.icon";

   @RBEntry("height=550,width=750")
   @RBPseudo(false)
   @RBComment("DO NOT TRANSLATE")
   public static final String PRIVATE_CONSTANT_174 = "part.editPartCommonAttrsWizard.moreurlinfo";

   @RBEntry("Set Attributes")
   @RBComment("Used as the label for the Set Attributes step of Edit Common Attributes action")
   public static final String PRIVATE_CONSTANT_175 = "part.editPartCommonAttrsWizardStep.description";

   @RBEntry("Set Attributes")
   @RBComment("Used as the label for the Set Attributes step of Edit Common Attributes action")
   public static final String PRIVATE_CONSTANT_176 = "part.editPartCommonAttrsWizardStep.title";

   @RBEntry("Set Attributes")
   @RBComment("Used as the label for the Set Attributes step of Edit Common Attributes action")
   public static final String PRIVATE_CONSTANT_177 = "part.editPartCommonAttrsWizardStep.tooltip";

   @RBEntry("Edit Common Attributes")
   @RBComment("Used as the label for the Edit Common Attributes action for a part")
   public static final String PRIVATE_CONSTANT_178 = "part.editPartCommonAttrsAttrTableWizard.description";

   @RBEntry("Edit Common Attributes")
   @RBComment("Used as the label for the Edit Common Attributes action for a part")
   public static final String PRIVATE_CONSTANT_179 = "part.editPartCommonAttrsAttrTableWizard.title";

   @RBEntry(" Edit Common Attributes")
   @RBComment("Used as the tooltip for the Edit Common Attributes action for a part")
   public static final String PRIVATE_CONSTANT_180 = "part.editPartCommonAttrsAttrTableWizard.tooltip";

   @RBEntry("attribute_edit.gif")
   @RBPseudo(false)
   @RBComment("Icon for the edit part common attributes action (for toolbars)")
   public static final String PRIVATE_CONSTANT_181 = "part.editPartCommonAttrsAttrTableWizard.icon";

   @RBEntry("height=500,width=750")
   @RBPseudo(false)
   @RBComment("DO NOT TRANSLATE")
   public static final String PRIVATE_CONSTANT_182 = "part.editPartCommonAttrsAttrTableWizard.moreurlinfo";

   @RBEntry("Reassign View")
   @RBComment("Used as the label for Reassign View action")
   public static final String PRIVATE_CONSTANT_183 = "part.assignView.description";

   @RBEntry("Reassign View")
   @RBComment("Used as the label for Reassign View action")
   public static final String PRIVATE_CONSTANT_184 = "part.assignView.title";

   @RBEntry("Reassign View")
   @RBComment("Used as the label for Reassign View action")
   public static final String PRIVATE_CONSTANT_185 = "part.assignView.tooltip";

   @RBEntry("height=200,width=600")
   @RBPseudo(false)
   @RBComment("DO NOT TRANSLATE")
   public static final String PRIVATE_CONSTANT_186 = "part.assignView.moreurlinfo";

   @RBEntry("view_reassign.gif")
   @RBPseudo(false)
   @RBComment("Icon for Reassign View action")
   public static final String PRIVATE_CONSTANT_187 = "part.assignView.icon";

   @RBEntry("Alternates")
   public static final String PRIVATE_CONSTANT_188 = "part.alternates.description";

   @RBEntry("Alternates")
   public static final String PRIVATE_CONSTANT_189 = "part.alternates.title";

   @RBEntry("Alternate For")
   @RBComment("Label to use as the menu option for the \"Alternate For\" table in the \"My Tab\" menu which lets you choose which tables to display on the info page. Probably should match the ALTERNATESFOR_LABEL.")
   public static final String PRIVATE_CONSTANT_190 = "part.alternateFor.description";

   @RBEntry("Substitutes")
   public static final String PRIVATE_CONSTANT_191 = "part.substitutes.description";

   @RBEntry("Substitutes")
   public static final String PRIVATE_CONSTANT_192 = "part.substitutes.title";

   @RBEntry("Substitutes For")
   public static final String PRIVATE_CONSTANT_193 = "part.substitutesFor.description";

   @RBEntry("Substitutes For")
   public static final String PRIVATE_CONSTANT_194 = "part.substitutesFor.title";

   @RBEntry("Manage Replacements")
   public static final String PRIVATE_CONSTANT_195 = "part.replacements.description";

   @RBEntry("Manage Replacements")
   public static final String PRIVATE_CONSTANT_196 = "part.replacements.title";

   @RBEntry("height=500,width=1000")
   @RBPseudo(false)
   @RBComment("DO NOT TRANSLATE")
   public static final String PRIVATE_CONSTANT_197 = "part.replacements.moreurlinfo";

   @RBEntry("../../com/ptc/core/ui/images/replacement_manage.gif")
   @RBPseudo(false)
   @RBComment("Icon that appears in the see action drop down list")
   public static final String PRIVATE_CONSTANT_198 = "part.replacements.icon";

   @RBEntry("Cancel")
   @RBComment("Used as the label for the Cancel button")
   public static final String PRIVATE_CONSTANT_199 = "part.replacementsCancelButton.description";

   @RBEntry("Cancel")
   @RBComment("Used as the title for Cancel button")
   public static final String PRIVATE_CONSTANT_200 = "part.replacementsCancelButton.title";

   @RBEntry("Cancel")
   @RBComment("Used as the tooltip for Cancel button")
   public static final String PRIVATE_CONSTANT_201 = "part.replacementsCancelButton.tooltip";

   @RBEntry("OK")
   @RBComment("Used as the label for the Ok button")
   public static final String PRIVATE_CONSTANT_202 = "part.replacementsOkButton.description";

   @RBEntry("OK")
   @RBComment("Used as the title for Ok button")
   public static final String PRIVATE_CONSTANT_203 = "part.replacementsOkButton.title";

   @RBEntry("OK")
   @RBComment("Used as the tooltip for Ok button")
   public static final String PRIVATE_CONSTANT_204 = "part.replacementsOkButton.tooltip";

   @RBEntry("Allocation")
   public static final String PRIVATE_CONSTANT_205 = "part.allocations.description";

   @RBEntry("Associated Changes")
   public static final String PRIVATE_CONSTANT_206 = "part.associatedChanges.description";

   @RBEntry("Life Cycle History")
   public static final String PRIVATE_CONSTANT_207 = "object.showLifeCycleHistory.description";

   @RBEntry("Two-Way")
   public static final String PRIVATE_CONSTANT_208 = "part.toggleTwoway.description";

   @RBEntry("Indicates two-way relationship")
   public static final String PRIVATE_CONSTANT_209 = "part.toggleTwoway.tooltip";

   @RBEntry("../../wtcore/images/worksp.gif")
   public static final String PRIVATE_CONSTANT_210 = "part.toggleTwoway.icon";

   @RBEntry("../../wtcore/images/replacement_add.gif")
   public static final String PRIVATE_CONSTANT_211 = "part.addAlternateLinks.icon";

   @RBEntry("Add Alternate")
   public static final String PRIVATE_CONSTANT_212 = "part.addAlternateLinks.description";

   @RBEntry("Add Alternate Part")
   public static final String PRIVATE_CONSTANT_213 = "part.addAlternateLinks.tooltip";

   @RBEntry("remove16x16.gif")
   @RBComment("DO NOT TRANSLATE")
   public static final String PART_REMOVE_ALTERNATELINK_ICON = "part.removeAlternateLinks.icon";

   @RBEntry("Remove Alternate")
   @RBComment("Toolbar button to remove an alternate part")
   public static final String PART_REMOVE_ALTERNATELINK_DESCRIPTION = "part.removeAlternateLinks.description";

   @RBEntry("Remove Alternate Part")
   @RBComment("Toolbar button to remove an alternate part")
   public static final String PART_REMOVE_ALTERNATELINK_TOOLTIP = "part.removeAlternateLinks.tooltip";

   @RBEntry("../../wtcore/images/substitute_add.gif")
   public static final String PRIVATE_CONSTANT_214 = "part.addSubstituteLinks.icon";

   @RBEntry("Add Substitute")
   public static final String PRIVATE_CONSTANT_215 = "part.addSubstituteLinks.description";

   @RBEntry("Add Substitute Part")
   public static final String PRIVATE_CONSTANT_216 = "part.addSubstituteLinks.tooltip";

   @RBEntry("remove16x16.gif")
   @RBComment("DO NOT TRANSLATE")
   public static final String PART_REMOVE_SUBSTITUTELINK_ICON = "part.removeSubstituteLinks.icon";

   @RBEntry("Remove Substitute")
   @RBComment("Toolbar button to remove a substitute part")
   public static final String PART_REMOVE_SUBSTITUTELINK_DESCRIPTION = "part.removeSubstituteLinks.description";

   @RBEntry("Remove Substitute Part")
   @RBComment("Toolbar button to remove a substitute part")
   public static final String PART_REMOVE_SUBSTITUTELINK_TOOLTIP = "part.removeSubstituteLinks.tooltip";

   @RBEntry("add16x16.gif")
   public static final String PRIVATE_CONSTANT_217 = "part.addAlternateLinksThirdNav.icon";

   @RBEntry("Add")
   public static final String PRIVATE_CONSTANT_218 = "part.addAlternateLinksThirdNav.description";

   @RBEntry("Add Alternate")
   public static final String PRIVATE_CONSTANT_219 = "part.addAlternateLinksThirdNav.tooltip";

   @RBEntry("../../wtcore/images/replacement_add.gif")
   public static final String PRIVATE_CONSTANT_220 = "part.addSubstituteLinksThirdNav.icon";

   @RBEntry("Add Substitute")
   public static final String PRIVATE_CONSTANT_221 = "part.addSubstituteLinksThirdNav.description";

   @RBEntry("Add Substitute Part")
   public static final String PRIVATE_CONSTANT_222 = "part.addSubstituteLinksThirdNav.tooltip";

   @RBEntry("Assign Part Version")
   public static final String PRIVATE_CONSTANT_223 = "part.assignPartVersion.description";

   @RBEntry("Assign Part Version")
   public static final String PRIVATE_CONSTANT_224 = "part.assignPartVersion.title";

   @RBEntry("Override Part Version")
   public static final String PRIVATE_CONSTANT_225 = "part.overridePartVersion.description";

   @RBEntry("Override Part Version")
   public static final String PRIVATE_CONSTANT_226 = "part.overridePartVersion.title";

   @RBEntry("Add Described By Document")
   public static final String PRIVATE_CONSTANT_227 = "part.associate_document_to_part_described.description";

   @RBEntry("Add Described By Document")
   public static final String PRIVATE_CONSTANT_228 = "part.associate_document_to_part_described.title";

   @RBEntry("iconAssociate.gif")
   @RBPseudo(false)
   @RBComment("Icon that appears in the see action drop down list")
   public static final String PRIVATE_CONSTANT_229 = "part.associate_document_to_part_described.icon";

   @RBEntry("Replace")
   public static final String PRIVATE_CONSTANT_233 = "part.partInstance_replacePart.description";

   @RBEntry("Replace Part")
   public static final String PRIVATE_CONSTANT_234 = "part.partInstance_replacePart.title";

   @RBEntry("height=500,width=500")
   @RBPseudo(false)
   @RBComment("DO NOT TRANSLATE")
   public static final String PRIVATE_CONSTANT_235 = "part.partInstance_replacePart.moreurlinfo";

   @RBEntry("Undo Replace")
   public static final String PRIVATE_CONSTANT_236 = "part.partInstance_undo_replacement.description";

   @RBEntry("Undo Replace Part")
   public static final String PRIVATE_CONSTANT_237 = "part.partInstance_undo_replacement.title";

   @RBEntry("Replace")
   public static final String PRIVATE_CONSTANT_238 = "part.replacePart.description";

   @RBEntry("Replace Part")
   public static final String PRIVATE_CONSTANT_239 = "part.replacePart.title";

   @RBEntry("../../com/ptc/core/ui/images/replace.gif")
   @RBPseudo(false)
   @RBComment("Icon that appears in the see action drop down list")
   public static final String PRIVATE_CONSTANT_240 = "part.replacePart.icon";

   @RBEntry("Are you sure you want to undo replacing part {0} - {1}  - {2}?")
   @RBComment("The confirmation message when a user tries to undo replacement from part instance.")
   @RBArgComment0("Part number")
   @RBArgComment1("Part manufacture id")
   @RBArgComment2("Part name")
   public static final String CONFIRM_PARTINSTANCE_UNDO_REPLACEMENT = "CONFIRM_PARTINSTANCE_UNDO_REPLACEMENT";

   @RBEntry("Replacement Part")
   public static final String REPLACEMENT_PART_HEADER = "REPLACEMENT_PART_HEADER";

   @RBEntry("Associate Documents")
   public static final String ASSOCIATE_DOCUMENT_SEARCH_HEADER = "ASSOCIATE_DOCUMENT_SEARCH_HEADER";

   @RBEntry("Set As Primary End Item")
   @RBComment("Used as the label for Set As Primary End Item action on End items tab in Product Details Page")
   public static final String PRIVATE_CONSTANT_241 = "part.makePrimaryEndItem.description";

   @RBEntry("Set As Primary End Item")
   @RBComment("Used as the tooltip for Set As Primary End Item action on End items tab in Product Details Page")
   public static final String PRIVATE_CONSTANT_242 = "part.makePrimaryEndItem.tooltip";

   @RBEntry("Unset Primary End Item")
   @RBComment("Used as the label for Unset Primary End Item action on End items tab in Product Details Page")
   public static final String PRIVATE_CONSTANT_243 = "part.removePrimaryEndItem.description";

   @RBEntry("Unset Primary End Item")
   @RBComment("Used as the tooltip for Unset Primary End Item action on End items tab in Product Details Page")
   public static final String PRIVATE_CONSTANT_244 = "part.removePrimaryEndItem.tooltip";

   @RBEntry("Associate Documents")
   @RBComment("Used as the label for Associate Documents action on PSB table")
   public static final String PRIVATE_CONSTANT_245 = "part.ASSOCIATEDOCUMENTSTOPART.description";

   @RBEntry("Associate Documents")
   @RBComment("Used as the tooltip for Associate Documents action on PSB table")
   public static final String PRIVATE_CONSTANT_246 = "part.ASSOCIATEDOCUMENTSTOPART.tooltip";

   @RBEntry("iconAssociate.gif")
   @RBPseudo(false)
   @RBComment("Used as the icon for Associate Documents action on PSB table")
   public static final String PRIVATE_CONSTANT_247 = "part.ASSOCIATEDOCUMENTSTOPART.icon";

   /**
    * Tabular-input specific entries
    **/
   @RBEntry("Edit Bill of Materials")
   @RBComment("Title for edit structure pop up window")
   public static final String PRIVATE_CONSTANT_248 = "part.tabular_input.title";

   @RBEntry("Edit Bill of Materials")
   @RBComment("Action name (description) that shows up in 'actions' link")
   public static final String PRIVATE_CONSTANT_249 = "part.tabular_input.description";

   @RBEntry("Edit Bill of Materials")
   public static final String PRIVATE_CONSTANT_250 = "part.tabular_input.tooltip";

   @RBEntry("multi_update.gif")
   @RBComment("Icon for the Edit Bill of Materials action ")
   public static final String PRIVATE_CONSTANT_251 = "part.tabular_input.icon";

   @RBEntry("height=580,width=1000")
   @RBPseudo(false)
   @RBComment("DO NOT TRANSLATE")
   public static final String PRIVATE_CONSTANT_252 = "part.tabular_input.moreurlinfo";

   @RBEntry("Edit Bill of Materials")
   @RBComment("Title for edit structure pop up window")
   public static final String PRIVATE_CONSTANT_253 = "part.psb_tabular_input.title";

   @RBEntry("Edit Bill of Materials")
   @RBComment("Action name (description) that shows up in 'actions' link")
   public static final String PRIVATE_CONSTANT_254 = "part.psb_tabular_input.description";

   @RBEntry("Edit Bill of Materials")
   public static final String PRIVATE_CONSTANT_255 = "part.psb_tabular_input.tooltip";

   @RBEntry("multi_update.gif")
   @RBComment("Icon for the Edit Structure action ")
   public static final String PRIVATE_CONSTANT_256 = "part.psb_tabular_input.icon";

   @RBEntry("height=580,width=1000")
   @RBPseudo(false)
   @RBComment("DO NOT TRANSLATE")
   public static final String PRIVATE_CONSTANT_257 = "part.psb_tabular_input.moreurlinfo";

   @RBEntry("Paste Part")
   @RBComment("Tooltip for this action that shows up in the client action toolbar")
   public static final String PRIVATE_CONSTANT_258 = "part.ti_paste_part.tooltip";

   @RBEntry("Paste Part")
   @RBComment("Localize the same way as tooltip")
   public static final String PRIVATE_CONSTANT_259 = "part.ti_paste_part.description";

   @RBEntry("height=375,width=485")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_260 = "part.ti_paste_part.moreurlinfo";

   @RBEntry("paste.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_261 = "part.ti_paste_part.icon";

   @RBEntry("Select parts to paste")
   @RBComment("Title of the Paste Select popup window")
   public static final String PRIVATE_CONSTANT_262 = "part.ti_paste_select_part.title";

   @RBEntry("Select parts to paste")
   @RBComment("Tooltip for this action that shows up in the client action toolbar")
   public static final String PRIVATE_CONSTANT_263 = "part.ti_paste_select_part.tooltip";

   @RBEntry("Paste selection")
   @RBComment("Localize the same way as tooltip")
   public static final String PRIVATE_CONSTANT_264 = "part.ti_paste_select_part.description";

   @RBEntry("paste_select.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_265 = "part.ti_paste_select_part.icon";

   @RBEntry("height=550,width=700")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_266 = "part.ti_paste_select_part.moreurlinfo";

   @RBEntry("Find and add part")
   public static final String PRIVATE_CONSTANT_267 = "part.ti_add_part.title";

   @RBEntry("Find and add part")
   public static final String PRIVATE_CONSTANT_268 = "part.ti_add_part.tooltip";

   @RBEntry("Find and add part")
   public static final String PRIVATE_CONSTANT_269 = "part.ti_add_part.description";

   @RBEntry("add16x16.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_270 = "part.ti_add_part.icon";

   @RBEntry("height=750,width=900")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_271 = "part.ti_add_part.moreurlinfo";

   @RBEntry("Find and add part")
   @RBComment("DO NOT TRANSLATE. This action is not visible to users.")
   public static final String PRIVATE_CONSTANT_272 = "part.ti_add_part_auto.title";

   @RBEntry("Find and add part")
   @RBComment("DO NOT TRANSLATE. This action is not visible to users.")
   public static final String PRIVATE_CONSTANT_273 = "part.ti_add_part_auto.tooltip";

   @RBEntry("Find and add part")
   @RBComment("DO NOT TRANSLATE. This action is not visible to users.")
   public static final String PRIVATE_CONSTANT_274 = "part.ti_add_part_auto.description";

   @RBEntry("add16x16.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_275 = "part.ti_add_part_auto.icon";

   @RBEntry("height=750,width=900")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_276 = "part.ti_add_part_auto.moreurlinfo";

   @RBEntry("New Part")
   @RBComment("Used as the label for the New Part action from Edit Structure table")
   public static final String PRIVATE_CONSTANT_277 = "part.ti_create_part.description";

   @RBEntry("New Part")
   @RBComment("Used as the tooltip for the New Part action from Edit Structure table")
   public static final String PRIVATE_CONSTANT_278 = "part.ti_create_part.tooltip";

   @RBEntry("height=550,width=700")
   @RBPseudo(false)
   @RBComment("DO NOT TRANSLATE")
   public static final String PRIVATE_CONSTANT_279 = "part.ti_create_part.moreurlinfo";

   @RBEntry("newpart.gif")
   @RBPseudo(false)
   @RBComment("Used as the icon for the New Part action from Edit Structure table")
   public static final String PRIVATE_CONSTANT_280 = "part.ti_create_part.icon";

   @RBEntry("New Multiple Parts")
   @RBComment("Used as the label for the New Multiple Parts action from Edit Structure table")
   public static final String PRIVATE_CONSTANT_281 = "part.ti_create_multiple_part.description";

   @RBEntry("New Multiple Parts")
   @RBComment("Used as the tooltip for the New Multiple Parts action from Edit Structure table")
   public static final String PRIVATE_CONSTANT_282 = "part.ti_create_multiple_part.tooltip";

   @RBEntry("part_createmultiple.gif")
   @RBPseudo(false)
   @RBComment("Used as the icon for the New Multiple Parts action from Edit Structure table")
   public static final String PRIVATE_CONSTANT_283 = "part.ti_create_multiple_part.icon";

   @RBEntry("OK")
   @RBComment("Used as the label for the Ok button")
   public static final String PRIVATE_CONSTANT_284 = "part.tabularInputOkButton.description";

   @RBEntry("OK")
   @RBComment("Used as the title for Ok button")
   public static final String PRIVATE_CONSTANT_285 = "part.tabularInputOkButton.title";

   @RBEntry("OK")
   @RBComment("Used as the tooltip for Ok button")
   public static final String PRIVATE_CONSTANT_286 = "part.tabularInputOkButton.tooltip";

   @RBEntry("Apply")
   @RBComment("Used as the label for the Apply button")
   public static final String PRIVATE_CONSTANT_287 = "part.tabularInputApplyButton.description";

   @RBEntry("Apply")
   @RBComment("Used as the title for Apply button")
   public static final String PRIVATE_CONSTANT_288 = "part.tabularInputApplyButton.title";

   @RBEntry("Apply")
   @RBComment("Used as the tooltip for Apply button")
   public static final String PRIVATE_CONSTANT_289 = "part.tabularInputApplyButton.tooltip";

   @RBEntry("Cancel")
   @RBComment("Used as the label for the Cancel button")
   public static final String PRIVATE_CONSTANT_290 = "part.tabularInputCancelButton.description";

   @RBEntry("Cancel")
   @RBComment("Used as the title for Cancel button")
   public static final String PRIVATE_CONSTANT_291 = "part.tabularInputCancelButton.title";

   @RBEntry("Cancel")
   @RBComment("Used as the tooltip for Cancel button")
   public static final String PRIVATE_CONSTANT_292 = "part.tabularInputCancelButton.tooltip";

   /**
    * multi part related entries
    **/
   @RBEntry("height=500,width=475")
   @RBPseudo(false)
   @RBComment("DO NOT TRANSLATE")
   public static final String PRIVATE_CONSTANT_293 = "part.setAttributesWizStepForCreateMultiPart.moreurlinfo";

   @RBEntry("height=500,width=475")
   @RBPseudo(false)
   @RBComment("DO NOT TRANSLATE")
   public static final String PRIVATE_CONSTANT_294 = "part.setAttributesWizStepForWTPart.moreurlinfo";

   @RBEntry("New Multiple Parts")
   @RBComment("Used as the label for the New Multiple Parts Wizard")
   public static final String PRIVATE_CONSTANT_295 = "part.createMultiPart.description";

   @RBEntry("New Multiple Parts")
   @RBComment("Used as the label for the New Multiple Parts Wizard")
   public static final String PRIVATE_CONSTANT_296 = "part.createMultiPart.title";

   @RBEntry("New Multiple Parts")
   @RBComment("Used as the tooltip for the New Multiple Parts Wizard")
   public static final String PRIVATE_CONSTANT_297 = "part.createMultiPart.tooltip";

   @RBEntry("height=550,width=1000")
   @RBPseudo(false)
   @RBComment("DO NOT TRANSLATE")
   public static final String PRIVATE_CONSTANT_298 = "part.createMultiPart.moreurlinfo";

   @RBEntry("part_createmultiple.gif")
   @RBPseudo(false)
   @RBComment("Icon that appears in toolbars for creating a New Multiple Parts")
   public static final String PRIVATE_CONSTANT_299 = "part.createMultiPart.icon";

   /**
    * adding one more entry because for some reason, title defined above is not picked up
    * using this title explicitly in CreatePartWizard.jsp
    **/
   @RBEntry("New Multiple Parts")
   @RBComment("Used as the label for the New Multiple Parts Wizard")
   public static final String PRIVATE_CONSTANT_300 = "part.createMultiPart.WIZARD_LABEL";

   @RBEntry("insert_multi_rows_below.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_301 = "part.addMultipleObjects.icon";

   @RBEntry("Add 5 Rows")
   public static final String PRIVATE_CONSTANT_302 = "part.addMultipleObjects.description";

   @RBEntry("Add 5 Rows")
   public static final String PRIVATE_CONSTANT_303 = "part.addMultipleObjects.tooltip";

   @RBEntry("insert_row_below.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_304 = "part.addObject.icon";

   @RBEntry("Add Row")
   public static final String PRIVATE_CONSTANT_305 = "part.addObject.description";

   @RBEntry("Add Row")
   public static final String PRIVATE_CONSTANT_306 = "part.addObject.tooltip";

   @RBEntry("row_select_remove.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_307 = "part.remove.icon";

   @RBEntry("Remove Selected Row")
   public static final String PRIVATE_CONSTANT_308 = "part.remove.description";

   @RBEntry("Remove Selected Row")
   public static final String PRIVATE_CONSTANT_309 = "part.remove.tooltip";

   @RBEntry("remove16x16.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_310 = "part.remove_part_usage.icon";

   @RBEntry("Remove Selected Row")
   public static final String PRIVATE_CONSTANT_311 = "part.remove_part_usage.description";

   @RBEntry("Remove Selected Row")
   public static final String PRIVATE_CONSTANT_312 = "part.remove_part_usage.tooltip";

   @RBEntry("Failed to create part")
   public static final String ERROR_CREATING_PART = "ERROR_CREATING_PART";

   @RBEntry("The part number is not unique.  Please choose a unique part number.")
   public static final String NUMBER_NOT_UNIQUE = "NUMBER_NOT_UNIQUE";

   @RBEntry("To add a child part to the list, enter a number and hit the Search button or &lt;tab&gt; or &lt;enter&gt; keys, or use the actions in the toolbar. A minimum number of characters must be entered before the search will begin.")
   @RBComment("This help message is displayed in the edit strcuture client. It is Not online help.")
   public static final String EDIT_STRUCTURE_HELP = "EDIT_STRUCTURE_HELP";

   @RBEntry("ATTENTION: No Results Found\nPlease try a different search.")
   @RBComment("An error message displayed as pop up")
   public static final String EDIT_STRUCTURE_NO_RESULTS = "EDIT_STRUCTURE_NO_RESULTS";

   @RBEntry("CONFIRM: Child Already Exists. Add again?\nA part you are adding is already a child of the parent.")
   @RBComment("A pop up error message used by edit structure client")
   public static final String EDIT_STRUCTURE_CHILD_EXISTS = "EDIT_STRUCTURE_CHILD_EXISTS";

   @RBEntry("Part Master")
   @RBComment("Part Master")
   public static final String WTPARTMASTER_TABLEVIEW_LABEL = "WTPARTMASTER_TABLEVIEW_LABEL";

   @RBEntry("Default Part Master View")
   @RBComment("Default Part Master View")
   public static final String WTPARTMASTER_TABLEVIEW_NAME = "WTPARTMASTER_TABLEVIEW_NAME";

   @RBEntry("Default Part Master Search Table View")
   @RBComment("Default Part Master Search Table View")
   public static final String WTPARTMASTER_TABLEVIEW_DESC = "WTPARTMASTER_TABLEVIEW_DESC";

   @RBEntry("Nothing is selected.")
   @RBComment("Error message displayed when the user doesn't select any objects before launching the multi select action.")
   public static final String NONE_SELECTED_ERROR = "NONE_SELECTED";

   @RBEntry("Minimum Required")
   @RBComment("Minimum Number of choices required for the option")
   public static final String MINIMUM_REQUIRED_LABEL = "MINIMUM_REQUIRED_LABEL";

   @RBEntry("Maximum Allowed")
   @RBComment("Maximum Number of choices allowed for the option")
   public static final String MAXIMUM_ALLOWED_LABEL = "MAXIMUM_ALLOWED_LABEL";

   /**
    * Create Shared Part Wizard action
    **/
   @RBEntry("New Shared Part")
   @RBComment("Used as the label for the New Shared Part Wizard")
   public static final String PRIVATE_CONSTANT_316 = "part.createSharedPart.description";

   @RBEntry("New Shared Part")
   @RBComment("Used as the label for the New Shared Part Wizard")
   public static final String PRIVATE_CONSTANT_317 = "part.createSharedPart.title";

   @RBEntry("New Shared Part")
   @RBComment("Used as the tooltip for the New Shared Part Wizard")
   public static final String PRIVATE_CONSTANT_318 = "part.createSharedPart.tooltip";

   @RBEntry("height=750,width=650")
   @RBPseudo(false)
   @RBComment("DO NOT TRANSLATE")
   public static final String PRIVATE_CONSTANT_319 = "part.createSharedPart.moreurlinfo";

   @RBEntry("CONFIRM: Changing Units from 'each' will force your Reference Designators to be deleted!\nDo you want to continue?")
   @RBComment("A pop up confirmation message used by edit structure client")
   public static final String CONFIRM_UNITS_CHANGE_WITH_REF_DES = "CONFIRM_UNITS_CHANGE_WITH_REF_DES";

   /**
    * Clicking the Apply button on a New Multi Parts wizard should reset the wizard to the initial step
    * Overridden the Apply button in order to redirect the user to the first step
    **/
   @RBEntry("<u class='mnemonic'>A</u>pply")
   @RBComment("Used for the text on the Apply wizard button.  The <U class=?mnemonic?> </U> tag should be put around the character that is the access key.")
   public static final String PRIVATE_CONSTANT_320 = "part.multiPartApplyButton.description";

   @RBEntry("a")
   @RBPseudo(false)
   @RBComment("Mnemonic for the Apply wizard button. This should be a character that matches the character surrounded by the <U class=?mnemonic?> </U> tag in the value line above.")
   public static final String PRIVATE_CONSTANT_321 = "part.multiPartApplyButton.hotkey";

   /**
    * Clicking the Back button on a New Multi Parts wizard should skip the nameNumberValidation
    * Overridden the Back button
    **/
   @RBEntry("<u class='mnemonic'>B</u>ack")
   @RBComment("Used for the text on the Back wizard button.  The <U class=?mnemonic?> </U> tag should be put around the character that is the access key.")
   public static final String PRIVATE_CONSTANT_322 = "part.multiPartprevButton.description";

   @RBEntry("b")
   @RBPseudo(false)
   @RBComment("Mnemonic for the Back wizard button. This should be a character that matches the character surrounded by the <U class=?mnemonic?> </U> tag in the value line above.")
   public static final String PRIVATE_CONSTANT_323 = "part.multiPartprevButton.hotkey";

   /**
    * Edit Multiple Parts Wizard Buttons
    **/
   @RBEntry("Check <u class='mnemonic'>I</u>n")
   @RBComment("Used for the text on the Check In wizard button.  The <U class=mnemonic> </U> tag should be put around the character that is the access key.")
   public static final String PRIVATE_CONSTANT_324 = "part.checkinButton.description";

   @RBEntry("i")
   @RBPseudo(false)
   @RBComment("Mnemonic for the Check In wizard button. This should be a character that matches the character surrounded by the <U class=mnemonic> </U> tag in the value line above.")
   public static final String PRIVATE_CONSTANT_325 = "part.checkinButton.hotkey";

   @RBEntry("Check In")
   @RBComment("Used for the tooltip on the Check In wizard button.")
   public static final String PRIVATE_CONSTANT_326 = "part.checkinButton.tooltip";

   @RBEntry("<u class='mnemonic'>S</u>ave")
   @RBComment("Used for the text on the Save wizard button.  The <U class=mnemonic> </U> tag should be put around the character that is the access key.")
   public static final String PRIVATE_CONSTANT_327 = "part.saveButton.description";

   @RBEntry("s")
   @RBPseudo(false)
   @RBComment("Mnemonic for the Save wizard button. This should be a character that matches the character surrounded by the <U class=mnemonic> </U> tag in the value line above.")
   public static final String PRIVATE_CONSTANT_328 = "part.saveButton.hotkey";

   @RBEntry("Save")
   @RBComment("Used for the tooltip on the Save wizard button.")
   public static final String PRIVATE_CONSTANT_329 = "part.saveButton.tooltip";

   @RBEntry("<u class='mnemonic'>C</u>ancel")
   @RBComment("Used for the text on the Cancel wizard button.  The <U class=mnemonic> </U> tag should be put around the character that is the access key.")
   public static final String PRIVATE_CONSTANT_330 = "part.editCancelButton.description";

   @RBEntry("c")
   @RBPseudo(false)
   @RBComment("Mnemonic for the Cancel wizard button. This should be a character that matches the character surrounded by the <U class=mnemonic> </U> tag in the value line above.")
   public static final String PRIVATE_CONSTANT_331 = "part.editCancelButton.hotkey";

   @RBEntry("Cancel")
   @RBComment("Used for the tooltip on the edit Cancel wizard button.")
   public static final String PRIVATE_CONSTANT_332 = "part.editCancelButton.tooltip";

   @RBEntry("Paste Action Failed")
   @RBComment(" Error message title unable to paste")
   public static final String PASTE_ACTION_FAILURE = "PASTE_ACTION_FAILURE";

   @RBEntry("Paste Action Partially Failed")
   @RBComment(" Error message title unable to paste")
   public static final String PASTE_ACTION_PARTIAL_FAILURE = "PASTE_ACTION_PARTIAL_FAILURE";

   @RBEntry("There are no objects on the clipboard to paste")
   @RBComment(" Error message for no objects selected to be pasted")
   public static final String NO_OBJECTS_IN_CLIPBOARD = "NO_OBJECTS_IN_CLIPBOARD";

   @RBEntry("Some objects on the clipboard do not have a valid relationship defined with the target object")
   @RBComment(" Error message for not all valid objects selected to be pasted")
   public static final String SOME_INVALID_OBJECTS_SELECTED_TO_PASTE = "SOME_INVALID_OBJECTS_SELECTED_TO_PASTE";

   @RBEntry("Option Rules")
   @RBComment("option rules column heading")
   public static final String OPTION_RULES = "OPTION_RULES";

   @RBEntry("Participate In Build")
   @RBComment("Participate In Build column heading")
   public static final String PARTICIPATE_IN_BUILD = "PARTICIPATE_IN_BUILD";

   @RBEntry("*Phantom Manufacturing Part")
   @RBComment("This string is used for the Phantom required label in the jsp page.")
   public static final String PHANTOM = "PHANTOM";

   @RBEntry("Expansion Criteria")
   @RBComment("Used as a label for Expansion Criteria action popup")
   public static final String PRIVATE_CONSTANT_333 = "part.showExpansionCriteria.title";

   @RBEntry("Expansion Criteria")
   public static final String PRIVATE_CONSTANT_334 = "part.showExpansionCriteria.description";

   @RBEntry("Display Expansion Criteria")
   @RBComment("Used as tooltip for the action")
   public static final String PRIVATE_CONSTANT_335 = "part.showExpansionCriteria.tooltip";

   @RBEntry("height=400,width=600")
   @RBPseudo(false)
   @RBComment("DO NOT TRANSLATE")
   public static final String PRIVATE_CONSTANT_336 = "part.showExpansionCriteria.moreurlinfo";

   @RBEntry("{0}, {1}")
   @RBComment("Used to build a list of values separated by a separator")
   public static final String MULTIPLE_VALUES = "MULTIPLE_VALUES";

   /**
    * Edit Alternate Table from 3rd level Nav
    **/
   @RBEntry("Edit")
   @RBComment("Used as the label for the edit action for a part")
   public static final String PRIVATE_CONSTANT_337 = "object.editReplacement.description";

   @RBEntry("Edit Alternate")
   @RBComment("Used as the label for the edit action for a part")
   public static final String PRIVATE_CONSTANT_338 = "object.editReplacement.title";

   @RBEntry("Edit Alternate Link Attributes")
   @RBComment("Used as the tooltip for the edit action for a part")
   public static final String PRIVATE_CONSTANT_339 = "object.editReplacement.tooltip";

   @RBEntry("multi_update.gif")
   @RBPseudo(false)
   @RBComment("Icon for the edit part action (for toolbars)")
   public static final String PRIVATE_CONSTANT_340 = "object.editReplacement.icon";

   @RBEntry("height=500,width=600")
   @RBPseudo(false)
   @RBComment("DO NOT TRANSLATE")
   public static final String PRIVATE_CONSTANT_341 = "object.editReplacement.moreurlinfo";

   @RBEntry("ATTENTION: Required Information Is Missing. \n\nName field is empty for Number:\"{0}\".\nEnter information for all fields indicated by an asterisk (*).")
   @RBComment("Message should prompt to user when Name field is empty but Number field has a valid value.")
   public static final String CREATE_MULTI_PART_NAME_VALIDATION_ERROR = "108";

   @RBEntry("Selected part \"{0}\" could not be added to list,as it is new in Workspace.")
   @RBComment("Message should promt when user tries to add newly created part in workspace.")
   public static final String ADD_PART_FAILED = "109";

   @RBEntry("ATTENTION: Required Information Is Missing. \n\nNumber field is empty for Name:\"{0}\".\nEnter information for all fields indicated by an asterisk (*).")
   @RBComment("Message should prompt to user when Number field is empty but Name field has a valid value.")
   public static final String CREATE_MULTI_PART_NUMBER_VALIDATION_ERROR = "110";

   @RBEntry("ATTENTION: Required information is missing \n\nYou must specify valid information for all required fields indicated by an asterisk(*)")
   @RBComment("Message should prompt user when Name field and Number field are empty on all rows.")
   public static final String CREATE_MULTI_PART_NAME_WITH_NUMBER_VALIDATION_ERROR = "111";

   @RBEntry("Current user has no permissions to create New View Version of object \"{0}\".")
   @RBArgComment0("The object ID")
   public static final String NO_PERMISSION_TO_CREATE_VIEW_VERSION = "NO_PERMISSION_TO_CREATE_VIEW_VERSION";

   @RBEntry("Event")
   @RBComment("Event Type of Alternate History")
   public static final String EVENT = "112";

   @RBEntry("Alternate History")
   @RBComment("Alternate History Table Title")
   public static final String ALTERNATE_HISTORY_TABLE = "113";

   @RBEntry("Event Date")
   @RBComment("Event Date of Alternate History")
   public static final String EVENT_DATE = "114";

   @RBEntry("User")
   @RBComment("Alternate History User")
   public static final String ALTERNATE_HISTORY_USER = "115";

   @RBEntry("Create Multipart View")
   @RBComment("Heading Label for Create Multi Part View in customize table.")
   public static final String CREATE_MULTI_PART_VIEW = "116";

   @RBEntry("Edit Multipart View")
   @RBComment("Heading Label for Edit Multi Part View in customize table.")
   public static final String EDIT_MULTI_PART_VIEW = "117";

   @RBEntry("CONFIRM: You have not clicked Apply. Changes will not persist.\nAre you sure you want to continue?")
   @RBComment("A pop up confirmation message used by edit structure client for navigation in pagination.")
   public static final String CONFIRM_NAVIGATION = "CONFIRM_NAVIGATION";

   @RBEntry("*Stop Effectivity Propagation")
   @RBComment("Stop Effectivity Propagation Column")
   public static final String STOP_EFFECTIVITY_R_PROPAGATION = "118";

   @RBEntry("Comment")
   @RBComment("used for the editing of comments on the doc references table")
   public static final String PART_COMMENT_TEXTAREA_HEADER = "119";

   @RBEntry("ATTENTION: Quantity value exceeds the limit of {0}. ")
   @RBComment("Message should prompt to user when quantity field is greater.")
   public static final String QUANTITY_LIMIT_VALIDATION = "120";

   @RBEntry("ATTENTION: The reference designator count specified is more than the quantity limit of {0}.  ")
   @RBComment("Message should prompt to user when quantity field is greater.")
   public static final String REFDESIG_EXCEEDS_QUANTITY_LIMIT = "121";

   @RBEntry("ATTENTION: Quantity value entered {0} is more than Reference Designator {1}.\n\n Click OK to store previous quantity {2} or click Cancel to continue with the same quantity {3}")
   @RBComment("Message should prompt user that quantity value entered is more than the Reference Designator so previous value is stored.")
   public static final String QUANTITY_MORE_VALIDATION = "122";

   @RBEntry("Edit Alternate")
   @RBComment("Edit Alternate")
   public static final String EDIT_ALTERNATE = "123";

   @RBEntry("Organization ID")
   @RBComment("Lable for Organization Column in edit Alternate")
   public static final String ORG_ID = "124";

   @RBEntry("Assembly")
   @RBComment("In Related Substitutes Table group of 4 columns in one column namely:- Assembly Name,Number,Organization and Context")
   public static final String ASSEMBLY = "125";

   @RBEntry("Substitute Number")
   @RBComment("In Related Substitutes Table display substitute Number instead of just number.")
   public static final String SUBSTITUTE_NUMBER = "126";

   @RBEntry("Substitute Organization ID")
   @RBComment("In Related Substitutes Table display substitute Number instead of just number.")
   public static final String SUBSTITUTE_ORGANIZATION_ID = "127";

   @RBEntry("Substitute Name")
   @RBComment("In Related Substitutes Table display substitute Number instead of just number.")
   public static final String SUBSTITUTE_NAME = "128";

   @RBEntry("Substitute-For Number")
   @RBComment("In Related Substitutes Table display substitute Number instead of just number.")
   public static final String SUBSTITUTEFOR_NUMBER = "129";

   @RBEntry("Substitute-For Organization ID")
   @RBComment("In Related Substitutes Table display substitute Number instead of just number.")
   public static final String SUBSTITUTEFOR_ORGANIZATION_ID = "130";

   @RBEntry("Substitute-For Name")
   @RBComment("In Related Substitutes Table display substitute Number instead of just number.")
   public static final String SUBSTITUTEFOR_NAME = "131";

   @RBEntry("Open in")
   public static final String PRIVATE_CONSTANT_342 = "object.more parts toolbar actions open.description";

   @RBEntry("Open in")
   public static final String PRIVATE_CONSTANT_343 = "object.more parts toolbar actions open.tooltip";

   @RBEntry("Add to")
   public static final String PRIVATE_CONSTANT_344 = "object.more parts toolbar actions add.description";

   @RBEntry("Add to")
   public static final String PRIVATE_CONSTANT_345 = "object.more parts toolbar actions add.tooltip";

   @RBEntry("Compare")
   public static final String PRIVATE_CONSTANT_346 = "object.more parts actions compare.description";

   @RBEntry("Compare")
   public static final String PRIVATE_CONSTANT_347 = "object.more parts actions compare.tooltip";

   @RBEntry("New")
   public static final String PRIVATE_CONSTANT_348 = "object.more parts toolbar actions new.description";

   @RBEntry("New")
   public static final String PRIVATE_CONSTANT_349 = "object.more parts toolbar actions new.tooltip";

   @RBEntry("Create CAD Document")
   @RBComment("Label on check box in New Part wizard to choose whether to create a new CAD document also.")
   public static final String CREATE_CAD_DOC_FROM_NEW_PART_LABEL = "CREATE_CAD_DOC_FROM_NEW_PART_LABEL";

   @RBEntry("classify.gif")
   @RBPseudo(false)
   @RBComment("Icon for Classification Attributes in Create New Multiple Part Wizard")
   public static final String PRIVATE_CONSTANT_350 = "part.setClassificationAttributesForMultiPart.icon";

   @RBEntry("Set Classification Attributes")
   @RBComment("Description for Classification Attributes in Create New Multiple Part Wizard")
   public static final String PRIVATE_CONSTANT_351 = "part.setClassificationAttributesForMultiPart.description";

   @RBEntry("Set Classification Attributes")
   @RBComment("ToolTip for Classification Attributes in Create New Multiple Part Wizard")
   public static final String PRIVATE_CONSTANT_352 = "part.setClassificationAttributesForMultiPart.tooltip";

   @RBEntry("height=375,width=485")
   @RBPseudo(false)
   @RBComment("Classification Attributes")
   public static final String PRIVATE_CONSTANT_353 = "part.setClassificationAttributesForMultiPart.moreurlinfo";

   @RBEntry("Set Classification Attributes")
   @RBComment("Used as the label for 2nd step of Set Classification Wizard in New Multiple Part Wizard")
   public static final String PRIVATE_CONSTANT_354="part.setClassification.WIZARD_STEP_LABEL";

   @RBEntry("Select Classifications ")
   @RBComment("Select Classifications")
   public static final String PRIVATE_CONSTANT_355="part.selectClassificationattributesWizStepForMultiPart";

    @RBEntry("Set Classification")
   @RBComment("Title of Wizard Set Classification in New Multi Part Wizard")
   public static final String PRIVATE_CONSTANT_356 = "part.setClassificationAttributes.title";

   @RBEntry("*Collapsible")
   @RBComment("This string is used for the Collapsible required label in the jsp page.")
   public static final String COLLAPSIBLE_R_COLUMN_LABEL = "part.createMultiPart.Collapsible";

   @RBEntry("Maximum Allowed")
   @RBComment("This string is used for the maximumAllowed label in the jsp page.")
   public static final String MaximumAllowed_R_COLUMN_LABEL = "part.createMultiPart.maximumAllowed";

   @RBEntry("Minimum Required")
   @RBComment("This string is used for the minimumRequired label in the jsp page.")
   public static final String MinimumRequired_R_COLUMN_LABEL = "part.createMultiPart.minimumRequired";

   @RBEntry("Parts Lists")
   @RBComment("Used in the 3rd level nav bar under 'Related items' and as the table title")
   public static final String PRIVATE_CONSTANT_357 = "part.relatedPartsLists.description";
   
   @RBEntry("Missing Objects")
   public static final String MISSING_OBJECT_TABLE = "persistedCollectable.missingObjectsTable.description";

   /**
    * Column headers for the related Parts Lists table (3rd level nav)
    **/
   @RBEntry("Version")
   public static final String PRIVATE_CONSTANT_358 = "part.relatedPartsLists.VERSION";

   @RBEntry("Context")
   public static final String PRIVATE_CONSTANT_359 = "part.relatedPartsLists.CONTEXT";

   @RBEntry("State")
   public static final String PRIVATE_CONSTANT_360 = "part.relatedPartsLists.STATE";

   @RBEntry("Team")
   public static final String PRIVATE_CONSTANT_361 = "part.relatedPartsLists.TEAM";

   @RBEntry("Last Modified")
   public static final String PRIVATE_CONSTANT_362 = "part.relatedPartsLists.LAST_UPDATED";

   @RBEntry("Association")
   public static final String PRIVATE_CONSTANT_363 = "part.relatedPartsLists.ASSOCIATION";

   @RBEntry("Configurable Module")
   @RBComment("This is a label for Configurable Module column")
   public static final String GENERICTYPE = "364";

    /**
     * Build status glyph
     **/
    @RBEntry("Part Build Status")
    @RBComment("Table column header for data that indicates if the object is build")
    public static final String BUILD_STATUS_TITLE = "BUILD_STATUS_TITLE";
    /**
     * Attribute(Service Kit, Serviceable) For Part. B-88847
     */
    @RBEntry("Service Kit")
    @RBComment("This string is used for the servicekit label in the jsp page")
    public static final String SERVICE_KIT_COLUMN_LABEL = "SERVICE_KIT_COLUMN_LABEL";

    @RBEntry("Serviceable")
    @RBComment("This string is used for the serviceable label in the jsp page")
    public static final String SERVICEABLE_COLUMN_LABEL = "SERVICEABLE_COLUMN_LABEL";

    @RBEntry("Publish to CAD")
    @RBComment("The title of the action")
    public static final String PUBLISH_TO_CAD_TITLE = "part.publishToCAD.title";

    @RBEntry("Publish to CAD")
    @RBComment("The description of the action")
    public static final String PUBLISH_TO_CAD_DESC = "part.publishToCAD.description";

    @RBEntry("Publish to CAD")
    @RBComment("The tooltip for the action")
    public static final String PUBLISH_TO_CAD_TOOLTIP = "part.publishToCAD.tooltip";

    @RBEntry("One or more selected objects are invalid for publishing to CAD. The valid parts selected are queued to build a corresponding CAD structure. See the Event Manager for details.")
    @RBComment("Message displayed if invalid objects are selected when invoking the Publish to CAD action")
    public static final String INVALID_SELECTED_OBJECTS_WARNING = "INVALID_SELECTED_OBJECTS_WARNING";

    @RBEntry("The selected objects are invalid for publishing to CAD. Only parts that are not checked out, and are the latest iteration of the latest version are valid.")
    @RBComment("Message displayed when no valid parts are selected when invoking the Publish to CAD action")
    public static final String NO_VALID_OBJECTS_SELECTED_ERROR = "NO_VALID_OBJECTS_SELECTED_ERROR";

    @RBEntry("The selected parts are queued to build a corresponding CAD structure. See the Event Manager for details.")
    @RBComment("Message on the yellow banner displayed on part info page when parts are selected to be published to CAD from Check in UI")
    public static final String MESSAGE_PUBLISH_TO_CAD = "MESSAGE_PUBLISH_TO_CAD";

    @RBEntry("Parts queued for Publish to CAD")
    @RBComment("Title on the yellow banner displayed on part info page when parts are selected to be published to CAD from Check in UI")
    public static final String CONFIRM_PUBLISH_TO_CAD = "CONFIRM_PUBLISH_TO_CAD";

    @RBEntry("No valid objects selected for Publish to CAD")
    @RBComment("Title on the yellow banner displayed on part info page when parts are selected to be published to CAD from Check in UI")
    public static final String ERROR_PUBLISH_TO_CAD = "ERROR_PUBLISH_TO_CAD";

    @RBEntry("ERROR: Unable to publish the selected parts to CAD")
    @RBComment("Title on the yellow banner displayed on part info page when parts are selected to be published to CAD from Check in UI")
    public static final String UNABLE_TO_PUBLISH_TO_CAD = "UNABLE_TO_PUBLISH_TO_CAD";

    @RBEntry("Cannot decrease the quantity below the number of occurrences for the child part.")
    @RBComment("Message for quantity validation.")
    public static final String QUANTITY_CAN_NOT_BE_LESS_THAN_OCCURRENCES = "QUANTITY_CAN_NOT_BE_LESS_THAN_OCCURRENCES";

    @RBEntry("Classification is required. You can set it using the Set Classification Attributes action.")
    @RBComment("This string is used to show alert on multi part create wizard for validation message when classification attribute is required")
    public static final String CLASSIFICATION_REQUIRED = "CLASSIFICATION_REQUIRED";

    // resource entry for replace with alternate substitute
    @RBEntry("Replace with Alternate/Substitute")
    @RBComment("Used as the label for Replace with Alternate/Substitute")
    public static final String PRIVATE_CONSTANT_365 = "part.replaceWithAlternateSubstitute.description";

    @RBEntry("Replace with Alternate/Substitute")
    @RBComment("Used as the title for Replace with Alternate/Substitute")
    public static final String PRIVATE_CONSTANT_366 = "part.replaceWithAlternateSubstitute.title";

    @RBEntry("OK")
    @RBComment("Used as the label for the Ok button")
    public static final String PRIVATE_CONSTANT_367 = "part.replaceWithAltSubOkButton.description";

    @RBEntry("OK")
    @RBComment("Used as the title for Ok button")
    public static final String PRIVATE_CONSTANT_368 = "part.replaceWithAltSubOkButton.title";

    @RBEntry("Cancel")
    @RBComment("Used as the label for the Cancel button")
    public static final String PRIVATE_CONSTANT_369 = "part.replaceWithAltSubCancelButton.description";

    @RBEntry("Cancel")
    @RBComment("Used as the title for Cancel button")
    public static final String PRIVATE_CONSTANT_370 = "part.replaceWithAltSubCancelButton.title";

    @RBEntry("Child Part:")
    @RBComment("Label for child part on replace with alternate subtitute client")
    public static final String CHILD_PART_LABEL = "371";

    @RBEntry("Parent Assembly:")
    @RBComment("Label for parent replace with alternate subtitute client")
    public static final String PARENT_ASSEMBLY_LABEL = "372";
    
    @RBEntry("*Team Template")
    @RBComment("This string is used for the team template required label in the jsp page")
    public static final String TEAM_TEMPLATE_COLUMN_LABEL = "373";

    @RBEntry("Missing Object Status")
    public static final String MISSING_OBJECT_STATUS = "missingObjectStatus";
    
    
    @RBEntry("This object is member of variant baseline(s) {0}. It will be removed from all the relevant variant baselines if converted to a configurable module.")
    public static final String FLOATING_BASLINE_MEMBER_CONFIRMATION_MESSAGE = "FLOATING_BASLINE_MEMBER_CONFIRMATION_MESSAGE";

    @RBEntry("Cannot proceed converting to a configurable module as this object is member of locked variant baseline(s) {0}.")
    public static final String FLOATING_BASLINE_MEMBER_LOCK_ERROR_MESSAGE = "FLOATING_BASLINE_MEMBER_LOCK_ERROR_MESSAGE";

    @RBEntry("ATTENTION: Required information is missing in all the rows.\nEnter value in at least one row.")
    @RBComment("Message should prompt user that fields are empty on all rows.")
    public static final String CREATE_MULTI_PART_VALIDATION_ERROR = "CREATE_MULTI_PART_VALIDATION_ERROR";
}
