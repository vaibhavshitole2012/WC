﻿Este fichero zip contiene información del paquete extraída de Windchill. Para ver el contenido de este paquete, se puede utilizar el visor html fuera de línea incluido en este fichero zip. También se puede acceder a los ficheros de contenido directamente e importarlos al sistema.

Aunque este proceso puede variar dependiendo de la configuración del sistema, los siguientes pasos básicos pueden ser útiles para navegar hasta la información del paquete:

1. Con una utilidad para ficheros zip, como, por ejemplo, WinZip, extraiga este paquete a una carpeta nueva del disco duro.

2. Navegue hasta la ubicación seleccionada para el fichero zip del paquete. La carpeta contendrá una lista de datos. Hay dos maneras de ver el fichero zip del paquete:
- Para ver la información del paquete en el explorador Web, pulse dos veces en el fichero index.html. El paquete se abrirá en el explorador Web por defecto del sistema.
- Si no desea ver la información del paquete con el visor fuera de línea, abra la carpeta Contents. Esta carpeta contiene todas las representaciones, ficheros de artículos y adjuntos del paquete. Puede utilizar esta carpeta para importar los ficheros del paquete directamente al sistema.

3. Si ha abierto el fichero index.html, se abrirá la página Package Details en el explorador.

Si desea obtener más información sobre la información del paquete disponible en la vista fuera de línea, pulse en el botón de ayuda que se encuentra en la parte superior de la página.
