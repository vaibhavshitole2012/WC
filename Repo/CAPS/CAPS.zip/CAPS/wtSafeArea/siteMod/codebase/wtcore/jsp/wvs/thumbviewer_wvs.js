///
// javascript functions to support thumbnail viewer from property pages
//

// //////////////////////////////////////////////////////////////
// determine which browser we are running in - this global
// value _isIE is used elsewhere in the pvcadview scripts
// //////////////////////////////////////////////////////////////
var _isIE = false;
var _is64bitIE = false;
var _isFirefox = false;
var _isChrome = false;
var _isEdge = false;

var usrAgent = navigator.userAgent;
if (usrAgent.indexOf("MSIE") != -1) { // MSIE has been removed from IE 11
    _isIE = true;
    if (usrAgent.indexOf("Win64") != -1) {
        _is64bitIE = true;
    }
} else if (usrAgent.indexOf("Trident") != -1) { // Trident exists from IE8 >
    _isIE=true;
    if (usrAgent.indexOf("Win64") != -1) {
        _is64bitIE = true;
    }
} else if (usrAgent.indexOf('Firefox') > -1) {
    _isFirefox = true;
} else if (usrAgent.indexOf('Chrome') > -1 && usrAgent.indexOf('Edge') == -1) {
    _isChrome = true;
} else if (usrAgent.indexOf('Edge') > -1) {
    _isEdge = true;
}

Ext.ns('PTC.wvs');

var logger = log4javascript.getLogger("PTC.wvs");

// //////////////////////////////////////////////////////////////
// document-specific functions
// //////////////////////////////////////////////////////////////
var _docType="application/x-pvlite9-ed";
              // defines the type of viewable (drawing or model)
var _docPluginVersion;    // version string of the form '1.2.3.4'
var _docPluginURL;    // version string of the form '1.2.3.4'
var _docAction;
var g_pluginParams;
var _docOnLoadOverride;
var _docColorOption;
var _docGradColorOption;
var _docViewOrientationOption;
var _docAdditionalOption;
var g_downloaddir;
var _urllist;
var _visNavEvents = null;
var _windowBeforeUnloadOverride = null;
var _windowBeforeUnloadMsgFlag = true;
var _windowUnloadOverride = null;
var _local_UpgradeTitle = "A new version of Creo View is available for download";
var _local_UpgradeContinue = "Use currently installed viewer";
var _local_UpgradeInstall = "Upgrade viewer";
var _local_Install="Install Creo View";
var _local_Enable_SoftwareUpdate = "You must enable Software Update to install this plugin";
var _local_Install_Failed = "Creo View installation failed";
var _local_Unsupported_Browser = "Unsupported browser platform";
var _local_InitialisePlugin_Error = "An error occured initialising the Creo View plugin";
var _local_Restart_Needed = "You need to restart your browser to complete the Creo View installation";
var _local_nocheck= "Stop Checking for new versions";
var _local_ExitViaProductMenu="Creo View should be closed via the main menu.\nContinuing may result in lost data!";
var g_docLoadedAction=0;
var g_oldLoadedFunc=null;
var g_width=null;
var g_height=null;
var g_resetMainDivSize = false;
var g_proeLoadComplete=null;
var g_launchUrl = null;
var _isEmbededCreo = (navigator.appVersion.indexOf("ProE") != -1) ? true : false;
var _isVisTab =false; //Defines if this is being launched from a visualization Tab
var _isMPMLink =false; // Defines if this is an MPMLink object
var _useWebGL =false; //Defines if the WebGL viewer should be used
// Temporary don't run any plugins unless on the Windows platform
var g_platformSupported=false;
var isLoadingVisTabComplete=false;
var WebGlStartTime=0;
var WebGlLoadDuration=0;
var featureSelection = {};

// This function will return Windchill Base URL.
function getBaseURL() {
            if ('baseURI' in document) {
                return document.baseURI;
            }
            else {
                var baseTags = document.getElementsByTagName ("base");
                if (baseTags.length > 0) {
                    return baseTags[0].href;
                }
                else if (location.href.length>0) {
                var url = location.href;
        		var pathname = location.pathname;
        		var index1 = url.indexOf(pathname);
        		var index2 = url.indexOf("/", index1 + 1);
        		var baseLocalUrl = url.substr(0, index2);
        		return baseLocalUrl + "/";
                }
				else {
				console.error ("The function getBaseURL() is not able to return the Windchill base URL. \n It is returning the full URL:" + window.location.href);
		     	}
            }
        }


function PV_InsertPlugin(params, img, width, height, downloaddir, versionstrings, pviewHome)
{
    logger.trace("Calling PV_Insert plugin");

    setPVLiteWin(self, window.name);
    if( width.indexOf("%") < 0 && width.indexOf("px") < 0 ) width += "px";
    if( height.indexOf("%") < 0 && height.indexOf("px") < 0 ) height += "px";
    g_width = width;
    g_height = height;
    g_pluginParams = params;
    
    _isVisTab = g_pluginParams.indexOf("isVisTab") >= 0;
    _isMPMLink = g_pluginParams.indexOf("isMPMLink") >= 0;

    logger.debug("_isVisTab = " + _isVisTab);
    logger.debug("_isMPMLink = " + _isMPMLink);

    if (_isVisTab) {
       _useWebGL = PTC.wvs.webgl.isEnabledForVisTab();
    }
    
    // Creo 2.0 Mozilla based embedded browser does not support WebGL. 
    //We will filter out identifying it by forcing _useWebGL flag to false. 
    if(_useWebGL) {
        _useWebGL = !(usrAgent.indexOf("Gecko/ /2.0") >= 0);
    } 
    
    logger.debug("_useWebGL" + _useWebGL);

    var _mainHTMLstring = "";

    if (_useWebGL === true) {
        _mainHTMLstring +='<div id="pvmaindiv" style="position:relative;top:0;left:0;border-width:0px;border-style:none;width:'+width + ';height:'+height+'">';
        _mainHTMLstring += '<div id=pview_img style="position:relative;top:0;left:0;border-width:0px;border-style:none"></div>';
        _mainHTMLstring +='<div id="pvctl" style="visibility:hidden;position:absolute;top:0;left:0;width:100%;height:100%;zIndex=-1;border-width:0px;border-style:none">';
        _mainHTMLstring +='</div>';
        _mainHTMLstring +='</div>';
        window.onbeforeunload=webglBeforeUnload;
        window.onhashchange=webglHashChange;
        document.getElementById("wvs_pview_div").innerHTML = _mainHTMLstring;

        if (img != null && img != "")
            document.getElementById("pview_img").innerHTML = '<A HREF="'+_docAction+'" ><IMG SRC="'+img+'" style="border-height:0;border-width:0;border-style:none;" width=100% height=100% ></IMG></A>';
        docLoaded();
    } else {
        var _browser_type = "";
        var _browser_platform = "";
        var _imageOnly = false;
        var cookies = document.cookie;
        var pvVerChecked = cookies.indexOf("pvlite_version_checked");
        var pvVerRebootNeeded = cookies.indexOf("pvlite_reboot_needed");
        var pvVerPluginFailed = cookies.indexOf("pvlite_plugin_failed");
        g_downloaddir = downloaddir;
        var _docPluginDownloadURL = downloaddir + "/" + _docPluginURL;

        if (navigator.platform == "SunOS sun4u")
        {
            g_platformSupported=true;
            _browser_platform="sun4_solaris";
        }
        if (navigator.platform == "SunOS i86pc")
        {
            g_platformSupported=true;
            _browser_platform="sun_solaris_x32";
        }
        if (navigator.platform == "Win32")
        {
            g_platformSupported=true;
            if (_is64bitIE)
            {
                _browser_platform = "x86e_win64";
            }
            else
            {
                _browser_platform = "i486_nt";
            }
        }
        if (navigator.platform == "Win64")
        {
            g_platformSupported=true;
            _browser_platform = "x86e_win64";
        }
        if (navigator.platform.substring(0,5) == "HP-UX")
        {
            g_platformSupported=true;
            _browser_platform = "hpux11_pa32";
        }
        if (navigator.platform.substring(0,3) == "AIX")
        {
            _browser_platform = "ibm_rs6000";
        }
        /* J. Mosley: Do not popup an alert when the client platform is not supported.
                      Displaying the gif image is enough. */
        /*
        if (_browser_platform == "")
        {
            if (typeof _pvliteString_Unsupported_Browser != "undefined")
            {
                _local_Unsupported_Browser = _pvliteString_Unsupported_Browser;
            }
            window.alert(_local_Unsupported_Browser +"\n" + navigator.platform);
            return;
        }
        */

        if (_isFirefox) {
            _browser_type = "ns";
        } else if (_isIE) {
            _browser_type = "ie";
        }

        if (_browser_type == "" || _browser_platform == "")
        {
            _imageOnly = true;
        } else
        {
            var _browser = _browser_platform + "_" + _browser_type + "/";
            var vs = versionstrings;

            while(true)
            {
                var loc = vs.indexOf(";");

                var v = loc!=-1?vs.substring(0,loc):vs;
                if( v.indexOf(_browser) == 0 ) {
                    var versionLoc = v.lastIndexOf('/');

                    _docPluginVersion = v.substring(versionLoc+1);
                    _docPluginURL = v.substring(0,versionLoc);
                }

                if( loc == -1 ) break;
                vs = vs.substring(loc+1);
            }
        }

        //g_oldLoadedFunc = window.onload;
        //window.onload = docLoaded;

        if( (width == "100%") && (height == "100%") )
        {
            if (Ext.isIE && !_isVisTab) {
                var d = document,
                    e = d.documentElement;
                width = e.clientWidth + 'px';
                height = e.clientHeight + 'px';
            }
            // Disable F1 Help provided by the browser when running in full screen mode(onhelp is ie only and ignored by Firefox).
            document.body.onhelp=function keyhit(){ event.returnValue=false;};
            document.onkeypress = keyHit;
            if(!_isVisTab)
            {
                var tmp_override = window.onbeforeunload;
                if( tmp_override != pvBeforeUnload ) {
                    _windowBeforeUnloadOverride = tmp_override;
                    window.onbeforeunload=pvBeforeUnload;
                }
                _windowBeforeUnloadMsgFlag = !_isEmbededCreo;
            }
            if(Ext.isIE && !_isVisTab)
            {
                _mainHTMLstring +='<div id="iepvmaindiv" style="position:relative;top:0;left:0;border-width:0px;border-style:none;width:'+width + ';height:'+height+'">';
                if (typeof _isPvlite != "undefined")
                    window.onresize = ie_resize;
            }
            else
            {
                _mainHTMLstring += '<div style="position:relative;top:0;left:0;border-width:0px;border-style:none;width:'+width + ';height:'+height+'">';
            }
        }
        else
        {
            if(Ext.isIE && !_isVisTab)
            {
                _mainHTMLstring +='<div id="iepvmaindiv" style="position:relative;top:0;left:0;border-width:0px;border-style:none;width:'+width + ';height:'+height+'">';
                if (typeof _isPvlite != "undefined")
                    window.onresize = ie_resize;
            }
            else
            {
                g_resetMainDivSize = true;
                _mainHTMLstring +='<div id="pvmaindiv" style="position:relative;top:0;left:0;border-width:0px;border-style:none;">';
            }
        }

        if (_isIE)
        {
            var tmp_override = window.onunload;
            if( tmp_override != pvUnloadPage ) {
                _windowUnloadOverride = tmp_override;
                window.onunload=pvUnloadPage;
            }
        }

        //_mainHTMLstring += '<div id=pview_img style="position:relative;top:0;left:0;border-width:0px;border-style:none;width:'+width + ';height:'+height +'"></div>';
        _mainHTMLstring += '<div id=pview_img style="position:relative;top:0;left:0;border-width:0px;border-style:none"></div>';

        if(g_platformSupported==false)
        {
            if(img == null)
            {
                alert("Platform not supported");
            }
        }
        else
        {
            _mainHTMLstring +='<div align=center id=pview_upgrade style="position:relative;top:0;left:0;border-width:0px;border-style:none">';
            _mainHTMLstring +='</div>';

            var ieInstallpv = false;
            if (_isIE) {
                if (typeof _docPluginVersion == "undefined") {
                    if (pvVerChecked == "-1") ieInstallpv = true;
                }
            }
        
		g_docLoadedAction = 0 ;
		/* Replaced content as per PTC CS27008 Workaround with the above single line

            if ((_docPluginVersion && pvVerChecked == "-1" ) || ieInstallpv)
            {

                 var installPlugin = PTC.wvs.properties.getProperty('productview.version.checker.plugin.disabled');
                 if(installPlugin !== 'true' ) {
                     _mainHTMLstring +='<div id=checkpview style="visibility:hidden;position:absolute;top:2;left:2;zIndex=-1;width:0;height:0;border-style:none">';
                     _mainHTMLstring +=GetPvCheckHtml();
                     _mainHTMLstring +='</div>';
                     g_docLoadedAction = 1 ;
                 }
            }
			*/
            _mainHTMLstring +='<div id=runpview style="visibility:hidden;position:absolute;top:0;left:0;width:100%;height:100%;zIndex=-1;border-width:0px;border-style:none">';
            _mainHTMLstring +='</div>';
            _mainHTMLstring +='</div>';

        }

        document.getElementById("wvs_pview_div").innerHTML = _mainHTMLstring;

        if (img != null && img != "")
            document.getElementById("pview_img").innerHTML = '<A HREF="'+_docAction+'" ><IMG SRC="'+img+'" style="border-height:0;border-width:0;border-style:none;" width=100% height=100% ></IMG></A>';

        docLoaded();
    }
}

// Resize the main Creo View DIV when the window is re-sized.  Only needs to be done
// When the browser is inetnet explorer.
function ie_resize() {
    var d = document;
    var e = d.documentElement;
    var width = e.clientWidth;
    var height = e.clientHeight;
    document.getElementById('iepvmaindiv').style.height =height+"px";
    document.getElementById('iepvmaindiv').style.width =width+"px";
}

function webglHashChange() {
    
    logger.trace("webglHashChange");
    StopWebGLViewer("pvctl");
}

function webglBeforeUnload()
{
    logger.trace("webglBeforeUnload");
}

    // This is for warning the user to exit PV using our Menu not the close button
function pvBeforeUnload()
{
    //This is code to set the window size in this sessions cookie.
    var mform = getMainForm();
    if(!mform.windowNameForCookie){
      mform.windowNameForCookie ={};
    }
    mform.windowNameForCookie.value = 'edrview_window';
    setWindowSizeCookie();

    if(_windowBeforeUnloadOverride) {
        var func = _windowBeforeUnloadOverride;
        _windowBeforeUnloadOverride = null;
        func();
    }

    if (typeof _pvliteString_ExitViaProductMenu != "undefined") {
        _local_ExitViaProductMenu = _pvliteString_ExitViaProductMenu;
    }
    else {
        _local_ExitViaProductMenu = bundleHandler.getBundleStringAndInserts('com.ptc.wvs.server.ui.uiResource.PVLITE_CLOSE_MAIN_MENU');
    }
    if( _windowBeforeUnloadMsgFlag )
       return _local_ExitViaProductMenu;
}

function pvUnloadPage()
{
    if(_windowUnloadOverride) {
        var func = _windowUnloadOverride;
        _windowUnloadOverride = null;
        func();
    }

    _windowUnloadOverride = null;
    try
    {
        // Need to set the div to empty to force the ref counting to work.
        document.getElementById("runpview").innerHTML="";
    }
    catch(e)
    {

    }
}

function pvUnloadPageCallback()
{
    try {
       // set innerHTML to "" to make IE unload PV
       if( typeof(PTC) != "undefined" ) {
          PTC.navigation.un('historyChange', pvUnloadPageCallback);
          PTC.navigation.un('reloadpage', pvUnloadPageCallback);
       } else if( parent!=null && typeof(parent.PTC) != "undefined" ) {
          parent.PTC.navigation.un('historyChange', pvUnloadPageCallback);
          parent.PTC.navigation.un('reloadpage', pvUnloadPageCallback);
       } else if( top!=null && typeof(top.PTC) != "undefined" ) {
          top.PTC.navigation.un('historyChange', pvUnloadPageCallback);
          top.PTC.navigation.un('reloadpage', pvUnloadPageCallback);
       }
       document.getElementById("runpview").innerHTML="";
    } catch(e) {}
    return true;
}

function keyHit(event)
{

    if (event.keyCode == event.DOM_VK_F1)
    {
        // cancel browser app event handler for F1 key
        event.stopPropagation()
        event.preventDefault()
    }
}

function docLoaded()
{
    if (_useWebGL === true) {
        WebGlStartTime = Date.now();
        var gl_prop_start = g_pluginParams.indexOf("webGLClientObjToCall='")+"webGLClientObjToCall='".length;
        var gl_prop_end = g_pluginParams.indexOf("'",gl_prop_start);
        StartWebGLViewer("pvctl", g_pluginParams.substring(gl_prop_start,gl_prop_end), g_pluginParams);
        return;
    }
    if (g_oldLoadedFunc)
    g_oldLoadedFunc();

    // If not supported platform just return
    if(g_platformSupported==false)
    {
        return;
    }

    //window.alert("docLoaded readystate " + document.pvVerCtl.ReadyState);
    if (g_docLoadedAction == 0)
    {
        StartPview();
        return;
    }

    if (g_docLoadedAction == 1)
    {
        try
        {
            if (_isIE) {
                if (typeof document.pvVerCtl == "undefined") {
                    // No action required
                }
                else if (document.pvVerCtl.ReadyState == "undefined") {
                    // No action required
                }
                else  if (document.pvVerCtl.ReadyState != 4) {
                    StartPview();
                    return;
                }
            }
            else {
                 if (document.pvVerCtl.ReadyState != 4)
                 {
                     StartPview();
                     return;
                 }
            }

            var isInstalled = document.pvVerCtl.CheckPview(_docPluginVersion);
            var installedVersion = document.pvVerCtl.GetInstalledVersion();
            //window.alert("IsInstalled is " + isInstalled);

            var installPlugin = PTC.wvs.properties.getProperty('productview.version.checker.plugin.disabled');
            if(installPlugin == 'true' && isInstalled == 2) {
                StartPview();
            }

            if (isInstalled == 0) // Pview Not installed so need to install it
            {
                if (typeof _pvliteString_Install != "undefined")
                {
                    _local_Install = _pvliteString_Install;
                }
                else {
                    _local_Install = bundleHandler.getBundleStringAndInserts('com.ptc.wvs.server.ui.uiResource.PVLITE_INSTALL');
                }

                document.getElementById("pview_upgrade").innerHTML += '<A class=wizardlabel HREF="javascript:void(DoInstall())" TITLE="'+_docPluginVersion+'">'+_local_Install+'</A>';

                //Hard coding in a size of the div that holds content of the viz panel on the details pages to display install Link
                document.getElementById("pview_img").style.height="177px"
            }
            if (isInstalled == 1) //pview is installed and up to date so just run
            {
                StartPview();
            }
            if (isInstalled == 2) //pview is installed But can be upgraded
            {
                if (typeof _pvliteString_UpgradeContinue != "undefined")
                {
                    _local_UpgradeContinue = _pvliteString_UpgradeContinue;
                }
                else {
                    _local_UpgradeContinue = bundleHandler.getBundleStringAndInserts('com.ptc.wvs.server.ui.uiResource.PVLITE_UPGRADE_CONTINUE');
                }

                if (typeof _pvliteString_UpgradeTitle != "undefined")
                {
                    _local_UpgradeTitle = _pvliteString_UpgradeTitle;
                }
                else {
                    _local_UpgradeTitle = bundleHandler.getBundleStringAndInserts('com.ptc.wvs.server.ui.uiResource.PVLITE_UPGRADE_TITLE');
                }

                if (typeof _pvliteString_UpgradeInstall != "undefined")
                {
                    _local_UpgradeInstall = _pvliteString_UpgradeInstall;
                }
                else {
                    _local_UpgradeInstall = bundleHandler.getBundleStringAndInserts('com.ptc.wvs.server.ui.uiResource.PVLITE_UPGRADE_INSTALL');
                }
                document.getElementById("pview_upgrade").innerHTML +='<A class=wizardlabel HREF="javascript:void(DoInstall())" TITLE="'+_docPluginVersion+'">'+_local_UpgradeInstall+'</A><BR><A class=wizardlabel HREF="javascript:void(DoNotInstall())" TITLE="'+installedVersion+'">'+_local_UpgradeContinue+'</A><BR>';

                //Hard coding in a size of the div that holds content of the viz panel on the details pages to display install Link
                document.getElementById("pview_img").style.height="162px"
            }
        }
        catch(e)
        {
            StartPview();
        }
    }
}

function OnInstalledFinished( name , result ){
    if(result == 0)
    {
        PV_InsertPlugin(thumbnail3d, thumbnail, width, height, downloaddir, versionstrings, pviewhome,false);
    }
    else
    {
        alert("Download failed");
    }
}

function StopWebGLViewer(divID) {
    logger.debug("in StopWebGLViewer for DIV:" + divID);

    window.MyThingView.session.RemoveAllModels(true);
    window.MyThingView.widget = undefined;
    ThingView.DeleteSession(window.MyThingView.session);
    window.MyThingView.session = undefined;
}

function StartWebGLViewer(divID, visTabCallbackDivIn, pluginParameters) {

    logger.debug("in StartWebGLViewer for DIV: " + divID);
    logger.trace("in StartWebGLViewer for callback DIV: " + visTabCallbackDivIn);
    document.getElementById(divID).style.visibility = 'visible';

    if (window.MyThingView === undefined) {
        
        PTC.wvs.webgl.addContextMenuEventListener(divID, function(event) {  });
        
        window.MyThingView = new Object();
        
        PTC.wvs.webgl.getSession(divID, function(session) {
            
            window.MyThingView.session=session;
            
            initializeWebGLCache();
            
            var rp = document.getElementById("pvctl");

            // For PSB, PSC and PAR visTabCallbackDivIn variable will contain
            // correct div id to call
            var visTabCallbackDiv = document.getElementById(visTabCallbackDivIn);

            // Query for the DIV containing all the call back functions that support the
            // Visualization Tab. The assumption is a DIV under the
            // 'MSR.viz' DIV will contain the call back functions. Find the DIV that has
            // the OnLoadComplete function defined under the 'MSR.viz' DIV.
            if (!visTabCallbackDiv) {
                var visTabDiv = document.getElementById('MSR.viz');
                if (visTabDiv != null) {
                    var allVisTabChildDivs = visTabDiv.getElementsByTagName("div");
                    if (allVisTabChildDivs != null && allVisTabChildDivs.length > 0) {
                        for (var i=0;i < allVisTabChildDivs.length;++i) {
                            if (typeof allVisTabChildDivs[i].OnLoadComplete == 'function') {
                                visTabCallbackDiv = allVisTabChildDivs[i];
                                break;
                            }
                        }
                    }
                }
            }

            if (!visTabCallbackDiv) {
                // The DIV containing all the call back functions to support the Visualization Tab
                // doesn't exist. Assume within an iFrame supporting the Compare Part Structure UI.
                visTabCallbackDiv = window.parent.document.getElementById(visTabCallbackDivIn);
                
                if (!visTabCallbackDiv) {
                    if (!!window.vizObj && !!window.vizObj.vizPanel) {
                        visTabCallbackDiv = document.getElementById(vizObj.vizPanel);
                    }
                }

                if (!visTabCallbackDiv) {
                    throw "Unable to find the div with viz callbacks";
                }
                // Toolbar actions in the Compare Part Structure UI assumg the "document.pvctl" is an object.
                rp = new Object();
                document.pvctl=rp;
            }

            if (rp) {
                rp.ZoomToAll = function (delay) {
                    window.MyThingView.session.ZoomView(Module.ZoomMode.ZOOM_ALL, 1000.0);
                    logger.trace("ZoomToAll");
                }
                rp.ZoomToSelectedTime = function () {
                    //window.MyThingView.session.ZoomView(Module.ZoomMode.ZOOM_SELECTED, 1000.0);
                    logger.trace("ZoomToSelectedTime");
                }

                rp.ZoomToInstance = function(ids) {
                    logger.trace("ZoomToInstance");
                    logger.trace("propvalues: " + ids);
                    var idsValues = new Module.VectorString();
                    idsValues.push_back(ids);
                    window.MyThingView.session.ZoomToParts(idsValues);
                };

                rp.ZoomToAllTime = function () {
                    logger.trace("ZoomToAllTime");
                }
                rp.ZoomToSelected = function (flyTime) {
                    window.MyThingView.session.ZoomView(Module.ZoomMode.ZOOM_SELECTED, 1000.0);
                    logger.trace("ZoomToSelected");
                }
                rp.SetMode = function (mode) {
                    if (mode == "translate" || mode == "rotate")
                        window.MyThingView.session.SetDragMode(Module.DragMode.DRAG);
                    else if (mode == "select") {
                        window.MyThingView.session.SetDragMode(Module.DragMode.NONE);
                        window.MyThingView.session.ClearActions(); 
                    } else if (mode == "spincenter") {
                        window.MyThingView.session.SetSpinCenter();
                    } else if (mode == "zoomtowindow") {
                        window.MyThingView.session.ZoomView(Module.ZoomMode.ZOOM_WINDOW, 1000.0);
                        logger.trace("zoom to window");
                    } else {
                        logger.trace("SetMode: " + mode);
                    }
                }
                rp.SetRenderMode = function (mode) {
                    logger.debug("SetMode: " + mode);
                    if(mode=="shaded") {
                        window.MyThingView.widget.SetRenderMode(Module.RenderMode.SHADED, 0);
                    }
                }
                rp.DeSelectAll =  function() {
                    window.MyThingView.session.DeselectAllInstances();
               
                }
                rp.FindInstancesWithProperties =  function(allGroup, group, propName, propValues) {
                    logger.debug("propName: " + propName + ", propValues: " + propValues);
                    var propValueArr = new Module.VectorString();
                    for (var i=0;i<propValues.length;++i)
                    {
                        logger.trace("propvalues: " + propValues[i]);
                        propValueArr.push_back(propValues[i]);
                    }
                    var insts = window.MyThingView.widget.FindInstancesWithProperties(true, group, propName, propValueArr); // group
                    var results = [];
                    for (var i = 0; i < insts.size() ; i++) {
                        var ins = insts.get(i);
                        results.push(ins);
                        logger.trace("res: " + ins);
                    }

                    visTabCallbackDiv.OnFindInstances(results);
                }

                rp.SynchronousFindInstancesWithProperties =  function(allGroup, group, propName, propValues) {
                    logger.debug("propName: " + propName + ", propValues: " + propValues);
                    var propValueArr = new Module.VectorString();
                    for (var i=0;i<propValues.length;++i)
                    {
                        logger.trace("propvalues: " + propValues[i]);
                        propValueArr.push_back(propValues[i]);
                    }
                    var insts = window.MyThingView.widget.FindInstancesWithProperties(true, group, propName, propValueArr); // group
                    var results = [];
                    for (var i = 0; i < insts.size() ; i++) {
                        var ins = insts.get(i);
                        results.push(ins);
                        logger.trace("res: " + ins);
                    }

                    return results;
                }
                rp.GetPropertyValue = function (a,b,c) {
                    logger.debug("GetPropertyValue, a:" + a +", b: " + b + ", c: " + c);
                    var res = window.MyThingView.widget.GetPropertyValue(a,b,c);
                    logger.debug("GetPropertyValue, value: " + res);
                    return res;
                }
                rp.RestoreAllLocations = function () {
                    logger.debug("***RestoreAllLocations");
                    window.MyThingView.widget.UnsetLocation(true);
                }
                rp.CalculateBoundingBox = function() {
                    logger.debug("CalculateBoundingBox");
                    var propValueArr = new Module.VectorString();
                    var res = window.MyThingView.widget.CalculateBoundingBox(propValueArr);
                    logger.debug("CalculateBoundingBox: valid = " + res.valid);
                    var vals = "";
                    if(res.valid){
                        vals = (res.min.x + " " + res.min.y + " " + res.min.z + " " + res.max.x + " " + res.max.y + " " + res.max.z);
                    }
                    return vals;
                }
                rp.CalculateBoundingSphere = function() {
                    logger.debug("CalculateBoundingSphere");
                    var propValueArr = new Module.VectorString();
                    var res = window.MyThingView.widget.CalculateBoundingSphere(propValueArr);
                    logger.debug("CalculateBoundingSphere: valid = " + res.valid);
                    var vals = "";
                    if(res.valid){
                        vals = (res.center.x + " " + res.center.y + " " + res.center.z + " " + res.radius);
                    }
                    return vals;
                }
                rp.SelectInstance = function(idpath) {
                    var utf8EncodedPath = unescape(encodeURIComponent(idpath));
                    window.MyThingView.widget.SelectPart(utf8EncodedPath, true, 0);
                }
                
                rp.SelectInstances = function(idpaths) {
                    
                    var idPathArr = new Module.VectorString();
                    for (var i = 0; i < idpaths.length ; i++) {
                        var utf8EncodedPath = unescape(encodeURIComponent(idpaths[i]));
                        idPathArr.push_back(utf8EncodedPath);
                    }
                        window.MyThingView.session.SelectInstances(idPathArr, true);
                }
                
                rp.DeSelectInstances = function(idpaths) {
                    
                    var idPathArr = new Module.VectorString();
                    for (var i = 0; i < idpaths.length ; i++) {
                        var utf8EncodedPath = unescape(encodeURIComponent(idpaths[i]));
                        idPathArr.push_back(utf8EncodedPath);
                    }
                       window.MyThingView.session.SelectInstances(idPathArr, false);
                } 
                
                rp.SelectAll = function() {
                    window.MyThingView.session.SelectAllInstances();
                    logger.debug("SelectAll");
                }
                rp.CreateBoundingBox = function(xmin,ymin,zmin,xmax,ymax,zmax, c, t, d) {
                    logger.debug("CreateBoundingBox");
                    window.MyThingView.bbox = new MyBoundClass(Module.BoundType.BOX);
                    window.MyThingView.bbox.type = "Box";
                    window.MyThingView.bbox.SetBoundingBoxBounds(xmin,ymin,zmin,xmax,ymax,zmax);
                    window.MyThingView.bbox.SetSelectable(d);
                    window.MyThingView.session.AddBoundMarker(window.MyThingView.bbox);
                    return 1;
                }
                rp.DeleteBoundingBox = function (v) {
                    if (window.MyThingView.bbox) {
                        window.MyThingView.session.RemoveBoundMarker(window.MyThingView.bbox);
                        window.MyThingView.bbox['delete']();
                        window.MyThingView.bbox = null;
                    }
                }
                rp.CreateSphere = function (x,y,z,radius,color,transparency,isDraggable) {
                    logger.debug("CreateBoundingSphere");
                    window.MyThingView.sphere = new MyBoundClass(Module.BoundType.SPHERE);
                    window.MyThingView.sphere.type = "Sphere";
                    window.MyThingView.sphere.SetBoundingSpherePosition(x,y,z, radius);
                    window.MyThingView.sphere.SetSelectable(isDraggable);
                    window.MyThingView.session.AddBoundMarker(window.MyThingView.sphere);
                    return 1;

                }
                rp.DeleteSphere = function (v) {
                    if (window.MyThingView.sphere) {
                        window.MyThingView.session.RemoveBoundMarker(window.MyThingView.sphere);
                        window.MyThingView.sphere['delete']();
                        window.MyThingView.sphere = null;
                    }
                }

                rp.UpdateSphere = function (spId, x, y, z, r) {
                    window.MyThingView.sphere.SetBoundingSpherePosition(x, y, z, r);
                }

                rp.UpdateBoundingBox = function (spId, xMin, yMin, zMin, xMax, yMax, zMax) {
                    window.MyThingView.bbox.SetBoundingBoxBounds(xMin, yMin, zMin, xMax, yMax, zMax);
                }

                rp.ResetInstanceLocation = function () {
                    window.MyThingView.widget.UnsetSelectedLocation();
                }

                rp.GetOrientations = function () {
                    return this;
                }

                rp.SetOrientation = function (name, type) {
                    var preset = Module.OrientPreset.ORIENT_ISO1;
                    if (name == 'ISO1')
                        preset = Module.OrientPreset.ORIENT_ISO1;
                    else if (name == 'ISO2')
                        preset = Module.OrientPreset.ORIENT_ISO2;
                    else if (name == 'Top')
                        preset = Module.OrientPreset.ORIENT_TOP;
                    else if (name == 'Bottom')
                        preset = Module.OrientPreset.ORIENT_BOTTOM;
                    else if (name == 'Left')
                        preset = Module.OrientPreset.ORIENT_LEFT;
                    else if (name == 'Right')
                        preset = Module.OrientPreset.ORIENT_RIGHT;
                    else if (name == 'Front')
                        preset = Module.OrientPreset.ORIENT_FRONT;
                    else if (name == 'Back')
                        preset = Module.OrientPreset.ORIENT_BACK;

                    window.MyThingView.session.ApplyOrientPreset(preset, 1000);
                }

                rp.SetViewState = function (name, type) {
                    window.MyThingView.widget.LoadViewState(name, "/");
                }

                rp.ReloadStructure = function (srcUrl) {

                    window.MyThingView.session.RemoveAllModels(true);
                    window.MyThingView.widget = new MyModelClass();
                    window.MyThingView.widget.type = "Model";
                    window.MyThingView.session.AddModel(window.MyThingView.widget);
                    var widgetParams = new Module.NameValueVec();
                    widgetParams.push_back({name:"sourceUrl",value:srcUrl});
                    widgetParams.push_back({name:"baseUrl",value:getBaseURL()});
                    widgetParams.push_back({name:"templateUrl",value:window.MyThingView.urltemplate});
                    widgetParams.push_back({name:"markupUrl",value:window.MyThingView.getmarkupurl});
                    widgetParams.push_back({name:"blparams",value:blparams});
                    window.MyThingView.widget.LoadFromWCURL(widgetParams, window.MyThingView.renderAtStartup, window.MyThingView.renderAtStartup);
                    setTimeout(function(){ window.MyThingView.session.ShowProgress(true);}, 350);
                }

                rp.RegisterTreeObserver = function(treeObs) {
                    window.MyThingView.treeObserver = treeObs;
                    var treeObserver = new MyTreeClass();
                    window.MyThingView.session.RegisterTreeObserver(treeObserver);
                }

                rp.GetInstanceName = function (idpath) {
                    return window.MyThingView.widget.GetInstanceName(idpath);
                }
                
                rp.HideInstanceAndDescendants = function(idpath) {
                    if (window.MyThingView.widget) {
                        var idpaths = idpath.split(",");
                        for (var i=0;i<idpaths.length;++i) {
                           window.MyThingView.widget.SetPartVisibility(idpaths[i], false, Module.ChildBehaviour.INCLUDE, Module.InheritBehaviour.USE_DEFAULT);
                        }
                    }
                }

                rp.HideInstancesAndDescendants = function(idpaths) {
                    if (window.MyThingView.widget) {
                        //var idpaths = idpath.split(",");
                        for (var i=0;i<idpaths.length;++i) {
                           window.MyThingView.widget.SetPartVisibility(idpaths[i], false, Module.ChildBehaviour.INCLUDE, Module.InheritBehaviour.USE_DEFAULT);
                        }
                    }
                }

                rp.IsolateInstances =function (ids) {
                    logger.debug("IsolateInstances START");
                    if (window.MyThingView.widget) {
                        for (var i=0;i<ids.length;++i) {
                           this.IsolateSelected(ids[i]);
                        }
                    }
                    logger.debug("IsolateInstances STOP");
                }

                rp.HideInstance = function(idpath) {
                    if (window.MyThingView.widget) {
                        var idpaths = idpath.split(",");
                        for (var i=0;i<idpaths.length;++i) {
                           window.MyThingView.widget.SetPartVisibility(idpaths[i], false, Module.ChildBehaviour.IGNORED, Module.InheritBehaviour.USE_DEFAULT);
                        }
                    }
                }
                
                rp.ShowInstanceAndDescendants = function(idpath) {
                    if (window.MyThingView.widget) {
                        var idpaths = idpath.split(",");
                        for (var i=0;i<idpaths.length;++i) {
                           window.MyThingView.widget.SetPartVisibility(idpaths[i], true, Module.ChildBehaviour.INCLUDE, Module.InheritBehaviour.USE_DEFAULT);
                        }
                    }
                }
                
                rp.LoadInstanceAndDescendents = function (idpath) {
                    logger.debug("LoadInstanceAndDescendents START");
                    logger.debug("idpath: " + idpath );
                    var idPathArr = new Module.VectorString();
                    idPathArr.push_back(idpath);
                    logger.debug("LoadInstanceAndDescendents STOP");
                    return window.MyThingView.widget.LoadParts(idPathArr, true, function(){
                        logger.trace("LoadParts callback");
                    });
                }

                rp.GetLoadProgressWebGL = function(){
                    logger.debug("GetLoadProgress START");
                    var progress = MyThingView.session.GetProgress();
                    logger.debug("progress: " + progress);
                    logger.debug("GetLoadProgress STOP");
                    return progress;
                }

                rp.ShowInstancesAndDescendants = function(idpaths) {
                    if (window.MyThingView.widget) {
                        // var idpaths = idpath.split(",");
                        var idPathArr = new Module.VectorString();
                        for (var i = 0; i < idpaths.length; ++i) {
                            idPathArr.push_back(idpaths[i]);
                        }
                        return window.MyThingView.widget.LoadParts(idPathArr, true, function() {
                            logger.trace("LoadParts callback");
                            for (var i = 0; i < idpaths.length; ++i) {
                                window.MyThingView.widget.SetPartVisibility(idpaths[i], true, Module.ChildBehaviour.INCLUDE, Module.InheritBehaviour.USE_DEFAULT);
                            }
                        });
                    }
                }

                rp.ShowInstance = function(idpath) {
                    if (window.MyThingView.widget) {
                        var idpaths = idpath.split(",");
                        for (var i=0;i<idpaths.length;++i) {
                           window.MyThingView.widget.SetPartVisibility(idpaths[i], true, Module.ChildBehaviour.IGNORED, Module.InheritBehaviour.USE_DEFAULT);
                        }
                    }
                }
                

                rp.SelectTreeNodes = function (message) {
                    window.MyThingView.session.SelectTreeNodes(message, false);
                    setTimeout(function(){ window.MyThingView.session.ShowProgress(true);}, 350);
                }

                rp.SelectTreeNodesWebGL = function (message, shouldZoom) {
                    var zoomed;
                    if (shouldZoom) {
                        zoomed = window.MyThingView.session.SelectTreeNodes(message, true);
                    } else {
                        zoomed = window.MyThingView.session.SelectTreeNodes(message, false);
                    }
                    setTimeout(function(){ window.MyThingView.session.ShowProgress(true);}, 350);
                    return zoomed;
                }

                rp.UnregisterTreeObserver = function() {
                    delete window.MyThingView.treeObserver;
                    window.MyThingView.treeObserver = null;
                    window.MyThingView.session.RemoveAllModels(true);
                    window.MyThingView.widget = null;
                    window.MyThingView.session.UnRegisterTreeObserver();
                }

                rp.LoadInstances = function (parts) {
                    var partsObj = JSON.parse(parts);
                    if (partsObj.update != "begin" && partsObj.update != "end") {
                        var idPaths = new Module.VectorString();
                        for (var i=0;i<partsObj.length;++i){
                            idPaths.push_back(partsObj[i]);
                        }
                        window.MyThingView.widget.LoadParts(idPaths, false, function(){
                            window.MyThingView.session.ZoomView(Module.ZoomMode.ZOOM_ALL, 1000.0);
                        });
                        setTimeout(function(){ window.MyThingView.session.ShowProgress(true);}, 350);
                     }
                }

                rp.InsertComps = function(parentPVIds, names, urls, mapSrcs, autoExpand, autoLoad){
                    logger.debug("InsertComps START");
                    var se = window.MyThingView.session.GetStructureEdit();
                    var infoVector = Module.IdFileVector.Create();
                    infoVector.InsertIdFile(parentPVIds[0], urls[0]);
                    se.InsertBranchesChildren(infoVector, autoExpand, autoLoad, function (success) {
                        window.MyThingView.session.ZoomView(Module.ZoomMode.ZOOM_ALL, 1000.0);
                        visTabCallbackDiv.OnLoadComplete();
                        visTabCallbackDiv.OnLoadProgress(100);
			visTabCallbackDiv.OnStructureEditComplete();
                       
                    });
                    logger.debug("InsertComps STOP");
                }

                rp.InsertCompsWithStates = function(parentPVIds, names, urls, mapSrcs, group, propName, dataToLoad, autoExpand){
                    logger.debug("InsertCompsWithStates START");

                    var se = window.MyThingView.session.GetStructureEdit();
                    var infoVector = Module.IdFileVector.Create();
                    infoVector.InsertIdFile(parentPVIds[0], urls[0]);
                    se.InsertBranchesChildren(infoVector, autoExpand, false, function (success) {

                        if (dataToLoad.length === 0) {
                            window.MyThingView.session.ZoomView(Module.ZoomMode.ZOOM_ALL, 1000.0);
                            visTabCallbackDiv.OnLoadComplete();
                            visTabCallbackDiv.OnLoadProgress(100);
                            return;
                        }

                        var propValueArr = new Module.VectorString();
                        for (var i = 0; i < dataToLoad.length; i++) {
                            var tmp = dataToLoad[i];
                            propValueArr.push_back(tmp);
                        }

                        var result = window.MyThingView.widget.FindInstancesWithProperties(true, group, propName, propValueArr);

                        var instances = [];
                        for (var i = 0; i < result.size() ; i++) {
                            var instance = result.get(i);
                            instances.push(instance);
                        }

                        var idPaths = new Module.VectorString();
                        for (var i = 0; i < result.size(); i++){
                            idPaths.push_back(result.get(i));
                        }

                        window.MyThingView.widget.LoadParts(idPaths, true, function(){
                            window.MyThingView.session.ZoomView(Module.ZoomMode.ZOOM_ALL, 1000.0);
                            visTabCallbackDiv.OnLoadComplete();
                            visTabCallbackDiv.OnLoadProgress(100);
                        });
                        setTimeout(function(){ window.MyThingView.session.ShowProgress(true);}, 350);
                    });
                    logger.debug("InsertCompsWithStates STOP");
                }

                rp.MoveComps = function(idsToBeMoved,newParentId,newNodesIds){
                    logger.debug("MoveComps START");
                    var se = window.MyThingView.session.GetStructureEdit();
                    var markedComps = Module.StringSet.Create();
                    var newIds = Module.StringMap.Create();
                    for (var i=0;i<idsToBeMoved.length;++i){
                        markedComps.Insert(idsToBeMoved[i]);
                    }
                    for (var i=0;i<newNodesIds.length;++i){
                        newIds.Insert(idsToBeMoved[i],newNodesIds[i]);
                    }
                    se.MoveComps(markedComps, newParentId, true, true, newIds, function (success, movedIds) {
                        if (success) {
                            logger.debug('Successfully moved ' + movedIds.size() + ' comp(s)');
                        } else {
                            logger.debug('Failed to move comp(s)');
                        }
                    });
                    logger.debug("MoveComps STOP");
                }

                rp.RemoveComps = function(pvIdsToBeRemoved){
                    logger.debug("RemoveComps START");
                    var se = window.MyThingView.session.GetStructureEdit();
                    var stringSet =  Module.StringSet.Create();
                    for (var i = 0; i < pvIdsToBeRemoved.length; i++) {
                        logger.debug("RemoveComps pvIdsToBeRemoved [" + pvIdsToBeRemoved[i] + "]");
                        stringSet.Insert(pvIdsToBeRemoved[i]);
                    }
                    se.RemoveComps(stringSet, true, true, function (success) {
                        window.MyThingView.session.ZoomView(Module.ZoomMode.ZOOM_ALL, 1000.0);
                    });
                    logger.debug("RemoveComps STOP");
                }

                rp.GetProperties = function(pvInstanceIds,property,group){
                    logger.debug("GetProperties START");
                    var propertiesForInstanceIds = [];
                    for (var i = 0; i < pvInstanceIds.length; i++) {
                        propertiesForInstanceIds.push(window.MyThingView.widget.GetPropertyValue(pvInstanceIds[i],group,property));
                    }
                    visTabCallbackDiv.OnPropertyValue(propertiesForInstanceIds);
                    logger.debug("GetProperties STOP");
                }

                rp.SetPhantomMode = function(idpaths,mode) {
                    logger.debug("SetPhantomMode START");
                    for (var i=0;i<idpaths.length;++i) {
                        if (mode) {
                            window.MyThingView.widget.SetPartRenderMode(idpaths[i], Module.PartRenderMode.PHANTOM, Module.ChildBehaviour.INCLUDE, Module.InheritBehaviour.USE_DEFAULT);
                            window.MyThingView.widget.SetPartPickability(idpaths[i], false, Module.ChildBehaviour.INCLUDE, Module.InheritBehaviour.USE_DEFAULT);
                        } else {
                            if ((idpaths[i].match(/\/\w*$/g) || []).length === 1 || idpaths[i] === ":" || idpaths[i] === "") {
                                window.MyThingView.widget.UnsetPartRenderMode(idpaths[i], Module.ChildBehaviour.INCLUDE);
                                window.MyThingView.widget.UnsetPartPickability(idpaths[i], Module.ChildBehaviour.INCLUDE);
                            } else {
                                window.MyThingView.widget.SetPartRenderMode(idpaths[i], Module.PartRenderMode.SHADED, Module.ChildBehaviour.INCLUDE, Module.InheritBehaviour.USE_DEFAULT);
                                window.MyThingView.widget.SetPartPickability(idpaths[i], true, Module.ChildBehaviour.INCLUDE, Module.InheritBehaviour.USE_DEFAULT);
                            }
                        }
                    }
                    logger.debug("SetPhantomMode STOP");
                }

                rp.SetTransparency = function(id,transparency,descendant){
                    logger.debug("SetTransparency START");
                    logger.debug("id: " + id );
                    logger.debug("transparency: " + transparency );
                    logger.debug("descendant: " + descendant );
                    if (transparency != 1) {
                        logger.debug("SetOpacity");
                        window.MyThingView.widget.SetPartOpacity(id, transparency, Module.ChildBehaviour.INCLUDE, Module.InheritBehaviour.USE_DEFAULT);
                    } else {
                        logger.debug("UnsetOpacity");
                        if ((id.match(/\/\w*$/g) || []).length === 1 || id === ":" || id === "") {
                            window.MyThingView.widget.UnsetPartOpacity(id, Module.ChildBehaviour.INCLUDE);
                        } else {
                            window.MyThingView.widget.SetPartOpacity(id, 1, Module.ChildBehaviour.INCLUDE, Module.InheritBehaviour.USE_DEFAULT);
                        }
                    }
                    logger.debug("SetTransparency STOP");
                }

                rp.SetTransparencies = function(ids,transparency,descendants){
                    logger.debug("SetTransparencies START");
                    logger.debug("ids: " + ids );
                    logger.debug("transparency: " + transparency );
                    logger.debug("descendants: " + descendants );
                    for (var i=0;i<ids.length;++i) {
                        logger.debug("ids[i]: " + ids[i] );
                        if (transparency != 1) {
                            logger.debug("SetOpacity");
                            window.MyThingView.widget.SetPartOpacity(ids[i], transparency, Module.ChildBehaviour.INCLUDE, Module.InheritBehaviour.USE_DEFAULT);
                        } else {
                            logger.debug("UnsetOpacity");
                            if ((ids[i].match(/\/\w*$/g) || []).length === 1 || ids[i] === ":" || ids[i] === "") {
                                window.MyThingView.widget.UnsetPartOpacity(ids[i], Module.ChildBehaviour.INCLUDE);
                            } else {
                                window.MyThingView.widget.SetPartOpacity(ids[i], 1, Module.ChildBehaviour.INCLUDE, Module.InheritBehaviour.USE_DEFAULT);
                            }
                        }
                    }
                    logger.debug("SetTransparencies STOP");
                }

                rp.ShowAll = function() {
                    logger.debug("ShowAll START");
                    window.MyThingView.widget.SetPartVisibility("/", true, Module.ChildBehaviour.INCLUDE, Module.InheritBehaviour.USE_DEFAULT);
                    window.MyThingView.hideAllOnlyOnce = false;
                    logger.debug("ShowAll STOP");
                }
                 
                rp.HideAllModelAnnotations = function() {
                    logger.debug("HideAllModelAnnotations START");
                    window.MyThingView.widget.HideAllModelAnnotations();
                    logger.debug("HideAllModelAnnotations STOP");
                }

                rp.HideModelAnnotations = function(path, featureIds) {
                        logger.debug("HideModelAnnotations START");
                        if (featureIds) {
                            var uidArr = new Module.VectorString();
                            for (var j = 0; j < featureIds.length; j++) {
                                var uniqueId = window.MyThingView.widget.GetMarkupFeatureUniqueId(path,
                                        featureIds[j]);
                                uidArr.push_back(uniqueId.toString());
                            }
                            logger.debug("HideModelAnnotations for unique ids : " + uidArr);
                            window.MyThingView.widget.HideModelAnnotations(path, uidArr);
                        }
                        logger.debug("HideModelAnnotations STOP");
                }
  
                
                rp.ShowAllModelAnnotations = function() {
                    logger.debug("ShowAllModelAnnotations START");
                    window.MyThingView.widget.ShowAllModelAnnotations();
                    logger.debug("ShowAllModelAnnotations STOP");
                }
                
                rp.SelectAnnotation = function(path,id,selected) {
                    logger.debug("SelectAnnotation START");
                    var markupId = window.MyThingView.widget.GetMarkupFeatureUniqueId(path,id);
                    window.MyThingView.widget.SelectFeature(path,markupId,selected);
                    var features = featureSelection[path];
                    if (features) {
                                var i = features.indexOf(markupId);
                                if (i == -1) {
                                    if (selected) features.push(markupId);
                                } else {
                                    if (!selected) {
                                        features.splice(i, 1);
                                        if (features.length == 0) {
                                            delete featureSelection[si.GetInstanceIdPath()];
                                        }
                                    }
                                }
                            } else {
                                if (selected) {
                                    var feature = [];
                                    feature.push(markupId);
                                    featureSelection[path] = feature;
                                }
                            }
        
                   logger.debug("SelectAnnotation STOP");
                }
                
                rp.ShowAllModelAnnotations = function() {
                    logger.debug("ShowAllModelAnnotations START");
                    window.MyThingView.widget.ShowAllModelAnnotations();
                    logger.debug("ShowAllModelAnnotations STOP");
                }

                rp.IsolateSelected = function(id) {
                    logger.debug("IsolateSelected START");
                    if(!window.MyThingView.hideAllOnlyOnce) {
                        window.MyThingView.widget.SetPartVisibility("/", false, Module.ChildBehaviour.INCLUDE, Module.InheritBehaviour.USE_DEFAULT);
                        window.MyThingView.hideAllOnlyOnce = true;
                    }
                    window.MyThingView.widget.SetPartVisibility(id, true, Module.ChildBehaviour.INCLUDE, Module.InheritBehaviour.USE_DEFAULT);
                    logger.debug("IsolateSelected STOP");
                }

                rp.SetPropertyValue = function(pvIds,names,groups,values) {
                    logger.debug("SetPropertyValue START");
                    if (pvIds.length) {
                        for (var i=0; i<pvIds.length; i++) {
                            var result = window.MyThingView.widget.SetPropertyValue(pvIds[i],groups[i],names[i],values[i]);
                            if (!result) {
                                logger.debug("SetPropertyValue failed: " + pvIds[i] + " " + groups[i] + " " + names[i] + " " + values[i]);
                            }
                        }
                    }
                    logger.debug("SetPropertyValue STOP");
                }

                rp.CreateComponent = function(newNodesName, objType, URL, boundingBox) {
                    logger.debug("CreateComponent START");
                    window.MyThingView.CreateComponentParams = [];
                    window.MyThingView.CreateComponentParams.push(newNodesName);
                    window.MyThingView.CreateComponentParams.push(objType);
                    window.MyThingView.CreateComponentParams.push(URL);
                    window.MyThingView.CreateComponentParams.push(boundingBox);
                    logger.debug("CreateComponent STOP");
                }

                rp.AddComponentNode = function (newNodePVGeneratedID, parentId ,newNodeId,newNodesName) {
                    logger.debug("AddComponentNode START");
                    var se = window.MyThingView.session.GetStructureEdit();
                    se.CreateComp(newNodesName, parentId, window.MyThingView.CreateComponentParams[2], newNodeId, function (success) {
                        if (success) {
                            logger.debug('Successfully created component');
                        } else {
                            logger.debug('Failed to create component');
                        }
                    });
                    logger.debug("AddComponentNode STOP");
                }

                rp.SetInstancesColor = function(ids, applyToDescendants, instanceColor){
                    logger.debug("SetInstancesColor START");
                    logger.debug("ids: " + id);
                    logger.debug("applyToDescendants: " + applyToDescendants);
                    logger.debug("instanceColor: " + instanceColor);

                    // Need to convert hex color to r,g,b,a
                    hex = instanceColor.replace('0x','');
                    var r = (parseInt(hex.substring(0,2), 16))/255;
                    var g = (parseInt(hex.substring(2,4), 16))/255;
                    var b = (parseInt(hex.substring(4,6), 16))/255;

                    // Since opacity is not provided by the hex color, assume a = 1
                    var a = 1;
                    logger.debug("r: " + r);
                    logger.debug("g: " + g);
                    logger.debug("b: " + b);
                    logger.debug("a: " + a);

                    for (var i=0;i<ids.length;++i) {
                        logger.debug("id[i] : " + ids[i] );
                        if (applyToDescendants) {
                            window.MyThingView.widget.SetPartColor(ids[i], r, g, b, a, Module.ChildBehaviour.INCLUDE, Module.InheritBehaviour.USE_DEFAULT);
                        } else {
                            window.MyThingView.widget.SetPartColor(ids[i], r, g, b, a, Module.ChildBehaviour.IGNORED, Module.InheritBehaviour.USE_DEFAULT);
                        }
                    }
                    logger.debug("SetInstancesColor STOP");
                }

                rp.GetViewLocation = function() {
                    logger.debug("GetViewLocation START");
                    var locationInformation = window.MyThingView.session.GetViewLocation();
                    var locationInformationJson = JSON.stringify(locationInformation);
                    return locationInformationJson;
                }

                rp.SetViewLocationWebGL = function(location) {
                    logger.debug("SetViewLocation START");
                    var splitedLocation = location.split(" ");
                    var locObj = {
                        "orientation": {
                            "x": parseFloat(splitedLocation[0]),
                            "y": parseFloat(splitedLocation[1]),
                            "z": parseFloat(splitedLocation[2])
                        },
                        "position": {
                            "x": parseFloat(splitedLocation[3]),
                            "y": parseFloat(splitedLocation[4]),
                            "z": parseFloat(splitedLocation[5])
                        },
                        "scale": {
                            "x": 1.0,
                            "y": 1.0,
                            "z": 1.0
                        },
                        "size": {
                            "x": 1.0,
                            "y": 1.0,
                            "z": 1.0
                        },
                        "valid": false
                    }
                    window.MyThingView.session.SetViewLocation(locObj);
                    logger.debug("SetViewLocation STOP");
                }

                rp.GetOrthographicWidth = function(){
                    console.log("Not implemented yet by Creo View team. Use 0.94 as default" );
                    return 0.94;
                }

                rp.SetInstanceLocation = function(path, position){
                    logger.debug("SetInstanceLocation START");
                    logger.debug("path: " + path );
                    logger.debug("position: " + position );
                    var locationArr = new Module.PartLocationVec();

                    var location = {};
                    location.idPath = path;

                    var positionRotation = window.MyThingView.Util.GetPositionRotationFromMatrix(position);
                    logger.debug("positionRotation: " + positionRotation );

                    location.position = {};
                    location.position.x = Number(positionRotation[0]);
                    location.position.y = Number(positionRotation[1]);
                    location.position.z = Number(positionRotation[2]);

                    location.orientation = {};
                    location.orientation.x = Number(positionRotation[3]);
                    location.orientation.y = Number(positionRotation[4]);
                    location.orientation.z = Number(positionRotation[5]);

                    // Leave the removeOverride flag to false. Otherwise, if set to true when setting the location of an assembly,
                    // the location of all children becomes wrong.
                    location.removeOverride = false;

                    locationArr.push_back(location);

                    window.MyThingView.widget.SetPartLocation(locationArr);
                    logger.debug("SetInstanceLocation STOP");
                }

                rp.SetInstancesLocation = function(paths, positions){
                    logger.debug("SetInstancesLocation START");
                    logger.debug("paths: " + paths );
                    logger.debug("positions: " + positions );

                    var locationArr = new Module.PartLocationVec();

                    for (var i = 0; i < paths.length; i++) {

                        var location = {};
                        location.idPath = paths[i];

                        var positionRotation = window.MyThingView.Util.GetPositionRotationFromMatrix(positions[i]);
                        logger.debug("positionRotation: " + positionRotation );

                        location.position = {};
                        location.position.x = Number(positionRotation[0]);
                        location.position.y = Number(positionRotation[1]);
                        location.position.z = Number(positionRotation[2]);

                        location.orientation = {};
                        location.orientation.x = Number(positionRotation[3]);
                        location.orientation.y = Number(positionRotation[4]);
                        location.orientation.z = Number(positionRotation[5]);

                        // Leave the removeOverride flag to false. Otherwise, if set to true when setting the location of an assembly,
                        // the location of all children becomes wrong.
                        location.removeOverride = false;

                        locationArr.push_back(location);
                    }

                    window.MyThingView.widget.SetPartLocation(locationArr);
                    logger.debug("SetInstancesLocation STOP");
                }

                rp.ResetInstanceLocation = function(path){
                    logger.debug("ResetInstanceLocation START");
                    logger.debug("path: " + path );
                    var idPathArr = new Module.VectorString();
                    idPathArr.push_back(path);
                    window.MyThingView.widget.UnsetPartLocation(idPathArr,true);
                    logger.debug("ResetInstanceLocation STOP");
                }

                rp.GetInstanceLocation = function(path){
                    logger.debug("GetInstanceLocation START");
                    logger.debug("path: " + path );
                    var idPathArr = new Module.VectorString();
                    idPathArr.push_back(path);
                    var locs = window.MyThingView.widget.GetPartLocation(idPathArr);
                    var partLocation = locs.get(0);

                    var position_x = partLocation.position.x.toFixed(6);
                    var position_y = partLocation.position.y.toFixed(6);
                    var position_z = partLocation.position.z.toFixed(6);

                    var orientation_x = partLocation.orientation.x.toFixed(1);
                    var orientation_y = partLocation.orientation.y.toFixed(1);
                    var orientation_z = partLocation.orientation.z.toFixed(1);
                    logger.debug(
                            "pos x:[" + position_x + "] " +
                            "pos y:[" + position_y + "] " +
                            "pos z:[" + position_z + "] " +
                            "or x:["  + orientation_x + "] " +
                            "or y:["  + orientation_y + "] " +
                            "or z:["  + orientation_z +"]");
                    logger.debug("GetInstanceLocation STOP");
                    return position_x + " " + position_y + " " + position_z + " " + orientation_x + " " + orientation_y + " " + orientation_z;
                }
            }

            window.MyThingView.session.AllowPartSelection(true);
            window.MyThingView.session.SetDragMode(Module.DragMode.NONE);
            window.MyThingView.treeUpdates = [];
            window.MyThingView.hideAllOnlyOnce = false;
            window.MyThingView.treeUpdateTimer = false;
            window.MyThingView.treeMessageWaiting = false;
            window.MyThingView.treeUpdateTimeout = 100;
            window.MyThingView.Util = {
                    GetPositionRotationFromMatrix : function (matStr) {
                        var splitArr = matStr.split(" ");
                        var arrLen = splitArr.length;
                        var numArr = new Array(arrLen);

                        var epsilon = 1e-6;

                        for (var i=0;i<arrLen;i++) {
                            numArr[i] = Number(splitArr[i]);
                        }

                        var res = new Array(6);
                        res[0] = numArr[3];
                        res[1] = numArr[7];
                        res[2] = numArr[11];

                        var sy = -numArr[2];

                        if (sy >= (1 - epsilon)) {
                            var sxmz = numArr[4];
                            var cxmz = numArr[5];

                            res[3] = 0;
                            res[4] = Math.PI/2;
                            res[5] = -Math.atan2(sxmz, cxmz);
                        } else if (sy <= (-1 + epsilon)) {
                            var sxpz = -numArr[4];
                            var cxpz =  numArr[5];

                            res[3] = 0;
                            res[4] = -Math.PI/2;
                            res[5] = -Math.atan2(sxpz, cxpz)
                        } else {
                            var cysx = numArr[6];
                            var cxcy = numArr[10];
                            var cycz = numArr[0];
                            var cysz = numArr[1];

                            res[3] = Math.atan2(cysx, cxcy);
                            res[4] = Math.asin(sy);
                            res[5] = Math.atan2(cysz, cycz);
                        }

                        return res;
                    }
            };

            MyTreeClass = Module.TreeEvents.extend("TreeEvents", {
            OnTreeAddBegin: function () {
                window.MyThingView.treeObserver.OnTreeMappingBegin();
            },
            OnTreeAdd: function (message) {
                window.MyThingView.treeObserver.OnTreeMapping(message);
            },
            OnTreeAddEnd: function () {
                window.MyThingView.treeObserver.OnTreeMappingEnd();
            },
            OnTreeRemoveBegin: function () {
            },
            OnTreeRemove: function (message) {
            },
            OnTreeRemoveEnd: function () {
            },
            OnTreeUpdateBegin: function() {
            },
            OnTreeUpdate: function (message) {
                window.MyThingView.treeUpdates.push(message);
            },
            OnTreeUpdateEnd: function() {
                if (!window.MyThingView.treeUpdateTimer) {
                    window.MyThingView.treeUpdateTimer = true;
                    if (window.MyThingView.treeMessageWaiting) {
                        window.MyThingView.treeMessageWaiting = false;
                        window.MyThingView.treeUpdateTimeout = 500;
                    } else {
                        window.MyThingView.treeUpdateTimeout = 100;
                    }
                    setTimeout(function() { 
                        window.MyThingView.treeUpdateTimer = false;
                        window.MyThingView.treeObserver.OnTreeUpdateBegin();
                        for (var u=0;u<window.MyThingView.treeUpdates.length;++u) {
                            window.MyThingView.treeObserver.OnTreeUpdateWebGL(window.MyThingView.treeUpdates[u]);
                        }
                        window.MyThingView.treeObserver.OnTreeUpdateEndWebGL(); 
                        window.MyThingView.treeUpdates = [];
                
                    }, window.MyThingView.treeUpdateTimeout);
                    } else {
                        window.MyThingView.treeMessageWaiting = true;
                    }
                }
            });           
            
            MySelectionClass = Module.SelectionEvents.extend("SelectionEvents", {
                OnSelectionBegin: function () {
                    logger.debug("OnSelectionBegin");
                },
                OnSelectionChanged: function (clear, removed, added) {
                    if (clear)
                        visTabCallbackDiv.OnDeSelectAll();
                    logger.debug("OnSelectionChanged - clear: " + clear);
                    for (var i=0;i<removed.size();++i) {
                        var decodedPath = decodeURIComponent(escape(removed.get(i).toString()));
                        visTabCallbackDiv.OnDeSelect(decodedPath);
                        logger.debug("OnSelectionChanged - removed: " + removed.get(i));
                    }
                    var addedStringifiedList = '';
                    for (var i=0; i < added.size(); i++) {
                        if (added.size()>1 && i>0) {
                            addedStringifiedList+=';';
                        }
                        var decodedPath = decodeURIComponent(escape(added.get(i).toString()));
                        addedStringifiedList+=decodedPath;
                    }
                    visTabCallbackDiv.OnSelect(addedStringifiedList);
                    logger.debug("OnSelectionChanged - added: " + addedStringifiedList);
                },
                OnSelectionEnd: function () {
                        visTabCallbackDiv.OnEndSelectWebGL();
                } 
            }); 
               
            window.MyThingView.selectionObserver = new MySelectionClass();
            window.MyThingView.session.RegisterSelectionObserver(window.MyThingView.selectionObserver); 

            MyModelClass = Module.Model.extend("Model", {
                OnLoadComplete: function () {

                    if(logger.isDebugEnabled()) {
                     // Structure is loaded here
                        var interval = setInterval(checkProgress, 10);

                        function checkProgress() {
                            var progress = MyThingView.session.GetProgress();
                            if (progress == 10000) {
                                console.timeEnd("loadStructure");
                                clearInterval(interval);
                            }
                        }
                    }



                    logger.debug("TV OnLoadComplete");
                    //document.getElementById('psbIFrame').contentWindow.document.getElementById('x-auto-12')
                  
                    window.MyThingView.session.SetShapeFilters(0x7 | 0x00300000); 
                    
                    try {
                        visTabCallbackDiv.OnBeginOrientation();
                        visTabCallbackDiv.OnAddOrientation("ISO1", "DEF");
                        visTabCallbackDiv.OnAddOrientation("ISO2", "DEF");
                        visTabCallbackDiv.OnAddOrientation("Top", "DEF");
                        visTabCallbackDiv.OnAddOrientation("Bottom", "DEF");
                        visTabCallbackDiv.OnAddOrientation("Left", "DEF");
                        visTabCallbackDiv.OnAddOrientation("Right", "DEF");
                        visTabCallbackDiv.OnAddOrientation("Front", "DEF");
                        visTabCallbackDiv.OnAddOrientation("Back", "DEF");

                        visTabCallbackDiv.OnBeginViewState();
                        var viewStates = window.MyThingView.widget.GetViewStates();
                       
                        var name = "";
                        var id = "";
                        var type = "";
                        for (var i = 0; i < viewStates.size() ; i++) {
                            name = viewStates.get(i).name;
                            type = viewStates.get(i).type;
                            id = viewStates.get(i).path;
                            // adding only root node views state 
                            if(id == "/")
                            {
                                if(type == "ViewState")
                                {
                                    type = "VIEW_STATE";
                                }
                                visTabCallbackDiv.OnAddViewState(name, type);
                            }
                        }
                        
                    } catch (e) {
                        // do nothing.
                    }
                    
                    visTabCallbackDiv.OnLoadComplete();
                    visTabCallbackDiv.OnLoadProgress(100);
                    LoadComplete();
                    isLoadingVisTabComplete = true;
                    WebGlLoadDuration = Date.now() - WebGlStartTime;

                },
                OnLoadError: function () {
                    logger.debug("MyModelClass::OnLoadError\n");
                    visTabCallbackDiv.OnLoadProgress(-1);
                },
                OnLocationChanged: function () {},
                OnSelectFeature: function (si, id, selected) {
                    var features = featureSelection[si.GetInstanceIdPath()];
                    var markupId = window.MyThingView.widget.GetMarkupFeatureId(si.GetInstanceIdPath(),id);
                       if (features) {
                           var i = features.indexOf(markupId);
                           if (i == -1) {
                               if (selected) features.push(markupId);
                           } else {
                               if (!selected) {
                                   features.splice(i, 1);
                                   if (features.length == 0) {
                                       delete featureSelection[si.GetInstanceIdPath()];
                                   }
                               }
                           }
                       } else {
                           if (selected) {
                               var feature = [];
                               feature.push(markupId);
                               featureSelection[si.GetInstanceIdPath()] = feature;
                           }
                       }

                       var keys = Object.keys(featureSelection);
                        if (keys.length) {
                            if (keys.length) {
                                 var returnString  = "";
                            for (var i=0; i<keys.length; i++) {
                                var features = featureSelection[keys[i]];
                                if (features) {
                                returnString =  returnString  + keys[i] + ":" + features.toString() +"@@@" ;
                                }
                            }
                             
                            }
                        }
        
                        visTabCallbackDiv.OnSelectFeature(returnString);
                },
                OnSelection: function (selected) {
                }
            });
            MyBoundClass = Module.BoundMarker.extend("BoundMarker", {
                OnLoadComplete: function() {
                    logger.debug("BoundMarker created");
                },
                OnLoadError: function() {
                },
                OnLocationChanged: function() {
                    try {
                        if (window.MyThingView.sphere) {
                            var res = window.MyThingView.sphere.GetBoundDimension();
                            var strArr = res.split(" ");
                            visTabCallbackDiv.OnSphereUpdate(1,  strArr[0], strArr[1], strArr[2], strArr[3])
                        } else if (window.MyThingView.bbox) {
                            var res = window.MyThingView.bbox.GetBoundDimension();
                            var strArr = res.split(" ");
                            visTabCallbackDiv.OnBoundingBoxUpdate(1, strArr[0], strArr[1], strArr[2], strArr[3], strArr[4],  strArr[5]);
                        }
                    } catch (e) {
                        logger.error("TV Bounding markup OnLocationChanged");
                    }
                }
            });


            window.MyThingView.widget = new MyModelClass();
            window.MyThingView.widget.type = "Model";
            window.MyThingView.session.AddModel(window.MyThingView.widget);

            logger.debug("pluginParameters: " + pluginParameters);

            var params = pluginParameters.split(" ");
            var structureurl = "";
            var urltemplate = "";
            var mapurl = "";
            var getmarkupurl = "";
            var blparams = "";
            var oid = "";
            var renderAtStartup = true;
            for (var i=0;i<params.length;++i) {
                var param = params[i].split("=");
                if (param[0] == "src") {
                    logger.debug("***src");
                    structureurl = params[i].substr(5, params[i].length-6);
                } else if (param[0] == "urltemplate") {
                    logger.debug("***urltemplate");
                    urltemplate = params[i].substr(13, params[i].length-14);
                } else if (param[0] == "mapurl") {
                    logger.debug("***mapurl");
                    mapurl = params[i].substr(8, params[i].length-9);
                } else if (param[0] == "getmarkupurl") {
                    logger.debug("***getmarkupurl");
                    getmarkupurl = params[i].substr(14, params[i].length-15);
                } else if (param[0] == "oid") {
                    logger.debug("***oid");
                    oid = params[i].substr(5, params[i].length-6);
                } else if (param[0] == "blparams") {
                    logger.debug("***blparams");
                    blparams = params[i].substr(10, params[i].length-11);
                } else if (param[0] == "renderatstartup") {
                    logger.debug("***renderatstartup");
                    logger.debug(params[i]);
                    if (params[i].indexOf("true") === -1) {
                        renderAtStartup=false;
                        logger.debug("set renderatstartup to false");
                    }
                    else {
                        renderAtStartup=true;
                        logger.debug("set renderatstartup to true");
                    }
                }
            }

            logger.debug("structureurl: " + structureurl + ", urltemplate: " + urltemplate);
            logger.debug("getmarkupurl: " + getmarkupurl + ", renderatstartup: " + renderAtStartup);
            logger.debug("blparams: " + blparams);

            window.MyThingView.urltemplate=urltemplate;
            window.MyThingView.getmarkupurl=getmarkupurl;
            window.MyThingView.renderAtStartup=renderAtStartup;
            window.MyThingView.blparams=blparams;

            if(logger.isDebugEnabled()) {
                console.time("loadStructure");
            }

            var widgetParams = new Module.NameValueVec();
            widgetParams.push_back({name:"sourceUrl",value:structureurl});
            widgetParams.push_back({name:"baseUrl",value:getBaseURL()});
            widgetParams.push_back({name:"templateUrl",value:urltemplate});
            widgetParams.push_back({name:"markupUrl",value:getmarkupurl});
            widgetParams.push_back({name:"blparams",value:blparams});
            window.MyThingView.widget.LoadFromWCURL(widgetParams, renderAtStartup, renderAtStartup);
            
            setTimeout(function(){ window.MyThingView.session.ShowProgress(true);}, 250); 


        });
    }
    else {
        if (window.MyThingView.session == undefined)
            window.MyThingView.session = ThingView.CreateSession("pvctl");

	var shapeFilters = window.MyThingView.session.GetShapeFilters();
	window.MyThingView.session.SetShapeFilters(shapeFilters | 0x7 | 0x00300000);
        window.MyThingView.session.RemoveAllModels(true);
        window.MyThingView.widget = new MyModelClass();
        window.MyThingView.widget.type = "Model";
        window.MyThingView.session.AddModel(window.MyThingView.widget);

        logger.debug(pluginParameters);
        var params = pluginParameters.split(" ");
        for (var i=0;i<params.length;++i) {
            var param = params[i].split("=");
            if (param[0] == "src") {
                var p = params[i].substr(5, params[i].length-6);
                window.MyThingView.widget.LoadFromURL(p);
            }
        }
    }

}

function StartPview()
{

    document.getElementById("pview_upgrade").style.visibility = 'hidden';
    document.getElementById("pview_upgrade").style.display = 'none';
    document.getElementById("pview_upgrade").style.height = "0";
    if (g_resetMainDivSize && document.getElementById("pvmaindiv") != null && g_height != null && g_width != null)
    {
        document.getElementById("pvmaindiv").style.height=g_height;
        document.getElementById("pvmaindiv").style.width=g_width;
    }
    //    document.cookie="pvlite_version_checked=true;path=/";

    document.getElementById("runpview").innerHTML = GetPviewHtml();
    IECallbackEvents();
    document.getElementById("runpview").style.visibility = 'visible';
    if(document.getElementById("infoPageinfoPanelID__infoPage_myTab_object_infoDetails_cadx") != null) {
        firePluginChecks();
    }

    // Define an API to wrap the setting of the SRC URL, allowing this function to be redefined
    // with a different implementation for the CV WebGL viewer.
    try
    {
       document.getElementById("pvctl").ReloadStructure = function(srcUrl) {
           document.getElementById("pvctl").src=srcUrl;
       }
    }
    catch(e)
    {
    }

    try
    {
        document.getElementById("pvctl").IsRunning();
    }
    catch(e)
    {
        document.getElementById("runpview").style.visibility = 'hidden';
        var cookies = document.cookie;
        var pvVerChecked = cookies.indexOf("pvlite_version_checked");

        var installPlugin = PTC.wvs.properties.getProperty('productview.version.checker.plugin.disabled');
        if(installPlugin !== 'true') {

            if (pvVerChecked == "-1")
            {
                if (typeof _pvliteString_Install != "undefined")
                {
                    _local_Install = _pvliteString_Install;
                }
                else {
                    _local_Install = bundleHandler.getBundleStringAndInserts('com.ptc.wvs.server.ui.uiResource.PVLITE_INSTALL');
                }
                if (typeof _pvliteString_nocheck != "undefined")
                {
                    _local_nocheck = _pvliteString_nocheck;
                }
                else {
                    _local_nocheck = bundleHandler.getBundleStringAndInserts('com.ptc.wvs.server.ui.uiResource.PVLITE_NOCHECK');
                }
                document.getElementById("pview_upgrade").innerHTML = '<A class=wizardlabel HREF="javascript:void(DoInstall())" TITLE="'+_docPluginVersion+'">'+_local_Install+'</A><BR>';
                document.getElementById("pview_upgrade").innerHTML += '<A class=wizardlabel HREF="javascript:void(DoNotCheck())" TITLE="'+_docPluginVersion+'">'+_local_nocheck+'</A>';
                document.getElementById("pview_upgrade").style.visibility = 'visible';
                document.getElementById("pview_upgrade").style.display = '';
                if (document.getElementById("pview_imghref")) {
                    document.getElementById("pview_img").style.height="162px";
                }
            }
        }
    }
}

function firePluginChecks()
{
    var navigatorPanel = document.getElementById("navigatorPanel");
    PTC.util.handlePlugins(navigatorPanel, true);
    PTC.util.fireEvent('checkplugins');
}

function ConvertNSParamsToIE(nsParams)
{
    var params = "";
    var startloc = 0;
    while(true)
    {
        var loc = nsParams.indexOf("=", startloc);
        if (loc == -1)
            break;
        params += "<param name='";
        var nameStartLoc = nsParams.lastIndexOf(' ', loc);
        params += nsParams.substring(nameStartLoc+1,loc);

        params += "' value=";
        var loc1 = nsParams.indexOf("'", startloc);
        var loc2 = nsParams.indexOf("'", loc1+1);
        params += nsParams.substring(loc1,loc2+1);
        params += ">";
        startloc = loc2+1;
    }
    return params;
}

// Parses the ProE parameters and replace the pvxMethodParam parameter value with the ProE
// connection id.
function getProEConnectionId(nsParams)
{
    var params = "";
    var startloc = 0;
    while(true)
    {
        var loc = nsParams.indexOf("=", startloc);
        if (loc == -1)
            break;

        var nameStartLoc = nsParams.lastIndexOf(' ', loc);
        var theParamName = nsParams.substring(nameStartLoc+1,loc);

        var loc1 = nsParams.indexOf("'", startloc);
        var loc2 = nsParams.indexOf("'", loc1+1);

        var theParamValue = nsParams.substring(loc1+1,loc2);
        startloc = loc2+1;

        if(theParamName == "pvxMethodParam")
        {
            params += "PVXConnectionID='";
            params += getThumbnailViewerPVXConnectionID(theParamValue);
            params += "' ";
        }
        else if(theParamName == "jsFunc")
        {
            g_proeLoadComplete = theParamValue;
        }
        else
        {
            params += theParamName;
            params += "='";
            params += theParamValue;
            params += "' ";
        }
    }
    return params;
}

// pvxMethodParam must be in the format GetProEPVXHandle?codebase=<encodedServerUrl> which is generated from server
function getThumbnailViewerPVXConnectionID(pvxMethodParam){

    PTC.JSBridge.log.debug("Call getThumbnailViewerPVXConnectionID(pvxMethodParam)");

    var pvxConnectionID = null;

    //Check "GetProEPVXHandle?codebase=" at the head of the string
    if(pvxMethodParam.indexOf("GetProEPVXHandle?codebase=")!=0){
        PTC.JSBridge.log.error("\"GetProEPVXHandle?codebase=\" is not at the head of the string pvxMethodParam = "+pvxMethodParam);
        return pvxConnectionID;
    }
    //Get the encoded server url
    var encodedServerUrl = pvxMethodParam.substring("GetProEPVXHandle?codebase=".length);

    var reqConfig = {
            onSuccess:function(response){
                PTC.JSBridge.log.debug("JSONB_GetProEPVXHandle call succeeded.");
                // check and get the result
                if(typeof response.GetProEPVXHandleResult !== 'undefined' && response.GetProEPVXHandleResult!=null){
                    pvxConnectionID = response.GetProEPVXHandleResult;
                    PTC.JSBridge.log.info('Return value from JSONB_GetProEPVXHandle call - response.GetProEPVXHandleResult: ' + pvxConnectionID);
                }
                else{
                    PTC.JSBridge.log.error("JSONB_GetProEPVXHandle call does not return GetProEPVXHandleResult!");
                }
            },
            onFailure:function(resultCode, resultCodeText){
                PTC.JSBridge.log.error("JSONB_GetProEPVXHandle call failed! resultCode: " + resultCode + ", result text: " + resultCodeText);
            },
            asynchronous: false
    };
    var paramsObj = {Codebase:encodedServerUrl};
    PTC.JSBridge.log.debug("JSONB_GetProEPVXHandle call starts");
    new PTC.JSBridge.Request("JSONB_GetProEPVXHandle", paramsObj, reqConfig);
    PTC.JSBridge.log.debug("JSONB_GetProEPVXHandle call exits");
    return pvxConnectionID;
}

function GetHelpUrl()
{
    if (_isIE)
    {
        var browserLang = navigator.userLanguage.substring(0,2);
        var helpUrl = " helpurl='/wt/helpfiles/help_" + browserLang + "/online/'";
        return helpUrl;
    }
    else
    {
        var browserLang = navigator.language.substring(0,2);
        var helpUrl = " helpurl='/wt/helpfiles/help_" + browserLang + "/online/'";
        return helpUrl;
    }
}

function isCVInstalled() {
    if( !navigator.plugins ) return false;

    if( navigator.plugins["Creo View"] !== undefined) return true;

    return false;
}

function GetPviewHtml()
{
    g_pluginParams += GetHelpUrl();

    var htmlString="";
    if (_isIE)
    {
        var ieParams = ConvertNSParamsToIE(g_pluginParams);

        if (_is64bitIE)
        {
            htmlString += '<object classid="CLSID:F1BFCEEA-892D-405c-945F-19F87338A17F" id="pvctl"';
        } else
        {
            htmlString += '<object classid="CLSID:F07443A6-02CF-4215-9413-55EE10D509CC" id="pvctl"';
        }
        if (_docType) htmlString +=' type="' + _docType + '"';
        htmlString += ' width=100%';
        htmlString += ' height=100%';
        htmlString += '>\n';
        htmlString += ieParams;
        htmlString += '</object>\n';
    }
    else
    {
        if (isCVInstalled()) {
            htmlString += '<embed id="pvctl" name="pvctl" ';
            htmlString += ' type="application/x-pvlite9-ed" ';
            htmlString += ' width=100%';
            htmlString += ' height=100% '; // add space to make sure params are seperated
            htmlString += g_pluginParams;
            htmlString += '>\n';
        }
    }
    return htmlString;
}

function CompareVersion(downloadVersion, installedVersion)
{
    var loc1=0;
    var loc2=0;
    for (i=0; i< 4; i++)
    {
        var val1, val2;
        var locEnd = downloadVersion.indexOf('.',loc1);
        if (locEnd != -1)
            val1 = eval(downloadVersion.substring(loc1,locEnd));
        else
            val1 =eval(downloadVersion.substring(loc1));
        loc1 = locEnd+1;
        locEnd = installedVersion.indexOf('.',loc2);
        if (locEnd != -1)
            val2 = eval(installedVersion.substring(loc2,locEnd));
        else
            val2 = eval(installedVersion.substring(loc2));
        loc2 = locEnd+1;
        if (val1 > val2)
            return false;
        if (val1 < val2)
            return true;
    }
    return true
}
function GetPvCheckHtml()
{
    var htmlString=""

    var installPlugin = PTC.wvs.properties.getProperty('productview.version.checker.plugin.disabled');
    if(installPlugin === 'true') {
        return htmlString;
    }

    if (_isChrome) {
        // Chrome does not support plugin installation from the web
    }
    else if (_isFirefox)
    {
        var usePlugin = false;

        var firefoxPlugin = navigator.plugins["ProductView Version Checker"];
        if (firefoxPlugin === undefined)
            firefoxPlugin = navigator.plugins["Creo View Version Checker"];

        if (firefoxPlugin !== undefined)
        {
            v = firefoxPlugin.description;
            var versionLoc = v.lastIndexOf(' ');

            var instVer =  v.substring(versionLoc+1);
            usePlugin = CompareVersion(_docPluginVersion, instVer);
        }

        if(usePlugin)
        {
            htmlString += '<embed name="pvVerCtl" ';
            htmlString += ' id="pvVerCtl"';
            if (_docPluginURL) htmlString += ' pluginurl=' + g_downloaddir + "/" + _docPluginURL;
            htmlString += ' pluginspage="' + g_downloaddir + "/" + _docPluginURL +'"';
            htmlString += ' type="application/x-pvlite9-ver" ';
            htmlString += ' hidden="true"';
            htmlString += ' autostart="true"';
            htmlString += '>\n';
        }
        else
        {
            try{
                xpi={'XPInstall Creo View Version Checker':g_downloaddir + "/" + _docPluginURL};
                InstallTrigger.install(xpi,OnInstalledFinished);
            }
            catch ( e ) {
            }

        }
    }
    else if (_isIE) {
        htmlString += '<object classid="CLSID:AA34B0DE-D0FE-4587-8B31-0BB687A9EF0B" id="pvVerCtl"';

        if (_docType) htmlString +=' type="' + _docType + '"';
        if (_docPluginURL) htmlString +=' codebase="' + g_downloaddir + "/" + _docPluginURL;

        if (_docPluginVersion) htmlString +='#version=' + _docPluginVersion;
        if (_docPluginURL)  htmlString += '"';

        htmlString += '>\n';
        htmlString += '</object>\n';

    } else {
        // Unsupported
    }

    return htmlString;
}




function DoNotInstall()
{
    document.cookie="pvlite_version_checked=true;path=/";
    StartPview();
}

function installDone()
{
    if (_isFirefox)
        navigator.plugins.refresh(false);
    StartPview();
}

function installCancel()
{
}

function DoNotCheck()
{
    document.cookie="pvlite_version_checked=true;path=/";
    document.getElementById("pview_upgrade").style.visibility = 'hidden';
    document.getElementById("pview_upgrade").style.display = 'none';
    document.getElementById("pview_upgrade").style.height = "0";

}

function DoInstall()
{
    var opts = "dependent=yes,toolbar=0,location=0,directory=0,status=1,menubar=0,scrollbars=1,resizable=1,width=760,height=510";
    var modalWin = wfWindowOpen( g_downloaddir+"/download_cvmcad.jsp?notify=true", "hello", opts );

    /*
    var UTCString;
    today=new Date();
    nummilli=Date.parse(today);
    today.setTime(nummilli+-1*24*24*60*1000);
    expires=today.toUTCString();
    document.cookie="pvlite_plugin_failed=;path=/;expires="+expires;
    document.cookie="pvlite_version_checked=;path=/;expires="+expires;
    InstallTrigger.install(_urllist, _xpiInstallCallback);
    */
 }

function _xpiInstallCallback(url, status)
{
   url = window.location;
   if (status == 0)
   {
     navigator.plugins.refresh(false);
     window.location.href = url;
     document.cookie="pvlite_version_checked=true;path=/";
   }
   else     if (status == 999)
   {
     window.location.href = url;
     document.cookie="pvlite_reboot_needed=true;path=/";
   }
   else  {
     if (typeof _pvliteString_Install_Failed != "undefined")
     {
        _local_Install_Failed = _pvliteString_Install_Failed;
     }
     else {
        _local_Install_Failed = bundleHandler.getBundleStringAndInserts('com.ptc.wvs.server.ui.uiResource.PVLITE_INSTALL_FAILED');
     }
     msg = _local_Install_Failed +" " +status+"\n"+url;
     window.alert(msg);
  }
}

////////////////////////////////////////////////////
var VIEW_PROP_CLR_BKG                    = "clrBkg"
var VIEW_PROP_CLR_WBKG                   = 2
var VIEW_PROP_CLR_GRAD                   = "clrGradient"
var VIEW_PROP_BOOL_GNOMON                = 52
var VIEW_PROP_BOOL_HIGHLIGHTCOLOR        = 51
var VIEW_PROP_BOOL_BBOXSEL               = 69
var VIEW_PROP_BOOL_2BUTTONMOUSE          = 93
var COMPONENT_PROP_BOOL_LOCKED           = 25

function _RGB2BGR(rgb)
{
  // flip
  tmpred = (rgb & 0x00ff0000);
  tmpblue = (rgb & 0x000000ff);
  return ((tmpblue << 16) | (rgb & 0x0000ff00) | (tmpred >> 16));
}
function ViewSetPropValueColor(propid, propVal)
{
  return document.pvctl.SetPropValueInt(propid, propVal);
}
function ViewSetPropValueBool(propid, propVal)
{
  return document.pvctl.SetPropValueBool(propid, propVal);
}
function ComponentSetPropertyBool(propid, propVal)
{
  document.pvctl.SetComponentPropertyBool(propid, propVal);
}

function NSInitialised()
{
  document.pvctl.SetSrc(_docPvtURL);
  document.pvctl.SetPvAppLiteMode(1);
  ViewSetPropValueColor(VIEW_PROP_CLR_WBKG, 0x00eeddcc);
  ViewSetPropValueBool(VIEW_PROP_BOOL_GNOMON, false);
  ViewSetPropValueBool(VIEW_PROP_BOOL_HIGHLIGHTCOLOR, false);
  ViewSetPropValueBool(VIEW_PROP_BOOL_BBOXSEL, false);
  ViewSetPropValueBool(VIEW_PROP_BOOL_2BUTTONMOUSE, true);

  if( _docAdditionalOption ) {
     eval(_docAdditionalOption);
  }
}

function LoadComplete()
{
    NSLoadComplete();
    if (_useWebGL === true) {
        
        GetMsgsFromPVS(false);
        
    } else {
        GetMsgsFromPVS(true);
    }
}

function OnActiveViewTitle(text)
{
    window.document.title=text;
}

function GetMsgsFromPVS(useCreoViewDialog)
{
    window.setTimeout("WVSMessage("+useCreoViewDialog+");", 0);
}

function WVSMessage(useCreoViewDialog)
{
    var resourceClass ="com.ptc.wvs.server.publish.publishResource."
        var constructMessage = "";
    var hasNext = true;
    var counter = 1;

    var errors = "";
    var warnings = "";
    var info = "";
    var ico = 'INFO';

    while(hasNext) {

        var val =""
        if(_useWebGL) {
            val =  window.MyThingView.widget.GetPropertyValue("/","","wvs_message_id"+counter);
        }
        else {
            // use the API from plugin to retrieve property values from Structure
            val = document.pvctl.GetPropertyValue("/", "", ("wvs_message_id"+counter));
        }

        if(val!= null && val!="") {
            var parts = val.split("::");
            var parameters = parts.slice(3,parts.length);
            if(parts[0].localeCompare("1")==0){
                errors+= bundleHandler.getBundleStringAndInserts(parts[1] + "." + parts[2],parameters) + "\n";
            }
            else if(parts[0].localeCompare("2")==0){
                warnings+= bundleHandler.getBundleStringAndInserts(parts[1] + "." + parts[2],parameters) + "\n";
            }
            else if(parts[0].localeCompare("3")==0){
                info+= bundleHandler.getBundleStringAndInserts(parts[1] + "." + parts[2],parameters) + "\n";
            }
        }
        else {
            hasNext = false;
        }

        counter+=1;
    }

    if(errors!=""){
        constructMessage += "<b>" + bundleHandler.getBundleStringAndInserts(resourceClass+"GENERIC_VISUALIZTION_MESSAGE_ERROR",null)+"</b> \n"+ errors;
        ico = 'ERROR';
    }
    if(warnings!=""){
        constructMessage += "<b>" + bundleHandler.getBundleStringAndInserts(resourceClass+"GENERIC_VISUALIZTION_MESSAGE_WARNING",null)+"</b> \n"+ warnings;
        if(ico!='ERROR'){
            ico = 'WARNING';
        }
    }
    if(info!=""){
        constructMessage += "<b>" + bundleHandler.getBundleStringAndInserts(resourceClass+"GENERIC_VISUALIZTION_MESSAGE_INFO",null) + "</b> \n" + info;
    }
    if(constructMessage!=""){
        if(useCreoViewDialog){
            // Used when plugin is enabled in Viz tab
            constructMessage = constructMessage.replace(/<b>|<\/b>/g,"");
            try {
                document.pvctl.ShowMsgDialog(bundleHandler.getBundleStringAndInserts(resourceClass+"GENERIC_VISUALIZTION_MESSAGE_TITLE",null), constructMessage, ico);
            }  catch(e){
                alert(constructMessage);
            }
        }
        else{
            Ext.Msg.buttonText.ok =bundleHandler.getBundleStringAndInserts(resourceClass+"GENERIC_VISUALIZTION_MESSAGE_OK_BUTTON",null);
            Ext.Msg.show({
                title: bundleHandler.getBundleStringAndInserts(resourceClass+"GENERIC_VISUALIZTION_MESSAGE_TITLE",null),
                msg: constructMessage.replace(/\r\n|\r|\n/g,"<br />"),
                buttons: Ext.Msg.OK,
                icon: Ext.Msg[ico],
                modal: true,  // if the Creo View dialog is not modal, then make this not modal
                autoScroll: true,
                minWidth: 600,
                minHeight: 400
            });
        }
    }
}

function NSLoadComplete()
{
    if (_useWebGL === true) {
        if( document.getElementById("pview_img") ) {
            document.getElementById("pview_img").style.visibility = 'hidden';
        }
    } else {


        document.getElementById("pview_upgrade").style.visibility = 'hidden';
        document.getElementById("pview_upgrade").style.display = 'none';
        document.getElementById("pview_upgrade").style.height = "0";

        if( document.getElementById("pview_img") ) {
            document.getElementById("pview_img").style.visibility = 'hidden';
        }

        if(_docColorOption)
        {
            if(_docGradColorOption)
            {
                logger.debug("calling plugin background color");
                document.pvctl.backgroundcolor=(_docGradColorOption & 0x00ffffff).toString(16)+":"+(_docColorOption & 0x00ffffff).toString(16);

            }
            else
            {
                document.pvctl.backgroundcolor=(_docColorOption & 0x00ffffff).toString(16);
            }
        }
        else
        {
            document.pvctl.backgroundcolor="0x00000077:0x00eeeeee";
        }

        _UpdateThumbOrientation();

        if(g_proeLoadComplete != null)
        {
            try
            {
                eval(g_proeLoadComplete + "(" + ")");
            }
            catch(e)
            {
            }
        }
    }
}

function NSDoAction()
{
    window.setTimeout(NSTimer, 0);
}

function IECallbackEvents()
{
    if( _isIE )
    {
        try {
           if( typeof(PTC) != "undefined" ) {
              PTC.navigation.on('historyChange', pvUnloadPageCallback);
              PTC.navigation.on('reloadpage', pvUnloadPageCallback);
           } else if( parent!=null && (typeof(parent.PTC) != "undefined") ) {
              parent.PTC.navigation.on('historyChange', pvUnloadPageCallback);
              parent.PTC.navigation.on('reloadpage', pvUnloadPageCallback);
           } else if( top!=null && typeof(top.PTC) != "undefined" ) {
              top.PTC.navigation.on('historyChange', pvUnloadPageCallback);
              top.PTC.navigation.on('reloadpage', pvUnloadPageCallback);
           }
        } catch(e) {}

        if( _visNavEvents != null && _visNavEvents != "null" ) {
           try {
              eval( _visNavEvents );
           } catch(e) {}
           _visNavEvents = null;
        } else {
           IEcallback();
        }
    }
}

function IEcallback(){
    var obj = document.getElementById("pvctl");

    if (Ext.isIE) {
        document.getElementById("runpview").innerHTML += "<script for='pvctl' event='OnDoAction()'>NSDoAction()</script>\n";
        document.getElementById("runpview").innerHTML += "<script for='pvctl' event='OnLoadComplete()'>LoadComplete()</script>\n";
        document.getElementById("runpview").innerHTML += "<script for='pvctl' event='OnActiveViewTitle(text)'>OnActiveViewTitle(text)</script>\n";
        document.getElementById("runpview").innerHTML += "<script for='pvctl' event='OnSetStatusText(text)'>NSSetStatusText(text)</script>\n";
        document.getElementById("runpview").innerHTML += "<script for='pvctl' event='OnCloseWindow()'>NSCloseWindow()</script>\n";
        document.getElementById("runpview").innerHTML += "<script for='pvctl' event='OnSetFocus()'>NSSetFocus()</script>\n";
        document.getElementById("runpview").innerHTML += "<script for='pvctl' event='OnLaunchUrl(text, target)'>NSLaunchUrl(text, target)</script>\n";
    }
    else
    {
        registerIEcallback("OnDoAction()", "NSDoAction();");
        registerIEcallback("OnLoadComplete()", "LoadComplete();");
        registerIEcallback("OnActiveViewTitle(text)", "OnActiveViewTitle(text);");
        registerIEcallback("OnSetStatusText(text)", "NSSetStatusText(text);");
        registerIEcallback("OnCloseWindow()", "NSCloseWindow();");
        registerIEcallback("OnSetFocus()", "NSSetFocus();");
        registerIEcallback("OnLaunchUrl(text, target)", "NSLaunchUrl(text, target);");
    }


}

function registerIEcallback(event, callbackFunction) {
    var handler = document.createElement("script");
    handler.setAttribute("for", "pvctl");
    handler.event = event;
    handler.appendChild(document.createTextNode(callbackFunction));
    document.getElementById("runpview").appendChild(handler);
}

// dummy functions needed for the netscape6 plugin callbacks
function NSLoadEdComplete() {
  if( _docColorOption ) {
     ViewSetPropValueColor("model/" + VIEW_PROP_CLR_BKG,  _docColorOption);
     ViewSetPropValueColor("model/" + VIEW_PROP_CLR_GRAD, _docColorOption);
  }
  else {
     ViewSetPropValueColor("model/" + VIEW_PROP_CLR_BKG,  0x00000077);
     ViewSetPropValueColor("model/" + VIEW_PROP_CLR_GRAD, 0x00eeeeee);
  }
}

function NSDeselect() {}
function NSSelect() {}
var _docDisplayText ;
function NSDisplayText(string)
{
    _docDisplayText = string;
    window.setTimeout(DoDisplayText, 0);
}
function DoDisplayText()
{
    if (typeof decodeURIComponent == "function")
    {
        _docDisplayText = decodeURIComponent(_docDisplayText);
    }
    window.alert(_docDisplayText);
}

function NSSetStatusText(text) {
   if (typeof decodeURIComponent == "function")
    {
        try {
            text = decodeURIComponent(text);
        }
        catch (e)
        {
                return;
        }
    }
    window.defaultStatus=text;
}
function NSSetPage(i) {}
function NSGetLayerStates() {}
function NSReportError(msg) {}
function NSHelp() {}
function NSMove(compid) {}
function NSActivate(compid) {}
function NSView() {}
function NSPreferences() {}

function NSSelectInstance(text) {}
function NSDeSelectInstance(text) {}
function NSDeSelectAll() {}
function NSBeginSelect() {}
function NSEndSelect() {}
function NSPreSelectedInstance(text) {}
function NSClearPreSelection() {}

var confirmMessage =""
var confirmHandle =""
function DoConfirm()
{
        var ret = window.confirm(confirmMessage);
        document.pvctl.ConfirmReply(ret, confirmHandle);

}
function NSConfirm(text, handle)
{
      confirmMessage=text;
      confirmHandle=handle;
       window.setTimeout(DoConfirm, 0);
}

function NSCloseWindow()
{
    if(!_isVisTab)
    {
        window.onbeforeunload=null;
    }
    window.setTimeout(ClosePvWindow, 0);
}

function NSSetFocus()
{
    window.focus();
}

function ClosePvWindow()
{
    //This is code to set the window size in this sessions cookie.
    var mform = getMainForm();
    if(!mform.windowNameForCookie){
        mform.windowNameForCookie ={};
    }
    mform.windowNameForCookie.value = 'edrview_window';
    setWindowSizeCookie();

    window.close();
}

// NEW for netscape6.x support; NS6Callback is a mirror
// of the XPCOM nsIPVCadviewEvent class.  This is passed
// to the ns6 plugin and is used to map the callback functions
// into the plugin.
function NS6callback()
{
    // this structure mimics the nsIPVCadviewEVent object
    //
    this.OnLoadComplete        = LoadComplete;
    this.OnDoAction            = NSDoAction;
    this.OnSetStatusText       = NSSetStatusText;
    this.OnSelectInstance      = NSSelectInstance;
    this.OnDeSelectInstance    = NSDeSelectInstance;
    this.OnDeSelectAll         = NSDeSelectAll;
    this.OnBeginSelect         = NSBeginSelect;
    this.OnEndSelect           = NSEndSelect;
    this.OnCloseWindow         = NSCloseWindow;
    this.OnLaunchUrl           = NSLaunchUrl;
    this.OnPreSelectedInstance = NSPreSelectedInstance;
    this.OnClearPreSelection   = NSClearPreSelection;
    this.OnActiveViewTitle     = OnActiveViewTitle;

}



function OnLaunchUrlCallback()
{
    if(parent)
        parent.location.href=g_launchUrl;
    else
        location.href=g_launchUrl;
}

function NSLaunchUrl(text,target)
{
    if(target=="_blank" || target=="_BLANK")
    {
        window.open(text,target,"menubar=yes,location=yes,toolbar=yes,status=yes,resizable=yes,scrollbars=yes,minimizable=yes,close=yes,titlebar=yes ");
    }
    else if(target == "_top")
    {
        g_launchUrl = text;
        window.setTimeout(OnLaunchUrlCallback, 0);
    }
    else
    {
        window.open(text,target,"dialog");
    }
}

// NEW for netsacpe6.x support; this function should be called
// as part of the <body> OnLoad event (which signals that the
// plugin has been instanced fully).  This function creates a
// new NS6Callback object which gets passed to the plugin
function NSTimer()
{
    if (_docAction) eval(_docAction);
}
function NS6loaded() {
    if (_isFirefox || _isChrome)
    {
        var cb = new NS6callback;
        try
        {
            var retVal = document.pvctl.SetNSCallback(cb);
        }
        catch (e)
        {
            document.cookie="pvlite_plugin_failed=true;path=/";
            if (typeof _pvliteString_InitialisePlugin_Error != "undefined")
            {
                _local_InitialisePlugin_Error = _pvliteString_InitialisePlugin_Error;
            }
            else {
                _local_InitialisePlugin_Error = bundleHandler.getBundleStringAndInserts('com.ptc.wvs.server.ui.uiResource.PVLITE_INITIALIZE_PLUGIN_ERROR');
            }
            window.alert(_local_InitialisePlugin_Error + "\n" + e);
            url = window.location;
            window.location.href = url;
        }
    }

    // did we try overriding some page onload function?  If so, call it
    if (_docOnLoadOverride) _docOnLoadOverride();
}


function _UpdateThumbOrientation()
{
  if( _docViewOrientationOption ) {
     var s = _docViewOrientationOption.split(" ");
     document.pvctl.SetViewLocation(s[0]+" "+s[1]+" "+s[2]+" 0 "+s[3]+" "+s[4]+" "+s[5]+" 0 "+s[6]+" "+s[7]+" "+s[8]+" 0 0 0 0 1");
     document.pvctl.ZoomToAllTime(0);
  }
}

function thumbview(thumbnail, thumbnail3d, actionString, width, height, downloaddir, versionstrings, pviewhome, options)
{
    logger.debug("thumbview");
   if( options && options.length > 0 ) {
       logger.debug("options = " + options);
      var i = options.indexOf(";");
      var opt= options;
      if( i >= 0 ) {
         opt = options.substring(0, i);
         if( i < options.length ) {
            options = options.substring(i+1);
         }
         else {
            options = null;
         }
      }
      else {
         options = null;
      }
      i = opt.indexOf(" ");
      if( i > 0 ) {
         _docColorOption = Math.floor(new Number(opt.substring(0,i)));
         _docGradColorOption = Math.floor(new Number(opt.substring(i+1)));
      } else {
         _docColorOption = Math.floor(new Number(opt));
         _docGradColorOption = null;
      }

      if( options && options.length > 0 ) {
         var i = options.indexOf(";");
         var opt = options;
         if( i >= 0 ) {
            opt = options.substring(0, i);
            if( i < options.length ) {
               options = options.substring(i+1);
            }
            else {
               options = null;
            }
         }
         else {
            options = null;
         }
         _docViewOrientationOption = opt;

         if( options && options.length > 0 ) {
            _docAdditionalOption = options;
         }
      }
   }

   _docAction = actionString;
   var params;
   var httpsIndex = thumbnail3d.indexOf("https:");
   var httpIndex = thumbnail3d.indexOf("http:");


   // Check whether we are loading a pvt or ProE data. If the url starts http(s) then we are a pvt
   if(httpsIndex == 0 || httpIndex == 0)
   {
       params += " src='"+ thumbnail3d + "'";
       params += " renderatstartup='true'";
   }
   else
   {
       params = getProEConnectionId(thumbnail3d);
       params += " renderatstartup='auto' ";
       params += " configOptions='gnomon=\"false\" navigation=\"proe\" watermarks=\"false\" selection=\"parts\" selectioncallback=\"pvx\"'";
   }
   params += " thumbnailView='true' getetb='false'";
   _visNavEvents = null;  //do we need to set var _isVisTab to null here?
   logger.debug("params = " + params);
   PV_InsertPlugin(params, thumbnail, width, height, downloaddir, versionstrings, pviewhome);
}

function PVLite(embedOptions, downloadDir, versionStrings, visNavEvents)
{
    logger.debug("PVLite");
      if( visNavEvents != null && visNavEvents != "null")
      {
    _visNavEvents = visNavEvents;
      }

    PV_InsertPlugin(embedOptions, null, "100%", "100%", downloadDir, versionStrings, "");
}


function pvloaded()
{
    window.setTimeout(pvloadedtimeout, 1);
}

function pvloadedtimeout()
{
    if(_visNavEvents != null )
    {
        try {
           eval( _visNavEvents );
        } catch(e) {}
        _visNavEvents = null;
    }
    else
    {
        var cb = new NS6callback;
        try
        {
            var retVal = document.pvctl.SetNSCallback(cb);
        }
        catch (e)
        {

        }
    }
}

var PVLiteWin = null;
function setPVLiteWin(win, dialogName) { if( win!=null && dialogName=="ProductViewLite" ) getMainWindowForPVLite().PVLiteWin = win; }

function getMainWindowForPVLite()
{
   try {
      if ( Ext.isIE ) {
         // conditions to properly stop recursion for IE with and without multiple tabs
         if ( history.length == 0 && top.window.opener==null) { //Clipboard has history == 0 but we want window.opener if it is not closed
            return top.window;
         }
         else if( top.window.opener == null || top.window.opener.document == null || top.window.opener.closed ) {
             return top.window;
         }
         else if ( history.length == 1 ) {
             return top.window;
         }
         else {
            if( top.window.opener!=null && !top.window.opener.closed ) return top.window.opener.getMainWindowForPVLite();
         }
      }
      else {
         if( top.window.opener!=null && !top.window.opener.closed ) return top.window.opener.getMainWindowForPVLite();
      }
   } catch (e) {}
   return top.window;
}

/**
 * Evaluate the URL to determine if the target representation is marked out of date. If so, a
 * confirmation dialog will be displayed allowing the user to proceed opening Creo View or not.
 *
 * @return {boolean} True only if the validation has determined the target representation is 
 *                   marked out of date.
 */
function doMarkOutOfDateValidation(dialogURL, dialogName, opts) {

   var isOutOfDate = (dialogURL.indexOf("outofdate=1") >= 0);
   
   if (isOutOfDate) {
      var outOfDateWin = new Ext.Window({
         title: bundleHandler.get('com.ptc.wvs.client.beans.messageResource.VIEW_OOD_TITLE'),
         width: 350,
         height: 140,
         modal: true,
         footer: true,
         resizable:false,
         draggable:false,
         shadow: true,
         shadowOffset: 6,
         layout: {
            type: 'hbox',
            pack: 'center'
         },
         items: [new Ext.Panel ({
            border: false,
            margins: "10 5 10 5", //top,right,bottom,left
            html: '<table><tr><td><img src="netmarkets/themes/windchill/window/icon-question.gif"></td><td>' + bundleHandler.get('com.ptc.wvs.client.beans.messageResource.VIEW_OOD_MESSAGE_AND_CONTINUE') + '</td></tr></table>'
         })
         ],
         buttons : [
            {  id: 'yes',
               text: bundleHandler.get('com.ptc.wvs.client.beans.messageResource.YES'),
               handler: function() {
               
                  outOfDateWin.hide();
               
                  // Remove the out of date flag contained as a parameter in the URL to prevent
                  // the display of the message again.
                  dialogURL = dialogURL.replace("outofdate=1&", "");
                  dialogURL = dialogURL.replace("outofdate=1", "");
                  
                  // Invoke the launch of Creo View, in which the "checkaddtopv" will be called again.             
                  window.setTimeout(createDialogWindowOptions(dialogURL, dialogName, opts), 0);
               }
            },
            {  id: 'no',
               text: bundleHandler.get('com.ptc.wvs.client.beans.messageResource.NO'),
               handler: function() {
                  outOfDateWin.hide();
              }
            },
            {  id: 'ofddetails',
               text: bundleHandler.get('com.ptc.wvs.client.beans.messageResource.VIEW_OODDET_BUTTON'),
               handler: function() {
                  
                  // Get the objref parameter from the URL
                  var params = dialogURL.split("&objref=");
                        
                  createDialogWindow('wtcore/jsp/wvs/repood.jsp?repref='+params[1], 'RepOutOfDate','600','400', '0');
               }
            }
         ]
      });
      
      outOfDateWin.show();
   }

   return isOutOfDate;
}

function checkaddtopv(dialogURL, dialogName, opts)
{

   PTC.wvs.log("dialogURL=" + dialogURL);
   PTC.wvs.log("dialogName=" + dialogName);
   PTC.wvs.log("opts=" + opts);

   if (doMarkOutOfDateValidation(dialogURL, dialogName, opts)) {
       // Return true since the mark out of data validation has displayed a confirmation dialog to the
       // user and we need to terminate the launch execution of this thread. User selecting "Yes" to
       // continue the launching of Creo View will initiate a new thread.
       return true;
   }
   
   var launchCreoViewWithPlugin = (PTC.wvs.forceuseplugin != null && PTC.wvs.forceuseplugin === true)? true:false;
   if (PTC.wvs.forceuseplugin == null) { // Force flag was not specified, check wvs.properties for default value
      if (_isIE) {
         if ("true" === PTC.wvs.properties.getProperty("wvs.openincreoview.use.plugin.ie")) {
            launchCreoViewWithPlugin = true;
         }
      }

      if (_isFirefox) {
         if ("true" === PTC.wvs.properties.getProperty("wvs.openincreoview.use.plugin.firefox")) {
            launchCreoViewWithPlugin = true;
         }
      }
      // Check if the given URL contains the parameter to force the usage of the plugin or not.
      //beside debug/testing, forceuseplugin is also used by different applications to enforce
      //the use of plugin mode.
      if (dialogURL.indexOf("forceuseplugin=true") >= 0) {
         launchCreoViewWithPlugin = true;
      }
      if (dialogURL.indexOf("forceuseplugin=false") >= 0) {
         launchCreoViewWithPlugin = false;
      }

   }

   if (launchCreoViewWithPlugin === false && dialogName === 'ProductViewLite' && dialogURL.indexOf("sendToPublisher") == -1) {

      // Define the "browser" parameter setting to reflect the current Windchill browser. One exception, is that we will
      // not set the parameter when coming from the embedded browser. The browser parameter will be used by Creo View when
      // a need to launch a browser window to support URLs in uiconfig.xml i.e. Copy to Windchill Clipboard.
      var browser = null;
      if (!_isEmbededCreo) {
         if (_isIE) {
            browser = "ie";
         }
         else if (_isFirefox) {
            browser = "firefox";
         }
         else if (_isChrome) {
            browser = "chrome";
         }
         else if (_isEdge) {
            browser = "edge";
         }
      }

      // Initialize a session context in Windchill to be used as a transferring mechanism of the Windchill user's
      // session to the authenticated Creo View session, ensuring any URLs that Creo View invokes will have
      // dependent cached data available i.e. clipboard bean. The Creo View service process will call the
      // REST Visualization Service, getClientParams that will consume the information in the session context.
      var url = PTC.wvs.getWVSGatewayURL('com.ptc.wvs.server.ui.UIHelper', 'getOpenInCreoViewServiceCustomURI');
      new Ajax.Request(
         url,
         {
            asynchronous: false,
            method: 'post',
            parameters: {
               linkurl: dialogURL,
               browser: browser
            },
            onSuccess: function(transport) {
               var response = Ext.util.JSON.decode(transport.responseText);

               PTC.wvs.log("Creo View Custom URI: " + response.uri);

               // Add a new event to the browser event queue; allows the rendering to complete before the
               // execution of the event. Using the "setTimout" function here addressed the issue in the
               // embedded browser, invoking the Open in Creo View action from the drop down menu.
               window.setTimeout(function(){window.location=response.uri;}, 0); // Launch the Creo View Custom URI
            },
            onFailure: function(){
               PTC.wvs.error("An error occurred when attempting to perform an Ajax call to " + url);
            }
         });

      return true;
   }

   if( dialogName != "ProductViewLite" ) return false;
   try {
        var _PVLiteWin = getMainWindowForPVLite().PVLiteWin;
        if( _PVLiteWin == null || _PVLiteWin.closed ) return false; // no current open PV win
    }
    catch(e) { // SPR 4338632 - Creo view to launch second time in embedded browser
    }

   var pvbatchprint = false;
   try {
      var pvtag = _PVLiteWin.document.getElementById("pvctl");
      if( pvtag == null ) return false; // open PV win but no pv, eg publish

      if( _isIE ) {
         var xx = pvtag.innerHTML + "";
         if( xx.indexOf("NAME=\"batchprint\" VALUE=\"true\"") != -1 || xx.indexOf("name=\"batchprint\" value=\"true\"") != -1 ) {
            pvbatchprint = true;
         }
      } else {
         var bptag = pvtag.getAttribute("batchprint");
         if( bptag != null && bptag ) pvbatchprint = true;
      }
   } catch(e) { return false; }
   var batchprint = dialogURL.split("batchprint=").length>1?true:false;

   if( pvbatchprint != batchprint ) return false;

   var theURL;
   if ($('basehref')) {
       var href = $('basehref').href;
       theURL = (href + "servlet/WindchillAuthGW/com.ptc.wvs.server.ui.ThumbnailHelper/getAddToPVMessages");
     } else {
       theURL = 'servlet/WindchillAuthGW/com.ptc.wvs.server.ui.ThumbnailHelper/getAddToPVMessages';
     }
   var xmlhttp = newHttp();
   xmlhttp.open('GET', theURL, false);
   setHeaders(xmlhttp);
   xmlhttp.send(null);

   if (xmlhttp.readyState==4 && xmlhttp.responseText && xmlhttp.responseText.length>0 ) {
      try {
         var s = xmlhttp.responseText.split("\n");
         Ext.Msg.show({
            title: batchprint?s[1]:s[0],
            msg: s[2],
            buttons: {yes:s[3], no:s[4], cancel:s[5]},
            fn: checkaddtopv_callback,
            icon: Ext.MessageBox.QUESTION,
            modal: false,
            pvlitewin: _PVLiteWin,
            pvlitedialogURL: dialogURL,
            pvliteopts: opts
         });
         return true;
      } catch(e) {}
   }

   return false;
}
function checkaddtopv_callback(btn, t, obj)
{
   if( btn == "cancel" ) {
      return;
   } else if( btn == "no" || (btn == "yes" && obj.pvlitewin.closed)) {
      try {
         if( !obj.pvlitewin.closed ) obj.pvlitewin._windowBeforeUnloadMsgFlag = false;
         var newwin = wfWindowOpen(obj.pvlitedialogURL, "ProductViewLite", obj.pvliteopts);
         if( newwin != null ) {
            getMainWindowForPVLite().PVLiteWin = newwin;
            newwin.focus();
         }
      } catch(e) {}
      return;
   }

   // Get the full URL in Creo View.
   var dialogURL = obj.pvlitedialogURL;
   PTC.wvs.log("dialogURL: " + dialogURL);

   // Need to retrieve the container OID from the URL for sandbox use case.
   var s = dialogURL.split("ContainerOid=");
   var containerOid = "";
   if( s.length > 1 ) {
      containerOid = s[1].split("&")[0].replace(/%3A/g,":");
   }

   // Do we have a object reference. If in clipboard case, there will not be an object reference.
   var objref = "";
   s = dialogURL.split("partid=");
   if( s.length > 1 ) {
      objref = s[1].split("&")[0].replace(/%3A/g,":");
   } else {
      s = dialogURL.split("objref=");
      if( s.length > 1 ) {
         objref = s[1].split("&")[0].replace(/%3A/g,":");
      }
   }

   // Check if this is coming from the clipboard.
   var fromclip = "";
   if( dialogURL.indexOf("fromclip=1") >= 0 ) {
      //var d = new Date();
      //edurl += (dialogURL.indexOf("?"==-1)?"?ct=":"&ct=") + d.getTime();
      fromclip="true";
   }

   PTC.wvs.log("objref=" + objref + " containerOid=" + containerOid + " fromclip=" + fromclip);

   // Get PVS and EDM URLs.
   var url = PTC.wvs.getWVSGatewayURL('com.ptc.wvs.server.util.WVSContentHelper', 'getDownloadURLForBranchLink');
   new Ajax.Request(
        url,
        {
            asynchronous: false,
            method: 'post',
            parameters: {
                oid: objref,
                fromclip: fromclip,
                containeroid: containerOid
            },
            onSuccess: function(transport) {
                PTC.wvs.log("getBranchLinks: onSuccess");

                var allurls = eval("(" + transport.responseText + ")");
                PTC.wvs.log("allurls: " + allurls.length);

                for (var i=0; i < allurls.length; i++) {
                   var urls = allurls[i];

                   PTC.wvs.log("url:" + urls.url);
                   PTC.wvs.log("edmurl:" + urls.edmurl);

                   try {
                      obj.pvlitewin.document.pvctl.InsertBranchLink("/", "", urls.url, urls.edmurl, "", true, true);
                      obj.pvlitewin.focus();
                   } catch(e) {PTC.wvs.log("exception occurred during insert branch link: " + e);}
                }
            },
            onFailure: function(){
                PTC.wvs.error("getBranchLinks: An error occurred when attempting to perform an ajax call to retrieve branch link URLs" + url);
            }
       }
   );
}

/**
 * Sets the cache size for corresponding browser in use if available, else uses the global cache size.  
 */

function initializeWebGLCache() {
    try {
        if ((ThingView.loadedPreferences !== undefined) && (ThingView.loadedPreferences !== "")) {
            var fileCacheSetting = undefined;
            if (ThingView.loadedPreferences["Gen.FileCache"] !== undefined) {
                fileCacheSetting = ThingView.loadedPreferences["Gen.FileCache"];
            }
            if (fileCacheSetting !== undefined) {
                if (fileCacheSetting === true) {
                    if (ThingView.loadedPreferences["Gen.FileCacheSize"]) {
                        var fileCacheSize = ThingView.loadedPreferences["Gen.FileCacheSize"];
                        window.MyThingView.session.EnableFileCache(Number(fileCacheSize));
                        return;
                    }
                }
                return;
            }
        }
    } catch (e) {
    }

    var cacheSize = PTC.wvs.webgl.getCacheSizeForVizTab();
    
    if(cacheSize >0) {
            logger.debug("Using cache size: " + cacheSize);
            window.MyThingView.session.EnableFileCache(cacheSize);
    }
    else {
            logger.debug("IndexedDB caching is not enabled. ");
    }
}

function isLoadCompleted() { return isLoadingVisTabComplete; }
function getWebGlLoadDuration() { return WebGlLoadDuration; }

