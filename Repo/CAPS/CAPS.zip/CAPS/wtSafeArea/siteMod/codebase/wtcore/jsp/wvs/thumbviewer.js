///
// javascript functions to support thumbnail viewer from property pages
//

// //////////////////////////////////////////////////////////////
// determine which browser we are running in - this global
// value _isIE is used elsewhere in the pvcadview scripts
// //////////////////////////////////////////////////////////////
var _isIE = false;
var _is64bitIE = false;
var _isNS6 = false;
var ver = navigator.appVersion;
if (ver.indexOf("MSIE") != -1)
{
  _isIE=true;
  if (ver.indexOf("Win64") != -1)
  {
        _is64bitIE = true;
  }
}
if (ver.indexOf("5.0") == 0)
  _isNS6=true;


// //////////////////////////////////////////////////////////////
// document-specific functions
// //////////////////////////////////////////////////////////////
var _docType="application/x-pvlite9-ed";
			  // defines the type of viewable (drawing or model)
var _docPluginVersion;	  // version string of the form '1.2.3.4'
var _docPluginURL;	  // version string of the form '1.2.3.4'
var _docAction;
var g_pluginParams;
var _docOnLoadOverride;
var _docColorOption;
var _docViewOrientationOption;
var _docAdditionalOption;
var g_downloaddir;
var _urllist;
var _visNavEvents = null;
var _windowBeforeUnloadOverride = null;
var _local_UpgradeTitle = "A new version of ProductView Lite is available for download";
var _local_UpgradeContinue = "Use currently installed viewer";
var _local_UpgradeInstall = "Upgrade viewer";
var _local_Install="Install ProductView Lite";
var _local_Enable_SoftwareUpdate = "You must enable Software Update to install this plugin";
var _local_Install_Failed = "ProductView Lite installation failed";
var _local_Unsupported_Browser = "Unsupported browser platform";
var _local_InitialisePlugin_Error = "An error occured initialising the ProductView Lite plugin";
var _local_Restart_Needed = "You need to restart your browser to complete the ProductView Lite installation";
var _local_nocheck= "Stop Checking for new versions";
var _local_ExitViaProductMenu="ProductView should be closed via the main menu.\nContinuing may result in lost data!";
var g_docLoadedAction=0;
var g_oldLoadedFunc=null;
var g_width=null;
var g_height=null;
var g_resetMainDivSize = false;

// Temporary don't run any plugins unless on the Windows platform
var g_platformSupported=false;
function PV_InsertPlugin(params, img, width, height, downloaddir, versionstrings, pviewHome)
{
    g_width = width;
    g_height = height;
    g_pluginParams = params;
    var _browser_type = "";
    var _browser_platform = "";
    var _imageOnly = false;
    var cookies = document.cookie;
    var pvVerChecked = cookies.indexOf("pvlite_version_checked");
    var pvVerRebootNeeded = cookies.indexOf("pvlite_reboot_needed");
    var pvVerPluginFailed = cookies.indexOf("pvlite_plugin_failed");
    g_downloaddir = downloaddir;
    var _docPluginDownloadURL = downloaddir + "/" + _docPluginURL;

    if (navigator.platform == "SunOS sun4u")
    {
        g_platformSupported=true;
        _browser_platform="sun4_solaris";
    }
    if (navigator.platform == "SunOS i86pc")
    {
        g_platformSupported=true;
        _browser_platform="sun_solaris_x32";
    }
    if (navigator.platform == "Win32")
    {
        g_platformSupported=true;
        if (_is64bitIE)
        {
            _browser_platform = "x86e_win64";
        }
        else
        {
            _browser_platform = "i486_nt";
        }
    }
    if (navigator.platform == "Win64")
    {
        g_platformSupported=true;
        _browser_platform = "x86e_win64";
    }
    if (navigator.platform.substring(0,5) == "HP-UX")
    {
        _browser_platform = "hpux11_pa32";
    }
    if (navigator.platform.substring(0,3) == "AIX")
    {
        _browser_platform = "ibm_rs6000";
    }
//    if (_browser_platform == "")
//    {
//        if (typeof _pvliteString_Unsupported_Browser != "undefined")
//        {
//            _local_Unsupported_Browser = _pvliteString_Unsupported_Browser;
//        }
//        window.alert(_local_Unsupported_Browser +"\n" + navigator.platform);
//        return;
//    }
    if (navigator.appName == "Netscape")
    {
        _browser_type = "ns";
    } else
    {
        _browser_type = "ie";
    }
    if (_browser_type == "" || _browser_platform == "")
    {
        _imageOnly = true;
    } else
    {
        var _browser = _browser_platform + "_" + _browser_type + "/";
        var vs = versionstrings;
        while(true)
        {
            var loc = vs.indexOf(";");

            var v = loc!=-1?vs.substring(0,loc):vs;
            if( v.indexOf(_browser) == 0 ) {
                var versionLoc = v.lastIndexOf('/');

                _docPluginVersion = v.substring(versionLoc+1);
                _docPluginURL = v.substring(0,versionLoc);
            }

            if( loc == -1 ) break;
            vs = vs.substring(loc+1);
        }
    }

    g_oldLoadedFunc = window.onload;
    window.onload = docLoaded;
    IECallbackEvents();
    
    if( (width == "100%") && (height == "100%") )
    {
        // Disable F1 Help provided by the browser when running in full screen mode(onhelp is ie only and ignored by Firefox).
        document.body.onhelp=function keyhit(){ event.returnValue=false;};
        document.body.onmousewheel=function mousewheel(){event.returnValue=false;}; 
        document.onkeypress = keyHit;
        if(_visNavEvents == null)
        {
            _windowBeforeUnloadOverride = window.onbeforeunload;
            window.onbeforeunload=pvBeforeUnload;
        }
        document.write('<div style="position:relative;top:0;left:0;border-width:0px;border-style:none;width:'+width + ';height:'+height+'">');
    }
    else
    {

        if(_isIE)
        {
            document.write('<div style="position:relative;top:0;left:0;border-width:0px;border-style:none;width:'+width + ';height:'+height+'">');
        }
        else
        {
            g_resetMainDivSize = true;
            document.write('<div id="pvmaindiv" style="position:relative;top:0;left:0;border-width:0px;border-style:none;">');
        }
            
    }

    if (img != null)
    {
        document.write('<div id=pview_img style="position:relative;top:0;left:0;border-width:0px;border-style:none;width:'+width + ';height:'+height +'">');
        document.write('</div>');
    }
    
    if(g_platformSupported==false)
    {
        if(img == null)
        {
            alert("Platform not supported");
        }
    }
    else
    {
        document.write('<div align=center id=pview_upgrade style="position:relative;top:0;left:0;border-width:0px;border-style:none">');
        document.write('</div>');
        g_docLoadedAction = 0 ;
		
		/* Replaced content as per PTC CS27008 Workaround with the above single line
		if (_docPluginVersion && pvVerChecked == "-1" )
        {
            document.write('<div id=checkpview style="visibility:hidden;position:absolute;top:2;left:2;zIndex=-1;width:0;height:0;border-style:none">');
            document.write(GetPvCheckHtml());
            document.write('</div>');
            g_docLoadedAction = 1 ; // Test client
        }
		*/
		
		
        document.write('<div id=runpview style="visibility:hidden;position:absolute;top:0;left:0;width:'+width+';height:'+height+';zIndex=-1;border-width:0px;border-style:none">');
        document.write('</div>');
        document.write('</div>');
        
    }
    if (img != null)
        document.getElementById("pview_img").innerHTML = '<A HREF="'+_docAction+'" ><IMG SRC="'+img+'" style="border-height:0;border-width:0;border-style:none;" width=100% height=100% ></IMG></A>';

}

function pvBeforeUnload()
{
    if(_windowBeforeUnloadOverride) _windowBeforeUnloadOverride();
    return _local_ExitViaProductMenu;
}

function keyHit(event) 
{

    if (event.keyCode == event.DOM_VK_F1) 
    {
        // cancel browser app event handler for F1 key
        event.stopPropagation()
        event.preventDefault()
    }
} 

function docLoaded()
{
    if (g_oldLoadedFunc)
    g_oldLoadedFunc();
    
    // If not supported platform just return
    if(g_platformSupported==false)
    {
        return;
    }
    
    //window.alert("docLoaded readystate " + document.pvVerCtl.ReadyState);
    if (g_docLoadedAction == 0)
    {
        StartPview();
        return;
    }

    if (g_docLoadedAction == 1)
    {
        try
        {
            var vi="";
            if (document.pvVerCtl.ReadyState != 4)
            {
                StartPview();
                return;
            }


            var isInstalled = document.pvVerCtl.CheckPview(_docPluginVersion);
            var installedVersion = document.pvVerCtl.GetInstalledVersion();

            //window.alert("IsInstalled is " + isInstalled);
            if (isInstalled == 0) // Pview Not installed so need to install it
            {
                if (typeof _pvliteString_Install != "undefined")
                {
                    _local_Install= _pvliteString_Install;
                }

                document.getElementById("pview_upgrade").innerHTML += '<A class=wizardlabel HREF="javascript:void(DoInstall())" TITLE="'+_docPluginVersion+'">'+_local_Install+'</A>';
            }
            if (isInstalled == 1) //pview is installed and up to date so just run
            {
                StartPview();
            }
            if (isInstalled == 2) //pview is installed But can be upgraded
            {
                if (typeof _pvliteString_UpgradeContinue != "undefined")
                {
                    _local_UpgradeContinue= _pvliteString_UpgradeContinue;
                }
                if (typeof _pvliteString_UpgradeTitle != "undefined")
                {
                    _local_UpgradeTitle= _pvliteString_UpgradeTitle;
                }
                if (typeof _pvliteString_UpgradeInstall != "undefined")
                {
                    _local_UpgradeInstall= _pvliteString_UpgradeInstall;
                }
                document.getElementById("pview_upgrade").innerHTML +='<A class=wizardlabel HREF="javascript:void(DoInstall())" TITLE="'+_docPluginVersion+'">'+_local_UpgradeInstall+'</A><BR><A class=wizardlabel HREF="javascript:void(DoNotInstall())" TITLE="'+installedVersion+'">'+_local_UpgradeContinue+'</A><BR>';
            }
        }
        catch(e)
        {
            StartPview();
        }
    }
}

function OnInstalledFinished( name , result ){
    if(result == 0)
    {
        PV_InsertPlugin(thumbnail3d, thumbnail, width, height, downloaddir, versionstrings, pviewhome,false);
    }
    else
    {
        alert("Download failed");
    }
}

function StartPview()
{
    document.getElementById("pview_upgrade").style.visibility = 'hidden';
    document.getElementById("pview_upgrade").style.display = 'none';
    document.getElementById("pview_upgrade").style.height = "0";
    if(g_resetMainDivSize)
    {
        document.getElementById("pvmaindiv").style.height=g_height;
        document.getElementById("pvmaindiv").style.width=g_width;            
    }
    //    document.cookie="pvlite_version_checked=true;path=/";
    document.getElementById("runpview").innerHTML=GetPviewHtml();
    document.getElementById("runpview").style.visibility = 'visible';

    try
    {
        document.pvctl.IsRunning();
    }
    catch(e)
    {
        document.getElementById("runpview").style.visibility = 'hidden';
        var cookies = document.cookie;
        var pvVerChecked = cookies.indexOf("pvlite_version_checked");
        if (pvVerChecked == "-1")
        {           
            if (typeof _pvliteString_nocheck != "undefined")
            {
                _local_nocheck= _pvliteString_nocheck;
            }
            document.getElementById("pview_upgrade").innerHTML = '<A class=wizardlabel HREF="javascript:void(DoInstall())" TITLE="'+_docPluginVersion+'">'+_local_Install+'</A><BR>';
            document.getElementById("pview_upgrade").innerHTML += '<A class=wizardlabel HREF="javascript:void(DoNotCheck())" TITLE="'+_docPluginVersion+'">'+_local_nocheck+'</A>';
        }
    }
}

function ConvertNSParamsToIE(nsParams)
{
        var params = "";
        var startloc = 0;
        while(true)
        {
            var loc = nsParams.indexOf("=", startloc);
            if (loc == -1)
                break;
            params += "<param name='";
            var nameStartLoc = nsParams.lastIndexOf(' ', loc);
            params += nsParams.substring(nameStartLoc+1,loc);
            
            params += "' value=";
            var loc1 = nsParams.indexOf("'", startloc);
            var loc2 = nsParams.indexOf("'", loc1+1);
            params += nsParams.substring(loc1,loc2+1);
            params += ">";
            startloc = loc2+1;
         }
        return params;
}

function GetHelpUrl()
{
    if (_isIE)
    {
        var browserLang = navigator.userLanguage.substring(0,2);
        var helpUrl = " helpurl='/wt/helpfiles/help_" + browserLang + "/online/'";
        return helpUrl;
    }
    else
    {
        var browserLang = navigator.language.substring(0,2);
        var helpUrl = " helpurl='/wt/helpfiles/help_" + browserLang + "/online/'";
        return helpUrl;
    }
}

function GetPviewHtml()
{
    g_pluginParams += GetHelpUrl();

    var htmlString="";
    if (_isIE)
    {
        var ieParams = ConvertNSParamsToIE(g_pluginParams);
        if (_is64bitIE)
        {                                         
            htmlString += '<object classid="CLSID:F1BFCEEA-892D-405c-945F-19F87338A17F" id="pvctl"';
        } else
        {
            htmlString += '<object classid="CLSID:F07443A6-02CF-4215-9413-55EE10D509CC" id="pvctl"';
        }
        if (_docType) htmlString +=' type="' + _docType + '"';
        htmlString += ' width=100%';
        htmlString += ' height=100%';
        htmlString += '>\n';
        htmlString += ieParams;
        htmlString += '</object>\n';
    }
    else
    {
        
        htmlString += '<embed name="pvctl" ';
        htmlString += ' type="application/x-pvlite9-ed" ';
        htmlString += ' width=100%';
        htmlString += ' height=100% '; // add space to make sure params are seperated
        htmlString += g_pluginParams;
        htmlString += '>\n';
    }

    return htmlString;
}

function CompareVersion(downloadVersion, installedVersion)
{
    var loc1=0;
    var loc2=0;
    for (i=0; i< 4; i++)
    {
        var val1, val2;
        var locEnd = downloadVersion.indexOf('.',loc1);
        if (locEnd != -1)
            val1 = eval(downloadVersion.substring(loc1,locEnd));
        else
            val1 =eval(downloadVersion.substring(loc1));
        loc1 = locEnd+1;
        locEnd = installedVersion.indexOf('.',loc2);
        if (locEnd != -1)
            val2 = eval(installedVersion.substring(loc2,locEnd));
        else
            val2 = eval(installedVersion.substring(loc2));
        loc2 = locEnd+1;
        if (val1 > val2)
            return false;
        if (val1 < val2)
            return true;
    }
    return true
}
function GetPvCheckHtml()
{
    var htmlString="";
    if (navigator.appName == "Netscape")
    {
        var L = navigator.plugins.length;
        var usePlugin = false;
        for (i=0; i< L; i++)
        {
            if(navigator.plugins[i].name == "ProductView Version Checker")
            {
                v = navigator.plugins[i].description;
                var versionLoc = v.lastIndexOf(' ');

                var instVer =  v.substring(versionLoc+1);
                usePlugin= CompareVersion(_docPluginVersion, instVer);
                break;
            }
        }
        if(usePlugin)
        {
            htmlString += '<embed name="pvVerCtl" ';
            htmlString += ' id="pvVerCtl"';
            if (_docPluginURL) htmlString += ' pluginurl=' + g_downloaddir + "/" + _docPluginURL;
            htmlString += ' pluginspage="' + g_downloaddir + "/" + _docPluginURL +'"';
            htmlString += ' type="application/x-pvlite9-ver" ';
            htmlString += ' hidden="true"';
            htmlString += ' autostart="true"';
            htmlString += '>\n';
        }
        else
        {
            xpi={'XPInstall ProductView Version Checker':g_downloaddir + "/" + _docPluginURL};
            InstallTrigger.install(xpi,OnInstalledFinished);
        }
    }
    else
    {
        if(_is64bitIE)
        {
            htmlString += '<object classid="CLSID:82DBCFDB-5658-4cfb-B32B-0828247043C0" id="pvVerCtl"';
        }
        else
        {
            htmlString += '<object classid="CLSID:F694EA1F-2EC1-445D-8988-1862AD0CC4C8" id="pvVerCtl"';    
        }
        
        if (_docType) htmlString +=' type="' + _docType + '"';
        if (_docPluginURL) htmlString +=' codebase="' + g_downloaddir + "/" + _docPluginURL;
        
        if (_docPluginVersion) htmlString +='#version=' + _docPluginVersion;
        if (_docPluginURL)  htmlString += '"';

        htmlString += '>\n';
        htmlString += '</object>\n';
        
       
    }

    return htmlString
}




function DoNotInstall()
{
    document.cookie="pvlite_version_checked=true;path=/";
    StartPview();
}
function installDone()
{
    StartPview();
}

function installCancel()
{
}

function DoNotCheck()
{
    document.cookie="pvlite_version_checked=true;path=/";
    document.getElementById("pview_upgrade").style.visibility = 'hidden';
    document.getElementById("pview_upgrade").style.display = 'none';
    document.getElementById("pview_upgrade").style.height = "0";

}

function DoInstall()
{
    var opts = "dependent=yes,toolbar=0,location=0,directory=0,status=1,menubar=0,scrollbars=1,resizable=1,width=760,height=510";
    var modalWin = wfWindowOpen( g_downloaddir+"/download_cvmcad.jsp?notify=true", "hello", opts );

    /**
    var UTCString;
    today=new Date();
    nummilli=Date.parse(today);
    today.setTime(nummilli+-1*24*24*60*1000);
    expires=today.toUTCString();
    document.cookie="pvlite_plugin_failed=;path=/;expires="+expires;
    document.cookie="pvlite_version_checked=;path=/;expires="+expires;
    InstallTrigger.install(_urllist, _xpiInstallCallback);
    */
 }

function _xpiInstallCallback(url, status)
{
   url = window.location;
   if (status == 0)
   {
     navigator.plugins.refresh(false);
     window.location.href = url;
     document.cookie="pvlite_version_checked=true;path=/";
   }
   else     if (status == 999)
   {
     window.location.href = url;
     document.cookie="pvlite_reboot_needed=true;path=/";
   }
   else  {
     if (typeof _pvliteString_Install_Failed != "undefined")
     {
        _local_Install_Failed= _pvliteString_Install_Failed;
    }
    msg = _local_Install_Failed +" " +status+"\n"+url;
    window.alert(msg);
  }
}

////////////////////////////////////////////////////
var VIEW_PROP_CLR_BKG                    = "clrBkg"
var VIEW_PROP_CLR_WBKG                   = 2
var VIEW_PROP_CLR_GRAD                   = "clrGradient"
var VIEW_PROP_BOOL_GNOMON                = 52
var VIEW_PROP_BOOL_HIGHLIGHTCOLOR        = 51
var VIEW_PROP_BOOL_BBOXSEL               = 69
var VIEW_PROP_BOOL_2BUTTONMOUSE			 = 93
var COMPONENT_PROP_BOOL_LOCKED           = 25

function _RGB2BGR(rgb)
{
  // flip
  tmpred = (rgb & 0x00ff0000);
  tmpblue = (rgb & 0x000000ff);
  return ((tmpblue << 16) | (rgb & 0x0000ff00) | (tmpred >> 16));
}
function ViewSetPropValueColor(propid, propVal)
{
  return document.pvctl.SetPropValueInt(propid, propVal);
}
function ViewSetPropValueBool(propid, propVal)
{
  return document.pvctl.SetPropValueBool(propid, propVal);
}
function ComponentSetPropertyBool(propid, propVal)
{
  document.pvctl.SetComponentPropertyBool(propid, propVal);
}

function NSInitialised()
{
  document.pvctl.SetSrc(_docPvtURL);
  document.pvctl.SetPvAppLiteMode(1);
  ViewSetPropValueColor(VIEW_PROP_CLR_WBKG, 0x00eeddcc);
  ViewSetPropValueBool(VIEW_PROP_BOOL_GNOMON, false);
  ViewSetPropValueBool(VIEW_PROP_BOOL_HIGHLIGHTCOLOR, false);
  ViewSetPropValueBool(VIEW_PROP_BOOL_BBOXSEL, false);
  ViewSetPropValueBool(VIEW_PROP_BOOL_2BUTTONMOUSE, true);

  if( _docAdditionalOption ) {
     eval(_docAdditionalOption);
  }
}
function NSLoadComplete()
{
    document.getElementById("pview_upgrade").style.visibility = 'hidden';
    document.getElementById("pview_upgrade").style.display = 'none';
    document.getElementById("pview_upgrade").style.height = "0";
    
    if( typeof(pview_img) != "undefined" ) {
        document.getElementById("pview_img").style.visibility = 'hidden';
    }
    
    if(_docColorOption)
    {
        document.pvctl.backgroundcolor=(_docColorOption & 0x00ffffff).toString(16);
    }
    else
    {
        document.pvctl.backgroundcolor="0x00000077:0x00eeeeee";
    }

    _UpdateThumbOrientation();
}


function NSDoAction()
{
    window.setTimeout(NSTimer, 0);
}

function IECallbackEvents()
{
    if( _isIE )
    {
        if( _visNavEvents != null ) {
           eval( _visNavEvents );
        }
        else {
           document.write("<script for='pvctl' event='OnDoAction()'>NSDoAction()</script>\n");
           document.write("<script for='pvctl' event='Initialised()'>NSInitialised()</script>\n");
           document.write("<script for='pvctl' event='LoadEdComplete()'>NSLoadEdComplete()</script>\n");
           document.write("<script for='pvctl' event='OnLoadComplete()'>NSLoadComplete()</script>\n");
           document.write("<script for='pvctl' event='OnSetStatusText(text)'>NSSetStatusText(text)</script>\n");
           document.write("<script for='pvctl' event='DisplayText(text)'>NSDisplayText(text)</script>\n");
           document.write("<script for='pvctl' event='OnCloseWindow()'>NSCloseWindow()</script>\n");
           document.write("<script for='pvctl' event='OnSetFocus()'>NSSetFocus()</script>\n");
        }
    }
}

// dummy functions needed for the netscape6 plugin callbacks
function NSLoadEdComplete() {
  if( _docColorOption ) {
     ViewSetPropValueColor("model/" + VIEW_PROP_CLR_BKG,  _docColorOption);
     ViewSetPropValueColor("model/" + VIEW_PROP_CLR_GRAD, _docColorOption);
  }
  else {
     ViewSetPropValueColor("model/" + VIEW_PROP_CLR_BKG,  0x00000077);
     ViewSetPropValueColor("model/" + VIEW_PROP_CLR_GRAD, 0x00eeeeee);
  }

}

function NSDeselect() {}
function NSSelect() {}
var _docDisplayText ;
function NSDisplayText(string)
{
    _docDisplayText = string;
    window.setTimeout(DoDisplayText, 0);
}
function DoDisplayText()
{
    if (typeof decodeURIComponent == "function")
    {
        _docDisplayText = decodeURIComponent(_docDisplayText);
    }
    window.alert(_docDisplayText);
}

function NSSetStatusText(text) {
   if (typeof decodeURIComponent == "function")
    {
        try {
            text = decodeURIComponent(text);
        } 
        catch (e)
        {
                return;
        }
    }
    window.defaultStatus=text;
}
function NSSetPage(i) {}
function NSGetLayerStates() {}
function NSReportError(msg) {}
function NSHelp() {}
function NSMove(compid) {}
function NSActivate(compid) {}
function NSView() {}
function NSPreferences() {}

function NSSelectInstance(text) {}
function NSDeSelectInstance(text) {}
function NSDeSelectAll() {}
function NSBeginSelect() {}
function NSEndSelect() {}

var confirmMessage =""
var confirmHandle =""
function DoConfirm()
{
        var ret = window.confirm(confirmMessage);
        document.pvctl.ConfirmReply(ret, confirmHandle);

}
function NSConfirm(text, handle)
{
      confirmMessage=text;
      confirmHandle=handle;
       window.setTimeout(DoConfirm, 0);
}

function NSCloseWindow()
{
    if(_visNavEvents == null)
    {
        window.onbeforeunload=null;
    }
    window.setTimeout(ClosePvWindow, 0);
}

function NSSetFocus()
{
    window.focus();
}

function ClosePvWindow()
{
    window.close();
}

// NEW for netscape6.x support; NS6Callback is a mirror
// of the XPCOM nsIPVCadviewEvent class.  This is passed
// to the ns6 plugin and is used to map the callback functions
// into the plugin.
function NS6callback()
{
    // this structure mimics the nsIPVCadviewEVent object
    //
    this.OnLoadComplete      = NSLoadComplete;
    this.OnDoAction	     = NSDoAction;
    this.OnSetStatusText     = NSSetStatusText;
    this.OnSelectInstance    = NSSelectInstance;
    this.OnDeSelectInstance  = NSDeSelectInstance;
    this.OnDeSelectAll       = NSDeSelectAll;
    this.OnBeginSelect       = NSBeginSelect;
    this.OnEndSelect         = NSEndSelect;
    this.OnCloseWindow       = NSCloseWindow;
    this.OnLaunchUrl         = NSLaunchUrl;
}

function NSLaunchUrl(text,target)
{
    
    // Firefox implementation, the only way to guarantee to launch a new url in a seperate window.
    if(target=="_blank" || target=="_BLANK")
    {
        window.open(text,target,"menubar=yes,location=yes,toolbar=yes,status=yes,resizable=yes,scrollbars=yes,minimizable=yes,close=yes,titlebar=yes ");
    }
    else
    {
        window.open(text,target,"dialog");
    }
}

// NEW for netsacpe6.x support; this function should be called
// as part of the <body> OnLoad event (which signals that the
// plugin has been instanced fully).  This function creates a
// new NS6Callback object which gets passed to the plugin
function NSTimer()
{
    if (_docAction) eval(_docAction);
}
function NS6loaded()
{
    if (_isNS6)
    {
        var cb = new NS6callback;
        try
        {
            var retVal = document.pvctl.SetNSCallback(cb);
        }
        catch (e)
        {
            document.cookie="pvlite_plugin_failed=true;path=/";
            if (typeof _pvliteString_InitialisePlugin_Error != "undefined")
            {
                _local_InitialisePlugin_Error= _pvliteString_InitialisePlugin_Error;
            }
            window.alert(_local_InitialisePlugin_Error + "\n" + e);
            url = window.location;
            window.location.href = url;
        }
    }

    // did we try overriding some page onload function?  If so, call it
    if (_docOnLoadOverride) _docOnLoadOverride();
}


function _UpdateThumbOrientation()
{
  if( _docViewOrientationOption ) {
     var s = _docViewOrientationOption.split(" ");
     document.pvctl.SetViewLocation(s[0]+" "+s[1]+" "+s[2]+" 0 "+s[3]+" "+s[4]+" "+s[5]+" 0 "+s[6]+" "+s[7]+" "+s[8]+" 0 0 0 0 1");
     document.pvctl.ZoomToAllTime(0);
  }
}

function thumbview(thumbnail, thumbnail3d, actionString, width, height, downloaddir, versionstrings, pviewhome, options)
{
   if( options && options.length > 0 ) {
      var i = options.indexOf(";");
      var opt= options;
      if( i >= 0 ) {
         opt = options.substring(0, i);
         if( i < options.length ) {
            options = options.substring(i+1);
         }
         else {
            options = null;
         }
      }
      else {
         options = null;
      }
      _docColorOption = Math.floor(new Number(opt));

      if( options && options.length > 0 ) {
         var i = options.indexOf(";");
         var opt = options;
         if( i >= 0 ) {
            opt = options.substring(0, i);
            if( i < options.length ) {
               options = options.substring(i+1);
            }
            else {
               options = null;
            }
         }
         else {
            options = null;
         }
         _docViewOrientationOption = opt;

         if( options && options.length > 0 ) {
            _docAdditionalOption = options;
         }
      }
   }

   _docAction = actionString;
   var params;
   params += " pvt='"+ thumbnail3d + "'";
   params += " thumbnailView='true'";
   PV_InsertPlugin(params, thumbnail, width, height, downloaddir, versionstrings, pviewhome);
}

function PVLite(embedOptions, downloadDir, versionStrings, visNavEvents)
{
    _visNavEvents = visNavEvents;
    PV_InsertPlugin(embedOptions, null, "100%", "100%", downloadDir, versionStrings, "");
}

function pvloaded()
{
    window.setTimeout(pvloadedtimeout, 1);
}

function pvloadedtimeout()
{
    if(_visNavEvents != null )
    {
        eval( _visNavEvents );
    }
    else
    {
        var cb = new NS6callback;
        try
        {
            var retVal = document.pvctl.SetNSCallback(cb);
        }
        catch (e)
        {
            
        }
    }
}
