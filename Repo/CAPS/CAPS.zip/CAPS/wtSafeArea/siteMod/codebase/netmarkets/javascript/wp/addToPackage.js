/* bcwti
 *
 * Copyright (c) 2007 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * PTC and is subject to the terms of a software license agreement.
 * You shall not disclose such confidential information
 * and shall use it only in accordance with the terms of the license
 * agreement.
 *
 * ecwti
*/

var SEPARATOR = "#";

// Adds rows to baseline table dynamically.
function addBaselineTableRows(results, tableId, sourceDocument) {

   if (results.length > 0) {
      params = {doAjaxUpdate:true, preventDuplicates:true, addDone: false,  onSuccess:verifyRuleConfiguration};
      rowHandler.addRows(results,tableId,null,params);

      // Ensure any oids just added via paste also reside in selectedOids element to preserve them during resubmit operations
      var elementSelectedOids = sourceDocument.getElementById("selectedOids");
      if (elementSelectedOids)
         includePastedRowsInSelectedOidsElement(results, elementSelectedOids);
   }

}


/*
 * Given results object of array of oids being pasted and input element containing selectedOids data, this method
 * adds any oids not already in the element to it. 
 */
function includePastedRowsInSelectedOidsElement(results, elementSelectedOids) {
    var OID_SEPARATOR = ",";

    // Build array of those we need to add (i.e. not already in the element)
    var arrOidsToAdd = new Array();
    var arrSelectedOids = elementSelectedOids.value.split(OID_SEPARATOR);
    for (var i = 0; i < results.length; i++)
       if (arrSelectedOids.indexOf(results[i]) == -1)
          arrOidsToAdd.push(results[i]);

    // Update node value if any to add
    if (arrOidsToAdd.length > 0) {
       var sElementValue = elementSelectedOids.value;

       // Remove any trailing separator in case one is there
       if (sElementValue.endsWith(OID_SEPARATOR))
          sElementValue = sElementValue.substr(0, sElementValue.length - 1);

       // Loop through and update the string
       for (var i = 0; i < arrOidsToAdd.length; i++) {
          if (sElementValue.length > 0)
             sElementValue += OID_SEPARATOR;
          sElementValue += arrOidsToAdd[i];
       }

       // Update element value
       elementSelectedOids.value = sElementValue;
    }
}


function deleteOption(list,index) {
    list.options[index] = null;
}

function addOption(list,value,text) {
    var defaultSelected = false;
    var selected = false;
    var atText =leftTrim(rightTrim(text));
    var atValue = leftTrim(rightTrim(value));
    var optionName = new Option(atText, atValue, defaultSelected, selected);
    var temp = list.options[list.length - 1];
    list.options[list.length - 1] = optionName;
    list.options[list.length] = temp;
}

function isPresent(toList, selectedVal){
    for (var i=0; i < toList.options.length; i++) {
        if (leftTrim(rightTrim(toList.options[i].value)) == leftTrim(rightTrim(selectedVal)))
            return true;
    }
    return false;
}

function copyTo(fromList, toList){
    /** copies selected items from src list to tgt list; src list remains unchanged
    */
    if (fromList.selectedIndex >= 0) {
        for (var i=fromList.selectedIndex, l=fromList.options.length; i < l; i++) {
            if ((fromList.options[i].selected) && (fromList.options[i].value != "space")){
                var selectedVal = fromList.options[i].value;
                if (!isPresent(toList, selectedVal))
                    addOption(toList,fromList.options[i].value,fromList.options[i].text);
            }
        }
    }
}
function removeSelected(toList){
    /** removes selected items from tgt list; src list remains unchanged
    */
    if (toList.selectedIndex >= 0) {
        for (var i=toList.options.length-1; i>-1; i--) {
            if ((toList.options[i].selected) && (toList.options[i].value != "space"))
                deleteOption(toList, i);
        }
    }
}

function myContextPickerCallBack(objects) {
	if(objects == null) return;
	var myJSONObjects = objects.pickedObject;
	var contextOptions = document.getElementById("selectedList").options;
	var pickerOptions = new Array();
	for(var i=0; i< myJSONObjects.length;i++) {
		var oid = myJSONObjects[i].oid;
		var name = myJSONObjects[i].name;
                //alert("adding oid=" + oid + " name=" + name);
		pickerOptions[i] = new Option(name, oid, false, false);
	}

	appendOptionItemsToList(pickerOptions, contextOptions);
}

/*
 * Get the collector id from the dom if it is not passed in.
 */
var wpGetCollectorId = function(collectorId) {
   // If collectorId is not passed in then get it from the document 
   if (collectorId == null  ||  collectorId.length == 0) {
      collectorId = document.getElementById("collectorId").value;
   }
   return collectorId;
};

/*
 * Overrides openCollectorPicker, appends additional filter fields for the collector.
 */
var wpOpenCollectorPicker = function( collectorId, uiMode, evt ) {
   // Ensure the collector ID is defined.
   collectorId = wpGetCollectorId(collectorId);

   var collectorConfig = collectionPickerContext.comps[collectorId];

   // Ensure the expansion criteria buttons and dependants dropdown are present.
   collectorConfig["uiColContext"].addValue("disableCollectionPresentation", "false");
   collectorConfig["uiColContext"].addValue("disableConfigSpecsPresentation", "false");

   return _wpOpenCollectorPicker(collectorId, uiMode, evt, collectorConfig);
};

/*
 * Overrides openCollectorPicker, appends additional filter fields for the collector preview.
 */
var wpOpenCollectorPickerPreview = function( collectorId, uiMode, evt ) {
   // Ensure the collector ID is defined.
   collectorId = wpGetCollectorId(collectorId);
   var collectorConfig = collectionPickerContext.comps[collectorId];

   // Remove the expansion criteria buttons and dependants dropdown the preview collector.
   collectorConfig["uiColContext"].addValue("disableCollectionPresentation", "true");
   collectorConfig["uiColContext"].addValue("disableConfigSpecsPresentation", "true");
   collectorConfig["uiColContext"].addValue("reportAccessControlWarnings", "true");
   collectorConfig["uiColContext"].addValue("disableCollectorDisplays", "false");
   collectorConfig["uiColContext"].addValue("contentType", sessionStorage.getItem("contentType"));
   collectorConfig["uiColContext"].addValue("language", sessionStorage.getItem("language"));

   return _wpOpenCollectorPicker(collectorId, uiMode, evt, collectorConfig);
};

/*
 * private
 * Configures the collector (or preview collector), then launches it in a new window.
 */
var _wpOpenCollectorPicker = function( collectorId, uiMode, evt, collectorConfig) {
   // Set the ui mode
   collectorConfig["uiMode"] = uiMode;

   // Set the collector title
   collectorConfig["pickerDialogDescriptor"] = updateCollectorTitle(collectorConfig, uiMode);
   
   //Retain container objects as seeds

   collectorConfig["uiColContext"].addValue("use_contents_as_seeds", "false");
   collectorConfig["uiColContext"].addValue("contentType", sessionStorage.getItem("contentType"));
   collectorConfig["uiColContext"].addValue("language", sessionStorage.getItem("language"));

   // Get the seeds
   var soids = [];   
   var error="";
   var pickertype="";
   var pickerSelected="";
   var rows = tableUtils.getTableRowsByID("windchill.seed.list");
   if (rows) {
      var rows_length=rows.length;
      for (var i=0; i<rows_length; i++) {
         soids.push(rows.keys[i]);
      }
   }
   pkgPickerElement = document.getElementById("packageSearchPicker$label$");
    if(pkgPickerElement!=null){
        pickertype="pkg";
        pickerSelected=pkgPickerElement.value;
    }else{
        mcPickerElement = document.getElementById("managedCollectionSearchPicker$label$");
        if(mcPickerElement!=null){
            pickertype="mc";
            pickerSelected=mcPickerElement.value;
        }
    }
    if(pickertype!=null && pickertype!= ""){
        if(pickertype=="pkg"){
            if((pickerSelected==null || pickerSelected.length==0) || ( soids == null || soids.length == 0 )){
                error = "com.ptc.netmarkets.wp.wpResource.NEED_SEED_OBJECT_AND_PACKAGE";
            }
        }else if(pickertype=="mc"){
            if((pickerSelected==null || pickerSelected.length==0) || ( soids == null || soids.length == 0 )){
                error = "com.ptc.netmarkets.wp.wpResource.NEED_SEED_OBJECT_AND_MC";
            }
        }
    }else if ( soids == null || soids.length == 0 ){
        error = "com.ptc.netmarkets.wp.wpResource.NEED_SEED_OBJECT";
    }
    
    if(error!=null && error.length >0){
        JCAAlert(error);
        Event.stop(evt);
        return false;
    }
   var oid_s = "";
   var sThisOID;
   for( var i=0; i < soids.length; i++) {
      if ( soids[i] ) {
    	 sThisOID = parseNmContext(soids[i]);
    	 if (sThisOID.indexOf("OR:wt.part.WTPart") === 0)
    		oid_s = sThisOID + " " + oid_s;
    	 else
            oid_s = oid_s + sThisOID + " ";
      }
   }
   collectorConfig["seedsOIDs"] = oid_s;

   var options = document.getElementById("colsToExecFormatString");
   if (options != null) {
      collectorConfig["initialColsToExecFormatString"] = options.value;
   }

   var navCriteriaID = document.getElementById("navCriteriaID");
   if (navCriteriaID != null && navCriteriaID.value.length > 0) {
      collectorConfig["initialExpansionCriteriaID"] = navCriteriaID.value;
   } else {		  
	    var options = {
	        asynchronous: false,
	        parameters: getFormData()
	    };
	
	    var url = "netmarkets/jsp/wpcollection/resetNavCriteriaID.jsp";
	    var response = requestHandler.doRequest(url, options);
	    var newNavCriteriaID = response.responseText;
	    
	    if (newNavCriteriaID != null) {
	            collectorConfig["initialExpansionCriteriaID"] = newNavCriteriaID;
	    }
   }

   // Add initial package parameters to the form
   collectorConfig["addlParams"] = getPackageParams();

   eval( collectorId + "_OpenCollectionPicker()" );
   Event.stop(evt);

   return false;
};


/**
 * Returns an array of the package filters to be used by the collector
 */
function getPackageParams() {
   var addlParams = new Array();
   if (document.getElementById("oid") != null) addlParams.push("OID", document.getElementById("oid").value);
   addlParams.push("ecPassThroughParams", getECPassThruParamsValue());
   addlParams.push("language", sessionStorage.getItem("language"));
   addlParams.push("contentType", sessionStorage.getItem("contentType"));
   return addlParams;
}


/**
 * Returns the expansion criteria parameters and values to be passed through to the EC component.
 * This will be a comma-separated list of key value pairs (<key1>=<value1>,<key2=value2>) which will
 * be submitted as one form value field to collector. 
 */
function getECPassThruParamsValue() {
   var sResult = "";

   var NAV_CRITERIA_CONTEXT_TYPE_ID_PARAM = "contextObjectTypeId";
   var elementTypeId = document.getElementById(NAV_CRITERIA_CONTEXT_TYPE_ID_PARAM);
   if (elementTypeId != null)
      sResult += NAV_CRITERIA_CONTEXT_TYPE_ID_PARAM + "=" + elementTypeId.value;

  //disable "Include Work In Progress" option on Config spec tab.
   sResult += ",disableIncludeWork=true";

   return sResult;
}


/**
 * extraFormDataCallback function called by the collector when the config spec is updated in the Preview
 * This will add the package parameters to the form
 */
function addPackageParams(colComp, form) {
   var addlParams = getPackageParams();
   if (addlParams != null) {
      for (var i=0; i<addlParams.length-1; i=i+2) {
         appendFormHiddenInput(form, addlParams[i], addlParams[i+1]);
      }
   }
}

/**
 * Updates the page descriptor with the correct title based on the uimode
 **/
var updateCollectorTitle = function( collectorConfig, uiMode) {
   var pdString = collectorConfig["pickerDialogDescriptor"];
   var url = getBaseHref()+'netmarkets/jsp/wpcollection/updateCollectorTitle.jsp?pageDescriptorString='+encodeURIComponent(pdString)+'&uiMode='+encodeURIComponent(uiMode);
   var options = {
      asynchronous: false
   };
   var transport = requestHandler.doRequest(url, options);
   return transport.responseText;
}

/**
 * Add items to list box (ignoring duplicates)
 * Both parameters are arrays of HTML Option elements
 **/
function appendOptionItemsToList(optionsToAdd, optionsExisting) {
    // Get some extended Prototype Arrays to take advantage of Enumerable support
    var optionsToAddArray = $A(optionsToAdd);
    var optionsExistingArray = $A(optionsExisting);

    // Only put the item into the list if it's not already there (use Prototype.js support for iterating -- see http://www.prototypejs.org/api for info)
    optionsToAddArray.each(function(optionToAdd) {
        if (!optionsExistingArray.find(function (optionExising) {return optionExising.value == optionToAdd.value;})) {
            optionsExisting[optionsExisting.length] = optionToAdd;
        }
    })

    // Make sure nothing in our list box is selected
    optionsExisting.selectedIndex = -1;
}

function wpCollectorPickerCallback(results, tableId) {
   if (results != null) {
      document.getElementById("colsToExecFormatString").value = results.getOptions();
      appendFormHiddenInput(getMainForm(), "colsToExecFormatString", results.getOptions());
      document.getElementById("navCriteriaID").value = results.getExpansionCriteriaID();
      refreshCurrentStep();
   }
}

function saveFilter() {
   var allSelected = document.getElementById("includeAllRadio").checked;
   var options = document.getElementById("selectedList").options;
   var valueList = '';
   var textList = '';

   var setId = includeListField;
   var resetId = excludeListField;

   if (!allSelected) {
      for (var j = 0; j < options.length; j++) {
         if ((options[j].value != 'space') && (options[j].value != '')){
            valueList += options[j].value;
            textList += options[j].text;
            if (j < options.length - 1){
               valueList += SEPARATOR;
               textList += SEPARATOR;
            }
         }
      }

      var inclRadio = document.getElementById("includeRadio");
      var exclRadio = document.getElementById("excludeRadio");
      if (inclRadio.checked){
             setId = includeListField;
         resetId = excludeListField;
      } else if (exclRadio.checked){
         setId = excludeListField;
         resetId = includeListField;
      }
   }

   window.opener.document.getElementById(setId).value=valueList;
   window.opener.document.getElementById(resetId).value='';
   window.opener.document.getElementById(selectedTextListField).value=textList;
   window.opener.refreshCurrentStep();
   window.close();
}

function loadFilter() {
   var options = document.getElementById("selectedList").options;
   var includeList = window.opener.document.getElementById(includeListField).value;
   var excludeList = window.opener.document.getElementById(excludeListField).value;
   var textList = window.opener.document.getElementById(selectedTextListField).value;
   var inclRadio = document.getElementById("includeRadio");
   var exclRadio = document.getElementById("excludeRadio");

   var optionValue;
   var optionText = textList.split(SEPARATOR);
   if (includeList.length > 0) {
      optionValue = includeList.split(SEPARATOR);
      inclRadio.checked=true;
      exclRadio.checked=false;
   } else if (excludeList.length > 0) {
      optionValue = excludeList.split(SEPARATOR);
      inclRadio.checked=false;
      exclRadio.checked=true;
   }

   if (optionValue != null && optionValue.length > 0) {
      var option;
      for (var j = 0; j < optionValue.length; j++) {
         option = new Option();
         option.text = optionText[j];
         option.value = optionValue[j];
         options[j] = option;
      }
   }
}

/**
 * Updates the hidden value associated with the baseline name so that
 * we can retain its value when refreshing the step.
 **/
function updateBaselineName() {
   document.getElementById("newName").value = document.getElementById("baselineNameId").value;
}

/**
 * Updates the hidden value associated with the incremental filter so that
 * we can retain its value when refreshing the step.
 **/
function updateIncrementalFilter() {
   document.getElementById("initIncrementalFilter").value = document.getElementById("incrementalFilterId").checked;
}

/**
 * Gets the value of the Basic attribute from the New Package wizard
 **/
function initializeAddToPackageStep() {
   var isNewPackage = document.getElementById("isNewPackageWizard");
   if (isNewPackage != null) {
      refreshCurrentStep();
   }

   return true;
}

/**
 * Calls the Paste action if Paste and Add to Package, and shows the preview button
 */
var pasteMode; //pasteToPackage.jsp sets this to true.
function addToPackageBeforeJS() {
   showPreview();

   if (pasteMode) {
      PTC.onReady( function() {Ext.getCmp('pastSeedAction')._handler()});
   }

   return true;
}

/**
 * Validates the add to package step and hides the preview button
 **/
function addToPackageAfterJS() {
   var retVal = validateSeeds();
   if (retVal == true) {
      hidePreview();
   }
   return retVal;
}

/**
 * Performs the following if user modified seeds by add or remove action:
 *  1) Updates config spec, if config spec requires update for project sandbox. 
 *  2) Checks if centricity should be changed and prompts user if they want to reset their rules back to the default rules.
 **/
function verifyRuleConfiguration() {
  
   var options = {
	  asynchronous: false,
	  parameters: getFormData()
    };
	
    var response = requestHandler.doRequest('netmarkets/jsp/wpcollection/validateCentricity.jsp', options);
    var result = response.responseText;
    var json = result.evalJSON();
   
    var centricityRequiresUpdate = json.centricityShouldBeUpdate;
    //alert("centricityRequiresUpdate == " + centricityRequiresUpdate);
 
    var configSpecRequiresUpdateForPjlSandbox = json.configSpecShouldBeUpdateForPjlSandbox;
    
    //alert("configSpecRequiresUpdateForPjlSandbox == " + configSpecRequiresUpdateForPjlSandbox);

    
    if(configSpecRequiresUpdateForPjlSandbox != null && configSpecRequiresUpdateForPjlSandbox == "true"){
         updateRecipe();
    }

    if (centricityRequiresUpdate != null && centricityRequiresUpdate == "true") {
         if (JCAConfirm('com.ptc.netmarkets.wp.wpResource.WARN_UPDATE_CUSTOM_RULES')) {
	   updateRecipe();
         }
    }
}

/**
 * Updates the following in existing recipe 
 *  1) Changes NavigationCriteria applicableType to default value. 
 *  2) Changes Dependents collection option to default value.
 *  3) Changes config spec to default value.
 *  4) Changes config spec options to default values.
 * 
 **/
function updateRecipe() {
    var options = {
       asynchronous: false,
       parameters: getFormData()
    };
	
    var response = requestHandler.doRequest('netmarkets/jsp/wpcollection/updateRecipe.jsp', options);
    var result = response.responseText;
    var json = result.evalJSON();
    //alert("colsToExecFormatString == " + json.colsToExecFormatString);
    //alert("navCriteriaID == " + json.navCriteriaID);
    
    if (json.colsToExecFormatString && json.colsToExecFormatString !=='') {
	   document.getElementById("colsToExecFormatString").value = json.colsToExecFormatString;
    }
    
    if (json.navCriteriaID && json.navCriteriaID !=='') {
	   document.getElementById("navCriteriaID").value = json.navCriteriaID;
    }
	 
    refreshCurrentStep();
}


/**
 * Verifies there is at least one seed in the objects table.
 * In the New Package wizard, warn the user that they will lose all collection information
 * In the Add To Package wizard, display an error message
 **/
function validateSeeds() {
   var seeds = tableUtils.getTableRowsByID("windchill.seed.list");
   if (seeds.length == 0) {
      if (document.getElementById("isNewPackageWizard")) {
         var bNamesPresent = (document.getElementById("newName") != null) && (document.getElementById("initName") != null);
         // In new package, if there are filters specified without seeds, warn the user that no collection will be created.
         if ((bNamesPresent && (document.getElementById("newName").value != document.getElementById("initName").value)) ||
             document.getElementById("rulesAreCustom").value == "true") {
            var retVal = JCAConfirm("com.ptc.netmarkets.wp.wpResource.WARN_NO_COLLECTION_CREATED");
            if (retVal == true) {
               resetAddToPackageStep();
            }
            return retVal;
         }
      } 
   }
   return true;
}

function resetAddToPackageStep() {
   var bNamesPresent = (document.getElementById("newName") != null) && (document.getElementById("initName") != null);
   if (bNamesPresent) document.getElementById("newName").value = document.getElementById("initName").value;
   document.getElementById("colsToExecFormatString").value = "";
   document.getElementById("navCriteriaID").value = "";
   document.getElementById("rulesAreCustom").value = "";
   wizardSteps[currentStepStrName].isDirty = true;
}

/**
 * Shows the Preview button
 **/
function showPreview() {
   $("leftButton").style.visibility="visible";
   return true;
}

/**
 * Hides the Preview button
 **/
function hidePreview() {
   $("leftButton").style.visibility="hidden";
  parent.enableButtons = parent.enableButtons.wrap(
  function(proceed) {
      if (currentStepStrName.indexOf("wpcollection.addToPackageStep") >= 0) {
          // redisplay the preview button if server side error during New Package save.
          showPreview();
      }
      // proceed using the original function
      return proceed();
  });
   return true;
}


function collectionSearchCallback(objects) {
	
     var collectionPicked = objects.pickedObject;
     var oid = collectionPicked[0].oid;
     var identifier = collectionPicked[0].displayIdentifier;

   goProgress();

   var eleForm = createRefreshWizardForm(window, "packageOid", oid);
   document.getElementById("mainform").parentNode.appendChild(eleForm);
   eleForm.submit();
}


function managedcollectionSearchCallback(objects) {
   var collectionPicked = objects.pickedObject;
   var oid = collectionPicked[0].oid;     

   var sManagedCollectionOid = oid;
   var OR_PREFIX = "OR:";
   if (sManagedCollectionOid.substr(0, OR_PREFIX.length) != OR_PREFIX)
      sManagedCollectionOid = OR_PREFIX + sManagedCollectionOid;

   goProgress();

   var eleForm = createRefreshWizardForm(window, "managedCollectionOid", sManagedCollectionOid);
   document.getElementById("mainform").parentNode.appendChild(eleForm);
   eleForm.submit();
}


// Creates a form element with input elements for the collection oid and selected oids
function createRefreshWizardForm(currWin, collectionParamName, collectionOid) {
   var eleForm = currWin.document.createElement("form");
   eleForm.name = "updateWizardForm";
   eleForm.method = "post";

   var sURL = currWin.location.href;
   sURL = removeParamFromString(collectionParamName, sURL);
   sURL = removeParamFromString("selectedOids", sURL);
   sURL = removeParamFromString("soid", sURL);
   eleForm.action = sURL;

   var eleInput;

   eleInput = currWin.document.createElement("input");
   eleInput.id = collectionParamName;
   eleInput.name = eleInput.id;
   eleInput.type = "hidden";
   eleInput.value = collectionOid;
   eleForm.appendChild(eleInput);

   eleInput = currWin.document.createElement("input");
   eleInput.id = "selectedOids";
   eleInput.name = eleInput.id;
   eleInput.type = "hidden";
   eleInput.value = currWin.document.getElementById("selectedOids").value;
   eleForm.appendChild(eleInput);

   return eleForm;
}
