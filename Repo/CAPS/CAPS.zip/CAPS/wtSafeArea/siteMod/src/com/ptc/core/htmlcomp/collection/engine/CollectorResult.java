/* bcwti
 *
 * Copyright (c) 2010 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */

package com.ptc.core.htmlcomp.collection.engine;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import wt.fc.ObjectIdentifier;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.collections.WTCollection;
import wt.navigation.CollectedResultValidator;
import wt.navigation.NavigatedGraph;
import wt.navigation.NavigationUnit;
import wt.navigation.cs.CSCollectionResult;
import wt.occurrence.PathToOccurrence;
import wt.util.WTException;
import wt.vc.Iterated;
import wt.vc.struct.IteratedUsageLink;

import com.ptc.core.collectionsrv.engine.CollectionSrvHelper;
import com.ptc.core.htmlcomp.util.Message;
import com.ptc.core.logging.Log;
import com.ptc.core.logging.LogFactory;

/**
 *
 * <BR>
 * <BR>
 * <B>Supported API: </B>false <BR>
 * <BR>
 * <B>Extendable: </B>false
 *
 * @version 1.0
 **/
public class CollectorResult implements Externalizable, CSCollectionResult {
    private static final String CLASSNAME = CollectorResult.class.getName();

    private Map messages;

    private Map collectedData;

    private Map appliedCollections;

    private boolean hasUnresolvedObjects = false, hasUnresolvedObjectsByAccessRights = false, wasAborted = false,
            isIncompleted = false, wasPathToOccurrenceAlwaysRequested = false;

    private Boolean hasCycles;

    private Collection[] cyclicDependents;

    private boolean hasVirtualElements = false;

    private String collectorID;

    static final long serialVersionUID = 1;

    private WTException exception = null;

    public static final long EXTERNALIZATION_VERSION_UID = 8845296750107279260L;

    private Map cns, graphs, components, filters;

    private Set allDependents, hiddenDependents, parents = new HashSet(), navigatedObjs, hsFoundKinds = new HashSet(),
            chunkSeeds;

    private List foundKinds, seeds;

    final private String ALL_KINDS = "~#igorak$@", ALL_LEVELS = "~#igoral$@";

    final private int ANY_KEY = -1;

    final private static Log log = LogFactory.getLog(CollectorResult.class);

    private CollectedResultValidator crValidator;

    /**
     * Writes the non-transient fields of this class to an external source.
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     *
     * @param output
     * @exception java.io.IOException
     **/
    public void writeExternal(ObjectOutput output)
            throws IOException {
        output.writeLong(EXTERNALIZATION_VERSION_UID);

        output.writeObject(appliedCollections);
        output.writeObject(collectedData);
        output.writeBoolean(hasUnresolvedObjects);
        output.writeBoolean(hasUnresolvedObjectsByAccessRights);
        output.writeBoolean(wasAborted);
        output.writeBoolean(isIncompleted);
        output.writeObject(messages);
        output.writeObject(cns);
        output.writeObject(graphs);
        output.writeObject(allDependents);
        output.writeObject(hiddenDependents);
        output.writeObject(parents);
        output.writeObject(seeds);
        output.writeObject(foundKinds);
        output.writeObject(chunkSeeds);
        output.writeBoolean(hasVirtualElements);
    }

    /**
     * Reads the non-transient fields of this class from an external source.
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     *
     * @param input
     * @exception java.io.IOException
     * @exception java.lang.ClassNotFoundException
     **/
    public void readExternal(ObjectInput input)
            throws IOException, ClassNotFoundException {
        long readSerialVersionUID = input.readLong(); // consume UID

        if (readSerialVersionUID == EXTERNALIZATION_VERSION_UID) { // if current version UID
            appliedCollections = (Map) input.readObject();
            collectedData = (Map) input.readObject();
            hasUnresolvedObjects = input.readBoolean();
            hasUnresolvedObjectsByAccessRights = input.readBoolean();
            wasAborted = input.readBoolean();
            isIncompleted = input.readBoolean();
            messages = (Map) input.readObject();
            cns = (Map) input.readObject();
            graphs = (Map) input.readObject();
            allDependents = (Set) input.readObject();
            hiddenDependents = (Set) input.readObject();
            parents = (Set) input.readObject();
            seeds = (List) input.readObject();
            foundKinds = (List) input.readObject();
            chunkSeeds = (Set) input.readObject();
            hasVirtualElements = input.readBoolean();
        }
        else
            throw new java.io.InvalidClassException(CLASSNAME, "Local class not compatible:"
                    + " stream classdesc externalizationVersionUID=" + readSerialVersionUID
                    + " local class externalizationVersionUID=" + EXTERNALIZATION_VERSION_UID);
    }

    /**
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     *
     * @param obj
     * @param message
     **/
    public void addMessage(Object obj, Message message) {
        if (messages == null)
            messages = new HashMap();

        List list = (List) messages.get(obj);
        if (list == null) {
            list = new ArrayList();
            messages.put(obj, list);
        }

        list.add(message);
    }

    /**
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     *
     * @param obj
     * @return List
     **/
    public List getMessages(Object obj) {
        if (messages == null)
            return null;
        else
            return (List) messages.get(obj);
    }

    /**
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     *
     * @return boolean
     **/
    public boolean hasMessages() {
        return (messages != null);
    }

    /**
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     *
     * @return Collection
     **/
    public Collection getCollectedObjects() {
        return allDependents;
    }

    /**
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     *
     * @param obj
     * @return Collection of CollectedFrmObjs
     * @exception wt.util.WTException
     **/
    public Collection<CollectedFromObj> getCollectedFromObjs(Object obj)
            throws WTException {
        if (collectedData == null)
            return null;

        Map m = (Map) collectedData.get(getMapKey(obj));

        if (m == null)
            return null;

        int size = 0;
        for (Iterator i = m.values().iterator(); i.hasNext();)
            size += ((HashMap) i.next()).size();

        Map parents = new HashMap(size);

        for (Iterator i = m.entrySet().iterator(); i.hasNext();) {
            Map.Entry e = (Map.Entry) i.next();

            CollectionType ct = (CollectionType) e.getKey();

            HashMap p = (HashMap) e.getValue();
            for (Iterator j = p.entrySet().iterator(); j.hasNext();) {
                Map.Entry pe = (Map.Entry) j.next();

                Object parent = pe.getKey();
                String key = parent.toString() + String.valueOf(ct.collectedAsKey);

                CollectedFromObj cfo = (CollectedFromObj) parents.get(key);

                if (cfo == null || !ct.isCollectedByForce) {
                    boolean isVisible = true;
                    if ((parent instanceof Iterated) && hiddenDependents != null
                            && hiddenDependents.contains(PersistenceHelper.getObjectIdentifier((Iterated) parent)))
                        isVisible = false;

                    cfo = new CollectedFromObj(obj, parent, ct.collectedAsKey, isVisible, ct.isCollectedByForce,
                            (Collection) pe.getValue());
                    if (parent instanceof Persistable && obj instanceof Persistable) {
                        NavigatedGraph graph = getNavigatedGraph(ct.collectedAsKey, (Persistable) parent,
                                (Persistable) obj);
                        if (graph != null)
                            cfo.setNavigatedGraph(graph);
                    }

                    parents.put(key, cfo);
                }
            }
        }

        if (log.isTraceEnabled() && !parents.isEmpty()) {
            log.trace("Parents of " + CollectionSrvHelper.getObjectInfo(obj, true, true) + " :");

            for (Iterator i = parents.values().iterator(); i.hasNext();) {
                CollectedFromObj parent = (CollectedFromObj) i.next();

                log.trace("\t" + parent.getCollectionKey() + "*"
                        + CollectionSrvHelper.getObjectInfo(parent.getCollectedFrom()) + "*" + parent.isVisibility()
                        + "*" + parent.isCollectedByForce() + (parent.getLinks() != null && !parent.getLinks().isEmpty()
                                ? "*" + parent.getLinks().iterator().next().toString() : ""));
            }
        }

        return parents.values();
    }

    /**
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     *
     * @param obj
     * @return List
     **/
    public List getAppliedCollections(Object obj) {
        if (appliedCollections == null)
            return null;

        HashSet ret = (HashSet) appliedCollections.get(getMapKey(obj));

        HashSet collectedAsKey = new HashSet((HashSet) appliedCollections.get(ALL_KINDS));
        if (collectedAsKey != null) {
            if (ret == null)
                ret = new HashSet();

            for (Iterator i = ret.iterator(); i.hasNext();)
                collectedAsKey.remove(Integer.valueOf(((AppliedCollection) i.next()).getCollectionKey()));

            for (Iterator i = collectedAsKey.iterator(); i.hasNext();)
                ret.add(new AppliedCollection(((Integer) i.next()).intValue(), false));
        }

        if (log.isTraceEnabled()) {
            boolean isFirst = true;
            for (Iterator i = ret.iterator(); i.hasNext();) {
                AppliedCollection ac = (AppliedCollection) i.next();
                if (ac.isFoundItems()) {
                    if (isFirst) {
                        log.trace("**Applied collections for " + CollectionSrvHelper.getObjectInfo(obj, true, true));
                        isFirst = false;
                    }

                    log.trace("\t\t" + ac.getCollectionKey() + "*" + ac.isFoundItems());
                }
            }
        }

        return new ArrayList(ret);
    }

    /**
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     *
     * @param obj
     * @param appliedCollections
     **/
    public void setAppliedCollections(Object obj, List appliedCollections) {
        if (this.appliedCollections == null)
            this.appliedCollections = new HashMap();

        this.appliedCollections.put(getMapKey(obj), appliedCollections);
    }

    /**
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     *
     * @param object
     * @param collectionKey
     * @param foundItems
     **/
    public void addAppliedCollection(Object object, int collectionKey, boolean foundItems) {
        if (object == null)
            return;

        if (appliedCollections == null)
            appliedCollections = new HashMap();

        Integer key = Integer.valueOf(collectionKey);
        if (!((Set) appliedCollections.get(ALL_KINDS)).contains(key) || (appliedCollections.containsKey(ALL_LEVELS)
                && ((Set) appliedCollections.get(ALL_LEVELS)).contains(key)))
            return;

        HashSet list = (HashSet) appliedCollections.get(getMapKey(object));
        if (list == null) {
            list = new HashSet();
            appliedCollections.put(getMapKey(object), list);
        }

        AppliedCollection ac = new AppliedCollection(collectionKey, foundItems);

        if (!list.contains(ac)) {
            list.add(ac);
            list.remove(new AppliedCollection(collectionKey, !foundItems));

            if (log.isTraceEnabled())
                log.trace("Applied collection [" + collectionKey + "," + foundItems + "] for "
                        + CollectionSrvHelper.getObjectInfo(object, true, true));
        }
    }

    /**
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     *
     * @return boolean
     **/
    public boolean hasUnresolvedObjects() {
        if (log.isTraceEnabled())
            log.trace("hasUnresolvedObjects=" + hasUnresolvedObjects);

        return hasUnresolvedObjects;
    }

    public boolean hasUnresolvedObjectsByAccessRights() {
        if (log.isTraceEnabled())
            log.trace("hasUnresolvedObjectsByAccessRights=" + hasUnresolvedObjectsByAccessRights);

        return hasUnresolvedObjectsByAccessRights;
    }

    public boolean isAborted() {
        if (log.isTraceEnabled())
            log.trace("wasAborted=" + wasAborted);

        return wasAborted;
    }

    public boolean isIncompleted() {
        if (log.isTraceEnabled())
            log.trace("isIncompleted=" + isIncompleted);

        return isIncompleted;
    }

    /**
     * returns CollectedFromObjs for all collected objects
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     *
     * @return Collection of CollectedFromObjs
     * @exception wt.util.WTException
     **/
    public Collection<CollectedFromObj> getCollectedFromObjs()
            throws WTException {
        ArrayList ret = new ArrayList();
        for (Iterator i = getCollectedObjects().iterator(); i.hasNext();)
            ret.addAll(getCollectedFromObjs(i.next()));

        return ret;
    }

    /**
     * Add WTCollection of dependencies to the given object with the given rule and option
     *
     * @param parent
     * @param collectedAsKey
     * @param children
     * @param isCollectedByForce
     **/
    public void addDependents(Object parent, int collectedAsKey, WTCollection children, boolean isCollectedByForce)
            throws WTException {
        if (parent == null || children == null || children.isEmpty())
            return;

        Map dependents = new HashMap(children.size());

        for (Iterator i = children.persistableIterator(); i.hasNext();)
            dependents.put(i.next(), null);

        addDependents(parent, collectedAsKey, dependents, isCollectedByForce);
    }

    public void addDependents(Object parent, int collectedAsKey, Map children, boolean isCollectedByForce)
            throws WTException {
        if (parent == null || children == null || children.isEmpty())
            return;

        if (allDependents != null && !allDependents.contains(parent))
            return;

        if (crValidator != null && !crValidator.isCollectedDependentValid(parent)) {
            if (log.isTraceEnabled())
                log.trace("parent " + CollectionSrvHelper.getObjectInfo(parent, true, true) + " is invalid");
            return;
        }

        CollectionType key = new CollectionType(collectedAsKey, isCollectedByForce);

        if (collectedData == null)
            collectedData = new HashMap();

        Set cn = null;
        if (parent instanceof Persistable) {
            ObjectIdentifier parentId = PersistenceHelper.getObjectIdentifier((Persistable) parent);
            if (cns == null)
                cns = new HashMap();

            cn = (Set) cns.get(parentId);
            if (cn == null) {
                cn = new HashSet();
                cns.put(parentId, cn);
            }

            parents.add(parent);
        }

        for (Iterator i = children.entrySet().iterator(); i.hasNext();) {
            Map.Entry e = (Map.Entry) i.next();

            Persistable child = (Persistable) e.getKey();

            if (parent.equals(child) || (allDependents != null && !allDependents.contains(child))
                    || (crValidator != null && !crValidator.isCollectedDependentValid(child))) {
                if (log.isTraceEnabled())
                    log.trace("child " + CollectionSrvHelper.getObjectInfo(parent) + " is invalid");
                continue;
            }

            ObjectIdentifier childId = PersistenceHelper.getObjectIdentifier(child);

            if (cn != null)
                cn.add(child);

            Map m = (Map) collectedData.get(childId);
            if (m == null) {
                m = new HashMap();
                collectedData.put(childId, m);
            }

            Map parents = (Map) m.get(key);
            if (parents == null) {
                parents = new HashMap();
                m.put(key, parents);
            }

            HashSet link = (HashSet) e.getValue();
            Collection links = (Collection) parents.get(parent);

            if (links == null && link != null)
                links = new HashSet();

            if (link != null)
                links.addAll(link);

            if (log.isTraceEnabled())
                log.trace("Added[" + collectedAsKey + "," + isCollectedByForce + ","
                        + (links == null ? 0 : links.size()) + "] parent " + CollectionSrvHelper.getObjectInfo(parent)
                        + " for " + CollectionSrvHelper.getObjectInfo(child)
                        + (link == null ? "" : " link=" + link.size()));

            parents.put(parent, links);

            addCollectedAsKey(collectedAsKey);
        }
    }

    public void addCollectedAsKey(int collectedAsKey) {
        Integer objCollectedAsKey = Integer.valueOf(collectedAsKey);
        if (!hsFoundKinds.contains(objCollectedAsKey)) {
            if (foundKinds == null)
                foundKinds = new ArrayList();

            foundKinds.add(objCollectedAsKey);
            hsFoundKinds.add(objCollectedAsKey);
        }
    }

    public void addAllDependents(Collection allDependents) throws WTException {
        if (allDependents == null)
            return;

        if (crValidator != null) {
            Collection validDependents = new ArrayList();
            for (Iterator i = allDependents.iterator(); i.hasNext();) {
                Object dependent = i.next();
                if (crValidator.isCollectedDependentValid(dependent))
                    validDependents.add(dependent);
                else if (log.isTraceEnabled())
                    log.trace(CollectionSrvHelper.getObjectInfo(dependent, true, true) + " is invalid");

            }
            allDependents = validDependents;
        }

        if (this.allDependents == null)
            this.allDependents = new HashSet(allDependents);
        else
            this.allDependents.addAll(allDependents);
    }

    public void refineDependents() {
        if (allDependents == null || allDependents.isEmpty() || navigatedObjs == null)
            return;

        HashSet ids = new HashSet();

        for (Iterator i = allDependents.iterator(); i.hasNext();) {
            Object obj = i.next();
            if (obj instanceof Persistable && !navigatedObjs.contains(obj)) {
                i.remove();
                if (log.isDebugEnabled())
                    log.debug("Filtered out " + obj);
                parents.remove(obj);
            }
            else
                ids.add(PersistenceHelper.getObjectIdentifier((Persistable) obj));
        }

        for (Iterator i = cns.entrySet().iterator(); i.hasNext();) {
            Map.Entry e = (Map.Entry) i.next();
            Object parentId = e.getKey();
            boolean remove = !ids.contains(parentId);
            if (!remove) {
                Set c = (Set) e.getValue();
                for (Iterator j = c.iterator(); j.hasNext();) {
                    Object obj = j.next();
                    if (!allDependents.contains(obj))
                        j.remove();
                }
                if (c.isEmpty())
                    remove = true;
            }
            if (remove)
                i.remove();
        }

        for (Iterator i = collectedData.entrySet().iterator(); i.hasNext();) {
            Map.Entry e = (Map.Entry) i.next();
            ObjectIdentifier childId = (ObjectIdentifier) e.getKey();
            boolean remove = !ids.contains(childId);
            if (!remove) {
                Map m = (Map) e.getValue();
                for (Iterator j = m.entrySet().iterator(); j.hasNext();) {
                    Map.Entry me = (Map.Entry) j.next();
                    Map prs = (Map) me.getValue();
                    for (Iterator k = prs.entrySet().iterator(); k.hasNext();) {
                        Map.Entry pe = (Map.Entry) k.next();
                        Object obj = pe.getKey();
                        if (!allDependents.contains(obj))
                            k.remove();
                    }
                    if (prs.isEmpty())
                        j.remove();
                }
                remove = m.isEmpty();
            }
            if (remove)
                i.remove();
        }

    }

	public void removeDependents() {
		if(allDependents==null || allDependents.isEmpty()) return;
		for( Iterator i=allDependents.iterator(); i.hasNext();) {
			Object obj = i.next();
			if(obj instanceof Persistable) {
				i.remove();
				parents.remove(obj);
			}
		}
	}
	
    private Object getMapKey(Object obj) {
        return (obj instanceof Persistable ? PersistenceHelper.getObjectIdentifier((Persistable) obj) : obj);
    }

    public void setHiddenDependents(Collection hiddenDependents) {
        if (hiddenDependents == null)
            return;

        if (this.hiddenDependents == null)
            this.hiddenDependents = new HashSet(hiddenDependents.size());

        this.hiddenDependents.addAll(hiddenDependents);
    }

    public Set getParents() {
        return parents;
    }

    public void addParents(Collection prnts) {
        if (prnts != null && !prnts.isEmpty())
            parents.addAll(prnts);
    }

    public void addParent(Persistable p) {
        addParents(Arrays.asList(new Persistable[] { p }));
    }

    public boolean isParent(Persistable p) {
        return parents.contains(p);
    }

    public CollectorResult() {
    }

    public CollectorResult(HashMap allKinds) {
        if (allKinds != null) {
            HashSet collectedAsKey = new HashSet(allKinds.size());
            for (Iterator i = allKinds.values().iterator(); i.hasNext();)
                collectedAsKey.add(Integer.valueOf(((CollectionKind) i.next()).getCollectedAsKey()));
            appliedCollections = new HashMap();
            appliedCollections.put(ALL_KINDS, collectedAsKey);
            appliedCollections.put(ALL_LEVELS, new HashSet());
        }
    }

    public void setHasUnresolvedObjects() {
        hasUnresolvedObjects = true;
    }

    public void setHasUnresolvedObjectsByAccessRights() {
        hasUnresolvedObjectsByAccessRights = true;
    }

    public void setWasAborted() {
        wasAborted = true;
    }

    public void setWasIncompleted() {
        isIncompleted = true;
    }

    private static class CollectionType implements Serializable {
        int collectedAsKey;

        boolean isCollectedByForce;

        CollectionType() {
        }

        CollectionType(int collectedAsKey, boolean isCollectedByForce) {
            this.collectedAsKey = collectedAsKey;
            this.isCollectedByForce = isCollectedByForce;
        }

        public boolean equals(Object obj) {
            if (obj instanceof CollectionType) {
                CollectionType ct = (CollectionType) obj;
                return ct.isCollectedByForce == isCollectedByForce && ct.collectedAsKey == collectedAsKey;
            }
            else
                return false;
        }

        public int hashCode() {
            return collectedAsKey * (isCollectedByForce ? 1 : -1);
        }

        public String toString() {
            return "collectedAsKey=" + collectedAsKey + "*isCollectedByForce=" + isCollectedByForce;
        }
    }

    public Collection<CollectedFromObj> getChildren(Object parent, Integer collectedAsKey) throws WTException {
        if (collectedData == null || !(parent instanceof Persistable) || cns == null)
            return null;

        Collection ret;

        Set<Persistable> cn = (Set) cns.get(PersistenceHelper.getObjectIdentifier((Persistable) parent));
        if (cn != null) {
            ret = new HashSet(cn.size());
            for (Persistable child : cn) {
                Map m = (Map) collectedData.get(PersistenceHelper.getObjectIdentifier(child));

                if (m != null) {
                    for (Iterator i = m.entrySet().iterator(); i.hasNext();) {
                        Map.Entry e = (Map.Entry) i.next();

                        CollectionType ct = (CollectionType) e.getKey();
                        if (collectedAsKey != null && collectedAsKey.intValue() != ct.collectedAsKey)
                            continue;

                        Map parents = (HashMap) e.getValue();

                        if (parents.containsKey(parent)) {
                            boolean isVisible = true;

                            if (hiddenDependents != null && hiddenDependents.contains(parent))
                                isVisible = false;

                            Collection links = (Collection) parents.get(parent);
                            CollectedFromObj cfo = new CollectedFromObj(child, parent, ct.collectedAsKey, isVisible,
                                    ct.isCollectedByForce, links);
                            NavigatedGraph graph = getNavigatedGraph(ct.collectedAsKey, (Persistable) parent, child);
                            if (graph != null)
                                cfo.setNavigatedGraph(graph);
                            ret.add(cfo);
                        }
                    }
                }
            }
        }
        else
            ret = Collections.EMPTY_LIST;

        return ret;
    }

    public NavigationUnit getNavigationUnit(int collectedAsKey, Persistable parent, Persistable child)
            throws WTException {
        return getNavigatedGraph(collectedAsKey, parent, child);
    }

    public NavigationUnit[] getNavigationUnit(Persistable parent, int collectedAsKey) throws WTException {
        return getNavigatedGraph(parent, collectedAsKey);
    }

    public NavigatedGraph getNavigatedGraph(int collectedAsKey, Persistable parent, Persistable child)
            throws WTException {
        NavigatedGraph ret = null;
        if (!(graphs == null || !(parent instanceof Persistable) || !(child instanceof Persistable))) {

            Map ckg = (Map) graphs.get(PersistenceHelper.getObjectIdentifier(parent));
            if (ckg != null) {
                Map kg = (Map) ckg.get(PersistenceHelper.getObjectIdentifier(child));
                if (kg != null)
                    ret = (NavigatedGraph) kg.get(Integer.valueOf(collectedAsKey));
            }
        }
        return ret;
    }

    public NavigatedGraph[] getNavigatedGraphWithoutVirtualElements(Persistable parent, int collectedAsKey)
            throws WTException {
        return getNavigatedGraph(parent, collectedAsKey, true, false);
    }

    public NavigatedGraph[] getNavigatedGraph(Persistable parent, int collectedAsKey) throws WTException {
        return getNavigatedGraph(parent, collectedAsKey, false, false);
    }

    public NavigatedGraph[] getNavigatedGraph(Persistable parent, int collectedAsKey, boolean isLinkOnlyStartNode)
            throws WTException {
        return getNavigatedGraph(parent, collectedAsKey, false, isLinkOnlyStartNode);
    }

    public NavigatedGraph[] getNavigatedGraph(Persistable parent, int collectedAsKey, boolean eraseClonedElements,
            boolean isLinkOnlyStartNode) throws WTException {
        NavigatedGraph[] ret = new NavigatedGraph[0];

        if (graphs == null || graphs.isEmpty())
            return ret;

        Collection tmp = new ArrayList();
        if (parent instanceof Iterated) {
            Collection<CollectedFromObj> children = getChildren(parent,
                    collectedAsKey == ANY_KEY ? null : Integer.valueOf(collectedAsKey));
            if (children != null && !children.isEmpty())
                for (CollectedFromObj cfo : children) {
                    NavigatedGraph ng = cfo.getNavigatedGraph();
                    if (ng != null)
                        tmp.add(ng);
                }
        }
        else {
            for (Iterator i = graphs.values().iterator(); i.hasNext();) {
                Map ckg = (Map) i.next();
                for (Iterator j = ckg.values().iterator(); j.hasNext();) {
                    Map kg = (Map) j.next();
                    if (collectedAsKey == ANY_KEY)
                        for (Iterator k = kg.values().iterator(); k.hasNext();) {
                            NavigatedGraph graph = (NavigatedGraph) k.next();
                            addGraphByLink(parent, graph, isLinkOnlyStartNode, tmp);
                        }
                    else {
                        NavigatedGraph graph = (NavigatedGraph) kg.get(collectedAsKey);
                        addGraphByLink(parent, graph, isLinkOnlyStartNode, tmp);
                    }
                }
            }
        }

        if (!tmp.isEmpty())
            ret = (NavigatedGraph[]) tmp.toArray(new NavigatedGraph[tmp.size()]);

        if (eraseClonedElements && ret.length > 0) {
            for (int i = 0; i < ret.length; i++) {
                NavigatedGraph ng = ret[i];
                if (ng.hasClonedPath()) {
                    ng = ng.clone();
                    ng.removeClonedElements();
                    ret[i] = ng;
                }
            }
        }

        return ret;
    }

    private void addGraphByLink(Persistable parent, NavigatedGraph graph, boolean isLinkOnlyStartNode, Collection tmp) {
        if (graph != null) {
            if (!isLinkOnlyStartNode || (isLinkOnlyStartNode && graph.getStartNode().equals(parent)))
                if (graph.hasNode(parent))
                    tmp.add(graph);
        }
    }

    public void addGraph(int collectedAsKey, NavigatedGraph graph) throws WTException {
        if (graph != null) {
            /*
             * if( graph.hasClonedPath() && log.isDebugEnabled() ) log.debug("Return cloned \n"+graph);
             */

            if (graphs == null)
                graphs = new HashMap();

            Persistable s = graph.getStartNode(), e = graph.getEndNode();
            ObjectIdentifier sId = PersistenceHelper.getObjectIdentifier(s),
                    eId = PersistenceHelper.getObjectIdentifier(e);
            if (navigatedObjs == null)
                navigatedObjs = new HashSet();
            navigatedObjs.addAll(Arrays.asList(new Persistable[] { s, e }));

            if (crValidator != null
                    && (!crValidator.isCollectedDependentValid(s) || !crValidator.isCollectedDependentValid(e)))
                return;

            Map ckg = (Map) graphs.get(sId);
            if (ckg == null) {
                ckg = new HashMap();
                graphs.put(sId, ckg);
            }

            Map kg = (Map) ckg.get(eId);
            if (kg == null) {
                kg = new HashMap();
                ckg.put(eId, kg);
            }

            kg.put(Integer.valueOf(collectedAsKey), graph);

            Set<IteratedUsageLink> ls = graph.getChildrn(s, IteratedUsageLink.class, true);
            if (ls != null && !ls.isEmpty())
                for (IteratedUsageLink l : ls) {
                    ObjectIdentifier lAId = (ObjectIdentifier) l.getRoleAObjectId(),
                            lBId = (ObjectIdentifier) l.getRoleBObjectId();
                    if (lAId.equals(sId))
                        l.setRoleAObject(s);
                    else if (lAId.equals(eId))
                        l.setRoleAObject(e);

                    Persistable sMaster = (s instanceof Iterated) ? ((Iterated) s).getMaster() : s,
                            eMaster = (e instanceof Iterated) ? ((Iterated) e).getMaster() : e;
                    if (lBId.equals(PersistenceHelper.getObjectIdentifier(sMaster)))
                        l.setRoleBObject(sMaster);
                    else if (lBId.equals(PersistenceHelper.getObjectIdentifier(eMaster)))
                        l.setRoleBObject(eMaster);
                }
        }
    }

    public String getCollectorID() {
        return collectorID;
    }

    public void setCollectorID(String collectorID) {
        this.collectorID = collectorID;
    }

    public Set<PathToOccurrence> getPathToOccurrenceByComponentId(long componentId) {
        Map<Long, Set<PathToOccurrence>> cmps = getComponents();
        return cmps.get(Long.valueOf(componentId));
    }

    public boolean isPathRetrieved(long[] componentId) {
        boolean isRetrieved = true;
        for (int i = 0; i < componentId.length && isRetrieved; i++) {
            Set path = getPathToOccurrenceByComponentId(componentId[i]);
            isRetrieved = path != null && !path.isEmpty();
        }
        return isRetrieved;
    }

    private Map<Long, Set<PathToOccurrence>> getComponents() {
        if (components == null) {
            components = new HashMap();
            for (NavigatedGraph ng : (Collection<NavigatedGraph>) graphs.values()) {
                Set<PathToOccurrence> ptos = ng.getElements(PathToOccurrence.class, true);
                if (ptos != null && !ptos.isEmpty())
                    for (PathToOccurrence pto : ptos) {
                        Long compID = Long.valueOf(pto.getOccID());
                        Set co = (Set) components.get(compID);
                        if (co == null) {
                            co = new HashSet();
                            components.put(compID, co);
                        }
                        co.add(pto);
                    }
            }
        }

        return components;
    }

    public Map getFileters() {
        return filters;
    }

    public void setFilters(Map filters) {
        this.filters = filters;
    }

    public void addAllLevelCollection(CollectionKind kind) {
        HashSet collectedAllLevel = (HashSet) appliedCollections.get(ALL_LEVELS);
        Integer key = Integer.valueOf(kind.getCollectedAsKey());
        collectedAllLevel.add(key);

        boolean isRequired = CollectionKind.REQUIRED_DEPENDENTS == key;
        HashSet collectedAll = (HashSet) appliedCollections.get(ALL_KINDS);
        if (key == CollectionKind.OPTIONAL_DEPENDENTS) {
            isRequired = true;
            addAllLevelCollection(collectedAll, collectedAllLevel, CollectionKind.OPTIONAL_MEMBER_DEPENDENTS);
            addAllLevelCollection(collectedAll, collectedAllLevel, CollectionKind.OPTIONAL_REF_DEPENDENTS);
            addAllLevelCollection(collectedAll, collectedAllLevel, CollectionKind.OPTIONAL_VARIANT_DEPENDENTS);
        }

        if (isRequired) {
            addAllLevelCollection(collectedAll, collectedAllLevel, CollectionKind.REQUIRED_DEPENDENTS);
            addAllLevelCollection(collectedAll, collectedAllLevel, CollectionKind.REQUIRED_MEMBER_DEPENDENTS);
            addAllLevelCollection(collectedAll, collectedAllLevel, CollectionKind.REQUIRED_REF_DEPENDENTS);
            addAllLevelCollection(collectedAll, collectedAllLevel, CollectionKind.REQUIRED_VARIANT_DEPENDENTS);
        }
    }

    public void addAllLevelCollection(HashSet collectedAll, HashSet collectedAllLevel, int key) {
        Integer intKey = Integer.valueOf(key);
        if (collectedAll.contains(intKey))
            collectedAllLevel.add(intKey);
    }

    public NavigationUnit[] getChildrenUnits(Persistable parent) throws WTException {
        return getNavigatedGraph(parent, ANY_KEY);
    }

    public NavigationUnit[] getParentUnits(Persistable child) throws WTException {
        NavigatedGraph[] ret = new NavigatedGraph[0];

        if (graphs == null || !(child instanceof Iterated))
            return ret;

        Collection tmp = new ArrayList();
        Collection<CollectedFromObj> parents = getCollectedFromObjs(child);
        if (parents != null && !parents.isEmpty())
            for (CollectedFromObj cfo : parents) {
                NavigatedGraph ng = cfo.getNavigatedGraph();
                if (ng != null)
                    tmp.add(ng);
            }

        if (!tmp.isEmpty())
            ret = (NavigatedGraph[]) tmp.toArray(new NavigatedGraph[tmp.size()]);

        return ret;
    }

    public Collection getCollectedChildren(Persistable parent) throws WTException {
        Collection ret;
        Collection<CollectedFromObj> children = getChildren(parent, null);
        if (children != null && !children.isEmpty()) {
            ret = new HashSet(children.size());
            for (CollectedFromObj cfo : children)
                ret.add(cfo.getCollectedObject());
        }
        else
            ret = Collections.EMPTY_SET;
        return ret;
    }

    public Collection getCollectedParents(Persistable child) throws WTException {
        Collection ret;
        Collection<CollectedFromObj> parents = getCollectedFromObjs(child);
        if (parents != null && !parents.isEmpty()) {
            ret = new HashSet(parents.size());
            for (CollectedFromObj cfo : parents)
                ret.add(cfo.getCollectedFrom());
        }
        else
            ret = Collections.EMPTY_SET;
        return ret;
    }

    public List<Integer> getAllCollectedKeys() {
        return foundKinds == null ? Collections.EMPTY_LIST : foundKinds;
    }

    public Collection getSeeds() {
        return seeds;
    }

    public Collection getChunkSeeds() {
        return chunkSeeds;
    }

    public void setSeeds(Collection seeds) {
        if (seeds != null)
            this.seeds = new ArrayList(seeds);
    }

    public void setChunkSeeds(Collection chunkSeeds) {
        if (chunkSeeds != null)
            this.chunkSeeds = new HashSet(chunkSeeds);
    }

    public Collection<CollectedFromObj> getChildren(Object parent) throws WTException {
        return getChildren(parent, null);
    }

    /**
     * <p>
     * The exception encountered during collection processing.
     * </p>
     * <p>
     * If the dependency fetching limit is exceeded while processing then a
     * {@link com.ptc.core.htmlcomp.collection.DependencyTracingLimitExceededException
     * DependencyTracingLimitExceededException} will be returned.
     * </p>
     * 
     */
    public void setException(WTException exp) {
        exception = exp;
    }

    public WTException getException() {
        return exception;
    }

    public void removeEmptySeeds(Collection chunkSeeds) {
        for (Iterator i = chunkSeeds.iterator(); i.hasNext();) {
            Persistable seed = (Persistable) i.next();
            if (!isParent(seed)) {
                allDependents.remove(seed);
                seeds.remove(seed);
            }
        }
    }

    public boolean hasCycles() throws WTException {
        if (hasCycles == null) {
            Collection[] cycles = getCyclicDependents();
            hasCycles = Boolean.valueOf(cycles.length > 0);
        }
        return hasCycles.booleanValue();
    }

    public Collection[] getCyclicDependents() throws WTException {
        if (seeds == null || seeds.isEmpty() || allDependents == null || allDependents.isEmpty())
            return new Collection[0];

        if (cyclicDependents == null) {
            List cycles = new ArrayList();
            Set prs = new HashSet(allDependents.size());
            for (Iterator i = seeds.iterator(); i.hasNext();)
                checkCycles(cycles, i.next(), prs);

            cyclicDependents = (Collection[]) cycles.toArray(new Collection[0]);
        }
        return cyclicDependents;
    }

    private void checkCycles(List cycles, Object parent, Set parents) throws WTException {
        if (parent instanceof Persistable) {
            parents.add(parent);
            NavigationUnit[] nus = getNavigationUnit((Persistable) parent, ANY_KEY);
            for (int i = 0; i < nus.length; i++) {
                Persistable child = nus[i].getEndNode();
                if (parents.contains(child)) {
                    Collection cycle = new ArrayList(2);
                    cycle.add(child);
                    cycle.add(parent);
                    cycles.add(cycle);
                }
                else
                    checkCycles(cycles, child, parents);

            }
            parents.remove(parent);
        }
    }

    public void setEsrMemberLink(Collection esrs) {
        if (esrs == null || esrs.isEmpty() || collectedData == null)
            return;

        int repl = 0;

        for (Iterator s = esrs.iterator(); s.hasNext();) {
            Persistable esr = (Persistable) s.next();
            ObjectIdentifier esrID = PersistenceHelper.getObjectIdentifier(esr);

            Set children = (Set) cns.get(esrID);

            if (children != null)
                for (Iterator c = children.iterator(); c.hasNext();) {
                    Object child = c.next();

                    if (graphs != null && child instanceof Persistable) {
                        Map ckg = (Map) graphs.get(esrID);
                        if (ckg != null) {
                            Map kg = (Map) ckg.get(PersistenceHelper.getObjectIdentifier((Persistable) child));
                            if (kg != null) {
                                NavigatedGraph ng = (NavigatedGraph) kg
                                        .get(Integer.valueOf(CollectionKind.REQUIRED_REF_DEPENDENTS));
                                if (ng != null)
                                    kg.put(CollectionKind.REQUIRED_MEMBER_DEPENDENTS, ng);
                            }
                        }
                    }

                    Map m = (Map) collectedData.get(getMapKey(child));

                    if (m == null)
                        continue;

                    for (Iterator i = m.entrySet().iterator(); i.hasNext();) {
                        Map.Entry e = (Map.Entry) i.next();

                        CollectionType ct = (CollectionType) e.getKey();

                        HashMap p = (HashMap) e.getValue();
                        for (Iterator j = p.entrySet().iterator(); j.hasNext();) {
                            Map.Entry pe = (Map.Entry) j.next();

                            Object parent = pe.getKey();

                            if (parent.equals(esr)) {
                                if (ct.collectedAsKey == CollectionKind.REQUIRED_REF_DEPENDENTS) {
                                    ct.collectedAsKey = CollectionKind.REQUIRED_MEMBER_DEPENDENTS;
                                    repl++;
                                }
                            }
                        }
                    }

                    if (log.isTraceEnabled())
                        log.trace("Set required member reference for " + esrs.size() + " collected esrs=" + repl);
                }
        }

    }

    public boolean wasPathToOccurrenceAlwaysRequested() {
        return wasPathToOccurrenceAlwaysRequested;
    }

    public void setWasPathToOccurrenceAlwaysRequested(boolean wasPathToOccurrenceAlwaysRequested) {
        this.wasPathToOccurrenceAlwaysRequested = wasPathToOccurrenceAlwaysRequested;
    }

    public void setCollectedResultValidator(CollectedResultValidator crValidator) {
        this.crValidator = crValidator;
    }

    public void setHasVirtualElements(boolean hasVirtualElements) {
        this.hasVirtualElements = hasVirtualElements;
    }

    public boolean hasVirtualElements() {
        return hasVirtualElements;
    }
}
