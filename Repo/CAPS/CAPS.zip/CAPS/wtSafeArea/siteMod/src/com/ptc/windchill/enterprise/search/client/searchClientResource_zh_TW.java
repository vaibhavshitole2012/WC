/* bcwti
 *
 * Copyright (c) 2013 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */
package com.ptc.windchill.enterprise.search.client;

import wt.util.resource.RBComment;
import wt.util.resource.RBEntry;
import wt.util.resource.RBPseudo;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

/**
 * searchResource message resource bundle [English/US]
 */
@RBUUID("com.ptc.windchill.enterprise.search.client.searchClientResource")
public final class searchClientResource_zh_TW extends WTListResourceBundle {
   @RBEntry("記�?跨工作階段的物件�?��?�項。")
   @RBComment("Decscription for preference 'remember object selection'.")
   public static final String PRIVATE_CONSTANT_0 = "STICKY_PICKER_SHORT_DESCRIPTION";

   @RBEntry("記�?跨工作階段的物件�?��?�項。")
   @RBComment("Decscription for preference 'remember object selection'.")
   public static final String PRIVATE_CONSTANT_1 = "STICKY_PICKER_DESCRIPTION";

   @RBEntry("記�?物件�?��?�項")
   @RBComment("Preference Remember object selection.")
   public static final String PRIVATE_CONSTANT_2 = "STICKY_PICKER";

   @RBEntry("此�??好設定用來將存�?�控制套用至�?�尋�?果。")
   @RBComment("This preference is used to apply access control on search results.")
   public static final String PRIVATE_CONSTANT_3 = "ACCESS_CONTROL_FLAG_SHORT_DESCRIPTION";

   @RBEntry("此�??好設定用來將存�?�控制套用至�?�尋�?果。")
   @RBComment("This preference is used to apply access control on search results.")
   public static final String PRIVATE_CONSTANT_4 = "ACCESS_CONTROL_FLAG_DESCRIPTION";

   @RBEntry("將存�?�控制套用至�?�尋�?果")
   @RBComment("Apply Access Control to Search Results")
   public static final String PRIVATE_CONSTANT_5 = "ACCESS_CONTROL_FLAG";

   @RBEntry("此�??好設定用來將存�?�控制套用至�?�尋�?果。")
   @RBComment("This preference is used to apply access control on search results.")
   public static final String PRIVATE_CONSTANT_6 = "ACCESS_CONTROL_FLAG_LONGDESCRIPTION";

   @RBEntry("使用 * 作為�?�用字元以傳回更多�?果。")
   @RBComment("Wildcard suggestion for keyword field")
   public static final String PRIVATE_CONSTANT_7 = "WILDCARD_SUGGESSTION";

   @RBEntry("說明")
   @RBComment("Search page help icon tooltip")
   public static final String PRIVATE_CONSTANT_8 = "HELP";

   @RBEntry("�?�尋")
   @RBComment("Label for the page title of the search page.")
   public static final String SEARCH_LABEL = "SEARCH_LABEL";

   @RBEntry("清除")
   @RBComment("Label for the clear button .")
   public static final String PRIVATE_CONSTANT_9 = "CLEAR_BUTTON";

   @RBEntry("�?�尋物件類型")
   @RBComment("Label for the type property on the search page.")
   public static final String PRIVATE_CONSTANT_10 = "SEARCH_FOR";

   @RBEntry("�??好設定")
   @RBComment("Label for the \"Preferences\" link on search page.")
   public static final String PRIVATE_CONSTANT_11 = "PREFERENCES_LNK";

   @RBEntry("開啟使用者�??好設定")
   @RBComment("Tooltip for the \"Preferences\" link on search page.")
   public static final String PRIVATE_CONSTANT_12 = "PREFERENCES_LNK_TT";

   @RBEntry("尋找")
   @RBComment("Label for the \"Show Results\" input field")
   public static final String PRIVATE_CONSTANT_13 = "RANGE_OF_SEARCH_PROPTY";

   @RBEntry("符�?�任一�?件")
   @RBComment("Label for one of the values in the \"Show Results\" pull down list")
   public static final String PRIVATE_CONSTANT_14 = "RANGE_OF_SEARCH_VALUE_OR";

   @RBEntry("符�?�全部�?件")
   @RBComment("Label for one of the values in the \"Show Results\" pull down list")
   public static final String PRIVATE_CONSTANT_15 = "RANGE_OF_SEARCH_VALUE_AND";

   @RBEntry("定義�?�尋範�?")
   @RBComment("Label for search scope <HR> separator of the search criteria")
   public static final String PRIVATE_CONSTANT_16 = "SCOPE_SEPARATOR_LABEL";

   @RBEntry("�?��?��?�尋�?件")
   @RBComment("Label for search criteria <HR> separator of the search criteria")
   public static final String PRIVATE_CONSTANT_17 = "CRITERIA_SEPARATOR_LABEL";

   @RBEntry("全部�?後關�?�")
   @RBComment("The default element in the container drop down list on search page.")
   public static final String PRIVATE_CONSTANT_18 = "ALL_CONTAINERS";

   @RBEntry("所有專案")
   @RBComment("Label for All Projects.")
   public static final String PRIVATE_CONSTANT_19 = "ALL_PROJECTS";

   @RBEntry("所有產�?")
   @RBComment("Label for All Products.")
   public static final String PRIVATE_CONSTANT_20 = "ALL_PRODUCTS";

   @RBEntry("所有物件庫")
   @RBComment("Label for All Libraries.")
   public static final String PRIVATE_CONSTANT_21 = "ALL_LIBRARIES";

   @RBEntry("未�?定關係")
   @RBComment("The default value for relationship on search in network page.")
   public static final String PRIVATE_CONSTANT_22 = "NO_RELATIONS";

   @RBEntry("�?後關�?�")
   @RBComment("Label for the property \"Search In:\" on the search page.")
   public static final String PRIVATE_CONSTANT_23 = "CONTAINER_TYPE_PROPTY";

   @RBEntry("僅�?我為�?員者")
   @RBComment("Label for the membership checkbox on the search page")
   public static final String PRIVATE_CONSTANT_24 = "MEMBER_OF_CONTAINER_CHKBX";

   @RBEntry("在我的組織內")
   @RBComment("Label for the search only in contexts in my organization checkbox on the search page")
   public static final String PRIVATE_CONSTANT_25 = "SEARCH_IN_USER_ORG_CHKBX";

   @RBEntry("�?�?�?果")
   @RBComment("Label for the \"Results Per Page:\" input field")
   public static final String PRIVATE_CONSTANT_26 = "ADHOC_PAGE_COUNT_PROPTY";

   @RBEntry("分類�?�尋")
   @RBComment("Label for the \"Classification Search\" link on search page.")
   public static final String PRIVATE_CONSTANT_27 = "CLASSIFICATION_SEARCH_LNK";

   @RBEntry("開啟分類�?�尋")
   @RBComment("Tooltip for the \"Classification Search\" link on search page.")
   public static final String PRIVATE_CONSTANT_28 = "CLASSIFICATION_SEARCH_LNK_TT";

   @RBEntry("進階�?�尋")
   @RBComment("Label for the page title of the advanced search page.")
   public static final String ADVANCED_SEARCH_LABEL = "ADVANCED_SEARCH_LABEL";

   @RBEntry("自訂...")
   @RBComment("Label for the link to the customize saved search table.")
   public static final String PRIVATE_CONSTANT_29 = "CUSTOMIZE_LINK_LABEL";

   @RBEntry("自訂已存�?�尋清單")
   @RBComment("Tool tip for the link to the customize saved search table.")
   public static final String PRIVATE_CONSTANT_30 = "CUSTOMIZE_LINK_TT";

   @RBEntry("群組")
   @RBComment("Label for header of groups table in saved search create clerk.")
   public static final String PRIVATE_CONSTANT_31 = "GROUP_TABLE_HEADER";

   @RBEntry("新增")
   @RBComment("Label for 'Add' action on the Group Access table of saved search create clerk.")
   public static final String PRIVATE_CONSTANT_32 = "ADD_GROUP_LABEL";

   @RBEntry("為已存�?�尋新增群組")
   @RBComment("Tool tip for 'Add' action on the Group Access table of saved search create clerk.")
   public static final String PRIVATE_CONSTANT_33 = "ADD_GROUP_TT";

   @RBEntry("群組存�?�")
   @RBComment("Label for the Group Access Tab in the saved search create clerk.")
   public static final String PRIVATE_CONSTANT_34 = "GROUP_ACCESS_TAB_LABEL";

   @RBEntry("為此�?�尋設定群組存�?�")
   @RBComment("Tool tip for the Group Access Tab in the saved search create clerk.")
   public static final String PRIVATE_CONSTANT_35 = "GROUP_ACCESS_TAB_TT";

   @RBEntry("- 擇�?�一個動作 -")
   @RBComment("Label for table action dropdown list.")
   public static final String PRIVATE_CONSTANT_36 = "TABLE_ACTION_LIST_PROMPT";

   @RBEntry("刪除此�?�尋")
   @RBComment("Label for delete action in customize saved search table.")
   public static final String PRIVATE_CONSTANT_37 = "DELETE_LABEL";

   @RBEntry("顯示")
   @RBComment("Label for show action in customize saved search table.")
   public static final String PRIVATE_CONSTANT_38 = "SHOW_LABEL";

   @RBEntry("隱�?")
   @RBComment("Label for hide action in customize saved search table.")
   public static final String PRIVATE_CONSTANT_39 = "HIDE_LABEL";

   @RBEntry("已存�?�尋")
   @RBComment("Label for header of customize saved search table.")
   public static final String PRIVATE_CONSTANT_40 = "CUSTOMIZE_SAVED_SEARCH_TABLE_LABEL";

   @RBEntry("於已存�?�尋清單中顯示")
   @RBComment("Label for display search check box on saved search create clerk.")
   public static final String PRIVATE_CONSTANT_41 = "DISPLAY_SEARCH_LABEL";

   @RBEntry("匯出至檔案")
   @RBComment("Label for the export button.")
   public static final String PRIVATE_CONSTANT_42 = "EXPORT_TO_FILE_LABEL";

   @RBEntry("匯出至檔案")
   @RBComment("Tool tip for the export button.")
   public static final String PRIVATE_CONSTANT_43 = "EXPORT_TO_FILE_TT";

   @RBEntry("將已匯出檔案儲存為")
   @RBComment("Label for the File name in the export wizard")
   public static final String PRIVATE_CONSTANT_44 = "EXPORT_FILE_SAVE";

   @RBEntry("格�?:")
   @RBComment("Label for the File format in the export wizard")
   public static final String PRIVATE_CONSTANT_45 = "EXPORT_FILE_FORMAT";

   @RBEntry("csv")
   @RBComment("Label for csv format to export")
   public static final String PRIVATE_CONSTANT_46 = "EXPORT_FORMAT_CSV";

   @RBEntry("xml")
   @RBComment("Label for xml format to export")
   public static final String PRIVATE_CONSTANT_47 = "EXPORT_FORMAT_XML";

   @RBEntry("html")
   @RBComment("Label for html format to export")
   public static final String PRIVATE_CONSTANT_48 = "EXPORT_FORMAT_HTML";

   @RBEntry("xls 報告")
   @RBComment("Label for xls format to export")
   public static final String PRIVATE_CONSTANT_49 = "EXPORT_FORMAT_XLS";

   @RBEntry("xls")
   @RBComment("Label for xls format to SUMA export")
   public static final String PRIVATE_CONSTANT_50 = "EXPORT_FORMAT_SUMA_XLS";

   @RBEntry("正在下載匯出檔...")
   @RBComment("Label for downloading the export file")
   public static final String PRIVATE_CONSTANT_51 = "ACT_LBL_DOWNLOAD";

   @RBEntry("請在完�?之後關閉視窗。")
   @RBComment("Close window message")
   public static final String PRIVATE_CONSTANT_52 = "ACT_LBL_CLOSE_MSG";

   @RBEntry("等於")
   @RBComment("Label for the operator pulldown on the advanced search, search criteria table")
   public static final String PRIVATE_CONSTANT_53 = "OP_EQ";

   @RBEntry("�?等於")
   @RBComment("Label for the operator pulldown on the advanced search, search criteria table")
   public static final String PRIVATE_CONSTANT_54 = "OP_NE";

   @RBEntry("�?於")
   @RBComment("Label for the operator pulldown on the advanced search, search criteria table")
   public static final String PRIVATE_CONSTANT_55 = "OP_LT";

   @RBEntry("�?於等於")
   @RBComment("Label for the operator pulldown on the advanced search, search criteria table")
   public static final String PRIVATE_CONSTANT_56 = "OP_LE";

   @RBEntry("大於")
   @RBComment("Label for the operator pulldown on the advanced search, search criteria table")
   public static final String PRIVATE_CONSTANT_57 = "OP_GT";

   @RBEntry("大於等於")
   @RBComment("Label for the operator pulldown on the advanced search, search criteria table")
   public static final String PRIVATE_CONSTANT_58 = "OP_GE";

   @RBEntry("尋找�?刪除的已儲存�?�尋")
   @RBComment("Label for the \"Administrative Delete\" action for saved searches.")
   public static final String PRIVATE_CONSTANT_59 = "ADMIN_DELETE";

   @RBEntry("�?�擇物件類型")
   @RBComment("Label for the object type picker on the simple search page.")
   public static final String PRIVATE_CONSTANT_60 = "CHANGE_OBJECT_TYPES";

   @RBEntry("�?��?�")
   @RBComment("Button to select a saved search and populate criteria")
   public static final String PRIVATE_CONSTANT_61 = "SELECT_BTN";

   @RBEntry("-- �?��?� --")
   @RBComment("Label for the default element for the \"Criteria\" pulldown on the Advanced Search page")
   public static final String PRIVATE_CONSTANT_62 = "SELECT_CRITERION";

   @RBEntry("關閉")
   @RBComment("Label for an action button that closes a window")
   public static final String PRIVATE_CONSTANT_63 = "CLOSE_BUTTON";

   @RBEntry("尋找�?刪除的已儲存�?�尋")
   @RBComment("Label for the saved search administrative delete clerk")
   public static final String ADMIN_DELETE_PICKER_LABEL = "ADMIN_DELETE_PICKER_LABEL";

   @RBEntry("建立者")
   @RBComment("Label for the saved search admin delete picker for created by")
   public static final String PRIVATE_CONSTANT_64 = "ADMIN_DELETE_CREATED_BY_LABEL";

   @RBEntry("建立時間")
   @RBComment("Label for the saved search admin delete picker for created on")
   public static final String PRIVATE_CONSTANT_65 = "ADMIN_DELETE_CREATED_ON_LABEL";

   @RBEntry("上次修改")
   @RBComment("Label for the saved search admin delete picker for last modified criteria")
   public static final String PRIVATE_CONSTANT_66 = "ADMIN_DELETE_LAST_UPDATED_LABEL";

   @RBEntry("建立者")
   @RBComment("Label for the saved search customize table \"created by\" column")
   public static final String PRIVATE_CONSTANT_67 = "CREATED_BY_LABEL";

   @RBEntry("�?有的用戶端")
   @RBComment("Label for the saved search customize table owningclient (owner) column")
   public static final String PRIVATE_CONSTANT_68 = "QUERY_OWNING_CLIENT";

   @RBEntry("群組存�?�")
   @RBComment("Label for the saved search customize table group access column")
   public static final String PRIVATE_CONSTANT_69 = "QUERY_GROUP_ACCESS";

   @RBEntry("範�?")
   @RBComment("Label for the saved search table scope column")
   public static final String PRIVATE_CONSTANT_70 = "SAVED_QUERY_SCOPE";

   @RBEntry("�??稱")
   @RBComment("Label for the saved search customize table name column")
   public static final String PRIVATE_CONSTANT_71 = "NAME_LABEL";

   @RBEntry("顯示")
   @RBComment("Label for the saved search customize table show column")
   public static final String PRIVATE_CONSTANT_72 = "QUERY_SHOW";

   @RBEntry("全部�?�用物件類型")
   @RBComment("Label for the type property")
   public static final String PRIVATE_CONSTANT_73 = "ALL_ITEMS";

   @RBEntry("�??稱")
   @RBComment("Label for the name attribute")
   public static final String PRIVATE_CONSTANT_74 = "NAME_ATTRIBUTE";

   @RBEntry("編號")
   @RBComment("Label for the number attribute")
   public static final String PRIVATE_CONSTANT_75 = "NUMBER_ATTRIBUTE";

   @RBEntry("上次修改")
   @RBComment("Label for the last modified attribute")
   public static final String PRIVATE_CONSTANT_76 = "LAST_UPDATED_ATTRIBUTE";

   @RBEntry("從")
   @RBComment("Label for the From date attribute")
   public static final String PRIVATE_CONSTANT_77 = "FROM_DATE_ATTRIBUTE";

   @RBEntry("到")
   @RBComment("Label for the To date attribute")
   public static final String PRIVATE_CONSTANT_78 = "TO_DATE_ATTRIBUTE";

   @RBEntry("建立時間")
   @RBComment("Label for the created attribute")
   public static final String PRIVATE_CONSTANT_79 = "CREATED_ATTRIBUTE";

   @RBEntry("全部")
   @RBComment("All")
   public static final String PRIVATE_CONSTANT_80 = "VERSION_ALL";

   @RBEntry("最新")
   @RBComment("Latest")
   public static final String PRIVATE_CONSTANT_81 = "VERSION_LATEST";

   @RBEntry("關�?�字")
   @RBComment("Keyword")
   public static final String PRIVATE_CONSTANT_82 = "KEYWORD_LABEL";

   @RBEntry("已存�?�尋")
   @RBComment("Saved Searches")
   public static final String PRIVATE_CONSTANT_83 = "SAVED_SEARCH_LABEL";

   @RBEntry("-- �?��?� --")
   @RBComment("-- Select a Search --")
   public static final String PRIVATE_CONSTANT_84 = "SELECT_SEARCH_LABEL";

   @RBEntry("版本修訂")
   @RBComment("Version")
   public static final String PRIVATE_CONSTANT_85 = "VERSION_LABEL";

   @RBEntry("�?��?�")
   @RBComment("Select")
   public static final String PRIVATE_CONSTANT_86 = "SELECT_LABEL";

   @RBEntry("指定")
   @RBComment("Specify")
   public static final String PRIVATE_CONSTANT_87 = "SPECIFY_LABEL";

   @RBEntry("版�?")
   @RBComment("Iteration")
   public static final String PRIVATE_CONSTANT_88 = "ITERATION_LABEL";

   @RBEntry("�?件:")
   @RBComment("Criteria")
   public static final String PRIVATE_CONSTANT_89 = "CRITERIA_LABEL";

   /**
    * Picker Related localized values
    **/
   @RBEntry("使用者�??稱")
   @RBComment("User Name")
   public static final String PRIVATE_CONSTANT_90 = "USER_NAME_LABEL";

   @RBEntry("全�??")
   @RBComment("Full Name")
   public static final String PRIVATE_CONSTANT_91 = "FULL_NAME_LABEL";

   @RBEntry("電�?郵件")
   @RBComment("Email")
   public static final String PRIVATE_CONSTANT_92 = "EMAIL_LABEL";

   @RBEntry("組織�??稱")
   @RBComment("Organization Name")
   public static final String PRIVATE_CONSTANT_93 = "ORG_NAME_LABEL";

   @RBEntry("組織 ID")
   @RBComment("Organization ID")
   public static final String PRIVATE_CONSTANT_94 = "ORG_ID_LABEL";

   @RBEntry("群組�??稱")
   @RBComment("Group Name")
   public static final String PRIVATE_CONSTANT_95 = "GROUP_NAME_LABEL";

   @RBEntry("�??述")
   @RBComment("Description")
   public static final String PRIVATE_CONSTANT_96 = "DESCRIPTION_LABEL";

   @RBEntry("�?後關�?��??稱")
   @RBComment("Context Name")
   public static final String PRIVATE_CONSTANT_97 = "CONTEXT_NAME_LABEL";

   @RBEntry("狀態")
   @RBComment("State")
   public static final String PRIVATE_CONSTANT_98 = "STATE_LABEL";

   @RBEntry("�?後關�?�")
   @RBComment("Context")
   public static final String PRIVATE_CONSTANT_99 = "CONTEXT_LABEL";

   @RBEntry("編號")
   @RBComment("Number")
   public static final String PRIVATE_CONSTANT_100 = "NUMBER_LABEL";

   @RBEntry("�?�與者�??稱")
   @RBComment("Participant Name")
   public static final String PRIVATE_CONSTANT_101 = "PARTICIPANT_NAME_LABEL";

   @RBEntry("輸入使用者的全�??�?群組�??稱 (例如 Blue Group) 或組織�??稱 (例如 XYZ Organization)。使用分號 (;) 分隔�?�個項目。�?�使用星號 (*) 作為�?�用字元; 例如: J* Doe; Jane Smith; Blue Group; * Organization。")
   @RBComment("Principal Picker Help Text")
   public static final String PRIVATE_CONSTANT_102 = "PRINCIPAL_PICKER_HELP_TEXT";

   @RBEntry("輸入使用者的全�??。使用分號 (;) 分隔�?�個項目。�?�加入�?�用字元 * 代表任何字元。例如輸入 * Mike; Smith, Jane,  J* Doe。")
   @RBComment("User Picker Help Text")
   public static final String PRIVATE_CONSTANT_103 = "USER_PICKER_HELP_TEXT";

   @RBEntry("e.g. Mary Smith; *Smith; Mary*")
   @RBComment("User Picker Short Help Text")
   public static final String PRIVATE_CONSTANT_104 = "USER_PICKER_SHORT_HELP_TEXT";

   @RBEntry("�?�入使用者�??稱 (使用者�??字)。用分號分隔多項輸入項。�?�包括 * �?�用字元以代表字元。例舉: Admin*; Mike")
   @RBComment("User Picker User Name Help Text")
   public static final String PRIVATE_CONSTANT_105 = "USER_PICKER_NAME_HELP_TEXT";

   @RBEntry("e.g. Admin*; Mike")
   @RBComment("User Picker User Name Short Help Text")
   public static final String PRIVATE_CONSTANT_106 = "USER_PICKER_NAME_SHORT_HELP_TEXT";

   @RBEntry("輸入�?�?�尋的組織�??稱。使用分號分隔�?�個項目。�?�包括�?�用字元 * 代表任何字元。例如輸入 XYZ Organization; * Organization;  ABC Org*")
   @RBComment("Org Picker Help Text")
   public static final String PRIVATE_CONSTANT_107 = "ORG_PICKER_HELP_TEXT";

   @RBEntry("輸入�?�?�尋的群組�??稱。使用分號分隔�?�個項目。�?�包括�?�用字元 * 代表任何字元。例如輸入 Red Group; * Group; Yellow *")
   @RBComment("Group Picker Help Text")
   public static final String PRIVATE_CONSTANT_108 = "GROUP_PICKER_HELP_TEXT";

   @RBEntry("物件�??稱")
   @RBComment("Object Name lable comment")
   public static final String PRIVATE_CONSTANT_109 = "ITEM_NAME_LABEL";

   @RBEntry("物件版本")
   @RBComment("Object Version comment")
   public static final String PRIVATE_CONSTANT_110 = "ITEM_VERSION_LABEL";

   @RBEntry("物件編號")
   @RBComment("Object Number label")
   public static final String PRIVATE_CONSTANT_111 = "ITEM_NUMBER_LABEL";

   @RBEntry("物件版�?")
   @RBComment("Object Iteration label")
   public static final String PRIVATE_CONSTANT_112 = "ITEM_ITERATION_LABEL";

   @RBEntry("物件 CAD 檔案�??稱")
   @RBComment("Object CAD File Name label")
   public static final String PRIVATE_CONSTANT_113 = "ITEM_CAD_FILE_NAME_LABEL";

   @RBEntry("物件狀態")
   @RBComment("Object State label")
   public static final String PRIVATE_CONSTANT_114 = "ITEM_STATE_LABEL";

   @RBEntry("物件�?後關�?�")
   @RBComment("Object Context Path label")
   public static final String PRIVATE_CONSTANT_115 = "ITEM_CONTEXT_PATH_LABEL";

   @RBEntry("物件檢視")
   @RBComment("Object View label")
   public static final String PRIVATE_CONSTANT_116 = "ITEM_VIEW_LABEL";

   @RBEntry("物件建立者")
   @RBComment("Object Creator label")
   public static final String PRIVATE_CONSTANT_117 = "ITEM_CREATOR_LABEL";

   @RBEntry("全部�?後關�?�類型")
   @RBComment("Text to be displayed in case of context picker for all object types")
   public static final String PRIVATE_CONSTANT_118 = "ALL_CONTEXT_ITEMS";

   /**
    * Picker Titles
    **/
   @RBEntry("尋找使用者")
   @RBComment("User Picker Title")
   public static final String PRIVATE_CONSTANT_119 = "USER_PICKER_TITLE";

   @RBEntry("尋找組織")
   @RBComment("Organization Picker Title")
   public static final String PRIVATE_CONSTANT_120 = "ORG_PICKER_TITLE";

   /**
    * Query Builder table column headings
    **/
   @RBEntry("�?�尋�?件")
   @RBComment("Search Criteria")
   public static final String QB_TABLE_HEADING_LABEL = "QB_TABLE_HEADING_LABEL";

   @RBEntry("�??稱")
   @RBComment("Name")
   public static final String QB_NAME_LABEL = "QB_NAME_LABEL";

   @RBEntry("�?�算�?")
   @RBComment("Operator")
   public static final String PRIVATE_CONSTANT_121 = "QB_OPERATOR_LABEL";

   @RBEntry("值")
   @RBComment("Value")
   public static final String PRIVATE_CONSTANT_122 = "QB_VALUE_LABEL";

   @RBEntry("�?�尋�?果")
   @RBComment("Search Results")
   public static final String PRIVATE_CONSTANT_123 = "SEARCH_RESULTS_TABLE";

   @RBEntry("您的工作階段資料已�?�期。請�?覆您的動作")
   @RBComment("Session Expired")
   public static final String SESSION_EXPIRED_MSG = "SESSION_EXPIRED_MSG";

   @RBEntry("此�?已�?�期，因此�?�能導致�?正確�?�尋�?果。請�?新執行�?�尋。")
   @RBComment("Back Button Clicked before Search")
   public static final String PRIVATE_CONSTANT_124 = "CHECK_BACKBUTTON_CLICKED";

   @RBEntry("新增")
   @RBComment("Add text for attribute menu drop down")
   public static final String PRIVATE_CONSTANT_125 = "ADD_CRITERIA";

   @RBEntry("清除")
   @RBComment("Clear criteria link")
   public static final String PRIVATE_CONSTANT_126 = "CLEAR_CRITERIA";

   @RBEntry("匯出清單至檔案")
   public static final String PRIVATE_CONSTANT_127 = "search.exportSearchResults.description";

   @RBEntry("匯出清單至檔案")
   public static final String PRIVATE_CONSTANT_128 = "search.exportSearchResults.tooltip";

   @RBEntry("../../com/ptc/core/ui/images/export.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_129 = "search.exportSearchResults.icon";

   @RBEntry("height=300,width=600")
   @RBPseudo(false)
   @RBComment("DO NOT TRANSLATE")
   public static final String PRIVATE_CONSTANT_130 = "search.exportSearchResults.moreurlinfo";

   @RBEntry("儲存此�?�尋")
   public static final String PRIVATE_CONSTANT_131 = "search.saveThisSearch.description";

   @RBEntry("儲存此�?�尋")
   public static final String PRIVATE_CONSTANT_132 = "search.saveThisSearch.tooltip";

   @RBEntry("�?��?�")
   public static final String PRIVATE_CONSTANT_133 = "search.selectSearch.description";

   @RBEntry("�?�尋")
   public static final String PRIVATE_CONSTANT_134 = "search.search.description";

   @RBEntry("移除")
   public static final String PRIVATE_CONSTANT_135 = "search.remove.description";

   @RBEntry("移除")
   public static final String PRIVATE_CONSTANT_136 = "search.remove.tooltip";

   @RBEntry("../../wtcore/images/com/ptc/core/ca/web/misc/delete.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_137 = "search.remove.icon";

   @RBEntry("在網路內�?�尋")
   public static final String PRIVATE_CONSTANT_138 = "search.networkSearch.description";

   @RBEntry("在網路內�?�尋")
   public static final String PRIVATE_CONSTANT_139 = "search.networkSearch.tooltip";

   @RBEntry("netmarkets/images/search_tbar16.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_140 = "search.networkSearch.icon";

   @RBEntry("在節點內�?�尋")
   public static final String PRIVATE_CONSTANT_141 = "search.searchInNode.description";

   @RBEntry("在節點內�?�尋")
   public static final String PRIVATE_CONSTANT_142 = "search.searchInNode.tooltip";

   @RBEntry("../../netmarkets/images/search.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_143 = "search.searchInNode.icon";

   @RBEntry("�?�尋相關物件")
   public static final String PRIVATE_CONSTANT_144 = "search.relatedItemSearch.description";

   @RBEntry("�?�尋相關物件")
   public static final String PRIVATE_CONSTANT_145 = "search.relatedItemSearch.tooltip";

   @RBEntry("netmarkets/images/related_objects_search.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_146 = "search.relatedItemSearch.icon";

   @RBEntry("自訂...")
   public static final String PRIVATE_CONSTANT_147 = "search.relationPicker.description";

   @RBEntry("自訂...")
   public static final String PRIVATE_CONSTANT_148 = "search.relationPicker.tooltip";

   @RBEntry("�?�擇�?�?�尋的關係")
   public static final String PRIVATE_CONSTANT_149 = "search.relationPicker.title";

   @RBEntry("height=600,width=600")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_150 = "search.relationPicker.moreurlinfo";

   @RBEntry("�?��?�一或多個�?�?�尋的關係")
   public static final String PRIVATE_CONSTANT_151 = "search.relationPickerStep.title";

   @RBEntry("�?��?��?�?�尋的關係")
   public static final String PRIVATE_CONSTANT_152 = "search.relationPickerStep.tooltip";

   @RBEntry("�?��?�關係")
   public static final String PRIVATE_CONSTANT_153 = "search.relationPickerStep.description";

   @RBEntry("刪除此�?�尋")
   public static final String PRIVATE_CONSTANT_154 = "SavedQuery.deleteQuery.description";

   @RBEntry("刪除此�?�尋")
   public static final String PRIVATE_CONSTANT_155 = "SavedQuery.deleteQuery.tooltip";

   @RBEntry("netmarkets/images/delete.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_156 = "SavedQuery.deleteQuery.icon";

   @RBEntry("顯示")
   public static final String PRIVATE_CONSTANT_157 = "SavedQuery.showQuery.description";

   @RBEntry("顯示")
   public static final String PRIVATE_CONSTANT_158 = "SavedQuery.showQuery.tooltip";

   @RBEntry("../../wtcore/images/search_show.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_159 = "SavedQuery.showQuery.icon";

   @RBEntry("隱�?")
   public static final String PRIVATE_CONSTANT_160 = "SavedQuery.hideQuery.description";

   @RBEntry("隱�?")
   public static final String PRIVATE_CONSTANT_161 = "SavedQuery.hideQuery.tooltip";

   @RBEntry("../../wtcore/images/search_hide.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_162 = "SavedQuery.hideQuery.icon";

   @RBEntry("刪除")
   public static final String PRIVATE_CONSTANT_163 = "SavedQuery.deleteRowQuery.description";

   @RBEntry("刪除")
   public static final String PRIVATE_CONSTANT_164 = "SavedQuery.deleteRowQuery.tooltip";

   @RBEntry("../../wtcore/images/com/ptc/core/ca/web/misc/delete.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_165 = "SavedQuery.deleteRowQuery.icon";

   @RBEntry("顯示")
   public static final String PRIVATE_CONSTANT_166 = "SavedQuery.showRowQuery.description";

   @RBEntry("顯示")
   public static final String PRIVATE_CONSTANT_167 = "SavedQuery.showRowQuery.tooltip";

   @RBEntry("../../wtcore/images/search_show.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_168 = "SavedQuery.showRowQuery.icon";

   @RBEntry("隱�?")
   public static final String PRIVATE_CONSTANT_169 = "SavedQuery.hideRowQuery.description";

   @RBEntry("隱�?")
   public static final String PRIVATE_CONSTANT_170 = "SavedQuery.hideRowQuery.tooltip";

   @RBEntry("../../wtcore/images/search_hide.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_171 = "SavedQuery.hideRowQuery.icon";

   @RBEntry("管�?�刪除")
   public static final String PRIVATE_CONSTANT_172 = "search.adminDelete.description";

   @RBEntry("管�?�刪除")
   public static final String PRIVATE_CONSTANT_173 = "search.adminDelete.tooltip";

   @RBEntry("../../wtcore/images/search_deletesaved.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_174 = "search.adminDelete.icon";

   /**
    * Entries for simplesearch typepicker "Customize" link.
    * Copied from \wcEnterprise\EnterpriseUI\src\com\ptc\windchill\enterprise\picker\type\typePickerResource.rbInfo
    **/
   @RBEntry("新增/更新")
   @RBComment("Used as the label for the find action for a SimpleSearch page Type Picker.")
   public static final String PRIVATE_CONSTANT_175 = "search.typePicker.description";

   @RBEntry("尋找類型")
   @RBComment("Used as the title for the find action pop-up wizard for a Type Picker.")
   public static final String PRIVATE_CONSTANT_176 = "search.typePicker.title";

   @RBEntry("height=600,width=500")
   @RBPseudo(false)
   @RBComment("DO NOT TRANSLATE")
   public static final String PRIVATE_CONSTANT_177 = "search.typePicker.moreurlinfo";

   /**
    * Entries for simplesearch newtypepicker "Customize" link.
    * Copied from \wcEnterprise\EnterpriseUI\src\com\ptc\windchill\enterprise\picker\type\typePickerResource.rbInfo
    **/
   @RBEntry("新增/更新...")
   @RBComment("Used as the label for the find action for a SimpleSearch page Type Picker.")
   public static final String PRIVATE_CONSTANT_178 = "search.newtypePicker.description";

   @RBEntry("尋找類型")
   @RBComment("Used as the title for the find action pop-up wizard for a Type Picker.")
   public static final String PRIVATE_CONSTANT_179 = "search.newtypePicker.title";

   @RBEntry("height=600,width=375")
   @RBPseudo(false)
   @RBComment("DO NOT TRANSLATE")
   public static final String PRIVATE_CONSTANT_180 = "search.newtypePicker.moreurlinfo";

   @RBEntry("完整�?果清單")
   @RBComment("Full Result List option in the picker dropdown")
   public static final String FULL_RESULT_LIST = "FULL_RESULT_LIST";

   @RBEntry("管�?�刪除")
   public static final String PRIVATE_CONSTANT_181 = "SavedQuery.finalDelete.description";

   @RBEntry("管�?�刪除")
   public static final String PRIVATE_CONSTANT_182 = "SavedQuery.finalDelete.tooltip";

   @RBEntry("netmarkets/images/delete.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_183 = "SavedQuery.finalDelete.icon";

   @RBEntry("isAdminDelete=true")
   @RBPseudo(false)
   @RBComment("DO NOT TRANSLATE")
   public static final String PRIVATE_CONSTANT_184 = "SavedQuery.finalDelete.moreurlinfo";

   @RBEntry("匯出")
   public static final String PRIVATE_CONSTANT_185 = "SavedQuery.savedQueryExport.description";

   @RBEntry("netmarkets/images/export.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_186 = "SavedQuery.savedQueryExport.icon";

   @RBEntry("匯出已存查詢")
   public static final String PRIVATE_CONSTANT_187 = "SavedQuery.savedQueryExport.title";

   @RBEntry("匯出已存�?�尋")
   public static final String PRIVATE_CONSTANT_188 = "SavedQuery.savedQueryExport.tooltip";

   @RBEntry("height=300,width=500")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_189 = "SavedQuery.savedQueryExport.moreurlinfo";

   @RBEntry("匯入")
   public static final String PRIVATE_CONSTANT_190 = "SavedQuery.savedQueryImport.description";

   @RBEntry("netmarkets/images/import.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_191 = "SavedQuery.savedQueryImport.icon";

   @RBEntry("匯入已存查詢")
   public static final String PRIVATE_CONSTANT_192 = "SavedQuery.savedQueryImport.title";

   @RBEntry("匯入已存�?�尋")
   public static final String PRIVATE_CONSTANT_193 = "SavedQuery.savedQueryImport.tooltip";

   @RBEntry("height=300,width=500")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_194 = "SavedQuery.savedQueryImport.moreurlinfo";

   @RBEntry("匯入")
   public static final String PRIVATE_CONSTANT_195 = "search.import.description";

   @RBEntry("匯入已存�?�尋")
   public static final String PRIVATE_CONSTANT_196 = "search.import.title";

   @RBEntry("匯入")
   public static final String PRIVATE_CONSTANT_197 = "search.import_step.description";

   @RBEntry("匯入已存�?�尋")
   public static final String PRIVATE_CONSTANT_198 = "search.import_step.title";

   @RBEntry("開始")
   public static final String PRIVATE_CONSTANT_199 = "search.typeChange.description";

   @RBEntry("全部清除")
   public static final String PRIVATE_CONSTANT_200 = "search.clearSearch.description";

   @RBEntry("尋找...")
   public static final String PRIVATE_CONSTANT_201 = "search.callSearchPicker.description";

   @RBEntry("尋找...")
   public static final String PRIVATE_CONSTANT_202 = "search.callSearchPicker.tooltip";

   @RBEntry("height=768,width=550")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_203 = "search.callSearchPicker.moreurlinfo";

   @RBEntry("新增群組")
   public static final String PRIVATE_CONSTANT_204 = "search.callSavedSearchGroupPicker.description";

   @RBEntry("新增群組")
   public static final String PRIVATE_CONSTANT_205 = "search.callSavedSearchGroupPicker.title";

   @RBEntry("新增群組")
   public static final String PRIVATE_CONSTANT_206 = "search.callSavedSearchGroupPicker.tooltip";

   @RBEntry("height=550,width=400")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_207 = "search.callSavedSearchGroupPicker.moreurlinfo";

   @RBEntry("netmarkets/images/add16x16.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_208 = "search.callSavedSearchGroupPicker.icon";

   @RBEntry("移除群組")
   public static final String PRIVATE_CONSTANT_209 = "search.removeSavedSearchGroups.description";

   @RBEntry("移除群組")
   public static final String PRIVATE_CONSTANT_210 = "search.removeSavedSearchGroups.title";

   @RBEntry("移除群組")
   public static final String PRIVATE_CONSTANT_211 = "search.removeSavedSearchGroups.tooltip";

   @RBEntry("netmarkets/images/remove16x16.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_212 = "search.removeSavedSearchGroups.icon";

   @RBEntry("進階�?�項")
   public static final String PRIVATE_CONSTANT_213 = "search.saveThisSearchNew.description";

   @RBEntry("進階�?�項")
   public static final String PRIVATE_CONSTANT_214 = "search.saveThisSearchNew.tooltip";

   @RBEntry("進階�?�項")
   public static final String PRIVATE_CONSTANT_215 = "search.saveThisSearchNew.title";

   @RBEntry("設定已儲存的�?�尋�??稱")
   public static final String PRIVATE_CONSTANT_216 = "search.saveThisSearch_saveName.description";

   @RBEntry("設定已儲存的�?�尋�??稱")
   public static final String PRIVATE_CONSTANT_217 = "search.saveThisSearch_saveName.tooltip";

   @RBEntry("定義詳細資訊")
   public static final String PRIVATE_CONSTANT_218 = "search.saveThisSearch_saveName.title";

   @RBEntry("設定必�?屬性")
   public static final String PRIVATE_CONSTANT_219 = "search.saveThisSearch_saveRequired.description";

   @RBEntry("設定必�?屬性")
   public static final String PRIVATE_CONSTANT_220 = "search.saveThisSearch_saveRequired.tooltip";

   @RBEntry("設定必�?屬性")
   public static final String PRIVATE_CONSTANT_221 = "search.saveThisSearch_saveRequired.title";

   @RBEntry("設定表格檢視")
   public static final String PRIVATE_CONSTANT_222 = "search.saveThisSearch_saveTableView.description";

   @RBEntry("設定表格檢視")
   public static final String PRIVATE_CONSTANT_223 = "search.saveThisSearch_saveTableView.tooltip";

   @RBEntry("設定表格檢視")
   public static final String PRIVATE_CONSTANT_224 = "search.saveThisSearch_saveTableView.title";

   @RBEntry("設定群組存�?�")
   public static final String PRIVATE_CONSTANT_225 = "search.saveThisSearch_saveAccess.description";

   @RBEntry("設定群組存�?�")
   public static final String PRIVATE_CONSTANT_226 = "search.saveThisSearch_saveAccess.tooltip";

   @RBEntry("設定群組存�?�")
   public static final String PRIVATE_CONSTANT_227 = "search.saveThisSearch_saveAccess.title";

   /**
    * Saved Search related fields
    **/
   @RBEntry("�??稱")
   @RBComment("Search Name")
   public static final String PRIVATE_CONSTANT_228 = "SAVED_SEARCH_NAME";

   @RBEntry("於已存�?�尋清單中顯示")
   @RBComment("Show in Saved Search list")
   public static final String PRIVATE_CONSTANT_229 = "SAVED_SEARCH_SHOW";

   @RBEntry("請輸入�??稱")
   @RBComment("Please enter Name")
   public static final String PRIVATE_CONSTANT_230 = "PLEASE_ENTER_NAME";

   @RBEntry("建立表格檢視")
   @RBComment("Create Table View")
   public static final String PRIVATE_CONSTANT_231 = "SAVED_SEARCH_CREATE_VIEW";

   @RBEntry("表格檢視")
   @RBComment("Use Existing Table View")
   public static final String PRIVATE_CONSTANT_232 = "SAVED_SEARCH_EXISTING_VIEW";

   @RBEntry("- 擇�?�一個檢視 -")
   @RBComment("- Pick a View -")
   public static final String PRIVATE_CONSTANT_233 = "PICK_VIEW";

   @RBEntry("�?�用的屬性:")
   @RBComment("Available Attributes:")
   public static final String PRIVATE_CONSTANT_234 = "AVAILABLE_ATTRIBUTES";

   @RBEntry("必�?屬性:")
   @RBComment("Required Attributes:")
   public static final String PRIVATE_CONSTANT_235 = "REQUIRED_ATTRIBUTES";

   @RBEntry("新增")
   @RBComment("Add")
   public static final String PRIVATE_CONSTANT_236 = "ADD_ATTRIBUTE";

   @RBEntry("移除")
   @RBComment("Remove")
   public static final String PRIVATE_CONSTANT_237 = "REMOVE_ATTRIBUTE";

   @RBEntry("�?設 CAD 文件檢視")
   @RBComment("Default CAD Document View")
   public static final String PRIVATE_CONSTANT_238 = "CADDOC_TABLEVIEW_NAME";

   @RBEntry("�?設 EPM 文件�?�尋表檢視")
   @RBComment("Default EPM Document Search Table View")
   public static final String PRIVATE_CONSTANT_239 = "CADDOC_TABLEVIEW_DESC";

   @RBEntry("EPM 文件")
   @RBComment("EPM Document")
   public static final String PRIVATE_CONSTANT_240 = "CADDOC_TABLEVIEW_LABEL";

   @RBEntry("�?設零件檢視")
   @RBComment("Default Part View")
   public static final String PRIVATE_CONSTANT_241 = "WTPART_TABLEVIEW_NAME";

   @RBEntry("�?設零件�?�尋表檢視")
   @RBComment("Default Part Search Table View")
   public static final String PRIVATE_CONSTANT_242 = "WTPART_TABLEVIEW_DESC";

   @RBEntry("零件")
   @RBComment("Part ")
   public static final String PRIVATE_CONSTANT_243 = "WTPART_TABLEVIEW_LABEL";

   @RBEntry("�?設文件檢視")
   @RBComment("Default Document View")
   public static final String PRIVATE_CONSTANT_244 = "WTDOCUMENT_TABLEVIEW_NAME";

   @RBEntry("�?設文件�?�尋表檢視")
   @RBComment("Default Document Search Table View")
   public static final String PRIVATE_CONSTANT_245 = "WTDOCUMENT_TABLEVIEW_DESC";

   @RBEntry("文件")
   @RBComment("Document")
   public static final String PRIVATE_CONSTANT_246 = "WTDOCUMENT_TABLEVIEW_LABEL";

   @RBEntry("�?設物件集檢視")
   @RBComment("Default Work Set View")
   public static final String PRIVATE_CONSTANT_247 = "WTWORKSET_TABLEVIEW_NAME";

   @RBEntry("�?設物件集�?�尋表檢視")
   @RBComment("Default Work Set Search Table View")
   public static final String PRIVATE_CONSTANT_248 = "WTWORKSET_TABLEVIEW_DESC";

   @RBEntry("物件集")
   @RBComment("Work Set")
   public static final String PRIVATE_CONSTANT_249 = "WTWORKSET_TABLEVIEW_LABEL";

   @RBEntry("�?設�?存檢視")
   @RBComment("Default Archive View")
   public static final String PRIVATE_CONSTANT_250 = "ARCHIVE_TABLEVIEW_NAME";

   @RBEntry("�?設�?存�?�尋表檢視")
   @RBComment("Default Archive Search Table View")
   public static final String PRIVATE_CONSTANT_251 = "ARCHIVE_TABLEVIEW_DESC";

   @RBEntry("�?存")
   @RBComment("Archive")
   public static final String PRIVATE_CONSTANT_252 = "ARCHIVE_TABLEVIEW_LABEL";

   @RBEntry("�?設變更通知檢視")
   @RBComment("Default Change Notice View")
   public static final String PRIVATE_CONSTANT_253 = "CHANGENOTICE_TABLEVIEW_NAME";

   @RBEntry("�?設變更通知�?�尋表檢視")
   @RBComment("Default Change Notice Search Table View")
   public static final String PRIVATE_CONSTANT_254 = "CHANGENOTICE_TABLEVIEW_DESC";

   @RBEntry("變更通知")
   @RBComment("Change Notice")
   public static final String PRIVATE_CONSTANT_255 = "CHANGENOTICE_TABLEVIEW_LABEL";

   @RBEntry("�?設變更請求檢視")
   @RBComment("Default Change Request View")
   public static final String PRIVATE_CONSTANT_256 = "CHANGEREQUEST_TABLEVIEW_NAME";

   @RBEntry("�?設變更請求�?�尋表檢視")
   @RBComment("Default Change Request Search Table View")
   public static final String PRIVATE_CONSTANT_257 = "CHANGEREQUEST_TABLEVIEW_DESC";

   @RBEntry("變更請求")
   @RBComment("Change Request")
   public static final String PRIVATE_CONSTANT_258 = "CHANGEREQUEST_TABLEVIEW_LABEL";

   @RBEntry("�?設變更指令檢視")
   @RBComment("Default Change Directive View")
   public static final String PRIVATE_CONSTANT_259 = "CHANGEDIRECTIVE_TABLEVIEW_NAME";

   @RBEntry("�?設變更指令�?�尋表檢視")
   @RBComment("Default Change Directive Search Table View")
   public static final String PRIVATE_CONSTANT_260 = "CHANGEDIRECTIVE_TABLEVIEW_DESC";

   @RBEntry("變更指令")
   @RBComment("Change Directive")
   public static final String PRIVATE_CONSTANT_261 = "CHANGEDIRECTIVE_TABLEVIEW_LABEL";

   @RBEntry("�?設�?題報告檢視")
   @RBComment("Default Problem Report View")
   public static final String PRIVATE_CONSTANT_262 = "WTCHANGEISSUE_TABLEVIEW_NAME";

   @RBEntry("�?設�?題報告�?�尋表檢視")
   @RBComment("Default Problem Report Search Table View")
   public static final String PRIVATE_CONSTANT_263 = "WTCHANGEISSUE_TABLEVIEW_DESC";

   @RBEntry("�?題報告")
   @RBComment("Problem Report")
   public static final String PRIVATE_CONSTANT_264 = "WTCHANGEISSUE_TABLEVIEW_LABEL";

   @RBEntry("�?設�?�傳�?作業檢視")
   @RBComment("Default Deliverable View")
   public static final String PRIVATE_CONSTANT_265 = "DELIVERABLE_TABLEVIEW_NAME";

   @RBEntry("�?設�?�傳�?作業�?�尋表檢視")
   @RBComment("Default Deliverable Search Table View")
   public static final String PRIVATE_CONSTANT_266 = "DELIVERABLE_TABLEVIEW_DESC";

   @RBEntry("�?�傳�?作業")
   @RBComment("Deliverable")
   public static final String PRIVATE_CONSTANT_267 = "DELIVERABLE_TABLEVIEW_LABEL";

   @RBEntry("�?設製造商檢視")
   @RBComment("Default Manufacturer View")
   public static final String PRIVATE_CONSTANT_268 = "MANUFACTURER_TABLEVIEW_NAME";

   @RBEntry("�?設製造商�?�尋表檢視")
   @RBComment("Default Manufacturer Search Table View")
   public static final String PRIVATE_CONSTANT_269 = "MANUFACTURER_TABLEVIEW_DESC";

   @RBEntry("製造商")
   @RBComment("Manufacturer")
   public static final String PRIVATE_CONSTANT_270 = "MANUFACTURER_TABLEVIEW_LABEL";

   @RBEntry("�?設組織檢視")
   @RBComment("Default Organization View")
   public static final String PRIVATE_CONSTANT_271 = "ORGNIZATION_TABLEVIEW_NAME";

   @RBEntry("�?設組織�?�尋表檢視")
   @RBComment("Default Organization Search Table View")
   public static final String PRIVATE_CONSTANT_272 = "ORGNIZATION_TABLEVIEW_DESC";

   @RBEntry("組織")
   @RBComment("Organization")
   public static final String PRIVATE_CONSTANT_273 = "ORGNIZATION_TABLEVIEW_LABEL";

   @RBEntry("�?設專案檢視")
   @RBComment("Default Project View")
   public static final String PRIVATE_CONSTANT_274 = "PROJECT2_TABLEVIEW_NAME";

   @RBEntry("�?設專案�?�尋表檢視")
   @RBComment("Default Project Search Table View")
   public static final String PRIVATE_CONSTANT_275 = "PROJECT2_TABLEVIEW_DESC";

   @RBEntry("專案")
   @RBComment("Project")
   public static final String PRIVATE_CONSTANT_276 = "PROJECT2_TABLEVIEW_LABEL";

   @RBEntry("�?設零件組態檢視")
   @RBComment("Default Part Configuration View")
   public static final String PRIVATE_CONSTANT_277 = "PARTCONFIGURATION_TABLEVIEW_NAME";

   @RBEntry("�?設零件組態�?�尋表檢視")
   @RBComment("Default Part Configuration Search Table View")
   public static final String PRIVATE_CONSTANT_278 = "PARTCONFIGURATION_TABLEVIEW_DESC";

   @RBEntry("零件組態")
   @RBComment("Part Configuration")
   public static final String PRIVATE_CONSTANT_279 = "PARTCONFIGURATION_TABLEVIEW_LABEL";

   @RBEntry("�?設零件實例檢視")
   @RBComment("Default Part Instance View")
   public static final String PRIVATE_CONSTANT_280 = "PARTINSTANCE_TABLEVIEW_NAME";

   @RBEntry("�?設零件實例�?�尋表檢視")
   @RBComment("Default Part Instance Search Table View")
   public static final String PRIVATE_CONSTANT_281 = "PARTINSTANCE_TABLEVIEW_DESC";

   @RBEntry("零件實例")
   @RBComment("Part Instance")
   public static final String PRIVATE_CONSTANT_282 = "PARTINSTANCE_TABLEVIEW_LABEL";

   @RBEntry("�?設廠商檢視")
   @RBComment("Default Vendor View")
   public static final String PRIVATE_CONSTANT_283 = "VENDOR_TABLEVIEW_NAME";

   @RBEntry("�?設廠商�?�尋表檢視")
   @RBComment("Default Vendor Search Table View")
   public static final String PRIVATE_CONSTANT_284 = "VENDOR_TABLEVIEW_DESC";

   @RBEntry("廠商")
   @RBComment("Vendor")
   public static final String PRIVATE_CONSTANT_285 = "VENDOR_TABLEVIEW_LABEL";

   @RBEntry("�?設所管�?�的物件集檢視")
   @RBComment("Default Managed Collection View")
   public static final String PRIVATE_CONSTANT_286 = "MANAGEDCOLLECTION_TABLEVIEW_NAME";

   @RBEntry("�?設所管�?�的物件集�?�尋表檢視")
   @RBComment("Default Managed Collection Search Table View")
   public static final String PRIVATE_CONSTANT_287 = "MANAGEDCOLLECTION_TABLEVIEW_DESC";

   @RBEntry("所管�?�的物件集")
   @RBComment("Managed Collection")
   public static final String PRIVATE_CONSTANT_288 = "MANAGEDCOLLECTION_TABLEVIEW_LABEL";

   @RBEntry("修改者")
   @RBComment("Modified By")
   public static final String MC_MODIFIED_BY = "MC_MODIFIED_BY";

   @RBEntry("�?設�?�?檢視")
   @RBComment("Default Package View")
   public static final String PRIVATE_CONSTANT_289 = "WORKPACKAGE_TABLEVIEW_NAME";

   @RBEntry("�?設�?�?�?�尋表檢視")
   @RBComment("Default Package Search Table View")
   public static final String PRIVATE_CONSTANT_290 = "WORKPACKAGE_TABLEVIEW_DESC";

   @RBEntry("�?�?")
   @RBComment("Package")
   public static final String PRIVATE_CONSTANT_291 = "WORKPACKAGE_TABLEVIEW_LABEL";

   /** The Constant LOCKED_ATTR_TABLE_LABEL. */
   @RBEntry("鎖定狀�?")
   public static final String LOCKED_ATTR_TABLE_LABEL = "LOCKED_ATTR_TABLE_LABEL";

   @RBEntry("�?設零件請求檢視")
   @RBComment("Default Part Request View")
   public static final String PRIVATE_CONSTANT_292 = "WTPARTREQUEST_TABLEVIEW_NAME";

   @RBEntry("�?設零件請求�?�尋表檢視")
   @RBComment("Default Part Request Search Table View")
   public static final String PRIVATE_CONSTANT_293 = "WTPARTREQUEST_TABLEVIEW_DESC";

   @RBEntry("零件請求")
   @RBComment("Part Request")
   public static final String PRIVATE_CONSTANT_294 = "WTPARTREQUEST_TABLEVIEW_LABEL";

   @RBEntry("�?設變動檢視")
   @RBComment("Default Variance View")
   public static final String PRIVATE_CONSTANT_295 = "WTVARIANCE_TABLEVIEW_NAME";

   @RBEntry("�?設變動�?�尋表檢視")
   @RBComment("Default Variance Search Table View")
   public static final String PRIVATE_CONSTANT_296 = "WTVARIANCE_TABLEVIEW_DESC";

   @RBEntry("變動")
   @RBComment("Variance")
   public static final String PRIVATE_CONSTANT_297 = "WTVARIANCE_TABLEVIEW_LABEL";

   @RBEntry("�?設變體�?格檢視")
   @RBComment("Default Variant Spec View")
   public static final String PRIVATE_CONSTANT_298 = "VARIANTSPEC_TABLEVIEW_NAME";

   @RBEntry("�?設變體�?格�?�尋表檢視")
   @RBComment("Default Variant Spec Search Table View")
   public static final String PRIVATE_CONSTANT_299 = "VARIANTSPEC_TABLEVIEW_DESC";

   @RBEntry("變體�?格")
   @RBComment("Variant Spec")
   public static final String PRIVATE_CONSTANT_300 = "VARIANTSPEC_TABLEVIEW_LABEL";

   @RBEntry("�?設使用者檢視")
   @RBComment("Default User View")
   public static final String PRIVATE_CONSTANT_301 = "WTUSER_TABLEVIEW_NAME";

   @RBEntry("�?設使用者�?�尋表檢視")
   @RBComment("Default User Search Table View")
   public static final String PRIVATE_CONSTANT_302 = "WTUSER_TABLEVIEW_DESC";

   @RBEntry("使用者")
   @RBComment("User")
   public static final String PRIVATE_CONSTANT_303 = "WTUSER_TABLEVIEW_LABEL";

   @RBEntry("�?設行動項目檢視")
   @RBComment("Default Action Item View")
   public static final String PRIVATE_CONSTANT_304 = "DISCRETEACTIONITEM_TABLEVIEW_NAME";

   @RBEntry("�?設行動項目�?�尋表檢視")
   @RBComment("Default Action Item Search Table View")
   public static final String PRIVATE_CONSTANT_305 = "DISCRETEACTIONITEM_TABLEVIEW_DESC";

   @RBEntry("行動項目")
   @RBComment("Action Item")
   public static final String PRIVATE_CONSTANT_306 = "DISCRETEACTIONITEM_TABLEVIEW_LABEL";

   @RBEntry("�?設 EPM 文件主檢視")
   @RBComment("Default EPM Document Master View")
   public static final String PRIVATE_CONSTANT_307 = "EPMDOCUMENTMASTER_TABLEVIEW_NAME";

   @RBEntry("�?設 EPM 文件主�?�尋表檢視")
   @RBComment("Default EPM Document Master Search Table View")
   public static final String PRIVATE_CONSTANT_308 = "EPMDOCUMENTMASTER_TABLEVIEW_DESC";

   @RBEntry("EPM  文件主物件")
   @RBComment("EPM Document Master")
   public static final String PRIVATE_CONSTANT_309 = "EPMDOCUMENTMASTER_TABLEVIEW_LABEL";

   @RBEntry("�?設文件主檢視")
   @RBComment("Default Document Master View")
   public static final String PRIVATE_CONSTANT_310 = "WTDOCUMENTMASTER_TABLEVIEW_NAME";

   @RBEntry("�?設文件主�?�尋表檢視")
   @RBComment("Default Document Master Search Table View")
   public static final String PRIVATE_CONSTANT_311 = "WTDOCUMENTMASTER_TABLEVIEW_DESC";

   @RBEntry("文件主物件")
   @RBComment("Document Master")
   public static final String PRIVATE_CONSTANT_312 = "WTDOCUMENTMASTER_TABLEVIEW_LABEL";

   @RBEntry("�?設零件主檢視")
   @RBComment("Default Part Master View")
   public static final String PRIVATE_CONSTANT_313 = "WTPARTMASTER_TABLEVIEW_NAME";

   @RBEntry("�?設零件主�?�尋表檢視")
   @RBComment("Default Part Master Search Table View")
   public static final String PRIVATE_CONSTANT_314 = "WTPARTMASTER_TABLEVIEW_DESC";

   @RBEntry("零件主物件")
   @RBComment("Part Master")
   public static final String PRIVATE_CONSTANT_315 = "WTPARTMASTER_TABLEVIEW_LABEL";

   @RBEntry("�?設格�?檢視")
   @RBComment("Default Format View")
   public static final String PRIVATE_CONSTANT_316 = "FORMAT_TABLEVIEW_NAME";

   @RBEntry("�?設格�?�?�尋表檢視")
   @RBComment("Default Format Search Table View")
   public static final String PRIVATE_CONSTANT_317 = "FORMAT_TABLEVIEW_DESC";

   @RBEntry("格�?")
   @RBComment("Format")
   public static final String PRIVATE_CONSTANT_318 = "FORMAT_TABLEVIEW_LABEL";

   @RBEntry("�?設群組檢視")
   @RBComment("Default Group View")
   public static final String PRIVATE_CONSTANT_319 = "GROUP_TABLEVIEW_NAME";

   @RBEntry("�?設群組�?�尋表檢視")
   @RBComment("Default Group Search Table View")
   public static final String PRIVATE_CONSTANT_320 = "GROUP_TABLEVIEW_DESC";

   @RBEntry("群組")
   @RBComment("Group")
   public static final String PRIVATE_CONSTANT_321 = "GROUP_TABLEVIEW_LABEL";

   @RBEntry("�?設組織檢視")
   @RBComment("Default Organization View")
   public static final String PRIVATE_CONSTANT_322 = "ORG_TABLEVIEW_NAME";

   @RBEntry("�?設組織�?�尋表檢視")
   @RBComment("Default Organization Search Table View")
   public static final String PRIVATE_CONSTANT_323 = "ORG_TABLEVIEW_DESC";

   @RBEntry("組織")
   @RBComment("Organization")
   public static final String PRIVATE_CONSTANT_324 = "ORG_TABLEVIEW_LABEL";

   @RBEntry("�?設�?�考附件檢視")
   @RBComment("Default Reference Attachment View")
   public static final String PRIVATE_CONSTANT_325 = "IMPORTEDBOOKMARK_TABLEVIEW_NAME";

   @RBEntry("�?設�?�考附件�?�尋表檢視")
   @RBComment("Default Reference Attachment Search Table View")
   public static final String PRIVATE_CONSTANT_326 = "IMPORTEDBOOKMARK_TABLEVIEW_DESC";

   @RBEntry("�?�考附件")
   @RBComment("Reference Attachment")
   public static final String PRIVATE_CONSTANT_327 = "IMPORTEDBOOKMARK_TABLEVIEW_LABEL";

   @RBEntry("�?設�?專案/方案檢視")
   @RBComment("Default Sub Project/Program View")
   public static final String PRIVATE_CONSTANT_328 = "PROJECTPROXY_TABLEVIEW_NAME";

   @RBEntry("�?設�?專案/方案�?�尋表檢視")
   @RBComment("Default Sub Project/Program Search Table View")
   public static final String PRIVATE_CONSTANT_329 = "PROJECTPROXY_TABLEVIEW_DESC";

   @RBEntry("�?專案/方案")
   @RBComment("Sub Project/Program")
   public static final String PRIVATE_CONSTANT_330 = "PROJECTPROXY_TABLEVIEW_LABEL";

   @RBEntry("�?設檔案櫃檢視")
   @RBComment("Default Cabinet View")
   public static final String PRIVATE_CONSTANT_331 = "CABINET_TABLEVIEW_NAME";

   @RBEntry("�?設檔案櫃�?�尋表檢視")
   @RBComment("Default Cabinet Search Table View")
   public static final String PRIVATE_CONSTANT_332 = "CABINET_TABLEVIEW_DESC";

   @RBEntry("檔案櫃")
   @RBComment("Cabinet")
   public static final String PRIVATE_CONSTANT_333 = "CABINET_TABLEVIEW_LABEL";

   @RBEntry("�?設管�?�基準線檢視")
   @RBComment("Default Managed Baseline View")
   public static final String PRIVATE_CONSTANT_334 = "MANAGEDBASELINE_TABLEVIEW_NAME";

   @RBEntry("�?設管�?�基準線�?�尋表格檢視")
   @RBComment("Default Managed Baseline Search Table View")
   public static final String PRIVATE_CONSTANT_335 = "MANAGEDBASELINE_TABLEVIEW_DESC";

   @RBEntry("管�?�基準線")
   @RBComment("Managed Baseline")
   public static final String PRIVATE_CONSTANT_336 = "MANAGEDBASELINE_TABLEVIEW_LABEL";

   @RBEntry("�?設製程計劃檢視")
   @RBComment("Default Process Plan View")
   public static final String PRIVATE_CONSTANT_337 = "MPMPROCESSPLAN_TABLEVIEW_NAME";

   @RBEntry("�?設製程計劃�?�尋表檢視")
   @RBComment("Default Process Plan Search Table View")
   public static final String PRIVATE_CONSTANT_338 = "MPMPROCESSPLAN_TABLEVIEW_DESC";

   @RBEntry("製程計劃")
   @RBComment("Process Plan")
   public static final String PRIVATE_CONSTANT_339 = "MPMPROCESSPLAN_TABLEVIEW_LABEL";

   @RBEntry("�?設工�?檢視")
   @RBComment("Default Sequence View")
   public static final String PRIVATE_CONSTANT_340 = "MPMSEQUENCE_TABLEVIEW_NAME";

   @RBEntry("�?設工�?�?�尋表檢視")
   @RBComment("Default Sequence Search Table View")
   public static final String PRIVATE_CONSTANT_341 = "MPMSEQUENCE_TABLEVIEW_DESC";

   @RBEntry("工�?")
   @RBComment("Sequence")
   public static final String PRIVATE_CONSTANT_342 = "MPMSEQUENCE_TABLEVIEW_LABEL";

   @RBEntry("�?設作業檢視")
   @RBComment("Default Operation View")
   public static final String PRIVATE_CONSTANT_343 = "MPMOPERATION_TABLEVIEW_NAME";

   @RBEntry("�?設作業�?�尋表檢視")
   @RBComment("Default Operation Search Table View")
   public static final String PRIVATE_CONSTANT_344 = "MPMOPERATION_TABLEVIEW_DESC";

   @RBEntry("作業")
   @RBComment("Operation")
   public static final String PRIVATE_CONSTANT_345 = "MPMOPERATION_TABLEVIEW_LABEL";

   @RBEntry("�?設製造標準群組檢視")
   @RBComment("Default Manufacturing Standard Group View")
   public static final String PRIVATE_CONSTANT_346 = "MPMMFGSTANDARDGROUP_TABLEVIEW_NAME";

   @RBEntry("�?設製造標準群組�?�尋表檢視")
   @RBComment("Default Manufacturing Standard Group Search Table View")
   public static final String PRIVATE_CONSTANT_347 = "MPMMFGSTANDARDGROUP_TABLEVIEW_DESC";

   @RBEntry("製造標準群組")
   @RBComment("Manufacturing Standard Group")
   public static final String PRIVATE_CONSTANT_348 = "MPMMFGSTANDARDGROUP_TABLEVIEW_LABEL";

   @RBEntry("�?設製造�?程檢視")
   @RBComment("Default Manufacturing Process View")
   public static final String PRIVATE_CONSTANT_349 = "MPMMFGPROCESS_TABLEVIEW_NAME";

   @RBEntry("�?設製造�?程�?�尋表檢視")
   @RBComment("Default Manufacturing Process Search Table View")
   public static final String PRIVATE_CONSTANT_350 = "MPMMFGPROCESS_TABLEVIEW_DESC";

   @RBEntry("製造�?程")
   @RBComment("Manufacturing Process")
   public static final String PRIVATE_CONSTANT_351 = "MPMMFGPROCESS_TABLEVIEW_LABEL";

   @RBEntry("�?設資�?檢視")
   @RBComment("Default Resource View")
   public static final String PRIVATE_CONSTANT_352 = "MPMRESOURCE_TABLEVIEW_NAME";

   @RBEntry("�?設資�?�?�尋表檢視")
   @RBComment("Default Resource Search Table View")
   public static final String PRIVATE_CONSTANT_353 = "MPMRESOURCE_TABLEVIEW_DESC";

   @RBEntry("資�?")
   @RBComment("Resource")
   public static final String PRIVATE_CONSTANT_354 = "MPMRESOURCE_TABLEVIEW_LABEL";

   @RBEntry("�?設工廠檢視")
   @RBComment("Default Plant View")
   public static final String PRIVATE_CONSTANT_355 = "MPMPLANT_TABLEVIEW_NAME";

   @RBEntry("�?設工廠�?�尋表格檢視")
   @RBComment("Default Plant Search Table View")
   public static final String PRIVATE_CONSTANT_356 = "MPMPLANT_TABLEVIEW_DESC";

   @RBEntry("工廠")
   @RBComment("Plant")
   public static final String PRIVATE_CONSTANT_357 = "MPMPLANT_TABLEVIEW_LABEL";

   @RBEntry("�?設 Resource 群組檢視")
   @RBComment("Default Resource Group View")
   public static final String PRIVATE_CONSTANT_358 = "MPMRESOURCEGROUP_TABLEVIEW_NAME";

   @RBEntry("�?設資�?群組�?�尋表檢視")
   @RBComment("Default Resource Group Search Table View")
   public static final String PRIVATE_CONSTANT_359 = "MPMRESOURCEGROUP_TABLEVIEW_DESC";

   @RBEntry("資�?群組")
   @RBComment("Resource Group")
   public static final String PRIVATE_CONSTANT_360 = "MPMRESOURCEGROUP_TABLEVIEW_LABEL";

   @RBEntry("�?設工作項目檢視")
   @RBComment("Default Work Item View")
   public static final String PRIVATE_CONSTANT_361 = "WORKITEM_TABLEVIEW_NAME";

   @RBEntry("�?設工作項目�?�尋表檢視")
   @RBComment("Default Work Item Search Table View")
   public static final String PRIVATE_CONSTANT_362 = "WORKITEM_TABLEVIEW_DESC";

   @RBEntry("工作項目")
   @RBComment("Work Item")
   public static final String PRIVATE_CONSTANT_363 = "WORKITEM_TABLEVIEW_LABEL";

   @RBEntry("�?設報告檢視")
   @RBComment("Default Report View")
   public static final String PRIVATE_CONSTANT_364 = "REPORT_TABLEVIEW_NAME";

   @RBEntry("�?設報告�?�尋表檢視")
   @RBComment("Default Report Search Table View")
   public static final String PRIVATE_CONSTANT_365 = "REPORT_TABLEVIEW_DESC";

   @RBEntry("報告")
   @RBComment("Report")
   public static final String PRIVATE_CONSTANT_366 = "REPORT_TABLEVIEW_LABEL";

   @RBEntry("�?設已存�?�尋檢視")
   @RBComment("Default Saved Search View")
   public static final String PRIVATE_CONSTANT_367 = "SAVEDQUERY_TABLEVIEW_NAME";

   @RBEntry("�?設已存�?�尋表檢視")
   @RBComment("Default Saved Search Table View")
   public static final String PRIVATE_CONSTANT_368 = "SAVEDQUERY_TABLEVIEW_DESC";

   @RBEntry("�?設已存�?�尋挑�?�器檢視")
   @RBComment("Default Saved Search Picker View")
   public static final String PRIVATE_CONSTANT_369 = "SAVEDQUERY_PICKER_TABLEVIEW_NAME";

   @RBEntry("�?設已存�?�尋挑�?�器表格檢視")
   @RBComment("Default Saved Search Picker Table View")
   public static final String PRIVATE_CONSTANT_370 = "SAVEDQUERY_PICKER_TABLEVIEW_DESC";

   @RBEntry("已存�?�尋")
   @RBComment("Saved Search")
   public static final String PRIVATE_CONSTANT_371 = "SAVEDQUERY_TABLEVIEW_LABEL";

   @RBEntry("�?設")
   @RBComment("Default View")
   public static final String PRIVATE_CONSTANT_372 = "PERSISTABLE_TABLEVIEW_NAME";

   @RBEntry("�?設表檢視")
   @RBComment("Default Table View")
   public static final String PRIVATE_CONSTANT_373 = "PERSISTABLE_TABLEVIEW_DESC";

   @RBEntry("簡易�?�尋")
   @RBComment("Simple Search")
   public static final String PRIVATE_CONSTANT_374 = "PERSISTABLE_TABLEVIEW_LABEL";

   @RBEntry("�?設討論�?�張貼檢視")
   @RBComment("Default Discussion Posting View")
   public static final String PRIVATE_CONSTANT_375 = "DISCUSSIONPOSTING_TABLEVIEW_NAME";

   @RBEntry("�?設討論�?�張貼�?�尋表檢視")
   @RBComment("Default Discussion Posting Search Table View")
   public static final String PRIVATE_CONSTANT_376 = "DISCUSSIONPOSTING_TABLEVIEW_DESC";

   @RBEntry("討論�?�張貼")
   @RBComment("Discussion Posting")
   public static final String PRIVATE_CONSTANT_377 = "DISCUSSIONPOSTING_TABLEVIEW_LABEL";

   @RBEntry("�?設會議檢視")
   @RBComment("Default Meeting View")
   public static final String PRIVATE_CONSTANT_378 = "MEETING_TABLEVIEW_NAME";

   @RBEntry("�?設會議�?�尋表檢視")
   @RBComment("Default Meeting Search Table View")
   public static final String PRIVATE_CONSTANT_379 = "MEETING_TABLEVIEW_DESC";

   @RBEntry("會議")
   @RBComment("Meeting")
   public static final String PRIVATE_CONSTANT_380 = "MEETING_TABLEVIEW_LABEL";

   /**
    * L10N CHANGE BEGIN: comment out duplicate resource id
    * PDMLINKPRODUCT_TABLEVIEW_NAME.comment=Default Product View
    * PDMLINKPRODUCT_TABLEVIEW_NAME.value=Default Product View
    * L10N CHANGE END
    * L10N CHANGE BEGIN: comment out duplicate resource id
    * PDMLINKPRODUCT_TABLEVIEW_DESC.comment=Default Product Search Table View
    * PDMLINKPRODUCT_TABLEVIEW_DESC.value=Default Product Search Table View
    * L10N CHANGE END
    * L10N CHANGE BEGIN: comment out duplicate resource id
    * PDMLINKPRODUCT_TABLEVIEW_LABEL.comment=Product
    * PDMLINKPRODUCT_TABLEVIEW_LABEL.value=Product
    * L10N CHANGE END
    **/
   @RBEntry("�?設報告範本檢視")
   @RBComment("Default Report Template View")
   public static final String PRIVATE_CONSTANT_381 = "REPORTTEMPLATE_TABLEVIEW_NAME";

   @RBEntry("�?設報告範本�?�尋表檢視")
   @RBComment("Default Report Template Search Table View")
   public static final String PRIVATE_CONSTANT_382 = "REPORTTEMPLATE_TABLEVIEW_DESC";

   @RBEntry("報告範本")
   @RBComment("Report Template")
   public static final String PRIVATE_CONSTANT_383 = "REPORTTEMPLATE_TABLEVIEW_LABEL";

   @RBEntry("�?設工作�?程檢視")
   @RBComment("Default Workflow Process View")
   public static final String PRIVATE_CONSTANT_384 = "WORKFLOWPROCESS_TABLEVIEW_NAME";

   @RBEntry("�?設工作�?程�?�尋表檢視")
   @RBComment("Default Workflow Process Search Table View")
   public static final String PRIVATE_CONSTANT_385 = "WORKFLOWPROCESS_TABLEVIEW_DESC";

   @RBEntry("工作�?程")
   @RBComment("Workflow Process")
   public static final String PRIVATE_CONSTANT_386 = "WORKFLOWPROCESS_TABLEVIEW_LABEL";

   @RBEntry("�?設物件庫檢視")
   @RBComment("Default Library View")
   public static final String PRIVATE_CONSTANT_387 = "WTLIBRARY_TABLEVIEW_NAME";

   @RBEntry("�?設物件庫�?�尋表檢視")
   @RBComment("Default Library Search Table View")
   public static final String PRIVATE_CONSTANT_388 = "WTLIBRARY_TABLEVIEW_DESC";

   @RBEntry("物件庫")
   @RBComment("Library")
   public static final String PRIVATE_CONSTANT_389 = "WTLIBRARY_TABLEVIEW_LABEL";

   @RBEntry("�?設匯入工作檢視")
   @RBComment("Default Import Job View")
   public static final String PRIVATE_CONSTANT_390 = "IMPORTJOB_TABLEVIEW_NAME";

   @RBEntry("�?設匯入工作�?�尋表檢視")
   @RBComment("Default Import Job Search Table View")
   public static final String PRIVATE_CONSTANT_391 = "IMPORTJOB_TABLEVIEW_DESC";

   @RBEntry("匯入工作")
   @RBComment("Import Job")
   public static final String PRIVATE_CONSTANT_392 = "IMPORTJOB_TABLEVIEW_LABEL";

   @RBEntry("�?設里程碑檢視")
   @RBComment("Default Milestone View")
   public static final String PRIVATE_CONSTANT_393 = "MILESTONE_TABLEVIEW_NAME";

   @RBEntry("�?設里程碑�?�尋表檢視")
   @RBComment("Default Milestone Search Table View")
   public static final String PRIVATE_CONSTANT_394 = "MILESTONE_TABLEVIEW_DESC";

   @RBEntry("里程碑")
   @RBComment("Milestone")
   public static final String PRIVATE_CONSTANT_395 = "MILESTONE_TABLEVIEW_LABEL";

   @RBEntry("�?設專案資�?檢視")
   @RBComment("Default Project Resource View")
   public static final String PRIVATE_CONSTANT_396 = "PROJECTRESOURCE_TABLEVIEW_NAME";

   @RBEntry("�?設專案資�?�?�尋表檢視")
   @RBComment("Default Project Resource Search Table View")
   public static final String PRIVATE_CONSTANT_397 = "PROJECTRESOURCE_TABLEVIEW_DESC";

   @RBEntry("專案資�?")
   @RBComment("Project Resource")
   public static final String PRIVATE_CONSTANT_398 = "PROJECTRESOURCE_TABLEVIEW_LABEL";

   @RBEntry("�?設專案活動檢視")
   @RBComment("Default Project Activity View")
   public static final String PRIVATE_CONSTANT_399 = "PROJECTACTIVITY_TABLEVIEW_NAME";

   @RBEntry("�?設專案動作�?�尋表檢視")
   @RBComment("Default Project Activity Search Table View")
   public static final String PRIVATE_CONSTANT_400 = "PROJECTACTIVITY_TABLEVIEW_DESC";

   @RBEntry("專案活動")
   @RBComment("Project Activity")
   public static final String PRIVATE_CONSTANT_401 = "PROJECTACTIVITY_TABLEVIEW_LABEL";

   @RBEntry("�?設推進請求檢視")
   @RBComment("Default Promotion Request View")
   public static final String PRIVATE_CONSTANT_402 = "PROMOTIONNOTICE_TABLEVIEW_NAME";

   @RBEntry("�?設推進請求�?�尋表檢視")
   @RBComment("Default Promotion Request Search Table View")
   public static final String PRIVATE_CONSTANT_403 = "PROMOTIONNOTICE_TABLEVIEW_DESC";

   @RBEntry("推進請求")
   @RBComment("Promotion Request")
   public static final String PRIVATE_CONSTANT_404 = "PROMOTIONNOTICE_TABLEVIEW_LABEL";

   @RBEntry("�?設摘�?活動檢視")
   @RBComment("Default Summary Activity View")
   public static final String PRIVATE_CONSTANT_405 = "SUMMARYACTIVITY_TABLEVIEW_NAME";

   @RBEntry("�?設摘�?活動�?�尋表檢視")
   @RBComment("Default Summary Activity Search Table View")
   public static final String PRIVATE_CONSTANT_406 = "SUMMARYACTIVITY_TABLEVIEW_DESC";

   @RBEntry("摘�?活動")
   @RBComment("Summary Activity")
   public static final String PRIVATE_CONSTANT_407 = "SUMMARYACTIVITY_TABLEVIEW_LABEL";

   @RBEntry("�?設供應商檢視")
   @RBComment("Default Supplier View")
   public static final String PRIVATE_CONSTANT_408 = "SUPPLIER_TABLEVIEW_NAME";

   @RBEntry("�?設供應商�?�尋表檢視")
   @RBComment("Default Supplier Search Table View")
   public static final String PRIVATE_CONSTANT_409 = "SUPPLIER_TABLEVIEW_DESC";

   @RBEntry("供應商")
   @RBComment("Supplier")
   public static final String PRIVATE_CONSTANT_410 = "SUPPLIER_TABLEVIEW_LABEL";

   @RBEntry("�?設供應商零件檢視")
   @RBComment("Default Supplier Part View")
   public static final String PRIVATE_CONSTANT_411 = "SUPPLIERPART_TABLEVIEW_NAME";

   @RBEntry("�?設供應商零件�?�尋表檢視")
   @RBComment("Default Supplier Part Search Table View")
   public static final String PRIVATE_CONSTANT_412 = "SUPPLIERPART_TABLEVIEW_DESC";

   @RBEntry("供應商零件")
   @RBComment("Supplier Part")
   public static final String PRIVATE_CONSTANT_413 = "SUPPLIERPART_TABLEVIEW_LABEL";

   @RBEntry("�?設 ProductView")
   @RBComment("Default Product View")
   public static final String PRIVATE_CONSTANT_414 = "PDMLINKPRODUCT_TABLEVIEW_NAME";

   @RBEntry("�?設產�?�?�尋表檢視")
   @RBComment("Default Product Search Table View")
   public static final String PRIVATE_CONSTANT_415 = "PDMLINKPRODUCT_TABLEVIEW_DESC";

   @RBEntry("產�?")
   @RBComment("Product")
   public static final String PRIVATE_CONSTANT_416 = "PDMLINKPRODUCT_TABLEVIEW_LABEL";

   @RBEntry("�?設�?後關�?�檢視")
   @RBComment("Default Context View")
   public static final String PRIVATE_CONSTANT_417 = "CONTAINER_TABLEVIEW_NAME";

   @RBEntry("�?設�?後關�?��?�尋表檢視")
   @RBComment("Default Context Search Table View")
   public static final String PRIVATE_CONSTANT_418 = "CONTAINER_TABLEVIEW_DESC";

   @RBEntry("�?後關�?�")
   @RBComment("Context")
   public static final String PRIVATE_CONSTANT_419 = "CONTAINER_TABLEVIEW_LABEL";

   @RBEntry("是")
   @RBComment("Label for True")
   public static final String PRIVATE_CONSTANT_420 = "TRUE_LABEL";

   @RBEntry("�?�")
   @RBComment("Label for False")
   public static final String PRIVATE_CONSTANT_421 = "FALSE_LABEL";

   @RBEntry("無效的已存 Query XML 格�?")
   @RBComment("Invalid Saved Query XML Format")
   public static final String PRIVATE_CONSTANT_422 = "INVALID_SAVED_QUERY_FORMAT";

   @RBEntry("- �?��?� -")
   @RBComment("Label for No Selection")
   public static final String PRIVATE_CONSTANT_423 = "NO_SELECTION_LABEL";

   @RBEntry("將此�?�尋設定為全域�?�尋")
   @RBComment("Mark as Global Search")
   public static final String PRIVATE_CONSTANT_424 = "GLOBAL_SEARCH_SHOW";

   @RBEntry("覆寫�?�有已存�?�尋")
   @RBComment("Overwrite Existing Saved Search")
   public static final String PRIVATE_CONSTANT_425 = "OVERWRITE_EXISTING";

   @RBEntry("全域�?�尋範�?:")
   @RBComment("Set Scope of Global Search")
   public static final String PRIVATE_CONSTANT_426 = "SCOPE_OF_GLOBAL_SEARCH";

   @RBEntry("在網路內�?�尋")
   @RBComment("Label for search in network")
   public static final String PRIVATE_CONSTANT_427 = "SEARCH_IN_NETWORK_LABEL";

   @RBEntry("�?�尋相關物件")
   @RBComment("Label for search related to objects in a particular context")
   public static final String PRIVATE_CONSTANT_428 = "SEARCH_FOR_ITEMS_IN_CONTEXT_LABEL";

   @RBEntry("網路�?後關�?�:")
   @RBComment("Label for the property \"Search In:\" on the search page when the request comes from Program tab.")
   public static final String PRIVATE_CONSTANT_429 = "SEARCH_IN_NETWORK_CONTEXT";

   @RBEntry("�?�尋類型:")
   @RBComment("Label for the type property on the search page when the request comes from Program tab.")
   public static final String PRIVATE_CONSTANT_430 = "SEARCH_FOR_TYPE";

   @RBEntry("關係:")
   @RBComment("Label for the relationship property on the search page when the request comes from Program tab.")
   public static final String PRIVATE_CONSTANT_431 = "SEARCH_FOR_RELATIONSHIP";

   @RBEntry("檔案:")
   @RBComment("Select jar or zip to import")
   public static final String PRIVATE_CONSTANT_432 = "SELECT_FILE_IMPORT";

   @RBEntry("(.jar�?.zip)")
   @RBComment("File types allowed for Import Saved Query wizard")
   public static final String PRIVATE_CONSTANT_433 = "IMPORT_FILE_TYPES";

   @RBEntry("檔案必須為 .jar 或 .zip 類型。")
   @RBComment("Error message displayed when user tries to import a file other than a jar or zip file.")
   public static final String PRIVATE_CONSTANT_434 = "EXPORT_IMPORT_FILE_ERROR";

   @RBEntry("解決�?��?新定義�?�?")
   @RBComment("Label for the resolve overridable conflicts checkbox")
   public static final String PRIVATE_CONSTANT_435 = "RESOLVE_OVERRIDABLE_CONFLICTS";

   @RBEntry("檔案:")
   @RBComment("File name into which the savedquery should be exported")
   public static final String PRIVATE_CONSTANT_436 = "SELECT_FILE_EXPORT";

   @RBEntry("(�??供檔案路徑+檔�??，後�?�加上 .jar 或 .zip 副檔�??)")
   @RBComment("File types allowed for Export Saved Query wizard")
   public static final String PRIVATE_CONSTANT_437 = "EXPORT_FILE_TYPES";

   @RBEntry("詳細記錄檔")
   @RBComment("Label for detailed log link")
   public static final String PRIVATE_CONSTANT_438 = "EXPORT_IMPORT_DETAILED_LOG";

   @RBEntry("無法刪除下列所�?�項目: {0}")
   @RBComment("Message showing list of queries couldn't be deleted")
   public static final String PRIVATE_CONSTANT_439 = "DELETE_QUERY_MESSAGE";

   @RBEntry("�?設資料夾�?�尋檢視")
   @RBComment("Default Folder Search View")
   public static final String PRIVATE_CONSTANT_440 = "FOLDER_TABLEVIEW_NAME";

   @RBEntry("�?設資料夾�?�尋表")
   @RBComment("Default Folder Search Table")
   public static final String PRIVATE_CONSTANT_441 = "FOLDER_TABLEVIEW_DESC";

   @RBEntry("資料夾")
   @RBComment("Folder")
   public static final String PRIVATE_CONSTANT_442 = "FOLDER_TABLEVIEW_LABEL";

   @RBEntry("注�?: 必填欄�?無法移除\n\n下列必填欄�?無法移除:\n{0}")
   @RBComment("Message for alert when one tries to remove criteria which is marked required.")
   public static final String PRIVATE_CONSTANT_443 = "REMOVE_QUERYBUILDER_ROW";

   @RBEntry("注�?: �?�失必填資訊 \n\n{0} 是必填欄�?。\n您必須�?�?全部附星號 (*) 的必填欄�?指定有效資訊。")
   @RBComment("Message for alert if the required attributes are not filled.")
   public static final String REQ_INFO_MISSING = "REQ_INFO_MISSING";

   @RBEntry("注�?: �?�失必填資訊。\n\n 您必須�?�?全部附星號 (*) 的必填欄�?指定有效資訊。")
   public static final String SAVED_SEARCH_NAME_MISSING = "SAVED_SEARCH_NAME_MISSING";

   @RBEntry("檔案�??稱")
   @RBComment("CADName")
   public static final String PRIVATE_CONSTANT_444 = "CADNAME";

   @RBEntry("改�?�尋:")
   @RBComment("The query suggestion message.")
   public static final String QUERY_SUGGESTION_MESSAGE = "QUERY_SUGGESTION_MESSAGE";

   @RBEntry("�?有者")
   @RBComment("Owner")
   public static final String PRIVATE_CONSTANT_445 = "OWNER_LABEL";

   @RBEntry("出庫者")
   @RBComment("Checked Out By")
   public static final String PRIVATE_CONSTANT_446 = "CHECKED_OUT_BY";

   @RBEntry("更新者")
   @RBComment("Updated By")
   public static final String PRIVATE_CONSTANT_447 = "UPDATED_BY";

   @RBEntry("註記文字")
   @RBComment("Note Text")
   public static final String PRIVATE_CONSTANT_448 = "PTC_NOTE_TEXT";

   @RBEntry("�?於")
   @RBComment("Less than")
   public static final String PRIVATE_CONSTANT_449 = "OP_LESS";

   @RBEntry("�?於等於")
   @RBComment("Less than equal to")
   public static final String PRIVATE_CONSTANT_450 = "OP_LESS_THAN_EQUAL_TO";

   @RBEntry("大於")
   @RBComment("Greater than")
   public static final String PRIVATE_CONSTANT_451 = "OP_GREATOR";

   @RBEntry("大於等於")
   @RBComment("Greater than equal to")
   public static final String PRIVATE_CONSTANT_452 = "OP_GREATOR_THAN_EQUAL_TO";

   @RBEntry("角色�??稱")
   @RBComment("Role Name")
   public static final String PRIVATE_CONSTANT_453 = "ROLE_NAME";

   @RBEntry("角色")
   @RBComment("Role")
   public static final String PRIVATE_CONSTANT_454 = "ROLE";

   @RBEntry("進階�?�尋")
   @RBComment("Refine search")
   public static final String PRIVATE_CONSTANT_455 = "REFINE_SEARCH";

   @RBEntry("尋找物件")
   @RBComment("Item Picker Title")
   public static final String PRIVATE_CONSTANT_456 = "ITEM_PICKER_TITLE";

   @RBEntry("物件挑�?�器")
   @RBComment("Item Picker Label")
   public static final String PRIVATE_CONSTANT_457 = "ITEM_PICKER_LABEL";

   @RBEntry("尋找�?後關�?�")
   @RBComment("Context Picker Title")
   public static final String PRIVATE_CONSTANT_458 = "CONTEXTS_PICKER_TITLE";

   @RBEntry("�?後關�?�挑�?�器")
   @RBComment("Context Picker Label")
   public static final String PRIVATE_CONSTANT_459 = "CONTEXTS_PICKER_LABEL";

   @RBEntry("尋找")
   @RBComment("Find")
   public static final String PRIVATE_CONSTANT_460 = "FIND_PICKER_LABEL";

   @RBEntry("檢視")
   @RBComment("View")
   public static final String PRIVATE_CONSTANT_461 = "VIEW_PICKER_LABEL";

   @RBEntry("�?設 Sourcing �?後關�?��?�尋檢視")
   @RBComment("Default Sourcing Context Search View")
   public static final String PRIVATE_CONSTANT_462 = "AXLCONTEXT_TABLEVIEW_NAME";

   @RBEntry("�?設 Sourcing �?後關�?��?�尋表")
   @RBComment("Default Sourcing Context Search Table")
   public static final String PRIVATE_CONSTANT_463 = "AXLCONTEXT_TABLEVIEW_DESC";

   @RBEntry("Sourcing �?後關�?�")
   @RBComment("Sourcing Context")
   public static final String PRIVATE_CONSTANT_464 = "AXLCONTEXT_TABLEVIEW_LABEL";

   @RBEntry("�?設附註檢視")
   @RBComment("Default Note View")
   public static final String PRIVATE_CONSTANT_465 = "NOTE_TABLEVIEW_NAME";

   @RBEntry("�?設附註�?�尋表")
   @RBComment("Default Note Search Table")
   public static final String PRIVATE_CONSTANT_466 = "NOTE_TABLEVIEW_DESC";

   @RBEntry("已匯出�?�尋�?果")
   @RBComment("Exported search results header")
   public static final String PRIVATE_CONSTANT_467 = "EXPORTED_SEARCH_RESULTS";

   @RBEntry("註記")
   @RBComment("Note")
   public static final String PRIVATE_CONSTANT_468 = "NOTE_TABLEVIEW_LABEL";

   @RBEntry("�?�尋")
   public static final String PRIVATE_CONSTANT_469 = "search.pickerSearch.description";

   @RBEntry("清除")
   public static final String PRIVATE_CONSTANT_470 = "search.pickerClear.description";

   @RBEntry("您似乎尚未定義回呼函數，或此函數有錯:")
   @RBComment("Error on picker call back")
   public static final String PICKER_CALL_BACK_ERROR = "PICKER_CALL_BACK_ERROR";

   @RBEntry("�??稱")
   @RBComment("Name")
   public static final String SAVED_QUERY_NAME = "SAVED_QUERY_NAME";

   @RBEntry("建立者")
   @RBComment("Creator")
   public static final String SAVED_QUERY_CREATOR = "SAVED_QUERY_CREATOR";

   @RBEntry("�?有的�?�?�")
   @RBComment("Owning Page")
   public static final String SAVED_QUERY_OWNINGPAGE = "SAVED_QUERY_OWNINGPAGE";

   @RBEntry("建立時間")
   @RBComment("Created")
   public static final String SAVED_QUERY_CREATEDON = "SAVED_QUERY_CREATEDON";

   @RBEntry("上次更新")
   @RBComment("Last Updated")
   public static final String SAVED_QUERY_UPDATEDON = "SAVED_QUERY_UPDATEDON";

   @RBEntry("�?有者")
   @RBComment("Owner")
   public static final String SAVED_QUERY_OWNER = "SAVED_QUERY_OWNER";

   @RBEntry("顯示")
   @RBComment("Show")
   public static final String SAVED_QUERY_SHOW = "SAVED_QUERY_SHOW";

   @RBEntry("開啟者視窗似乎已關閉")
   @RBComment("Message thrown when picker opener is closed")
   public static final String OPENER_WINDOW_CLOSED = "OPENER_WINDOW_CLOSED";

   @RBEntry("未�?��?�任何項目")
   @RBComment("Nothing has been selected")
   public static final String NOTHING_SELECTED = "NOTHING_SELECTED";

   @RBEntry("請指定�?�尋�?件或輸入有效關�?�字。")
   @RBComment("Please specify search criteria or enter a valid keyword.")
   public static final String EMPTY_CRITERAI_MESSAGE = "EMPTY_CRITERAI_MESSAGE";

   @RBEntry("包括所有零件")
   @RBComment("Include All Parts")
   public static final String SEARCH_CRITERIA_INCLUDE_ALL_PARTS = "SEARCH_CRITERIA_INCLUDE_ALL_PARTS";

   @RBEntry("僅包括")
   @RBComment("Include Only")
   public static final String SEARCH_CRITERIA_INCLUDE_ONLY = "SEARCH_CRITERIA_INCLUDE_ONLY";

   @RBEntry("�?設追蹤代碼")
   @RBComment("Default Trace Code")
   public static final String DEFAULT_TRACE_CODE = "DEFAULT_TRACE_CODE";
 
   @RBEntry("最終項目")
   @RBComment("End Item")
   public static final String DDL_OPTIONS_ENDITEM = "DDL_OPTIONS_ENDITEM";

   @RBEntry("批號")
   @RBComment("Lot")
   public static final String DDL_OPTIONS_LOT = "DDL_OPTIONS_LOT";

   @RBEntry("�?號")
   @RBComment("serialNumber")
   public static final String DDL_OPTIONS_SERIALNUMBER = "DDL_OPTIONS_SERIALNUMBER";

   @RBEntry("批/�?號")
   @RBComment("lotSerialNumber")
   public static final String DDL_OPTIONS_LOTSERIALNUMBER = "DDL_OPTIONS_LOTSERIALNUMBER";

   @RBEntry("標準")
   @RBComment("standard")
   public static final String DDL_OPTIONS_STANDARD = "DDL_OPTIONS_STANDARD";

   @RBEntry("泛型")
   @RBComment("genericParts")
   public static final String DDL_OPTIONS_GENERICPARTS = "DDL_OPTIONS_GENERICPARTS";

   @RBEntry("�?�供�?置泛型")
   @RBComment("configurableGenericParts")
   public static final String DDL_OPTIONS_CONFIGURABLEGENERICPARTS = "DDL_OPTIONS_CONFIGURABLEGENERICPARTS";

   @RBEntry("變體")
   @RBComment("variantParts")
   public static final String DDL_OPTIONS_VARIANTPARTS = "DDL_OPTIONS_VARIANTPARTS";

   @RBEntry("進階�?�供�?置")
   @RBComment("advancedConfigurableParts")
   public static final String DDL_OPTIONS_ADVANCEDCONFIGURABLEPARTS = "DDL_OPTIONS_ADVANCEDCONFIGURABLEPARTS";

   @RBEntry("進階�?�供�?置最終項目")
   @RBComment("advanced Configurable End Items")
   public static final String DDL_OPTIONS_ADVANCEDCONFIGURABLEENDITEMS = "DDL_OPTIONS_ADVANCEDCONFIGURABLEENDITEMS";

   @RBEntry("�?�供�?置")
   @RBComment("configurableParts")
   public static final String DDL_OPTIONS_CONFIGURABLEPARTS = "DDL_OPTIONS_CONFIGURABLEPARTS";

   @RBEntry("�?�供�?置模組")
   @RBComment("genericType")
   public static final String GENERIC_TYPE = "GENERIC_TYPE";
  
   @RBEntry("簡易�?�尋�?上的檔�??欄�?")
   @RBComment("Property need to set to Search for CAD Name from Simple search page.")
   public static final String CADNAME_FILENAME_ENABLED = "CADNAME_FILENAME_ENABLED";

   @RBEntry("在簡易�?�尋�?上顯示「檔�??�?欄�?，使用者�?�利用此欄�?，以 CAD �??稱來�?�尋 CAD 文件。")
   @RBComment("Property need to set to Search for CAD Name from Simple search page.")
   public static final String CADNAME_FILENAME_ENABLED_DESCRIPTION = "CADNAME_FILENAME_ENABLED_DESCRIPTION";

   @RBEntry("在簡易�?�尋�?上顯示「檔�??�?欄�?，使用者�?�利用此欄�?，以 CAD �??稱來�?�尋 CAD 文件。")
   @RBComment("Property need to set to Search for CAD Name from Simple search page.")
   public static final String CADNAME_FILENAME_ENABLED_LONGDESCRIPTION = "CADNAME_FILENAME_ENABLED_LONGDESCRIPTION";

   @RBEntry("縮圖")
   @RBComment("Thumbnail column label")
   public static final String THUMBNAIL = "THUMBNAIL";

   @RBEntry("�?�?�?果必須是有效數值")
   @RBComment("Message thrown when user enters invalid number for result per page.")
   public static final String MESSAGE_RESULT_PER_PAGE = "MESSAGE_RESULT_PER_PAGE";

   @RBEntry("全域�?�尋�?設類型清單")
   @RBComment("display name for global search type list in preference manager")
   public static final String GLOBAL_SEARCH_TYPE_LIST_NAME = "GLOBAL_SEARCH_TYPE_LIST_NAME";

   @RBEntry("此�??好設定將指定在全域�?�尋下拉�?清單中顯示的物件類型。")
   @RBComment("short description of global search type list in preference manager")
   public static final String GLOBAL_SEARCH_TYPE_LIST_DESC = "GLOBAL_SEARCH_TYPE_LIST_DESC";

   @RBEntry("此�??好設定將指定在全域�?�尋下拉�?清單中顯示的物件類型。")
   @RBComment("long description of global search type list in preference manager")
   public static final String GLOBAL_SEARCH_TYPE_LIST_LONG_DESC = "GLOBAL_SEARCH_TYPE_LIST_LONG_DESC";

   @RBEntry("�?�尋�?果中的縮圖顯示")
   @RBComment("Display name for thumbnailsOnWCSearch option in Preferences client")
   public static final String THUMBNAILS_ON_WC_SEARCH = "THUMBNAILS_ON_WC_SEARCH";

   @RBEntry("�?�擇是�?�在�?�尋�?果�?上顯示縮圖圖�?。")
   @RBComment("Description for thumbnailsOnWCSearch option in the Preferences client")
   public static final String THUMBNAILS_ON_WC_SEARCH_DESCRIPTION = "THUMBNAILS_ON_WC_SEARCH_DESCRIPTION";

   @RBEntry("此�??好設定已由�?�尋用戶端使用。僅�?�?�?�在 Creo View 內檢視的物件�??供縮圖圖�?。請注�?，如果�?顯示縮圖圖�?，�?�尋�?果會載入得更快。系統�?設是�?顯示縮圖。")
   @RBComment("Long description for thumbnailsOnWCSearch option in the Preferences client")
   public static final String THUMBNAILS_ON_WC_SEARCH_LONGDESCRIPTION = "THUMBNAILS_ON_WC_SEARCH_LONGDESCRIPTION";

   @RBEntry("�?設 GlobalType �?��?�項")
   @RBComment("Display name for ResetGlobalTypeSelection option in Preferences client")
   public static final String RESET_GLOBAL_TYPESELECTION = "RESET_GLOBAL_TYPESELECTION";

   @RBEntry("�?許使用者�?設全域類型")
   @RBComment("Description for ResetGlobalTypeSelection option in the Preferences client")
   public static final String RESET_GLOBAL_TYPESELECTION_DESCRIPTION = "RESET_GLOBAL_TYPESELECTION_DESCRIPTION";

   @RBEntry("�?許使用者�?設全域類型")
   @RBComment("Long description for ResetGlobalTypeSelection option in the Preferences client")
   public static final String RESET_GLOBAL_TYPESELECTION_LONGDESCRIPTION = "RESET_GLOBAL_TYPESELECTION_LONGDESCRIPTION";

   @RBEntry("�?�尋全部�?�用物件類型")
   @RBComment("Display name for allSearchTypes option in Preferences client")
   public static final String ALLSEARCHTYPES = "ALLSEARCHTYPES";

   @RBEntry("這是顯示在�?�尋�?上類型挑�?�器內的類型清單。也是使用者在簡易�?�尋�?上�?��?�「全部�?�用物件類型�?為物件類型後，系統所�?�尋的物件清單。")
   @RBComment("Description for allSearchTypes option in the Preferences client.When you search within a specific context, the object types listed are set by the context administrator and may differ from the object types that you select for this preference.")
   public static final String ALLSEARCHTYPES_DESCRIPTION = "ALLSEARCHTYPES_DESCRIPTION";

   @RBEntry("類型清單顯示在�?�尋�?的「類型�?視窗中。當使用者�?��?�「所有�?�用物件類型�?作為物件類型時，�?�尋的物件清單也在簡易�?�尋�?上。安�? Windchill 伺�?器時，「所有�?�用物件類型�?�尋�?�??好設定並沒有值。存�?� Windchill �?�尋�?時，會根據 SearchableTypes.properties 檔案設定�??好設定�?設值。在變更�?�尋�??好設定之�?，應至少存�?�一次�?�尋�?。")
   @RBComment("Long description for allSearchTypes option in the Preferences client.When you search within a specific context, the object types listed are set by the context administrator and may differ from the object types that you select for this preference.")
   public static final String ALLSEARCHTYPES_LONGDESCRIPTION = "ALLSEARCHTYPES_LONGDESCRIPTION";

   @RBEntry("全�?�類型�?��?�")
   @RBComment("Display name for globalTypeSelection option in Preferences client")
   public static final String GLOBAL_TYPE_SELECTION = "GLOBAL_TYPE_SELECTION";

   @RBEntry("您在簡易�?�尋�?上所�?�的類型�?��?�，會�??映在�??好設定上。當使用者�?��?�了�?�?�的物件類型，�??好設定也會隨之變更。")
   @RBComment("Description for Default Type Selection option in the Preferences client")
   public static final String GLOBAL_TYPE_SELECTION_DESCRIPTION = "GLOBAL_TYPE_SELECTION_DESCRIPTION";

   @RBEntry("您在簡易�?�尋�?上所�?�的類型�?��?�，會�??映在�??好設定上。當使用者�?��?�了�?�?�的物件類型，�??好設定也會隨之變更。")
   @RBComment("Long description for Default Type Selection option in the Preferences client")
   public static final String GLOBAL_TYPE_SELECTION_LONGDESCRIPTION = "GLOBAL_TYPE_SELECTION_LONGDESCRIPTION";

   @RBEntry("進階�?�尋�?設類型清單")
   @RBComment("Display name for searchTypeSelection ")
   public static final String SEARCH_TYPE_SELECTION = "SEARCH_TYPE_SELECTION";

   @RBEntry("此�??好設定會指定進階�?�尋�?上�?設顯示的物件類型。")
   @RBComment("Description for Default Type Selection option in the Preferences client")
   public static final String SEARCH_TYPE_SELECTION_DESCRIPTION = "SEARCH_TYPE_SELECTION_DESCRIPTION";

   @RBEntry("此�??好設定會指定進階�?�尋�?上�?設顯示的物件類型。")
   @RBComment("Long description for Default Type Selection option in the Preferences client")
   public static final String SEARCH_TYPE_SELECTION_LONGDESCRIPTION = "SEARCH_TYPE_SELECTION_LONGDESCRIPTION";

   @RBEntry("�?�?使用者的已存�?�尋內部�??稱。")
   @RBComment("Display name for savedSearches option in Preferences client")
   public static final String SAVEDSEARCHES = "SAVEDSEARCHES";

   @RBEntry("�?�?使用者的已存�?�尋內部�??稱。")
   @RBComment("Description for savedSearches option in the Preferences client")
   public static final String SAVEDSEARCHES_DESCRIPTION = "SAVEDSEARCHES_DESCRIPTION";

   @RBEntry("�?�?使用者的已存�?�尋內部�??稱。")
   @RBComment("Long description for savedSearches option in the Preferences client")
   public static final String SAVEDSEARCHES_LONGDESCRIPTION = "SAVEDSEARCHES_LONGDESCRIPTION";

   /**
    * added for fixing SPR 1350174
    **/
   @RBEntry("執行這個�?�尋時，發生錯誤。請通知您的系統管�?�員並告知�?題發生當時，你所執行的動作。")
   @RBComment("This value is will be displayed as a warning alert for exceptions which are thrown from Server side without proper embedded messages ")
   public static final String GENERIC_ERROR_MESSAGE = "GENERIC_EXCEPTION_MESSAGE";

   @RBEntry("警告: 您的�?�尋�?功，但有�?�能系統並未傳回�?些物件，�?果集�?��?完整。請按一下修改�?件，然後在關�?�字欄�?輸入更具�?制性的�?件，如此�?�確�?�?�得全部�?�尋�?果。")
   @RBComment("Message to display to a user when there are possible additional search results in Rware and they need to make their criteria more specific")
   public static final String INCOMPLETE_RESULT_SET_WARNING = "INCOMPLETE_RESULT_SET_WARNING";

   @RBEntry("警告: 您的�?�尋�?功，但�?些物件�?�能並未傳回，導致�?果集�?完整。請按一下「修改�?件�?，然後輸入更具�?制性的�?件，以確�?返回全部�?�尋�?果。有關使用�?�尋�?件的更多資訊，請�?�閱線上說明。")
   @RBComment("Message to display to a user when there are possible additional search results at DB and they need to make their criteria more specific")
   public static final String INCOMPLETE_DB_RESULT_SET_WARNING = "INCOMPLETE_DB_RESULT_SET_WARNING";

   @RBEntry("�?�?�?果")
   @RBComment("Display name for result per page in Preferences client")
   public static final String SEARCHTABLELIMIT = "SEARCHTABLELIMIT";

   @RBEntry("此�??好設定�?�設定�?設的�?�?�?果值。�?設值為 15。")
   @RBComment("Description for Results per page option in the Preferences client")
   public static final String RESULT_PER_PAGE_DESCRIPTION = "SEARCHTABLELIMIT_DESCRIPTION";

   @RBEntry("此�??好設定�?�設定�?設的�?�?�?果值。�?設值為 15。")
   @RBComment("Long description for Results per page option in the Preferences client")
   public static final String RESULT_PER_PAGE_LONGDESCRIPTION = "SEARCHTABLELIMIT_LONGDESCRIPTION";

   @RBEntry("注�?: 項目已存在於「已�?��?��?物件清單中...\n\n「已�?��?��?清單內存有若干您試圖移動的項目:\n{0}\n\n會加入沒有包�?�在「已�?��?��?清單中的指定項目。")
   @RBComment("Attention: Item(s) already in Selected object list...\n\nThe Selected list already contains some of the items you are attempting to move:\n{0}\n\nItems you indicated that are not already in the Selected list will be added.")
   public static final String SOME_ITEMS_ALREADY_SELECTED = "SOME_ITEMS_ALREADY_SELECTED";

   @RBEntry("注�?: 項目已存在於「已�?��?��?物件清單中...\n\n「已�?��?��?清單內存有若干您試圖移動的項目:\n{0}")
   @RBComment("Attention: Item(s) already in Selected object list...\n\nThe Selected list already contains the items you are attempting to move:\n{0}")
   public static final String ALL_ITEMS_ALREADY_SELECTED = "ALL_ITEMS_ALREADY_SELECTED";

   @RBEntry("未追蹤的")
   @RBComment("untracedParts")
   public static final String DDL_OPTIONS_UUNTRACED = "DDL_OPTIONS_UUNTRACED";

   @RBEntry("「僅包括�?�?求至少�?��?�一個�?�項。")
   @RBComment("Alert message if user selects no checkbox from include only radio.")
   public static final String DDLALERT = "DDLALERT";

   @RBEntry("值已存在於系統內。\n\n您在本�?所輸入的�??稱已經存在。請按一下「確定�?以覆寫�?�有�??稱，或按一下「�?�消�?返回�?�?�並輸入新�??稱。")
   @RBComment("Alert message for same saved search name")
   public static final String SAVEDSEARCHNAMEALERT = "SAVEDSEARCHNAMEALERT";

   @RBEntry("契約行項目碼")
   @RBComment("search attribute for CDRLBasePackage")
   public static final String CONTRACT_LINE_ITEM = "CONTRACT_LINE_ITEM";

   @RBEntry("契約編號")
   @RBComment("search attribute for CDRLBasePackage")
   public static final String CONTRACT_NUMBER = "CONTRACT_NUMBER";

   @RBEntry("注�?: 所�?�物件�?符�?�「刪除�?動作資格。\n\n �?符�?�資格的物件將�?予刪除。")
   @RBComment("Delete action is invalid for one or more selected objects")
   public static final String DELETE_ACTION_INVALID = "DELETE_ACTION_INVALID";

   @RBEntry("資料夾")
   @RBComment("Label for folder search picker.")
   public static final String LOCATION_PICKER_LABEL = "LOCATION_PICKER_LABEL";

   @RBEntry("上次�?�尋")
   @RBComment("Last Search")
   public static final String LAST_SEARCH = "LAST_SEARCH";

   @RBEntry("編寫應用程�?")
   @RBComment("Label for EPMDocument authoring application")
   public static final String EPM_AUTHORING_APPLICATION = "EPM_AUTHORING_APPLICATION";

   @RBEntry("文件類別")
   @RBComment("Label for EPMDocument document category")
   public static final String EPM_DOCUMENT_TYPE = "EPM_DOCUMENT_TYPE";

   @RBEntry("�?設�?�定檢視")
   @RBComment("Default Agreement View")
   public static final String PRIVATE_CONSTANT_471 = "AUTHORIZATIONAGREEMENT_TABLEVIEW_NAME";

   @RBEntry("�?設�?�定�?�尋表檢視")
   @RBComment("Default Agreement Search Table View")
   public static final String PRIVATE_CONSTANT_472 = "AUTHORIZATIONAGREEMENT_TABLEVIEW_DESC";

   @RBEntry("�?�定")
   @RBComment("Agreement")
   public static final String PRIVATE_CONSTANT_473 = "AUTHORIZATIONAGREEMENT_TABLEVIEW_LABEL";

   @RBEntry("資�?類型")
   @RBComment("Label for Resource User Type dropdown having values Windchill User and Other")
   public static final String PLAN_RESOURCE_NAME_LABEL = "PLAN_RESOURCE_NAME_LABEL";

   @RBEntry("CAGE 代碼")
   @RBComment("Org field name on search page when wadam is installed")
   public static final String WADMORG = "WADMORG";

   @RBEntry("零件組態�??稱")
   @RBComment("Label for configuration name in the configuration compare search picker")
   public static final String PART_CONFIGURATION_NAME_LABEL = "PART_CONFIGURATION_NAME_LABEL";

   @RBEntry("基礎零件�??稱")
   @RBComment("Label for base part name in the configuration compare search picker")
   public static final String BASE_PART_NAME_LABEL = "BASE_PART_NAME_LABEL";

   @RBEntry("基礎零件編號")
   @RBComment("Label for base part number in the configuration compare search picker")
   public static final String BASE_PART_NUMBER_LABEL = "BASE_PART_NUMBER_LABEL";

   @RBEntry("連絡人")
   @RBComment("Label for the saved search customize table contact column")
   public static final String PRIVATE_CONSTANT_474 = "CONTACT_LABEL";

   @RBEntry("顯示進階�?�尋")
   @RBComment("Label used at picker")
   public static final String ADVANCED_SEARCH_LBL = "ADVANCED_SEARCH_LBL";

   @RBEntry("隱�?進階�?�尋")
   @RBComment("Label used at picker")
   public static final String BASIC_SEARCH_LBL = "BASIC_SEARCH_LBL";

   @RBEntry("類型")
   @RBComment("Label used at object type picker")
   public static final String OBJECT_TYPE_LBL = "OBJECT_TYPE_LBL";

   @RBEntry("類型")
   @RBComment("Label used at object type picker on advanced search page")
   public static final String TYPE_LBL = "TYPE_LBL";

   @RBEntry("代碼")
   @RBComment("Label for the code field in Choice Search")
   public static final String PRIVATE_CONSTANT_475 = "CODE_LABEL";

   @RBEntry("�?�項")
   @RBComment("Label for the option field in Choice Search")
   public static final String PRIVATE_CONSTANT_476 = "OPTION_LABEL";

   @RBEntry("群組")
   @RBComment("Label for the group field in Choice Search")
   public static final String PRIVATE_CONSTANT_477 = "GROUP_LABEL";

   @RBEntry("特定�?後關�?�")
   @RBComment("Static Find Specific Context option added in context picker dropdown")
   public static final String PRIVATE_CONSTANT_478 = "FIND_CONTEXT";

   @RBEntry("格�?圖示")
   @RBComment("Label for the column \"Format Icon\" in tables")
   public static final String FORMAT_ICON = "FORMAT_ICON";

   @RBEntry("�?�?�?果必須�?於")
   @RBComment("Max result per page cap.")
   public static final String RESULT_PER_PAGEMAX_CAP = "RESULT_PER_PAGEMAX_CAP";

   @RBEntry("�?�擇日期範�?")
   @RBComment("Choose Date Range")
   public static final String DATE_DATE_RANGE = "DATE_DATE_RANGE";

   @RBEntry("�?�擇天數範�?")
   @RBComment("Choose Day Range")
   public static final String DATE_DAY_RANGE = "DATE_DAY_RANGE";

   @RBEntry("昨天")
   @RBComment("Yesterday")
   public static final String DATE_YESTERDAY = "DATE_YESTERDAY";

   @RBEntry("今天")
   @RBComment("Today")
   public static final String DATE_TODAY = "DATE_TODAY";

   @RBEntry("明天")
   @RBComment("Tomorrow")
   public static final String DATE_TOMORROW = "DATE_TOMORROW";

   @RBEntry("天之�?")
   @RBComment("days ago")
   public static final String DAYS_AGO = "DAYS_AGO";

   @RBEntry("天 (�?�日起)")
   @RBComment("days from now")
   public static final String DAYS_NOW = "DAYS_NOW";

   @RBEntry("新建檢視")
   public static final String PRIVATE_CONSTANT_479 = "search.newView.description";

   @RBEntry("已作廢�?件。")
   @RBComment("Message for alert when some of the criteria's are missing after upgrade.")
   public static final String MISSING_QUERYBUILDER_ROW = "MISSING_QUERYBUILDER_ROW";

   @RBEntry("在�?�級為最新發行版後，此�?件便被作廢了。請刪除這個�?件並從�?件清單中新增全新的�?件，然後�?新儲存�?�尋。若管�?�員所指派�?�尋為已存�?�尋，請�?求管�?�員�?新建立已存�?�尋。")
   @RBComment("Message for alert when some of the criteria's are missing after upgrade.")
   public static final String INVALID_QUERYBUILDER_ROW = "INVALID_QUERYBUILDER_ROW";

   @RBEntry("ID")
   @RBComment("Label for Project Plan Activity ID.")
   public static final String PLAN_ACTIVITY_ID = "PLAN_ACTIVITY_ID";

   @RBEntry("進階�?�尋的無效類型。")
   @RBComment("wt.fc.Persistable is not a valid type for advanced search")
   public static final String INVALID_TYPE_FOR_ADVANCED_SEARCH = "INVALID_TYPE_FOR_ADVANCED_SEARCH";

   @RBEntry("新建檢視")
   @RBComment("new view")
   public static final String NEWVIEW = "NEWVIEW";

   @RBEntry("關閉")
   public static final String PRIVATE_CONSTANT_480 = "search.searchCloseButton.description";

   @RBEntry("製造")
   public static final String PRIVATE_CONSTANT_481 = "MAKE_FACET";

   @RBEntry("購買")
   public static final String PRIVATE_CONSTANT_482 = "BUY_FACET";

   @RBEntry("工作中")
   public static final String PRIVATE_CONSTANT_483 = "INWORK_FACET";

   @RBEntry("已發行")
   public static final String PRIVATE_CONSTANT_484 = "RELEASED_FACET";

   @RBEntry("零件")
   public static final String PRIVATE_CONSTANT_485 = "WTPART_FACET";

   @RBEntry("文件")
   public static final String PRIVATE_CONSTANT_486 = "WTDOCUMENT_FACET";

   @RBEntry("收件者�??稱")
   @RBComment("Field name for recipent name in delta delivery picker")
   public static final String RECIPIENT_NAME = "RECIPIENT_NAME";

   @RBEntry("管�?�")
   public static final String PRIVATE_CONSTANT_487 = "search.savedSearchTable.description";

   @RBEntry("管�?�")
   public static final String PRIVATE_CONSTANT_488 = "search.savedSearchTable.tooltip";

   @RBEntry("管�?�已存�?�尋")
   public static final String PRIVATE_CONSTANT_489 = "search.savedSearchTable.title";

   @RBEntry("height=450,width=920")
   public static final String PRIVATE_CONSTANT_523 = "search.savedSearchTable.moreurlinfo";

   @RBEntry("儲存此�?�尋")
   public static final String PRIVATE_CONSTANT_490 = "search.saveThisSearchDefaultName.description";

   @RBEntry("height=250,width=450")
   public static final String PRIVATE_CONSTANT_491 = "search.saveThisSearchDefaultName.moreurlinfo";

   @RBEntry("儲存此�?�尋")
   public static final String PRIVATE_CONSTANT_492 = "search.saveThisSearchDefaultName.title";

   @RBEntry("�??稱")
   public static final String SAVED_SEARCH_DISPLAY_NAME = "SAVED_SEARCH_DISPLAY_NAME";

   @RBEntry("關閉")
   public static final String PRIVATE_CONSTANT_493 = "search.savedSearchLightBoxCloseButton.description";

   @RBEntry("�?�尋記錄和已存�?�尋")
   public static final String PRIVATE_CONSTANT_494 = "search.searchHistSavedSearch.description";

   @RBEntry("進階�?�尋")
   public static final String PRIVATE_CONSTANT_495 = "search.advancedSearch.description";

   @RBEntry("分類�?�尋")
   public static final String PRIVATE_CONSTANT_496 = "search.classificationSearch.description";

   @RBEntry("�?�尋記錄")
   @RBComment("Heading for Search History Display")
   public static final String SEARCH_HISTORY_HEADING = "SEARCH_HISTORY_HEADING";

   @RBEntry("已存�?�尋")
   @RBComment("Heading for Saved Search Display")
   public static final String SAVED_SEARCH_HEADING = "SAVED_SEARCH_HEADING";

   @RBEntry("由我建立")
   @RBComment("Saved Search section for queries saved by current user")
   public static final String SAVED_SEARCH_CREATED_BY_ME = "SAVED_SEARCH_CREATED_BY_ME";

   @RBEntry("與我共用")
   @RBComment("Saved Search section for queries saved by current user")
   public static final String SAVED_SEARCH_SHARED_WITH_ME = "SAVED_SEARCH_SHARED_WITH_ME";

   @RBEntry("今天")
   @RBComment(" Search History for today's searches.")
   public static final String SEARCH_HISTORY_TODAY = "SEARCH_HISTORY_TODAY";

   @RBEntry("較舊")
   @RBComment(" Search History for older searches.")
   public static final String SEARCH_HISTORY_OLDER = "SEARCH_HISTORY_OLDER";

   @RBEntry("今天未執行任何�?�尋")
   @RBComment("label when no records found in todays history")
   public static final String SEARCH_HISTORY_TODAY_NO_RECORDS_LABEL = "SEARCH_HISTORY_TODAY_NO_RECORDS_LABEL";

   @RBEntry("無")
   @RBComment("label when no records found in Saved Searches.")
   public static final String SAVED_SEARCH_NO_RECORDS_LABEL = "SAVED_SEARCH_NO_RECORDS_LABEL";

   @RBEntry("編輯�?件")
   @RBComment("Label for Edit action in saved search & search history display.")
   public static final String PRIVATE_CONSTANT_497 = "EDIT_LABEL";

   @RBEntry("關�?�字")
   @RBComment("Being used in the search history display page in search history link.")
   public static final String KEYWORD_FOR_SEARCH_HISTORY_LINK = "KEYWORD_FOR_SEARCH_HISTORY_LINK";

   @RBEntry("類型")
   @RBComment("Being used in the search history display page in search history link.")
   public static final String TYPE_FOR_SEARCH_HISTORY_LINK = "TYPE_FOR_SEARCH_HISTORY_LINK";

   @RBEntry("�?設�?�項集檢視")
   @RBComment("Default Option Set View")
   public static final String PRIVATE_CONSTANT_498 = "OPTIONSET_TABLEVIEW_NAME";

   @RBEntry("�?設�?�項集�?�尋表檢視")
   @RBComment("Default Option Set Search Table View")
   public static final String PRIVATE_CONSTANT_499 = "OPTIONSET_TABLEVIEW_DESC";

   @RBEntry("�?�項集  ")
   @RBComment("Option Set ")
   public static final String PRIVATE_CONSTANT_500 = "OPTIONSET_TABLEVIEW_LABEL";

   @RBEntry("確定")
   @RBComment("Label for Ok button in Ext Window for lightbix.")
   public static final String PRIVATE_CONSTANT_501 = "Ok_LABEL";

   @RBEntry("�?�消")
   @RBComment("Label for Cancel button in Ext Window for lightbix.")
   public static final String PRIVATE_CONSTANT_502 = "Cancel_LABEL";

   @RBEntry("�?�?零件的�?外�?件:")
   @RBComment("Label for Additonal Criteria for Parts")
   public static final String PRIVATE_CONSTANT_503 = "PART_ADDITIONAL_CRITERIA";

   @RBEntry("儲存")
   @RBComment("Label for Save button in Ext Window for lightbix.")
   public static final String PRIVATE_CONSTANT_504 = "Save_LABEL";

   @RBEntry("�?�項")
   @RBComment("Caption text at type picker launch point at search page")
   public static final String TYPE_PICKER_MENU_CAPTION = "TYPE_PICKER_MENU_CAPTION";

   @RBEntry("新增")
   @RBComment("Caption text at type picker launch point at search page")
   public static final String TYPE_PICKER_MENU_ADD_UPDATE = "TYPE_PICKER_MENU_ADD_UPDATE";

   @RBEntry("�?�復�?設值")
   @RBComment("Caption text at type picker launch point at search page")
   public static final String TYPE_PICKER_MENU_RESTORE_DEFAULT = "TYPE_PICKER_MENU_RESTORE_DEFAULT";

   @RBEntry("全部類型")
   @RBComment("display name for persistable type")
   public static final String ALL_TYPES = "ALL_TYPES";

   @RBEntry("�?��?�關係")
   @RBComment("label for relations")
   public static final String SELECT_RELATIONS = "SELECT_RELATIONS";

   @RBEntry("�?設�?�擇檢視")
   @RBComment("Default Choice View")
   public static final String PRIVATE_CONSTANT_505 = "CHOICE_TABLEVIEW_NAME";

   @RBEntry("�?設�?�擇�?�尋表檢視")
   @RBComment("Default Choice Search Table View")
   public static final String PRIVATE_CONSTANT_506 = "CHOICE_TABLEVIEW_DESC";

   @RBEntry("�?�擇")
   @RBComment("Choice ")
   public static final String PRIVATE_CONSTANT_507 = "CHOICE_TABLEVIEW_LABEL";

   @RBEntry("無法載入已存�?�尋，因為有一或多個相關物件被刪除了。")
   @RBComment(" Error message to be shown when user selects a deleted saved query for edit or execute.")
   public static final String SAVED_SEARCH_DELETED_MESSAGE = "SAVED_SEARCH_DELETED_MESSAGE";

   /**
    * special column labels
    **/
   @RBEntry("�??稱")
   public static final String PACKAGE_NAME = "PACKAGE_NAME";

   @RBEntry("�?�?編號")
   public static final String PACKAGE_NUMBER = "PACKAGE_NUMBER";

   @RBEntry("�?�?版本")
   public static final String PACKAGE_VERSION = "PACKAGE_VERSION";

   @RBEntry("全部")
   public static final String ALL_VIEW = "ALL_VIEW";

   @RBEntry("全部")
   public static final String ALL_VIEW_DESCRIPTION = "ALL_VIEW_DESCRIPTION";

   @RBEntry("已儲存的�?�尋�??稱")
   @RBComment("Label of the saved search name being displayed on advanced search screen.")
   public static final String SAVED_SEARCH_NAME_LABEL = "SAVED_SEARCH_NAME_LABEL";

   @RBEntry("開始新�?�尋")
   @RBComment("label for start a new search link on the search page")
   public static final String START_A_NEW_SEARCH_LINK = "START_A_NEW_SEARCH_LINK";

   @RBEntry("儲存此�?�尋")
   @RBComment("label for save this search link on the search page ")
   public static final String SAVE_THIS_SEARCH_LINK = "SAVE_THIS_SEARCH_LINK";

   @RBEntry("編輯�?�尋�?件")
   @RBComment(" label for edit search criteria link on the search page ")
   public static final String EDIT_SEARCH_CRITERIA_LINK = "EDIT_SEARCH_CRITERIA_LINK";

   @RBEntry("檢視�?�尋記錄和已存�?�尋")
   @RBComment("Label of the view saved search option")
   public static final String VIEW_SAVED_SEARCH_LABEL = "VIEW_SAVED_SEARCH_LABEL";

   @RBEntry("�?�擇類型")
   @RBComment("Label of the choose type option")
   public static final String CHOOSE_TYPE_LABEL = "CHOOSE_TYPE_LABEL";

   @RBEntry("全部物件類型")
   @RBComment("Label of the all type option")
   public static final String ALL_TYPE_LABEL = "ALL_TYPE_LABEL";

   @RBEntry("�?�尋記錄和已存�?�尋")
   @RBComment("Tab label for history & saved searches page")
   public static final String PRIVATE_CONSTANT_508 = "navigation.historySaved.description";

   @RBEntry("進階�?�尋")
   @RBComment("Tab label for Advanced search page")
   public static final String PRIVATE_CONSTANT_509 = "navigation.advanced.description";

   @RBEntry("分類�?�尋")
   @RBComment("Tab label for Classification search page")
   public static final String PRIVATE_CONSTANT_510 = "navigation.classification.description";

   @RBEntry("其他�?件")
   @RBComment("Label for Additional Criteria on search info page for search history and saved searches")
   public static final String ADDITIONAL_CRITERIA_LABEL = "ADDITIONAL_CRITERIA_LABEL";


   @RBEntry("上一次執行時間")
   @RBComment("Label for Last Performed on search info page for search history and saved searches")
   public static final String LAST_PERFORMED_ON_LABEL = "LAST_PERFORMED_ON_LABEL";


   @RBEntry("目�?造訪的�?後關�?�挑�?�器清單大�?")
   @RBComment("Determines maximum number of items in recently visited Context Picker drop-down.")
   public static final String MULTISELECT_CONTEXTPICKER_LIMIT = "MULTISELECT_CONTEXTPICKER_LIMIT";

   @RBEntry("最多�?�以從�?果�?�擇 {0} 個�?後關�?�。�?�消�?��?��?些�?後關�?�以繼續。")
   @RBComment("Alert to be shown for user if selects more contexts than preference set for search page.")
   public static final String MULTISELECT_CONTEXTPICKER_LIMIT_ALERT = "MULTISELECT_CONTEXTPICKER_LIMIT_ALERT";

   @RBEntry("網路關係")
   @RBComment("Label for the network realtionship display in search criteria string ")
   public static final String NETWORK_RELATIONSHIP_LABEL = "NETWORK_RELATIONSHIP_LABEL";


   @RBEntry("網路�?後關�?�")
   @RBComment("Label for the network context display in search criteria string ")
   public static final String NETWORK_CONTEXT_LABEL = "NETWORK_CONTEXT_LABEL";


   @RBEntry("編輯�?件")
   @RBComment("Link for edit criteria on search info page for search history and saved searches")
   public static final String EDIT_CRITERIA_LINK = "EDIT_CRITERIA_LINK";

   @RBEntry("DDL �?件")
   @RBComment("DDL  Criteria label on search info page for search history and saved searches")
   public static final String DDL_CRITERIA_LABEL = "DDL_CRITERIA_LABEL";

   @RBEntry("相關物件")
   @RBComment("Related Object label on search info page for search history and saved searches")
   public static final String RELATED_OBJECT_LABEL = "RELATED_OBJECT_LABEL";


   @RBEntry("�?存�?��?�")
   @RBComment("Archive Panel label on search info page for search history and saved searches")
   public static final String ARCHIVE_PANEL_LABEL = "ARCHIVE_PANEL_LABEL";

   @RBEntry("�?設技能檢視")
   @RBComment("Default Skill View")
   public static final String PRIVATE_CONSTANT_511 = "MPMPSKILL_TABLEVIEW_NAME";

   @RBEntry("�?設技能�?�尋表檢視")
   @RBComment("Default Skill Search Table View")
   public static final String PRIVATE_CONSTANT_512 = "MPMPSKILL_TABLEVIEW_DESC";

   @RBEntry("技能")
   @RBComment("Skill")
   public static final String PRIVATE_CONSTANT_513 = "MPMPSKILL_TABLEVIEW_LABEL";

   @RBEntry("�?設刀具檢視")
   @RBComment("Default Tooling View")
   public static final String PRIVATE_CONSTANT_514 = "MPMTOOLING_TABLEVIEW_NAME";

   @RBEntry("�?設刀具�?�尋表檢視")
   @RBComment("Default Tooling Search Table View")
   public static final String PRIVATE_CONSTANT_515 = "MPMTOOLING_TABLEVIEW_DESC";

   @RBEntry("刀具")
   @RBComment("Tooling")
   public static final String PRIVATE_CONSTANT_516 = "MPMTOOLING_TABLEVIEW_LABEL";

   @RBEntry("�?設工作中心檢視")
   @RBComment("Default WorkCenter View")
   public static final String PRIVATE_CONSTANT_517 = "MPMWORKCENTER_TABLEVIEW_NAME";

   @RBEntry("�?設工作中心�?�尋表檢視")
   @RBComment("Default WorkCenter Search Table View")
   public static final String PRIVATE_CONSTANT_518 = "MPMWORKCENTER_TABLEVIEW_DESC";

   @RBEntry("工作中心")
   @RBComment("WorkCenter")
   public static final String PRIVATE_CONSTANT_519 = "MPMWORKCENTER_TABLEVIEW_LABEL";

   @RBEntry("�?設製程物料檢視")
   @RBComment("Default Process Material View")
   public static final String PRIVATE_CONSTANT_520 = "MPMPROCESSMATERIAL_TABLEVIEW_NAME";

   @RBEntry("�?設製程物料�?�尋表檢視")
   @RBComment("Default Process Material Search Table View")
   public static final String PRIVATE_CONSTANT_521 = "MPMPROCESSMATERIAL_TABLEVIEW_DESC";

   @RBEntry("製程物料")
   @RBComment("Process Material")
   public static final String PRIVATE_CONSTANT_522 = "MPMPROCESSMATERIAL_TABLEVIEW_LABEL";



   @RBEntry("儲存此�?�尋")
   public static final String saveThisSearchProEDesc = "search.saveThisSearchProE.description";

   @RBEntry("儲存此�?�尋")
   public static final String saveThisSearchProEToolT = "search.saveThisSearchProE.tooltip";

   @RBEntry("儲存此�?�尋")
   public static final String saveThisSearchProETitle = "search.saveThisSearchProE.title";

   @RBEntry("最多")
   public static final String uoToLabel = "UP_TO_ATTRIBUTE";

   @RBEntry("{0} 天之�?")
   public static final String daysAgoAttrib = "DAYS_AGO_TO_ATTRIBUTE";

   @RBEntry("{0} 天 (�?�日起)")
   public static final String daysFromNowAttrib = "DAYS_FROM_NOW_ATTRIBUTE";

   @RBEntry("更多")
   @RBComment("More lable in query builder")
   public static final String moreQBLabel = "MORE_QB_LABEL";


   @RBEntry("�?�項")
   public static final String options = "OPTIONS";

   @RBEntry("新增�?後關�?�")
   public static final String addContext = "ADD_CONTEXT";

   @RBEntry("其他�?�項")
   public static final String moreOptions = "MORE_OPTIONS";

   @RBEntry("確定")
   public static final String ok = "OK";

   @RBEntry("�?�消")
   public static final String cancel = "CANCEL";

   @RBEntry("�?�尋範�?")
   public static final String searchIn = "SEARCH_IN";

   @RBEntry("�?員資格")
   public static final String membership = "MEMBERSHIP";

   @RBEntry("我身為其�?員")
   public static final String iAmAMemberOf = "I_AM_A_MEMBER_OF";

   @RBEntry("在我的組織中")
   public static final String areInMyOrganization = "ARE_IN_MY_ORGANIZATION";

   @RBEntry("請輸入一個有效的數值。")
   @RBComment("Msg for invalid numeric entry.")
   public static final String INVALID_NUMBER = "INVALID_NUMBER";

   @RBEntry("新建")
   @RBComment("Label of submenu New")
   public static final String new_submenu = "object.new_submenu.description";

   @RBEntry("新增至")
   @RBComment("Label of submenu Add to")
   public static final String add_to_submenu = "object.add_to_submenu.description";

   @RBEntry("比較")
   @RBComment("Label of submenu Compare")
   public static final String compare_submenu = "object.compare_submenu.description";

   @RBEntry("處�?�")
   @RBComment("Label of submenu Process")
   public static final String process_submenu = "object.process_submenu.description";

   @RBEntry("未定義")
   public static final String UNDEFINED_LABEL = "UNDEFINED_LABEL";

   @RBEntry("�?��?��?存�?件")
   @RBComment("Label of link to launch archive panel on search page")
   public static final String ARCHIVE_LINK_LEVEL = "ARCHIVE_LINK_LEVEL";

   @RBEntry("所�?�物件中，無一支�?�此動作")
   @RBComment("Warning messafe to user when invalid objects are selected to perform Email object owners action")
   public static final String INVALID_OBJECT_EMAIL = "INVALID_OBJECT_EMAIL";

   @RBEntry("所�?�物件很少�?支�?�此動作。請按下「確定�?以繼續")
   @RBComment("Warning messafe to user when invalid objects are selected to perform Email object owners action")
   public static final String FEW_INVALID_OBJECT_EMAIL = "FEW_INVALID_OBJECT_EMAIL";


   @RBEntry("{0} �?能與其他類型一起�?�尋。")
   @RBComment("Message alerting the individual type cannot be searched with other types. ")
   public static final String INDIVIDUAL_SEARCH_TYPE = "INDIVIDUAL_SEARCH_TYPE";


   @RBEntry("全域替代識別元")
   @RBComment("Field name for user record key in Quality People or Places")
   public static final String ALTERNATE_IDENTIFIER = "ALTERNATE_IDENTIFIER";

   @RBEntry("電話號碼")
   @RBComment("Field name for Phone number in Quality People or Places")
   public static final String PHONE_NUMBER = "PHONE_NUMBER";

   @RBEntry("電�?郵件�?�?�")
   @RBComment("Field name for E-mail address in Quality People or Places")
   public static final String EMAIL_ADDRESS = "EMAIL_ADDRESS";

   @RBEntry("郵�?��?�號")
   @RBComment("Field name for Postal code in Quality People or Places")
   public static final String POSTAL_CODE = "POSTAL_CODE";

   @RBEntry("儲存查詢: ")
   @RBComment("Saved Search Create Message")
   public static final String SAVED_SEARCH_CREATED = "SAVED_SEARCH_CREATED";

   @RBEntry("確�?: 建立�?功")
   @RBComment("Saved Search Create Message Title")
   public static final String SAVED_SEARCH_CREATED_TITLE = "SAVED_SEARCH_CREATED_TITLE";

   @RBEntry("�?設工作�?程範本檢視")
   @RBComment("Default Workflow Process Template View")
   public static final String PRIVATE_CONSTANT_530 = "WFTEMPLATE_TABLEVIEW_NAME";

   @RBEntry("�?設工作�?程範本�?�尋表檢視")
   @RBComment("Default Workflow Process Template Search Table View")
   public static final String PRIVATE_CONSTANT_531 = "WFTEMPLATE_TABLEVIEW_DESC";

   @RBEntry("工作�?程範本")
   @RBComment("Workflow Process Template")
   public static final String PRIVATE_CONSTANT_532 = "WFTEMPLATE_TABLEVIEW_LABEL";
   @RBEntry("注�?: �?�?版�?化物件，將刪除所�?�版本修訂的所有版�?。")
   @RBComment("If one or more of the selected objects are iterated. All iterations for the selected object revisions will be deleted.")
   public static final String CONFIRM_DELETE = "CONFIRM_DELETE";

   @RBEntry("�?設已接收�?��?檢視")
   @RBComment("Default Received Delivery View")
   public static final String PRIVATE_CONSTANT_533 = "RECEIVEDDELIVERY_TABLEVIEW_NAME";

   @RBEntry("�?設已接收�?��?�?�尋表檢視")
   @RBComment("Default Received Delivery Search Table View")
   public static final String PRIVATE_CONSTANT_534 = "RECEIVEDDELIVERY_TABLEVIEW_DESC";

   @RBEntry("已接收�?��?")
   @RBComment("Received Delivery")
   public static final String PRIVATE_CONSTANT_535 = "RECEIVEDDELIVERY_TABLEVIEW_LABEL";

   @RBEntry("檢視�??稱")
   @RBComment("view name label")
   public static final String PRIVATE_CONSTANT_536 = "VIEW_NAME_LABEL";

   // resources for Clear icon in Structured Enumeration Picker
   @RBEntry("清除...")
   public static final String PRIVATE_CONSTANT_537 = "search.callSearchPickerClear.description";

   // resources for Clear icon in Structured Enumeration Picker
   @RBEntry("清除...")
   public static final String PRIVATE_CONSTANT_538 = "search.callSearchPickerClear.tooltip";

   @RBEntry("編號")
   public static final String PRIVATE_CONSTANT_539 = "2";

   @RBEntry("�??稱")
   public static final String PRIVATE_CONSTANT_540 = "1";

   @RBEntry("請指定�?�尋�?件")
   @RBComment("Alert shown to the user when empty search is executed with mulitple object types or multiple object types.")
   public static final String MULTI_TYPE_EMPTY_SEARCH_MESSAGE_TITLE = "MULTI_TYPE_EMPTY_SEARCH_MESSAGE_TITLE";

   @RBEntry("此日期�?�能並�?�必�?的 dd/MM/yyyy 格�?或超�?�範�?。")
   public static final String DATE_ERROR = "DATE_ERROR";

   @RBEntry("�?�尋並未�?功完�?。�?題�?�能是出在�?�尋�?件，或者您並無權�?�?�存�?�本�?�尋找到的物件。請編輯�?�尋�?件並�?試一次，或連絡您的系統管�?�員以�?�得進一步�?�助。")
   @RBComment("Message to display to a user when there is there is an invalid search criteria.")
   public static final String INVALID_CRITERIA_ERROR = "INVALID_CRITERIA_ERROR";

   /*
    * ***********************************************************
    * Search in Folder Resources
    *************************************************************
    */
   @RBEntry("在所�?�資料夾中�?�尋")
   @RBComment("Empty text for the Search in Folder component")
   public static final String SEARCH_IN_FOLDER_PROMPT = "SEARCH_IN_FOLDER_PROMPT";

   @RBEntry("清除")
   @RBComment("Clear text in Search in Folder component. Reset the text to Empty text string")
   public static final String CLEAR_SEARCH_IN_FOLDER = "CLEAR_SEARCH_IN_FOLDER";

   @RBEntry("索引伺�?器當機")
   @RBComment("Index Server down title")
   public static final String WARN_INDEX_SERER_DOWN_FALLBACK_TO_DB_SEAR_TITLE = "WARN_INDEX_SERER_DOWN_FALLBACK_TO_DB_SEARCH_TITLE";

   @RBEntry("索引�?�尋功能�?能使用，已使用了屬性�?�尋。�?�尋�?果�?�能�?會包�?�全部�?期的物件。請�?�絡您的 Windchill 系統管�?�員。")
   @RBComment("Index Server down. Fall back to DB Search.")
   public static final String WARN_INDEX_SERER_DOWN_FALLBACK_TO_DB_SEARCH = "WARN_INDEX_SERER_DOWN_FALLBACK_TO_DB_SEARCH";

   /*
    ************************************************************
    * Structured Enumeration Picker Resources
    ************************************************************
    */
   @RBEntry("分類樹")
   @RBComment("Title for Classification Tree")
   public static final String CLASSIFICATION_TREE_TITLE = "csm.clfTree.title";

   @RBEntry("類別")
   @RBComment("Title for the column in Classification Tree")
   public static final String CLASSIFICATION_TREE_COLUMN_NAME = "csm.clfTreeColumnName.title";

   // following entries are added as a part of story B-100525
   @RBEntry("請審核所�?�物件類型並�?新執行�?�尋")
   @RBComment("The message to be shown to user when the parent and child types both are selected and parent types should be removed")
   public static final String PARENT_TYPE_SELECTED_MESSAGE = "PARENT_TYPE_SELECTED_MESSAGE";

   @RBEntry("無法�?�?層級中的物件執行�?�尋。")
   @RBComment("The title to be shown to user when the parent and child types both are selected and parent types should be removed")
   public static final String PARENT_TYPE_SELECTED_MESSAGE_TITLE = "PARENT_TYPE_SELECTED_MESSAGE_TITLE";

   @RBEntry("我的最愛�?後關�?�")
   @RBComment("Message for My Context Display")
   public static final String MY_FAVOURITE_CONTEXT_LBL = "MY_FAVOURITE_CONTEXT_LBL";

   @RBEntry("查詢模�?語法範例")
   @RBComment("Examples for query mode syntax")
   public static final String EXAMPLES_FOR_QUERY_MODE_SYNTAX = "EXAMPLES_FOR_QUERY_MODE_SYNTAX";

   @RBEntry("我的最愛類型")
   @RBComment("Label for My Favorite Type checkbox shown on the search page")
   public static final String  MY_FAVOURITE_TYPE_LBL = "MY_FAVOURITE_TYPE_LBL";

   @RBEntry("�?件")
   @RBComment("Criteria label for the criteria fieldset on the advanced search page.")
   public static final String CRITERIA_LABEL = "CRITERIA_LBL";

   @RBEntry("�?��?�了多個資料夾")
   @RBComment("Warning Heading message when My Fav checkbox selected and only folders present inside it.")
   public static final String MULTIPLE_FOLDER_SELECTION_HEADING = "MULTIPLE_FOLDER_SELECTION_HEADING";
   
   @RBEntry("一次僅能�?��?�一個資料夾。")
   @RBComment("Warning message when My Fav checkbox selected and only folders present inside it.")
   public static final String MULTIPLE_FOLDER_SELECTION_MSG = "MULTIPLE_FOLDER_SELECTION_MSG";

    @RBEntry("在")
    @RBComment("Description has format 'Type in Organization', localizing word 'in' ")
    public static final String SAVE_SEARCH_COMBO_BOX_TOOLTIP_DESCRIPTION = "SAVE_SEARCH_COMBO_BOX_TOOLTIP_DESCRIPTION";

    @RBEntry("網站")
    @RBComment("Site")
    public static final String PRIVATE_CONSTANT_541 = "Site";
    
    /*Adding Secondary Attachments column*/
    @RBEntry("附件")
    @RBComment("Label for Secondary Attachments column")
    public static final String SECONDARY_ATTACHMENTS = "SECONDARY_ATTACHMENTS";

    @RBEntry("標籤")
    @RBComment("Label for Tag column")
    public static final String TAG_LABEL = "TAG_LABEL";
    
    @RBEntry("篩�?�器")
    @RBComment("Label for Filter column")
    public static final String FILTER_LABEL = "FILTER_LABEL";
    
    @RBEntry("您無法在特定�?後關�?�內�?�尋 {0}。")
    @RBComment("Message alerting type can not be searched with single context. ")
    public static final String DENY_SINGLE_CONTEXT_SEARCH = "DENY_SINGLE_CONTEXT_SEARCH";
}
