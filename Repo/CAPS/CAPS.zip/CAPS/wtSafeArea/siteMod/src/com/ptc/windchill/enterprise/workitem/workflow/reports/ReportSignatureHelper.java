/* bcwti
 *
 * Copyright (c) 2010 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */
package com.ptc.windchill.enterprise.workitem.workflow.reports;


import com.infoengine.object.factory.Att;
import com.infoengine.object.factory.Element;
import com.infoengine.object.factory.Group;

import java.sql.Timestamp;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Vector;

import org.apache.log4j.Logger;

import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.lifecycle.LifeCycleHelper;
import wt.lifecycle.LifeCycleManaged;
import wt.lifecycle.LifeCycleService;
import wt.lifecycle.LifeCycleTemplate;
import wt.lifecycle.PhaseTemplate;
import wt.lifecycle.State;
import wt.log4j.LogR;

import wt.query.QuerySpec;
import wt.query.SearchCondition;

import wt.org.WTPrincipalReference;

import wt.pds.StatementSpec;

import wt.project.Role;

import wt.util.WTException;

import wt.workflow.definer.ProcessDataInfo;
import wt.workflow.definer.WfAssignedActivityTemplate;
import wt.workflow.definer.WfProcessTemplate;
import wt.workflow.definer.WfVariableInfo;

import wt.workflow.engine.WfProcess;
import wt.workflow.engine.WfEngineHelper;

import wt.workflow.work.ActivityAssignmentLink;
import wt.workflow.work.Ballots;
import wt.workflow.work.WfAssignedActivity;
import wt.workflow.work.WfAssignment;
import wt.workflow.work.WfBallot;
import wt.workflow.work.WfRoleAssignee;

/**
 * Helper used for the Signatures section of the Change Notice Summary Report
 *
 * <BR>
 * <BR>
 * <B>Supported API: </B>false <BR>
 * <BR>
 * <B>Extendable: </B>false
 */
public class ReportSignatureHelper {
   /**
    * The name of the workflow variable that determines whether a given
    * WfAssignedActivity is a sign-off activity for the purposes of the
    * signature section of the Change Notice Summary Report
    */
   public static final String SIGN_OFF_VARIABLE_NAME = "windchillSignOffActivity";

   private static final Logger logger = LogR.getLogger("com.ptc.windchill.enterprise.change2.reports.ChangeNoticeReportSignatureHelper");

   /**
 * 
 */
protected Locale locale;

   static LifeCycleService lifeCycleService = LifeCycleHelper.service;



   /**
    * Constructs the ChangeNoticeReportSignatureHelper for a given locale.
    *
    * @param l
    *           The locale to use
    *
    * <BR>
    * <BR>
    * <B>Supported API: </B>false <BR>
    */
   public ReportSignatureHelper(Locale l) {
      locale = l;
   }



   /**
    * This method looks at all future lifecycle phases for a phase workflow. If
    * only one such phase workflow exists, then its template is returned.
    * Otherwise null is returned.
    *
    * <BR>
    * <BR>
    * <B>Supported API: </B>false
    */
   @SuppressWarnings("unchecked")
   protected WfProcessTemplate getFutureProcessTemplate(Persistable p) throws WTException {
      if (!(p instanceof LifeCycleManaged)) {
         return null;
      }

      LifeCycleManaged lcm = (LifeCycleManaged) p;

      Vector phaseTemplates = lifeCycleService.getPhaseTemplates((LifeCycleTemplate) lcm.getLifeCycleTemplate().getObject());
      ArrayList<WfProcessTemplate> workflowTemplates = new ArrayList<WfProcessTemplate>();

      State objectState = lcm.getState().getState();
      boolean pastCurrentPhase = false;

      for (Object obj : phaseTemplates) {
         PhaseTemplate pt = (PhaseTemplate) obj;

         if (!pastCurrentPhase) {
            State phaseState = pt.getPhaseState();

            if (phaseState.equals(objectState)) {
               pastCurrentPhase = true;
            }

            continue;
         }

         if (pt.getPhaseWorkflowId() != null) {
            workflowTemplates.add(pt.getPhaseWorkflowId().getProcessTemplate());
         }
      }

      if (workflowTemplates.size() == 1) {
         return workflowTemplates.get(0);
      }

      return null;
   }



   /**
    * Returns all the WfAssignedActivities for the passed in
    * <code>WfProcess</code>.
    *
    * <BR>
    * <BR>
    * <B>Supported API: </B>false
    */
   @SuppressWarnings("unchecked")
   protected Enumeration getAllAssignedActivities(WfProcess process) throws WTException {
      QuerySpec qs = new QuerySpec(WfAssignedActivity.class);
      qs.appendWhere(new SearchCondition(WfAssignedActivity.class, "parentProcessRef.key.id", SearchCondition.EQUAL,
                                         process.getPersistInfo().getObjectIdentifier().getId()), new int[] { 0 });
      return PersistenceHelper.manager.find((StatementSpec) qs);
   }



   /**
    * Returns all the WfAssignments for the passed in
    * <code>WfAssignedActivity</code>.
    *
    * <BR>
    * <BR>
    * <B>Supported API: </B>false
    */
   @SuppressWarnings("unchecked")
   protected Enumeration getAllAssignments(WfAssignedActivity wfa) throws WTException {
      return PersistenceHelper.manager.navigate(wfa, ActivityAssignmentLink.ASSIGNMENT_ROLE, ActivityAssignmentLink.class, true);
   }



   /**
    * Returns all the WfBallots for the passed in <code>WfAssignment</code>.
    *
    * <BR>
    * <BR>
    * <B>Supported API: </B>false
    */
   @SuppressWarnings("unchecked")
   protected Enumeration getBallots(WfAssignment assignment) throws WTException {
      return PersistenceHelper.manager.navigate(assignment, Ballots.BALLOT_ROLE, Ballots.class, true);
   }



   /**
    * Returns all the WfAssignedActivityTemplates for the passed in
    * <code>WfProcessTemplate</code>.
    *
    * <BR>
    * <BR>
    * <B>Supported API: </B>false
    */
   @SuppressWarnings("unchecked")
   protected Enumeration getAllAssignedActivityTemplates(WfProcessTemplate processTemplate) throws WTException {
      QuerySpec qs = new QuerySpec(WfAssignedActivityTemplate.class);
      qs.appendWhere(new SearchCondition(WfAssignedActivityTemplate.class, "parentTemplate.key.id", SearchCondition.EQUAL,
                                         processTemplate.getPersistInfo().getObjectIdentifier().getId()), new int[] { 0 });
      return PersistenceHelper.manager.find((StatementSpec) qs);
   }



   /**
    * Returns whether the WfAssignedActivityTemplate is a sign-off activity.
    *
    * <BR>
    * <BR>
    * <B>Supported API: </B>false
    */
   protected boolean isSignOffActivity(WfAssignedActivityTemplate template) throws WTException {
      ProcessDataInfo pdi = template.getContextSignature();

      WfVariableInfo varInfo = pdi.getVariableInfo(SIGN_OFF_VARIABLE_NAME);

      if (varInfo == null) {
         return false;
      }

      if (!("boolean".equals(varInfo.getTypeName()))) {
         return false;
      }

      Boolean boolValue = (Boolean) varInfo.getDefaultValue();

      if (boolValue.booleanValue()) {
         return true;
      }

      return false;
   }



   /**
    * This method creates the Info*Engine elements and adds them to the output
    * Group.
    *
    * <BR>
    * <BR>
    * <B>Supported API: </B>false
    */
   protected void addElement(String signator, String role, String vote, Timestamp timestamp, Group output) throws WTException {
      if (output != null) {
         Element elem = new Element();
         elem.addAtt(new Att("SIGNATOR", signator));
         elem.addAtt(new Att("ROLE", role));
         elem.addAtt(new Att("VOTE", vote));
         elem.addAtt(new Att("TIMESTAMP", timestamp));
         output.addElement(elem);
      }
   }



   /**
    * This method will attempt to gather signatures from all active and historic
    * workflow processes for the passed in persistable. It will fill the passed
    * in group with elements representing the ballots cast in the appropriate
    * assigned activities. If there are no active or historic workflow processes
    * associated with the persistable, then we look for workflows associated
    * with a future phase of the lifecycle of the object. If exactly one such
    * workflow is found we process it for roles that will be required to sign
    * off.
    *
    * <BR>
    * <BR>
    * <B>Supported API: </B>false
    *
    * @throws NullPointerException
    *            if either changeNotice or output is null.
    */
   @SuppressWarnings("unchecked")
   public void getSignatures(Persistable changeNotice, Group output) throws WTException {
      if (changeNotice == null || output == null) {
         throw new NullPointerException();
      }
      if (logger.isDebugEnabled()) {
          logger.debug("Getting signatures for [" + changeNotice.getPersistInfo().getObjectIdentifier() + "]");
      }

      Enumeration processes = WfEngineHelper.service.getAssociatedProcesses(changeNotice, null, null);

      if (!processes.hasMoreElements()) {
         logger.debug("no active or historic processes. Looking for a WfProcessTemplate associated with a future lifecycle phase.");
         WfProcessTemplate processTemplate = getFutureProcessTemplate(changeNotice);

         if (processTemplate != null) {
            logger.debug("found a single future WfProcessTemplate.");

            Enumeration activityTemplatesEnum = getAllAssignedActivityTemplates(processTemplate);
            List<WfAssignedActivityTemplate> allTemplates = new ArrayList<WfAssignedActivityTemplate>();

            while (activityTemplatesEnum.hasMoreElements()) {
               allTemplates.add((WfAssignedActivityTemplate) activityTemplatesEnum.nextElement());
            }

            processNotYetStartedActivities(allTemplates, null, output);
         }

         return;
      }

      while (processes.hasMoreElements()) {
         logger.debug("found active or historic processes. Gathering signatures from each.");
         WfProcess process = (WfProcess) processes.nextElement();
         gatherSignaturesForProcess(process, output);
      }
   }



   /**
    * This method gathers signatures for a given WfProcess. It first looks at
    * all the completed and running activities gathering signatures. It then
    * looks at activities that have not yet started.
    *
    * <BR>
    * <BR>
    * <B>Supported API: </B>false
    */
   @SuppressWarnings("unchecked")
   protected void gatherSignaturesForProcess(WfProcess process, Group output) throws WTException {
      if (process == null) {
         logger.warn("Process passed to gatherSignaturesForProcess was null");
         return;
      }

      WfProcessTemplate processTemplate = (WfProcessTemplate) process.getTemplate().getObject();
      Enumeration activityTemplatesEnum = getAllAssignedActivityTemplates(processTemplate);
      List<WfAssignedActivityTemplate> allTemplates = new ArrayList<WfAssignedActivityTemplate>();

      while (activityTemplatesEnum.hasMoreElements()) {
         allTemplates.add((WfAssignedActivityTemplate) activityTemplatesEnum.nextElement());
      }

      // Process all running and completed Assigned Activities
      Enumeration assignedActivities = getAllAssignedActivities(process);

      while (assignedActivities.hasMoreElements()) {
         WfAssignedActivity activity = (WfAssignedActivity) assignedActivities.nextElement();
         processActivity(activity, allTemplates, output);
      }

      // The above code has removed all running/completed activity templates
      // from allTemplates
      processNotYetStartedActivities(allTemplates, process, output);
   }



   /**
    * This method does three things
    * <ol>
    * <li>Checks to make sure this is a sign off activity
    * <li>Generates a map Role to RoleRequired
    * <li>Iterates through the assignments for the activity calling
    * processActivityAssignment() for each one
    * </ol>
    *
    * <BR>
    * <BR>
    * <B>Supported API: </B>false
    */
   @SuppressWarnings("unchecked")
   protected void processActivity(WfAssignedActivity activity, List<WfAssignedActivityTemplate> allTemplates, Group output)
                                                                                                                           throws WTException {
      WfAssignedActivityTemplate template = (WfAssignedActivityTemplate) activity.getTemplate().getObject();
      allTemplates.remove(template);

      if (logger.isDebugEnabled()) {
          logger.debug(" looking at template [" + template.getPersistInfo().getObjectIdentifier() + "]");
      }

      //Molla
	  /*if (!isSignOffActivity(template)) {
         logger.debug(" template was not a signoff activity");
         return;
      }
      */
      logger.debug(" template was a signoff activity");

      boolean activityCompleted = activity.isComplete();

      Enumeration roleAssignees = template.getRoleAssignees();
      HashMap<String, Boolean> roleRequiredMap = new HashMap<String, Boolean>();

      while (roleAssignees.hasMoreElements()) {
         WfRoleAssignee wfra = (WfRoleAssignee) roleAssignees.nextElement();
         roleRequiredMap.put(wfra.getRole().getDisplay(locale), wfra.isRequired());
      }

      Enumeration assignments = getAllAssignments(activity);

      while (assignments.hasMoreElements()) {
         WfAssignment assignment = (WfAssignment) assignments.nextElement();
         processActivityAssignment(assignment, roleRequiredMap, activityCompleted, output);
      }
   }



   /**
    * This method does three things:
    * <ol>
    * <li>Gets the localized role name for this assignment
    * <li>Constructs a Ballot Map of Voter->Vote
    * <li>Iterates over the assignees calling processAssignmentAssignee() for
    * each one
    * </ol>
    * <BR>
    * <BR>
    * <B>Supported API: </B>false
    */
   @SuppressWarnings("unchecked")
   protected void processActivityAssignment(WfAssignment assignment, Map<String, Boolean> roleRequiredMap, boolean activityCompleted,
                                            Group output) throws WTException {
      String role = null;
      boolean roleRequired = false;

      if (logger.isDebugEnabled()) {
          logger.debug("  looking at assignment [" + assignment + "]");
      }

      if (assignment.getAssignee() instanceof WfRoleAssignee) {
         role = ((WfRoleAssignee) assignment.getAssignee()).getRole().getDisplay(locale);

         if (roleRequiredMap.containsKey(role)) {
            roleRequired = roleRequiredMap.get(role);
         }
      }
      else {
         role = Role.toRole("ASSIGNEE").getDisplay(locale);
      }

      Enumeration ballots = getBallots(assignment);
      HashMap<WTPrincipalReference, WfBallot> ballotMap = new HashMap<WTPrincipalReference, WfBallot>();

      while (ballots.hasMoreElements()) {
         WfBallot ballot = (WfBallot) ballots.nextElement();
         ballotMap.put(ballot.getVoter(), ballot);
      }

      boolean assignmentCompleted = assignment.isComplete();

      Enumeration assignees = assignment.getPrincipals().elements();

      while (assignees.hasMoreElements()) {
         WTPrincipalReference pref = (WTPrincipalReference) assignees.nextElement();

         processAssignmentAssignee(pref, ballotMap, role, roleRequired, activityCompleted, assignmentCompleted, output);
      }
   }



   /**
    * This method determines whether or not this particular assignee should be
    * included in the Signature table. If so, it adds them as an entry to the
    * InfoEngine group output.
    *
    * <BR>
    * <BR>
    * <B>Supported API: </B>false
    */
   @SuppressWarnings("unchecked")
   protected void processAssignmentAssignee(WTPrincipalReference pref, Map<WTPrincipalReference, WfBallot> ballotMap, String role,
                                            boolean roleRequired, boolean activityCompleted, boolean assignmentCompleted, Group output)
                                                                                                                                     throws WTException {
      if (logger.isDebugEnabled()) {
          logger.debug("   looking at assignee [" + pref.getDisplayName() + "]");
      }

      String user = pref.getDisplayName();
      String vote = null;
      Timestamp timestamp = null;

      if (ballotMap.containsKey(pref)) {
         WfBallot ballot = ballotMap.get(pref);
         Vector choices = ballot.getEventList();

         if (choices.size() > 0) {
            vote = choices.get(0).toString();
            timestamp = ballot.getTimestamp();
         }
      }

      if (activityCompleted && !roleRequired && vote == null) {
         logger.debug("   skipping assignee as they didn't vote and this activity is complete");
         return;
      }

      if (assignmentCompleted && vote == null) {
         logger.debug("  skipping assignee as they didn't vote and this assignment is complete.");
         return;
      }

      if (logger.isDebugEnabled()) {
          logger.debug("   adding vote for assignee [" + pref.getDisplayName() + "] to the output group");
      }
      addElement(user, role, vote, timestamp, output);
   }



   /**
    * This method looks at the remaining activity templates and generates a row
    * for each required role for each activity template. If there are already
    * people assigned to this role it includes an entry for each person.
    *
    * <BR>
    * <BR>
    * <B>Supported API: </B>false
    */
   @SuppressWarnings("unchecked")
   protected void processNotYetStartedActivities(List<WfAssignedActivityTemplate> unstartedTemplates, WfProcess process, Group output)
                                                                                                                                      throws WTException {
      logger.debug(" looking at activities that have not yet started.");

      for (WfAssignedActivityTemplate template : unstartedTemplates) {
         if (logger.isDebugEnabled()) {
            logger.debug("  looking at template [" + template.getPersistInfo().getObjectIdentifier() + "]");
         }

       //Molla       
	   /*        
		if (!isSignOffActivity(template)) {
            logger.debug(" template is not a signoff activity");
            continue;
         }
        */
         logger.debug(" template is a signoff activity.");

         Enumeration roleAssignees = template.getRoleAssignees();

         while (roleAssignees.hasMoreElements()) {
            WfRoleAssignee wfra = (WfRoleAssignee) roleAssignees.nextElement();
            String role = wfra.getRole().getDisplay(locale);
            if (logger.isDebugEnabled()) {
                logger.debug(" looking at role [" + role + "]  isRequired? [" + wfra.isRequired() + "]");
            }

            if (!wfra.isRequired()) {
               logger.debug(" skipping role, it's not required.");
               continue;
            }

            Enumeration principals = null;

            if (process != null) {
               principals = process.getPrincipals(wfra.getRole());
            }

            if (principals == null || !principals.hasMoreElements()) {
               logger.debug(" no principals found for role, adding an entry for just the role");
               addElement(null, role, null, null, output);
            }
            else {
               logger.debug(" principals found for role, adding an entry per principal");

               while (principals.hasMoreElements()) {
                  WTPrincipalReference pref = (WTPrincipalReference) principals.nextElement();
                  String signator = pref.getDisplayName();
                  if (logger.isDebugEnabled()) {
                      logger.debug("  adding entry for [" + signator + "]");
                  }
                  addElement(signator, role, null, null, output);
               }
            }
         }
      }
   }
}
