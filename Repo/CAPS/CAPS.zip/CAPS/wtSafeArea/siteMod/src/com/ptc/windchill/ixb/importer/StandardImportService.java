/* bcwti
 *
 * Copyright (c) 2010 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */
package com.ptc.windchill.ixb.importer;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.ptc.core.lwc.common.view.AttributeDefinitionReadView;
import com.ptc.generic.iba.AttributesUtil;
import com.ptc.windchill.ixb.importer.part.PartSheetElementBuilder;
import com.ptc.windchill.ixb.importer.xls.XlsSheetParser;
import com.ptc.windchill.ixb.util.ImportXlsHelper;

import ext.kb.util.IBAHelper;
import ext.kb.util.KBConstants;
import ext.kb.util.KBTeamUtils;
import wt.access.AccessControlHelper;
import wt.access.AccessPermission;
import wt.admin.AdminDomainRef;
import wt.conflict.ConflictServerHelper;
import wt.content.ApplicationData;
import wt.content.ContentHelper;
import wt.content.ContentRoleType;
import wt.content.ContentServerHelper;
import wt.fc.ObjectIdentifier;
import wt.fc.ObjectReference;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceManagerEvent;
import wt.fc.QueryResult;
import wt.fc.collections.CollectionsHelper;
import wt.fc.collections.WTArrayList;
import wt.fc.collections.WTCollection;
import wt.fc.collections.WTKeyedHashMap;
import wt.fc.collections.WTKeyedMap;
import wt.inf.container.WTContainerHelper;
import wt.inf.container.WTContainerRef;
import wt.inf.team.ContainerTeamManaged;
import wt.ixb.actor.actions.IxbActionsHelper;
import wt.ixb.clientAccess.IXBExpImpStatus;
import wt.ixb.publicforapps.Importer;
import wt.ixb.publicforapps.IxbHelper;
import wt.ixb.publicforhandlers.IxbHndHelper;
import wt.log4j.LogR;
import wt.method.MethodContext;
import wt.notify.DistributionList;
import wt.notify.WTDistributionList;
import wt.notify.templateProcessor.EmailTemplateNotificationRequest;
import wt.org.WTPrincipal;
import wt.org.WTPrincipalReference;
import wt.org.WTUser;
import wt.ownership.OwnershipHelper;
import wt.part.WTPart;
import wt.pds.StatementSpec;
import wt.pom.Transaction;
import wt.query.QuerySpec;
import wt.queue.ProcessingQueue;
import wt.queue.QueueEntry;
import wt.queue.QueueHelper;
import wt.queue.StandardQueueService;
import wt.services.ManagerException;
import wt.services.ManagerService;
import wt.services.ManagerServiceFactory;
import wt.services.StandardManager;
import wt.services.applicationcontext.UnableToCreateServiceException;
import wt.services.applicationcontext.implementation.DefaultServiceProvider;
import wt.session.SessionContext;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.WTProperties;
import wt.util.WTPropertyVetoException;
import wt.util.WTRuntimeException;
import wt.wvs.VisualizationHelperFactory;
import wt.wvs.VisualizationHelperIfc;

/**
 *
 * <p>
 * Use the <code>newStandardImportService</code> static factory method(s), not
 * the <code>StandardImportService</code> constructor, to construct instances of
 * this class. Instances must be constructed using the static factory(s), in
 * order to ensure proper initialization of the instance.
 * <p>
 *
 *
 * <BR>
 * <BR>
 * <B>Supported API: </B>false <BR>
 * <BR>
 * <B>Extendable: </B>false
 *
 * @version 1.0
 **/
public class StandardImportService extends StandardManager implements ImportService, ImportServerService {
	private static final String RESOURCE = "com.ptc.windchill.ixb.importer.importerResource";

	private static final String CLASSNAME = StandardImportService.class.getName();

	private static WTKeyedMap canceledJobToPrincipalMap = CollectionsHelper
			.synchronizedWTKeyedMap(new WTKeyedHashMap());

	private static String IXB_TEMP_DIRECTORY;

	private static StandardQueueService queueManager;

	private static final String DEFAULT_SENDER_EMAIL;

	private static final String DEFAULT_ENCODING = "UTF-8";

	private static final Logger logger = LogR.getLogger(CLASSNAME);

	private static String xlsFileName = "";

	private static int importChunkSize;
	private static final int DEFAULT_CANCELLABLE_CHUNK_SIZE = 5;
	private static final String CANCELLABLE_CHUNK_SIZE_PROPERTY_KEY = "com.ptc.windchill.ixb.importer.cancellableChunkSize";
	private static final String IMPORT_SEQUENCE = "com.ptc.windchill.ixb.importer.ImportSequence";

	static {
		try {
			WTProperties props = WTProperties.getLocalProperties();
			DEFAULT_SENDER_EMAIL = props.getProperty("wt.notify.notificationSenderEmail");
		} catch (Throwable t) {
			logger.error("Error initializing " + StandardImportService.class.getName(), t);
			throw new ExceptionInInitializerError(t);
		}
	}

	/**
	 * Returns the conceptual (modeled) name for the class.
	 *
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 *
	 * @deprecated
	 *
	 * @return String
	 **/
	public String getConceptualClassname() {
		return CLASSNAME;
	}

	/**
	 *
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 *
	 * @exception wt.services.ManagerException
	 **/
	@Override
	protected synchronized void performStartupProcess() throws ManagerException {
		super.performStartupProcess();
	}

	/**
	 * This method is intented to be executed from a queue. Performs spreadsheet
	 * import as specified in the import job.
	 *
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 *
	 * @param jobId
	 * @return ImportJob
	 * @exception wt.util.WTException
	 **/
	public static final ImportJob importSpreadsheet(ObjectIdentifier jobId, ImportJobArgsBean importJobArgsBean)
			throws WTException {
		logger.debug("importSpreadsheet started.");
		ImportJob job = null;
		try {
			job = (ImportJob) PersistenceHelper.manager.refresh(jobId);
			if (job == null) {
				throw new WTException(RESOURCE, importerResource.FATAL_ERROR_IMPORT_JOB_FAILED_REFRESH,
						new Object[] { Long.valueOf(jobId.getId()) });
			}

			// set job status
			job.getSpec().setPreview(false);
			job.setStatus(ImportJobStatus.RUNNING);
			job = (ImportJob) PersistenceHelper.manager.save(job);
			job.setImportJobArgsBean(importJobArgsBean);

			try {
				job = doPreviewOrImport(job);

				// job completed
				if (job.getStatus() == ImportJobStatus.COMPLETED || job.getStatus() == ImportJobStatus.PARTIAL) {
					sendImportJobEvent(job, ImportJobEvent.COMPLETED);
				} else {
					sendImportJobEvent(job, ImportJobEvent.FAILED);
				}
			} catch (ImportCanceledException e) {
				// job canceled
				job.setStatus(ImportJobStatus.CANCELED);
				canceledJobToPrincipalMap.remove(job);
				sendImportJobEvent(job, ImportJobEvent.CANCELED);
			} catch (Exception e) {
				// job failed
				job.setStatus(ImportJobStatus.FAILED);
				sendImportJobEvent(job, ImportJobEvent.FAILED);
			} finally {
				ImportJob refreshedJobObj = (ImportJob) PersistenceHelper.manager.refresh(job);
				logger.debug("job status " + job.getStatus().toString());
				logger.debug("refreshedJobObj status " + refreshedJobObj.getStatus().toString());
				if ((refreshedJobObj.getStatus() == ImportJobStatus.RUNNING)
						&& (refreshedJobObj.getStatus() != ImportJobStatus.CANCELED)) {
					job = (ImportJob) PersistenceHelper.manager.save(job);
				} else if ((refreshedJobObj.getStatus() == ImportJobStatus.COMPLETED)
						&& (refreshedJobObj.getStatus() != ImportJobStatus.CANCELED)) {
					job = (ImportJob) PersistenceHelper.manager.save(refreshedJobObj);
				}
			}
			return job;
		} catch (WTPropertyVetoException e) {
			throw new WTException(e);
		}
	}

	/**
	 * Default factory for the class.
	 *
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>false
	 *
	 * @return StandardImportService
	 * @exception wt.util.WTException
	 **/
	public static StandardImportService newStandardImportService() throws WTException {
		StandardImportService instance = new StandardImportService();
		instance.initialize();
		return instance;
	}

	@Override
	public ImportJob createImportJob(ImportSpec spec) throws WTException {
		logger.debug("StandardImportService.createImportJob()...started");
		Transaction trx = new Transaction();
		logger.debug("The transaction description: " + trx.getDescription());
		try {
			trx.start();
			ImportJob job = ImportJob.newImportJob();
			job.setImportJobArgsBean(new ImportJobArgsBean());
			WTContainerRef containerRef = spec.getContainerRef();
			job.setContainerReference(containerRef);
			String filename = spec.getFilename();
			int pathSeparatorIndex = filename.lastIndexOf("/");
			pathSeparatorIndex = pathSeparatorIndex >= 0 ? pathSeparatorIndex : filename.lastIndexOf("\\");
			if (pathSeparatorIndex >= 0) {
				filename = filename.substring(pathSeparatorIndex + 1);
			}
			spec.setFilename(filename);
			// set the locale
			// spec.setLocale(SessionHelper.getLocale());
			job.setSpec(spec);
			job.setStatus(ImportJobStatus.DEFINING);
			OwnershipHelper.setOwner(job, SessionHelper.manager.getPrincipal());

			// WTContainer container = containerRef.getReferencedContainer();
			AdminDomainRef domainRef = containerRef.getReferencedContainer().getDefaultDomainReference();
			job.setDomainRef(domainRef);

			job = (ImportJob) PersistenceHelper.manager.store(job);
			logger.debug("job persisted: " + job);

			trx.commit();
			trx = null;
			return job;
		} catch (Exception e) {
			e.printStackTrace();
			throw new WTException(e);
		} finally {
			if (trx != null) {
				logger.debug("transaction rolled back");
				trx.rollback();
			}
			logger.debug("StandardImportService.createImportJob()...ended");
		}
	}

	@Override
	public synchronized void cancelImportJob(ObjectIdentifier jobOid) throws WTException {
		ImportJob job = (ImportJob) PersistenceHelper.manager.refresh(jobOid);
		WTPrincipal principal = SessionHelper.manager.getPrincipal();
		WTPrincipal owner = OwnershipHelper.getOwner(job);
		// make sure the principal is either the owner of or
		// has administrative permission to the import job
		if (!principal.equals(owner)) {
			AccessControlHelper.manager.checkAccess(job, AccessPermission.ADMINISTRATIVE);
		}

		ImportJobStatus status = job.getStatus();

		if (status.equals(ImportJobStatus.COMPLETED) || status.equals(ImportJobStatus.PARTIAL)) {
			throw new ImportException(RESOURCE, importerResource.MSG_CANNOT_CANCEL_COMPLETED_JOB,
					new Object[] { job.getDisplayIdentity() });
		}

		if (status.equals(ImportJobStatus.CANCELED)) {
			throw new ImportException(RESOURCE, importerResource.MSG_CANNOT_CANCEL_CANCELED_JOB,
					new Object[] { job.getDisplayIdentity() });
		}

		if (status.equals(ImportJobStatus.FAILED)) {
			throw new ImportException(RESOURCE, importerResource.MSG_CANNOT_CANCEL_FAILED_JOB,
					new Object[] { job.getDisplayIdentity() });
		}

		// running job, cancel
		if (status.equals(ImportJobStatus.RUNNING)) {
			canceledJobToPrincipalMap.put(job, principal);
			try {
				job.setStatus(ImportJobStatus.CANCELED);
				canceledJobToPrincipalMap.remove(job);
				sendImportJobEvent(job, ImportJobEvent.CANCELED);
				job = (ImportJob) PersistenceHelper.manager.save(job);
			} catch (WTPropertyVetoException e) {
				e.printStackTrace();
			}
		}

		// pending job, delete queue entry
		if (status.equals(ImportJobStatus.PENDING)) {
			canceledJobToPrincipalMap.put(job, principal);
		}
	}

	@Override
	public void deleteImportJob(ObjectIdentifier jobOid) throws WTException {
		ImportJob job = (ImportJob) PersistenceHelper.manager.refresh(jobOid);
		ImportJobStatus status = job.getStatus();
		if (status.equals(ImportJobStatus.RUNNING)) {
			throw new ImportException("A currently running job cannot be deleted.");
		}
		// TODO: what kind of permission is required here?
		// should we deal with deleting the queue entry?
		PersistenceHelper.manager.delete(job);
	}

	@Override
	public ImportJob doPreview(ImportJob job) throws WTException {
		logger.debug("StandardImportService.doPreview()...started");
		try {
			if (job == null) {
				throw new WTException(RESOURCE, importerResource.FATAL_ERROR_IMPORT_PREVIEW_JOB_NULL, new Object[] {});
			}
			job.getSpec().setPreview(true);
			job.setStatus(ImportJobStatus.RUNNING);
			job = (ImportJob) PersistenceHelper.manager.save(job);
			job = doPreviewOrImport(job);
		} catch (WTPropertyVetoException wtpvEx1) {
			throw new WTException(wtpvEx1);
		} catch (Exception e) {
			// job failed
			e.printStackTrace();
			try {
				job.setStatus(ImportJobStatus.FAILED);
			} catch (WTPropertyVetoException wtpvEx2) {
				throw new WTException(wtpvEx2);
			}
		} finally {
			ImportJob refreshedJobObj = (ImportJob) PersistenceHelper.manager.refresh(job);
			if (!(refreshedJobObj.getStatus() == ImportJobStatus.CANCELED)) {
				job = (ImportJob) PersistenceHelper.manager.save(job);
			}
		}
		return job;
	}

	@Override
	public ImportJob doImport(ImportJob job) throws WTException {
		logger.debug("StandardImportService.doImport()...started");

		if (job.getSpec().isPreviewStep()) {
			try {
				job.getSpec().setPreviewStep(true);
			} catch (WTPropertyVetoException e) {
				e.printStackTrace();
			}
			PersistenceHelper.manager.modify(job);
			importSpreadsheet(job.getPersistInfo().getObjectIdentifier(), job.getImportJobArgsBean());
		} else {
			job = queueImportJob(job);
		}

		logger.debug("StandardImportService.doImport()...ended");
		return job;
	}

	@Override
	public WTCollection getImportJobs(WTContainerRef containerRef) throws WTException {
		throw new WTException("not implemented yet.");
	}

	@Override
	public WTCollection getAllImportJobs() throws WTException {
		WTCollection importJobList = new WTArrayList();
		QuerySpec qs = new QuerySpec(ImportJob.class);
		logger.trace("getAllImportJobs() SQL: " + qs.toString());
		QueryResult qr = PersistenceHelper.manager.find((StatementSpec) qs);
		if (qr.size() > 0) {
			logger.trace("Query found " + qr.size() + " matching import jobs.");
			importJobList.addAll(qr);
		} else {
			return null;
		}
		return importJobList;
	}

	@Override
	public synchronized void checkJobCancelation(ImportJob job) throws WTException {
		if (canceledJobToPrincipalMap.containsKey(job)) {
			WTPrincipal principal = (WTPrincipal) canceledJobToPrincipalMap.get(job);
			throw new ImportCanceledException(RESOURCE, importerResource.MSG_JOB_CANCELED_BY_USER,
					new Object[] { job.getDisplayIdentity(), principal.getDisplayIdentity() });
		}
	}

	@Override
	public void processPreInsertEvent(PersistenceManagerEvent event) throws WTException {
		WTCollection jobs = ((WTCollection) event.getEventTarget()).subCollection(ImportJob.class);
		if (!jobs.isEmpty()) {
			processPreInsertForImportJob(jobs);
		}
	}

	@Override
	public void registerEvents(ManagerService managerService) {
		managerService.addEventBranch(ImportJobEvent.generateEventKey(ImportJobEvent.CREATED),
				ImportJobEvent.class.getName(), ImportJobEvent.CREATED);
		managerService.addEventBranch(ImportJobEvent.generateEventKey(ImportJobEvent.SUBMITTED),
				ImportJobEvent.class.getName(), ImportJobEvent.SUBMITTED);
		managerService.addEventBranch(ImportJobEvent.generateEventKey(ImportJobEvent.STARTED),
				ImportJobEvent.class.getName(), ImportJobEvent.STARTED);
		managerService.addEventBranch(ImportJobEvent.generateEventKey(ImportJobEvent.COMPLETED),
				ImportJobEvent.class.getName(), ImportJobEvent.COMPLETED);
		managerService.addEventBranch(ImportJobEvent.generateEventKey(ImportJobEvent.CANCELED),
				ImportJobEvent.class.getName(), ImportJobEvent.CANCELED);
		managerService.addEventBranch(ImportJobEvent.generateEventKey(ImportJobEvent.FAILED),
				ImportJobEvent.class.getName(), ImportJobEvent.FAILED);
	}

	/**
	 * checks whether an import job was canceled by user
	 */
	private synchronized static void checkJobCancelation(ImportJob job, WTPrincipal user)
			throws ImportCanceledException {
		if (canceledJobToPrincipalMap.containsKey(job)) {
			WTPrincipal principal = (WTPrincipal) canceledJobToPrincipalMap.get(job);
			throw new ImportCanceledException(RESOURCE, importerResource.MSG_JOB_CANCELED_BY_USER,
					new Object[] { job.getDisplayIdentity(), principal.getDisplayIdentity() });
		}
	}

	/**
	 * Fires an import job event with the given event key
	 */
	private static void sendImportJobEvent(ImportJob job, String eventType) throws WTException {
		ImportJobEvent event = new ImportJobEvent(eventType, job);
		if (logger.isTraceEnabled())
			logger.trace("send ImportJobEvent: job = " + job.getDisplayIdentity() + " eventType = " + eventType);
		WTUser sender = (WTUser) SessionContext.getEffectivePrincipal();
		if (sender == null)
			sender = (WTUser) SessionHelper.getPrincipal();
		if (logger.isTraceEnabled())
			logger.trace("sender = " + sender);
		WTDistributionList list = new WTDistributionList();
		list.addUser(sender);
		EmailTemplateNotificationRequest request = getNotificationRequest(event, list);
		request.setEventInitiator(sender.getFullName());
		request.setSender(getSenderEmailAddress(sender));
		request.send();
	}

	/*
	 * Compose EmailTemplateNotificationRequest
	 */
	public static EmailTemplateNotificationRequest getNotificationRequest(ImportJobEvent event,
			DistributionList distList) throws WTException {
		ObjectReference importJobRef = ObjectReference
				.newObjectReference(((ImportJob) event.getEventTarget()).getPersistInfo().getObjectIdentifier());
		EmailTemplateNotificationRequest notificationRequest = EmailTemplateNotificationRequest
				.newEmailTemplateNotificationRequest(distList, importJobRef, false);
		notificationRequest.setEvent(event.getEventType());
		return notificationRequest;
	}

	/*
	 * Get sender's e-mail address
	 */
	private static String getSenderEmailAddress(WTUser sender) throws WTException {
		String emailAddress = null;
		if (sender != null)
			emailAddress = sender.getEMail();
		if (emailAddress == null)
			emailAddress = DEFAULT_SENDER_EMAIL;
		if (logger.isTraceEnabled())
			logger.trace("Sender e-mail address = " + emailAddress);
		return emailAddress;
	}

	/**
	 * Uploads some fake contents to an import job as primary/secondary content,
	 * with a delay
	 */
	private static ImportJob uploadFakeContent(ImportJob job, String fakeFile, boolean isPrimary, long delay)
			throws WTException {
		Transaction trx = new Transaction();

		try {
			ApplicationData appData = ApplicationData.newApplicationData(job);
			String filename = new File(fakeFile).getName();
			appData.setFileName(filename);
			appData.setUploadedFromPath(fakeFile);
			appData.setDescription("Fake File: " + fakeFile);
			appData.setRole(isPrimary ? ContentRoleType.PRIMARY : ContentRoleType.SECONDARY);
			appData = ContentServerHelper.service.updateContent(job, appData, fakeFile);

			job = (ImportJob) PersistenceHelper.manager.refresh(job);
			trx.commit();
			trx = null;

			if (delay > 0L) {
				try {
					Thread.sleep(delay);
				} catch (InterruptedException e) {
					// do nothing
				}
			}
			return job;
		} catch (Exception e) {
			throw (e instanceof WTException) ? (WTException) e : new WTException(e);
		} finally {
			if (trx != null) {
				trx.rollback();
			}
		}
	}

	/**
	 * Returns the import job queue. Creates one if not exists
	 */
	private static ProcessingQueue getImportJobQueue() throws WTException {
		String queueName = ImportHelper.getImportJobQueueName();
		ProcessingQueue importJobQueue = QueueHelper.manager.getQueue(queueName);
		if (importJobQueue == null) {
			try {
				logger.debug("creating/starting \"" + queueName + "\"");
				importJobQueue = getQueueManager().createQueue(queueName, true/* started */);
			} finally {
				if (importJobQueue == null) {
					throw new WTException(RESOURCE, importerResource.FATAL_ERROR_IMPORT_JOB_QUEUE_CREATION_FAILURE,
							new Object[] { queueName });
				}

			}
		}
		return importJobQueue;
	}

	/**
	 * Executes the import job in an queue entry
	 */
	private ImportJob queueImportJob(ImportJob job) throws WTException {
		logger.debug("queueImportJob started");
		Transaction trx = new Transaction();
		try {
			trx.start();

			WTPrincipal administrator = SessionHelper.manager.getAdministrator();
			WTPrincipal previous = SessionContext.setEffectivePrincipal(administrator);
			WTPrincipal myself = SessionHelper.getPrincipal();

			ProcessingQueue queue = getImportJobQueue();
			logger.debug("queue = " + queue);
			job.setStatus(ImportJobStatus.PENDING);
			job = (ImportJob) PersistenceHelper.manager.save(job);

			Class[] argTypes = new Class[] { ObjectIdentifier.class, ImportJobArgsBean.class };
			Object[] args = new Object[] { job.getPersistInfo().getObjectIdentifier(), job.getImportJobArgsBean() };

			QueueEntry queueEntry = null;
			try {
				queueEntry = queue.addEntry(myself, "importSpreadsheet", this.getClass().getName(), argTypes, args);

				// updates the job with the queue entry
				JobToQueueEntryLink link = JobToQueueEntryLink.newJobToQueueEntryLink(queueEntry, job);
				PersistenceHelper.manager.save(link);

			} finally {
				SessionContext.setEffectivePrincipal(previous);
			}

			logger.debug("Admin = " + administrator);
			logger.debug("Current = " + myself);

			trx.commit();
			trx = null;
			return job;
		} catch (WTPropertyVetoException e) {
			throw new WTException(e);
		} finally {
			if (trx != null) {
				trx.rollback();
			}
		}
	}

	/**
	 * Finds StandardQueueService - it should always be available barring some
	 * extrordinary situations
	 */
	private static StandardQueueService getQueueManager() throws WTException {
		if (queueManager == null) {
			queueManager = (StandardQueueService) ManagerServiceFactory.getDefault()
					.getManager(wt.queue.StandardQueueService.class);
		}

		return queueManager;
	}

	/**
	 * Returns the import source in the ImportJob as an InputStream The import
	 * source is the sole primary content of the content holder
	 */
	private static InputStream getImportSourceStream(ImportJob job) throws WTException {
		if (job == null) {
			throw new WTException(RESOURCE, importerResource.FATAL_ERROR_IMPORT_JOB_NULL, new Object[] {});
		}

		QueryResult qr = ContentHelper.service.getContentsByRole(job, ContentRoleType.PRIMARY);
		if (qr == null || !qr.hasMoreElements()) {
			throw new WTException(RESOURCE, importerResource.FATAL_ERROR_PRIMARY_CONTENT_NOT_FOUND, new Object[] {});
		}
		ApplicationData ad = (ApplicationData) qr.nextElement();
		return ContentServerHelper.service.findContentStream(ad);
	}

	private static void validateFileNameAndFormat(String fileName, String formatValue) throws WTException {
		if ((null == fileName || "".equals(fileName)) && (null == formatValue || "".equals(formatValue)))
			throw new WTException(RESOURCE, importerResource.ERROR_FILE_NAME_AND_FORMAT_NOT_SPECIFIED, new Object[] {});
		else if ((null == fileName || "".equals(fileName)) && (null != formatValue || !"".equals(formatValue)))
			throw new WTException(RESOURCE, importerResource.ERROR_FILE_NAME_NOT_SPECIFIED, new Object[] {});
		else if ((null != fileName || !"".equals(fileName)) && (null == formatValue || "".equals(formatValue)))
			throw new WTException(RESOURCE, importerResource.ERROR_FILE_FORMAT_NOT_SPECIFIED, new Object[] {});
		else
			logger.debug("File name is <" + fileName + "> and file format is <" + formatValue + ">");
	}

	private synchronized static File getUniqueLogFile(ImportJob job) throws WTException {
		// 1. make temp dir (like C:\TEMP\IxbLog)
		String tmpDir = null;
		try {
			if (IXB_TEMP_DIRECTORY == null) {
				WTProperties prop = WTProperties.getServerProperties();
				tmpDir = prop.getProperty("wt.temp");
				IXB_TEMP_DIRECTORY = tmpDir;
			} else {
				tmpDir = IXB_TEMP_DIRECTORY;
			}
			String prefix = "IxbLog";
			tmpDir += File.separator + prefix;
			File dir = new File(tmpDir);
			dir.mkdirs();
			// 2. make file in log dir
			String extension = ".log";
			String fileName = "ImportJob-" + job.getNumber() + "-" + System.currentTimeMillis() + extension;
			File file = new File(tmpDir, fileName);
			return file;
		} catch (IOException ioEx) {
			throw new WTException(ioEx);
		}
	}

	private static Importer getIxbImporter(ImportJob job, ImportXlsHandler handler) throws WTException {
		String dtd = IxbHelper.STANDARD_DTD;
		String ruleFileName = null;
		String xslPolicyFileName = null;
		String containerMappingFileName = null;
		// String actor = ImportHndHelper.getIxbImportActor(importAction);
		String actor = IxbActionsHelper.NEW_ITERATION;
		if (job.getSpec().getAction().equals(ImportAction.UPDATE_CHECKED_OUT_PARTS)) {
			actor = IxbActionsHelper.UPDATE_IN_PLACE_FOR_XLS;
		}
		boolean overrideConflicts = true;
		boolean validate = false;
		try {
			Importer importer = IxbHelper.newImporter(handler, job.getSpec().getContainerRef(), dtd, ruleFileName,
					xslPolicyFileName, containerMappingFileName, actor, new Boolean(overrideConflicts),
					new Boolean(validate));
			importer.setIgnoreSignalPersistenceOf(false);
			importer.setCheckTypeConstraints(true);
			importer.setPopulateMissingTypeAttributess(false);
			return importer;
		} catch (WTPropertyVetoException e) {
			throw new WTException(e);
		}
	}

	private static ImportXlsHandler getHandler(ImportJob job, PrintWriter writer) throws WTException {
		IXBExpImpStatus result = new IXBExpImpStatus();
		ImportXlsHandler handler = new ImportXlsHandler(result, job, null, writer);
		return handler;
	}

	/*
	 * private synchronized static void writeImportLogMessage(Locale locale,
	 * File logFile, String resourceBundle, String messageKey, Object[]
	 * textInserts, int importanceLevel) throws WTException { try {
	 * BufferedWriter bwLog = new BufferedWriter(new FileWriter(logFile));
	 * WTMessage wtmess = new WTMessage(resourceBundle, messageKey,
	 * textInserts); String s = wtmess.getLocalizedMessage(locale); if (bwLog !=
	 * null) { bwLog.write(s); bwLog.newLine(); bwLog.flush(); } } catch
	 * (IOException e) { String errorKey = null; logger.fatal(resourceBundle,
	 * errorKey, textInserts); } }
	 */
	synchronized public static void logMessage(BufferedWriter bwLog, String message) throws WTException {
		try {
			if (null != bwLog && null != message) {
				bwLog.write(message);
				bwLog.newLine();
				bwLog.flush();
			}
		} catch (IOException e) {
			throw new WTException(e);
		}
	}

	/**
	 * Performs the actual preview or import
	 *
	 * @param job
	 * @return
	 * @throws WTException
	 */
	private static ImportJob doPreviewOrImport(ImportJob job) throws WTException {
		HashMap validationAttributesMap = new HashMap();
		SessionHelper.getPrincipal().setAdditionalAttributes(validationAttributesMap);
		boolean outcome = false;
		boolean isBOM = false;
		logger.debug("StandardImportService.doPreviewOrImport()...started");
		boolean isPreview = job.getSpec().isPreview();
		File logFile = getUniqueLogFile(job);
		if (null == logFile) {
			throw new WTException(RESOURCE, importerResource.FATAL_ERROR_COULD_NOT_OPEN_LOG_FILE, new Object[] {});
		}
		// Session data is shared through a single import job session
		SessionData sessionData = new SessionData();
		SessionData sessionDataBOM = new SessionData();
		initSessionData(sessionData, job);
		initSessionData(sessionDataBOM, job);
		PrintWriter writer = null;
		Transaction trx = null;
		// read import sequence.
		final ArrayList<String> strList = new ArrayList();
		try {
			importChunkSize = WTProperties.getServerProperties().getProperty(CANCELLABLE_CHUNK_SIZE_PROPERTY_KEY,
					DEFAULT_CANCELLABLE_CHUNK_SIZE);
			String strImportSeq = WTProperties.getServerProperties().getProperty(IMPORT_SEQUENCE);
			Collections.addAll(strList, strImportSeq.split(","));
		} catch (IOException e) {
			e.printStackTrace();
		}

		String sheetName = "";
		try {
			OutputStreamWriter osw = new OutputStreamWriter(new FileOutputStream(logFile), DEFAULT_ENCODING);
			writer = new PrintWriter(osw);
			ImportSourceFormat format = getImportSourceFormat(job);
			ImportSource source = ImportSourceFactory.getInstance().newImportSource(format, getImportSourceStream(job));
			logger.debug("Uploading Excel file on Windchill server from primary content of the import job...");
			writer.println(getLocalizedMessage(importerResource.MSG_STREAMING_EXCEL, null, sessionData.getJobLocale()));
			List sheets = source.getSheets();
			if (sheets == null || sheets.isEmpty()) {
				logger.debug("sheets is null or empty");
				writer.println(getLocalizedMessage(importerResource.MSG_SHEETS_ARE_NULL_OR_EMPTY, null,
						sessionData.getJobLocale()));
				outcome = false;
			} else {
				if (!isPreview) {
					trx = new Transaction();
					trx.start();
				}
				// ====== Enable viewable (representation) forwarding ======
				Map globalmap = trx.getGlobalMap();
				VisualizationHelperIfc visHelper = new VisualizationHelperFactory().getHelper();
				globalmap.put(visHelper.getWvsCopyForwardTransactionKey(), null);
				// ============
				sessionData.setLogger(writer);
				sessionDataBOM.setLogger(writer);
				xlsFileName = ImportXlsHelper.getFileName(job);
				HashMap importSheetMap = new HashMap();
				for (ListIterator i = sheets.listIterator(); i.hasNext();) {
					job = (ImportJob) PersistenceHelper.manager.refresh(job);
					if (job.getStatus() == ImportJobStatus.CANCELED) {
						return job;
					}
					ImportSheet sheet = (ImportSheet) i.next();
					if (null == sheet) {
						logger.debug("The sheet is null.");
						continue;
					}
					writer.println();
					writer.println(getSheetTitle(sheet));
					sheetName = sheet.getSheetName();

					ImportSheetParser parser = ImportSheetParserFactory.getInstance().newParser(sheet);

					PreImportSheetValidator preImportSheetValidator = getPreImportSheetValidatorHandler(job, parser);

					ImportSheetType type = preImportSheetValidator.validateImportSheetType(parser, sheetName, writer,
							job);

					if (type == null) {
						continue;
					}

					// need to remove this method.
					isBOM = setAdditionalAttributeToIndicateBOMSheetPresence(isBOM, type, validationAttributesMap);

					List list;
					if (importSheetMap.containsKey(type))
						list = (List) importSheetMap.get(type);
					else
						list = new ArrayList();
					list.add(sheet);
					importSheetMap.put(type, list);
				}
				if (importSheetMap.keySet().isEmpty()) {
					logger.debug("No valid sheets were found in this spreadsheet");
					writer.println(getLocalizedMessage(importerResource.MSG_NO_VALID_SHEET_TYPES, null,
							sessionData.getJobLocale()));
					outcome = false;
					ImportXlsHelper.reportError(ImportXlsHelper.getLocaleErrorStr(), xlsFileName, "", "",
							getLocalizedMessage(importerResource.MSG_NO_VALID_SHEET_TYPES, null,
									sessionData.getJobLocale()));
				} else {
					writer.println();
					writer.println(getLocalizedMessage(importerResource.MSG_RESORTING_THE_SHEETS, null,
							sessionData.getJobLocale()));

					boolean tempOutComeFlag = outcome;
					Set keys = importSheetMap.keySet();
					// first process all the sheets which are defined in Xconf
					// seq. and removes those from the key set.
					outcome = true;
					boolean priviewOutCome = true;
					Iterator seqItr = strList.iterator();
					while (seqItr.hasNext()) {
						String seqType = (String) seqItr.next();
						if (seqType != null && !seqType.isEmpty()) {
							ImportSheetType impIype = ImportSheetType.toImportSheetType(seqType.toLowerCase());
							if (keys.contains(impIype)) {
								List list = (List) importSheetMap.get(impIype);
								if (outcome || isPreview) {
									if (!(impIype.equals(ImportSheetType.PART)) && !isPreview) {
										outcome = doSameTypeSheetImport(sessionDataBOM, job, impIype, list);
										if (!outcome) {
											priviewOutCome = outcome;
										}
									} else
										outcome = doSameTypeSheetImport(sessionData, job, impIype, list);
									if (!outcome && priviewOutCome) {
										priviewOutCome = outcome;
									}
									if (!isPreview) {
										sessionData = null;
										sessionData = new SessionData();
										initSessionData(sessionData, job);
										sessionData.setLogger(writer);
									}
									if (tempOutComeFlag) {
										tempOutComeFlag = outcome;
									}
								}
								keys.remove(impIype);
							}
						}
					}
					// process all remaining key set.
					Iterator sIter = keys.iterator();
					while (sIter.hasNext()) {
						ImportSheetType type = (ImportSheetType) sIter.next();
						List list = (List) importSheetMap.get(type);
						if (outcome || isPreview) {
							if (!(type.equals(ImportSheetType.PART)) && !isPreview) {
								outcome = doSameTypeSheetImport(sessionDataBOM, job, type, list);
								if (!outcome) {
									priviewOutCome = outcome;
								}
							} else
								outcome = doSameTypeSheetImport(sessionData, job, type, list);
							if (!outcome && priviewOutCome) {
								priviewOutCome = outcome;
							}
							if (!isPreview) {
								sessionData = null;
								sessionData = new SessionData();
								initSessionData(sessionData, job);
								sessionData.setLogger(writer);
							}
							if (tempOutComeFlag) {
								tempOutComeFlag = outcome;
							}
						}
					}
					// put the outcome in the map which indicates whether or not
					// job failed
					validationAttributesMap.put("isJobFail", !priviewOutCome);
					if (isPreview) {
						doFinalizeImport(sessionData, job, false);
						doFinalizeImport(sessionDataBOM, job, false);
						logger.debug("Preview completed.");
					} else {
						if (!job.getSpec().isPreviewStep()) {
							doFinalizeImport(sessionData, job, false);
							doFinalizeImport(sessionDataBOM, job, false);
						} else {
							// Used for data retrieval in
							// ImportSpreadsheetPreviewStepTableBuilder
							MethodContext.getContext().put("sheetNamePartCache",
									sessionDataBOM.getSheetNamePartCache());
							// Used for data retrieval and comparison logic in
							// PreviewTableColumnsDataUtility
							MethodContext.getContext().put("keysMappedToPartsCache",
									getKeysMappedToParts(sessionDataBOM.getSheetNamePartCache()));
						}
						if (null != trx && !(job.getStatus().equals(ImportJobStatus.CANCELED))) {
							trx.commit();
							trx = null;
							logger.trace("Transaction committed.");

						}
						logger.debug("Import completed.");
					}
					sessionData.dumpSessionData(Level.TRACE);
					sessionDataBOM.dumpSessionData(Level.TRACE);
				}
			}
		} catch (Exception e) {
			outcome = false;
			doFinalizeImport(sessionData, job, true);
			doFinalizeImport(sessionDataBOM, job, true);
			if (!isPreview && e instanceof ImportCanceledException) {
				logger.trace("The import job has been cancelled.");
			} else {
				writer.println(e.getMessage());
				logger.debug(e);
				ImportXlsHelper.reportError(ImportXlsHelper.getLocaleErrorStr(), xlsFileName, sheetName, "",
						e.getLocalizedMessage());
			}

			throw (e instanceof WTException) ? (WTException) e : new WTException(e);
		} finally {

			if (null != trx || job.getStatus().equals(ImportJobStatus.CANCELED)) {
				trx.rollback();
				logger.trace("Rollback the transaction.");
			}
			if (writer != null) {
				finalize(job, writer, logFile, outcome, isPreview, job.getSpec().isPreviewStep());
			}
			try {
				if (!isPreview)
					job.setStatus(outcome
							? (job.getSpec().isPreviewStep() ? ImportJobStatus.PARTIAL : ImportJobStatus.COMPLETED)
							: ((job.getStatus() == ImportJobStatus.CANCELED) ? ImportJobStatus.CANCELED
									: ImportJobStatus.FAILED));
				else
					job.setStatus(outcome ? ImportJobStatus.VALIDATED
							: ((job.getStatus() == ImportJobStatus.CANCELED) ? ImportJobStatus.CANCELED
									: ImportJobStatus.FAILED));
			} catch (WTPropertyVetoException e) {
				e.printStackTrace();
				throw new WTException(e);
			}

		}
		return job;
	}

	// set the attribute "isBomCache" - used for adding preview button or not in
	// UI
	private static boolean setAdditionalAttributeToIndicateBOMSheetPresence(boolean isBOM, ImportSheetType type,
			HashMap validationAttributesMap) throws WTException {
		if (!isBOM) {
			if (type.equals(ImportSheetType.BOM)) {
				isBOM = true;
			} else {
				isBOM = false;
			}
			validationAttributesMap.put("isBomCache", isBOM);
		}
		return isBOM;
	}

	/*
	 * This method will import a list of same type sheets
	 *
	 * @param sessionData, job, writer, type, sheets
	 *
	 * @return
	 *
	 * @throws WTException
	 */
	private static boolean doSameTypeSheetImport(SessionData sessionData, ImportJob job, ImportSheetType type,
			List sheets) throws WTException {
		PrintWriter writer = sessionData.getLogger();
		boolean outcome = true;
		String sheetName = "";
		int rowNumber = 0;
		int count = 0;
		try {

			WTPrincipalReference owner = job.getOwnership().getOwner();
			boolean isAdministrator = WTContainerHelper.service.isAdministrator(job.getContainerReference(),
					owner.getPrincipal());
			boolean isProductManagement = KBTeamUtils.isUserInRole(owner.getPrincipal(),
					(ContainerTeamManaged) job.getContainerReference().getObject(),
					KBConstants.PRODUCT_MANAGEMENT_ROLE);
			boolean isDataManager = KBTeamUtils.isUserInRole(owner.getPrincipal(),
					(ContainerTeamManaged) job.getContainerReference().getObject(), KBConstants.DATA_MANAGEMENT);
			for (ListIterator i = sheets.listIterator(); i.hasNext();) {
				// set row number "1", if any error found during parsing prolog
				// / header
				rowNumber = 1;
				ImportSheet sheet = (ImportSheet) i.next();
				writer.println();
				writer.println(getSheetTitle(sheet));
				sheetName = sheet.getSheetName();
				ImportSheetParser parser = ImportSheetParserFactory.getInstance().newParser(sheet);
				Map prolog = parser.parseProlog();
				logger.debug("prolog is " + prolog);
				List header = null;
				try {
					header = parser.parseHeader();
					logger.debug("header is " + header);
				} catch (WTException exception) {
					String errorStr = exception.getLocalizedMessage(sessionData.getJobLocale());
					// String errorStr =
					// exception.getCause().getLocalizedMessage();
					Object[] additioErrorInfo = exception.getAdditionalMessageArray();
					int errorAtLine = ((Integer) additioErrorInfo[0]).intValue();
					String typeValue = (String) additioErrorInfo[1];

					// for printing the error/warning in log file
					ImportXlsHelper.reportLogError(writer, ": " + typeValue, ": " + errorAtLine, ": " + errorStr);

					// for displaying the error in validation step
					ImportXlsHelper.reportError(typeValue, xlsFileName, sheetName, errorAtLine + "", errorStr);

					// continue from the next sheet
					continue;
				}

				// set row number "2", this for actual data row in the sheet
				rowNumber = 2;
				SheetElementBuilder builder = ElementBuilderFactory.getInstance().newSheetElementBuilder(type);

				// IF ImportAction is UPDATE_CHECKED_OUT_PARTS then throw
				// warning to ignore sheet types other than part
				if (job.getSpec().getAction().equals(ImportAction.UPDATE_CHECKED_OUT_PARTS)) {
					if (!(builder instanceof PartSheetElementBuilder)) {
						String errortype = ImportXlsHelper.getLocaleWarningStr();
						String message = getLocalizedMessage(importerResource.IGNORE_SHEET, new Object[] { sheetName },
								sessionData.getJobLocale());
						;

						// for printing the error/warning in log file
						ImportXlsHelper.reportLogError(writer, ": " + errortype, ": " + "", ": " + message);

						// for displaying the error in validation step
						ImportXlsHelper.reportError(errortype, xlsFileName, sheetName, "", message);
						return true;
					}
				}
				builder.initialize(prolog, header, sessionData);

				// First pass: Build all the import elements into a map
				LinkedHashMap elementMap = new LinkedHashMap();
				List<String> keyList = new ArrayList<String>();

				for (Iterator rows = parser.parseSheet(); rows.hasNext(); rowNumber++) {
					job = (ImportJob) PersistenceHelper.manager.refresh(job);
					if (job.getStatus() == ImportJobStatus.CANCELED) {
						return false;
					}
					Map rowData = (Map) rows.next();
					if (null == rowData.values() || rowData.values().size() == 0)
						continue;
					ImportElement importElement = null;
					sessionData.setFileName(xlsFileName);
					sessionData.setSheetName(sheetName);
					sessionData.setRowNumber(XlsSheetParser.DEFAULT_HEADER_ROW_INDEX + rowNumber + "");
					try {
						if (!isAdministrator && !isProductManagement && !isDataManager) {
							checkState(type, rowData);
						}
					} catch (WTException e) {
						if (sessionData.isPreview()) {
							logger.debug("StandardImportService -> doPreviewOrImport() : " + e);

							String typeValue = ImportXlsHelper.getLocaleErrorStr();
							String description = e.getLocalizedMessage(sessionData.getJobLocale());
							if (e.getAdditionalMessageArray() != null && e.getAdditionalMessageArray().length > 0) {
								if (e.getAdditionalMessageArray()[0].equals(ImportXlsHelper.getLocaleWarningStr())) {
									typeValue = ImportXlsHelper.getLocaleWarningStr();
									description = e.getCause().getLocalizedMessage();
								}
							}

							String rowNum = XlsSheetParser.DEFAULT_HEADER_ROW_INDEX + rowNumber + "";

							// for printing the error/warning in log file
							ImportXlsHelper.reportLogError(writer, ": " + typeValue, ": " + rowNum, ": " + description);

							// for displaying the error in validation step
							ImportXlsHelper.reportError(typeValue, xlsFileName, sheetName, rowNum, description);

							if (typeValue.equals(ImportXlsHelper.getLocaleErrorStr())) {
								outcome = false;
							}
						} else {
							ImportXlsHelper.reportLogError(writer,
									ImportXlsHelper.getLocaleTypeStr() + ": " + ImportXlsHelper.getLocaleErrorStr(), "",
									ImportXlsHelper.getLocaleDescriptionStr() + ": " + e.getLocalizedMessage());

							e.printStackTrace(writer);
							outcome = false;
							throw new WTException("Import failed...");
						}

					}
					try {
						importElement = builder.newElement(rowData);
						if (!isAdministrator) {
							checkNumberLengthConstraint(type, rowData);
						}

					} catch (WTException e) {
						if (sessionData.isPreview()) {
							logger.debug("StandardImportService -> doPreviewOrImport() : " + e);

							String typeValue = ImportXlsHelper.getLocaleErrorStr();
							String description = e.getLocalizedMessage(sessionData.getJobLocale());
							if (e.getAdditionalMessageArray() != null && e.getAdditionalMessageArray().length > 0) {
								if (e.getAdditionalMessageArray()[0].equals(ImportXlsHelper.getLocaleWarningStr())) {
									typeValue = ImportXlsHelper.getLocaleWarningStr();
									description = e.getCause().getLocalizedMessage();
								}
							}

							String rowNum = XlsSheetParser.DEFAULT_HEADER_ROW_INDEX + rowNumber + "";

							// for printing the error/warning in log file
							ImportXlsHelper.reportLogError(writer, ": " + typeValue, ": " + rowNum, ": " + description);

							// for displaying the error in validation step
							ImportXlsHelper.reportError(typeValue, xlsFileName, sheetName, rowNum, description);

							if (typeValue.equals(ImportXlsHelper.getLocaleErrorStr())) {
								outcome = false;
							}
						} else {
							ImportXlsHelper.reportLogError(writer,
									ImportXlsHelper.getLocaleTypeStr() + ": " + ImportXlsHelper.getLocaleErrorStr(), "",
									ImportXlsHelper.getLocaleDescriptionStr() + ": " + e.getLocalizedMessage());

							e.printStackTrace(writer);
							outcome = false;
							throw new WTException("Import failed...");
						}

					}

					if (null != importElement) {
						if (logger.isTraceEnabled()) {
							ImportHndHelper.printDomXml(importElement.getDocument().getDom(), System.out);
						}
						String pathKey = importElement.getPathToTrackable();
						String key = importElement.getDocument().getValue(pathKey);

						if (sessionData.isPreview() && null == key) {
							key = IxbHndHelper.XML_VALUE_NULL;
						}
						if (null != key && !"".equals(key)) {
							if (logger.isTraceEnabled())
								logger.debug("Key = <" + key + ">");
							if (elementMap.containsKey(key)) {
								List list = (List) elementMap.get(key);
								TreeMap<Integer, ImportElement> importElementMap = null;
								if (type.equals(ImportSheetType.PART)) {
									importElementMap = (TreeMap) list.get(0);
								} else {
									List innerList = (List) list.get(0);
									importElementMap = (TreeMap) innerList.get(0);
								}
								count++;
								importElementMap.put(rowNumber, importElement);

							} else {
								List innerList = new ArrayList();
								TreeMap<Integer, ImportElement> importElementMap = new TreeMap<Integer, ImportElement>();
								count++;
								importElementMap.put(rowNumber, importElement);
								innerList.add(importElementMap);
								if (type.equals(ImportSheetType.PART)) {
									elementMap.put(key, innerList);
								} else {
									List outerList = new ArrayList();
									outerList.add(0, innerList);
									if (type.equals(ImportSheetType.BOM)) {
										outerList.add(1, rowData.get("Level"));
									}
									elementMap.put(key, outerList);
								}
							}
							keyList.add(key);
							if (count >= importChunkSize && !elementMap.keySet().isEmpty()
									&& !type.equals(ImportSheetType.BOM)) {
								outcome = importInChunk(job, sessionData, type, sheet, rowNumber, elementMap, writer,
										outcome);
								elementMap.clear();
							}
						} else {
							throw new WTException(RESOURCE,
									importerResource.FATAL_ERROR_COULD_NOT_FIND_IMPORT_ELEMENT_KEY, new Object[] {});
						}
					} else {

						logger.debug("The ImportElement object is null, ignore it.");
					}
				}
				logger.debug("Build the import element map with " + elementMap.size() + " key(s).");
				if (elementMap.keySet().size() != 0 && !elementMap.keySet().isEmpty())
					outcome = importInChunk(job, sessionData, type, sheet, rowNumber, elementMap, writer, outcome);
			}
		} catch (Exception e) {
			logger.debug("StandardImportService -> doSameTypeSheetImport() : ImportSheetType :" + type, e);
			if (!sessionData.isPreview() && e instanceof ImportCanceledException) {
				logger.trace("The import job has been cancelled.");

			} else {
				String typeValue = ImportXlsHelper.getLocaleErrorStr();
				String rowNum = XlsSheetParser.DEFAULT_HEADER_ROW_INDEX + rowNumber + "";
				String description = e.getLocalizedMessage();

				// for printing the error/warning in log file
				ImportXlsHelper.reportLogError(writer, ": " + typeValue, ": " + rowNum, ": " + description);

				// for displaying the error in validation step
				ImportXlsHelper.reportError(typeValue, xlsFileName, sheetName, rowNum, description);
				logger.debug(e.getMessage());
			}
			outcome = false;
			if (!sessionData.isPreview()) {
				throw new WTException(e);
			}
		}
		return outcome;
	}

	private static void checkNumberLengthConstraint(ImportSheetType type, Map rowData) throws WTException {
		if (type.equals(ImportSheetType.PART)) {
			String subType = rowData.get("Type").toString();
			String number = rowData.get("Number").toString();
			int numberLength = number.length();
			AttributeDefinitionReadView def = IBAHelper.getAttributeDefinitionReadView(subType, "number");
			int constraintStringLength = ((int) AttributesUtil.getLengthConstraintForStringAttribute(def)) / 3;

			if (numberLength > constraintStringLength) {

				logger.error("Part number \"" + number + "\" is to long. " + "Constraint Length : "
						+ constraintStringLength + " current length : " + numberLength);
				throw new WTException("Part number \"" + number + "\" is to long. " + "Constraint Length : "
						+ constraintStringLength + " current length : " + numberLength);
			}
		}
	}

	private static void checkState(ImportSheetType type, Map rowData) throws WTException {
		if (type.equals(ImportSheetType.PART)) {
			String state = rowData.get("State").toString();
			if (!state.equals(KBConstants.IN_WORK)) {

				logger.error("WTPart is in a wrong state, only 1010 is allowed to be imported");
				throw new WTException("WTPart is in a wrong state, only 1010 is allowed to be imported");
			}
		}
	}

	private static boolean importInChunk(ImportJob job, SessionData sessionData, ImportSheetType type,
			ImportSheet sheet, int rowNumber, Map elementMap, PrintWriter writer, boolean outcome)
			throws WTException, WTPropertyVetoException {
		// Second pass: Reform, process and import the elements.
		ImportXlsHandler handler = getHandler(job, sessionData.getLogger());
		SheetImporter sheetImporter = ImporterFactory.getInstance().newSheetImporter(type);
		sheetImporter.setSheetNumber(sheet.getSheetNumber());
		sheetImporter.setSheetName(sheet.getSheetName());
		Importer importer = getIxbImporter(job, handler);

		sheetImporter.initialize(job, importer, sessionData);
		if (sessionData.isSkipCopyForwardPrefrance() == null) {
			WTContainerRef containerRef = importer.getTargetContainerRef();
			boolean skipCopyForwardPrefrance = ImportHndHelper.skipCopyForward(containerRef);
			sessionData.setSkipCopyForwardPrefrance(skipCopyForwardPrefrance);
		}
		rowNumber = 0;
		try {
			sheetImporter.importSheetElements(elementMap);
		} catch (WTException e) {
			logger.debug("StandardImportService -> doSameTypeSheetImport() : ImportSheetType :" + type, e);

			if (sessionData.isPreview()) {
				Object[] exceptionsArray = e.getAdditionalMessageArray();
				if (exceptionsArray != null && exceptionsArray.length > 0) {
					for (Object exceptionObj : exceptionsArray) {
						WTException exception = (WTException) exceptionObj;
						if (logger.isDebugEnabled()) {
							exception.printStackTrace();
						}

						String errorStr = getExceptionMessage(exception, sessionData);
						Object[] additioErrorInfo = exception.getAdditionalMessageArray();
						int errorAtLine = ((Integer) additioErrorInfo[0]).intValue()
								+ XlsSheetParser.DEFAULT_HEADER_ROW_INDEX;
						String typeValue = (String) additioErrorInfo[1];

						// for printing the error/warning in log file
						ImportXlsHelper.reportLogError(writer, ": " + typeValue, ": " + errorAtLine, ": " + errorStr);

						// for displaying the error in validation step
						ImportXlsHelper.reportError(typeValue, xlsFileName, sessionData.getSheetName(),
								errorAtLine + "", errorStr);

						if (typeValue.equals(ImportXlsHelper.getLocaleErrorStr())) {
							outcome = false;
						}
					}

				}
			} else {
				// for printing the error/warning in log file
				ImportXlsHelper.reportLogError(writer,
						ImportXlsHelper.getLocaleTypeStr() + ": " + ImportXlsHelper.getLocaleErrorStr(), "",
						ImportXlsHelper.getLocaleDescriptionStr() + ": " + e.getLocalizedMessage());
				e.printStackTrace(writer);
				outcome = false;
				throw new WTException("Import failed...");
			}

		}
		return outcome;
	}

	private static String getExceptionMessage(Throwable exception, SessionData sessionData) throws WTException {
		String exceptionMsg = "";
		Locale locale = sessionData.getJobLocale();

		Throwable throwable = exception.getCause();
		if (throwable.getCause() != null) {
			exceptionMsg = getExceptionMessage(throwable, sessionData);
		} else {
			if (throwable instanceof WTException) {
				exceptionMsg = ((WTException) throwable).getLocalizedMessage(locale);
			} else if (throwable instanceof WTRuntimeException) {
				exceptionMsg = ((WTRuntimeException) throwable).getLocalizedMessage(locale);
			} else if (throwable instanceof WTPropertyVetoException) {
				exceptionMsg = ((WTPropertyVetoException) throwable).getLocalizedMessage(locale);
			} else if (throwable instanceof Exception) {
				exceptionMsg = ((Exception) throwable).toString();
			}
		}
		return exceptionMsg;
	}

	/**
	 *
	 * @param sessionData
	 * @param job
	 * @param commitChanges
	 * @throws WTException
	 */
	private static void doFinalizeImport(SessionData sessionData, ImportJob job, boolean commitChanges)
			throws WTException {
		Map checkedOutObjectCache = sessionData.getCheckedOutBeanCache();
		Set apSet = checkedOutObjectCache.keySet();
		Iterator iter = apSet.iterator();
		while (iter.hasNext()) {
			((AbstractCheckedOutObject) checkedOutObjectCache.get(iter.next())).doPostCleanUpImport(job,
					!commitChanges);
		}
	}

	private synchronized static void closeImportLog(PrintWriter writer, boolean outcome, boolean isPreview,
			Locale jobLocale) throws WTException {
		if (writer != null) {
			if (isPreview && outcome) {
				writer.println(getLocalizedMessage(importerResource.PREVIEW_RESULT_VALIDATED, null, jobLocale));
			} else if (isPreview && !outcome) {
				writer.println(getLocalizedMessage(importerResource.PREVIEW_RESULT_FAILED, null, jobLocale));
			} else if (!isPreview && outcome) {
				writer.println(getLocalizedMessage(importerResource.IMPORT_RESULT_COMPLETED, null, jobLocale));
			} else {
				writer.println(getLocalizedMessage(importerResource.IMPORT_RESULT_FAILED, null, jobLocale));
			}
			writer.flush();
			writer.close();
		}
	}

	private static void removeConflictResolutions() throws WTException {
		MethodContext m_context = MethodContext.getContext();
		if (m_context != null && m_context.get(ConflictServerHelper.RESOLUTIONS_STORE) != null)
			m_context.remove(ConflictServerHelper.RESOLUTIONS_STORE);
	}

	private static void finalize(ImportJob job, PrintWriter writer, File logFile, boolean outcome, boolean isPreview,
			boolean keepParentCheckedout) throws WTException {
		if (writer == null) {
			return;
		}

		try {

			if (!isPreview)
				job.setStatus(outcome ? (keepParentCheckedout ? ImportJobStatus.PARTIAL : ImportJobStatus.COMPLETED)
						: ImportJobStatus.FAILED);
			else
				job.setStatus(outcome ? ImportJobStatus.VALIDATED : ImportJobStatus.FAILED);
			closeImportLog(writer, outcome, isPreview, job.getSpec().getLocale());
			QueryResult result = ContentHelper.service.getContentsByRole(job, ContentRoleType.SECONDARY);
			ApplicationData appData = null;
			if (!result.hasMoreElements()) {
				appData = ApplicationData.newApplicationData(job);
			} else {
				appData = (ApplicationData) result.nextElement();
				String filePath = appData.getUploadedFromPath();
				File previewLog = new File(filePath);
				if (previewLog.delete()) {
					logger.debug("File <" + filePath + "> has been deleted.");
				}
			}
			appData.setFileName(logFile.getName());
			appData.setUploadedFromPath(logFile.getAbsolutePath());
			appData.setDescription("Import log file: " + logFile.getName());
			appData.setRole(ContentRoleType.SECONDARY);
			appData = ContentServerHelper.service.updateContent(job, appData, logFile.getAbsolutePath());
			removeConflictResolutions();
		} catch (Exception e) {
			throw (e instanceof WTException) ? (WTException) e : new WTException(e);
		}
	}

	private static String getSheetTitle(ImportSheet sheet) {
		int sheetNumber = sheet.getSheetNumber();
		String sheetName = sheet.getSheetName();
		String sheetTitle = new String("");
		if (sheetNumber >= 0)
			sheetTitle = "Sheet " + sheetNumber;
		if (null != sheetName && sheetName.trim().length() > 0)
			sheetTitle += " \"" + sheetName + "\"";
		sheetTitle += ":";
		return sheetTitle;
	}

	private static String getLocalizedMessage(String messageKey, Object[] params, Locale locale) {
		return (new WTMessage(RESOURCE, messageKey, params)).getLocalizedMessage(locale);
	}

	/**
	 * Processes PRE_INSERT event for ImportJob Persists data with appropriate
	 * job number fro datastore sequence
	 *
	 * @param jobs
	 *            import job collection
	 * @throws WTException
	 */
	private void processPreInsertForImportJob(WTCollection jobs) throws WTException {
		logger.debug("PRE_INSERT: processing " + jobs.size() + " import jobs");
		try {
			for (Iterator i = jobs.persistableIterator(); i.hasNext();) {
				ImportJob job = (ImportJob) i.next();
				String jobNumberString = PersistenceHelper.manager.getNextSequence(ImportJobNumberSeq.class);
				job.setNumber(Long.parseLong(jobNumberString));
				logger.debug("job number is set to: " + job.getNumber());
			}
		} catch (Exception e) {
			throw new WTException(e);
		}
		logger.debug("PRE_INSERT: processed " + jobs.size() + " import jobs");
	}

	private static ImportSourceFormat getImportSourceFormat(ImportJob job) throws WTException {
		String filename = job.getSpec().getFilename();
		String extension = filename.substring(filename.lastIndexOf(".") + 1).toLowerCase();
		ImportSourceFormat format = ImportSourceFormat.toImportSourceFormat(extension);
		logger.debug("getImportSourceFormat(): filename=" + filename + " extension=" + extension + " format=" + format);
		return format;
	}

	/**
	 *
	 * @param sheetNamePartCacheMap
	 * @return
	 * @throws WTException
	 */
	private static Map getKeysMappedToParts(Map sheetNamePartCacheMap) throws WTException {

		Map keysMappedToParts = new HashMap();
		Set beansSet = sheetNamePartCacheMap != null ? sheetNamePartCacheMap.keySet() : null;
		Iterator iterator = beansSet != null ? beansSet.iterator() : null;

		if (iterator != null) {

			Object iteratedObj = null;
			ObjectIdentifier objId = null;
			WTPart part = null;

			while (iterator.hasNext()) {
				iteratedObj = iterator.next();
				objId = ImportHndHelper.getObjectIdentifier(iteratedObj + "");
				part = (WTPart) PersistenceHelper.manager.refresh(objId);
				keysMappedToParts.put(part, iteratedObj);
			}
		}

		return keysMappedToParts;
	}

	/**
	 *
	 * @param sessionData
	 * @param job
	 * @throws WTException
	 */
	private static void initSessionData(SessionData sessionData, ImportJob job) throws WTException {
		if (job.getImportJobArgsBean() != null) {
			if (job.getImportJobArgsBean().getFolderPath() == null)
				sessionData.setDirectoryPathCache("/Default");
			else
				sessionData.setDirectoryPathCache(job.getImportJobArgsBean().getFolderPath());
		}

		sessionData.setPreview(job.getSpec().isPreview());
		sessionData.setContainerRef(job.getContainerReference());
		sessionData.setImportAction(job.getSpec().getAction());
		sessionData.setJobLocale(job.getSpec().getLocale());
	}

	/**
	 * Given IXApplicationContext and datatype to lookup the LabelHandler
	 *
	 * @param ixApplicationContext
	 * @param datatype
	 * @return LabelHandler
	 * @throws WTException
	 */
	private static PreImportSheetValidator getPreImportSheetValidatorHandler(ImportJob job, ImportSheetParser parser) {
		PreImportSheetValidator handler = null;
		ImportSheetType sheet = null;
		String sheetType = null;
		try {
			sheet = parser.parseSheetType();
		} catch (WTException e1) {
			sheet = null;
		}
		logger.debug("parser is a " + parser.getClass().getName());
		if (sheet != null)
			sheetType = sheet.getDisplay();
		if (job == null || sheetType == null) {
			return new StandardPreImportSheetValidator();
		}
		String selector = sheetType;
		try {
			handler = (PreImportSheetValidator) DefaultServiceProvider.getService(PreImportSheetValidator.class,
					selector, job);
		} catch (UnableToCreateServiceException e) {
			logger.info("The requestor:" + job + ", selector:" + selector + " doesn't have LabelHandler");
		}

		if (handler == null)
			handler = new StandardPreImportSheetValidator();
		return handler;
	}
}
