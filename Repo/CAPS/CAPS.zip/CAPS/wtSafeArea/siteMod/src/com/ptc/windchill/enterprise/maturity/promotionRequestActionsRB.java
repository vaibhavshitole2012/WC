package com.ptc.windchill.enterprise.maturity;

import wt.util.resource.RBComment;
import wt.util.resource.RBEntry;
import wt.util.resource.RBPseudo;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("com.ptc.windchill.enterprise.maturity.promotionRequestActionsRB")
public final class promotionRequestActionsRB extends WTListResourceBundle {
   /**
/* bcwti
 *
 * Copyright (c) 2010 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
    *
    * This file contains all the strings used by the JCA based Promotion Request clients
    *
    * ##############################################################################
    *
    * Wizard step names
    *
    * ##############################################################################
    **/
   @RBEntry("Select Promotion Objects")
   @RBComment("Used as the label for a wizard step")
   public static final String PRIVATE_CONSTANT_0 = "promotionRequest.promotionObjectsTableStep.description";

   @RBEntry("Select Promotion Objects")
   @RBComment("Used as the title for a wizard step")
   public static final String PRIVATE_CONSTANT_1 = "promotionRequest.promotionObjectsTableStep.title";

   @RBEntry("Select Participants")
   @RBComment("Used as the label for a wizard step")
   public static final String PRIVATE_CONSTANT_2 = "promotionRequest.workflowParticipantsStep.description";

   @RBEntry("Select Participants")
   @RBComment("Used as the title for a wizard step")
   public static final String PRIVATE_CONSTANT_3 = "promotionRequest.workflowParticipantsStep.title";

   /**
    * ##############################################################################
    *
    * Table Names
    *
    * ##############################################################################
    **/
   @RBEntry("Promotion Objects")
   @RBComment("Used as the label for the table action")
   public static final String PRIVATE_CONSTANT_4 = "promotionRequest.promotionItemsTable.description";

   /**
    * ##############################################################################
    *
    * Table actions
    *
    * ##############################################################################
    **/
   @RBEntry("Remove")
   @RBComment("Used as the label for the action")
   public static final String PRIVATE_CONSTANT_5 = "promotionRequest.remove.description";

   @RBEntry("Remove")
   @RBComment("Used as the tooltip for the action")
   public static final String PRIVATE_CONSTANT_6 = "promotionRequest.remove.tooltip";

   @RBEntry("remove16x16.gif")
   @RBPseudo(false)
   @RBComment("DO NOT TRANSLATE")
   public static final String PRIVATE_CONSTANT_7 = "promotionRequest.remove.icon";

   @RBEntry("Add Promotion Objects")
   @RBComment("Used as the label for the add action")
   public static final String PRIVATE_CONSTANT_8 = "promotionRequest.addPromotables.description";

   @RBEntry("width=900,height=550,status=yes")
   @RBPseudo(false)
   @RBComment("DO NOT TRANSLATE")
   public static final String PRIVATE_CONSTANT_9 = "promotionRequest.addPromotables.moreurlinfo";

   @RBEntry("Add promotion objects")
   @RBComment("Used as the tooltip for the add action")
   public static final String PRIVATE_CONSTANT_10 = "promotionRequest.addPromotables.tooltip";

   @RBEntry("add16x16.gif")
   @RBPseudo(false)
   @RBComment("DO NOT TRANSLATE")
   public static final String PRIVATE_CONSTANT_11 = "promotionRequest.addPromotables.icon";

   @RBEntry("Paste")
   @RBComment("Used as the label for the paste action")
   public static final String PRIVATE_CONSTANT_12 = "promotionRequest.paste.description";

   @RBEntry("Paste")
   @RBComment("Used as the label for the paste action")
   public static final String PRIVATE_CONSTANT_13 = "promotionRequest.paste.title";

   @RBEntry("Paste objects from clipboard")
   @RBComment("Used as the tooltip for the paste action")
   public static final String PRIVATE_CONSTANT_14 = "promotionRequest.paste.tooltip";

   @RBEntry("paste.gif")
   @RBPseudo(false)
   @RBComment("DO NOT TRANSLATE")
   public static final String PRIVATE_CONSTANT_15 = "promotionRequest.paste.icon";

   @RBEntry("Paste Selection")
   @RBComment("Used as the label for the paste selection action")
   public static final String PRIVATE_CONSTANT_16 = "promotionRequest.pasteSelect.description";

   @RBEntry("Paste Selection")
   @RBComment("Used as the label for the paste selection action")
   public static final String PRIVATE_CONSTANT_17 = "promotionRequest.pasteSelect.title";

   @RBEntry("Paste selection of objects from clipboard")
   @RBComment("Used as the tooltip for the paste selection action")
   public static final String PRIVATE_CONSTANT_18 = "promotionRequest.pasteSelect.tooltip";

   @RBEntry("paste_select.gif")
   @RBPseudo(false)
   @RBComment("DO NOT TRANSLATE")
   public static final String PRIVATE_CONSTANT_19 = "promotionRequest.pasteSelect.icon";

   /**
    * ##############################################################################
    *
    * Object actions
    *
    * ##############################################################################
    **/
   @RBEntry("New Promotion Notice")
   @RBComment("Used as the label for the create promotion notice action")
   public static final String PRIVATE_CONSTANT_20 = "promotionRequest.create.description";

   @RBEntry("New Promotion Notice")
   @RBComment("Used as the title for the create action")
   public static final String PRIVATE_CONSTANT_21 = "promotionRequest.create.title";

   @RBEntry("promotereqst_create.gif")
   @RBPseudo(false)
   @RBComment("DO NOT TRANSLATE")
   public static final String PRIVATE_CONSTANT_22 = "promotionRequest.create.icon";

   @RBEntry("New Promotion Notice")
   public static final String PRIVATE_CONSTANT_23 = "promotionRequest.create.tooltip";

   @RBEntry("width=1280,height=800")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_24 = "promotionRequest.create.moreurlinfo";

   @RBEntry("Delete")
   @RBComment("Used as the label for the action")
   public static final String PRIVATE_CONSTANT_25 = "promotionRequest.delete.description";

   @RBEntry("Delete")
   @RBComment("Used as the tooltip for the action")
   public static final String PRIVATE_CONSTANT_26 = "promotionRequest.delete.tooltip";

   @RBEntry("delete.gif")
   @RBPseudo(false)
   @RBComment("DO NOT TRANSLATE")
   public static final String PRIVATE_CONSTANT_27 = "promotionRequest.delete.icon";

   @RBEntry("create_tbar.gif")
   @RBPseudo(false)
   @RBComment("DO NOT TRANSLATE")
   public static final String PRIVATE_CONSTANT_28 = "promotionRequest.createPromotionPreference.icon";

   @RBEntry("New Promotion Preference")
   public static final String PRIVATE_CONSTANT_29 = "promotionRequest.createPromotionPreference.description";

   @RBEntry("New promotion preference")
   public static final String PRIVATE_CONSTANT_30 = "promotionRequest.createPromotionPreference.tooltip";

   @RBEntry("New Promotion Preference")
   @RBComment("Used as the title for the create promotion preference action")
   public static final String PRIVATE_CONSTANT_31 = "promotionRequest.createPromotionPreference.title";

   @RBEntry("Promotion Preference Manager")
   public static final String PRIVATE_CONSTANT_32 = "promotionRequest.preferenceTable.description";

   @RBEntry("Promotion preference manager")
   public static final String PRIVATE_CONSTANT_33 = "promotionRequest.preferenceTable.tooltip";

   @RBEntry("netmarkets/images/defer_default.gif")
   @RBPseudo(false)
   @RBComment("DO NOT TRANSLATE")
   public static final String PRIVATE_CONSTANT_34 = "promotionRequest.promoteObjects.icon";

   @RBEntry("Set Object for Promotion")
   @RBComment("Used as the tooltip for the action")
   public static final String PRIVATE_CONSTANT_35 = "promotionRequest.promoteObjects.description";

   @RBEntry("Set Object for Promotion")
   @RBComment("Used as the label for the action")
   public static final String PRIVATE_CONSTANT_36 = "promotionRequest.promoteObjects.tooltip";

   @RBEntry("Collect Objects")
   public static final String PRIVATE_CONSTANT_37 = "promotionRequest.collectBaselineItems.description";

   @RBEntry("Collect objects")
   public static final String PRIVATE_CONSTANT_38 = "promotionRequest.collectBaselineItems.tooltip";

   @RBEntry("collect.gif")
   @RBPseudo(false)
   @RBComment("DO NOT TRANSLATE")
   public static final String PRIVATE_CONSTANT_39 = "promotionRequest.collectBaselineItems.icon";

   @RBEntry("Details")
   @RBComment("The Details tab on the info page of a promotion request")
   public static final String PRIVATE_CONSTANT_40 = "object.promotionRequestDetailsTab.description";

   @RBEntry("Process")
   @RBComment("The Process tab on the info page of a promotion request")
   public static final String PRIVATE_CONSTANT_41 = "object.promotionRequestProcessTab.description";

   @RBEntry("Collaboration")
   @RBComment("The Collaboration tab on the info page of a promotion request")
   public static final String PRIVATE_CONSTANT_42 = "object.promotionRequestCollaborationTab.description";

   @RBEntry("History")
   @RBComment("The History tab on the info page of a promotion request")
   public static final String PRIVATE_CONSTANT_43 = "object.promotionRequestHistoryTab.description";

   @RBEntry("Open in")
   public static final String PRIVATE_CONSTANT_44 = "object.promotion request row actions open.description";

   @RBEntry("Open in")
   public static final String PRIVATE_CONSTANT_45 = "object.promotion request row actions open.tooltip";
   
   @RBEntry("Edit")
   @RBComment("Used as the label for the action")
   public static final String PRIVATE_CONSTANT_46 = "promotionRequest.edit.description";
   
   @RBEntry("Edit")
   @RBComment("Used as the tooltip for the action")
   public static final String PRIVATE_CONSTANT_47 = "promotionRequest.edit.tooltip";

   @RBEntry("edit.gif")
   @RBPseudo(false)
   @RBComment("DO NOT TRANSLATE")
   public static final String PRIVATE_CONSTANT_48 = "promotionRequest.edit.icon";
   
   @RBEntry("width=1280,height=800")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_49 = "promotionRequest.edit.moreurlinfo";
   
   @RBEntry("Edit Promotion Request")
   @RBComment("Used as the title for the edit action")
   public static final String PRIVATE_CONSTANT_50 = "promotionRequest.edit.title";

   @RBEntry("Promotion Objects")
   @RBComment("Used as the label for the Promotion Objects table for a Promotion Request work item.")
   public static final String WORKFLOW_TASK_PROMOTIONOBJ_DESC = "promotionRequest.reviewApproveTask_PromotionObjectsTable.description";

   @RBEntry("Promotion Objects")
   @RBComment("Used as the tooltip for the Promotion Objects table for a Promotion Request work item.")
   public static final String WORKFLOW_TASK_PROMOTIONOBJ_TOOLTIP = "promotionRequest.reviewApproveTask_PromotionObjectsTable.tooltip";
   
   @RBEntry("Select Promotion Objects")
   @RBComment("Used as the label for a wizard step")
   public static final String PRIVATE_CONSTANT_51 = "promotionRequest.edit_promotionObjectsTableStep.description";

   @RBEntry("Select Promotion Objects")
   @RBComment("Used as the title for a wizard step")
   public static final String PRIVATE_CONSTANT_52 = "promotionRequest.edit_promotionObjectsTableStep.title";
}
