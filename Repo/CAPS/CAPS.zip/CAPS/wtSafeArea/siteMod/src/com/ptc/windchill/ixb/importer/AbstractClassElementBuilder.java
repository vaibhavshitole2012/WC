/* bcwti
 *
 * Copyright (c) 2010 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */
package com.ptc.windchill.ixb.importer;

import java.rmi.RemoteException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.springframework.util.StringUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.ptc.core.components.forms.CreateEditFormProcessorHelper;
import com.ptc.core.lwc.common.view.AttributeDefinitionReadView;
import com.ptc.core.lwc.common.view.ConstraintDefinitionReadView;
import com.ptc.core.lwc.common.view.PropertyValueReadView;
import com.ptc.core.lwc.common.view.TypeDefinitionReadView;
import com.ptc.core.lwc.server.TypeDefinitionServiceHelper;
import com.ptc.core.meta.common.AttributeTypeIdentifier;
import com.ptc.core.meta.common.DataSet;
import com.ptc.core.meta.common.DataTypesUtility;
import com.ptc.core.meta.common.DiscreteSet;
import com.ptc.core.meta.common.EnumeratedSet;
import com.ptc.core.meta.common.OperationIdentifier;
import com.ptc.core.meta.common.OperationIdentifierConstants;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.WildcardSet;
import com.ptc.core.meta.common.impl.WCTypeIdentifier;
import com.ptc.core.meta.container.common.AttributeTypeSummary;
import com.ptc.core.meta.server.TypeIdentifierUtility;
import com.ptc.core.meta.type.common.TypeInstance;
import com.ptc.windchill.ixb.importer.part.WTPartElementBuilder;
import com.ptc.windchill.ixb.util.ImportXlsHelper;
import com.ptc.windchill.option.service.OptionUtility;

import wt.enterprise.EnterpriseHelper;
import wt.facade.ixb.IxbHndHelperConstants;
import wt.filter.iba.OptionExclusionReference;
import wt.iba.definition.AttributeDefinition;
import wt.iba.definition.litedefinition.AttributeDefDefaultView;
import wt.iba.definition.service.IBADefinitionCache;
import wt.iba.definition.service.IBADefinitionHelper;
import wt.iba.value.IntegerValue;
import wt.inf.container.WTContainerHelper;
import wt.inf.container.WTContainerRef;
import wt.ixb.publicforhandlers.IxbHndHelper;
import wt.lifecycle.LifeCycleHelper;
import wt.lifecycle.LifeCycleTemplate;
import wt.lifecycle.PhaseTemplate;
import wt.log4j.LogR;
import wt.org.WTOrganization;
import wt.part.WTPartMaster;
import wt.preference.PreferenceClient;
import wt.session.SessionHelper;
import wt.type.TypedUtility;
import wt.units.FloatingPointWithUnits;
import wt.units.Unit;
import wt.units.UnitFormatException;
import wt.util.WTContext;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.WTProperties;

/**
 * Shares common attributes and methods to concrete class element builders.
 *
 * <BR>
 * <BR>
 * <B>Supported API: </B>false <BR>
 * <BR>
 * <B>Extendable: </B>false
 *
 * @version 1.0
 **/
public abstract class AbstractClassElementBuilder extends AbstractElementBuilder implements ClassElementBuilder {
    private static final String RESOURCE = "com.ptc.windchill.ixb.importer.importerResource";

    private static final String CLASSNAME = AbstractClassElementBuilder.class.getName();

    private DocumentBuilder documentBuilder;

    private Set<String> ibaNames;

    private Set<String> optionNames;

    protected static Set<String> NON_IBA_COLUMN_NAME_SET = new HashSet<String>();

    protected static final String DEFAULT_UNIT = "Default Unit";

    protected static final String STATE = "State";

    protected static final String VERSION = "Revision";

    protected static final String VIEW = "View";

    protected static final String NAME = "Name";

    protected static final String NUMBER = "Number";

    protected static final String FOLDER_PATH = "Location";

    protected static final String CONTAINER = "Container";

    protected static final String ORGANIZATION_ID = "Organization ID";

    protected static final String LIFECYCLE = "Lifecycle";

    protected static final String SECURITY_LABELS = "Security Labels";

    private static final Logger logger = LogR.getLogger(CLASSNAME);

    private static final String SECURITY_LABELS_SCHEME_SEPARATOR = ",";

    private static final String SECURITY_LABELS_NAME_VALUE_SEPARATOR = "=";

    public static final String IBA_VALUE_SEPARATOR = "\\|";

    public static final String DUMMYNUMBER_GENRATED = "dummyNumber_Genrated";

    private static final String ENUMERATION_CONSTRAINT_STR = "Enumerated Value List";

    private static final String REQUIRED_CONSTRAINT_STR = "Required";

    private static final String LEGALVALUE_CONSTRAINT_STR = "Legal Value List";

	private static final String SINGLE_VALUE_CONSTRAINT_STR = "Single-Valued";

	private static final String SIGNIFICANT_FIGURES = "-1";

	private Set<String> singleValuedIBA = new HashSet<>();

	private Map<String, Boolean> ibaWithNonBaseUnitMap=new HashMap<>();

    private static String defaultUnitsSystem = null;

    static
    {
      try
       {
        WTProperties properties = WTProperties.getLocalProperties();
        defaultUnitsSystem = properties.getProperty("wt.units.defaultMeasurementSystem");
       }
       catch (Throwable t)
       {
          logger.error("failed to get default measurement system");
          throw new ExceptionInInitializerError(t);
       }
    }

    /**
     * Initializes the builder. A builder must be initialized before being used.
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     *
     * @param prolog
     *            A prolog typically contains additional information about an ImportSheet, in the form of name value
     *            pairs.
     * @param header
     *            A header contains metadata about an ImportSheet - specifically, these are the column headers of the
     *            sheet.
     * @param sessionData
     *            session data
     * @exception wt.util.WTException
     **/
    @Override
    public void initialize(Map prolog, List header, SessionData sessionData) throws WTException {
        super.initialize(prolog, header, sessionData);
        try {
            this.documentBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        } catch (ParserConfigurationException e) {
            throw new WTException(e);
        }

        this.ibaNames = new HashSet<String>();
        this.optionNames = new HashSet<String>();
        WTContainerRef containerRef = sessionData.getContainerRef();
        for (Iterator i = header.iterator(); i.hasNext();) {
            String columnName = (String) i.next();
            if (columnName == null || columnName.trim().length() == 0) {
                continue;
            }
            if (columnName.startsWith("(") && columnName.endsWith(")")) {
                continue;
            }
            if (NON_IBA_COLUMN_NAME_SET.contains(columnName)) {
                continue;
            }
            if (OptionUtility.getOption(columnName, containerRef) != null) {
                this.optionNames.add(columnName);
            } else {
                this.ibaNames.add(columnName);
            }
        }
    }

    /**
     * Creates a new import element for the object represented by the row data.
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     *
     * @param rowData
     *            A row that represents an object. The data is in the form of a map where keys are attribute names
     *            corresponding to the table header column names, and values are string value of attributes.
     * @return ImportElement
     * @exception wt.util.WTException
     **/
    public abstract ImportElement newElement(Map rowData) throws WTException;

    /**
     * Creates a defaultUnit element and adds to the parent
     *
     * @param doc
     *            dom document
     * @param parent
     *            parent element to which the new element will be added to
     * @param rowData
     *            a map that contains key/value pairs for current context object
     * @throws WTException
     */
    protected void addDefaultUnitElement(Document doc, Element parent, Map rowData) throws WTException {
        Element defaultUnitElement = doc.createElement(ImportHndHelper.XML_TAG_DEFAULT_UNIT);
        String defaultUnit = (String) rowData.get(DEFAULT_UNIT);
        if (defaultUnit == null || defaultUnit.trim().length() == 0) {
            defaultUnitElement.appendChild(doc.createTextNode(ImportHndHelper.DEFAULT_QUANTITY_UNIT));
        } else {
            // TODO: is there a way to find the default unit? OIR?
        	//removed the toLowerCase for the SPR-2061246. So the default unit specified in the excel would be case sensitive.
            defaultUnitElement.appendChild(doc.createTextNode(defaultUnit.trim()));
        }
        parent.appendChild(defaultUnitElement);
    }

    /**
     * Creates a domainName element and adds to the parent
     *
     * @param doc
     *            dom document
     * @param parent
     *            parent element to which the new element will be added to
     * @param rowData
     *            a map that contains key/value pairs for current context object
     * @throws WTException
     */
    protected void addDomainNameElement(Document doc, Element parent, Map rowData) throws WTException {
        Element domainNameElement = doc.createElement(IxbHndHelper.XML_ATTR_DOMAIN);
        String domainName = getSessionData().getContainerRef().getReferencedContainer().getDefaultDomain().getName();
        if (!domainName.startsWith(ImportHndHelper.SEPARATOR_STRING))
            domainName = ImportHndHelper.SEPARATOR_STRING + domainName;
        domainNameElement.appendChild(doc.createTextNode(domainName.trim()));
        parent.appendChild(domainNameElement);
    }



    /**
     * Creates an externalTypeId element and adds to the parent
     *
     * @param doc
     *            dom document
     * @param parent
     *            parent element to which the new element will be added to
     * @param rowData
     *            a map that contains key/value pairs for current context object
     * @throws WTException
     */
    protected void addExternalTypeIdElement(Document doc, Element parent, Map rowData) throws WTException {
        String value = (String) rowData.get(TYPE);
        if (null != value && value.trim().length() > 0) {
            Element element = doc.createElement(IxbHndHelper.XML_EXTERNAL_TYPE_ID);
            String externalTypeId = ImportHndHelper.getExternalTypeId(value);
            logger.debug("makeExternalTypeIdElement(): id=" + value + " external id=" + externalTypeId);
            element.appendChild(doc.createTextNode(externalTypeId));
            parent.appendChild(element);
        }
    }

    /**
     * Creates a folderPath element and adds to the parent
     *
     * @param doc
     *            dom document
     * @param parent
     *            parent element to which the new element will be added to
     * @param rowData
     *            a map that contains key/value pairs for current context object
     * @throws WTException
     */
    protected void addFolderPathElement(Document doc, Element parent, Map rowData) throws WTException {

        String folderPath = (String) rowData.get(FOLDER_PATH);
        String PartNumber = (String) rowData.get(NUMBER);


        if (folderPath == null || folderPath.trim().length() == 0) {
            folderPath = getSessionData().getDirectoryPathCache();
        }
        if (folderPath == null || folderPath.trim().length() == 0) {
             folderPath = getSessionData().getContainerRef().getReferencedContainer().getDefaultCabinet().getFolderPath();
        }
        if(getSessionData().isPreview() && !folderPath.startsWith("/Default/"))
        {
        	if(!folderPath.equals("/Default")){
        		String fileName = getSessionData().getFileName();
                String sheetName = getSessionData().getSheetName();
                String rowNumber = getSessionData().getRowNumber();
                String message = new WTMessage(RESOURCE,importerResource.MSG_SHEET_INVALID_LOCATION, new Object[] {folderPath,PartNumber}).getLocalizedMessage(getSessionData().getJobLocale());
                ImportXlsHelper.reportError(ImportXlsHelper.getLocaleWarningStr(), fileName, sheetName, rowNumber, message);
        	}
        }
        Element folderPathElement = doc.createElement(IxbHndHelper.XML_ATTR_FOLDER);
        folderPathElement.appendChild(doc.createTextNode(folderPath));
        parent.appendChild(folderPathElement);
    }

    /**
     * <Purpose> Creates all (except "PartClassification") iba elements / standard attribute elements and adds to the parent.
     *
     * @param doc - dom document
     * @param parent - parent element to which the new elements will be added to
     * @param rowData - a map that contains key/value pairs for current context object
     * @throws WTException
     */
    protected void addBussinessFieldElements(Document doc, Element parent, Map rowData) throws WTException {
        boolean isSkipCopyForward = ImportHndHelper.skipCopyForward(getSessionData().getContainerRef());
    	String objectTypeStr = getObjectTypeStr(rowData);
    	Set<String> clssificationIBA = new HashSet<String>();
    	Map<String, Set> classificationMap = new HashMap<String, Set>();
        Set<String> ibaSet = getIbaNames();
		if (objectTypeStr != null && !objectTypeStr.isEmpty()) {
           List<WTException> constraintsValidationErrorList = validateIbaForConstraints(ibaSet, rowData);
           if (constraintsValidationErrorList != null && constraintsValidationErrorList.size() > 0) {
               throw new WTException(constraintsValidationErrorList.toArray());
           }
        }

        for (String ibaName : ibaSet) {
        	AttributeTypeIdentifier attrubuteTypeIdentifier =   TypeDefinitionServiceHelper.service.getAttributeTypeIdentifier(ibaName, objectTypeStr);
        	if(attrubuteTypeIdentifier == null ){
        		clssificationIBA.add(ibaName);
        		continue;
        	}
        	AttributeDefinitionReadView attributeDefinitionReadView = TypeDefinitionServiceHelper.service.getAttributeDefView(attrubuteTypeIdentifier);
        	boolean isClassificationIBA = ImportHndHelper.isClassificationConstrained(attributeDefinitionReadView);

            String ibaType = ImportHndHelper.getIbaSdaTypeByPath(ibaName,objectTypeStr, getSessionData());
            String ibaValue = (String) rowData.get(ibaName);
            String dataTypeQlifier = ImportHndHelper.getDatatypeQualifier(attributeDefinitionReadView);

            // Fix for SPR Task: 7308362 && SPR Task : 8074650 (Fixed issue on validation with base unit)              
            if (ibaType.equals("wt.units.FloatingPointWithUnits")) {
				validateIbaForBaseUnit(rowData, objectTypeStr, ibaName, attrubuteTypeIdentifier);
            }

            //if IBA is classification node then get all the IBAs attached with node.
            if(isClassificationIBA){
            	String[] ibaValues = ibaValue.split(IBA_VALUE_SEPARATOR);
                for (String value : ibaValues) {
                	 Set<AttributeTypeIdentifier> classificationNodeIBA = new HashSet<AttributeTypeIdentifier>();
     	    		TypeDefinitionReadView typeView = TypeDefinitionServiceHelper.service.getTypeDefView(com.ptc.core.lwc.common.AttributeTemplateFlavor.LWCSTRUCT, ImportHndHelper.NAMESPACE, value);
     	    		if (typeView != null) {
     	    			classificationNodeIBA.addAll(typeView.getAttributeTypeIdentifiers());
     	    		}
     	    		Set<String> classIBA = new HashSet<String>();
     	    		Iterator itr = classificationNodeIBA.iterator();
     	    		while(itr.hasNext()){
     	    			AttributeTypeIdentifier atrs = (AttributeTypeIdentifier) itr.next();
     	    			String atrName = atrs.getAttributeName();
     	    			classIBA.add(atrName);
     	    		}
     	    		classificationMap.put(value, classIBA);
                }

            }
           
            if ((ibaValue != null && ibaValue.length() > 0) || isSkipCopyForward) {
            	addBusinessFieldElement(doc, parent, ibaName, ibaValue, ibaType,  rowData,"type", dataTypeQlifier, objectTypeStr);
            }
        }
        //process all classification IBAs
        for (String ibaName : clssificationIBA) {
        	try {
        		boolean processFlag = false;
        		Set<String> classificationNodes = classificationMap.keySet();
        		String ibaValue = (String) rowData.get(ibaName);
        		for (String classificationNode : classificationNodes) {
        			Set<String> setVal = classificationMap.get(classificationNode);
        			if(setVal.contains(ibaName)){
        					processFlag =true;
        				break;
        			}
        		}
        		//Fix for SPR 2246514: When part is reclassified, the attributes from earlier classification remains on Part as ad-hoc attribute.
        		//This ad-hoc attribute should be taken care while import from spreadsheet. So adding  attributes as ad-hoc either it is a classification
        		//attribute or has a valid AttributeDefDefaultView.
        		AttributeDefDefaultView attrDef = IBADefinitionHelper.service.getAttributeDefDefaultViewByPath(ibaName);
                if(processFlag || attrDef!=null ){

				  String attDataTypeDef =ImportHndHelper.getDatatype(attrDef.getAttributeDefinitionClassName());

				  IBADefinitionCache IBA_DEF_CACHE = IBADefinitionCache.getIBADefinitionCache();
				  AttributeDefinition attDef = IBA_DEF_CACHE.getAttributeDefinition( ibaName );
				  String datatypeQualifier = ImportHndHelper.getDatatypeQualifier(attDef);

				  String defClassName = attDataTypeDef.substring(attDataTypeDef.lastIndexOf(".") + 1);
				  defClassName = defClassName.replaceFirst("Definition", "Value");
				  String attDataType =ImportHndHelper.getDatatype(defClassName);
				  if ((ibaValue != null && ibaValue.length() > 0) || isSkipCopyForward) 
				    addBusinessFieldElement(doc, parent, ibaName, ibaValue, attDataType,  rowData, "ad_hoc", datatypeQualifier,objectTypeStr);
        		}else if(ibaValue!= null && !ibaValue.isEmpty()){
        			throw new WTException(RESOURCE, importerResource.ERROR_IBA_ATTRIBUTE_NOT_FOUND, new Object[] {ibaName});
        		}
			} catch (RemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
    }

    /**
     * Creates an iba or excludedIba element and adds to the parent
     *
     * @param doc
     *            dom document
     * @param parent
     *            parent element to which the new element will be added to
     * @param ibaPath
     *            IBA path
     * @param ibaValue
     *            IBA value as a string
     * @param ibaType
     *            unqualified IBA value class name (for example, "BooleanValue")
     * @param isExcludedIba
     *            a boolean flag indicating whether the element is an iba or excludedIba
     * @throws WTException
     */

    protected void addBusinessFieldElement(Document doc, Element parent, String ibaPath, String ibaValue,
            String ibaType, Map rowData, String category, String datatypeQualifier, String objectTypeStr) throws WTException {
    	String clientName = PreferenceClient.WINDCHILL_CLIENT_NAME;

    	if (logger.isTraceEnabled())
    	    logger.trace("ibaType: " + ibaType + " ibaValue: " + ibaValue);
    	if (ibaValue != null && ibaValue.length() > 0 && ibaType.equals(IntegerValue.class.getSimpleName())) {
    	    ibaValue = toIntegerString(ibaValue);
    	    if (logger.isTraceEnabled())
    	        logger.trace("new ibaValue: " + ibaValue);
    	}
		Locale locale = SessionHelper.getLocale();
        Element ibaElement = doc.createElement(IxbHndHelper.XML_BUSINESS_FIELD);

        Element ibabusinessFieldIDElement = doc.createElement(IxbHndHelper.XML_BUSINESS_FIELD_ID);

        Element ibasolutionElement = doc.createElement(IxbHndHelper.XML_SOLUTION);
        ibasolutionElement.appendChild(doc.createTextNode(clientName));
        ibabusinessFieldIDElement.appendChild(ibasolutionElement);

        if(category.equals("ad_hoc")){
        	Element ibanamespaceElement = doc.createElement(IxbHndHelper.XML_NAMESPACE);

            Element ibacategoryElement = doc.createElement(IxbHndHelper.XML_CATEGORY);
            ibacategoryElement.appendChild(doc.createTextNode(category));
            ibanamespaceElement.appendChild(ibacategoryElement);

            ibabusinessFieldIDElement.appendChild(ibanamespaceElement);

            Element ibanameElement1 = doc.createElement(IxbHndHelper.XML_BUSINESS_FIELD_ID_NAME);
            ibanameElement1.appendChild(doc.createTextNode(ibaPath));
            ibabusinessFieldIDElement.appendChild(ibanameElement1);

            ibaElement.appendChild(ibabusinessFieldIDElement);

        }else{
        	Element ibanamespaceElement = doc.createElement(IxbHndHelper.XML_NAMESPACE);

            Element ibacategoryElement = doc.createElement(IxbHndHelper.XML_CATEGORY);
            ibacategoryElement.appendChild(doc.createTextNode(category));
            ibanamespaceElement.appendChild(ibacategoryElement);

            Element ibanameElement = doc.createElement(IxbHndHelper.XML_NAMESPACE_NAME);
            ibanameElement.appendChild(doc.createTextNode(objectTypeStr));
            ibanamespaceElement.appendChild(ibanameElement);

            ibabusinessFieldIDElement.appendChild(ibanamespaceElement);

            Element ibanameElement1 = doc.createElement(IxbHndHelper.XML_BUSINESS_FIELD_ID_NAME);
            ibanameElement1.appendChild(doc.createTextNode(ibaPath));
            ibabusinessFieldIDElement.appendChild(ibanameElement1);

            ibaElement.appendChild(ibabusinessFieldIDElement);
        }


        Element ibadatatypeElement1 = doc.createElement(IxbHndHelper.XML_DATATYPE);
        ibadatatypeElement1.appendChild(doc.createTextNode(ibaType));
        ibaElement.appendChild(ibadatatypeElement1);
		String[] values;
		if (singleValuedIBA.contains(ibaPath)) {
			String[] mayContainPipeChar = { ibaValue };
			values = mayContainPipeChar;
		} else {
			values = ibaValue.split(IBA_VALUE_SEPARATOR);
		}
		for (String value : values) {
            // SPR #6792107 - Import from Spreadsheet failed to validate import file using preference 
            // "Empty Values When Importing from Spreadsheet" to Yes.
                value = getWCFormatedValue(ibaType, value, locale);
                Element ibavalueElement1 = doc.createElement(IxbHndHelper.XML_VALUE);
                ibavalueElement1.appendChild(doc.createTextNode(value));
                ibaElement.appendChild(ibavalueElement1);
            }
            if(datatypeQualifier != null && !datatypeQualifier.isEmpty()){
                if(!category.equals("ad_hoc")){
                    Element ibavalueElement1 = doc.createElement(IxbHndHelper.XML_DATATYPE_QUALIFIER);
                    ibavalueElement1.appendChild(doc.createTextNode(datatypeQualifier));
                    ibaElement.appendChild(ibavalueElement1);
                }else{
                    Element ibavalueElement1 = doc.createElement(IxbHndHelper.XML_DATATYPE_QUALIFIER);
                    ibavalueElement1.appendChild(doc.createTextNode(datatypeQualifier));
                    ibaElement.appendChild(ibavalueElement1);
                }
            }
        parent.appendChild(ibaElement);
    }

    public static String getWCFormatedValue(String ibaType,  String value, Locale locale)
            throws UnitFormatException, WTException {
        if (value != null && !StringUtils.isEmpty(value)) {
            if (ibaType.equals("wt.units.FloatingPointWithUnits")
                    || ibaType.equals("com.ptc.core.meta.common.FloatingPoint")) {
                try {
                    value = getWCFormatedRealValue(ibaType, value, locale);
                } catch (ParseException e) {
                    logger.error("Failed to convert cell value to a windchill real value");
                    throw new WTException(e);
                }
            }
            if (ibaType.equals("com.ptc.core.meta.common.Hyperlink")) {
                value = getWCFormatedURLValue(value);
            }
        }
        return value;
    }

    private static String getWCFormatedURLValue(String value) {
        if (value.endsWith(")") && value.contains("(")) {
            StringTokenizer tocken = new StringTokenizer(value, "(");
            String url = (String) tocken.nextElement();
            String val2 = (String) tocken.nextElement();
            String lableUrl = val2.replace(")", "");
            value = url + "|" + lableUrl;
        }
        return value;
    }

    private static String getWCFormatedRealValue(String ibaType, String value, Locale locale)
            throws ParseException, UnitFormatException {
        if (ibaType.equals("wt.units.FloatingPointWithUnits")) {
            FloatingPointWithUnits floatingPointUnit;
            floatingPointUnit = DataTypesUtility.toFloatingPointWithUnits(value, locale);
            value = floatingPointUnit.getValue() + ImportHndHelper.UFID_SEPARATOR
                    + SIGNIFICANT_FIGURES + ImportHndHelper.UFID_SEPARATOR
                    + floatingPointUnit.getUnits();
        }
        if (ibaType.equals("com.ptc.core.meta.common.FloatingPoint")) {
            FloatingPointWithUnits floatingPointUnit = DataTypesUtility
                    .toFloatingPointWithUnits(value, locale);
            value = floatingPointUnit.getValue() + ImportHndHelper.UFID_SEPARATOR
                    + SIGNIFICANT_FIGURES;
        }
        return value;
    }

    /**
     * Converts the string representing an integer IBA value to a real integer string by getting rid of decimal points,
     * etc.
     */
    private String toIntegerString(String number) throws WTException {
        if (number == null || number.trim().length() == 0)
            return number;
        try {
            Double value = Double.valueOf(number);
            double double_value = value.doubleValue();
            if (double_value > Long.MAX_VALUE || double_value < Long.MIN_VALUE) {
                throw new WTException("Number out of range: " + number + " [" + Long.MIN_VALUE + ", " + Long.MAX_VALUE
                        + "]");
            }
            return String.valueOf(value.longValue());
        } catch (NumberFormatException e) {
            throw new WTException(e);
        }
    }

    /**
     * Creates a lifecycleInfo element and adds to the parent. The element contains lifecycleTemplateName and
     * lifecycleState.
     *
     * @param doc
     *            dom document
     * @param parent
     *            parent element to which the new element will be added to
     * @param rowData
     *            a map that contains key/value pairs for current context object
     * @throws WTException
     */
    protected void addLifeCycleInfoElement(Document doc, Element parent, Map rowData) throws WTException {
        logger.debug("In addLifeCycleInfoElement method ");
        Element lifecycleInfoElement = doc.createElement(ImportHndHelper.XML_TAG_LIFECYCLEINFO);
        String typeId = (String) rowData.get(TYPE);
        String state = (String) rowData.get(STATE);
        String containerPath = (String) rowData.get(CONTAINER);
        WTContainerRef wtContainerRef = getSessionData().getContainerRef();
        if (containerPath == null || containerPath.trim().length() == 0) {
            containerPath = WTContainerHelper.getPath(wtContainerRef);
        }
        // Call: 7771174 support for specifying lifecycle template in spreadsheet.
        // previously, we were retrieving the lifecycle template name from OIRs using simple assumptions.
        // these don't hold when more sophisticated OIRs with attribute value
        // based logic maybe involved.
        // the IXB framework bypasses OIRs so skipping this here in the spreadsheet code won't allow
        // for it to happen in a different place. the workaround is to allow customers to specify the
        // lifecycle template name directly in the spreadsheet.
        String lifecycleTemplateName = (String) rowData.get(LIFECYCLE);
        LifeCycleTemplate lifeCycleTemplate = null;
        // Fix for SPR 5138075
        // If lifecycleTemplate is provided in spreadsheet and state is not provided then get it from the
        // given lifecycleTemplate
        if (lifecycleTemplateName != null && !lifecycleTemplateName.trim().isEmpty()) {
            if (state == null || state.trim().isEmpty()) {
                lifeCycleTemplate = LifeCycleHelper.service.getLifeCycleTemplate(lifecycleTemplateName,
                        wtContainerRef);
                Vector phaseTemplates = LifeCycleHelper.service.getPhaseTemplates(lifeCycleTemplate);
                PhaseTemplate phaseTemplate = (PhaseTemplate) phaseTemplates.firstElement();
                state = phaseTemplate.getPhaseState().toString();
                if (logger.isDebugEnabled()) {
                    logger.debug("State: " + state);
                }
            }
        } else {
            // fix for Customer case 13029267 , SPR Task: 5667541
            // Import should look for OIR for initial creation only. For any iteration or revision it should behave like
            // Check Out or Check In or Revise ,that is the Lifecycle template should not be changed
            boolean partExist = isExistingPart(wtContainerRef, rowData);
            if (!partExist) {
                lifeCycleTemplate = ImportHndHelper.getLifecycleTemplate(containerPath, typeId, getSessionData());
                lifecycleTemplateName = lifeCycleTemplate.getName();
            }

        }
        boolean hasLCT = lifecycleTemplateName != null && lifecycleTemplateName.trim().length() > 0;
        boolean hasLCS = state != null && state.trim().length() > 0;

        if (!hasLCT && !hasLCS) {
            return;
        }

        if (hasLCT) {
            Element lifecycleTemplateNameElement = doc.createElement(ImportHndHelper.XML_TAG_LIFECYCLE_TEMPLATE_NAME);
            lifecycleTemplateNameElement.appendChild(doc.createTextNode(lifecycleTemplateName));
            lifecycleInfoElement.appendChild(lifecycleTemplateNameElement);
        }

        if (hasLCS) {

            Element lifecycleStateElement = doc.createElement(ImportHndHelper.XML_TAG_LIFECYCLE_STATE);
            lifecycleStateElement.appendChild(doc.createTextNode(state));
            lifecycleInfoElement.appendChild(lifecycleStateElement);
        }

        parent.appendChild(lifecycleInfoElement);
    }

    /**
     * Creates a name element and adds to the parent
     *
     * @param doc
     *            dom document
     * @param parent
     *            parent element to which the new element will be added to
     * @param rowData
     *            a map that contains key/value pairs for current context object
     * @throws WTException
     */
    protected void addNameElement(Document doc, Element parent, Map rowData) throws WTException {
        Element nameElement = doc.createElement(IxbHndHelper.XML_ATTR_NAME);
        String name = (String) rowData.get(NAME);
        nameElement.appendChild(doc.createTextNode(name));
        parent.appendChild(nameElement);
    }

    /**
     * Creates a number element and adds to the parent
     *
     * @param doc
     *            dom document
     * @param parent
     *            parent element to which the new element will be added to
     * @param rowData
     *            a map that contains key/value pairs for current context object
     * @throws WTException
     */
    protected void addNumberElement(Document doc, Element parent, Map rowData) throws WTException {
    	 String number = (String) rowData.get(NUMBER);
         if (number == null || number.trim().length() == 0) {
             TypeIdentifier typeId = ImportHndHelper.getTypeIdentifier((String) rowData.get(TYPE));
             WTContainerRef targetContainerRef = getSessionData().getContainerRef();
             boolean isAutoNumber = EnterpriseHelper.isAutoNumber(typeId, targetContainerRef);
             if (!isAutoNumber) { // this should never happen since it's already been validated
                 throw new WTException(RESOURCE, importerResource.MSG_MISSING_NUMBER, new Object[] {
                         typeId.getTypename(), targetContainerRef.getName() });
             }
             if(getSessionData().isPreview()){
             	number = DUMMYNUMBER_GENRATED;
             	logger.debug("Number not set, setting dummy number for preview step In Import will generate autonumber " + typeId.getTypename() + ", obtained number: "
                     + number);
             }
             else{
//             	number = EnterpriseHelper.getNumber(typeId, targetContainerRef);
            	 number = DUMMYNUMBER_GENRATED;
             	logger.debug("Number not set, using autonumber for type " + typeId.getTypename() + ", obtained number: "
                     + number);
             }
         }
         Element numberElement = doc.createElement(IxbHndHelper.XML_ATTR_NUMBER);
         numberElement.appendChild(doc.createTextNode(number));
         parent.appendChild(numberElement);

    }

    /**
     * Creates an objectContainerPath element and adds to the parent
     *
     * @param doc
     *            dom document
     * @param parent
     *            parent element to which the new element will be added to
     * @param rowData
     *            a map that contains key/value pairs for current context object
     * @throws WTException
     */
    protected void addObjectContainerPathElement(Document doc, Element parent, Map rowData) throws WTException {
        String containerPath = WTContainerHelper.getPath(getSessionData().getContainerRef());
        Element objectContainerPathElement = doc.createElement(IxbHndHelper.XML_TAG_CONTAINER_PATH);
        objectContainerPathElement.appendChild(doc.createTextNode(containerPath));
        parent.appendChild(objectContainerPathElement);
    }

    /**
     * Creates an empty ObjectID element and adds to the parent
     *
     * @param doc
     *            dom document
     * @param parent
     *            parent element to which the new element will be added to
     * @param rowData
     *            a map that contains key/value pairs for current context object
     * @throws WTException
     */
    protected void addObjectIDElement(Document doc, Element parent, Map rowData) throws WTException {
        Element objectIDElement = doc.createElement(IxbHndHelper.XML_TAG_UPPER_OBJECT_ID);
        parent.appendChild(objectIDElement);
    }

    /**
     * get the WTOrganization from rowData
     *
     * @param rowData
     * @return
     * @throws WTException
     */
    protected WTOrganization getWTOrganization(Map rowData) throws WTException {
        String orgIdOrName = (String) rowData.get(ORGANIZATION_ID);
        logger.debug("AbstractClassElementBuilder.getWTOrganization(): orgIdOrName = "
                + orgIdOrName);
        WTOrganization org = null;
        if (orgIdOrName != null && orgIdOrName.trim().length() > 0) {
            org = ImportHndHelper.getWTOrganizationByIdOrName(orgIdOrName);
        } else {
            org = getSessionData().getContainerRef().getReferencedContainerReadOnly().getOrganization();
        }
        return org;
    }
    /**
     * Creates an organizationId element and adds to the parent
     *
     * @param doc
     *            dom document
     * @param parent
     *            parent element to which the new element will be added to
     * @param rowData
     *            a map that contains key/value pairs for current context object
     * @throws WTException
     */
    protected void addOrganizationIdAndNameElement(Document doc, Element parent, Map rowData) throws WTException {
        WTOrganization org = getWTOrganization(rowData);
        logger.debug("AbstractClassElementBuilder.addOrganizationIdElement(): org = " + org);
        String organizationName = org.getName();
        String organizationId = ImportHndHelper.getOrganizationUniqueId(org);
        logger.debug("AbstractClassElementBuilder.addOrganizationIdElement(): organizationId = " + organizationId);
        Element organizationIdElement = doc.createElement(IxbHndHelper.XML_ATTR_ORGANIZATION_ID);
        Element organizationNameElement = doc.createElement(IxbHndHelper.XML_ATTR_ORGANIZATION_NAME);
        organizationIdElement.appendChild(doc.createTextNode(organizationId));
        organizationNameElement.appendChild(doc.createTextNode(organizationName));
        parent.appendChild(organizationIdElement);
        parent.appendChild(organizationNameElement);
    }

    protected void addReferenceValueElement(Document doc, Element parent) {
        Element ibaElement = doc.createElement(IxbHndHelper.XML_IBA);

        Element ibaPathElement = doc.createElement(IxbHndHelper.XML_IBA_PATH);
        ibaPathElement.appendChild(doc.createTextNode("EXCLUSION"));
        ibaElement.appendChild(ibaPathElement);

        Element ibaValueElement = doc.createElement(IxbHndHelper.XML_IBA_VALUE);
        ibaValueElement.appendChild(doc.createTextNode(OptionExclusionReference.OPTION_EXCLUSION_REFERENCE_KEY));
        ibaElement.appendChild(ibaValueElement);

        Element ibaTypeElement = doc.createElement(IxbHndHelper.XML_IBA_TYPE);
        ibaTypeElement.appendChild(doc.createTextNode("ReferenceValue"));
        ibaElement.appendChild(ibaTypeElement);

        Element ibaDependencyElement = doc.createElement(IxbHndHelper.XML_IBA_DEPENDENDENCY);
        ibaDependencyElement.appendChild(doc.createTextNode("Exclusion"));
        ibaElement.appendChild(ibaDependencyElement);

        parent.appendChild(ibaElement);
    }

    /**
     * Creates a SecurityLabels element and adds to the parent
     *
     * @param doc
     *            dom document
     * @param parent
     *            parent element to which the new element will be added to
     * @param rowData
     *            a map that contains key/value pairs for current context object
     * @throws WTException
     */
    protected void addSecurityLabelsElement(Document doc, Element parent, Map rowData) throws WTException {
        Element securityLabelsElement = doc.createElement(IxbHndHelper.XML_SECURITY_LABELS);
        String securityLabels = (String) rowData.get(SECURITY_LABELS);
        if (logger.isTraceEnabled())
            logger.trace("Security Labels = \"" + securityLabels + "\"");
        if (securityLabels == null || securityLabels.trim().length() == 0) {
            return;
        }

        String[] schemes = securityLabels.split(SECURITY_LABELS_SCHEME_SEPARATOR);
        if (schemes == null || schemes.length == 0) {
            return;
        }

        for (String scheme : schemes) {
            if (scheme == null || scheme.trim().length() == 0) {
                logger.debug("Empty scheme skipped");
                continue;
            }
            String[] nameValue = scheme.split(SECURITY_LABELS_NAME_VALUE_SEPARATOR);
            if (nameValue == null || nameValue.length != 2) {
                logger.debug("Invalid security label data ignored: \"" + scheme + "\"");
                continue;
            }
            if (logger.isTraceEnabled())
                logger.trace("scheme:" + scheme + " name:" + nameValue[0] + " value:" + nameValue[1]);
            Element securityLabelElement = doc.createElement(IxbHndHelper.XML_SECURITY_LABEL);
            securityLabelElement.setAttribute(IxbHndHelper.XML_ATTR_NAME, nameValue[0]);
            securityLabelElement.setAttribute(IxbHndHelper.XML_ATTR_SECURITY_LABEL_VALUE, nameValue[1]);
            if (logger.isTraceEnabled()) {
                logger.trace("has name attr: " + securityLabelElement.getAttribute(IxbHndHelper.XML_ATTR_NAME));
                logger.trace("has attrs: " + securityLabelElement.hasAttributes());
            }
            securityLabelsElement.appendChild(securityLabelElement);
        }

        parent.appendChild(securityLabelsElement);
    }

    /**
     * Creates a versionInfo element and adds to the parent. The element contains versionId, iterationId, versionLevel,
     * and series.
     *
     * @param doc
     *            dom document
     * @param parent
     *            parent element to which the new element will be added to
     * @param rowData
     *            a map that contains key/value pairs for current context object
     * @throws WTException
     */
    /**
     * @param doc
     * @param parent
     * @param rowData
     * @throws WTException
     */
    protected void addVersionInfoElement(Document doc, Element parent, Map rowData) throws WTException {
        String versionId = (String) rowData.get(VERSION);
        /*if (versionId == null || versionId.trim().length() == 0) {
            logger.debug("version id not found, skip creating version info element...");
            return;
        }*/

        String typeId = (String) rowData.get(TYPE);
        String containerPath = (String) rowData.get(CONTAINER);
        if (containerPath == null || containerPath.trim().length() == 0) {
            containerPath = WTContainerHelper.getPath(getSessionData().getContainerRef());
        }
        if (logger.isDebugEnabled())
            logger.debug("typeId=" + typeId + " container path=" + containerPath);

        Element versionInfoElement = doc.createElement(IxbHndHelper.XML_ATTR_VERSION_INFO);
        Element versionIdElement = doc.createElement(ImportHndHelper.XML_TAG_VERSION_ID);
        versionIdElement.appendChild(doc.createTextNode(versionId));
        versionInfoElement.appendChild(versionIdElement);
        Element iterationIdElement = doc.createElement(ImportHndHelper.XML_TAG_ITERATION_ID);
        // iterationIdElement.appendChild(doc.createTextNode(""));
        versionInfoElement.appendChild(iterationIdElement);
        Element versionLevelElement = doc.createElement(ImportHndHelper.XML_TAG_VERSION_LEVEL);
        // versionLevelElement.appendChild(doc.createTextNode(""));
        versionInfoElement.appendChild(versionLevelElement);
        //as series is not mandatory attribute in X-24 DTD so removing this. this might resolve the SPR 2182518 for upgrade server.
//        Element seriesElement = doc.createElement(ImportHndHelper.XML_TAG_VERSION_SERIES);
//        String series = ImportHndHelper.getVersionSeries(containerPath, typeId, getSessionData());
//        if (logger.isDebugEnabled())
//            logger.debug("series=" + series);
//        seriesElement.appendChild(doc.createTextNode(series));
//        versionInfoElement.appendChild(seriesElement);


        //if user gives only one value i.e. BRANCH_REVISION it will get ignored.
        String branchPoint = (String) rowData.get(WTPartElementBuilder.BRANCH_REVISION);
        if ( branchPoint != null && branchPoint.trim().length() != 0 ) {
        	 String derivedFrom = (String) rowData.get(WTPartElementBuilder.BRANCH_VIEW);

        	 if(derivedFrom != null && derivedFrom.trim().length() == 0 ){
        		 derivedFrom = IxbHndHelper.XML_VALUE_NULL;
        	 }

        	Element derivedFromElement = doc.createElement(ImportHndHelper.XML_TAG_BRANCHPOINT);
        	Element ObjectReference = doc.createElement(IxbHndHelperConstants.XML_TAG_OBJECT_REFERENCE);
        	derivedFromElement.appendChild(ObjectReference);
        	Element ufid = doc.createElement(IxbHndHelperConstants.XML_TAG_UFID);
        	ObjectReference.appendChild(ufid);
        	ufid.appendChild(doc.createTextNode(derivedFrom));
            versionInfoElement.appendChild(derivedFromElement);

        	Element branchPointElement = doc.createElement(ImportHndHelper.XML_TAG_DERIVEDFROM);
        	Element branchObjectReference = doc.createElement(IxbHndHelperConstants.XML_TAG_OBJECT_REFERENCE);
        	branchPointElement.appendChild(branchObjectReference);
        	Element branchufid = doc.createElement(IxbHndHelperConstants.XML_TAG_UFID);
        	branchObjectReference.appendChild(branchufid);
        	branchufid.appendChild(doc.createTextNode(branchPoint));
        	versionInfoElement.appendChild(branchPointElement);

        	Element predecessorElement = doc.createElement(ImportHndHelper.XML_TAG_PREDECESSOR);
        	Element predecessorObjectReference = doc.createElement(IxbHndHelperConstants.XML_TAG_OBJECT_REFERENCE);
        	predecessorElement.appendChild(predecessorObjectReference);
        	Element predecessorufid = doc.createElement(IxbHndHelperConstants.XML_TAG_UFID);
        	predecessorObjectReference.appendChild(predecessorufid);
            versionInfoElement.appendChild(predecessorElement);
        }
        //--
        parent.appendChild(versionInfoElement);

    }

    /**
     * Returns the document builder
     *
     * @return
     */
    protected DocumentBuilder getDocumentBuilder() {
        return this.documentBuilder;
    }

    /**
     * Validates the input row data and throws exception if the row data is invalid
     *
     * @param rowData
     * @throws WTException
     */
    protected abstract void validateRowData(Map rowData) throws WTException;

    /**
     * Returns the set of IBA attribute names
     */
    protected Set<String> getIbaNames() {
        return this.ibaNames;
    }

    /**
     * returns the set of option names in columns
     * @return
     */
    protected Set<String> getOptionNames() {
        return this.optionNames;
    }

    /**
     * <Purpose> Retrieves the object type of the externalTypeId which is passed in rowData map
     * @param rowData
     * @return actual object type
     * @throws WTException
     */
    private String getObjectTypeStr(Map rowData) throws WTException{
    	String value = (String) rowData.get(TYPE);
    	if(value == ""){
    		throw new WTException(RESOURCE, importerResource.ERROR_INVALID_TYPE, new Object[]{value});
    	}
    	String objectTypeStr = null;

    	if (null != value && value.trim().length() > 0) {
        	TypeIdentifier typeID = ImportHndHelper.getTypeIdentifier(value);
        	objectTypeStr = ((WCTypeIdentifier)typeID).getLeafName();
        }


        return objectTypeStr;
    }

    private List<WTException> validateIbaForConstraints(Set<String> ibaSet, Map rowData) throws WTException {

        Map<String, Map<String, Map<String, EnumeratedSet>>> constraintsMapOnIbaByObjectType = updateAndGetConstraintsOnIba(
                ibaSet, rowData);
        String objectType = rowData.get("Type").toString();

        Map<String, Map<String, EnumeratedSet>> tempMap = constraintsMapOnIbaByObjectType.get(objectType);

		Locale locale = getSessionData().getJobLocale();
        List<WTException> constraintsValidationErrorList = new ArrayList<WTException>();
        for (String ibaName : ibaSet) {

            Map<String, EnumeratedSet> constraintsNameValuesMap = tempMap.get(ibaName);
            String ibaValue = (String) rowData.get(ibaName);
            if (constraintsNameValuesMap!=null && constraintsNameValuesMap.containsKey(REQUIRED_CONSTRAINT_STR)) {

                if (ibaValue != null && ibaValue.isEmpty()) {
                    String message = new WTException(RESOURCE, importerResource.VALUE_REQUIRED_FOR_IBA,
                            new Object[] { ibaName }).getLocalizedMessage(locale);
                    constraintsValidationErrorList.add(new WTException(message));
                }
            }

            if (constraintsNameValuesMap!=null && constraintsNameValuesMap.containsKey(LEGALVALUE_CONSTRAINT_STR)) {
            	String objectTypeStr = getObjectTypeStr(rowData);
            	AttributeTypeIdentifier attrubuteTypeIdentifier = TypeDefinitionServiceHelper.service
                           .getAttributeTypeIdentifier(ibaName, objectTypeStr);
            	TypeIdentifier tid = TypedUtility.getTypeIdentifier(objectTypeStr);
            	TypeInstance ti = TypedUtility.prepare( tid, new AttributeTypeIdentifier[]{attrubuteTypeIdentifier}, OperationIdentifier.newOperationIdentifier(OperationIdentifierConstants.UPDATE), locale, true, false );       // 	EnumeratedSet enumValueSet = constraintDefinitionReadView.ge
                AttributeTypeSummary ats = ti.getAttributeTypeSummary(attrubuteTypeIdentifier);
            	DataSet LegalValueSet = ats.getLegalValueSet();
            	List<String> legalValueDisplayList = new ArrayList<String>();
            	if (!constraintsNameValuesMap.containsKey(REQUIRED_CONSTRAINT_STR)) legalValueDisplayList.add("");
            	if(LegalValueSet instanceof DiscreteSet) {
            		for (Object display : ((DiscreteSet)LegalValueSet).getElements()) {
            			legalValueDisplayList.add(display.toString());
                    }
            	}
                String[] ibaValuesforLegal = ibaValue.split(IBA_VALUE_SEPARATOR);
                for (String value : ibaValuesforLegal){
                if ((!legalValueDisplayList.contains(value)) && (LegalValueSet instanceof DiscreteSet)){

                    String message = new WTException(RESOURCE, importerResource.VALUE_NOT_IN_ENUMERATION_LIST,
                            new Object[] { ibaName, LegalValueSet.toString() }).getLocalizedMessage(locale);
                    constraintsValidationErrorList.add(new WTException(message));
                }
                }
            }

            if (constraintsNameValuesMap!=null && constraintsNameValuesMap.containsKey(ENUMERATION_CONSTRAINT_STR)) {

            	EnumeratedSet enumValueSet = constraintsNameValuesMap.get(ENUMERATION_CONSTRAINT_STR);
            	List<String> enumValueDisplayList = new ArrayList<String>();
            	if (!constraintsNameValuesMap.containsKey(REQUIRED_CONSTRAINT_STR)) enumValueDisplayList.add("");
                for (Object display : enumValueSet.getElements()) {
                	enumValueDisplayList.add(display.toString());
                }
                String[] ibaValues = ibaValue.split(IBA_VALUE_SEPARATOR);
                for (String value : ibaValues){
                if (!enumValueDisplayList.contains(value)) {
                    if (enumValueDisplayList.size() != 0 &&  enumValueDisplayList.get(0) == "") enumValueDisplayList.remove(0);
                    String message = new WTException(RESOURCE, importerResource.VALUE_NOT_IN_ENUMERATION_LIST,
                            new Object[] { ibaName, enumValueDisplayList.toString() }).getLocalizedMessage(locale);
                    constraintsValidationErrorList.add(new WTException(message));

                }

            }
        }
        }
        return constraintsValidationErrorList;
    }

    private Map<String, Map<String, Map<String, EnumeratedSet>>> updateAndGetConstraintsOnIba(Set<String> ibaSet,
            Map rowData) throws WTException {

        Map<String, Map<String, Map<String, EnumeratedSet>>> constraintsMapOnIbaByObjectType = getSessionData()
                .getConstraintsMapOnIbaByObjectType();
        String objectType = rowData.get("Type").toString();
        Map<String, EnumeratedSet> constraintsNameValuesMap =null;

        if (constraintsMapOnIbaByObjectType.containsKey(objectType)) {
            return constraintsMapOnIbaByObjectType;
        } else {

            Map<String, Map<String, EnumeratedSet>> tempMap = new HashMap<String, Map<String, EnumeratedSet>>();
            String objectTypeStr = getObjectTypeStr(rowData);
			getSessionData().setJobLocale(WTContext.getContext().getLocale());
            Locale locale = getSessionData().getJobLocale();
            for (String ibaName : ibaSet) {

                AttributeTypeIdentifier attrubuteTypeIdentifier = TypeDefinitionServiceHelper.service
                        .getAttributeTypeIdentifier(ibaName, objectTypeStr);

                if (attrubuteTypeIdentifier != null) {



                    AttributeDefinitionReadView attributeDefinitionReadView = TypeDefinitionServiceHelper.service
                            .getAttributeDefView(attrubuteTypeIdentifier);


                    if(attributeDefinitionReadView!=null){
                        Collection<ConstraintDefinitionReadView> constraintsDefMap = attributeDefinitionReadView
                                .getAllConstraints();
                        constraintsNameValuesMap = new HashMap<String, EnumeratedSet>();
                        EnumeratedSet enumValueSet = null;
                        for (ConstraintDefinitionReadView constraintDefinitionReadView : constraintsDefMap) {

                            PropertyValueReadView propertyViewDef = constraintDefinitionReadView.getRule()
                                    .getPropertyValueByName("displayName");

                            if (propertyViewDef != null && propertyViewDef.getValue().equals(LEGALVALUE_CONSTRAINT_STR) && !constraintDefinitionReadView.isDisabled()) {
                            	constraintsNameValuesMap.put(LEGALVALUE_CONSTRAINT_STR, null);
                            }
							if (propertyViewDef != null && propertyViewDef.getValue().equals(SINGLE_VALUE_CONSTRAINT_STR) && !constraintDefinitionReadView.isDisabled()) {
								singleValuedIBA.add(ibaName);
							}

                            if (propertyViewDef != null && propertyViewDef.getValue().equals(REQUIRED_CONSTRAINT_STR) && !constraintDefinitionReadView.isDisabled()) {
                                if (constraintDefinitionReadView.getAllConditions() != null && !constraintDefinitionReadView.getAllConditions().isEmpty()) {
                                    Set<ConstraintDefinitionReadView> setOfConditions = constraintDefinitionReadView.getAllConditions();
                                    Iterator iteratorOfConditions = setOfConditions.iterator();
                                    while (iteratorOfConditions.hasNext()) {
                                        ConstraintDefinitionReadView definitionReadViewForCondtion  =  (ConstraintDefinitionReadView) iteratorOfConditions.next();
                                        Boolean checkCondtion = checkRequiredConstarintsConditions(definitionReadViewForCondtion,objectTypeStr,rowData);
                                        if (checkCondtion) {
                                            constraintsNameValuesMap.put(REQUIRED_CONSTRAINT_STR, null);
                                            break;
                                        }
                                    }
                                } else {
                                    constraintsNameValuesMap.put(REQUIRED_CONSTRAINT_STR, null); 
                                }
                                
                            }

                            if (propertyViewDef != null && propertyViewDef.getValue().equals(ENUMERATION_CONSTRAINT_STR) && !constraintDefinitionReadView.isDisabled()) {
                                // If there are multiple enumerated constraints defined, sometimes due to hierarchical propagation, we need to consider them as well 
                                if (enumValueSet != null){
                                    EnumeratedSet enumValueSettemp = constraintDefinitionReadView.getEnumDef().getEnumeratedSet(locale);
                                    DataSet tempDataSet = enumValueSettemp.getIntersection(enumValueSet);
                                    enumValueSet = (EnumeratedSet) tempDataSet;
                                }
                                else {
                                    enumValueSet = constraintDefinitionReadView.getEnumDef().getEnumeratedSet(locale);
                                }

                                constraintsNameValuesMap.put(ENUMERATION_CONSTRAINT_STR, enumValueSet);
                            }
                        }
                        tempMap.put(ibaName, constraintsNameValuesMap);
                    }
                }

            }
            constraintsMapOnIbaByObjectType.put(objectType, tempMap);
            getSessionData().setConstraintsMapOnIbaByObjectType(constraintsMapOnIbaByObjectType);
        }
        return constraintsMapOnIbaByObjectType;
    }

    /**
     * This method check whether the given part number exist a given container and organization or not
     * 
     * @param wtContainerRef
     * @param rowData
     * @return
     */
    private boolean isExistingPart(WTContainerRef wtContainerRef, Map rowData) {
        if (logger.isDebugEnabled()) {
            logger.debug("In isExistingPart method");
        }
        String partNumber = (String) rowData.get(NUMBER);
        String orgId = (String) rowData.get(ORGANIZATION_ID);
        WTOrganization wtOrgnization = null;
        try {
            if (orgId == null || orgId.trim().length() == 0) {
                wtOrgnization = wtContainerRef.getReferencedContainer().getOrganization();
            } else {
                wtOrgnization = ImportHndHelper.getWTOrganizationByIdOrName(orgId);
            }
            if (logger.isDebugEnabled()) {
                logger.debug("Part Number" + partNumber + "  Container " + wtContainerRef + " Org Id" + wtOrgnization);
            }
            WTPartMaster partMaster = ImportHndHelper.getPartMaster(partNumber, wtOrgnization, wtContainerRef);
            if (partMaster != null)
                return true;
        } catch (WTException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    private boolean checkRequiredConstarintsConditions(ConstraintDefinitionReadView constraintDefinitionReadView,
            String objectTypeStr, Map rowData) throws WTException {
            Boolean checkConstraint = false;
            if (constraintDefinitionReadView.getAttName() != null) {
                if (constraintDefinitionReadView.getRuleData() instanceof DiscreteSet) {
                    DiscreteSet ruleData = (DiscreteSet) constraintDefinitionReadView.getRuleData();

                    
                    String attributeName = constraintDefinitionReadView.getAttName();
                    AttributeTypeIdentifier ati = TypeDefinitionServiceHelper.service
                            .getAttributeTypeIdentifier(attributeName, objectTypeStr);
                    if (ati != null) {
                        AttributeDefinitionReadView adRv = TypeDefinitionServiceHelper.service.getAttributeDefView(ati);
                        String displayNameOfAttr = adRv.getDisplayName();
                        // get the value of attribute from excel sheet
                        String valueFromExcel = (String) rowData.get(displayNameOfAttr);
                        Object[] elements = ruleData.getElements();
                        for (int i = 0; i < elements.length; i++) {
                            String value = (String) elements[i];
                            if (valueFromExcel.equalsIgnoreCase(value)) {
                                checkConstraint = true;
                                break;
                            }
                        }

                    }

                } else if (constraintDefinitionReadView.getRuleData() instanceof WildcardSet) {
                    WildcardSet wildcardSet = (WildcardSet)constraintDefinitionReadView.getRuleData();
                    
                    String attributeName = constraintDefinitionReadView.getAttName();
                    AttributeTypeIdentifier ati = TypeDefinitionServiceHelper.service
                            .getAttributeTypeIdentifier(attributeName, objectTypeStr);
                    if (ati != null) {
                        AttributeDefinitionReadView adRv = TypeDefinitionServiceHelper.service.getAttributeDefView(ati);
                        String displayNameOfAttr = adRv.getDisplayName();
                        String valueFromExcel = (String) rowData.get(displayNameOfAttr);
                        if (null != valueFromExcel) {
                            String element = wildcardSet.getValue();
                            valueFromExcel.contains(element);
                            checkConstraint = true;
                        }
                        else {
                            checkConstraint = false;
                        }
                    }
                }

            }

        return checkConstraint;
    }
    

	/**
	 * This method check if a given floating point with unit iba base display unit
	 * as base unit of it is overridden . If overridden then this method throws
	 * error message to change the display unit to base unit to avoid any data
	 * display corruption
	 * 
	 * @param rowData
	 * @param objectTypeStr
	 * @param ibaName
	 * @param attrubuteTypeIdentifier
	 * @throws WTException
	 * @throws UnitFormatException
	 */
	private void validateIbaForBaseUnit(Map rowData, String objectTypeStr, String ibaName,
			AttributeTypeIdentifier attrubuteTypeIdentifier) throws WTException, UnitFormatException {
		Locale locale = null;
		locale = SessionHelper.getLocale();
		if (!ibaWithNonBaseUnitMap.containsKey(ibaName)) {
			String unitOfMeasure = null;
			TypeInstance ti = null;
			if (null != attrubuteTypeIdentifier) {
				ti = CreateEditFormProcessorHelper.getTypeInstance(
						TypeIdentifierUtility.getTypeInstanceIdentifier(objectTypeStr), null,
						OperationIdentifierConstants.CREATE, new AttributeTypeIdentifier[] { attrubuteTypeIdentifier },
						locale);
			}

            AttributeTypeSummary ats = ti.getAttributeTypeSummary(attrubuteTypeIdentifier);
            String unitsSystem = getUnitSystem();
            unitOfMeasure = ats.getDisplayUnits(unitsSystem);
            logger.info("unit of measure " + unitOfMeasure);
            String baseUnit = getBaseUnit(unitOfMeasure);
			try {
                String rowValue = (String) rowData.get(ibaName);
                logger.debug("The unit of measure and row data is " + baseUnit + "  ==  " + rowValue);
                boolean isValid = isCellValueValidRealWithUnit(rowValue,  baseUnit, locale);
                logger.debug("Is the cell value valid real with unit " + isValid);
                if (!isValid) {
                    ibaWithNonBaseUnitMap.put(ibaName, true);
                    String message = new WTMessage(RESOURCE, importerResource.DISPLAY_UNIT_IS_OTHER_THAN_BASE_UNIT,
                                            new Object[] { ibaName }).getLocalizedMessage(locale);
                    throw new WTException(message);
                }
                else {
                    ibaWithNonBaseUnitMap.put(ibaName, false);
                }
			} catch (ParseException e) {
				logger.error("Exception encountered while FloatingPointWithUnits" + e);
			}
		}
	}
	
    public static String getBaseUnit(String unitOfMeasure) throws UnitFormatException {
        String baseUnit = null;
        if (unitOfMeasure != null) {
            baseUnit = new Unit(1.0d, unitOfMeasure).getUnits();
        }
        return baseUnit;
    }

    public static String getUnitSystem() {
        String unitsSystem = ((defaultUnitsSystem != null) && !StringUtils.isEmpty(defaultUnitsSystem))?defaultUnitsSystem:"SI";
        return unitsSystem;
    }

    public static boolean isCellValueValidRealWithUnit(String rowValue, String unitOfMeasure, Locale locale)
            throws ParseException, UnitFormatException, WTException {
        boolean isCellValueValid = true; //Empty and null cells are valid cell if it is not required attribute
        if (rowValue != null && !StringUtils.isEmpty(rowValue)) { //If the data is empty the floatingpointunit will be null. Check is not valid.
            FloatingPointWithUnits floatingPointUnit = DataTypesUtility
                            .toFloatingPointWithUnits(rowValue, locale);
            logger.debug("The value of floatpointwithunits is " + floatingPointUnit);
            if (!floatingPointUnit.getUnits().equals(unitOfMeasure)) {
                 isCellValueValid = false;
            } else {
                 isCellValueValid = true;
            }
       }
        return isCellValueValid;
    }
}
