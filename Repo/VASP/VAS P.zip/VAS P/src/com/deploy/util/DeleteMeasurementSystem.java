package com.deploy.util;

import org.apache.log4j.Appender;
import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Layout;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;

import wt.method.RemoteMethodServer;
import wt.org.WTPrincipal;
import wt.session.SessionHelper;
import wt.units.dbService.UnitDBService;
import wt.units.display.MeasurementSystem;
import wt.units.service.MeasurementSystemDefaultView;
import wt.units.service.UnitsObjectsFactory;
import wt.util.WTException;

// TODO: Auto-generated Javadoc
/**
 * The Class DeleteMeasurementSystem.
 */
public class DeleteMeasurementSystem {

	/**
	 * The Constant CLASSNAME.
	 */
	private static final String CLASSNAME = DeleteMeasurementSystem.class.getName();

	/**
	 * The args.
	 */
	private String[] args;

	/**
	 * The logger.
	 */
	private static Logger logger = null;

	static {
		logger = Logger.getLogger(CLASSNAME);
		Layout layout = new PatternLayout("");
		Appender console = new ConsoleAppender(layout);
		logger.addAppender(console);
		Level level = Level.DEBUG;
		logger.setLevel(level);
	}
	
	 private static UnitDBService theUnitDBService = new UnitDBService();

	/**
	 * Instantiates a new delete template.
	 *
	 * @param args
	 *            the args
	 */
	public DeleteMeasurementSystem(String[] args) {
		this.args = args;
	}

	/**
	 * The main method.
	 *
	 * @param args
	 *            the arguments
	 */
	public static void main(String[] args) {
		new DeleteMeasurementSystem(args).run();
	}

	/**
	 * Run.
	 */
	public void run() {
		logger.info("DeleteMeasurementSystem starts");
		if (args.length > 3 || args.length < 2) {
			printUsage();
			logger.info("DeleteMeasurementSystem ends with status 1");
			System.exit(1);
		}

		// Authenticate to Windchill as wcadmin
		String login = args[0];
		String password = args[1];
		authenticate(login, password);

		// start processing part
		process();
		logger.info("DeleteMeasurementSystem ends with status 0");
		System.exit(0);
	}

	/**
	 * Authenticate.
	 *
	 * @param username
	 *            the username
	 * @param password
	 *            the password
	 */
	private void authenticate(String username, String password) {
		RemoteMethodServer remoteMethodServer = RemoteMethodServer.getDefault();
		remoteMethodServer.setUserName(username);
		remoteMethodServer.setPassword(password);
		try {
			WTPrincipal currentUser = SessionHelper.manager.getPrincipal();
			WTPrincipal wtAdministrator = SessionHelper.manager.getAdministrator();
			if (!currentUser.equals(wtAdministrator)) {
				logger.info(
						"Invalid user! DeleteMeasurementSystem may be launched by Windchill Administrator only \nDeleteMeasurementSystem ends with status 1");
				System.exit(1);
			}
		} catch (WTException e) {
			logger.error("Authentication failed! " + e.getLocalizedMessage() + "\nDeleteMeasurementSystem ends with status 1");
			logger.error(" Exception :" + e.toString());
			System.exit(1);
		}
	}

	/**
	 * Process.
	 */
	public void process() {
		try {
			// parse arguments
			String[] measurementNames = null;
			measurementNames = args[2].split(",");
			
			MeasurementSystem [] allMS = theUnitDBService.getMeasurementSystems();
            if (allMS == null) {
                logger.warn("Sorry, no Measurement System are available.");
                return;
            }
			
			if (measurementNames != null) {
				for (String measurementName : measurementNames) {
		   
			            for (int i = 0; i < allMS.length; i++) {
			              
			                if(allMS[i].getName().equals(measurementName)){
			                  MeasurementSystemDefaultView ms = UnitsObjectsFactory.newMeasurementSystemDefaultView(allMS[i]);

			                  try {
			                	  theUnitDBService.deleteMeasurementSystem(ms);
			                  } catch (WTException wte) {
			                	  logger.trace(wte.getLocalizedMessage(), wte);			                    
			                  }
			                }
			            }
				}
			}					 
					
		} catch (WTException e) {
			logger.error(e.getLocalizedMessage() + " Exiting!!!");
			logger.error(" Exception :" + e.toString());
			System.exit(1);
		}
	}

	/**
	 * Prints the usage.
	 */
	private void printUsage() {
		System.out.println(
				"Usage: DeleteMeasurementSystem <login> <password> <MeasurementName1[, MeasurementName2]> \n"
						+ "Delete measurement systems\n"
						+ "<login> - login of Windchill administrator\n"
						+ "<password> - password of Windchill administrator\n"
						+ "<MeasurementName1[, MeasurementName2]> - comma separated list of measurement to be deleted\n"
						+ "EXAMPLE: windchill com.deploy.util.DeleteMeasurementSystem <login> <password> \"SI,USCS\"");
	}

}
