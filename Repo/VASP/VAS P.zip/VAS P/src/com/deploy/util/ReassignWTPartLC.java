package com.deploy.util;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.collections.WTArrayList;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerRef;
import wt.lifecycle.LifeCycleHelper;
import wt.lifecycle.LifeCycleState;
import wt.lifecycle.State;
import wt.lifecycle.LifeCycleTemplate;
import wt.lifecycle.LifeCycleTemplateReference;
import wt.method.RemoteMethodServer;
import wt.org.WTPrincipal;
import wt.part.WTPart;
import wt.pds.StatementSpec;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.vc.Iterated;
import wt.vc.IterationInfo;

import com.ptc.core.meta.type.mgmt.server.impl.WTTypeDefinition;

import ext.kb.util.KBUtils;

// TODO: Auto-generated Javadoc
//##end user.imports

//##begin ReassignWTPartLC%4A1DBD0402BF.doc preserve=no
/**
 * The Class ReassignWTPartLC.
 *
 * @version 1.0
 */
// ##end ReassignWTPartLC%4A1DBD0402BF.doc
public class ReassignWTPartLC implements Serializable {

	// --- Attribute Section ---

	/**
	 * The logger.
	 */
	private static Logger logger = Logger
			.getLogger(ReassignWTPartLC.class);
	
	/**
	 * The Constant CLASSNAME.
	 */
	private static final String CLASSNAME = ReassignWTPartLC.class.getName();
	
	/**
	 * The args.
	 */
	private String[] args;

	// ##begin user.attributes preserve=yes
	// ##end user.attributes

	// ##begin static.initialization preserve=yes
	// ##end static.initialization

	// --- Operation Section ---

	// ##begin ReassignWTPartLC%4A1DBD4500AB.doc preserve=no
	/**
	 * Class constructor: first two elements of String array should be WT
	 * administrator login and password.
	 *
	 * @param args the args
	 */
	// ##end ReassignWTPartLC%4A1DBD4500AB.doc
	public ReassignWTPartLC(String[] args) {
		// ##begin ReassignWTPartLC%4A1DBD4500AB.body preserve=yes
		this.args = args;
		// ##end ReassignWTPartLC%4A1DBD4500AB.body
	}

	// ##begin main%4A1DBD7100DA.doc preserve=no
	/**
	 * This method provides possibility to launch this program as batch tool.
	 *
	 * @param args the arguments
	 */
	// ##end main%4A1DBD7100DA.doc
	public static void main(String[] args) {
		// ##begin main%4A1DBD7100DA.body preserve=yes
		new ReassignWTPartLC(args).run();
		// ##end main%4A1DBD7100DA.body
	}

	// ##begin run%4A1DBD8E0157.doc preserve=no
	/**
	 * This method runs ReassignWTPartLC tool for particular part.
	 * 
	 **/
	// ##end run%4A1DBD8E0157.doc
	public void run() {
		// ##begin run%4A1DBD8E0157.body preserve=yes
		if (args.length !=5){
			if(args.length !=6) {
			printUsage();
			System.exit(1);
		}
		}
		// Authenticate to Windchill as wcadmin
		String login = args[0];
		String password = args[1];
		authenticate(login, password);

		// start processing part
		process();
		System.exit(0);
		// ##end run%4A1DBD8E0157.body
	}

	// ##begin authenticate%4A1DBD950119.doc preserve=no
	/**
	 * As ReassignWTPartLC can be launched by WT administrator only, this provides
	 * authentication based on WT credentials.
	 * 
	 * @param username
	 *            login of Windchill Administrator user
	 * @param password
	 *            password of Windchill Administrator user
	 * 
	 * 
	 **/
	// ##end authenticate%4A1DBD950119.doc
	private void authenticate(String username, String password) {
		// ##begin authenticate%4A1DBD950119.body preserve=yes
		RemoteMethodServer remoteMethodServer = RemoteMethodServer.getDefault();
		remoteMethodServer.setUserName(username);
		remoteMethodServer.setPassword(password);
		try {
			WTPrincipal currentUser = SessionHelper.manager.getPrincipal();
			WTPrincipal wtAdministrator = SessionHelper.manager
					.getAdministrator();
			if (!currentUser.equals(wtAdministrator)) {
				logger.debug("Invalid user! ReassignWTPartLC may be launched by Windchill Administrator only \nExiting...");
				System.exit(1);
			}
		} catch (WTException e) {
			logger.debug("Authentication failed!\nExiting...");
			System.exit(1);
		}
		// ##end authenticate%4A1DBD950119.body
	}

	// ##begin process%4A1DBE2903C8.doc preserve=no
	/**
	 * This method is responsible for business logic related to change of
	 * lifecycle of particular part.
	 * 
	 * 
	 **/
	// ##end process%4A1DBE2903C8.doc
	private void process() {
		// ##begin process%4A1DBE2903C8.body preserve=yes
		String typeName = args[2];		
		String lcTemplateName = args[3];
		String lcState = args[4];
		String newStateName = null;
		State newState = null;
		if(args.length==6){
		newStateName = args[5];
		newState = State.toState(newStateName);
		}
		boolean allStates=false;
		if ("all".equalsIgnoreCase(lcState)) {
			allStates=true;
		}else{
			
			try{
				State lcStateObj = State.toState(lcState);
			}catch(Exception  wte){
				
				logger.debug("ERROR State is not defined: "+ lcState);
				logger.error(" Exception :" + wte.toString());
				return;
			}
		}
		
		
		
		String partnumber;
		String currentVersionOfPart;
		// Search for part with given number
		List<WTPart> result = null;
		try {
			result = querySoftype(typeName,lcState);
		// proceed the change for specified versions
		for (WTPart wtPart : result) {
			boolean isEbomPart = KBUtils.isEbomPart(wtPart);
			if(!isEbomPart) {
				logger.info("Skipping part as it is MBOM, not EBOM");
				continue;
			}
			partnumber =   wtPart.getNumber();
			LifeCycleState state = wtPart.getState();
			String partState = state.toString();
			
      if (allStates || partState.equals(lcState)){   
				currentVersionOfPart =wtPart.getVersionIdentifier().getValue()+"."+wtPart.getIterationIdentifier().getValue(); 
					// retrieve current lifecycle template of part
					LifeCycleTemplate lifecycleTemplate = (LifeCycleTemplate) wtPart
							.getLifeCycleTemplate().getObject();
					logger.debug("Current lifecycle template name is: "
							+ lifecycleTemplate.getName()+ " in state "+state.getState());
					WTContainer wtContainer = lifecycleTemplate.getContainer();
					WTContainerRef wtContainerRef = wtContainer
							.getContainerReference();
					wtContainerRef = wtPart.getContainerReference();								
					LifeCycleTemplateReference newLifecycleTemplateReference = new LifeCycleTemplateReference();
					try {
	
						// retrieve new lifecycle template
						LifeCycleTemplate newLifecycleTemplate = LifeCycleHelper.service
								.getLifeCycleTemplate(lcTemplateName,
										wtContainerRef);
	
						// exit when lifecycle template with given name doesn't
						// exist in WT database
						if (newLifecycleTemplate == null) {
							logger.debug("Unable to get lifecycle template '"
									+ lcTemplateName + "' for change \n"
									+ "Lifecycle with this name doesn't exist. "
									+ "Exiting!!");
							System.exit(1);
						}
						newLifecycleTemplateReference = newLifecycleTemplate
								.getLifeCycleTemplateReference();
	
						// reassign lifecycle
	//					LifeCycleHelper.service.reassign(lifecycleManaged,newLifecycleTemplateReference);
						WTArrayList list = new WTArrayList();
						list.add(wtPart);
						if(newStateName!=null){
							LifeCycleHelper.service.reassign(list, newLifecycleTemplateReference, wtContainerRef, newState);
							
						}
						else{
						LifeCycleHelper.service.reassign(list, newLifecycleTemplateReference, wtContainerRef, state.getState());
						}
						
						logger.debug("NEW Lifecycle reassigned to: "
								+ lcTemplateName + ", for part no. " + partnumber
								+ ", version: " + currentVersionOfPart+" State: "+state.getState());
	
					} catch (WTException e) {
						logger.debug("Unable to reassign lifecycle to: "
								+ lcTemplateName + ", for part no. " + partnumber
								+ ", version: " + currentVersionOfPart);
						logger.error(" Exception :" + e.toString());
					}
				}
			}
		}catch (WTException e)
		{
			logger.error(" Exception :" + e.toString());
		}		
		// ##end process%4A1DBE2903C8.body
	}

	// ##begin printUsage%4A1DBEA20196.doc preserve=no
	/**
	 * This method displays usage of this tool (command) when it's launched from
	 * command line.
	 * 
	 **/
	// ##end printUsage%4A1DBEA20196.doc
	private static void printUsage() {
		// ##begin printUsage%4A1DBEA20196.body preserve=yes
		System.out
				.println("Usage: ReassignWTPartLC <login> <password> <type> <LCtemplateName> "
						+ "- reassign lifecycle"
						+ " of parts.\n"
						+ "<login> - login of Windchill administrator\n"
						+ "<password> - password of Windchill administrator\n"
						+ "<type> - softtype name\n"
						+ "<LCtemplateName> - name of lifecycle template used to change \n" 
						+ "<LCState> - name of lifecycle state to be used to change or \"all\" to apply for all \n" +
						"EXAMPLE: windchill com.eads.efw.efwloaders.stdparts.tools.ReassignWTPartLC wcadmin <password> corp.efw.EFWSTDPART \"EFW STD PART LC\" all");
		// ##end printUsage%4A1DBEA20196.body
	}

	// ##begin user.operations preserve=yes
	// ##end user.operations
//	String softType = "com.ptc.ADAPCI";
	 
	// get soft type definition definition (latest iteration)
	 
	
	//String softType = "com.ptc.ADAPCI";
	
	/**
	 * Query softype.
	 *
	 * @param softType the soft type
	 * @param state the state
	 * @return the list
	 * @throws WTException the wT exception
	 */
	private static List<WTPart> querySoftype (String softType, String state) throws WTException {
		boolean isAllStates= "all".equalsIgnoreCase(state);
		
		QuerySpec typespec = new QuerySpec(WTTypeDefinition.class);
		typespec.appendWhere(new SearchCondition(WTTypeDefinition.class, WTTypeDefinition.NAME, SearchCondition.EQUAL, softType));
		
		QueryResult typeresult = PersistenceHelper.manager.find((StatementSpec)typespec);
	
		// if the type exists, proceed for searching related objects
		 
		List<WTPart> wtParts = new ArrayList<WTPart>();
		while(typeresult.hasMoreElements()) {
			WTTypeDefinition typedef = (WTTypeDefinition)typeresult.nextElement();
		 
			QuerySpec objectspec = new QuerySpec(WTPart.class);
			objectspec.appendSearchCondition(new SearchCondition(WTPart.class, "typeDefinitionReference.key", SearchCondition.EQUAL, typedef.getPersistInfo().getObjectIdentifier()));
			objectspec.appendAnd();
			objectspec.appendSearchCondition(new SearchCondition(WTPart.class, Iterated.ITERATION_INFO + "." + IterationInfo.LATEST, SearchCondition.IS_TRUE));
			if(!isAllStates){
				objectspec.appendAnd();
				objectspec.appendSearchCondition(new SearchCondition(WTPart.class, "state.state", SearchCondition.EQUAL, state));
			}
			QueryResult objectresult = PersistenceHelper.manager.find((StatementSpec)objectspec);
			while (objectresult.hasMoreElements()) {
				wtParts.add((WTPart) objectresult.nextElement());
			}
		} 
		logger.debug("Found "+wtParts.size()+" to reasign lifecycle");
		
		return wtParts;
	}

}
