package com.deploy.util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.apache.log4j.Appender;
import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Layout;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;

import wt.doc.WTDocument;
import wt.enterprise.EnterpriseHelper;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.inf.container.WTContainer;
import wt.method.RemoteMethodServer;
import wt.org.WTPrincipal;
import wt.pds.StatementSpec;
import wt.query.OrderBy;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.session.SessionHelper;
import wt.util.WTException;

// TODO: Auto-generated Javadoc
/**
 * The Class DeleteTemplate.
 */
public class DeleteTemplate {

	/**
	 * The Constant CLASSNAME.
	 */
	private static final String CLASSNAME = DeleteTemplate.class.getName();
	
	/**
	 * The args.
	 */
	private String[] args;
	
	/**
	 * The logger.
	 */
	private static Logger logger = null;

	static {
		logger = Logger.getLogger(CLASSNAME);
		Layout layout = new PatternLayout("");
		Appender console = new ConsoleAppender(layout);
		logger.addAppender(console);
		Level level = Level.DEBUG;
		logger.setLevel(level);
	}

	/**
	 * Instantiates a new delete template.
	 *
	 * @param args the args
	 */
	public DeleteTemplate(String[] args) {
		this.args = args;
	}

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {
		new DeleteTemplate(args).run();
	}

	/**
	 * Run.
	 */
	public void run() {
		logger.info("DeleteTemplate starts");
		if (args.length > 6 || args.length < 5) {
			printUsage();
			logger.info("DeleteTemplate ends with status 1");
			System.exit(1);
		}

		// Authenticate to Windchill as wcadmin
		String login = args[0];
		String password = args[1];
		authenticate(login, password);

		// start processing part
		process();
		logger.info("DeleteTemplate ends with status 0");
		System.exit(0);
	}

	/**
	 * Authenticate.
	 *
	 * @param username the username
	 * @param password the password
	 */
	private void authenticate(String username, String password) {
		RemoteMethodServer remoteMethodServer = RemoteMethodServer.getDefault();
		remoteMethodServer.setUserName(username);
		remoteMethodServer.setPassword(password);
		try {
			WTPrincipal currentUser = SessionHelper.manager.getPrincipal();
			WTPrincipal wtAdministrator = SessionHelper.manager
					.getAdministrator();
			if (!currentUser.equals(wtAdministrator)) {
				logger
						.info("Invalid user! DeleteTemplate may be launched by Windchill Administrator only \nDeleteTemplate ends with status 1");
				System.exit(1);
			}
		} catch (WTException e) {
			logger.error("Authentication failed! " + e.getLocalizedMessage()
					+ "\nDeletePrincipal ends with status 1");
			logger.error(" Exception :" + e.toString());
			System.exit(1);
		}
	}

	/**
	 * Process.
	 */
	public void process() {
		try {
			// find container
			WTContainer container = queryContainerByName(args[2]);
			logger.info("Container: " + container.getDisplayIdentity());
			// parse arguments
			String templateType = args[3];
			String[] templateNames = null;
			if (args.length == 6 && args[4].equalsIgnoreCase("-f")) {
				templateNames = retrieveTemplateNamesFromFile(args[5]).split(
						",");
			} else {
				templateNames = args[4].split(",");
			}
			Set templates = new HashSet();
			// process WTDocuments
			if (templateType.equalsIgnoreCase("WTDOCUMENT")) {
				// prepare a query for WTDocument templates with specific names
				QuerySpec queryWtDocument = new QuerySpec(WTDocument.class);
				// add where clause with template names if the argument, that
				// specifies the template names doesn't equal "ALL" or process
				// all templates from the container if so
				if (!(templateNames.length == 1 && templateNames[0].trim()
						.equals("ALL"))) {
					for (int i = 0; i < templateNames.length; i++) {
						String templateName = templateNames[i];
						queryWtDocument.appendWhere(new SearchCondition(
								WTDocument.class, WTDocument.NAME,
								SearchCondition.EQUAL, templateName),
								new int[] { 0 });
						if (i + 1 < templateNames.length) {
							queryWtDocument.appendOr();
						}
					}
				}
				// search for document templatestemplates
				QueryResult foundTemplates = EnterpriseHelper.service
						.getTemplates((WTContainer) container, queryWtDocument,
								new OrderBy[] {}, false, true, false, true);
				// collect found templates
				templates.addAll(foundTemplates.getObjectVectorIfc()
						.getVector());
			}
			if (templates.size() > 0) {
				for (Object object : templates) {
					if (object instanceof WTDocument) {
						logger.info("Deleting '"
								+ ((WTDocument) object).getName() + "'...");
					}
					// delete found template
					PersistenceHelper.manager.delete((Persistable) object);
					logger.info("OK");
				}
				logger.info(templates.size() + " templates deleted.");
			} else {
				logger.info("No specified templates found with name: "
						+ Arrays.toString(templateNames));
			}
		} catch (WTException e) {
			logger.error(e.getLocalizedMessage() + " Exiting!!!");
			logger.error(" Exception :" + e.toString());
			System.exit(1);
		}
	}

	/**
	 * Retrieve template names from file.
	 *
	 * @param fileName the file name
	 * @return the string
	 */
	private static String retrieveTemplateNamesFromFile(String fileName) {
		StringBuilder templateNamesBuilder = new StringBuilder();
		try {
			BufferedReader reader = new BufferedReader(new FileReader(fileName));
			String line = "";
			while ((line = reader.readLine()) != null) {
				templateNamesBuilder.append(line);
				if (!line.endsWith(",")) {
					templateNamesBuilder.append(',');
				}
			}
			return templateNamesBuilder.toString();
		} catch (Exception e) {
			logger.error(" Exception :" + e.toString());
			return "";
		}
	}

	// returns a WTContainer having name as specified by parameter, throws an
	// exception, if more than one container with the same name found
	/**
	 * Query container by name.
	 *
	 * @param containerName the container name
	 * @return the wT container
	 * @throws WTException the wT exception
	 */
	private static WTContainer queryContainerByName(String containerName)
			throws WTException {
		QuerySpec queryContainers = new QuerySpec(WTContainer.class);
		queryContainers.appendWhere(new SearchCondition(WTContainer.class,
				WTContainer.NAME, SearchCondition.EQUAL, containerName),
				new int[] { 0 });
		QueryResult foundContainers = PersistenceHelper.manager
				.find((StatementSpec) queryContainers);
		if (foundContainers.size() > 1) {
			throw new WTException("More than one container found!");
		} else if (foundContainers.size() == 0) {
			throw new WTException("Container not found!");
		}
		return (WTContainer) foundContainers.nextElement();
	}

	/**
	 * Prints the usage.
	 */
	private void printUsage() {
		System.out
				.println("Usage: DeleteTemplate <login> <password> <containerName> <templateType> <templateName1[, templateName2]>|ALL|<-f pathToFileWithTemplateNames> \n"
						+ "Delete users/groups/roles from the WT system and LDAP\n"
						+ "<login> - login of Windchill administrator\n"
						+ "<password> - password of Windchill administrator\n"
						+ "<containerName> - name of the container where templates are stored\n"
						+ "<templateType> - type of object for which the template has been created. Currently only WTDOCUMENT is handled.\n"
						+ "<templateName1[, templateName2]> - comma separated list of templates to be deleted or \"ALL\" if all templates in container are supposed to be deleted or -f path to file with template names\n"
						+ "EXAMPLE: windchill com.eads.efw.common.tools.DeleteTemplate <login> <password> EFW WTDOCUMENT \"EFW Technical Specification,EFW Static Approval Sheet\"");
	}

}
