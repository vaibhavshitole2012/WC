package com.deploy.util;

import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.util.Arrays;
import java.util.List;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.log4j.*;
import wt.change2.WTChangeOrder2;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.pds.StatementSpec;
import wt.query.ClassAttribute;
import wt.query.ConstantExpression;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;


public class RemoveChangeObjectTemplate implements RemoteAccess {

    private static final String CLASSNAME = RemoveChangeObjectTemplate.class.getName();
    private static final String USER_ARG = "username";
    private static final String PASSWORD_ARG = "password";
    private static final String TEMPLATE_ARG = "template";
    private static final String TARGET_METHOD = "run";

    private static Logger logger;

    static {
        logger = null;
        logger = Logger.getLogger(CLASSNAME);
        Layout layout = new PatternLayout("");
        Appender console = new ConsoleAppender(layout);
        logger.addAppender(console);
        Level level = Level.DEBUG;
        logger.setLevel(level);
    }

    @SuppressWarnings({"rawtypes"})
    public static void main(String[] args) {
        final CommandLineParser parser = new DefaultParser();
        final Options options = getOptions();

        try {
            CommandLine cmdLine = parser.parse(options, args);
            String username;
            String password;
            String containerNames;

            RemoteMethodServer rms = RemoteMethodServer.getDefault();
            username = cmdLine.getOptionValue(USER_ARG);
            password = cmdLine.getOptionValue(PASSWORD_ARG);
            containerNames = cmdLine.getOptionValue(TEMPLATE_ARG);
            rms.setUserName(username);
            rms.setPassword(password);
            final Class[] argTypes = {String.class};
            final Object[] argObjs = {containerNames};
            rms.invoke(TARGET_METHOD, RemoveChangeObjectTemplate.class.getName(), null, argTypes, argObjs);

        } catch (RemoteException | InvocationTargetException | ParseException exception) {
            exception.printStackTrace();
        }
    }

    private static Options getOptions() {
        final Options posixOptions = new Options();

        Option userOption = new Option(USER_ARG, true, "User name (ex: wcadmin)");
        userOption.setRequired(true);
        posixOptions.addOption(userOption);

        Option passwordOption = new Option(PASSWORD_ARG, true, "User password (ex: wcadmin3)");
        passwordOption.setRequired(true);
        posixOptions.addOption(passwordOption);

        Option modeOption = new Option(TEMPLATE_ARG, true, "Document template names, separated by comma");
        modeOption.setRequired(true);
        posixOptions.addOption(modeOption);

        return posixOptions;
    }

    public static void run(String templateNames) throws WTException {
        logger.debug("Delete Change Object Templates: " + templateNames);
        List<String> names = Arrays.asList(templateNames.split(","));
        for (String name : names) {
            removeTemplate(name);
        }
    }

    private static void removeTemplate(String templateName) throws WTException {
        logger.debug("Removing: " +templateName);
        List<String> splited = Arrays.asList(templateName.split(":"));
        String name = splited.get(0);
        String number = splited.get(1);
        QuerySpec qs = new QuerySpec(WTChangeOrder2.class);
        qs.appendWhere(new SearchCondition(new ClassAttribute(WTChangeOrder2.class, WTChangeOrder2.NAME), SearchCondition.EQUAL,
                new ConstantExpression(name)), new int[]{0});
        qs.appendAnd();
        qs.appendWhere(new SearchCondition(new ClassAttribute(WTChangeOrder2.class, WTChangeOrder2.NUMBER), SearchCondition.EQUAL,
                new ConstantExpression(number)), new int[]{0});
        QueryResult result = PersistenceHelper.manager.find((StatementSpec) qs);

        if (!result.hasMoreElements()) {
            logger.debug("Cannot find document template: " + templateName);
        }
        while (result.hasMoreElements()) {
            WTChangeOrder2 order = (WTChangeOrder2) result.nextElement();
            PersistenceServerHelper.manager.remove(order);
            logger.debug("Document template " + templateName + " removed");
        }
    }
}