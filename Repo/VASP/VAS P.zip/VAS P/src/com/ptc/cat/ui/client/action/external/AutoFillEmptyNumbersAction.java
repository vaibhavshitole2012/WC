package com.ptc.cat.ui.client.action.external;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import com.extjs.gxt.ui.client.mvc.Controller;
import com.extjs.gxt.ui.client.mvc.Dispatcher;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.ptc.cat.entity.client.Flags;
import com.ptc.cat.entity.client.Identifier;
import com.ptc.cat.entity.client.structure.StructureModel;
import com.ptc.cat.gxt.client.GSEEvents;
import com.ptc.cat.gxt.client.controller.TreeController;
import com.ptc.cat.gxt.client.widget.MessageDialog;
import com.ptc.cat.ops.client.OperationResult;
import com.ptc.cat.ops.client.OpsCore;
import com.ptc.cat.ops.client.external.AutoFillEmptyNumbersOperation;
import com.ptc.cat.ops.client.internal.CheckoutOperation;
import com.ptc.cat.ui.client.action.AbstractAction;
import com.ptc.cat.ui.client.action.ActionDefinition;

public class AutoFillEmptyNumbersAction extends AbstractAction {

	private static final String PROCESSOR_CLASS_NAME = "ext.kb.part.form.KBArticleAutofillFormProcessor";
	
	public AutoFillEmptyNumbersAction(ActionDefinition actionDefinition) {
		super(actionDefinition);
	}

	/*
	 * Method called after action is invoked from GWT.
	 * It collects selected node from parts tree (only the top one) and performs
	 * auto fill line/find numbers logic on it
	 * 
	 * (non-Javadoc)
	 * @see com.ptc.cat.ui.client.action.Action#run(com.google.gwt.user.client.rpc.AsyncCallback)
	 */
	@Override
	public void run(AsyncCallback<OperationResult> arg0) {
		StructureModel structureModel;
		//get part model 
		structureModel = getView().getContextModel();
		
		if (!structureModel.isFlagEnabled(Flags.F_HAS_CHILDREN)) {
			Dispatcher.forwardEvent(GSEEvents.ActionCompleted);
            MessageDialog.showWarningMessage("Autofill Line/Find numbers action", "There is no object to autofill numbers on");
		} else {
			//perform checkout operation if needed
			if (!structureModel.isFlagEnabled(Flags.F_WORKING_COPY)) {
				Set<StructureModel> modelSet = new HashSet<StructureModel>(1);
				modelSet.add(structureModel);
				//prepare GWT checkout operation
				CheckoutOperation checkoutOperation = new CheckoutOperation(structureModel.getContext(),
						modelSet);
	            OpsCore.getInstance().getOperationManager().commitNow(checkoutOperation,
	            		new CheckoutCallBack(new AutoFillEmptyNumbersCallBack(structureModel)));
			} else {
				Identifier workingCopyID = structureModel.getChildEntity().getIdentifier();
				performAutoFillNumbersOperation(new AutoFillEmptyNumbersCallBack(structureModel),
						workingCopyID);
			}
		}
	}
	
	/*
	 * Callback class for checkout operation
	 */
	private class CheckoutCallBack implements AsyncCallback<OperationResult> {
		
		private AutoFillEmptyNumbersCallBack autoFillcallback;
		private Identifier originalCopyID;
		
		/**
		 * Constructor
		 * 
		 * @param autoFillcallback - AutoFillEmptyNumbers operation callback 
		 * 		(used when the checkout was success) 
		 */
		public CheckoutCallBack(AutoFillEmptyNumbersCallBack autoFillcallback) {
			this.autoFillcallback = autoFillcallback;
			originalCopyID = autoFillcallback.getStructureModel().getChildEntity().getIdentifier();
		}
		
		@Override
		public void onFailure(Throwable caught) {
            Dispatcher.forwardEvent(GSEEvents.ActionCompleted);
            MessageDialog.showErrorMessage(caught, "Unable to checkout part.");
		}

		@Override
		public void onSuccess(OperationResult result) {
			Map<Identifier, Identifier> replacements = result.getReplacements();
			if (replacements != null) {
				//collect workingCopy ID
				Identifier workingCopyID = replacements.get(originalCopyID);
				performAutoFillNumbersOperation(autoFillcallback, workingCopyID);
			}
		}
    }
	
	/*
	 * Callback class for AutoFillEmptyNumbers operation
	 */
	private class AutoFillEmptyNumbersCallBack implements AsyncCallback<OperationResult> {
		
		private StructureModel structureModel;
		
		public AutoFillEmptyNumbersCallBack(StructureModel structureModel) {
			this.structureModel = structureModel;
		}
		
		@Override
		public void onFailure(Throwable caught) {
            Dispatcher.forwardEvent(GSEEvents.ActionCompleted);
            MessageDialog.showErrorMessage(caught, "Unable to auto fill empty numbers.");
		}

		@Override
		public void onSuccess(OperationResult result) {
			for (Controller ctrl : Dispatcher.get().getControllers()) {
				if (ctrl instanceof TreeController) {
					((TreeController) ctrl).refresh(structureModel.getContext().getRootIdentifier(), true);
				}
			}
			Dispatcher.forwardEvent(GSEEvents.ActionCompleted);
		}
		
		public StructureModel getStructureModel() {
			return structureModel;
		}
		
    }
	
	/**
	 * Creates AutoFillEmptyNumbers operation and invoke it
	 * 
	 * @param afenCallback - callback for AutoFillEmptyNumbers operation 
	 * @param workingCopyID - OID of part working copy
	 */
	public void performAutoFillNumbersOperation(AutoFillEmptyNumbersCallBack afenCallback, Identifier workingCopyID) {
		if (workingCopyID != null) {
			AutoFillEmptyNumbersOperation afenOp = 
					new AutoFillEmptyNumbersOperation(afenCallback.getStructureModel().getContext(), 
							workingCopyID);
			OpsCore.getInstance().getOperationManager().commitNow(afenOp, afenCallback);
		}
	}

}
