/*
 * FormTaskDelegateHelper.java
 *
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.ptc.generic.processors;

import wt.templateutil.processor.HTTPState;
import wt.templateutil.processor.ServletSessionCookie;
import wt.util.WTException;

/**
 * This class contains common methods for subclasses of FormTaskDelegate.
 * @author Simone Graf
 */
public class FormTaskDelegateHelper {
    
    /**
     * Reads the value from an input field from a form.
     * @param formName the name of the form in the html page e.g. CreateEAProduct
     * @param inputFieldName the name of the input field in the html page e.g. productName
     * @param defaultValue the default value if the field does not exist e.g. ""
     * @param state the state, e.g. getState()
     * @return the value of the input field
     * @throws wt.util.WTException throws an exception if inputFieldName or formName is null or an empty string
     */
    public static String getFormValueFromSession(String formName, String inputFieldName, String defaultValue, HTTPState state) throws WTException {
        if(formName == null || formName.equals("")|| inputFieldName == null || inputFieldName.equals(""))
            throw new WTException("FormTaskDelegateHelper.getFormValueFromSession(): required \"formName\" = " + formName + " and \"inputFieldName\" = " + inputFieldName + " parameters are missing");
        ServletSessionCookie servletsessioncookie = state.getCookieManager().getCookie(formName);
        String value = (String)servletsessioncookie.get(inputFieldName);
        if(value == null && defaultValue != null)
            value = defaultValue;
        return value;
    }
    
}
