package com.ptc.generic.datarepair;

import java.util.ArrayList;
import java.util.List;

import wt.epm.EPMDocument;
import wt.epm.build.EPMBuildHistory;
import wt.epm.build.EPMBuildRule;
import wt.epm.structure.EPMDescribeLink;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.collections.WTArrayList;
import wt.fc.collections.WTCollection;
import wt.part.WTPart;
import wt.util.WTException;
import wt.vc.VersionControlException;

import com.ptc.generic.VersionUtil;

public class EPMUtil {
	public static String getEPMDocumentDisplay(EPMDocument epmDoc) throws VersionControlException {
		return epmDoc.getNumber() + " - " + epmDoc.getName() + " " + VersionUtil.getVersionIterationDisplay(epmDoc) + " (" + epmDoc + ")";
	}

        public static String getEPMDoc(EPMDocument epmDoc) throws VersionControlException {
		return epmDoc.getNumber();
	}

	protected static List<EPMBuildRule> getBuildRules(WTPart part) throws WTException {
		ArrayList<EPMBuildRule> buildRules = new ArrayList<EPMBuildRule>();

		QueryResult qrBuildRules = PersistenceHelper.manager.navigate(part, EPMBuildRule.BUILD_SOURCE_ROLE, EPMBuildRule.class, false);

		while (qrBuildRules.hasMoreElements()) {
			buildRules.add((EPMBuildRule) qrBuildRules.nextElement());
		}

		return buildRules;
	}

	protected static List<EPMBuildHistory> getBuildHistories(WTPart part) throws WTException {
		ArrayList<EPMBuildHistory> buildHistories = new ArrayList<EPMBuildHistory>();
                QueryResult qrBuildHistories = null;
               
		qrBuildHistories = PersistenceHelper.manager.navigate(part, EPMBuildHistory.BUILT_BY_ROLE, EPMBuildHistory.class, false);
                while (qrBuildHistories.hasMoreElements()) {
			buildHistories.add((EPMBuildHistory) qrBuildHistories.nextElement());
		}
                
		return buildHistories;
	}

	protected static List<EPMDescribeLink> getEPMDescribeLinks(WTPart part) throws WTException {
		List<EPMDescribeLink> describeLinks = new ArrayList<EPMDescribeLink>();
		WTCollection parts = new WTArrayList();
               	parts.add(part);
                
                QueryResult partToDocs = null;
                partToDocs=PersistenceHelper.manager.navigate(part,wt.epm.structure.EPMDescribeLink.DESCRIBED_BY_ROLE,wt.epm.structure.EPMDescribeLink.class, false);
                    while (partToDocs.hasMoreElements()){
                    describeLinks.add((EPMDescribeLink) partToDocs.nextElement());

                }
		return describeLinks;
	}

        protected static boolean getLockedEPMDocument(EPMDocument epmDoc) throws VersionControlException {
		return epmDoc.isLocked();
	}
}
