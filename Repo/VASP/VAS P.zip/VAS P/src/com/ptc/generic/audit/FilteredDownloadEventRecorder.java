/* bcwti
 *
 * Copyright (c) 2016 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */

package com.ptc.generic.audit;

import java.util.StringTokenizer;

import wt.audit.AuditRecord;
import wt.audit.configaudit.DownloadEventRecorder;
import wt.events.KeyedEvent;
import wt.fc.collections.WTCollection;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.util.WTProperties;

/*
**	Functionality:
**		Whenever a publishing job does the job a file is downloaded to be converted. Such a download event is not
**		only for WVS it is also triggered for "normal" download, e.g. a user reads some content.
**		When a customer enabled the READ_DOWNLOAD event in configAudit.xml the audit tables get spammed with millions of such
**		download events coming from the CAD workers. This customization is to filter out these events triggered by the CAD worker userid, 
**		so  they don't get logged into the audit tables.
**
**	How to enable and configure:
**		In file WNC/conf/auditing/configAudit.xml copy this line into section:
**		<ConfigEntry class="" enabled="true">
**			<KeyedEventEntry eventKey=" * /wt.content.ContentServiceEvent/READ_CONTENT" enabled="true" handler="com.ptc.generic.audit.FilteredDownloadEventRecorder"/>
**			Note: remove the blanks at the beginning of the eventKey
**		    Define in wt.properties the list of userids to be skipped:
**			wt.audit.READ_CONTENT.skipUsers=CADworker1,CADworker2
**			Note: the site administrator always shows up as Administrator, not as wcadmin
**
**	Logging available:
**		via server status page enable INFO logging for wt.audit.configaudit
**
**	Risk:
**		no risk, no functionality changed or modified. No database changes 
*/

public class FilteredDownloadEventRecorder extends DownloadEventRecorder {

	static String skipUsers = null;
	static final String propName = "wt.audit.READ_CONTENT.skipUsers";

	protected void readSkipList () {
		if (skipUsers == null) {
			WTProperties props = null;
			try {
				props = WTProperties.getLocalProperties();
				skipUsers = props.getProperty(propName,"");
				logger.info ("### FilteredDownloadEventRecorder.readSkipList = "+skipUsers+" ###");
			} catch (Exception e) {}
		}
	}
	
	protected boolean isInSkipList (String id) {
		readSkipList();
		StringTokenizer toks = new StringTokenizer(skipUsers, ", ");
		if (toks.countTokens() > 0) {
			while (toks.hasMoreTokens()) {
                if (id.equals(toks.nextToken())) return true;
			}
		}
		return false;
	}
	
	protected boolean skipEvent () {
		String userid = null;
		try {
			userid = SessionHelper.manager.getPrincipal().getName();
			logger.info ("### FilteredDownloadEventRecorder.skipEvent  testing userid = "+userid+" ###");
			if (isInSkipList(userid)) {
				logger.info ("###   ==> skipped "+userid+" ###");
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	/*
	**	The customization point is just overwriting these two methods with the logic to test the userid.
	**	If user is not in skipList, call the super method.
	*/
	
	protected WTCollection persistMultiObjectEvent( KeyedEvent event, WTCollection alternateTargets ) throws WTException {

		if (!skipEvent()) return super.persistMultiObjectEvent( event, alternateTargets );
		return null;
	}

	protected AuditRecord persistEvent( KeyedEvent event ) throws WTException {

		if (!skipEvent()) return super.persistEvent( event );
		return null;
	}

}
