package com.ptc.generic;

import com.ptc.ssp.util.*;

// LB 29.03.2010:
// instead of changing all references to AuthHelper in all our code to AuthenticationHelper, I just made AuthHelper extend AuthenticationHelper 
public class AuthHelper extends AuthenticationHelper {
}
