/** 

Class for table configuration implementation of the HSSF excel API.

@author Lothar Germund, PLUS-Systeme GmbH
@since 19.10.2010
*/
package com.ptc.generic.tableconversion;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFDataFormat;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;

import java.util.HashMap;
import java.util.Map;


/**
 * Class for table configuration implementation of the HSSF excel API.
 * @author DVORGER
 */
public class ExcelConfigurationImpl extends AbstractExportTableConfiguration {

    // enumeration constants for style differences because of cell type
    public final static int STYLE_TYPE_CLASS_NORMAL = 0;
    public final static int STYLE_TYPE_CLASS_DATE   = 1;

    // constants for keys of the styleMap, so style names
    public final static String STYLE_NORMAL      = "normal";
    public final static String STYLE_NORMAL_DATE = "normal_date";
    public final static String STYLE_HEADER      = "header";

    public final static HSSFColor MARKED_COLOR   = new HSSFColor.LIGHT_YELLOW();
    
    // constant array of normal styles, uses STYLE_TYPE_CLASS constants as index
    public final static String[] STYLE_NORMAL_TYPES = {STYLE_NORMAL, STYLE_NORMAL_DATE};

    // Strings for the JSP response object
    private final static String RESPONSE_CONTENTTYPE   = "application/vnd.ms-excel";
    private final static String RESPONSE_FILEEXTENSION = ".xls";
    
    // own render type name, used in the factories
    public final static String RENDERTYPE = "excel";
    
    private HSSFWorkbook workbook;
    private Map<String, HSSFCellStyle> styleMap = null;
// TODO see also getter/setter  private Collection layoutStructure; // together with getCellStyles() for complex layouts
    
    //flag to identify whether to wrap the header text or not
    //CR_2012_002
    private boolean wrapHeaderText=false;
    
   	/**
     * Constructor
     */
    public ExcelConfigurationImpl() {
        setResponseContentType(RESPONSE_CONTENTTYPE);
        setFileExtensionName(RESPONSE_FILEEXTENSION);
    }
    

    /**
     * @param workbook
     *            the workbook to set
     */
    public void setWorkbook(HSSFWorkbook workbook) {
        this.workbook = workbook;
        createStyles();
    }

    
    /**
     * @return the workbook
     */
    public HSSFWorkbook getWorkbook() {
        return workbook;
    }

    
    /**
     * @param styleMap
     *            the styleMap to set
     */
    public void setStyleMap(Map<String, HSSFCellStyle> styleMap) {
        this.styleMap = styleMap;
    }

    
    /**
     * @return the styleMap
     */
    public Map<String, HSSFCellStyle> getStyleMap() {
        return styleMap;
    }

    
    /**
     * @param layoutStructure
     *            the layoutStructure to set
     */
//    public void setLayoutStructure(Collection layoutStructure) {
//        this.layoutStructure = layoutStructure;
//    }

    
    /**
     * @return the layoutStructure
     */
//    public Collection getLayoutStructure() {
//        return layoutStructure;
//    }

    
    /**
     * Added as part of CR_2012_002
     * 
     * @return
     *  a <code> boolean </code> type
     */
    public boolean isWrapHeaderText() {
		return wrapHeaderText;
	}

    /**
     * 
     * Set true / false depending on whether wrapping of
     * header text is needed or not. By default this flag
     * is set to false. Use this method if the value to be
     * changed to true.
     * 
     * Added as part of CR_2012_002
     * 
     * @param wrapHeaderText
     *  a <code> boolean </code> type
     */
	public void setWrapHeaderText(boolean wrapHeaderText) {
		this.wrapHeaderText = wrapHeaderText;
	}

    
    /**
     * Creates a bordered style from the workbook. It can be used directly or to add more attributes.
     * 
     * @return HSSFCellStyle
     */
    protected HSSFCellStyle createBorderedStyle() {
        final HSSFCellStyle style = workbook.createCellStyle();
        
        style.setBorderBottom(BorderStyle.THIN);
        style.setBottomBorderColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
        
        style.setBorderLeft(BorderStyle.THIN);
        style.setLeftBorderColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
        
        style.setBorderRight(BorderStyle.THIN);
        style.setRightBorderColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
        
        style.setBorderTop(BorderStyle.THIN);
        style.setTopBorderColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
        
        return style;
    }

    /**
     * Creates a bordered header style from the workbook. It can be used directly or to add more attributes.
     * 
     * @return HSSFCellStyle
     */
    private HSSFCellStyle createHeaderStyle() {
        HSSFCellStyle style = createBorderedStyle();
        style.setAlignment(HorizontalAlignment.CENTER);
        style.setFillForegroundColor(HSSFColor.HSSFColorPredefined.LIGHT_CORNFLOWER_BLUE.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        //Wrap the header text. This is needed if text in
        //multiple lines to be displayed properly
        //Added as part of CR_2012_002
        if(this.isWrapHeaderText()){
        	style.setWrapText(true);
        }
        HSSFFont headerFont = workbook.createFont();
//        headerFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
        headerFont.setBold(true);
        style.setFont(headerFont);
        return style;
    }


    /**
     * Creates a map of styles. Date format uses own styles.
     */
    private void createStyles() {
        Map<String, HSSFCellStyle> styles = new HashMap<String, HSSFCellStyle>();
        HSSFCellStyle style;
        
        HSSFDataFormat dataFormat = workbook.createDataFormat();
        short nDateFormat = dataFormat.getFormat("dd.mm.yyyy");

        // for simple data cells
        style = createBorderedStyle();
        styles.put(STYLE_NORMAL, style);

        style = createBorderedStyle();
        style.setDataFormat(nDateFormat);
        styles.put(STYLE_NORMAL_DATE, style);

        // nice header cells
        style = createHeaderStyle();
        styles.put(STYLE_HEADER, style);

        setStyleMap(styles);
    }


    /**
     * Get the style for the current cell.
     * Called through the render loop with the current cell address (row,column).
     *  
     * @param row
     * @param column
     * @return
     */
    public HSSFCellStyle getCellStyle(int row, int column, int styleTypeClass) {
        HSSFCellStyle style = null;
        if (LAYOUT_HEADER.equals(getLayoutName())) {
            if (row == 0) {
                style = styleMap.get(STYLE_HEADER);
            } else {
                style = styleMap.get(STYLE_NORMAL_TYPES[styleTypeClass]);
            }
        } else {
            // LAYOUT_NORMAL as default
            style = styleMap.get(STYLE_NORMAL_TYPES[styleTypeClass]);
        }
        return style;
    }

}
