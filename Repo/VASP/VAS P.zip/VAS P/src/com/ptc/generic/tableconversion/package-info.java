/*
 * Responsible: T-Systems
 * 
 */

package com.ptc.generic.tableconversion;