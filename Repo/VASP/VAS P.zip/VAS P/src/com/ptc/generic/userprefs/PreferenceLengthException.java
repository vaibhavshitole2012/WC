
/* bcwti
 * 
 *  Copyright (c) 2011 Parametric Technology Corporation (PTC). All Rights
 *  Reserved.
 * 
 *  This software is the confidential and proprietary information of PTC.
 *  You shall not disclose such confidential information and shall use it
 *  only in accordance with the terms of the license agreement.
 * 
 *  ecwti
 */
package com.ptc.generic.userprefs;

import wt.util.WTException;
import wt.util.WTMessage;

/**
 * Exception is thrown when you tried to save user preference that had value
 * lunger then allowed number of chars determined by maximum varchar size in
 * database.
 *
 * @author piechutm
 */
public class PreferenceLengthException extends WTException {

    public PreferenceLengthException(Throwable t, String rb, String key, Object[] params, Object[] additionalMessages) {
        super(t, rb, key, params, additionalMessages);
    }

    public PreferenceLengthException(Throwable t, String rb, String key, Object[] params) {
        super(t, rb, key, params);
    }

    public PreferenceLengthException(Throwable t, String s, Object[] additionalMessages) {
        super(t, s, additionalMessages);
    }

    public PreferenceLengthException(Throwable t, String s) {
        super(t, s);
    }

    public PreferenceLengthException(Throwable t, WTMessage message, Object[] additionalMessages) {
        super(t, message, additionalMessages);
    }

    public PreferenceLengthException(Throwable t, Object[] additionalMessages) {
        super(t, additionalMessages);
    }

    public PreferenceLengthException(Throwable t, WTMessage message) {
        super(t, message);
    }

    public PreferenceLengthException(Throwable t) {
        super(t);
    }

    public PreferenceLengthException(String rb, String key, Object[] params, Object[] additionalMessages) {
        super(rb, key, params, additionalMessages);
    }

    public PreferenceLengthException(String rb, String key, Object[] params) {
        super(rb, key, params);
    }

    public PreferenceLengthException(String s, Object[] additionalMessages) {
        super(s, additionalMessages);
    }

    public PreferenceLengthException(String s) {
        super(s);
    }

    public PreferenceLengthException(WTMessage message, Object[] additionalMessages) {
        super(message, additionalMessages);
    }

    public PreferenceLengthException(Object[] additionalMessages) {
        super(additionalMessages);
    }

    public PreferenceLengthException(WTMessage message) {
        super(message);
    }

    public PreferenceLengthException() {
    }
}
