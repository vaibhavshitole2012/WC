package com.ptc.generic.epm;


import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;

import org.apache.log4j.Logger;

import com.ptc.service.annotations.GenerateService;
import com.ptc.windchill.uwgm.common.autoassociate.WTPartUtilities;
import com.ptc.windchill.uwgm.common.container.ContainerType;
import com.ptc.windchill.uwgm.common.query.QueryHelper;
import com.ptc.windchill.uwgm.common.util.PrintHelper;
import com.ptc.windchill.uwgm.common.workspace.ConfigSpecHelper;
import com.ptc.windchill.uwgm.proesrv.RequestContext;
import com.ptc.windchill.uwgm.proesrv.action.AddToWorkspaceAction;
import com.ptc.windchill.uwgm.proesrv.action.IncludeDependenciesOptionType;
import com.ptc.windchill.uwgm.proesrv.action.IncludeDrawingsOptionType;
import com.ptc.windchill.uwgm.soap.impl.uwgmdb.WorkspaceStateId_i;
import com.ptc.windchill.uwgm.soap.uwgmdb.WorkspaceStateIdX26;

import ext.tools.ToolUtils;
import wt.epm.EPMApplicationType;
import wt.epm.EPMContextHelper;
import wt.epm.EPMDocConfigSpec;
import wt.epm.EPMDocument;
import wt.epm.workspaces.CheckinOption;
import wt.epm.workspaces.EPMWorkspace;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.WTReference;
import wt.fc.collections.WTArrayList;
import wt.fc.collections.WTCollection;
import wt.fc.collections.WTKeyedHashMap;
import wt.fc.collections.WTKeyedMap;
import wt.fc.collections.WTValuedMap;
import wt.folder.Cabinet;
import wt.folder.Folder;
import wt.folder.FolderHelper;
import wt.folder.FolderNotFoundException;
import wt.folder.FolderService;
import wt.inf.container.WTContained;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerRef;
import wt.org.WTPrincipal;
import wt.part.WTPart;
import wt.part.WTPartConfigSpec;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.services.StandardManager;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.vc.baseline.Baselineable;
import wt.vc.views.View;
import wt.vc.wip.WorkInProgressHelper;

/**
 * Service that provides methods for EPMWorkspace handling. Use like this: VWEPMWorkspaceHelper.service.someMethod().
 */
@GenerateService(generateHelper=false) 
public class StandardEPMWorkspaceService extends StandardManager implements EPMWorkspaceService {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3536464181465769687L;
	private static final String CLASSNAME = StandardEPMWorkspaceService.class.getName();
	private static final Logger logger = Logger.getLogger(CLASSNAME);
	private RequestContext rcontext = null;
	
	/**
	 * Default factory for the class.
	 *
	 * @return    StandardEPMWorkspaceService
	 * @exception wt.util.WTException
	 **/
	public static StandardEPMWorkspaceService newStandardEPMWorkspaceService() throws WTException {
		StandardEPMWorkspaceService instance = new StandardEPMWorkspaceService();
		instance.initialize();
		return instance;
	}

	/**
	 * This method tries to find an EPMWorkspace with the given name that belongs to the 
	 * current user and with given container. If 'isExactSearch' parameter is set to true,
	 * then this method will try to find the workspace exactly with given name. 
	 * This method will try to find the workspace starting with given 
	 * name. If no workspace could be found, then a new one is created with the given name in the given container
	 * with current principal in the context.
	 * 
	 * @param container
	 *  a <code> WTContainer </code> type - container of the Theo.Part of EPMDocument
	 * @return
	 *  a <code> EPMWorkspace </code> type
	 * @throws
	 *  This method may throw WTException
	 */
	@Override
	public EPMWorkspace findOrCreateTempWS(WTContainer container) throws WTException {
		// try to find existing workspace
		EPMWorkspace ws = null;
		WTReference ref = findTempWS(container);
		if (ref != null){
			ws = (EPMWorkspace) ref.getObject();
		}

		WTPrincipal user = SessionHelper.manager.getPrincipal();
		
		// if no workspace was found, then try to create one
		if (ws == null) {
			ws = createWorkspace(EPMWorkspaceHelper.TMP_WS, user, container, true);
			logger.debug("New workspace created:" + ws.getName());
		} else {
			logger.debug("Existing workspace found:" + ws.getName());
		}

		return ws;
	}
	
	/**
	 * This method tries to find an EPMWorkspace with the given name that belongs to the 
	 * current user and with given container. If 'isExactSearch' parameter is set to true,
	 * then this method will try to find the workspace exactly with given name. If 'isExactSearch'
	 * parameter is set to false, then this method will try to find the workspace starting with given 
	 * name. If no workspace could be found, then a new one is created with the given name in the given container
	 * with current principal in the context.
	 * 
	 * @param workspaceName
	 *  a <code> String </code> type - Name of the workspace
	 * @param container
	 *  a <code> WTContainer </code> type - container of the Theo.Part of EPMDocument
	 * @param isExactSearch
	 *  a <code> boolean </code> type
	 * 
	 * @return
	 *  a <code> EPMWorkspace </code> type
	 * 
	 * @throws
	 *  This method may throw WTException
	 */
	@Override
	public EPMWorkspace findOrCreateWorkspace(String wsName, WTContainer container, boolean isExactSearch) throws WTException {
		// try to find existing workspace
		WTPrincipal user = SessionHelper.manager.getPrincipal();
		EPMWorkspace ws = this.findWorkspace(wsName, user, container, isExactSearch);
		// if no workspace was found, then try to create one
		if (ws == null) {
			ws = createWorkspace(wsName, user, container, true);
			logger.debug("New workspace created:" + ws.getName());
		} else {
			logger.debug("Existing workspace found:" + ws.getName());
		}

		return ws;
	}

	/**
	 * Searches for an EPMWorkspace with the given name that belongs to the current user search is exact, no wildcards allowed. When more than one workspace exist
	 * then the first found by QuerySpec is returned. 
	 * 
	 * @param workspaceName
	 * @param currentUser
	 */
	@Override
	public EPMWorkspace findWorkspace(String wsName, WTPrincipal currentUser) throws WTException {
		return this.findWorkspace(wsName, currentUser,null,true);
	}
	
	
	/**
	 * This method searches for an EPMWorkspace with the name provided with wsName
	 * parameter, with current user and with the given container. 
	 * If the 'isExactSearch' parameter is set to true, then this method
	 * searches for workspace exactly matching with given wsName. If the 'isExactSearch'
	 * parameter is set to false, then this method searches for workspaces starting with given
	 * wsName.
	 * 
	 * @param wsName
	 *  a <code> String </code> type - Name of the workspace prefix
	 * @param currentUser
	 *  a <code> WTPrincipal </code> type - current user
	 * @param container
	 *  a <code> WTContainer </code> type - container of the theo.part
	 * @param isExactSearch
	 *  a <code> boolean </code> type - whether to search workspace by exactly with given wsName or with start name as wsName
	 * @throws WTException
	 *  This method may throw WTException
	 *   
	 *   
	 */
	@Override
	public EPMWorkspace findWorkspace(String wsName, WTPrincipal currentUser, WTContainer container, boolean isExactSearch) throws WTException {
		//container can be null. So don't print container name in logging without null check
		logger.debug("Workspace name:" + wsName + ",currentUser:" + currentUser.getName()+",container:"+container+",isExactSearch:"+isExactSearch);
		if(container!=null){
			logger.debug("container name:"+container.getName());
		}
		QuerySpec querySpec = new QuerySpec();
		int wsInd = querySpec.addClassList(EPMWorkspace.class, true);
		final int[] queryIndexes = new int[] { wsInd };
		if (isExactSearch) {
			querySpec.appendWhere(new SearchCondition(EPMWorkspace.class, EPMWorkspace.NAME, SearchCondition.EQUAL, wsName), queryIndexes);
			querySpec.appendAnd();
		} else {
			querySpec.appendWhere(new SearchCondition(EPMWorkspace.class, EPMWorkspace.NAME, SearchCondition.LIKE, wsName + "%"), queryIndexes);
			querySpec.appendAnd();
		}
		// SearchCondition by user
		querySpec.appendWhere(QueryHelper.getSearchConditionByPrincipal(EPMWorkspace.class, currentUser), queryIndexes);
		if (container != null) {
			// SearchCondition by container
			querySpec.appendAnd();
			querySpec.appendWhere(QueryHelper.getSearchConditionByContainer(EPMWorkspace.class, container), queryIndexes);
		}
		QueryResult qr = QueryHelper.find(querySpec);
		while (qr.hasMoreElements()) {
			EPMWorkspace workspace = (EPMWorkspace) (((Persistable[]) qr.nextElement())[wsInd]);
			logger.debug("Workspace found with name:" + workspace.getName());
			if (workspace.getPrincipalReference().getPrincipal().equals(currentUser)) {
				return workspace;
			}
		}
		logger.debug("Workspace not found with name:" + wsName + " for user:" + currentUser.getName() + " in context:" + container);
		return null;
	}
	
	

	/** 
	 * Retrieves an instance of workspace. When createWorkspace parameter is true, it creates new workspace with name set in workspaceName parameter.
	 *  
	 * @param workspaceName Workspace name we want to retrieve or to create (depends on createWorkspace flag)
	 * @param createWorkspace Flag whether to instantiate existing workspace or to create new one
	 * @return instance of workspace or null if something was wrong
	 * @throws WTException
	 */ 
	@Override
	public EPMWorkspace getWorkspace(String workspaceName, WTPart phase, boolean createWorkspace) throws WTException {
		EPMWorkspace workspace = null;
		try {
			// whether to create new workspace
			if(createWorkspace) {
				workspace = findOrCreateWorkspace(workspaceName, phase.getContainer(),true);
			} else {
				workspace = findWorkspace(workspaceName, SessionHelper.manager.getPrincipal());
			}
		} catch(Throwable t) {
			if(t instanceof WTException) {
				throw (WTException) t;
			} else {
				throw new WTException(t);
			}

		}
		return workspace;
	}
	 
	/**
	 * This method creates the workspace with given parameters.
	 * Workspace name is derived from given name and container name
	 * separated by '-' if 'isAppendContName parameter value is set to true
	 * (ex: TEMP-JU003). This is needed
	 * to make the workpace unique as OOTB functionality don't allow
	 * creation of multiple workspaces with same name. Make sure that
	 * 'isAppendContName' is set to true only when TMP_WS work space
	 * is used. In other cases, 'isAppendContName' should be set to false.
	 * 
	 * Note about limitations of the workspace name
	 * -- Limit on number of characters in workspace name = 200
	 * -- Limit on number of characters in product container name = 60
	 * -- Limit on number of characters in library container name = 60
	 * -- number of characters in Temp workspace name = 13 (TMP_WS)
	 * Combination of temp workspace name and container name is less than characters
	 * limitation on workspace name. So further check is not added in this method.
	 * If there are any changes in these limitations, logic in this method should be
	 * changed.
	 * 
	 * @param name
	 *  a <code> String </code> type - Workspace name prefix 
	 * @param principal
	 *  a <code> WTPrincipal </code> type
	 * @param container
	 *  a <code> WTContainer </code> type
	 * @param isAppendContName
	 *  a <code> boolean </code> type
	 * @return
	 *  a <code> EPMWorkspace </code> type
	 * @throws WTException
	 */
	private EPMWorkspace createWorkspace(String wsName, WTPrincipal principal, WTContainer container,boolean isAppendContName) throws WTException {		
		
		if (ContainerType.isProjectContainer(container)) {
			throw new WTException("This method cannot create workspace in project container.");
		}

		String wsUniqueName = wsName;
		if (isAppendContName) {
			wsUniqueName += "-" + container.getName();
		}
		logger.debug("name:" + wsUniqueName + ",principal name:" + principal + ",container:" + container.getName());

		if (logger.isDebugEnabled()) {
			logger.debug("prepararing to create ws for user: " + principal.getName() + " with name: [" + wsUniqueName + "] in container: "
					+ ToolUtils.prettyPrint(container, false));
		}

		EPMWorkspace epmWorkspace = null;
		try {
			View preferredPartView = WTPartUtilities.getPreferredPartView(container);

			// create ConfigSpecs for EPMDocuments and WTParts
			EPMDocConfigSpec docCS = ConfigSpecHelper.createEPMDocConfigSpec(container);
			WTPartConfigSpec partCS = ConfigSpecHelper.createWTPartConfigSpec(container);

			// Apply Preference based view to the Part ConfigSpec
			if (!ContainerType.isProjectContainer(container)) {
				ConfigSpecHelper.setPreferredPartView(partCS, preferredPartView);
			}

			// create WS folder (in user Private Cabinet)
			Folder wsFolder = createWorkspaceFolder(wsUniqueName, principal);
			if (logger.isDebugEnabled()) {
				logger.debug("created WS folder: " + ToolUtils.prettyPrint(wsFolder, false));
			}

			// create EPMWorkspace objects
			epmWorkspace = EPMWorkspace.newEPMWorkspace(wsUniqueName, principal, wsFolder, partCS, docCS, container);
			if (logger.isInfoEnabled()) {
				logger.info("EPM workspace created: " + ToolUtils.prettyPrint(epmWorkspace, false));
			}

			// Default workspace preferences
			epmWorkspace.setView(preferredPartView);
			logger.debug("Part View : " + (preferredPartView == null ? "null" : preferredPartView.getName()) + " is set to the Workspace");


			// Save the WS
			epmWorkspace = (EPMWorkspace) PersistenceHelper.manager.save(epmWorkspace);
		} catch (WTPropertyVetoException wve) {
			throw new WTException(wve);
		}

		if (logger.isDebugEnabled()) {
			logger.debug("workspace created successfully: " + ToolUtils.prettyPrint(epmWorkspace, false));
		}

		return epmWorkspace;
	}
	
	
	  /**
	   * create new Folder for Workspace
	   *
	   * @throws WTException
	   * @return Folder
	   */
	  private Folder createWorkspaceFolder(String wsName, WTPrincipal principal) throws WTException {
	    Cabinet personalCab = FolderHelper.service.getPersonalCabinet(principal);
	    if (logger.isDebugEnabled()) {
	      logger.debug("users personal cabinet: " + ToolUtils.prettyPrint(personalCab, false));
}

	    WTContainerRef containerRef = personalCab.getContainerReference();

	    StringBuffer wsFolderPath = new StringBuffer(personalCab.getFolderPath());
	    // folder is plain wsName
	    wsFolderPath.append(FolderService.FOLDER_SEPARATOR).append(wsName);

	    // create WS folder
	    String spath = wsFolderPath.toString();
	    Folder wsFolder = null;
	    try {
	      wsFolder = FolderHelper.service.getFolder(spath, containerRef);
	    } catch (FolderNotFoundException fnf) {
	      wsFolder = FolderHelper.service.createSubFolder(spath, containerRef);
	      if (logger.isInfoEnabled()) {
			logger.info("created folder for WS: " + PrintHelper.printFolder(wsFolder));
		}
	    }

	    return wsFolder;
	  }
	
	/**
	 * This method finds the Temp workspace for the current user in the given container.
	 * When the contains is not null, this method checks for workspace starting with
	 * name 'TMP_WS'. 
	 * 
	 * This is a new method used for implementation of CR_2013_010.
	 * With this implementation we start keeping a WTReference to the Temp WS on client side
	 * 
	 * @param container
	 *  a <code> WTContainer </code> type
	 * @return 
	 *  a <code> WTReference </code> to the workspace
	 * @throws WTException
	 */
	@Override
	public WTReference findTempWS(WTContainer container) throws WTException {
		WTPrincipal user = SessionHelper.manager.getPrincipal();
		logger.debug("Container:"+container+"User:"+user);
		EPMWorkspace ws=null;
		WTReference wsRef=null;
		if (container == null) {
			ws = findWorkspace(EPMWorkspaceHelper.TMP_WS, user);
		} else {
			ws = findWorkspace(EPMWorkspaceHelper.TMP_WS, user, container, false);
		}
		if(ws!=null){
			wsRef = ObjectReference.newObjectReference(ws);
		}
		return wsRef;	
	}
	 
	

	/**
	 * This method deletes the given workspace provided that the owner of the
	 * workspace and the current user from the session are same.
	 * 
	 * @param ws
	 *            a <code> EPMWorkspace </code> type
	 * 
	 * @throws WTException
	 *             This method may throw WTException
	 * 
	 */
	@Override
	public void deleteWorkspace(EPMWorkspace ws) throws WTException {
		if(PersistenceHelper.isPersistent(ws)){
			String wsOwnerName = ws.getPrincipalReference().getPrincipal().getName();
			WTPrincipal currentUser = SessionHelper.manager.getPrincipal();
			if (currentUser.getName().equalsIgnoreCase(wsOwnerName)) {
				PersistenceHelper.manager.delete(ws);
				logger.debug("Workspace:" + ws.getName() + " deleted");
			} else {
				logger.error("Workspace cannot be deleted as owner:" + wsOwnerName + " and current user:" + currentUser.getName() + " are different");
			}
		}
	}
	
	/**
	 * Creates a temporary workspace, adds given EPMDocument to workspace and checks it out.<br>
	 * Make sure to check in EPMDocument using <code>checkin(aEPMDocument)</code> finally.
	 * @param workspace
	 * @param doc : The document to check out. 
	 * @return EPMDocument : The checked out and from DB refreshed working copy.
	 * @throws WTException
	 */
	@Override
	public EPMDocument checkout(EPMDocument doc) throws WTException {
		Collection toCheckout = checkin(new EPMDocument[]{doc}, doc.getContainer(),null);
		if(toCheckout != null && !toCheckout.isEmpty()){
			Iterator iter = toCheckout.iterator();
			if(iter.hasNext())
				return (EPMDocument) PersistenceHelper.manager.refresh((Persistable)iter.next());
		}
		
		return null;
	}
	
	/**
     * Creates a temporary workspace, adds given Baselineable object to workspace and checks it out.<br>
     * Make sure to check in EPMDocument using <code>checkin(Baselineable[] objs, WTContainer container)</code> finally.
     * @param objs : The documents or parts to check out.
     * @param container : Container where the temp. workspace is searched or created.
     * @return The checked out and workingcopy objects as a persistable collection.
     * @throws WTException
     */
	@SuppressWarnings("unchecked")
	@Override
	public Collection<Baselineable> checkout(Baselineable[] objs, WTContainer container) throws WTException {
		WTCollection result = null;
		//find temp-workspace from the first object passed in the array
		WTContainer _container = null;
		if (container == null) {
			if(objs[0] instanceof WTContained)
				_container = ((WTContained) objs[0]).getContainer();
		}else
			_container = container;
		
        EPMWorkspace workspace = findOrCreateTempWS(_container);
        if(workspace != null){
        	setApplicationType();
            WTKeyedMap instructions = new WTKeyedHashMap();
            /**
             * Adding document to workspace and check it out 
             */
            for (Baselineable baselineable : objs) {
            	instructions.put(baselineable, Boolean.TRUE);
			}
            AddToWorkspaceAction addToWorkspaceAction = new AddToWorkspaceAction(getRequestContext(), workspace);
            addToWorkspaceAction.setDependencyOption(IncludeDependenciesOptionType.REQUIRED);
    		addToWorkspaceAction.setDrawingsOption(IncludeDrawingsOptionType.SEED_ONLY);
    		addToWorkspaceAction.setAllInstances(true);
    		
            addToWorkspaceAction.addInstructions(instructions);
            addToWorkspaceAction.execute();
            
            /**
             * return result of checked out workingcopy objects
             */
            WTCollection checkedOutOnWS = addToWorkspaceAction.getCheckedOutIterations();
            WTValuedMap checkedOutToWorkingMap = WorkInProgressHelper.service.getCheckedOutToWorkingMap(checkedOutOnWS);
            result = checkedOutToWorkingMap.wtValues();
        }
        
		return (Collection<Baselineable>)result.persistableCollection();
    }
	
	/**
     * Checks in the given EPMDocument by using a temporary workspace, if existing.<br>
     * The found temporary workspace is finally deleted.
     * @param doc : The CADDoc to check in.
     * @return The checked in and from DB refreshed EPMDocument object.
     * @throws WTException
     */
	@Override
	public EPMDocument checkin(EPMDocument doc) throws WTException {
		Collection checkedin = checkin(new EPMDocument[]{doc}, doc.getContainer(),null);
		if(checkedin != null){
			Iterator iter = checkedin.iterator();
			if(iter.hasNext())
				return (EPMDocument) PersistenceHelper.manager.refresh((Persistable)iter.next());
		}
		return null;
	}
	
    /**
     * Checks in the given Baselineables by using a temporary workspace, if existing.<br>
     * The found temporary workspace is finally deleted.
     * @param objs : The documents or parts to check in.
     * @return Collection<Baselineable> : The checked in persistable objects.
     * @throws WTException
     */
	@SuppressWarnings("unchecked")
	@Override
	public Collection<Baselineable> checkin(Baselineable[] objs, WTContainer container, String comment) throws WTException {
		WTKeyedMap checkinMap = new WTKeyedHashMap();
		WTCollection result = null;
		//Collecting objects to check-in
		CheckinOption cioption = null;
		if(comment != null)
			cioption = new CheckinOption(comment);
		for (Baselineable baselineable : objs) {
			checkinMap.put(baselineable, cioption);
		}
		//find temp-workspace from the first object passed in the array
		WTContainer _container = null;
		if (container == null) {
			if(objs[0] instanceof WTContained)
				_container = ((WTContained) objs[0]).getContainer();
		}else
			_container = container;
		
		//Workaround: find fist in given container the workspace and secondly possibly in any container of the user
		WTReference workspaceref = findTempWS(_container);
		if(workspaceref == null)
			workspaceref = findTempWS(null);
		EPMWorkspace workspace = workspaceref == null? findOrCreateTempWS(_container) : (EPMWorkspace) workspaceref.getObject();
		if (workspace != null) {
			result = wt.epm.workspaces.EPMWorkspaceHelper.manager.checkin(workspace, checkinMap, new WTArrayList(), new WTArrayList());
		} else {
			try {
				//normal check-in
				result = WorkInProgressHelper.service.checkin(checkinMap);
			} catch (WTPropertyVetoException e) {
				throw new WTException();
			}
		}

		if (result != null) {
			deleteWorkspace(workspace);
			return (Collection<Baselineable>) result.persistableCollection();
		}
		
		return null;

	}
	
    private void setApplicationType() throws WTException{
		EPMApplicationType epmApplicationType = EPMContextHelper.getApplication();
		if(epmApplicationType == null){
			epmApplicationType = EPMApplicationType.toEPMApplicationType("EPM");
			try {
				EPMContextHelper.setApplication(epmApplicationType);
			} catch (WTPropertyVetoException e) {
				throw new WTException(e);
			}
		}
		
	}
    
    /**
	 * Creating dummy client context
	 * @param principal
	 * @return
	 * @throws WTException
	 */
    public RequestContext getRequestContext() throws WTException {
    	return getRequestContext(null);
    }
    
    /**
	 * Creating dummy client context
	 * @param principal
	 * @return
	 * @throws WTException
	 */
    private RequestContext getRequestContext(WTPrincipal principal) throws WTException {
    	
    	final Locale locale = SessionHelper.manager.getLocale();
		final WTPrincipal wtprincipal;
		if(principal == null){
			wtprincipal = SessionHelper.manager.getPrincipal();
		}else{
			wtprincipal = principal;
		}
    	
		if(rcontext != null){
			if(rcontext.getPrincipal().equals(wtprincipal)){
				return rcontext;
			}
		}
		
    	//Creating local request context
		rcontext = new RequestContext(){
			/**
			 * principal (user) name
			 */
			private WTPrincipal lprincipal = wtprincipal;
			/**
			 * client Locale
			 */
			private Locale llocale = locale;
			/**
			 * Client name
			 */
			private final String clientName = "Uwgm Server Workspace Creator";
			/**
			 * Client version identifier
			 */
			private final String clientVersion = "01";
			/**
			 * Is this an admin request
			 * 
			 */
			private boolean isAdminRequest = false;
			/**
			 * dummy sessionID
			 */
			private String clientSessionID = "sessionID" + clientVersion;
			/**
			 * dummy transactionID
			 */
			private String uwgmTransactionID = "transactionID" + clientVersion;
			/**
			 * dummy uwgmRequestID
			 */
			private String currentUwgmRequestID = "uwgmRequestID" + clientVersion;
			/**
			 * 
			 */
			private Map<String, WorkspaceStateId_i> savedWorkspaceUpdateCounters = new HashMap<String, WorkspaceStateId_i>();
			/**
			 * @return WTPrincipal
			 */
			@Override
			public WTPrincipal getPrincipal() {
				return lprincipal;
			}
			/**
			 * @return Locale
			 */
			@Override
			public Locale getLocale() {
				return llocale;
			}
			/**
			 * @return String
			 */
			@Override
			public String getClientName() {
				return clientName;
			}
			/**
			 * @return int
			 */
			@Override
			public String getClientVersion() {
				return clientVersion;
			}
			/**
			 * @return boolean
			 */
			@Override
			public boolean isStandalone() {
				return true;
			}
			@Override
			public boolean isAdminRequest() {
				return isAdminRequest;
			}
			/**
			 * client SessionID
			 * @return String
			 */
			@Override
			public String getClientSessionID() {
				return clientSessionID;
			}

			/**
			 * uwgm TransactionID
			 * @return String
			 */
			@Override
			public String getUwgmTransactionID() {
				return uwgmTransactionID;
			}

			/**
			 * current UwgmRequestID
			 * @return
			 */
			@Override
			public String getCurrentRequest() {
				return currentUwgmRequestID;
			}

			//@Override
			//public WorkspaceStateId_i getUpdateCounters(String objId) {
			//	return savedWorkspaceUpdateCounters.get(objId);
			//}
			
			//@Override
			//public void setWorkspaceCounters(String objId, WorkspaceStateId_i wsi) {
			//	savedWorkspaceUpdateCounters.put(objId, wsi);
			//	
			//}

			@Override
			public WorkspaceStateIdX26 getUpdateCounters(String arg0) {
				// TODO Auto-generated method stub
				return null;
			}
			@Override
			public boolean isRestRequest() {
				// TODO Auto-generated method stub
				return false;
			}
			@Override
			public void setWorkspaceCounters(String arg0, WorkspaceStateIdX26 arg1) {
				// TODO Auto-generated method stub
				
			}
		};
    	
    	return rcontext;
    }
}