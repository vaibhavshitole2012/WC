package com.ptc.generic.validators;

import java.text.MessageFormat;

import com.ptc.generic.validators.validatorsResource;

import wt.access.AccessControlHelper;
import wt.access.AccessControlled;
import wt.access.AccessPermission;
import wt.fc.collections.WTArrayList;
import wt.fc.collections.WTCollection;
import wt.util.WTException;
import wt.util.WTMessage;

/**
 * GenericAccessRightsValidator
 *
 * Checks if the passed rights are available for the current user on the passed object
 *
 * @author cherrmann
 *
 */
public class GenericAccessRightsValidator<T extends AccessControlled> implements GenericValidator<T> {

	private ValidationResult validationResult;
	private String errorMessage;
	private static final String defaultErrorMessage = WTMessage.getLocalizedMessage(VALIDATION_RESOURCE, validatorsResource.INVALID_NO_ACCESS_RIGHT, null);

	private AccessPermission[] accessPermissions;

	/**
	 * All passed AccessPermission will be validated.
	 *
	 * @param accessPermissions a list of AccessPermissions
	 */
	public GenericAccessRightsValidator(AccessPermission... accessPermissions) {
		this(null, accessPermissions);
	}

	/**
	 * All passed AccessPermission will be validated.
	 *
	 * @param errorMessage the default error message
	 * @param accessPermissions a list of AccessPermissions
	 */
	public GenericAccessRightsValidator(String errorMessage, AccessPermission... accessPermissions){
		this.accessPermissions = accessPermissions;
		this.errorMessage = errorMessage;
	}

	/**
	 *
	 * @param object an object which implements AccessControlled
	 * @return true if all the specified AccessPermissions are available for the current user
	 * @see com.ptc.generic.validators.GenericValidator#validate(java.lang.Object)
	 */
	@Override
	public boolean validate(T accessControlled) {
		resetValidationResult();

		if (accessControlled != null){
			WTCollection collection = new WTArrayList();
            collection.add(accessControlled);
			try {
				for (int i = 0; i < accessPermissions.length; i++){
					if (!AccessControlHelper.manager.hasAccess(collection, accessPermissions[i])) {
						if (errorMessage == null){
							this.validationResult = new ValidationResult(MessageFormat.format(defaultErrorMessage, accessControlled.toString(), accessPermissions[i].getDisplay()), false);
						} else {
							this.validationResult = new ValidationResult(errorMessage, false);
						}
					}
				}
			} catch (WTException e) {
				this.validationResult = new ValidationResult(MessageFormat.format(EXCEPTION_THROWN, e.getLocalizedMessage()), false, null, e);
				e.printStackTrace();
			}
		} else {
			this.validationResult = new ValidationResult(INVALID_PARAMETER_WAS_NULL, false);
		}

		if (this.validationResult == null){
			this.validationResult = new ValidationResult(SUCCESS_MESSAGE, true);
		}

		return this.validationResult.getIsValid();
	}

	@Override
	public ValidationResult getValidationResult() {
		return this.validationResult;
	}

	@Override
	public void resetValidationResult(){
		this.validationResult = null;
	}

}
