/* bcwti
 *
 * Copyright (c) 2008 Parametric Technology Corporation (PTC). All Rights
 * Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */
package com.ptc.generic.epm;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.log4j.Logger;

import com.ptc.core.businessRules.validation.RuleValidationObject;
import com.ptc.smb.helper.HelperBase;
import com.ptc.windchill.uwgm.common.associate.Association;

import ext.kb.util.ObjectRevisionHelper;
import wt.build.BuildHistory;
import wt.epm.EPMDocument;
import wt.epm.build.EPMBuildHistory;
import wt.epm.build.EPMBuildRule;
import wt.epm.familytable.EPMSepFamilyTable;
import wt.epm.navigator.CollectItem;
import wt.epm.navigator.EPMNavigateHelper;
import wt.epm.navigator.relationship.AssociatedCADDocs;
import wt.epm.structure.EPMDescribeLink;
import wt.epm.structure.EPMStructureHelper;
import wt.fc.ObjectIdentifier;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.fc.WTReference;
import wt.fc.collections.WTArrayList;
import wt.fc.collections.WTCollection;
import wt.fc.collections.WTHashSet;
import wt.fc.collections.WTKeyedMap;
import wt.fc.collections.WTList;
import wt.part.WTPart;
import wt.session.SessionHelper;
import wt.type.Typed;
import wt.type.TypedUtilityServiceHelper;
import wt.util.WTException;
import wt.vc.VersionControlHelper;
import wt.vc.struct.StructHelper;
import wt.vc.wip.WorkInProgressHelper;

public class EPMHelper {

	private static final String CLASSNAME = EPMHelper.class.getName();
	private static final Logger logger = Logger.getLogger(CLASSNAME);
	private static final ReferenceFactory RF = new ReferenceFactory();
	public static final com.ptc.generic.epm.EPMAssociateService service = wt.services.ServiceFactory.getService(com.ptc.generic.epm.EPMAssociateService.class);

	/**
	 * converts the given object o (either String, WTReference, or WTPart) to a
	 * WTPart does not check if object has correct softtype method should only
	 * be used on server!
	 *
	 * @param o
	 * @return a WTPart
	 * @throws WTException
	 *             if the given object can not be converted to a WTPart
	 */
	public static WTPart convertToWTPart(Object o) throws WTException {
		return convertToWTPart(o, (String) null);
	}

	/**
	 * converts the given object o (either String, WTReference, or WTPart) to a
	 * WTPart if shortSofttypeName is not null, then checks if the converted
	 * object is of the given softtype method should only be used on server!
	 *
	 * @param o
	 * @param shortSofttypeName
	 *            short name of softtype without full hierarchy
	 * @return a WTPart
	 * @throws WTException
	 *             if the given object can not be converted to a WTPart, or if
	 *             the WTPart has not the required softtype
	 */
	public static WTPart convertToWTPart(Object o, String shortSofttypeName) throws WTException {
		if (shortSofttypeName == null || shortSofttypeName.length() == 0) {
			return convertToWTPart(o, new String[0]);
		} else {
			return convertToWTPart(o, new String[] { shortSofttypeName });
		}
	}

	/**
	 * converts the given object o (either String, WTReference, or WTPart) to a
	 * WTPart if shortSofttypeNames isn't empty, then check if the converted
	 * object is of one of the given softtypes. <br>
	 * Method should only be used on server!
	 *
	 * @param o
	 * @param shortSofttypeNames
	 *            array of short names of softtype without full hierarchy
	 * @return a WTPart
	 * @throws WTException
	 *             if the given object can not be converted to a WTPart, or if
	 *             the WTPart has not the required softtype
	 */
	public static WTPart convertToWTPart(Object o, String[] shortSofttypeNames) throws WTException {
		// not nice to set o to a new object class several times, but then the
		// whole stuff below becomes quite easy
		WTPart part = null;
		try {
			o = convertToPersistable(o);
			if (o instanceof WTPart) {
				part = (WTPart) o;
			} else {
				throw new WTException("Given object does not represent a WTPart: o=" + o + " o.class=" + o.getClass().getName());
			}

			// check for softtype if it was given
			if (shortSofttypeNames != null && shortSofttypeNames.length != 0) {
				// there are softtype names given
				boolean foundCorrectST = false;
				for (String stname : shortSofttypeNames) {
					if (isType(part, stname)) {
						foundCorrectST = true;
						break;
					}
				}
				if (!foundCorrectST) {
					throw new WTException("Softtype not found");
				}
			}
		} catch (Exception e) {
			if (e instanceof WTException) {
				throw (WTException) e;
			} else {
				throw new WTException(e);
			}
		}
		return part;
	}

	/**
	 * Can be used to replace instanceof statements code: if(
	 * SoftTypeHelper.isType(object, "MyShortSofttypeName") ) ...
	 *
	 * @param object
	 * @param type
	 * @return
	 */
	private static boolean isType(Object object, String type) {
		if (object == null) {
			return false;
		}
		if (!(object instanceof wt.type.Typed)) {
			return false;
		}

		String typeName = null;
		try {
			typeName = TypedUtilityServiceHelper.service.getExternalTypeIdentifier((Typed) object);
		} catch (Exception re) {
			// lberger 20100616: I don't like not to throw such an exception,
			// but we would need to change many calling classes otherwise
			logger.error(re.getLocalizedMessage(), re);
			return false;
		}

		if (typeName != null && typeName.indexOf(type) >= 0) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * converts the given object o (either String, WTReference, Persistable,
	 * ObjectIdentifier) to a Persistable method should only be used on server!
	 * 
	 * @param o
	 * @return a Persistable
	 * @throws WTException
	 *             if the given object can not be converted to a Persistable
	 */
	public static Persistable convertToPersistable(Object o) throws WTException {

		// not nice to set o to a new object class several times, but then the
		// whole stuff below becomes quite easy
		Persistable persistable = null;
		try {
			if (o == null) {
				throw new WTException("FcHelper.convertToPersistable: given object was null");
			}
			if (o instanceof String) {
				o = RF.getReference((String) o);
			}

			if (o instanceof WTReference) {
				o = ((WTReference) o).getObject();
			} else if (o instanceof ObjectIdentifier) {
				final ObjectReference objRef = ObjectReference.newObjectReference((ObjectIdentifier) o);
				if (objRef != null) {
					o = objRef.getObject();
				}
			}
			persistable = (Persistable) o;
		} catch (Exception e) {
			if (e instanceof WTException) {
				throw (WTException) e;
			} else {
				throw new WTException(e);
			}
		}
		return persistable;
	}

	public static EPMDocument convertToEPMDoc(Object o) throws WTException {
		EPMDocument epmdoc = null;
		if (o instanceof EPMDocument) {
			epmdoc = (EPMDocument) o;
		} else if (o instanceof WTReference) {
			Persistable p = ((WTReference) o).getObject();
			if (p instanceof EPMDocument) {
				epmdoc = (EPMDocument) p;
			} else {
				throw new WTException("given WTReference does not represent a EPMDocument");
			}
		} else if (o instanceof String) {
			epmdoc = (EPMDocument) RF.getReference((String) o).getObject();
		} else if (o instanceof ObjectIdentifier) {
			final Persistable persistable = convertToPersistable(o);
			return convertToEPMDoc(persistable);
		}
		return epmdoc;
	}

	public static boolean isRoleRep(int buildFlags) {
		return (buildFlags & EPMBuildRule.CAD_REPRESENTATION) > 0;
	}

	public static boolean isRoleStruct(int buildFlags) {
		return (buildFlags & EPMBuildRule.BUILD_STRUCTURE) > 0;
	}

	public static boolean isRoleAttr(int buildFlags) {
		return (buildFlags & EPMBuildRule.BUILD_ATTRIBUTES) > 0;
	}

	/**
	 * @param o
	 * @return List<Association>
	 * @exception wt.util.WTException
	 **/
	public static List<EPMAssociation> getActiveAssociations(Object o) throws WTException {
		WTPart givenPart = null;
		EPMDocument givenEPMDoc = null;

		// try to convert given object to WTPart
		try {
			givenPart = convertToWTPart(o);
		} catch (Exception e) {
			// don't throw this exception, we will try to find a given
			// EPMDocument instead
		}

		if (givenPart != null) {
			return getActiveAssociationsOfPart(givenPart);
		} else {
			// try to convert given object to EPMDocument
			try {
				givenEPMDoc = convertToEPMDoc(o);
				if (givenEPMDoc != null) {
					return getActiveAssociationsOfEPMDoc(givenEPMDoc);
				} else {
					throw new Exception("nix"); // we'll throw a nice Exception
												// below then
				}
			} catch (Exception e) {
				// we could convert given Object to either WTPart or EPMDocument
				throw new WTException(
						"Given object is neither a WTPart nor an EPMDocument. givenObject=" + o + " class: " + (o == null ? "NULL" : o.getClass().getName()));
			}
		}
	}

	/**
	 * Returns active links for given WTPart
	 * 
	 * @param part
	 *            WTPart to find its active links
	 * @return Collection of EPMBuildRule representing active relation between
	 *         given part and CAD documents
	 */
	private static ArrayList<EPMBuildRule> getBuildRules(WTPart part) {
		ArrayList<EPMBuildRule> buildRules = new ArrayList<EPMBuildRule>();
		try {
			if (VersionControlHelper.isLatestIteration(part)) {
				QueryResult result = PersistenceHelper.manager.navigate(part, EPMBuildRule.BUILD_SOURCE_ROLE, EPMBuildRule.class, false);

				while (result.hasMoreElements()) {
					Object obj = result.nextElement();
					if (obj instanceof EPMBuildRule) {
						buildRules.add((EPMBuildRule) obj);
					}
				}
			}
		} catch (Exception e) {
			logger.error(e.getLocalizedMessage(), e);
		}
		return buildRules;
	}

	private static List<EPMAssociation> getActiveAssociationsOfPart(WTPart part) throws WTException {
		List<EPMAssociation> list = new ArrayList<EPMAssociation>();

		if (part == null) {
			throw new WTException("no part given to method getActiveAssociationsOfPart()");
		}

		if (VersionControlHelper.isLatestIteration(part)) {
			logger.debug("navigating via GenericUtilities.getBuildRules(part)");
			// BinaryLink links[] = GenericUtilities.getBuildRules(part);
			ArrayList<EPMBuildRule> links = getBuildRules(part);
			for (int i = 0; (links != null) && (i < links.size()); i++) {
				EPMBuildRule rule = links.get(i);
				logger.debug("found rule=" + rule);

				EPMDocument epmd = (EPMDocument) rule.getBuildSource();
				if (WorkInProgressHelper.isCheckedOut(epmd, SessionHelper.getPrincipal()) && !WorkInProgressHelper.isWorkingCopy(epmd)) {
					// this is an original copy where current user also owns the
					// working copy. Ignore and use the working copy
				} else {
					EPMAssociation assoc = new EPMAssociation(epmd, part, Association.Type.ACTIVE, isRoleStruct(rule.getBuildType()),
							isRoleRep(rule.getBuildType()), isRoleAttr(rule.getBuildType()), rule);
					list.add(assoc);
				}
			}
		} else {
			logger.debug("navigating via BuildHistory");
			QueryResult qr = PersistenceHelper.manager.navigate(part, BuildHistory.BUILT_BY_ROLE, BuildHistory.class, false);
			while (qr.hasMoreElements()) {
				EPMBuildHistory hist = (EPMBuildHistory) qr.nextElement();
				logger.debug("found hist=" + hist);
				EPMAssociation assoc = new EPMAssociation((EPMDocument) hist.getBuiltBy(), part, Association.Type.ACTIVE, isRoleStruct(hist.getBuildType()),
						isRoleRep(hist.getBuildType()), isRoleAttr(hist.getBuildType()), hist);

				list.add(assoc);
			}
		}

		return list;
	}

	private static List<EPMAssociation> getActiveAssociationsOfEPMDoc(EPMDocument epmdoc) throws WTException {
		List<EPMAssociation> list = new ArrayList<EPMAssociation>();

		if (epmdoc == null) {
			throw new WTException("no epmdoc given to method getActiveAssociationsOfPart()");
		}

		if (VersionControlHelper.isLatestIteration(epmdoc)) {
			logger.debug("navigating via BuildRule");
			QueryResult qr = PersistenceHelper.manager.navigate(epmdoc, EPMBuildRule.BUILD_TARGET_ROLE, EPMBuildRule.class, false);
			while (qr.hasMoreElements()) {
				EPMBuildRule buildRule = (EPMBuildRule) qr.nextElement();
				logger.debug("found hist=" + buildRule);

				EPMAssociation assoc = new EPMAssociation(epmdoc, (WTPart) buildRule.getBuildTarget(), Association.Type.ACTIVE,
						isRoleStruct(buildRule.getBuildType()), isRoleRep(buildRule.getBuildType()), isRoleAttr(buildRule.getBuildType()), buildRule);

				list.add(assoc);
			}
		} else {
			logger.debug("navigating via BuildHistory");
			QueryResult qr = PersistenceHelper.manager.navigate(epmdoc, BuildHistory.BUILT_ROLE, BuildHistory.class, false);
			while (qr.hasMoreElements()) {
				EPMBuildHistory hist = (EPMBuildHistory) qr.nextElement();
				logger.debug("found hist=" + hist);

				EPMAssociation assoc = new EPMAssociation(epmdoc, (WTPart) hist.getBuilt(), Association.Type.ACTIVE, isRoleStruct(hist.getBuildType()),
						isRoleRep(hist.getBuildType()), isRoleAttr(hist.getBuildType()), hist);

				list.add(assoc);
			}
		}

		return list;
	}

	/**
	 * @param o
	 * @return List<Association>
	 * @exception wt.util.WTException
	 **/
	public static List<Association> getPassiveAssociations(Object o) throws WTException {
		WTPart givenPart = null;
		EPMDocument givenEPMDoc = null;

		// try to convert given object to WTPart
		try {
			givenPart = convertToWTPart(o);
		} catch (Exception e) {
			// don't throw this exception, we will try to find a given
			// EPMDocument instead
		}

		if (givenPart != null) {
			return getPassiveAssociationsOfPart(givenPart);
		} else {
			// try to convert given object to EPMDocument
			try {
				givenEPMDoc = convertToEPMDoc(o);
				if (givenEPMDoc != null) {
					return getPassiveAssociationsOfEPMDoc(givenEPMDoc);
				} else {
					throw new Exception("nix"); // we'll throw a nice Exception
												// below then
				}
			} catch (Exception e) {
				// we could convert given Object to either WTPart or EPMDocument
				throw new WTException(
						"given object is neither a WTPart nor an EPMDocument. givenObject=" + o + " class: " + (o == null ? "NULL" : o.getClass().getName()));
			}
		}
	}

	private static List<Association> getPassiveAssociationsOfPart(WTPart part) throws WTException {
		List<Association> associations = new ArrayList<Association>();
		WTCollection parts = new WTArrayList();
		parts.add(part);
		WTKeyedMap partToDocs = StructHelper.service.navigateDescribedBys(parts, EPMDescribeLink.class, false);
		WTList list = (WTList) partToDocs.get(part);

		if (list != null) {
			for (Object object : list.persistableCollection()) {
				EPMDescribeLink link = (EPMDescribeLink) object;
				Association assoc = new Association(link.getDescribedBy(), part, Association.Type.PASSIVE, false, false, false);
				associations.add(assoc);
			}
		}
		return associations;
	}

	private static List<Association> getPassiveAssociationsOfEPMDoc(EPMDocument epmdoc) throws WTException {
		throw new WTException("getPassiveAssociationsOfEPMDoc(EPMDoc) is not yet implemented");
	}

	public static Collection<EPMDocument> getAssociatedEPMs(WTPart... parts) throws WTException {
		logger.debug("getAssociatedEPMs - start");
		AssociatedCADDocs associatedDocs = new AssociatedCADDocs();

		Collection<AssociatedCADDocs.Type> types = new ArrayList<AssociatedCADDocs.Type>();

		types.add(AssociatedCADDocs.Type.ACTIVE);

		associatedDocs.setTypes(types.toArray(new AssociatedCADDocs.Type[types.size()]));
		WTCollection associatedObjects = EPMNavigateHelper.navigate(HelperBase.toWTList((Object[]) parts), associatedDocs, CollectItem.OTHERSIDE)
				.getResults(new WTArrayList());

		logger.debug("getAssociatedEPMs - stop, result:" + associatedObjects.subCollection(EPMDocument.class));
		return associatedObjects.subCollection(EPMDocument.class);
	}
	
	public static boolean isFamilyTable(Persistable persistable) {
		boolean isFamilyTable = false;

		if (persistable instanceof EPMDocument) {
			EPMDocument epmDoc = (EPMDocument) persistable;
			isFamilyTable = epmDoc.getFamilyTableStatus() > 0 ? true : false;
			if (logger.isDebugEnabled()) {
				logger.debug(epmDoc.getNumber() + " is a family table? " + isFamilyTable);
			}
		}

		return isFamilyTable;
	}

	/**
	 * Checks if both CAD documents are members of the same family table.
	 * @param epm1 A family table. Can be a generic or variant.
	 * @param epm2 A family table. Can be a generic or variant.
	 * @return <br>true</br> if both CAD documents are members of the same family table,
	 * <br>false</br> if they are not family tables at all or if they do not belong to the same family table.
	 */
	public static boolean isFamily (EPMDocument epm1, EPMDocument epm2) {

		boolean isFamily = false;

		if (!isFamilyTable(epm1) || !isFamilyTable(epm2)) {
			isFamily = false;
		} else {
			WTCollection collection = getFamilyTableMembers(epm1);

			if (collection.isEmpty()) {
				isFamily = false;
			} else {
				isFamily = collection.contains(epm2);
			}
		}

		logger.debug(epm1.getNumber() + " and " + epm2.getNumber() + " are in the same family table? " + isFamily);
		return isFamily;
	}
	
	/**
	 * Returns all members of this family table, including the epmDoc itself
	 * 
	 * @param epmDoc The family table
	 * @return Collection of all family table members. Empty collection if epmDoc is not a family table.
	 */
	public static WTCollection getFamilyTableMembers(EPMDocument epmDoc) {
		WTCollection familyTableMembersCollection = new WTHashSet();
		if (logger.isDebugEnabled()){
			 logger.debug("entering getFamilyTableMembers");
		}
		if (epmDoc.getFamilyTableStatus() > 0) { // Generic or variant
			logger.debug(epmDoc.getNumber() + " is a family table object");
			try {
				// Retrieve the containers where this family table (generic/variant) is in.
				QueryResult qrFTContainer = EPMStructureHelper.service.navigateContainedIn(epmDoc, null, true);
				while (qrFTContainer.hasMoreElements()) {
					EPMSepFamilyTable epmSepFamilyTable = (EPMSepFamilyTable) qrFTContainer.nextElement();
					// Now we have a container. Retrieve the members (generic/variant).
					QueryResult qrFamTab = EPMStructureHelper.service.navigateContains(epmSepFamilyTable, null, true);
					// Add the family table objects to epmDocCollection.
					while (qrFamTab.hasMoreElements()) {
						Object famTabObj = qrFamTab.nextElement();
						if (famTabObj instanceof EPMDocument) {
							EPMDocument epmFamTabObj = (EPMDocument) famTabObj;
							// API returns all versions. Get the latest now.
							// TODO: Do we need to use another API to get the latest only?
							logger.debug("Found family table member " + epmFamTabObj.getNumber() + " - " + epmFamTabObj.getVersionIdentifier());
							EPMDocument latestEpmFamTabObj = ObjectRevisionHelper.getLatestVersion(epmFamTabObj);
							logger.debug("Adding latest version " + latestEpmFamTabObj.getVersionIdentifier() + " - " + latestEpmFamTabObj);
							familyTableMembersCollection.add(latestEpmFamTabObj);
						}
					}
				}
			} catch (WTException e) {
				logger.error("Error while retrieving family table objects for " + epmDoc.getNumber());
				logger.error(e);
			}
		}
		if (logger.isDebugEnabled()){
			 logger.debug("ended getFamilyTableMembers collection size=" + familyTableMembersCollection.size());
		}
		return familyTableMembersCollection;
	}
	
	 /** 
     * The preferences Include related Family table objects = All and Include related Generics = All
     * do not add the variants or generic if the validationObject is a generic or variant.
     * This method fixes this.
     * TODO: File a PTC case.
	 *
	 * @param epmDocCollection Collection of EPMDocument objects. This method loops through this list.
	 * When a family table object is encountered, the related family table objects are added.
	 * @param targetEPMDocument The object to validate. If it is a family table object (generic/variant), the related objects are added to the collection
	 * @return The collection enhanced by a generic if the validationObject is a variant or the variants if the validationObject is a generic
	 * The validationObject itself is not added.
	 */
	public static WTCollection addFamilyTableObjects(EPMDocument targetEPMDocument) {
		WTCollection epmDocCollection = new WTHashSet();
		
        epmDocCollection.addAll(EPMHelper.getFamilyTableMembers(targetEPMDocument));
        epmDocCollection.remove(targetEPMDocument);

		return epmDocCollection;
	}
	
}
