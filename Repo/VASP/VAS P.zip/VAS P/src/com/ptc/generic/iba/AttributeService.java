package com.ptc.generic.iba;

import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.Vector;

import org.apache.log4j.Logger;
import org.springframework.util.StringUtils;

import com.ptc.core.lwc.common.view.AttributeDefinitionReadView;
import com.ptc.core.lwc.common.view.TypeDefinitionReadView;
import com.ptc.core.lwc.server.PersistableAdapter;
import com.ptc.core.lwc.server.TypeDefinitionServiceHelper;
import com.ptc.core.meta.common.FloatingPoint;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.impl.WCTypeIdentifier;

import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.iba.constraint.AttributeConstraint;
import wt.iba.constraint.ConstraintGroup;
import wt.iba.constraint.IBAConstraintException;
import wt.iba.constraint.Immutable;
import wt.iba.definition.litedefinition.AttributeDefDefaultView;
import wt.iba.definition.service.IBADefinitionHelper;
import wt.iba.definition.service.StandardIBADefinitionService;
import wt.iba.value.DefaultAttributeContainer;
import wt.iba.value.IBAHolder;
import wt.iba.value.litevalue.AbstractValueView;
import wt.iba.value.service.IBAValueDBService;
import wt.iba.value.service.IBAValueHelper;
import wt.iba.value.service.IBAValueService;
import wt.iba.value.service.MultiObjIBAValueService;
import wt.services.ManagerServiceFactory;
import wt.services.ac.ACRuntimeException;
import wt.session.SessionHelper;
import wt.type.TypedUtilityServiceHelper;
import wt.util.WTException;

public class AttributeService {

	private static final String CLASSNAME = AttributeService.class.getName();
	private static final Logger logger = Logger.getLogger(CLASSNAME);
	private static final String READ_ERROR = "IBAHelper IBAs could not be read";
	private static final String WRITE_ERROR = "IBAHelper IBAs could not be set";
	private static final String UPDATE_ERROR = "IBAHelper IBAs could not be updated";
	private static StandardIBADefinitionService IBA_DEF_SERVICE;

	static {
		try {
			IBA_DEF_SERVICE = StandardIBADefinitionService.newStandardIBADefinitionService();
		} catch (WTException e) {
			logger.fatal("Failed to load IBA definition service", e);
			throw new ACRuntimeException(e); // System should NOT start up
		}
	}

	public static StandardIBADefinitionService getIBAService() {
		return IBA_DEF_SERVICE;
	}

	@SuppressWarnings("unchecked")
	public static <T> T getAttribute(Object primaryBusinessObject, String attribute) {
		if (logger.isDebugEnabled()) {
			logger.debug("Getting value for attribute: " + attribute);
		}
		Object obj = null;
		try {
			TypeIdentifier targetType = TypedUtilityServiceHelper.service.getTypeIdentifier(primaryBusinessObject);
			PersistableAdapter persistableAdapter = new PersistableAdapter((Persistable) primaryBusinessObject,
					((WCTypeIdentifier) targetType).getLeafName(), SessionHelper.getLocale(),
					new com.ptc.core.meta.common.DisplayOperationIdentifier());
			persistableAdapter.load(attribute);
			obj = persistableAdapter.get(attribute);
		} catch (wt.util.WTException exwt) {
			logger.error(READ_ERROR + " " + attribute);
		}

		return (T) obj;
	}

	public static HashMap<String, Object> getAttributes(java.lang.Object primaryBusinessObject, String[] ibaAttrNames) {
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		if (logger.isDebugEnabled()) {
			logger.debug("Getting values for attributes: " + ibaAttrNames);
		}
		try {
			TypeIdentifier targetType = wt.type.TypedUtilityServiceHelper.service
					.getTypeIdentifier(primaryBusinessObject);
			PersistableAdapter pa = new PersistableAdapter((Persistable) primaryBusinessObject,
					((WCTypeIdentifier) targetType).getLeafName(), SessionHelper.getLocale(),
					new com.ptc.core.meta.common.DisplayOperationIdentifier());
			pa.load(ibaAttrNames);
			for (String attrName : ibaAttrNames) {
				try {
					Object objAttr = pa.get(attrName);
					resultMap.put(attrName, objAttr);
				} catch (WTException ex) {
					logger.error(READ_ERROR + " " + attrName);
				}
			}

		} catch (wt.util.WTException exwt) {
			logger.error(READ_ERROR);
		}

		return resultMap;
	}

	public static HashMap<String, Object> getAttributes(java.lang.Object primaryBusinessObject,
			List<String> ibaAttrNames) {
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		if (logger.isDebugEnabled()) {
			logger.debug("Getting values for attributes: " + ibaAttrNames);
		}
		try {
			TypeIdentifier targetType = wt.type.TypedUtilityServiceHelper.service
					.getTypeIdentifier(primaryBusinessObject);
			PersistableAdapter pa = new PersistableAdapter((Persistable) primaryBusinessObject,
					((WCTypeIdentifier) targetType).getLeafName(), SessionHelper.getLocale(),
					new com.ptc.core.meta.common.DisplayOperationIdentifier());
			pa.load(ibaAttrNames);
			for (String attrName : ibaAttrNames) {
				try {
					Object objAttr = pa.get(attrName);
					resultMap.put(attrName, objAttr);
				} catch (WTException ex) {
					logger.info(READ_ERROR + " " + attrName);
				}
			}

		} catch (wt.util.WTException exwt) {
			logger.error(READ_ERROR);
		}

		return resultMap;
	}

	public static void setAttribute(Object primaryBusinessObject, String attr, Object objValue) {
		if (logger.isDebugEnabled()) {
			logger.debug("Setting value for attribute: " + attr + "=" + objValue);
		}
		try {
			TypeIdentifier targetType = wt.type.TypedUtilityServiceHelper.service
					.getTypeIdentifier(primaryBusinessObject);
			PersistableAdapter persistableAdapter = new PersistableAdapter((Persistable) primaryBusinessObject,
					((WCTypeIdentifier) targetType).getLeafName(), SessionHelper.getLocale(), null);

			persistableAdapter.load(attr);
			persistableAdapter.set(attr, convertValue(objValue));
			if (((Persistable) primaryBusinessObject).getPersistInfo().isPersisted())
				persistableAdapter.persist();

		} catch (wt.util.WTException exwt) {
			logger.error(WRITE_ERROR, exwt);
		}

	}

	public static void updateAttribute(Persistable primaryBusinessObject, String attributeName, Object objValue) {

		try {
			TypeIdentifier targetType = wt.type.TypedUtilityServiceHelper.service
					.getTypeIdentifier(primaryBusinessObject);
			PersistableAdapter persistableAdapter = new PersistableAdapter((Persistable) primaryBusinessObject,
					((WCTypeIdentifier) targetType).getLeafName(), SessionHelper.getLocale(), null);
			persistableAdapter.load(attributeName);
			persistableAdapter.set(attributeName, objValue);
			primaryBusinessObject = persistableAdapter.apply();
			primaryBusinessObject = (Persistable) PersistenceHelper.manager.modify(primaryBusinessObject);
		} catch (WTException e) {
			logger.error(UPDATE_ERROR, e);
		}
	}

	public static void updateAttribute(Persistable primaryBusinessObject, Map<String, Object> attributeToValueMap) {

		try {
			TypeIdentifier targetType = wt.type.TypedUtilityServiceHelper.service
					.getTypeIdentifier(primaryBusinessObject);
			PersistableAdapter persistableAdapter = new PersistableAdapter((Persistable) primaryBusinessObject,
					((WCTypeIdentifier) targetType).getLeafName(), SessionHelper.getLocale(), null);
			Set<String> keySet = attributeToValueMap.keySet();
			persistableAdapter.load(keySet);
			for (String attributeName : keySet) {
				persistableAdapter.set(attributeName, attributeToValueMap.get(attributeName));
			}
			primaryBusinessObject = persistableAdapter.apply();
			primaryBusinessObject = (Persistable) PersistenceHelper.manager.modify(primaryBusinessObject);
		} catch (WTException e) {
			logger.error(UPDATE_ERROR, e);
		}
	}

	public static void setMultipleAttribute(Object primaryBusinessObject, Map<String, Object> objValues) {
		if (logger.isDebugEnabled()) {
			logger.debug("Getting values for attributes: " + objValues);
		}
		try {
			TypeIdentifier targetType = wt.type.TypedUtilityServiceHelper.service
					.getTypeIdentifier(primaryBusinessObject);
			PersistableAdapter persistableAdapter = new PersistableAdapter((Persistable) primaryBusinessObject,
					((WCTypeIdentifier) targetType).getLeafName(), SessionHelper.getLocale(), null);
			persistableAdapter.load(objValues.keySet());
			for (Entry<String, Object> entry : objValues.entrySet()) {
				persistableAdapter.set(entry.getKey(), convertValue(entry.getValue()));
			}
			if (((Persistable) primaryBusinessObject).getPersistInfo().isPersisted())
				persistableAdapter.persist();

		} catch (wt.util.WTException exwt) {
			logger.error(WRITE_ERROR, exwt);
		}

	}

	/**
	 * Converts attributes' types from Java's OOTB to Windchill's. Float/Double
	 * -> FloatingPoint; Integer -> Long;
	 * 
	 * @param value
	 * @return
	 */
	private static Object convertValue(Object value) {
		Object convertedValue = value;
		if (value != null) {
			if (value instanceof Integer || value instanceof Long) {
				convertedValue = Long.valueOf(value.toString());
			} else if (value instanceof Float || value instanceof Double) {
				convertedValue = FloatingPoint.valueOf(value.toString());
			} else if (value instanceof java.util.Date) {
				java.util.Date date = (java.util.Date) value;
				convertedValue = new Timestamp(date.getTime());
			} else if (value instanceof Integer) {
				convertedValue = new Long((Integer) value);
			}
			if (logger.isDebugEnabled()) {
				logger.debug("Converted " + value.getClass() + " to " + convertedValue.getClass());
			}
		}
		return convertedValue;
	}

	public static void deleteValueOnAttribContainer(IBAHolder ibaHolder, ArrayList<String> attributesToClear)
			throws WTException {
		try {
			DefaultAttributeContainer container = (DefaultAttributeContainer) ibaHolder.getAttributeContainer();
			if (ibaHolder.getAttributeContainer() == null) {
				ibaHolder = IBAValueHelper.service.refreshAttributeContainerWithoutConstraints(ibaHolder);
				container = (DefaultAttributeContainer) ibaHolder.getAttributeContainer();
			}
			for (String ibaName : attributesToClear) {
				AttributeDefDefaultView attributeDefinition = IBADefinitionHelper.service
						.getAttributeDefDefaultViewByPath(ibaName);
				if (attributeDefinition != null) {
					try {
						container.deleteAttributeValues(attributeDefinition);
					} catch (IBAConstraintException e) {
						logger.warn("Custom Attribute SaveAs Reset: Attribute " + ibaName
								+ " can't be deleted, immutable constraint");
					}
				}
			}
			ibaHolder.setAttributeContainer(container);

		} catch (RemoteException ex) {
			throw new WTException(ex);
		}
	}

	/**
	 * Retrieves DefaultAttributeContainer from IBAHolder with a built-in
	 * functionality to refresh the container by IBAValueHelper when it was
	 * found null or the refreshFlag parameter is set to true.
	 * 
	 * @param ibaHolder
	 *            the IBAHolder containing the desired AttributeContainer
	 * @param refreshFlag
	 *            a flag indicating whether to force refresh of the attribute
	 *            container from IBAHolder
	 * 
	 * @return Possibly refreshed DefaultAttribueContainer from specified
	 *         IBAHolder
	 * 
	 * @throws WTException
	 *             the WT exception
	 * @throws RemoteException
	 *             the remote exception
	 */

	public static DefaultAttributeContainer getRefreshableAttributeContainer(IBAHolder ibaHolder, boolean refreshFlag)
			throws WTException, RemoteException {
		DefaultAttributeContainer attributeContainer = (DefaultAttributeContainer) ibaHolder.getAttributeContainer();
		if ((attributeContainer == null) || (PersistenceHelper.isPersistent(ibaHolder) && refreshFlag)) {
			ibaHolder = IBAValueHelper.service.refreshAttributeContainer(ibaHolder, null, null, null);
			attributeContainer = (DefaultAttributeContainer) ibaHolder.getAttributeContainer();
		}
		return attributeContainer;
	}

	/**
	 * Gets AttributeDefDefaultView object for given IBA name.
	 * 
	 * @param ibaName
	 *            name of the IBA attribute definition to be found
	 * @return AttributeDefDefaultView object for given IBA name
	 * @throws RemoteException
	 *             the remote exception
	 * @throws WTException
	 *             the WT exception
	 */
	public static AttributeDefDefaultView getAttributeDefDefaultView(String ibaName)
			throws RemoteException, WTException {
		AttributeDefDefaultView attributeDefinition = IBA_DEF_SERVICE.getAttributeDefDefaultViewByPath(ibaName);
		return attributeDefinition;
	}

	/**
	 * Checks if value of attribute is null or empty
	 * 
	 * @param object
	 *            - object
	 * @param attributeName
	 *            - attribute's name
	 * @return true if attribute's value is null or empty
	 */
	public static boolean isEmpty(Object object, String attributeName) {
		logger.debug("Start checking if attribute's value is null or empty");
		Object value = AttributeService.getAttribute(object, attributeName);
		logger.debug("value: " + value + " of attribute: " + attributeName);
		return StringUtils.isEmpty(value);
	}

	public static boolean updateIBAHolder(IBAHolder ibaHolder) {
		IBAValueDBService ibavaluedbservice = new IBAValueDBService();
		boolean flag = true;
		try {
			wt.iba.value.AttributeContainer attributecontainer = ibaHolder.getAttributeContainer();
			Object obj = ((DefaultAttributeContainer) attributecontainer).getConstraintParameter();
			wt.iba.value.AttributeContainer attributecontainer1 = ibavaluedbservice.updateAttributeContainer(ibaHolder,
					obj, null, null);
			ibaHolder.setAttributeContainer(attributecontainer1);
		} catch (WTException wtexception) {
			flag = false;
			logger.debug(wtexception);
		}
		return flag;
	}

	public static void deleteIBAAttribute(IBAHolder ibaHolder, String ibaName) throws WTException, RemoteException {
		if (logger.isDebugEnabled()) {
			logger.debug("entering deleteIBAAttribute(IBAHolder,String)");
			logger.debug("ibaHolder: " + ibaHolder);
			logger.debug("ibaName: \"" + ibaName + "\"");
		}
		IBAHolder holder = (IBAHolder) IBAValueHelper.service.refreshAttributeContainer(ibaHolder, null,
				SessionHelper.manager.getLocale(), null);
		DefaultAttributeContainer container = (DefaultAttributeContainer) holder.getAttributeContainer();
		container = suppressConstraint(container);
		// get exact attribute definizer
		AttributeDefDefaultView attDefinizer = IBADefinitionHelper.service.getAttributeDefDefaultViewByPath(ibaName);
		// remove attribute values from container if any
		AbstractValueView[] avv = container.getAttributeValues(attDefinizer);
		for (AbstractValueView abstractValueView : avv) {
			container.deleteAttributeValue(abstractValueView);
		}

		MultiObjIBAValueService dbm = (MultiObjIBAValueService) ManagerServiceFactory.getDefault()
				.getManager(IBAValueService.class);
		dbm.theStandardIBAValueService.theIBAValueDBService.updateAttributeContainer(ibaHolder,
				container.getConstraintParameter(), null, null);
		if (logger.isDebugEnabled()) {
			logger.debug("exiting deleteIBAAttribute()");
		}
	}

	private static DefaultAttributeContainer suppressConstraint(DefaultAttributeContainer theContainer)
			throws WTException {
		if (logger.isDebugEnabled()) {
			logger.debug("entering suppressConstraint(DefaultAttributeContainer)");
			logger.debug("theContainer: " + theContainer);
		}
		Vector cgs = theContainer.getConstraintGroups();
		Vector newCgs = new Vector();

		try {
			for (int i = 0; i < cgs.size(); i++) {
				ConstraintGroup cg = (ConstraintGroup) cgs.elementAt(i);
				if (cg != null) {
					Enumeration enums = cg.getConstraints();
					ConstraintGroup newCg = new ConstraintGroup();
					newCg.setConstraintGroupLabel(cg.getConstraintGroupLabel());
					while (enums.hasMoreElements()) {
						AttributeConstraint ac = (AttributeConstraint) enums.nextElement();
						if (!(ac.getValueConstraint() instanceof Immutable)) {
							newCg.addConstraint(ac);
						}
					}
					newCgs.addElement(newCg);
				}
			}
			theContainer.setConstraintGroups(newCgs);
		} catch (Exception ex) {
			throw new WTException(ex);
		}

		if (logger.isDebugEnabled()) {
			logger.debug("exiting suppressConstraint()");
			logger.debug("returning: " + theContainer);
		}
		return theContainer;
	}

	/**
	 * The method returns the display name of given attribute of a specified
	 * type
	 * 
	 * @param softTypeName
	 *            - type name
	 * @param attributeName
	 *            - attributeName
	 * @return
	 */
	public static String getAttributeDisplayValue(String softTypeName, String attributeName) {
		TypeIdentifier identifier = wt.type.TypedUtility.getTypeIdentifier(softTypeName);
		TypeDefinitionReadView view;
		String displayName = null;
		logger.debug("Starting of getting display name for: " + softTypeName + " attribute name " + attributeName);
		try {
			view = TypeDefinitionServiceHelper.service.getTypeDefView(identifier);
			AttributeDefinitionReadView singleibaView = view.getAttributeByName(attributeName);
			if(singleibaView == null) {
				return displayName;
			}
			// The key is 'displayName'.
			displayName = singleibaView.getPropertyValueByName("displayName")
					.getValue(wt.session.SessionHelper.manager.getLocale(), false).toString();
		} catch (WTException e) {
			logger.debug("error during getting the display name of: " + attributeName + " " + softTypeName);
		}
		return displayName;
	}
}
