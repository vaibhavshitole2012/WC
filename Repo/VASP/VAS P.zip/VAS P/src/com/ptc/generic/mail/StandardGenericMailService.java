package com.ptc.generic.mail;

import java.util.Enumeration;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Set;

import org.apache.commons.lang.ArrayUtils;
import org.apache.log4j.Logger;

import wt.mail.EMailMessage;
import wt.org.OrganizationServicesHelper;
import wt.org.WTGroup;
import wt.org.WTPrincipal;
import wt.org.WTUser;
import wt.services.StandardManager;
import wt.util.WTException;
import wt.util.WTMessage;

import com.ptc.generic.mail.GenericMailService;
import com.ptc.service.annotations.GenerateService;

/**
 * StandardGenericMailService
 *
 * Provides functionality to send localized mails to single users and groups.
 *
 * @author cherrmann
 *
 */
@GenerateService
public class StandardGenericMailService extends StandardManager implements GenericMailService {

	private static final long serialVersionUID = 3071790141035425293L;
	
	private static final Locale[] supportedLocales = {Locale.GERMAN, Locale.ENGLISH};
	
	private static final Logger logger = Logger.getLogger(StandardGenericMailService.class);

	public static StandardGenericMailService newStandardGenericMailService() throws WTException {
		StandardGenericMailService instance = new StandardGenericMailService();
		instance.initialize();
		return instance;
	}

	private void sendLocalizedMail(Set<WTUser> recipients, Set<WTUser> ccRecipients, Set<WTUser> bccRecipients, WTPrincipal originator,
			Class<? extends ResourceBundle> resourceBundle, String resourceEntry, String[] textInsertsSubject,
			String[] textInsertsBody, String[] attachments, int attachmentType, Set<Locale> locales) throws WTException {
		EMailMessage eMail = EMailMessage.newEMailMessage();

		
		// FROM:
		eMail.setOriginator(originator);

		// TO:
		addRecipients(eMail, recipients, EMailMessage.TO_RECIPIENT);

		// CC:
		addRecipients(eMail, ccRecipients, EMailMessage.CC_RECIPIENT);
		
		// BCC:
		addRecipients(eMail, bccRecipients, EMailMessage.BCC_RECIPIENT);

		// SUBJECT:
		String subject = getLocalizedTexts(resourceBundle, resourceEntry + "_SUBJECT", textInsertsSubject, locales, " / ");
		eMail.setSubject(subject);

		// BODY:
		String body = getLocalizedTexts(resourceBundle, resourceEntry + "_BODY", textInsertsBody, locales, "<br><br><br><br>");
		eMail.addPart(body, "text/html");
		
		// ATTACHMENT:
		if( attachments != null && attachments.length > 0){
            eMail.addAttachments(attachments);
            eMail.setAttachContentType(attachmentType);
        }

		if (logger.isDebugEnabled()) {
			logger.debug("attempting to send the email with the following parameters:");
			logger.debug("subject: " + subject);
			logger.debug("body:" + body);
			logger.debug("recipients: " + eMail.getRecipients());
			logger.debug("cc recipients" + eMail.getCcRecipients());
			logger.debug("bcc recipients: " + eMail.getBccRecipients());			
		}

		eMail.send(true);
	}
	
	/**
	 * @param resourceBundle
	 * @param resourceEntry
	 * @param textInsertsSubject
	 * @param locales
	 */
	private String getLocalizedTexts(Class<? extends ResourceBundle> resourceBundle, String resourceEntry, String[] textInserts, Set<Locale> locales, String filler) {
		StringBuilder text = new StringBuilder();
		Set<Locale> localeCopy = new HashSet<Locale>();
		localeCopy.addAll(locales);
		boolean appended = false;
		
		if (localeCopy.contains(Locale.GERMAN)) {
			localeCopy.remove(Locale.GERMAN);
			text.append(WTMessage.getLocalizedMessage(resourceBundle.getName(), resourceEntry, textInserts, Locale.GERMAN));
			appended = true;
		}
		
		for (Locale locale : localeCopy){
			if (appended){
				text.append(filler);
			} else {
				appended = true;
			}
			text.append(WTMessage.getLocalizedMessage(resourceBundle.getName(), resourceEntry, textInserts, locale));
		}
		
		return text.toString();
	}

	/**
	 * @param recipients
	 * @param toRecipient
	 * @throws WTException 
	 */
	private void addRecipients(EMailMessage eMail, Set<WTUser> recipients, int recipientType) throws WTException {
		for (WTUser recipient : recipients){
			eMail.addRecipient(recipient, recipientType);
		}
	}

	/**
	 * @Deprecated - Not localized - Please use sendLocalizedMail instead.
	 * 
	 * Sends an E-Mail with an attachment. The attachment comes from a documents primary or secondary content.
	 * The document is the objectreference as string (epmReference)
     *
     * @param     subject
     * @param     body
     * @param     prince
     * @param	  epmReference
     * @param	  contentType - e.g. EMailMessage.ATTACH_SECONDARY_CONTENT (= 2) to get secondary content
     * @return    boolean
     * @exception wt.util.WTException
     **/	
	@Deprecated
	public boolean sendEMailWithAttachment( String subject, String body, WTPrincipal prince, String contentHolderReference, int contentType)
             throws WTException {

         EMailMessage eMail = EMailMessage.newEMailMessage();
         //FROM:
         eMail.setOriginator(prince);
         //TO:
         eMail.addRecipient(prince);
         //SUBJECT:
         eMail.setSubject(subject);
         //BODY:
         eMail.addPart(body, "text/html");
         
         
         if( contentHolderReference != null && contentHolderReference.length() > 0){
             String[] attachments = {contentHolderReference};
             eMail.addAttachments(attachments);
             eMail.setAttachContentType(contentType);
         }
         eMail.sendWithAttachment(true);
         return true;
    }
	
	/**
	 * @Deprecated - Not localized - Please use sendLocalizedMail instead.
	 * 
     * Sends an E-Mail without attachment
     *
     * @param     subject
     * @param     body
     * @param     prince
     * @return    boolean
     * @exception wt.util.WTException
     **/
	@Deprecated
	public boolean sendEMailWithoutAttachment( String subject, String body, WTPrincipal reciepient)
        throws WTException {
		return sendEMailWithoutAttachment(subject, body, reciepient, reciepient);
	}
	
	
	/**
	 * @Deprecated - Not localized - Please use sendLocalizedMail instead.
	 * 
     * Sends an E-Mail without attachment
     *
     * @param     subject
     * @param     body
     * @param     prince
     * @return    boolean
     * @exception wt.util.WTException
     **/
	@Deprecated
	public boolean sendEMailWithoutAttachment( String subject, String body, WTPrincipal reciepient, WTPrincipal originator)
            throws WTException {
        EMailMessage eMail = EMailMessage.newEMailMessage();
        //FROM:
        eMail.setOriginator(originator);
        //TO:
        eMail.addRecipient(reciepient);
        //SUBJECT:
        eMail.setSubject(subject);
        //BODY:
        eMail.addPart(body, "text/html");

        eMail.send(true);
        return true;
   }

	/**
	 * This function will send an email to the list of recipients.
	 * The mail is localized to the language which is set in the windchill user preference of each user.
	 * 
	 * The resource bundle and bundle-entry specify the message which should be used.
	 * Three resource entries are needed:
	 * 
	 * <ENTRY_NAME>
	 * <ENTRY_NAME>_BODY
	 * <ENTRY_NAME>_SUBJECT
	 * 
	 * The <ENTRY_NAME> is only a dummy. The _BODY part holds the text / html code for the email body and the _SUBJECT holds the mails subject.
	 * The <ENTRY_NAME> without and appendices is mandatory! This is the entry point which has to be passed to the function call as 'resourceEntry' parameter.
	 * During the assembly of the mail the _BODY and _SUBJECT parts of the resource are attached to the entry point to get the localized values.
	 * 
	 * The resource entries may contain indexes for text replacement, e.g. {0}
	 * Those are replaced automatically replaced with the entries in 'textInsertsSubject' / 'textInsertsBody'
	 * 
	 * 
	 * Example - Resource bundle called errorMailResource with the following entries:
	 * ERROR_MAIL_NOTIFICATION.constant=ERROR_MAIL_NOTIFICATION
	 * ERROR_MAIL_NOTIFICATION.value=
	 * 
	 * ERROR_MAIL_NOTIFICATION_BODY.constant=ERROR_MAIL_NOTIFICATION_BODY
	 * ERROR_MAIL_NOTIFICATION_BODY.constant=This mail informs about an error in function {0}
	 * 
	 * ERROR_MAIL_NOTIFICATION_SUBJECT.constant=ERROR_MAIL_NOTIFICATION_SUBJECT
	 * ERROR_MAIL_NOTIFICATION_SUBJECT.value=An error happened
	 * 
	 * Function Call:
	 * WTPrincipal user = SessionHelper.getPrincipal(); 
 	 * 
	 * String[] textInsertsSubject = null; 
	 * String[] textInsertsBody = new String[1]; 
	 * textInsertsBody[0] = "MyFunction"; 
 	 * 
	 * GenericMailHelper.service.sendLocalizedMail(user, user, errorMailResource.class, errorMailResource.ERROR_MAIL_NOTIFICATION, textInsertsSubject, textInsertsBody, null, -1); 
	 * 
	 * 
	 * @param recipients
	 * @param originator
	 * @param resourceBundle
	 * @param resourceEntry
	 * @param textInsertsSubject
	 * @param textInsertsBody
	 * @throws WTException
	 */
	public void sendLocalizedMail(List<WTPrincipal> recipients, List<WTPrincipal> ccRecipients, List<WTPrincipal> bccRecipients, WTPrincipal originator,
			Class<? extends ResourceBundle> resourceBundle, String resourceEntry, String[] textInsertsSubject,
			String[] textInsertsBody, String[] attachments, int attachmentType) throws WTException {
		if (recipients == null && ccRecipients == null && bccRecipients == null) {
			throw new WTException("Could not send email. No recipients given!");
		}
		if (resourceBundle == null) {
			throw new WTException("Could not send email. No resource bundle given!");
		}
		if (resourceEntry == null) {
			throw new WTException("Could not send email. No resource entry given!");
		}
		
		
		Set<WTUser> allRecipientsUsers = splitGroupsIntoUsers(recipients);
		Set<WTUser> allCCRecipientsUsers = splitGroupsIntoUsers(ccRecipients);
		Set<WTUser> allBCCRecipientsUsers = splitGroupsIntoUsers(bccRecipients);
		
		Set<WTUser> allRecipients = new HashSet<WTUser>();
		allRecipients.addAll(allRecipientsUsers);
		allRecipients.addAll(allCCRecipientsUsers);
		allRecipients.addAll(allBCCRecipientsUsers);
		
		Set<Locale> locales = new HashSet<Locale>();

		for (WTUser recipient : allRecipients) {
			if (recipient instanceof WTUser) {
				Locale userLocale = new Locale(recipient.getLocale().getLanguage());
				if (ArrayUtils.contains(supportedLocales, userLocale)) {
					locales.add(userLocale);
				} else {
					locales.add(Locale.ENGLISH);
				}
			}
		}
		
		sendLocalizedMail(allRecipientsUsers, allCCRecipientsUsers, allBCCRecipientsUsers, originator, resourceBundle, resourceEntry, textInsertsSubject, textInsertsBody, attachments, attachmentType, locales);
	}
	
	private Set<WTUser> splitGroupsIntoUsers(List<WTPrincipal> recipients) throws WTException {
		Set<WTUser> allRecipientUsers = new HashSet<WTUser>();
		if (recipients != null) {
			for (WTPrincipal recipient : recipients) {
				if (recipient instanceof WTUser) {
					allRecipientUsers.add((WTUser) recipient);
				} else if (recipient instanceof WTGroup) {
					WTGroup group = (WTGroup) recipient;
					if (group != null) {
						Enumeration<?> members = OrganizationServicesHelper.manager.members(group, true);
						while (members.hasMoreElements()) {
							WTUser user = (WTUser) members.nextElement();
							allRecipientUsers.add(user);
						}
					}
				}
			}
		}

		return allRecipientUsers;
	}
}
