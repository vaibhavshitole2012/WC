/*
 * Repair Util for repair tools:
 * RepairMengenverwendungDValues
 * ChangeMengenverwendungLCState
 * ActiveAndPassiveLnks
 * @a.nowak
 */

package com.ptc.generic.datarepair;

import java.util.SortedMap;
import java.util.TreeMap;

import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.lifecycle.State;
import wt.part.WTPart;
import wt.util.WTException;
import wt.vc.Iterated;
import wt.vc.VersionControlException;
import wt.vc.VersionControlHelper;
import wt.vc.Versioned;


public class DataRepairUtil {

    private static ReferenceFactory rf = new ReferenceFactory();

    
    protected static String getPartDisplay(WTPart part) throws VersionControlException {
	return part.getNumber() + " - " + part.getName() + " " + DataRepairUtil.getVersionIterationDisplay(part) + " (" + part + ")";
    }
    
    protected static String getVersionIterationDisplay(Versioned objIteration) throws VersionControlException {
        return VersionControlHelper.getVersionIdentifier(objIteration).getValue() + "." + VersionControlHelper.getIterationIdentifier(objIteration).getValue();
    }

    protected static String getSortableVersionIterationDisplay(Versioned objIteration) throws VersionControlException {
        return VersionControlHelper.getVersionIdentifier(objIteration).getValue() + "." + String.format("%2s", VersionControlHelper.getIterationIdentifier(objIteration).getValue());
    }

    protected static SortedMap<String, Versioned> getSortedIterationsAsc(QueryResult qr) throws VersionControlException {
        SortedMap<String, Versioned> sortedIterations = new TreeMap<String, Versioned>();
        while (qr.hasMoreElements()) {
            Versioned iteration = (Versioned) qr.nextElement();
            sortedIterations.put(getSortableVersionIterationDisplay(iteration), iteration);
        }
        return sortedIterations;
    }

    protected static Iterated getLatestIteration(String oid) throws WTException, VersionControlException {
        Iterated latestIteration = getIteration(oid);

        if (!latestIteration.isLatestIteration()) {
            latestIteration = VersionControlHelper.getLatestIteration(latestIteration);
        }
        return latestIteration;
    }

    protected static Iterated getIteration(String oid) throws WTException {
        Iterated iteration = null;
        try {
            iteration = (Iterated) rf.getReference(oid).getObject();
        } catch (Exception ex) {
            System.out.println("Teil " + oid + " existiert nicht");
        }

        return iteration;
    }

    protected static SortedMap<String, Versioned> getSortedIterations(String oid) throws WTException {
        Iterated latestIteration = DataRepairUtil.getLatestIteration(oid);

        QueryResult qrAllIterations = VersionControlHelper.service.allIterationsFrom(latestIteration);

        SortedMap<String, Versioned> sortedIterations = DataRepairUtil.getSortedIterationsAsc(qrAllIterations);

        return sortedIterations;
    }
    protected static State getPartState(WTPart partIteration) {

        State lcState = partIteration.getLifeCycleState();

        return lcState;
    } 
}
