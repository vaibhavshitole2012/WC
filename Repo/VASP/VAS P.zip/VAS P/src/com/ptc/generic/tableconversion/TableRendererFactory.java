/** 

Factory class for the creation of a table renderer object.

@author Lothar Germund, PLUS-Systeme GmbH
@since 20.10.2010
*/

package com.ptc.generic.tableconversion;

/**
 * @author DVORGER
 *
 */
public interface TableRendererFactory {


    /**
     * Creates a table renderer object.
     * 
     * @param renderType
     * @param tableConfig
     * @return renderer object
     * @throws RenderException
     */
    public TableRenderer create(String renderType, TableConfiguration tableConfig) throws RenderException;
}
