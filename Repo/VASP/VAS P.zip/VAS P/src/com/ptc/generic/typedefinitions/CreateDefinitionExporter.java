/*
 * bcwti
 *
 * Copyright (c) 2013 PTC Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */
/**
 * 
 */
package com.ptc.generic.typedefinitions;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.Charset;
import java.util.Set;

import wt.util.WTException;

import com.ptc.generic.GenericProperties;

/**
 * Tool to generate the "DefinitionExporter.xml" files to export type definitions.
 * 
 * @author Benjamin Mueller (bmueller@ptc.com)
 * @version 20130425
 * @see VW_ECA-17233
 * @since 5.0
 * 
 * Usage:
 * windchill com.ptc.generic.typedefinitions.CreateDefinitionExporter
 */
public final class CreateDefinitionExporter {

    public static final String svnRev = "$Revision: 1.1.1.3 $ $Date: 2016/02/23 22:21:36IST $";
    public static final String svnUrl = "$URL: http://127.0.0.1/svn/KB_04082016/components/Generic-Utilities/src/com/ptc/generic/typedefinitions/CreateDefinitionExporter.java $";
    
    private static String wt_home = "/ptc/Windchill_10.1/Windchill/";
    private static String exportDir = "loadFiles/ext/kb/typedefinitions/";
    private static boolean ancestors = false;
    private static int exportMode = 0;
    private static final String PREFIX = "DefinitionExporter_";
    private static String username = "wcadmin";
    private static String password = "wcadmin";
    private static int timeout = 5000;
    private static final Charset ENCODING = Charset.forName("cp1252");
    private static BufferedReader userreader = new BufferedReader(new InputStreamReader(System.in, ENCODING));
    private static GenericProperties typeDefinitions = null;
	private static final String TYPE_DEF_PROPERTIES = "com/ptc/generic/typedefinitions/typeDefinitions.properties";

    /**
     * @param args
     * @throws IOException 
     * @throws WTException 
     */
    public static void main(String[] args) throws IOException, WTException {

        initMap();
        
        System.out.println("Hit enter to accept the default value.");
        wt_home = getResponse("Enter WT_HOME", wt_home);
        exportDir = getResponse("Enter export directory", exportDir);
        ancestors = Boolean.valueOf(getResponse("Export ancestors?", "false"));
        exportMode = Integer.parseInt(getResponse("Export mode: 0 - default inside XML OR 1 - additional rbInfo files", "0"));
        username = getResponse("Admin username?", username);
        password = getResponse("Admin password?", password);
        
        writeExporter();
        
        if (Boolean.valueOf(getResponse("Directly execute exports?", "false"))) {
            timeout = Integer.parseInt(getResponse("Delay between commands in milliseconds?", "5000"));
            executeExport();
        }
        
        userreader.close();
    }
    
    /*
     * Map between
     * type name which will be used as postfix for export definition
     * and
     * the internal name of the type.
     */
    private static void initMap() throws WTException {

		if (typeDefinitions == null) {
			typeDefinitions = GenericProperties.getProperties(TYPE_DEF_PROPERTIES, true);
		}
    }

    /*
     * Write the DefinitionExporter.xml files with information from the map.
     * Example of a DefinitionExporter.xml file.
     *  
<?xml version="1.0"?>
<!DOCTYPE NmLoader SYSTEM "standardX20.dtd">
  <NmLoader>
    <csvExportDefinition handler="com.ptc.core.lwc.server.TypeDefinitionExporter.beginExportDefinition">
      <csvtoLocation>D:\</csvtoLocation>
      <csvtoFileName>document.xml</csvtoFileName>
      <csvexportDefClass>com.ptc.core.lwc.server.LWCTypeDefinition</csvexportDefClass>
      <csvexportNames>wt.doc.WTDocument</csvexportNames>
      <csvmode>0</csvmode>
      <csvExportAncestorTypes>true</csvExportAncestorTypes>
    </csvExportDefinition> 
    <!--
    windchill wt.load.LoadFromFile -d d:/ptc/Windchill_10.1/Windchill/loadFiles/export/DefinitionExporter.xml -u wcadmin -p wcadmin -CONT_PATH /
    -->
</NmLoader> 
     */
    private static void writeExporter() throws IOException {
        
        final Set<Object> filenames = typeDefinitions.keySet();
        
        File file = null;
        BufferedWriter bw = null;
        StringBuffer sb = null;
        final File directory = new File(wt_home + exportDir + "export/");
        boolean targetExists = false;
        if (!directory.exists()) {
            targetExists = directory.mkdirs();
        } else {
            targetExists = true;
        }
        
        if (targetExists) {
        	
            for (final Object filename : filenames) {

                file = new File(wt_home + exportDir + "export/" + PREFIX + filename.toString() + ".xml");
                bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file), ENCODING));
                sb = new StringBuffer();

                sb.append("<?xml version=\"1.0\"?>\n");
                sb.append("<!DOCTYPE NmLoader SYSTEM \"standardX20.dtd\">\n");
                sb.append("<NmLoader>\n");
                sb.append("\t<csvExportDefinition handler=\"com.ptc.core.lwc.server.TypeDefinitionExporter.beginExportDefinition\">\n");
                sb.append("\t\t<csvtoLocation>");
                sb.append(wt_home);
                sb.append(exportDir); // location
                sb.append("</csvtoLocation>\n");
                sb.append("\t\t<csvtoFileName>");
                sb.append(filename.toString()); // filename
                sb.append(".xml");
                sb.append("</csvtoFileName>\n");
                sb.append("\t\t<csvexportDefClass>com.ptc.core.lwc.server.LWCTypeDefinition</csvexportDefClass>\n");
                sb.append("\t\t<csvexportNames>");
                sb.append(typeDefinitions.get(filename)); // type from map
                sb.append("</csvexportNames>\n");
                sb.append("\t\t<csvmode>");
                sb.append(String.valueOf(exportMode)); // resourceBundle export mode // 0 - default inside XML // 1 - additional rbInfo files
                sb.append("</csvmode>\n");
                sb.append("\t\t<csvExportAncestorTypes>");
                sb.append(String.valueOf(ancestors)); // true - default, export full hierarchy including ancestors // false - only partial hierarchy
                sb.append("</csvExportAncestorTypes>\n");
                sb.append("\t</csvExportDefinition>\n");
                sb.append("<!--\n");
                sb.append("windchill wt.load.LoadFromFile -d ");
                sb.append(wt_home); // WT_HOME
                sb.append(exportDir); // export directory
                sb.append("export/");
                sb.append(PREFIX); // prefix "DefinitionExporter_"
                sb.append(filename.toString()); // filename
                sb.append(".xml -u ");
                sb.append(username); // admin username
                sb.append(" -p ");
                sb.append(password); // admin password
                sb.append(" -CONT_PATH /");
                sb.append("\n");                
                sb.append("-->\n");
                sb.append("</NmLoader>\n");

                bw.write(sb.toString());
                bw.close();
            }
        }
    }

    /*
     * Executes windchill commands for each type
     */
    private static void executeExport() {
        
        final Set<Object> filenames = typeDefinitions.keySet();
        final Runtime runtime = Runtime.getRuntime();
        if (timeout < 5000) {
            timeout = 5000;
        }
        
        String command = null;
        String credentials = " -u " + username + " -p " + password;
        
        System.out.println("\n*********************** Warning ***********************\n");
        System.out.println("If you see error messages like " +
        		"\n'com.ptc.core.lwc.common.view.AttributeDefinitionReadView wcadmin - DATATYPE MISMATCH:'\n" +
        		" you must restart with a higher delay value!");
        System.out.println("\n*********************** Warning ***********************\n");
        
        for (final Object filename : filenames) {
            try {
                command = "windchill wt.load.LoadFromFile -d " + wt_home + exportDir + "export/"+ PREFIX + filename.toString() + ".xml";
                System.out.println(command);
                runtime.exec(command + credentials + " -CONT_PATH /");
                
                // need to wait a little otherwise the methodserver will throw exceptions
                Thread.sleep(timeout);
            } catch (final IOException e) {
                e.printStackTrace();
            } catch (final InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
    
    /*
     * get user input for the system depended parameters
     */
    private static String getResponse(final String prompt, final String defaultValue) throws IOException {
        String response = null;
        while (true) {
            // parameter to ask for and it�s default value
            System.out.print(prompt + " (" + defaultValue + "): ");
            System.out.flush();

            response = userreader.readLine();

            if (response == null) {
                return null;
            }

            response = response.trim();
            if ((response.equals("")) && (!defaultValue.equals(""))) {
                response = defaultValue;
            }
            if (!response.equals("")) {
                return response;
            }
        }
    }
}
