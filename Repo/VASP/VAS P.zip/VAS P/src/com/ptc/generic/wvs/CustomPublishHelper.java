/* bcwti
 * 
 *  Copyright (c) 2012 Parametric Technology Corporation (PTC). All Rights
 *  Reserved.
 * 
 *  This software is the confidential and proprietary information of PTC.
 *  You shall not disclose such confidential information and shall use it
 *  only in accordance with the terms of the license agreement.
 * 
 *  ecwti
 */

package com.ptc.generic.wvs;

import java.util.Collection;
import java.util.Vector;

import org.apache.log4j.Logger;

import wt.epm.EPMDocument;
import wt.method.RemoteAccess;
import wt.representation.RepresentationHelper;
import wt.util.WTException;

import com.ptc.windchill.uwgm.common.prefs.ViewablePreferenceHelper;

/**
 * 
 * @author mvonhasselbach, extensions by lberger@ptc.com
 * @since 4.2 (old name was PublishHelper)
 */
public class CustomPublishHelper implements RemoteAccess {
    
    public static final String svnRev = "$Revision: 1.1.1.3 $ $Date: 2015/12/10 21:01:36IST $";
    public static final String svnUrl = "$URL: http://127.0.0.1/svn/KB_04082016/components/Generic-Utilities/src/com/ptc/generic/wvs/CustomPublishHelper.java $";

    private static final String CLASSNAME = CustomPublishHelper.class.getName();
    private static final Logger logger = Logger.getLogger(CLASSNAME);
    
    public static final String JOB_ID = "jobId";                  // key for user-defined PublishParam JobId
    public static final String BASELINE = "baseline";             // key for user-defined PublishParam baseline
    public static final String PRINCIPAL = "principal";           // key for user-defined PublishParam principal

    /**
     * Method added by lberger 20111024.
     * This is the logic that's used OOTB when something is checked in from Pro/E.
     * Logic was copied from com.ptc.windchill.uwgm.proesrv.action.CheckinAction (PDML 9.1 M060).
     * Customization needs it to generate the viewables when custom CADDocUI checks in the theoTeil.
     * @param epmDocuments 
     */
    public static void publishViewables(Collection<EPMDocument> epmDocuments) {
        if (epmDocuments.isEmpty()) {
            logger.debug("nothing to publish");
            return;
        }

        try {
            Vector<EPMDocument> toPublish = new Vector<EPMDocument>(epmDocuments.size());
            for (EPMDocument doc : epmDocuments) {
				if (ViewablePreferenceHelper.isDocumentValidForViewableGeneration(doc) && !doc.isDerived()) {
                    toPublish.add(doc);
                    logger.debug("added EPMDoc for viewable generation: " + doc);
                } else {
                	logger.debug("EPMDoc was not valid for viewable generation: " + doc);
                }
            }

            logger.debug("<> Number of CAD Documents checked in: " + epmDocuments.size()
                    + "\t Number of cad document viewables to be generated " + toPublish.size());

            RepresentationHelper.service.emitReadyToPublishEvent(toPublish, null);
        } catch (WTException ex) {
            logger.warn("publishing problem, skip publishing");
            /**
             * @todo: create resource for this warning InfoMessage warning =
             * InfoElementFactory.createWarning() addWarning();
             */
            if (logger.isDebugEnabled()) {
                logger.error(ex.getLocalizedMessage(), ex);
            }
        }
    }
    
	
}
