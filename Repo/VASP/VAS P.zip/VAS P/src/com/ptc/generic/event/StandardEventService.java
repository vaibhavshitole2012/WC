package com.ptc.generic.event;


import java.io.Serializable;

import org.apache.log4j.Logger;

import com.ptc.generic.event.EventService;
import com.ptc.service.annotations.GenerateService;

import wt.events.KeyedEvent;
import wt.fc.Persistable;
import wt.services.ManagerException;
import wt.services.StandardManager;
import wt.util.WTException;


@GenerateService
public class StandardEventService extends StandardManager implements EventService, Serializable {


   /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
// --- Attribute Section ---
   //private static final String RESOURCE = "com.ptc.generic.event.eventResource";
   private static final String CLASSNAME = StandardEventService.class.getName();
   private static final Logger logger = Logger.getLogger(CLASSNAME);
   
   private boolean startupErrorWasLogged = false;

   /**
    * Default factory for the class.
    *
    * @return    StandardEventService
    * @exception wt.util.WTException
    **/
   public static StandardEventService newStandardEventService() throws WTException {
      StandardEventService instance = new StandardEventService();
      instance.initialize();
      return instance;
   }

   protected synchronized void performStartupProcess() throws ManagerException {
	   super.performStartupProcess();
	   System.out.println("STARTED LISTENER: " + CLASSNAME);
   }
   
   /**
    * @param     event
    * @param     eventKey
    * @exception wt.util.WTException
    **/
   public void dispatchVetoableEvent( KeyedEvent event, String eventKey ) throws WTException {
	   if(getManagerService()==null) {
		   if(!startupErrorWasLogged) {
			   logger.error("Configuration ERROR: StandardEventService is not properly integrated into your wt.properties !!! It needs to be configured as a service that starts up during MethodServer start.");
			   startupErrorWasLogged=true;
		   }
	   } else {
		   getManagerService().dispatchVetoableEvent(event, eventKey);
	   }
   }
   
   public void dispatchVetoableEvent(KeyedEvent event) throws WTException {
	   if(getManagerService()==null) {
		   if(!startupErrorWasLogged) {
			   logger.error("Configuration ERROR: StandardEventService is not properly integrated into your wt.properties !!! It needs to be configured as a service that starts up during MethodServer start.");
			   startupErrorWasLogged=true;
		   }
	   } else {
		   getManagerService().dispatchVetoableEvent(event, event.getEventKey());
	   }
   }

   public void dispatchEvent(KeyedEvent event) throws WTException {
	   if(getManagerService()==null) {
		   if(!startupErrorWasLogged) {
			   logger.error("Configuration ERROR: StandardEventService is not properly integrated into your wt.properties !!! It needs to be configured as a service that starts up during MethodServer start.");
			   startupErrorWasLogged=true;
		   }
	   } else {
		   getManagerService().dispatchEvent(event, event.getEventKey());
	   }
   }

   /**
    * @param     eventName
    * @param     persistable
    * @exception wt.util.WTException
    **/
   public void dispatchVetoablePersistenceEvent( String eventName, Persistable persistable )
            throws WTException {
	   //lberger 20110902: why was this commented out long ago???
      //HLO:PersistenceManagerEvent persistencemanagerevent = new PersistenceManagerEvent(PersistenceHelper.manager, eventName, persistable);
      //HLO:getManagerService().dispatchVetoableEvent(persistencemanagerevent, persistencemanagerevent.getEventKey());
   }
}
