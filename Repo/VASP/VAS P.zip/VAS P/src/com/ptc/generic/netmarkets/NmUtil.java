/*
 * NmUtil.java
 *
 *
 * This class contains generic methods necessary for the
 */

package com.ptc.generic.netmarkets;

import com.ptc.netmarkets.util.table.NmDefaultHTMLTable;
import com.ptc.netmarkets.util.misc.NmComboBox;
import com.infoengine.object.factory.Att;
import com.infoengine.object.factory.Element;
import com.infoengine.object.factory.Group;
import java.util.Enumeration;
import java.util.StringTokenizer;
import java.util.ArrayList;

/**
 *
 * @author Simone Graf
 */
public class NmUtil {
    
    /** Creates a new instance of NmUtil */
    public NmUtil() {
    }
    
    /**
     * Creates a NmComboBox for Boolean
     * @param comboBoxName the name of the combobox
     */
    public static NmComboBox getBooleanComboBox(String comboBoxName, Boolean selectedValue) {
        //Initialize
        NmComboBox nmComboBox    = new NmComboBox();
        ArrayList values         = new ArrayList();
        ArrayList internalValues = new ArrayList();
        ArrayList selected       = new ArrayList();
        
        //Set the values of the comboBox
        values.add(Boolean.FALSE.toString());
        values.add(Boolean.TRUE.toString());
        internalValues.add(Boolean.FALSE.toString());
        internalValues.add(Boolean.TRUE.toString());
        selected.add(selectedValue == null ? Boolean.TRUE.toString() : selectedValue.toString());
        
        //Initialize ComboBox
        nmComboBox.setEnabled(true);
        nmComboBox.setValues(values);
        nmComboBox.setInternalValues(internalValues);
        nmComboBox.setRowName(comboBoxName);
        nmComboBox.setSelected(selected);

        //return NmComboBox
        return nmComboBox;
    }
    
   /**
    * Returns a NmTable, build from the given I*E Group. I*E Atts are displayed as
    * columns. If tablename is given, it is used as title, otherwise the
    * Groupname will be used. If header is given as a comma-separeted string, the 
    * tokens are used as table-headers. Otherwise the Att-names will be used. If columns
    * is given as a comma-separated string, only the Atts with names matching the given 
    * tokens will be displayed. Otherwies all Atts are displayed
    * @param     ingroup
    * @param     tablename
    * @param     columns
    * @param     header
    **/
   public static NmDefaultHTMLTable getIEGroupAsNmTable(Group ingroup, String tablename, String columns, String header)
   {
       NmDefaultHTMLTable result = new NmDefaultHTMLTable();
       if( tablename == null )tablename = ingroup.getName();
       result.setName(tablename);
       boolean headergiven = false;
       if(header != null){
           StringTokenizer stn = new StringTokenizer(header, ",");
           while(stn.hasMoreTokens() ){
               result.addColumn( stn.nextToken() );
           }
       }else if (columns != null){
           StringTokenizer stn = new StringTokenizer(columns, ",");
           while(stn.hasMoreTokens() ){
               result.addColumn( stn.nextToken() );
           }
       }else{
           Element line = ingroup.getElementAt(0);
           if( line != null){
               Enumeration attEnum = line.getAtts();
               while(attEnum.hasMoreElements()){
                   Att att = (Att)(attEnum.nextElement());
                   result.addColumn(att.getName());
               }
           }
       }
       int size = ingroup.getElementCount();
       for( int i=0; i<size; i++){
           Element curLine = ingroup.getElementAt(i);
           Enumeration lineAtts = curLine.getAtts();
           int colCount = 0;
           while( lineAtts.hasMoreElements()){
               Att curAtt = (Att)(lineAtts.nextElement());
               result.addCellValue(i, colCount++, curAtt.getValue());
           }
       }
       
       return result;
   }    
   /**
    * Returns a NmTable, build from the given I*E Group. All attribute names are displayed in 
    * one column. Only the first <code>Element</code> of the given Group will be used.
    * @param     ingroup
    * @param     tablename
    **/
   public static NmDefaultHTMLTable getIEGroupAsNmTableV(Group ingroup, String tablename)
   {
       NmDefaultHTMLTable result = new NmDefaultHTMLTable();
       result.setCollapseable(false);
       if( tablename == null )tablename = ingroup.getName();
       result.setName(tablename);
       
       result.addColumn( "Attribut");
       result.addColumn( "Wert");
       
       Element curLine = ingroup.getElementAt(0);
       if(curLine != null){
           int lineIndex = 0;
           Enumeration lineAtts = curLine.getAtts();
           while( lineAtts.hasMoreElements()){
               Att curAtt = (Att)(lineAtts.nextElement());
               result.addCellValue(lineIndex, 0, curAtt.getName());
               result.addCellValue(lineIndex, 1, curAtt.getValue());
               lineIndex++;
           }
       }
       
       return result;
   }    
    
}
