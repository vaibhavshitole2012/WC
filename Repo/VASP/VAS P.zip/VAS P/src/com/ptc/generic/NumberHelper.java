/*
 * NumberHelper.java
 *
 * Created on 10. September 2003, 18:44
 */
package com.ptc.generic;

import java.math.BigDecimal;
import java.util.Locale;

import org.apache.log4j.Category;

import com.ptc.generic.genericResource;

import wt.util.WTContext;
import wt.util.WTException;
import wt.util.WTMessage;

/**
 *
 * @author  avs
 */
public class NumberHelper {
    private static final String CLASSNAME = NumberHelper.class.getName();
    private static final Category logCategory = Category.getInstance( CLASSNAME );
    private static final String RESOURCE = "com.ptc.generic.genericResource";
    public static final int INVALID_INT = Integer.MIN_VALUE + 1;
    
    /**
     *  Returns the given float rounded to two decimal places.
     *
     *  <BR><BR><B>Supported API:</B> false
     *
     *  @param  number   the float to be rounded
     *  @return the given number rounded to two decimal places
     **/
    private static double roundDecimals( double number, int count )
    {
        BigDecimal big = new BigDecimal( number ).setScale( count, BigDecimal.ROUND_HALF_UP );
        return big.doubleValue();
    }

    public static double roundToTwoDecimals( double number )
    {
        return( NumberHelper.roundDecimals( number, 2 ) );
    }


    public static boolean contains( int[] array, int zahl )
    {
        boolean contains = false;

        if( array != null )
        {
            for( int i = 0; i < array.length; ++i )
            {
                if( array[ i ] == zahl )
                {
                    contains = true;
                    break;
                }
            }
        }

        return( contains );
    }

    /**
     *  Versucht, ein double aus dem &uuml;bergebenen String zu machen und reicht
     *  dann weiter.
     * @param f
     * @return  
     */
    public static String getNumberStringWithTwoDecimals( String f )
    {
        double d = 0d;

        try
        {
            d = Double.valueOf( f ).doubleValue();
        }
        catch( Exception e )
        {
            logCategory.info( "while trying to build a double from " + f, e );
        }

        return( NumberHelper.getNumberStringWithTwoDecimals( d ) );
    }

    /**
     * Works life parseStringToLong with the difference, that it ignores
     * null, spaces, nbsp. In this cases a 0 is returned. It also
     * trims incoming string
     *
     * @param in value to be converted to long
     * @return long representation of string
     * @throws WTException 
     * @since Release 2.10
     * @author Lars Mense
     */
    public static long parseStringToLongIgnoreSpaces( String in ) throws WTException
    {
        if (in == null || in.length() == 0 || in.equalsIgnoreCase("&nbsp;") || in.equals(" ")) {
            return 0;
        } else {
            return (parseStringToLong(in.trim()));
        }
    }

    /**
     * converts a given String value to long. If an parse Exception
     * occures, a localized Exception is thrown. Method ignores
     * @param in value to be converted to long
     * @return long representation of string
     * @throws WTException 
     * @since Release 2.10
     * @author Lars Mense
     */
    public static long parseStringToLong( String in ) throws WTException
    {
       Locale locale = WTContext.getContext().getLocale();
       long out = 0;
       try
        {
            out = Long.parseLong(in);
        }
        catch(NumberFormatException nfe)
        {
            Object[] obj = new Object[1];
            obj[0] = in;
            throw new WTException(WTMessage.getLocalizedMessage(RESOURCE, genericResource.NO_INTEGER, obj, locale));
        }
       return out;
    }


    /**
     *  Die toString()-Methoden der ganzen Gleitkommazahlen sind nicht wirklich
     *  sch&ouml;n f&uuml;r's Auge
     * @param f
     * @return  
     */
    public static String getNumberStringWithTwoDecimals( double f )
    {
        String s = "";

        try
        {
            f *= 100;
            f = NumberHelper.roundToTwoDecimals( f );
            String temp_s = "" + ( long )f;
            int len = temp_s.length();

            StringBuilder sb = new StringBuilder();
            for( int i = 0; i < len; ++i )
            {
                if( i == ( len - 2 ) )
                {
                    sb.append( "." );
                }
                sb.append( temp_s.charAt( i ) );
            }

            s = sb.toString();
        }
        catch( Exception e )
        {
            logCategory.info( "while trying to build a String from " + f, e );
        }

        return( s );
    }


    public static void main( String[] sdfgh )
    {
        int[] array = new int[]{ 12, 45, -67, -2, -4 };

        System.out.print( "1. array = " );
        for( int i = 0; i < array.length; ++i )
        {
            System.out.print( ", " + array[ i ] );
        }
        System.out.println();
        array = NumberHelper.sort( array );
        System.out.print( "2. array = " );
        for( int i = 0; i < array.length; ++i )
        {
            System.out.print( ", " + array[ i ] );
        }
        System.out.println();
        System.out.println();

        array = new int[]{ 12, 45, -67, Integer.MAX_VALUE - 1, Integer.MIN_VALUE + 1, 45, -67 };
        System.out.print( "3. array = " );
        for( int i = 0; i < array.length; ++i )
        {
            System.out.print( ", " + array[ i ] );
        }
        System.out.println();
        array = NumberHelper.sort( array );
        System.out.print( "4. array = " );
        for( int i = 0; i < array.length; ++i )
        {
            System.out.print( ", " + array[ i ] );
        }
        System.out.println();
        System.out.println();

        array = new int[]{ 12, Integer.MIN_VALUE, Integer.MAX_VALUE, 45, -67, Integer.MAX_VALUE - 1, Integer.MIN_VALUE + 1, 45, -67 };
        System.out.print( "3. array = " );
        for( int i = 0; i < array.length; ++i )
        {
            System.out.print( ", " + array[ i ] );
        }
        System.out.println();
        array = NumberHelper.sort( array );
        System.out.print( "4. array = " );
        for( int i = 0; i < array.length; ++i )
        {
            System.out.print( ", " + array[ i ] );
        }
        System.out.println();

    }


    public static int[] sort( int[] array )
    {
        if( array == null || array.length < 2 )
        {
            return( array );
        }

        int[] returnArray = null;
        for( int i = 0; i < array.length; ++i )
        {
            int max = Integer.MAX_VALUE;
            int count = 0;
            for( int j = 0; j < array.length; ++j )
            {
                if( max > array[ j ] )
                {
                    count = j;
                    max = array[ j ];
                }
            }
            returnArray = NumberHelper.addToIntArray( returnArray, array[ count ] );
            array[ count ] = Integer.MAX_VALUE;
        }
        return( returnArray );
    }



    public static int[] addToIntArray( int[] array, int value )
    {
        int[] returnArray = null;
        if( array == null )
        {
            returnArray = new int[ 0 ];
            return( NumberHelper.addToIntArray( returnArray, value ) );
        }

        returnArray = new int[ array.length + 1 ];
        System.arraycopy( array, 0, returnArray, 0, array.length );
        returnArray[ array.length ] = value;

        return( returnArray );
    }



    public static int getInt( String string ) throws RuntimeException
    {
        int returnInt;
        try
        {
            returnInt = Integer.parseInt( string );
        }
        catch( Exception e )
        {
            logCategory.info( "Keine Zahl : " + string, e );
            returnInt = NumberHelper.INVALID_INT;
        }
        return( returnInt );
    }



    public static int[] revert( int[] array )
    {
        int[] returnArray = null;
        if( array != null )
        {
            for( int i = ( array.length - 1 ); i >= 0; --i )
            {
                returnArray = NumberHelper.addToIntArray( returnArray, array[ i ] );
            }
        }

        return( returnArray );
    }


    public static int[] getIntArray( String[] strings )
    {
        if( strings == null || strings.length < 1 )
        {
            return( new int[ 0 ] );
        }
        int[] returnArray = null;

        for( int i = 0; i < strings.length; ++i )
        {
            try
            {
                int number = NumberHelper.getInt( strings[ i ] );
                returnArray = NumberHelper.addToIntArray( returnArray, number );
            }
            catch( Exception e )
            {
                logCategory.info( "unhandled: while converting to ints: ", e );
            }
        }

        return( returnArray );
    }

    /**
     * Calculate the length (digits count) of given integer number.
     * 
     * @param number
     * @return
     */
    public static int numberLength(final int number) {
        // logarithm of 0 is -infinity
        if (number == 0) {
            return 1;
        }
        return (int) Math.log10(Math.abs(number)) + 1;
    }
    
    /**
     * Check if given number can be represented as decimal or not.
     * 
     * @param number
     * @return 
     */
    public static boolean isDecimal(final double number) {
        int numberInt = (int) number;
        return Double.compare(number, numberInt) == 0;
    }
}
