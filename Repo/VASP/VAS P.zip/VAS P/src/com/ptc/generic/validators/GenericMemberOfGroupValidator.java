package com.ptc.generic.validators;

import java.text.MessageFormat;
import java.util.Enumeration;

import com.ptc.generic.validators.validatorsResource;

import wt.inf.container.WTContainerHelper;
import wt.org.DirectoryContextProvider;
import wt.org.OrganizationServicesHelper;
import wt.org.WTGroup;
import wt.org.WTPrincipal;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.util.WTMessage;



/**
 * @author cherrmann
 *
 */
public class GenericMemberOfGroupValidator implements GenericValidator<WTPrincipal> {

	private ValidationResult validationResult;
	private String errorMessage;
	private static final String defaultErrorMessage = WTMessage.getLocalizedMessage(VALIDATION_RESOURCE, validatorsResource.INVALID_NOT_MEMBER_OF_GROUP, null);

	private String[] groupNames;
	private DirectoryContextProvider containerContextProvider;

	/**
	 * @param groupNames
	 */
	public GenericMemberOfGroupValidator(String... groupNames) {
		this(null, null, groupNames);
	}
	
	/**
	 * @param containerContextProvider
	 * @param groupNames
	 */
	public GenericMemberOfGroupValidator(DirectoryContextProvider containerContextProvider, String... groupNames) {
		this(null, containerContextProvider, groupNames);
	}

	/**
	 * @param errorMessage
	 * @param containerContextProvider
	 * @param groupNames
	 */
	public GenericMemberOfGroupValidator(String errorMessage, DirectoryContextProvider containerContextProvider, String... groupNames){
		this.containerContextProvider = containerContextProvider;
		this.groupNames = groupNames;
		this.errorMessage = errorMessage;
	}

	/**
	 * Checks if the specified user is part of at least one of the specified groups in the passed context 
	 *
	 * @param user
	 * @return true if the specified user is a member of at least one of the specified org groups in the given container context
	 * @see com.ptc.generic.validators.GenericValidator#validate(java.lang.Object)
	 */
	public boolean validate(WTPrincipal user) {
		resetValidationResult();
		
		boolean atLeastMemberOfOneGroup = false;
		try {

			if (containerContextProvider == null) {
				containerContextProvider = WTContainerHelper.service.getExchangeContainer().getContextProvider();
			}
			
			if (user == null){
				user = SessionHelper.getPrincipal();
			}
			
			if (this.groupNames != null && user != null){
				
				for (int i = 0; i < groupNames.length; i++){
					Enumeration<?> groups = OrganizationServicesHelper.manager.getGroups(groupNames[i], containerContextProvider);
					while (groups != null && groups.hasMoreElements()) {
						Object tmpGrp = groups.nextElement();
						if (tmpGrp != null && tmpGrp instanceof WTGroup) {
							WTGroup exceptionGroup = (WTGroup) tmpGrp;
							if (OrganizationServicesHelper.manager.isMember(exceptionGroup, user)) {
								atLeastMemberOfOneGroup = true;
							}
						}
					}
				}
				if (!atLeastMemberOfOneGroup){
					if (errorMessage == null){
						String errorGroups = "";
						if (errorGroups.length() > 0){
							errorGroups = groupNames[0];
						} else {
							errorGroups = "<null>";
						}
						for (int i = 1; i < groupNames.length; i++){
							errorGroups += ", " + groupNames[i];
						}

						this.validationResult = new ValidationResult(MessageFormat.format(defaultErrorMessage, user.getPrincipalDisplayIdentifier(), errorGroups, containerContextProvider), false);
					} else {
						this.validationResult = new ValidationResult(errorMessage, false);
					}
				}
			}
		} catch (WTException e) {
			this.validationResult = new ValidationResult(MessageFormat.format(EXCEPTION_THROWN, e.getLocalizedMessage()), false, null, e);
			e.printStackTrace();
		}
		

		if (this.validationResult == null){
			this.validationResult = new ValidationResult(SUCCESS_MESSAGE, true);
		}

		return this.validationResult.getIsValid();
	}

	public ValidationResult getValidationResult() {
		return this.validationResult;
	}

	public void resetValidationResult(){
		this.validationResult = null;
	}

}
