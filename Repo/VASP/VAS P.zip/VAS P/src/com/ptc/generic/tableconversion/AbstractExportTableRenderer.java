/** 

Abstract super class for table render implementations.
The implementations must be tolerant for empty cell rows at the end of the cell matrix.
This may happen if rows are filtered after creation of the matrix object.
This super class contains a method to find the real row count of the matrix.

@author Lothar Germund, PLUS-Systeme GmbH
@since 19.10.2010
*/

package com.ptc.generic.tableconversion;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;


/**
 * Abstract super class for table render implementations.
 * @author DVORGER
 */
public abstract class AbstractExportTableRenderer implements com.ptc.generic.tableconversion.TableRenderer {

    public final static int BASICAPI_BYTEARRAY = 0;
    public final static int BASICAPI_STREAMREF = 1;

    protected int basicApi;


    /**
     * Private constructor, so no construction without parameter allowed.
     */
    @SuppressWarnings("unused")
    private AbstractExportTableRenderer() {
    }

    
    /**
     * Normal constructor, called from derived classes. For a HSSF API based subclass the parameter must be BASICAPI_STREAMREF.
     * 
     * @param basicApi
     *            One of the symbolic constants, show which abstract method is the real API.
     */
    public AbstractExportTableRenderer(int basicApi) {
        this.basicApi = basicApi;
    }

    
    /**
     * Renders the cell matrix (table) to a given output stream (byte stream). One method is basic and the others derived from it.
     * Depending from the construction parameter implement this method or call only basicRenderToStreamSourceArray(...).
     * 
     * @param outStream
     * @param tableCells
     * @throws com.ptc.generic.tableconversion.RenderException
     */
    public abstract void renderToStream(OutputStream outStream, com.ptc.generic.tableconversion.Cell[][] tableCells) throws com.ptc.generic.tableconversion.RenderException;

    
    /**
     * Renders the cell matrix (table) and returns a byte array. One method is basic and the others derived from it.
     * Depending from the construction parameter implement this method or call only basicRenderToArraySourceStream(...).
     * 
     * @param tableCells
     * @return
     * @throws com.ptc.generic.tableconversion.RenderException
     */
    public abstract byte[] renderToArray(com.ptc.generic.tableconversion.Cell[][] tableCells) throws com.ptc.generic.tableconversion.RenderException;

    
    /**
     * Renders the cell matrix (table) and returns a byte array output stream. For best performance it calls the right interface translation method (basic method).
     * 
     * @param tableCells
     * @return
     * @throws com.ptc.generic.tableconversion.RenderException
     */
    public ByteArrayOutputStream renderToArrayStream(com.ptc.generic.tableconversion.Cell[][] tableCells) throws com.ptc.generic.tableconversion.RenderException {
        ByteArrayOutputStream bos;
        if (basicApi == BASICAPI_BYTEARRAY) {
            bos = basicRenderToArrayStreamSourceArray(tableCells);
        } else {
            bos = basicRenderToArrayStreamSourceStream(tableCells);
        }
        return bos;
    }

    
    /**
     * Interface translation method. The source interface/API is renderToArray.
     * 
     * @param outStream
     * @param tableCells
     * @throws com.ptc.generic.tableconversion.RenderException
     */
    protected void basicRenderToStreamSourceArray(OutputStream outStream, com.ptc.generic.tableconversion.Cell[][] tableCells) throws com.ptc.generic.tableconversion.RenderException {
        byte[] byteArray = renderToArray(tableCells);
        try {
            outStream.write(byteArray);
        } catch (IOException e) {
            throw new com.ptc.generic.tableconversion.RenderException("IO problem on stream write", e);
        }
    }

    
    /**
     * Interface translation method. The source interface/API is renderToArray.
     * 
     * @param tableCells
     * @return
     * @throws com.ptc.generic.tableconversion.RenderException
     */
    protected ByteArrayOutputStream basicRenderToArrayStreamSourceArray(com.ptc.generic.tableconversion.Cell[][] tableCells) throws com.ptc.generic.tableconversion.RenderException {
        byte[] byteArray = renderToArray(tableCells);
        ByteArrayOutputStream bos = new ByteArrayOutputStream(byteArray.length);
        try {
            bos.write(byteArray);
        } catch (IOException e) {
            throw new com.ptc.generic.tableconversion.RenderException("IO problem on stream write", e);
        }
        return bos;
    }

    
    /**
     * Interface translation method. The source interface/API is renderToStream.
     * 
     * @param tableCells
     * @return
     * @throws com.ptc.generic.tableconversion.RenderException
     */
    protected byte[] basicRenderToArraySourceStream(com.ptc.generic.tableconversion.Cell[][] tableCells) throws RenderException {
        ByteArrayOutputStream bos = basicRenderToArrayStreamSourceStream(tableCells);
        return bos.toByteArray();
    }

    
    /**
     * Interface translation method. The source interface/API is renderToStream.
     * 
     * @param tableCells
     * @return
     * @throws com.ptc.generic.tableconversion.RenderException
     */
    protected ByteArrayOutputStream basicRenderToArrayStreamSourceStream(com.ptc.generic.tableconversion.Cell[][] tableCells) throws com.ptc.generic.tableconversion.RenderException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        renderToStream(bos, tableCells);
        return bos;
    }
    

    /**
     * Find the real row count (trim row count from the end).
     * This means it looks from the end to the beginning of the rows to find a cell object in the 1st column.
     * The logic after this must use the result as the new row count, so it works like a "trim" function.
     *  
     * @param tableCells
     * @return
     */
    protected int trimRowcount( com.ptc.generic.tableconversion.Cell[][] tableCells) {
        int rowCount = tableCells.length;
        int rows = rowCount;

        for (int r = rowCount; r >= 1; r--) {
            Cell[] tableRow = tableCells[r-1];
            if ((tableRow != null) && (tableRow.length > 0) && (tableRow[0] != null)) {
                // this table row contains a cell in the 1st column
                rows = r;
                break;
            }
        }
        return rows;
    }

    /**
     * Filters an Cell value for unallowed signs.
     *
     * @param value
     *            cell value
     * @param method
     *            header column name or query name
     */
    public abstract Object filterCell(Object value, String method, boolean isDataCell);

    
    /**
     * Returns the Value of the HeaderCell for a row.
     *
     * @param columnId Id of the Column that should be displayed
     * @param contextId Id of the context. Use this if you want to display the same row different in various contexts
     * @return The Value that stands for the Column.
     */
    public abstract String getHeaderName(Object columnId, String contextId);

}
