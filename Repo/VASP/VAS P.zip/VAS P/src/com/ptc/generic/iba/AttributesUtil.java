package com.ptc.generic.iba;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import com.ptc.core.lwc.common.view.AttributeDefaultValueReadView;
import com.ptc.core.lwc.common.view.AttributeDefinitionReadView;
import com.ptc.core.lwc.common.view.ConstraintDefinitionReadView;
import com.ptc.core.lwc.common.view.DatatypeReadView;
import com.ptc.core.lwc.common.view.TypeDefinitionReadView;
import com.ptc.core.meta.common.AnalogSet;
import com.ptc.core.meta.container.common.impl.SingleValuedConstraint;
import com.ptc.core.meta.container.common.impl.StringLengthConstraint;

/**
 * 
 * @author Bartosz Lipinski
 *
 */
public class AttributesUtil {
	public static final String MULTI_VALUE = "/MultiValue";
	
	/**
	 * Returns attribute name. If it is multi-valued "/MultiValue" suffix is added, otherwise standard attribute name is returned (for wbm mapping purposes). 
	 * 
	 * @param attributeDefinition attribute which name has to be found
	 * @return attribute name proper for wbm
	 */
	public static String getIbaNameMultiValued(AttributeDefinitionReadView attributeDefinition){
		DatatypeReadView datatypeReadView = attributeDefinition.getDatatype();
		String attributeName = attributeDefinition.getName();
		if(datatypeReadView.isCanBeMultiValued())
			if(AttributesUtil.isMultiValued(attributeDefinition))
				return attributeName + MULTI_VALUE;
		return attributeName;
	}
	
	/**
	 * Used to parse attributes (comma separated) collection into string
	 * 
	 * @param attributes attributes that has to be parsed into string
	 * @return single string with comma separated attributes
	 */
	public static String getIBAAttributesAsString(List<AttributeDefinitionReadView> attributes){
		StringBuilder sb = new StringBuilder();
		for (AttributeDefinitionReadView attributeDefinition : attributes)
			sb.append(attributeDefinition.getName()).append(",");
		
		return sb.length()!=0?sb.substring(0, sb.length() - 1):null;
	}
	
	/**
	 * Returns all IBA definitions for a particular type definition given as a parameter.
	 * 
	 * @param typeDefinition Type definition which IBAs have to be found
	 * @return list of attribute definitions
	 */
	public static List<AttributeDefinitionReadView> getIBAAttributesForType(TypeDefinitionReadView typeDefinition){
		List<AttributeDefinitionReadView> attributes = new ArrayList<AttributeDefinitionReadView>();
		Collection<AttributeDefinitionReadView> attributeDefinitions = typeDefinition.getAllAttributes();
		Iterator<AttributeDefinitionReadView> iterator = attributeDefinitions.iterator();
		while(iterator.hasNext()){
			AttributeDefinitionReadView attribute = (AttributeDefinitionReadView) iterator.next();
			if(attribute.getIBARefView() != null)
				attributes.add(attribute);
		}
		return attributes;////////////////////////////////////////////
	}
	
	/**
	 * Checks whether attribute is multi-valued (contains single-valued constraint)
	 * 
	 * @param attributeDefinition attribute to be tested
	 * @return true if multi-valued, false otherwise
	 */
	public static boolean isMultiValued(AttributeDefinitionReadView attributeDefinition){
		Collection<ConstraintDefinitionReadView> constraintDefinition = attributeDefinition.getAllConstraints();
		Iterator<ConstraintDefinitionReadView> iterator = constraintDefinition.iterator();
		while(iterator.hasNext()){
			ConstraintDefinitionReadView x = iterator.next();
			if(SingleValuedConstraint.class.getName().equals(x.getRule().getRuleClassname()))
				return false;
		}
		return true;
	}
	
	/**
	 * Finds and returns the most narrowed maximum string length constraint for a STRING attribute
	 * 
	 * @param attributeDefinition STRING attribute definition 
	 * @return maximum string length (the default value is multiplied by 3)
	 */
	public static long getLengthConstraintForStringAttribute(AttributeDefinitionReadView attributeDefinition){
		Collection<ConstraintDefinitionReadView> constraintDefinition = attributeDefinition.getAllConstraints();
		Iterator<ConstraintDefinitionReadView> iterator = constraintDefinition.iterator();
		
		long min = Long.MAX_VALUE;
		while(iterator.hasNext()){
			ConstraintDefinitionReadView x = iterator.next();
			if(StringLengthConstraint.class.getName().equals(x.getRule().getRuleClassname())){
				AnalogSet ruleData = (AnalogSet) x.getRuleData();
				//upperBound multiplied by 3 for special characters in a String
				long upperBound = (Long)ruleData.getBoundingRange().getUpperBoundValue()*3; 
				if(upperBound < min)
					min = upperBound;
			}
		}
		return min;
	}
	
	public static long getConstraints(AttributeDefinitionReadView attributeDefinition){
		Collection<ConstraintDefinitionReadView> constraintDefinition = attributeDefinition.getAllConstraints();
		Iterator<ConstraintDefinitionReadView> iterator = constraintDefinition.iterator();
		
		long min = Long.MAX_VALUE;
		while(iterator.hasNext()){
			ConstraintDefinitionReadView x = iterator.next();
			System.out.println(x.getRule().getRuleClassname());
			
		}
		return min;
	}
	
	@SuppressWarnings("unchecked")
	public static <T> Collection<T> getDefaultAttributeValues(AttributeDefinitionReadView attributeDefinition) {
		Collection<T> defaultValues = new ArrayList<T>();
		for (AttributeDefaultValueReadView defaultValue : attributeDefinition.getAllDefaultValues()) {
			if (defaultValue != null && defaultValue.getValue() != null) {
				defaultValues.add((T) defaultValue.getValue());
			}
		}
		return defaultValues;
	}
	
	public static Collection<String> getDefaultAttributeValuesAsStrings(AttributeDefinitionReadView attributeDefinition) {
		Collection<String> defaultValues = new ArrayList<>();
		for (AttributeDefaultValueReadView defaultValue : attributeDefinition.getAllDefaultValues()) {
			if (defaultValue != null && defaultValue.getValue() != null) {
				defaultValues.add(defaultValue.getValue().toString());
			}
		}
		return defaultValues;
	}
	
}
