package com.ptc.generic.workinprogress;

import com.ptc.service.annotations.GenerateService;
import com.ptc.generic.workinprogress.WIPService;
import com.ptc.generic.workinprogress.workinprogressResource;

import java.util.HashMap;
import java.util.Vector;

import org.apache.log4j.Logger;

import wt.fc.*;
import wt.folder.Folder;
import wt.part.WTPart;
import wt.query.ArrayExpression;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.query.TableColumn;
import wt.services.StandardManager;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.WTPropertyVetoException;
import wt.util.WTRuntimeException;
import wt.vc.Iterated;
import wt.vc.VersionControlHelper;
import wt.vc.wip.CheckoutLink;
import wt.vc.wip.WorkInProgressException;
import wt.vc.wip.WorkInProgressHelper;
import wt.vc.wip.Workable;

@GenerateService(generateHelper = false)
public class StandardWIPService extends StandardManager implements WIPService {

    // --- Attribute Section ---
    private static final String RESOURCE = "com.ptc.generic.workinprogress.workinprogressResource";
    private static final String CLASSNAME = StandardWIPService.class.getName();
    private static Logger logger = Logger.getLogger(CLASSNAME);

    /**
     * Default factory for the class.
     *
     * @return    StandardWIPService
     * @exception wt.util.WTException
     **/
    public static StandardWIPService newStandardWIPService()
            throws WTException {
        StandardWIPService instance = new StandardWIPService();
        instance.initialize();
        return instance;
    }

    /**
     * @param     oids
     * @return    HashMap
     * @exception wt.util.WTException
     **/
    public HashMap getWorkingCopies(Vector oids)
            throws WTException {
        if (oids == null) {
            throw new WTException(WTMessage.getLocalizedMessage(RESOURCE, workinprogressResource.NO_ORIGCOPIES_GIVEN, null));
        }

        //always instanciate a HashMap that is returned. This method must not return null at any time.
        HashMap hm = new HashMap();

        //return if we did not get any oids
        if (oids.size() == 0) {
            return hm;
        }

        //Long[] arrayOids =
        QuerySpec qs = new QuerySpec();
        qs.setAdvancedQueryEnabled(true);

        //lberger 20050208: how can we retrieve the oids of the original copy (only in the table checkoutlink
        //  without instanciating the CheckOutLink objects??
        //int indexLink = qs.appendFrom(new ExternalTableExpression("checkoutlink"));
        int indexLink = qs.appendClassList(CheckoutLink.class, true);
        int indexWCs = qs.appendClassList(Workable.class, true);

        //join tables
        SearchCondition scJoin = new SearchCondition(new TableColumn("A0", "ida3b5"), SearchCondition.EQUAL, new TableColumn("A1", "ida2a2"));
        qs.appendWhere(scJoin);

        //filter on given original copies
        SearchCondition sc = new SearchCondition(new TableColumn("A0", "ida3a5"), SearchCondition.IN, new ArrayExpression(oids.toArray()));
        qs.appendAnd();
        qs.appendWhere(sc);

        if (logger.isDebugEnabled()) {
            logger.debug("qs=" + qs);
        }

        QueryResult qr = PersistenceHelper.manager.find(qs);
        WTReference wtrefOC = null;
        Workable workable = null;
        Persistable[] p = null;
        while (qr.hasMoreElements()) {
            p = (Persistable[]) qr.nextElement();
            if (logger.isDebugEnabled()) {
                logger.debug("found: " + p[0] + " " + p[1]);
            }
            wtrefOC = ((CheckoutLink) p[indexLink]).getRoleAObjectRef();
            workable = (Workable) p[indexWCs];
            hm.put(wtrefOC.getKey(), workable);
        }

        return hm;
    }

    /**
     * @param     oids
     * @param     cClassType
     * @param     mode
     * @return    HashMap
     * @exception wt.util.WTException
     **/
    public HashMap getOrigCopies(Vector oids, Class cClassType, int mode)
            throws WTException {
        if (oids == null) {
            throw new WTException(WTMessage.getLocalizedMessage(RESOURCE, workinprogressResource.NO_ORIGCOPIES_GIVEN, null));
        }
        if (mode != WIPHelper.MODE_RETURN_BRANCHIDS && mode != WIPHelper.MODE_RETURN_OBJECTS && mode != WIPHelper.MODE_RETURN_OIDS) {
            throw new WTException("unsupported given mode");
        }

        //always instanciate a HashMap that is returned. This method must not return null at any time.
        HashMap hm = new HashMap();

        //return if we did not get any oids
        if (oids.size() == 0) {
            return hm;
        }

        QuerySpec qs = new QuerySpec();
        qs.setAdvancedQueryEnabled(true);

        //lberger 20050208: how can we retrieve the oids of the original copy (only in the table checkoutlink
        //  without instanciating the CheckOutLink objects??
        //int indexLink = qs.appendFrom(new ExternalTableExpression("checkoutlink"));
        int indexLink = qs.appendClassList(CheckoutLink.class, true);
        int indexWCs = -1;
        if (cClassType == null) {
            indexWCs = qs.appendClassList(Workable.class, true);
        } else {
            indexWCs = qs.appendClassList(cClassType, true);
        }

        //join tables
        SearchCondition scJoin = new SearchCondition(new TableColumn("A0", "ida3a5"), SearchCondition.EQUAL, new TableColumn("A1", "ida2a2"));
        qs.appendWhere(scJoin);

        //filter on given working copies
        SearchCondition sc = new SearchCondition(new TableColumn("A0", "ida3b5"), SearchCondition.IN, new ArrayExpression(oids.toArray()));
        qs.appendAnd();
        qs.appendWhere(sc);

        QueryResult qr = PersistenceHelper.manager.find(qs);
        Iterated origCopy = null;
        Persistable[] p = null;
        while (qr.hasMoreElements()) {
            p = (Persistable[]) qr.nextElement();
            String roleBOid = ((CheckoutLink) p[indexLink]).getRoleBObjectId().toString();
            origCopy = (Iterated) p[indexWCs];
            if (mode == WIPHelper.MODE_RETURN_BRANCHIDS) {
                hm.put(roleBOid, String.valueOf(VersionControlHelper.getBranchIdentifier(origCopy)));
            } else if (mode == WIPHelper.MODE_RETURN_OBJECTS) {
                hm.put(roleBOid, origCopy);
            } else if (mode == WIPHelper.MODE_RETURN_OIDS) {
                hm.put(roleBOid, String.valueOf(origCopy.getPersistInfo().getObjectIdentifier().getId()));
            }
        }

        return hm;
    }

    /**
     * Returns the OID of the original copy if the passed OID represents a working copy.
     * @param oid
     * @return
     */
    public String getOrigCopyOid(String oid) {
        String baseOID = oid;
        if (oid != null && oid.length() > 0) {
            ReferenceFactory rf = new ReferenceFactory();
            Persistable item = null;
            try {
                item = rf.getReference(oid).getObject();
            } catch (WTRuntimeException e1) {
                logger.error(e1.getLocalizedMessage(), e1);
            } catch (WTException e1) {
                logger.error(e1.getLocalizedMessage(), e1);
            }

            if (item != null && item instanceof Workable) {
                Workable workable = (Workable) item;

                if (WorkInProgressHelper.isWorkingCopy(workable)) {
                    try {
                        workable = (Workable) WorkInProgressHelper.service.originalCopyOf(workable);
                        baseOID = PersistenceHelper.getObjectIdentifier(workable).toString();
                    } catch (WorkInProgressException e) {
                        logger.error(e.getLocalizedMessage(), e);
                    } catch (WTException e) {
                        logger.error(e.getLocalizedMessage(), e);
                    }
                }
            }
        }

        return baseOID;
    }
    
    /**
     * Tries to return a working copy.<br>
     * If the object is already a working copy, return it<br>
     * If the object is an original copy and checked out by me, return the
     * working copy. If the object is checked out by somebody else throw
     * a WTException<br>
     * If bCheckOutIfNecessary=true, then try to check it out and return
     * working copy. If bCheckOutIfNecessary=false (and above checks did
     * not return or threw WTE) then return null.
     *
     * @param     w
     * @param     bCheckOutIfNecessary
     * @param     note
     * @return    Persistable
     * @exception wt.util.WTException
     **/
    public Persistable getWorkingCopy(Workable w, boolean bCheckOutIfNecessary, String note)
            throws WTException {
        //if the object is already a working copy, return it
        if (WorkInProgressHelper.isWorkingCopy(w)) {
            return w;
        }


        //if the object is an original copy and checked out by me, return the working copy
        if (!WorkInProgressHelper.isWorkingCopy(w)) {
            if (WorkInProgressHelper.isCheckedOut(w, SessionHelper.getPrincipal())) {
                return WorkInProgressHelper.service.workingCopyOf(w);
            } else if (WorkInProgressHelper.isCheckedOut(w)) {
                //the object is checked out by somebody else
                throw new WTException(WTMessage.getLocalizedMessage(RESOURCE, workinprogressResource.OBJECT_IS_CHECKEDOUT_NOCHECKOUT, null));
            }
        }

        //when we got here, the object is not a working copy and is not checked out at all
        //if bCheckOutIfNecessary=true, then try to check it out
        //if not, then return null;
        if (bCheckOutIfNecessary) {
            return this.checkOut(w, note);
        } else {
            return null;
        }
    }

    /**
     * @param     w
     * @param     note
     * @return    Persistable
     * @exception wt.util.WTException
     **/
    public Persistable checkOut(Workable w, String note)
            throws WTException {
        if (WorkInProgressHelper.isWorkingCopy(w)) {
            throw new WTException(WTMessage.getLocalizedMessage(RESOURCE, workinprogressResource.OBJECT_IS_WORKINGCOPY_NOCHECKOUT, null));
        } else if (WorkInProgressHelper.isCheckedOut(w)) {
            throw new WTException(WTMessage.getLocalizedMessage(RESOURCE, workinprogressResource.OBJECT_IS_CHECKEDOUT_NOCHECKOUT, null));
        }
        //checkout the object
        Folder checkoutFolder = WorkInProgressHelper.service.getCheckoutFolder();
        CheckoutLink link = null;

        try {
            link = WorkInProgressHelper.service.checkout(w, checkoutFolder, note);
        } catch (WTPropertyVetoException wpe) {
            throw new WTException(wpe);
        }

        if (link != null) {
            return (Persistable) link.getWorkingCopy();
        } else {
            throw new WTException(WTMessage.getLocalizedMessage(RESOURCE, workinprogressResource.CHECKOUT_FAILED, null));
        }
    }

    /**
     * @param     w
     * @param     note
     * @return    Persistable
     * @exception wt.util.WTException
     **/
    public Persistable checkIn(Workable w, String note)
            throws WTException {
        if (!WorkInProgressHelper.isWorkingCopy(w)) {
            throw new WTException(WTMessage.getLocalizedMessage(RESOURCE, workinprogressResource.OBJECT_IS_NO_WORKINGCOPY_NOCHECKIN, null));
        }

        //checkin the object
        try {
            return (Persistable) WorkInProgressHelper.service.checkin(w, note);
        } catch (WTPropertyVetoException wpe) {
            throw new WTException(wpe);
        }
    }

    /**
     * @param     w
     * @return    Persistable
     * @exception wt.util.WTException
     **/
    public Persistable undoCheckOut(Workable w)
            throws WTException {
        if (!WorkInProgressHelper.isWorkingCopy(w)) {
            throw new WTException(WTMessage.getLocalizedMessage(RESOURCE, workinprogressResource.OBJECT_IS_NO_WORKINGCOPY_NO_UNDOCHECKOUT, null));
        }

        //undocheckout the object
        try {
            return (Persistable) WorkInProgressHelper.service.undoCheckout(w);
        } catch (WTPropertyVetoException wpe) {
            throw new WTException(wpe);
        }
    }

    /**
     * @param     w
     * @return    Iterated
     * @exception wt.util.WTException
     **/
    public Iterated getMyLatestIteration(Iterated w)
            throws WTException {
        if (w == null) {
            return null;
        }
        Iterated retval = w;
        try {
            wt.org.WTUser currentUser = (wt.org.WTUser) wt.session.SessionHelper.getPrincipal();

            if (logger.isDebugEnabled()) {
                if (w instanceof WTPart) {
                    WTPart p = (WTPart) w;
                    logger.debug(".......getmylatest, start, p=" + p.getNumber() + "/" + p.getName() + ", wipstatus=" + p.getCheckoutInfo().getState().toString() + ", " + p.getVersionIdentifier().getValue() + "." + p.getIterationIdentifier().getValue());
                }
            }


            // retrieve temporarily the latest iteration:
            w = VersionControlHelper.getLatestIteration(w);


            if (logger.isDebugEnabled()) {
                if (w instanceof WTPart) {
                    WTPart p = (WTPart) w;
                    logger.debug(".......getmylatest, nach get latest, p=" + p.getNumber() + "/" + p.getName() + ", wipstatus=" + p.getCheckoutInfo().getState().toString() + ", " + p.getVersionIdentifier().getValue() + "." + p.getIterationIdentifier().getValue());
                }
            }

            if (w instanceof Workable) {
                Workable wk = (Workable) w;
                if (!WorkInProgressHelper.isCheckedOut(wk)) {
                    if (logger.isDebugEnabled()) {
                        if (w instanceof WTPart) {
                            WTPart p = (WTPart) w;
                            logger.debug(".......getmylatest, not checked out, p=" + p.getNumber() + "/" + p.getName() + ", wipstatus=" + p.getCheckoutInfo().getState().toString() + ", " + p.getVersionIdentifier().getValue() + "." + p.getIterationIdentifier().getValue());
                        }
                    }
                    retval = wk;
                } else if (WorkInProgressHelper.isCheckedOut(wk, currentUser)) {

                    if (logger.isDebugEnabled()) {
                        if (w instanceof WTPart) {
                            WTPart p = (WTPart) w;
                            logger.debug(".......getmylatest, checked out by me, p=" + p.getNumber() + "/" + p.getName() + ", wipstatus=" + p.getCheckoutInfo().getState().toString() + ", " + p.getVersionIdentifier().getValue() + "." + p.getIterationIdentifier().getValue());
                        }
                    }

                    // set retval
                    retval = wk;


                    // try to find working copy if wk is the original:
                    if (!WorkInProgressHelper.isWorkingCopy(wk)) {
                        retval = (WTPart) WorkInProgressHelper.service.workingCopyOf((Workable) wk);

                        if (logger.isDebugEnabled()) {
                            if (retval instanceof WTPart) {
                                WTPart p = (WTPart) retval;
                                logger.debug(".......getmylatest, checked out by but not wc, get the wc, p=" + p.getNumber() + "/" + p.getName() + ", wipstatus=" + p.getCheckoutInfo().getState().toString() + ", " + p.getVersionIdentifier().getValue() + "." + p.getIterationIdentifier().getValue());
                            }
                        }
                    }
                } else {
                    if (logger.isDebugEnabled()) {
                        if (w instanceof WTPart) {
                            WTPart p = (WTPart) w;
                            logger.debug(".......getmylatest, checked out by somebody else, p=" + p.getNumber() + "/" + p.getName() + ", wipstatus=" + p.getCheckoutInfo().getState().toString() + ", " + p.getVersionIdentifier().getValue() + "." + p.getIterationIdentifier().getValue());
                        }
                    }

                    if (WorkInProgressHelper.isWorkingCopy(wk)) {
                        retval = (WTPart) WorkInProgressHelper.service.originalCopyOf((Workable) wk);

                        if (logger.isDebugEnabled()) {
                            WTPart p = (WTPart) retval;
                            logger.debug(".......getmylatest, checked out by somebody else but not original, get the org, p=" + p.getNumber() + "/" + p.getName() + ", wipstatus=" + p.getCheckoutInfo().getState().toString() + ", " + p.getVersionIdentifier().getValue() + "." + p.getIterationIdentifier().getValue());
                        }
                    }

                }
            }


        } catch (Exception e) {
            e.printStackTrace();
        }


        return retval;
    }
}
