package com.ptc.generic;


import java.lang.reflect.Method;

import org.apache.log4j.Logger;

//import wt.util.WTException;



public class InstalledModuleUtils {

	private static final Logger logger = Logger.getLogger(InstalledModuleUtils.class.getName());
	
	private static boolean kvsInstalled = true; //default
	
	static {
		//checks for KVS: all of them must pass, otherwise we assume that KVS-interface is not properly installed or configured
		try {
			//check if KVSHelper is in classpath
			Class.forName("com.ptc.interfaces.kvs.service.KVSHelper");
			
			//check if kvs.properties exists
			//the code below is similar to the following line, but no import statement (package dependency) is needed 
			//KVSProperties p = KVSProperties.getKVSProperties();
			Class c = Class.forName("com.ptc.interfaces.kvs.KVSProperties");
			Method m1 = c.getDeclaredMethod("getKVSProperties", new Class[0]);
			Object o = m1.invoke(c, (Object[])null);
			
			//kvsInstalled = KVSProperties.isInterfaceConfigured();
		} catch(ClassNotFoundException e) {
			logger.error("KVS-interface is not properly installed or configured (class not found)");
			if(logger.isDebugEnabled()) {
				e.printStackTrace();
			}
			kvsInstalled = false;
		} catch(Throwable t) {
			logger.error("KVS-interface is not properly installed or configured");
			if(logger.isDebugEnabled()) {
				t.printStackTrace();
			}
			kvsInstalled = false;
		}
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("kvsInstalled=" + InstalledModuleUtils.isKVSInstalled());
	}

	public static boolean isKVSInstalled() {
		return kvsInstalled;
	}
}
