package com.ptc.generic.validators;

import java.text.MessageFormat;

import com.ptc.generic.validators.validatorsResource;

import wt.util.WTException;
import wt.util.WTMessage;
import wt.vc.wip.WorkInProgressHelper;
import wt.vc.wip.Workable;

/**
 * GenericCheckedOutValidator
 *
 * Validation passes if:<br>
 * - checkedOutToPassValidation == true:  the object is checked out<br>
 * - checkedOutToPassValidation == false: the object is not checked out<br>
 * Default is: false
 *
 * @author cherrmann
 *
 */
public class GenericCheckedOutValidator<T extends Workable> implements GenericValidator<T> {

	private ValidationResult validationResult;
	private String errorMessage;
	private boolean checkedOutToPassValidation = false;

	/**
	 * GenericCheckedOutValidator
	 */
	public GenericCheckedOutValidator() {
		this(WTMessage.getLocalizedMessage(VALIDATION_RESOURCE, validatorsResource.INVALID_IS_CHECKED_OUT, null));
	}

	/**
	 * GenericCheckedOutValidator
	 *
	 * @param errorMessage the default error message
	 */
	public GenericCheckedOutValidator(String errorMessage){
		this(errorMessage, false);
	}

	/**
	 * GenericCheckedOutValidator
	 *
	 * Validation passes if:<br>
	 * - checkedOutToPassValidation == true:  the object is checked out<br>
	 * - checkedOutToPassValidation == false: the object is not checked out
	 *
	 * @param errorMessage the default error message
	 * @param checkedOutToPassValidation inverts the check
	 */
	public GenericCheckedOutValidator(String errorMessage, boolean checkedOutToPassValidation){
		this.errorMessage = errorMessage;
		this.checkedOutToPassValidation = checkedOutToPassValidation;
	}


	/**
	 * GenericCheckedOutValidator
	 *
	 * Validation passes if:<br>
	 * - checkedOutToPassValidation == true:  the object is checked out<br>
	 * - checkedOutToPassValidation == false: the object is not checked out
	 *
	 * @param checkedOutToPassValidation inverts the check
	 */
	public GenericCheckedOutValidator(boolean checkedOutToPassValidation){
		this(WTMessage.getLocalizedMessage(VALIDATION_RESOURCE, validatorsResource.INVALID_IS_CHECKED_OUT, null), checkedOutToPassValidation);
	}



	/**
	 * Checks if the given object is checked out.
	 * Validation passes if:<br>
	 * - checkedOutToPassValidation == true:  the object is checked out<br>
	 * - checkedOutToPassValidation == false: the object is not checked out
	 *
	 * @param object an object which implements Workable
	 * @return false if the passed object is checked out
	 * @see com.ptc.generic.validators.GenericValidator#validate(java.lang.Object)
	 */
	public boolean validate(Workable object) {
		resetValidationResult();

		boolean result = true;
		try {
			if (object != null) {
				if (WorkInProgressHelper.isCheckedOut(object)) {
					result = false;
				}
			} else {
				this.validationResult = new ValidationResult(INVALID_PARAMETER_WAS_NULL, false);
			}

		} catch (WTException e) {
			this.validationResult = new ValidationResult(MessageFormat.format(EXCEPTION_THROWN, e.getLocalizedMessage()), false, null, e);
			e.printStackTrace();
		}

		if (this.validationResult == null){
			if (checkedOutToPassValidation){
				result ^= true;
			}

			if (result){
				this.validationResult = new ValidationResult(SUCCESS_MESSAGE, true);
			} else {
				this.validationResult = new ValidationResult(errorMessage, false);
			}
		}

		return this.validationResult.getIsValid();
	}

	public ValidationResult getValidationResult() {
		return this.validationResult;
	}


	public void resetValidationResult(){
		this.validationResult = null;
	}

}
