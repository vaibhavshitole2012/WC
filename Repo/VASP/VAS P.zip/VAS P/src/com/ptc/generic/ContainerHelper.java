package com.ptc.generic;

import java.util.Enumeration;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;

import wt.dataops.containermove.ContainerMoveHelper;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.fc.collections.WTValuedHashMap;
import wt.fc.collections.WTValuedMap;
import wt.folder.Folder;
import wt.folder.FolderEntry;
import wt.folder.FolderHelper;
import wt.inf.container.LookupSpec;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerHelper;
import wt.inf.container.WTContainerRef;
import wt.inf.container.WTContainerTemplate;
import wt.inf.template.ContainerTemplateHelper;
import wt.inf.template.WTContainerTemplateMaster;
import wt.org.WTPrincipal;
import wt.pds.StatementSpec;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;

public class ContainerHelper {
	private static final Logger logger = Logger.getLogger(ContainerHelper.class);

	private static final ReferenceFactory rf = new ReferenceFactory();

	public static WTContainer getContainer(Folder folder, String containerRef) throws WTException {
		if(logger.isDebugEnabled()) {
			logger.debug("folder=" + folder + " containerRef=" + containerRef);
		}
		WTContainer container = null;
		if (containerRef != null && containerRef.trim().length()!=0) {
			container = (WTContainer) rf.getReference(containerRef.trim()) .getObject();
			if (logger.isDebugEnabled()) {
				logger.debug("Container = " + container.toString());
			}
		} else {
			logger.debug("no containerRef given");
			if (folder != null) {
				container = folder.getContainer();
				if (logger.isDebugEnabled())
					logger.debug("Container = " + container.toString());
			} else {
				throw new WTException("Container cannot be found, no containerRef or folder given!");
			}
		}
		return container;
	}
        

    /** 
     * this method checks if given relative folderpath exist and creates subfolders if necessary
     *     
     * @param folderpath relative folderpath p.e. "/2007/MW" that should be returned
     * @param containerpath path to container p.e. "/wt.inf.container.OrgContainer=Volkswagen/wt.inf.library.WTLibrary=Erprobungsauftraege"
     * @author Lars Mense, Plussystem
     * @author since ECA 3.00
     * @return if folderpath is null method returns top folder of given container, if folderpath is not null method returns leaf folder (p.e. Folder "MW" in path "/2007/MW")
     */
    public static Folder getAndCreateFolderStructure(String folderpath, String containerpath) throws WTException
    {
        WTContainerRef containerref = WTContainerHelper.service.getByPath(containerpath);
        return (getAndCreateFolderStructure(folderpath, containerref));
    }
    
    /** 
     * this method checks if given relative folderpath exist and creates subfolders if necessary     
     *
     * @param folderpath relative folderpath p.e. "/2007/MW" that should be returned
     * @param container reference
     * @return if folderpath is null method returns top folder of given container, if folderpath is not null method returns leaf folder (p.e. Folder "MW" in path "/2007/MW")
     * @author Lars Mense, Plussysteme
     * @author since ECA 3.00
     */
    public static Folder getAndCreateFolderStructure(String folderpath, WTContainerRef containerref) throws WTException
    {
        
        /* get top folder */        
        WTContainer library = (WTContainer) containerref.getReferencedContainer();
        Folder documentfolder = (wt.folder.Folder) library.getDefaultCabinet();  
        /* if no folderpath given: return topfolder */
        if (folderpath == null) return documentfolder;
        StringTokenizer tokens = new StringTokenizer(folderpath, "/");
        while (tokens.hasMoreElements ())
        {
            documentfolder = getAndCreateSubfolder(documentfolder, tokens.nextToken (), containerref);
        }
        return (documentfolder);
        //FolderHelper.FolderHelper.assign.getDefaultCabinetReference()
    }
    
     /*
     * searchs for subfolder with given name. If no subfolder exist, it 
     * creates the subfolder and returns new subfolder
     *
     * @param parentfolder parent folder object
     * @param subfoldername name of subfolder
     * @param containerreference reference to container
     * @return new folder
     * @author Lars Mense, Plussystem
     * @author since ECA 3.00      
     */
    private static Folder getAndCreateSubfolder(Folder parentfolder, String subfoldername, WTContainerRef containerreference) throws WTException
    {
        QueryResult subfoldersquery = FolderHelper.service.findSubFolders(parentfolder);
        logger.debug("getAndCreateSubfolder() parentfolder: "+parentfolder.getName()+" "+parentfolder.getIdentity());
        /* check if a subfolder must be created */
        Folder subfolder = null; // stores the subfolder
        if (subfoldersquery != null) {
            Enumeration en = subfoldersquery.getEnumeration();            
            while (en.hasMoreElements()) { // iterate and search through all  subfolders
                Folder testfolder = (Folder) en.nextElement();
                logger.debug("found subfolder: "+testfolder.getName()+" "+testfolder.getIdentity());
                if (testfolder.getName().equals(subfoldername)) {
                    subfolder = testfolder;
                    break; // if a subfolder was found: stop searching 
                }
            }            
        }
        /* create subfolder if necessary */
        if (subfolder == null) {
            /*
             * @TODO fix the bug and reactivate following lines
             * 
             * setAdministrator() may fail with following exception:
             *
             * Verschachtelte Ausnahme ist: (wt.session.sessionResource/0) wt.access.NotAuthorizedException: Nicht-authentifizierte Client-Anmeldung nicht erlaubt: "Administrator".
             * at wt.session.StandardSessionManager.setAdministrator(StandardSessionManager.java:328)             
             */
                logger.debug("Creating Folder with path: "+parentfolder.getFolderPath()+"/"+subfoldername);                
                
                WTPrincipal actualuser = SessionHelper.getPrincipal ();
                try
                { // create folder with administrative permissions
                    //SessionHelper.manager.setAdministrator ();
                    subfolder = FolderHelper.service.createSubFolder(parentfolder.getFolderPath()+"/"+subfoldername, containerreference);           
                }
                catch(Exception ex)
                {
                    logger.error (ex);                    
                    throw new WTException("Ordner mit dem Namen "+parentfolder.getFolderPath()+"/"+subfoldername+" existiert nicht");           
                    //throw new WTException(ex);
                }
                finally
                {
                    //SessionHelper.manager.setAuthenticatedPrincipal (actualuser.getIdentity ());
                }
        }
        return subfolder;
    }
      
   public static WTContainerTemplate findProductTemplate(String containerPath, String containerTemplateStr) throws WTException {
      if(containerPath==null || containerPath.length()==0) {
      	throw new WTException("null/empty param 'containerPath' given");
      }
      if(containerTemplateStr==null || containerTemplateStr.length()==0) {
      	throw new WTException("null/empty param 'containerTemplateStr' given");
      }
      
      WTContainerRef containerRef = WTContainerHelper.service.getByPath (containerPath);
      if(logger.isDebugEnabled()) {
      	logger.debug("given containerPath is valid. Found containerRef=" + containerRef);
      }
      //System.out.println("found containerRef=" + containerRef);

          QuerySpec query = new QuerySpec(WTContainerTemplateMaster.class);
          SearchCondition where = new SearchCondition(WTContainerTemplateMaster.class, "name", "=", containerTemplateStr);
          query.appendWhere(where, new int[] { 0, 1 });
          LookupSpec lookup = new LookupSpec(query, containerRef);
          try {
          lookup.setFirstMatchOnly(true);
          } catch(WTPropertyVetoException pve) {
         	 throw new WTException(pve);
          }
          QueryResult results = WTContainerHelper.service.lookup(lookup);
          if(!results.hasMoreElements())
          {
              throw new WTException("did not find a ContainerTemplate for containerPath=" + containerPath + " name=" + containerTemplateStr);
          }
          WTContainerTemplateMaster templateMaster = (WTContainerTemplateMaster)results.nextElement();
          WTContainerTemplate containerTemplate = ContainerTemplateHelper.service.getContainerTemplateRef(templateMaster).getTemplate();
          //System.out.println("found containerTemplate=" + containerTemplate);
          return containerTemplate;
   }
   
    public static SearchCondition getSearchCondition(WTContainer container, Class searchClass) throws WTException {
        return new SearchCondition(searchClass, "containerReference.key.id", SearchCondition.EQUAL, PersistenceHelper.getObjectIdentifier(container).getId());
    }
    
    /**
     * Change objects folder to another one
     * @param entry Object to move into folder
     * @param folder Folder to which move
     * @throws wt.util.WTException 
     */
    public static void changeFolder(final FolderEntry entry, final Folder folder) throws WTException {

        WTContainer newContainer = FolderHelper.getFolder(entry).getContainer();
        WTContainer oldContainer = folder.getContainer();

        if (PersistenceHelper.equals(newContainer, oldContainer)) {
            logger.debug("In the same container, using FolderHelper to move to the target folder");
            FolderHelper.service.changeFolder(entry, folder);
        } else {
            logger.debug("In other container, using ConteinerMoveHelper to move to the target container");
            WTValuedMap valMap = new WTValuedHashMap();
            valMap.put(entry, folder);
            ContainerMoveHelper.service.moveAllVersions(valMap);
        }
    }
    
    /**
     * Obtains the wtcontainer object from the database based on name. 
     * If there are more containers with that name
     * and class, the first returned container will be returned.
     * 
     * @param containerName
     * @param class - the class of the container (eg. WTLibrary.class)
     * @return
     * @throws 
     */
    public static WTContainer getContainerBasedOnName(String containerName, Class containerClass) throws WTException {
    	
    	QueryResult foundContainers = createAndExecuteQueryForWTContainer(containerName, containerClass);

    	if (foundContainers == null || !foundContainers.hasMoreElements()) {
    		logger.warn("cannot find container for name: " + containerName + " , and class: " + containerClass );
    		return null; 
    	}
    	
    	if (foundContainers.size() > 1) {
    		logger.warn("There are more than 1 container for name: " + containerName + " , and class: " + containerClass);
    		logger.warn("will return the first object in the queryresult");
    	}

    	return (WTContainer) foundContainers.nextElement();
    }
    
    /**
     * Creates and excecutes query for the wtcontainer - class and name (with condition equal)
     * 
     * @param wtContainerName
     * @param wtContainerClass
     * @return
     * @throws WTException
     */
    private static QueryResult createAndExecuteQueryForWTContainer(String wtContainerName, Class<?> wtContainerClass) throws WTException {
    	QuerySpec querySpec = new QuerySpec(wtContainerClass);
        querySpec.appendWhere(new SearchCondition(WTContainer.class, WTContainer.NAME, SearchCondition.EQUAL, wtContainerName), new int[] { 0 });
        QueryResult queryResult = PersistenceHelper.manager.find((StatementSpec) querySpec);
        return queryResult;
    }
    
}
