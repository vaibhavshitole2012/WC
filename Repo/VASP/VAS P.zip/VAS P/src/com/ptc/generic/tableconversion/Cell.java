package com.ptc.generic.tableconversion;


import java.io.Serializable;

/**
 * Simple Cell object that only carries a Value.
 */
public class Cell implements Serializable
{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Object value; // only simple value objects allowed: String, ...
	//Added as part of CR_2012_002
    //This parameter holds the information about the color
    //that will be used when the cell is added to the excel
    private int cellColorRGB=0;
    

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		if(value != null)
			return this.value.toString();
		else
			return "";
	}

	
	
	public Cell(Object value)
    {
        this.value = value;
    }
    
    public void setValue(Object value)
    {
        this.value = value;
    }

    public Object getValue()
    {
        return value;
    }
    
    
    /**
     * Returns RGB value of Cell Color
     * 
     * @return
     *  a <code> int </code> value
     *  
     */
    public int getCellColor() {
		return cellColorRGB;
	}
    
    /**
     * This method will set cell color (in RGB) that should be
     * applied to cell in excel. 
     * 
     * @param cellColor
     *  a <code> int </code> type
     */
	public void setCellColor(int cellColor) {
		this.cellColorRGB = cellColor;
	}
}
