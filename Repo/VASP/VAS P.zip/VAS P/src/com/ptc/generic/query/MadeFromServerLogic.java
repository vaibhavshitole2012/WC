package com.ptc.generic.query;

import wt.enterprise.MadeFromLink;
import wt.query.ArrayExpression;
import wt.query.ClassAttribute;
import wt.query.QueryException;
import wt.query.SearchCondition;
import wt.query.SubSelectExpression;
import wt.util.WTException;

import com.ptc.generic.fc.ImprovedQuerySpec;

public class MadeFromServerLogic {

	/**
	 * <pre>
	 * Given a list of IDs this method creates a QueryApec to search for all existing save-as-copies 
	 * 
	 * As the MadeFromLink is iteration-specific we have first to get the branchId to a specific id.
	 * Then we have  to get all iterations from a parent branch-id. 
	 * After we have all iterations we can check if one of this iterations exists as parent.
	 * 
	 * For every found copy the QuerySpec returns the following information as a pair: 
	 * - the OID of the save as copy 
	 * 
	 * SELECT A1.idA3A5
	 * FROM  MadeFromLink A1
	 *  WHERE A1.idA3B5 IN 
	 *  => Find all object for which a save as-copy exists
	 *  	(SELECT A0.idA2A2 FROM WTPart A0 WHERE A0.branchIditerationInfo IN 
	 *      => Get all Oids for the list of branchIds
	 *      	(SELECT branchiditerationinfo FROM wtpart WHERE ida2a2 IN oids)
	 *      	=> Get all BranchIDs for the list of oids
	 * </pre>
	 * 
	 * 
	 * @param oids
	 *            a list of branch Ids
	 * @return a QuerySpec to search for the search-as-copy
	 * @throws WTException
	 */
	public static ImprovedQuerySpec getQuerySpecSaveAsChildrenFromOids(Long[] oids) throws WTException {

		ImprovedQuerySpec qsSaveAsChildren = getQSSaveAsChildren();

		appendSCMadeFromParentOids(qsSaveAsChildren, oids);

		return qsSaveAsChildren;
	}

	/**
	 * <pre>
	 * 
	 * Given a list of ids this method creates a ImprovedQuerySpec to search for all existing save-as-copies.
	 * As the MadeFromLink is iteration-specific we have first to get the branchId to a specific id.
	 * Then we have  to get all iterations from a parent branch-id. 
	 * After we have all iterations we can check if one of this iterations exists as parent.
	 * 
	 *  WHERE A1.idA3B5 IN 
	 *  => Find all object for which a save as-copy exists
	 *  	(SELECT A0.idA2A2 FROM WTPart A0 WHERE A0.branchIditerationInfo IN 
	 *      => Get all Oids for the list of branchIds
	 *      	(SELECT branchiditerationinfo FROM wtpart WHERE ida2a2 IN oids)
	 *      	=> Get all BranchIDs for the list of oids
	 * </pre>
	 * 
	 * @param qsSaveAsChildren
	 * @param oids
	 * @return
	 * @throws QueryException
	 * @throws WTException
	 */
	private static ImprovedQuerySpec appendSCMadeFromParentOids(ImprovedQuerySpec qsSaveAsChildren, Long[] oids) throws WTException {
		// WHERE A1.idA3B5 IN
		int idxMadeFromLink = qsSaveAsChildren.getClassIndex(MadeFromLink.class.getName());
		ClassAttribute parentId = new ClassAttribute(MadeFromLink.class, QueryServerUtils.ROLE_B_OBJECT_REF_KEY_ID);
		ImprovedQuerySpec qsBranchIdFromOid = QueryServerUtils.getQSWTPartBranchIdFromOid(oids);
		ImprovedQuerySpec qsAllOidsFromOid = QueryServerUtils.getQSWTPartOidsFromBranchIds(qsBranchIdFromOid);
		SubSelectExpression subQSOids = new SubSelectExpression(qsAllOidsFromOid);
		SearchCondition scBranchIds = new SearchCondition(parentId, SearchCondition.IN, subQSOids);
		qsSaveAsChildren.appendWhere(scBranchIds, new int[] { idxMadeFromLink });
		return qsSaveAsChildren;
	}

	/**
	 * <pre>
	 * Given a list of branchIDs this method creates a ImprovedQuerySpec to search for all existing save-as-copies.
	 * As the MadeFromLink is iteration-specific we have first to get all iterations from a parent branch-id. 
	 * After we have all iterations we can check if one of this iterations exists as parent.
	 * 
	 * For every found copy the QuerySpec returns the following information as: 
	 * - the OID of the save as copy 
	 * 
	 * SELECT A1.idA3A5
	 * FROM  MadeFromLink A1
	 *  WHERE A1.idA3B5 IN 
	 *  => Find all object for which a save as-copy exists
	 *  	(SELECT A0.idA2A2 FROM WTPart A0 WHERE A0.branchIditerationInfo IN branchIds)
	 *      => Get all Oids for the list of branchIds
	 * 
	 * </pre>
	 * 
	 * @param branchIds
	 *            a list of branch Ids
	 * @return a QuerySpec to search for the search-as-copy
	 * @throws WTException
	 */
	public static ImprovedQuerySpec getQuerySpecSaveAsChildrenFromBranchId(Long[] branchIds) throws WTException {
		ImprovedQuerySpec qsSaveAsChildren = getQSSaveAsChildren();

		qsSaveAsChildren = appendSCMadeFromParentBranchIds(qsSaveAsChildren, branchIds);

		return qsSaveAsChildren;
	}

	/**
	 * <pre>
	 * Append a search condition to a save-as query to include specific save-as (MadeFromLink) parent Ids.
	 * 
	 * As the MadeFromLink is iteration-specific we have first to get all iterations from a parent branch-id. 
	 * After we have all iterations we can check if one of this iterations exists as parent.
	 * 
	 *  WHERE A1.idA3B5 IN 
	 *  => Find all object for which a save as-copy exists
	 *  	(SELECT A0.idA2A2 FROM WTPart A0 WHERE A0.branchIditerationInfo IN branchIds)
	 *      => Get all Oids from the list of branchIds
	 * </pre>
	 * 
	 * @param qsSaveAsChildren
	 *            a query spec to find the save as children
	 * @param branchIds
	 *            a list of branchIds
	 * 
	 * @return
	 * @throws WTException
	 * @throws QueryException
	 */
	private static ImprovedQuerySpec appendSCMadeFromParentBranchIds(ImprovedQuerySpec qsSaveAsChildren, Long[] branchIds) throws WTException {
		try {
			// where ida3b5 (parent branch-id) in list of branchIds
			int idxMadeFromLink = qsSaveAsChildren.getClassIndex(MadeFromLink.class.getName());
			ClassAttribute ida3b5 = new ClassAttribute(MadeFromLink.class, QueryServerUtils.ROLE_B_OBJECT_REF_KEY_ID);
			ImprovedQuerySpec qsAllOidsFromOid = QueryServerUtils.getQSWTPartOidsFromBranchIds(branchIds);
			SubSelectExpression subQSOids = new SubSelectExpression(qsAllOidsFromOid);
			SearchCondition ida3b5InSub = new SearchCondition(ida3b5, SearchCondition.IN, subQSOids);
			qsSaveAsChildren.appendWhere(ida3b5InSub, new int[] { idxMadeFromLink });
			return qsSaveAsChildren;
		} catch (QueryException queryException) {
			throw new WTException(queryException);
		}
	}

	/**
	 * <pre>
	 * Create a query spec which search for the children (Id) of a save-as link (MadeFromLink)
	 * 
	 * SELECT ida3a5 FROM MadeFromLink 
	 * => Find Child-Id in MadeFromLink
	 * </pre>
	 * 
	 * @return the query spec to find the save-as children
	 * @throws QueryException
	 */
	private static ImprovedQuerySpec getQSSaveAsChildren() throws WTException {
		try {
			ImprovedQuerySpec qsSaveAsChildren = new ImprovedQuerySpec();
			qsSaveAsChildren.setAdvancedQueryEnabled(true);

			// from MadeFromLink
			int idxMadeFromLink = qsSaveAsChildren.appendClassList(MadeFromLink.class, false);

			// select ida3a5 => Child-ID
			qsSaveAsChildren.appendSelectAttribute(QueryServerUtils.ROLE_A_OBJECT_REF_KEY_ID, idxMadeFromLink, false);
			return qsSaveAsChildren;
		} catch (QueryException queryException) {
			throw new WTException(queryException);
		}
	}
}
