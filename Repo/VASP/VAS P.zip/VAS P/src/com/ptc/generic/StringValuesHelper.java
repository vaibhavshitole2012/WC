/* bcwti
 *
 *  Copyright (c) 2012 Parametric Technology Corporation (PTC). All Rights
 *  Reserved.
 *
 *  This software is the confidential and proprietary information of PTC.
 *  You shall not disclose such confidential information and shall use it
 *  only in accordance with the terms of the license agreement.
 *
 *  ecwti
 */
package com.ptc.generic;

import com.ptc.generic.iba.IBAUtil;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import wt.introspection.WTIntrospectionException;

/**
 * Handles splitting Strings for multivalued IBA's and User Preferences
 *
 * @author lachb
 */
public class StringValuesHelper {

    public static final String svnRev = "$Revision: 1.1.1.3 $ $Date: 2015/12/10 21:01:36IST $";
    public static final String svnUrl = "$URL: http://127.0.0.1/svn/KB_04082016/components/Generic-Utilities/src/com/ptc/generic/StringValuesHelper.java $";
    private static final String CLASSNAME = StringValuesHelper.class.getName();
    private static final Logger logger = Logger.getLogger(CLASSNAME);

    /**
     * Splits the String into a List of Strings, accordingly to the length of database value.
     * @param table Table to check the property size.
     * @param column Column name that is to be used as length indicator.
     * @param value Value to split
     * @param addSplitter Indicates if numbers are to be added to each of the splitted strings.
     * @param columnLength If the column length is known you can give it here, pass 0 to perform introspection.
     * @return List of splitted strings.
     * @throws WTIntrospectionException
     */
    public static List<String> splitMultiValue(Class<?> table, String column, String value, boolean addSplitter,
            int columnLength) throws WTIntrospectionException {
        logger.debug("Splitting value = " + value);
        List<String> splittedValues = new ArrayList<String>();
        if (StringUtils.isNotBlank(value)) {
            // Check if the columnLength parameter was not 0 and use it or perform introspection in order to get the length.
            int dbColumnMaxLength = columnLength > 0 ? columnLength : Introspector.introspectColumnLength(table, column);
            logger.debug("Max value length = " + dbColumnMaxLength);
            StringBuilder valueBuilder = new StringBuilder();
            // Checks if value needs to be splitted (if it's longer than database limit)
            if (!StringHelper.isLongerThan(value, dbColumnMaxLength)) {
                logger.debug("Value doesn't need to be split");
                splittedValues.add(valueBuilder.append(value).toString());
            } else {
                logger.debug("Value need to be split");
                // Save enough space in the splited value to add a value number (used in multivalue IBA's).
                for (int i = 0, offset = 0, maxLength = calculateMaxLength(dbColumnMaxLength, 
                        NumberHelper.numberLength(i) + (addSplitter ? IBAUtil.MULTI_VALUE_SPLITTER.length() : 0));
                        offset < value.length();) {
                    logger.debug("Max value length for current part = " + maxLength);
                    // Append number and multivalue splitter character.
                    if (addSplitter) {
                        valueBuilder.append(constructIndex(i, IBAUtil.MULTI_VALUE_SPLITTER));
                    }
                    valueBuilder.append(value.substring(offset, offset + maxLength < value.length() ? offset + maxLength
                            : value.length()));
                    if (logger.isDebugEnabled()) {
                        logger.debug("Current value part: " + valueBuilder.toString());
                    }
                    splittedValues.add(valueBuilder.toString());
                    valueBuilder.delete(0, valueBuilder.length());
                    offset += maxLength;
                    maxLength = calculateMaxLength(dbColumnMaxLength, NumberHelper.numberLength(++i) + (addSplitter
                            ? IBAUtil.MULTI_VALUE_SPLITTER.length() : 0));
                }
            }
        }
        return splittedValues;
    }

    /**
     * Calculates max length of line depending on max database's column and given line number
     * Used in splitting long Strings
     * @param dbIBAMaxLength
     * @param numberLength
     * @return
     */
    private static int calculateMaxLength(int dbIBAMaxLength, int numberLength) {
        return dbIBAMaxLength - numberLength;
    }
    
    public static String constructIndex(int i, String splitter) {
        StringBuilder builder = new StringBuilder();
        return builder.append(i).append(splitter).toString();
    }
}
