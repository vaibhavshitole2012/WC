/*
 * bcwti
 *
 * Copyright (c) 2012 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */
package com.ptc.generic.userprefs;

/**
 * Allowed user preferences categories
 * Use UserPrefCategory.name() to get string representation
 *
 * @see Enum#name()
 * @author Marek Piechut <mpiechut@ptc.com>
 */
public enum UserPrefCategory {

    /**
     * General user preferences (ones declared in UserPreference)
     * @see UserPreference
     */
    ECA,
    /**
     * Category of preferences holding user views
     */
    ECA_VIEW,
    /**
     * Category of preferences holding user column filters
     *
     */
    ECA_COLUMN_FILTER,
    /**
     * Category of preferences holding user PR filters
     */
    ECA_PR_FILTER,

    /**
     * Category of preferences for ECA Auftragswesen
     */
    AUFTRAGSWESEN,

    /**
     * Category of preferences for Baustandsvergleich
     */
    BSV,

    /**
     * Category of preferences for Baustandsvergleich
     */
    BSV_CONFIGURATION,

    /**
     * Category of preferences for ECA Interfaces
     */
    INTERFACES,

    /**
     * Category of preferences for ECA Interfaces
     */
    WORKFLOWS,

    /**
     * Category of preferences for vaulting and replication
     */
    VAULTING_AND_REPLICATION,

    /**
     *  Category of preferences which save the collapse state of the Baustufen table
     */
    BAUSTUFEN_TABLE,
    
    ECA_EXPANSION_STATES,
}
