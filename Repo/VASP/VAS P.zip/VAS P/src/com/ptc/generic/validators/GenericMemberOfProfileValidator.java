package com.ptc.generic.validators;

import com.ptc.generic.validators.validatorsResource;
import com.ptc.generic.GenericProperties;

import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerHelper;
import wt.inf.container.WTContainerRef;
import wt.org.DirectoryContextProvider;
import wt.org.OrganizationServicesHelper;
import wt.org.WTGroup;
import wt.org.WTPrincipal;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.util.WTMessage;



/**
 * @author AB
 *
 */
public class GenericMemberOfProfileValidator implements GenericValidator<WTPrincipal> {
	public static final String svnRev = "$Revision: 1.1.1.3 $ $Date: 2016/02/23 22:21:36IST $";
	public static final String svnUrl = "$URL: http://127.0.0.1/svn/KB_04082016/components/Generic-Utilities/src/com/ptc/generic/validators/GenericMemberOfProfileValidator.java $";
	
	private ValidationResult validationResult;
	private String errorMessage;
	private static final String defaultErrorMessage = WTMessage.getLocalizedMessage(VALIDATION_RESOURCE, validatorsResource.INVALID_NOT_MEMBER_OF_GROUP, null);

	private String profileName;
	private DirectoryContextProvider containerContextProvider;

	/**
	 * @param groupNames
	 */
	public GenericMemberOfProfileValidator(String profileName) {
		this(null, null, profileName);
	}
	
	/**
	 * @param containerContextProvider
	 * @param groupNames
	 */
	public GenericMemberOfProfileValidator(DirectoryContextProvider containerContextProvider, String profileName) {
		this(null, containerContextProvider, profileName);
	}

	/**
	 * @param errorMessage
	 * @param containerContextProvider
	 * @param groupNames
	 */
	public GenericMemberOfProfileValidator(String errorMessage, DirectoryContextProvider containerContextProvider, String profileName){
		this.containerContextProvider = containerContextProvider;
		this.profileName = profileName;
		this.errorMessage = errorMessage;
	}

	/**
	 * Checks if the specified user is part of at least one of the specified groups in the passed context 
	 *
	 * @param user
	 * @return true if the specified user is a member of at least one of the specified org groups in the given container context
	 * @see com.ptc.generic.validators.GenericValidator#validate(java.lang.Object)
	 */
	public boolean validate(WTPrincipal user) {
		resetValidationResult();
		boolean isMemberOfProfile = false;
		
		try {

			if (containerContextProvider == null) {
				containerContextProvider = WTContainerHelper.service.getExchangeContainer().getContextProvider();
			}
			
			if (user == null){
				user = SessionHelper.getPrincipal();
			}
			
			if (this.profileName != null && user != null){
				
				try {
					GenericProperties vwProps = GenericProperties.getProperties("custom.properties");
		            String orgname = (String) vwProps.get("com.ptc.part.Organisation");
		            
					WTContainer container = null;
		            if (orgname != null && orgname.length() != 0) {
		                WTContainerRef orgRef = WTContainerHelper.service.getByPath("/wt.inf.container.OrgContainer=" + orgname);
						container = orgRef.getReferencedContainer();
					}

					WTGroup profile = WTContainerHelper.service.getProfileGroup(profileName, container);
					if (profile != null && profile instanceof WTGroup) {
						
						if (OrganizationServicesHelper.manager.isMember(profile, user)) {
							isMemberOfProfile = true;
						}
					}

				} catch (WTException e){
					if(errorMessage != null){
						this.validationResult = new ValidationResult(errorMessage, false, null, e);
					}else{
						this.validationResult = new ValidationResult(defaultErrorMessage, false, null, e);
					}
					
					e.printStackTrace();
				}
				
				
			}
		} catch (WTException e) {
			if(errorMessage != null){
				this.validationResult = new ValidationResult(errorMessage, false, null, e);
			}else{
				this.validationResult = new ValidationResult(defaultErrorMessage, false, null, e);
			}
			e.printStackTrace();
		}
		

		if (isMemberOfProfile){
			this.validationResult = new ValidationResult(SUCCESS_MESSAGE, true);
		}else{
			this.validationResult = new ValidationResult(defaultErrorMessage, false);
		}

		return this.validationResult.getIsValid();
	}

	public ValidationResult getValidationResult() {
		return this.validationResult;
	}

	public void resetValidationResult(){
		this.validationResult = null;
	}

}
