/* bcwti
 * 
 *  Copyright (c) 2012 Parametric Technology Corporation (PTC). All Rights
 *  Reserved.
 * 
 *  This software is the confidential and proprietary information of PTC.
 *  You shall not disclose such confidential information and shall use it
 *  only in accordance with the terms of the license agreement.
 * 
 *  ecwti
 */
package com.ptc.generic;

/**
 *
 * @author Marek Piechut <m.piechut@tt.com.pl>
 */
public class ExceptionUtils {

    //Constants with placeholders for Subversion
    public static final String svnRev = "$Revision: 1.1.1.3 $ $Date: 2015/12/10 21:01:36IST $";
    public static final String svnUrl = "$URL: http://127.0.0.1/svn/KB_04082016/components/Generic-Utilities/src/com/ptc/generic/ExceptionUtils.java $";
    //

    public static Throwable getRootCause(Throwable ex) {
        while (ex.getCause() != null) {
            ex = ex.getCause();
        }

        return ex;
    }
}
