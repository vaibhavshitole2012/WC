package com.ptc.generic.fc;

import java.util.HashMap;
import java.util.Map;

import com.ptc.generic.query.QueryServerUtils;

import wt.query.QueryException;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;

public class ImprovedQuerySpec extends QuerySpec {

	Map<String, Integer> mapClassListIndexes;

	public ImprovedQuerySpec() throws QueryException {
		super();

		mapClassListIndexes = new HashMap<String, Integer>();
	}

	/**
	 * Overwrite the existing method to save the class index
	 */
	public int appendClassList(Class newClass, boolean isSelectable) throws QueryException {
		int idxClass = super.appendClassList(newClass, isSelectable);

		mapClassListIndexes.put(newClass.getName(), Integer.valueOf(idxClass));

		return idxClass;
	}

	/**
	 * Overwrite the existing method to save the class index
	 */
	public int addClassList(Class newClass, boolean isSelectable) throws QueryException {
		int idxClass = super.addClassList(newClass, isSelectable);

		mapClassListIndexes.put(newClass.getName(), Integer.valueOf(idxClass));

		return idxClass;
	}

	/**
	 * Returns the saved class index
	 *
	 * @param className the name of the class e.g. WTPart
	 * @return the index of this class in the query
	 */
	public int getClassIndex(String className){
		return mapClassListIndexes.get(className).intValue();
	}

	/**
	 * Appends a search condition to return only the latest iteration
	 *
	 * @param qs
	 *            the query spec
	 * @param idxS
	 *            the index of the class in the query
	 * @throws QueryException
	 */
	public void appendSCLatest(Class searchClass, int idx) throws WTException {
		SearchCondition scOnlyLatest = new SearchCondition(searchClass, QueryServerUtils.ITERATION_INFO_LATEST, SearchCondition.IS_TRUE);
		this.appendWhere(scOnlyLatest, new int[] { idx });
	}
}
