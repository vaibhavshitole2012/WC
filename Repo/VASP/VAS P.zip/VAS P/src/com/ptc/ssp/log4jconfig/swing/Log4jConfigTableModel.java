package com.ptc.ssp.log4jconfig.swing;

import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.Vector;

import javax.swing.table.AbstractTableModel;

import org.apache.log4j.*;

public class Log4jConfigTableModel extends AbstractTableModel {

   private final String[] logLevels = { "TRACE", "DEBUG", "INFO", "WARN", "ERROR", "FATAL", "OFF" };
   private Vector rows = null;
   private Vector allRows = null;

	private Log4jConfigTableModel() {
		super();
		initialize();
	}

	private void initialize() {
		Enumeration e = LogManager.getCurrentLoggers();
		rows = new Vector();
		while(e.hasMoreElements()) {
		   rows.add(e.nextElement());
		}
		Collections.sort(rows, new Comparator() {
			public int compare(Object o1, Object o2) {
				Logger c1 = (Logger) o1;
				Logger c2 = (Logger) o2;
				return c1.getName().compareTo(c2.getName());
			}
		});

		allRows = (Vector) rows.clone();
	}

	public static Log4jConfigTableModel newLog4jConfigTableModel() {
		Log4jConfigTableModel tm = new Log4jConfigTableModel();
		return tm;
	}

	public int getColumnCount() {
		return 2;
	}

	public int getRowCount() {
		return rows.size();
	}

	public Object getValueAt(int rowIndex, int columnIndex) {
		if(rowIndex>=rows.size()) {
			throw new RuntimeException("rowIndex bigger than number of rows");
		}
		if(columnIndex>=this.getColumnCount()) {
			throw new RuntimeException("columnIndex must be less than 1");
		}

		Logger l = (Logger) rows.elementAt(rowIndex);
		if(columnIndex==0) {
			return l.getName();
		} else {
			//columnIndex==1 because everything else was checked above
			return l.getEffectiveLevel();
		}
	}

	public Class getColumnClass(int columnIndex) {
		if(columnIndex>=this.getColumnCount()) {
			throw new RuntimeException("columnIndex must be less than 1");
		}
		if(columnIndex==0) {
			return String.class;
		} else {
			//columnIndex==1 because everything else was checked above
			return Level.class;
		}
	}

	public boolean isCellEditable(int row, int col) {
		//only the level column should be editable
		return (col==1);
	}

	public void setValueAt(Object value, int row, int col) {
		if(row>=rows.size()) {
			throw new RuntimeException("rowIndex bigger than number of rows");
		}
		if(col>=this.getColumnCount()) {
			throw new RuntimeException("columnIndex must be less than 1");
		}

		//TODO check for valid given value

		Logger l = (Logger) rows.elementAt(row);
		l.setLevel(Level.toLevel((String)value));

		fireTableCellUpdated(row, col);
	}

	public String[] getPossibleLevels() {
		return logLevels;
	}

	public void filterRows(String filterValue){
		filterValue = filterValue.toLowerCase();
		if (filterValue != null && filterValue.length() > 0){
			rows = new Vector();
			if (filterValue.startsWith("l:")||filterValue.startsWith("l=")){
				filterValue = filterValue.substring(2);
				for (Object o : allRows){
					Logger log = (Logger) o;
					if (log.getLevel() != null && log.getLevel().toString().toLowerCase().contains(filterValue)) {
						rows.add(o);
					} else if (log.getLevel() == null && log.getParent().getLevel() != null && log.getParent().getLevel().toString().toLowerCase().contains(filterValue)) {
						rows.add(o);
					}
				}
			} else {
				String [] cards = filterValue.split("\\*");
				for (Object o : allRows){
					String loggerName = ((Logger) o).getName().toLowerCase();
					boolean match = true;
					for (String card : cards)
			        {
						int idx = loggerName.indexOf(card);
						if(idx == -1)
			            {
							match = false;
			                break;
			            }
						loggerName = loggerName.substring(idx + card.length());
			        }
					if (match){
						rows.add(o);
					}

				}
			}
		} else {
			rows = (Vector) allRows.clone();
		}
	}
}
