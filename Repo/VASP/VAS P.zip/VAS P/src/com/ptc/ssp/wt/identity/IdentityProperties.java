/**
 * Copyright (c) 1998-2008 Parametric Technology. All Rights Reserved.
 */
package com.ptc.ssp.wt.identity;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import wt.util.WTProperties;

/**
 * @author Malte Siefkes PTC Global Services 2008
 * 
 */
public class IdentityProperties {
	private static final String CLASSNAME = IdentityProperties.class.getName();
	private static Logger logger = Logger.getLogger(CLASSNAME);


	/**
	 * Prefix of numbers which are supposed to be cached. All other number are omitted.
	 */
	public static String CachedNumberPrefix; 
	/**
	 * Name of Oracle sequence for retrieving new number values in case cache is empty or not existing
	 */
	public static String OracleSequenceNameForNumbers;
	
	/**
	 * Number of digits to consider after CachedNumberPrefix, any postfix beyond MeaningfulDigits is ignored
	 */
	public static int MeaningfulDigits;
	
	public static Boolean skippedNumberCacheEnabled;

	static {
		try {
			WTProperties wtproperties = WTProperties.getLocalProperties();
			String path = "com.ptc.ssp.wt.identity.";
			CachedNumberPrefix = wtproperties.getProperty(path +"CachedNumberPrefix","H");
			OracleSequenceNameForNumbers = wtproperties.getProperty(path + "OracleSequenceName", "HVAC_Part");
			MeaningfulDigits = wtproperties.getProperty(path + "MeaningfulDigits", 7);
			skippedNumberCacheEnabled = wtproperties.getProperty(path + "SkippedNumberCacheEnabled", true);
		} catch (Exception exception) {
			exception.printStackTrace();
		}
	}

	public IdentityProperties() {
		logger.debug("########################################");
		logger.debug("VERBOSE Property Values START");
		try {
			java.lang.reflect.Field fields[] = this.getClass().getDeclaredFields();
			for (int i = 0; i < fields.length; i++) {
				String name = fields[i].getName();
				if (name.startsWith("_"))
					name = name.substring(1);
				if (fields[i].get(this) == null)
					logger.error("   >>> FIELD NOT INITIALIZED: " + name);
				logger.debug(name + " = " + fields[i].get(this));
			}
		} catch (java.lang.IllegalAccessException iae) {
			logger.error(iae.getMessage(), iae);
		}
		logger.debug("VERBOSE Property Values END");
		logger.debug("########################################");
	}

	public static void main(String[] args) {
		logger.setLevel(Level.TRACE);
		@SuppressWarnings("unused")
		IdentityProperties abbProperties = new IdentityProperties();
	}
}
