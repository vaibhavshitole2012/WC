package com.ptc.ssp.log4jconfig;

import java.net.URL;
import java.util.*;

import wt.method.*;
import wt.util.*;

import org.apache.log4j.*;


public class Log4jHelper implements RemoteAccess {
	
   static RemoteMethodServer rms=null;
   static RemoteMethodServer bgms=null;
   
   public static final String TARGETJVM_TC = "TC";
   public static final String TARGETJVM_MSs = "MSs";
   public static final String TARGETJVM_BGMS = "BGMS";
   
   public static String serverCodebase = null;
   static {
	   try {
		   WTProperties wtp = WTProperties.getServerProperties();
		   serverCodebase = wtp.getProperty ("wt.server.codebase");
		   if(!serverCodebase.endsWith("/")) {
			   serverCodebase = serverCodebase + "/";
		   }
		   //System.out.println("Log4jHelper: serverCodebase=" + serverCodebase);
	   } catch(Throwable t) {
		   t.printStackTrace();
		   throw new RuntimeException("exception in static block of Log4jHelper: " + t.getLocalizedMessage());
	   }
   }
   /**
    * retrieves the names of the Loggers that are currently instanciated in a JVM
    * if bFromMS=true, then the loggers of the DefaultRemoteMethodserver are retrieved,
    *   i.e. when multiple method servers are running, it is not determined from which MS the 
    *   logger names are retrieved.
    *        
    * @param bFromMS: if true, then retrieves logger names from DefaultRemoteMethodServer
    * @return Vector of logger names (String)
    * @exception WTException
    */
   public static Vector getCurrentLoggerNames(String targetJVM) throws WTException {
	   if(TARGETJVM_TC.equals(targetJVM)) {
		   return getCurrentLoggerNames(false);
	   } else if(TARGETJVM_BGMS.equals(targetJVM)) {
//		   if(RemoteMethodServer.ServerFlag) {
//			   throw new RuntimeException("Log4jHelper.getCurrentLoggerNames(String) not supported for targetJVM=" + TARGETJVM_BGMS + " on server-side");
//		   } else {
			   checkBGMS();
			   try {
				   return (Vector)bgms.invoke("_getCurrentLoggerNames","com.ptc.ssp.log4jconfig.Log4jHelper",null, new Class[]{}, new Object[]{});
			   } catch(Exception re) {
				   throw new WTException(re);
			   }
//		   }
	   } else {
		   return getCurrentLoggerNames(true);
	   }
   }
	public static Vector getCurrentLoggerNames(boolean bFromMS) throws WTException {
		if(!bFromMS || RemoteMethodServer.ServerFlag) {
			//get values from local Virtual machine
		   return _getCurrentLoggerNames();
		} else {
    		//make sure to get values from Windchill server
			if(rms == null)
			   rms=RemoteMethodServer.getDefault();
			try {
				return (Vector)rms.invoke("_getCurrentLoggerNames","com.ptc.ssp.log4jconfig.Log4jHelper",null, new Class[]{}, new Object[]{});
			} catch(Exception re) {
				throw new WTException(re);
			}
		}
	}
   public static Vector _getCurrentLoggerNames() throws WTException {
   	Enumeration e = LogManager.getCurrentLoggers();
   	Vector v = new Vector();
   	while(e.hasMoreElements()) {
   		v.add(((Logger)e.nextElement()).getName());
   	}
   	//System.out.println("found loggers: " + v.size());
   	return v;
   }

   /**
    * retrieves the name of the root Logger that is currently defined in a JVM
    * if bFromMS=true, then the root logger of the DefaultRemoteMethodserver is retrieved,
    *   i.e. when multiple method servers are running, it is not determined from which MS the 
    *   logger names are retrieved.
    *        
    * @param bFromMS: if true, then retrieves root logger name from DefaultRemoteMethodServer
    * @return: String: name of the root logger
    * @exception WTException
    */
   public static String getRootLoggerName(String targetJVM) throws WTException {
   	if(TARGETJVM_TC.equals(targetJVM)) {
   		return getRootLoggerName(false);
   	} else if(TARGETJVM_BGMS.equals(targetJVM)) {
//   		if(RemoteMethodServer.ServerFlag) {
//   			throw new RuntimeException("Log4jHelper.getRootLoggerName(String) not supported for targetJVM=" + TARGETJVM_BGMS + " on server-side");
//   		} else {
   			checkBGMS();
   			try {
   				return (String)bgms.invoke("_getRootLoggerName","com.ptc.ssp.log4jconfig.Log4jHelper",null, new Class[]{}, new Object[]{});
   			} catch(Exception re) {
   				throw new WTException(re);
   			}
//   		}
   	} else {
   		return getRootLoggerName(true);
   	}
   }
   public static String getRootLoggerName(boolean bFromMS) throws WTException {
		if(!bFromMS || RemoteMethodServer.ServerFlag) {
			//get values from local Virtual machine
		   return _getRootLoggerName();
		} else {
    		//make sure to get values from Windchill server
			if(rms == null)
			   rms=RemoteMethodServer.getDefault();
			try {
				return (String)rms.invoke("_getRootLoggerName","com.ptc.ssp.log4jconfig.Log4jHelper",null, new Class[]{}, new Object[]{});
			} catch(Exception re) {
				throw new WTException(re);
			}
		}
   }
   public static String _getRootLoggerName() throws WTException {
   	Logger r = LogManager.getRootLogger();
   	//System.out.println("rootLogger=" + r.getName());
   	return r.getName();
   }

   /**
    *        
    * @param bFromMS: if true, then retrieves logger names from DefaultRemoteMethodServer
    * @param     loggername
    * @param     levelName
    * @return: String
    * @exception WTException
    */
   public static String setLevel(boolean bFromMS, boolean bSynchronize, String loggername, String levelName) throws WTException {
   	//System.out.println("setLevel bFromMS=" + bFromMS + " bSync=" + bSynchronize);
		if(!bFromMS || RemoteMethodServer.ServerFlag) {
			//get values from local Virtual machine
		   return _setLevel(Boolean.valueOf(bSynchronize), loggername, levelName);
		} else {
    		//make sure to get values from Windchill server
			if(rms == null)
			   rms=RemoteMethodServer.getDefault();
			try {
				return (String)rms.invoke("_setLevel","com.ptc.ssp.log4jconfig.Log4jHelper",null, 
						new Class[]{Boolean.class, String.class, String.class}, new Object[]{Boolean.valueOf(bSynchronize), loggername, levelName});
			} catch(Exception re) {
				re.printStackTrace();
				throw new WTException(re);
			}
		}
   }
   public static String setLevelInBGMS(String loggername, String levelName) throws WTException {
//  		if(RemoteMethodServer.ServerFlag) {
//   			throw new RuntimeException("Log4jHelper.setLevelInBGMS(String, String) not supported for targetJVM=" + TARGETJVM_BGMS + " on server-side");
//   		} else {
   			checkBGMS();
   			try {
				return (String)bgms.invoke("_setLevel","com.ptc.ssp.log4jconfig.Log4jHelper",null, 
						new Class[]{Boolean.class, String.class, String.class}, new Object[]{Boolean.FALSE, loggername, levelName});
   			} catch(Exception re) {
   				throw new WTException(re);
   			}
//   		}
   }
   public static String _setLevel(Boolean bSynchronize, String loggername, String levelName) throws WTException {
   	//System.out.println("_setLevel bSync=" + bSynchronize);
   	Logger l = LogManager.getLogger(loggername);
   	
   	//when synchronizing between different MethodServers, some of them might not have all loggers
   	if(l==null) {
   		l = Logger.getLogger(loggername);
   		System.out.println("Log4jConfig: instanciated non-existing logger for: " + loggername);
   	}
   	
   	if(l!=null) {
   		if(RemoteMethodServer.ServerFlag && bSynchronize.equals(Boolean.TRUE)) {
   			try {
       			//here comes the magic: we are pushing this change of the log level to all methodServers
       			Log4jSynchronizer.getLog4jCache().synchronizeLoglevel(loggername, levelName);
   			} catch(Exception e) {
   				throw new WTException(e);
   			}
   		} else {
      		l.setLevel(Level.toLevel(levelName));
      		System.out.println("Log4jConfig: LOGLEVEL SET: " + l.getName() + ": " + l.getEffectiveLevel());
   		}
      	return l.getEffectiveLevel().toString();
   	} else {
   		throw new WTException("could not find logger with name '" + loggername + "'");
   	}
   }

   public static String getEffectiveLevel(boolean bFromMS, String loggername) throws WTException {
	   //System.out.println("getEffectiveLevel (" + bFromMS + ", " + loggername + ")");
		if(!bFromMS || RemoteMethodServer.ServerFlag) {
			//get values from local Virtual machine
		   return _getEffectiveLevel(loggername);
		} else {
    		//make sure to get values from Windchill server
			if(rms == null)
			   rms=RemoteMethodServer.getDefault();
			try {
				return (String)rms.invoke("_getEffectiveLevel","com.ptc.ssp.log4jconfig.Log4jHelper",null, 
						new Class[]{String.class}, new Object[]{loggername});
			} catch(Exception re) {
				throw new WTException(re);
			}
		}
   }
   public static String getEffectiveLevelFromBGMS(String loggername) throws WTException {
//		if(RemoteMethodServer.ServerFlag) {
//  			throw new RuntimeException("Log4jHelper.getEffectiveLevel(String) not supported for targetJVM=" + TARGETJVM_BGMS + " on server-side");
//  		} else {
  			checkBGMS();
  			try {
				return (String)bgms.invoke("_getEffectiveLevel","com.ptc.ssp.log4jconfig.Log4jHelper",null, 
						new Class[]{String.class}, new Object[]{loggername});
  			} catch(Exception re) {
  				throw new WTException(re);
  			}
//  		}
  }
   public static String _getEffectiveLevel( String loggername ) throws WTException {
	   //System.out.println("_getEffectiveLevel for " + loggername);
   	Logger l = LogManager.getLogger(loggername);
   	if(l!=null) {
   		return l.getEffectiveLevel().toString();
   	} else {
   		throw new WTException("could not find logger with name '" + loggername + "'");
   	}
   }

   public static String getLoggerParentName(boolean bFromMS, String loggername) throws WTException {
		if(!bFromMS || RemoteMethodServer.ServerFlag) {
			//get values from local Virtual machine
		   return _getLoggerParentName(loggername);
		} else {
    		//make sure to get values from Windchill server
			if(rms == null)
			   rms=RemoteMethodServer.getDefault();
			try {
				return (String)rms.invoke("_getLoggerParentName","com.ptc.ssp.log4jconfig.Log4jHelper",null, 
						new Class[]{String.class}, new Object[]{loggername});
			} catch(Exception re) {
				throw new WTException(re);
			}
		}
   }
   public static String getLoggerParentNameFromBGMS(String loggername) throws WTException {
// 		if(RemoteMethodServer.ServerFlag) {
//   			throw new RuntimeException("Log4jHelper.getLoggerParentNameFromBGMS(String) not supported for targetJVM=" + TARGETJVM_BGMS + " on server-side");
//   		} else {
   			checkBGMS();
   			try {
				return (String)bgms.invoke("_getLoggerParentName","com.ptc.ssp.log4jconfig.Log4jHelper",null, 
						new Class[]{String.class}, new Object[]{loggername});
   			} catch(Exception re) {
   				throw new WTException(re);
   			}
//   		}
   }
   public static String _getLoggerParentName( String loggername ) throws WTException {
	   //System.out.println("_getLoggerParentName for " + loggername);
   	Logger l = LogManager.getLogger(loggername);
   	if(l!=null) {
   		return l.getParent().getName();
   	} else {
   		throw new WTException("could not find logger with name '" + loggername + "'");
   	}
   }
   private static void checkBGMS() throws WTException {
	   if(bgms == null) {
		   try {
			   URL serverURL = new URL(serverCodebase);
			   bgms=RemoteMethodServer.getInstance(serverURL, "BackgroundMethodServer");
			   //System.out.println("got BGMS");
		   } catch(Throwable t) {
			   throw new WTException(t);
		   }
	   }
   }
}
