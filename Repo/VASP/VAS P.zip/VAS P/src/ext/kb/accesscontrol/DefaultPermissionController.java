package ext.kb.accesscontrol;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import wt.access.AccessControlHelper;
import wt.access.AccessPermission;
import wt.log4j.LogR;
import wt.util.WTException;

import com.ptc.netmarkets.util.beans.NmHelperBean;

import ext.kb.util.KBUtils;

/**
 * Permission controller class for KB access controlled search data.
 * @author kissn
 *
 */
public class DefaultPermissionController implements PermissionController {

    private static final Logger LOG = LogR.getLogger(DefaultPermissionController.class.getName());

    private static final Set<AccessPermission> ALLOWED_PERMISSIONS = new HashSet<AccessPermission>();

    private static final Map<String, AccessPermission> PERMISSION_MAP = new HashMap<String, AccessPermission>();

    static {
        ALLOWED_PERMISSIONS.add(AccessPermission.READ);
        ALLOWED_PERMISSIONS.add(AccessPermission.DOWNLOAD);
        AccessPermission[] permissions = AccessPermission.getAccessPermissionSet();
        for (AccessPermission perm : permissions) {
            String translatedLabel = KBUtils.translatePermissionLabel(perm.getDisplay().toUpperCase());
            if (KBUtils.isEmpty(translatedLabel)) {
                PERMISSION_MAP.put(perm.getDisplay().toUpperCase(), perm);
            } else {
                PERMISSION_MAP.put(translatedLabel.toUpperCase(), perm);
            }
        }
    }

    @Override
    public Set<AccessPermission> getAllowedPermissions() {
        return ALLOWED_PERMISSIONS;
    }

    @Override
    public AccessPermission extractPermission(NmHelperBean attributeBean) {
        try {
            if (attributeBean != null && attributeBean.getNmCommandBean() != null
                    && attributeBean.getNmCommandBean().getComboBox() != null) {
                @SuppressWarnings("unchecked")
                ArrayList<String> value = (ArrayList<String>) attributeBean.getNmCommandBean().getComboBox()
                        .get("permission2_SearchComboBox");
                // comboBox name depends on pickerAttributes.xml; check the name
                // of the KBEnum tag and add the position it is listed in
                if (KBUtils.isEmpty(value)) {
                    return PERMISSION_MAP.get("READ");
                } else {
                    return PERMISSION_MAP.get(value.get(0).toUpperCase());
                }
            }
        } catch (WTException e) {
            LOG.error("Failed to read data content", e);
        }
        return null;
    }

    @Override
    public boolean hasPermission(Object accessControlled, AccessPermission permission) {
        try {
            return AccessControlHelper.manager.checkAccess(accessControlled, permission);
        } catch (WTException e) {
            return false;
        }
    }
}
