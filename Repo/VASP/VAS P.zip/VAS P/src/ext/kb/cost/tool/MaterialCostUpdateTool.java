package ext.kb.cost.tool;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.Charset;
import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import org.apache.log4j.Logger;
import org.apache.xmlbeans.impl.tool.CommandLine;

import wt.configuration.TraceCode;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.collections.WTArrayList;
import wt.fc.collections.WTCollection;
import wt.httpgw.GatewayAuthenticator;
import wt.iba.value.AttributeContainer;
import wt.iba.value.DefaultAttributeContainer;
import wt.iba.value.IBAHolder;
import wt.iba.value.service.IBAValueDBService;
import wt.lifecycle.LifeCycleException;
import wt.lifecycle.LifeCycleHelper;
import wt.lifecycle.State;
import wt.log4j.LogR;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.org.OrganizationServicesHelper;
import wt.org.WTOrganization;
import wt.org.WTOrganizationIdentifier;
import wt.part.QuantityUnit;
import wt.part.WTPart;
import wt.pds.StatementSpec;
import wt.pom.PersistenceException;
import wt.pom.Transaction;
import wt.query.ClassAttribute;
import wt.query.ConstantExpression;
import wt.query.QueryException;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.session.SessionHelper;
import wt.session.SessionMgr;
import wt.type.TypedUtilityServiceHelper;
import wt.units.FloatingPointWithUnits;
import wt.util.WTAttributeNameIfc;
import wt.util.WTException;
import wt.util.WTProperties;
import wt.util.WTPropertyVetoException;
import wt.vc.Mastered;
import wt.vc.config.ConfigSpec;
import wt.vc.config.LatestConfigSpec;
import wt.vc.views.View;
import wt.vc.views.ViewHelper;
import wt.vc.views.ViewReference;

import com.google.common.io.Files;
import com.ptc.core.lwc.server.PersistableAdapter;
import com.ptc.core.meta.common.TypeIdentifierHelper;
import com.ptc.core.meta.container.common.AttributeTypeSummary;
import com.ptc.core.meta.server.TypeIdentifierUtility;
import com.ptc.core.meta.type.mgmt.server.impl.WTTypeDefinition;
import com.ptc.windchill.suma.part.VendorPart;
import com.ptc.windchill.suma.part.VendorPartMaster;
import com.ptc.windchill.suma.supplier.Vendor;
import com.ptc.windchill.uwgm.common.container.OrganizationHelper;

import ext.kb.util.KBTypeIdProvider;
import ext.kb.util.SupplierHelper;

/**
 * The Class MaterialCostUpdateTool.
 * 
 */
public class MaterialCostUpdateTool implements RemoteAccess {

    /** The Constant CLASSNAME. */
    private static final String CLASSNAME = MaterialCostUpdateTool.class.getName();

    /** The Constant LOGGER. */
    protected static final Logger LOGGER = LogR.getLogger(CLASSNAME);

    /** The Constant USER_INPUT_ARGUMENT_NAME. */
    private static final String USER_INPUT_ARGUMENT_NAME = "u";

    /** The Constant PASSWORD_INPUT_ARGUMENT_NAME. */
    private static final String PASSWORD_INPUT_ARGUMENT_NAME = "p";

    /** The Constant INPUT_FILE_INPUT_ARGUMENT_NAME. */
    private static final String INPUT_FILE_INPUT_ARGUMENT_NAME = "i";

    /** The Constant INPUT_FILE_INPUT_ARGUMENT_NAME. */
    private static final String LOG_DIR_ARGUMENT_NAME = "d";

    /** The Constant RELEASED. */
    private static final String RELEASED = "1050";

    /** The ibas. Variable to gather attributes to update */
    private static String IBAS = "";

    /** The type. */
    private static String TYPE = "";

    /** The attributes delimiter. */
    private static String ATTRIBUTES_DELIMITER = "";

    /** The csv delimiter. */
    private static String CSV_DELIMITER = "";

    /** The input atts. */
    private static String INPUT_ATTS = "";

    /** The bad file name */
    private static String BAD_FILE_NAME = "";

    /** The bad file name */
    private static String LOG_FILE_NAME = "";

    /** The bad file name */
    private static String COST_UPDATE_COMPLETED_FILE = "";

    static {
        try {
            WTProperties properties = WTProperties.getServerProperties();
            IBAS = properties.getProperty("ext.kb.cost.attributes");
            ATTRIBUTES_DELIMITER = properties.getProperty("ext.kb.cost.attributes.delimiter");
            TYPE = properties.getProperty("ext.kb.cost.type");
            CSV_DELIMITER = properties.getProperty("ext.kb.cost.csv.delimiter");
            INPUT_ATTS = properties.getProperty("ext.kb.cost.csv.atts");
            BAD_FILE_NAME = properties.getProperty("ext.kb.cost.badfilename");
            LOG_FILE_NAME = properties.getProperty("ext.kb.cost.logfilename");
            COST_UPDATE_COMPLETED_FILE = properties.getProperty("ext.kb.cost.completedfilename");
        } catch (IOException e) {
            LOGGER.error("Problem during read properties from wt.properties file");
        }
    }

    /** The Constant IBAS_TO_UPDATE. */
    private static final Collection<String> IBAS_TO_UPDATE = Arrays.asList(IBAS.split(ATTRIBUTES_DELIMITER));

    /** The Constant INPUT_ATTS_TO_UPDATE. */
    private static final String[] INPUT_ATTS_TO_UPDATE = INPUT_ATTS.split(CSV_DELIMITER);

    /**
     * The main method.
     *
     * @param arguments
     *            the arguments
     * @throws Exception
     *             the exception
     */
    public static void main(String[] arguments) throws Exception {
        if (arguments.length != 8) {
            printUsage();
            System.exit(0);
        }

        Set<String> commandLineOptions = new HashSet<String>();
        commandLineOptions.add(USER_INPUT_ARGUMENT_NAME);
        commandLineOptions.add(PASSWORD_INPUT_ARGUMENT_NAME);
        commandLineOptions.add(INPUT_FILE_INPUT_ARGUMENT_NAME);
        commandLineOptions.add(LOG_DIR_ARGUMENT_NAME);

        CommandLine commandLine = new CommandLine(arguments, Collections.EMPTY_SET, commandLineOptions);
        String username = commandLine.getOpt(USER_INPUT_ARGUMENT_NAME);
        String password = commandLine.getOpt(PASSWORD_INPUT_ARGUMENT_NAME);
        String inputFile = commandLine.getOpt(INPUT_FILE_INPUT_ARGUMENT_NAME);
        String logDir = commandLine.getOpt(LOG_DIR_ARGUMENT_NAME);

        if (username == null || password == null || inputFile == null || logDir == null) {
            printUsage();
            System.exit(0);
        }

        RemoteMethodServer remoteMethodServer = logIn(username, password);
        //       Execution of method updateProcurementParts(inputFile, logDir);
        remoteMethodServer.invoke("updateProcurementParts", MaterialCostUpdateTool.class.getName(), null, new Class[] { String.class, String.class }, new Object[] { inputFile, logDir });
    }

    /**
     * Update procurement parts. The methog is looking for ProcurementPart in
     * specified Vendor Id. In case that Procurement Part doesn't exist then
     * look for WTPart with specific number and create missing ProcurementPart.
     * Both Parts will be assigned by AXL Link.
     *
     * @param inputFilePath
     *            Input csv file from SAP
     */
    public static void updateProcurementParts(String inputFilePath, String logDir) throws IOException {
        BufferedReader inputFile = null;
        PrintWriter pw = null;
        PrintWriter logPw = null;
        File file = getBadRecordsFile(logDir);
        File logfile = getDetailLogFile(logDir);
        isCompleteFileExist(logDir);
        try {
            inputFile = new BufferedReader(new FileReader(inputFilePath));
            pw = new PrintWriter(file);
            logPw = new PrintWriter(logfile);
        } catch (FileNotFoundException e) {
            LOGGER.error("Input file not found.");
        }
        WTOrganization org = null;
        try {
            org = OrganizationHelper.getOrganizationByName("HVAC");
        } catch (WTException e) {
            LOGGER.info("Organization has not been found");
        }
        Transaction trx = null;
        try {
            String lineFromFile = null;
            

            lineFromFile = inputFile.readLine();// skip first line
            pw.println(lineFromFile);
            int i = 0;
            WTCollection procurementMasters = new WTArrayList();
            while ((lineFromFile = inputFile.readLine()) != null) {
                try {
                    if (i % 1000 == 0) {
                        trx = new Transaction();
                        trx.start();
                    }
                    lineFromFile = lineFromFile.trim();
                    String[] inputAtts = lineFromFile.split(CSV_DELIMITER);
                    VendorPart vendor = findProcurementPart(inputAtts[1], inputAtts[0]);
                    procurementMasters = createOrUpdateProcurementMaster(pw, logPw, org, lineFromFile, procurementMasters, inputAtts, vendor);
                    i++;
                    if (i % 1000 == 0 && procurementMasters != null) {
                        updateIBAHolders(procurementMasters);
                        procurementMasters.clear();
                        trx.commit();
                        trx = null;
                    }
                } catch (WTException e) {
                    LOGGER.error("WTException during update IBA's", e);
                    pw.println(lineFromFile);
                } catch (WTPropertyVetoException e) {
                    LOGGER.error(e.getMessage());
                    pw.println(lineFromFile);
                } 
                catch (ArrayIndexOutOfBoundsException e) {
                    LOGGER.error(e.getMessage());
                    pw.println(lineFromFile);
                }
                catch (RemoteException e) {
                    LOGGER.error(e.getMessage());
                    pw.println(lineFromFile);
                } 
            }
            if (procurementMasters != null && !procurementMasters.isEmpty() && trx != null) {
                updateIBAHolders(procurementMasters);
                procurementMasters.clear();
                try {
                    trx.commit();
                    trx = null;
                } catch (PersistenceException e) {
                   LOGGER.error("Error during persist action.");
                }
                
            }

        } finally {
            if (trx != null) {
                trx.rollback();
            }
            inputFile.close();
            pw.flush();
            pw.close();
            logPw.flush();
            logPw.close();

        }
        List<String> lines = Files.readLines(file, Charset.defaultCharset());
        if (lines.size() == 1) {
            file.delete();
        }
        createCompleteLogFile(logDir);
    }

    public static WTCollection createOrUpdateProcurementMaster(PrintWriter pw, PrintWriter logPw, WTOrganization org, String lineFromFile, WTCollection procurementMasters, String[] inputAtts, VendorPart vendor) throws WTException, WTPropertyVetoException, RemoteException, LifeCycleException, ArrayIndexOutOfBoundsException {
        VendorPartMaster vendorMaster = null;
        if (vendor != null) {
            vendorMaster = (VendorPartMaster) vendor.getMaster();
            LOGGER.info("Vendor Part with number " + vendor.getNumber() + " VendorSiteId: " + inputAtts[0] + " has been found.");
            vendorMaster = updateIBAS(vendorMaster, inputAtts);
            procurementMasters.add(vendorMaster);
            LifeCycleHelper.service.setLifeCycleState(vendor, State.toState(RELEASED));
        } else {
            LOGGER.info("Vendor Part with number " + inputAtts[1] + " VendorSiteId: " + inputAtts[0] + " has not been found.");

            WTPart part = (WTPart) getLatestIterated(WTPart.class, org, inputAtts[1]);

            if (part != null && TypeIdentifierHelper.getType(part).isDescendedFrom(TypeIdentifierHelper.getTypeIdentifier("com.ptc.KBArticle"))) {

                WTOrganizationIdentifier orgId = new WTOrganizationIdentifier();
                orgId.setUniqueIdentifier(inputAtts[0]);
                orgId.setCodingSystem("0001");
                WTOrganization vendOrg = OrganizationServicesHelper.getOrganizationByOrgId(orgId);
                if (vendOrg == null) {
                    LOGGER.error("Organization with Id: " + inputAtts[0] + " doesn't exist.");
                    logPw.println("Organization with Id: " + inputAtts[0] + " doesn't exist.");
                    LOGGER.error(lineFromFile);
                    pw.println(lineFromFile);

                } else {
                    VendorPart procPart = createVendorPart(part, vendOrg);
                    Vendor vend = getVendor(procPart);
                    if (vend != null) {
                        SupplierHelper.assignPartToVendor(part, procPart, vend);
                        LifeCycleHelper.service.setLifeCycleState(procPart, State.toState(RELEASED));
                        Mastered master = procPart.getMaster();
                        if (master instanceof VendorPartMaster) {
                            master = updateIBAS((VendorPartMaster) master, inputAtts);
                            procurementMasters.add(master);
                        }

                    } else {
                        LOGGER.error("Vendor with number: " + inputAtts[0] + " doesn't exist.");
                        logPw.println("Vendor with number: " + inputAtts[0] + " doesn't exist.");
                        LOGGER.error(lineFromFile);
                        pw.println(lineFromFile);
                    }
                }
            } else {
                LOGGER.error("VendorPart and Part with number: " + inputAtts[1] + " has not been found in Windchill.");
                //logPw.println("VendorPart and Part with number: " + inputAtts[1] + " has not been found in Windchill.");
                LOGGER.error(lineFromFile);
                //pw.println(lineFromFile);
            }
        }
        return procurementMasters;
    }

    /**
     * Creates the vendor part.
     *
     * @param part
     *            the part
     * @param vendOrg
     *            the Vendor Organization
     * @return the vendor part
     * @throws WTException
     *             the WT exception
     * @throws WTPropertyVetoException
     *             the WT property veto exception
     * @throws RemoteException
     *             the remote exception
     */
    public static VendorPart createVendorPart(WTPart part, WTOrganization vendOrg) throws WTException, WTPropertyVetoException, RemoteException {
        VendorPart procPart = VendorPart.newVendorPart(part.getNumber(), vendOrg.getName());

        procPart.setTypeDefinitionReference(TypedUtilityServiceHelper.service.getTypeDefinitionReference(KBTypeIdProvider.getType("PROCUREMENTPART").getLeafName()));

        procPart.setEndItem(false);
        procPart.setDefaultUnit(QuantityUnit.toQuantityUnit("pc"));
        procPart.setDefaultTraceCode(TraceCode.toTraceCode("S"));
        procPart.setOrganization(vendOrg);
        procPart.setContainer(part.getContainer());

        try {
            View[] views = ViewHelper.service.getAllViews();
            for (View v : views)
                if ("Design".equalsIgnoreCase(v.getName())) {
                    procPart.setView(ViewReference.newViewReference(v));
                    break;
                }
        } catch (WTException e) {
            LOGGER.warn("Failed to set the view of the part", e);
        }
        return procPart;
    }

    /**
     * Find procurement part. Method look for VendorPartMaster with specific
     * number and Organization Id.
     *
     * @param partNumber
     *            the part number
     * @param vendorOrganizationId
     *            the vendor organization id
     * @return the vendor part master
     * @throws PersistenceException
     *             the persistence exception
     * @throws QueryException
     *             the query exception
     * @throws WTException
     *             the WT exception
     */
    private static VendorPart findProcurementPart(final String partNumber, final String vendorOrganizationId) throws PersistenceException, QueryException, WTException {

        QuerySpec queryspec = new QuerySpec();

        int i = queryspec.addClassList(VendorPart.class, true);

        SearchCondition localSearchCondition1 = new SearchCondition(VendorPart.class, "master>number", "=", partNumber.toUpperCase(), false);

        queryspec.appendWhere(localSearchCondition1, new int[] { i });

        int typeDefinitionIndex = queryspec.addClassList(WTTypeDefinition.class, false);

        SearchCondition localSearchCondition2 = new SearchCondition(new ClassAttribute(VendorPart.class, "typeDefinitionReference.key.id"), SearchCondition.EQUAL, new ClassAttribute(WTTypeDefinition.class, "thePersistInfo.theObjectIdentifier.id"));

        queryspec.appendAnd();
        queryspec.appendWhere(localSearchCondition2, new int[] { i, typeDefinitionIndex });

        SearchCondition localSearchCondition3 = new SearchCondition(new ClassAttribute(WTTypeDefinition.class, "logicalIdentifier"), SearchCondition.EQUAL, new ConstantExpression(TYPE));

        queryspec.appendAnd();
        queryspec.appendWhere(localSearchCondition3, new int[] { typeDefinitionIndex });

        ConfigSpec configSpec = new LatestConfigSpec();
        queryspec = configSpec.appendSearchCriteria(queryspec);

        QueryResult localQueryResult = PersistenceHelper.manager.find((StatementSpec) queryspec);
        VendorPart vendorPart = null;
        while (localQueryResult.hasMoreElements()) {
            wt.fc.Persistable apersistable[] = (wt.fc.Persistable[]) (wt.fc.Persistable[]) localQueryResult.nextElement();

            vendorPart = (VendorPart) apersistable[0];
            LOGGER.debug("Found procurement part: " + vendorPart.getDisplayIdentifier());
            String organizationUniqueIdentifier = vendorPart.getOrganizationUniqueIdentifier();

            if (organizationUniqueIdentifier != null && organizationUniqueIdentifier.equals(vendorOrganizationId)) {
                return vendorPart;
            } else {
                LOGGER.debug("Organization ids didn't match (" + vendorOrganizationId + " vs " + organizationUniqueIdentifier + ") aborting");
            }
        }

        return null;
    }

    /**
     * Get Latest Iteration for a given master.
     *
     * @param klazz
     *            the Class parameter
     * @param wtOrganization
     *            the wt organization
     * @param objectNumber
     *            the object number
     * @return Persistable
     * @throws WTException
     *             the WT exception
     */
    public static Persistable getLatestIterated(Class<?> klazz, WTOrganization wtOrganization, String objectNumber) throws WTException {

        Persistable returnObject = null;

        if (wtOrganization == null) {
            IllegalArgumentException e = new IllegalArgumentException("WTOrganization cannot be null!");
            LOGGER.error(e.getMessage(), e);
        }

        if (klazz == null) {
            IllegalArgumentException e = new IllegalArgumentException("Class cannot be null!");
            LOGGER.error(e.getMessage(), e);
        }
        if ((objectNumber == null) || (objectNumber.isEmpty())) {
            IllegalArgumentException e = new IllegalArgumentException("Object number cannot be null!");
            LOGGER.error(e.getMessage(), e);
        }

        LatestConfigSpec configSpec = null;
        QuerySpec qs = new QuerySpec(klazz);
        // Object number condition
        qs.appendWhere(new SearchCondition(klazz, "master>number", SearchCondition.EQUAL, objectNumber, false));

        // Add Organization condition
        qs.appendAnd();
        qs.appendWhere(new SearchCondition(klazz, "master>organizationReference" + '.' + WTAttributeNameIfc.REF_OBJECT_ID, SearchCondition.EQUAL, PersistenceHelper.getObjectIdentifier(wtOrganization).getId()));

        configSpec = new LatestConfigSpec();
        qs = configSpec.appendSearchCriteria(qs);
        LOGGER.debug("SQL query: " + qs.toString());

        QueryResult qr = PersistenceHelper.manager.find((StatementSpec) qs);
        LOGGER.debug("Query found " + qr.size() + " matching parts.");

        qr = configSpec.process(qr);
        LOGGER.debug("Query filtered by ConfigSpec found " + qr.size() + " matching parts.");

        // LatestConfigSpec processing will always return only one object
        if (qr.hasMoreElements())
            returnObject = (Persistable) qr.nextElement();

        return returnObject;
    }

    /**
     * Prints the usage.
     */
    private static void printUsage() {
        System.out.println("Usage:");
        System.out.println("windchill " + CLASSNAME + " -" + USER_INPUT_ARGUMENT_NAME + " <username> " + "-" + PASSWORD_INPUT_ARGUMENT_NAME + " <password> " + "-" + INPUT_FILE_INPUT_ARGUMENT_NAME + " <intpuFile>");
        System.out.println("\tu - Windchill username");
        System.out.println("\tp - Windchill username password");
        System.out.println("\ti - path to file with input data");
        System.out.println("\td - path to log directory");
        System.out.println();
    }

    /**
     * Update ibas on source VendorPartMaster.
     *
     * @param ibaHolder
     *            the source VendorPartMaster object
     * @param inputAtts
     *            the input atts
     * @return the updated VendorPartMaster
     * @throws WTException
     *             the WT exception
     * @throws WTPropertyVetoException
     *             the WT property veto exception
     * @throws RemoteException
     *             the remote exception
     */
    private static VendorPartMaster updateIBAS(VendorPartMaster ibaHolder, String[] inputAtts) throws WTException, WTPropertyVetoException, RemoteException, ArrayIndexOutOfBoundsException {
        PersistableAdapter sourceLWC = new PersistableAdapter(ibaHolder, TypeIdentifierUtility.getTypeIdentifier(ibaHolder).toExternalForm(), Locale.US, null);
        Collection<String> ibas = IBAS_TO_UPDATE;
        sourceLWC.load(ibas);

        Iterator<String> iter = ibas.iterator();
        int i = 0;
        while (iter.hasNext()) {
            String attribute = iter.next();
            AttributeTypeSummary s = sourceLWC.getAttributeDescriptor(attribute);
            String s1 = s.getDataType();
            if (s1.contains("Timestamp")) {
                sourceLWC.set(attribute, convertDate(inputAtts[Integer.parseInt(INPUT_ATTS_TO_UPDATE[i])]));
            } else if (s1.contains("FloatingPointWithUnits")) {
                sourceLWC.set(attribute, FloatingPointWithUnits.valueOf(inputAtts[Integer.parseInt(INPUT_ATTS_TO_UPDATE[i])].replace(",", ".") + " EUR"));
            } else {
                if(inputAtts.length>= (Integer.parseInt(INPUT_ATTS_TO_UPDATE[i])+1))
                {	
            	sourceLWC.set(attribute, inputAtts[Integer.parseInt(INPUT_ATTS_TO_UPDATE[i])]);
                }
            }
            i++;
        }

        ibaHolder = (VendorPartMaster) sourceLWC.apply();
        //        updateIBAHolder(ibaHolder);

        return ibaHolder;
    }

    /**
     * Update iba holder.
     *
     * @param ibaholder
     *            the ibaholder
     * @return true, if successful
     */
    public static boolean updateIBAHolder(IBAHolder ibaholder) {
        // NOTE: This method works only at server level, because it uses the
        // PersistenceServerHelper class.
        IBAValueDBService ibavaluedbservice = new IBAValueDBService();
        boolean flag = true;
        try {
            wt.fc.PersistenceServerHelper.manager.update((Persistable) ibaholder);
            AttributeContainer attributecontainer = ibaholder.getAttributeContainer();
            Object obj = ((DefaultAttributeContainer) attributecontainer).getConstraintParameter();
            AttributeContainer attributecontainer1 = ibavaluedbservice.updateAttributeContainer(ibaholder, obj, null, null);
            ibaholder.setAttributeContainer(attributecontainer1);
        } catch (WTException wtexception) {
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("updateIBAHOlder: Couldn't update. " + wtexception);
            }

            flag = false;
        }
        return flag;
    }

    /**
     * Update iba holder.
     *
     * @param ibaholder
     *            the ibaholder
     * @return true, if successful
     */
    public static boolean updateIBAHolders(WTCollection collection) {
        // NOTE: This method works only at server level, because it uses the
        // PersistenceServerHelper class.
        if (collection == null || collection.isEmpty()) {
            return false;
        }
        IBAValueDBService ibavaluedbservice = new IBAValueDBService();
        boolean flag = true;
        try {
            wt.fc.PersistenceServerHelper.manager.update(collection);
            Iterator iter = collection.persistableIterator();
            IBAHolder ibaholder = null;
            while (iter.hasNext()) {
                Object object = iter.next();
                if (object instanceof IBAHolder) {
                    ibaholder = (IBAHolder) object;
                    AttributeContainer attributecontainer = ibaholder.getAttributeContainer();
                    Object obj = ((DefaultAttributeContainer) attributecontainer).getConstraintParameter();
                    AttributeContainer attributecontainer1 = ibavaluedbservice.updateAttributeContainer(ibaholder, obj, null, null);
                    ibaholder.setAttributeContainer(attributecontainer1);
                }

            }

        } catch (WTException wtexception) {
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("updateIBAHOlder: Couldn't update. " + wtexception);
            }

            flag = false;
        }
        return flag;
    }

    /**
     * Log in.
     *
     * @param username
     *            the username
     * @param password
     *            the password
     * @return the remote method server
     * @throws WTException
     *             the WT exception
     */
    public static RemoteMethodServer logIn(String username, String password) throws WTException {
        RemoteMethodServer remotemethodserver = RemoteMethodServer.getDefault();
        remotemethodserver.setUserName(username);
        remotemethodserver.setPassword(password);
        SessionMgr.getPrincipal();
        GatewayAuthenticator auth = new GatewayAuthenticator();
        auth.setRemoteUser(SessionHelper.getPrincipal().getName());
        remotemethodserver.setAuthenticator(auth);
        LOGGER.info("Sucessfully logged to Method Server.");
        return remotemethodserver;
    }

    /**
     * Gets the vendor.
     * 
     * @param part
     *            the part
     *
     * @return the vendor
     * @throws WTException
     *             the WT exception
     * @throws WTPropertyVetoException
     *             the WT property veto exception
     */
    public static Vendor getVendor(VendorPart part) throws WTException, WTPropertyVetoException {
        Vendor vend = com.ptc.windchill.suma.supplier.SupplierHelper.service.getVendor(part.getOrganization(), part.getContainer().getContainer());
        return vend;
    }

    /**
     * Convert date.
     *
     * @param dateInFileBeforeConversion
     *            the date in file before conversion
     * @return the timestamp
     */
    private static Timestamp convertDate(String dateInFileBeforeConversion) {
        if (dateInFileBeforeConversion == null)
            return null;

        DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
        try {
            Date dateInFile = (Date) dateFormat.parse(dateInFileBeforeConversion);
            Timestamp stamp = new Timestamp(dateInFile.getTime());
            return stamp;
        } catch (Exception exception) {
            LOGGER.trace("Error while processing " + dateInFileBeforeConversion);
        }

        return null;
    }

    private static File getBadRecordsFile(String logDir) {
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        String[] filenames = null;
        String filename = null;
        String extension = null;
        if (BAD_FILE_NAME.contains(".")) {
            filenames = BAD_FILE_NAME.split("\\.");
            filename = filenames[0];
            extension = filenames[1];
        } else {
            filename = BAD_FILE_NAME;
            extension = "";
        }
        File file = new File(logDir + File.separator + filename + timestamp.toString() + "." + extension);
        
        if (file.exists()) {
            file.delete();
        }
        try {
            file.createNewFile();
            file.setExecutable(true, false);
            file.setReadable(true, false);
            file.setWritable(true, false);
        } catch (IOException e) {
            LOGGER.error("Error during Bad Records File creation");
        }
        return file;
    }

    private static File getDetailLogFile(String logDir) {
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        String[] filenames = null;
        String filename = null;
        String extension = null;
        if (LOG_FILE_NAME.contains(".")) {
            filenames = LOG_FILE_NAME.split("\\.");
            filename = filenames[0];
            extension = filenames[1];
        } else {
            filename = LOG_FILE_NAME;
            extension = "";
        }
        File file = new File(logDir + File.separator + filename + timestamp.toString() + "." + extension);
        
        if (file.exists()) {
            file.delete();
        }
        try {
            file.createNewFile();
            file.setExecutable(true, false);
            file.setReadable(true, false);
            file.setWritable(true, false);
           
        } catch (IOException e) {
            LOGGER.error("Error during Log File creation");
        }
        return file;
    }

    private static File createCompleteLogFile(String logDir) {
        File file = isCompleteFileExist(logDir);
        
        try {
            file.createNewFile();
            file.setExecutable(true, false);
            file.setReadable(true, false);
            file.setWritable(true, false);
            
        } catch (IOException e) {
            LOGGER.error("Error during Bad Records File creation");
        }
        return file;
    }

    public static File isCompleteFileExist(String logDir) {
        String[] filenames = null;
        String filename = null;
        String extension = null;
        if (COST_UPDATE_COMPLETED_FILE.contains(".")) {
            filenames = COST_UPDATE_COMPLETED_FILE.split(".");
            filename = filenames[0];
            extension = filenames[1];
        } else {
            filename = COST_UPDATE_COMPLETED_FILE;
            extension = "";
        }
        if (!extension.equals("")) {
            extension = "." + extension;
        }
        File file = new File(logDir + File.separator + filename + extension);
        if (file.exists()) {
            file.delete();
        }
        return file;
    }

}
