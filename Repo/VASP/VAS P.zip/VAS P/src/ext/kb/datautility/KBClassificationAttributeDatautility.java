package ext.kb.datautility;

import java.util.Collection;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.ptc.core.components.descriptor.ComponentDescriptor;
import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.dataUtilities.DefaultDataUtility;
import com.ptc.core.components.rendering.guicomponents.AttributeInputCompositeComponent;
import com.ptc.core.components.rendering.guicomponents.ComboBox;
import com.ptc.core.components.rendering.guicomponents.MultiValuedInputComponent;
import com.ptc.core.components.rendering.guicomponents.StringInputComponent;
import com.ptc.core.components.util.OidHelper;
import com.ptc.core.lwc.common.AttributeTemplateFlavor;
import com.ptc.core.lwc.common.view.AttributeDefaultValueReadView;
import com.ptc.core.lwc.common.view.AttributeDefinitionReadView;
import com.ptc.core.lwc.common.view.TypeDefinitionReadView;
import com.ptc.core.lwc.server.TypeDefinitionServiceHelper;
import com.ptc.core.meta.type.common.TypeInstance;
import com.ptc.generic.iba.AttributeService;
import com.ptc.windchill.csm.common.CsmConstants;

import ext.kb.util.KBConstants;
import ext.kb.util.KBTeamUtils;
import ext.kb.util.KBUtils;
import wt.access.NotAuthorizedException;
import wt.fc.ObjectVector;
import wt.fc.ReferenceFactory;
import wt.inf.container.WTContainerException;
import wt.inf.container.WTContainerRef;
import wt.inf.team.ContainerTeam;
import wt.inf.team.ContainerTeamHelper;
import wt.inf.team.ContainerTeamManaged;
import wt.log4j.LogR;
import wt.org.OrganizationServicesHelper;
import wt.org.WTGroup;
import wt.org.WTPrincipal;
import wt.org.WTPrincipalReference;
import wt.project.Role;
import wt.project._Role;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.vc.wip.WorkInProgressHelper;
import wt.vc.wip.Workable;

public class KBClassificationAttributeDatautility extends DefaultDataUtility {
	protected static final Logger LOGGER = LogR.getLogger(KBClassificationAttributeDatautility.class.getName());
	private final static String CONTAINER_OID = "ContainerOid";
	public static final Role CLASSIFICATION_LIBRARY_MANAGER = Role.toRole("CLASSIFICATION_LIBRARY_MANAGER");
	private final static String KB_EKLA_ID = "WCTYPE|wt.part.WTPart|com.ptc.KBArticle|com.ptc.KBAssyComp|com.ptc.KBAssemblyComponent~IBA|KB_EKLA";
	private final static String KB_GROUP = "WCTYPE|wt.part.WTPart|com.ptc.KBArticle|com.ptc.KBAssyComp|com.ptc.KBAssemblyComponent~IBA|KB_GROUP";

	@Override
	public Object getDataValue(String paramString, Object paramObject, ModelContext paramModelContext)
			throws WTException {
		LOGGER.debug("entering getDataValue()");
		LOGGER.debug("isEditMode :  " + KBUtils.isEditMode(paramModelContext.getDescriptorMode()));
		LOGGER.debug("isCreateMode :  " + KBUtils.isCreateMode(paramModelContext.getDescriptorMode()));
		LOGGER.debug(OidHelper.getPersistable(paramObject));
		if (KBUtils.isEditMode(paramModelContext.getDescriptorMode())
				|| KBUtils.isCreateMode(paramModelContext.getDescriptorMode())) {
			ComponentDescriptor compdes = paramModelContext.getParentDescriptor();
			List list = compdes.getDescriptors();
			String classificationnode = "";
			for (int i = 0; i < list.size(); i++) {
				ComponentDescriptor compdes1 = (ComponentDescriptor) list.get(i);
				classificationnode = compdes1.getId();

			}

			LOGGER.debug(super.getDataValue(paramString, paramObject, paramModelContext).getClass().getName());
			AttributeInputCompositeComponent component = (AttributeInputCompositeComponent) super.getDataValue(
					paramString, paramObject, paramModelContext);
			LOGGER.debug("Component name :: " + component + " :: component name ::" + component.getName() + " :: ID ::"
					+ component.getId());

			LOGGER.debug("paramString :: " + paramString + "\nparamModelContext :: " + paramModelContext);
			LOGGER.debug("Component :: " + paramString + " :: Is nmultivalued::"
					+ component.getValueInputComponent().isMultiValued() + "\n"
					+ component.getValueInputComponent().getDefaultValue() + "\nRawvalue :: "
					+ component.getValueInputComponent().getRawValue());
			LOGGER.debug(component.getValueInputComponent().getDefaultValue());
			component.getValueInputComponent().setEditable(false);
			component.setReadOnly(true);

			LOGGER.debug("component readonly :: " + component.isReadOnly());
			LOGGER.debug("Component editable to false :: " + component.getValueInputComponent().isEditable());
			WTContainerRef containerRef = getContainerReference(paramModelContext);
			LOGGER.debug("Container Name : " + containerRef.getContainer().getOrganizationName());
			boolean isuserclasslibrarymanager = isUserLibraryManager(containerRef);
			String org = containerRef.getContainer().getOrganizationName();
			LOGGER.debug("isuserlibrarymanager :: >>" + isuserclasslibrarymanager);
			LOGGER.debug("IsorgHvac :: " + org.equalsIgnoreCase(KBConstants.HVAC));
			boolean attributechkfornonlibrarymanager = !isuserclasslibrarymanager && org.equalsIgnoreCase(KBConstants.HVAC);
	
			System.out.println("Is checked out :: "
					+ WorkInProgressHelper.isCheckedOut((Workable) OidHelper.getPersistable(paramObject)));
			Object classificationAttribute1 = null;
			String originalobjgrp = "";
			String attrid = component.getId();
			String attributename = attrid.substring(attrid.lastIndexOf("|") + 1, attrid.length());
			LOGGER.debug("attributename :: " + attributename);
			if (WorkInProgressHelper.isCheckedOut((Workable) OidHelper.getPersistable(paramObject))) {

				Workable originalobj = WorkInProgressHelper.service
						.originalCopyOf((Workable) OidHelper.getPersistable(paramObject));
				classificationAttribute1 = AttributeService.getAttribute(originalobj, "KB_CSM_PART_CLASSIFICATION");
				if(attributename.equalsIgnoreCase("KB_EKLA") || attributename.equalsIgnoreCase("KB_GROUP")) {
				originalobjgrp = AttributeService.getAttribute(originalobj, attributename);
				LOGGER.debug("originalobjgrp :: " + originalobjgrp);
				}

			}
			LOGGER.debug("classificationnode :: "+classificationnode +"\nclassificationAttribute1  :: >>"+classificationAttribute1);
			if (attributechkfornonlibrarymanager) {
				LOGGER.debug("Inside eklacheckoncreate for ekla");
				if (KBUtils.isCreateMode(paramModelContext.getDescriptorMode())) {
					DataUtilityHelper.setEditableFieldOnComponent(component, false);
					ComboBox cb = new ComboBox();
					LOGGER.debug("cb.setEnabled" + cb.isEnabled());
					cb.setReadOnly(true);
					LOGGER.debug("cb.setReadOnly(true)");
					cb.setColumnName(component.getColumnName());
					LOGGER.debug("component.getColumnName()");
					cb.setLabel(component.getLabel());
					LOGGER.debug("component.getLabel()");
					String defaultvalue = getAttrDefaultValue(classificationnode, component.getId());
					LOGGER.debug("defaultvalue :: " + defaultvalue);

					if (defaultvalue != null) {
						cb.setValue(defaultvalue);
					} else {
						cb.setValue("");
					}
					return cb;
				}
				if (KBUtils.isEditMode(paramModelContext.getDescriptorMode()) && (component.getId().equals(KB_EKLA_ID) || component.getId().equals(KB_GROUP))) {
					DataUtilityHelper.setEditableFieldOnComponent(component, false);
					ComboBox cb = new ComboBox();

					LOGGER.debug("cb.setEnabled" + cb.isEnabled());
					cb.setReadOnly(true);
					LOGGER.debug("cb.setReadOnly(true)");
					cb.setColumnName(component.getColumnName());
					LOGGER.debug("component.getColumnName()");
					cb.setLabel(component.getLabel());
					LOGGER.debug("component.getLabel()");
					String defaultvalue = getAttrDefaultValue(classificationnode, component.getId());

					if(classificationAttribute1 != null
							&& classificationAttribute1.toString().equalsIgnoreCase(classificationnode)) {
						cb.setValue(originalobjgrp);
						if (originalobjgrp == null) {
							System.out.println("originalobjgrp==null");
							cb.setValue("");
						}
						return cb;
					}else {
						System.out.println("edit && notequal && attrname");
						if (defaultvalue != null) {
							cb.setValue(defaultvalue);
						} else {
							cb.setValue("");
						}
						return cb;
					}
					
				}
			}

			if (isuserclasslibrarymanager && org.equalsIgnoreCase(KBConstants.HVAC)) {
				LOGGER.debug("isuserclasslibrarymanager inside");
				LOGGER.debug("Component editable :: " + component.getValueInputComponent().isEditable());
				Object object=super.getDataValue(paramString, paramObject, paramModelContext);
				LOGGER.debug("Object class :: "+ (object instanceof AttributeInputCompositeComponent));
				LOGGER.debug("paramObject class :: "+(paramObject instanceof TypeInstance));
				if(component.getId().equals(KB_EKLA_ID) || component.getId().equals(KB_GROUP)) {
				if (object instanceof AttributeInputCompositeComponent && paramObject instanceof TypeInstance) {
					TypeInstance typeInstance = (TypeInstance) paramObject;
					AttributeInputCompositeComponent attributeInputCompositeComponent = (AttributeInputCompositeComponent) object;
					StringInputComponent attributeInputComponent = (StringInputComponent) attributeInputCompositeComponent.getValueInputComponent();
					if (classificationAttribute1 != null
							&& classificationAttribute1.toString().equalsIgnoreCase(classificationnode)) {
						attributeInputComponent.setDefaultValue(originalobjgrp);
					}
					else {
					String value=getAttrDefaultValue(classificationnode, attributename);
					LOGGER.debug("Defaultvalue object :: "+value+":: value :: "+attributeInputComponent.getValue()+ ":: Internalvalue string ::"+attributeInputComponent.getInternalValueString());
					attributeInputComponent.setValue(value);
					
					}
					attributeInputCompositeComponent.setValueInputComponent(attributeInputComponent);
					return attributeInputCompositeComponent;
				}
				}
				component.getValueInputComponent().setEditable(true);
				component.setReadOnly(false);

			} else {
				if (component.getValueInputComponent().isMultiValued()) {
					if(classificationAttribute1 != null && !classificationAttribute1.toString().equalsIgnoreCase(classificationnode)) {
						LOGGER.debug("notequal && !attrname" + !attributename.equals("KB_HVAC_PROC_SITES"));
						
						ComboBox cb = new ComboBox();

						LOGGER.debug("cb.setEnabled" + cb.isEnabled());
						cb.setReadOnly(true);
						LOGGER.debug("cb.setReadOnly(true)");
						cb.setColumnName(component.getColumnName());
						LOGGER.debug("component.getColumnName()");
						cb.setLabel(component.getLabel());
						LOGGER.debug("component.getLabel()");
						String defaultvalue = getAttrDefaultValue(classificationnode, component.getId());
						if (defaultvalue != null) {
							cb.setValue(defaultvalue);
						} else {
							cb.setValue("");
						}
							return cb;
						

					}
					else {
					LOGGER.debug("Is nultivalued");
					LOGGER.debug(component.getValueInputComponent().getClass().getName());
					MultiValuedInputComponent multicomp = (MultiValuedInputComponent) component
							.getValueInputComponent();
					multicomp.getMinusButton().setReadOnly(true);
					LOGGER.debug("pbutton Set to readonly");
					multicomp.getMinusButton().setEditable(false);
					LOGGER.debug("mbutton Set to readonly");
					multicomp.getPlusButton().setReadOnly(true);
					multicomp.getPlusButton().setEditable(false);
					multicomp.setReadOnly(true);
					multicomp.setEditable(false);

					return multicomp;
					}
				}

			}
		}

		return super.getDataValue(paramString, paramObject, paramModelContext);
	}

	public static boolean isUserInRole(WTPrincipal user, ContainerTeamManaged container, Role role) throws WTException {
		ContainerTeam containerTeam = ContainerTeamHelper.service.getContainerTeam(container);

		ObjectVector objectvector = new ObjectVector();
		if (containerTeam == null) {
			return false;
		}
		Map<?, ?> map = containerTeam.getRolePrincipalMap();
		findContainerTeamPrincipals(map, "roleGroups", objectvector, true);
		Enumeration<WTGroup> roleGroups = objectvector.elements();
		return hasRole(roleGroups, user, role);

	}

	private static void findContainerTeamPrincipals(Map<?, ?> map, String group, ObjectVector objectvector,
			boolean flag) throws WTException {
		Role role = _Role.toRole(group);
		List<?> list = (List<?>) map.get(role);
		if ((list != null) && (list.size() > 0)) {
			WTPrincipalReference wtprincipalreference = (WTPrincipalReference) list.get(0);
			if (flag) {
				WTPrincipal wtprincipal = wtprincipalreference.getPrincipal();
				Enumeration<?> enumeration = OrganizationServicesHelper.manager.members((WTGroup) wtprincipal, false);
				while (enumeration.hasMoreElements()) {
					objectvector.addElement(enumeration.nextElement());
				}
			} else {
				objectvector.addElement(wtprincipalreference.getPrincipal());
			}
		}
	}

	public static boolean hasRole(Enumeration<WTGroup> roleGroups, WTPrincipal user, Role role) throws WTException {
		while (roleGroups.hasMoreElements()) {
			WTGroup group = (WTGroup) roleGroups.nextElement();
			if (role.equals(_Role.toRole(group.getName()))) {
				return group.isMember(user);
			}
		}
		return false;
	}

	private WTContainerRef getContainerReference(ModelContext modelContext) throws WTException {
		WTContainerRef containerRef = modelContext.getNmCommandBean().getContainerRef();
		if (containerRef == null)
			containerRef = (WTContainerRef) new ReferenceFactory()
					.getReference(modelContext.getNmCommandBean().getRequest().getParameter(CONTAINER_OID));
		return containerRef;
	}

	private boolean isUserLibraryManager(WTContainerRef containerRef) throws WTException {
		return KBTeamUtils.isUserInRole(SessionHelper.getPrincipal(),
				(ContainerTeamManaged) containerRef.getReferencedContainer(), CLASSIFICATION_LIBRARY_MANAGER);
	}

	private String getAttrDefaultValue(String nodeid, String attrid)
			throws NotAuthorizedException, WTContainerException, WTException {
		LOGGER.debug("Inside getAttrDefaultValue :: Node :: " + nodeid + " :: attrid ::" + attrid);
		String defaultvalue = "";
		String attributename = attrid.substring(attrid.lastIndexOf("|") + 1, attrid.length());
		LOGGER.debug("attributename :: " + attributename);
		TypeDefinitionReadView localTypeDefinitionReadView = TypeDefinitionServiceHelper.service
				.getTypeDefView(AttributeTemplateFlavor.LWCSTRUCT, CsmConstants.NAMESPACE, nodeid);

		if (localTypeDefinitionReadView != null) {
			LOGGER.debug("Inside localTypeDefinitionReadView");

			AttributeDefinitionReadView readview = localTypeDefinitionReadView.getAttributeByName(attributename);
			Collection<AttributeDefaultValueReadView> collection = readview.getAllDefaultValues();
			LOGGER.debug("Collection size :: " + collection.size());
			Iterator<AttributeDefaultValueReadView> it1 = collection.iterator();

			while (it1.hasNext()) {

				Object object1 = (Object) it1.next();
				AttributeDefaultValueReadView adv = (AttributeDefaultValueReadView) object1;
				LOGGER.debug("default value id:: " + adv.getScreenName());
				LOGGER.debug("default value :: " + adv.getValue());
				defaultvalue = (String) adv.getValue();
			}
		}
		return defaultvalue;
	}

}
