package ext.kb.datautility;

import org.apache.log4j.Logger;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.dataUtilities.DefaultDataUtility;
import com.ptc.core.components.rendering.guicomponents.AttributeInputCompositeComponent;
import com.ptc.core.components.rendering.guicomponents.StringInputComponent;
import ext.kb.util.KBUtils;
import wt.inf.container.WTContainerHelper;
import wt.inf.container.WTContainerRef;
import wt.log4j.LogR;
import wt.org.WTUser;
import wt.preference.PreferenceClient;
import wt.preference.PreferenceHelper;
import wt.session.SessionHelper;
import wt.util.WTException;

public class KBDefaultCurrencyDataUtility extends DefaultDataUtility {
	
	private static final String CLASSNAME = KBDefaultCurrencyDataUtility.class.getName();
	protected static final Logger LOGGER = LogR.getLogger(CLASSNAME);

		@Override
		public Object getDataValue(String paramString, Object paramObject,
				ModelContext paramModelContext) throws WTException {
			if (LOGGER.isDebugEnabled()){
				LOGGER.debug("datautility starts... " + paramString + "-" + paramModelContext.getDescriptorMode().toString());
			}
			Object result = super.getDataValue(paramString, paramObject, paramModelContext);
			
				AttributeInputCompositeComponent inputComponent = (AttributeInputCompositeComponent)  result;
				StringInputComponent vInputComp = (StringInputComponent) inputComponent.getValueInputComponent();
				String currency = null;
				currency = KBUtils.getCurrencyPreference();
				vInputComp.setDefaultValue(currency);
				inputComponent.setValueInputComponent(vInputComp);
				if (LOGGER.isDebugEnabled()){
					LOGGER.debug("datautility defaultValue is set to " + inputComponent.getValueInputComponent().getDefaultValue());
				}
				
			if (LOGGER.isDebugEnabled()){
				LOGGER.debug("datautility ended");
			}
			return result;
		}
	
}
