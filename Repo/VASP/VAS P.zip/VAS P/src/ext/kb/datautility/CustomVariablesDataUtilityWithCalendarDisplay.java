package ext.kb.datautility;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import wt.fc.EnumeratedType;
import wt.org.WTPrincipal;
import wt.session.SessionServerHelper;
import wt.util.WTException;
import wt.util.WTRuntimeException;
import wt.workflow.definer.WfAssignedActivityTemplate;
import wt.workflow.definer.WfVariableInfo;
import wt.workflow.engine.ProcessData;
import wt.workflow.engine.WfActivity;
import wt.workflow.engine.WfVariable;
import wt.workflow.work.WorkItem;
import wt.workflow.worklist.WfTaskProcessor;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.AbstractDataUtility;
import com.ptc.core.components.rendering.AbstractGuiComponent;
import com.ptc.core.components.rendering.guicomponents.ComboBox;
import com.ptc.core.components.rendering.guicomponents.DateInputComponent;
import com.ptc.core.components.rendering.guicomponents.GUIComponentArray;
import com.ptc.core.components.rendering.guicomponents.StringInputComponent;
import com.ptc.core.components.rendering.guicomponents.TextDisplayComponent;
import com.ptc.core.meta.type.common.TypeInstance;
import com.ptc.windchill.enterprise.workitem.ComponentId;
import com.ptc.windchill.enterprise.workitem.dataUtilities.CustomVariablesDataUtility;

import ext.kb.rendering.guicomponent.KBDateInputComponent;
import ext.kb.util.KBUtils;

public final class CustomVariablesDataUtilityWithCalendarDisplay extends AbstractDataUtility {

    public static final String WIDTH_HEIGHT = "width_height";
    public static final String WIDTH = "width";
    public static final String HEIGHT = "height";
    public static final int TRUNCATION_LENGTH = 0;

    private static final String DATE_PICKER_PROPERTY = "wt.workflow.displayDatePicker";
    private static final String NAME_FIX = "CustActVar";

    // private static final Logger LOGGER =
    // LogR.getLogger(CustomVariablesDataUtilityWithCalendarDisplay.class.getName());

    private WorkItem workItem;
    private WfTaskProcessor wfTaskProcessor;

    private CustomVariablesDataUtility parentDataUtil;

    public CustomVariablesDataUtilityWithCalendarDisplay() {
        this.wfTaskProcessor = new WfTaskProcessor();
        parentDataUtil = new CustomVariablesDataUtility();
    }

    public final Object getDataValue(String paramString, Object paramObject, ModelContext paramModelContext) throws WTException {

        parentDataUtil.getDataValue(paramString, paramObject, paramModelContext);// need
                                                                                 // to
                                                                                 // call
                                                                                 // parent
                                                                                 // util
                                                                                 // to
                                                                                 // register
                                                                                 // WF
        if (paramObject instanceof TypeInstance) {
            paramObject = paramModelContext.getNmCommandBean().getPageOid().getRefObject();
        }

        if (!DataUtilityHelper.isValidObjectType(WorkItem.class, paramObject.getClass(), this)) {
            return TextDisplayComponent.NBSP;
        }

        this.workItem = (WorkItem) paramObject;
        this.wfTaskProcessor.setWorkItem(this.workItem);

        String displayDatePicker = DataUtilityHelper.getProperty(DATE_PICKER_PROPERTY);

        // If an attribute needs to be ignored the parent class will already
        // have removed that
        GUIComponentArray array = (GUIComponentArray) parentDataUtil.getDataValue(paramString, paramObject,
                paramModelContext);

        if (KBUtils.isEmpty(displayDatePicker)) {
            return array;
        }

        Set<String> dateFields = KBUtils.split(displayDatePicker);

        WfActivity wfActivity = this.wfTaskProcessor.getActivity();
        ProcessData processData = wfActivity.getContext();
        if ((this.workItem.getContext() == null) || (this.wfTaskProcessor.getWorkItem().getContext() == null)) {
            processData = wfActivity.getContext();
        } else {
            processData = this.workItem.getContext();
        }

        Map<String, WfVariableInfo> variables = getVariables(wfActivity);

        return createComponentArray(dateFields, processData, variables, array);
    }

    protected String getVariableName(String param) {
        return NAME_FIX + param + NAME_FIX;
    }

    protected Map<String, WfVariableInfo> getVariables(WfActivity wfActivity) {
        boolean bool1 = SessionServerHelper.manager.setAccessEnforced(false);
        WfAssignedActivityTemplate wfTemplate;
        try {
            wfTemplate = (WfAssignedActivityTemplate) wfActivity.getTemplate().getObject();
        } catch (WTRuntimeException localWTRuntimeException) {
            throw localWTRuntimeException;
        } finally {
            SessionServerHelper.manager.setAccessEnforced(bool1);
        }

        Map<String, WfVariableInfo> variables = new HashMap<String, WfVariableInfo>();

        for (WfVariableInfo variable : wfTemplate.getContextSignature().getVariableList()) {
            variables.put(getVariableName(variable.getName()), variable);
        }

        return variables;
    }

    protected GUIComponentArray createComponentArray(Set<String> dateFields, ProcessData processData,
            Map<String, WfVariableInfo> variables, GUIComponentArray array) {

        GUIComponentArray newArray = new GUIComponentArray();
        newArray.setId(ComponentId.WORKITEM_CUSTOMVARIABLE.getId());
        for (int i = 0; i < array.size(); i++) {
            AbstractGuiComponent comp = (AbstractGuiComponent) array.get(i);

            String name = comp.getName();
            if (!variables.containsKey(name) || variables.get(name).isReadOnly()) {
                newArray.addGUIComponent(comp);

            } else if (dateFields.contains(processData.getVariable(variables.get(comp.getName()).getName()).getTypeName()) // type
                                                                                                                           // based
                                                                                                                           // check,
                                                                                                                           // like
                                                                                                                           // java.util.Date
                    || dateFields.contains(processData.getVariable(variables.get(comp.getName()).getName()).getName())) { // field
                                                                                                                          // name
                                                                                                                          // based
                                                                                                                          // check,
                                                                                                                          // like
                                                                                                                          // confirmed_date
                StringInputComponent formerInput = (StringInputComponent) comp;

                newArray.addGUIComponent(createDateBox(formerInput.getName(), formerInput.getColumnName(),
                        formerInput.getId(), processData.getVariable(variables.get(comp.getName()).getName()),
                        formerInput.isRequired()));
            } else {
                newArray.addGUIComponent(comp);

            }
        }

        newArray.setRequired(false);
        return newArray;
    }

    protected AbstractGuiComponent createDateBox(String name, String columnName, String id, WfVariable var, boolean required) {
        KBDateInputComponent comp = new KBDateInputComponent(name, DateInputComponent.ValueType.DATE_ONLY);
        comp.setName(name);
        comp.setId(id);
        comp.setValue((java.util.Date) var.getValue());
        comp.setReadOnly(false);
        comp.setRenderLabel(false);
        comp.setRequired(required);
        return comp;
    }

    public final String getLabel(String paramString, ModelContext paramModelContext) throws WTException {
        return parentDataUtil.getLabel(paramString, paramModelContext);
    }

    public ComboBox enumeratedTypeSelector(Class paramClass, EnumeratedType paramEnumeratedType, String paramString1,
            String paramString2, Locale paramLocale, GUIComponentArray paramGUIComponentArray) {
        return parentDataUtil.enumeratedTypeSelector(paramClass, paramEnumeratedType, paramString1, paramString2,
                paramLocale, paramGUIComponentArray);
    }

    public AbstractGuiComponent principalSelector(String paramString1, WTPrincipal paramWTPrincipal, String paramString2,
            String paramString3, GUIComponentArray paramGUIComponentArray) throws WTException {
        return parentDataUtil.principalSelector(paramString1, paramWTPrincipal, paramString2, paramString3,
                paramGUIComponentArray);
    }
}
