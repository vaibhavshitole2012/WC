/**
 * 
 */
package ext.kb.datautility;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.dataUtilities.DefaultDataUtility;
import com.ptc.core.components.factory.dataUtilities.NameDataUtility;
import com.ptc.core.components.rendering.guicomponents.AttributeDisplayCompositeComponent;
import com.ptc.core.components.rendering.guicomponents.NumberInputComponent;
import com.ptc.core.components.rendering.guicomponents.TextDisplayComponent;

import ext.kb.util.KBTypeIdProvider;
import wt.doc.WTDocument;
import wt.util.WTException;

/**
 * @author bankowskie
 *
 */
public class KBDocumentNameDataUtility extends NameDataUtility{
	
	@Override
	public Object getDataValue(String paramString, Object paramObject, ModelContext paramModelContext) throws WTException {
		Object result = super.getDataValue(paramString, paramObject, paramModelContext);
		if (paramModelContext.getDescriptorMode() == com.ptc.core.ui.resources.ComponentMode.CREATE) {
			boolean isRefDoc = KBTypeIdProvider.isDescendant(paramObject, "REFDOC");
			boolean isKbDoc = KBTypeIdProvider.isDescendant(paramObject, "KBDOC");
			if(isKbDoc || isRefDoc) {
				return new TextDisplayComponent(paramString, "(Generated)");
				
			}
		}
		return result;
	}

}
