package ext.kb.datautility;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import wt.iba.value.IBAHolder;
import wt.log4j.LogR;
import wt.util.WTException;

import com.ptc.KBNameCatalogueEntry;
import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.dataUtilities.DefaultDataUtility;
import com.ptc.core.components.rendering.guicomponents.AttributeGuiComponent;
import com.ptc.core.components.rendering.guicomponents.PickerInputComponent;
import com.ptc.core.components.rendering.guicomponents.TextDisplayComponent;
import com.ptc.core.lwc.common.view.AttributeDefinitionReadView;
import com.ptc.core.lwc.common.view.ConstraintDefinitionReadView;
import com.ptc.core.lwc.common.view.ConstraintRuleDefinitionReadView;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.container.common.impl.ValueRequiredConstraint;

import ext.kb.dynamiclist.CatalogueContainer;
import ext.kb.dynamiclist.naming.NameCatalogueEnumerationInfoProvider;
import ext.kb.resources.NameCatalogueRB;
import ext.kb.util.IBAHelper;
import ext.kb.util.KBConstants;
import ext.kb.util.KBTypeIdProvider;
import ext.kb.util.KBUtils;

public class CatalogueDynamicListItemPickerDataUtility extends EditArticleAttributesDataUtility {


    protected static final Logger LOGGER = LogR.getLogger(CatalogueDynamicListItemPickerDataUtility.class.getName());
    
    protected static final String PICKER_PROPERTY = "ext.kb.catalogue.picker";
    static final String RESOURCE = NameCatalogueRB.class.getName();
    private static final String NUMBER = "number";
//    private static String CONTAINER_REF;
//
//    public DynamicListItemPickerDataUtility() {
//        super();
//        try {
//            ObjectIdentifier oi = (ObjectIdentifier) DBUtils.getCorporateStandardsLibrary().getKey();
//            CONTAINER_REF = oi.getStringValue();
//        } catch (WTException e) {
//            LOGGER.error("Caught exception while setting library reference", e);
//        }
//    }

    private NameCatalogueEnumerationInfoProvider suggestionProvider = new NameCatalogueEnumerationInfoProvider();

    @Override
	public Object getDataValue(String paramString, Object paramObject, ModelContext paramModelContext)
			throws WTException {
		// TODO Auto-generated method stub
		return super.getDataValue(paramString, paramObject, paramModelContext);
	}

	@Override
    public Object getDataValueInternal(String paramString, Object paramObject, ModelContext paramModelContext) throws WTException {
        
        Object uiComponent= new DefaultDataUtility().getDataValue(paramString, paramObject, paramModelContext);
        
        LOGGER.debug("uiComponent: "+uiComponent);
        
        if (uiComponent instanceof AttributeGuiComponent){
        
			        AttributeGuiComponent defaultComponent = (AttributeGuiComponent) uiComponent;
			        String dynamicListItemPickers = DataUtilityHelper.getProperty(PICKER_PROPERTY);
			
			        TypeIdentifier targetType = wt.type.TypedUtilityServiceHelper.service.getTypeIdentifier(paramObject);
			        boolean isArticle = targetType.isDescendedFrom(KBTypeIdProvider.getType("ARTICLE"));
			        boolean isCad = targetType.isDescendedFrom(KBTypeIdProvider.getType("CADDOC"));
			        boolean isDoc = targetType.isDescendedFrom(KBTypeIdProvider.getType("KBDOC"));
			        boolean isRefDoc = targetType.isDescendedFrom(KBTypeIdProvider.getType("REFDOC"));
			        if (isArticle || isCad || isDoc || isRefDoc) {
			
			            if (paramModelContext.getDescriptorMode() == com.ptc.core.ui.resources.ComponentMode.VIEW) {
			            	String translationId = IBAHelper.getStringIBAValue((IBAHolder) paramObject, KBConstants.TRANSLATION_ID_IBA);
			            	String displayValue = "";
			            	if (!KBUtils.isEmpty(translationId)) {
			            		List<CatalogueContainer> entries = suggestionProvider.loadCatalogue("location.nameCatalogue", "nameCatalogues", "sourceLanguage");
			            		for (CatalogueContainer cont : entries) {
				                    String key = cont.getKey();
				                    if (translationId.equals(key)) {
				                    	displayValue = cont.getDescription();
				                    }
				                }
							}
			                return new TextDisplayComponent(paramString, displayValue);
			            } else {
			                if (KBUtils.isEmpty(dynamicListItemPickers)) {
			                    return TextDisplayComponent.NBSP;
			                }
			                String[] dynamicPickers = dynamicListItemPickers.split(",");
			                AttributeDefinitionReadView rv = IBAHelper.getAttributeDefinitionReadView(targetType.getTypename(),
			                        KBConstants.TRANSLATION_ID_IBA);
			                Collection<ConstraintDefinitionReadView> rest = rv.getAllConstraints();
			                boolean required = false;
			                for (ConstraintDefinitionReadView v : rest) {
			                    ConstraintRuleDefinitionReadView rule = v.getRule();
			                    if (ValueRequiredConstraint.class.getName().equals(rule.getRuleClassname())) {
			                        required = true;
			                        break;
			                    }
			                }
			                PickerInputComponent field = new PickerInputComponent(defaultComponent.getColumnName(), "",
			                        getPickerConfigs(dynamicPickers[0], dynamicPickers[1], required));
			                field.setRequired(required);
			                field.setColumnName(defaultComponent.getColumnName());
			                if (paramModelContext.getDescriptorMode() == com.ptc.core.ui.resources.ComponentMode.EDIT) {
			                    field.setValue(IBAHelper.getStringIBAValue((IBAHolder) paramModelContext.getNmCommandBean().getPageOid()
			                            .getRefObject(), KBConstants.TRANSLATION_ID_IBA));
			                }
			                defaultComponent = field;
			            }
			        }
			        return defaultComponent;
			      } else {
			      	 
			      	 return uiComponent;
			      	 
			      }
    }

    protected static Map<String, String> getPickerConfigs(String id, String objectType, boolean isRequired) {
        Map<String, String> configs = new HashMap<String, String>();
        // default settings
        configs.put("pickerType", "search");
        if (isRequired)
            configs.put("required", Boolean.TRUE.toString());
        else
            configs.put("required", Boolean.FALSE.toString());
        configs.put("width", "40");
        configs.put("showSuggestion", Boolean.TRUE.toString());
        configs.put("suggestMinChars", "2");
        // mapping to mapping settings
        configs.put("typeComponentId", "Foundation.cataloguePickerComponentId");
        configs.put("componentId", "cataloguePicker");
        configs.put("suggestServiceKey", "cataloguePicker");
        configs.put("pickerCallback", "cataloguePickerCallback");
//        configs.put("sourceLanguage", "");
        configs.put("displayAttribute", KBNameCatalogueEntry.SOURCE_LANGUAGE);
        configs.put("pickedAttributes", KBNameCatalogueEntry.SOURCE_LANGUAGE);
        configs.put("searchResultsViewId", "com.ptc.KBNameCatalogueEntry.customSearchView"); 
        // parameter based settings
        configs.put("objectType", objectType);
        configs.put("pickerId", id);
        configs.put("pickerTitle", "Naming Catalogue");
        return configs;
    }

}
