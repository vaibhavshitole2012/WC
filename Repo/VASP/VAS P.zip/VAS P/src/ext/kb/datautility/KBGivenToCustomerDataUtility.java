package ext.kb.datautility;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.dataUtilities.DefaultDataUtility;
import com.ptc.core.components.rendering.guicomponents.AttributeInputCompositeComponent;
import com.ptc.core.components.rendering.guicomponents.StringInputComponent;
import com.ptc.core.components.util.OidHelper;
import com.ptc.generic.iba.AttributeService;
import ext.kb.util.KBConstants;
import ext.kb.util.KBDocumentUtils;
import ext.kb.util.KBTeamUtils;
import ext.kb.util.KBUtils;
import ext.kb.util.ObjectRevisionHelper;
import java.util.ArrayList;
import java.util.TreeMap;
import org.apache.log4j.Logger;
import wt.doc.WTDocument;
import wt.fc.ReferenceFactory;
import wt.inf.container.WTContainerHelper;
import wt.inf.container.WTContainerRef;
import wt.inf.team.ContainerTeamManaged;
import wt.lifecycle.State;
import wt.log4j.LogR;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.vc.wip.WorkInProgressHelper;

public class KBGivenToCustomerDataUtility extends DefaultDataUtility {

	private static final String HAS_TO_BE_CHECKED_ATTR_VALUE = "3";
    private final static String CONTAINER_OID = "ContainerOid";
    private static final String INPUT_COMPONENT_LABEL = "Customer Document";
    protected static final Logger LOGGER = LogR.getLogger(KBGivenToCustomerDataUtility.class.getName());
    private static final String[] DOCCHECK = { "102", "109", "111", "112", "121", "179", "191", "206", "208", "209",
			"222", "223", "262", "265", "267", "282", "303", "304", "311", "317", "501", "502", "508", "509", "510",
			"516", "519", "520", "521", "522", "524", "525", "528", "529", "531", "538", "541", "542", "546", "560",
			"564", "614", "630", "635", "638", "654", "656", "704", "705", "706", "710", "722", "749" };
    
    @Override
    public Object getDataValue(String componentId, Object datum, ModelContext modelContext) throws WTException {
        LOGGER.debug("entering getDataValue()");
        if (KBUtils.isEditMode(modelContext.getDescriptorMode())) {	
        	LOGGER.debug("isEditMode : true");
            AttributeInputCompositeComponent component = (AttributeInputCompositeComponent) super.getDataValue(componentId, datum, modelContext);
            WTDocument wtDocument = (WTDocument) OidHelper.getPersistable(datum);
            WTContainerRef containerRef = getContainerReference(modelContext);
            boolean isDataManagerDocumentManagerOrAdministrative = isUserDataManagerDocumentManagerOrAdministrative(containerRef);
            boolean isDesigner = isDesigner(containerRef);
 			LOGGER.debug("exiting isDataManagerDocumentManagerOrAdministrative--"+isDataManagerDocumentManagerOrAdministrative);
 			LOGGER.debug("exiting isDesigner--"+isDesigner);
            if (isDesigner && !isDataManagerDocumentManagerOrAdministrative){
            	component = processForCadDesigner(wtDocument, component);
            }
            LOGGER.debug("returning isEditable: " + component.getValueInputComponent().isEditable());
            LOGGER.debug("exiting getDataValue()");
            return component;
        }
        LOGGER.debug("exiting getDataValue()");
        return super.getDataValue(componentId, datum, modelContext);
    }

    private boolean isUserDataManagerDocumentManagerOrAdministrative(WTContainerRef containerRef) throws WTException {
        return KBTeamUtils.isUserInRole(SessionHelper.getPrincipal(),
                (ContainerTeamManaged) containerRef.getReferencedContainer(), KBConstants.DATA_MANAGEMENT) ||
        		KBTeamUtils.isUserInRole(SessionHelper.getPrincipal(),
                        (ContainerTeamManaged) containerRef.getReferencedContainer(), KBConstants.DOCUMENT_MANAGEMENT_ROLE) ||
        		WTContainerHelper.service.isAdministrator(containerRef, SessionHelper.getPrincipal());
    }
    
    private AttributeInputCompositeComponent processForCadDesigner(WTDocument wtDoc, AttributeInputCompositeComponent component) throws WTException{
    	State lifeCycleState = wtDoc.getLifeCycleState();
    	String docContentType = AttributeService.getAttribute(wtDoc, KBConstants.DOC_CONTENT_TYPE);
    	LOGGER.debug("proccessForCadDesigner - docContentType: " + docContentType);
    	boolean isInWorkState = KBConstants.IN_WORK_STATE.equals(lifeCycleState);
    	boolean isDocContentCheck = false;
        LOGGER.debug("proccessForCadDesigner - lifeCycleState: " + lifeCycleState);
        if(docContentType!=null && !docContentType.equals("")){
        	for (String docCheck : DOCCHECK) {
        		if (docContentType.contains(docCheck)) {
        			isDocContentCheck=true;
        		}
        	}
        }
        LOGGER.debug("proccessForCadDesigner - isDocContentCheck: " + isDocContentCheck);
        if(isInWorkState && isDocContentCheck){	
        	component.getValueInputComponent().setEditable(true);
        	if(isPredecessorInReleasedState(wtDoc)){
        		LOGGER.debug("Document has released predecessor.");
        		component = adjustAvailableValues(component);
        	}
        } else {
        	LOGGER.debug("setEditableDependingOnStateAndAttrValue: false");
            component.getValueInputComponent().setEditable(false);
        } 
        return component;
    }
    
	private boolean isPredecessorInReleasedState(WTDocument wtDoc) throws WTException{
        WTDocument originalCopy = (WTDocument)WorkInProgressHelper.service.originalCopyOf(wtDoc);
        LOGGER.debug("isPredecessorInReleasedState:originalCopy "+originalCopy.getVersionDisplayIdentifier() +" And"+ originalCopy);
		WTDocument predecessor = (WTDocument) ObjectRevisionHelper.getPreviousVersionLatestIteration(originalCopy);
		LOGGER.debug("isPredecessorInReleasedState:predecessor "+predecessor.getVersionDisplayIdentifier() +" And"+ predecessor);
		return predecessor != null && KBConstants.RELEASED_STATE.equals(predecessor.getLifeCycleState());
	}

    private AttributeInputCompositeComponent adjustAvailableValues(AttributeInputCompositeComponent component) throws WTException{
    	TreeMap<String, String> givenToCustomerNamesMap = KBDocumentUtils.getEnumerationKeysAndValues(KBConstants.KB_GIVEN_TO_CUSTOMER_ENUMERATION);
    	Object rawValue = component.getValueInputComponent().getRawValue();
    	LOGGER.debug("Given to customer values :" + givenToCustomerNamesMap);
    	givenToCustomerNamesMap.remove(HAS_TO_BE_CHECKED_ATTR_VALUE);
    	LOGGER.debug("Given to customer values after remove of 'has to be checked' :" + givenToCustomerNamesMap);
    	ArrayList<String> internalValues = new ArrayList<>(givenToCustomerNamesMap.keySet());
    	ArrayList<String> displayValues = new ArrayList<>(givenToCustomerNamesMap.values());
    	StringInputComponent adjustedStringInputComponent = new StringInputComponent(KBConstants.KB_GIVEN_TO_CUSTOMER_IBA, internalValues, displayValues, false);
    	component.getValueInputComponent().setRawValue(rawValue);
    	adjustedStringInputComponent.setValue((String) rawValue);
    	adjustedStringInputComponent.setRawValue(rawValue);
        adjustedStringInputComponent.setLabel(INPUT_COMPONENT_LABEL);
    	component.setValueInputComponent(adjustedStringInputComponent);
    	return component;
    }

    private WTContainerRef getContainerReference(ModelContext modelContext) throws WTException {
        WTContainerRef containerRef = modelContext.getNmCommandBean().getContainerRef();
        if (containerRef == null)
            containerRef = (WTContainerRef) new ReferenceFactory().getReference(
                    modelContext.getNmCommandBean().getRequest().getParameter(CONTAINER_OID));
        return containerRef;
    }
    private static boolean isDesigner(WTContainerRef containerRef) throws WTException{
    	boolean isDesigner =  KBTeamUtils.isUserInRole(SessionHelper.getPrincipal(),
        (ContainerTeamManaged) containerRef.getReferencedContainer(), KBConstants.DESIGNER_ROLE);
        boolean isDesignerLimited = KBTeamUtils.isUserInRole(SessionHelper.getPrincipal(),
        (ContainerTeamManaged) containerRef.getReferencedContainer(), KBConstants.DESIGNER_LIMITED_ROLE);
        boolean isSystemEngineer = KBTeamUtils.isUserInRole(SessionHelper.getPrincipal(),
        (ContainerTeamManaged) containerRef.getReferencedContainer(), KBConstants.SYSTEM_ENGINEER);
        return isDesigner || isDesignerLimited || isSystemEngineer;
    }
}
