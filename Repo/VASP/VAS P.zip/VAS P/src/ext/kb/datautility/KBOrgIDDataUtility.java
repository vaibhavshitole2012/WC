package ext.kb.datautility;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.rendering.guicomponents.AttributeDisplayCompositeComponent;
import com.ptc.core.components.rendering.guicomponents.AttributeInputCompositeComponent;
import com.ptc.core.meta.common.ElementIdentifier;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.TypeIdentifierHelper;
import com.ptc.core.meta.type.common.impl.DefaultTypeInstance;
import com.ptc.core.ui.resources.ComponentMode;
import com.ptc.core.ui.resources.ComponentType;
import com.ptc.windchill.enterprise.org.dataUtilities.OrgIDDataUtility;
import ext.kb.datautility.renderer.KBPickerInputComponentRenderer;
import org.apache.commons.lang.StringUtils;
import wt.util.WTException;

/**
 * Data Utility that hides Organization ID Picker when Creating/Editing WTPart/WTDocument/EPMDocument except
 * com.ptc.windchill.suma.part.SupplierPart and all subtypes.
 * KBPickerInputComponentRenderer is needed to not draw magnifying glass as setting Picker to HIDDEN
 * does not hide magnifying glass.
 */
public class KBOrgIDDataUtility extends OrgIDDataUtility {

    private static final String SUPPLIER_PART = "com.ptc.windchill.suma.part.SupplierPart";
    private static final String HIDDEN = "hidden";
    private final TypeIdentifier supplierTypeIdentifier = TypeIdentifierHelper.getTypeIdentifier(SUPPLIER_PART);

    @Override
    public Object getDataValue(String componentId, Object datum, ModelContext modelContext) throws WTException {
        Object dataValue = super.getDataValue(componentId, datum, modelContext);
        if (isEditOrCreateMode(modelContext) && !isObjectSupplierPart(modelContext)) {
            if (dataValue instanceof AttributeInputCompositeComponent) {
                AttributeInputCompositeComponent inputCompositeComponent = (AttributeInputCompositeComponent) dataValue;
                inputCompositeComponent.getValueInputComponent().addStyleClass(HIDDEN);
                inputCompositeComponent.getValueInputComponent().setRenderer(new KBPickerInputComponentRenderer());
                return inputCompositeComponent;
            }
            if (dataValue instanceof AttributeDisplayCompositeComponent) {
                AttributeDisplayCompositeComponent displayCompositeComponent = (AttributeDisplayCompositeComponent) dataValue;
                displayCompositeComponent.getValueDisplayComponent().addStyleClass(HIDDEN);
                return displayCompositeComponent;
            }
        }
        return dataValue;
    }

    private boolean isEditOrCreateMode(ModelContext modelContext) {
        ComponentMode descriptorMode = modelContext.getDescriptorMode();
        ComponentType descriptorType = modelContext.getDescriptorType();
        return ComponentMode.CREATE.equals(descriptorMode) ||
                (ComponentMode.VIEW.equals(descriptorMode) && ComponentType.INFO.equals(descriptorType));
    }

    @Override
    public String getLabel(String componentId, ModelContext modelContext) throws WTException {
        if (isEditOrCreateMode(modelContext) && !isObjectSupplierPart(modelContext)) {
            return StringUtils.EMPTY;
        }
        return super.getLabel(componentId, modelContext);
    }

    private boolean isObjectSupplierPart(ModelContext modelContext) throws WTException {
        Object targetObject = modelContext.getTargetObject();
        if (targetObject instanceof DefaultTypeInstance) {
            DefaultTypeInstance defaultTypeInstance = (DefaultTypeInstance) targetObject;
            ElementIdentifier typeInstanceIdentifier = defaultTypeInstance.getIdentifier();
            return typeInstanceIdentifier.getDefinitionIdentifier().isDescendedFrom(supplierTypeIdentifier);
        }
        return false;
    }

}
