package ext.kb.datautility;

import org.apache.log4j.Logger;

import wt.log4j.LogR;
import wt.util.WTException;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.rendering.GuiComponent;
import com.ptc.core.components.rendering.guicomponents.TextDisplayComponent;
import com.ptc.windchill.enterprise.wizardParticipant.beans.RoleParticipantOid;
import com.ptc.windchill.enterprise.wizardParticipant.dataUtilities.ParticipantTeamRolesDataUtility;
import com.ptc.windchill.enterprise.wizardParticipant.renderers.ParticipantComponentCheckBox;

public class KBParticipantTeamRolesDataUtility extends ParticipantTeamRolesDataUtility {

	private static Logger logger = LogR.getLogger(KBParticipantTeamRolesDataUtility.class.getName());
	static final String SELECTION_STATUS = "wizpart_selectionStatus";
	static final String PARENTID = "parentIds";
	static final int FALSE = 0;
	static final int SYSTEM = 1;
	static final int USER = 2;
	static final int DERIVED = 3;

	@Override
	public Object getDataValue(String paramString, Object paramObject,
			ModelContext paramModelContext) throws WTException {
		
		if (/*"SSL RELEASER".equals(paramString) || */!"SSL RELEASER".equals(paramString) ){
			return super.getDataValue(paramString, paramObject, paramModelContext);
		}

		long l1 = System.currentTimeMillis();
		Object localObject = TextDisplayComponent.NBSP;
		RoleParticipantOid localRoleParticipantOid = (paramObject instanceof RoleParticipantOid) ? (RoleParticipantOid) paramObject : null;
		if (localRoleParticipantOid == null) {
			if (logger.isDebugEnabled()) {
				logger.debug("The following datum was not a RoleParticipantOid:\n" + paramObject);
				logger.debug("This may be okay if the datum is the dynamically expanded node.");
			}
			return localObject;
		}
		localObject = createCheckBox(paramString, localRoleParticipantOid);

		long l2 = System.currentTimeMillis();
		if ((logger.isTraceEnabled()) && (l2 - l1 > 0L)) {
			logger.trace("Time in getDataValue: " + (l2 - l1));
		}
		return localObject;

	}

	private GuiComponent createCheckBox(String paramString,
			RoleParticipantOid paramRoleParticipantOid) {
		if (!paramRoleParticipantOid.isRoleCheckable(paramString)) {
			if (logger.isDebugEnabled()){
				logger.debug("The " + paramRoleParticipantOid + " is not checkable.");
			}
			return TextDisplayComponent.NBSP;
		}

		if (logger.isDebugEnabled()) {
			logger.debug("Role '" + paramString + "' is checked for '" + paramRoleParticipantOid.getHTMLId() + "' ? " + paramRoleParticipantOid.isChecked(paramString));
			logger.debug("Role '" + paramString + "' is system checked for '" + paramRoleParticipantOid.getHTMLId() + "' ? " + paramRoleParticipantOid.isSystemChecked(paramString));
		}

		ParticipantComponentCheckBox localParticipantComponentCheckBox = new ParticipantComponentCheckBox(paramRoleParticipantOid.isChecked(paramString), true);		
		localParticipantComponentCheckBox.setSystemCheckedValue(systemCheckedValue(paramString, paramRoleParticipantOid));
		localParticipantComponentCheckBox.setRoleCheckable(true);
		return localParticipantComponentCheckBox;
	}

	private int systemCheckedValue(String paramString,
			RoleParticipantOid paramRoleParticipantOid) {
		int i = 0;
		if (paramRoleParticipantOid.isSystemChecked(paramString) || paramRoleParticipantOid.isUserChecked(paramString)) {
			i = 2;
		} else if (paramRoleParticipantOid.isUserDerivedChecked(paramString)) {
			i = 3;
		}
		if (logger.isDebugEnabled()){
			logger.debug("System checked value " + paramRoleParticipantOid + "|" + paramString + " : " + i);
		}
		return i;
	}

}
