package ext.kb.datautility;

import wt.change2.ChangeHelper2;
import wt.change2.WTChangeActivity2;
import wt.change2.WTChangeOrder2;
import wt.fc.QueryResult;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.workflow.work.WorkItem;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.rendering.guicomponents.GUIComponentArray;
import com.ptc.core.components.rendering.guicomponents.UrlDisplayComponent;
import com.ptc.windchill.enterprise.work.assignmentslist.dataUtilities.AssignmentsSubjectNameDataUtility;

import ext.kb.resources.KBAssignmentSubjectRB;

public class KBAssignmentSubjectNameDataUtility extends AssignmentsSubjectNameDataUtility {
	
	@Override
	public Object getDataValue(String paramString, Object paramObject, ModelContext paramModelContext) throws WTException {
		GUIComponentArray componentAray = (GUIComponentArray) super.getDataValue(paramString, paramObject, paramModelContext);
		
		if (paramObject instanceof WorkItem && ((WorkItem)paramObject).getPrimaryBusinessObject().getObject() instanceof WTChangeActivity2){
			UrlDisplayComponent url = (UrlDisplayComponent) componentAray.get(0);
			WTChangeActivity2 ca = (WTChangeActivity2)((WorkItem)paramObject).getPrimaryBusinessObject().getObject();
			QueryResult localQuery = ChangeHelper2.service.getLatestChangeOrder(ca);
			if (localQuery.hasMoreElements()){
				WTChangeOrder2 cOrder = (WTChangeOrder2) localQuery.nextElement();
				String newLabel = new WTMessage(KBAssignmentSubjectRB.class.getName(), 
						KBAssignmentSubjectRB.ASSIGNMENT_SUBJECT, 
						new Object[]{cOrder.getNumber(), ca.getNumber(), ca.getName()}).getLocalizedMessage();
				url.setLabel(newLabel);
				url.setLabelForTheLink(newLabel);
				return url;
			}
		}
		return componentAray;
	}
	
}
