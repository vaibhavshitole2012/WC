package ext.kb.datautility;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.jfree.util.Log;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.dataUtilities.DefaultDataUtility;
import com.ptc.core.components.rendering.guicomponents.AttributeDisplayCompositeComponent;
import com.ptc.core.components.rendering.guicomponents.AttributeGuiComponent;
import com.ptc.core.components.rendering.guicomponents.AttributeInputComponent;
import com.ptc.core.components.rendering.guicomponents.AttributeInputCompositeComponent;
import com.ptc.core.components.rendering.guicomponents.MultiValuedInputComponent;
import com.ptc.core.components.rendering.guicomponents.StringInputComponent;
import com.ptc.core.components.rendering.guicomponents.TextDisplayComponent;
import com.ptc.core.lwc.common.view.EnumerationEntryReadView;
import com.ptc.core.lwc.common.view.PropertyValueReadView;
import com.ptc.core.ui.resources.ComponentMode;
import com.ptc.generic.iba.AttributeService;

import ext.kb.ui.validation.KBLanguageProcessDelegate;
import ext.kb.util.IBAHelper;
import ext.kb.util.KBConstants;
import ext.kb.util.KBDocumentUtils;
import ext.kb.util.KBType;
import ext.kb.util.KBUtils;
import wt.doc.WTDocument;
import wt.epm.EPMDocument;
import wt.log4j.LogR;
import wt.part.WTPart;
import wt.util.WTException;

public class KBLanguageDataUtility extends DefaultDataUtility {

    /** The Constant CLASSNAME. */
    private static final String CLASSNAME = KBLanguageDataUtility.class.getName();
    /** The Constant LOGGER. */
    protected static final Logger LOGGER = LogR.getLogger(CLASSNAME);
    @Override
    public Object getDataValue(String paramString, Object paramObject, ModelContext paramModelContext) throws WTException {
        Object mainComponent = super.getDataValue(paramString, paramObject, paramModelContext);
        WTDocument doc = null;
        WTPart part = null;
        EPMDocument epmDoc = null;
        String languages = "";
        Object paramObj = paramModelContext.getNmCommandBean().getPrimaryOid().getRefObject();
		if (paramObj instanceof WTDocument) {
		    doc = (WTDocument) paramObj;
		    Object tmpValue = AttributeService.getAttribute(doc, KBConstants.KBLANGUAGE_IBA);
		    if (tmpValue instanceof Object[]){
		    	for (Object l : (Object[]) tmpValue) {
		      		if (!languages.isEmpty()){
		      			languages = languages.concat("/");
		      		}
						languages = languages.concat(l.toString());
					}
		    } else {
                languages = (String)tmpValue;
            }
            boolean shouldBeEditable = DataUtilityHelper.shouldBeEditableOnDocument(doc);
            DataUtilityHelper.setEditableFieldOnComponent(mainComponent, shouldBeEditable);
        } else if (paramObj instanceof WTPart) {
		    part = (WTPart) paramObj;
		    languages = (String)IBAHelper.getStringIBAValue(part, paramString);
		} else if (paramObj instanceof EPMDocument) {
		    epmDoc = (EPMDocument) paramObj;
		    languages = (String)IBAHelper.getStringIBAValue(epmDoc, paramString);
		}
        if (LOGGER.isDebugEnabled()){
        	LOGGER.debug("mode: " + paramModelContext.getDescriptorMode().toString() + " languages: " + languages);
        }
        ArrayList<String> languagesInternalValues = getLanguagesInternalValues();
        ArrayList<String> languagesDisplayValues = getLanguagesDisplayValues(languagesInternalValues);
        
		if (KBUtils.isDataUtilityRunInOrganization(paramModelContext, KBUtils.KB_ORG_NAME)
				&& paramModelContext.getDescriptorMode().equals(ComponentMode.VIEW)
				&& KBType.isOneOfTypes(paramObj, KBUtils.supportedTypesForLeadingLanguage)) {

			Log.debug("Ogranization is KB and Component mode is View for desired type");
			TextDisplayComponent langComponent = new TextDisplayComponent(paramString);
			String langs = getUpdatedLanguageIBAValue(doc);
			Log.debug("Languages value is : " + langs);
			langComponent.setValue(langs.toString());
			return langComponent;
		}
       
        if (KBUtils.isDataUtilityRunInOrganization(paramModelContext, KBUtils.HVAC_ORG_NAME)) {
        	//can be mapped with Enumerated values
        	Map<String, EnumerationEntryReadView> globalEnum = KBDocumentUtils.getGlobalEnumeration(KBConstants.DOC_LANGUAGES_ENUMERATION);
        	boolean isValidLanguageValue = isValidLanguageValue(globalEnum, languages);
        	if(!isValidLanguageValue){
        		return mainComponent;
        	}
            if (ComponentMode.CREATE.equals(paramModelContext.getDescriptorMode())) {
                AttributeInputCompositeComponent component = (AttributeInputCompositeComponent) mainComponent;
                ArrayList<AttributeInputComponent> inputComponentsForCreate = getFilledInputComponentsForCreate(component.getValueInputComponent(), languagesInternalValues, languagesDisplayValues);
                int visibleElements = inputComponentsForCreate.size();
                if (visibleElements == 0)
                    visibleElements++;
                inputComponentsForCreate = fillWithEmptyInputComponents(inputComponentsForCreate, languagesInternalValues, languagesDisplayValues);
                MultiValuedInputComponent multiValuedInputComponent = createMultiValuedInputComponent(inputComponentsForCreate, visibleElements);
                component.setValueInputComponent(multiValuedInputComponent);
            } else if (ComponentMode.EDIT.equals(paramModelContext.getDescriptorMode())) {
                AttributeInputCompositeComponent component = (AttributeInputCompositeComponent) mainComponent;
                component.setValueInputComponent(createValueInputComponent(languages, languagesInternalValues, languagesDisplayValues));
            } else if (ComponentMode.VIEW.equals(paramModelContext.getDescriptorMode())) {
            	TextDisplayComponent langComponent = new TextDisplayComponent(paramString);
            	StringBuilder sb = new StringBuilder();
            	if (!StringUtils.isEmpty(languages)){
	            	
	            	for (String value : languages.split("\\/")) {
	            		EnumerationEntryReadView enumValue = globalEnum.get(value);
	            		PropertyValueReadView displayName = enumValue.getPropertyValueByName("displayName");
	            		String displayNameString = displayName.getValueAsString();
						if (sb.length()>0){
							sb.append(", ");
						}
						sb.append(displayNameString);
					}
            	}
            	langComponent.setValue(sb.toString());
            	return langComponent;
            }
        }
        return mainComponent;
    }


    private ArrayList<String> getLanguagesInternalValues() throws WTException {
        Map<String, EnumerationEntryReadView> valuesToReadViewsMap = KBDocumentUtils.getGlobalEnumeration(KBConstants.DOC_LANGUAGES_ENUMERATION);
        Set<String> enumerationValues = valuesToReadViewsMap.keySet();

        return new ArrayList<String>(enumerationValues);
    }

    private MultiValuedInputComponent createValueInputComponent(String originalStringInputComponentValue, ArrayList<String> languagesInternalValues, ArrayList<String> languagesDisplayValues) throws WTException {
    	ArrayList<AttributeInputComponent> inputComponentsForEdit = getFilledInputComponentsForEdit(originalStringInputComponentValue, languagesInternalValues, languagesDisplayValues);
    	int visibleElements = inputComponentsForEdit.size();
    	
    	if (visibleElements == 0)
    		visibleElements++;
    	inputComponentsForEdit = fillWithEmptyInputComponents(inputComponentsForEdit, languagesInternalValues, languagesDisplayValues);
    	return createMultiValuedInputComponent(inputComponentsForEdit, visibleElements);
    }
    
    private ArrayList<String> getLanguagesDisplayValues(ArrayList<String> languagesInternalValues) throws WTException {
        Map<String, EnumerationEntryReadView> valuesToReadViewsMap = KBDocumentUtils.getGlobalEnumeration(KBConstants.DOC_LANGUAGES_ENUMERATION);
        Collection<EnumerationEntryReadView> values = valuesToReadViewsMap.values();

        ArrayList<String> enumerationDisplayValues = new ArrayList<String>();
	

        Iterator<String> languagesInternalValuesIterator = languagesInternalValues.iterator();
        for (Iterator<EnumerationEntryReadView> enumerationEntryReadViewIterator = values.iterator(); enumerationEntryReadViewIterator.hasNext();) {
            EnumerationEntryReadView enumerationEntryReadView = enumerationEntryReadViewIterator.next();

            String displayName = languagesInternalValuesIterator.next();

            if (enumerationEntryReadView.getPropertyValueByName("displayName") != null)
                displayName = enumerationEntryReadView.getPropertyValueByName("displayName").getValueAsString();

            enumerationDisplayValues.add(displayName);
        }

        return enumerationDisplayValues;
    }

    private HashSet<String> parseLanguageAttributeValue(String defaultValue, ArrayList<String> languagesInternalValues) throws WTException {
        HashSet<String> parsedLanguages = new HashSet<String>();

        if (defaultValue != null) {
            Collections.addAll(parsedLanguages, defaultValue.split("\\/"));

            if (languagesInternalValues.containsAll(parsedLanguages) == false)
                throw new WTException("Language value is incorrect!");
        }

        return parsedLanguages;
    }

    private ArrayList<AttributeInputComponent> getFilledInputComponentsForCreate(AttributeInputComponent attributeInputComponent, ArrayList<String> languagesInternalValues, ArrayList<String> languagesDisplayValues) throws WTException {
        String originalStringInputComponentDefaultValue = attributeInputComponent.getDefaultValue() != null ? attributeInputComponent.getDefaultValue().toString() : null;
        HashSet<String> defaultValues = parseLanguageAttributeValue(originalStringInputComponentDefaultValue, languagesInternalValues);

        ArrayList<AttributeInputComponent> attributeInputComponents = new ArrayList<AttributeInputComponent>();

        for (Iterator<String> defaultValuesIterator = defaultValues.iterator(); defaultValuesIterator.hasNext();) {
            String defaultValue = defaultValuesIterator.next();

            StringInputComponent defaultValueStringInputComponent = new StringInputComponent(KBConstants.KBLANGUAGE_IBA, languagesInternalValues, languagesDisplayValues, false);
            defaultValueStringInputComponent.setName(KBConstants.KBLANGUAGE_IBA);
            defaultValueStringInputComponent.setDefaultValue(defaultValue);

            attributeInputComponents.add(defaultValueStringInputComponent);
        }

        return attributeInputComponents;
    }

    private ArrayList<AttributeInputComponent> getFilledInputComponentsForEdit(String originalStringInputComponentValue, ArrayList<String> languagesInternalValues, ArrayList<String> languagesDisplayValues) throws WTException {
        ArrayList<AttributeInputComponent> attributeInputComponents = new ArrayList<AttributeInputComponent>();

        if (KBUtils.isEmpty(originalStringInputComponentValue) == false) {
            HashSet<String> values = parseLanguageAttributeValue(originalStringInputComponentValue, languagesInternalValues);

            for (Iterator<String> defaultValuesIterator = values.iterator(); defaultValuesIterator.hasNext();) {
                String defaultValue = defaultValuesIterator.next();

                StringInputComponent defaultValueStringInputComponent = new StringInputComponent(KBConstants.KBLANGUAGE_IBA, languagesInternalValues, languagesDisplayValues, false);
                defaultValueStringInputComponent.setName(KBConstants.KBLANGUAGE_IBA);
                defaultValueStringInputComponent.setValue(defaultValue);

                attributeInputComponents.add(defaultValueStringInputComponent);
            }
        }

        return attributeInputComponents;
    }

    private ArrayList<AttributeInputComponent> fillWithEmptyInputComponents(ArrayList<AttributeInputComponent> attributeInputComponents, ArrayList<String> languagesInternalValues, ArrayList<String> languagesDisplayValues) {
        StringInputComponent emptyStringInputComponent = new StringInputComponent(KBConstants.KBLANGUAGE_IBA, languagesInternalValues, languagesDisplayValues, false);
        emptyStringInputComponent.setName(KBConstants.KBLANGUAGE_IBA);
        attributeInputComponents.add(emptyStringInputComponent);

        if (attributeInputComponents.size() < 2) // list has to have at least 2
                                                 // elements else the minus
                                                 // button is not rendered
            attributeInputComponents.add(emptyStringInputComponent);

        return attributeInputComponents;
    }

    private MultiValuedInputComponent createMultiValuedInputComponent(ArrayList<AttributeInputComponent> attributeInputComponents, int visibleElements) {
        AttributeInputComponent defaultInputComponent = attributeInputComponents.get(attributeInputComponents.size() - 1);

        MultiValuedInputComponent multiValuedInputComponent = new MultiValuedInputComponent(attributeInputComponents, defaultInputComponent);
        multiValuedInputComponent.setLabel(defaultInputComponent.getLabel());
        multiValuedInputComponent.setMultiValued(true);
        multiValuedInputComponent.setVisibleElements(visibleElements);
        multiValuedInputComponent.addHiddenField("FormProcessorDelegate", KBLanguageProcessDelegate.class.getName());

        return multiValuedInputComponent;
    }
    
    private boolean isValidLanguageValue(Map<String, EnumerationEntryReadView> globalEnum, String languages){
    	if(StringUtils.isEmpty(languages)) return false;
		for (String value : languages.split("\\/")) {
    		EnumerationEntryReadView enumValue = globalEnum.get(value);
    		if(enumValue == null){
    			return false;
    		}
    		PropertyValueReadView displayName = enumValue.getPropertyValueByName("displayName");
    		if(displayName == null){
    			return false;
    		}
		}
    	return true;
    }
    
    /**
	 * gets languages values from IBA and returns them with '/' e.g. languages are
	 * AR,EN,DE then they are sorted and displayed as AR/DE/EN
	 * 
	 * @param doc
	 * @return
	 */
    private String getUpdatedLanguageIBAValue(WTDocument doc) {
    	String langs = "";
    	Object tmpValue = AttributeService.getAttribute(doc, KBConstants.KBLANGUAGE_IBA);
    	LOGGER.debug("Language values obtained from doc are : " + tmpValue);
		if (tmpValue instanceof Object[]) {
			List<String> languageList = new ArrayList<>();
			Object[] langObjects = (Object[]) tmpValue;
			for (int i = 0; i < langObjects.length; i++) {
				languageList.add(langObjects[i].toString());
			}
			Collections.sort(languageList);
			
    		for (String lang : languageList) {
    			langs += lang + "/";
    		}
    		LOGGER.debug("langs to update: " + langs);
		} else if (tmpValue instanceof String) {
			// if only one language value then it's taken as a String
			LOGGER.debug("Language value is string : " + tmpValue.toString());
			langs = tmpValue.toString();
		}
		if (langs.endsWith("/")) {
			langs = langs.substring(0, langs.length() - 1);
		}
		return langs;
    }
}
