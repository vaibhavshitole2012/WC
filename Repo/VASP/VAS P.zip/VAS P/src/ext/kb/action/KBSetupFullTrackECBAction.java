package ext.kb.action;

import java.util.Iterator;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.ptc.core.components.forms.FormProcessingStatus;
import com.ptc.core.components.forms.FormResult;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;

import ext.kb.util.DBUtils;
import ext.kb.util.KBConstants;
import ext.kb.util.KBUtils;
import ext.kb.workflow.ChangeRequestUtils;
import ext.kb.workflow.WFUtils;
import wt.change2.WTChangeRequest2;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.collections.WTHashSet;
import wt.fc.collections.WTKeyedHashMap;
import wt.log4j.LogR;
import wt.query.ClassTableExpression;
import wt.util.WTException;
import wt.workflow.engine.WfActivity;
import wt.workflow.work.WorkItem;

public class KBSetupFullTrackECBAction extends KBFormProcessor{
	
	private static final Logger LOG = LogR.getLogger(KBSetupFullTrackECBAction.class.getName());
	private static final String COMMA = ",";
	private static final ClassTableExpression WORK_ITEM_EXP = new ClassTableExpression(WorkItem.class);
	private static final ClassTableExpression CHANGE_REQUEST_EXP = new ClassTableExpression(WTChangeRequest2.class);
	
	private String rolesByMultiLevelContext = null;
	private String rolesByParentLevelContext = null;
	
	public FormResult setupFullTrackECB(NmCommandBean commandBean) throws WTException{
		FormResult result = new FormResult(FormProcessingStatus.FAILURE);
		String[] rolesByMLC = StringUtils.split(getRolesByMultiLevelContext(),COMMA);
		String[] rolesByPLC = StringUtils.split(getRolesByParentLevelContext(),COMMA);
		if(LOG.isDebugEnabled()){
    		LOG.debug("rolesByMultiLevelContext='"+rolesByMultiLevelContext+"', rolesByParentLevelContext='"+rolesByParentLevelContext+"'");
    	}
		NmOid oid = KBUtils.getOidFromBeanContext(commandBean);
		
		WorkItem wItem = DBUtils.queryObjectById(WorkItem.class, oid.getOidObject());
		WfActivity activity = WFUtils.getWfActivity(wItem);
		WTKeyedHashMap principalContextsMap = (WTKeyedHashMap)WFUtils.getWfVariableValue(activity, "principalContextsMap");
	
        if (oid != null) {
        	try {
                WTHashSet list = DBUtils.joinTables(WORK_ITEM_EXP, "primaryBusinessObject", 1, KBConstants.PERS_OBID, CHANGE_REQUEST_EXP, 5, oid.getOidObject());

                @SuppressWarnings("unchecked")
                Iterator<Persistable> it = list.iterator();
                while (it.hasNext()) {
                    ObjectReference ref = (ObjectReference)it.next();
                    WTChangeRequest2  cr2 = (WTChangeRequest2) ref.getObject();
                    for(String roleName :rolesByMLC){
                    	ChangeRequestUtils.assignRoleByMultiLevelContext(cr2, StringUtils.upperCase(roleName), KBConstants.ECB_PROJECT_MANAGER_ROLE);
                    	if(LOG.isDebugEnabled()){
                    		LOG.debug("Assign "+roleName+" to ECB project manager");
                    	}
            		}
            		
            		for(String roleName :rolesByPLC){
            			ChangeRequestUtils.setup4EyeReview(cr2, principalContextsMap, KBConstants.ECB_TECHINCAL_ROLE);
            			if(LOG.isDebugEnabled()){
            				LOG.debug("Assign "+roleName+" to ECB technical role");
            			}
            		}
                    
                }
            } catch (WTException e) {
                LOG.error("Failed to query main object", e);
            }
        }
        LOG.error("principalContextsMap "+principalContextsMap);
		result.setStatus(FormProcessingStatus.SUCCESS);
		return result;
	}
	
	
	private String getRolesByMultiLevelContext() {
		if(rolesByMultiLevelContext == null){
			rolesByMultiLevelContext = StringUtils.EMPTY;
		}
		return rolesByMultiLevelContext;
	}


	private String getRolesByParentLevelContext() {
		if(rolesByParentLevelContext == null){
			rolesByParentLevelContext = StringUtils.EMPTY;
		}
		return rolesByParentLevelContext;
	}


	public void setRolesByMultiLevelContext(String rolesByMultiLevelContext) {
		this.rolesByMultiLevelContext = rolesByMultiLevelContext;
	}
	
	public void setRolesByParentLevelContext(String rolesByParentLevelContext) {
		this.rolesByParentLevelContext = rolesByParentLevelContext;
	}
}
