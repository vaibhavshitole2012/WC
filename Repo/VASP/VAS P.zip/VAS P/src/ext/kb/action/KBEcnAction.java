package ext.kb.action;

import org.apache.log4j.Logger;

import wt.change2.AffectedActivityData;
import wt.change2.ChangeHelper2;
import wt.change2.Changeable2;
import wt.change2.WTChangeActivity2;
import wt.change2.WTChangeOrder2;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.log4j.LogR;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;

import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;

import ext.kb.util.DBUtils;
import ext.kb.util.KBConstants;

/**
 * KB ECN Save as functionality handler.
 * @author kissn
 *
 */
public class KBEcnAction {

    private static final Logger LOG = LogR.getLogger(KBEcnAction.class.getName());

    private KBEcnAction() {
    }
    
    public static void saveEcnAs(NmCommandBean paramNmCommandBean) {
        NmOid oid;
        try {
            oid = paramNmCommandBean.getElementOid();

            if (oid != null) {

                WTChangeOrder2 originalEcn = DBUtils.queryObjectById(WTChangeOrder2.class,
                        KBConstants.PERS_OBID, oid.getOidObject());
                WTChangeOrder2 newEcn = WTChangeOrder2.newWTChangeOrder2();

                newEcn.setTypeDefinitionReference(originalEcn.getTypeDefinitionReference());
                newEcn.setTypeInfoWTChangeOrder2(originalEcn.getTypeInfoWTChangeOrder2());
                newEcn.setName("Prototype of " + originalEcn.getName());
                newEcn.setDescription(originalEcn.getDescription());
                newEcn.setContainer(originalEcn.getContainer());
                newEcn.setOrganization(originalEcn.getOrganization());
                newEcn.setChangeNoticeComplexity(originalEcn.getChangeNoticeComplexity());
                newEcn.setContentVector(originalEcn.getContentVector());
                newEcn.setEntrySet(originalEcn.getEntrySet());
                newEcn.setNeedDate(originalEcn.getNeedDate());
                newEcn.setTeamId(originalEcn.getTeamId());
                newEcn.setTeamTemplateId(originalEcn.getTeamTemplateId());
                newEcn = (WTChangeOrder2) ChangeHelper2.service.saveChangeOrder(newEcn);
                QueryResult originalTasks = ChangeHelper2.service.getChangeActivities(originalEcn);

                while (originalTasks.hasMoreElements()) {
                    WTChangeActivity2 activity = (WTChangeActivity2) originalTasks.nextElement();
                    WTChangeActivity2 newEca = WTChangeActivity2.newWTChangeActivity2();
                    newEca.setTypeInfoWTChangeActivity2(activity.getTypeInfoWTChangeActivity2());
                    newEca.setTypeDefinitionReference(activity.getTypeDefinitionReference());
                    newEca.setName(activity.getName());
                    newEca.setDescription(activity.getDescription());
                    newEca.setContainer(activity.getContainer());
                    newEca.setOrganization(activity.getOrganization());
                    newEca.setContentVector(activity.getContentVector());
                    newEca.setTeamId(activity.getTeamId());
                    newEca.setTeamTemplateId(activity.getTeamTemplateId());
                    newEca = (WTChangeActivity2) ChangeHelper2.service.saveChangeActivity(newEcn, newEca);
                    QueryResult changeables = ChangeHelper2.service.getChangeablesBefore(activity);

                    while (changeables.hasMoreElements()) {
                        AffectedActivityData affData = AffectedActivityData.newAffectedActivityData(
                                (Changeable2) changeables.nextElement(), newEca);
                        PersistenceHelper.manager.save(affData);
                    }
                }
            } else {
                LOG.debug("Element identity is missing, skipping operation");
            }
        } catch (WTException e) {
            LOG.error("Failed to query main object", e);
        } catch (WTPropertyVetoException e) {
            LOG.error("Error during property setting", e);
        }
    }
}
