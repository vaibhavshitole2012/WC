package ext.kb.action;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;

import ext.kb.util.DBUtils;
import ext.kb.util.KBConstants;
import ext.kb.util.KBTeamUtils;
import ext.kb.util.KBUtils;
import ext.kb.workflow.ChangeRequestUtils;
import ext.kb.workflow.WFUtils;
import wt.change2.ChangeException2;
import wt.change2.ChangeHelper2;
import wt.change2.WTChangeRequest2;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.fc.WTObject;
import wt.fc.collections.WTHashSet;
import wt.fc.collections.WTKeyedHashMap;
import wt.inf.team.ContainerTeam;
import wt.log4j.LogR;
import wt.org.WTPrincipal;
import wt.part.WTPart;
import wt.pdmlink.PDMLinkProduct;
import wt.project.Role;
import wt.query.ClassTableExpression;
import wt.session.SessionHelper;
import wt.team.Team;
import wt.util.WTException;
import wt.util.WTRuntimeException;
import wt.workflow.engine.WfActivity;
import wt.workflow.work.WorkItem;

public class KBRoleActions extends KBFormProcessor
{ 
	private static final ClassTableExpression WORK_ITEM_EXP = new ClassTableExpression(WorkItem.class);
    
    private static final ClassTableExpression CHANGE_REQUEST_EXP = new ClassTableExpression(WTChangeRequest2.class);
    
    private static final Logger LOG = LogR.getLogger(KBRoleActions.class.getName());
    
    private Role action1RoleFrom;
    
    private Role action1RoleTo;
    
    private Role action2RoleFrom;
    
    private Role action2RoleTo;
    
    public KBRoleActions() {}
    
    public KBRoleActions(String action1From, String action1To, String action2From, String action2To) {
        action1RoleFrom = Role.toRole(action1From);
        action1RoleTo = Role.toRole(action1To);
        action2RoleFrom = Role.toRole(action2From);
        action2RoleTo = Role.toRole(action2To);
    }
    
    public void setupRole1(NmCommandBean paramNmCommandBean) {
        setupRole(paramNmCommandBean, action1RoleFrom,  action1RoleTo);
    }

    public void setupRole2(NmCommandBean paramNmCommandBean) {
        setupRole(paramNmCommandBean, action2RoleFrom,  action2RoleTo);
        
    }

    public void setupRole3(NmCommandBean paramNmCommandBean) throws WTException {
    	WTPrincipal currentPrincipal = getCurrentUser();
    	try{
    		asAdmin();
	    	//role in current context
    		NmOid oid = KBUtils.getOidFromBeanContext(paramNmCommandBean);
	    	WTChangeRequest2 request = getChangeRequest(paramNmCommandBean);
	    	String preference = (String)KBUtils.getPreferenceByHierarchyHandleExc(KBConstants.PREF_KB_ECB_4EYE_ROLE, request);
	    	if(LOG.isDebugEnabled()){
	    		LOG.debug("KB_ECB-4Eye_Role preference value is "+preference);
	    	}
	    		
	    	if(StringUtils.isEmpty(preference)){
	    		throw new WTRuntimeException("Preference '"+preference+"' is not set neither on product nor on Site");
	    	}
	    
	    	WorkItem wItem = DBUtils.queryObjectById(WorkItem.class, oid.getOidObject());
			WfActivity activity = WFUtils.getWfActivity(wItem);
			WTKeyedHashMap principalContextsMap = (WTKeyedHashMap)WFUtils.getWfVariableValue(activity, "principalContextsMap");
	    		//search roles based on usage
	    	ChangeRequestUtils.setup4EyeReview(request, principalContextsMap, KBConstants.ECB_TECHINCAL_ROLE);
    	}finally{
    		asOriginalUser(currentPrincipal);
    	}
    }
    
    private void asAdmin(){
		try {
			SessionHelper.manager.setPrincipal(SessionHelper.manager.getAdministrator().getName());
		} catch (WTException e) {
			throw new WTRuntimeException(e,"Setting As Admin failed ");
		}
	}
	
	private void asOriginalUser(WTPrincipal origUser){
		try {
			SessionHelper.manager.setPrincipal(origUser.getName());
		} catch (WTException e) {
			throw new WTRuntimeException(e,"Setting As OriginalUser failed ");
		}
	}
	
	private WTPrincipal getCurrentUser(){
		try {
			return SessionHelper.manager.getPrincipal();
		} catch (WTException e) {
			throw new WTRuntimeException(e,"Setting As asOriginalUser failed ");
		}
	}
	
	private void setupRole(NmCommandBean paramNmCommandBean, Role sourceRole, Role targetRole) {
		try{
			WTChangeRequest2 req = getChangeRequest(paramNmCommandBean);
			populateContainerUsers(sourceRole, targetRole, req);
		}catch(WTException e){
			LOG.error("Failed to populateContainerUsers", e);
		}
	}

	private void populateContainerUsers(Role sourceRole, Role targetRole, WTChangeRequest2 req)
			throws WTException, ChangeException2 {
		Set<PDMLinkProduct> products = new HashSet<PDMLinkProduct>();
		QueryResult changeables = ChangeHelper2.service.getChangeables(req, true);
		while (changeables.hasMoreElements()) {
			WTObject affectedObj = (WTObject) changeables.nextElement();
			if (!(affectedObj instanceof WTPart)) {
				continue;
			}
			WTPart p = (WTPart) affectedObj;
			PDMLinkProduct prod = (PDMLinkProduct) p.getContainer();
			products.add(prod);
		}
		Iterator<PDMLinkProduct> prodIt = products.iterator();
		while (prodIt.hasNext()) {
			KBTeamUtils.populateContainerUsers((ContainerTeam) prodIt.next().getContainerTeamReference().getObject(),sourceRole.toString(), targetRole, (Team) req.getTeamId().getObject());
			// KBTeamUtils.populateUsers(((Team)w.getTeamId().getObject()).getRolePrincipalMap(),
			// sourceRole, w.getTeamId(), targetRole, true);
		}
	}
	
	private WTChangeRequest2 getChangeRequest(NmCommandBean paramNmCommandBean) {
        NmOid oid = KBUtils.getOidFromBeanContext(paramNmCommandBean);
        WTChangeRequest2 req = null;
        if (oid != null) {
        	
            try {
                WTHashSet list = DBUtils.joinTables(WORK_ITEM_EXP, "primaryBusinessObject", 1, KBConstants.PERS_OBID, CHANGE_REQUEST_EXP, 5, oid.getOidObject());
                @SuppressWarnings("unchecked")
                Iterator<Persistable> it = list.iterator();
                if(it.hasNext()) {
                    ObjectReference ref = (ObjectReference)it.next();
                    req = (WTChangeRequest2) ref.getObject();
                }
            } catch (WTException e) {
                LOG.error("Failed to query main object", e);
            }
        }
        return req;
    }
    
}
