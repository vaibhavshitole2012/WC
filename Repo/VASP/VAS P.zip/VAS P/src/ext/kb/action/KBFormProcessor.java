package ext.kb.action;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;

import org.apache.log4j.Logger;

import wt.log4j.LogR;
import wt.util.WTException;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormProcessingStatus;
import com.ptc.core.components.forms.FormResult;
import com.ptc.netmarkets.util.beans.NmCommandBean;

import ext.kb.util.KBContextService;

/**
 * Custom form processor for ECN role setup action.
 * @author kissn
 *
 */
public class KBFormProcessor extends DefaultObjectFormProcessor {

    private static final Logger LOG = LogR.getLogger(KBFormProcessor.class.getName());
    
    public KBFormProcessor() {
    }
    
    @Override
    public FormResult doOperation(NmCommandBean paramNmCommandBean, List<ObjectBean> paramList) throws WTException {
        String method = paramNmCommandBean.getActionMethod();
            
        try {
            Class<?> type = Class.forName(paramNmCommandBean.getActionClass());
            //usually the type is the same but the instance is not so need to get it from context.
            Object instance = KBContextService.getContext().getBean(type);
            Method m = instance.getClass().getMethod(method, NmCommandBean.class);
            m.invoke(instance, paramNmCommandBean);
        } catch (ClassNotFoundException e) {
            LOG.error("Required object not found", e);
            throw new RuntimeException(e);
        } catch (SecurityException e) {
            LOG.error("Access denied on looked up object", e);
            throw new RuntimeException(e);
        } catch (NoSuchMethodException e) {
            LOG.error("Referenced service does not have required method", e);
            throw new RuntimeException(e);
        } catch (IllegalArgumentException e) {
            LOG.error("Looked up method doesn't use this input parameter", e);
            throw new RuntimeException(e);
        } catch (IllegalAccessException e) {
            LOG.error("Illegal access on object", e);
            throw new RuntimeException(e);
        } catch (InvocationTargetException e) {
            LOG.error("Invocation error on method", e);
            throw new RuntimeException(e);
        }
        FormResult r = new FormResult();
        r.setStatus(FormProcessingStatus.SUCCESS);
        return r;
    }
    /*
    @Override
    public FormResult postProcess(NmCommandBean paramNmCommandBean, List<ObjectBean> paramList) throws WTException {
        return null;
    }

    @Override
    public FormResult postTransactionProcess(NmCommandBean paramNmCommandBean, List<ObjectBean> paramList)
            throws WTException {
        return null;
    }

    @Override
    public FormResult preProcess(NmCommandBean paramNmCommandBean, List<ObjectBean> paramList) throws WTException {
        return null;
    }

    @Override
    public void setDelegates(List<ObjectFormProcessorDelegate> paramList) {
        
    }

    @Override
    public FormResult setResultNextAction(FormResult paramFormResult, NmCommandBean paramNmCommandBean,
            List<ObjectBean> paramList) throws WTException {
        return null;
    }
*/
}
