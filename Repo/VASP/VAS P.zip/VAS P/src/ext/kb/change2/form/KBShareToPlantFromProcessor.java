package ext.kb.change2.form;

import java.util.List;

import org.apache.log4j.Logger;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormResult;
import com.ptc.netmarkets.util.beans.NmCommandBean;

import ext.kb.project.ProjectHelper;
import wt.change2.ChangeActivityIfc;
import wt.change2.ChangeHelper2;
import wt.fc.ObjectIdentifier;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.fc.WTReference;
import wt.inf.container.WTContainerRef;
import wt.log4j.LogR;
import wt.util.WTException;

/**
 * Custom form processor created for Share to plant action/wizard
 *
 * @author ext-atres
 *
 */
public class KBShareToPlantFromProcessor extends DefaultObjectFormProcessor {
	/**
	 * Logger variable
	 */
	protected static final Logger LOG = LogR.getLogger(KBShareToPlantFromProcessor.class.getName());

	@Override
	/**
	 * @param cmdBean
	 * @param objBeans
	 * @return
	 * @throws WTException
	 */
	public FormResult doOperation(final NmCommandBean cmdBean, final List<ObjectBean> objBeans) throws WTException {

		if (LOG.isDebugEnabled()) {
			LOG.debug("in doOperation");
			LOG.debug("Command Bean" + cmdBean);
			LOG.debug("Object Beans" + objBeans);
		}

		final ObjectIdentifier ectOid = cmdBean.getActionOid().getOidObject();
		final String projectID = cmdBean.getRequest().getParameter("contextPicker");

		if (LOG.isDebugEnabled()) {
			LOG.debug("ECT OID" + ectOid);
			LOG.debug("Project Oid" + projectID);
		}

		final ObjectReference changeTaskReference = ObjectReference.newObjectReference(ectOid);
		final WTReference projReference = new ReferenceFactory().getReference(projectID);

		final QueryResult resultingObjects = ChangeHelper2.service
				.getChangeablesAfter((ChangeActivityIfc) changeTaskReference.getObject());

		while (resultingObjects.hasMoreElements()) {
			final Persistable object = (Persistable) resultingObjects.nextElement();
			if (LOG.isDebugEnabled()) {
				LOG.debug("Sharing-" + object + "-To Project-" + projReference);
			}
			ProjectHelper.updateItemInProject(object, (WTContainerRef) projReference);

		}

		return super.doOperation(cmdBean, objBeans);
	}

}
