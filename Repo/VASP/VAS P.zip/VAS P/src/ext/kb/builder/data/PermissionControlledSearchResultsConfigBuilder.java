/* bcwti
 *
 * Copyright (c) 2010 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */
package ext.kb.builder.data;

import java.util.Map;

import com.ptc.core.components.descriptor.DescriptorConstants;
import com.ptc.jca.mvc.components.JcaColumnConfig;
import com.ptc.mvc.components.ColumnConfig;
import com.ptc.mvc.components.ComponentBuilder;
import com.ptc.mvc.components.ComponentBuilderType;
import com.ptc.mvc.components.ComponentParams;
import com.ptc.mvc.components.TableConfig;
import com.ptc.mvc.components.ds.DataSourceMode;
import com.ptc.netmarkets.search.SearchResultsParamHelper;
import com.ptc.netmarkets.search.SearchWebConstants;
import com.ptc.netmarkets.search.beans.SearchBean;
import com.ptc.netmarkets.search.rendering.ICriteriaBean;
import com.ptc.windchill.enterprise.search.mvc.builders.AbstractSearchResultsConfigBuilder;

import wt.util.WTException;

/**
 * Build SearchResultsTable [searchTableDescriptor.jspf]<BR>
 * <B>Supported API: </B>false <BR>
 * <BR>
 * <B>Extendable: </B>false
 *
 * @version 1.0
 *
 */
@ComponentBuilder(value = "ext.kb.accesscontrolled.searchResults", type = ComponentBuilderType.CONFIG_ONLY)
public class PermissionControlledSearchResultsConfigBuilder extends AbstractSearchResultsConfigBuilder {

    private static final org.apache.log4j.Logger LOG = wt.log4j.LogR.getLogger(PermissionControlledSearchResultsConfigBuilder.class
            .getName());

    /*
     * (non-Javadoc)
     *
     * @see
     * com.ptc.windchill.enterprise.search.mvc.builders.AbstractSearchResultsConfigBuilder#buildSearchComponentConfig
     * (com.ptc.windchill.enterprise.search.mvc.SearchComponentParams)
     */
    @Override
    protected void updateSearchComponentConfig(TableConfig table, ComponentParams params) throws WTException {

        SearchBean search_bean = (SearchBean) params.getAttribute(SearchWebConstants.SEARCH_BEAN); // search_bean.getHmCriteriaBean().get("1");
        Map<String, ICriteriaBean> hmCriteriaBean = search_bean.getHmCriteriaBean();
        ICriteriaBean criteriaTable = hmCriteriaBean.get("1");
        SearchResultsParamHelper search_paramHelper = (SearchResultsParamHelper) params
                .getAttribute(SearchWebConstants.SEARCH_PARAM_HELPER);


        table.setType(getObjectType(search_bean));
        
        //Below lines are commented to Hide the File and Edit menu on Search Results table
        //String menuBar_actionName = search_paramHelper.getSearchTableMenuActionModel();
        //table.setMenubarName(menuBar_actionName);
        
        table.setSingleViewOnly(search_paramHelper.isSingleViewOnly());
        table.setActionModel(search_paramHelper.getTableActions());

        ColumnConfig col1 = getComponentConfigFactory().newColumnConfig(
                DescriptorConstants.ColumnIdentifiers.GENERAL_STATUS_FAMILY, true);
        col1.setDistinguishWIPVersions(true);
        table.addComponent(col1);

        ColumnConfig col2 = getComponentConfigFactory().newColumnConfig(DescriptorConstants.ColumnIdentifiers.NUMBER,
                true);
        ((JcaColumnConfig) col2).setDescriptorProperty(DescriptorConstants.DescriptorProperties.TOOLTIP_ATTRIBUTE,
                "teaser");
        table.addComponent(col2);

        ColumnConfig col3 = getComponentConfigFactory().newColumnConfig(DescriptorConstants.ColumnIdentifiers.NAME,
                true);
        col3.setDefaultSecondarySort(true);
        ((JcaColumnConfig) col3).setDisplayLengthInTables("25");
        table.addComponent(col3);

        ColumnConfig col4 = getComponentConfigFactory().newColumnConfig(
                DescriptorConstants.ColumnIdentifiers.INFO_ACTION, false);
        // col4.setLabel("View Information");
        col4.setDataUtilityId("nmActions");
        ((JcaColumnConfig) col4).setDescriptorProperty(DescriptorConstants.ActionProperties.ACTION_NAME, "view");
        ((JcaColumnConfig) col4).setDescriptorProperty(DescriptorConstants.ActionProperties.OBJECT_TYPE, "object");
        col4.addComponent(col4);
//Commented the below code for SPR 2030074
//Right click actions was getting added on picker result table views
//        ColumnConfig col5 = getComponentConfigFactory().newColumnConfig(
//                DescriptorConstants.ColumnIdentifiers.NM_ACTIONS, false);
//        table.addComponent(col5);

        ColumnConfig col6 = getComponentConfigFactory().newColumnConfig(
                DescriptorConstants.ColumnIdentifiers.DESCRIPTION, true);
        ((JcaColumnConfig) col6).setDisplayLengthInTables("50");
        table.addComponent(col6);

        ColumnConfig col7 = getComponentConfigFactory().newColumnConfig("message", true);
        ((JcaColumnConfig) col7).setDisplayLengthInTables("50");
        table.addComponent(col7);

        ColumnConfig col8 = getComponentConfigFactory().newColumnConfig(DescriptorConstants.ColumnIdentifiers.VERSION,
                true);
        col8.setNeed("versionInfo.identifier.versionId");
        table.addComponent(col8);

        ColumnConfig col9 = getComponentConfigFactory().newColumnConfig(DescriptorConstants.ColumnIdentifiers.REVISION,
                true);
        col9.setNeed("revision");
        table.addComponent(col9);

        table.addComponent(createSearchThumbNailConfig());
        table.addComponent(createSmallThumbNailConfig());
        table.addComponent(createPtcNoteTextConfig());

        ColumnConfig col10 = getComponentConfigFactory().newColumnConfig(
                DescriptorConstants.ColumnIdentifiers.FORMAT_ICON, true);
        table.addComponent(col10);
    }
    
    @Override
	public DataSourceMode getDataSourceMode(){
		return DataSourceMode.SYNCHRONOUS;
	}
}
