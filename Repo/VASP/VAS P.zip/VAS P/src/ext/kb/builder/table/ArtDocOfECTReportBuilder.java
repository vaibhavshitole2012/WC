package ext.kb.builder.table;

import com.ptc.jca.mvc.components.JcaComponentParams;
import com.ptc.mvc.components.*;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import ext.kb.ui.report.methods.AttributesMethods;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import wt.change2.ChangeActivity2;
import wt.change2.ChangeHelper2;
import wt.change2.WTChangeActivity2;
import wt.doc.WTDocument;
import wt.epm.EPMDocument;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.part.WTPart;
import wt.query.ArrayExpression;
import wt.query.ClassAttribute;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.vc.wip.WorkInProgressHelper;
import wt.vc.wip.Workable;

import java.util.*;

@ComponentBuilder("ext.kb.builder.table.ArtDocOfECTReportBuilder")
public class ArtDocOfECTReportBuilder extends AbstractComponentConfigBuilder implements ComponentDataBuilder {

    private static final Logger logger = Logger.getLogger(ArtDocOfECTReportBuilder.class);
    private static final String ECT_NUMBER = "ECT_Number";
    private static final String NUMBER = "Number";
    private static final String NAME = "Name";
    private static final String STATE = "State";
    private static final String CREATOR = "Creator";
    private static final String VERSION = "Version";
    private static final String DOC_CONTENT_TYPE = "Doc Content Type";
    private static final String TYPE_OF_OBJECT = "Type of object";
    private static final String CHANGEABLE_TYPE = "Changeable type";
    private static final String PIPE = "\\|";
    private static final String AFFECTED = "Affected";
    private static final String RESULTING = "Resulting";
    private static final String ADHOC_TABLE = "adhocTable";
    private static final String TABLE_LABEL = "Art./Doc. of ECTs";
    private static final String ECT_NUMBER_CONSTRAINT = "ECT_Numberconstraint";
    private static final String NOT_LIKE = "notLike";
    private static final String NOT_EQUAL = "notEqual";
    private static final String EXPORT_ACTIONS = "report results table actions";

    @Override
    public ComponentConfig buildComponentConfig(ComponentParams params) throws WTException {
        ComponentConfigFactory factory = getComponentConfigFactory();
        TableConfig tableConfig = factory.newTableConfig();
        tableConfig.setId(ADHOC_TABLE);
        tableConfig.setLabel(TABLE_LABEL);
        tableConfig.setFreezable(true);
        tableConfig.setShowCount(true);
        tableConfig.setShowCustomViewLink(false);
        tableConfig.setSelectable(true);
        tableConfig.setConfigurable(false);
        tableConfig.setActionModel(EXPORT_ACTIONS);
        tableConfig.addComponent(factory.newColumnConfig(ECT_NUMBER, true));
        tableConfig.addComponent(factory.newColumnConfig(NUMBER, true));
        tableConfig.addComponent(factory.newColumnConfig(NAME, true));
        tableConfig.addComponent(factory.newColumnConfig(STATE, true));
        tableConfig.addComponent(factory.newColumnConfig(CREATOR, true));
        tableConfig.addComponent(factory.newColumnConfig(VERSION, true));
        tableConfig.addComponent(factory.newColumnConfig(DOC_CONTENT_TYPE, true));
        tableConfig.addComponent(factory.newColumnConfig(TYPE_OF_OBJECT, true));
        tableConfig.addComponent(factory.newColumnConfig(CHANGEABLE_TYPE, true));
        return tableConfig;
    }

    @Override
    public Object buildComponentData(ComponentConfig componentConfig, ComponentParams componentParams) throws Exception {
        logger.debug("ArtDocOfECTReportBuilder - buildComponentData started");
        List<Map<String, String>> objectsForReport = new ArrayList<>();
        String[] ectNumbers = componentParams.getParameter(ECT_NUMBER).toString().split(PIPE);
        logger.debug("ECT Numbers: " + Arrays.toString(ectNumbers));
        QueryResult changeTasks = getECTsByNumbers(ectNumbers, componentParams);
        while (changeTasks.hasMoreElements()) {
            ChangeActivity2 changeTask = (ChangeActivity2) changeTasks.nextElement();
            QueryResult affectedObjects = ChangeHelper2.service.getChangeablesBefore(changeTask);
            QueryResult resultingObjects = ChangeHelper2.service.getChangeablesAfter(changeTask);
            objectsForReport.addAll(addObjectsForReport(affectedObjects, changeTask.getNumber(), AFFECTED));
            objectsForReport.addAll(addObjectsForReport(resultingObjects, changeTask.getNumber(), RESULTING));
        }
        logger.debug("ArtDocOfECTReportBuilder - buildComponentData finished");
        return objectsForReport;
    }

    private QueryResult getECTsByNumbers(String[] ectNumbers, ComponentParams componentParams) throws WTException {
        QuerySpec queryForECTs = new QuerySpec(WTChangeActivity2.class);
        if (ectNumbers.length > 1 || !ectNumbers[0].equals(StringUtils.EMPTY)) {
            queryForECTs.appendWhere(new SearchCondition(new ClassAttribute(WTChangeActivity2.class, WTChangeActivity2.NUMBER),
                    getSearchCondition(componentParams), new ArrayExpression(ectNumbers)), new int[]{0});
        }
        return PersistenceServerHelper.manager.query(queryForECTs);
    }

    private String getSearchCondition(ComponentParams componentParams) throws WTException {
        NmCommandBean nmCommandBean = ((JcaComponentParams) componentParams).getHelperBean().getNmCommandBean();
        String ectNumberConstraint = ((String[]) nmCommandBean.getParameterMap().get(ECT_NUMBER_CONSTRAINT))[0];
        logger.debug("ECT constraint: " + ectNumberConstraint);
        if (ectNumberConstraint.equals(NOT_LIKE) || ectNumberConstraint.equals(NOT_EQUAL)) {
            return SearchCondition.NOT_IN;
        }
        return SearchCondition.IN;
    }

    private List<Map<String, String>> addObjectsForReport(QueryResult objects, String ectNumber, String changeableType) throws WTException {
        List<Map<String, String>> objectsForReport = new ArrayList<>();
        while (objects.hasMoreElements()) {
            Object object = objects.nextElement();
            if(object instanceof Workable && !WorkInProgressHelper.isWorkingCopy((Workable) object)) {
                if (object instanceof WTPart) {
                    objectsForReport.add(getWTPartRow((WTPart) object, ectNumber, changeableType));
                }
                if (object instanceof WTDocument) {
                    objectsForReport.add(getWTDocumentRow((WTDocument) object, ectNumber, changeableType));
                }
                if (object instanceof EPMDocument) {
                    objectsForReport.add(getEPMDocumentRow((EPMDocument) object, ectNumber, changeableType));
                }
            }
        }
        return objectsForReport;
    }

    private Map<String, String> getWTPartRow(WTPart part, String ectNumber, String changeableType) throws WTException {
        Map<String, String> row = new HashMap<>();
        logger.debug("WTPart: " + part);
        row.put(ECT_NUMBER, ectNumber);
        row.put(NUMBER, part.getNumber());
        row.put(NAME, part.getName());
        row.put(STATE, part.getLifeCycleState().getDisplay());
        row.put(CREATOR, part.getCreatorFullName());
        row.put(VERSION, AttributesMethods.getRevision(part));
        row.put(DOC_CONTENT_TYPE, StringUtils.EMPTY);
        row.put(TYPE_OF_OBJECT, part.getDisplayType().getLocalizedMessage(SessionHelper.getLocale()));
        row.put(CHANGEABLE_TYPE, changeableType);
        return row;
    }

    private Map<String, String> getWTDocumentRow(WTDocument document, String ectNumber, String changeableType) throws WTException {
        Map<String, String> row = new HashMap<>();
        logger.debug("WTDocument: " + document);
        row.put(ECT_NUMBER, ectNumber);
        row.put(NUMBER, document.getNumber());
        row.put(NAME, document.getName());
        row.put(STATE, document.getLifeCycleState().getDisplay());
        row.put(CREATOR, document.getCreatorFullName());
        row.put(VERSION, AttributesMethods.getRevision(document));
        row.put(DOC_CONTENT_TYPE, AttributesMethods.getDocContentType(document));
        row.put(TYPE_OF_OBJECT, document.getDisplayType().getLocalizedMessage(SessionHelper.getLocale()));
        row.put(CHANGEABLE_TYPE, changeableType);
        return row;
    }

    private Map<String, String> getEPMDocumentRow(EPMDocument epmDocument, String ectNumber, String changeableType) throws WTException {
        Map<String, String> row = new HashMap<>();
        logger.debug("EPMDocument: " + epmDocument);
        row.put(ECT_NUMBER, ectNumber);
        row.put(NUMBER, epmDocument.getNumber());
        row.put(NAME, epmDocument.getName());
        row.put(STATE, epmDocument.getLifeCycleState().getDisplay());
        row.put(CREATOR, epmDocument.getCreatorFullName());
        row.put(VERSION, AttributesMethods.getRevision(epmDocument));
        row.put(DOC_CONTENT_TYPE, StringUtils.EMPTY);
        row.put(TYPE_OF_OBJECT, epmDocument.getDisplayType().getLocalizedMessage(SessionHelper.getLocale()));
        row.put(CHANGEABLE_TYPE, changeableType);
        return row;
    }

}
