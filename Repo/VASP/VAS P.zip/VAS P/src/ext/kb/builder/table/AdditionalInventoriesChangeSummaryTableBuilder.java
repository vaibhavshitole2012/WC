package ext.kb.builder.table;

import wt.util.WTException;

import com.ptc.core.htmlcomp.tableview.ConfigurableTable;
import com.ptc.mvc.components.ComponentBuilder;
import com.ptc.mvc.components.ComponentConfig;
import com.ptc.mvc.components.ComponentParams;
import com.ptc.mvc.components.OverrideComponentBuilder;
import com.ptc.windchill.enterprise.change2.mvc.builders.tables.ChangeSummaryTableBuilder;

import ext.kb.tableview.AdditionalInventoriesChangeSummaryTableViews;

/**
 * KB Custom table builder for additional inventory items display window. ("changeNotice.changeSummary")
 * @author kissn
 *
 */

@ComponentBuilder({ "changeNotice.changeSummary" })
@OverrideComponentBuilder
public class AdditionalInventoriesChangeSummaryTableBuilder extends ChangeSummaryTableBuilder {

    @Override
    public ConfigurableTable buildConfigurableTable(String arg0) throws WTException {
        return new AdditionalInventoriesChangeSummaryTableViews();
    }

    public ComponentConfig buildComponentConfig(ComponentParams paramComponentParams) throws WTException {
        ComponentConfig conf = super.buildComponentConfig(paramComponentParams);
        return conf;
    }

}
