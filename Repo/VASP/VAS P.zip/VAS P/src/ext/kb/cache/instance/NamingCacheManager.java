package ext.kb.cache.instance;

import java.rmi.RemoteException;
import java.util.List;

import ext.kb.cache.KBCacheManager;
import ext.kb.dynamiclist.infoengine.PermissionControlledInfoEngineEnumerationInfoProvider;
import ext.kb.dynamiclist.naming.NameCatalogueEnumerationInfoProvider;

public class NamingCacheManager extends KBCacheManager {

	private static final long serialVersionUID = -2736248152914703585L;
	private static final String KEY = "NAMING_ID";
	private static final String KEY_INFO_PROVIDER = "NAMING_ID_INFO_PROVIDER";
	private static NamingCacheManager instance = null;

	public NameCatalogueEnumerationInfoProvider getNameCatalogueEnumerationInfoProvider() {
		return (NameCatalogueEnumerationInfoProvider) retrieve(KEY_INFO_PROVIDER);
	}

	public void setNameCatalogueEnumerationInfoProvider(
			NameCatalogueEnumerationInfoProvider nameCatalogueEnumerationInfoProvider) {
		store(KEY_INFO_PROVIDER, nameCatalogueEnumerationInfoProvider);
	}

	public NamingCacheManager() throws RemoteException {
		super(KEY);
	}

	public static synchronized void createCache() throws RemoteException {
		if (instance == null) {
			instance = new NamingCacheManager();
		}
	}

	public static NamingCacheManager getCache() throws RemoteException {
		if (instance == null) {
			createCache();
		}
		return instance;
	}

	public void store(List<?> list) {
		synchronized (NamingCacheManager.class) {
			super.store(list);
		}
	}
}
