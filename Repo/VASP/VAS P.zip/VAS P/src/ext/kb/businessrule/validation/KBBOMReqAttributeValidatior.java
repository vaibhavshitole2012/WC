package ext.kb.businessrule.validation;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.core.businessRules.feedback.RuleFeedbackType;
import com.ptc.core.businessRules.validation.RuleValidationKey;
import com.ptc.core.lwc.server.PersistableAdapter;

import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.DBUtils;
import ext.kb.util.KBConstants;
import ext.kb.util.KBTypeIdProvider;
import ext.kb.util.KBUtils;
import wt.doc.WTDocument;
import wt.epm.EPMDocument;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.part.WTPartSubstituteLink;
import wt.part.WTPartUsageLink;
import wt.preference.PreferenceHelper;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.vc.config.LatestConfigSpec;
import wt.vc.struct.StructHelper;

public class KBBOMReqAttributeValidatior extends KBValidation {
	private static final Logger LOG = Logger.getLogger(KBBOMReqAttributeValidatior.class);
	private static final String VALIDATION_RESULT = "VALIDATION_RESULT";
	
	@Override
	public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList, RuleValidationKey paramRuleValidationKey) throws WTException {
		LOG.debug("paramPersistable :: "+paramPersistable+"\n paramMap ::"+paramMap +"\n paramList :: "+paramList);
		boolean isvalid=true;
		List<RuleFeedbackMessage> localValidationResult = new ArrayList<>();
		paramRuleValidationKey.addToProcessingMap(VALIDATION_RESULT, localValidationResult);
		List<RuleFeedbackMessage> validationResult = (List<RuleFeedbackMessage>) paramRuleValidationKey
				.getProcessingMapValue(VALIDATION_RESULT);

		if(paramPersistable instanceof WTPart){
			WTPart part=(WTPart) paramPersistable;
			boolean isEbomPart = KBUtils.isEbomPart(part);
			if(!isEbomPart) {
				LOG.info("Found part is MBOM, skipping.");
				return isvalid;
			}
			String prefValue="";
			prefValue=getPrefValue("KB_REQ_ATTR_ARTICLE");
			LOG.debug("PrefValue::>>"+prefValue);				
			validationResult=validateReqatrributesonparent(prefValue,part, paramRuleValidationKey, validationResult);
			QueryResult childpartQr = StructHelper.service.navigateUsesToIteration(part,WTPartUsageLink.class, true, new LatestConfigSpec());
			if(childpartQr.size()>0){
			LOG.debug("Children qr :: "+childpartQr.size());
			while(childpartQr.hasMoreElements()){
				WTPart childpart=(WTPart) childpartQr.nextElement();
				LOG.debug("childPart number ::"+childpart.getNumber());
				LOG.debug("prefValue ::>>"+prefValue);
				if(prefValue!=null && !("".equalsIgnoreCase(prefValue))){
					ArrayList missingattrlist= getMissingattributelist(prefValue, childpart);
					String missingattr=formMissingattrString(missingattrlist);
					LOG.debug("ChildPartnumber ::>>"+childpart.getNumber()+" :: MissingAttrlist ::>>"+missingattr);
					if(!missingattrlist.isEmpty()){
						validationResult=formValidationResult(paramRuleValidationKey, validationResult, missingattr, childpart.getNumber());
						}
					}
				validationResult=validateReqAttributesondescribeByDoc(childpart,paramRuleValidationKey, validationResult);
				}
			}
			 List<WTPartUsageLink> usageLinks = DBUtils.retrieveLinks(WTPartUsageLink.class, part,
						WTPartUsageLink.ROLE_BOBJECT_ROLE);
				
				for (WTPartUsageLink link : usageLinks) {
					QueryResult allLinks = PersistenceHelper.manager.navigate(link,
							WTPartSubstituteLink.SUBSTITUTES_ROLE, WTPartSubstituteLink.class, true);
					LOG.debug("allLinks size : "+allLinks.size());
					
					while (allLinks.hasMoreElements()) {
						WTPartMaster obj = (WTPartMaster) allLinks.nextElement();
						WTPart subPart =(WTPart) KBUtils.getLatestIteration(obj);
						if(prefValue!=null && !("".equalsIgnoreCase(prefValue))){
							ArrayList missingattrlist= getMissingattributelist(prefValue, subPart);
							String missingattr=formMissingattrString(missingattrlist);
							LOG.debug("Substitute Part ::>>"+subPart.getNumber()+" :: MissingAttrlist ::>>"+missingattr);
							if(!missingattrlist.isEmpty()){
								validationResult=SubFormValidationResult(paramRuleValidationKey, validationResult, missingattr, subPart.getNumber());
								}
							}
						validationResult=validateReqAttributesondescribeByDoc(subPart,paramRuleValidationKey, validationResult);
						}
					}
				
			LOG.debug("Is Empty : "+CollectionUtils.isEmpty(localValidationResult));
			if (!CollectionUtils.isEmpty(localValidationResult)) {
				paramList.addAll(localValidationResult);
				isvalid = false;
			}
			if (LOG.isDebugEnabled()) {
				LOG.debug("exiting isRulesValid()");
				LOG.debug("returning: " + isvalid);
			}
		}



		return isvalid;
	}
	
	

	private List<RuleFeedbackMessage> SubFormValidationResult(RuleValidationKey paramRuleValidationKey,
			List<RuleFeedbackMessage> validationResult, String missingattr, String number) {
		RuleFeedbackType feedbackType = RuleFeedbackType.ERROR;
		validationResult = (List<RuleFeedbackMessage>) paramRuleValidationKey
					.getProcessingMapValue(VALIDATION_RESULT);
			validationResult.add(new RuleFeedbackMessage(
					new WTMessage(RESOURCE, BusinessRuleRB.KB_SUBSTITUTE_MISSING_ATTRIBUTE, new Object[] { missingattr,number }),
					feedbackType));	
			
			return validationResult;
	}



	public static HashMap<String, Object> getAttribuetvales(Persistable part,String[] attrval){
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		PersistableAdapter obj;
		try {
			
			obj = new PersistableAdapter(part,null,Locale.US,null);
			
			obj.load(attrval);
			
			for (String attrName : attrval) {
				try {
					Object objAttr = obj.get(attrName);
					LOG.debug("Attribute descriptor ::>>"+obj.getAttributeDescriptor(attrName).getLabel());
					
					LOG.debug("attrName :: "+attrName+";;objAttr :: "+objAttr);
					if(objAttr==null){
					resultMap.put(attrName, obj.getAttributeDescriptor(attrName).getLabel());
					}
					
				} catch (WTException ex) {
					LOG.debug(ex.getLocalizedMessage(),ex);
				}
			}
		} catch (WTException e) {
			LOG.debug(e.getLocalizedMessage(),e);
		}
		

		
		return resultMap;
	}

	

	@Override
	public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList) throws WTException {
		return false;
	}
	
	private static ArrayList getMissingattributelist(String prefValue,Persistable object){
		
		ArrayList<String> missingattrlist=new ArrayList();		
		String[] attrarr=prefValue.split(",");	
		HashMap<String,Object> resultMap=getAttribuetvales(object, attrarr);
		
		for(int i=0;i<attrarr.length;i++){
			if(resultMap.containsKey(attrarr[i])){
				missingattrlist.add((String) resultMap.get(attrarr[i]));
				
			}
		}
		
		
		return missingattrlist;
	}
	
	private static String getPrefValue(String prefname){
		String prefValue="";
		try {
			prefValue = (String) PreferenceHelper.service.getValue(prefname, KBConstants.WINDCHILL);
			LOG.debug("prefValue::>>"+prefValue);
		} catch (WTException e) {
			LOG.error(e.getLocalizedMessage(),e);
		}
		return prefValue;
	}
	
	private static List<RuleFeedbackMessage> validateReqatrributesonparent(String prefValue1,WTPart parentpart,RuleValidationKey paramRuleValidationKey,List<RuleFeedbackMessage> validationResult ){
		QueryResult describedBydocQR;
		if(prefValue1!=null && !("".equalsIgnoreCase(prefValue1))){
		ArrayList missingattrlist= getMissingattributelist(prefValue1, parentpart);
		String missingattr=formMissingattrString(missingattrlist);
		
	LOG.debug("ChildPartnumber ::>>"+parentpart.getNumber()+" :: MissingAttrlist ::>>"+missingattr);
	if(!missingattrlist.isEmpty()){
		validationResult=formValidationResult(paramRuleValidationKey, validationResult, missingattr, parentpart.getNumber());

	}
		}
	validationResult=validateReqAttributesondescribeByDoc(parentpart, paramRuleValidationKey, validationResult);
		
		return validationResult;
	}
	
	private static List<RuleFeedbackMessage> validateReqAttributesondescribeByDoc(WTPart part,RuleValidationKey paramRuleValidationKey,List<RuleFeedbackMessage> validationResult){
		
		QueryResult describedBydocQR;
try {
	describedBydocQR = StructHelper.service.navigateDescribedBy(part);

		
		LOG.debug("validateReqatrributesonparent getDecsribeByDoc ::>>"+describedBydocQR.size());
		
		while(describedBydocQR.hasMoreElements()){
			Persistable doc=(Persistable) describedBydocQR.nextElement();
           
			if(doc instanceof WTDocument){
				WTDocument wtdoc=(WTDocument) doc;
				LOG.debug("WTDocument number :: "+wtdoc.getNumber());
				if(KBTypeIdProvider.isDescendant(wtdoc, "TECHDRWDOC") || KBTypeIdProvider.isDescendant(wtdoc, "TECHDOC")){
				String prefValue=getPrefValue("KB_REQ_ATTR_DOCUMENT");
				
				if(prefValue!=null && !("".equalsIgnoreCase(prefValue))){
				ArrayList missingdocattrlist= getMissingattributelist(prefValue, wtdoc);
				String missingdocattr=formMissingattrString(missingdocattrlist);
				ArrayList missingcaddrwattrlist=new ArrayList<>();
				if(KBTypeIdProvider.isDescendant(wtdoc, "TECHDRWDOC")){
					String techdrwprefValue=getPrefValue("KB_REQ_ATTR_TECHNICALDRAWING");
					 missingcaddrwattrlist= getMissingattributelist(techdrwprefValue, wtdoc);
					String missingtechdrwattr=formMissingattrString(missingcaddrwattrlist);
					if(!missingdocattrlist.isEmpty() && !missingcaddrwattrlist.isEmpty()){
					missingdocattr=missingdocattr+","+missingtechdrwattr;
					}
					else if(missingdocattrlist.isEmpty() && !missingcaddrwattrlist.isEmpty()){
						missingdocattr=missingtechdrwattr;
					} 
				}
				LOG.debug("wtdocnumber ::>>"+wtdoc.getNumber()+" :: MissingAttrlist ::>>"+missingdocattr);
				if(!missingdocattrlist.isEmpty() || !missingcaddrwattrlist.isEmpty()){
					validationResult=formValidationResult(paramRuleValidationKey, validationResult, missingdocattr, wtdoc.getNumber());

				}
				}
			}
			}
			if(doc instanceof EPMDocument){
				EPMDocument epmdoc=(EPMDocument) doc;
				LOG.debug("EPMDocument number :: "+epmdoc.getNumber());
				
				if(KBTypeIdProvider.isDescendant(epmdoc, "KBCADDRW")){ 
				String prefValue=getPrefValue("KB_REQ_ATTR_CADDRAWING");
				if(prefValue!=null && !("".equalsIgnoreCase(prefValue))){
				ArrayList missingdocattrlist= getMissingattributelist(prefValue, epmdoc);
				String missingdocattr=formMissingattrString(missingdocattrlist);
				LOG.debug("epmdocnumber ::>>"+epmdoc.getNumber()+" :: MissingAttrlist ::>>"+missingdocattr);
				if(!missingdocattrlist.isEmpty()){
					validationResult=formValidationResult(paramRuleValidationKey, validationResult, missingdocattr, epmdoc.getNumber());

				}
				}
				}
			}

		}
	} catch (WTException e) {
		LOG.debug(e.getLocalizedMessage(),e);
	}
	return validationResult;
		
	}
	
	private static String formMissingattrString(ArrayList missingattrlist){
		String missingattr="";
		for(int i=0;i<missingattrlist.size();i++){
			LOG.debug("missingattrlist :: >>"+missingattrlist.get(i));
			
			if(missingattrlist.size()>1){
				if("".equals(missingattr)){
				missingattr=missingattrlist.get(i).toString();
				}
				else{					
					missingattr=missingattr+","+missingattrlist.get(i);
				}
			}
			else
				missingattr=missingattrlist.get(i).toString();
		}
		return missingattr;
	}
	
	private static List<RuleFeedbackMessage> formValidationResult(RuleValidationKey paramRuleValidationKey,List<RuleFeedbackMessage> validationResult,String missingattr,String objnumber){
		RuleFeedbackType feedbackType = RuleFeedbackType.ERROR;
		validationResult = (List<RuleFeedbackMessage>) paramRuleValidationKey
					.getProcessingMapValue(VALIDATION_RESULT);
			validationResult.add(new RuleFeedbackMessage(
					new WTMessage(RESOURCE, BusinessRuleRB.KB_COMPONENT_MISSING_ATTRIBUTE, new Object[] { missingattr,objnumber }),
					feedbackType));	
			
			return validationResult;

	}

	
}
