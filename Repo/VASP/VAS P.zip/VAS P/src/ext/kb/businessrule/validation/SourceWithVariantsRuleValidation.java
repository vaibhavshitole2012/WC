package ext.kb.businessrule.validation;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.apache.log4j.Logger;
import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.core.businessRules.feedback.RuleFeedbackType;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.TypeIdentifierHelper;
import com.ptc.generic.iba.AttributeService;
import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.KBConstants;
import ext.kb.util.KBTypeIdProvider;
import ext.kb.workflow.EPMChangeUtils;
import wt.change2.ChangeException2;
import wt.change2.ChangeHelper2;
import wt.change2.Changeable2;
import wt.change2.WTChangeActivity2;
import wt.change2.WTChangeOrder2;
import wt.configurablelink.ConfigurableRevisionLink;
import wt.doc.WTDocument;
import wt.epm.EPMDocument;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.util.WTException;
import wt.util.WTMessage;

public class SourceWithVariantsRuleValidation extends KBValidation {

	private static final Logger LOG = Logger.getLogger(SourceWithVariantsRuleValidation.class.getName());

	@Override
	public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList) throws WTException {
		boolean shouldBeValidated = false;
		boolean status = true;
		setFeedbackType(RuleFeedbackType.WARNING);
		if ((KBTypeIdProvider.isDescendant(paramPersistable, "KBCADDRW")
				|| KBTypeIdProvider.isDescendant(paramPersistable, "KBDOC")
				|| KBTypeIdProvider.isDescendant(paramPersistable, "REFDOC")) && isSourceDocument(paramPersistable)) {
			LOG.debug("Object has valid type to be validated");
			shouldBeValidated = true;
		}

		if (!shouldBeValidated)
			return status;

		WTChangeOrder2 changeNotice = null;
		QueryResult resultingItems = null;

		try {
			changeNotice = EPMChangeUtils.getChangeNoticeFromPersistable(paramPersistable);
			if (changeNotice != null) {
				resultingItems = EPMChangeUtils.getResultingItems(changeNotice);
			}
		} catch (WTException e) {
			LOG.error("Unable retrieve ECN data from given Persistable");
		}

		if (resultingItems == null) {
			LOG.debug("Resulting items are empty, returning.");
			return status;
		}

		status = validateResultingObjects(resultingItems, paramPersistable, paramList);

		LOG.debug("Exiting with status: " + status);
		return status;
	}

	private boolean validateResultingObjects(QueryResult resultingItems, Persistable paramPersistable,
			List<RuleFeedbackMessage> paramList) {
		List<Persistable> resultingVariantsFromECN = getResultingVariantsFromECN(resultingItems);
		ArrayList<Persistable> variants = getVariants((Persistable) paramPersistable);
		boolean isValid = !variants.retainAll(resultingVariantsFromECN);

		if (!isValid) {
			paramList.add(new RuleFeedbackMessage(new WTMessage(RESOURCE, BusinessRuleRB.SOURCE_WITH_VARIANT,
					new Object[] { paramPersistable, resultingVariantsFromECN }), getFeedbackType()));
			return false;
		}

		return true;
	}

	private boolean isSourceDocument(Persistable persistable) {
		String sapIdx = AttributeService.getAttribute(persistable, KBConstants.KBSAP_IDX_IBA);
		if (sapIdx == null) {
			LOG.debug("Sap idx is empty, returning.");
			return false;
		}
		LOG.debug("Got sap idx: " + sapIdx);
		if (sapIdx.equals("000")) {
			return true;
		}
		return false;
	}

	private WTChangeActivity2 getChangeActivityFromPersistable(Persistable persistable)
			throws ChangeException2, WTException {
		WTChangeActivity2 changeActivity = null;
		QueryResult latestChangeActivities = ChangeHelper2.service
				.getAffectingChangeActivities((Changeable2) persistable, true);
		while (latestChangeActivities.hasMoreElements()) {
			Object obj = latestChangeActivities.nextElement();
			if (obj instanceof WTChangeActivity2) {
				changeActivity = (WTChangeActivity2) obj;
				break;
			}
		}
		return changeActivity;
	}

	private ArrayList<Persistable> getVariants(Persistable document) {
		ArrayList<Persistable> documents = new ArrayList<Persistable>();
		try {
			QueryResult allLinks = PersistenceHelper.manager.navigate(document, ConfigurableRevisionLink.ALL_ROLES,
					ConfigurableRevisionLink.class, true);
			while (allLinks.hasMoreElements()) {
				Object obj = allLinks.nextElement();
				if (obj instanceof WTDocument) {
					WTDocument doc = (WTDocument) obj;
					TypeIdentifier targetType = wt.type.TypedUtilityServiceHelper.service.getTypeIdentifier(doc);
					boolean hasValidType = isDocumentAppropriateType(targetType);
					if (hasValidType)
						documents.add((WTDocument) obj);
				} else if (obj instanceof EPMDocument) {
					EPMDocument doc = (EPMDocument) obj;
					TypeIdentifier targetType = wt.type.TypedUtilityServiceHelper.service.getTypeIdentifier(doc);
					boolean hasValidType = isDocumentAppropriateType(targetType);
					if (hasValidType)
						documents.add((EPMDocument) obj);
				}
			}
		} catch (WTException e) {
			LOG.error("Unable to query for source document of " + document, e);
		}
		return documents;
	}

	private boolean isDocumentAppropriateType(TypeIdentifier targetType) {
		return targetType.isEquivalentTypeIdentifier(TypeIdentifierHelper.getTypeIdentifier("com.ptc.KBCertificate"))
				|| targetType.isEquivalentTypeIdentifier(TypeIdentifierHelper.getTypeIdentifier("com.ptc.KBStandard"))
				|| targetType.isEquivalentTypeIdentifier(
						TypeIdentifierHelper.getTypeIdentifier("com.ptc.KBTechnicalDocument"))
				|| targetType.isEquivalentTypeIdentifier(
						TypeIdentifierHelper.getTypeIdentifier("com.ptc.KBTechnicalDrawing"))
				|| targetType
						.isEquivalentTypeIdentifier(TypeIdentifierHelper.getTypeIdentifier("com.ptc.DesignCADDrw"));
	}

	private List<Persistable> getResultingVariantsFromECN(QueryResult resultingItems) {
		List<Persistable> persistablesFromECN = new ArrayList<>();

		while (resultingItems.hasMoreElements()) {
			Object resultingObject = resultingItems.nextElement();
			LOG.debug("Validating resulting object : " + resultingObject);
			if ((resultingObject instanceof EPMDocument || resultingObject instanceof WTDocument)
					&& !isSourceDocument((Persistable) resultingObject)) {
				persistablesFromECN.add((Persistable) resultingObject);
			}
		}

		return persistablesFromECN;
	}
}
