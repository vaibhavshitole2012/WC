package ext.kb.businessrule.validation;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.core.businessRules.feedback.RuleFeedbackType;
import com.ptc.windchill.enterprise.attachments.server.AttachmentsHelper;
import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.KBType;
import org.apache.commons.io.FilenameUtils;
import org.apache.log4j.Logger;
import wt.content.*;
import wt.doc.WTDocument;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.log4j.LogR;
import wt.util.WTException;
import wt.util.WTMessage;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class KBDocPrimaryContentValidator extends KBValidation {

    private static final List<String> ALLOWED_FILE_TYPES;
    protected static final Logger LOG = LogR.getLogger(KBDocPrimaryContentValidator.class.getName());

    static {
        ALLOWED_FILE_TYPES = Arrays.asList("DOC", "doc", "docx", "DOCX", "ppt", "PPT", "pptx", "PPTXxls", "xlsx", "XLS", "XLSX", "eps", "EPS", "PS", "ps", "VSD", "vsd", "MPP", "mpp", "pdf", "PDF," +
                "dxf", "DXF", "stp", "STP", "tiff", "tif", "TIFF", "TIF", "JT", "jt", "cgm", "CGM", "zip", "ZIP", "jar", "JAR");
    }

    @Override
    public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap, List<RuleFeedbackMessage> paramList) throws WTException {
        boolean isValid = true;
        if (isValidForValidation(paramPersistable)) {
            WTDocument document = (WTDocument) paramPersistable;
            QueryResult primaryContent = AttachmentsHelper.service.getAttachments(document, ContentRoleType.PRIMARY);
            QueryResult secondaryContent = AttachmentsHelper.service.getAttachments(document, ContentRoleType.SECONDARY);
            if (isEmpty(primaryContent) && isEmpty(secondaryContent)) {
                paramList.add(getRuleFeedbackMessage(BusinessRuleRB.KB_DOC_PRIMARY_CONTENT_EMPTY_ERROR_MSG, RuleFeedbackType.ERROR));
                isValid = false;
            } 
                      
            else if (hasInValidType(primaryContent) && hasInValidType(secondaryContent)) {
                paramList.add(getRuleFeedbackMessage(BusinessRuleRB.KB_DOC_PRIMARY_CONTENT_TYPE, RuleFeedbackType.WARNING));
                isValid = false;
            }
            if (LOG.isDebugEnabled()) {
                LOG.debug("Validated document: " + document.getNumber());
                LOG.debug("PrimaryContent size: " + primaryContent.size());
                LOG.debug("SecondaryContent size: " + secondaryContent.size());
                LOG.debug("Param List: " + paramList);
            }
        }
        return isValid;
    }


    private boolean hasInValidType(QueryResult content) {
        boolean result = false;	
        int inValidsize = 0;
        while (content.hasMoreElements()) {
            Object object = content.nextElement();
            if (object instanceof ApplicationData) {
                ApplicationData appData = (ApplicationData) object;
                String fileName = appData.getFileName();
                String extension = FilenameUtils.getExtension(fileName);
                LOG.debug("fileName: " + fileName);
                LOG.debug("extension: " + extension);
                LOG.debug("Allowed extension: " + ALLOWED_FILE_TYPES);
                if (!ALLOWED_FILE_TYPES.contains(extension)) {
                    inValidsize = inValidsize+1;
                }
            }
        }
        if (content.size() == inValidsize){
         result = true;
        }
        return result;
    }

    private boolean isEmpty(QueryResult content) {
        return content.size() == 0;
    }


    private RuleFeedbackMessage getRuleFeedbackMessage(String warningMessage, RuleFeedbackType typeOfMessage) {
        WTMessage message = new WTMessage(RESOURCE, warningMessage, new Object[]{});
        return new RuleFeedbackMessage(message, typeOfMessage);
    }

    private boolean isValidForValidation(Persistable persistable) {
        return KBType.isDescendedFrom(persistable, "com.ptc.KBTechnicalDrawing")
                || KBType.isDescendedFrom(persistable, "com.ptc.KBTechnicalDocument")
                || KBType.isDescendedFrom(persistable, "com.ptc.KBCertificate")
                || KBType.isDescendedFrom(persistable, "com.ptc.KBProjectInput")
                || KBType.isDescendedFrom(persistable, "com.ptc.KBStandard");
    }

    @Override
    public void setFeedbackType(RuleFeedbackType feedbackType) {
        super.setFeedbackType(RuleFeedbackType.WARNING);
    }
}
