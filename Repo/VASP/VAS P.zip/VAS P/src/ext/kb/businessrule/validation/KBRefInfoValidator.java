package ext.kb.businessrule.validation;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.apache.log4j.Logger;
import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.core.businessRules.feedback.RuleFeedbackType;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.TypeIdentifierHelper;
import com.ptc.generic.iba.AttributeService;
import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.KBConstants;
import ext.kb.util.KBType;
import ext.kb.util.ObjectRevisionHelper;
import wt.configurablelink.ConfigurableLinkHelper;
import wt.configurablelink.ConfigurableReferenceLink;
import wt.fc.BinaryLink;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.collections.WTArrayList;
import wt.fc.collections.WTCollection;
import wt.fc.collections.WTHashSet;
import wt.fc.collections.WTSet;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.vc.Mastered;

public class KBRefInfoValidator extends KBValidation{

	private static final String KB_KIT_BOM = "com.ptc.KBKitBOM";
	private static final TypeIdentifier REF_INFO_LINK = TypeIdentifierHelper.getTypeIdentifier("com.ptc.KBRefInfoLink");
	private static final List VALID_LINK_TYPES_FOR_KIT = Arrays.asList("215", "617", "619");
	private static final List VALID_LINK_TYPES_FOR_ARTICLE = Arrays.asList("215","216", "617", "619");
	private static final String PART_CATEGORY_10 = "10";
	private static final String GEKLA_SUFFIX_97 = "97";
	private static final String PREFIX_NUMBER = "OPK";
	private static final Logger LOG = Logger.getLogger(KBRefInfoValidator.class.getName());
	
	@Override
	public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList) throws WTException {
		LOG.debug("Validation for RefInfoRule");
		String category = AttributeService.getAttribute(paramPersistable, KBConstants.KB_PART_CATEGORY_IBA);
		boolean isPart = paramPersistable instanceof WTPart;

		if (isValidatedKitPart(paramPersistable)) {
			LOG.debug("Starting validation for" +BusinessRuleRB.REF_INFO_RULE_FOR_KIT_PARTS);
			boolean foundLinkedPart = containsValidLinksForKitPart(paramPersistable, VALID_LINK_TYPES_FOR_KIT);
			if (!foundLinkedPart) {
				LOG.debug("Cannot find valid linked part for given KIT Part");
				paramList.add(getErrorFeedbackMessage(BusinessRuleRB.REF_INFO_RULE_FOR_KIT_PARTS));
				return false;
			}
		} else if (isPart && !PART_CATEGORY_10.equals(category)) {
			LOG.debug("Starting validation for" +BusinessRuleRB.REF_INFO_RULE_FOR_WT_PARTS);
			boolean foundLinkedPart = containsValidLinksForWtPart(paramPersistable, VALID_LINK_TYPES_FOR_ARTICLE);
			if (foundLinkedPart) {
				LOG.debug("Found linked part via invalid type of link for Wtpart");
				paramList.add(getErrorFeedbackMessage(BusinessRuleRB.REF_INFO_RULE_FOR_WT_PARTS));
				return false;
			}
		}
		LOG.debug("No found invalid objects for RefInfoRule");
		return true;
	}

	/**
	 * Method that checks if given object contains at least one valid link for this object
	 * 
	 * @param paramPersistable - Object to check
	 * @param validLinkTypesForKit - list of valid types for link
	 * @return true if at least one valid link exist,otherwise return false
	 */
	private boolean containsValidLinksForKitPart(Persistable paramPersistable, List validLinkTypesForKit)
			throws WTException {
		WTHashSet refInfoLinks = new WTHashSet();
		refInfoLinks.addAll(getConfigurableLinksByRole(paramPersistable, REF_INFO_LINK, BinaryLink.ROLE_AOBJECT_ROLE));
		LOG.debug("found" + refInfoLinks.size() +" links");
		for (Object object : refInfoLinks) {
			ObjectReference linkRef = (ObjectReference) object;
			ConfigurableReferenceLink link = (ConfigurableReferenceLink) linkRef.getObject();
			boolean isPart = (getOtherObjectFromLink(paramPersistable, link) instanceof WTPart);
			if (isValidLink(link, validLinkTypesForKit) && isPart) {
				LOG.debug("Given link is valid");
				return true;
			}
		}
		LOG.debug("Given object doesn't contain valid links");
		return false;
	}
	
	
	/**
	 * Method that checks if given object contains at least one valid link for this object
	 * 
	 * @param paramPersistable - Object to check
	 * @param validLinkTypesForWTPart - list of valid types for link
	 * @return true if at least one valid link exist,otherwise return false
	 */
	private boolean containsValidLinksForWtPart(Persistable paramPersistable, List validLinkTypesForWTPart)
			throws WTException {
		WTHashSet refInfoLinks = new WTHashSet();
		refInfoLinks.addAll(getConfigurableLinksByRole(paramPersistable, REF_INFO_LINK, BinaryLink.ROLE_AOBJECT_ROLE));
		LOG.debug("found" + refInfoLinks.size() +" links");
		for (Object object : refInfoLinks) {
			ObjectReference linkRef = (ObjectReference) object;
			ConfigurableReferenceLink link = (ConfigurableReferenceLink) linkRef.getObject();
			if (isValidLink(link, validLinkTypesForWTPart)) {
				LOG.debug("Given link is valid");
				return true;
			}
		}
		LOG.debug("Given object doesn't contain valid links");
		return false;
	}

	/**
	 * Method that checks if given object should be validated for the current business rule
	 * 
	 * @param persistable - Object to check
	 * @return true if the object meets the requirements, otherwise false
	 */
	private boolean isValidatedKitPart(Persistable persistable) {
		boolean isKitPart = KBType.isOfType(persistable, KB_KIT_BOM);
		String category = AttributeService.getAttribute(persistable, KBConstants.KB_PART_CATEGORY_IBA);
		String number = AttributeService.getAttribute(persistable, KBConstants.NUMBER);
		String gekla = AttributeService.getAttribute(persistable, KBConstants.GEKLA_IBA);
		gekla = (gekla == null) ? "" : gekla;
		number = (number == null) ? "" : number;
		LOG.debug("Number of part: " + number + " Gekla: " + gekla + " Category: " + category + " Is Kit part: "
				+ isKitPart);
		return isKitPart && number.startsWith(PREFIX_NUMBER) && PART_CATEGORY_10.equals(category)
				&& gekla.endsWith(GEKLA_SUFFIX_97);
	}
	
	/**
	 * Method that checks if given link is valid
	 * 
	 * @param link - Object to check
	 * @param validLinkTypes - list of valid types for link
	 * @return true if link contains valid type
	 */
	private boolean isValidLink(ConfigurableReferenceLink link, List validLinkTypes) {
		Object linkType = AttributeService.getAttribute(link, KBConstants.KB_TYPE_DESIGNATION);
		return validLinkTypes.contains(linkType);
	}

	/**
	 * Method to extract given type of configurable links from given object
	 * 
	 * @param roleA - object from links are extracted
	 * @param linkTypeIdentifier - type of link
	 * @param roleSide - role from link
	 * @return set of links of given type
	 */
	private WTSet getConfigurableLinksByRole(Object roleA, TypeIdentifier linkTypeIdentifier, String roleSide)
			throws WTException {
		WTSet result = new WTHashSet();
		WTCollection list = new WTArrayList();
		list.add(roleA);
		WTSet configurableLinks = ConfigurableLinkHelper.service.getConfigurableLinks(list, roleSide,
				linkTypeIdentifier);
		for (Object objRef : configurableLinks) {
			ObjectReference linkRef = (ObjectReference) objRef;
			Persistable link = linkRef.getObject();
			result.add(link);
		}
		LOG.debug("found" + result.size() +" links");
		return result;
	}
	
	/**
	 * Method, which return the other object from link
	 * 
	 * @param object - object 
	 * @param link - type of link
	 * @return the other object from link
	 */
	private Persistable getOtherObjectFromLink(Persistable object, ConfigurableReferenceLink link) throws WTException {
		Persistable otherObject = link.getOtherObject(object);
		if (otherObject instanceof WTPartMaster) {
			otherObject = ObjectRevisionHelper.getLatestVersionByMastered((Mastered) otherObject);
		}
		return otherObject;
	}
	
	/**
	 * Method, which return the error message for the current business rule
	 * 
	 * @param message - message 
	 * @return the error message
	 */
	private RuleFeedbackMessage getErrorFeedbackMessage(String message) {
		WTMessage wtMessage = new WTMessage(RESOURCE, message, null);
		return new RuleFeedbackMessage(wtMessage, RuleFeedbackType.ERROR);
	}

}
