package ext.kb.businessrule.validation.dto;

import java.util.ArrayList;
import java.util.List;

import com.ptc.core.businessRules.validation.RuleValidationKey;
import com.ptc.core.businessRules.validation.RuleValidationResult;
import com.ptc.core.businessRules.validation.RuleValidationStatus;

public class KBRuleValidationResult extends RuleValidationResult{

	
	public List<ValidationReport> validationReports = null;
	
	public KBRuleValidationResult(RuleValidationKey paramRuleValidationKey,
			Object paramObject, RuleValidationStatus paramRuleValidationStatus) {
		super(paramRuleValidationKey, paramObject, paramRuleValidationStatus);
		
	}

	public KBRuleValidationResult(RuleValidationResult aResult) {
		super(aResult.getValidationKey(), aResult.getTargetObject(), aResult.getStatus());
		
	}
	public List<ValidationReport> getValidationReports() {
		if(validationReports == null){
			validationReports = new ArrayList<ValidationReport>();
		}
		return validationReports;
	}
	
	public void addValidationReport(ValidationReport report) {
		if(report != null){
			getValidationReports().add(report);
		}
	
	}
	
	

}
