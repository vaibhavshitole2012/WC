package ext.kb.businessrule.validation;

import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;

import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.core.businessRules.feedback.RuleFeedbackType;
import com.ptc.core.businessRules.validation.BOMReleaseRuleValidator;
import com.ptc.core.businessRules.validation.RuleValidationCriteria;
import com.ptc.core.businessRules.validation.RuleValidationKey;
import com.ptc.core.businessRules.validation.RuleValidationObject;
import com.ptc.core.businessRules.validation.RuleValidationResult;
import com.ptc.core.businessRules.validation.RuleValidationStatus;

import ext.kb.businessrule.util.KBBusinessRuleUtil;
import ext.kb.businessrule.validation.helper.KBBOMReleaseValidationHelper;
import ext.kb.change2.helper.ChangeNoticeUtils;
import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.DBUtils;
import ext.kb.util.KBUtils;
import ext.kb.util.ObjectRevisionHelper;
import ext.kb.workflow.ChangeTaskUtils;
import wt.change2.ChangeActivity2;
import wt.change2.ChangeRecord2;
import wt.enterprise.RevisionControlled;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.collections.WTHashSet;
import wt.lifecycle.State;
import wt.log4j.LogR;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.part.WTPartSubstituteLink;
import wt.part.WTPartUsageLink;
import wt.util.WTException;
import wt.util.WTMessage;

public class KBBOMComponentStateValidator extends BOMReleaseRuleValidator {

	protected static final Logger LOG = LogR.getLogger(KBBOMComponentStateValidator.class.getName());

	@Override
	@SuppressWarnings("unchecked")
	public RuleValidationResult performValidation(RuleValidationKey paramRuleValidationKey,
			RuleValidationObject paramRuleValidationObject, RuleValidationCriteria paramRuleValidationCriteria)
			throws WTException {

		KBBOMReleaseValidationHelper validationHelper = new KBBOMReleaseValidationHelper();
		LOG.debug("paramRuleValidationObject:" + validationHelper.constructDisplayIdentity(
				(RevisionControlled) paramRuleValidationObject.getTargetObject().getObject()));

		RuleValidationResult result = new RuleValidationResult(RuleValidationStatus.SUCCESS);

		Set<State> validStates = (Set<State>) paramRuleValidationKey.getProcessingMapValue("validDependentState");
		LOG.debug("validStates: "+validStates);
		Set<State> invalidStates = (Set<State>) paramRuleValidationKey.getProcessingMapValue("invalidDependentState");
		LOG.debug("invalidStates: "+invalidStates);
		Persistable targetBOM = paramRuleValidationObject.getTargetObject().getObject();
		ChangeRecord2 currentChangeRecord = ((ChangeRecord2) paramRuleValidationObject.getTargetObjectLink().getObject());
		
		ChangeActivity2 ectOfTargetBOM = currentChangeRecord.getChangeActivity2();

		QueryResult context = KBBusinessRuleUtil.getChangeContext(ectOfTargetBOM);
		WTHashSet resultingObjectsInContext = ChangeTaskUtils.getResultingObjects(context);
		LOG.debug("resultingObjectsInContext : "+resultingObjectsInContext);
	    List<WTPartUsageLink> usageLinks = DBUtils.retrieveLinks(WTPartUsageLink.class, targetBOM,
				WTPartUsageLink.ROLE_BOBJECT_ROLE);
		
		for (WTPartUsageLink link : usageLinks) {
			RuleFeedbackMessage error = validate(validStates, invalidStates, resultingObjectsInContext, link);
			if (error != null) {
				result.setStatus(RuleValidationStatus.FAILURE);
				result.setTargetObject(paramRuleValidationObject.getTargetObject());
				result.setValidationKey(paramRuleValidationKey);
				result.addFeedbackMessage(error);
			}
			
			WTPartMaster childMaster = link.getUses();
			QueryResult allLinks = PersistenceHelper.manager.navigate(link,
					WTPartSubstituteLink.SUBSTITUTES_ROLE, WTPartSubstituteLink.class, true);
			LOG.debug("allLinks size : "+allLinks.size());
			
			while (allLinks.hasMoreElements()) {
				error = null;
				WTPartMaster obj = (WTPartMaster) allLinks.nextElement();
				WTPart subPart =(WTPart) KBUtils.getLatestIteration(obj);
				String objectnumber = subPart.getNumber();
				ChangeRecord2 cr = ChangeNoticeUtils.getChangeRecord(subPart);
				LOG.debug("CR : "+cr+" subPart : "+subPart+" number: "+subPart.getNumber());
				if (cr != null && resultingObjectsInContext.contains(subPart)) {
					error = KBBOMReleaseValidationHelper.validateChangeContextForSubstitute(validStates, invalidStates, cr, error, objectnumber, childMaster);
				} else {
					error = KBBOMReleaseValidationHelper.validateOutsideChangeContextForSubstitute(validStates, invalidStates, subPart, error, objectnumber,childMaster);
				}
				if (error != null) {
					result.setStatus(RuleValidationStatus.FAILURE);
					result.setTargetObject(paramRuleValidationObject.getTargetObject());
					result.setValidationKey(paramRuleValidationKey);
					result.addFeedbackMessage(error);
				}
			}
			
			
			
		}
		return result;
	}

	private RuleFeedbackMessage validate(Set<State> validStates, Set<State> invalidStates,
			WTHashSet resultingObjectsInContext, WTPartUsageLink link) throws WTException {
		
		RuleFeedbackMessage error = null;
		WTPartMaster componentMaster = link.getUses();
		
		WTPart componentLatestIteration = (WTPart) KBUtils.getLatestIteration(componentMaster);
		if(componentLatestIteration == null) {
			error = new RuleFeedbackMessage(new WTMessage(BusinessRuleRB.class.getName(),
			BusinessRuleRB.KB_CHILD_ONLY_MANUFACTURING_VERSION, 
			new Object[] {componentMaster.getNumber()}), 
			RuleFeedbackType.ERROR);
			return error;
		}
		ChangeRecord2 cr = ChangeNoticeUtils.getChangeRecord(componentLatestIteration);

		String objectnumber = componentLatestIteration.getNumber();
		LOG.debug("componentMaster : "+objectnumber);
		
		if (cr != null && resultingObjectsInContext.contains(componentLatestIteration)) {
			error = KBBOMReleaseValidationHelper.validateChangeContext(validStates, invalidStates, cr, error, objectnumber);
		} else {
			error = KBBOMReleaseValidationHelper.validateOutsideChangeContext(validStates, invalidStates, componentLatestIteration, error, objectnumber);
		}
		
		
		return error;
	}

}
