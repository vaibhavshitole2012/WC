package ext.kb.businessrule.validation;

import com.ptc.core.businessRules.feedback.RuleFeedbackType;

import ext.kb.businessrule.util.InfoEngineBusinessRuleDao;

public class KBMaterialWarningValidation extends KBMaterialValidation {

    private static KBMaterialWarningValidation INSTANCE = new KBMaterialWarningValidation();

    private KBMaterialWarningValidation() {
        super(new InfoEngineBusinessRuleDao());
        setFeedbackType(RuleFeedbackType.WARNING);
    }

    public static KBMaterialWarningValidation getInstance() {
        return INSTANCE;
    }

}
