package ext.kb.businessrule.validation;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.core.businessRules.feedback.RuleFeedbackType;
import com.ptc.core.businessRules.validation.RuleValidationCriteria;
import com.ptc.core.businessRules.validation.RuleValidationKey;
import com.ptc.generic.iba.AttributeService;

import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.KBConstants;
import ext.kb.util.KBType;
import ext.kb.util.KBUtils;
import ext.kb.workflow.ChangeTaskUtils;
import ext.kb.workflow.EPMChangeUtils;
import wt.change2.ChangeHelper2;
import wt.change2.ChangeRecord2;
import wt.change2.Changeable2;
import wt.change2.WTChangeActivity2;
import wt.doc.WTDocument;
import wt.enterprise.RevisionControlled;
import wt.epm.EPMDocument;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.fc.collections.WTCollection;
import wt.fc.collections.WTHashSet;
import wt.fc.collections.WTSet;
import wt.identity.IdentityFactory;
import wt.lifecycle.Transition;
import wt.part.PartDocHelper;
import wt.part.WTPart;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.vc.VersionControlHelper;
import wt.vc.Versioned;

public class KBWTPartDocPreReleaseValidator extends KBValidation {

	private static final String DOC_TYPE_664 = "664";
	protected static final String FEEDBACKMESSAGES = "FEEDBACKMESSAGES";
	protected static final String DOCSINSAMEECN = "DOCSINSAMEECN";
	
	@Override
	public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList, RuleValidationKey validationKey) throws WTException {
		
		logger.debug("Inside KBWTPartDocPreReleaseValidator");
		if (logger.isDebugEnabled()) {
			logger.debug(
					"entering isRulesValid(Persistable,Map<String,Set<AttributeRuleSet>>,List<RuleFeedbackMessage>)");
			logger.debug("paramPersistable: " + paramPersistable);
			logger.debug("paramMap: " + paramMap);
			logger.debug("paramList: " + paramList);
		}
		ArrayList<RuleFeedbackMessage> ruleFeedbackMessages = (ArrayList<RuleFeedbackMessage>) validationKey.getProcessingMapValue(FEEDBACKMESSAGES);
		boolean result = true;

		if (paramPersistable instanceof WTPart) {

			WTPart part = (WTPart) paramPersistable;
			boolean isEbom = KBUtils.isEbomPart(part);
			if(!isEbom) {
				logger.debug("MBOM Part found, will not validate.");
				return result;
			}
			String partTargetState = "";
		
			WTChangeActivity2 partECT = (WTChangeActivity2) validationKey.getProcessingMapValue(ECT);
			
			ChangeRecord2 changeRecord = ChangeTaskUtils.getChangeRecord(part, partECT);
			Transition targetTransition = changeRecord.getTargetTransition();
			partTargetState = targetTransition != null ? KBUtils.getKBTargetStateNumericValueString(targetTransition): "";

			if (logger.isDebugEnabled()) {
				logger.debug("Resulting part: " + part.getIdentity() + " has target state: " + partTargetState);
			}

			boolean validateDocumentState = isDocumentValidationNeeded(partTargetState);

			if (!validateDocumentState) {
				return result;
			}
			List<Persistable> associatedDocs = getRelatedDocuments(part);

			WTHashSet changeables = new WTHashSet(associatedDocs);

			List<Persistable> docsInSameECN = getDocsInSameECN(partECT, changeables);
			validationKey.addToProcessingMap(DOCSINSAMEECN, docsInSameECN);
			associatedDocs.removeAll(docsInSameECN);
			
			validetaDocsInSameECN(docsInSameECN, partECT, ruleFeedbackMessages);				
			if (ruleFeedbackMessages.isEmpty()) {
				validateOtherDocs(associatedDocs, ruleFeedbackMessages,validationKey.getRuleKey());
			}
		}
		if (!ruleFeedbackMessages.isEmpty()) {
			for (RuleFeedbackMessage message : ruleFeedbackMessages) {
				paramList.add(message);
			}
			ruleFeedbackMessages.clear();
			result = false;
		}
		return result;
	}


	private List<Persistable> getDocsInSameECN(WTChangeActivity2 partECT, WTHashSet changeables)
			throws WTException {
		List<Persistable> localDocsInSameECN = new ArrayList<>();
		QueryResult activities = ChangeTaskUtils.getActivitiesFromChangeContext(partECT);	
		WTHashSet resultingObjects = ChangeTaskUtils.getResultingObjects(activities);
		
		for (Object object : resultingObjects) {
			if (changeables.contains(object)) {
				localDocsInSameECN.add((Persistable) ((ObjectReference) object).getObject());
			}
		}
		return localDocsInSameECN;
	}

	private boolean isDocumentValidationNeeded(String partTargetState) {
		try {
			int intTargetState = Integer.parseInt(partTargetState);
			if (intTargetState > 1030 && intTargetState < 1075) {
				return true;
			}
		} catch (NumberFormatException ext) {
			logger.error(ext.getLocalizedMessage());
		}
		return false;
	}

	private void validetaDocsInSameECN(List<Persistable> docsInSameECN, WTChangeActivity2 partECT, ArrayList<RuleFeedbackMessage> ruleFeedbackMessages) throws WTException {
		QueryResult activitiesFromChangeContext = ChangeTaskUtils.getActivitiesFromChangeContext(partECT);
		WTSet ects = new WTHashSet(activitiesFromChangeContext);
		
		for (Persistable doc : docsInSameECN) {
			if (!isDocumentValidForCheck(doc)) {
				continue;
			}

			QueryResult changingChangeActivities = ChangeHelper2.service.getChangingChangeActivities((Changeable2) doc,
					false);
			while (changingChangeActivities.hasMoreElements()) {
				ChangeRecord2 changeRecord = (ChangeRecord2) changingChangeActivities.nextElement();
				WTChangeActivity2 ect = (WTChangeActivity2) changeRecord.getRoleAObject();
				if (!ects.contains(ect) || KBConstants.STATE_CANCELED.equals(ect.getLifeCycleState())) {
					continue;
				}
				Transition targetTransition = changeRecord.getTargetTransition();
				if (targetTransition == null) {
				
					ruleFeedbackMessages.add(getErrorFeedbackMessage(doc, BusinessRuleRB.KB_WTPART_DOC_ERROR_MSG_TARGET_STATE));
				} else {
					String stateNumeric = KBUtils.getKBTargetStateNumericValueString(targetTransition);
					if (!"1050".equals(stateNumeric)) {
						ruleFeedbackMessages.add(getErrorFeedbackMessage(doc, BusinessRuleRB.KB_WTPART_DOC_ERROR_MSG_TARGET_STATE));
					}
				}
			}
		}
	}

	private void validateOtherDocs(List<Persistable> associatedDocs, ArrayList<RuleFeedbackMessage> ruleFeedbackMessages,String validationkey) throws WTException {
		for (Persistable doc : associatedDocs) {
			if (!isDocumentValidForCheck(doc)) {
				continue;
			}
			String docNumericState = KBUtils.getKBStateNumericValueString((RevisionControlled) doc);
			
			
			if("1080".equals(docNumericState) || "1020".equals(docNumericState) || "1050".equals(docNumericState)){
			if("1080".equals(docNumericState)){
				QueryResult successorQr=VersionControlHelper.service.allVersionsOf((Versioned)doc);
				logger.debug("SuccessorQr size ::>>"+successorQr.size());
				boolean issuccessorreleased=false;
				
				while(successorQr.hasMoreElements()){
					Object obj=successorQr.nextElement();
					if(obj instanceof WTDocument){
					WTDocument wtdoc=(WTDocument) obj;
				
					logger.debug("Docuemnt version :: "+wtdoc.getVersionIdentifier().getValue()+"."+wtdoc.getIterationIdentifier().getValue());
					
					if((((Versioned)doc).getVersionIdentifier().getValue()+"."+((Versioned)doc).getIterationIdentifier().getValue()).equals(wtdoc.getVersionIdentifier().getValue()+"."+wtdoc.getIterationIdentifier().getValue())){
						
						break;
						
					}
					else if(wtdoc.getLifeCycleState().toString().equals("1050")){
						issuccessorreleased=true;
						break;
					}
					
					}
					else if(obj instanceof EPMDocument){
						EPMDocument epmdoc=(EPMDocument) obj;
						if((((Versioned)doc).getVersionIdentifier().getValue()+"."+((Versioned)doc).getIterationIdentifier().getValue()).equals(epmdoc.getVersionIdentifier().getValue()+"."+epmdoc.getIterationIdentifier().getValue())){
							
							break;
						}
						else if(epmdoc.getLifeCycleState().toString().equals("1050")){
							issuccessorreleased=true;
							break;
						}
					}
					
				}
				if(!issuccessorreleased){
					ruleFeedbackMessages.add(getErrorFeedbackMessage(doc, BusinessRuleRB.KB_WTPART_DOC_ERROR_MSG));
				}
			}
			if("1020".equals(docNumericState) && validationkey.equals("WTPART_DOC_RULE_RELEASE")){
				logger.debug("Validation Key ::>>"+validationkey);
				ruleFeedbackMessages.add(getErrorFeedbackMessage(doc, BusinessRuleRB.KB_WTPART_DOC_ERROR_MSG));
				
				
			}
			}
			else{
				
				QueryResult predecessorQr=VersionControlHelper.service.allVersionsOf((Versioned)doc);
				logger.debug("SuccessorQr size ::>>"+predecessorQr.size());
				logger.debug("attached doc version :: "+((Versioned)doc).getVersionIdentifier().getValue()+"."+((Versioned)doc).getIterationIdentifier().getValue());
				boolean ispredecessorreleased=false;
				boolean hasreleasedpredessor=false;
				while(predecessorQr.hasMoreElements()){
					Object obj=predecessorQr.nextElement();
					if(obj instanceof WTDocument){
					WTDocument wtdoc=(WTDocument) obj;
				
					logger.debug("Docuemnt version :: "+wtdoc.getVersionIdentifier().getValue()+"."+wtdoc.getIterationIdentifier().getValue());
					
					if((((Versioned)doc).getVersionIdentifier().getValue()+"."+((Versioned)doc).getIterationIdentifier().getValue()).equals(wtdoc.getVersionIdentifier().getValue()+"."+wtdoc.getIterationIdentifier().getValue())){
						logger.debug("Version matched");
						ispredecessorreleased=true;
						
					}
					logger.debug("wtdoc.getLifeCycleState().toString() :: "+wtdoc.getLifeCycleState().toString());
					
					if(ispredecessorreleased && wtdoc.getLifeCycleState().toString().equals("1050")){
						logger.debug("Inside ispredecessorreleased");
						
						hasreleasedpredessor=true;
					  break;
					}
					}
					else if(obj instanceof EPMDocument){
						EPMDocument epmdoc=(EPMDocument) obj;
						if((((Versioned)doc).getVersionIdentifier().getValue()+"."+((Versioned)doc).getIterationIdentifier().getValue()).equals(epmdoc.getVersionIdentifier().getValue()+"."+epmdoc.getIterationIdentifier().getValue())){
							
							ispredecessorreleased=true;
						}
						if(ispredecessorreleased && epmdoc.getLifeCycleState().toString().equals("1050")){
							hasreleasedpredessor=true;
							  break;
						}
					}
				
			}
			logger.debug("hasreleasedpredessor :: "+hasreleasedpredessor);
			if(hasreleasedpredessor){
				ruleFeedbackMessages.add(getErrorFeedbackMessage(doc,BusinessRuleRB.ASSOCIATE_LATEST_RELEASED_DOC));
			} 
			else{
				logger.debug("KBWTPartDocPreReleaseValidator:: validateOtherDocs :: predecessor == null");
				ruleFeedbackMessages.add(getErrorFeedbackMessage(doc, BusinessRuleRB.KB_WTPART_DOC_ERROR_MSG));
			}
			}
		}
	}

	private List<Persistable> getRelatedDocuments(WTPart part) throws WTException {
		List<Persistable> associatedCADs = new ArrayList<>();

		QueryResult relatedCads = PartDocHelper.service.getAssociatedDocuments(part);
		WTCollection calculatedCads = EPMChangeUtils.getCalculatedDocuments(part);
		
		while (relatedCads.hasMoreElements()) {
			Persistable document = (Persistable) relatedCads.nextElement();
			if (isTechnicalDrawing(document)) {
				associatedCADs.add(document);
			}
		}
		associatedCADs.removeAll(calculatedCads);
		return associatedCADs;
	}

	protected boolean isDocumentValidForCheck(Persistable document) {
		String attribute = AttributeService.getAttribute(document, KBConstants.DOC_CONTENT_TYPE);
		return DOC_TYPE_664.equals(attribute) ? false : true;
	}

	protected RuleFeedbackMessage getErrorFeedbackMessage(Persistable paramPersistable, String ruleFeedback) throws WTException {
		String localizedMessage = IdentityFactory.getDisplayIdentifier(paramPersistable)
				.getLocalizedMessage(SessionHelper.manager.getLocale());
		WTMessage message = new WTMessage(BusinessRuleRB.class.getName(), ruleFeedback,
				new Object[] { localizedMessage });
		return new RuleFeedbackMessage(message, RuleFeedbackType.ERROR);
	}

	private boolean isTechnicalDrawing(Persistable document) {
		boolean result = false;
		if (KBType.isOfType(document, "com.ptc.KBTechnicalDrawing")
				|| KBType.isOfType(document, "com.ptc.DesignCADDrw")) {
			result = true;
		}
		return result;
	}
	
    @Override
    public void prepareForValidation(RuleValidationKey ruleValidationKey, RuleValidationCriteria ruleValidationCriteria) throws WTException {
        if (logger.isDebugEnabled()) {
            logger.debug("entering prepareForValidation(RuleValidationKey,RuleValidationCriteria)");
            logger.debug("ruleValidationKey: " + ruleValidationKey);
            logger.debug("ruleValidationCriteria: " + ruleValidationCriteria);
        }
        ruleValidationKey.addToProcessingMap(ECT, (WTChangeActivity2) ruleValidationCriteria.getPrimaryBusinessObject());
        ruleValidationKey.addToProcessingMap(FEEDBACKMESSAGES, new ArrayList<RuleFeedbackMessage>());
        
        if (logger.isDebugEnabled()) {
            logger.debug("exiting prepareForValidation()");
        }
    }

	@Override
	public boolean isRulesValid(Persistable paramPersistable,
			Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList) throws WTException {
		// TODO Auto-generated method stub
		return false;
	}

}
