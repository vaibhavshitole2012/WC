package ext.kb.businessrule.validation;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;

import com.ptc.core.businessRules.validation.RuleValidationKey;

import wt.fc.BinaryLink;
import wt.fc.ObjectIdentifier;
import wt.fc.PersistInfo;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.log4j.LogR;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.part.WTPartUsageLink;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTAttributeNameIfc;
import wt.util.WTException;
import wt.vc.VersionControlHelper;
import wt.vc.wip.WorkInProgressHelper;
import ext.kb.util.KBUtils;

/**
* This class is responsible for walking through
* the usage links of a BOM.
* The instances of his class are initiated from the
* implementations of PartUsageLinkLogicExecutable interface
*/

public class BasePartUsageLinkProcessor {
	private PartUsageLinkLogicExecutable uLinkExecutable;
	
	protected static final Logger LOG = LogR.getLogger(BasePartUsageLinkProcessor.class.getName());
	public BasePartUsageLinkProcessor(PartUsageLinkLogicExecutable aULinkExecutable){
		this.uLinkExecutable = aULinkExecutable;
	}
	
	/**
	 * This method is the main executable in the class.
	 * Fetches the 1st level usageLinks of the BOM,
	 * might do some extra validations before iterating through
	 * and executing specific logic on all elements
	 * 
	 * @param part The BOM we check the againts the usage links
	 * @throws WTException
	 */
	public void process(final WTPart part, RuleValidationKey paramRuleValidationKey) throws WTException{
		long id = PersistenceHelper.getObjectIdentifier(part).getId();
		
		long[] idsToFetch = new long[]{id};
        List<BinaryLink> links = queryAndFetchUsageLinks(idsToFetch);
       
        uLinkExecutable.executeSpecificPreProcess(links);
        
        if(!CollectionUtils.isEmpty(links)){
	       	for(BinaryLink link : links){
	        	//No need to check with instanceof,
	        	//as this has been already done in 
	        	//KBUtils.fetchUsageLinks
	        	WTPartUsageLink uLink = (WTPartUsageLink)link;
	        	recursiveProcessing(uLink, links, paramRuleValidationKey);
	       	}
        }
    }
	
	private void recursiveProcessing(final WTPartUsageLink usageLink,final List<BinaryLink> linksOnSameLevel, 
			RuleValidationKey paramRuleValidationKey) throws WTException{
		
		uLinkExecutable.executeSpecific(usageLink, linksOnSameLevel, paramRuleValidationKey);
		if(uLinkExecutable.isOnlyToplevel()){
			return;
		}
		WTPartMaster master = usageLink.getUses();
		//Only last version is used
		QueryResult queryRes = VersionControlHelper.service.allIterationsOf(master);
		int nrOfRecs = queryRes == null ? 0: queryRes.size();
		List<BinaryLink> links = null;
		if (nrOfRecs > 0){
			long[] ids = new long[1];
			Object obj = queryRes.nextElement();
			WTPart localPart = null;
			if(obj instanceof WTPart){
	            	localPart = (WTPart)obj;
	            	if (WorkInProgressHelper.isWorkingCopy(localPart)) {
	                    localPart = (WTPart)WorkInProgressHelper.service.originalCopyOf(localPart);
	            	}
	            	PersistInfo persistInfo = localPart.getPersistInfo();
	            	ObjectIdentifier oid = persistInfo.getObjectIdentifier();
	            	ids[0]= oid.getId();
	            	links = queryAndFetchUsageLinks(ids);
	        }
		}
		
        if(!CollectionUtils.isEmpty(links)){
        	for(BinaryLink link : links){
        		WTPartUsageLink localUsageLink = (WTPartUsageLink)link;
        		recursiveProcessing(localUsageLink, links, paramRuleValidationKey);
        	}
        }
    }

	/**
	 * Returns the usage link objects belonging to a WTPart by the id of the part.
	 * @param ids
	 * @return
	 * @throws WTException
	 */
	public List<BinaryLink> queryAndFetchUsageLinks(long[] ids) throws WTException{
		QuerySpec qs = new QuerySpec();
		int usageLinkIndex = qs.addClassList(WTPartUsageLink.class, true);
	    int[] indices = new int[] { usageLinkIndex };
	    qs.appendWhere(new SearchCondition(WTPartUsageLink.class, WTAttributeNameIfc.ROLEA_OBJECT_ID, ids), indices);
	    QueryResult qr = PersistenceServerHelper.manager.query(qs);
	    return KBUtils.fetchUsageLinks(qr);
	}
	
}
