package ext.kb.businessrule.validation;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import wt.change2.ChangeRecord2;
import wt.change2.WTChangeActivity2;
import wt.fc.Persistable;
import wt.util.WTException;
import wt.util.WTMessage;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.core.businessRules.feedback.RuleFeedbackType;
import com.ptc.core.businessRules.validation.RuleValidationCriteria;
import com.ptc.core.businessRules.validation.RuleValidationKey;

import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.KBConstants;
import ext.kb.util.KBTeamUtils;
import ext.kb.workflow.ChangeTaskUtils;
import ext.kb.workflow.EPMChangeUtils;

public class KBRoleMemberValidation extends KBValidation {

	private static final String ROLECHECKMAP = "ROLECHECKMAP";
	private static final String ISREVIEWEREMPTY = "ISREVIEWEREMPTY";
	private static final String ISBONDINGEMPTY = "ISBONDINGEMPTY";
	private static final String ISWELDINGEMPTY = "ISWELDINGEMPTY";
	
	private static final Logger logger = Logger.getLogger(KBRoleMemberValidation.class);
	
	@Override
	public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList, RuleValidationKey validationKey) throws WTException {
		if (logger.isDebugEnabled()) {
			logger.debug("entering  isRulesValid(Persistable, Map<String, Set<AttributeRuleSet>>, List<RuleFeedbackMessage>)");
		}
		boolean isValid = true;
		Boolean isReviewerRoleEmpty = (Boolean) validationKey.getProcessingMapValue(ISREVIEWEREMPTY);
		if (isReviewerRoleEmpty){
			isValid = false;
			paramList.add(new RuleFeedbackMessage(new WTMessage("ext.kb.resources.BusinessRuleRB", BusinessRuleRB.KB_ROLE_IS_EMPTY, new Object[] {KBConstants.REVIEWER_ROLE.getAbbreviatedDisplay()}), RuleFeedbackType.ERROR));
		}
		HashMap<Persistable, String> roleCheckMap = (HashMap<Persistable, String>) validationKey.getProcessingMapValue(ROLECHECKMAP);
		String roleCheck = roleCheckMap.get(paramPersistable);
		if (logger.isDebugEnabled()){
			logger.debug("Role check needed: " + roleCheck);
		}
		Boolean isBondingRoleEmpty = (Boolean) validationKey.getProcessingMapValue(ISBONDINGEMPTY);
		if ((roleCheck.equals(KBConstants.BONDING_REVIEW) || roleCheck.equals(KBConstants.BOTH))
				&& isBondingRoleEmpty){
			isValid = false;
			paramList.add(new RuleFeedbackMessage(new WTMessage("ext.kb.resources.BusinessRuleRB", BusinessRuleRB.KB_ROLE_IS_EMPTY, new Object[] {KBConstants.BONDING_ENGINEER_ROLE.getAbbreviatedDisplay()}), RuleFeedbackType.ERROR));
		}
		Boolean isWeldingRoleEmpty = (Boolean) validationKey.getProcessingMapValue(ISWELDINGEMPTY);
		if ((roleCheck.equals(KBConstants.WELDING_REVIEW) || roleCheck.equals(KBConstants.BOTH))
				&& isWeldingRoleEmpty){
			isValid = false;
			paramList.add(new RuleFeedbackMessage(new WTMessage("ext.kb.resources.BusinessRuleRB", BusinessRuleRB.KB_ROLE_IS_EMPTY, new Object[] {KBConstants.WELDING_ENGINEER_ROLE.getAbbreviatedDisplay()}), RuleFeedbackType.ERROR));
		}
		if (logger.isDebugEnabled()) {
			logger.debug("exiting isRulesValid(Persistable, Map<String, Set<AttributeRuleSet>>, List<RuleFeedbackMessage>)");
		}
		return isValid;
	}
	
	@Override
	public void prepareForValidation(RuleValidationKey paramRuleValidationKey, RuleValidationCriteria paramRuleValidationCriteria) throws WTException {
		if (logger.isDebugEnabled()){
			logger.debug("prepareForValidation starts");
		}
		super.prepareForValidation(paramRuleValidationKey, paramRuleValidationCriteria);
		WTChangeActivity2 ect = (WTChangeActivity2) paramRuleValidationCriteria.getPrimaryBusinessObject();
		paramRuleValidationKey.addToProcessingMap(ISREVIEWEREMPTY, KBTeamUtils.getRoleMembers(KBConstants.REVIEWER_ROLE.toString(), ect).isEmpty());
		paramRuleValidationKey.addToProcessingMap(ISBONDINGEMPTY, KBTeamUtils.getRoleMembers(KBConstants.BONDING_ENGINEER_ROLE.toString(), ect).isEmpty());
		paramRuleValidationKey.addToProcessingMap(ISWELDINGEMPTY, KBTeamUtils.getRoleMembers(KBConstants.WELDING_ENGINEER_ROLE.toString(), ect).isEmpty());
		HashMap<Persistable, String> roleCheckMap = new HashMap<Persistable, String>();
		
		for (Object resObject : ChangeTaskUtils.getResultingObjects(ect, false)) {
			ChangeRecord2 changeRecord = (ChangeRecord2) resObject;
			boolean bondingFlag = EPMChangeUtils.getBondingFlag(changeRecord);
			boolean weldingFlag = EPMChangeUtils.getWeldingFlag(changeRecord);
			String result = EPMChangeUtils.evaluateBondingWeldingFlags(bondingFlag, weldingFlag);
			roleCheckMap.put(changeRecord.getChangeable2(), result); 
		}
		paramRuleValidationKey.addToProcessingMap(ROLECHECKMAP, roleCheckMap);
		
		if (logger.isDebugEnabled()){
			logger.debug("prepareForValidation ends");
		}
	}

	@Override
	public boolean isRulesValid(Persistable paramPersistable,
			Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList) throws WTException {
		// TODO Auto-generated method stub
		return false;
	}

}
