package ext.kb.businessrule.validation;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.core.businessRules.feedback.RuleFeedbackType;

import ext.kb.businessrule.validation.KBValidation;
import ext.kb.change2.helper.ChangeNoticeUtils;
import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.KBUtils;
import ext.kb.util.ObjectRevisionHelper;
import wt.change2.ChangeRecord2;
import wt.fc.Persistable;
import wt.identity.IdentityFactory;
import wt.lifecycle.Transition;
import wt.part.WTPart;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.util.WTMessage;

public class KBSalesOrderBlockRuleValidator extends KBValidation {

	/**
	 * Validates if predecessor of Part which will be released to 1050 state was in state 1058 or 1070
	 */
	@Override
	public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList) throws WTException {
		if (logger.isDebugEnabled()) {
			logger.debug(
					"entering isRulesValid(Persistable,Map<String,Set<AttributeRuleSet>>,List<RuleFeedbackMessage>)");
			logger.debug("paramPersistable: " + paramPersistable);
			logger.debug("paramMap: " + paramMap);
			logger.debug("paramList: " + paramList);
		}

		boolean result = true;

		if (paramPersistable instanceof WTPart) {
			WTPart part = (WTPart) paramPersistable;
			String partTargetState = "";

			ChangeRecord2 changeRecord = ChangeNoticeUtils.getChangeRecord(part);
			Transition targetTransition = changeRecord.getTargetTransition();
			partTargetState = targetTransition != null ? KBUtils.getKBTargetStateNumericValueString(targetTransition)
					: "";

			boolean validateSalesOrderBlock = isSalesOrderBlockValidationNeeded(partTargetState);

			if (!validateSalesOrderBlock) {
				return result;
			}

			WTPart predecessor = (WTPart) ObjectRevisionHelper.getPreviousVersionLatestIteration(part);

			result = validateSalesOrderBlock(predecessor);
		}

		if (!result) {
			RuleFeedbackMessage localRuleFeedbackMessage = getWarningFeedbackMessage(paramPersistable);
			paramList.add(localRuleFeedbackMessage);
		}

		return result;
	}

	private boolean validateSalesOrderBlock(WTPart predecessor) {
		if(predecessor == null){
			return true;
		}
		String stateStr = KBUtils.getKBStateNumericValueString(predecessor);
		return !("1058".equals(stateStr) || "1070".equals(stateStr));
	}

	private boolean isSalesOrderBlockValidationNeeded(String partTargetState) {
		return "1050".equals(partTargetState);
	}

	private RuleFeedbackMessage getWarningFeedbackMessage(Persistable paramPersistable) throws WTException {
		String localizedMessage = IdentityFactory.getDisplayIdentifier(paramPersistable)
				.getLocalizedMessage(SessionHelper.manager.getLocale());
		WTMessage message = new WTMessage(BusinessRuleRB.class.getName(),
				BusinessRuleRB.KB_SALES_ORDER_BLOCK_WARNING_MSG, new Object[] { localizedMessage });
		RuleFeedbackMessage localRuleFeedbackMessage = new RuleFeedbackMessage(message, RuleFeedbackType.WARNING);
		return localRuleFeedbackMessage;
	}

}
