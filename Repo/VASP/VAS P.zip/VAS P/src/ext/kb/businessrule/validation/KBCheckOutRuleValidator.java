package ext.kb.businessrule.validation;

import org.apache.log4j.Logger;

import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.core.businessRules.feedback.RuleFeedbackType;
import com.ptc.core.businessRules.validation.CheckoutRuleValidator;
import com.ptc.core.businessRules.validation.RuleValidationCriteria;
import com.ptc.core.businessRules.validation.RuleValidationKey;
import com.ptc.core.businessRules.validation.RuleValidationObject;
import com.ptc.core.businessRules.validation.RuleValidationResult;
import com.ptc.core.businessRules.validation.RuleValidationStatus;

import ext.kb.resources.BusinessRuleRB;
import wt.doc.WTDocument;
import wt.epm.EPMDocument;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.part.WTPart;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.vc.VersionControlHelper;
import wt.vc.wip.WorkInProgressHelper;

public class KBCheckOutRuleValidator extends CheckoutRuleValidator {
	private static final Logger LOG = Logger.getLogger(KBCheckOutRuleValidator.class);
	protected static final String RESOURCE = "ext.kb.resources.BusinessRuleRB";
	
	@Override
	 public RuleValidationResult performValidation(RuleValidationKey rulevalidationkey, RuleValidationObject rulevalidationobject, RuleValidationCriteria rulevalidationcriteria) throws WTException {
		RuleValidationResult validationResult = super.performValidation(rulevalidationkey,rulevalidationobject, rulevalidationcriteria);
		
		LOG.debug("Inside KBCheckOutRuleValidator ");
		LOG.debug("rulevalidationobject :: "+rulevalidationobject);
		LOG.debug("RuleValidationResult :: "+validationResult);
		Persistable persistable = rulevalidationobject.getTargetObject().getObject();

			if(persistable instanceof WTDocument) {
				WTDocument doc=(WTDocument) persistable;
				LOG.debug("doc.getState().toString()comparison ::"+doc.getState().toString().compareTo("1020"));
				if(doc.getState().toString().compareTo("1020") >= 0) {
				QueryResult allversion=VersionControlHelper.service.allVersionsFrom(doc);
				while(allversion.hasMoreElements()) {
					WTDocument prevversion=(WTDocument) allversion.nextElement();
					LOG.debug("Previous version :: "+prevversion.getNumber()+"\n Version :: "+prevversion.getVersionIdentifier().getValue()+"."+prevversion.getIterationIdentifier().getValue());
					if(WorkInProgressHelper.isCheckedOut(prevversion)) {
						LOG.debug("Object is checkedout :: "+prevversion.getNumber()+"\n Version :: "+prevversion.getVersionIdentifier().getValue()+"."+prevversion.getIterationIdentifier().getValue());
						validationResult=formValidationResult(rulevalidationkey,validationResult,prevversion.getNumber(),persistable);
					}
				}
				}
				
			}
			if(persistable instanceof WTPart) {
				WTPart part=(WTPart) persistable;
				LOG.debug("part.getState().toString()comparison ::"+part.getState().toString().compareTo("1020"));
				if(part.getState().toString().compareTo("1020")>= 0) {
				QueryResult allversion=VersionControlHelper.service.allVersionsFrom(part);
				while(allversion.hasMoreElements()) {
					WTPart prevversion=(WTPart) allversion.nextElement();
					LOG.debug("Previous version :: "+prevversion.getNumber()+"\n Version :: "+prevversion.getVersionIdentifier().getValue()+"."+prevversion.getIterationIdentifier().getValue());
					if(WorkInProgressHelper.isCheckedOut(prevversion)) {
						LOG.debug("Object is checkedout :: "+prevversion.getNumber()+"\n Version :: "+prevversion.getVersionIdentifier().getValue()+"."+prevversion.getIterationIdentifier().getValue());
						validationResult=formValidationResult(rulevalidationkey,validationResult,prevversion.getNumber(),persistable);
					}
				}
				}
				
			}
			if(persistable instanceof EPMDocument) {
				EPMDocument doc=(EPMDocument) persistable;
				LOG.debug("doc.getState().toString()comparison ::"+doc.getState().toString().compareTo("1020"));
				if(doc.getState().toString().compareTo("1020") >= 0) {
				QueryResult allversion=VersionControlHelper.service.allVersionsFrom(doc);
				while(allversion.hasMoreElements()) {
					EPMDocument prevversion=(EPMDocument) allversion.nextElement();
					LOG.debug("Previous version :: "+prevversion.getNumber()+"\n Version :: "+prevversion.getVersionIdentifier().getValue()+"."+prevversion.getIterationIdentifier().getValue());
					if(WorkInProgressHelper.isCheckedOut(prevversion)) {
						LOG.debug("Object is checkedout :: "+prevversion.getNumber()+"\n Version :: "+prevversion.getVersionIdentifier().getValue()+"."+prevversion.getIterationIdentifier().getValue());
						validationResult=formValidationResult(rulevalidationkey,validationResult,prevversion.getNumber(),persistable);
					}
				}
				}
				
			}
	
		return validationResult;
		
	}
	@Override
	 public void prepareForValidation(RuleValidationKey rulevalidationkey, RuleValidationCriteria rulevalidationcriteria) throws WTException{
		 super.prepareForValidation(rulevalidationkey, rulevalidationcriteria);
	 }
	
	private static RuleValidationResult formValidationResult(RuleValidationKey paramRuleValidationKey,RuleValidationResult validationResult,String objnumber,Persistable rulevalidationobject){
		validationResult.setStatus(RuleValidationStatus.FAILURE);
		validationResult.setValidationKey(paramRuleValidationKey);
		 RuleFeedbackMessage error = new RuleFeedbackMessage(
				new WTMessage(BusinessRuleRB.class.getName(), BusinessRuleRB.CHECKIN_PREDECESSOR,
						new Object[] { objnumber}),
				RuleFeedbackType.ERROR);
		 validationResult.addFeedbackMessage(error);
			return validationResult;

	}
	
	

}
