package ext.kb.businessrule.validation;

import java.util.List;
import java.util.Map;
import java.util.Set;

import wt.doc.WTDocument;
import wt.fc.Persistable;
import wt.util.WTException;
import wt.util.WTMessage;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.core.businessRules.feedback.RuleFeedbackType;
import com.ptc.core.businessRules.validation.BOMReleaseRuleValidator;
import com.ptc.core.businessRules.validation.RuleValidationCriteria;
import com.ptc.core.businessRules.validation.RuleValidationKey;

import ext.kb.businessrule.validation.helper.KBBOMReleaseValidationHelper;
import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.KBDocumentUtils;

import org.apache.log4j.Logger;

public class KBGeneratedTechDrawingValidator extends KBValidation {

	private static final Logger logger = Logger.getLogger(KBGeneratedTechDrawingValidator.class);
	private static final String VALIDATION_HELPER_KEY = "VALIDATIONHELPER";

	@Override
	public boolean isRulesValid(Persistable resultingObject, Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList, RuleValidationKey paramRuleValidationKey) {
		if (logger.isDebugEnabled()) {
			logger.debug(
					"entering isRulesValid(Persistable,Map<String,Set<AttributeRuleSet>>,List<RuleFeedbackMessage>)");
			logger.debug("resultingObject: " + resultingObject);
			logger.debug("paramMap: " + paramMap);
			logger.debug("paramList: " + paramList);
		}
		boolean isValidResultingObject = true;
		KBBOMReleaseValidationHelper helper = (KBBOMReleaseValidationHelper) paramRuleValidationKey.getProcessingMapValue(VALIDATION_HELPER_KEY);
		if (KBDocumentUtils.isTechDrawing(resultingObject)) {
			WTDocument techDrawing = (WTDocument) resultingObject;
			isValidResultingObject = validateTechDrawing(techDrawing, helper);
			if (!isValidResultingObject) {
				RuleFeedbackMessage errorMessage = constructErrorMessage(techDrawing, helper);
				paramList.add(errorMessage);
			}
		}
		if (logger.isDebugEnabled()) {
			logger.debug("exiting isRulesValid()");
			logger.debug("returning: " + isValidResultingObject);
		}
		return isValidResultingObject;
	}

	private boolean validateTechDrawing(WTDocument techDrawing, KBBOMReleaseValidationHelper helper) {
		if (logger.isDebugEnabled()) {
			logger.debug("entering validateTechDrawing(WTDocument)");
			logger.debug("techDrawing: " + techDrawing);
		}
		boolean cadDocWithSameNumberExists = helper.cadDocWithSameNumberExists(techDrawing);
		boolean isValid = !cadDocWithSameNumberExists;
		if (logger.isDebugEnabled()) {
			logger.debug("exiting validateTechDrawing()");
			logger.debug("returning: " + isValid);
		}
		return isValid;
	}

	private RuleFeedbackMessage constructErrorMessage(WTDocument techDrawing, KBBOMReleaseValidationHelper helper) {
		if (logger.isDebugEnabled()) {
			logger.debug("entering constructErrorMessage(WTDocument)");
			logger.debug("techDrawing: " + techDrawing);
		}
		String diplayIdentity = helper.constructDisplayIdentity(techDrawing);
		RuleFeedbackMessage message = new RuleFeedbackMessage(new WTMessage(RESOURCE,
				BusinessRuleRB.KB_GENERATED_TECH_DRAWING_ERROR_MSG, new Object[] { diplayIdentity }),
				RuleFeedbackType.ERROR);
		if (logger.isDebugEnabled()) {
			logger.debug("exiting constructErrorMessage()");
			logger.debug("returning: " + message);
		}
		return message;
	}

	@Override
	public void prepareForValidation(RuleValidationKey ruleValidationKey, RuleValidationCriteria validationCriteria)
			throws WTException {
		if (logger.isDebugEnabled()) {
			logger.debug("entering prepareForValidation(RuleValidationKey,RuleValidationCriteria)");
			logger.debug("ruleValidationKey: " + ruleValidationKey);
			logger.debug("validationCriteria: " + validationCriteria);
		}
		super.prepareForValidation(ruleValidationKey, validationCriteria);
		BOMReleaseRuleValidator bomReleaseRuleValidator = new BOMReleaseRuleValidator();
		bomReleaseRuleValidator.prepareForValidation(ruleValidationKey, validationCriteria);
		KBBOMReleaseValidationHelper validationHelper = new KBBOMReleaseValidationHelper();
		validationHelper.prepareForValidation(ruleValidationKey);
		ruleValidationKey.addToProcessingMap(VALIDATION_HELPER_KEY, validationHelper);
		if (logger.isDebugEnabled()) {
			logger.debug("exiting prepareForValidation()");
		}
	}


	@Override
	public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList) throws WTException {
		return false;
	}

}
