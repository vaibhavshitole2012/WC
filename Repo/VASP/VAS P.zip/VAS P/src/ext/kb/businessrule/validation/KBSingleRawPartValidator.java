package ext.kb.businessrule.validation;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import ext.kb.util.KBConstants;
import ext.kb.util.KBTypeIdProvider;
import wt.change2.ChangeHelper2;
import wt.change2.ChangeRecord2;
import wt.change2.WTChangeActivity2;
import wt.doc.WTDocument;
import wt.enterprise.RevisionControlled;
import wt.epm.EPMDocument;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.fc.collections.WTArrayList;
import wt.fc.collections.WTCollection;
import wt.fc.collections.WTHashSet;
import wt.lifecycle.Transition;
import wt.part.PartDocHelper;
import wt.part.WTPart;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.vc.VersionControlHelper;
import wt.vc.VersionIdentifier;
import wt.vc.Versioned;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.core.businessRules.feedback.RuleFeedbackType;
import com.ptc.core.businessRules.validation.RuleValidationCriteria;
import com.ptc.core.businessRules.validation.RuleValidationKey;
import com.ptc.core.foundation.doc.server.LatestReleasedConfigSpec;
import com.ptc.generic.iba.AttributeService;
import com.ptc.windchill.cadx.common.util.ObjectDependencyUtility;

import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.KBType;
import ext.kb.util.KBUtils;
import ext.kb.util.ObjectRevisionHelper;
import ext.kb.workflow.ChangeTaskUtils;
import ext.kb.workflow.EPMChangeUtils;

public class KBSingleRawPartValidator  extends KBValidation{
	
	private static final String[] VALID_TYPES;
	private static final String WINDCHILL_MASTER_SYSTEM = "WCT";
	private static final List<String> INVALID_DOC_CONTENTS;
	private static final Map<String, List<String>> INVALID_TARGET_STATES;
	private static final List<String> INVALID_CATEGORIES = Arrays.asList("3","5");
	private static final String STATE_1030 = "1030"; 
	private static final String STATE_1035 = "1030"; 
	private static final String STATE_1045 = "1045"; 
	private static final String STATE_1050 = "1050";
	private static final String STATE_1058 = "1058";
	private static final String STATE_1060 = "1060";
	private static final String STATE_1070 = "1070";
	private static final String STATE_1075 = "1075";
	private static final String STATE_1080 = "1080";
	
	static{
		INVALID_TARGET_STATES = new HashMap<>();
		INVALID_TARGET_STATES.put(STATE_1050, Arrays.asList(STATE_1030,STATE_1035,STATE_1045, STATE_1050, STATE_1058,STATE_1060, STATE_1070));
		INVALID_TARGET_STATES.put(STATE_1080, Arrays.asList(STATE_1075, STATE_1080));
		VALID_TYPES = new String[] {"com.ptc.DesignCADDrw","com.ptc.KBTechnicalDrawing"};
		INVALID_DOC_CONTENTS = Arrays.asList("3","5","220", "003", "005");	
	}

	@Override
	public boolean isRulesValid(Persistable persistable, Map<String, Set<AttributeRuleSet>> paramMap,List<RuleFeedbackMessage> paramList, RuleValidationKey validationKey) throws WTException {
		logger.debug("Starting validation of KBSingleRawPartValidator");
		boolean isRuleValid = true;
		WTChangeActivity2 currentECT = (WTChangeActivity2) validationKey.getProcessingMapValue(ECT);
		ChangeRecord2 changeRecord = ChangeTaskUtils.getChangeRecord(persistable,  currentECT);
		Transition targetTransition = changeRecord.getTargetTransition();
		String drawingTargetState = null;
		boolean hasInvalidtargetState =false;
		if(targetTransition != null){
			 drawingTargetState = targetTransition.toString();
			 hasInvalidtargetState = INVALID_TARGET_STATES.keySet().contains(drawingTargetState);	
			 logger.debug("Object target state:" + drawingTargetState +"has Invalid targetState:" +hasInvalidtargetState);
		}		
		WTPart relatedArticle = getRelatedArticle(persistable);
		boolean isMbom = relatedArticle != null && !KBUtils.isEbomPart(relatedArticle);
		if(isMbom) {
			logger.debug("MBOM Part found, will not validate.");
			return isRuleValid;
		}
		Object contentType = AttributeService.getAttribute(persistable, "KB_DOC_CONTENT_TYPE");		
		boolean isTechnicalOrCadDrawing = KBType.isOneOfTypes(persistable, VALID_TYPES);
		 
		if(isTechnicalOrCadDrawing && INVALID_DOC_CONTENTS.contains(contentType) && relatedArticle != null && hasInvalidtargetState){
			if(KBType.isOfType(persistable, "com.ptc.DesignCADDrw")){
				Object isPhantom = AttributeService.getAttribute(persistable, "KB_PHANTOM");
				if(!Boolean.TRUE.equals(isPhantom)){					
					isRuleValid = validateRelatedPart(relatedArticle, persistable, paramList, currentECT);
					logger.debug("Validation of CAD drawing finished:  " + isRuleValid);
				}
			}else{
				isRuleValid = validateRelatedPart(relatedArticle, persistable, paramList, currentECT);
				logger.debug("Validation of Technical drawing finished:  " + isRuleValid);
			}
		}
		
		else if (KBType.isDescendedFrom(persistable, "com.ptc.KBArticle")){
			String partCategoryAttribute = AttributeService.getAttribute(persistable, "KB_PART_CATEGORY");
			logger.debug("Part Category of article: " + partCategoryAttribute);
			if(INVALID_CATEGORIES.contains(partCategoryAttribute)){ 
				Set<Persistable> relatedDrawings = getRelatedDrawings(persistable);
				isRuleValid = validateDrawings(persistable, relatedDrawings, paramList, currentECT);
				logger.debug("Validation of Article finished:  " + isRuleValid);
			}		
		}
		return isRuleValid;
	}
	
	/**
	 * Method checks if related article's drawings are valid
	 * 
	 * @param  article - WTPart (Article) 
	 * @param relatedDrawings = related Documents or EPMDocuments for the article
	 * @param currentECT 
	 * @return false if related drawings are not valid otherwise return true
	 * 
	 */
	private boolean validateDrawings(Persistable article, Set<Persistable> relatedDrawings, List<RuleFeedbackMessage> paramList, WTChangeActivity2 currentECT) throws WTException {
		if (logger.isDebugEnabled()){
			logger.debug("Starting validation drawings");
		}
		boolean isValid = true;	
		QueryResult activities = ChangeTaskUtils.getActivitiesFromChangeContext(currentECT);	
		WTHashSet resultingofECN = ChangeTaskUtils.getResultingObjects(activities);
		boolean wtDocHasMoreRelatedArticles = false;
		if (logger.isDebugEnabled()){
			logger.debug("relatedDrawings size: " + relatedDrawings.size());
		}
		for (Persistable relatedDocument : relatedDrawings) {
			if(relatedDocument instanceof EPMDocument){
				WTPart[] associatedParts = ObjectDependencyUtility.getAssociated((EPMDocument) relatedDocument);
				List<WTPart> relatedParts =
						Arrays.stream(associatedParts).filter(part -> KBTypeIdProvider.isDescendant(part,
						KBConstants.ARTICLE_TYPE)).collect(Collectors.toList());
				if (logger.isDebugEnabled()){
					logger.debug("relatedDocument(EPMDocument):" + ((EPMDocument) relatedDocument).getNumber());
				}
				if(!relatedParts.isEmpty()){
					WTArrayList lsitOfparts =  new WTArrayList(relatedParts);
					WTHashSet latestRevisions = new WTHashSet(VersionControlHelper.service.getLatestRevisions(new WTArrayList(lsitOfparts)).wtValues()) ;
					if(latestRevisions.size() == 1 && !isSameVersion(article, relatedDocument)){
						paramList.add(new RuleFeedbackMessage(new WTMessage(RESOURCE, BusinessRuleRB.SINGLE_RAW_PART_DRAWING_REVISION, null), RuleFeedbackType.WARNING));
						logger.debug("Drawing has invalid revision");
						isValid = false;
					}
				}
			}
			else if(relatedDocument instanceof WTDocument){ 
				QueryResult associatedPartsQueryResult = PartDocHelper.service.getAssociatedParts((WTDocument) relatedDocument);
				if (logger.isDebugEnabled()){
					logger.debug("relatedDocument(WTDocument):" + ((WTDocument) relatedDocument).getNumber());
				}
				if(associatedPartsQueryResult != null){
					List<Persistable> associatedPartsList = new ArrayList<>();
					if(associatedPartsQueryResult.hasMoreElements()) {
						Object nextElement = associatedPartsQueryResult.nextElement();
						if(KBTypeIdProvider.isDescendant(nextElement, KBConstants.ARTICLE_TYPE))
							associatedPartsList.add((Persistable)nextElement);
					}
					WTHashSet latestRevisions =
							new WTHashSet(VersionControlHelper.service.getLatestRevisions(new WTArrayList(associatedPartsList)).wtValues());
					if(latestRevisions.size() == 1 && !isSameVersion(article, relatedDocument)){
						paramList.add(new RuleFeedbackMessage(new WTMessage(RESOURCE, BusinessRuleRB.SINGLE_RAW_PART_DRAWING_REVISION, null), RuleFeedbackType.WARNING));
						isValid = false;
						if (logger.isDebugEnabled()){
							logger.debug("Drawing has invalid revision");
						}
					}
					wtDocHasMoreRelatedArticles = associatedPartsQueryResult.size()>1;
					if (logger.isDebugEnabled()){
						logger.debug("wtdoc is associated to " + associatedPartsQueryResult.size() + " articles.");
					}
				}
			}
			 
			String relatedDrawingState = AttributeService.getAttribute(relatedDocument, "state.state");
			
			RevisionControlled latestReleased = (RevisionControlled) ObjectRevisionHelper.getLatestReleasedVersion(relatedDocument);
			
			WTChangeActivity2 activityOfRelatedDrawing = getRelatedActivity(relatedDocument, currentECT);
			
			if (resultingofECN.contains(relatedDocument)) {
				ChangeRecord2 changeRecordRelatedDocument = ChangeTaskUtils.getChangeRecord(relatedDocument, activityOfRelatedDrawing);
				Transition targetTransition = changeRecordRelatedDocument.getTargetTransition();
				if(targetTransition != null){
					relatedDrawingState = targetTransition.toString();
					if (logger.isDebugEnabled()){
						logger.debug("Drawing target state" + relatedDrawingState);
					}
				} 				
			}
			ChangeRecord2 articleTargetState = ChangeTaskUtils.getChangeRecord(article, currentECT);
			Transition articleTransition = articleTargetState.getTargetTransition();
			String articleState = null;
			if(articleTransition != null){
				articleState = articleTransition.toString();
			}		
			
			if (logger.isDebugEnabled()){
				logger.debug("relatedDrawingState:" + relatedDrawingState + " articleState: " + articleState + " wtDocHasMoreRelatedArticles: " + wtDocHasMoreRelatedArticles);
				logger.debug("relatedDrawing Latest Released: " + (latestReleased != null ? latestReleased.getDisplayIdentity().toString() : "null"));
			}
			if (!STATE_1050.equals(relatedDrawingState)  && INVALID_TARGET_STATES.get(STATE_1050).contains(articleState)){
					if( !(latestReleased != null && wtDocHasMoreRelatedArticles)) {
						paramList.add(new RuleFeedbackMessage(new WTMessage(RESOURCE, BusinessRuleRB.SINGLE_RAW_PART_DRRAWING_STATE_1050, null), getFeedbackType()));
						isValid = false;
						if (logger.isDebugEnabled()){
							logger.debug("Drawing has invalid state, It needs to be 1050");
						}
					} else {
						if (logger.isDebugEnabled()){
							logger.debug("Drawing has invalid state, but it has latest released version in 1050, and is associated to more articles.");
						}
					}
			}
			if (!STATE_1080.equals(relatedDrawingState) && INVALID_TARGET_STATES.get(STATE_1080).contains(articleState)) {
				paramList.add(new RuleFeedbackMessage( new WTMessage(RESOURCE, BusinessRuleRB.SINGLE_RAW_PART_DRRAWING_STATE_1080, null), getFeedbackType()));
				logger.debug("Drawing has invalid state, It needs to be 1080");
				isValid = false;
			}
			if(!isValid){
				break;
			}
		}
		if (logger.isDebugEnabled()){
			logger.debug("Drawing is valid: " +isValid);
		}
		return isValid;
	}
	
	
	/**
	 * Method checks if related drawing's article is valid 
	 * 
	 * @param relatedArticle - related WTPart (Article)
	 * @param drawing - drawing (EPMDocument or WTDocument)
	 * @param paramList - list of errors
	 * @param currentECT 
	 * @return false if related article is not valid otherwise return true
	 */
	private boolean validateRelatedPart(Persistable relatedArticle, Persistable drawing, List<RuleFeedbackMessage> paramList, WTChangeActivity2 currentECT) throws WTException {
		boolean isValid = true;
		QueryResult activities = ChangeTaskUtils.getActivitiesFromChangeContext(currentECT);	
		WTHashSet resultingofECN = ChangeTaskUtils.getResultingObjects(activities);

		WTPart latestVersion = (WTPart) relatedArticle;
		String state = latestVersion.getState().toString();
		WTChangeActivity2 activityOfRelatedPart = getRelatedActivity(relatedArticle, currentECT);
		ChangeRecord2 changeRecordDrawing = ChangeTaskUtils.getChangeRecord(drawing, currentECT);
		String drawingTargetState = changeRecordDrawing.getTargetTransition().toString();
		String relatedArticleTargetState = null;
		if (logger.isDebugEnabled()){
			logger.debug("relatedArticle: " + latestVersion.getNumber());
			logger.debug("activityOfRelatedPart: " + (activityOfRelatedPart == null ? null : activityOfRelatedPart.getNumber()));
			logger.debug("drawingTargetState: " + drawingTargetState);
		}

		if (!resultingofECN.contains(latestVersion)) {
			paramList.add(new RuleFeedbackMessage( new WTMessage(RESOURCE, BusinessRuleRB.SINGLE_RAW_PART_NO_RESULTING_OBJECT, null), getFeedbackType()));
			logger.debug("related Article is not resulting object of ECN");
			isValid = false;
		}
		if (Integer.valueOf(state) >= 1030) {
			paramList.add(new RuleFeedbackMessage(new WTMessage(RESOURCE, BusinessRuleRB.SINGLE_RAW_PART_INVALID_STATE, null), getFeedbackType()));
			logger.debug("Related Article has not required state. It must be < 1030");
			isValid = false;
		}
		if (!isSameVersion(relatedArticle, drawing)) {
			paramList.add(new RuleFeedbackMessage( new WTMessage(RESOURCE, BusinessRuleRB.SINGLE_RAW_PART_INVALID_REVISION, null), RuleFeedbackType.WARNING));
			logger.debug("Related Article has differetn revision then Drawing");
			isValid = false;
		}
		if (resultingofECN.contains(latestVersion)) {
			ChangeRecord2 changeRecordRelatedArticle = ChangeTaskUtils.getChangeRecord(relatedArticle,activityOfRelatedPart);
			 Transition relatedArticleTransition = changeRecordRelatedArticle.getTargetTransition();	
			 if(relatedArticleTransition != null){
				 relatedArticleTargetState = relatedArticleTransition.toString();
			 }
			 if (logger.isDebugEnabled()){
					logger.debug("relatedArticleTargetState: " + relatedArticleTargetState);
			 }
			if (STATE_1050.equals(drawingTargetState)  && !INVALID_TARGET_STATES.get(STATE_1050).contains(relatedArticleTargetState)) {
				paramList.add(new RuleFeedbackMessage(new WTMessage(RESOURCE, BusinessRuleRB.SINGLE_RAW_PART_INVALID_RELEASE_TARGET_FOR_1050, null), getFeedbackType()));
				logger.debug("Article has invalid state, it require state for Drawing in 1050");
				isValid = false;
			}
			if (STATE_1080.equals(drawingTargetState) && !INVALID_TARGET_STATES.get(STATE_1080).contains(relatedArticleTargetState)) {
				paramList.add(new RuleFeedbackMessage( new WTMessage(RESOURCE, BusinessRuleRB.SINGLE_RAW_PART_INVALID_RELEASE_TARGET_FOR_1080, null), getFeedbackType()));
				logger.debug("Article has invalid state, it require state for Drawing in 1080");
				isValid = false;
			}
		} else {
			if (logger.isDebugEnabled()){
				logger.debug("latestVersion is NOT a resulting object on the ECN.");
			}
		}
		return isValid;
	}

	/**
	 * Method collecting all related CAD and technical Drawing
	 * 
	 * @param  persistable -  WTPart (Article) 
	 * @return return set of related Drawings
	 */
	private Set<Persistable> getRelatedDrawings(Persistable persistable) throws WTException {
		logger.debug("Starting collecting drawings");
		Set<Persistable> set = new HashSet<>();
		QueryResult associatedDocuments = PartDocHelper.service.getAssociatedDocuments((WTPart) persistable);
		WTCollection calculatedCads = EPMChangeUtils.getCalculatedDocuments(persistable);
		if (logger.isDebugEnabled()){
			logger.debug("calculatedCads size: " + calculatedCads.size());
			for (Object objectRef : calculatedCads) {
				if (objectRef instanceof ObjectReference){
					Persistable object = ((ObjectReference)objectRef).getObject();
					if (object instanceof EPMDocument){
						logger.debug("calculatedCAD: " + ((EPMDocument)object).getNumber());
					} else if (object instanceof WTDocument) {
						logger.debug("calculatedCAD: " + ((WTDocument)object).getNumber());
					} else {
						logger.debug("calculatedCAD: " + objectRef);
					}
				} else {
					logger.debug("calculatedCAD: " + objectRef);
				}
			}
		}
		while (associatedDocuments.hasMoreElements()) {
			Persistable document = (Persistable) associatedDocuments.nextElement();
			if (isTechnicalDrawing(document)) {
				Object contentType = AttributeService.getAttribute(document, "KB_DOC_CONTENT_TYPE");
				if (document instanceof EPMDocument){
					logger.debug("tech drw: " + ((EPMDocument)document).getNumber() + " KB_DOC_CONTENT_TYPE=" + contentType);
				} else {
					logger.debug("tech drw: " + ((WTDocument)document).getNumber() + " KB_DOC_CONTENT_TYPE=" + contentType);
				}
				if (INVALID_DOC_CONTENTS.contains(contentType)) {
					logger.debug("KB_DOC_CONTENT_TYPE is invalid");
					set.add(ObjectRevisionHelper.getLatestVersionByPersistable(document));
				}
			}
		}
		set.removeAll(calculatedCads);
		logger.debug("set size: " + set.size());
		return set;
	}
	
	
	/**
	 * Method collect exactly one related article
	 * 
	 * @param  persistable -  CAD or Technical Drawing
	 * @return return related Article  or null if Article is not collected
	 * @throws WTException
	 */
	private WTPart getRelatedArticle(Persistable persistable) throws WTException {
		logger.debug("Starting collecting article");
		WTPart relatedPart = null;
		Set<WTPart> set = new HashSet<>();
		if (persistable instanceof EPMDocument) {
			WTPart[] relatedParts = ObjectDependencyUtility.getAssociated((EPMDocument) persistable);
			logger.debug("EPM : " + ((EPMDocument) persistable).getNumber());
			if (relatedParts != null) {
				List<WTPart> relatedPartsList = Arrays.asList(relatedParts);
				logger.debug("has " + relatedPartsList.size() + " related parts.");
				for (WTPart part : relatedPartsList) {
					if(KBTypeIdProvider.isDescendant(part, KBConstants.ARTICLE_TYPE)) {
						WTPart latestVersion = (WTPart) ObjectRevisionHelper.getLatestVersionByPersistable(part);
						logger.debug("part: " + latestVersion.getNumber());
						set.add(latestVersion);
					}
				}
			}
		} else if (persistable instanceof WTDocument) {
			QueryResult associatedParts = PartDocHelper.service.getAssociatedParts((WTDocument) persistable);
			logger.debug("WTDoc : " + ((WTDocument) persistable).getNumber());
			logger.debug("has " + associatedParts.size() + " related parts.");
			while (associatedParts.hasMoreElements()) {
				WTPart part = (WTPart) associatedParts.nextElement();
				if(KBTypeIdProvider.isDescendant(part, KBConstants.ARTICLE_TYPE)) {
					WTPart latestVersion = (WTPart) ObjectRevisionHelper.getLatestVersionByPersistable(part);
					set.add(latestVersion);
				}
			}
		}
		logger.debug("set size: " + set.size());
		if (set.size() == 1) {
			relatedPart = set.iterator().next();
		}
		if (relatedPart != null) {
			String partCategoryAttribute = AttributeService.getAttribute(relatedPart, "KB_PART_CATEGORY");
			String masterSystemWindchill = AttributeService.getAttribute(relatedPart, "KB_MASTERSYSTEM");
			logger.debug("relatedPart: " + relatedPart.getNumber() + " partCategoryAttribute: " + partCategoryAttribute + " masterSystemWindchill: " + masterSystemWindchill);
			if (!(INVALID_CATEGORIES.contains(partCategoryAttribute)
					&& WINDCHILL_MASTER_SYSTEM.equalsIgnoreCase(masterSystemWindchill))) {
				relatedPart = null;
				logger.debug("setting related part to null");
			}
		}
		logger.debug("related part:" + (relatedPart == null ? null : relatedPart.getNumber()));
		return relatedPart;
	}
	
	/**
	 * Method return related activity for searched object
	 * @param currentECT 
	 * 
	 * @param  relatedArticle -   searched object
	 * @return return related Activity or null if activity is not found
	 * @throws WTException
	 */
	private WTChangeActivity2 getRelatedActivity(Persistable relatedArticle, WTChangeActivity2 currentECT) throws WTException {
		QueryResult activities = ChangeTaskUtils.getActivitiesFromChangeContext(currentECT);
		while(activities.hasMoreElements()){
			WTChangeActivity2 activity = (WTChangeActivity2) activities.nextElement();
			QueryResult changeablesAfter = ChangeHelper2.service.getChangeablesAfter(activity);
			WTHashSet activitiesSet = new WTHashSet(changeablesAfter);
			if(activitiesSet.contains(relatedArticle)){
				return activity;
			}
		} 
		return null;
	}
	
	/**
	 * Method check if objectA and objectB have same revision
	 * 
	 * @param  objectA -   first object 
	 *  @param  objectB -   second object 
	 * @return return true if object are same version
	 * @throws WTException
	 */
	private static boolean isSameVersion(Persistable objectA, Persistable objectB) {
		Versioned versionedA = (Versioned) objectA;
		VersionIdentifier versionIdentifierA = versionedA.getVersionIdentifier();
		
		Versioned versionedB = (Versioned) objectB;
		VersionIdentifier versionIdentifierB = versionedB.getVersionIdentifier();
		
		int valueA = Integer.parseInt(versionIdentifierA.getValue());
		int valueB = Integer.parseInt(versionIdentifierB.getValue());
		
		return (valueA == valueB) ? true : false;
	}

	@Override
	public void prepareForValidation(RuleValidationKey validationKey, RuleValidationCriteria paramRuleValidationCriteria)
			throws WTException {
		logger.debug("Preparing validation of KBSingleRawPartValidator");
		validationKey.addToProcessingMap(ECT, (WTChangeActivity2) paramRuleValidationCriteria.getPrimaryBusinessObject());
	}
	
	private boolean isTechnicalDrawing(Persistable document) {
		boolean result = false; 
		if (KBType.isOfType(document, "com.ptc.KBTechnicalDrawing")
				|| KBType.isOfType(document, "com.ptc.DesignCADDrw")) {
			result = true;
		}
		return result;
	}

	@Override
	public boolean isRulesValid(Persistable paramPersistable,
			Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList) throws WTException {
		// TODO Auto-generated method stub
		return false;
	}

} 
 