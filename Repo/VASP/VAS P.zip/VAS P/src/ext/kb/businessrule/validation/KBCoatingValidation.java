package ext.kb.businessrule.validation;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.ptc.generic.iba.AttributeService;

import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.KBTypeIdProvider;
import wt.fc.Persistable;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.part.WTPart;
import wt.pds.StatementSpec;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;
import wt.util.WTMessage;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;

import org.apache.log4j.Logger;

public class KBCoatingValidation extends KBValidation {

	private static final String IBA_COATING = "KB_SURFACE";
    private static final Logger LOGGER = Logger.getLogger(KBCoatingValidation.class);
	
	@Override
	public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList) throws WTException {
		boolean isArticle = KBTypeIdProvider.isDescendant(paramPersistable, "ARTICLE");
		if(LOGGER.isDebugEnabled()){
			LOGGER.debug("Is article? "+isArticle);
		}
		boolean isCoatingValid = true;
		if(isArticle){
			String coating  = AttributeService.getAttribute(paramPersistable, IBA_COATING);
			if(coating != null)
			{	
				LOGGER.debug("coating - "+coating);
				String coatings[] = coating.split(";");
				for(int i =0; i<coatings.length;i++ )
				{
					WTPart cce = (WTPart) findCCE(coatings[i]);
					LOGGER.debug("Got coating value: "+coatings[i]);
					if(!cce.getLifeCycleState().toString().equalsIgnoreCase("1050")){
						isCoatingValid = false;
						  paramList.add(new RuleFeedbackMessage(new WTMessage(RESOURCE, BusinessRuleRB.KBCOATING_STATE_INVALID, null), getFeedbackType()));
						  LOGGER.debug("Invalid Lifecycle state - "+cce.getLifeCycleState().toString());
					}
				}
				if(!isCoatingValid)	
					return false;
			}
		}
		return true;
	}
	
	
	private static Object findCCE(String coatingNumber) throws WTException {
		Object cce = null; 
		LOGGER.debug("Querying database with id: " + coatingNumber);
		QueryResult query = queryObjectById(WTPart.class, "master>number", coatingNumber);
		LOGGER.debug("Found " + query.size() + " items");
		while (query.hasMoreElements()) {
			WTPart part = (WTPart) query.nextElement();
			if(!part.isLatestIteration()){
				continue;
			}
			LOGGER.debug("cce:" + part.getName());
			if (part != null) {
					cce = part;
			}
		}
		return cce;
	}
	private static QueryResult queryObjectById(Class<?> objClass, String attribute, String value) throws WTException {
		QuerySpec querySpec = new QuerySpec(objClass);
		QueryResult qResult = null ;
		querySpec.appendWhere(new SearchCondition(objClass, attribute, SearchCondition.EQUAL, value), new int[] { 0 });
		LOGGER.debug("Querying object with: " + querySpec.toString());
		qResult = PersistenceServerHelper.manager.query((StatementSpec) querySpec);
		LOGGER.debug("returing qResult : " + qResult.size());
		return qResult;
	}


}
