package ext.kb.businessrule.validation;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;

import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.KBConstants;
import ext.kb.util.KBTypeIdProvider;
import wt.build.BuildRule;
import wt.doc.WTDocument;
import wt.epm.EPMDocument;
import wt.epm.build.EPMBuildRule;
import wt.epm.build.EPMBuildRuleAssociationLink;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.lifecycle.LifeCycleHelper;
import wt.lifecycle.LifeCycleState;
import wt.log4j.LogR;
import wt.part.WTPart;
import wt.part.WTPartHelper;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.vc.struct.StructHelper;

public class CadReleaseRuleValidator extends KBValidation {

	private static final Logger LOG = LogR.getLogger(CadReleaseRuleValidator.class.getName());

	@Override
	public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList) throws WTException {

		LOG.debug("paramPersistable :: "+paramPersistable+"\n paramMap ::"+paramMap +"\n paramList :: "+paramList);
		boolean isvalid=true;
		Boolean kbPhantom = false;
		String name = null;
		WTPart latestPart;
		String num = null;
		String CadNum = null;
		EPMDocument epmDoc = null ;

		if(paramPersistable instanceof EPMDocument)
		{
			epmDoc = (EPMDocument) paramPersistable;

			boolean isKBCadDrw = KBTypeIdProvider.isDescendant(epmDoc, "KBCADDRW");

			if(isKBCadDrw)
			{
				String state = epmDoc.getState().toString();
				if(!state.equalsIgnoreCase("1050"))
				{
					kbPhantom = ext.kb.util.IBAHelper.readIBA(epmDoc, KBConstants.KB_PHANTOM_IBA);
					boolean ndGeneration = ext.wfHelper.KB_AdvReleasePendingProcessHelper.skipTransferToCadim(epmDoc);
					logger.debug("kbPhantom : " + kbPhantom+" ndGeneration: "+ndGeneration);

					if(kbPhantom!=null)
					{
						if(kbPhantom && ndGeneration )
						{
							isvalid = false;
						}
					}

					QueryResult associatedParts = StructHelper.service.navigateDescribes(epmDoc, wt.epm.structure.EPMDescribeLink.class, true);

					if(associatedParts.size()!=0)
					{
						while(associatedParts.hasMoreElements())
						{
							WTPart referencedPart = (WTPart) associatedParts.nextElement();
							name = referencedPart.getName();
							LOG.debug("name: "+name);

							latestPart = (wt.part.WTPart) wt.vc.VersionControlHelper.service.allVersionsOf(referencedPart.getMaster()).nextElement();
							Integer partState = Integer.valueOf(latestPart.getState().toString());
							LOG.debug("partState: "+partState);

							if(partState>=1030 && partState<=1070)
							{
								QueryResult describeDoc = WTPartHelper.service.getDescribedByDocuments(latestPart);

								if(describeDoc.size()!=0)
								{
									while(describeDoc.hasMoreElements())
									{
										Object obj = describeDoc.nextElement();

										if(obj instanceof WTDocument)
										{
											WTDocument doc = (WTDocument) obj;
											CadNum = epmDoc.getNumber();
											num = doc.getNumber();
											LOG.debug("CadNum: "+CadNum+"num: "+num);

											if(!CadNum.equals(num))
											{
												isvalid = false;
												paramList.add(new RuleFeedbackMessage(new WTMessage(RESOURCE, BusinessRuleRB.KB_INVALID_CAD, new Object[] { CadNum }),
														getFeedbackType()));
											}
										}
									}
								}
							}

						}
					}
				}




			}
		}

		return isvalid;
	}

} 
