package ext.kb.businessrule.validation;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.core.businessRules.feedback.RuleFeedbackType;
import com.ptc.generic.iba.AttributeService;

import ext.kb.change2.helper.ChangeNoticeUtils;
import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.KBConstants;
import ext.kb.util.KBDocumentUtils;
import ext.kb.util.KBTypeIdProvider;
import ext.kb.util.KBUtils;
import ext.kb.util.ObjectRevisionHelper;
import wt.change2.ChangeHelper2;
import wt.change2.ChangeRecord2;
import wt.change2.WTChangeActivity2;
import wt.change2.WTChangeOrder2;
import wt.doc.WTDocument;
import wt.epm.EPMDocument;
import wt.epm.structure.EPMDescribeLink;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.fc.collections.WTArrayList;
import wt.fc.collections.WTHashSet;
import wt.fc.collections.WTKeyedMap;
import wt.identity.IdentityFactory;
import wt.lifecycle.State;
import wt.lifecycle.Transition;
import wt.part.WTPart;
import wt.part.WTPartHelper;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.vc.struct.StructHelper;

public class KBDocObsolescenceValidator extends KBValidation {

	private static final String DOC_TYPE_664 = "664";
	private static final String STATE_1080 = "1080";

	@Override
	public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList) throws WTException {

		if (logger.isDebugEnabled()) {
			logger.debug(
					"entering isRulesValid(Persistable,Map<String,Set<AttributeRuleSet>>,List<RuleFeedbackMessage>)");
			logger.debug("paramPersistable: " + paramPersistable);
			logger.debug("paramMap: " + paramMap);
			logger.debug("paramList: " + paramList);
		}

		if (!isDocValidForCheck(paramPersistable)) {
			if (logger.isDebugEnabled()) {
				logger.debug("Object " + paramPersistable + " is not valid for check, returning");
			}
			return true;
		}

		ChangeRecord2 changeRecord = ChangeNoticeUtils.getChangeRecord(paramPersistable);
		Transition targetTransition = changeRecord.getTargetTransition();

		WTChangeActivity2 docECT = (WTChangeActivity2) changeRecord.getRoleAObject();

		String documentTargetState = targetTransition != null
				? KBUtils.getKBTargetStateNumericValueString(targetTransition) : "";

		if (!STATE_1080.equals(documentTargetState)) {
			if (logger.isDebugEnabled()) {
				logger.debug("Objects " + paramPersistable + " target state is not 1080, returning");
			}
			return true;
		}

		Set<WTPart> relatedParts = getRelatedWTParts(paramPersistable);
		Persistable latestReleasedDoc = ObjectRevisionHelper.getLatestReleasedVersion(paramPersistable);
		relatedParts.addAll(getRelatedWTParts(latestReleasedDoc));

		boolean result = true;
		for (WTPart part : relatedParts) {
			result = validateRelatedPart(part, paramPersistable, docECT);
			if (!result) {
				break;
			}
		}
		if (!result) {
			RuleFeedbackMessage localRuleFeedbackMessage = getErrorFeedbackMessage(paramPersistable);
			paramList.add(localRuleFeedbackMessage);
		}

		if (logger.isDebugEnabled()) {
			logger.debug(
					"returning from isRulesValid(Persistable,Map<String,Set<AttributeRuleSet>>,List<RuleFeedbackMessage>)");
			logger.debug("result: " + result);
		}
		return result;

	}

	protected RuleFeedbackMessage getErrorFeedbackMessage(Persistable paramPersistable) throws WTException {
		String localizedMessage = IdentityFactory.getDisplayIdentifier(paramPersistable)
				.getLocalizedMessage(SessionHelper.manager.getLocale());
		WTMessage message = new WTMessage(BusinessRuleRB.class.getName(), BusinessRuleRB.KB_DOC_OBSOLETE_ERROR_MSG,
				new Object[] { localizedMessage });
		RuleFeedbackMessage localRuleFeedbackMessage = new RuleFeedbackMessage(message, RuleFeedbackType.ERROR);
		return localRuleFeedbackMessage;
	}

	private boolean validateRelatedPart(WTPart part, Persistable document, WTChangeActivity2 documentECT)
			throws WTException {
		if(!KBTypeIdProvider.isDescendant(part, KBConstants.ARTICLE_TYPE)) {
			return true;
		}
		WTPart latestRevision = (WTPart) ObjectRevisionHelper.getLatestVersionByPersistable(part);
		String latestRevisionState = KBUtils.getKBStateNumericValueString(latestRevision);
		int stateInteger;
		try {
			stateInteger = Integer.parseInt(latestRevisionState);
		} catch (NumberFormatException ex) {
			stateInteger = 0;
		}
		
		if (partIsInSameChangeContext(latestRevision, documentECT)) {
			if (logger.isDebugEnabled()) {
				logger.debug("part " + part + " is in same change context as document");
			}
			return validatePartTargetStates(latestRevision, document);
		} else {
			if (logger.isDebugEnabled()) {
				logger.debug("part " + part + " is not in same change context as document");
				logger.debug("part " + part + " is in state > 1010");
			}
			
			// getting the latest iteration of the linked part
			WTPart latestIteration = (WTPart) ObjectRevisionHelper.getLatestIterationOfVersion(part, false);
			String latestIterationState = KBUtils.getKBStateNumericValueString(latestIteration);
			try {
				// getting state of latest iteration of the linked part
				stateInteger = Integer.parseInt(latestIterationState);
			} catch (NumberFormatException ex) {
				stateInteger = 0;
			}
			
			// checking if the linked part is already obsolete
			if (stateInteger >= 1075 && stateInteger <= 1080) {
				return true;
			}
			
			// if the linked document is not obsolete then checking if the previous version is linked or not
			WTPart previousVersion = (WTPart) ObjectRevisionHelper.getPreviousVersionLatestIteration(latestIteration);
			if (previousVersion != null && isPreviousRevisionLinkedWithDocument(previousVersion, document)) {
				if (logger.isDebugEnabled()) {
					logger.debug("previous version of part is linked with document");
				}
				String previousRevisionState = KBUtils.getKBStateNumericValueString(previousVersion);
				int stateIntegerPrevious;
				try {
					stateIntegerPrevious = Integer.parseInt(previousRevisionState);
				} catch (NumberFormatException ex) {
					stateIntegerPrevious = 0;
				}
				return (stateIntegerPrevious >= 1075 && stateIntegerPrevious <= 1080);
			}
		}

		return false;
	}

	private boolean isPreviousRevisionLinkedWithDocument(WTPart previousVersion, Persistable document)
			throws WTException {
		if (document instanceof EPMDocument) {
			QueryResult qr = KBUtils.navigateEPMDescribeLinkGetDescribedBy(previousVersion);
			WTHashSet set = new WTHashSet(qr);
			return set.contains(document);
		} else if (document instanceof WTDocument) {
			QueryResult describedByDocuments = WTPartHelper.service.getDescribedByDocuments(previousVersion);
			WTHashSet set = new WTHashSet(describedByDocuments);
			return set.contains(document);
		}
		return false;
	}

	private boolean validatePartTargetStates(WTPart part, Persistable document) throws WTException {
		
		logger.debug("Validating part target states");
		ChangeRecord2 changeRecord = ChangeNoticeUtils.getChangeRecord(part);
		Transition targetTransition = changeRecord.getTargetTransition();
		String partTargetStateSTR = targetTransition != null
				? KBUtils.getKBTargetStateNumericValueString(targetTransition) : "";
				
		logger.debug(part.getNumber() + " Part target state is : " + partTargetStateSTR);

		int stateInt;
		try {
			stateInt = Integer.parseInt(partTargetStateSTR);
			logger.debug(part.getNumber() + " Part Integer target state is : " + stateInt);
		} catch (NumberFormatException ex) {
			stateInt = 0;
			logger.debug("Part target state is set to " + stateInt);
		}
		
		if (stateInt >= 1075 && stateInt <= 1080) {
			logger.debug("Target state of the part is either 1075 or 1080");
			return (stateInt >= 1075 && stateInt <= 1080);
		} else if (stateInt >= 1050 && stateInt <= 1070) {
			logger.debug("Target state of the part between 1050 and 1070.");
			if (ObjectRevisionHelper.getPreviousVersionLatestIteration(part) != null) {
				logger.debug("Previous version not found for current part. Returning true.");
				return true;
			}
		// If not target state mentioned then stateInt = 0
		} else if (stateInt == 0) {
			if(KBUtils.getStateIntegerValue(part) == 1050) {
				return true;
			}
		}
		return false;
	}

	private boolean partIsInSameChangeContext(WTPart part, WTChangeActivity2 documentECT) throws WTException {
		WTChangeOrder2 ecn = ChangeNoticeUtils.getECN(documentECT);
		Boolean immediateRelease = AttributeService.getAttribute(documentECT, KBConstants.KB_IMMEDIATE_RELEASE_IBA);

		if (immediateRelease) {
			QueryResult changeablesAfter = ChangeHelper2.service.getChangeablesAfter(documentECT);
			WTHashSet set = new WTHashSet(changeablesAfter);
			return set.contains(part);
		} else {
			QueryResult changeActivities = ChangeHelper2.service.getChangeActivities(ecn);
			while (changeActivities.hasMoreElements()) {
				WTChangeActivity2 ect = (WTChangeActivity2) changeActivities.nextElement();
				Boolean immRel = AttributeService.getAttribute(ect, KBConstants.KB_IMMEDIATE_RELEASE_IBA);
				State ectState = ect.getLifeCycleState();
				if (!immRel && !KBConstants.STATE_CANCELED.equals(ectState)) {
					QueryResult changeablesAfter = ChangeHelper2.service.getChangeablesAfter(ect);
					WTHashSet set = new WTHashSet(changeablesAfter);
					if (set.contains(part)) {
						return true;
					}
				}
			}
		}

		return false;
	}

	private boolean isDocValidForCheck(Persistable resultingObject) {

		if (!KBDocumentUtils.isTechDrawing(resultingObject)
				&& !KBTypeIdProvider.isDescendant(resultingObject, "KBCADDRW")) {
			return false;
		}
		if (isSimplifiedDrawing(resultingObject)) {
			return false;
		}
		if (resultingObject instanceof EPMDocument && isCADPhantom(resultingObject)) {
			return false;
		}

		return true;
	}

	private boolean isSimplifiedDrawing(Persistable document) {
		String attribute = AttributeService.getAttribute(document, KBConstants.DOC_CONTENT_TYPE);
		return DOC_TYPE_664.equals(attribute) ? true : false;
	}

	private boolean isCADPhantom(Persistable document) {
		Boolean attribute = AttributeService.getAttribute(document, KBConstants.KB_PHANTOM_IBA);
		return attribute == null ? false : attribute.booleanValue();
	}

	private Set<WTPart> getRelatedWTParts(Persistable document) throws WTException {
		if (logger.isDebugEnabled()) {
			logger.debug("retrieving related parts for drawing: " + document);
		}
		Set<WTPart> relatedParts = new HashSet<>();

		if (document instanceof EPMDocument) {
			relatedParts.addAll(getPartsFromCadDrawing(document));
		} else if (document instanceof WTDocument) {
			relatedParts.addAll(getPartsFromWTDocuments(document));
		}
		if (logger.isDebugEnabled()) {
			logger.debug("found " + relatedParts.size() + " related parts");
		}
		return relatedParts;
	}

	@SuppressWarnings({ "deprecation", "unchecked" })
	private Set<WTPart> getPartsFromCadDrawing(Persistable document) throws WTException {
		Set<WTPart> associatedParts = new HashSet<>();

		WTArrayList collection = new WTArrayList();
		collection.add(document);
		WTKeyedMap navigateDescribes = StructHelper.service.navigateDescribes(collection, EPMDescribeLink.class, true);
		if (!navigateDescribes.isEmpty()) {
			WTArrayList parts = (WTArrayList) navigateDescribes.get(document);
			for (Object ref : parts) {
				ObjectReference partRef = (ObjectReference) ref;
				associatedParts.add((WTPart) partRef.getObject());
			}
		}

		return associatedParts;
	}

	private Set<WTPart> getPartsFromWTDocuments(Persistable paramPersistable) throws WTException {
		Set<WTPart> associatedParts = new HashSet<>();

		QueryResult describesWTParts = WTPartHelper.service.getDescribesWTParts((WTDocument) paramPersistable);
		while (describesWTParts.hasMoreElements()) {
			associatedParts.add((WTPart) describesWTParts.nextElement());
		}
		return associatedParts;
	}

}
