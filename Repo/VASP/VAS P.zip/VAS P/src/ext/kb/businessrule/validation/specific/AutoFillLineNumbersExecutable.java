package ext.kb.businessrule.validation.specific;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.ptc.core.businessRules.validation.RuleValidationKey;

import wt.fc.BinaryLink;
import wt.fc.PersistenceHelper;
import wt.log4j.LogR;
import wt.part.LineNumber;
import wt.part.WTPartUsageLink;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.WTPropertyVetoException;
import ext.kb.businessrule.validation.PartUsageLinkLogicExecutable;
import ext.kb.resources.KBPartUsageLinkRB;

/**
 * Implementation for autofill line/find numbers action
 * (KNORRBREMSE_RAILPLM-2235)
 * 
 * Code extracted from KBArticleAutofillFormProcessor class 
 * 
 * @author wachurad
 *
 */
public class AutoFillLineNumbersExecutable implements
		PartUsageLinkLogicExecutable {
	
	private static final Logger LOGGER = LogR.getLogger(AutoFillLineNumbersExecutable.class.getName());
	private static final String RESOURCE_KEY = "ext.kb.resources.KBPartUsageLinkRB";
	private static final String DEFAULT_FIND_NUMBER_VALUE = "0";
	
	/*
	 * Responsible for checking if find and lineNumber attributes
	 * are set.In case they are empty it fills them out with values
	 * in a specific order.
	 * (non-Javadoc)
	 * @see ext.kb.businessrule.validation.PartUsageLinkLogicExecutable#executeSpecific(wt.part.WTPartUsageLink, java.util.List)
	 */
	@Override
	public void executeSpecific(WTPartUsageLink link,
			List<BinaryLink> linksOnSameLevel, RuleValidationKey paramRuleValidationKey) throws WTException {
		String findNumber = link.getFindNumber();
		LineNumber lineNumber = link.getLineNumber();
		
		if(!StringUtils.isEmpty(findNumber) && null != lineNumber){
			return;
		}
		
		int nrOfUpdatedFindNumbers = executeFixOnLineNumber(link, linksOnSameLevel);
		int nrOfUpdatedLineNumbers = executeFixOnFindNumber(link, linksOnSameLevel);
		
		LOGGER.debug("nrOfUpdatedFindNumbers = " + nrOfUpdatedFindNumbers 
				+ ", nrOfUpdatedLineNumbers = " + nrOfUpdatedLineNumbers);
	}

	/*
	 * We need to fill out attributes only on the first Usage Link level.
	 * Meaning only the main Bom is considered, no sub Boms are scanned
	 * (non-Javadoc)
	 * @see ext.kb.businessrule.validation.PartUsageLinkLogicExecutable#isOnlyToplevel()
	 */
	@Override
	public boolean isOnlyToplevel() {
		return true;
	}

	/**
	 * PreHook that checks if the current object is a Bom,
	 * if so processes a sorting on the usageLinks, such
	 * that autofilling happens not randomly.
	 */
	@Override
	public void executeSpecificPreProcess(final List<BinaryLink> links)
			throws WTException {
		if(CollectionUtils.isEmpty(links)){
        	String message = WTMessage.getLocalizedMessage(RESOURCE_KEY, KBPartUsageLinkRB.OPERATION_ONLY_ALLOWED_ON_BOM,
                    new Object[] {}, SessionHelper.getLocale());
        	
        	throw new WTException(message);
        }
	
		sortBeforeProcess(links);
	}
	
	private int executeFixOnLineNumber(final WTPartUsageLink link, final List<BinaryLink> linksOnSameLevel) throws WTException{
		int counter = 0;
		LineNumber lineNumber = link.getLineNumber();
		if(null == lineNumber){
			//New object out of links list, because we modify the order of elements,
			//which affects the order in the main loop in BasePartUsageLinkProcessor.process
			List<BinaryLink> localLinksOnSameLevel = new ArrayList<BinaryLink>(linksOnSameLevel);
			WTPartUsageLink maxLineNumberItem =(WTPartUsageLink) Collections.max(localLinksOnSameLevel, new Comparator<BinaryLink>(){
				
				@Override
				public int compare(BinaryLink paramT1, BinaryLink paramT2) {
					WTPartUsageLink p1 = (WTPartUsageLink)paramT1;
					WTPartUsageLink p2 = (WTPartUsageLink)paramT2;
					LineNumber ln1 = p1.getLineNumber();
					LineNumber ln2 = p2.getLineNumber();
					if(ln1 == null && ln2 == null){
						return 0;
					}
					if(null == ln1){
						return -1;
					}
					if(null == ln2){
						return 1;
					}
					
					return Long.compare(ln1.getValue(), ln2.getValue());
				}
				
			});
			
			LineNumber maxLineNumber = maxLineNumberItem.getLineNumber();
			long maxLineNumberVal = maxLineNumber == null ? 0 : maxLineNumber.getValue();
			long newLineNumberVal = maxLineNumberVal + 10l;
			LineNumber newLineNumber = LineNumber.newLineNumber(newLineNumberVal);
			try {
				link.setLineNumber(newLineNumber);
				PersistenceHelper.manager.save(link);
				counter=1;
			} catch (WTPropertyVetoException e) {
				LOGGER.error("New line number value could not be set on WTPartUsageLink due to error", e);
				throw new WTException(e);
			}
		}
		return counter;
	}
	
	private int executeFixOnFindNumber(final WTPartUsageLink link, final List<BinaryLink> linksOnSameLevel) throws WTException{
		int counter = 0;
		String findNumber = link.getFindNumber();
		if(StringUtils.isEmpty(findNumber)){
			//Make a new Object out from param list
			List<BinaryLink> localLinksOnSameLevel = new ArrayList<BinaryLink>(linksOnSameLevel);
			
			//Filter out not numerical elements from list
			CollectionUtils.filter(localLinksOnSameLevel, new Predicate() {
				
				@Override
				public boolean evaluate(Object arg0) {
					WTPartUsageLink checked = (WTPartUsageLink) arg0;
					String findNumber = checked.getFindNumber();
					if(StringUtils.isEmpty(findNumber)){
						return false;
					}
					if(StringUtils.isNumeric(findNumber)){
						return true;
					}
					return false;
				}
			});
			//Sort the numerical values
			 Collections.sort(localLinksOnSameLevel, new Comparator<BinaryLink>(){
	
				@Override
				public int compare(BinaryLink paramT1, BinaryLink paramT2) {
					WTPartUsageLink p1 = (WTPartUsageLink)paramT1;
					WTPartUsageLink p2 = (WTPartUsageLink)paramT2;
					String fn1 = p1.getFindNumber();
					String fn2 = p2.getFindNumber();
					Integer i1 = Integer.valueOf(fn1);
					Integer i2 = Integer.valueOf(fn2);
					return i1.compareTo(i2);
				}
				
			});
			
			WTPartUsageLink itemWithMaxFindNumber = null;
			int nrOfItems = localLinksOnSameLevel.size();
			if(nrOfItems > 0){
				itemWithMaxFindNumber = (WTPartUsageLink)localLinksOnSameLevel.get(nrOfItems-1);
			}
			String maxfindNumberAsString = itemWithMaxFindNumber == null ? DEFAULT_FIND_NUMBER_VALUE : itemWithMaxFindNumber.getFindNumber(); 
			int maxFindNumber = Integer.parseInt(maxfindNumberAsString);
			
			int newFindNumber = maxFindNumber+1;
			
			try {
				link.setFindNumber(String.valueOf(newFindNumber));
				PersistenceHelper.manager.save(link);
				counter=1;
			} catch (WTPropertyVetoException e) {
				LOGGER.error("New findnumber value could not be set on WTPartUsageLink due to error", e);
				throw new WTException(e);
			}
		}
		return counter;
	}
	
	private void sortBeforeProcess(final List<BinaryLink> links){
		WTPartUsageLinkSorter sorter = new WTPartUsageLinkSorter(links);
		sorter.sortByNumberGeklaAndBuildStatus();
	}
	
}
