/**
 * 
 */
package ext.kb.businessrule.validation;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.generic.iba.AttributeService;

import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.DocumentVariantHelper;
import ext.kb.util.KBConstants;
import ext.kb.util.KBTypeIdProvider;
import ext.kb.workflow.EPMChangeUtils;
import wt.change2.ChangeActivity2;
import wt.change2.ChangeException2;
import wt.change2.ChangeHelper2;
import wt.change2.ChangeRecord2;
import wt.change2.ChangeRequestIfc;
import wt.change2.Changeable2;
import wt.change2.ChangeableIfc;
import wt.change2.SupportingDataFor;
import wt.change2.WTChangeOrder2;
import wt.doc.WTDocument;
import wt.epm.EPMDocument;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.log4j.LogR;
import wt.maturity.MaturityHelper;
import wt.util.WTException;
import wt.util.WTMessage;

/**
 * @author bankowskie
 *
 */
public class SourceVariantVersionRuleValidator extends KBValidation{
	protected static final Logger LOG = LogR.getLogger(SourceVariantVersionRuleValidator.class.getName());
	
	/* (non-Javadoc)
	 * @see ext.kb.businessrule.validation.KBValidation#isRulesValid(wt.fc.Persistable, java.util.Map, java.util.List)
	 */
	
	@Override
	public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap, List<RuleFeedbackMessage> paramList) throws WTException {
		boolean status = true;
		if(!(paramPersistable instanceof WTDocument)){
			LOG.debug("Invalid type for validation, returning");
			return true;
		}
		WTDocument paramDocument = (WTDocument) paramPersistable;
		if(DocumentVariantHelper.isSourceDocument(paramDocument)){
			LOG.debug("Param document is source document, returning.");
			return true;
		}
		status = validateRevision((WTDocument)paramPersistable,paramList);
		LOG.debug("Exiting with status: "+status);
		return status;
	}
	
	/**
	 * Method that iterates over all resulting items from ECN, and compares their numbers to filter out source and variant pairs. 
	 * Then the revision of these is compared and suitable message attached if needed.
	 * @param resultingItems - All resulting items from ECN //obsolete, not needed anymore
	 * @param paramDocument - WTDocument invoking listener
	 * @param paramList - Placeholder for UI message if validation fails
	 * @return Validation status
	 */
	private boolean validateRevision(WTDocument paramDocument, List<RuleFeedbackMessage> paramList){
		WTDocument sourceDocument = (WTDocument) DocumentVariantHelper.getSourceFromVariant(paramDocument);
		if(sourceDocument == null) {
			return true;
		}
		if(isRevisionNotEqual(paramDocument, sourceDocument)){
			paramList.add(new RuleFeedbackMessage(new WTMessage(RESOURCE, BusinessRuleRB.SOURCE_VARIANT_DIFFERENT_REVISION, new Object[] { paramDocument, sourceDocument }), getFeedbackType()));
			return false;
		}
		return true;
	}
	
	/**
	 * Method comparing revisions of two objects.
	 * @param arg1 First object to compare
	 * @param arg2 Second object to compare
	 * @return Revision compare status
	 */
	private boolean isRevisionNotEqual(Object arg1, Object arg2){
		LOG.debug("Comparing revisions of "+arg1+" and "+arg2);
		String arg1Revision = AttributeService.getAttribute(arg1, "revision").toString() + AttributeService.getAttribute(arg1, "versionInfo.identifier.versionId").toString();
		String arg2Revision = AttributeService.getAttribute(arg2, "revision").toString() + AttributeService.getAttribute(arg2, "versionInfo.identifier.versionId").toString();
		boolean status = !arg1Revision.equals(arg2Revision);
		LOG.debug("Is revision different? : "+status);
		return status;
	}

	
}

