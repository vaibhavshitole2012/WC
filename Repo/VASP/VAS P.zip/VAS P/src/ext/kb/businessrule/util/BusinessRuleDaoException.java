package ext.kb.businessrule.util;

public class BusinessRuleDaoException extends RuntimeException {

    private static final long serialVersionUID = -7514981547855674194L;

    public BusinessRuleDaoException() {
    }

    public BusinessRuleDaoException(String message) {
        super(message);
    }

    public BusinessRuleDaoException(String message, Throwable cause) {
        super(message, cause);
    }

}
