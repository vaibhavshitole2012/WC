package ext.kb.businessrule.validation;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import wt.fc.Persistable;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.log4j.LogR;
import wt.part.WTPart;
import wt.query.QueryException;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.type.TypedUtilityServiceHelper;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.vc.VersionControlHelper;
import wt.vc.config.ConfigSpec;
import wt.vc.config.LatestConfigSpec;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.core.businessRules.validation.RuleValidationKey;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.TypeIdentifierHelper;
import com.ptc.generic.iba.AttributeService;

import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.KBConstants;
import ext.kb.util.KBUtils;
import ext.kb.util.ObjectRevisionHelper;

public class KBNamingEntryValidator extends KBValidation {

	protected static final Logger LOG = LogR.getLogger(KBNamingEntryValidator.class.getName());
	private static final String RULE_RESOURCE = "ext.kb.resources.BusinessRuleRB";

	@Override
	public boolean isConfigurationValid(RuleValidationKey paramRuleValidationKey) throws WTException {
		return super.isConfigurationValid(paramRuleValidationKey);
	}
	
	@Override
	public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap, List<RuleFeedbackMessage> paramList,
			RuleValidationKey paramRuleValidationKey) throws WTException {
		if (LOG.isDebugEnabled()) {
			LOG.debug("entering isRulesValid(Persistable,Map<String,Set<AttributeRuleSet>>,List<RuleFeedbackMessage>)");
			LOG.debug("paramPersistable: " + paramPersistable);
			LOG.debug("paramMap: " + paramMap);
			LOG.debug("paramList: " + paramList);
		}
		// Checking if need to validate paramPersistable
		if (skipValidation(paramPersistable)){
			if (LOG.isDebugEnabled()) {
				LOG.debug("exiting isRulesValid()");
				LOG.debug("returning true");
			}
			return true;
		}
		
		List<RuleFeedbackMessage> tmpList = new  ArrayList<RuleFeedbackMessage>();
		boolean isValid = true;

		String description1Dyn = (String) AttributeService.getAttribute(paramPersistable, KBConstants.TRANSLATION_ID_IBA);
		String description2Dyn = (String) AttributeService.getAttribute(paramPersistable, KBConstants.TRANSLATION2_ID_IBA);
		if (LOG.isInfoEnabled()) {
			LOG.info("description1Dyn: " + description1Dyn + " description2Dyn: " + description2Dyn);
		}
		
		if (StringUtils.isEmpty(description1Dyn)) {
			tmpList.add(new RuleFeedbackMessage(new WTMessage(RULE_RESOURCE, BusinessRuleRB.KB_NAMING_ENTRY_RULE_DESCRIPTION1_REQUIRED, new Object[] {}), getFeedbackType()));
		} else {
			validateNamingEntry(description1Dyn, tmpList, BusinessRuleRB.KB_NAMING_ENTRY_RULE_DESCRIPTION1_INVALID);
		}
		
		if (!StringUtils.isEmpty(description2Dyn)) {
			validateNamingEntry(description2Dyn, tmpList, BusinessRuleRB.KB_NAMING_ENTRY_RULE_DESCRIPTION2_INVALID);
		}

		if (!CollectionUtils.isEmpty(tmpList)){
			paramList.addAll(tmpList);
			isValid = false;
		}

		if (LOG.isDebugEnabled()) {
			LOG.debug("exiting isRulesValid()");
			LOG.debug("returning: " + isValid);
		}
		return isValid;
	}
	
	
	private boolean skipValidation(Persistable paramPersistable) {
		List<TypeIdentifier> validObjectTypes = Arrays.asList(new TypeIdentifier[]{ TypeIdentifierHelper.getTypeIdentifier("com.ptc.KBDocuments"),
				TypeIdentifierHelper.getTypeIdentifier("com.ptc.KBStdSemi"),
				TypeIdentifierHelper.getTypeIdentifier("com.ptc.KBAssyComp"),
				TypeIdentifierHelper.getTypeIdentifier("com.ptc.KBSalesSystemsBoM"),
				TypeIdentifierHelper.getTypeIdentifier("com.ptc.DesignCADDoc")
				});
		TypeIdentifier currentObjectType = TypeIdentifierHelper.getType(paramPersistable);
		if (LOG.isDebugEnabled()){
			LOG.debug("currentObjectType=" + currentObjectType.getTypename());
		}
		boolean skipValidation = true;
		if (!validObjectTypes.contains(currentObjectType)){
			for (TypeIdentifier typeIdentifier : validObjectTypes) {
				if (currentObjectType.isDescendedFrom(typeIdentifier)){
					skipValidation = false;
					break;
				}
			}
			if (LOG.isDebugEnabled()) {
				LOG.debug("skipValidation= " + skipValidation);
			}
		}
		return skipValidation;
	}

	@Override
	public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList) throws WTException {
		return false;
	}
	
	private void validateNamingEntry(String namingEntryId, List<RuleFeedbackMessage> tmpList, String rbErrorKey) throws QueryException, WTException {
		WTPart latestNamingEntry = getLatestNamingEntry(namingEntryId);
		if (latestNamingEntry == null){
			tmpList.add(new RuleFeedbackMessage(new WTMessage(RULE_RESOURCE, rbErrorKey, new Object[] {namingEntryId}), getFeedbackType()));
		} else {
			try{
				if (!isNamingEntryValid(latestNamingEntry)){
					tmpList.add(new RuleFeedbackMessage(new WTMessage(RULE_RESOURCE, rbErrorKey, new Object[] {namingEntryId}), getFeedbackType()));
				}
			} catch (WTException e){
				tmpList.add(new RuleFeedbackMessage(new WTMessage(RULE_RESOURCE, rbErrorKey, new Object[] {namingEntryId}), getFeedbackType()));
			}
		}
	}

	/**
	 * Recursive validation of naming entry<br>
	 * <ul>
	 * <li> If the latest version of the Naming Entry is in state 1050, it is valid <br>
	 * <li> If the latest version of the Naming Entry is in state 1080 it is not valid <br>
	 * <li> If the latest version of the Naming Entry is in a state other than 1050 or 1080 <br>
	 * 	Check if an earlier version exists in state 1050 <br>
	 * 	<ul> 
	 * 	<li> If it does, then Naming Entry is valid <br>
	 * 	<li> If it does not, then Naming Entry is invalid <br>
	 * 	</ul>
	 * </ul>
	 * @param namingEntry
	 * @return
	 * @throws WTException
	 */
	private boolean isNamingEntryValid(WTPart namingEntry) throws WTException {
		if (namingEntry == null){
			if (LOG.isDebugEnabled()){
				LOG.debug("namingEntry is null, returning false");
			}
			return false;
		}
		if (LOG.isDebugEnabled()){
			LOG.debug("isNamingEntryValid started: " + KBUtils.getIdentityWithStateAndRevision(namingEntry));
			
		}
		WTPart latestVersion = (WTPart) ObjectRevisionHelper.getLatestVersionByPersistable(namingEntry);
		if (latestVersion.getVersionIdentifier().getValue().equals(namingEntry.getVersionIdentifier().getValue())
				&& VersionControlHelper.isLatestIteration(namingEntry)){
			if (namingEntry.getState().toString().compareTo(KBConstants.RELEASED) == 0){
				if (LOG.isDebugEnabled()){
					LOG.debug("namingEntry is in 1050, returning true");
				}
				return true;
			} else if (namingEntry.getState().toString().compareTo(KBConstants.INVALID) == 0){
				if (LOG.isDebugEnabled()){
					LOG.debug("namingEntry is in 1080, returning false");
				}
				return false;
			} else {
				WTPart previous = (WTPart) ObjectRevisionHelper.getPreviousVersionLatestIteration(namingEntry);
				return isNamingEntryValid(previous);
			}
		} else {
			if (namingEntry.getState().toString().compareTo(KBConstants.RELEASED) == 0){
				if (LOG.isDebugEnabled()){
					LOG.debug("namingEntry is in 1050, returning true");
				}
				return true;
			} else {
				WTPart previous = (WTPart) ObjectRevisionHelper.getPreviousVersionLatestIteration(namingEntry);
				return isNamingEntryValid(previous);
			}
		}
	}

	private WTPart getLatestNamingEntry(String number) throws QueryException, WTException{
		QuerySpec qs = new QuerySpec(WTPart.class);
		int partIndex = 0;
		TypeIdentifier typeIdentifier = TypeIdentifierHelper.getTypeIdentifier("WCTYPE|wt.part.WTPart|com.ptc.Administrative|com.ptc.KBNamingEntry");
		qs.appendWhere(TypedUtilityServiceHelper.service.getSearchCondition(typeIdentifier, true), new int[] { partIndex });
		qs.appendAnd();
		qs.appendWhere(new SearchCondition(WTPart.class, WTPart.NUMBER, SearchCondition.EQUAL, number), new int[] {partIndex});
		
		ConfigSpec configSpec = new LatestConfigSpec();
		QueryResult entries = PersistenceServerHelper.manager.query(qs);
		entries = configSpec.process(entries);
		if (entries.hasMoreElements()){
			return (WTPart) entries.nextElement();
		}
		return null;
	}
	
	
}
