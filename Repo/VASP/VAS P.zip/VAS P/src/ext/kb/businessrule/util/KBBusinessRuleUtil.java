package ext.kb.businessrule.util;

import static ext.kb.util.KBConstants.PBO_RELEASE_RULE_SET;
import static ext.kb.util.KBConstants.PRE_RELEASE_RULESET;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.Predicate;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import wt.businessRules.BusinessRulesHelper;
import wt.change2.ChangeActivity2;
import wt.change2.ChangeRecord2;
import wt.change2.WTChangeActivity2;
import wt.change2.WTChangeOrder2;
import wt.enterprise.RevisionControlled;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.lifecycle.State;
import wt.lifecycle.Transition;
import wt.part.WTPart;
import wt.util.LocalizableMessageCollection;
import wt.util.WTException;
import wt.util.WTMessage;

import com.ptc.core.businessRules.engine.BusinessRuleSetBean;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.core.businessRules.feedback.RuleFeedbackType;
import com.ptc.core.businessRules.validation.RuleValidationResult;
import com.ptc.core.businessRules.validation.RuleValidationResultSet;
import com.ptc.core.businessRules.validation.RuleValidationStatus;
import com.ptc.core.meta.common.TypeIdentifierHelper;
import com.ptc.core.validation.FeedbackMsg;
import com.ptc.core.validation.ValidationResult;
import com.ptc.generic.iba.AttributeService;
import com.ptc.windchill.enterprise.change2.change2ClientResource;

import ext.kb.change2.helper.ChangeNoticeUtils;
import ext.kb.util.KBConstants;
import ext.kb.util.KBUtils;
import ext.kb.workflow.ChangeTaskUtils;

public class KBBusinessRuleUtil {

	private static final Logger LOG = Logger.getLogger(KBBusinessRuleUtil.class);
	private static final String CHANGE2_CLIENT_RESOURCE = "com.ptc.windchill.enterprise.change2.change2ClientResource";

	private KBBusinessRuleUtil() {
		//private constructor to hide default public one.
	}

	/**
	 * Returns pre-release rule set result 
	 * @param primaryBusinessObject object to apply business rules.
	 * @return RuleValidationResultSet of pre-release rule set
	 */
	public static RuleValidationResultSet getPreReleaseRuleSetResult(Persistable primaryBusinessObject) {
		
		if(LOG.isDebugEnabled()){
			LOG.debug("Building beans for PRE_RELEASE_RULE_SET");
		}
		BusinessRuleSetBean preReleaseBean = BusinessRuleSetBean.newBusinessRuleSetBean(PRE_RELEASE_RULESET, "wt.change2.ChangeRecord2");
		BusinessRuleSetBean preReleaseBeanChange = BusinessRuleSetBean.newBusinessRuleSetBean(PBO_RELEASE_RULE_SET,
				BusinessRuleSetBean.PRIMARY_BUSINESS_OBJECT);
		BusinessRuleSetBean[] beans = new BusinessRuleSetBean[] { preReleaseBean, preReleaseBeanChange };

		if(LOG.isDebugEnabled()){
			LOG.debug("Executing business rules on PBO");
		}
		return BusinessRulesHelper.engine.execute(primaryBusinessObject, beans);
	}
	
	/**
	 * Returns KBSCT_RULESET rule set result
	 * @param primaryBusinessObject object to apply business rules.
	 * @return RuleValidationResultSet of KBSCT_RULESET
	 */
	public static RuleValidationResultSet getKBSCTRuleSetResult(Persistable primaryBusinessObject) {

		if(LOG.isDebugEnabled()){
			LOG.debug("Building beans for KBSCT_RULESET");
		}
		BusinessRuleSetBean preReleaseBean = BusinessRuleSetBean.newBusinessRuleSetBean("KB_STATE_CHANGE_RULESET", "wt.change2.ChangeRecord2");
		BusinessRuleSetBean[] beans = new BusinessRuleSetBean[] { preReleaseBean };

		if(LOG.isDebugEnabled()){
			LOG.debug("Executing business rules on PBO");
		}
		return BusinessRulesHelper.engine.execute(primaryBusinessObject, beans);
	}

	/**
	 * Returns KBMINOR_RULESET rule set result
	 * @param primaryBusinessObject object to apply business rules.
	 * @return RuleValidationResultSet of KBMINOR_RULESET
	 */
	public static RuleValidationResultSet getKBMinorRuleSetResult(Persistable primaryBusinessObject) {

		if(LOG.isDebugEnabled()){
			LOG.debug("Building beans for KBMinor_RULESET");
		}
		BusinessRuleSetBean preReleaseBean = BusinessRuleSetBean.newBusinessRuleSetBean("KB_MINOR_CHANGE_RULESET", "wt.change2.ChangeRecord2");
		BusinessRuleSetBean[] beans = new BusinessRuleSetBean[] { preReleaseBean };

		if(LOG.isDebugEnabled()){
			LOG.debug("Executing business rules on PBO");
		}
		return BusinessRulesHelper.engine.execute(primaryBusinessObject, beans);
	}



	/**
	 * Builds pre-release conflict message
	 * @param resultSet - rule result set to get failure message from
	 * @return message of error/warning
	 */
	public static String getPreReleaseConflictsMsg(RuleValidationResultSet resultSet) {
		
		if(LOG.isDebugEnabled()){
			LOG.debug("Building PreReleaseConflictsMsg for ruleSet");
		}
		
		StringBuilder builder = new StringBuilder();
		WTMessage msg = new WTMessage(CHANGE2_CLIENT_RESOURCE, change2ClientResource.BUSINESS_RULES_PRERELEASE_VALIDATION_MSG, null);
		builder.append(msg.getLocalizedMessage());
		builder.append("\n");
		builder.append(resultSet.getFailedRulesMessage(java.util.Locale.getDefault()));
		String conflictMsg = builder.toString();
		if(LOG.isDebugEnabled()){
			LOG.debug("PreReleaseConflictsMsg has been build correctly");
			LOG.debug(conflictMsg);
		}
		return conflictMsg;
	}
	
	/**
	 * Checks if the ruleValidationresultSet contains any errors
	 * 
	 * @param resultSet
	 * @return true, if there are errors present
	 */
	public static boolean hasValidationErrors(final RuleValidationResultSet resultSet) {
		final String M_NAME = "hasValidationErrors";
		boolean result = false;
		try {
			if (LOG.isDebugEnabled()) {

				Object[][] params = { { "resultSet", resultSet } };
				LOG.debug(String.format("Entering %s.%s", KBBusinessRuleUtil.class.getName(), M_NAME));
				LOG.debug("Input parameters:" + params);
			}
			result = hasFeedbackType(resultSet, KBConstants.ERROR_FEEDBACK_MSG_PREFIX);

		} finally {
			if (LOG.isDebugEnabled()) {

				LOG.debug(String.format("Exiting %s.%s", KBBusinessRuleUtil.class.getName(), M_NAME));
				LOG.debug("Result :" + result);
			}
		}
		return result;
	}
	
	/**
	 * Checks if the ruleValidationresultSet contains any warnings
	 * 
	 * @param resultSet
	 * @return true, if there are warnings present
	 */
	public static boolean hasValidationWarnings(final RuleValidationResultSet resultSet) {
		final String M_NAME = "hasValidationWarnings";
		boolean result = false;
		try {
			if (LOG.isDebugEnabled()) {

				Object[][] params = { { "resultSet", resultSet } };
				LOG.debug(String.format("Entering %s.%s", KBBusinessRuleUtil.class.getName(), M_NAME));
				LOG.debug("Input parameters:" + params);
			}
			result = hasFeedbackType(resultSet, KBConstants.WARNING_FEEDBACK_MSG_PREFIX);

		} finally {
			if (LOG.isDebugEnabled()) {

				LOG.debug(String.format("Exiting %s.%s", KBBusinessRuleUtil.class.getName(), M_NAME));
				LOG.debug("Result :" + result);
			}
		}
		return result;
	}
	
	
	/**
	 * Checks if the ruleValidationresultSet contains specified feedbackType
	 * 
	 * @param resultSet
	 * @param feebackTypePrefix
	 * @return true, if there is specified feebackTypePrefix
	 */
	private static boolean hasFeedbackType(final RuleValidationResultSet resultSet, final String feebackTypePrefix) {
		if (resultSet == null) {
			return false;
		}
		if (!resultSet.hasResultsByStatus(RuleValidationStatus.FAILURE)) {
			return false;
		}

		List<ValidationResult> localValidationResults = new ArrayList<ValidationResult>(resultSet.getAllResults());
		ValidationResult valResContainingMsgWithFeedbackType = (ValidationResult) CollectionUtils
				.find(localValidationResults, new Predicate() {

					@Override
					public boolean evaluate(Object arg0) {
						ValidationResult item = (ValidationResult) arg0;
						List<FeedbackMsg> messages = new ArrayList<FeedbackMsg>(item.getFeedbackMessages());
						FeedbackMsg msgWithFeedbackType = (FeedbackMsg) CollectionUtils.find(messages, new Predicate() {

							@Override
							public boolean evaluate(Object paramObject) {
								RuleFeedbackMessage msg = (RuleFeedbackMessage) paramObject;
								String localizedMsg = msg.getLocalizedMessageWithType(Locale.ENGLISH);
								if (StringUtils.startsWithIgnoreCase(localizedMsg, feebackTypePrefix)) {
									return true;
								}
								return false;
							}

						});
						return (msgWithFeedbackType != null);
					}
				});

		return (valResContainingMsgWithFeedbackType != null);
	}
	
	
	public static QueryResult getChangeContext(ChangeActivity2 ectOfTargetBOM) throws WTException{
		Boolean immediateReleaseOfECTOfTargetBOM = AttributeService.getAttribute(ectOfTargetBOM, KBConstants.KB_IMMEDIATE_RELEASE_IBA);
		QueryResult result = new QueryResult();
		if (LOG.isDebugEnabled()){
			LOG.debug("immediateReleaseOfECTOfTargetBOM is " + immediateReleaseOfECTOfTargetBOM);
		}
		if (immediateReleaseOfECTOfTargetBOM){
//			If the CT to be validated has attribute "immediate release = yes", then the Change Context is only built of the CT itself.
			if (LOG.isDebugEnabled()){
				LOG.debug("Context is only the given ECT.");
			}
			result.getObjectVectorIfc().addElement(ectOfTargetBOM);
		} else {
//			Otherwise if the CT to be validated has attribute "immediate release = no", then all CTs on the same ECN having "immediate release = no" build the change context.
			if (LOG.isDebugEnabled()){
				LOG.debug("Collecting all ECTs on the ECN with immediate release=no");
			}
			WTChangeOrder2 ecn = ChangeNoticeUtils.getECN((WTChangeActivity2) ectOfTargetBOM);
			QueryResult ects = ChangeTaskUtils.getLatestChangeActivity(ecn, false);
			while(ects.hasMoreElements()){
				WTChangeActivity2 ect = (WTChangeActivity2) ects.nextElement();
				if (LOG.isDebugEnabled()){
					LOG.debug("ECT added to context: " + ect.getNumber());
				}
				result.getObjectVectorIfc().addElement(ect);
			}
		}
		return result;
	}

	public static boolean isStateValid(String state, Set<State> validStates, Set<State> invalidStates) {
		boolean isValid = validStates.contains(State.toState(state)) && !invalidStates.contains(State.toState(state));
		if (LOG.isDebugEnabled()){
			LOG.debug("state is: " + state.toString() + " is valid: " + isValid);
		}
		return isValid;
	}
	
	
	public static boolean checkTargetTransitionOnECTsWithGivenType(QueryResult changeRecords, String type, Transition transition){
		if (LOG.isDebugEnabled()){
			LOG.debug("changeRecords size=" + (changeRecords != null ? changeRecords.size() : "null"));
			LOG.debug("type=" + type);
			LOG.debug("transition=" + transition.getAbbreviatedDisplay());
		}
		while (changeRecords.hasMoreElements()){
			ChangeRecord2 cr = (ChangeRecord2) changeRecords.nextElement();
			if (LOG.isDebugEnabled()){
				LOG.debug("ECT state: " + cr.getChangeActivity2().getLifeCycleState().getAbbreviatedDisplay());
			}
			if (!KBConstants.STATE_CANCELED.equals(cr.getChangeActivity2().getLifeCycleState())){
				if (LOG.isDebugEnabled()){
					LOG.debug("ECT type is " + TypeIdentifierHelper.getType(cr.getChangeActivity2()));
					LOG.debug("resulting object is " + KBUtils.getIdentityWithStateAndRevision((RevisionControlled) cr.getRoleBObject()) + " with target transition=" + cr.getTargetTransition());
					LOG.debug("resulting object type is " + TypeIdentifierHelper.getType(cr.getRoleBObject()));
				}
				if (TypeIdentifierHelper.getType(cr.getChangeActivity2()).equals(TypeIdentifierHelper.getTypeIdentifier(type)) ){
					Transition targetTransition = cr.getTargetTransition(); 
					if (cr.getRoleBObject() instanceof WTPart && (targetTransition == null || !targetTransition.equals(transition))){
						if (LOG.isDebugEnabled()){
							LOG.debug("WTPart targettransition is NOT Valid, returning false");
						}
						return false;
					}
				} else {
					if (LOG.isDebugEnabled()){
						LOG.debug("ECT type is NOT Valid, returning false");
					}
					return false;
				}
			}
		}
		if (LOG.isDebugEnabled()){
			LOG.debug("All resulting WTParts are on ECT with type=" + type + " with targetTransition " + transition.getAbbreviatedDisplay());
		}
		return true;
	}
	
	
	public static void setCustomFailureResult(String resource, RuleValidationResult result, String key, String lcm, Set<State> states) {
		if (LOG.isDebugEnabled()) {
			LOG.debug("entering setCustomFailureResult(RuleValidationResult,String,String,Set<State>)");
			LOG.debug("result: " + result);
			LOG.debug("key: \"" + key + "\"");
			LOG.debug("lcm: \"" + lcm + "\"");
			LOG.debug("states: " + states);
		}
		result.setStatus(RuleValidationStatus.FAILURE);
		RuleFeedbackMessage feedback = new RuleFeedbackMessage(
				new WTMessage(resource, key, new Object[] { lcm, new LocalizableMessageCollection(states) }),
				RuleFeedbackType.ERROR);
		result.addFeedbackMessage(feedback);
		if (LOG.isDebugEnabled()) {
			LOG.debug("exiting setCustomFailureResult()");
		}
	}
	
	/**
	 * Returns variant release rule set result 
	 * @param primaryBusinessObject object to apply business rules.
	 * @return RuleValidationResultSet of variant release rule set
	 */
	public static RuleValidationResultSet getVariantReleaseRuleSetResult(Persistable primaryBusinessObject) {

		if (LOG.isDebugEnabled()) {
			LOG.debug("Building beans for VARIANT_RELEASE_RULE_SET");
		}
		BusinessRuleSetBean[] ruleSetBeans = new BusinessRuleSetBean[] { BusinessRuleSetBean
				.newBusinessRuleSetBean("KB_VARIANT_RELEASE_RULESET", BusinessRuleSetBean.PRIMARY_BUSINESS_OBJECT) };

		if (LOG.isDebugEnabled()) {
			LOG.debug("Executing business rules on PBO");
		}
		return BusinessRulesHelper.engine.execute(primaryBusinessObject, ruleSetBeans);
	}
	
	
}
