package ext.kb.businessrule.validation;

import java.util.List;
import java.util.Map;
import java.util.Set;

import wt.enterprise.RevisionControlled;
import wt.fc.Persistable;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.vc.Mastered;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;

import ext.kb.resources.ListenerRB;
import ext.kb.util.IBAHelper;
import ext.kb.util.KBUtils;

public class KBMasterSystemValidation extends KBValidation {

    private static final String IBA = "KB_MASTERSYSTEM";
    
    private static final String WT_MASTER = "WCT";
    
    @Override
    public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
            List<RuleFeedbackMessage> paramList) throws WTException {
            boolean result = true;
            if (paramPersistable instanceof Mastered) {
                result = checkMaster(paramPersistable, paramList);
            } else if (paramPersistable instanceof RevisionControlled) {
                RevisionControlled rev = (RevisionControlled) paramPersistable;
                if (rev.getMaster() != null) {
                    result = checkMaster(rev.getMaster(), paramList);
                } else if (rev.getMasterReference() != null && rev.getMasterReference().getObject() instanceof Mastered) {
                    result = checkMaster((Mastered)rev.getMasterReference().getObject(), paramList);
                }
            }
        return result;
    }
    
    private boolean checkMaster (Object masterObject, List<RuleFeedbackMessage> paramList) {
        String masterSys = IBAHelper.readIBA(masterObject, IBA);
        if (!KBUtils.isEmpty(masterSys) && !WT_MASTER.equals(masterSys)) {
            paramList.add(new RuleFeedbackMessage(new WTMessage(
                    RESOURCE, ListenerRB.WRONG_MASTER_SYSTEM, null),
                    getFeedbackType()));
            return false;
        }
        return true;
    }
}
