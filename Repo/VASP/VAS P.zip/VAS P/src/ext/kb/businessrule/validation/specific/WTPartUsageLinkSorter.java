package ext.kb.businessrule.validation.specific;

import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.ObjectUtils;
import org.apache.log4j.Logger;

import wt.fc.BinaryLink;
import wt.fc.QueryResult;
import wt.iba.value.IBAHolder;
import wt.log4j.LogR;
import wt.part.SyncedWithCADStatus;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.part.WTPartUsageLink;
import wt.util.WTException;
import wt.vc.VersionControlHelper;
import ext.kb.util.IBAHelper;
import ext.kb.util.KBConstants;

public class WTPartUsageLinkSorter {

	protected static final Logger LOG = LogR.getLogger(WTPartUsageLinkSorter.class.getName());
	private List<BinaryLink> usageLinks;
	private Comparator<BinaryLink> numberComparator = null;
	private Comparator<BinaryLink> geklaComparator = null;
	private Comparator<BinaryLink> buildStatusComparator = null;
	private Map<WTPartMaster,WTPart> wtpartByMaster = null;
	
	public WTPartUsageLinkSorter(List<BinaryLink> links){
			usageLinks = links;
			initializeComparators();
			wtpartByMaster = new HashMap<WTPartMaster, WTPart>();
	}
	
	private void initializeComparators(){
		prepareNumberComparator();
		prepareGeklaComparator();
		prepareBuildStatusComparator();
	}

	private void prepareBuildStatusComparator() {
		buildStatusComparator = new Comparator<BinaryLink>() {
			@Override
			public int compare(BinaryLink o1, BinaryLink o2) {
				WTPartUsageLink link1 = (WTPartUsageLink)o1;
				WTPartUsageLink link2 = (WTPartUsageLink)o2;
				SyncedWithCADStatus buildStatus1 =  (SyncedWithCADStatus) ObjectUtils.defaultIfNull(link1.getCadSynchronized(),SyncedWithCADStatus.DEFAULT_VALUE);
				SyncedWithCADStatus buildStatus2 =  (SyncedWithCADStatus) ObjectUtils.defaultIfNull(link2.getCadSynchronized(),SyncedWithCADStatus.DEFAULT_VALUE);
				String display1 = buildStatus1.getDisplay();
				String display2 = buildStatus2.getDisplay();
				return ObjectUtils.compare(display1, display2);
			}
		};
	}

	private void prepareGeklaComparator() {
		geklaComparator = new Comparator<BinaryLink>() {
			@Override
			public int compare(BinaryLink usageLink1, BinaryLink usageLink2) {
				WTPart part1 = getPartLatestIteration((WTPartUsageLink)usageLink1);
				WTPart part2 = getPartLatestIteration((WTPartUsageLink)usageLink2);
				String gekla1 = getGekla(part1);
				String gekla2 = getGekla(part2);
				return ObjectUtils.compare(gekla1, gekla2);
			}
		};
	}

	private String getGekla(WTPart part){
		String gekla = null;
		try {
			if(part != null){
				gekla = IBAHelper.getStringIBAValue((IBAHolder) part,
						KBConstants.GEKLA_IBA);
			}
		} catch (WTException e) {
			LOG.warn("Reading Gekla has failed");
		}
		return gekla;
	}
	
	private void prepareNumberComparator() {
		numberComparator = new Comparator<BinaryLink>() {
			@Override
			public int compare(BinaryLink usageLink1, BinaryLink usageLink2) {
				String number1;
				String number2;
				WTPart part1 = getPartLatestIteration((WTPartUsageLink)usageLink1);
				WTPart part2 = getPartLatestIteration((WTPartUsageLink)usageLink2);
				if (part1 == null) {
					WTPartUsageLink ul1 = (WTPartUsageLink)usageLink1;
					WTPartMaster master = ul1.getUses();
					number1 = master.getNumber();
				} else number1 = part1.getNumber();
				
				if (part2 == null) {
					WTPartUsageLink ul2 = (WTPartUsageLink)usageLink2;
					WTPartMaster master = ul2.getUses();
					number2 = master.getNumber();
				} else number2 = part2.getNumber();
				
				return ObjectUtils.compare(number1, number2);
			}
		};
	}
	
	public void sortByNumberGeklaAndBuildStatus(){
		Collections.sort(usageLinks,numberComparator);
		Collections.sort(usageLinks,geklaComparator);
		Collections.sort(usageLinks,buildStatusComparator);
	}
	
	private WTPart getPartLatestIteration(WTPartUsageLink usageLink){
		WTPartMaster master = usageLink.getUses();
		WTPart partLastIteration = wtpartByMaster.get(master);
		
		if(partLastIteration == null){
			partLastIteration = getPartLastIteration(master, partLastIteration);
			if (partLastIteration != null) {
				wtpartByMaster.put(master, partLastIteration);
			}
		}
		return partLastIteration;
	}

	private WTPart getPartLastIteration(WTPartMaster master,
			WTPart partLastIteration) {
		QueryResult partIterations;
		try {
			partIterations = VersionControlHelper.service.allIterationsOf(master);
			if (partIterations.hasMoreElements()) {
				partLastIteration = (WTPart)partIterations.nextElement();
			}
		} catch (WTException e) {
			LOG.warn("Could not retrieve part's iterations ");
		}
		return partLastIteration;
	}
}
