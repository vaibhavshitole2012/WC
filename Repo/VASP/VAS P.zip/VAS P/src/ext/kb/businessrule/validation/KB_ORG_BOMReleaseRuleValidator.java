package ext.kb.businessrule.validation;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import org.apache.log4j.Logger;

import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.core.businessRules.feedback.RuleFeedbackType;
import com.ptc.core.businessRules.validation.BOMReleaseRuleValidator;
import com.ptc.core.businessRules.validation.RuleValidationCriteria;
import com.ptc.core.businessRules.validation.RuleValidationKey;
import com.ptc.core.businessRules.validation.RuleValidationObject;
import com.ptc.core.businessRules.validation.RuleValidationResult;
import com.ptc.core.businessRules.validation.RuleValidationStatus;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.TypeIdentifierHelper;
import com.ptc.generic.epm.EPMHelper;
import com.ptc.generic.iba.AttributeService;

import ext.kb.businessrule.util.KBBusinessRuleUtil;
import ext.kb.change2.helper.ChangeNoticeUtils;
import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.DBUtils;
import ext.kb.util.KBUtils;
import ext.kb.util.ObjectRevisionHelper;
import ext.kb.workflow.ChangeTaskUtils;
import wt.change2.ChangeRecord2;
import wt.change2.WTChangeActivity2;
import wt.enterprise.RevisionControlled;
import wt.epm.EPMDocument;
import wt.epm.EPMDocumentMaster;
import wt.epm.structure.EPMMemberLink;
import wt.fc.QueryResult;
import wt.fc.collections.WTCollection;
import wt.fc.collections.WTHashSet;
import wt.lifecycle.State;
import wt.log4j.LogR;
import wt.util.WTAttributeNameIfc;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.vc.ControlBranch;
import wt.vc.Iterated;
import wt.vc.VersionControlHelper;

public class KB_ORG_BOMReleaseRuleValidator extends BOMReleaseRuleValidator {

	private static final String TARGET_STATES_MAP = "TARGET_STATES_MAP";
	private static final Logger logger = LogR.getLogger(KB_ORG_BOMReleaseRuleValidator.class.getName());

	private static final String CONTROL_BRANCH_PREDECESSOR_ID_SELECTOR = ControlBranch.PREDECESSOR_REFERENCE + "."
			+ WTAttributeNameIfc.REF_OBJECT_ID;
	private static final String CONTROL_BRANCH_MASTER_ID_SELECTOR = ControlBranch.MASTER_REFERENCE + "."
			+ WTAttributeNameIfc.REF_OBJECT_ID;

	private static final String RESOURCE = "com.ptc.windchill.enterprise.businessRules.businessRulesClientResource";

	@SuppressWarnings("unchecked")
	@Override
	public RuleValidationResult performValidation(RuleValidationKey validationKey,
			RuleValidationObject validationObject, RuleValidationCriteria criteria) throws WTException {
		if (logger.isDebugEnabled()) {
			logger.debug("entering performValidation(RuleValidationKey,RuleValidationObject,RuleValidationCriteria)");
			logger.debug("validationKey: " + validationKey);
			logger.debug("validationObject: " + validationObject);
			logger.debug("criteria: " + criteria);
		}
		// We will use a null status to indicate we need to continue validating the given object, 
		// success that the next child object should be processed, and failure if there is a failure.

		ChangeRecord2 record = (ChangeRecord2) validationObject.getTargetObjectLink().getObject();
		WTChangeActivity2 changeActivity2 = (WTChangeActivity2) record.getRoleAObjectRef().getObject();
		Boolean asStoredConfiguration = false;
		Object ibaValue = AttributeService.getAttribute(changeActivity2, "KB_USE_ASSTORED_CONFIGURATION");

		if (logger.isDebugEnabled()) {
			logger.debug("KB_USE_AS-STORED_CONFIGURATION: " + ibaValue);
		}

		if (ibaValue != null) {
			asStoredConfiguration = (Boolean) ibaValue;
		}
		
		String objectTypeString = (String) validationKey.getRuleConfig().get("objectType");
		TypeIdentifier objTypeId = TypeIdentifierHelper.getType(validationObject.getTargetObject().getObject());
		TypeIdentifier allowedType = TypeIdentifierHelper.getTypeIdentifier(objectTypeString);
		
		boolean objTypeIsDescended = objTypeId.isDescendedFrom(allowedType);
		
		RuleValidationResult result = new RuleValidationResult(null);
		result.setValidationKey(validationKey);
		result.setTargetObject(validationObject.getTargetObject());
		
		if (asStoredConfiguration || !objTypeIsDescended) {
			if (logger.isDebugEnabled()) {
				logger.debug("asStoredConfiguration: " + asStoredConfiguration);
				logger.debug("objectTypeString: " + objectTypeString);
				logger.debug("objTypeId: " + objTypeId);
				logger.debug("allowedType: " + allowedType);
				logger.debug("objTypeId.isDescendedFrom(allowedType): " + objTypeIsDescended);
				logger.debug("returning SUCCESS without further validation");
			}
			result.setStatus(RuleValidationStatus.SUCCESS);
			return result;
		}

		EPMDocument targetEPMDocument = (EPMDocument) validationObject.getTargetObject().getObject();

		Set<State> validPredecessorStates = new HashSet<State>();
		validPredecessorStates.addAll((Set<State>) validationKey.getProcessingMapValue(VALID_DEPENDENT_STATE));
		validPredecessorStates.remove(State.toState("1020"));
		validPredecessorStates.remove(State.toState("1015"));
		Set<State> invalidPredecessorStates = new HashSet<State>();
		invalidPredecessorStates.addAll((Set<State>) validationKey.getProcessingMapValue(INVALID_DEPENDENT_STATE));
		invalidPredecessorStates.add(State.toState("1020"));
		invalidPredecessorStates.add(State.toState("1015"));
		
		Set<State> validDependentStates = (Set<State>) validationKey.getProcessingMapValue(VALID_DEPENDENT_STATE);
		Set<State> invalidDependentStates = (Set<State>) validationKey.getProcessingMapValue(INVALID_DEPENDENT_STATE);
		
		if (logger.isDebugEnabled()) {
			logger.debug("validDependentStates: " + validDependentStates);
			logger.debug("invalidDependentStates: " + invalidDependentStates);
		}
		// First level children. Which ones to retrieve is controlled by preferences underneath "BOM Maturity Release Collector"
		Set<RuleValidationObject> children = validationObject.getChildObjects();
		
		QueryResult changeContext = ChangeTaskUtils.getActivitiesFromChangeContext(changeActivity2);
		WTHashSet resultingObjectsInContext = ChangeTaskUtils.getResultingObjects(changeContext);
		
		ArrayList<EPMMemberLink> memberLinksList = (ArrayList<EPMMemberLink>) DBUtils.retrieveLinks(EPMMemberLink.class, targetEPMDocument, EPMMemberLink.ROLE_BOBJECT_ROLE);
		
		if (logger.isDebugEnabled()){
			logger.debug("memberLinksList size=" + memberLinksList.size());
		}
		
		for (Iterator<RuleValidationObject> it = children.iterator(); it.hasNext();) {
	        Object child = it.next().getTargetObject().getObject();
	        if (!(child instanceof EPMDocument)) {
	        	continue;
	        }
			EPMDocument document = (EPMDocument) child;
			EPMDocumentMaster master = (EPMDocumentMaster) document.getMaster();
			EPMDocument componentLatestIteration = (EPMDocument) KBUtils.getLatestIteration(master);
			ChangeRecord2 cr = ChangeNoticeUtils.getChangeRecord(componentLatestIteration);

			RuleFeedbackMessage error = null;
			String objectnumber = componentLatestIteration.getNumber();

			// a) if BOM Component master is a result object in the same Change
			// Context --> validate�its release target ������
			if (cr != null && resultingObjectsInContext.contains(componentLatestIteration)) {
				if (logger.isDebugEnabled()) {
					logger.debug("Component's latest iteration(" + objectnumber
							+ ") is IN the Change Context, validating target transition");
				}
				String targetTransition = "";
				if (cr.getTargetTransition() != null) {
					targetTransition = cr.getTargetTransition().toString();
				}
				if (targetTransition.isEmpty() || !KBBusinessRuleUtil.isStateValid(targetTransition,
						validDependentStates, invalidDependentStates)) {
					error = new RuleFeedbackMessage(new WTMessage("ext.kb.resources.BusinessRuleRB",
							BusinessRuleRB.KB_CHILD_INVALID_TARGET_STATE,
							new Object[] { objectnumber, targetTransition }), RuleFeedbackType.ERROR);
					if (logger.isDebugEnabled()) {
						logger.debug("component invalid");
					}
				}
			} else {
				if (logger.isDebugEnabled()) {
					logger.debug("Component's latest iteration(" + objectnumber
							+ ") is NOT in the Change Context, has state: "
							+ componentLatestIteration.getState().toString());
				}
				if (componentLatestIteration.getState().toString().compareTo("1035") > 0) {
					// b) else if BOM Component is in state > 1035 -->
					// validate�its state
					if (!KBBusinessRuleUtil.isStateValid(componentLatestIteration.getState().toString(),
							validDependentStates, invalidDependentStates)) {
						error = new RuleFeedbackMessage(
								new WTMessage("ext.kb.resources.BusinessRuleRB", BusinessRuleRB.KB_CHILD_INVALID_STATE,
										new Object[] { objectnumber, componentLatestIteration.getState().toString() }),
								RuleFeedbackType.ERROR);
					}
				} else if (componentLatestIteration.getState().toString().compareTo("1035") <= 0) {
					if (componentLatestIteration.getState().toString().compareTo("1020") != 0) {
						RevisionControlled predecessor = (RevisionControlled) ObjectRevisionHelper.getPreviousVersionLatestIteration(componentLatestIteration);
						boolean hasPredecessor = predecessor != null;
						if (hasPredecessor) {
							if (logger.isDebugEnabled()) {
								logger.debug("component has predecessor");
							}
							if (!KBBusinessRuleUtil.isStateValid(predecessor.getState().toString(),
									validPredecessorStates, invalidPredecessorStates)) {
								error = new RuleFeedbackMessage(new WTMessage("ext.kb.resources.BusinessRuleRB",
										BusinessRuleRB.KB_REVISIONS_INVALID_STATE,
										new Object[] { objectnumber, predecessor.getState().toString(),
												predecessor.getVersionDisplayIdentifier(),
												predecessor.getState().toString() }),
										RuleFeedbackType.ERROR);
								if (logger.isDebugEnabled()) {
									logger.debug("component invalid");
								}
							}
						} else {
							if (logger.isDebugEnabled()) {
								logger.debug("has no predecessor");
							}
							if (!KBBusinessRuleUtil.isStateValid(componentLatestIteration.getState().toString(),
									validDependentStates, invalidDependentStates)) {
								error = new RuleFeedbackMessage(
										new WTMessage("ext.kb.resources.BusinessRuleRB",
												BusinessRuleRB.KB_CHILD_INVALID_STATE,
												new Object[] { objectnumber,
														componentLatestIteration.getState().toString() }),
										RuleFeedbackType.ERROR);
							}
						}
					}
				}
			}
			if (error != null) {
				if (logger.isDebugEnabled()) {
					logger.debug("Adding error to result object");
				}
				result.setStatus(RuleValidationStatus.FAILURE);
				result.setTargetObject(validationObject.getTargetObject());
				result.setValidationKey(validationKey);
				result.addFeedbackMessage(error);
			}
		}
		

//		if (!children.isEmpty()) {
			
			// Filter children for EPMDocument objects and put them into epmChildren
			
//			for (RuleValidationObject child : children) {
//				if (child.getTargetObject().getObject() instanceof EPMDocument) {
//					EPMDocument epmDoc = (EPMDocument) child.getTargetObject().getObject();
//					epmChildren.add(epmDoc);
//					if (logger.isDebugEnabled()) {
//						logger.debug("Child CAD document: " + epmDoc.getName() + " - " + epmDoc.getNumber() + " - "
//								+ epmDoc.getVersionIdentifier().getValue() + "."
//								+ epmDoc.getIterationIdentifier().getValue() + " - state: "
//								+ epmDoc.getLifeCycleState());
//					}
//				}
//			}

			// The preferences Include related Family table objects = All and Include related Generics = All
			// do not add the variants or generic if the validationObject is a generic or variant. Fix this.
			WTCollection familyTableObjects = EPMHelper.addFamilyTableObjects(targetEPMDocument);

//			Map<Object, State> objStateMap = (Map<Object, State>) validationKey.getProcessingMapValue(TARGET_STATES_MAP);
//			if (logger.isDebugEnabled()) {
//				logger.debug("objStateMap:" + objStateMap);
//			}

//			WTCollection objectsToCheckPreviousRevisions = new WTArrayList();
			Iterator<EPMDocument> famTabObjsIterator = familyTableObjects.persistableIterator(EPMDocument.class, true);
			
			if (logger.isDebugEnabled()){
				logger.debug("familyTableObjects size=" + familyTableObjects.size() + " result status:" + result.getStatus());
			}
			
			while (famTabObjsIterator.hasNext() && !RuleValidationStatus.FAILURE.equals(result.getStatus())) {
				result.setStatus(null);
				EPMDocument familyTableObj = famTabObjsIterator.next();
				
				 ChangeRecord2 cr = ChangeNoticeUtils.getChangeRecord(familyTableObj);
				 RuleFeedbackMessage error = null;
				 String objectnumber = familyTableObj.getNumber();
				 
				 //	a) if this is a result object in the same Change Context --> validate�its release target ������
				 if (cr != null && resultingObjectsInContext.contains(familyTableObj)){
					 String targetTransition = "";
					 if (cr.getTargetTransition() != null){
						 targetTransition = cr.getTargetTransition().toString();
					 }
					 if (logger.isDebugEnabled()){
						 logger.debug("family table object(" + objectnumber + ") is IN the Change Context, validating target transition: " + targetTransition);
					 }
					 if (targetTransition.isEmpty() || !KBBusinessRuleUtil.isStateValid(targetTransition, validDependentStates, invalidDependentStates)){
						 error = new RuleFeedbackMessage(new WTMessage("ext.kb.resources.BusinessRuleRB", BusinessRuleRB.KB_CHILD_INVALID_TARGET_STATE, new Object[] {objectnumber,targetTransition}), RuleFeedbackType.ERROR);
						 if (logger.isDebugEnabled()) {
								logger.debug("invalid family table object");
						 }
					 }	
				 } else {
					 // else validate�its current state
					 if (logger.isDebugEnabled()){
						 logger.debug("family table object(" + objectnumber + ") is NOT in the Change Context, validating current state: " + familyTableObj.getState().toString());
					 }
					 if (!KBBusinessRuleUtil.isStateValid(familyTableObj.getState().toString(), validDependentStates, invalidDependentStates)){
						 error = new RuleFeedbackMessage(new WTMessage("ext.kb.resources.BusinessRuleRB", BusinessRuleRB.KB_CHILD_INVALID_STATE, new Object[] {objectnumber,familyTableObj.getState().toString()}), RuleFeedbackType.ERROR);
						 if (logger.isDebugEnabled()) {
								logger.debug("invalid family table object");
						 }
					 }
				 }
				
				 if (error != null){
					 if (logger.isDebugEnabled()){
						 logger.debug("Adding error to result object");
		    		}
					 result.setStatus(RuleValidationStatus.FAILURE);
					 result.setTargetObject(validationObject.getTargetObject());
					 result.setValidationKey(validationKey);
					 result.addFeedbackMessage(error);
				 }
			}
				
				
				
//				validateDependent(familyTableObj, result, validDependentStates, invalidDependentStates, objStateMap);
//
//				if (result.getStatus() == null) {
//					WTKeyedMap childToLinksMap = validationObject.getChildToLinksMap();
//					Set<BinaryLink> links = (Set<BinaryLink>) childToLinksMap.get(familyTableObj);
//
//					if (links == null) {
//						if (logger.isDebugEnabled()) {
//							logger.debug("BinaryLinks are null, inserting empty collection");
//						}
//
//						childToLinksMap.put(familyTableObj, new HashSet<BinaryLink>());
//					}
//					
//					if (callShouldCheckPreviousRevision(familyTableObj, validationObject, validationKey)) {
//						objectsToCheckPreviousRevisions.add(familyTableObj);
//					} else {
//						KBBusinessRuleUtil.setCustomFailureResult(RESOURCE, result, businessRulesClientResource.CHILD_INVALID_STATE_CUSTOM, KBUtils.getIdentityWithStateAndRevision(familyTableObj), validDependentStates);
//						if (logger.isDebugEnabled()) {
//							logger.debug("The dependent object " + familyTableObj + " is not in a valid state: " + familyTableObj.getLifeCycleState());
//						}
//					}
//				} else {
//					logger.debug("Validation result: " + result);
//				}
//			}

//			if (!objectsToCheckPreviousRevisions.isEmpty() && !RuleValidationStatus.FAILURE.equals(result.getStatus())) {
//				validatePreviousRevisions(result, validPredecessorStates, invalidPredecessorStates, objectsToCheckPreviousRevisions, objStateMap);
//			}
//		}

		if (result.getStatus() == null) {
			result.setStatus(RuleValidationStatus.SUCCESS);
		}

		if (logger.isDebugEnabled()) {
			logger.debug("exiting performValidation()");
			logger.debug("returning: " + result);
		}

		return result;
	}

//	private boolean callShouldCheckPreviousRevision(EPMDocument objToCheck,
//			RuleValidationObject paramRuleValidationObject, RuleValidationKey paramRuleValidationKey) {
//
//
//		if (logger.isDebugEnabled()) {
//			logger.debug("entering callShouldCheckPreviousRevision(LifeCycleManaged,RuleValidationObject,RuleValidationKey)");
//			logger.debug("paramLifeCycleManaged: " + objToCheck);
//			logger.debug("paramRuleValidationObject: " + paramRuleValidationObject);
//			logger.debug("paramRuleValidationKey: " + paramRuleValidationKey);
//		}
//	
//		// Req. 186126. A previous revision shall not be checked for family table objects.
//		// Means: if objToCheck and paramRuleValidationObject are both members of the same family table, then do not check the previous revision.
//		Persistable persistableValidationObject = paramRuleValidationObject.getTargetObject().getObject();
//
//		if (persistableValidationObject instanceof EPMDocument) {
//			if (EPMHelper.isFamily((EPMDocument) persistableValidationObject, objToCheck)) {
//				logger.debug("Both the validation object and the object to check are members of the same family tables. No check of previous revision.");
//				return false;
//			}
//		}
//
//		boolean result = (boolean) invokePrivateMethod("shouldCheckPreviousRevision",
//				new Class[] { LifeCycleManaged.class, RuleValidationObject.class, RuleValidationKey.class },
//				new Object[] { objToCheck, paramRuleValidationObject, paramRuleValidationKey });
//
//		if (logger.isDebugEnabled()) {
//			logger.debug("exiting callShouldCheckPreviousRevision()");
//			logger.debug("returning: " + result);
//		}
//		return result;
//	}

//	private Object invokePrivateMethod(final String methodName, final Class[] paramClasses, final Object[] paramObjects) {
//		if (logger.isDebugEnabled()) {
//			logger.debug("entering invokePrivateMethod(String,Class[],Object[])");
//			logger.debug("methodName: \"" + methodName + "\"");
//			logger.debug("paramClasses: " + paramClasses);
//			logger.debug("paramObjects: " + paramObjects);
//		}
//
//		BOMReleaseRuleValidator r = new BOMReleaseRuleValidator();
//		Method method = null;
//		Object result = null;
//		try {
//			method = r.getClass().getDeclaredMethod(methodName, paramClasses);
//			method.setAccessible(true);
//			result = method.invoke(r, paramObjects);
//		} catch (NoSuchMethodException | SecurityException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
//			logger.error("Unexpected exception ws thrown ", e);
//			throw new WTRuntimeException(e);
//		} finally {
//			if (method != null) {
//				method.setAccessible(false);
//			}
//		}
//
//		if (logger.isDebugEnabled()) {
//			logger.debug("exiting invokePrivateMethod()");
//			logger.debug("returning: " + result);
//		}
//
//		return result;
//	}
//
//	private void validatePreviousRevisions(RuleValidationResult result, Set<State> validDependentStates,
//			Set<State> invalidDependentStates, WTCollection objectsToCheckPreviousRevisions,
//			Map<Object, State> objStateMap) throws WTException, PersistenceException {
//
//		if (logger.isDebugEnabled()) {
//			logger.debug(
//					"entering validatePreviousRevisions(RuleValidationResult,Set<State>,Set<State>,WTCollection,Map<Object,State>)");
//			logger.debug("result: " + result);
//			logger.debug("validDependentStates: " + validDependentStates);
//			logger.debug("invalidDependentStates: " + invalidDependentStates);
//			logger.debug("objectsToCheckPreviousRevisions: " + objectsToCheckPreviousRevisions);
//			logger.debug("objStateMap: " + objStateMap);
//		}
//		WTKeyedMap versionMap = getVersionHistories(objectsToCheckPreviousRevisions);
//
//		for (Object entryObject : versionMap.entrySet()) {
//			result.setStatus(null);
//			@SuppressWarnings("unchecked")
//			Entry<WTReference, WTList> entry = (Entry<WTReference, WTList>) entryObject;
//			WTReference lcm = entry.getKey();
//			WTList versions = entry.getValue();
//			Iterator<?> previousVersions = versions.persistableIterator();
//			ViewReference validView = null;
//			// The collected revision will be first.
//			if (previousVersions.hasNext()) {
//				Object version = previousVersions.next();
//				if (version instanceof ViewManageable) {
//					// If the collected object has the same view as the seed
//					// object then only look at past revisions with that view
//					validView = ((ViewManageable) version).getView();
//					if (logger.isDebugEnabled()) {
//						logger.debug("The child object has view " + validView + " so only previous "
//								+ "versions with that view will be used");
//					}
//				}
//			}
//			while (previousVersions.hasNext() && result.getStatus() == null) {
//				Object previousVersion = previousVersions.next();
//				if (validView == null || validView.equals(((ViewManageable) previousVersion).getView())) {
//					validateDependent((LifeCycleManaged) previousVersion, result, validDependentStates,
//							invalidDependentStates, objStateMap);
//				}
//			}
//			if (result.getStatus() == null) {
//				KBBusinessRuleUtil.setCustomFailureResult(RESOURCE, result, businessRulesClientResource.CHILD_INVALID_STATE_CUSTOM,
//						KBUtils.getIdentityWithStateAndRevision((EPMDocument) lcm.getObject()), validDependentStates);
//				if (logger.isDebugEnabled()) {
//					logger.debug(
//							"The dependent object " + lcm + " and its previous iterations are not in a valid state: ");
//				}
//			}
//			if (RuleValidationStatus.FAILURE.equals(result.getStatus())) {
//				break;
//			}
//
//		}
//		if (logger.isDebugEnabled()) {
//			logger.debug("exiting validatePreviousRevisions()");
//		}
//	}
//
//	private static WTKeyedMap getVersionHistories(final WTCollection iterations) throws WTException {
//		if (logger.isDebugEnabled()) {
//			logger.debug("entering getVersionHistories(WTCollection)");
//			logger.debug("iterations: " + iterations);
//		}
//		final Map<Long, Long> cbPredessorMap = getControlBranchPrecedessors(iterations);
//		if (cbPredessorMap == null || cbPredessorMap.isEmpty()) {
//			if (logger.isDebugEnabled()) {
//				logger.debug("cbPredessorMap == null || cbPredessorMap.isEmpty()");
//				logger.debug("exiting getVersionHistories()");
//				logger.debug("returning: " + new WTKeyedHashMap(0));
//			}
//			return new WTKeyedHashMap(0);
//		}
//
//		WTKeyedMap versionHistoryMap = null;
//		for (final Iterator<?> typeIter = iterations.classIterator(); typeIter.hasNext();) {
//			final Class<?> iterationType = (Class<?>) typeIter.next();
//			if (!Iterated.class.isAssignableFrom(iterationType))
//				continue;
//
//			final WTCollection iterationsOfType = iterations.subCollection(iterationType, false);
//			versionHistoryMap = getVersionHistories(iterationsOfType, cbPredessorMap, versionHistoryMap);
//		}
//
//		if (logger.isDebugEnabled()) {
//			logger.debug("exiting getVersionHistories()");
//			logger.debug("returning: " + versionHistoryMap);
//		}
//		return versionHistoryMap;
//	}
//
//	private static WTKeyedMap getVersionHistories(final WTCollection iterations, final Map<Long, Long> cbPredessorMap,
//			WTKeyedMap versionHistoryMap) throws WTException {
//
//		if (logger.isDebugEnabled()) {
//			logger.debug("entering getVersionHistories(WTCollection,Map<Long,Long>,WTKeyedMap)");
//			logger.debug("iterations: " + iterations);
//			logger.debug("cbPredessorMap: " + cbPredessorMap);
//			logger.debug("versionHistoryMap: " + versionHistoryMap);
//		}
//		try {
//			if (iterations == null || iterations.isEmpty()) {
//				if (logger.isDebugEnabled()) {
//					logger.debug("iterations == null || iterations.isEmpty()");
//					logger.debug("exiting getVersionHistories()");
//					logger.debug("returning: " + versionHistoryMap);
//				}
//				return versionHistoryMap;
//			}
//
//			// Make sure collection only has one type of object.
//			final Iterator<?> classIter = iterations.classIterator();
//			final Class<?> iterationType = (Class<?>) classIter.next();
//			if (classIter.hasNext())
//				throw new IllegalArgumentException(
//						"Internal error - iterations collection may only contain one objects of the same type.");
//
//			if (versionHistoryMap == null)
//				versionHistoryMap = new WTKeyedHashMap(iterations.size());
//
//			// Get the set of predecessor control branch ids for each specified
//			// iteration.
//			final Set<Long> cbIdSet = new HashSet<Long>(2 * iterations.size());
//			for (final Object iteration : iterations.persistableCollection()) {
//				if (versionHistoryMap.containsKey(iteration))
//					continue; // Don't duplicate existing entries.
//
//				// Copy control branch IDs of this iteration and all of its
//				// predecessors.
//				Long cbId = ((Iterated) iteration).getBranchIdentifier();
//				while (cbId != null && cbId > 0) {
//					cbIdSet.add(cbId);
//					cbId = cbPredessorMap.get(cbId);
//				}
//			}
//
//			// Convert control branch ID set to ID array.
//			final long[] cbIds = new long[cbIdSet.size()];
//			int i = 0;
//			for (final Long cbId : cbIdSet) {
//				cbIds[i++] = cbId;
//			}
//
//			// Get all predecessor versions (i.e., latest iterations) of
//			// specified iterations.
//			// SELECT <version> FROM <type> WHERE latestIteration = true AND
//			// controlBranchId IN (cbIds);
//			final QuerySpec qs = new QuerySpec();
//			final int[] idx = { qs.addClassList(iterationType, true) };
//			qs.setDescendantQuery(false);
//			qs.appendWhere(VersionControlHelper.getSearchCondition(iterationType, true), idx);
//			qs.appendAnd();
//			qs.appendWhere(new SearchCondition(iterationType, Iterated.BRANCH_IDENTIFIER, cbIds), idx);
//			final QueryResult qr = PersistenceHelper.manager.find((StatementSpec) qs);
//
//			// Construct map of control branch IDs to their latest iterations.
//			final Map<Long, Iterated> cbIdToVersionMap = new HashMap<Long, Iterated>(qr.size());
//			while (qr.hasMoreElements()) {
//				final Iterated iteration = (Iterated) ((Object[]) qr.nextElement())[0];
//				cbIdToVersionMap.put(iteration.getBranchIdentifier(), iteration);
//			}
//
//			// Add version histories to output map.
//			for (final Object iteration : iterations.persistableCollection()) {
//				if (versionHistoryMap.containsKey(iteration))
//					continue; // Don't duplicate existing entries.
//				final WTList versionHistoryList = new WTArrayList(4);
//				versionHistoryMap.put(iteration, versionHistoryList);
//
//				// Copy predecessor versions to list according to control branch
//				// predecessor order.
//				Long cbId = ((Iterated) iteration).getBranchIdentifier();
//				while (cbId != null && cbId > 0) {
//					final Iterated version = cbIdToVersionMap.get(cbId);
//					if (version != null)
//						versionHistoryList.add(version);
//					cbId = cbPredessorMap.get(cbId);
//				}
//			}
//
//			if (logger.isDebugEnabled()) {
//				logger.debug("exiting getVersionHistories()");
//				logger.debug("returning: " + versionHistoryMap);
//			}
//			return versionHistoryMap;
//		} catch (WTPropertyVetoException e) {
//			throw new WTException(e);
//		}
//	}
//
//	private static Map<Long, Long> getControlBranchPrecedessors(final WTCollection objs) throws WTException {
//		if (logger.isDebugEnabled()) {
//			logger.debug("entering getControlBranchPrecedessors(WTCollection)");
//			logger.debug("objs: " + objs);
//		}
//		if (objs == null || objs.isEmpty()) {
//			if (logger.isDebugEnabled()) {
//				logger.debug("objs == null || objs.isEmpty()");
//				logger.debug("exiting getControlBranchPrecedessors()");
//				logger.debug("returning: " + new HashMap<Long, Long>(0));
//			}
//			return new HashMap<Long, Long>(0);
//		}
//
//		// Gather all master references.
//		final WTSet masters = new WTHashSet(objs.size());
//		masters.addAll(objs.subCollection(Mastered.class));
//		for (final Object iteration : objs.subCollection(Iterated.class).persistableCollection()) {
//			masters.add(((Iterated) iteration).getMasterReference());
//		}
//
//		// Query for the ids and predecessor ids of the deflated control
//		// branches.
//		// SELECT id, predecessor_id FROM ControlBranch WHERE master.id IN
//		// <masters.id>
//		final QuerySpec qs = new QuerySpec();
//		final int[] idx = { qs.addClassList(ControlBranch.class, false) };
//		qs.appendSelectAttribute(WTAttributeNameIfc.ID_NAME, idx[0], false);
//		qs.appendSelectAttribute(CONTROL_BRANCH_PREDECESSOR_ID_SELECTOR, idx[0], false);
//		qs.appendWhere(new SearchCondition(ControlBranch.class, CONTROL_BRANCH_MASTER_ID_SELECTOR, masters.toIdArray()),
//				idx);
//		final QueryResult qr = PersistenceHelper.manager.find((StatementSpec) qs);
//
//		// Create control branch id to predecessor id map from query results.
//		final Map<Long, Long> cbPredessorMap = new HashMap<Long, Long>(qr.size());
//		while (qr.hasMoreElements()) {
//			final Object[] row = (Object[]) qr.nextElement();
//			if (row[0] != null) {
//				final long cbId = ((Number) row[0]).longValue();
//				final long predecessorId = (row[1] == null) ? 0 : ((Number) row[1]).longValue();
//				cbPredessorMap.put(cbId, predecessorId);
//			}
//		}
//
//		if (logger.isDebugEnabled()) {
//			logger.debug("exiting getControlBranchPrecedessors()");
//			logger.debug("returning: " + cbPredessorMap);
//		}
//		return cbPredessorMap;
//	}
//
//	/**
//	 * result's status will be set to failure if the object is in an invalid
//	 * state, success if the object is in a valid state, and null if it is in
//	 * neither an invalid or valid state
//	 */
//	void validateDependent(LifeCycleManaged lcm, RuleValidationResult result, Set<State> validDependentStates,
//			Set<State> invalidDependentStates, Map<Object, State> objStateMap) {
//		if (logger.isDebugEnabled()) {
//			logger.debug(
//					"entering validateDependent(LifeCycleManaged,RuleValidationResult,Set<State>,Set<State>,Map<Object,State>)");
//			logger.debug("lcm: " + lcm);
//			logger.debug("result: " + result);
//			logger.debug("validDependentStates: " + validDependentStates);
//			logger.debug("invalidDependentStates: " + invalidDependentStates);
//			logger.debug("objStateMap: " + objStateMap);
//		}
//		State childTargetState = objStateMap.containsKey(lcm) ? objStateMap.get(lcm) : lcm.getLifeCycleState();
//		if (invalidDependentStates != null && invalidDependentStates.contains(childTargetState)) {
//			KBBusinessRuleUtil.setCustomFailureResult(RESOURCE, result, businessRulesClientResource.CHILD_INVALID_STATE_CUSTOM,
//					KBUtils.getIdentityWithStateAndRevision((RevisionControlled) lcm), validDependentStates);
//			if (logger.isDebugEnabled()) {
//				logger.debug("The dependent object " + lcm + " is in an invalid state: " + childTargetState);
//			}
//		} else if (validDependentStates != null && validDependentStates.contains(childTargetState)) {
//			result.setStatus(RuleValidationStatus.SUCCESS);
//			if (logger.isDebugEnabled()) {
//				logger.debug("The dependent object " + lcm + " is in a valid state: " + childTargetState);
//			}
//		}
//		if (logger.isDebugEnabled()) {
//			logger.debug("exiting validateDependent()");
//		}
//
//	}
	
	@Override
	public void prepareForValidation(RuleValidationKey paramRuleValidationKey, RuleValidationCriteria paramRuleValidationCriteria) throws WTException {
		super.prepareForValidation(paramRuleValidationKey, paramRuleValidationCriteria);
		
	}

}
