package ext.kb.businessrule.validation;

import com.ptc.core.businessRules.feedback.RuleFeedbackType;

public class KBWTPartWhereUsedStatePreReleaseValidator extends KBWTPartWhereUsedStateValidator{
	
	public KBWTPartWhereUsedStatePreReleaseValidator() {  
        setFeedbackType(RuleFeedbackType.WARNING);
    }   
 
}
