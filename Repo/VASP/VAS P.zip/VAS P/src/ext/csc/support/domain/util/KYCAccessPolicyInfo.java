package ext.csc.support.domain.util;

import com.ptc.core.meta.type.mgmt.server.impl.WTTypeDefinition;
import java.util.Vector;
import wt.access.AccessPermission;
import wt.access.AccessPermissionSet;
import wt.access.AccessPermissionType;
import wt.access.AccessPolicyRule;
import wt.access.AccessSelector;
import wt.access.WTAclEntry;
import wt.fc.ReferenceFactory;
import wt.fc.WTObject;
import wt.fc.WTReference;
import wt.org.WTPrincipalReference;
import wt.org.WTRolePrincipal;
import wt.project.Role;
import wt.util.WTException;

public class KYCAccessPolicyInfo extends WTObject
{
  public AccessPolicyRule aPolicyRule = null;
  public Vector aAclEntryVector = null;
  boolean DEBUG = true;

  public KYCAccessPolicyInfo()
  {
  }

  public KYCAccessPolicyInfo(AccessPolicyRule theObject, Vector aclEntryVector) throws WTException {
    this.aPolicyRule = theObject;
    this.aAclEntryVector = aclEntryVector;
  }

  public String getTypeObjectName() throws WTException
  {
    String typeId = this.aPolicyRule.getSelector().getTypeId();
    if (typeId.lastIndexOf("|") > -1) {
      String idString = typeId.substring(typeId.lastIndexOf("|") + 1);
      WTTypeDefinition typeDefinition = (WTTypeDefinition)getInstance("VR:com.ptc.core.meta.type.mgmt.server.impl.WTTypeDefinition:" + idString);

      String typeName = typeDefinition.getName();
      return typeName.substring(typeName.lastIndexOf(".") + 1);
    }
    return typeId;
  }

  public String getFullTypeObjectName()
    throws WTException
  {
    String typeId = this.aPolicyRule.getSelector().getTypeId();

    if (typeId.lastIndexOf("|") > -1) {
      String idString = typeId.substring(typeId.lastIndexOf("|") + 1);
      WTTypeDefinition typeDefinition = (WTTypeDefinition)getInstance("VR:com.ptc.core.meta.type.mgmt.server.impl.WTTypeDefinition:" + idString);

      typeId = getFullTypeObjectName(typeDefinition);

      return "WCTYPE" + typeId;
    }
    return "WCTYPE|" + typeId;
  }

  public String getFullTypeObjectName(WTTypeDefinition definition)
    throws WTException
  {
    String typeName = definition.getName();
    String parentName = "";

    if (definition.getParent() != null) {
      parentName = getFullTypeObjectName((WTTypeDefinition)definition.getParent());
    }

    return parentName + "|" + typeName;
  }

  public String getStateName() throws WTException {
    if (this.aPolicyRule.getSelector().getStateName() == null) return "ALL";
    return this.aPolicyRule.getSelector().getStateName();
  }

  public String getPrincipal() throws WTException {
    WTAclEntry oneAcl = (WTAclEntry)this.aAclEntryVector.get(0);
    WTPrincipalReference userRefer = oneAcl.getPrincipalReference();

    if (userRefer.getName() == null) return "ALL";

    if ((userRefer.getObject() instanceof WTRolePrincipal)) {
      WTRolePrincipal rolePrincipal = (WTRolePrincipal)userRefer.getObject();
      String roleStringValue = rolePrincipal.getRole().getStringValue();
      return roleStringValue.substring(roleStringValue.lastIndexOf(".") + 1);
    }

    return userRefer.getName();
  }

  public WTPrincipalReference getPrincipalReference() throws WTException {
    WTAclEntry oneAcl = (WTAclEntry)this.aAclEntryVector.get(0);
    WTPrincipalReference userRefer = oneAcl.getPrincipalReference();

    return userRefer;
  }

  public String getPrincipalType() throws WTException {
    WTAclEntry oneAcl = (WTAclEntry)this.aAclEntryVector.get(0);
    WTPrincipalReference userRefer = oneAcl.getPrincipalReference();

    if (userRefer.getRepository() == null) return "ROLE";
    return "PRINCIPAL";
  }

  public String getAppliesTo() throws WTException {
    WTAclEntry oneAcl = (WTAclEntry)this.aAclEntryVector.get(0);
    boolean isAppliesTo = oneAcl.isAllExceptPrincipal();
    if (!isAppliesTo) {
      return "Principal";
    }
    return "All except principal";
  }

  public String getAppliesToFile() throws WTException
  {
    WTAclEntry oneAcl = (WTAclEntry)this.aAclEntryVector.get(0);
    boolean isAppliesTo = oneAcl.isAllExceptPrincipal();
    if (!isAppliesTo) {
      return "false";
    }
    return "true";
  }

  public String getPermissions() throws WTException
  {
    String grantStr = "";
    String denyStr = "";
    String absoluteStr = "";
    boolean grantAdded = false;
    boolean denyAdded = false;
    boolean absoluteAdded = false;
    AccessPermissionSet pSet = null;
    Object[] pSetArray = (Object[])null;

    for (int i = 0; i < this.aAclEntryVector.size(); i++) {
      WTAclEntry oneAcl = (WTAclEntry)this.aAclEntryVector.get(i);
      AccessPermissionType oneAclType = oneAcl.getAccessPermissionType();
      if (oneAclType.getDisplay().equals(AccessPermissionType.DENY.getDisplay())) {
        pSet = oneAcl.getPermissionSet();
        pSetArray = pSet.toArray();
        for (int j = 0; j < pSet.size(); j++) {
          if (denyAdded) denyStr = denyStr + ",";
          denyStr = denyStr + ((AccessPermission)pSetArray[j]).getDisplay();
          denyAdded = true;
        }
      } else if (oneAclType.getDisplay().equals(AccessPermissionType.GRANT.getDisplay())) {
        pSet = oneAcl.getPermissionSet();
        pSetArray = pSet.toArray();
        for (int j = 0; j < pSet.size(); j++) {
          if (grantAdded) grantStr = grantStr + ",";
          grantStr = grantStr + ((AccessPermission)pSetArray[j]).getDisplay();
          grantAdded = true;
        }
      } else {
        pSet = oneAcl.getPermissionSet();
        pSetArray = pSet.toArray();
        for (int j = 0; j < pSet.size(); j++) {
          if (absoluteAdded) absoluteStr = absoluteStr + ",";
          absoluteStr = absoluteStr + ((AccessPermission)pSetArray[j]).getDisplay();
          absoluteAdded = true;
        }
      }
    }

    String lastStr = "";
    if (grantStr.length() > 0) lastStr = lastStr + "[G]" + grantStr;
    if (denyStr.length() > 0) lastStr = lastStr + " | [D]" + denyStr;
    if (absoluteStr.length() > 0) lastStr = lastStr + " | [AD]" + absoluteStr; else
      lastStr = lastStr + " | ";
    return lastStr;
  }

  public Vector getPermissionSet() throws WTException {
    String grantStr = "";
    String denyStr = "";
    String absoluteStr = "";
    boolean grantAdded = false;
    boolean denyAdded = false;
    boolean absoluteAdded = false;
    AccessPermissionSet pSet = null;
    Object[] pSetArray = (Object[])null;

    for (int i = 0; i < this.aAclEntryVector.size(); i++) {
      WTAclEntry oneAcl = (WTAclEntry)this.aAclEntryVector.get(i);
      AccessPermissionType oneAclType = oneAcl.getAccessPermissionType();
      if (oneAclType.getDisplay().equals(AccessPermissionType.DENY.getDisplay())) {
        pSet = oneAcl.getPermissionSet();
        pSetArray = pSet.toArray();
        for (int j = 0; j < pSet.size(); j++) {
          if (denyAdded) denyStr = denyStr + "/";
          denyStr = denyStr + getAccessString((AccessPermission)pSetArray[j]);
          denyAdded = true;
        }
      } else if (oneAclType.getDisplay().equals(AccessPermissionType.GRANT.getDisplay())) {
        pSet = oneAcl.getPermissionSet();
        pSetArray = pSet.toArray();
        for (int j = 0; j < pSet.size(); j++) {
          if (grantAdded) grantStr = grantStr + "/";
          grantStr = grantStr + getAccessString((AccessPermission)pSetArray[j]);
          grantAdded = true;
        }
      } else {
        pSet = oneAcl.getPermissionSet();
        pSetArray = pSet.toArray();
        for (int j = 0; j < pSet.size(); j++) {
          if (absoluteAdded) absoluteStr = absoluteStr + "/";
          absoluteStr = absoluteStr + getAccessString((AccessPermission)pSetArray[j]);
          absoluteAdded = true;
        }
      }
    }

    Vector lastSet = new Vector();
    lastSet.add(grantStr);
    lastSet.add(denyStr);
    lastSet.add(absoluteStr);

    return lastSet;
  }

  public String getAccessString(AccessPermission accessPermission) {
    String accessStr = null;

    if (accessPermission.getStringValue().equals("wt.access.AccessPermission.-1"))
      accessStr = "ALL";
    else if (accessPermission.getStringValue().equals("wt.access.AccessPermission.14"))
      accessStr = "CHANGE_CONTEXT";
    else if (accessPermission.getStringValue().equals("wt.access.AccessPermission.12"))
      accessStr = "CHANGE_DOMAIN";
    else if (accessPermission.getStringValue().equals("wt.access.AccessPermission.9"))
      accessStr = "CHANGE_PERMISSIONS";
    else if (accessPermission.getStringValue().equals("wt.access.AccessPermission.2"))
      accessStr = "CREATE";
    else if (accessPermission.getStringValue().equals("wt.access.AccessPermission.13"))
      accessStr = "CREATE_BY_MOVE";
    else if (accessPermission.getStringValue().equals("wt.access.AccessPermission.5"))
      accessStr = "DELETE";
    else if (accessPermission.getStringValue().equals("wt.access.AccessPermission.10"))
      accessStr = "DOWNLOAD";
    else if (accessPermission.getStringValue().equals("wt.access.AccessPermission.1"))
      accessStr = "MODIFY";
    else if (accessPermission.getStringValue().equals("wt.access.AccessPermission.11"))
      accessStr = "MODIFY_CONTENT";
    else if (accessPermission.getStringValue().equals("wt.access.AccessPermission.16"))
      accessStr = "MODIFY_IDENTITY";
    else if (accessPermission.getStringValue().equals("wt.access.AccessPermission.8"))
      accessStr = "NEW_VIEW_VERSION";
    else if (accessPermission.getStringValue().equals("wt.access.AccessPermission.0"))
      accessStr = "READ";
    else if (accessPermission.getStringValue().equals("wt.access.AccessPermission.7"))
      accessStr = "REVISE";
    else if (accessPermission.getStringValue().equals("wt.access.AccessPermission.15"))
      accessStr = "SET_STATE";
    else if (accessPermission.getStringValue().equals("wt.access.AccessPermission.6")) {
      accessStr = "ADMINISTRATIVE";
    }

    return accessStr;
  }

  public AccessPolicyRule getObject() {
    return this.aPolicyRule;
  }

  public WTObject getInstance(String oid) throws WTException {
    ReferenceFactory referencefactory = new ReferenceFactory();
    WTReference wtreference = referencefactory.getReference(oid);
    return (WTObject)wtreference.getObject();
  }

  public String toString() {
    try {
      return getTypeObjectName() + " | " + getStateName() + " | " + 
        getPrincipal() + " | " + getAppliesTo() + " | " + getPermissions();
    } catch (WTException e) {
    }
    return null;
  }

  public String getConceptualClassname()
  {
    return "ext.csc.support.domain.util.AccessPolicyInfo";
  }
}