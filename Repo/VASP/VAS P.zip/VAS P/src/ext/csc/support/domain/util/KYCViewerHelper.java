package ext.csc.support.domain.util;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.LinkedList;
import wt.change2.WTChangeActivity2;
import wt.change2.WTChangeIssue;
import wt.change2.WTChangeOrder2;
import wt.change2.WTChangeRequest2;
import wt.enterprise.RevisionControlled;
import wt.fc.ObjectIdentifier;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.fc.WTObject;
import wt.fc.WTReference;
import wt.folder.Folder;
import wt.inf.container.OrgContainer;
import wt.inf.library.WTLibrary;
import wt.lifecycle.LifeCycleTemplate;
import wt.pdmlink.PDMLinkProduct;
import wt.projmgmt.admin.Project2;
import wt.query.template.ReportTemplate;
import wt.team.TeamTemplate;
import wt.util.WTException;
import wt.util.WTProperties;
import wt.workflow.definer.WfTemplateObject;
import wt.workflow.engine.WfProcess;

public class KYCViewerHelper {
	static String CODEBASE;
	static int FOLDER_NAME = 1;

	static int SITE = 1;
	static int ORG = 2;
	static int PRODUCT = 3;
	static int PROJECT = 4;

	static {
		try {
			WTProperties wtproperties = WTProperties.getLocalProperties();
			CODEBASE = wtproperties.getProperty("wt.server.codebase", "");
		} catch (Exception wte) {
			wte.printStackTrace();
		}
	}

	public void vcInit() {
	}

	public static WTObject getSelectedObject(String soid) {
		try {
			ReferenceFactory referencefactory = new ReferenceFactory();
			WTReference wtreference = referencefactory.getReference(soid);
			return (WTObject) wtreference.getObject();
		} catch (WTException localWTException) {
		}
		return null;
	}

	static void quickSort(String[] array, int lowest, int highest)
  {
    int low = lowest;
    int high = highest;

    if (highest > lowest) {
      String arrayMid = array[((lowest + highest) / 2)];

      while ( low <= high ) {
        do if (low >= highest) break; while (array[low].compareTo(arrayMid) < 0);
        while ((high > lowest) && (array[high].compareTo(arrayMid) > 0)) high--;

        if (low <= high) {
          swap(array, low, high);
          low++;
          high--;
        }
      }

      if (lowest < high) quickSort(array, lowest, high);
      if (low < highest) quickSort(array, low, highest);
    }
  }

	private static void swap(String[] a, int i, int j) {
		String temp = a[i];
		a[i] = a[j];
		a[j] = temp;
	}

	public static void sort(String[] array) {
		quickSort(array, 0, array.length - 1);
	}

	public static LinkedList getQuerySort(QueryResult enumeration, int sortFlag)
			throws WTException {
		Hashtable gotObject = new Hashtable();
		int size = 0;

		while (enumeration.hasMoreElements()) {
			WTObject theElement = (WTObject) enumeration.nextElement();
			long longID = PersistenceHelper.getObjectIdentifier(theElement)
					.getId();
			String theElementOid = theElement.getConceptualClassname() + ":"
					+ longID;
			gotObject.put(theElementOid, theElement);
		}

		Hashtable numberVSoid = new Hashtable();

		Enumeration hashOids = gotObject.keys();

		String objectNumber = new String();
		String objectOid = new String();

		if (sortFlag == FOLDER_NAME) {
			while (hashOids.hasMoreElements()) {
				objectOid = (String) hashOids.nextElement();
				try {
					ReferenceFactory referencefactory = new ReferenceFactory();
					WTReference wtreference = referencefactory
							.getReference(objectOid);
					WTObject theObject = (WTObject) wtreference.getObject();
					if ((theObject instanceof Folder)) {
						objectNumber = "[00]" + ((Folder) theObject).getName()
								+ ":" + objectOid;
					} else if ((theObject instanceof RevisionControlled)) {
						objectNumber = "[01]"
								+ ((RevisionControlled) theObject).getName()
								+ ":" + objectOid;
					} else if ((theObject instanceof WfProcess)) {
						objectNumber = "[02]"
								+ ((WfProcess) theObject).getName() + ":"
								+ objectOid;
					} else if ((theObject instanceof LifeCycleTemplate)) {
						objectNumber = "[03]"
								+ ((LifeCycleTemplate) theObject).getName()
								+ ":" + objectOid;
					} else if ((theObject instanceof WfTemplateObject)) {
						objectNumber = "[04]"
								+ ((WfTemplateObject) theObject).getName()
								+ ":" + objectOid;
					} else if ((theObject instanceof ReportTemplate)) {
						objectNumber = "[05]"
								+ ((ReportTemplate) theObject).getName() + ":"
								+ objectOid;
					} else if ((theObject instanceof TeamTemplate)) {
						objectNumber = "[06]"
								+ ((TeamTemplate) theObject).getName() + ":"
								+ objectOid;
					} else if ((theObject instanceof WTChangeIssue)) {
						objectNumber = "[07]"
								+ ((WTChangeIssue) theObject).getName() + ":"
								+ objectOid;
					} else if ((theObject instanceof WTChangeRequest2)) {
						objectNumber = "[08]"
								+ ((WTChangeRequest2) theObject).getName()
								+ ":" + objectOid;
					} else if ((theObject instanceof WTChangeOrder2)) {
						objectNumber = "[09]"
								+ ((WTChangeOrder2) theObject).getName() + ":"
								+ objectOid;
					} else if ((theObject instanceof WTChangeActivity2)) {
						objectNumber = "[10]"
								+ ((WTChangeActivity2) theObject).getName()
								+ ":" + objectOid;
					}

					numberVSoid.put(objectNumber, objectOid);
				} catch (WTException we) {
					we.printStackTrace();
				}
			}

		}

		Enumeration countTemp = numberVSoid.keys();

		while (countTemp.hasMoreElements()) {
			countTemp.nextElement();
			size++;
		}

		String[] sortNumber = new String[size];

		Enumeration hashNumbers = numberVSoid.keys();

		int i = 0;

		while (hashNumbers.hasMoreElements()) {
			sortNumber[i] = ((String) hashNumbers.nextElement());
			i++;
		}

		sort(sortNumber);

		LinkedList resultVector = new LinkedList();

		for (i = 0; i < size; i++) {
			String resultPartNumber = sortNumber[i];

			String resultPartOid = (String) numberVSoid.get(resultPartNumber);

			WTObject resultPart = (WTObject) gotObject.get(resultPartOid);

			resultVector.add(i, resultPart);
		}

		return resultVector;
	}

	public static LinkedList getQuerySort(QueryResult enumeration,
			int sortFlag, int rootType) throws WTException {
		Hashtable gotObject = new Hashtable();
		int size = 0;

		while (enumeration.hasMoreElements()) {
			if (rootType != ORG) {
				WTObject theElement = (WTObject) enumeration.nextElement();
				long longID = PersistenceHelper.getObjectIdentifier(theElement)
						.getId();
				String theElementOid = theElement.getConceptualClassname()
						+ ":" + longID;
				gotObject.put(theElementOid, theElement);
			} else {
				WTObject theElement = (WTObject) enumeration.nextElement();
				if (!(theElement instanceof OrgContainer)) {
					long longID = PersistenceHelper.getObjectIdentifier(
							theElement).getId();
					String theElementOid = theElement.getConceptualClassname()
							+ ":" + longID;
					gotObject.put(theElementOid, theElement);
				}

			}

		}

		Hashtable numberVSoid = new Hashtable();

		Enumeration hashOids = gotObject.keys();

		String objectNumber = new String();
		String objectOid = new String();

		if (sortFlag == FOLDER_NAME) {
			if (rootType == SITE) {
				while (hashOids.hasMoreElements()) {
					objectOid = (String) hashOids.nextElement();
					try {
						ReferenceFactory referencefactory = new ReferenceFactory();
						WTReference wtreference = referencefactory
								.getReference(objectOid);
						WTObject theObject = (WTObject) wtreference.getObject();

						if ((theObject instanceof OrgContainer))
							objectNumber = "[01]"
									+ ((OrgContainer) theObject).getName();
						else {
							objectNumber = "[02]"
									+ ((Folder) theObject).getName();
						}
						numberVSoid.put(objectNumber, objectOid);
					} catch (WTException we) {
						we.printStackTrace();
					}
				}
			}
			if (rootType == ORG) {
				while (hashOids.hasMoreElements()) {
					objectOid = (String) hashOids.nextElement();
					try {
						ReferenceFactory referencefactory = new ReferenceFactory();
						WTReference wtreference = referencefactory
								.getReference(objectOid);
						WTObject theObject = (WTObject) wtreference.getObject();

						if ((theObject instanceof PDMLinkProduct))
							objectNumber = "[01]"
									+ ((PDMLinkProduct) theObject).getName();
						else if ((theObject instanceof Project2))
							objectNumber = "[02]"
									+ ((Project2) theObject).getName();
						else if ((theObject instanceof WTLibrary))
							objectNumber = "[03]"
									+ ((WTLibrary) theObject).getName();
						else {
							objectNumber = "[00]"
									+ ((Folder) theObject).getName();
						}
						numberVSoid.put(objectNumber, objectOid);
					} catch (WTException we) {
						we.printStackTrace();
					}
				}
			}

		}

		Enumeration countTemp = numberVSoid.keys();

		while (countTemp.hasMoreElements()) {
			countTemp.nextElement();
			size++;
		}

		String[] sortNumber = new String[size];

		Enumeration hashNumbers = numberVSoid.keys();

		int i = 0;

		while (hashNumbers.hasMoreElements()) {
			sortNumber[i] = ((String) hashNumbers.nextElement());
			i++;
		}

		sort(sortNumber);

		LinkedList resultVector = new LinkedList();

		for (i = 0; i < size; i++) {
			String resultPartNumber = sortNumber[i];

			String resultPartOid = (String) numberVSoid.get(resultPartNumber);

			WTObject resultPart = (WTObject) gotObject.get(resultPartOid);

			resultVector.add(i, resultPart);
		}
		return resultVector;
	}
}