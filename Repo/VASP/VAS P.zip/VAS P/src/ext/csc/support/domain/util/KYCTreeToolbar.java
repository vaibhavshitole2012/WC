package ext.csc.support.domain.util;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JToggleButton;
import javax.swing.JToolBar;
import javax.swing.JTree;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;
import wt.admin.AdministrativeDomain;

public class KYCTreeToolbar extends JToolBar
  implements ActionListener
{
  private KYCTreeLogic theLogic;
  private JButton pasteButton;
  private JButton searchsaveButton;
  public static String VIEW_XML_TOOLTIP = "View XML Format";
  public static String VIEW_CSV_TOOLTIP = "View CSV Format";
  public static String EXPORT_XML_TOOLTIP = "Import XML Format";
  public static String EXPORT_CSV_TOOLTIP = "Import CSV Format";
  public static String REFRESH_TOOLTIP = "Refresh Node";
  public static String EXIT_TOOLTIP = "Exit Window";

  public static String COMMIT_TOOLTIP = "Commit Changes";
  public static String CONFIGSPEC_TOOLTIP = "Configuration Specification";

  public KYCTreeToolbar(KYCTreeLogic theLogic, boolean sourceOnly)
  {
    this.theLogic = theLogic;

    IconFactory iconFactory = new IconFactory();

    Dimension theDim = new Dimension(24, 24);
    JButton theButton;
    add(theButton = newButton("Create Domain", "create.gif"));
    theButton.setToolTipText("Create New Child Domain");

    add(theButton = newButton("Delete Domain", "delete.gif"));
    theButton.setToolTipText("Delete selected Domain");

    addSeparator();

    add(theButton = newButton("Clear Access", "clear.gif"));
    theButton.setToolTipText("Clear target domain's access");

    addSeparator();

    add(theButton = newButton("View XML", "view.gif"));
    theButton.setToolTipText(VIEW_XML_TOOLTIP);

    add(theButton = newButton("View CSV", "viewproc.gif"));
    theButton.setToolTipText(VIEW_CSV_TOOLTIP);

    add(theButton = newButton("Import XML Format", "exportsrchresults_tl.gif"));
    theButton.setToolTipText(EXPORT_XML_TOOLTIP);

    add(theButton = newButton("Import CSV Format", "export_includeall.gif"));
    theButton.setToolTipText(EXPORT_CSV_TOOLTIP);

    addSeparator();

    add(theButton = newButton("Refresh", "refresh.gif"));
    theButton.setToolTipText(REFRESH_TOOLTIP);

    addSeparator();

    add(theButton = newButton("About", "question.gif"));
    theButton.setToolTipText("About this tool");

    add(theButton = newButton("Exit Window", "cancellink.gif"));
    theButton.setToolTipText(EXIT_TOOLTIP);
  }

  public JButton getPasteButton() {
    return this.pasteButton;
  }
  public JButton getSearchSaveButton() {
    return this.searchsaveButton;
  }

  private JButton newButton(String actionName, String iconName)
  {
    Dimension theDim = new Dimension(30, 30);
    JButton theButton = new JButton(new IconFactory().createIcon(iconName));
    theButton.setActionCommand(actionName);
    theButton.addActionListener(this);
    theButton.setPreferredSize(theDim);
    theButton.setMinimumSize(theDim);
    theButton.setMaximumSize(theDim);

    return theButton;
  }

  private JToggleButton newToggleButton(String actionName, String iconName)
  {
    Dimension theDim = new Dimension(30, 30);
    JToggleButton theButton = new JToggleButton(new IconFactory().createIcon(iconName));
    theButton.setActionCommand(actionName);
    theButton.addActionListener(this);
    theButton.setPreferredSize(theDim);
    theButton.setMinimumSize(theDim);
    theButton.setMaximumSize(theDim);

    return theButton;
  }

  public void actionPerformed(ActionEvent e)
  {
    try
    {
      String theCommand = e.getActionCommand();
      KYCWTObjectNode theNode = null;

      if ((!theCommand.equals("Exit Window")) && (!theCommand.equals("About"))) {
        JTree theTree = this.theLogic.getTheTree();
        TreePath path = theTree.getSelectionPath();
        if (path == null) {
          JOptionPane.showMessageDialog(this.theLogic.getParentComponent(), theCommand + " need to select one domain.");
        } else {
          TreeNode node = (TreeNode)path.getLastPathComponent();

          if (!node.toString().equals("ACL EXPLORER:@")) {
            theNode = (KYCWTObjectNode)node;
            if (!(theNode.getObject() instanceof AdministrativeDomain)) {
              JOptionPane.showMessageDialog(this.theLogic.getParentComponent(), theCommand + " need to select one domain.\nDo not use this butteon when selected AccessRule.");
            }
            else if (theCommand.equals("View XML"))
              this.theLogic.commitViewXML(theNode);
            else if (theCommand.equals("View CSV"))
              this.theLogic.commitViewCSV(theNode);
            else if (theCommand.equals("Refresh"))
              this.theLogic.refreshNode(theNode);
            else if (theCommand.equals("Import XML Format"))
              this.theLogic.commitLoadXML(theNode);
            else if (theCommand.equals("Import CSV Format"))
              this.theLogic.commitLoadCSV(theNode);
            else if (theCommand.equals("Clear Access"))
              this.theLogic.commitClearChild(theNode);
            else if (theCommand.equals("Create Domain"))
              this.theLogic.commitCreateDomain(theNode);
            else if (theCommand.equals("Delete Domain")) {
              this.theLogic.commitDeleteDomain(theNode);
            }
          }
        }
      }

      if (theCommand.equals("About")) {
        this.theLogic.commitAbout(theNode);
      }

      if (theCommand.equals("Exit Window")) {
        System.exit(0);
      }
    }
    catch (Exception wte)
    {
      wte.printStackTrace();
    }
  }

  class IconFactory
  {
    public IconFactory()
    {
    }

    public ImageIcon createIcon(String fileName)
    {
      URL myURL = null;
      try {
        myURL = new URL(KYCPartTreeCellRenderer.CODEBASE + "/wt/clients/images/" + fileName);
      } catch (Exception e) {
        e.printStackTrace();
      }

      return new ImageIcon(myURL);
    }
  }
}