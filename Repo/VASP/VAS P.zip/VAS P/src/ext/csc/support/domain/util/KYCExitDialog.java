package ext.csc.support.domain.util;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Insets;
import java.awt.Label;
import javax.swing.JDialog;

public class KYCExitDialog extends JDialog
{
  boolean frameSizeAdjusted = false;

  Label messageText = new Label();

  public KYCExitDialog(Frame parent)
  {
    super(parent);

    getContentPane().setLayout(null);
    setSize(355, 168);
    setVisible(false);
    getContentPane().add(this.messageText);
    this.messageText.setBounds(36, 24, 288, 84);
  }

  public KYCExitDialog()
  {
    this((Frame)null);
  }

  public KYCExitDialog(String sTitle)
  {
    this();
    setTitle(sTitle);
  }

  public void setVisible(boolean b)
  {
    if (b)
      setLocation(50, 50);
    super.setVisible(b);
  }

  public static void main(String[] args)
  {
    new KYCExitDialog().setVisible(true);
  }

  public void addNotify()
  {
    Dimension size = getSize();

    super.addNotify();

    if (this.frameSizeAdjusted)
      return;
    this.frameSizeAdjusted = true;

    Insets insets = getInsets();
    setSize(insets.left + insets.right + size.width, insets.top + insets.bottom + size.height);
  }
}