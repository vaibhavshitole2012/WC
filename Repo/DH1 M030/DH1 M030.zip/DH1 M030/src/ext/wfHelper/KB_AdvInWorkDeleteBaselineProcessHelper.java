package ext.wfHelper;

import java.util.logging.Level;
import java.util.logging.Logger;

import wt.epm.EPMDocument;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.util.WTException;
import wt.vc.baseline.ManagedBaseline;

import com.ptc.windchill.enterprise.history.MaturityHistoryInfo;

import ext.kb.util.KBConstants;
import ext.kb.util.KBUtils;
import ext.kb.workflow.EPMDocumentMaturityHistoryInfoResolver;

/**
 * Class handle actions related to KB_AdvInWorkDeleteBaseline workflow.
 * 
 * @author pboguski
 * 
 */
@Deprecated //R1 customization
public class KB_AdvInWorkDeleteBaselineProcessHelper {

    /** The logger. */
    private static Logger logger = Logger.getLogger(KB_AdvInWorkDeleteBaselineProcessHelper.class.getName());

    /**
     * Checks if given EPMDocument is Drawing.
     * 
     * @param pbo
     *            DesignCADDoc object (worklfow primary business object)
     * @return
     */
    public static boolean checkIfDrawingExists(EPMDocument pbo) {

        logger.log(Level.FINEST, "Checking if EPMDocument (name=" + pbo.getName() + ") is Drawing started");

        boolean result = KBUtils.isDrawing(pbo);

        logger.log(Level.FINEST, "Checking if EPMDocument (name=" + pbo.getName() + ") is Drawing ended");

        return result;
    }

    /**
     * Delete baseline with number: <DRW number without extension>_<number from DRW revision>.
     * 
     * @param pbo
     *            DesignCADDoc (Drawing) object (worklfow primary business
     *            object)
     * @return error message or null in case of no errors
     */
    public static String deleteBaseline(EPMDocument pbo) {

        String revision = null;
        ManagedBaseline baseline = null;

        try {

            MaturityHistoryInfo maturityHistoryInfo = EPMDocumentMaturityHistoryInfoResolver.latestMaturityHistoryInfo(pbo);

            if (maturityHistoryInfo != null) {
                String maturityHistoryInfoLCState = maturityHistoryInfo.getLifecycleStateStr();

                if (!KBConstants.INWORK_STATE.equals(maturityHistoryInfoLCState)) {
                    String errorMsg = "Latest MaturityHistoryInfo object, for EPMDocument: name=" + pbo.getName() + ", number=" + pbo.getNumber() + ", state should be " + KBConstants.INWORK_STATE + " but it is " + maturityHistoryInfoLCState;
                    logger.log(Level.SEVERE, errorMsg);
                    return errorMsg;
                }
            }
            String promotedBy = maturityHistoryInfo.getPromotedBy();

            //setting IBA's should be skipped for users from list in preferences
            if (KBUtils.isSpecialUser(promotedBy)) {
                logger.info("Setting IBA'a KB_RELEASED_BY and KB_RELEASED_DATE omitted for user " + promotedBy);
                return null;
            }

            revision = (String) KBUtils.getMBAValue(pbo, "revision");
            String blNumber = KBUtils.getNumberWithoutExtension(pbo) + "_" + KBUtils.getNumberFromRevision(revision);
            QueryResult queryResult = KBUtils.getBaselines(blNumber);
            if(queryResult.hasMoreElements()){
                baseline = (ManagedBaseline) queryResult.nextElement();
            }
        } catch (WTException e) {
            logger.info("Error occured: "+ e);
            return e.getMessage();
        }

        if (baseline == null) {
            return null;
        }

        String blNumber = baseline.getNumber();
        logger.info("Baseline pattern is <DRW number without extension>_<number from DRW revision>. Baseline (number) to delete is:" + blNumber);

        try {
            PersistenceHelper.manager.delete(baseline);
            logger.info("Baseline " + blNumber + " removed.");
            return null;
        } catch (Exception e) {
            logger.info("Error occured: "+ e);
            return "Error: " + e.getMessage();
        }
    }
}
