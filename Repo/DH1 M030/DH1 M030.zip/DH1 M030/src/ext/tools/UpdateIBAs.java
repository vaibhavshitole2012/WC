/*
maintenance: mkraegeloh@sulis.de
20051114 mkr; move code from main into method to make it callable from other classes.

purpose: set iba values on a holder - if workable checkin/out if necessary.

This program is free software; you can redistribute it and/or modify it under the terms of the
GNU Lesser General Public License as published by the Free Software Foundation;
see http://www.gnu.org/licenses/lgpl.html (und deutsch: http://www.gnu.de/lgpl-ger.html)

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
See the GNU Lesser General Public License for more details.

NOTE: use of -c to update classificationnodes is considered experimental and needs verification! 

RESTRICTION: float value precision is hardcoded to 6 (see createAbstractValueView())
*/

package ext.tools;

import java.util.*;
import java.sql.*;
import java.io.*;
import java.text.*;

import wt.util.*;
import wt.vc.wip.*;
import wt.folder.*;
import wt.part.*;
import wt.vc.*;
import wt.fc.*;
import wt.query.*;
import wt.method.*;
import wt.type.*;
import wt.fc.*;
import wt.pom.*;
import wt.session.SessionHelper;            //SessionHelper
import wt.iba.value.service.*;              //StandardIBAValueService
import wt.iba.value.*;                      //IBAHolder
import wt.iba.value.litevalue.*;            //AbstractValueView
import wt.iba.definition.*;                 //AttributeOrganizer
import wt.iba.definition.litedefinition.*;  //AttributeDefDefaultView
import wt.iba.definition.service.*;         //IBADefinitionDBService
import wt.iba.constraint.*;                 //IBAConstraintException
import wt.services.*;
import wt.units.service.*;

import org.apache.log4j.*;

/**
  * purpose: create/instantiate the IBAHolder, then checkout IBAHolder, add IBAs, checkin <pre>
  *       -a adds IBA values, 
  *       -t "types" the objects
  *       -e allow empty attribute values
  *       -c allows update of classification nodes.
  *       <b>-c option is to be considered experimental ... handle with care !!</b>
  *</pre>
  * @author mkraegeloh
  * @version 1.0
  */
// 20060802 mkr; version & -F
// 20070223 mkr; support setting reference ibas.

public class UpdateIBAs implements RemoteAccess{

   public static final String CVSVersion = "$Header: UpdateIBAs.java 1.2.2.2 2017/09/01 19:11:29IST Nosek, Marek (ext) (ext-nosekm) Exp  $";
   static Hashtable views=new Hashtable();
   static ReferenceFactory RF=new ReferenceFactory();
   static final Logger logger = Logger.getLogger(UpdateIBAs.class);
   static String Version="1.03";
   static Manager dbm=null;

   public static SimpleDateFormat FORMATTERT = new SimpleDateFormat("dd.MM.yyyy hh:mm:ss");

   /**
     * entry point from commandline invocation - check args and act accordingly.
     *
     * @param a	arguments: OBID iba value iba value ...
     * @exception Exception	
     * @return void	
   */
   public static void main(String[] a) throws Exception{
      if(a.length == 0){
	   System.out.println("UpdateIBAs version="+Version);
	   System.out.println("usage: UpdateIBAs [-c] [-a] [-f dateformat] [-t type] OR:class:ID [ibaname ibaval ....]");
	   System.out.println("       -a adds IBA values, -t \"types\" the objects, -c allows update of classification nodes.");
	   System.out.println("       -e allow empty attribute values");
	   System.out.println("       -c option is to be considered experimental ... handle with care !!");
	   return;
	}

      
	WTContext.init(a,true);
    //execute on server
	Vector<String> v = new Vector<String>();
	for(String x : a) {
		v.add(x);
	}
    String s = (String)RemoteMethodServer.getDefault().invoke("_updateIBAs", "ext.tools.UpdateIBAs", null, new Class[] { Vector.class }, new Object[] { v });
	System.out.println(s);
	System.exit(0);
   }
   
   /**
    * used from command line only
    * 
    * @param v
    * @return
    * @throws WTException
    */
   public static String _updateIBAs(Vector<String> v) throws WTException {
	   String[] a = (String[]) v.toArray(new String[0]);
	   return updateIBAs(a);
   }
   

   /**
     * does the work, string array description see main()
     *
     * @param a	arguments
     * @exception WTException	
     * @return String	diagnostics, mailny for command line usage.
   */
   public static String updateIBAs(String[] a) throws WTException{
	StringBuffer diagnostics=new StringBuffer();
	Hashtable deleted=new Hashtable();
	String type="";
	boolean add=false;
	boolean csm=false;
	boolean emptyOk=false;
	boolean force=false;
	boolean useMaster=false;
	boolean doDeleteOnly=false;
	
	try{
	   int off=0;
	   while(a[off].startsWith("-")){
		if(a[off].equals("-t")){
		   type=a[off+1];
		   off+=2;
		}
		else if(a[off].equals("-F")){
		   force=true;
		   off++;
		}
		else if(a[off].equals("-e")){
		   emptyOk=true;
		   off++;
		}
		else if(a[off].equals("-c")){
		   csm=true;
		   off++;
		}
		else if(a[off].equals("-m")){
		   useMaster=true;
		   off++;
		}
		else if(a[off].equals("-a")){
		   add=true;
		   off++;
		}
		else if(a[off].equals("-f")){
		   FORMATTERT = new SimpleDateFormat(a[off+1]);
		   off+=2;
		}
		//added by lberger@ptc.com
		else if(a[off].equals("-D")){
			doDeleteOnly=true;
		   off++;
		}
	   }
	   boolean needCheckin=false;
	   ToolUtils.fixEscapes(a);
	   // got a master? 
	   IBAHolder holder;
	   if(! useMaster && a[off].indexOf("Master")!= -1){
		QueryResult qr=VersionControlHelper.service.allVersionsOf((Mastered)RF.getReference(a[off++]).getObject());
		holder=(IBAHolder)qr.nextElement();
	   }
	   else
		holder=(IBAHolder)RF.getReference(a[off++]).getObject();

	   diagnostics.append("holder="+holder+"\n");
	   //check out if workable and not checked out.
	   if(holder instanceof Workable){
		diagnostics.append("   Workable ...\n");
		if(! WorkInProgressHelper.isCheckedOut((Workable)holder)){
		   if(! force){
			Folder folder = WorkInProgressHelper.service.getCheckoutFolder();
			WorkInProgressHelper.service.checkout((Workable)holder,folder,"auto checkout for UpdateIBAs ...");
			diagnostics.append(" checked it out ...\n");
			needCheckin=true;
		   }
		   else{
		      diagnostics.append(" -F flag ... no checkout done.");
		   }
		}
		else{
		   diagnostics.append(" already checked out ...\n");
		}
		if(! force){
		   if(! WorkInProgressHelper.isWorkingCopy((Workable)holder))
			holder=(IBAHolder)WorkInProgressHelper.service.workingCopyOf((Workable)holder);
		   diagnostics.append(" working copy="+holder+"\n");
		}
	   }
	   else{
		diagnostics.append("not a Workable (ok)\n");
	   }
	   // Create IBA container.
	   holder = (IBAHolder) IBAValueHelper.service.refreshAttributeContainer(holder, null, SessionHelper.manager.getLocale(), null);
	   DefaultAttributeContainer container = (DefaultAttributeContainer) holder.getAttributeContainer();
	   if (container == null) {	// will be null if this is a new holder?
		container = new DefaultAttributeContainer();
	   }
	   if(csm) // disable checks ... else service vetos. so far this has worked propertly.
		container.setConstraintGroups(new Vector());

	   if(! type.equals(""))
		if(holder instanceof Typed){
		   ((Typed)holder).setTypeDefinitionReference(TypedUtilityServiceHelper.service.getTypeDefinitionReference(type));
		   if(force) // only ibaservice further down.
			ToolUtils.update((Persistable)holder);
		}
		else
		   diagnostics.append("obj is not Typed, ignoring -t arg\n");

	   holder.setAttributeContainer(container);

	   //diagnostics.append("holder=" + holder);
	   // Add the IBA values.
	   AttributeDefDefaultView defview = null;
	   AbstractValueView valueview = null;
	   AbstractValueView[] avv;
	   StandardIBADefinitionService service = new StandardIBADefinitionService();
	   for(int i=off;i<a.length;i+=2){
	   	//diagnostics.append("a[" + i + "]=" + a[i]);
		try{
		   if((defview=(AttributeDefDefaultView)views.get(a[i]))==null){
			defview = service.getAttributeDefDefaultViewByPath(a[i]);
			if(defview == null){
			   diagnostics.append("   WARN: att def \""+a[i]+"\" not found.\n");
			   continue;
			//} else {
			//	diagnostics.append("   defview=" + defview + "\n");
			}
			views.put(a[i],defview);
		   }
		   avv = container.getAttributeValues(defview);
		   //diagnostics.append("avv=" + avv + "length=" + avv.length + "\n");
		   if(! add && deleted.get(a[i]) == null && avv.length > 0){ // old att
				diagnostics.append("   remove old "+a[i]+" vals: \n");
				deleted.put(a[i],"");
				for(int j=0;j<avv.length; j++) {
				   if(avv[j] instanceof TimestampValueDefaultView)
				   	System.out.println(((TimestampValueDefaultView)avv[j]).getValue().toString().replaceAll("-",".").replaceFirst("..$",""));
				   else if(avv[j] instanceof ReferenceValueDefaultView)
				   	diagnostics.append(((ReferenceValueDefaultView)avv[j]).getLiteIBAReferenceable().getIBAReferenceableDisplayString().toString()+"\n");
				   else
				   	diagnostics.append(((AbstractContextualValueDefaultView)avv[j]).getValueAsString()+"\n");
				}
				container.deleteAttributeValues(defview);
				//logger.debug("DELETED IBA");
		   }
		   if(!doDeleteOnly && (emptyOk || ! a[i+1].equals(""))){
				valueview = createAbstractValueView(defview, a[i+1]);
				if (valueview != null) {
				   if (csm || container.isAddValid(valueview))
				   	container.addAttributeValue(valueview);
				   else 
				   	throw new IBAConstraintException("invalid value \""+a[i+1]+"\" for attribute "+a[i]);
				}
		   }
		}
		catch(Exception err1){
		   err1.printStackTrace();
		   diagnostics.append("Exception: "+err1+"\n");
		   diagnostics.append("skipping "+a[i]+"="+a[i+1]+"\n");
		}
	   }
	   

	   if(! force)
		PersistenceHelper.manager.save((Persistable)holder);
	   else{
		if(RemoteMethodServer.ServerFlag)
		   forcedUpdate((IBAHolder) holder, container.getConstraintParameter(), null, null);
		else
		   RemoteMethodServer.getDefault().invoke("forcedUpdate","ext.tools.UpdateIBAs",null, new Class[] {IBAHolder.class, Object.class, Locale.class, MeasurementSystemDefaultView.class}, new Object[] { (IBAHolder) holder, container.getConstraintParameter(), null, null });
	   }
	   if(needCheckin){
		holder=(IBAHolder)WorkInProgressHelper.service.checkin((Workable)holder,"auto checkin after UpdateIBAs ...");
		diagnostics.append("   checkin...\n");
	   }
	   diagnostics.append(" Done adding the IBAs obj now: "+holder+"\n");
	}
	catch(Exception e){
	   e.printStackTrace();
	   //transaction.rollback();
	}
	return diagnostics.toString();
   } 
   /**
     * helper method for iba stuff
     *
     * @param def
     * @param value
     * @exception Exception
     * @return AbstractValueView
    */

   public static AbstractValueView createAbstractValueView(AttributeDefDefaultView def, String value) throws Exception {
	Object obj = null;
	try{
	if(def instanceof StringDefView)
	   obj = new StringValueDefaultView((StringDefView) def, value);
	else if(def instanceof TimestampDefView)
	   obj = new TimestampValueDefaultView((TimestampDefView) def, new Timestamp(FORMATTERT.parse(value).getTime()));
	else if(def instanceof BooleanDefView)
	   obj = new BooleanValueDefaultView((BooleanDefView) def, Boolean.valueOf(value).booleanValue());
	else if(def instanceof FloatDefView)
	   obj = new FloatValueDefaultView((FloatDefView) def, Double.parseDouble(value), 6);
	else if(def instanceof IntegerDefView)
	   obj = new IntegerValueDefaultView((IntegerDefView) def, Integer.parseInt(value));
	else if(def instanceof RatioDefView) {
	   StringTokenizer st = new StringTokenizer(value,":");
	   obj = new RatioValueDefaultView((RatioDefView) def, Double.parseDouble(st.nextToken()), Double.parseDouble(st.nextToken()));
	}
	else if(def instanceof ReferenceDefView){ /* never had this set from custom code ... */
	   // throw new WTException("ERROR: cannot set Reference IBA");
         obj=new ReferenceValueDefaultView((ReferenceDefView)def);
	   Object obj1=ToolUtils.objFromObid(value);
	   if(obj1 instanceof IBAReferenceable)
		((ReferenceValueDefaultView)obj).setLiteIBAReferenceable(new DefaultLiteIBAReferenceable(0, ((Persistable)obj1).getPersistInfo().getObjectIdentifier(), "hallo hier"));
	   else
	      throw new WTException("obj "+value+" must be a IBAReferenceable");
	}
	else if(def instanceof UnitDefView) 
	   obj = new UnitValueDefaultView((UnitDefView) def, Double.parseDouble(value), 6);
	else if(def instanceof URLDefView)
	   obj = new URLValueDefaultView((URLDefView) def, value, null);
	return ((AbstractValueView) (obj));
	}
	catch(WTException err){
	   err.printStackTrace();
	   throw err;
	}
   }

   public static void forcedUpdate(IBAHolder h, Object cpm, Locale l, MeasurementSystemDefaultView m) throws WTException{
	if(dbm == null)
	   dbm=ManagerServiceFactory.getDefault().getManager(wt.iba.value.service.IBAValueService.class);
	((MultiObjIBAValueService)dbm).theStandardIBAValueService.theIBAValueDBService.updateAttributeContainer(h, cpm, l, m);
   }
   
   /**
    * 
    * @param ibaHolder
    * @param ibas
    * @param bForceUpdate
    * @return
    * @throws WTException
    * @author Lorenz Berger, PTC; lberger@ptc.com
    */
   public static String updateIBAs(String ibaHolderOid, Map ibas, boolean bForceUpdate) throws WTException{
   	Vector vArgs = new Vector();
   	if(bForceUpdate) {
   		vArgs.add("-F");
   	}
   	//with '-a' multiple IBA values can be saved
   	if(ibas.containsKey("addIbas")) {
   		vArgs.add("-a");
   	}
   	vArgs.add(ibaHolderOid);
   	Iterator iKeys = ibas.keySet().iterator();
   	while(iKeys.hasNext()) {
   		Object key = iKeys.next();
   		Object value = ibas.get(key);
   		if(key!=null && value!=null) {
   		vArgs.add(key.toString());
   		vArgs.add(value.toString());
   		} else {
   			logger.error("map contained null key or value: key=" + key + " value=" + value);
   			logger.error("continuing with other IBAs");
   		}
   	}
   	
   	String[] s = new String[0];
   	return UpdateIBAs.updateIBAs((String[])vArgs.toArray(s));
   }
   
   public static String deleteIBAs(String ibaHolderOid, Map ibas, boolean bForceUpdate) throws WTException{
   	Vector vArgs = new Vector();
   	if(bForceUpdate) {
   		vArgs.add("-F");
   	}
   	vArgs.add("-D");
   	vArgs.add(ibaHolderOid);
   	Iterator iKeys = ibas.keySet().iterator();
   	while(iKeys.hasNext()) {
   		Object key = iKeys.next();
   		Object value = ibas.get(key);
   		if(key!=null && value!=null) {
   		vArgs.add(key.toString());
   		vArgs.add(value.toString());
   		} else {
   			logger.error("map contained null key or value: key=" + key + " value=" + value);
   			logger.error("continuing with other IBAs");
   		}
   	}
   	
   	String[] s = new String[0];
   	return UpdateIBAs.updateIBAs((String[])vArgs.toArray(s));
   }
}
