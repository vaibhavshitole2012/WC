package ext.kb.listener;

import static mockit.Deencapsulation.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.HashSet;
import java.util.Set;

import mockit.Mocked;
import mockit.NonStrictExpectations;
import mockit.Verifications;

import org.junit.Test;

import wt.doc.WTDocument;
import wt.fc.ObjectReference;
import wt.fc.QueryResult;
import wt.fc.collections.WTArrayList;
import wt.fc.collections.WTList;
import wt.lifecycle.LifeCycleHelper;
import wt.lifecycle.LifeCycleManaged;
import wt.lifecycle.LifeCycleService;
import wt.lifecycle.LifeCycleServiceEvent;
import wt.lifecycle.LifeCycleState;
import wt.lifecycle.State;
import wt.part.WTPart;
import wt.type.TypedUtilityService;
import wt.type.TypedUtilityServiceHelper;
import wt.vc.VersionControlHelper;
import wt.vc.VersionControlService;
import wt.vc.Versioned;

import com.ptc.core.meta.common.impl.WCTypeIdentifier;

public class StateChangeListenerTest {

    @Mocked 
    TypedUtilityService serv;
    @Mocked
    VersionControlService versionServ;
    @Mocked
    LifeCycleService lifeCycleServ;

    
    @Test
    public void testNotifyVetoableEventObject() throws Exception{
        StateChangeListener listener = new StateChangeListener("");
        mockGetVersions();
        new NonStrictExpectations() {
            {
                setField(TypedUtilityServiceHelper.class, "service", serv);
                serv.getTypeIdentifier(withAny(new ObjectReference()));
                returns(new WCTypeIdentifier("wt.doc.WTDocument|com.ptc.KBDOCUMENTOrganizer|com.ptc.KBDRAWINGDOCUMENT"));
 
                setField(LifeCycleHelper.class, "service", lifeCycleServ);
                lifeCycleServ.setLifeCycleState(withAny(new WTArrayList()), withAny(State.toState("1080")),
                        withAny(Boolean.FALSE));
            }
        };

        //Test is slightly cheating, change object is document while mocked services will return wtparts
        LifeCycleManaged lcmTarget = new WTDocument();
        LifeCycleState s = new LifeCycleState();
        s.setState(State.toState("1050"));
        lcmTarget.setState(s);
        
        LifeCycleServiceEvent lcEvent = new LifeCycleServiceEvent("", lcmTarget);
        
        listener.notifyVetoableEvent(lcEvent);
        new Verifications() {
            {
                WTList list;
                State s;
                Boolean b;
                lifeCycleServ.setLifeCycleState(list = withCapture(), s = withCapture(), b = withCapture());
                assertFalse(b);
                assertEquals("1080", s.toString());
                assertEquals(1, list.size());
                assertEquals("1050", ((WTPart) ((ObjectReference) list.get(0)).getObject()).getState().toString());
            }
        };
    }

    @Test
    public void testSetStateInvalid() throws Exception {
        StateChangeListener listener = new StateChangeListener("");
        mockGetVersions();
        new NonStrictExpectations() {
            {
                setField(LifeCycleHelper.class, "service", lifeCycleServ);
                lifeCycleServ.setLifeCycleState(withAny(new WTArrayList()), withAny(State.toState("1080")),
                        withAny(Boolean.FALSE));
            }
        };

        listener.setEarlierStatesInvalidAndResetPendingFlag(new WTPart(), new String[] { "1030", StateChangeListener.EQ });
        new Verifications() {
            {
                WTList list;
                State s;
                Boolean b;
                lifeCycleServ.setLifeCycleState(list = withCapture(), s = withCapture(), b = withCapture());
                assertFalse(b);
                assertEquals("1080", s.toString());
                assertEquals(1, list.size());
                assertEquals("1030", ((WTPart) ((ObjectReference) list.get(0)).getObject()).getState().toString());
            }
        };
    }

    @Test
    public void testGetPreviousVersions() throws Exception {
        StateChangeListener listener = new StateChangeListener("");
        mockGetVersions();
        WTList list = listener.getPreviousVersions(new WTPart(), new String[] { "1030", StateChangeListener.EQ });
        assertEquals(1, list.size());
        mockGetVersions();
        list = listener.getPreviousVersions(new WTPart(), new String[] { "1030", StateChangeListener.GR });
        assertEquals(2, list.size());
        Set<String> results = new HashSet<String>();
        results.add(((WTPart) ((ObjectReference) list.get(0)).getObject()).getState().toString());
        results.add(((WTPart) ((ObjectReference) list.get(1)).getObject()).getState().toString());
        assertTrue(results.contains("1030"));
        assertTrue(results.contains("1050"));
    }

    private void mockGetVersions() throws Exception {
        new NonStrictExpectations() {
            {
                QueryResult r = new QueryResult();

                r.getObjectVectorIfc().addElement(createPart("1020"));
                r.getObjectVectorIfc().addElement(createPart("1030"));
                r.getObjectVectorIfc().addElement(createPart("1050"));
                r.getObjectVectorIfc().addElement(createPart("1080"));

                setField(VersionControlHelper.class, "service", versionServ);
                versionServ.allVersionsFrom(withAny((Versioned) new WTPart()));
                returns(r);
            }
        };
    }

    private WTPart createPart(String state) throws Exception {
        WTPart p = new WTPart();
        LifeCycleState s = new LifeCycleState();
        s.setState(State.toState(state));
        p.setState(s);
        return p;
    }
}
