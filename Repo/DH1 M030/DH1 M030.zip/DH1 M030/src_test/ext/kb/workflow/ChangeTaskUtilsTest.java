package ext.kb.workflow;

import static mockit.Deencapsulation.setField;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import mockit.Mocked;
import mockit.NonStrictExpectations;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import wt.change2.ChangeActivity2;
import wt.change2.ChangeRecord2;
import wt.change2.ChangeService2;
import wt.change2.WTChangeActivity2;
import wt.configurablelink.ConfigurableLinkService;
import wt.fc.ObjectVector;
import wt.fc.QueryResult;
import wt.lifecycle.LifeCycleState;
import wt.lifecycle.State;
import wt.lifecycle.Transition;
import wt.part.WTPart;

public class ChangeTaskUtilsTest {

    @Mocked ChangeService2 changeService;
    @Mocked ConfigurableLinkService configLinkService;
    
    @Rule public ExpectedException expectedEx = ExpectedException.none();
    /*  
    @Test
    public void checkProcLocationNoLocation() throws Exception {
        QueryResult configLinks = new QueryResult();
        checkProcLocationTest("Please set Procurement Location to complete the task, part number is: ", configLinks);
    }
    
    @Test
    public void checkProcLocationNoMain() throws Exception { //IBAHelper is failing as item is not persisted into db
        QueryResult configLinks = new QueryResult();
        ConfigurableReferenceLink ooLink = new ConfigurableReferenceLink();
        ooLink.setTypeDefinitionReference(TypedUtilityServiceHelper.service.getTypeDefinitionReference("com.ptc.KBProcSiteLink"));
        WTObject [] elements = new WTObject [2];
        elements[0] = ooLink;
        Vector<WTObject []> v = new Vector<WTObject []>();
        v.add(elements);
        ObjectVector vec = new ObjectVector(v);
        configLinks.append(vec);
        checkProcLocationTest("Please leave one Main Procurement Location, part number is: ", configLinks);
    }
 
    public void checkProcLocationTest (String errorMsg, final QueryResult configLinks) throws Exception {
        expectedEx.expect(WTException.class);
        expectedEx.expectMessage(errorMsg);
        
        setField(wt.change2.ChangeHelper2.class, "service", changeService);
        setField(ConfigurableLinkHelper.class, "service", configLinkService);
        
        final ChangeActivity2 activity = WTChangeActivity2.newWTChangeActivity2();
        
        new NonStrictExpectations() {
            {
                QueryResult res = new QueryResult();
                ObjectVector vec = new ObjectVector();
                final WTPart article = WTPart.newWTPart();
                article.setTypeDefinitionReference(TypedUtilityServiceHelper.service.getTypeDefinitionReference("com.ptc.KBAssyComp"));
                vec.addElement(article);
                res.append(vec);
                changeService.getChangeablesAfter(activity);
                returns(res);
                
                configLinkService.getOtherSideObjectsFromLink(ObjectReference.newObjectReference(article), KBTypeIdProvider.getType("PROCLINK"), "roleBObject", false);
                returns(configLinks);
                
            }
        };
        ChangeTaskUtils.checkProcLocation(activity);
    }
    
    @Test
    public void setProcLocationTest () throws Exception {
        
        setField(wt.change2.ChangeHelper2.class, "service", changeService);
        setField(ConfigurableLinkHelper.class, "service", configLinkService);
        final ChangeActivity2 activity = WTChangeActivity2.newWTChangeActivity2();
        
        setProcLocationExpectations(activity, false);
        assertFalse(ChangeTaskUtils.setProcLocation(activity));
        setProcLocationExpectations(activity, true);
//        assertTrue(ChangeTaskUtils.setProcLocation(activity)); mocking does not recognize call
    }
    
    private void setProcLocationExpectations (final ChangeActivity2 activity, final boolean retVal) throws Exception {
        new NonStrictExpectations() {
            {
                QueryResult res = new QueryResult();
                ObjectVector vec = new ObjectVector();
                final WTPart article = WTPart.newWTPart();
                article.setTypeDefinitionReference(TypedUtilityServiceHelper.service.getTypeDefinitionReference("com.ptc.KBAssyComp"));
                vec.addElement(article);
                res.append(vec);
                changeService.getChangeablesAfter(activity);
                returns(res);
                
                QueryResult configLinks = new QueryResult();
                if (retVal) {
                    WTObject [] elements = new WTObject [2];
                    elements[0] = WTPart.newWTPart();
                    Vector<WTObject []> v = new Vector<WTObject []>();
                    v.add(elements);
                    ObjectVector v1 = new ObjectVector(v);
                    configLinks.append(v1);
                }
                configLinkService.getOtherSideObjectsFromLink((WTReference)any, (TypeIdentifier) any, "roleBObject", false);
                returns(configLinks);
            }
        };
    }
    
    @Test
    public void checkLocationsTest() throws Exception {
        
        setField(ConfigurableLinkHelper.class, "service", configLinkService);
        
        final ChangeActivity2 activity = WTChangeActivity2.newWTChangeActivity2();
        final ObjectReference objRef = ObjectReference.newObjectReference(WTPartMaster.newWTPartMaster());
        activity.setMasterReference(objRef);

        assertTrue(ChangeTaskUtils.checkLocations(activity));
        
        final WTPart p = WTPart.newWTPart();
        p.setTypeDefinitionReference(TypedUtilityServiceHelper.service.getTypeDefinitionReference("com.ptc.KBSite"));
        p.setName("procSite1");
        p.setMaster((Mastered) objRef.getObject());
        
        final WTPart article = WTPart.newWTPart();
        article.setTypeDefinitionReference(TypedUtilityServiceHelper.service.getTypeDefinitionReference("com.ptc.KBAssyComp"));
        
        new NonStrictExpectations() {
            {
                QueryResult res = new QueryResult();
                ConfigurableReferenceLink ooLink = ConfigurableReferenceLink.newConfigurableReferenceLink(article, (Mastered) objRef.getObject(), TypedUtilityServiceHelper.service.getTypeDefinitionReference("com.ptc.KBProcSiteLink"));
                ooLink.setRoleBObjectRef(ObjectReference.newObjectReference(p));
                ooLink.setRoleObject(p, "roleBObject");
                WTObject [] elements = new WTObject [2];
                elements[0] = ooLink;
                elements[1] = p;
                Vector<WTObject []> v = new Vector<WTObject []>();
                v.add(elements);
                ObjectVector vec = new ObjectVector(v);
                res.append(vec);
                
                configLinkService.getOtherSideObjectsFromLink(objRef, KBTypeIdProvider.getType("ASSYCOMP"), "roleAObject", false);
                returns(res);
            }
        };
//        assertFalse(ChangeTaskUtils.checkLocations(activity)); link initialization is not 100%, hence code fails
//        p.setName("");
        assertTrue(ChangeTaskUtils.checkLocations(activity));
    }
    */
    @Test
    public void isReleaseTargetTest() throws Exception{
        
        setField(wt.change2.ChangeHelper2.class, "service", changeService);
        final ChangeActivity2 activity = WTChangeActivity2.newWTChangeActivity2();
        
        //Single item tests
        createChangeRecord(activity, "1045");
        assertFalse(ChangeTaskUtils.isReleaseTarget(activity, "1050", "1070"));
        
        createChangeRecord(activity, "1050");
        assertTrue(ChangeTaskUtils.isReleaseTarget(activity, "1050", "1070"));
        
        createChangeRecord(activity, "1075");
        assertTrue(ChangeTaskUtils.isReleaseTarget(activity, "1050", "1070"));
          
        createChangeRecord(activity, "1080");
        assertTrue(ChangeTaskUtils.isReleaseTarget(activity, "1050", "1070"));
        
        //Multi item tests
        createChangeRecord(activity, "1045", "1030");
        assertFalse(ChangeTaskUtils.isReleaseTarget(activity, "1050", "1070"));
        
        createChangeRecord(activity, "1040", "1050");
        assertTrue(ChangeTaskUtils.isReleaseTarget(activity, "1050", "1070"));
        
        createChangeRecord(activity, "1020", "1075");
        assertTrue(ChangeTaskUtils.isReleaseTarget(activity, "1050", "1070"));
          
        createChangeRecord(activity, "1045", "1080");
        assertTrue(ChangeTaskUtils.isReleaseTarget(activity, "1050", "1070"));
    }
    
    private void createChangeRecord(final ChangeActivity2 activity, final String... transition) throws Exception {
        
        new NonStrictExpectations() {
            {
                WTPart p = new WTPart();
                p.setState(new LifeCycleState());
                p.getState().setState(State.toState("1030"));
                QueryResult res = new QueryResult();
                ObjectVector vec = new ObjectVector();
                for (String t : transition) {
                    ChangeRecord2 rec = ChangeRecord2.newChangeRecord2(p, activity);
                    rec.setTargetTransition(Transition.toTransition(t));
                    vec.addElement(rec);
                }
                res.append(vec);
                changeService.getChangeablesAfter(activity, false);
                returns(res);
            }
        };
    }
}
