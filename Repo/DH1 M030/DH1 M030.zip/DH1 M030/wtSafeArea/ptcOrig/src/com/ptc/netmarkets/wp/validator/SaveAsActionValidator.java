/* bcwti
 *
 * Copyright (c) 2010 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */
package com.ptc.netmarkets.wp.validator;

import java.util.Locale;

import org.apache.log4j.Logger;

import wt.facade.contentcontrol.ContentControlStateHelper;
import wt.facade.persistedcollection.PersistedCollectionHelper;
import wt.fc.Persistable;
import wt.fc.WTReference;
import wt.filter.common.FilterHelper;
import wt.log4j.LogR;
import wt.type.TypedUtility;
import wt.util.WTException;
import wt.util.WTMessage;

import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.percolui.PersistedCollectionHolderValidationHelper;
import com.ptc.core.percolui.percoluiResource;
import com.ptc.core.ui.resources.FeedbackType;
import com.ptc.core.ui.validation.DefaultUIComponentValidator;
import com.ptc.core.ui.validation.UIValidationCriteria;
import com.ptc.core.ui.validation.UIValidationFeedbackMsg;
import com.ptc.core.ui.validation.UIValidationKey;
import com.ptc.core.ui.validation.UIValidationResult;
import com.ptc.core.ui.validation.UIValidationResultSet;
import com.ptc.core.ui.validation.UIValidationStatus;
import com.ptc.netmarkets.wp.wpResource;
import com.ptc.windchill.wp.AbstractWorkPackage;
import com.ptc.windchill.wp.WPHelper;
import com.ptc.windchill.wp.WPValidationHelper;
import com.ptc.windchill.wp.rep.ReplicationPackage;

// TODO: Auto-generated Javadoc
/**
 * Validator for the "Save As" action.
 *
 * <BR>
 * <BR>
 * <B>Supported API: </B>false <BR>
 * <BR>
 * <B>Extendable: </B>false
 */
public class SaveAsActionValidator extends DefaultUIComponentValidator {
    
    /** The Constant logger. */
    private static final Logger logger = LogR.getLogger(SaveAsActionValidator.class.getName());
            
            /** The Constant SELECTED. */
            static final String SELECTED = "on";
            
            /** The Constant REFRESH_AFTER_COPY. */
            static final String REFRESH_AFTER_COPY = "refresh_after_copy";
    
    /** The Constant RESOURCE. */
    private static final String RESOURCE = "com.ptc.netmarkets.wp.wpResource";
    
    /** The Constant PERCOLUI_RESOURCE. */
    private static final String PERCOLUI_RESOURCE = "com.ptc.core.percolui.percoluiResource";
    
    /* (non-Javadoc)
     * @see com.ptc.core.ui.validation.DefaultUIComponentValidator#performFullPreValidation(com.ptc.core.ui.validation.UIValidationKey, com.ptc.core.ui.validation.UIValidationCriteria, java.util.Locale)
     */
    @Override
    public UIValidationResultSet performFullPreValidation(UIValidationKey validationKey,
             UIValidationCriteria validationCriteria, Locale locale) throws WTException {
        logger.trace("Entering SaveAsActionValidator.");
        
        UIValidationResultSet resultSet = UIValidationResultSet.newInstance();
    
        Object target = validationCriteria.getContextObject().getObject();

        if (ReplicationPackage.class.isAssignableFrom(target.getClass())) {
            logger.debug("Hiding SaveAs action for replication package.");
            resultSet.addResult(UIValidationResult.newInstance(validationKey, UIValidationStatus.HIDDEN));
        } else {
            UIValidationStatus status = UIValidationStatus.ENABLED;
            WTReference ref = validationCriteria.getContextObject();
            if (ref != null) {
                Persistable persistObj = ref.getObject();
                if (persistObj instanceof AbstractWorkPackage) {
                    AbstractWorkPackage wp = (AbstractWorkPackage) persistObj;
                    TypeIdentifier typeId = TypedUtility.getTypeIdentifier(wp);
                    if (!WPHelper.hasCreatePermission(wp.getDomainRef(), typeId) && !WPHelper.service.isPackageDomainDisplayEnabled(validationCriteria.getParentContainer())) {
                        status = UIValidationStatus.HIDDEN;
                    } else if (ContentControlStateHelper.isContentControlInTransitionState(wp)) {
                        status = UIValidationStatus.DISABLED;
                    }
                }
            }
            logger.debug("Showing SaveAs action for non-replication package.");
            resultSet.addResult(UIValidationResult.newInstance(validationKey, status));
        }
        
        logger.trace("Exiting SaveAsActionValidator.");
        return resultSet;
    }

    /**
     * Validates whether or not the save as package action should be allowed to proceed.
     * 
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     *
     * @param validationKey A UIValidationKey object representing the action or UI component to be validated.
     * @param validationCriteria Object holding information required to perform validation tasks.
     * @param locale The user's Locale. If a <i>null</i> value is passed in, the session locale will be used.
     * @return UIValidationResult
     * @throws WTException the wT exception
     */
    @Override
    public UIValidationResult validateSelectedAction(UIValidationKey validationKey,
            UIValidationCriteria validationCriteria, Locale locale) throws WTException {

        UIValidationResult result = null;
        String msg = null;
        UIValidationFeedbackMsg feedbackMsg = null;
        AbstractWorkPackage pkg = ValidatorHelper.getWorkPackage(validationCriteria);
        if (pkg != null) {
            if (ContentControlStateHelper.isContentControlInTransitionState(pkg)) {
                msg = WTMessage.getLocalizedMessage(RESOURCE,
                        wpResource.CANNOT_COPY_PKG_WITH_IN_TRANSITION_STATE);
            }

            if (msg != null) {
                feedbackMsg = UIValidationFeedbackMsg.newInstance(msg, FeedbackType.FAILURE);
                result = UIValidationResult.newInstance(validationKey, UIValidationStatus.DENIED, feedbackMsg);
            }
        }

        if (result == null) {
            result = super.validateSelectedAction(validationKey, validationCriteria, locale);
        }
        return result;
    }
    
    /**
     * Validates for inaccessible seed or member objects associated to a given package and provides the user with
     * confirmation message if the package contains seed or member objects to which the user does not have access.
     * This method makes method server calls.
     * 
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     *
     * @param validationKey A UIValidationKey object representing the action or UI component to be validated.
     * @param validationCriteria Object holding information required to perform validation tasks.
     * @param locale The user's Locale. If a <i>null</i> value is passed in, the session locale will be used.
     * @return UIValidationResult
     * @throws WTException the wT exception
     */
    @Override
    public UIValidationResult validateFormSubmission(UIValidationKey validationKey,
             UIValidationCriteria validationCriteria, Locale locale) throws WTException {
       
       final AbstractWorkPackage pkg = ValidatorHelper.getWorkPackage(validationCriteria);
       if (pkg == null)
          return super.validateSelectedAction(validationKey, validationCriteria, locale);
       
       // Determine accessibility of seeds and filters.
       final boolean hasInaccessibleSeed = !PersistedCollectionHelper.service.hasSeedAccess(pkg);
       final boolean hasInaccessibleFilter = FilterHelper.hasNonAccessibleFilter( PersistedCollectionHelper.service.getExpansionCriteria(pkg) );

       // Construct feedback message for inaccessible package elements.
       String message = "";
       if (hasInaccessibleSeed && hasInaccessibleFilter)
          message = WTMessage.getLocalizedMessage(PERCOLUI_RESOURCE, percoluiResource.SAVE_AS_NO_ACCESS_TO_SEEDS_AND_COLLECTION_OPTIONS_CONFIRMATION_MESSAGE, null, locale);

       else if (hasInaccessibleSeed)
          message = WTMessage.getLocalizedMessage(PERCOLUI_RESOURCE, percoluiResource.SAVE_AS_NO_ACCESS_TO_SEEDS_CONFIRMATION_MESSAGE, null, locale);

       else if (hasInaccessibleFilter)
          message = WTMessage.getLocalizedMessage(PERCOLUI_RESOURCE, percoluiResource.SAVE_AS_NO_ACCESS_TO_COLLECTION_OPTIONS_CONFIRMATION_MESSAGE, null, locale);

       else if (!PersistedCollectionHelper.service.hasAllMemberAccess(pkg)) {
          if (isRefreshSelected(validationCriteria))
             message = WTMessage.getLocalizedMessage(PERCOLUI_RESOURCE, percoluiResource.REFRESH_CONFIRMATION_MESSAGE_NO_ACCESS_TO_MEMBERS, null, locale);
          else
             message = WTMessage.getLocalizedMessage(RESOURCE, wpResource.WP_SAVE_AS_CONFIRMATION_MESSAGE_NO_ACCESS_TO_MEMBERS, null, locale);
       } 

       else if (WPValidationHelper.hasExcludeSeedTypes(pkg))
          message = WTMessage.getLocalizedMessage(RESOURCE, wpResource.EXCLUDED_SEED_TYPES, null, locale);
       
       else if (WPHelper.hasDeliveryWithDeletedRecipient(pkg))
           message = WTMessage.getLocalizedMessage(RESOURCE, wpResource.RECIPIENT_INVALID_CONFIRMATION_MESSAGE_FOR_SAVE_AS_PACKAGE, null, locale);

       else if (WPHelper.hasDeliveryWithDeletedSender(pkg))
           message = WTMessage.getLocalizedMessage(RESOURCE, wpResource.SENDER_INVALID_CONFIRMATION_MESSAGE_FOR_SAVE_AS_REVISE_ITERATE_PACKAGE, null, locale);

       // Add message if a refresh will cause package to lose its re-filter ability.
       if (isRefreshSelected(validationCriteria)  &&  PersistedCollectionHelper.service.hasFilterState(pkg)  &&  !WPHelper.service.getRetainCollectionResults(pkg))
          message = PersistedCollectionHolderValidationHelper.appendMessage(message, true, PERCOLUI_RESOURCE, percoluiResource.LOSING_REFILTERING_ABILITY, null, locale);

       return PersistedCollectionHolderValidationHelper.promptedValidationResult(validationKey, message, locale);
    }

    /**
     * Checks if is refresh selected.
     *
     * @param validationCriteria the validation criteria
     * @return true, if is refresh selected
     */
    private boolean isRefreshSelected(UIValidationCriteria validationCriteria) {
        boolean result = false;
        String refreshOption = null;
        Object obj = validationCriteria.getFormData().get(REFRESH_AFTER_COPY);
        if (obj instanceof String) {
            refreshOption = (String) obj;
        } else if (obj instanceof String[]) {
            refreshOption = ((String[]) obj)[0];
        }

        if (refreshOption != null && SELECTED.equalsIgnoreCase(refreshOption)) {
            result = true;
        }

        return result;
    }
}
