/**
 * bcwti
 *
 * Copyright (c) 2012 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC and is subject to the terms of a software
 * license agreement. You shall not disclose such confidential information and shall use it only in accordance with
 * the terms of the license agreement.
 *
 * ecwti
 *
 **/
package com.ptc.windchill.enterprise.businessRules;

import wt.util.resource.RBArgComment0;
import wt.util.resource.RBComment;
import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("com.ptc.windchill.enterprise.businessRules.businessRulesClientResource")
public final class businessRulesClientResource extends WTListResourceBundle {

    @RBEntry("No release target defined for the current state.")
    public static final String NO_TRANSITIONS_DEFINED = "NO_TRANSITIONS_DEFINED";

    @RBEntry("The release target specified is not valid for the current state.")
    public static final String SPECIFIED_TRANSITION_MISSING = "SPECIFIED_TRANSITION_MISSING";
    
    @RBEntry("Business Rules")
    @RBComment("The name of the preference category for business rules")
    public static final String BUSINESS_RULES_CATEGORY = "BUSINESS_RULES_CATEGORY";
    
    @RBEntry("Business Rules Preferences")
    @RBComment("Message displayed when loading the business rules preferences during install")
    public static final String BUSINESS_RULES_CATEGORY_PREF = "BUSINESS_RULES_CATEGORY_PREF";
    
    @RBEntry("BOM Maturity Release Collector")
    @RBComment("BOM Maturity Release is a business rule with an associated collector configuration.  This is the name of the preference category for the collector configuration.")
    public static final String BOM_RELEASE_COLLECTOR = "BOM_RELEASE_COLLECTOR";
    
    @RBEntry("BOM Maturity Release Collector Rule")
    @RBComment("The description in the preference manager for the BOM Maturity Release Collector preference category")
    public static final String BOM_RELEASE_COLLECTOR_DESC = "BOM_RELEASE_COLLECTOR_DESC";

    @RBEntry("The life cycle state of one or more associated objects is not valid for releasing the target object. Valid life cycle states are: {0}.")
    @RBArgComment0("The list of valid states")
    @RBComment("Error message for the BOM Maturity Release business rule.")
    public static final String CHILD_INVALID_STATE = "CHILD_INVALID_STATE";

    @RBEntry("The life cycle state of the target transition of one or more associated objects that are being released is not valid. Valid life cycle states are: {0}.")
    @RBArgComment0("The list of valid target states")
    @RBComment("Error message for the BOM Maturity Release business rule.")
    public static final String CHILD_TARGET_STATE_INVALID = "CHILD_TARGET_STATE_INVALID";

    @RBEntry("Rule Conflicts")
    @RBComment("Table title containing the Business Rule conflicts.")
    public static final String RULE_CONFLICTS = "RULE_CONFLICTS";

    @RBEntry("Conflicts")
    @RBComment("Table column title containing the Business Rule conflicts.")
    public static final String CONFLICTS = "CONFLICTS";
    
    @RBEntry("Group by Rule")
    @RBComment("Rule conflict table view name for displaying the conflicts by business rule name.")
    public static final String GROUP_BY_RULE = "GROUP_BY_RULE";

    @RBEntry("Displays the conflicts by business rule name.")
    @RBComment("Description for the Group by Rule table view.")
    public static final String GROUP_BY_RULE_DESC = "GROUP_BY_RULE_DESC";
    
    @RBEntry("Group by Object")
    @RBComment("Rule conflict table view name for displaying the conflicts by object.")
    public static final String GROUP_BY_OBJECT = "GROUP_BY_OBJECT";
    
    @RBEntry("Displays the conflicts by object.")
    @RBComment("Description for the Group by Object table view.")
    public static final String GROUP_BY_OBJECT_DESC = "GROUP_BY_OBJECT_DESC";
    
    @RBEntry("Rule Execution Conflicts")
    @RBComment("Short description for conflicts found while executing the business rules.  These conflicts are due to a misconfiguration of the business rules or an error that is not expected.")
    public static final String RULE_EXECUTION_CONFLICTS = "RULE_EXECUTION_CONFLICTS";

    @RBEntry("Rule Name")
    @RBComment("The column name for displaying the business rule name with objects that have rule conflicts.")
    public static final String RULE_NAME = "RULE_NAME";
    
    @RBEntry("Identity")
    @RBComment("The column name for displaying the identity of an object with business rule conflicts.")
    public static final String BUSINESS_RULE_OBJECT_IDENTITY = "BUSINESS_RULE_OBJECT_IDENTITY"; 
    
    @RBEntry("Rule Sets")
    @RBComment("The name of the table displaying loaded business rule sets.")
    public static final String BUSINESS_RULE_SETS = "BUSINESS_RULE_SETS";

    @RBEntry("Order")
    @RBComment("The block order for the business rule within a business rule set.")
    public static final String BLOCK_ORDER = "BLOCK_ORDER";
    
    @RBEntry("Secured Action. You do not have the necessary authorization for this page. Contact your administrator if you believe you have received this message in error.")
    @RBComment("Secured Action. You do not have the necessary authorization for this page. Contact your administrator if you believe you have received this message in error.")
    public static final String NO_ACCESS_ERROR = "NO_ACCESS_ERROR";
}