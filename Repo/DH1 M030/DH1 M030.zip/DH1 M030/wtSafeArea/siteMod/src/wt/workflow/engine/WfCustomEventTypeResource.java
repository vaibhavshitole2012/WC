package wt.workflow.engine;

import wt.util.resource.RBEntry;
import wt.util.resource.RBNameException;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("wt.workflow.engine.WfCustomEventTypeResource")
@RBNameException
public final class WfCustomEventTypeResource
  extends WTListResourceBundle
{
  @RBEntry("Default")
  public static final String DEFAULT = "0";
  
  public WfCustomEventTypeResource() {}
  
  @RBEntry("POST_PUBLISH_COMPLETED")
  public static final String POST_PUBLISH_COMPLETED = "POST_PUBLISH_COMPLETED";
  
  
}
