/* bcwti
 *
 * Copyright (c) 2010 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */

package wt.enterprise;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.ResourceBundle;
import java.util.Vector;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.spi.LoggingEvent;

import wt.access.AccessControlHelper;
import wt.access.AccessPermission;
import wt.content.ContentHTTPStream;
import wt.fc.ObjectNoLongerExistsException;
import wt.fc.ReferenceFactory;
import wt.fc.WTReference;
import wt.htmlutil.HTMLTemplate;
import wt.htmlutil.HtmlUtil;
import wt.htmlutil.TemplateName;
import wt.httpgw.CGIConstants;
import wt.httpgw.HTTPRequest;
import wt.httpgw.HTTPResponse;
import wt.httpgw.LanguagePreference;
import wt.inf.container.WTContained;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerHelper;
import wt.inf.container.WTContainerRef;
import wt.log4j.LogR;
import wt.method.MethodContext;
import wt.services.applicationcontext.UnableToCreateServiceException;
import wt.servlet.ServletState;
import wt.session.SessionContext;
import wt.templateutil.processor.DefaultHTMLTemplateFactory;
import wt.templateutil.processor.FormTaskDelegate;
import wt.templateutil.processor.FormTaskDelegateFactory;
import wt.templateutil.processor.HTTPState;
import wt.util.EncodingConverter;
import wt.util.HTMLEncoder;
import wt.util.LocalizableMessage;
import wt.util.MPInputStream;
import wt.util.WTContext;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.WTProperties;
import wt.util.WTRuntimeException;
import wt.workflow.work.WorkItemURLProcessor;

/**
 * Deprecation Notice: This class is still valid for this release, however
 * this serves as advance notice that it will be removed in the future.
 *  All user interfaces built using the Windchill HTML Template Processing
 * client architecture will be rewritten using a different framework in
 * an upcoming release.
 *
 * This class is a "Gateway" for the HTML client; by "Gateway", it is meant
 * that there are methods in this class that can be referenced directly
 * by URLs pointing to the Windchill method server, independent of whether
 * CGI or Servlets are being used. Any method that would like to be available
 * directly via a URL needs to implement the following signature :
 * <p>
 * <code>
 * public static void <em>Method Name</em>( wt.httpgw.HTTPRequest req, wt.httpgw.HTTPResponse
 * resp )<BR>
 *                    throws <em>List of exceptions</em> {
 * </code>
 * <p>
 * The method will be available via URL using a URL that looks like:<BR>
 * <code>
 * http://<em>Windchill Method Server Address</em>/<em>Class Name</em>/<em>Method
 * Name</em>
 * </code>
 * <p>
 * In the case that the Windchill home page is at http://smith.ptc.com/WindchillGW,
 * the URL that would reference the method processForm of this class would
 * look like:<BR>
 * <code>
 * http://smith.ptc.com/WindchillGW/URLProcessor/processForm
 * </code>
 * <p>
 * This class defines several methods that receive the HTTP request, process
 * the request if necessary, and generate a response page. These "Gateway"
 * methods below each perform this general functionality, but each has a
 * specific purpose that is described in the method JavaDoc.
 *
 *
 * <BR><BR><B>Supported API: </B>true
 * <BR><BR><B>Extendable: </B>false
 *
 * @deprecated
 *
 * @version   1.0
 **/
public class URLProcessor {
   private static final String RESOURCE = "wt.enterprise.enterpriseResource";
   private static final String CLASSNAME = URLProcessor.class.getName();

   private static final Logger  logger = LogR.getLogger( CLASSNAME );

   private static boolean VERBOSE;
   private static boolean isOnDemand;
   private static final boolean  omitDetailedErrorMessage;
   private static final ResourceBundle rb;

   public static final String NAME_HDR = "name";

   public static final String ACTION                  = "ACTION";
   public static final String CLASS                   = "CLASS";
   public static final String OID                     = "OID";
   public static final String NULL_ACTION             = "NullAction";
   public static final String UPDATE_COUNT            = "UPDATECOUNT";
   static
   {
     try
     {
       final WTProperties  properties = WTProperties.getLocalProperties();
       VERBOSE = properties.getProperty( "wt.enterprise.verbose", false );
       VERBOSE = properties.getProperty( "wt.enterprise.URLProcessor.verbose", VERBOSE );
       isOnDemand = properties.getProperty( "wt.inf.container.onDemand", false );
       omitDetailedErrorMessage = "true".equals( properties.getProperty( "wt.enterprise.URLProcessor.omitDetailedErrorMessage" ) );
       rb = ResourceBundle.getBundle( RESOURCE, WTContext.getContext().getLocale() );
     }
     catch ( Throwable t )
     {
       final Object[]  param = { CLASSNAME };
       System.err.println( WTMessage.getLocalizedMessage( RESOURCE, enterpriseResource.ERROR_INITIALIZING, param ) );
       t.printStackTrace( System.err );
       throw new ExceptionInInitializerError( t );
     }
   }

   /**
    * This gateway method should be used to generate HTML pages that present
    * views of data.
    *      This gateway method should not be used to process HTML Forms
    * or generate HTML Forms. There
    *      are a few existing exceptions, but they should remain exceptions.
    *
    *      <BR>
    *      <BR>
    *
    *      This method will accept a the standard HTTP Get that has a query
    * String attached to
    *      the URL. This method will also accept an HTTP Post request. This
    * method WILL NOT
    *      accept an HTTP Post with enc-type set for a multipart post. An
    * exception will be thrown
    *      in this case.
    *
    *      <BR>
    *      <BR>
    *
    *      This gateway method, as with all gateway methods in this class,
    * require that a
    *      parameter with the name action be passed in either the query
    * string or the
    *      Form data of the HTTP Post. If no value for an action parameter
    * is sent, an
    *      exception is thrown.
    *
    *      <BR>
    *      <BR>
    *
    *      The template processor that is used to process this request is
    * retrieved using the
    *      wt.enterprise.TemplateProcessorFactory. This factory will locate
    * the TemplateProcessor
    *      subclass to use based on value of the action parameter and either
    * the class of the oid
    *      passed in or the class of the class parameter passed in.
    *
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @deprecated
    *
    * @param     req
    * @param     resp
    * @exception wt.util.WTException
    **/
   public static void URLTemplateAction( HTTPRequest req, HTTPResponse resp )
            throws WTException {
     HTTPState httpState = null;
     try
     {
        if (VERBOSE)
        {
          System.out.println("Entering URLProcessor.URLTemplateAction()...");
          System.out.println("Type of HTTP request is GET = " + req.isGetRequest() );
          System.out.println("           request properties  -------> ");
          req.listProperties(new java.io.PrintWriter(System.out));
        }

        httpState = new HTTPState();
        httpState.setRequestObj( req );
        httpState.setResponseObj( resp );

        if ( req.isPostRequest() )
        {
           if ( req.getProperty( CGIConstants.CGI_MULTIPART_BOUNDARY ) != null  )
            {
                String message = WTMessage.getLocalizedMessage(RESOURCE,enterpriseResource.URL_POST_ERROR,null);
                throw new WTException( message );
            }
        }
        httpState.setFormData(req.getFormData());
        httpState.setFormDataMultivalue( req.getFormDataMultivalue() );
        //      HashMap map = httpState.getURLFactory().parseQueryString(httpState.getRequestObj().getQueryString());
        //      Properties props = new Properties();
        //      props.putAll(map);
        httpState.setQueryData( httpState.getRequestObj().splitQueryString() );

        readContextStatic( httpState );

        if (VERBOSE) {
          System.out.println("  query string: " + httpState.getQueryData().toString());
          System.out.println("  action is: " + httpState.getContextAction() );
          System.out.println("  contextObject: " + httpState.getContextObj() );
          System.out.println("  contextClass: " + httpState.getContextClassName() );
        }

        TemplateProcessorFactory factory = new TemplateProcessorFactory();
        TemplateProcessor tp = null;
        if ( httpState.getContextObj() != null )
        {
            tp = factory.getTemplateProcessor( httpState.getContextAction(), httpState.getContextObj() );
        }
        else
        {
            tp = factory.getTemplateProcessor( httpState.getContextAction(), httpState.getContextClassName() );
        }
        if (VERBOSE) {
          System.out.println("  TemplateProcessor from factory -> " + tp);
          System.out.println("  tp.getClass().getName() -> " +
                             tp.getClass().getName());
        }

        // This is done remove any spurrious context that was created only for the purposes of
        // using the factories
        if ( httpState.getQueryData().getProperty( OID ) == null || httpState.getQueryData().getProperty( OID ).equals( "" ) )
        {
          if ( httpState.getFormData().getProperty( OID ) == null || httpState.getFormData().getProperty( OID ).equals( "" ))
          {
             httpState.setContextObj( null );
          }
        }

        req.bizData = httpState;

        if ( tp instanceof BasicTemplateProcessor )
        {
          ((BasicTemplateProcessor)tp).setState( (HTTPState)httpState );
        }
        try
        {
          tp.handleRequest((wt.httpgw.HTTPRequest)req, (wt.httpgw.HTTPResponse)resp);
        }
        catch (Exception e)
        {
          if(e instanceof URLProcessorException)
             ((URLProcessorException) e).handleException(req, resp, httpState);
          else
             handleException(req, resp, e);
        }
     }
     catch ( WTException wte)
     {
       handleException(req, resp, wte);
     }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @deprecated
    *
    * @param     params
    * @param     locale
    * @param     os
    * @param     contextObject
    * @exception wt.util.WTException
    **/
   public static void handleIncludeRequest( Properties params, Locale locale, OutputStream os, Object contextObject )
            throws WTException {
    if (VERBOSE) {
      System.out.println("Entering URLProcessor.handleIncludeRequest()...");
    }

    String action;
    String template;
    TemplateProcessorFactory factory;

    try {
      action = parameterValue(params, "action");
    } catch (WTException e) {
      throw e;
    }
    try {
      template = parameterValue(params, "template");
    } catch (WTException e) {
      // template is optional.  If it is not supplied, just set it to null.
      template = null;
    }

    try {
      factory = new TemplateProcessorFactory();
    } catch (wt.services.applicationcontext.implementation.UnableToLoadServiceProperties e) {
      throw e;
    }
    // The following declaration is temporary.
    // Once TemplateProcessor (or some subclass) contains
    // the handleIncludeRequest() method, then tp can be defined to
    // be of type TemplateProcessor (or some subclass).
    //
    // Currently, the only template processor that includes
    // handleIncludeRequest is ObjectPropertiesProcessor.
    ObjectPropertiesProcessor tp = (ObjectPropertiesProcessor)
      factory.getTemplateProcessor(action, contextObject);
    if (VERBOSE) {
      System.out.println("  TemplateProcessor from factory -> " + tp);
      System.out.println("  tp.getClass().getName() -> " +
                         tp.getClass().getName());
    }
    tp.handleIncludeRequest(params, locale, os, contextObject, template);
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @deprecated
    *
    * @param     req
    * @param     resp
    * @param     e
    * @exception wt.util.WTException
    **/
   public static void handleException( HTTPRequest req, HTTPResponse resp, Exception e )
            throws WTException {
    resp.setHeader( "Content-Type", "text/html;charset=UTF-8" );
    OutputStream os = null;
    try {
      os = resp.getOutputStream();
    } catch (java.io.IOException ioe) {
      resp.setStatus(400);    //Status = No Content
      throw new WTException(ioe);
    }

    PrintWriter out = null;
    try {
      out = new PrintWriter( new OutputStreamWriter( os, "UTF-8" ) );
    } catch (java.io.UnsupportedEncodingException ue) {
      throw new RuntimeException( "Noncompliant JVM -- does not support UTF-8 encoding!", ue );  // should never happen
    }

    String text = WTMessage.getLocalizedMessage( RESOURCE, enterpriseResource.TP_FAILED_MESSAGE, new Object[0], getLocale(req));

    hanldleHTMLError(out,
                     rb.getString(enterpriseResource.TP_FAILED_TITLE),
                     text, e);
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @deprecated
    *
    * @param     request
    * @return    Locale
    **/
   public static Locale getLocale( HTTPRequest request ) {
        String acceptLanguage = request.getProperty(request.CGI_ACCEPT_LANGUAGE);
        Vector preferences = null;
        try
        {
            preferences =
                    LanguagePreference.getAcceptLanguagePreferences(acceptLanguage);

            wt.htmlutil.HTMLTemplate template = new wt.htmlutil.HTMLTemplate(
                                                wt.htmlutil.TemplateName.getWindchill ("windchill"));
            template.init (preferences);
            return template.getLocale();
        }
        catch ( wt.util.WTException wte)
        {
            wte.printStackTrace();
            return null;
        }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @deprecated
    *
    * @param     params
    * @param     paramName
    * @return    String
    * @exception wt.util.WTException
    **/
   public static String parameterValue( Properties params, String paramName )
            throws WTException {
    String result = params.getProperty(paramName);
    if (VERBOSE) {
      System.out.println("parameterValue() " + paramName + " is " + result);
    }
    boolean paramsOK = true;
    String badParamsMsg = null;

    if (result == null)   {
      paramsOK = false;

      Object[] param1 = {paramName, "null"};
      badParamsMsg = WTMessage.getLocalizedMessage(
                             RESOURCE,
                             enterpriseResource.PARAMETER_IS,
                             param1);
      if (VERBOSE) {
        System.out.println("badParamsMsg -> " + badParamsMsg);
      }

      //If we received bad parameters we can't continue (BAIL OUT!)
      Object[] param2 = {badParamsMsg};

      String message = WTMessage.getLocalizedMessage(
                             RESOURCE,
                             enterpriseResource.BAD_PARAMETERS,
                             param2);
      throw new WTException(message);
    }
    return result;
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @deprecated
    *
    * @param     out
    * @param     title
    * @param     text
    * @param     e
    **/
   public static void hanldleHTMLError( PrintWriter out, String title, String text, Exception e )
   {
      // obtain current time, request id, and method context id
      final long  now = System.currentTimeMillis();
      final Object  requestId = ServletState.getServletRequestId();
      Object  methodContextId;
      try
      {
        methodContextId = MethodContext.getContext().getId();
      }
      catch ( Throwable t )
      {
        if ( t instanceof VirtualMachineError )
          throw (VirtualMachineError) t;
        methodContextId = null;
      }

      // log exception along with request and method context ids, etc
      if ( logger.isEnabledFor( Level.ERROR ) )  // we almost shouldn't check here as we really want this to be logged in all cases, but an administrator might have other ideas...
      {
        final String  remoteAddr = ServletState.getRemoteAddr();
        final Object  servletRequest = ServletState.getServletRequest();
        final String  logMessage = "Exception occurred for request: " + requestId + "; method context: " + methodContextId +
                                   "; remote addr: " + remoteAddr +
                                   ( ( servletRequest instanceof HttpServletRequest )
                                         ? "; request URI: " + ((HttpServletRequest)servletRequest).getRequestURI() +
                                           "; query string: " + ((HttpServletRequest)servletRequest).getQueryString()
                                         : "" );
        // invoke callAppenders ourselves so as to provide exactly the same timestamp as that provided to end user
        logger.callAppenders( new LoggingEvent( Logger.class.getName(), logger, now, Level.ERROR, logMessage, e ) );
      }

      // output HTML error notice

      out.println(HtmlUtil.beginHtml(title));
      out.println(HtmlUtil.createBase());
      out.println(HtmlUtil.insertHeading("h2", null , text));
      out.println( "<table><tbody>" );
      // output requestId and methodContextId
      outputErrorTableRow( out, enterpriseResource.REQUEST_ID, requestId );
      outputErrorTableRow( out, enterpriseResource.METHOD_CONTEXT_ID, methodContextId );
      // output error message unless this is being omitted
      if ( !omitDetailedErrorMessage )
        outputErrorTableRow( out, enterpriseResource.ERROR_MESSAGE, e.getLocalizedMessage() );
      out.println( "</tbody></table>" );
      // output current time
      out.print( "<p style='font-style: italic; font-size: small'>" );
      out.print( HTMLEncoder.encodeAndFormatForHTMLContent( rb.getString( enterpriseResource.CURRENT_TIME ) ) );
      out.print( ": " );
      final SimpleDateFormat  dateFormat = new SimpleDateFormat( "yyyy-MM-dd HH:mm:ss.SSS Z" );
      dateFormat.setTimeZone( WTContext.getContext().getTimeZone() );
      out.print( HTMLEncoder.encodeAndFormatForHTMLContent( dateFormat.format( new Date( now ) ) ) );
      out.println( "</p>" );
      out.println(HtmlUtil.endHtml());
      out.flush();
   }

   private static void  outputErrorTableRow( final PrintWriter out, final String headingKey, final Object text )
   {
      out.println( "<tr valign='top'>" );
      out.print( "<th align='right' scope='row' nowrap='nowrap'>" );
      out.print( HTMLEncoder.encodeAndFormatForHTMLContent( rb.getString( headingKey ) ) );
      out.println( ": </th>" );
      out.print( "<td>" );
      out.print( HTMLEncoder.encodeAndFormatForHTMLContent( ( text != null ) ? text.toString() : "" ) );
      out.println( "</td>" );
      out.println( "</tr>" );
   }

   /**
    *
    *      This "Gateway" method is the first method in a two stage process
    * that is used
    *      to process an HTML form from an HTTP GET/POST request. Multi-part
    * POSTs are
    *      accepted and there is support for uploading content from the
    * HTML form using
    *      the service methods in the wt.content package.
    *
    *      <BR>
    *      <BR>
    *
    *      The first stage of the processing the HTML Form, as performed
    * in this method,
    *      consists of the following actions
    *      <UL>
    *      <LI>Find an ActionDelegate and see if the current user has permission
    * to
    *          submit the current form. If no ActionDelegate is located
    * for the current
    *          action, then it is assumed to be permission/state independent
    *      <LI>Locate a subclass of wt.templateutil.processor.FormTaskDelegate
    * using
    *          the FormTaskDelegateFactory and use that subclass of FormTaskDelegate
    *          to process this request.
    *      </UL>
    *      In the FormTaskDelegate, the HTTPState object should be updated
    * based on
    *      the result of processing the HTML Form. The updated HTTPState
    * object will
    *      be used in the second stage of the Form processing to select
    * and process
    *      the response page.
    *
    *      <BR>
    *      <BR>
    *
    *      This gateway method, as with all gateway methods in this class,
    * require that a
    *      parameter with the name action be passed in either the query
    * string or the
    *      Form data of the HTTP Post. If no value for an action parameter
    * is sent, an
    *      exception is thrown.
    *
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @deprecated
    *
    * @param     request
    * @param     response
    * @param     is
    * @exception wt.util.WTException
    **/
   public static void processForm( HTTPRequest request, HTTPResponse response, InputStream is )
            throws WTException {
      try
      {
        ContentHTTPStream contentStream = null;
        Properties multiPartProps = null;
        Hashtable multiPartMultiProps = null;

        HTTPState httpState = new HTTPState();
        httpState.setRequestObj( request );
        httpState.setResponseObj( response );

        httpState.setQueryData( request.splitQueryString( request.getProperty( CGIConstants.CGI_QUERY_STRING, "" ) , request.getEncoding() ) );

        if ( request.getProperty( CGIConstants.CGI_MULTIPART_BOUNDARY ) == null )
        {
            httpState.setFormData( request.getFormData() );
            httpState.setFormDataMultivalue( request.getFormDataMultivalue() );
        }

        else
        {
            multiPartProps = new Properties();
            multiPartMultiProps = new Hashtable();
            MPInputStream mis = new MPInputStream( is,
                             request.getProperty( CGIConstants.CGI_MULTIPART_BOUNDARY ) );

            if ( mis == null ) System.out.println( "ERROR - MPInputStream mis is null" );

            // Determine encoding of text in MPInputStream based on encoding of upload html template.
            // TODO - this should really be communicated in the request query string.
            String encoding = null;
            try
            {
               // This will need to be modified to handle a more general method
               // of locating the HTML template
               String acceptLanguage = request.getProperty( request.CGI_ACCEPT_LANGUAGE );
               Vector preferences    = LanguagePreference.getAcceptLanguagePreferences( acceptLanguage );
               String templateName = "windchill";
               HTMLTemplate template = new HTMLTemplate( TemplateName.getWindchill( templateName ) );
               try
               {
                  template.init( preferences );
                  encoding = template.getEncoding();
                  mis.setEncoding( encoding );
               }
               finally
               {
                  template.closeInput();
               }
            }
            catch (Exception e)
            {
               if (VERBOSE)
               {
                  System.err.println("\nFormProcessor.processForm : Exception trying to set MPInputStream encoding\n");
                  e.printStackTrace(); // Ignore
               }
            }
            if ( VERBOSE ) System.out.println( "processForm : Before loop over mis");

            // Might want to make this section of code a method call to
            // allow overriding in a subclass. This section is responsible
            // for getting to the first file to upload. As a side comment
            // it should be documented that the ContentHTTPStream assumes
            // that all content is contiguous

            while ( mis.hasMoreObjectBodies( ) )
            {
               String fieldInputName = mis.getBodyHeader( NAME_HDR );
               if ( VERBOSE ) System.out.println( "VERBOSE: processForm - " + fieldInputName );

               String tmp = mis.readString( ).trim( );
               if ( VERBOSE )
               {
                  System.out.println( "VERBOSE: tmp = " + tmp );
               }

               // break out of the while loop if we get to the beginning of some content
               if ( fieldInputName.equals( "BeginContent" ) )
               {
                  contentStream = new ContentHTTPStream( mis );
                  break;
               }
               multiPartProps.put( fieldInputName, tmp );
               put(multiPartMultiProps, fieldInputName, tmp);
               if (VERBOSE) System.out.println("processForm : intialProps added " + fieldInputName +  " and " + tmp);
            }
            httpState.setFormData( multiPartProps );
            httpState.setFormDataMultivalue( multiPartMultiProps );
        }

        readContextStatic( httpState );
        processAction( httpState, request, contentStream );
      }
      catch ( Exception e )
      {
         request.bizData = e;
      }
   }

   /**
    * This "Gateway" method is the second method in a two stage process
    * that is used
    *      to process an HTML form from an HTTP GET/POST request. Multi-part
    * POSTs are
    *      accepted.
    *
    *      <BR>
    *      <BR>
    *
    *      The second stage of the processing the HTML Form, as performed
    * in this method,
    *      consists of the checking the settings in the HTTPState object,
    * that should have
    *      been updated in FormTaskDelegate, and using these settings to
    * select an appropriate
    *      TemplateProcessor subclass to generate the Response page. The
    * TemplateProcessorFactory
    *      is used to select the desired subclass of TemplateProcessor.
    *
    *      <BR>
    *      <BR>
    *
    *      This gateway method, as with all gateway methods in this class,
    * require that a
    *      parameter with the name action be passed in either the query
    * string or the
    *      Form data of the HTTP Post. If no value for an action parameter
    * is sent, an
    *      exception is thrown.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @deprecated
    *
    * @param     request
    * @param     response
    * @exception wt.util.WTException
    **/
   public static void processForm( HTTPRequest request, HTTPResponse response )
            throws WTException {
     try
     {
        HTTPState httpState = null;

        if ( request.isGetRequest() )
        {
            String message = WTMessage.getLocalizedMessage(RESOURCE,enterpriseResource.PROCESSFORM_POST_ERROR,null);
            throw new WTException( message );
        }
        else if ( request.bizData instanceof Exception )
        {
            throw (Exception)( request.bizData );
        }
        else
        {
            if ( request.bizData == null )
            {
                String message = WTMessage.getLocalizedMessage(RESOURCE,enterpriseResource.PROCESSFORM_NULL_ERROR,null);
                throw new WTException( message );
            }
            else
            {
                httpState = ( HTTPState )request.bizData;
            }
        }

        TemplateProcessor generator = getTemplateProcessorStatic( httpState , request );

        if ( generator instanceof BasicTemplateProcessor )
        {
           ((BasicTemplateProcessor)generator).setState( (HTTPState)httpState );
        }
        generator.handleRequest(request, response);
     }
     catch ( Exception e )
     {
        if ( VERBOSE )
        {
            System.out.println( "VERBOSE: processForm caught exception " + e.getLocalizedMessage( ) );
            e.printStackTrace( );
        }
        handleException( request, response, e );
     }
   }

   /**
    * This "Gateway" method is used to generate HTML pages with HTML Forms
    * in them.
    *      This "Gateway" method can be called using either an HTTP GET
    * or an HTTP POST.
    *      Calling this "Gateway" method with a multi-part POST will result
    * in an exception
    *      being thrown and the page not being generated.
    *
    *      <BR>
    *      <BR>
    *
    *      The generation of the HTML page with the HTML Form in it
    *      consists of the following actions
    *      <UL>
    *      <LI>Find an ActionDelegate and see if the current user has permission
    * to
    *          submit the Form that is to be generated. If no ActionDelegate
    * is located
    *          for the current action, then it is assumed to be permission/state
    * independent
    *      <LI>Locate a subclass of wt.enterprise.TemplateProcessor using
    *          the TemplateProcessorFactory and use that subclass of TemplateProcessor
    *          to process generate the HTML page with the HTML Form in it.
    *      </UL>
    *
    *      <BR>
    *      <BR>
    *
    *      This gateway method, as with all gateway methods in this class,
    * require that a
    *      parameter with the name action be passed in either the query
    * string or the
    *      Form data of the HTTP Post. If no value for an action parameter
    * is sent, an
    *      exception is thrown.
    *
    *      <BR>
    *      <BR>
    *
    *      The template processor that is used to process this request is
    * retrieved using the
    *      wt.enterprise.TemplateProcessorFactory. This factory will locate
    * the TemplateProcessor
    *      subclass to use based on value of the action parameter and either
    * the class of the oid
    *      passed in or the class of the class parameter passed in.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @deprecated
    *
    * @param     request
    * @param     response
    * @exception wt.util.WTException
    **/
   public static void generateForm( HTTPRequest request, HTTPResponse response )
            throws WTException {
      try
      {
         HTTPState httpState = new HTTPState();
         httpState.setRequestObj( request );
         httpState.setResponseObj( response );
         if ( request.isPostRequest() ) {
             if ( request.getProperty( CGIConstants.CGI_MULTIPART_BOUNDARY ) != null  ) {
             String message = WTMessage.getLocalizedMessage(RESOURCE,enterpriseResource.URL_POST_ERROR,null);
             throw new WTException( message );
             }
         }
         httpState.setFormData( request.getFormData() );
         httpState.setFormDataMultivalue( request.getFormDataMultivalue() );
         httpState.setQueryData( request.splitQueryString( request.getProperty( CGIConstants.CGI_QUERY_STRING, "" ) , request.getEncoding() ) );

         try
         {
             readContextStatic( httpState );
         }
         catch ( WTRuntimeException e )
         {
            if ( BasicTemplateProcessor.PDMLinkIsInstalled() ) {
                httpState.setContextAction( "TemplateProcessorError" );
                httpState.addToResponseHeaders( (LocalizableMessage)e );
            } else {
                throw e;
            }
        }
         String action = httpState.getContextAction( ).toUpperCase( );

        if ( VERBOSE ) System.out.println( "VERBOSE: generateForm action = " + action
                        + OID + " = " + httpState.getFormData().getProperty( OID )
                        + CLASS + " = " + httpState.getContextClassName( ) );
        // validate legitimacy of operation ...
        try
        {
          Object obj = httpState.getContextObj();
          if (obj != null )
          {
             if (!(BasicTemplateProcessor.AccessOK(action,obj,request)))
                  throw new WTException( WTMessage.getLocalizedMessage(RESOURCE,enterpriseResource.ACCESS_DENIED_ERROR,null));
          }
        }
        catch (UnableToCreateServiceException e )
        {
            if (VERBOSE)
            {
                System.err.println("\nFormProcessor.generateForm : UnableToCreateServiceException grounded\n\n");
                e.printStackTrace();
            }
            if ( BasicTemplateProcessor.PDMLinkIsInstalled() ) {
                httpState.setContextAction( "TemplateProcessorError" );
                httpState.addToResponseHeaders( (LocalizableMessage)e );
            }
        }
        catch ( WTException e )
        {
            if ( BasicTemplateProcessor.PDMLinkIsInstalled() ) {
                httpState.setContextAction( "TemplateProcessorError" );
                httpState.addToResponseHeaders( (LocalizableMessage)e );
            } else {
                throw e;
            }
        }
        TemplateProcessor generator = getTemplateProcessorStatic( httpState, request );

        // This is done remove any spurrious context that was created only for the purposes of
        // using the factories
        if ( httpState.getQueryData().getProperty( OID ) == null || httpState.getQueryData().getProperty( OID ).equals( "" ) )
        {
           if ( httpState.getFormData().getProperty( OID ) == null || httpState.getFormData().getProperty( OID ).equals( "" ) )
           {
              httpState.setContextObj( null );
           }
        }

        request.bizData = httpState;

        if ( generator instanceof BasicTemplateProcessor )
        {
           ((BasicTemplateProcessor)generator).setState( (HTTPState)httpState );
        }
        generator.handleRequest( request, response );
     }
     catch ( Exception e )
     {
       if ( VERBOSE )
       {
          System.out.println( "VERBOSE: generateForm caught exception " + e.getLocalizedMessage( ) );
          e.printStackTrace( );
       }

       handleException(request, response, e);
     }
   }

   /**
    *
    *      This "Gateway" method is used to process an HTML form from an
    * HTTP GET/POST request.
    *      Multi-part POSTs are NOT accepted and there is NOT support for
    * uploading content from
    *      the HTML form.
    *      <BR>
    *      This method is generally used to process actions that are invoked
    * by clicking on
    *      a URL that has a Query String (i.e. an HTTP GET request). HTTP
    * POST requests
    *      that result from submitting an HTML Form are processed by this
    * "Gateway" method.
    *      However, you should really the processForm "Gateway" method for
    * such a purpose.
    *
    *      <BR>
    *      <BR>
    *
    *      The processing the Action/HTML Form, as performed in this method,
    *      consists of the following actions
    *      <UL>
    *      <LI>Find an ActionDelegate and see if the current user has permission
    * to
    *          submit the current form. If no ActionDelegate is located
    * for the current
    *          action, then it is assumed to be permission/state independent
    *      <LI>Locate a subclass of wt.templateutil.processor.FormTaskDelegate
    * using
    *          the FormTaskDelegateFactory and use that subclass of FormTaskDelegate
    *          to process this request.
    *      <LI>Using the updated state of the HTTPState object, locate a
    * subclass of
    *          TemplateProcessor using the TemplateProcessorFactory. This
    * instance of
    *          a subclass of TemplateProcessor will be used to generate
    * the response page.
    *      </UL>
    *
    *      <BR>
    *      <BR>
    *
    *      This gateway method, as with all gateway methods in this class,
    * require that a
    *      parameter with the name action be passed in either the query
    * string or the
    *      Form data of the HTTP Post. If no value for an action parameter
    * is sent, an
    *      exception is thrown.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @deprecated
    *
    * @param     request
    * @param     response
    * @exception wt.util.WTException
    **/
   public static void invokeAction( HTTPRequest request, HTTPResponse response )
            throws WTException {
      HTTPState httpState = new HTTPState();
      httpState.setRequestObj( request );
      httpState.setResponseObj( response );

      try
      {
        Properties args = null;
    if ( request.isPostRequest() ) {
       if ( request.getProperty( CGIConstants.CGI_MULTIPART_BOUNDARY ) != null  ) {
              String message = WTMessage.getLocalizedMessage(RESOURCE,enterpriseResource.URL_POST_ERROR,null);
            throw new WTException( message );
           }
    }
    httpState.setFormData( request.getFormData() );
    httpState.setFormDataMultivalue( request.getFormDataMultivalue() );
    httpState.setQueryData( request.splitQueryString( request.getProperty( CGIConstants.CGI_QUERY_STRING, "" ) , request.getEncoding() ) );

        readContextStatic( httpState );

        processAction( httpState, request, null );
        if (!(httpState.getContextAction()).equals(URLProcessor.NULL_ACTION)) {
            TemplateProcessor generator = getTemplateProcessorStatic( (HTTPState)(request.bizData), request );

            if ( generator instanceof BasicTemplateProcessor )
               ((BasicTemplateProcessor)generator).setState( (HTTPState)httpState );
            generator.handleRequest( request, response );
        }
      }
      catch ( Exception e )
      {
        if ( VERBOSE ) System.out.println( "VERBOSE: processForm caught exception during invoke : " + e.getLocalizedMessage( ) );
        e.printStackTrace( );

        handleException(request, response, e);
      }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @deprecated
    *
    * @param     httpState
    * @exception wt.util.WTException
    **/
   public static void readContextStatic( HTTPState httpState )
            throws WTException {
       Properties formData = httpState.getFormData();
       formData = copyToUpperCase( formData );
       httpState.setFormData( formData );
       String contentType = formData.getProperty("contentType");
       String language = formData.getProperty("language");
       if(contentType!=null) {
    	   List<String> contentTypeList = new ArrayList<>();
    	   contentTypeList.add(contentType);
           SessionContext.getContext().put("addToPackageProfile", contentTypeList);  
       }
       if(language!=null) {
    	   List<String> languageList = new ArrayList<>();
    	   languageList.addAll(Arrays.asList(language.split(",")));
           SessionContext.getContext().put("addToPackageLanguages", languageList);  
       }
       Hashtable formDataMultivalue = httpState.getFormDataMultivalue();
       formDataMultivalue = copyToUpperCase( formDataMultivalue );
       httpState.setFormDataMultivalue( formDataMultivalue );

       Properties queryData = httpState.getQueryData();
       queryData = copyToUpperCase( queryData );
       httpState.setQueryData( queryData );

       Properties mergeData = new Properties();
       mergeData = mergeProperties( mergeData, queryData );
       mergeData = mergeProperties( mergeData, formData );

       if ( VERBOSE )
         mergeData.list(System.out);

       String action = httpState.getRequestObj().getProperty("cgi.jsp.action");
       if ( action == null )
         action = mergeData.getProperty( "cgi.jsp.action" );  // try in request data
       if ( action == null )
         action = mergeData.getProperty( "jsp.action" );  // try without 'cgi.' prefix
       boolean contextObjectPresent = ( httpState.getContextObj( ) != null );
       if ( VERBOSE )
         System.out.println("contextobjectpresent is " + contextObjectPresent);
       validatePostStringStatic( mergeData, action);

       if ( ( action == null ) || ( action.length() == 0 ) )
         action = mergeData.getProperty( "_" + ACTION );
       if ( action == null )
         action = mergeData.getProperty( ACTION );
       if ( action != null )
       {
         // if 'action' contains comma then it was really multi-valued and we should take first value only
         // this is really a workaround for not having merged the multivalued form data above...
         int  commaIdx = action.indexOf( ',' );
         if ( commaIdx >= 0 )
           action = action.substring( 0, commaIdx );

         httpState.setContextAction(action);
         if (httpState.getContextProperties() == null)
           httpState.setContextProperties(new Properties());
         httpState.getContextProperties().put(HTTPState.ORIGINAL_CONTEXT_ACTION, action);
       }

       // record in the HTTPState object the last know value of the updateCount of the Persistable context object
       // (i.e., its value when the form was generated) as supplied in the query data, if present
       int update_count = 0;
       try {
          update_count = Integer.parseInt(mergeData.getProperty( UPDATE_COUNT ));
       } catch (Exception e) { };
       httpState.setUpdateCount(update_count);

       if ( contextObjectPresent )
       {
          return;
       }
       if (mergeData.getProperty("ufid") != null && !"".equals(mergeData.getProperty("ufid"))) {
       //getting oid from the mechanism that passes it from DCA
         //need a new private method or some refactoring. to avoid duplicating this code if this works...
         String ufid = mergeData.getProperty( "ufid" );

         WTReference ref = wt.federation.FederationUtilities.getObjectRefByUfid(ufid);
         Object obj = null;
         try {
            obj = ref.getObject();
            httpState.setContextObj(obj);

            //add it to the query data so it doesn't get removed later.
            Properties myqueryData = httpState.getQueryData();
            ReferenceFactory rf = new ReferenceFactory();
            myqueryData.put(OID, rf.getReferenceString(ref));
            httpState.setQueryData( queryData );

            if (VERBOSE) System.out.println("Set context object to object from DCA: " + obj);
         } catch (WTRuntimeException re) {
           System.out.println("Caught runtime exception " + re.getMessage());
            Throwable ex = re.getNestedThrowable();
            if (ex instanceof ObjectNoLongerExistsException) {
               if((ufid.indexOf("WorkItem") != -1)) {
                  WorkItemURLProcessor.readContextStatic(httpState);
                  httpState.setContextObj(obj);
               } else {
                  if (VERBOSE) System.err.println("Caught Exception: Object No Longer Exists");
                  httpState.setContextAction("ObjectGone");
                  httpState.setContextObj(new java.lang.Object());
               }
            } else if (ex instanceof wt.access.NotAuthorizedException) {
               if (VERBOSE) System.err.println("Caught Exception: Not Authorized");
               httpState.setContextAction("ObjectGone");
               httpState.setContextObj(new java.lang.Object());
            }
         }
       }

       else if ( mergeData.getProperty( OID ) != null && ! mergeData.getProperty( OID ).equals("") && !isProjectLinkOid(mergeData.getProperty( OID )))
       {
         if (VERBOSE) System.err.println("processPostStringStatic : " + OID  + " =  " + mergeData.getProperty( OID ));
         String refstr = mergeData.getProperty( OID );

         EncodingConverter encoder = new EncodingConverter();
         refstr = encoder.decode(refstr);
         // SPR 1406333 - fixed temporarily followinf the pattern above with the action parameter
         // General method of getting the first parameter should be created later
         if ( refstr != null ) {
           int  commaIdx2 = refstr.indexOf( ',' );
           if ( commaIdx2 >= 0 ) refstr = refstr.substring( 0, commaIdx2 );
         }
         ReferenceFactory rf = new ReferenceFactory();
         WTReference ref = null;
         try {
            ref = rf.getReference( refstr );
         }
         catch (WTException wte) {
             // Exception message may echo the oid parameter on the query string.
             // For security reasons, we must escape HTML special characters in that
             // parameter because it could contain malicious script
             throw new WTException(HTMLEncoder.encodeAndFormatForHTMLContent(wte.getLocalizedMessage(), false));
          }
         Object obj = null;
         try {
            obj = ref.getObject();
            httpState.setContextObj(obj);
         } catch (WTRuntimeException re) {
            Throwable ex = re.getNestedThrowable();
            if (ex instanceof ObjectNoLongerExistsException) {
               if((refstr.indexOf("WorkItem") != -1)) {
                  WorkItemURLProcessor.readContextStatic(httpState);
                  httpState.setContextObj(obj);
               } else {
                  if (VERBOSE) System.err.println("Caught Exception: Object No Longer Exists");
                  httpState.setContextAction("ObjectGone");
                  httpState.setContextObj(new java.lang.Object());
               }
            } else if (ex instanceof wt.access.NotAuthorizedException) {
               if (VERBOSE) System.err.println("Caught Exception: Not Authorized");
               httpState.setContextAction("ObjectGone");
               httpState.setContextObj(new java.lang.Object());
            }
         }
       }
       else if ( mergeData.getProperty( CLASS ) != null && ! mergeData.getProperty( CLASS ).equals("") )
       {
          try
          {
            Class.forName( mergeData.getProperty( CLASS ) );
          }
          catch ( java.lang.ClassNotFoundException cnfe )
          {
            if (VERBOSE) cnfe.printStackTrace();
            String message = WTMessage.getLocalizedMessage(RESOURCE,enterpriseResource.INVALID_CLASS_ERROR,null);
            throw new WTException( message );
          }
          if (VERBOSE) System.err.println("processPostStringStatic : CLASS = " + mergeData.getProperty( CLASS ));
          httpState.setContextClassName( mergeData.getProperty( CLASS ) );
       }
       else
       {
          if (VERBOSE) System.err.println("processPostStringStatic : using default context object");
          httpState.setContextObj( new java.lang.Object() );
       }

       if(isOnDemand) {
           WTContainerRef containerRef = null;
           Object contextObj = httpState.getContextObj();
           if( contextObj instanceof WTContainer) {
               containerRef = WTContainerRef.newWTContainerRef((WTContainer)contextObj);
           } else if ( contextObj instanceof WTContained) {
               try {
                   containerRef = WTContainerHelper.getContainerRef((WTContained)contextObj);
                   if (containerRef != null && !AccessControlHelper.manager.hasAccess(containerRef, AccessPermission.READ)) {
                      /*
                       * Previously, getContainerRef() would throw a NotAuthorizedException if the current principal did
                       * not have access to the container. This method was changed so now this exception is no longer thrown
                       * so we need to explicitly check access. If the current principal does not have access to the container, then
                       * do not call the method setOrgContainerSearchScope() with the returned container reference.
                       */
                      if (VERBOSE) {
                          System.err.println("OnDemand: Principal does not have access to container.");
                      }
                      containerRef = null;
                   }
               }
               catch (WTRuntimeException wtr) {
                   throw new WTRuntimeException(wtr);
               }
           }
           if (containerRef != null )
               WTContainerHelper.setOrgContainerSearchScope(containerRef);
           else {
               if (VERBOSE) System.err.println("readContextStatic : *Info* --> Context Object does not have a ContainerRef");
           }
       }
       if ( VERBOSE )
         System.out.println("Before Return context object is " + httpState.getContextObj());
   }

   /**
    * This "Gateway" method is used to process an HTML form from an HTTP
    * GET/POST request.
    *      Multi-part POSTs are NOT accepted and there is NOT support for
    * uploading content from
    *      the HTML form.
    *      <BR>
    *      This method is generally used to process actions that are invoked
    * by clicking on
    *      a URL that has a Query String (i.e. an HTTP GET request). HTTP
    * POST requests
    *      that result from submitting an HTML Form are processed by this
    * "Gateway" method.
    *      However, you should really the processForm "Gateway" method for
    * such a purpose.
    *
    *      <BR>
    *      <BR>
    *
    *      The processing the Action/HTML Form, as performed in this method,
    *      consists of the following actions
    *      <UL>
    *      <LI>Find an ActionDelegate and see if the current user has permission
    * to
    *          submit the current form. If no ActionDelegate is located
    * for the current
    *          action, then it is assumed to be permission/state independent
    *      <LI>Locate a subclass of wt.templateutil.processor.FormTaskDelegate
    * using
    *          the FormTaskDelegateFactory and use that subclass of FormTaskDelegate
    *          to process this request.
    *      <LI>Using the updated state of the HTTPState object, locate a
    * subclass of
    *          TemplateProcessor using the TemplateProcessorFactory. This
    * instance of
    *          a subclass of TemplateProcessor will be used to generate
    * the response page.
    *      </UL>
    *
    *      <BR>
    *      <BR>
    *
    *      This gateway method, as with all gateway methods in this class,
    * require that a
    *      parameter with the name action be passed in either the query
    * string or the
    *      Form data of the HTTP Post. If no value for an action parameter
    * is sent, an
    *      exception is thrown.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @deprecated
    *
    * @param     parameters
    * @exception wt.util.WTException
    **/
   public static void validatePostStringStatic( Properties parameters )
            throws WTException {
       if ( (parameters.getProperty( "_" + ACTION ) == null) && (parameters.getProperty( ACTION ) == null) )
       {
           throw new WTException( WTMessage.getLocalizedMessage(RESOURCE,enterpriseResource.INVALID_URL_ERROR,null));
       }
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @deprecated
    *
    * @param     request
    * @param     response
    * @param     e
    * @exception wt.util.WTException
    **/
   public static void presentFormProcessorException( HTTPRequest request, HTTPResponse response, Exception e )
            throws WTException {
    try
    {
       TemplateProcessorFactory templateProcessorFactory = new TemplateProcessorFactory();
       TemplateProcessor generator = null;
        try
        {
            if (VERBOSE) System.err.println("presentFormProcessorException : before call to getTemplateProcessor\n");
            generator = templateProcessorFactory.getTemplateProcessor( "FormProcessingException" , null );
        }
        catch (Exception e2)
        {
            if (VERBOSE) System.err.println("presentFormProcessorException : before call to new ErrorProcessor\n");
            if (VERBOSE) e2.printStackTrace();
            generator = new ErrorProcessor( e );
        }
        DefaultHTMLTemplateFactory defaultHTMLTemplateFactory = getHtmlTemplateFactoryStatic();
        defaultHTMLTemplateFactory.setContextAction( "FormProcessingException" );
        defaultHTMLTemplateFactory.setContextObj( "" );
        defaultHTMLTemplateFactory.setContextClassName( null );
        defaultHTMLTemplateFactory.setLanguagePreferences( request );
        defaultHTMLTemplateFactory.setServiceName( "wt.tempateutil.HTMLGateway" );

        if (VERBOSE) System.err.println("presentFormProcessorException : before call to new getHTMLTemplate\n");
        HTMLTemplate template = defaultHTMLTemplateFactory.getHTMLTemplate();
        if (VERBOSE) System.err.println("presentFormProcessorException : after call to new getHTMLTemplate\n");
        OutputStream os = response.getOutputStream( );
        template.process( os, generator );

        os.flush( );
    }
    catch (wt.services.applicationcontext.implementation.UnableToLoadServiceProperties utlsp)
    {
        utlsp.printStackTrace();
        throw new WTException(utlsp);
    }
    catch (WTException wte)
    {
        wte.printStackTrace();
        throw new WTException(wte);
    }
    catch (java.io.IOException ioe)
    {
        ioe.printStackTrace();
        throw new WTException(ioe);
    }
   }

   protected static TemplateProcessor getTemplateProcessorStatic( HTTPState httpState, HTTPRequest request ) throws WTException
   {
      TemplateProcessorFactory templateProcessorFactory = null;
      try
      {
        templateProcessorFactory = new TemplateProcessorFactory();
      }
      catch ( wt.services.applicationcontext.implementation.UnableToLoadServiceProperties utlsp)
      {
        if (VERBOSE) utlsp.printStackTrace();
        return null;
      }

      TemplateProcessor generator = null;
      if (VERBOSE) System.err.println("getTemplateProcessorStatic : Action = " + httpState.getContextAction());

        if ( httpState.getContextObj() != null )
        {
            if (VERBOSE) System.err.println("getTemplateProcessorStatic : Object used");
            if (VERBOSE) System.err.println("getTemplateProcessorStatic : Object = " + httpState.getContextObj());
            generator = templateProcessorFactory.getTemplateProcessor(
                                httpState.getContextAction() , httpState.getContextObj() );
        }
        else if (httpState.getContextClassName() != null && httpState.getContextClassName().length() > 0 )
        {
            if (VERBOSE) System.err.println("getTemplateProcessorStatic : Class used");
            if (VERBOSE) System.err.println("getTemplateProcessorStatic : Class = " + httpState.getContextClassName());
            generator = templateProcessorFactory.getTemplateProcessor(
                                httpState.getContextAction() , httpState.getContextClassName()  );
        }
        else
        {
            generator = templateProcessorFactory.getTemplateProcessor(
                                httpState.getContextAction() , "java.lang.Object" );
        }
      return generator;
   }

   protected static DefaultHTMLTemplateFactory getHtmlTemplateFactoryStatic() {
      DefaultHTMLTemplateFactory htmlTemplateFactory = null;
      try
      {
         htmlTemplateFactory = new DefaultHTMLTemplateFactory();
      }
      catch (wt.services.applicationcontext.implementation.UnableToLoadServiceProperties utlsp)
      {
         utlsp.printStackTrace();
         return null;
      }
      return htmlTemplateFactory;
   }

   protected static void processAction( HTTPState httpState, HTTPRequest request, ContentHTTPStream contentStream ) throws WTException
   {
  //     readContextStatic( httpState );
       String action = httpState.getContextAction( ).toUpperCase( );

       try
       {
           FormTaskDelegateFactory factory = new FormTaskDelegateFactory( );
           FormTaskDelegate delegate = null;

           Object obj = httpState.getContextObj();
           if (obj != null )
           {
              if (!(BasicTemplateProcessor.AccessOK(action,obj,request)))
                 if ( BasicTemplateProcessor.PDMLinkIsInstalled() ) {
                   httpState.setContextAction("AccessDeniedError");
                  }
                 else {
                     throw new WTException( WTMessage.getLocalizedMessage(RESOURCE,enterpriseResource.ACCESS_DENIED_ERROR,null));
                 }
                 delegate = factory.getFormTaskDelegate(obj, httpState.getContextAction( ) );
           }
           else if ( httpState.getContextClassName( ) != null ) {
              ActionDelegate checkAccess = null;
              try
              {
                 ActionDelegateFactory checkAccessFactory = new ActionDelegateFactory( );
                 checkAccess = checkAccessFactory.getDelegate( action );
              }
              catch (UnableToCreateServiceException e )
              {
                 if (VERBOSE)
                 {
                    System.err.println("FormProcessor.processForm  : Unable to create the ActionDelegate");
                    e.printStackTrace();
                 }
             }
             if ( VERBOSE ) System.out.println( "VERBOSE: processForm getFormTaskDelegate for class " + httpState.getContextClassName( ) + " Action = " + httpState.getContextAction( ) );
             if ( checkAccess != null &&  ! checkAccess.enableable( httpState.getContextClassName( ) ).booleanValue( ) )
              {
                  throw new WTException( WTMessage.getLocalizedMessage(RESOURCE,enterpriseResource.ACCESS_DENIED_ERROR,null) );
              }
             delegate = factory.getFormTaskDelegate( httpState.getContextClassName( ), httpState.getContextAction( ) );
           }

           if ( httpState.getFormData() == null )
           {
              if (VERBOSE)
              {
               System.err.println("URLProcessor - processAction : httpState.getFormData() == null");
              }
           }
           delegate.setState( httpState );
           delegate.processAction( contentStream );
           request.bizData = httpState;
       }
       catch ( Exception e )
       {
          throw new WTException( e );
       }
   }

   public static Properties copyToUpperCase( Properties props )
   {
       Enumeration enum_          = props.keys();
       String keyName            = null;
       String keyNameUpperCase   = null;

       // Create a new Properties object to return
       Properties new_props      = new Properties();
       while ( enum_.hasMoreElements() )
       {
          // Get the current key
          keyName = (String)enum_.nextElement();
          if( VERBOSE ) {
            System.err.println("processPostStringStatic : keyName = " + keyName +
                               "  property = " + props.getProperty(keyName));
          }

          // Convert the current key to uppercase
          keyNameUpperCase = keyName.toUpperCase();
          String value = props.getProperty(keyName);

          // Add entries for both the original key and
          // the uppercase key to the returned properties
          // object
          new_props.put( keyName, value );
          new_props.put( keyNameUpperCase , value );
       }

       return new_props;
   }

   public static Hashtable copyToUpperCase( Hashtable props )
   {
       Enumeration enum_          = props.keys();
       String keyName            = null;
       String keyNameUpperCase   = null;

       // Create a new Hashtable object to return
       Hashtable new_props      = new Hashtable();
       while ( enum_.hasMoreElements() )
       {
          // Get the current key
          keyName = (String)enum_.nextElement();
          if( VERBOSE ) {
            System.err.println("processPostStringStatic : keyName = " + keyName +
                               "  property = " + props.get(keyName));
          }

          // Convert the current key to uppercase
          keyNameUpperCase = keyName.toUpperCase();
          Object value = props.get(keyName);

          // Add entries for both the original key and
          // the uppercase key to the returned Hashtable
          // object
          new_props.put( keyName, value );
          new_props.put( keyNameUpperCase , value );
       }

       return new_props;
   }

   public static Properties mergeProperties( Properties receiver, Properties sender)
   {
       Enumeration enum_ = sender.keys();
       String keyName   = null;
       Properties props = receiver;
       while ( enum_.hasMoreElements() )
       {
         keyName = (String)enum_.nextElement();
         props.put( keyName , sender.getProperty(keyName) );
       }
       return props;
   }

   /**
    *  Put the specified value in the Hashtable with the specified key,
    *  unless the key is already in use, in which case, add the value to
    *  a Vector stored under the same key
   **/
   private static void put(Hashtable props, String key, String value)
   {
      Object obj = props.get(key);
      if (obj == null) {
         props.put(key, value);
      } else {
         if (obj instanceof String) {
            Vector v = new Vector();
            v.addElement(obj);
            v.addElement(value);
            props.put(key, v);
         } else {
            ((Vector)obj).addElement(value);
         }
      }
   }
    public static void validatePostStringStatic( Properties parameters, String jspAction)
             throws WTException {
        if (jspAction != null && jspAction.length() > 0 )
        {
            return;
        }
        if ( (parameters.getProperty( "_" + ACTION ) == null) && (parameters.getProperty( ACTION ) == null) )
        {
            throw new WTException( WTMessage.getLocalizedMessage(RESOURCE,enterpriseResource.INVALID_URL_ERROR,null));
        }
    }
   private static final String SEP = "~";

   private static boolean isProjectLinkOid( String nmOidStr )
   {
      return nmOidStr.indexOf(SEP) != -1;
      /* Failed attempt at actually converting oid.
      {
         StringTokenizer t = new StringTokenizer(nmOidStr, SEP);
         String nm_type = (String)t.nextToken();
         String oidStr = (String)t.nextToken();
         System.out.println(oidStr);
         return ("VR:"+oidStr);
      }
      return nmOidStr;
      */
   }
}
