package com.ptc.windchill.enterprise.change2.reports;

import wt.util.resource.RBComment;
import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("com.ptc.windchill.enterprise.change2.reports.change2ReportsResource")
public final class change2ReportsResource extends WTListResourceBundle {
   /**
/* bcwti
    *
 * Copyright (c) 2010 Parametric Technology Corporation (PTC). All Rights Reserved.
    *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
    *
    * ecwti
    *
    * This file contains all the strings used by the DCA based Change Management clients
    *
    **/


   /**
    * ##############################################################################
    *
    * Column and input prompt names specific to change.
    *
    * ##############################################################################
    **/
   @RBEntry("Priority ")
   public static final String PRIORITY = "PRIORITY";

   @RBEntry("Category ")
   public static final String CATEGORY = "CATEGORY";

   @RBEntry("Complexity ")
   public static final String COMPLEXITY = "COMPLEXITY";

   @RBEntry("Change Admin")
   public static final String CHANGE_ADMIN = "CHANGE_ADMIN";

   @RBEntry("Change Admin I")
   public static final String CHANGE_ADMIN1 = "CHANGE_ADMIN1";

   @RBEntry("Change Admin II")
   public static final String CHANGE_ADMIN2 = "CHANGE_ADMIN2";

   @RBEntry("Variance Approver")
   public static final String VARIANCE_APPROVER = "VARIANCE_APPROVER";

   @RBEntry(" From")
   public static final String FROM_LABEL = "FROM_LABEL";

   @RBEntry(" To")
   public static final String TO_LABEL = "TO_LABEL";

   @RBEntry(" Version")
   public static final String REVISION = "REVISION";

   @RBEntry("Name ")
   public static final String NAME = "NAME";

   @RBEntry("Number ")
   public static final String NUMBER = "NUMBER";

   @RBEntry("State ")
   public static final String STATE = "STATE";

   @RBEntry("Organization ID")
   public static final String ORGANIZATION_ID = "ORGANIZATION_ID";

   @RBEntry(" Type")
   public static final String ITEM_TYPE = "ITEM_TYPE";

   @RBEntry(" Created On")
   public static final String CREATEDON = "CREATEDON";

   @RBEntry("Last Modified ")
   public static final String LAST_UPDATED = "LAST_UPDATED";

   @RBEntry("Resolution Date")
   public static final String RESOLUTION_DATE = "RESOLUTION_DATE";

   @RBEntry(" Created By")
   public static final String CREATOR = "CREATOR";

   @RBEntry("Report Date ")
   public static final String REPORTDATE = "REPORTDATE";

   @RBEntry("Input Page")
   public static final String PROMPT_PAGE = "PROMPT_PAGE";

   @RBEntry("Container Type")
   public static final String CONTAINER_TYPE = "CONTAINER_TYPE";

   @RBEntry("Container Id")
   public static final String CONTAINER_ID = "CONTAINER_ID";

   @RBEntry("Principal Id")
   public static final String PRINCIPALID = "PRINCIPALID";

   @RBEntry("Last Updated - From")
   public static final String LASTUPDATEDFROMDATE = "LASTUPDATEDFROMDATE";

   @RBEntry("Last Updated - To")
   public static final String LASTUPDATEDTODATE = "LASTUPDATEDTODATE";

   @RBEntry("Created On - From")
   public static final String CREATEDFROMDATE = "CREATEDFROMDATE";

   @RBEntry("Created On - To")
   public static final String CREATEDTODATE = "CREATEDTODATE";

   @RBEntry("Version")
   public static final String Version = "VERSION";

   @RBEntry("Type")
   public static final String Type = "TYPE";

   @RBEntry("Change Notice Organization ID")
   public static final String changeNoticeId = "changeNoticeId";

   @RBEntry("Version")
   public static final String NEWVERSION = "NEWVERSION";

   @RBEntry("Previous Version")
   public static final String OLDVERSION = "OLDVERSION";

   @RBEntry("Attribute Name")
   public static final String ATTRNAME = "ATTRNAME";

   @RBEntry("Value")
   public static final String VALUE = "VALUE";

   @RBEntry("New Value")
   public static final String NEWVALUE = "NEWVALUE";

   @RBEntry("Old Value")
   public static final String OLDVALUE = "OLDVALUE";

   @RBEntry("Component Number")
   public static final String COMPNUMBER = "COMPNUMBER";

   @RBEntry("Quantity")
   public static final String QUANTITY = "QUANTITY";

   @RBEntry("Units")
   public static final String UOM = "UOM";

   @RBEntry("Action")
   public static final String STRUCTDIFF = "STRUCTDIFF";

   @RBEntry("Find Number")
   public static final String FINDNUMBER = "FINDNUMBER";

   @RBEntry("Role")
   public static final String ROLE = "ROLE";

   @RBEntry("Vote")
   public static final String VOTE = "VOTE";

   @RBEntry("Date")
   public static final String TIMESTAMP = "TIMESTAMP";

   @RBEntry("Description")
   public static final String DESCRIPTION = "DESCRIPTION";

   @RBEntry("Add")
   @RBComment("Used in the ChangeNoticeSummaryReport as the action column in the structure changes section of each resulting object.")
   public static final String ADDED = "ADDED";

   @RBEntry("Delete")
   @RBComment("Used in the ChangeNoticeSummaryReport as the action column in the structure changes section of each resulting object.")
   public static final String DELETED = "DELETED";

   @RBEntry("Change")
   @RBComment("Used in the ChangeNoticeSummaryReport as the action column in the structure changes section of each resulting object.")
   public static final String CHANGED = "CHANGED";

   @RBEntry("Replace")
   @RBComment("Used in the ChangeNoticeSummaryReport as the action column in the structure changes section of each resulting object.")
   public static final String REPLACED = "REPLACED";

   @RBEntry("Signator")
   public static final String SIGNATOR = "SIGNATOR";

   @RBEntry("Describes By")
   public static final String DESCRIBES_BY = "DESCRIBES_BY";

   @RBEntry("Reference To")
   public static final String REFERENCE_TO = "REFERENCE_TO";

   @RBEntry("Passive")
   public static final String PASSIVE = "PASSIVE";

   @RBEntry("Active")
   public static final String ACTIVE = "ACTIVE";

   @RBEntry("Name")
   public static final String name = "name";

   @RBEntry("Number")
   public static final String number = "number";

   @RBEntry("Description (summary)")
   public static final String description = "description";

   @RBEntry("Type")
   public static final String type = "type";

   @RBEntry("Version")
   public static final String iterationDisplayIdentifier = "iterationDisplayIdentifier";

   @RBEntry("Revision")
   public static final String version = "version";

   @RBEntry("Organization ID")
   public static final String organizationIdentifier = "organizationIdentifier";

   @RBEntry("Context")
   public static final String containerName = "containerName";

   @RBEntry("Corrective Action")
   public static final String correctiveAction = "correctiveAction";

   @RBEntry("Effect On Cost")
   public static final String effectOnCost = "effectOnCost";

   @RBEntry("Effect On Schedule")
   public static final String effectOnSchedule = "effectOnSchedule";

   @RBEntry("Resolution Date")
   public static final String resolutionDate = "resolutionDate";

   @RBEntry("Reason (summary)")
   public static final String reason = "reason";

   @RBEntry("Requester")
   public static final String requester = "requester";

   @RBEntry("Priority")
   public static final String theIssuePriority = "theIssuePriority";

   @RBEntry("Complexity")
   public static final String theComplexity = "theComplexity";

   @RBEntry("Priority")
   public static final String requestPriority = "requestPriority";

   @RBEntry("Proposed Solution (summary)")
   public static final String proposedSolution = "proposedSolution";

   @RBEntry("Recurring")
   public static final String recurring = "recurring";

   @RBEntry("State")
   public static final String state = "state";

   @RBEntry("Created On")
   public static final String createTimeStamp = "createTimeStamp";

   @RBEntry("Last Modified")
   public static final String modifyTimeStamp = "modifyTimeStamp";

   @RBEntry("Need Date")
   public static final String needDate = "needDate";

   @RBEntry("Nonrecurring Cost")
   public static final String nonRecurringCostEst = "nonRecurringCostEst";

   @RBEntry("Recurring Cost")
   public static final String recurringCostEst = "recurringCostEst";

   @RBEntry("Category")
   public static final String theCategory = "theCategory";

   @RBEntry("Effect On Support")
   public static final String effectOnSupport = "effectOnSupport";

   @RBEntry("Category")
   public static final String theVarianceCategory = "theVarianceCategory";

   @RBEntry("Variance Owner")
   public static final String varianceOwner = "varianceOwner";

   @RBEntry("Approved Quantity")
   public static final String approvedQuantity = "approvedQuantity";

   @RBEntry("Complexity")
   public static final String theChangeNoticeComplexity = "theChangeNoticeComplexity";

   @RBEntry("Number")
   public static final String displayIdentifier = "displayIdentifier";

   @RBEntry("Created By")
   public static final String creator = "creator";

   @RBEntry("Location")
   public static final String folderId = "folderId";

   @RBEntry("Modified By")
   public static final String modifier = "modifier";

   @RBEntry("Assignee")
   public static final String assignee = "assignee";

   @RBEntry("Reviewer")
   public static final String reviewer = "reviewer";

   @RBEntry("Role")
   public static final String role = "role";

   @RBEntry("Deadline")
   public static final String deadline = "deadline";

   @RBEntry("Assignment Name")
   public static final String workItemName = "workItemName";

   @RBEntry("Assigned To")
   public static final String workItemAssignee = "workItemAssignee";

   @RBEntry("Sequence")
   public static final String sequence = "sequence";

   @RBEntry("Organization")
   public static final String ORGID = "ORGID";

   @RBEntry("Component Name")
   public static final String COMPNAME = "COMPNAME";

   @RBEntry("Link Type")
   public static final String LINKTYPE = "LINKTYPE";

   @RBEntry("Old Find Number")
   public static final String FINDNUMBEROLD = "FINDNUMBEROLD";

   @RBEntry("Old Component Number")
   public static final String COMPNUMBEROLD = "COMPNUMBEROLD";

   @RBEntry("Old Component Name")
   public static final String COMPNAMEOLD = "COMPNAMEOLD";

   @RBEntry("Old Quantity")
   public static final String QUANTITYOLD = "QUANTITYOLD";

   @RBEntry("Old Units")
   public static final String UOMOLD = "UOMOLD";

   @RBEntry("Component Organization ")
   public static final String COMPORGID = "COMPORGID";

   @RBEntry("Old Component Organization")
   public static final String COMPORGIDOLD = "COMPORGIDOLD";

   @RBEntry("Component Version ")
   public static final String COMPVERSION = "COMPVERSION";

   @RBEntry("Old Component Version")
   public static final String COMPVERSIONOLD = "COMPVERSIONOLD";

   @RBEntry("An error occurred during the creation of the report. Contact your administrator.")
   public static final String ERROR_CREATING_REPORT = "ERROR_CREATING_REPORT";

   @RBEntry("Find Context")
   public static final String FIND_CONTEXT = "FIND_CONTEXT";

   @RBEntry("Find Change Admin I")
   public static final String FIND_CHANGEADMIN_I = "FIND_CHANGEADMIN_I";

   @RBEntry("Find Change Admin II")
   public static final String FIND_CHANGEADMIN_II = "FIND_CHANGEADMIN_II";

   @RBEntry("Find Variance Approver")
   public static final String FIND_VARIANCE_APPROVER = "FIND_VARIANCE_APPROVER";

   @RBEntry("From")
   public static final String DATE_RANGE_FROM = "DATE_RANGE_FROM";

   @RBEntry("To")
   public static final String DATE_RANGE_TO = "DATE_RANGE_TO";

   @RBEntry("With suppliers")
   public static final String ONORDERDISPOSITION = "ONORDERDISPOSITION";

   @RBEntry("On stock")
   public static final String INVENTORYDISPOSITION = "INVENTORYDISPOSITION";

   @RBEntry("In production")
   public static final String FINISHEDDISPOSITION = "FINISHEDDISPOSITION";

   @RBEntry("With customer")
   public static final String WITHCUSTOMERDISPOSITION = "WITHCUSTOMERDISPOSITION";

   @RBEntry("In assembled parts")
   public static final String INASSEMBLEDPARTSDISPOSITION = "INASSEMBLEDPARTSDISPOSITION";

   @RBEntry("In service center")
   public static final String INSERVICECENTERDISPOSITION = "INSERVICECENTERDISPOSITION";

   @RBEntry("Disposition Comments")
   public static final String DISPOSITIONCOMMENTS = "DISPOSITIONCOMMENTS";

   @RBEntry("Basic")
   public static final String BASIC = "BASIC";

   @RBEntry("Complex")
   public static final String COMPLEX = "COMPLEX";

   @RBEntry("Simple")
   public static final String SIMPLE = "SIMPLE";

   /**
    * ##############################################################################
    *
    * Error text messages
    *
    * ##############################################################################
    **/
   @RBEntry("Both the From date and the To date must be specified.")
   public static final String FROM_OR_TO_DATES_MISSING = "FROM_OR_TO_DATES_MISSING";

   @RBEntry("The To date must occur after the From date.")
   public static final String TO_DATE_AFTER_FROM_DATE = "TO_DATE_AFTER_FROM_DATE";

   /**
    * ##############################################################################
    *
    * Localized Name for action buttons
    *
    * ##############################################################################
    **/
   @RBEntry(" Continue")
   public static final String CONTINUE = "CONTINUE";

   @RBEntry("Cancel ")
   public static final String CANCEL = "CANCEL";

   @RBEntry("Clear ")
   public static final String CLEAR = "CLEAR";

   /**
    * ##############################################################################
    *
    * Localized Report Name
    *
    * ##############################################################################
    **/
   @RBEntry("Problem Report Status Report")
   public static final String PRIVATE_CONSTANT_0 = "Problem Report Status Report";

   @RBEntry("Variance Status Report")
   public static final String PRIVATE_CONSTANT_1 = "Variance Status Report";

   @RBEntry("Change Request Status Report")
   public static final String PRIVATE_CONSTANT_2 = "Change Request Status Report";

   @RBEntry("Change Notice Status Report")
   public static final String PRIVATE_CONSTANT_3 = "Change Notice Status Report";

   @RBEntry("Change Notice Summary Report")
   public static final String PRIVATE_CONSTANT_4 = "Change Notice Summary Report";

   @RBEntry("Problem Report Log")
   public static final String PRIVATE_CONSTANT_5 = "Problem Report Log";

   @RBEntry("Variance Log")
   public static final String PRIVATE_CONSTANT_6 = "Variance Log";

   @RBEntry("Change Request Log")
   public static final String PRIVATE_CONSTANT_7 = "Change Request Log";

   @RBEntry("Change Notice Log")
   public static final String PRIVATE_CONSTANT_8 = "Change Notice Log";

   @RBEntry("Problem Report Summary Report")
   public static final String PRIVATE_CONSTANT_9 = "Problem Report Summary Report";

   @RBEntry("Change Request Summary Report")
   public static final String PRIVATE_CONSTANT_10 = "Change Request Summary Report";

   @RBEntry("Variance Summary Report")
   public static final String PRIVATE_CONSTANT_11 = "Variance Summary Report";

   @RBEntry("Change Notice Implementation Status Report")
   public static final String PRIVATE_CONSTANT_12 = "Change Notice Implementation Status Report";

   @RBEntry("Issue Log")
   public static final String ISSUE_LOG_REPORT_NAME = "Issue Log";

   /**
    * ##############################################################################
    *
    * Cognos Report UI Entries
    *
    * ##############################################################################
    **/
   @RBEntry("Input Page")
   public static final String PRIVATE_CONSTANT_13 = "Input Page";

   @RBEntry("Report Date")
   public static final String PRIVATE_CONSTANT_14 = "Report Date";

   @RBEntry("Created By")
   public static final String PRIVATE_CONSTANT_15 = "Created By";

   @RBEntry("Container Type")
   public static final String PRIVATE_CONSTANT_16 = "Container Type";

   @RBEntry("Container Id")
   public static final String PRIVATE_CONSTANT_17 = "Container Id";

   @RBEntry("Principal Id")
   public static final String PRIVATE_CONSTANT_18 = "Principal Id";

   @RBEntry("Priority")
   public static final String PRIVATE_CONSTANT_19 = "Priority";

   @RBEntry("Category")
   public static final String PRIVATE_CONSTANT_20 = "Category";

   @RBEntry("Complexity")
   public static final String PRIVATE_CONSTANT_21 = "Complexity";

   @RBEntry("State")
   public static final String PRIVATE_CONSTANT_22 = "State";

   @RBEntry("Change Admin")
   public static final String PRIVATE_CONSTANT_23 = "Change Admin";

   @RBEntry("From")
   public static final String PRIVATE_CONSTANT_24 = "From";

   @RBEntry("To")
   public static final String PRIVATE_CONSTANT_25 = "To";

   @RBEntry("Version")
   public static final String PRIVATE_CONSTANT_26 = "Version";

   @RBEntry("Name")
   public static final String PRIVATE_CONSTANT_27 = "Name";

   @RBEntry("Number")
   public static final String PRIVATE_CONSTANT_28 = "Number";

   @RBEntry("Organization ID")
   public static final String PRIVATE_CONSTANT_29 = "Organization ID";

   @RBEntry("Type")
   public static final String PRIVATE_CONSTANT_30 = "Type";

   @RBEntry("Created On")
   public static final String PRIVATE_CONSTANT_31 = "Created On";

   @RBEntry("Last Modified")
   public static final String PRIVATE_CONSTANT_32 = "Last Modified";

   @RBEntry("Resolution Date")
   public static final String PRIVATE_CONSTANT_33 = "Resolution Date";

   @RBEntry("Link to Windchill Report Input Page")
   public static final String PRIVATE_CONSTANT_34 = "Link to Windchill Report Input Page";

   @RBEntry("Change Admin I")
   public static final String PRIVATE_CONSTANT_35 = "Change Admin I";

   @RBEntry("Change Admin II")
   public static final String PRIVATE_CONSTANT_36 = "Change Admin II";

   @RBEntry("Variance Approver")
   public static final String PRIVATE_CONSTANT_37 = "Variance Approver";

   @RBEntry("Implementation Status")
   public static final String PRIVATE_CONSTANT_38 = "Implementation Status";

   @RBEntry("Implementation Plan")
   public static final String PRIVATE_CONSTANT_39 = "Implementation Plan";

   @RBEntry("Related Changes")
   public static final String PRIVATE_CONSTANT_40 = "Related Changes";

   @RBEntry("Signature")
   public static final String PRIVATE_CONSTANT_41 = "Signature";

   @RBEntry("Dispositions")
   public static final String PRIVATE_CONSTANT_42 = "Dispositions";

   @RBEntry("Summary of Changes")
   public static final String PRIVATE_CONSTANT_43 = "Summary of Changes";

   @RBEntry("Affected Objects")
   public static final String PRIVATE_CONSTANT_44 = "Affected Objects";

   @RBEntry("Context")
   public static final String PRIVATE_CONSTANT_45 = "Context";

   @RBEntry("Created From Date")
   public static final String PRIVATE_CONSTANT_46 = "createFromDte";

   @RBEntry("Last Updated To Date")
   public static final String PRIVATE_CONSTANT_47 = "lstUpdToDte";

   @RBEntry("Number")
   public static final String PRIVATE_CONSTANT_48 = "num";

   @RBEntry("Last Updated From Date")
   public static final String PRIVATE_CONSTANT_49 = "lstUpdFromDte";

   @RBEntry("Category")
   public static final String PRIVATE_CONSTANT_50 = "ctgry";

   @RBEntry("Priority")
   public static final String PRIVATE_CONSTANT_51 = "priorty";

   @RBEntry("Container Id")
   public static final String PRIVATE_CONSTANT_52 = "cntnrId";

   @RBEntry("Change Admin I")
   public static final String PRIVATE_CONSTANT_53 = "chgAdmin";
   
   @RBEntry("Change Admin II")
   public static final String chgAdmin2 = "chgAdmin2";

   @RBEntry("Created To Date")
   public static final String PRIVATE_CONSTANT_54 = "createToDte";

   @RBEntry("Container Type")
   public static final String PRIVATE_CONSTANT_55 = "cntnrType";
   
   @RBEntry("Complexity")
   public static final String PRIVATE_CONSTANT_56 = "cmplxty";
   
   @RBEntry("Category")
   public static final String PRIVATE_CONSTANT_57 = "varCtgry";

   @RBEntry("Executed By")
   @RBComment("Report Footer of cognos report")
   public static final String EXECUTED_BY = "Executed By";

   @RBEntry("Created From Date")
   @RBComment("Cognos report input criteria text")
   public static final String CREATED_FROM_DATE = "Created From Date";

   @RBEntry("Created To Date")
   @RBComment("Cognos report input criteria text")
   public static final String CREATED_TO_DATE = "Created To Date";

   @RBEntry("Last Updated From Date")
   @RBComment("Cognos report input criteria text")
   public static final String LAST_UPDATED_FROM_DATE = "Last Updated From Date";

   @RBEntry("Last Updated To Date")
   @RBComment("Cognos report input criteria text")
   public static final String LAST_UPDATED_TO_DATE = "Last Updated To Date";
   
   @RBEntry("Release Target")
   @RBComment("Release Target for Cognos report")
   public static final String TARGETTRANSITION = "TARGETTRANSITION";
   
   @RBEntry("The number of objects returned exceeds the maximum allowed. Would you like to continue? Click OK to continue with limited results, or Cancel to refine your report criteria.")
   @RBComment("Message to indicate objects returned exceeds the maximum allowed.")
   public static final String REPORT_EXCEEDS_LIMIT = "REPORT_EXCEEDS_LIMIT";

   @RBEntry("Created by %s on %s")
   @RBComment("Header label for Change review report - output is 'Created by (user) on (date'")
   public static final String CHANGE_REVIEW_REPORT_HEADER = "CHANGE_REVIEW_REPORT_HEADER";
   
   @RBEntry("Description")
   public static final String longDescriptionPlainText = "longDescriptionPlainText";
   
   @RBEntry("Description")
   public static final String longDescriptionRichText = "longDescriptionRichText";
   
   @RBEntry("Description")
   public static final String longDescriptionCognosRichText = "longDescriptionCognosRichText";
   
   @RBEntry("Proposed Solution")
   public static final String longProposedSolutionPlainText = "longProposedSolutionPlainText";
   
   @RBEntry("Proposed Solution")
   public static final String longProposedSolutionRichText = "longProposedSolutionRichText";
   
   @RBEntry("Proposed Solution")
   public static final String longProposedSolutionCognosRichText = "longProposedSolutionCognosRichText";
   
   @RBEntry("Reason")
   public static final String longReasonPlainText = "longReasonPlainText";
   
   @RBEntry("Reason")
   public static final String longReasonRichText = "longReasonRichText";
   
   @RBEntry("Reason")
   public static final String longReasonCognosRichText = "longReasonCognosRichText";
}
