/* bcwti
 *
 * Copyright (c) 2015 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */
package com.ptc.core.lwc.server;

import static com.ptc.core.lwc.server.addColumns.DataType.STRING;

import java.beans.PropertyDescriptor;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import com.ptc.core.command.common.bean.repository.BasicClosePagingRepositoryCommand;
import com.ptc.core.command.common.bean.repository.BasicFetchPagingRepositoryCommand;
import com.ptc.core.command.common.bean.repository.PageMode;
import com.ptc.core.command.common.bean.repository.RepositoryPagingSession;
import com.ptc.core.command.common.bean.repository.ResultContainer;
import com.ptc.core.lwc.common.AttributeTemplateFlavor;
import com.ptc.core.lwc.common.BaseDefinitionService;
import com.ptc.core.lwc.common.TypeDefinitionService;
import com.ptc.core.lwc.common.datatypes.BooleanDatatypeHandler;
import com.ptc.core.lwc.common.datatypes.FloatingPointDatatypeHandler;
import com.ptc.core.lwc.common.datatypes.HyperlinkDatatypeHandler;
import com.ptc.core.lwc.common.datatypes.LongDatatypeHandler;
import com.ptc.core.lwc.common.datatypes.ReferenceDatatypeHandler;
import com.ptc.core.lwc.common.datatypes.StringDatatypeHandler;
import com.ptc.core.lwc.common.datatypes.TimestampDatatypeHandler;
import com.ptc.core.lwc.common.view.AttributeDefinitionReadView;
import com.ptc.core.lwc.common.view.AttributeDefinitionWriteView;
import com.ptc.core.lwc.common.view.ConstraintDefinitionWriteView;
import com.ptc.core.lwc.common.view.ConstraintRuleDefinitionReadView;
import com.ptc.core.lwc.common.view.TypeDefinitionReadView;
import com.ptc.core.lwc.common.view.TypeDefinitionWriteView;
import com.ptc.core.lwc.server.addColumns.AddColumnsImpl;
import com.ptc.core.meta.common.AttributeIdentifier;
import com.ptc.core.meta.common.AttributeTypeIdentifier;
import com.ptc.core.meta.common.EmptySet;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.TypeInstanceIdentifier;
import com.ptc.core.meta.common.impl.InstanceBasedAssociationTypeIdentifier;
import com.ptc.core.meta.common.impl.InstanceBasedAttributeTypeIdentifier;
import com.ptc.core.meta.common.impl.WCPersistableInstanceIdentifier;
import com.ptc.core.meta.common.impl.WCTypeInstanceIdentifier;
import com.ptc.core.meta.container.common.AttributeContainerSet;
import com.ptc.core.meta.container.common.impl.ImmutableConstraint;
import com.ptc.core.meta.server.IBAModel;
import com.ptc.core.meta.server.TypeIdentifierUtility;
import com.ptc.core.meta.type.common.TypeInstance;
import com.ptc.core.meta.type.server.TypeInstanceUtility;
import com.ptc.core.query.command.common.BasicQueryCommand;
import com.ptc.core.query.common.BasicResultSpec;
import com.ptc.core.query.common.CriteriaHelper;
import com.ptc.core.query.common.impl.BasicTypePagingSession;
import com.ptc.core.query.common.impl.NoOpCriteriaAugmentor;
import com.ptc.core.query.server.impl.HandlerUtil;

import wt.dataservice.DatastoreFunction;
import wt.fc.ObjectIdentifier;
import wt.fc.ObjectReference;
import wt.fc.PersistInfo;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.batch.AbstractBatchSpec;
import wt.fc.batch.DeleteBatchSpec;
import wt.fc.batch.UpdateBatchSpec;
import wt.fc.batch.UpdateColumnExpression;
import wt.fc.collections.WTArrayList;
import wt.fc.collections.WTList;
import wt.iba.definition.AbstractAttributeDefinition;
import wt.iba.definition.BooleanDefinitionReference;
import wt.iba.definition.FloatDefinitionReference;
import wt.iba.definition.IntegerDefinitionReference;
import wt.iba.definition.ReferenceDefinitionReference;
import wt.iba.definition.StringDefinitionReference;
import wt.iba.definition.TimestampDefinitionReference;
import wt.iba.definition.URLDefinitionReference;
import wt.iba.definition.UnitDefinitionReference;
import wt.iba.definition.litedefinition.AttributeDefDefaultView;
import wt.iba.definition.litedefinition.BooleanDefView;
import wt.iba.definition.litedefinition.FloatDefView;
import wt.iba.definition.litedefinition.IntegerDefView;
import wt.iba.definition.litedefinition.ReferenceDefView;
import wt.iba.definition.litedefinition.StringDefView;
import wt.iba.definition.litedefinition.TimestampDefView;
import wt.iba.definition.litedefinition.URLDefView;
import wt.iba.definition.litedefinition.UnitDefView;
import wt.iba.value.AbstractValue;
import wt.iba.value.BooleanValue;
import wt.iba.value.FloatValue;
import wt.iba.value.IBAHolderReference;
import wt.iba.value.IBAReferenceableReference;
import wt.iba.value.IntegerValue;
import wt.iba.value.ReferenceValue;
import wt.iba.value.StringValue;
import wt.iba.value.TimestampValue;
import wt.iba.value.URLValue;
import wt.iba.value.UnitValue;
import wt.inf.container.WTContainerHelper;
import wt.introspection.ClassInfo;
import wt.introspection.ColumnDescriptor;
import wt.introspection.WTIntrospector;
import wt.log4j.LogR;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.org.WTGroup;
import wt.org.WTPrincipal;
import wt.pds.DatabaseInfoUtilities;
import wt.pom.PersistenceException;
import wt.pom.Transaction;
import wt.query.ClassAttribute;
import wt.query.ClassTableExpression;
import wt.query.ColumnExpression;
import wt.query.ColumnSubSelectExpression;
import wt.query.DateExpression;
import wt.query.KeywordExpression;
import wt.query.QueryException;
import wt.query.QuerySpec;
import wt.query.SQLFunction;
import wt.query.SearchCondition;
import wt.query.SubSelectExpression;
import wt.services.LightweightServiceHelper;
import wt.services.ServiceFactory;
import wt.session.SessionHelper;
import wt.util.ClassCache;
import wt.util.WTAttributeNameIfc;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.WTProperties;
import wt.util.WTPropertyVetoException;

/**
 * Usage        : windchill com.ptc.core.lwc.server.TypeAttributeMoveTool typeName sourceAttributeName  targetAttributeName *
 *  Prerequisite: Specified type and attributes must all exist.
 */
public class TypeAttributeMoveTool
{
    private static final String USAGE =
   			"Usage        : windchill com.ptc.core.lwc.server.TypeAttributeMoveTool typeName sourceAttributeName  targetAttributeName updateTargetAttribute [-u username] [-p password]\n"
			+ " Prerequisite: Specified type and attributes must all exist.";

    private static final Logger logger = LogR.getLogger(TypeAttributeMoveTool.class.getName());
    private static final TypeDefinitionService LWCTYPE_DEF_SERVICE = TypeDefinitionServiceHelper.service;
    private static final BaseDefinitionService BASE_DEF_SERVICE = ServiceFactory.getService(BaseDefinitionService.class);
    private static final String DEFINITION_REF_ID = "definitionReference" + "." + ObjectReference.KEY + "." + ObjectIdentifier.ID;
    private static final String IMMUTABLE_CONSTRAINT = ImmutableConstraint.class.getName();
    private static final String BASIC_DEFCLASSNAME = LWCBasicConstraint.class.getName();
    private static final String VALUE_PROPERTY_NAME = "value";
    private static final int PAGE_QUERY_RANGE;
    // C12613701, SPR 4929167, allow PAGE_QUERY_RANGE to be controlled via wt property
    static {
        final int defaultSize = 1000;
        int temp = defaultSize;
        try {
            WTProperties wtp = wt.util.WTProperties.getLocalProperties();
            temp = wtp.getProperty(TypeAttributeMoveTool.class.getName() + ".pageQueryRange", defaultSize );
        } catch(IOException e) {
            logger.error("Exception getting wt.properties to find value for PAGE_QUERY_RANGE", e);
        }
        PAGE_QUERY_RANGE = Math.max( temp, defaultSize );  // don't allow a size < 1000
        if(logger.isDebugEnabled()) {
            logger.debug("PAGE_QUERY_RANGE initialized to " + PAGE_QUERY_RANGE);
        }
    }


    @SuppressWarnings("PMD.SystemPrintln")
    public static void main(String[] args) throws WTException
    {
        String user = null;
        String passwd = null;
        //check args
        if(args.length < 4)
        {
            System.out.println(USAGE);
            return;
        }

        //parse the cmd line
        final String typeName = args[0];
        final String sourceAttName = args[ 1 ];
        final String targetAttName = args[ 2 ];
				final boolean updateTargetAttribute = Boolean.valueOf(args[3]);
        for(int i = 4; i < args.length; i++)
        {
            switch ( args[i] )
            {
                case "-u":
                    if (++i < args.length)
                    {
                        user = args[i];
                    }   break;
                case "-p":
                    if (++i < args.length)
                    {
                        passwd = args[i];
                    }   break;
                default:
                    logger.error("Error processing argument \"" + args[i] + "\"!");
                return;
            }
        }

        // authenticate user, ensure only site admins can run this tool
        if ( user != null && !user.equals(""))
        {
            RemoteMethodServer.getDefault().setUserName ( user );
            if ( passwd != null )
            {
                RemoteMethodServer.getDefault().setPassword ( passwd );
            }
        }

        // validate type exists
        TypeDefinitionReadView typeView;
        try
        {   // validate
            typeView = LWCTYPE_DEF_SERVICE.getTypeDefView(typeName);
            if (typeView==null)
            {
                logger.error("TypeDefinition \"" + typeName + "\" doesn't exist yet!");
                return;
            }
        }
        catch ( WTException wte )
        {
            logger.error( wte.getLocalizedMessage(), wte );
            return;
        }


        final AttributeDefinitionReadView sourceAtt = typeView.getAttributeByName( sourceAttName );
        final AttributeDefinitionReadView targetAtt = typeView.getAttributeByName( targetAttName );
        if ( !validateAtts( sourceAtt, targetAtt ) )
        {
            return; // validate atts will output details as to why the validation failed.
        }

        long sourceStringAttColumnSize = getStringAttColumnSize(sourceAtt);
        long targetStringAttColumnSize = getStringAttColumnSize(targetAtt);
        if (sourceStringAttColumnSize > targetStringAttColumnSize)
        {
            logger.error("It's not supported to move attribute values from a source String attribute with larger column size to a target String attribute with a smaller column size. Source attribute "
                         + sourceAtt.getName() + " has a column size of " + sourceStringAttColumnSize +
                         ". Target attribute " + targetAtt.getName() + " has a column size of " + targetStringAttColumnSize + ".");
            return;
        }

        final long startTime = System.currentTimeMillis();
        final Boolean status =
            (Boolean) LightweightServiceHelper.invoke("moveAttributes", Server.class.getName(),
                                                      new Class []{TypeDefinitionReadView.class,
                                                                   AttributeDefinitionReadView.class,
                                                                   AttributeDefinitionReadView.class,
                                                                   boolean.class},
                                                      new Object[]{typeView, sourceAtt, targetAtt, updateTargetAttribute} );
        String message = "Move attributes took " + (System.currentTimeMillis()-startTime)/(60*1000) + " minutes.";
        if (status)
        {
            message += "\nSuccessfully moved attributes.\nPlease delete the source attribute from type manager UI!";
        }
        else
        {
            message += "\nThere are errors. Please check method server log";
        }
        System.out.println(message);
        logger.info(message);
        System.exit(0);
    }

    // two attributes are either LWCIBA or LWCFlex and they are of the same datatype and not reference atts
    private static boolean validateAtts( final AttributeDefinitionReadView sourceAtt,
                                         final AttributeDefinitionReadView targetAtt )
    {
        final boolean attsRValid;
        if ( sourceAtt == null )
        {
            logger.error( "Source attribute doesn't exist." );
            attsRValid = false;
        }
        else if ( targetAtt == null )
        {
            logger.error( "Target attribute doesn't exist." );
            attsRValid = false;
        }
        else
        {
            if ( !isGlobalAtt( sourceAtt.getAttDefClass() ) &&
                 !isLocalAtt( sourceAtt.getAttDefClass() ) )
            {
                logger.error("Source attribute is a \"" + sourceAtt.getAttDefClass() +
                             "\". This tool only supports moves for LWCIBAAttDefinition or LWCFlexAttDefinition! ");
                attsRValid = false;
            }
            else if ( !isGlobalAtt( targetAtt.getAttDefClass() ) &&
                      !isLocalAtt( targetAtt.getAttDefClass() ) )
            {
                logger.error("Target attribute is a \"" + targetAtt.getAttDefClass() +
                             "\". This tool only supports moves for LWCIBAAttDefinition or LWCFlexAttDefinition! ");
                attsRValid = false;
            }
            else
            {
                if ( !sourceAtt.getDatatype().equals( targetAtt.getDatatype() ) )
                {
                    logger.error( "Source Attribute's datatype \"" + sourceAtt.getDatatype().getName() +
                                  "\" is different from Target Attribute's datatype \"" +
                                  targetAtt.getDatatype().getName() + "\"!" );
                    attsRValid = false;
                }
                else if ( sourceAtt.getDatatype().getName().equals( TypeIdentifier.class.getName() ) ||
                          sourceAtt.getDatatype().getName().equals( WCTypeInstanceIdentifier.class.getName() ) )
                {
                    logger.error( "This tool doesn't support reference attributes!" );
                    attsRValid = false;
                }
                else
                {
                    attsRValid = true;
                }
            }
        }

        return attsRValid;
    }

    /**
     * Return String attribute column size. If the given attribute is not a string attribute, return 0;
     * @param attView
     * @return
     * @throws WTException
     */
    private static long getStringAttColumnSize( AttributeDefinitionReadView attView ) throws WTException
    {
        if (!attView.getDatatype().getName().equals(String.class.getName()))
        {
            return 0;
        }
        final long stringAttColumnSize;
        if ( isGlobalAtt( attView.getAttDefClass() ) )
        {
            stringAttColumnSize = getGlobalStringAttColumnSize();
        }
        else
        {
            stringAttColumnSize = getStandardStringAttColumnSize(attView);
        }
        return stringAttColumnSize;
    }

    /**
     * Return the global string attribute column size.
     * @return
     * @throws WTException
     */
    private static long getGlobalStringAttColumnSize() throws WTException
    {
        long upper_limit = PersistenceHelper.DB_MAX_SQL_STRING_SIZE;
        ClassInfo classInfo = WTIntrospector.getClassInfo(StringValue.class.getName());
        PropertyDescriptor[] pds = classInfo.getPropertyDescriptors();
        for (PropertyDescriptor pd : pds)
        {
            if (pd.getName().equals(VALUE_PROPERTY_NAME))
            {
                Number upperLimit;
                if (pd.getValue(WTIntrospector.UPPER_LIMIT) instanceof String)
                {
                    upperLimit = Integer.valueOf((String)pd.getValue(WTIntrospector.UPPER_LIMIT));
                }
                else
                {
                    upperLimit = (Number)pd.getValue(WTIntrospector.UPPER_LIMIT);
                }
                upper_limit = (upperLimit==null)?PersistenceHelper.DB_MAX_SQL_STRING_SIZE:upperLimit.longValue();
                if ( upper_limit > PersistenceHelper.DB_MAX_SQL_STRING_SIZE )
                {
                    upper_limit = PersistenceHelper.DB_MAX_SQL_STRING_SIZE;
                }
                return upper_limit;
            }
        }
        return upper_limit;
    }

    /**
     * Given the attribute read view, return the standard attribute column size. Return 0 if this attribute is not
     * a standard string attribute or there is no standard attribute column.
     * This API is for testing only
     * @param attView
     * @return
     * @throws WTException
     */    
    static long getStandardStringAttColumnSize(AttributeDefinitionReadView attView) throws WTException {
        long upper_limit;
        // SPR Task: 6815287
        if (!isLocalAtt(attView.getAttDefClass())) {
            return 0;
        }
        if (!attView.getDatatype().getName().equals(String.class.getName())) {
            return 0;
        }
        String modeledParentTypeName = getModeledParentTypeName(attView);
        String modeledParentTypeInfoName = modeledParentTypeName + AddColumnsImpl.TYPE_INFO_SUFFIX;
        ClassInfo classInfo = WTIntrospector.getClassInfo(modeledParentTypeInfoName);
        PropertyDescriptor[] pds = classInfo.getPropertyDescriptors();
        for (PropertyDescriptor pd : pds) {
            if (pd.getName().startsWith(STRING.getTypeInfoPropertyPrefix())) {
                Number upperLimit;
                if (pd.getValue(WTIntrospector.UPPER_LIMIT) instanceof String) {
                    upperLimit = Integer.valueOf((String) pd.getValue(WTIntrospector.UPPER_LIMIT));
                }
                else {
                    upperLimit = (Number) pd.getValue(WTIntrospector.UPPER_LIMIT);
                }
                upper_limit = (upperLimit == null) ? PersistenceHelper.DB_MAX_SQL_STRING_SIZE : upperLimit.longValue();
                if (upper_limit > PersistenceHelper.DB_MAX_SQL_STRING_SIZE) {
                    upper_limit = PersistenceHelper.DB_MAX_SQL_STRING_SIZE;
                }
                return upper_limit;
            }
        }
        return 0;
    }

    /**
     * Given the attribute view, return its modeled parent type name
     * @param attView
     * @return
     * @throws WTException
     */
    private static String getModeledParentTypeName (AttributeDefinitionReadView attView) throws WTException
    {
        attView.getReadViewIdentifier().getRootContextIdentifier().getOid().getClassname();
        TypeDefinitionReadView type =
            LWCTYPE_DEF_SERVICE.getTypeDefView( AttributeTemplateFlavor.LWCTYPE, attView.getTypeDefId().getId());
        if (type.isModeled())
        {
            return type.getName();
        }
        TypeDefinitionReadView parentType = LWCTYPE_DEF_SERVICE.getParentTypeDefView(type);
        while ( !(parentType.isModeled()) )
        {
            parentType = LWCTYPE_DEF_SERVICE.getParentTypeDefView(parentType);
        }
        return parentType.getName();
    }

    /**
     * Checks if the attribute definition class is a global attribute.
     * @param attDefClassName The name of the attribute definition class.
     * @return  Whether or not the attribute definition class is a global attribute.
     */
    private static boolean isGlobalAtt( final String attDefClassName )
    {
        return LWCIBAAttDefinition.class.getName().equals( attDefClassName );
    }

    /**
     * Checks if the attribute definition class is a local attribute.
     * @param attDefClassName The name of the attribute definition class.
     * @return  Whether or not the attribute definition class is a local attribute.
     */
    private static boolean isLocalAtt( final String attDefClassName )
    {
        return LWCFlexAttDefinition.class.getName().equals( attDefClassName );
    }

    public static class Server implements RemoteAccess
    {
        /** Enumeration for the type of attribute move being performed. */
        private enum ATT_MOVE_TYPE
        {
            IBA_2_IBA,
            IBA_2_FLEX,
            FLEX_2_IBA,
            FLEX_2_FLEX;

            /**
             * Get the type attribute move being performed.
             * @param sourceAttDefClassName The name of the type of the source attribute definition.  Must not be null.
             * @param targetAttDefClassName The name of the type of the target attribute definition.  Must not be null.
             * @return  The type of attribute move.
             * @throws IllegalArgumentException if either input is null or empty.
             */
            public static ATT_MOVE_TYPE getAttMoveType( final String sourceAttDefClassName, final String targetAttDefClassName )
            {
                if ( sourceAttDefClassName == null || sourceAttDefClassName.isEmpty() ||
                     targetAttDefClassName == null || targetAttDefClassName.isEmpty() )
                {
                    throw new IllegalArgumentException( "Invalid arguments: " + sourceAttDefClassName + ", " +
                                                        targetAttDefClassName );
                }
                final ATT_MOVE_TYPE result;
                if ( isGlobalAtt(sourceAttDefClassName ) )
                {
                    if ( isGlobalAtt( targetAttDefClassName ) )
                    {
                        result = IBA_2_IBA;
                    }
                    else
                    {
                        result = IBA_2_FLEX;
                    }
                }
                else
                {
                    if ( isGlobalAtt( targetAttDefClassName ) )
                    {
                        result = FLEX_2_IBA;
                    }
                    else
                    {
                        result = FLEX_2_FLEX;
                    }
                }
                return result;
            }
        }
        final static Timestamp TS_UPDATE_VALUE = new Timestamp(System.currentTimeMillis());

        public static boolean moveAttributes(TypeDefinitionReadView typeView, AttributeDefinitionReadView sourceAtt,
                                             AttributeDefinitionReadView targetAtt, boolean updateTargetAttribute)
                    throws WTException, WTPropertyVetoException, ClassNotFoundException
        {
            BasicTypePagingSession pagingSession = null;

            WTPrincipal principal = SessionHelper.manager.getPrincipal();
            WTGroup adminGroup = WTContainerHelper.service.getExchangeContainer().getAdministrators();
            boolean isMember = adminGroup.isMember(principal);
            if (!isMember)
            {
                throw new WTException(WTMessage.getLocalizedMessage(serverResource.class.getName(),
                                      serverResource.CURRENT_USER_IS_NOT_SITE_ADMIN, null));
            }

            TypeIdentifier ti = typeView.getTypeIdentifier();
            AttributeTypeIdentifier sourceATI = sourceAtt.getAttributeTypeIdentifier();
            AttributeTypeIdentifier targetATI = targetAtt.getAttributeTypeIdentifier();

            // Based on Joe T suggestion, initial BasicQueryCommand.execute() call have to run outside the transaction.
            int offset = 0;
            final int count = PAGE_QUERY_RANGE;
            BasicResultSpec resultSpec = new BasicResultSpec();
            resultSpec.putEntry(sourceATI);
            resultSpec.putEntry(targetATI);
            resultSpec.setTargetDataTypeIdentifiers(new TypeIdentifier[]{ti});

            BasicQueryCommand command = new BasicQueryCommand();
            command.setCriteriaAugmentor(new NoOpCriteriaAugmentor());
            command.setResult(resultSpec);
            command.setPageMode(PageMode.EXPLICIT_PAGING);
            command.setOffset(offset);
            command.setCount(count);

            // only query for the instances that have a value for the source attribute
            final AttributeContainerSet notNullAttVal = CriteriaHelper.newCriteria( sourceATI, EmptySet.getUniverseSet() );
            command.appendCriteria( notNullAttVal, false );
				if (!updateTargetAttribute) {
					final AttributeContainerSet nullAttVal = CriteriaHelper.newCriteria(targetATI,
							EmptySet.getEmptySet(true));
					command.appendCriteria(nullAttVal, false);
				}

            BasicFetchPagingRepositoryCommand fetch = new BasicFetchPagingRepositoryCommand();
            fetch.setPageMode(PageMode.EXPLICIT_PAGING);

            command = (BasicQueryCommand) command.execute();
            ResultContainer results = command.getResultContainer();
            if (results.getSize()<=0)
            {
                if (logger.isDebugEnabled())
                {
                    logger.debug("No instance data exist to be moved!");
                }
                return true;
            }

            final Class typeClass = getTypeClass(typeView);

            Transaction trx = null;
            Exception ex = null;
            boolean status = false;
            try
            {
                trx = new Transaction();
                trx.start();

                // add an immutable constraint to source attribute
                addImmutableConstraint2SourceAtt(typeView, sourceAtt);

                pagingSession = (BasicTypePagingSession) command.getResultSession();
                int totalCount = (pagingSession == null) ? 0 : pagingSession.getTotalCount();

                long startTime = 0;
                String range = "";
                if(logger.isInfoEnabled()) {
                    startTime = System.currentTimeMillis();
                    range = offset + "-" + (offset+count);
                    logger.info("Total count of attribute values to move: " + totalCount);
                    logger.info("Begin moving chunk of attribute values " + range);
                }
                final ATT_MOVE_TYPE attMoveType =
                    ATT_MOVE_TYPE.getAttMoveType( sourceAtt.getAttDefClass(), targetAtt.getAttDefClass() );
                status = moveAttributeValues(results, sourceAtt, targetAtt, typeClass, attMoveType );
                if(logger.isInfoEnabled()) {
                    logger.info("Done moving chunk of attribute values " + range + ". Time taken " + (System.currentTimeMillis()-startTime)/(60*1000) + " minutes.");
                }

                while (true)
                {
                    if(logger.isInfoEnabled()) {
                        startTime = System.currentTimeMillis();
                        range = offset + "-" + (offset+count);
                        logger.info("Begin moving chunk of attribute values " + range);
                    }
                    offset += count;
                    if (offset >= totalCount)
                    {
                        break;
                    }

                    pagingSession = new BasicTypePagingSession(pagingSession.getSessionId());
                    fetch.setSession(pagingSession);
                    fetch.setOffset(offset);
                    fetch.setCount(count);
                    fetch = (BasicFetchPagingRepositoryCommand) fetch.execute();

                    results = fetch.getResultContainer();
                    if (results.getSize() > 0)
                    {
                        status = moveAttributeValues(results, sourceAtt, targetAtt, typeClass, attMoveType);
                    }
                    pagingSession = (BasicTypePagingSession) fetch.getResultSession();
                    if(logger.isInfoEnabled()) {
                        logger.info("Done moving chunk of attribute values " + range + ". Time taken " + (System.currentTimeMillis()-startTime)/(60*1000) + " minutes.");
                    }
                }
                trx.commit();
                trx = null;
            }
            catch (Exception e)
            {
                logger.error(e.getLocalizedMessage(), e);
                ex = e;
            }
            finally
            {
                if (pagingSession != null && pagingSession.getSessionId() > 0)
                {
                    BasicClosePagingRepositoryCommand close = new BasicClosePagingRepositoryCommand();
                    close.setSession((RepositoryPagingSession) pagingSession);
                    close.execute();
                }
                if (trx != null)
                {
                   trx.rollback();
                   logger.debug("ERROR: moveAttributes failed! ROLLBACK!");

                   if (ex != null)
                   {
                      throw new WTException(ex);
                   }

                   status = false;
                }
            }
            return status;
        }

        /**
         * Move the values of source attribute to target attribute
         * @param result
         * @param sourceAtt
         * @param targetAtt
         * @param typeClass
         * @param attMoveType The type of attribute move being performed.
         * @return
         * @throws WTPropertyVetoException
         * @throws WTException
         */
        private static boolean moveAttributeValues(final ResultContainer result, final AttributeDefinitionReadView sourceAtt,
                                                   final AttributeDefinitionReadView targetAtt, Class typeClass,
                                                   final ATT_MOVE_TYPE attMoveType )
                        throws WTPropertyVetoException, WTException
        {
            boolean status = false;
            AttributeTypeIdentifier sourceATI = sourceAtt.getAttributeTypeIdentifier();
            if ( ATT_MOVE_TYPE.IBA_2_IBA == attMoveType )
            {
                status = moveIBA2IBA(result, sourceAtt, targetAtt);
            }
            else if ( ATT_MOVE_TYPE.IBA_2_FLEX == attMoveType )
            {
                Map<String, String> targetColNames = getColumnAllocation(targetAtt);
                status = moveIBA2Flex(result, sourceAtt, targetColNames, typeClass);
            }
            else
            {
                Map<String,String> sourceColNames = getColumnAllocation(sourceAtt);
                if ( ATT_MOVE_TYPE.FLEX_2_IBA == attMoveType )
                {
                    status = moveFlex2IBA(result, sourceATI, targetAtt, sourceColNames, typeClass);
                }
                else
                {
                    Map<String, String> targetColNames = getColumnAllocation(targetAtt);
                    if (sourceColNames.size()!=targetColNames.size())
                    {
                        throw new WTException("(moveAttributes): Two flex attributes have different number of columns allocated: source \"" +
                                              sourceAtt.getDatabaseColumnsLabel() + "\", and target \"" +
                                              targetAtt.getDatabaseColumnsLabel() + "\"!");
                    }
                    status = moveFlex2Flex(result, sourceColNames, targetColNames, typeClass);
                }
            }
            return status;
        }

        /**
         * Moves IBA values of source IBA to target IBA.
         * If source IBA has more IBA values than target IBA, those extra IBA values are added
         * to target IBA while others are moved to target IBA. If source IBA has fewer IBA values than target IBA,
         * extra IBA values of target IBA are deleted.
         * @param result
         * @param sourceAttView
         * @param targetAttView
         * @param valueClass
         * @return
         * @throws WTException
         * @throws WTPropertyVetoException
         */
        private static boolean moveIBA2IBA(final ResultContainer result, final AttributeDefinitionReadView sourceAttView,
                                           final AttributeDefinitionReadView targetAttView) throws WTException, WTPropertyVetoException
        {   // update values through PM
            Transaction trx = null;
            Exception ex = null;
            try
            {
                trx = new Transaction();
                trx.start();

                AttributeTypeIdentifier sourceATI = sourceAttView.getAttributeTypeIdentifier();
                Class valueClass = getIBAValueClass(sourceATI);

                // IBA value table: delete batch spec for extra target IBA values
                DeleteBatchSpec delBatchSpec = null;
                List<Long> delIBAIds = new ArrayList<>();

                // IBA value table: create time stamp
                UpdateColumnExpression createStampUpdate = createTimestampUpdateColExpr(valueClass);

                // IBA value table: create new IBA values if needed
                WTList newRecords = new WTArrayList();
                for (int i=0; i<result.getSize(); i++)
                {
                    TypeInstance typeInstance = result.getTypeInstanceAt(i);
                    ArrayList<AttributeIdentifier> sourceAIList = getAIsInList(typeInstance,sourceATI);
                    ArrayList<AttributeIdentifier> targetAIList = getAIsInList(typeInstance,targetAttView.getAttributeTypeIdentifier());

                    int j = 0;
                    for (AttributeIdentifier sourceAI : sourceAIList)
                    {
                        AttributeIdentifier targetAI = null;
                        if (j<targetAIList.size())
                        {
                            targetAI = targetAIList.get(j++);
                        }

                        Long sourceValueId = ((WCPersistableInstanceIdentifier)sourceAI.getInstanceIdentifier()).getOid();
                        Long targetValueId = (targetAI==null)? null : ((WCPersistableInstanceIdentifier)targetAI.getInstanceIdentifier()).getOid();

                        if (targetValueId!=null)
                        {
                            UpdateBatchSpec batchSpec = new UpdateBatchSpec();
                            batchSpec.setTarget(new ClassTableExpression(valueClass));
                            batchSpec.setWhere(new SearchCondition(valueClass, Persistable.PERSIST_INFO + "."
                                                                   + PersistInfo.OBJECT_IDENTIFIER + ".id",
                                                                   SearchCondition.EQUAL, targetValueId));

                            // construct columns
                            Set<String> columns = getColumnNames(sourceAttView);
                            List<UpdateColumnExpression> ibaUpdateColExps = new ArrayList<>(columns.size()+1);
                            ibaUpdateColExps.add(createStampUpdate);
                            for (String colName : columns)
                            {
                                UpdateColumnExpression valueUpdate = new UpdateColumnExpression();
                                valueUpdate.setAttribute(new ClassAttribute(valueClass, colName));
                                // get the corresponding column value from source IBA and set it on the target IBA
                                QuerySpec sub_qs = new QuerySpec();
                                sub_qs.appendClassList(valueClass, false);
                                // updating iba value table
                                sub_qs.appendSelectAttribute(colName, 0, true);
                                sub_qs.appendWhere(new SearchCondition(valueClass, Persistable.PERSIST_INFO + "."
                                                   + PersistInfo.OBJECT_IDENTIFIER + ".id", SearchCondition.EQUAL,
                                                   sourceValueId));
                                ColumnSubSelectExpression csse = new ColumnSubSelectExpression(sub_qs);
                                valueUpdate.setValue(csse);
                                ibaUpdateColExps.add(valueUpdate);
                            }
                            batchSpec.setUpdateColumns(ibaUpdateColExps.toArray(new UpdateColumnExpression[ibaUpdateColExps.size()]));

                            PersistenceServerHelper.manager.execute(batchSpec);

                            if (logger.isDebugEnabled())
                            {
                                logger.debug("Value \"" + typeInstance.get(sourceAI) + "\" of source AttributeIdentifier \"" +
                                             sourceAI + "\" is being moved to target AttributeIdentifier \"" + targetAI + "\"!");
                            }
                        }
                        else
                        {   // no record on the iba value table yet, thus create new IBA values on the target IBA
                            Map<String, Object> values = sourceAttView.decompose(typeInstance.get(sourceAI));
                            IBAHolderReference ibaHolderRef =
                                IBAHolderReference.newIBAHolderReference(TypeInstanceUtility.getObjectReference(typeInstance));
                            newRecords.add(createIBAValue(targetAttView.getIBARefView(), ibaHolderRef, values));

                            if (logger.isDebugEnabled())
                            {
                                logger.debug("Value \"" + typeInstance.get(sourceAI) + "\" of source AttributeIdentifier \""
                                             + sourceAI + "\" is being created on target attribute during the move...");
                            }

                        }
                    } // end of for (AttributeIdentifier sourceAI : sourceAIList)

                    // delete extra target attribute entry in the table
                    for (; j<targetAIList.size(); j++)
                    {
                        if (logger.isDebugEnabled())
                        {
                            logger.debug("Target AttributeIdentifier \"" + targetAIList.get(j) + "\" is being set to null!");
                        }
                        if (delBatchSpec == null)
                        {
                            delBatchSpec = createDelIBADeleteBatchSpec(valueClass);
                        }
                       Long valueId = ((WCPersistableInstanceIdentifier)targetAIList.get(j).getInstanceIdentifier()).getOid();
                       delIBAIds.add(valueId);
                    }
                } // end of for (int i=0; i<result.getSize(); i++)

                // execute iba table addition and deletion
                if (!newRecords.isEmpty())
                {
                    PersistenceHelper.manager.store(newRecords);
                }
                executePM(delBatchSpec, delIBAIds);

                trx.commit();
                trx = null;
            }
            catch (Exception e)
            {
                logger.error(e.getLocalizedMessage(), e);
                ex = e;
            }
            finally
            {
                if (trx != null)
                {
                    trx.rollback();
                    logger.debug("ERROR: moveIBA2IBA failed! ROLLBACK!");

                    if (ex != null)
                    {
                        throw new WTException(ex);
                    }
                    return false;
                }
            }
            return true;
        }

        /** * Moves a Flex attribute's value to an IBA.
         * If the target IBA has no corresponding IBA value, an IBA value with the source
         * Flex attribute's value is created. If the target IBA has multiple values, all except one
         * are deleted while that one being replaced with the Flex attribute's value. But if
         * the Flex attribute's value is null, then all IBA values are deleted.
         * @param result
         * @param flexATI
         * @param attView
         * @param colNames
         * @param ibaValueClass
         * @param typeClass
         * @return
         * @throws WTException
         */
        private static boolean moveFlex2IBA(final ResultContainer result, final AttributeTypeIdentifier flexATI,
                final AttributeDefinitionReadView attView, final Map<String, String> colNames, final Class typeClass)
                throws WTException
        {   // update values through PM
            Transaction trx = null;
            Exception ex = null;

            try
            {
                trx = new Transaction();
                trx.start();

                AttributeTypeIdentifier targetATI = attView.getAttributeTypeIdentifier();
                Class ibaValueClass = getIBAValueClass(targetATI);

                // IBA value table: addition, deletion, and update batch
                // create new IBA values if needed
                WTList newRecords = new WTArrayList();
                // delete batch to delete extra iba values
                DeleteBatchSpec delIBABatchSpec = null;
                List<Long> delIBAIds = new ArrayList<>();
                // update iba value table
                UpdateBatchSpec updateIBABatchSpec = null;
                List<Long> updateIBAIds = new ArrayList<>();

                for (int i=0; i<result.getSize(); i++)
                {
                    TypeInstance typeInstance = result.getTypeInstanceAt(i);
                    boolean needMove = (typeInstance.get(flexATI)!=null);

                    ArrayList<AttributeIdentifier> aiList = getAIsInList(typeInstance, targetATI);
                    if (needMove && aiList.isEmpty())
                    {   // no record on the iba value table yet, thus create new IBA values
                        Map<String, Object> values = attView.decompose(typeInstance.get(flexATI));
                        IBAHolderReference ibaHolderRef =
                            IBAHolderReference.newIBAHolderReference(TypeInstanceUtility.getObjectReference(typeInstance));
                       newRecords.add(createIBAValue(attView.getIBARefView(), ibaHolderRef, values));
                    }
                    else
                    {
                        for (AttributeIdentifier ai : aiList)
                        {
                            Long ibaId = ((WCPersistableInstanceIdentifier)ai.getInstanceIdentifier()).getOid();
                            if (needMove)
                            {
                                needMove = false;
                                if (updateIBABatchSpec == null)
                                {
                                    Map<String,String> newColNames = colNames;
                                    //special handling for StringValue iba value table
                                    if (attView.getDatatype().getName().equals(String.class.getName()))
                                    {
                                        newColNames = refreshColNames(colNames);
                                    }
                                    updateIBABatchSpec = createUpdateBatchSpec(typeClass, ibaValueClass, newColNames, null);
                                }
                                updateIBAIds.add(ibaId);

                                if (logger.isDebugEnabled())
                                {
                                    logger.debug("Value \"" + typeInstance.get(flexATI) +
                                                 "\" of source AttributeIdentifier is being moved to target AttributeIdentifier \""
                                                 + ai + "\"!");
                                }
                            }
                            else
                            {   // delete extra iba values
                                if (delIBABatchSpec == null)
                                {
                                    delIBABatchSpec = createDelIBADeleteBatchSpec(ibaValueClass);
                                }
                                delIBAIds.add(ibaId);
                                if (logger.isDebugEnabled())
                                {
                                    logger.debug("Value \"" + typeInstance.get(ai) + "\" of target AttributeIdentifier \""
                                                 + ai + "\" is being deleted during the move...");
                                }
                            } // end of if (needMove)
                        } // end of for (AttributeIdentifier ai : aiList)
                    } // end of if (needMove && aiList.isEmpty())x
                } // end of for (int i=0; i<result.getSize(); i++)
                // execute iba table addition, deletion, and update
                if (!newRecords.isEmpty())
                {
                    PersistenceHelper.manager.store(newRecords);
                }
                executePM(delIBABatchSpec, delIBAIds);
                executePM(updateIBABatchSpec, updateIBAIds);

                trx.commit();
                trx = null;
            }
            catch (Exception e)
            {
                logger.error(e.getLocalizedMessage(), e);
                ex = e;
            }
            finally
            {
                if (trx != null)
                {
                    trx.rollback();
                    logger.debug("ERROR: moveFlex2IBA failed! ROLLBACK!");

                    if (ex != null)
                    {
                        throw new WTException(ex);
                    }
                    return false;
                }
            }
            return true;
        }

        /**
         * Moves one of the source IBA's values to the target Flex attribute.
         * If the source IBA doesn't have any value, the corresponding Flex attribute is set to null.
         * If the source IBA has multiple values, all except one are deleted and that one is
         * moved to the target Flex attribute.
         * @param result
         * @param ati
         * @param colNames
         * @param ibaValueClass
         * @param typeClass
         * @return
         * @throws WTException
         */
        private static boolean moveIBA2Flex(final ResultContainer result, final AttributeDefinitionReadView attView,
                                            final Map<String, String> colNames, final Class typeClass) throws WTException
        {   // update values through PM
            Transaction trx = null;
            Exception ex = null;

            try
            {
                trx = new Transaction();
                trx.start();

                AttributeTypeIdentifier sourceATI = attView.getAttributeTypeIdentifier();
                Class ibaValueClass = getIBAValueClass(sourceATI);

                // Type table:
                // update batch to update flex attribute's column values with iba values
                UpdateBatchSpec updateTypeBatchSpec = null;
                List<Long> updateTypeIds = new ArrayList<>();
                // in the special case of no iba value exists, update batch to set corresponding flex columns to null
                UpdateBatchSpec nullTypeBatchSpec = null;
                List<Long> nullTypeIds = new ArrayList<>();

                for (int i=0; i<result.getSize(); i++)
                {
                    TypeInstance typeInstance = result.getTypeInstanceAt(i);
                    Long typeId =
                        ((WCPersistableInstanceIdentifier)(typeInstance.getIdentifier().getInstanceIdentifier())).getOid();
                    ArrayList<AttributeIdentifier> aiList = getAIsInList(typeInstance, sourceATI);

                    boolean noIBAUpdated = true;
                    for (AttributeIdentifier ai : aiList)
                    {
                        if (noIBAUpdated)
                        {
                            noIBAUpdated = false;
                            // attribute entry being moved in the iba value table
                            if (updateTypeBatchSpec == null)
                            {
                                updateTypeBatchSpec =
                                    createUpdateBatchSpec(ibaValueClass, typeClass, colNames, attView.getIBARefView().getObjectID());
                            }
                            updateTypeIds.add(typeId);

                            if (logger.isDebugEnabled())
                            {
                                logger.debug("Value \"" + typeInstance.get(ai) + "\" of source AttributeIdentifier \""
                                             + ai + "\" is being moved to target Attribute!");
                            }
                        }
                        else
                        {  // extra attribute entry in the iba value table
                            if (logger.isDebugEnabled())
                            {
                                logger.debug("Value \"" + typeInstance.get(ai) + "\" of source AttributeIdentifier \""
                                             + ai + "\" is being skipped during the move...");
                            }
                        } // end of if (noIBAUpdated)
                    } // end of for (AttributeIdentifier ai : aiList)
                    // there is no IBA for this type instance, thus set corresponding columns on type table to null
                    if (noIBAUpdated)
                    {
                        if (nullTypeBatchSpec == null)
                        {
                            nullTypeBatchSpec = createNullTypeUpdateBatchSpec(typeClass, colNames);
                        }
                        nullTypeIds.add(typeId);
                    }
                } // end of for (int i=0; i<result.getSize(); i++)

                // execute type table update
                executePM(updateTypeBatchSpec, updateTypeIds);
                // execute setting null to corresponding columns on type table
                executePM(nullTypeBatchSpec, nullTypeIds);

                trx.commit();
                trx = null;
            }
            catch (Exception e)
            {
                logger.error(e.getLocalizedMessage(), e);
                ex = e;
            }
            finally
            {
                if (trx != null)
                {
                    trx.rollback();
                    logger.debug("ERROR: moveIBA2Flex failed! ROLLBACK complete!");
                    if (ex != null)
                    {
                        throw new WTException(ex);
                    }
                    return false;
                }
            }
            return true;
        }

        /**
         * Move value from the source Flex attribute to the target Flex attribute.
         * @param result
         * @param sourceColNames
         * @param targetColNames
         * @param typeClass
         * @return
         * @throws WTException
         */
        private static boolean moveFlex2Flex(final ResultContainer result, final Map<String, String> sourceColNames,
                                             final Map<String, String> targetColNames, final Class typeClass) throws WTException
        {   // update values through PM
            Transaction trx = null;
            Exception ex = null;

            try
            {
                trx = new Transaction();
                trx.start();

                UpdateBatchSpec batchSpec = null;
                List<Long> typeIds = new ArrayList<>();
                for (int i=0; i<result.getSize(); i++)
                {
                    if (batchSpec == null)
                    {
                        batchSpec = new UpdateBatchSpec();
                        batchSpec.setTarget(new ClassTableExpression(typeClass));

                        // update columns
                        List<UpdateColumnExpression> updateColExps = new ArrayList<>(sourceColNames.size()+1);
                        UpdateColumnExpression createStampUpdate = createTimestampUpdateColExpr(typeClass);
                        updateColExps.add(createStampUpdate);

                        for (Map.Entry<String, String> entry : sourceColNames.entrySet())
                        {
                            String columnKey = entry.getKey();
                            String srcColAttName = entry.getValue();
                            String trgColAttName = targetColNames.get(columnKey);
                            UpdateColumnExpression targetUpdate = new UpdateColumnExpression();
                            targetUpdate.setAttribute(new ClassAttribute(typeClass, trgColAttName));
                            targetUpdate.setValue(new ClassAttribute(typeClass, srcColAttName));
                            updateColExps.add(targetUpdate);
                        }
                        batchSpec.setUpdateColumns(updateColExps.toArray(new UpdateColumnExpression[updateColExps.size()]));
                    }

                    TypeInstance typeInstance = result.getTypeInstanceAt(i);
                    Long typeId =
                        ((WCPersistableInstanceIdentifier)(typeInstance.getIdentifier().getInstanceIdentifier())).getOid();
                    typeIds.add(typeId);
                }

                // execute
                executePM(batchSpec, typeIds);

                trx.commit();
                trx = null;
            }
            catch (Exception e)
            {
                logger.error(e.getLocalizedMessage(), e);
                ex = e;
            }
            finally
            {
                if (trx != null)
                {
                    trx.rollback();
                    logger.debug("ERROR: moveFlex2Flex failed! ROLLBACK complete!");

                    if (ex != null)
                    {
                        throw new WTException(ex);
                    }
                    return false;
                }
            }
            return true;
        }

        /**
         * Gets the value class of the specified attribute type identifier.
         * @param ati
         * @return The IBA value class where the value of this attribute type identifier is stored.
         * @throws WTException
         */
        private static Class getIBAValueClass(AttributeTypeIdentifier ati) throws WTException, ClassNotFoundException
        {
            if (ati instanceof InstanceBasedAttributeTypeIdentifier)
            {
                return HandlerUtil.getValueClass((InstanceBasedAttributeTypeIdentifier)ati);
            }
            else if (ati instanceof InstanceBasedAssociationTypeIdentifier)
            {
                AbstractAttributeDefinition definition =
                    IBAModel.getIBADefinitionByHid(((InstanceBasedAssociationTypeIdentifier)ati).getExtHID());
                final Class valueClass;
                if ( ClassCache.isValidClass( definition.getValueClassname() ) )
                {
                    valueClass = ClassCache.getClass( definition.getValueClassname() );
                }
                else
                {
                    valueClass = null;
                }
                return valueClass;
            }
            else
            {
                throw new WTException("LWCIBAAttDefinition has an invalid AttributeTypeIdentifier: \"" +
                                      ati.toExternalForm() + "\"!");
            }
        }

        private static Persistable createIBAValue(AttributeDefDefaultView iba, IBAHolderReference ibaHolderRef,
                                                  Map<String, Object> values) throws WTException, WTPropertyVetoException
        {
            Persistable ibaValue = null;
            if (iba instanceof StringDefView)
            {
                StringDefinitionReference defRef =
                    StringDefinitionReference.newStringDefinitionReference((StringDefView)iba);
                StringValue value = new StringValue();
                value.setDefinitionReference(defRef);
                value.setIBAHolderReference(ibaHolderRef);
                value.setValue((String)values.get(StringDatatypeHandler.VALUE));
                ibaValue = value;
            }
            else if (iba instanceof BooleanDefView)
            {
                BooleanDefinitionReference defRef =
                    BooleanDefinitionReference.newBooleanDefinitionReference((BooleanDefView)iba);
                BooleanValue value = new BooleanValue();
                value.setDefinitionReference(defRef);
                value.setIBAHolderReference(ibaHolderRef);
                value.setValue(((Boolean)values.get(BooleanDatatypeHandler.VALUE)).booleanValue());
                ibaValue = value;
            }
            else if (iba instanceof IntegerDefView)
            {
                IntegerDefinitionReference defRef = IntegerDefinitionReference.newIntegerDefinitionReference((IntegerDefView)iba);
                IntegerValue value = new IntegerValue();
                value.setDefinitionReference(defRef);
                value.setIBAHolderReference(ibaHolderRef);
                value.setValue(((Long)values.get(LongDatatypeHandler.VALUE)).longValue());
                ibaValue = value;
            }
            else if (iba instanceof FloatDefView)
            {
                FloatDefinitionReference defRef = FloatDefinitionReference.newFloatDefinitionReference((FloatDefView)iba);
                FloatValue value = new FloatValue();
                value.setDefinitionReference(defRef);
                value.setIBAHolderReference(ibaHolderRef);
                value.setValue(((Double)values.get(FloatingPointDatatypeHandler.VALUE)).doubleValue());
                value.setPrecision(((Number)values.get(FloatingPointDatatypeHandler.PRECISION)).intValue());
                ibaValue = value;
            }
            else if (iba instanceof URLDefView )
            {
                URLDefinitionReference defRef = URLDefinitionReference.newURLDefinitionReference((URLDefView)iba);
                URLValue value = new URLValue();
                value.setDefinitionReference(defRef);
                value.setIBAHolderReference(ibaHolderRef);
                value.setValue((String)values.get(HyperlinkDatatypeHandler.LINK));
                value.setDescription((String)values.get(HyperlinkDatatypeHandler.LABEL));
                ibaValue = value;
            }
            else if (iba instanceof TimestampDefView)
            {
                TimestampDefinitionReference defRef =
                    TimestampDefinitionReference.newTimestampDefinitionReference((TimestampDefView)iba);
                TimestampValue value = new TimestampValue();
                value.setDefinitionReference(defRef);
                value.setIBAHolderReference(ibaHolderRef);
                value.setValue((Timestamp)values.get(TimestampDatatypeHandler.VALUE));
                ibaValue = value;
            }
            else if (iba instanceof UnitDefView)
            {
                UnitDefinitionReference defRef = UnitDefinitionReference.newUnitDefinitionReference((UnitDefView)iba);
                UnitValue value = new UnitValue();
                value.setDefinitionReference(defRef);
                value.setIBAHolderReference(ibaHolderRef);
                value.setValue(((Double)values.get(FloatingPointDatatypeHandler.VALUE)).doubleValue());
                value.setPrecision(((Number)values.get(FloatingPointDatatypeHandler.PRECISION)).intValue());
                ibaValue = value;
            }
            else if (iba instanceof ReferenceDefView )
            {
                ReferenceDefinitionReference defRef =
                    ReferenceDefinitionReference.newReferenceDefinitionReference((ReferenceDefView)iba);
                ReferenceValue value = new ReferenceValue();
                value.setDefinitionReference(defRef);
                value.setIBAHolderReference(ibaHolderRef);
                IBAReferenceableReference refRef =
                    IBAReferenceableReference.newIBAReferenceableReference(TypeIdentifierUtility.getObjectReference((TypeInstanceIdentifier)values.get(ReferenceDatatypeHandler.VALUE)));
                value.setIBAReferenceableReference(refRef);
                ibaValue = value;
            }
            else
            {
                logger.error("Unknown IBA definition class: \""+ iba+"\"!");
                throw new WTException("Unknown IBA definition class: \""+iba + "\"!");
            }
            return ibaValue;
        }

        private static ArrayList<AttributeIdentifier> getAIsInList(TypeInstance typeInstance, AttributeTypeIdentifier ati)
        {
            if (!(ati instanceof InstanceBasedAttributeTypeIdentifier))
            {
                if (logger.isDebugEnabled())
                {
                    logger.debug("ati is not of IBA related: " + ati);
                }
                return new ArrayList<>(0);
            }
            AttributeIdentifier[] ais = typeInstance.getAttributeIdentifiers(ati);
            ArrayList<AttributeIdentifier> aiList = new ArrayList<>(ais.length);
            for (AttributeIdentifier ai : ais)
            {
                if ( ai.getInstanceIdentifier() instanceof WCPersistableInstanceIdentifier)
                {
                    aiList.add(ai);
                }
            }
            return aiList;
        }

        /**
         * Gets the class of the least-important modeled type, the most-important being the root type,
         * in the type hierarchy tree of the specified type view.
         * @param typeView
         * @return Class
         * @throws ClassNotFoundException
         * @throws WTException
         */
        private static Class getTypeClass(TypeDefinitionReadView typeView) throws ClassNotFoundException, WTException
        {
            final Class modeledClass;
            if ( typeView.getAttTemplateFlavor() == AttributeTemplateFlavor.LWCTYPE )
            {
                final String className = typeView.getTypeIdentifier().getTableClassName();
                if ( ClassCache.isValidClass( className ) )
                {  // this should always be the case
                    Class tmpClass = null;
                    try
                    {
                        tmpClass = ClassCache.getClass( className );
                    }
                    catch ( ClassNotFoundException cnfe )
                    {   // should never happen
                        logger.error( "couldn't find class for: " + className, cnfe );
                    }
                    modeledClass = tmpClass;
                }
                else
                {
                    modeledClass = null;
                }
            }
            else
            {
                modeledClass = null;
            }
            return modeledClass;
        }

        private static ColumnExpression getNullExpression(Class typeClass, String attName)
                        throws PersistenceException, ClassNotFoundException, WTException
        {   //get ColumnDescriptor for the column
            ColumnDescriptor cd = DatabaseInfoUtilities.getPersistableColumnDescriptor(typeClass, attName);
            String javaType = cd.getJavaType();
            if (Object.class.getName().equals(javaType))
            {
                javaType = String.class.getName();
            }
            final Class attClass;
            if ( ClassCache.isValidClass( javaType ) )
            {
                attClass = ClassCache.getClass( javaType );
            }
            else
            {
                attClass = null;
            }
            return KeywordExpression.Keyword.NULL.newKeywordExpression(attClass);
        }

        private static void executePM(AbstractBatchSpec batchSpec, List<Long> ids) throws WTPropertyVetoException, WTException
        {
            if (batchSpec!=null)
            {
                batchSpec.setWhere(new SearchCondition(batchSpec.getTarget().getTableClass(), Persistable.PERSIST_INFO + "."
                                                       + PersistInfo.OBJECT_IDENTIFIER + ".id", toPrimitive(ids)));
                PersistenceServerHelper.manager.execute(batchSpec);
            }
        }

        private static UpdateBatchSpec createUpdateBatchSpec(Class fromClass, Class toClass, Map<String,String> colNames,
                                                             ObjectIdentifier ibaDefId)
                            throws WTPropertyVetoException, QueryException, WTException
        {
            UpdateBatchSpec batchSpec = new UpdateBatchSpec();
            ClassTableExpression targetClass = new ClassTableExpression(toClass);
            targetClass.setDescendantsIncluded(false);
            batchSpec.setTarget(targetClass);
            // construct update columns
            List<UpdateColumnExpression> updateColExps = new ArrayList<>(colNames.size()+1);
            UpdateColumnExpression ibaCreateStampUpdate = createTimestampUpdateColExpr(toClass);
            updateColExps.add(ibaCreateStampUpdate);
            for (Map.Entry<String, String> entry : colNames.entrySet())
            {   // IBA value table column Name
                String ibaColumn = entry.getKey();
                if (fromClass.equals(URLValue.class))
                {
                    if (ibaColumn.equals(HyperlinkDatatypeHandler.LABEL))
                    {
                        ibaColumn = "description"; // The Global URL attribute's label is "description" column in URLValue table.
                    }
                    if (ibaColumn.equals(HyperlinkDatatypeHandler.LINK))
                    {
                        ibaColumn = "value";  // The Global URL attribute's link is "value" column in URLValue table.
                    }
                }
                // type table flex column Name
                String flexColumn = entry.getValue();

                UpdateColumnExpression targetUpdate = new UpdateColumnExpression();
                if (ibaDefId == null)
                {
                    targetUpdate.setAttribute(new ClassAttribute(toClass, ibaColumn)); // updating iba value table
                }
                else
                {
                    targetUpdate.setAttribute(new ClassAttribute(toClass, flexColumn)); // updating type table
                }

                // get the corresponding column value from fromClass and set it on toClass
                QuerySpec sub_qs = new QuerySpec();
                if (ibaDefId == null)
                {
                    sub_qs.appendClassList(fromClass, false);
                    sub_qs.getFromClause().setAliasPrefix("id_table");
                    // updating iba value table
                    if (StringValue.class.getName().equals(toClass.getName())
                        && ibaColumn.equals(StringValue.VALUE))
                    {   // special handling for StringValue.value columnx
                        sub_qs.appendSelect(SQLFunction.newSQLFunction(SQLFunction.UPPER,
                                            new ClassAttribute(fromClass, flexColumn)), true);
                    }
                    else
                    {
                        sub_qs.appendSelectAttribute(flexColumn, 0, true);
                    }
                    sub_qs.appendWhere(new SearchCondition(
                                           new ClassAttribute(fromClass, Persistable.PERSIST_INFO + "."
                                                              + PersistInfo.OBJECT_IDENTIFIER + "." + ObjectIdentifier.ID,
                                                              sub_qs.getFromClause().getAliasAt(0)),
                                           SearchCondition.EQUAL,
                                           new ClassAttribute(toClass, AbstractValue.IBAHOLDER_REFERENCE + "."
                                                              + ObjectReference.KEY + "." + ObjectIdentifier.ID,
                                                              batchSpec.getTargetTableName())));
                }
                else
                {   // updating type table
                    // create a sub view so that sub-query is ensured to return one record only
                    // because the type table update batch spec only works correctly when
                    // the sub query of iba value table returns exactly one record
                    // example SQL for StringValue table:
                    //      select a0.idA3A4, a0.idA3A6, a0.idA2A2, a1.value2
                    //      from ( SELECT idA3A4, idA3A6, max(idA2A2) idA2A2
                    //                  FROM StringValue
                    //              group by idA3A4, idA3A6 ) a0, StringValue a1
                    //      where a0.idA2A2= a1.idA2A2
                    QuerySpec sub_from = new QuerySpec();
                    sub_from.appendClassList(fromClass, false);
                    sub_from.getFromClause().setAliasPrefix("max_table");
                    ClassAttribute ibaHolderRef = new ClassAttribute (fromClass, AbstractValue.IBAHOLDER_REFERENCE + "."
                                                                      + ObjectReference.KEY + "." + ObjectIdentifier.ID);
                    ibaHolderRef.setColumnAlias("idA3A4");
                    sub_from.appendSelect(ibaHolderRef, 0, false);
                    ClassAttribute ibaDefRef =  new ClassAttribute (fromClass, DEFINITION_REF_ID);
                    ibaDefRef.setColumnAlias("idA3A6");
                    sub_from.appendSelect(ibaDefRef, 0, false);
                    SQLFunction max_idA2A2 =
                        SQLFunction.newSQLFunction( DatastoreFunction.MAXIMUM,
                                                    new ClassAttribute( fromClass, WTAttributeNameIfc.ID_NAME));
                    max_idA2A2.setColumnAlias("idA2A2");
                    sub_from.appendSelect(max_idA2A2, 0, false);
                    sub_from.appendGroupBy(ibaHolderRef,0, false);
                    sub_from.appendGroupBy(ibaDefRef, 0, false);

                    sub_qs.appendFrom( new SubSelectExpression(sub_from));
                    sub_qs.appendClassList(fromClass, false);
                    sub_qs.appendSelectAttribute(ibaColumn, 1, true);
                    sub_qs.getFromClause().setAliasPrefix("id_table");

                    sub_qs.appendWhere(new SearchCondition(new ClassAttribute(fromClass, Persistable.PERSIST_INFO + "."
                                                                              + PersistInfo.OBJECT_IDENTIFIER + "." + ObjectIdentifier.ID,
                                                                              sub_qs.getFromClause().getAliasAt(0)),
                                                           SearchCondition.EQUAL,
                                                           new ClassAttribute(fromClass, Persistable.PERSIST_INFO + "."
                                                                              + PersistInfo.OBJECT_IDENTIFIER + "." + ObjectIdentifier.ID,
                                                                              sub_qs.getFromClause().getAliasAt(1))));
                    sub_qs.appendAnd();
                    sub_qs.appendWhere(new SearchCondition(new ClassAttribute (fromClass, AbstractValue.IBAHOLDER_REFERENCE
                                                                                + "." + ObjectReference.KEY + "." + ObjectIdentifier.ID,
                                                                               sub_qs.getFromClause().getAliasAt(0)),
                                                           SearchCondition.EQUAL,
                                                           new ClassAttribute(toClass, Persistable.PERSIST_INFO + "."
                                                                              + PersistInfo.OBJECT_IDENTIFIER + "." + ObjectIdentifier.ID,
                                                                              batchSpec.getTargetTableName())));
                    sub_qs.appendAnd();
                    sub_qs.appendWhere(new SearchCondition(fromClass, DEFINITION_REF_ID,
                                        SearchCondition.EQUAL, ibaDefId.getId()));
                } // end of if (ibaId == null)

                ColumnSubSelectExpression csse = new ColumnSubSelectExpression(sub_qs);
                targetUpdate.setValue(csse);
                updateColExps.add(targetUpdate);
           } // end of for (Map.Entry<String, String> entry : colNames.entrySet())

           batchSpec.setUpdateColumns(updateColExps.toArray(new UpdateColumnExpression[updateColExps.size()]));
           return batchSpec;
        }

        private static UpdateBatchSpec createNullTypeUpdateBatchSpec(Class typeClass, Map<String,String> colNames)
            throws WTPropertyVetoException, QueryException, PersistenceException, ClassNotFoundException, WTException
        {
            UpdateBatchSpec nullTypeBatchSpec = new UpdateBatchSpec();
            nullTypeBatchSpec.setTarget(new ClassTableExpression(typeClass));

            // construct columns to be nulled
            List<UpdateColumnExpression> updateColExps = new ArrayList<>(colNames.size()+1);
            UpdateColumnExpression createStampUpdate = createTimestampUpdateColExpr(typeClass);
            updateColExps.add(createStampUpdate);

            for (Map.Entry<String, String> entry : colNames.entrySet())
            {
                String colAttName = entry.getValue();
                UpdateColumnExpression targetUpdate = new UpdateColumnExpression();
                targetUpdate.setAttribute(new ClassAttribute(typeClass, colAttName));
                targetUpdate.setValue(getNullExpression(typeClass, colAttName));
                updateColExps.add(targetUpdate);
            }
            nullTypeBatchSpec.setUpdateColumns(updateColExps.toArray(new UpdateColumnExpression[updateColExps.size()]));
            return nullTypeBatchSpec;
        }

        private static DeleteBatchSpec createDelIBADeleteBatchSpec(Class ibaValueClass) throws WTPropertyVetoException
        {
            DeleteBatchSpec delIBABatchSpec = new DeleteBatchSpec();
            delIBABatchSpec.setTarget(new ClassTableExpression(ibaValueClass));
            return delIBABatchSpec;
        }

        private static UpdateColumnExpression createTimestampUpdateColExpr(Class className)
                        throws QueryException, WTPropertyVetoException
        {
            UpdateColumnExpression createStampUpdate = new UpdateColumnExpression();
            createStampUpdate.setAttribute(new ClassAttribute(className, WTAttributeNameIfc.CREATE_STAMP_NAME));
            createStampUpdate.setValue(DateExpression.newExpression(TS_UPDATE_VALUE));
            return createStampUpdate;
        }

        private static long[] toPrimitive(List<Long> aList)
        {
            long[] ids = new long[aList.size()];
            for (int i=0;i<aList.size();i++)
            {
                ids[i] = aList.get(i);
            }
            return ids;
        }

        /**
         * A workaround for String datatype since StringValue has two columns for its value and "value" column
         * actually stores the capitalized value of "value2" column which stores the real value.
         * @param attView
         * @return
         */
        private static Map<String,String> getColumnAllocation(AttributeDefinitionReadView attView)
        {
            Map<String, String> targetColNames = attView.getColumnAllocations();
            if (String.class.getName().equals(attView.getDatatype().getName()) && targetColNames.size()==1)
            {
                Map<String,String> copy = new HashMap<>(targetColNames.size()+1);
                copy.put(StringValue.VALUE2, targetColNames.get(StringValue.VALUE));
                return copy;
            }
            else
            {
                return targetColNames;
            }
        }

        /**
         * A workaround for String datatype since StringValue has two columns for its value and "value" column
         * actually stores the capitalized value of "value2" column which stores the real value.
         * @param attView
         * @return
         */
        private static Set<String> getColumnNames(AttributeDefinitionReadView attView)
        {
            Set<String> columnNames;
            if (String.class.getName().equals(attView.getDatatype().getName()))
            {
                columnNames = new HashSet<>(2);
                columnNames.addAll(attView.getDatatype().getColumnTypeMapping().keySet());
                columnNames.add(StringValue.VALUE2);
            }
            else
            {
                columnNames = attView.getDatatype().getColumnTypeMapping().keySet();
            }
            return columnNames;
        }

        /**
         * A workaround for String datatype since StringValue has two columns for its value and "value" column
         * actually stores the capitalized value of "value2" column which stores the real value.x
         * @param attViewx
         * @return
         */
        private static Map<String,String> refreshColNames(final Map<String,String> colNames)
        {
            Map<String,String> copy = new HashMap<>(colNames.size()+1);
            copy.putAll(colNames);
            copy.put(StringValue.VALUE, colNames.get(StringValue.VALUE2));
            return copy;
        }

        private static void addImmutableConstraint2SourceAtt(TypeDefinitionReadView typeView,
                                                             AttributeDefinitionReadView attView) throws WTException
        {
            ConstraintRuleDefinitionReadView constraintRule;
            try
            {
                constraintRule =
                    BASE_DEF_SERVICE.getConstraintRuleDefView(IMMUTABLE_CONSTRAINT, BASIC_DEFCLASSNAME, attView.getDatatype().getId(), null);
            }
            catch (Exception ex)
            {
                throw new WTException(ex);
            }
            if (constraintRule==null)
            {
                throw new WTException("Referenced Immutable ConstraintRule Definition has NOT been loaded!");
            }
            ConstraintDefinitionWriteView constraintWritable =
                new ConstraintDefinitionWriteView( constraintRule/*rule*/, null/*ruleData*/,
                                                   attView.getName()/*attName*/, null/*inputProps*/,
                                                   typeView.getOid()/*contextId*/, null/*loadID*/);
            TypeDefinitionWriteView typeWritable = typeView.getWritableView();
            AttributeDefinitionWriteView attWritable = attView.getWritableView();
            attWritable.setConstraintDefinition(constraintWritable);
            typeWritable.setAttribute(attWritable);
            LWCTYPE_DEF_SERVICE.updateTypeDef(typeWritable);
        }
    }
}