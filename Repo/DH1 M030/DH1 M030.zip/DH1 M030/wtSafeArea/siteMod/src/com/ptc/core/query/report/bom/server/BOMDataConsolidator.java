/* bcwti
 *
 * Copyright (c) 2010 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */
package com.ptc.core.query.report.bom.server;


import java.util.HashMap;
import java.util.Properties;
import java.util.Stack;

import wt.filter.NavigationCriteria;
import wt.part.Part;
import wt.part.Quantity;
import wt.part.QuantityUnit;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.part.WTPartUsageLink;
import wt.util.WTException;


class  BOMDataConsolidator
  extends AbstractBOMReportDataMaker
{
  /** 'rootPartQuantities' is an optional hash between root part
      master ids and quantity Number's.  Without it root
      quantities are assumed to be 1.
      <p>
      'consolidatedBOM' is a HashMap between Part ant
      and Quantity.
   */
  public  BOMDataConsolidator(  int reportTypes[], Properties reportInputs,
                           HashMap rootPartQuantities,
                           HashMap consolidatedBOM )
  {
    super( reportTypes, reportInputs );
    this.rootPartQuantities = rootPartQuantities;
    this.consolidatedBOM = consolidatedBOM;
    rolledUpQuantities = new Stack();
  }

  /** Reset part quantities and consolidated BOM data set.  Note that
      this does not reset the sets of ids collected for use with
      the specified Reportables.
        @param rootPartQuantities  Optional hash between root part
           masters and quantity Number's.  Without it root
           quantities are assumed to be 1.
        @param consolidatedBOM  HashMap between ConsolidatedBOMKey's
           and ConsolidatedBOMEntry's
  */
  void  resetParts( HashMap rootPartQuantities, HashMap consolidatedBOM )
  {
    this.rootPartQuantities = rootPartQuantities;
    this.consolidatedBOM = consolidatedBOM;
  }

  /** Called when BOM traversal is started.
      <p>
      Return 'false' to prevent traversal of sub-tree, else return 'true'.
   */
  public boolean  beginBOM( Part rootPart, NavigationCriteria navCriteria, int levelLimit )
    throws WTException
  {
    // Determine and push initial quantity multiplier
    Number  initialQuantity = null;
    if ( rootPart != null )
      if ( rootPartQuantities != null )
      {
        WTPartMaster  partMaster = ( ( rootPart instanceof WTPartMaster ) ? (WTPartMaster) rootPart : (WTPartMaster) ((WTPart)rootPart).getMaster() );
        Long  masterId = new Long( ( partMaster != null ) ? partMaster.getPersistInfo().getObjectIdentifier().getId() : -1 );
        initialQuantity = (Number) rootPartQuantities.get( masterId );
      }
    if ( initialQuantity == null )
      initialQuantity = new Double( 1.0 );
    rolledUpQuantities.push( initialQuantity );

    // Remember levelLimit
    this.levelLimit = levelLimit;

    // Collect top-level part
    return ( beginPartUsage( null, null, rootPart, 0, true ) );  // BEWARE: We don't actually know if 'rootPart' has children!!!
  }

  /** Called when BOM traversal is completed.
   */
  public void  endBOM( Part rootPart, NavigationCriteria navCriteria, int levelLimit )
    throws WTException
  {
    endPartUsage( null, null, rootPart, 0, true );  // BEWARE: We have already forgotten if 'rootPart' has children!!!
    rolledUpQuantities.pop();  // pop initial quantity off stack
  }

  /** Called when traversal of a given part usage is started.
      <p>
      Return 'false' to prevent traversal of sub-tree, else return 'true'.
   */
  public boolean beginPartUsage(WTPart parentPart, WTPartUsageLink usageLink,
			Part partNode, int level, boolean hasChildren) throws WTException {
		// compute new rolled up quantity and push it on the stack; also
		// determine units
		double rolledUpQuantity;
		QuantityUnit units = QuantityUnit.EA;
		{
			double linkQuantity = 1.0;
			if (usageLink != null) {
				Quantity quantityObj = usageLink.getQuantity();
				linkQuantity = quantityObj.getAmount();
				units = quantityObj.getUnit();
			}
			Number previousQuantity = (Number) rolledUpQuantities.lastElement();
			rolledUpQuantity = previousQuantity.doubleValue() * linkQuantity;
		}
		rolledUpQuantities.push(new Double(rolledUpQuantity));

		// Determine if this part should be collected as part of the
		// consolidated BOM
		/*
		 * Currently only component parts and those parts in the last level of
		 * BOM traversal are considered as being of interest in the consolidated
		 * BOM.
		 */

		//Commented out with ticket KNORRBREMSE_RAILPLM-3652 - all sub-assemblies need to be in the report
//		boolean shouldCollect = !hasChildren
//				|| ((levelLimit >= 0) && (level >= levelLimit));
//		if (!shouldCollect)
//			return (true);


		// collate BOM entry
		HashMap<Object, Double> unitsToQuantityMap = (HashMap<Object, Double>)consolidatedBOM.get(partNode);
		if (unitsToQuantityMap == null) {
			unitsToQuantityMap = new HashMap<Object, Double>();
			consolidatedBOM.put((WTPart)partNode, unitsToQuantityMap);
		}

		Double quantity = (Double) unitsToQuantityMap.get(units);
		if (quantity == null) {
			quantity = new Double(rolledUpQuantity);
		} else {
			quantity = new Double(quantity.doubleValue() + rolledUpQuantity);
		}

		unitsToQuantityMap.put(units, quantity);


		// call all data collectors
		callDataCollectors(parentPart, usageLink, partNode, level, hasChildren);

		// keep traversing
		return (true);
	}

  public void addRecursivePartMarker(WTPart partNode) {
	  HashMap<Object, Double> unitsToQuantityMap = (HashMap<Object, Double>)consolidatedBOM.get(partNode);
	  if (unitsToQuantityMap == null) {
		  unitsToQuantityMap = new HashMap<Object, Double>();
		  consolidatedBOM.put((WTPart)partNode, unitsToQuantityMap);
	  }

	  unitsToQuantityMap.put(new RecursiveStructureError(), new Double(0.0));
  }
  
  
  /**
	 * Called when traversal of a given part usage is completed.
	 */
  public void  endPartUsage( WTPart parentPart, WTPartUsageLink usageLink,
                             Part partNode, int level, boolean hasChildren )
    throws WTException
  {
    rolledUpQuantities.pop();
  }


  private HashMap  rootPartQuantities;
  private HashMap<WTPart, HashMap<Object, Double>>  consolidatedBOM;
  private Stack  rolledUpQuantities;  // pay synchronization cost for nice stack API
  private int  levelLimit;

}
