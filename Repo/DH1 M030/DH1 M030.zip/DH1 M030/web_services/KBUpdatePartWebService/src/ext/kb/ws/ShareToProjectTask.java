package ext.kb.ws;

import java.lang.invoke.MethodHandles;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ptc.netmarkets.model.NmOid;

import ext.kb.project.ProjectHelper;
import wt.identity.IdentityFactory;
import wt.part.WTPart;
import wt.util.WTProperties;

public class ShareToProjectTask {

	private static final Logger log = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());

	public static void execute(String oid) {
		log.debug("--> execute(oid = [{}])", oid);
		try {
			WTPart part = (WTPart) NmOid.newNmOid(oid).getRefObject();
			log.debug("WTPart -> [{}]", IdentityFactory.getDisplayIdentifier(part));

			if (part != null) {
				ProjectHelper.updateItemInRelatedSharedProjects(part);
			}
		} catch (Exception e) {
			log.error("error", e);
		}
		log.debug("<-- execute ");
	}
}
