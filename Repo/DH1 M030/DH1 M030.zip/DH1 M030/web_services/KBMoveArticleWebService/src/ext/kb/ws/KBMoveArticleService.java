package ext.kb.ws;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.xml.bind.JAXBException;

import org.apache.log4j.Logger;
import org.apache.poi.util.StringUtil;
import org.jfree.util.Log;

import wt.configuration.TraceCode;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.fc.collections.WTCollection;
import wt.fc.collections.WTHashSet;
import wt.inf.container.WTContainerHelper;
import wt.inf.container.WTContainerRef;
import wt.log4j.LogR;
import wt.org.WTOrganization;
import wt.part.QuantityUnit;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.pds.StatementSpec;
import wt.pom.Transaction;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.type.TypedUtilityServiceHelper;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.vc.VersionControlHelper;
import wt.vc.views.View;
import wt.vc.views.ViewHelper;
import wt.vc.views.ViewReference;
import com.deploy.util.PartMoveUtil;
import com.ptc.jws.servlet.JaxWsWebService;
import com.ptc.windchill.suma.axl.AXLAlreadyExistsException;
import com.ptc.windchill.suma.axl.AXLContext;
import com.ptc.windchill.suma.axl.AXLEntry;
import com.ptc.windchill.suma.axl.AXLHelper;
import com.ptc.windchill.suma.axl.AXLPreference;
import com.ptc.windchill.suma.jca.util.SumaJcaHelper;
import com.ptc.windchill.suma.part.ManufacturerPart;
import com.ptc.windchill.suma.part.ManufacturerPartMaster;
import com.ptc.windchill.suma.part.VendorPart;
import com.ptc.windchill.suma.part.VendorPartMaster;
import com.ptc.windchill.suma.supplier.Manufacturer;
import com.ptc.windchill.suma.supplier.SupplierHelper;

import ext.kb.service.WebServiceHelper;
import ext.kb.util.IBAHelper;
import ext.kb.util.KBTypeIdProvider;
import ext.kb.util.ObjectRevisionHelper;
import ext.kb.tool.ChangeTypeOfWTPart;
import ext.kb.ws.MoveArticlePosition;


@WebService()
public class KBMoveArticleService extends JaxWsWebService
{
	private static final Logger LOGGER = LogR.getLogger(KBMoveArticleService.class.getName());
	private static final Logger logWriter = LogR.getLogger("ext.kb.ws.KBMoveArticleService_Log");
	@WebMethod(operationName="moveArticleOwnership")
    public String moveArticleOwnership (@WebParam(name="partIDs") ArrayList<MoveArticlePosition> partIDs) throws WTException,WTPropertyVetoException, JAXBException, IOException
    
    {

    	Transaction trx = null;
    	//List<String> result = new ArrayList<String>();
    	String result = "";

	    Iterator part = partIDs.iterator();        
	    LOGGER.debug("partIDs.size() ==="+partIDs.size());
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        String MASTER_SYSTEM_IBA = "KB_MASTERSYSTEM";
        Date date = new Date();
        String formatedDate = sdf.format(date);
        
	    for(int i=0;i<partIDs.size();i++){ 	    
	    MoveArticlePosition pos = (MoveArticlePosition) part.next();
	    try {
            
        //trx = new Transaction();
        //trx.start();        
        
       	logWriter.info(" Processing move article ownership service on "+formatedDate+" request parent number is "+pos.getNumber()+" parent_CID is "+pos.getCID());

         QuerySpec resQS = WebServiceHelper.findPartByNumberAndCadim(pos.getNumber(),pos.getCID());
		QueryResult resQR = PersistenceHelper.manager.find((StatementSpec) resQS);
    	int size = resQR.size();
    	 if(size > 0)
		 {
		 Persistable resObj [] = (Persistable [])resQR.nextElement();
		 LOGGER.debug("resObj: " + resObj);

		 LOGGER.debug("resObj: " + resObj[0]);
		 WTPart resPart = (WTPart)resObj[0];
		 LOGGER.debug("resPart: " + resPart);
		 WTPart latestPartRevision = (WTPart)ObjectRevisionHelper.getLatestVersionByPersistable(resPart);
		 WTPart latestPartIteration = (WTPart)VersionControlHelper.getLatestIteration(latestPartRevision);
		//retrieving design view part
		 latestPartIteration = (WTPart)WebServiceHelper.getDesignViewPart(latestPartIteration);
			if(latestPartIteration == null)
				throw new WTException("Design view Part with number "+latestPartRevision.getNumber()+" not found");
		 WTPartMaster master = latestPartIteration.getMaster();
		
		 String articleLocation = latestPartIteration.getLocation();
		 WTContainerRef contRef = latestPartIteration.getContainerReference();
		 String containerName = latestPartIteration.getContainerName();
		 LOGGER.debug("containerName name ==="+ containerName);
		 logWriter.info("containerName name ==="+ containerName);
		 //SubFolder f = (SubFolder) FolderHelper.service.getFolder(articleLocation,contRef);
		 //LOGGER.debug("domain name ==="+ f.getDomainRef().getName());
		 //LOGGER.debug( " part domain before \"" + latestPartIteration.getDomainRef().getName() + "\" domain");
		 //logWriter.info( " part domain before \"" + latestPartIteration.getDomainRef().getName() + "\" domain");
         //WebServiceHelper.setCadimDomain(latestPartIteration, f.getDomainRef().getName(), latestPartIteration.getContainerName());
         //LOGGER.debug( " part domain After \"" + latestPartIteration.getDomainRef().getName() + "\" domain");
         //logWriter.info( " part domain After \"" + latestPartIteration.getDomainRef().getName() + "\" domain");
        
         String partCategory = IBAHelper.readIBA(latestPartIteration, "KB_PART_CATEGORY");
         LOGGER.debug( "partCategory "+partCategory);
         logWriter.info( "partCategory "+partCategory);
         if(partCategory.equals("1")||partCategory.equals("2")||partCategory.equals("3"))
         {
        	 ChangeTypeOfWTPart.changeTypeOfPart(latestPartIteration, "com.ptc.KBAssemblyComponent", null);
        	 logWriter.info("Type of WTPart - " + latestPartIteration.getName() + " , numbner : " + latestPartIteration.getNumber()
  					+ " , version : " + latestPartIteration.getVersionIdentifier().getValue() + "."
  					+ latestPartIteration.getIterationIdentifier().getValue() + " OID "
  					+ PersistenceHelper.getObjectIdentifier(latestPartIteration).getId() + " was changed to com.ptc.KBAssyComp");
         }
         else if(partCategory.equals("4"))
         {
        	 logWriter.info("Before changing type of part");
        	 ChangeTypeOfWTPart.changeTypeOfPart(latestPartIteration, "com.ptc.KBStandardPart", null);
        	 logWriter.info("Type of WTPart - " + latestPartIteration.getName() + " , numbner : " + latestPartIteration.getNumber()
 					+ " , version : " + latestPartIteration.getVersionIdentifier().getValue() + "."
 					+ latestPartIteration.getIterationIdentifier().getValue() + " OID "
 					+ PersistenceHelper.getObjectIdentifier(latestPartIteration).getId() + " was changed to com.ptc.KBStandardPart");
         }
         else if(partCategory.equals("5"))
         {
        	 ChangeTypeOfWTPart.changeTypeOfPart(latestPartIteration, "com.ptc.KBRaw", null);
        	 logWriter.info("Type of WTPart - " + latestPartIteration.getName() + " , numbner : " + latestPartIteration.getNumber()
  					+ " , version : " + latestPartIteration.getVersionIdentifier().getValue() + "."
  					+ latestPartIteration.getIterationIdentifier().getValue() + " OID "
  					+ PersistenceHelper.getObjectIdentifier(latestPartIteration).getId() + " was changed to com.ptc.KBRaw");
         }
         else if(partCategory.equals("9"))
         {
        	 ChangeTypeOfWTPart.changeTypeOfPart(latestPartIteration, "com.ptc.KBCommercial", null);
        	 logWriter.info("Type of WTPart - " + latestPartIteration.getName() + " , numbner : " + latestPartIteration.getNumber()
  					+ " , version : " + latestPartIteration.getVersionIdentifier().getValue() + "."
  					+ latestPartIteration.getIterationIdentifier().getValue() + " OID "
  					+ PersistenceHelper.getObjectIdentifier(latestPartIteration).getId() + " was changed to com.ptc.KBCommercial");
         }
         else if(partCategory.equals("10"))
         {
        	 ChangeTypeOfWTPart.changeTypeOfPart(latestPartIteration, "com.ptc.KBKitBOM", null);
        	 logWriter.info("Type of WTPart - " + latestPartIteration.getName() + " , numbner : " + latestPartIteration.getNumber()
  					+ " , version : " + latestPartIteration.getVersionIdentifier().getValue() + "."
  					+ latestPartIteration.getIterationIdentifier().getValue() + " OID "
  					+ PersistenceHelper.getObjectIdentifier(latestPartIteration).getId() + " was changed to com.ptc.KBKitBOM");
         }
         else if(partCategory.equals("6"))
			{
				ChangeTypeOfWTPart.changeTypeOfPart(latestPartIteration, "com.ptc.KBSemiFinished", null);
				logWriter.info("Type of WTPart - " + latestPartIteration.getName() + " , numbner : " + latestPartIteration.getNumber()
				+ " , version : " + latestPartIteration.getVersionIdentifier().getValue() + "."
				+ latestPartIteration.getIterationIdentifier().getValue() + " OID "
				+ PersistenceHelper.getObjectIdentifier(latestPartIteration).getId() + " was changed to com.ptc.KBSemiFinished");
			}
			else if(partCategory.equals("7"))
			{
				ChangeTypeOfWTPart.changeTypeOfPart(latestPartIteration, "com.ptc.KBAuxMaterial", null);
				logWriter.info("Type of WTPart - " + latestPartIteration.getName() + " , numbner : " + latestPartIteration.getNumber()
				+ " , version : " + latestPartIteration.getVersionIdentifier().getValue() + "."
				+ latestPartIteration.getIterationIdentifier().getValue() + " OID "
				+ PersistenceHelper.getObjectIdentifier(latestPartIteration).getId() + " was changed to com.ptc.KBAuxMaterial");
			}
			else if(partCategory.equals("8"))
			{
				ChangeTypeOfWTPart.changeTypeOfPart(latestPartIteration, "com.ptc.KBTool", null);
				logWriter.info("Type of WTPart - " + latestPartIteration.getName() + " , numbner : " + latestPartIteration.getNumber()
				+ " , version : " + latestPartIteration.getVersionIdentifier().getValue() + "."
				+ latestPartIteration.getIterationIdentifier().getValue() + " OID "
				+ PersistenceHelper.getObjectIdentifier(latestPartIteration).getId() + " was changed to com.ptc.KBTool");
			}
         LOGGER.debug( "going to move related AXL parts ");
         logWriter.info( "going to move related AXL parts ");
         moveAXLParts(latestPartIteration);
         LOGGER.debug( "After moving related AXL parts ");
         logWriter.info( "After moving related AXL parts ");
         LOGGER.debug( "going to create MLK supplier Mapping ");
         logWriter.info( "going to create MLK supplier Mapping ");
         String basicText = createMLKSupplierMapping(latestPartIteration);
         LOGGER.debug( "After create MLK supplier Mapping basic text is "+basicText);
         logWriter.info( "After create MLK supplier Mapping basic text is "+basicText);
         if(!basicText.equals(""))
         {
         latestPartIteration = (WTPart)IBAHelper.setIba(latestPartIteration, "KB_BASIC_TEXT", basicText);
         LOGGER.debug( "After setting Basic text "+basicText);
         logWriter.info( "After setting Basic text "+basicText);
         }
         master = (WTPartMaster)IBAHelper.setIba(master, MASTER_SYSTEM_IBA, "WCT");
		 PersistenceServerHelper.manager.update(master);			
		 LOGGER.debug("After setting master system");
		 
		 String presentFolder = latestPartIteration.getFolderPath();
         String [] folderPath = presentFolder.split("/");
         LOGGER.debug( " presentFolder" + presentFolder);
         logWriter.info( " presentFolder " + presentFolder);
         String targetFolder = "/"+folderPath[1]+"/"+folderPath[2]+"/Data";
         LOGGER.debug( " targetFolder" + targetFolder);
         logWriter.info( " targetFolder " + targetFolder);
         PartMoveUtil.moveAllViewVersionsToContainer(contRef.getContainer(), targetFolder, latestPartIteration);
         LOGGER.debug(" Moved " + latestPartIteration.getNumber()+" to folder "+ targetFolder);
         logWriter.info(" Moved " + latestPartIteration.getNumber()+" to folder "+ targetFolder);
		 }
    	 else{
    		 logWriter.info("  part number "+pos.getNumber()+" part CID is "+pos.getCID() +" not found ");
    		 result = result+pos.getCID()+";";
    	 }
    			    	
        }
       
	    catch (Exception e) {
	     	   String message = "Exception during Move Article exception is "+e ;
	     	  result = result+pos.getCID()+";";
	          LOGGER.debug(message);
	          logWriter.info("message of the resquest is "+message);
	        } 
        }
	    return result;
    }
	
	private static void moveAXLParts(WTPart latestPartIteration) throws WTException, WTPropertyVetoException, IOException {
		LOGGER.debug("Inside  moveAXLParts " );
		WTHashSet localWTHashSet = new WTHashSet();
		AXLContext context = SumaJcaHelper
				.getDefaultSourcingContext(WTContainerHelper.service
						.getOrgContainer(latestPartIteration));
		WTCollection avlParts = AXLHelper.service.getAVL(
				latestPartIteration, context, null);
		
		LOGGER.debug("Number of AVLs " + avlParts.size());
		
		VendorPart vendorPart = null;
		VendorPartMaster vendorPartMaster = null;

		for (Iterator vi = avlParts.iterator(); vi.hasNext();) {
			AXLEntry entry = (AXLEntry) ((ObjectReference) vi
					.next()).getObject();

			vendorPart = entry.getLatestVendorPart();
			vendorPartMaster = (VendorPartMaster)vendorPart.getMaster();
			vendorPartMaster = (VendorPartMaster)IBAHelper.setIba(vendorPartMaster, "KB_MASTERSYSTEM", "WCT");
			 String articleLocation = vendorPart.getLocation();
			 WTContainerRef contRef = vendorPart.getContainerReference();
			 String containerName = vendorPart.getContainerName();
			 //LOGGER.debug("containerName name ==="+ containerName);
			 //SubFolder f = (SubFolder) FolderHelper.service.getFolder(articleLocation,contRef);
			 //LOGGER.debug("folder domain name ==="+ f.getDomainRef().getName());
			 //LOGGER.debug( " part domain before \"" + vendorPart.getDomainRef().getName() + "\" domain");
	         //WebServiceHelper.setCadimDomain(vendorPart, f.getDomainRef().getName(), containerName);
	         //LOGGER.debug( " part domain After \"" + vendorPart.getDomainRef().getName() + "\" domain");
			}
		
		WTCollection amlParts = AXLHelper.service.getAML(
				latestPartIteration, context);
		
		LOGGER.debug("Number of AMLs " + avlParts.size());
		
		ManufacturerPart supplierPart = null;
		ManufacturerPartMaster supplierPartMaster = null;

		for (Iterator vi = amlParts.iterator(); vi.hasNext();) {
			AXLEntry entry = (AXLEntry) ((ObjectReference) vi
					.next()).getObject();

			supplierPart = entry.getLatestManufacturerPart();
			supplierPartMaster = (ManufacturerPartMaster)supplierPart.getMaster();
			supplierPartMaster = (ManufacturerPartMaster)IBAHelper.setIba(supplierPartMaster, "KB_MASTERSYSTEM", "WCT");
			 String articleLocation = supplierPart.getLocation();
			 WTContainerRef contRef = supplierPart.getContainerReference();
			 String containerName = supplierPart.getContainerName();
			 LOGGER.debug("containerName name ==="+ containerName);
			// SubFolder f = (SubFolder) FolderHelper.service.getFolder(articleLocation,contRef);
			// LOGGER.debug("folder domain name ==="+ f.getDomainRef().getName());
			 //LOGGER.debug( " part domain before \"" + supplierPart.getDomainRef().getName() + "\" domain");
	         //WebServiceHelper.setCadimDomain(supplierPart, f.getDomainRef().getName(), containerName);
	         //LOGGER.debug( " part domain After \"" + supplierPart.getDomainRef().getName() + "\" domain");
			}		
	}
	private static String createMLKSupplierMapping(WTPart latestPartIteration) throws WTException, WTPropertyVetoException, IOException {
		LOGGER.debug("Inside  createMLKSupplierMapping " );
		String concString = IBAHelper.readIBA(latestPartIteration, "KB_MLK_DESC");
		LOGGER.debug("concString "+concString );
		if (concString != null && concString.trim().startsWith("[") && StringUtil.countMatches(concString, '[')==15 ) 
		{
		String [] splitArr = concString.split("\\[");
		int arrLength = splitArr.length;
		LOGGER.debug("arrLength "+arrLength);
		String basicText = splitArr[arrLength - 1];
		String manfPartName = "";
		String supplierName = "";
		String supplierPartNumber =""; 
		if(basicText.trim().length()>62)
		{
		manfPartName = (basicText.trim()).substring(0,61);
		}
		else{
			manfPartName = basicText.trim();
		}
		LOGGER.debug("basicText "+manfPartName);		
		for(int i = 0; i< arrLength -1; i+=2)
		{
			if(i == (arrLength - 2))
			{
			LOGGER.debug("Array Length is Even");
			if(!(splitArr[i].trim()).equals(""))
			{
				supplierPartNumber = splitArr[i].trim();
				createAML(latestPartIteration,splitArr[i].trim(),manfPartName,supplierName);
			}
			}
			else
				{
					if (splitArr[0].isEmpty()) {
						LOGGER.debug("empty");
						supplierName = splitArr[i + 1]; // if there is bracket at 0th position
						supplierPartNumber = splitArr[i + 2];
					} else {
						LOGGER.debug("No empty");
						supplierName = splitArr[i]; // if there is no bracket at 0th position
						supplierPartNumber = splitArr[i + 1];
					}
				
				LOGGER.debug("supplierName "+supplierName);
				LOGGER.debug("supplierPartNumber "+supplierPartNumber);
			
				if((supplierName.trim()).equals("") && (supplierPartNumber.trim()).equals(""))
				{
					LOGGER.debug("Both supplier "+supplierName+" and supplier part number  "+supplierPartNumber+" are blank no AML will be created");
					
				}else {
					createAML(latestPartIteration, supplierPartNumber.trim(), manfPartName, supplierName.trim());

				}
			}
		}
		return basicText;
		}
		else{
			return ("");
		}
	}
	
	private static void createAML(WTPart latestPartIteration, String supplierPartNumber, String basicText,
			String supplierName) throws WTException, WTPropertyVetoException, IOException {

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Latest Part Version -->" + latestPartIteration);
			LOGGER.debug("supplierPartNumber -->" + supplierPartNumber);
			LOGGER.debug("basicText -->" + basicText);
			LOGGER.debug("supplierName -->" + supplierName);
		}

		logWriter.info("Latest Part Version -->" + latestPartIteration);
		logWriter.info("supplierPartNumber -->" + supplierPartNumber);
		logWriter.info("basicText -->" + basicText);
		logWriter.info("supplierName -->" + supplierName);

		WTOrganization org = null;
		Manufacturer manf = null;
		if (supplierName != null && !supplierName.trim().isEmpty() && supplierPartNumber != null
				&& !supplierPartNumber.trim().isEmpty()) {

			org = getOrganization(supplierName);

			boolean supplierorg = true;
			// if org =null means no supplier org found for given name
			if (org != null) {
				try {
					manf = com.ptc.windchill.suma.supplier.SupplierHelper.service.getManufacturer(org,
							WTContainerHelper.service.getOrgContainer(org));
				} catch (Exception ex) {
					LOGGER.error("Not Supplier  org " + supplierName);
					supplierorg = false;
				}
				// if manf = null means there is on manufacutrer found
				LOGGER.debug("manf of org-->" + manf);
				if (manf == null && supplierorg) {
					org = null;
					supplierPartNumber = supplierName + "-" + supplierPartNumber;
				}
			} else {
				supplierPartNumber = supplierName + "-" + supplierPartNumber;
			}
			LOGGER.debug("supplierPartNumber" + supplierPartNumber);
			logWriter.info("supplierPartNumber" + supplierPartNumber);
			// Supplier name and number provided A-B
		}

		if (supplierPartNumber != null && supplierPartNumber.trim().equalsIgnoreCase("\\")) {
			logWriter.info("skipping part since number is  \\");
			return;
		}
		// if supplier number and name not provided or if supplier of given name and
		// number not exist then search for legacy
		if (org == null) {
			org = getOrganization("Legacy");
		}
		
		if(org==null) {
			throw new RuntimeException("Either Legacy or "+ supplierName+" ,Organization not found ");
		}
		
		if (Log.isDebugEnabled()) {
			LOGGER.debug("org-->" + org.getContainer());
		}
		
		String manUniqueId = (org.getUniqueIdentifier() == null) ? org.getName() : org.getUniqueIdentifier();
		// Supplier number is not provided so making number =name
		if (supplierPartNumber.isEmpty()) {
			supplierPartNumber = supplierName;
		}
		// if supplier name is empty number=supplier number.

		ManufacturerPart manfPart = WebServiceHelper.findManufacturerPart(manUniqueId, supplierPartNumber);
		logWriter.info(" Manufacturer part "+manfPart+" \n supplierPartNumber ->"+supplierPartNumber  +"\n org -->"+ org+"\n manUniqueId -->"+manUniqueId);
		
		if (manfPart == null) {
			LOGGER.debug("Manufacturing part with number " + supplierPartNumber + " and org id "
					+ org.getUniqueIdentifier() + " not found going to create new Manuturing Part");

			if (!basicText.equals("")) {
				manfPart = ManufacturerPart.newManufacturerPart(supplierPartNumber, basicText);
			} else {
				manfPart = ManufacturerPart.newManufacturerPart(supplierPartNumber, org.getName());
			}
			manfPart.setTypeDefinitionReference(TypedUtilityServiceHelper.service
					.getTypeDefinitionReference(KBTypeIdProvider.getType("SUPPLIERPART").getLeafName()));
			manfPart.setEndItem(false);
			manfPart.setDefaultUnit(QuantityUnit.toQuantityUnit("ea"));
			manfPart.setDefaultTraceCode(TraceCode.toTraceCode("S"));
			manfPart.setOrganization(org);

			manfPart.setContainer(latestPartIteration.getContainer());

			try {
				View[] views = ViewHelper.service.getAllViews();
				for (View v : views)
					if ("Design".equalsIgnoreCase(v.getName())) {
						manfPart.setView(ViewReference.newViewReference(v));
						break;
					}
			} catch (WTException e) {
				LOGGER.warn("Failed to set the view of the part", e);
			}

			manf = com.ptc.windchill.suma.supplier.SupplierHelper.service.getManufacturer(manfPart.getOrganization(),
					manfPart.getContainer().getContainer());

			if (manf != null) {
				try {
					manfPart.setOrganization(manf.getOrganization());
					manfPart.setContainerReference(latestPartIteration.getContainerReference());
					LOGGER.debug("After setting org and container ref");
				} catch (WTPropertyVetoException e) {
					throw new RuntimeException("Failed to set organization of new manufacturing part", e);
				}
				LOGGER.debug("Persisting the manufacturer part");
				PersistenceHelper.manager.store(manfPart);
				LOGGER.debug("After Persisting the manufacturer part" + manfPart.getName());
			}

		} else {
			manf = com.ptc.windchill.suma.supplier.SupplierHelper.service.getManufacturer(manfPart.getOrganization(),
					manfPart.getContainer().getContainer());
			LOGGER.debug("Manufacturing part with number " + supplierPartNumber + " and org id "
					+ org.getUniqueIdentifier() + " found going to create new AML");

		}
		if(manf==null) {
			throw new RuntimeException("Manufacturer not found for part "+latestPartIteration.getDisplayIdentifier());
		}
		AXLContext cont = AXLHelper.service.getDefaultContext(manf.getContainerReference());

		try {
			AXLHelper.service.addAML(cont, latestPartIteration, null, manfPart, AXLPreference.PREFERRED);
		} catch (AXLAlreadyExistsException ex) {
			LOGGER.error("Linked alrady exist between part "+ latestPartIteration.getNumber() +" and "+ manfPart.getNumber(),ex);
			logWriter.info("Linked alrady exist between part "+ latestPartIteration.getNumber() +" and "+ manfPart.getNumber());

		}
		logWriter.info("Linked successfully created between part "+ latestPartIteration.getNumber() +" and "+ manfPart.getNumber());

		LOGGER.debug("After creating AML ");

	}

	
	private static WTOrganization getOrganization(String orgName) {

		WTOrganization org = null;
		try {
			int[] fromIndicies = { 0, -1 };
			QuerySpec querySpec = new QuerySpec(WTOrganization.class);
			querySpec.appendWhere(
					new SearchCondition(WTOrganization.class, WTOrganization.NAME, SearchCondition.EQUAL, orgName,false),
					fromIndicies);
			QueryResult qResult = PersistenceHelper.manager.find((StatementSpec) querySpec);

			if (qResult.hasMoreElements()) {
				org = (WTOrganization) qResult.nextElement();
			}
		} catch (WTException e) {
			LOGGER.error("Exception while getting organizaiton ", e);
		}
		LOGGER.debug("Return " + org);
		return org;

	}

}