package ext.kb.ws;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.xml.bind.JAXBException;

import org.apache.log4j.Logger;

import wt.associativity.EquivalenceLink;
import wt.configurablelink.ConfigurableReferenceLink;
import wt.doc.WTDocument;
import wt.doc.WTDocumentMaster;
import wt.doc.WTDocumentUsageLink;
import wt.eff.EffHelper;
import wt.eff.EffManagedVersion;
import wt.eff.EffRecordable;
import wt.effectivity.EffectivityHelper;
import wt.effectivity.EffectivityHolder;
import wt.effectivity.WTDatedEffectivity;
import wt.epm.EPMDocument;
import wt.epm.build.EPMBuildHistory;
import wt.epm.build.EPMBuildRule;
import wt.epm.structure.EPMDescribeLink;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.fc.collections.WTArrayList;
import wt.fc.collections.WTCollection;
import wt.fc.collections.WTHashSet;
import wt.fc.collections.WTSet;
import wt.inf.container.WTContainerHelper;
import wt.log4j.LogR;
import wt.part.WTPart;
import wt.part.WTPartAlternateLink;
import wt.part.WTPartDescribeLink;
import wt.part.WTPartMaster;
import wt.part.WTPartReferenceLink;
import wt.part.WTPartSubstituteLink;
import wt.part.WTPartUsageLink;
import wt.pds.StatementSpec;
import wt.pom.Transaction;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.supersede.SupersedeLink;
import wt.type.TypedUtilityServiceHelper;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.vc.Iterated;
import wt.vc.VersionControlHelper;
import wt.vc.baseline.BaselineMember;
import wt.vc.struct.StructHelper;

import com.ptc.jws.servlet.JaxWsWebService;
import com.ptc.windchill.suma.axl.AXLContext;
import com.ptc.windchill.suma.axl.AXLEntry;
import com.ptc.windchill.suma.jca.util.SumaJcaHelper;
import com.ptc.windchill.suma.part.VendorPart;
import com.ptc.windchill.suma.part.VendorPartMaster;
import com.sun.xml.rpc.util.Debug;

import ext.kb.service.WebServiceHelper;
import ext.kb.util.DBUtils;
import ext.kb.util.IBAHelper;
import ext.kb.util.ObjectRevisionHelper;

@WebService()
public class KBDeleteObjectService extends JaxWsWebService {
	private static final Logger LOGGER = LogR.getLogger(KBDeleteObjectService.class.getName());
	private static final Logger logWriter = LogR.getLogger("ext.kb.ws.KBDeleteObjectService_Log");

	@WebMethod(operationName = "deleteObject")
	public List<String> deleteObject(@WebParam(name = "objectType") String objectType,
			@WebParam(name = "objectID") String objectID, @WebParam(name = "C_ID") String C_ID)
					throws WTException, WTPropertyVetoException, JAXBException, IOException

	{

		Transaction trx = null;

		List<String> result = new ArrayList<String>();
		try {

			trx = new Transaction();
			trx.start();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			Date date = new Date();
			String formatedDate = sdf.format(date);
			logWriter.info("Processing delete request on " + formatedDate + " for object where number is " + objectID
					+ " and CID is " + C_ID + " objectType = " + objectType);

			if (objectType.equalsIgnoreCase("WTPart")) {

				QuerySpec partQS = WebServiceHelper.findPartByNumberAndCadim(objectID, C_ID);
				QueryResult partQR = PersistenceHelper.manager.find((StatementSpec) partQS);
				if(partQR.hasMoreElements()) {
					Persistable resObj[] = (Persistable[]) partQR.nextElement();
					LOGGER.debug("resObj: " + resObj[0]);
					WTPart resPart = (WTPart) resObj[0];
					LOGGER.debug("resPart ===" + resPart);
					logWriter.info("resPart ===" + resPart);
					WTPart latestPartRevision = (WTPart) ObjectRevisionHelper.getLatestVersionByPersistable(resPart);
					WTPart latestPartIteration = (WTPart) VersionControlHelper.getLatestIteration(latestPartRevision);
					WTPartMaster parentPart = (WTPartMaster) resPart.getMaster();
					QueryResult qr = VersionControlHelper.service.allIterationsOf(parentPart, true);
					QueryResult qrv = VersionControlHelper.service.allVersionsOf(parentPart);
					WTSet allIterations = new WTHashSet();
					LOGGER.debug("qr.size ==" + qr.size());
					logWriter.info("qr.size ==" + qr.size());

					LOGGER.debug("qrv.size ==" + qrv.size());
					logWriter.info("qrv.size ==" + qrv.size());
					allIterations.addAll(qrv);

					LOGGER.debug("Latest part version : " + latestPartIteration.getVersionIdentifier().getValue() + "."
							+ latestPartIteration.getIterationIdentifier().getValue());
					String masterSystem = IBAHelper.readIBA(latestPartIteration, "KB_MASTERSYSTEM");
					LOGGER.debug("master System : " + masterSystem);

					if (masterSystem != null && !"WCT".equalsIgnoreCase(masterSystem)) {
						WTPart part =null;
						while(qrv.hasMoreElements()){
							part = (WTPart)qrv.nextElement();
							QueryResult buildQuery = PersistenceHelper.manager.navigate(part,
									EPMBuildRule.BUILD_SOURCE_ROLE, EPMBuildRule.class, true);
							LOGGER.debug("EPMBuildRule : " + buildQuery.size());
							QueryResult buildHistoryQuery = PersistenceHelper.manager.navigate(part,
									EPMBuildHistory.BUILT_BY_ROLE, EPMBuildHistory.class, true);
							LOGGER.debug("EPMBuildHistory : " + buildHistoryQuery.size());
							if (buildQuery.size() > 0 || buildHistoryQuery.size() > 0) {
								throw new WTException("Part has CAD Data associated");
							}
							
							part = deleteEPMDescribeLinks(part);
							
							part = deleteDocLinks(part);
	
							part = deleteEffectivity(part);
	
							part = deleteAMLAVL(part);
	
							part = deleteBOMStructure(part);
							
							part = deleteAltSub(part);
	
							part = deleteBaseline(part);
	
							part = deleteSupersedeLinks(part);
	
							part = deleteRefInfos(part);
							if(Debug.enabled()){
							LOGGER.debug("Part being delete Revision is "
									+ part.getVersionIdentifier().getValue() + " and Iteration is "
									+ part.getIterationIdentifier().getValue());
							}
							logWriter.info("Part being delete Revision is "
									+ part.getVersionIdentifier().getValue() + " and Iteration is "
									+ part.getIterationIdentifier().getValue());
							if(("Design").equalsIgnoreCase(part.getViewName())){
								part = deleteDownstreamEquivalenceLink(part);
							}
							else{
								part = deleteUpstreamEquivalenceLink(part);
								PersistenceHelper.manager.delete(part);
							}
							LOGGER.debug("After Delete===");
							logWriter.info("After Delete===");
						}
						PersistenceHelper.manager.delete(part);
					} else {
						throw new WTException("Windchill Mastered Article can not be deleted.");
					}

				} if(partQR.size()==0) {
					throw new WTException("Part with number " + objectID + " and CID " + C_ID + " not found");
				}
			}

			if (objectType.equalsIgnoreCase("WTDocument")) {
				QuerySpec docQS = WebServiceHelper.findDocumentByNumberAndCadim(objectID, C_ID);
				QueryResult docQR = PersistenceHelper.manager.find((StatementSpec) docQS);
				if (docQR.size() > 0) {
					Persistable resObj[] = (Persistable[]) docQR.nextElement();
					LOGGER.debug("resObj: " + resObj[0]);
					WTDocument resDoc = (WTDocument) resObj[0];
					LOGGER.debug("resDoc ===" + resDoc);
					logWriter.info("resDoc ===" + resDoc);
					WTDocument latestDocRevision = (WTDocument) ObjectRevisionHelper
							.getLatestVersionByPersistable(resDoc);
					WTDocument latestDocIteration = (WTDocument) VersionControlHelper
							.getLatestIteration(latestDocRevision);
					String latestIteration_cid = IBAHelper.readIBA(latestDocIteration, "KB_CADIM_CID");
					WTDocumentMaster parentDoc = (WTDocumentMaster) resDoc.getMaster();

					QueryResult qrv = VersionControlHelper.service.allVersionsOf(parentDoc);
					WTSet allIterations = new WTHashSet();

					LOGGER.debug("qrv.size ==" + qrv.size());
					logWriter.info("qrv.size ==" + qrv.size());
					allIterations.addAll(qrv);
					String masterSystem = IBAHelper.readIBA(latestDocIteration, "KB_MASTERSYSTEM");
					LOGGER.debug("master System : " + masterSystem);
					if (masterSystem != null && !"WCT".equalsIgnoreCase(masterSystem)) {

						while (latestIteration_cid.equals(C_ID)) {
							Iterated docTobeDeleted = (Iterated) VersionControlHelper.service
									.getLatestIteration((Iterated) latestDocIteration, false);
							LOGGER.debug("Document being delete Revision is "
									+ ((WTDocument) docTobeDeleted).getVersionIdentifier().getValue()
									+ " and Iteration is " + docTobeDeleted.getIterationIdentifier().getValue());
							logWriter.info("Document being delete Revision is "
									+ ((WTDocument) docTobeDeleted).getVersionIdentifier().getValue()
									+ " and Iteration is " + docTobeDeleted.getIterationIdentifier().getValue());
							QueryResult qr = VersionControlHelper.service.allIterationsOf(parentDoc, true);
							LOGGER.debug("qr.size() " + qr.size());
							logWriter.info("qr.size() " + qr.size());
							if (qr.size() == 1) {
								LOGGER.debug(
										"Last Iteration going to delete complete revision Document being delete Revision is "
												+ ((WTDocument) latestDocIteration).getVersionIdentifier().getValue());
								logWriter.info(
										"ast Iteration going to delete complete revision Document being delete Revision is "
												+ ((WTDocument) latestDocIteration).getVersionIdentifier().getValue());

								latestDocIteration = deleteLinks(latestDocIteration);

								PersistenceHelper.manager.delete(latestDocIteration);
								break;
							} else {
								if (VersionControlHelper.service.isFirstIteration(docTobeDeleted)) {
									LOGGER.debug(" Its the first iteration of the revision deleting whole branch");
									logWriter.info(" Its the first iteration of the revision deleting whole branch ");

									docTobeDeleted = deleteLinks((WTDocument) docTobeDeleted);

									PersistenceHelper.manager.delete(docTobeDeleted);
									break;
								} else {

									LOGGER.debug(
											" Its the not the first iteration of the revision deleting only the iteration");
									logWriter.info(
											" Its the not thefirst iteration of the revision deleting only the iteration ");

									docTobeDeleted = deleteLinks((WTDocument) docTobeDeleted);

									VersionControlHelper.service.deleteIterations(docTobeDeleted, docTobeDeleted);

								}
								docTobeDeleted = (Iterated) VersionControlHelper.service
										.getLatestIteration((Iterated) latestDocIteration, false);
								LOGGER.debug("Latest Document After delete Revision is "
										+ ((WTDocument) docTobeDeleted).getVersionIdentifier().getValue()
										+ " and Iteration is " + docTobeDeleted.getIterationIdentifier().getValue());
								logWriter.info("Latest Document After delete Revision is "
										+ ((WTDocument) docTobeDeleted).getVersionIdentifier().getValue()
										+ " and Iteration is " + docTobeDeleted.getIterationIdentifier().getValue());
								latestIteration_cid = IBAHelper.readIBA((WTDocument) docTobeDeleted, "KB_CADIM_CID");
								LOGGER.debug("CID for latest document is " + latestIteration_cid
										+ " and CID of object bein deleted is " + C_ID);
								logWriter.info("CID for latest document is " + latestIteration_cid
										+ " and CID of object bein deleted is " + C_ID);
							}
						}
						LOGGER.debug("After Delete===");
					}else {
						throw new WTException("Windchill Mastered document can not be deleted .");
					}
					

				} else {
					throw new WTException("Document with number " + objectID + " and CID " + C_ID + " not found");
				}
			}

			LOGGER.debug("trx===before commit" + trx.toStringInContext());
			trx.commit();
			LOGGER.debug("trx===After commit" + trx.toStringInContext());
			trx = null;
			result.add("ReturnCode: 0");
			result.add("Text: Success");
			logWriter.info("result from the service is " + result);
			return result;
		} catch (WTException e) {
			e.printStackTrace();
			String message = "WTException during Delete exception is " + e;
			result.add("ReturnCode: 1");
			result.add("Text: " + message);
			logWriter.info("result from the service is " + result);
			return result;

		} catch (WTPropertyVetoException e) {
			String message = "WTPropertyVetoException during Delete exception is " + e;
			result.add("ReturnCode: 1");
			result.add("Text: " + message);
			logWriter.info("result from the service is " + result);
			return result;
		} finally {
			LOGGER.debug("trx in finally===" + trx);
			if (trx != null) {
				trx.rollback();
			}
		}
	}

	private WTPart deleteUpstreamEquivalenceLink(WTPart upstreamPart) throws WTException{
		if(Debug.enabled())
			LOGGER.debug("inside deleteUpstreamEquivalenceLink");
		logWriter.info("inside deleteUpstreamEquivalenceLink");
		List<EquivalenceLink> equiVLinksList = DBUtils.retrieveLinks(EquivalenceLink.class, upstreamPart,
				EquivalenceLink.UPSTREAM_ROLE);
		if(Debug.enabled())
			LOGGER.debug("equiVLinksList -> "+equiVLinksList.size());
		for (EquivalenceLink wtPartEquivLink : equiVLinksList) {
			if(Debug.enabled())
					LOGGER.debug("deleteEquivLink : B4 deleting wtPartEquivLink " +wtPartEquivLink);
			PersistenceServerHelper.manager.remove(wtPartEquivLink);
			if(Debug.enabled())
					LOGGER.debug("deleteEquivLink : After deleting wtPartEquivLink ");
			logWriter.info("deleteEquivLink : After deleting wtPartEquivLink ");
		}
		return upstreamPart;
	}
	
	private WTPart deleteDownstreamEquivalenceLink(WTPart upstreamPart) throws WTException{
		if(Debug.enabled())
		LOGGER.debug("inside deleteDownstreamEquivalenceLink");
		logWriter.info("inside deleteDownstreamEquivalenceLink");
		List<EquivalenceLink> equiVLinksList = DBUtils.retrieveLinks(EquivalenceLink.class, upstreamPart,
				EquivalenceLink.DOWNSTREAM_ROLE);
		if(Debug.enabled())
			LOGGER.debug("equiVLinksList -> "+equiVLinksList.size());
		for (EquivalenceLink wtPartEquivLink : equiVLinksList) {
			if(Debug.enabled())
					LOGGER.debug("deleteEquivLink : B4 deleting wtPartEquivLink " +wtPartEquivLink);
			PersistenceServerHelper.manager.remove(wtPartEquivLink);
			if(Debug.enabled())
					LOGGER.debug("deleteEquivLink : After deleting wtPartEquivLink ");
			logWriter.info("deleteEquivLink : After deleting wtPartEquivLink ");
		}
		return upstreamPart;
	}
	
	private WTPart deleteAltSub(WTPart latestPartIteration) throws WTException {
		
		List<WTPartAlternateLink> alternateLinksList = DBUtils.retrieveLinks(WTPartAlternateLink.class,
				latestPartIteration, WTPartAlternateLink.ALTERNATES_ROLE);
		
		for (WTPartAlternateLink wtPartAltink : alternateLinksList) {
			LOGGER.debug("deleteAltSub : B4 deleting wtPartAltink ");
			PersistenceServerHelper.manager.remove(wtPartAltink);
			LOGGER.debug("deleteAltSub : After deleting wtPartAltink ");
			logWriter.info("deleteAltSub : After deleting wtPartAltink ");
		}
		
		List<WTPartSubstituteLink> substituteLinksList = DBUtils.retrieveLinks(WTPartSubstituteLink.class,
				latestPartIteration, WTPartSubstituteLink.SUBSTITUTE_FOR_ROLE);
		
		for (WTPartSubstituteLink wtPartSubink : substituteLinksList) {
			LOGGER.debug("deleteAltSub : B4 deleting wtPartSubink ");
			PersistenceServerHelper.manager.remove(wtPartSubink);
			LOGGER.debug("deleteAltSub : After deleting wtPartSubink ");
			logWriter.info("deleteAltSub : After deleting wtPartSubink ");
		}
		return latestPartIteration;
	}

	private WTPart deleteEPMDescribeLinks(WTPart latestPartIteration) throws WTException {
		ArrayList<EPMDescribeLink> epmDescribeLinks = (ArrayList<EPMDescribeLink>) getEPMDescribeLinks(
				latestPartIteration);
		LOGGER.debug("EPMDescribeLinks : " + epmDescribeLinks.size());

		for (EPMDescribeLink epmDescribeLink : epmDescribeLinks) {
			EPMDocument epmdoc = (EPMDocument) epmDescribeLink.getRoleBObject();
			LOGGER.debug("deleteEPMDescribeLinks : B4 deleting EPMDescribeLink " + epmDescribeLink.getRoleBObject()
			+ " " + epmDescribeLink.getRoleAObject());
			LOGGER.debug("deleteEPMDescribeLinks : EPMDocument type : " + epmdoc.getDocType().toString());
			if ((epmdoc.getDocType().toString()).equals("CADDRAWING")) {
				List<WTPartDescribeLink> describeLinksList = DBUtils.retrieveLinks(WTPartDescribeLink.class,
						latestPartIteration, WTPartDescribeLink.DESCRIBED_BY_ROLE);

				for (WTPartDescribeLink wtPartDescribeLink : describeLinksList) {
					WTDocument doc = (WTDocument) wtPartDescribeLink.getRoleBObject();
					LOGGER.debug("deleteEPMDescribeLinks : : Document number : "+doc.getNumber());
					String typeName = TypedUtilityServiceHelper.service.getTypeIdentifier(doc).getTypename();
					LOGGER.debug("deleteEPMDescribeLinks : : Document type : "+typeName);
					if((typeName.equalsIgnoreCase("wt.doc.WTDocument|com.ptc.KBDocuments|com.ptc.KBTechnicalDrawing|com.ptc.KBNeutralData")) && (doc.getNumber().equals(epmdoc.getNumber()))){
						PersistenceServerHelper.manager.remove(epmDescribeLink);
						LOGGER.debug("deleteEPMDescribeLinks : After deleting EPMDescribeLink ");
						logWriter.info("deleteEPMDescribeLinks : After deleting EPMDescribeLink ");
					}
				}
				
				
			}

			
		}
		return latestPartIteration;
	}

	private WTDocument deleteLinks(WTDocument docTobeDeleted) throws WTException {
		List<WTPartDescribeLink> describeLinksList = DBUtils.retrieveLinks(WTPartDescribeLink.class, docTobeDeleted,
				WTPartDescribeLink.DESCRIBES_ROLE);
		LOGGER.debug("deleteLinks : describeLinksList Size : " + describeLinksList.size());

		List<WTPartReferenceLink> referenceLinksList = DBUtils.retrieveLinks(WTPartReferenceLink.class, docTobeDeleted,
				WTPartReferenceLink.ROLE_AOBJECT_ROLE);

		LOGGER.debug("deleteLinks : referenceLinksList Size : " + referenceLinksList.size());

		for (WTPartDescribeLink wtPartDescribeLink : describeLinksList) {
			LOGGER.debug("deleteLinks : B4 deleting wtPartDescribeLink ");
			PersistenceServerHelper.manager.remove(wtPartDescribeLink);
			LOGGER.debug("deleteLinks : After deleting wtPartDescribeLink ");
			logWriter.info("deleteLinks : After deleting wtPartDescribeLink ");
		}

		for (WTPartReferenceLink wtPartReferenceLink : referenceLinksList) {
			LOGGER.debug("deleteLinks : B4 deleting wtPartReferenceLink ");
			PersistenceServerHelper.manager.remove(wtPartReferenceLink);
			LOGGER.debug("deleteLinks : After deleting wtPartReferenceLink ");
			logWriter.info("deleteLinks : After deleting wtPartReferenceLink ");
		}

		ArrayList<ConfigurableReferenceLink> kbRefInfoLinksList = (ArrayList<ConfigurableReferenceLink>) DBUtils
				.retrieveLinks(ConfigurableReferenceLink.class, docTobeDeleted,
						ConfigurableReferenceLink.ROLE_BOBJECT_ROLE);
		LOGGER.debug("deleteLinks : kbRefInfoLinksList size " + kbRefInfoLinksList.size());
		logWriter.info("deleteLinks : kbRefInfoLinksList size " + kbRefInfoLinksList.size());
		for (ConfigurableReferenceLink confLink : kbRefInfoLinksList) {
			LOGGER.debug("deleteLinks : B4 deleting kbRefInfoLinks " + confLink);
			logWriter.info("deleteLinks : B4 deleting kbRefInfoLinks ");
			PersistenceServerHelper.manager.remove(confLink);
			LOGGER.debug("deleteLinks : After deleting kbRefInfoLinks ");
			logWriter.info("deleteLinks : After deleting kbRefInfoLinks ");
		}
		ArrayList<ConfigurableReferenceLink> kbRefInfoLinksList1 = (ArrayList<ConfigurableReferenceLink>) DBUtils
				.retrieveLinks(ConfigurableReferenceLink.class, docTobeDeleted.getMaster(),
						ConfigurableReferenceLink.ROLE_AOBJECT_ROLE);

		LOGGER.debug("deleteLinks : kbRefInfoLinksList1 size " + kbRefInfoLinksList1.size());
		logWriter.info("deleteLinks : kbRefInfoLinksList1 size " + kbRefInfoLinksList1.size());
		for (ConfigurableReferenceLink confLink : kbRefInfoLinksList1) {
			PersistenceServerHelper.manager.remove(confLink);
			LOGGER.debug("deleteLinks : After deleting kbRefInfoLinks ");
			logWriter.info("deleteLinks : After deleting kbRefInfoLinks ");
		}

		List<WTDocumentUsageLink> docUsesLinksList = DBUtils.retrieveLinks(WTDocumentUsageLink.class, docTobeDeleted,
				WTDocumentUsageLink.USES_ROLE);

		LOGGER.debug("deleteLinks : docUsesLinksList size : " + docUsesLinksList.size());
		logWriter.info("deleteLinks : docUsesLinksList size : " + docUsesLinksList.size());
		for (WTDocumentUsageLink link : docUsesLinksList) {
			LOGGER.debug("deleteLinks : Before deleting Uses Link");
			logWriter.info("deleteLinks : Before deleting Uses Link");
			PersistenceServerHelper.manager.remove(link);
			LOGGER.debug("deleteLinks : Uses Links deleted");
			logWriter.info("deleteLinks : Uses Links deleted");
		}

		List<WTDocumentUsageLink> docUsedByLinksList = DBUtils.retrieveLinks(WTDocumentUsageLink.class, docTobeDeleted,
				WTDocumentUsageLink.USED_BY_ROLE);
		LOGGER.debug("deleteLinks : docUsedByLinksList size : " + docUsedByLinksList.size());
		logWriter.info("deleteLinks : docUsedByLinksList size : " + docUsedByLinksList.size());
		for (WTDocumentUsageLink link : docUsedByLinksList) {
			LOGGER.debug("deleteLinks : Before deleting UsedBy Link");
			logWriter.info("deleteLinks : Before deleting UsedBy Link");
			PersistenceServerHelper.manager.remove(link);
			LOGGER.debug("deleteLinks : UsedBy Links deleted");
			logWriter.info("deleteLinks : UsedBy Links deleted");
		}
		
	 
		QueryResult qr2 = EffHelper.service.getEffectivity((EffRecordable)docTobeDeleted);
		LOGGER.debug("deleteLinks : Effectivity size : " + qr2.size());
		while (qr2.hasMoreElements()) {

			Object obj = (Object) qr2.nextElement();

			if (obj.getClass().isAssignableFrom(WTDatedEffectivity.class)) {
				LOGGER.debug("  ***** Date Effectivity *****  ");
				WTDatedEffectivity effDate = (WTDatedEffectivity) obj;
				LOGGER.debug("deleteEffectivity : WTDatedEffectivity " + effDate);
				PersistenceServerHelper.manager.remove(effDate);
				LOGGER.debug("deleteEffectivity : Dated effectivity deleted.");
				logWriter.info("deleteEffectivity : Dated effectivity deleted.");
			}
		}

		return docTobeDeleted;

	}

	protected static List<EPMDescribeLink> getEPMDescribeLinks(WTPart part) throws WTException {
		List<EPMDescribeLink> describeLinks = new ArrayList();
		WTCollection parts = new WTArrayList();
		parts.add(part);
		QueryResult partToDocs = null;
		partToDocs = PersistenceHelper.manager.navigate(part, "describedBy", EPMDescribeLink.class, false);

		while (partToDocs.hasMoreElements()) {
			describeLinks.add((EPMDescribeLink) partToDocs.nextElement());
		}

		return describeLinks;
	}

	private WTPart deleteRefInfos(WTPart latestPartIteration) throws WTException {
		ArrayList<ConfigurableReferenceLink> kbRefInfoLinksList = (ArrayList<ConfigurableReferenceLink>) DBUtils
				.retrieveLinks(ConfigurableReferenceLink.class, latestPartIteration,
						ConfigurableReferenceLink.ROLE_BOBJECT_ROLE);
		LOGGER.debug("deleteRefInfos : kbRefInfoLinksList size " + kbRefInfoLinksList.size());
		logWriter.info("deleteRefInfos : kbRefInfoLinksList size " + kbRefInfoLinksList.size());
		for (ConfigurableReferenceLink confLink : kbRefInfoLinksList) {
			LOGGER.debug("deleteRefInfos : B4 deleting kbRefInfoLinks " + confLink);
			logWriter.info("deleteRefInfos : B4 deleting kbRefInfoLinks ");
			PersistenceServerHelper.manager.remove(confLink);
			LOGGER.debug("deleteRefInfos : After deleting kbRefInfoLinks ");
			logWriter.info("deleteRefInfos : After deleting kbRefInfoLinks ");
		}
		ArrayList<ConfigurableReferenceLink> kbRefInfoLinksList1 = (ArrayList<ConfigurableReferenceLink>) DBUtils
				.retrieveLinks(ConfigurableReferenceLink.class, latestPartIteration.getMaster(),
						ConfigurableReferenceLink.ROLE_AOBJECT_ROLE);

		LOGGER.debug("deleteRefInfos : kbRefInfoLinksList1 size " + kbRefInfoLinksList1.size());
		logWriter.info("deleteRefInfos : kbRefInfoLinksList1 size " + kbRefInfoLinksList1.size());
		for (ConfigurableReferenceLink confLink : kbRefInfoLinksList1) {
			PersistenceServerHelper.manager.remove(confLink);
			LOGGER.debug("deleteRefInfos : After deleting kbRefInfoLinks ");
			logWriter.info("deleteRefInfos : After deleting kbRefInfoLinks ");
		}
		return latestPartIteration;
	}

	private WTPart deleteSupersedeLinks(WTPart latestPartIteration) throws WTException {
		List<SupersedeLink> supersededLinksList = DBUtils.retrieveLinks(SupersedeLink.class,
				latestPartIteration.getMaster(), SupersedeLink.SUPERSEDED_ROLE);
		List<SupersedeLink> supersedingLinksList = DBUtils.retrieveLinks(SupersedeLink.class,
				latestPartIteration.getMaster(), SupersedeLink.SUPERSEDING_ROLE);

		LOGGER.debug("deleteSupersedeLinks : supersededLinksList size " + supersededLinksList.size());
		logWriter.info("deleteSupersedeLinks : supersededLinksList size " + supersededLinksList.size());

		LOGGER.debug("deleteSupersedeLinks : supersedingLinksList size " + supersedingLinksList.size());
		logWriter.info("deleteSupersedeLinks : supersedingLinksList size " + supersedingLinksList.size());

		for (SupersedeLink supersedeLink : supersededLinksList) {
			LOGGER.debug("deleteSupersedeLinks : B4 deleting supersedeLink in supersededLinksList");
			logWriter.info("deleteSupersedeLinks : B4 deleting wtPartDescribeLink in supersededLinksList");
			PersistenceServerHelper.manager.remove(supersedeLink);
			LOGGER.debug("deleteSupersedeLinks : After deleting wtPartDescribeLink in supersededLinksList");
			logWriter.info("deleteSupersedeLinks : After deleting wtPartDescribeLink in supersededLinksList");
		}

		for (SupersedeLink supersedeLink1 : supersedingLinksList) {
			LOGGER.debug("deleteSupersedeLinks : B4 deleting SupersedeLink in supersedingLinksList");
			logWriter.info("deleteSupersedeLinks : B4 deleting SupersedeLink  in supersedingLinksList");
			PersistenceServerHelper.manager.remove(supersedeLink1);
			LOGGER.debug("deleteSupersedeLinks : After deleting SupersedeLink in supersedingLinksList");
			logWriter.info("deleteSupersedeLinks : After deleting SupersedeLink in supersedingLinksList");
		}
		return latestPartIteration;
	}

	private WTPart deleteBaseline(WTPart latestPartIteration) throws WTException {
		List<BaselineMember> baselineList = DBUtils.retrieveLinks(BaselineMember.class, latestPartIteration,
				BaselineMember.BASELINE_ROLE);
		LOGGER.debug("deleteBaseline : ManagedBaseLine : " + baselineList.size());

		for (BaselineMember baselineMember : baselineList) {

			LOGGER.debug("deleteBaseline : RoleAObject : " + (baselineMember.getRoleAObject()).getIdentity());
			LOGGER.debug("deleteBaseline : RoleBObject : " + (baselineMember.getRoleBObject()).getPersistInfo());
			PersistenceServerHelper.manager.remove(baselineMember);
			LOGGER.debug("deleteBaseline : After deleting BaseLineMember link");
			logWriter.info("deleteBaseline : After deleting BaseLineMember link");
		}
		return latestPartIteration;
	}

	private WTPart deleteBOMStructure(WTPart latestPartIteration) throws WTException {
		QueryResult qrUses = StructHelper.service.navigateUses(latestPartIteration, false);
		LOGGER.debug("deleteBOMStructure : query size : " + qrUses.size());
		while (qrUses.hasMoreElements()) {
			WTPartUsageLink usesLink = (WTPartUsageLink) qrUses.nextElement();
			LOGGER.debug("deleteBOMStructure : Next Element Uses is : " + usesLink);

			PersistenceServerHelper.manager.remove(usesLink);
			LOGGER.debug("deleteBOMStructure : Uses link delted");
			logWriter.info("deleteBOMStructure : Uses link delted");
		}

		QueryResult qrUsedBy = StructHelper.service.navigateUsedBy(latestPartIteration.getMaster(), false);
		LOGGER.debug("deleteBOMStructure : query size : " + qrUsedBy.size());
		while (qrUsedBy.hasMoreElements()) {
			WTPartUsageLink usedByLink = (WTPartUsageLink) qrUsedBy.nextElement();
			LOGGER.debug("Next Element usedBy is : " + usedByLink);

			PersistenceServerHelper.manager.remove(usedByLink);
			LOGGER.debug("deleteBOMStructure : UsedBy link delted");
			logWriter.info("deleteBOMStructure : UsedBy link delted");
		}
		return latestPartIteration;
	}

	private WTPart deleteAMLAVL(WTPart latestPartIteration) throws WTException {
		AXLContext context = SumaJcaHelper
				.getDefaultSourcingContext(WTContainerHelper.service.getOrgContainer((WTPart) latestPartIteration));
		LOGGER.debug("deleteAMLAVL : AXLContext : " + context + " " + context.getName());
		ArrayList aList = findAXLEntry(latestPartIteration, null, context);
		LOGGER.debug("deleteAMLAVL : aList size : " + aList.size());
		Object[] oArray = aList.toArray();
		for (int i = 0; i < oArray.length; i++) {
			AXLEntry entry = (AXLEntry) oArray[i];
			LOGGER.debug("deleteAMLAVL: AXL Prefrence : " + entry);
			PersistenceServerHelper.manager.remove(entry);
			LOGGER.debug("deleteAMLAVL : AML/AVL links deleted");
			logWriter.info("deleteAMLAVL : AML/AVL links deleted");
		}
		return latestPartIteration;
	}

	private WTPart deleteEffectivity(WTPart latestPartIteration) throws WTException {
		QueryResult qr2 = EffectivityHelper.service.getEffectivities(latestPartIteration);
		LOGGER.debug("deleteEffectivity : Effectivity size : " + qr2.size());
		while (qr2.hasMoreElements()) {

			Object obj = (Object) qr2.nextElement();

			if (obj.getClass().isAssignableFrom(WTDatedEffectivity.class)) {
				LOGGER.debug("  ***** Date Effectivity *****  ");
				WTDatedEffectivity effDate = (WTDatedEffectivity) obj;
				LOGGER.debug("deleteEffectivity : WTDatedEffectivity " + effDate);
				PersistenceServerHelper.manager.remove(effDate);
				LOGGER.debug("deleteEffectivity : Dated effectivity deleted.");
				logWriter.info("deleteEffectivity : Dated effectivity deleted.");
			}
		}
		return latestPartIteration;
	}

	private WTPart deleteDocLinks(WTPart latestPartIteration) throws WTException {
		List<WTPartDescribeLink> describeLinksList = DBUtils.retrieveLinks(WTPartDescribeLink.class,
				latestPartIteration, WTPartDescribeLink.DESCRIBED_BY_ROLE);

		List<WTPartReferenceLink> referenceLinksList = DBUtils.retrieveLinks(WTPartReferenceLink.class,
				latestPartIteration, WTPartReferenceLink.ROLE_BOBJECT_ROLE);

		for (WTPartDescribeLink wtPartDescribeLink : describeLinksList) {
			LOGGER.debug("deleteDocLinks : B4 deleting wtPartDescribeLink ");
			PersistenceServerHelper.manager.remove(wtPartDescribeLink);
			LOGGER.debug("deleteDocLinks : After deleting wtPartDescribeLink ");
			logWriter.info("deleteDocLinks : After deleting wtPartDescribeLink ");
		}

		for (WTPartReferenceLink wtPartReferenceLink : referenceLinksList) {
			LOGGER.debug("deleteDocLinks : B4 deleting wtPartReferenceLink ");
			PersistenceServerHelper.manager.remove(wtPartReferenceLink);
			LOGGER.debug("deleteDocLinks : After deleting wtPartReferenceLink ");
			logWriter.info("deleteDocLinks : After deleting wtPartReferenceLink ");
		}
		return latestPartIteration;
	}

	private static ArrayList<AXLEntry> findAXLEntry(WTPart part, VendorPart vendorPart, AXLContext axlContext)
			throws WTException {
		ArrayList<AXLEntry> result = new ArrayList<AXLEntry>();
		QuerySpec querySpec = new QuerySpec();
		querySpec.setAdvancedQueryEnabled(true);
		int axlEntryIDX = querySpec.appendClassList(AXLEntry.class, true);
		if (part != null) {
			querySpec.appendWhere(new SearchCondition(AXLEntry.class, "oemPartReference.key.id", SearchCondition.EQUAL,
					part.getBranchIdentifier() + 1), new int[] { axlEntryIDX });
			querySpec.appendAnd();
		}
		if (vendorPart != null) {
			VendorPartMaster vendorPartMaster = (VendorPartMaster) vendorPart.getMaster();
			querySpec.appendWhere(
					new SearchCondition(AXLEntry.class, "vendorPartReference.key.id", SearchCondition.EQUAL,
							vendorPartMaster.getPersistInfo().getObjectIdentifier().getId()),
					new int[] { axlEntryIDX });
			querySpec.appendAnd();
		}
		querySpec.appendWhere(new SearchCondition(AXLEntry.class, "contextReference.key.id", SearchCondition.EQUAL,
				axlContext.getPersistInfo().getObjectIdentifier().getId()), new int[] { axlEntryIDX });
		QueryResult queryResult = PersistenceHelper.manager.find((StatementSpec) querySpec);
		while (queryResult.hasMoreElements()) {
			result.add((AXLEntry) ((Object[]) queryResult.nextElement())[0]);
		}
		return result;
	}

}