package ext.kb.ws;

import java.io.IOException;
import java.rmi.RemoteException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.xml.bind.JAXBException;

import org.apache.log4j.Logger;

import wt.configurablelink.ConfigurableLinkHelper;
import wt.configurablelink.ConfigurableReferenceLink;
import wt.configuration.TraceCode;
import wt.doc.WTDocument;
import wt.doc.WTDocumentMaster;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.fc.collections.WTArrayList;
import wt.fc.collections.WTCollection;
import wt.fc.collections.WTHashSet;
import wt.iba.definition.litedefinition.AttributeDefDefaultView;
import wt.iba.value.DefaultAttributeContainer;
import wt.iba.value.service.IBAValueDBService;
import wt.inf.container.WTContainerHelper;
import wt.log4j.LogR;
import wt.org.OrganizationServicesHelper;
import wt.org.WTOrganization;
import wt.org.WTOrganizationIdentifier;
import wt.part.QuantityUnit;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.part.WTPartUsageLink;
import wt.pds.StatementSpec;
import wt.pom.PersistenceException;
import wt.pom.Transaction;
import wt.query.ClassAttribute;
import wt.query.QueryException;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.session.SessionHelper;
import wt.type.TypedUtilityServiceHelper;
import wt.util.WTException;
import wt.util.WTProperties;
import wt.util.WTPropertyVetoException;
import wt.vc.VersionControlHelper;

import com.ptc.core.foundation.type.server.impl.TypeHelper;
import com.ptc.core.lwc.server.PersistableAdapter;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.impl.WCTypeIdentifier;
import com.ptc.core.meta.server.TypeIdentifierUtility;
import com.ptc.generic.iba.AttributeService;
import com.ptc.jws.servlet.JaxWsWebService;
import com.ptc.windchill.suma.axl.AXLContext;
import com.ptc.windchill.suma.axl.AXLEntry;
import com.ptc.windchill.suma.axl.AXLHelper;
import com.ptc.windchill.suma.axl.AXLPreference;
import com.ptc.windchill.suma.jca.util.SumaJcaHelper;
import com.ptc.windchill.suma.part.ManufacturerPart;
import com.ptc.windchill.suma.supplier.Manufacturer;

import ext.kb.service.WebServiceHelper;
import ext.kb.util.DBUtils;
import ext.kb.util.IBAHelper;
import ext.kb.util.KBTypeIdProvider;
import ext.kb.util.ObjectRevisionHelper;
import wt.vc.views.View;
import wt.vc.views.ViewHelper;
import wt.vc.views.ViewReference;
import wt.vc.wip.WorkInProgressHelper;

@WebService()
public class KBCreateRefInfoService extends JaxWsWebService {
	private static final Logger LOGGER = LogR.getLogger(KBCreateRefInfoService.class.getName());
	private static final Logger logWriter = LogR.getLogger("ext.kb.ws.KBCreateRefInfoService_Log");

	@WebMethod(operationName = "createRefInfo")
	public List<String> createRefInfo(@WebParam(name = "parentID") String parentID,
			@WebParam(name = "parent_CID") String parent_CID, @WebParam(name = "RefInfos") String RefInfo[][])
			throws WTException, WTPropertyVetoException, JAXBException, IOException

	{

		Transaction trx = null;
		ArrayList partLinkExists = new ArrayList();
		ArrayList docLinkExists = new ArrayList();
		List<String> result = new ArrayList<String>();

		int counter = 1;
		WTProperties properties = WTProperties.getServerProperties();
		String defaultDomain = properties.getProperty("KBDefaultExternalDomain", "CADIM DOMAIN");
		String kitList = properties.getProperty("ext.kb.kitList");

		try {

			trx = new Transaction();
			trx.start();
			String legacyManufacturer = "460000870";
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			Date date = new Date();
			String formatedDate = sdf.format(date);

			logWriter.info(" Processing create RefInfo on " + formatedDate + " request parent number is " + parentID
					+ " parent_CID is " + parent_CID);
			LOGGER.debug(" Processing create RefInfo on " + formatedDate + " request parent number is " + parentID
					+ " parent_CID is " + parent_CID);
			QuerySpec resQS = WebServiceHelper.findPartByNumberAndCadim(parentID, parent_CID);
			QueryResult resQR = PersistenceHelper.manager.find((StatementSpec) resQS);
			int size = resQR.size();
			if (size > 0) {
				Persistable resObj[] = (Persistable[]) resQR.nextElement();
				LOGGER.debug("resObj: " + resObj);

				LOGGER.debug("resObj: " + resObj[0]);
				WTPart resPart = (WTPart) resObj[0];
				LOGGER.debug("resPart: " + resPart);
				WTPart latestPartRevision = (WTPart) ObjectRevisionHelper.getLatestVersionByPersistable(resPart);
				WTPart latestPartIteration = (WTPart) VersionControlHelper.getLatestIteration(latestPartRevision);
				WTPart workingCopyPart = null;
				//retrieving design view part
				 latestPartIteration = (WTPart)WebServiceHelper.getDesignViewPart((WTPart)latestPartIteration);
					if(latestPartIteration == null)
						throw new WTException("Design view Part with number "+latestPartRevision.getNumber()+" not found");
				LOGGER.debug("RefInfo.size(): " + RefInfo.length);
				logWriter.info("RefInfo.size(): " + RefInfo.length);
				LOGGER.debug("Going to delete related procurement parts");
				deleteManufacturerParts(latestPartIteration);
				LOGGER.debug("After deleting related AML's");
				logWriter.info("After deleting related AML's");

				ArrayList<ConfigurableReferenceLink> kbRefInfoLinksList = (ArrayList<ConfigurableReferenceLink>) DBUtils
						.retrieveLinks(ConfigurableReferenceLink.class, latestPartIteration,
								ConfigurableReferenceLink.ROLE_BOBJECT_ROLE);
				LOGGER.debug("kbRefInfoLinksList size " + kbRefInfoLinksList.size());
				logWriter.info("kbRefInfoLinksList size " + kbRefInfoLinksList.size());
				for (ConfigurableReferenceLink confLink : kbRefInfoLinksList) {
					LOGGER.debug("B4 deleting kbRefInfoLinks "+confLink);
					logWriter.info("B4 deleting kbRefInfoLinks ");
					PersistenceServerHelper.manager.remove(confLink);
					LOGGER.debug("After deleting kbRefInfoLinks ");
					logWriter.info("After deleting kbRefInfoLinks ");
				}
				ArrayList<ConfigurableReferenceLink> kbRefInfoLinksList1 = (ArrayList<ConfigurableReferenceLink>) DBUtils
						.retrieveLinks(ConfigurableReferenceLink.class, latestPartIteration.getMaster(),
								ConfigurableReferenceLink.ROLE_AOBJECT_ROLE);
				LOGGER.debug("kbRefInfoLinksList1 size " + kbRefInfoLinksList1.size());
				logWriter.info("kbRefInfoLinksList1 size " + kbRefInfoLinksList1.size());
				for (ConfigurableReferenceLink confLink : kbRefInfoLinksList1) {
					String linkYNumber = IBAHelper.readIBA(confLink, "KB_FREE_TEXT");
					LOGGER.debug("linkYNumber is " + linkYNumber);
					logWriter.info("linkYNumber is " + linkYNumber);
					WTPart roleAObject = (WTPart) confLink.getRoleAObject();
					String roleAObjectNumber = roleAObject.getNumber();
					LOGGER.debug("roleAObjectNumber is " + roleAObjectNumber);
					logWriter.info("roleAObjectNumber is " + roleAObjectNumber);
                    if (isCorrectType(roleAObject)){
						String roleAObjectPartCategory = IBAHelper.readIBA(roleAObject, "KB_PART_CATEGORY");
						LOGGER.debug("roleAObjectPartCategory is " + roleAObjectPartCategory);
						logWriter.info("roleAObjectPartCategory is " + roleAObjectPartCategory);
						if (roleAObjectPartCategory.equals("10") && kitList.contains(String.valueOf(linkYNumber))) {
							LOGGER.debug(
									"roleBObjectPartCategory is 10 and y number is contained in kitlist so deleting the configurable link between"
											+ latestPartIteration.getNumber() + " and " + roleAObject.getNumber()+" "+confLink);
							logWriter.info(
									"roleBObjectPartCategory is 10 and y number is contained in kitlist so deleting the configurable link between"
											+ latestPartIteration.getNumber() + " and " + roleAObject.getNumber());
							PersistenceServerHelper.manager.remove(confLink);
							LOGGER.debug("After deleting kbRefInfoLinks ");
							logWriter.info("After deleting kbRefInfoLinks ");
						}
                    }
				}

				for (int i = 0; i < RefInfo.length; i++) {
					WTOrganizationIdentifier orgId = new WTOrganizationIdentifier();
					LOGGER.debug("orgId ==" + orgId);
					int yNumber = Integer.parseInt(RefInfo[i][0]);
					LOGGER.debug("yNumber " + yNumber);
					logWriter.info("yNumber " + yNumber);
					LOGGER.debug("RefInfo[i].length " + RefInfo[i].length);
					logWriter.info("RefInfo[i].length " + RefInfo[i].length);
					if (yNumber == 125) {
						if (RefInfo[i].length > 2) {
							int j = 3;
							while (j < RefInfo[i].length){
								orgId.setUniqueIdentifier(legacyManufacturer);
								logWriter.info("Manufaturing Org id is legacy " + legacyManufacturer);
								LOGGER.debug("Manufacturing Org id is legacy " + legacyManufacturer);
								LOGGER.debug("After setting unique identifier");
								orgId.setCodingSystem("0060");
								LOGGER.debug("After setting coding System");
								WTOrganization manfOrg = OrganizationServicesHelper.getOrganizationByOrgId(orgId);
								LOGGER.debug("Manufacturing  is " + manfOrg.getName());
								
								Manufacturer manf = null;
								String partNumber = RefInfo[i][1].trim();
								
								if(partNumber==null || "".equals(partNumber)){
									partNumber = "-";
								}
								
								logWriter.info("Manufacturing part number is " + RefInfo[i][j] + partNumber);
								LOGGER.debug("Manufacturing part number is " + RefInfo[i][j] + partNumber);
								
								ManufacturerPart manfPart = WebServiceHelper.findManufacturerPart(legacyManufacturer,
										RefInfo[i][j] + "-" + partNumber);
								if (manfPart == null) {
									logWriter.info("Manufacturing part with number " + RefInfo[i][j] + "-"
											+ RefInfo[i][1] + " and org id " + legacyManufacturer
											+ " not found going to create new Manuturing Part");
									LOGGER.debug("Manufacturing part with number " + RefInfo[i][j] + "-" + partNumber
											+ " and org id " + legacyManufacturer
											+ " not found going to create new Manuturing Part");
									
									
									manfPart = ManufacturerPart.newManufacturerPart(RefInfo[i][j] + "-" + partNumber,
											manfOrg.getName());
									manfPart.setTypeDefinitionReference(
											TypedUtilityServiceHelper.service.getTypeDefinitionReference(
													KBTypeIdProvider.getType("SUPPLIERPART").getLeafName()));
									manfPart.setEndItem(false);
									manfPart.setDefaultUnit(QuantityUnit.toQuantityUnit("ea"));
									manfPart.setDefaultTraceCode(TraceCode.toTraceCode("S"));
									manfPart.setOrganization(manfOrg);
									manfPart.setContainer(latestPartIteration.getContainer());

									try {
										View[] views = ViewHelper.service.getAllViews();
										for (View v : views)
											if ("Design".equalsIgnoreCase(v.getName())) {
												manfPart.setView(ViewReference.newViewReference(v));
												break;
											}
									} catch (WTException e) {
										LOGGER.warn("Failed to set the view of the part", e);
									}

									manf = com.ptc.windchill.suma.supplier.SupplierHelper.service.getManufacturer(
											manfPart.getOrganization(), manfPart.getContainer().getContainer());
									LOGGER.debug("Manufacturer is " + manf.getName());

									if (manf != null) {
										try {
											manfPart.setOrganization(manf.getOrganization());
											manfPart.setContainerReference(latestPartIteration.getContainerReference());
											LOGGER.debug("After setting org and container ref");
										} catch (WTPropertyVetoException e) {
											throw new RuntimeException(
													"Failed to set organization of new manufacturing part", e);
										}
										LOGGER.debug("Persisting the manufacturer part");
										PersistenceHelper.manager.store(manfPart);
										LOGGER.debug("After Persisting the manufacturer part");
									}
									LOGGER.debug("containerName name ===" + manfPart.getContainerName());
									logWriter.info("containerName name ===" + manfPart.getContainerName());
									LOGGER.debug(
											" part domain before \"" + manfPart.getDomainRef().getName() + "\" domain");
									logWriter.info(
											" part domain before \"" + manfPart.getDomainRef().getName() + "\" domain");
									// WebServiceHelper.setCadimDomain(manfPart,
									// defaultDomain,manfPart.getContainerName());
									LOGGER.debug(
											" part domain After \"" + manfPart.getDomainRef().getName() + "\" domain");
									logWriter.info(
											" part domain After \"" + manfPart.getDomainRef().getName() + "\" domain");

								} else {
									manf = com.ptc.windchill.suma.supplier.SupplierHelper.service.getManufacturer(
											manfPart.getOrganization(), manfPart.getContainer().getContainer());
									logWriter.info("Manufacturing part with number " + RefInfo[i][j] + RefInfo[i][2]
											+ " and org id " + legacyManufacturer + " found going to create new AML");
									LOGGER.debug("Manufacturing part with number " + RefInfo[i][j] + RefInfo[i][2]
											+ " and org id " + legacyManufacturer + " found going to create new AML");

								}
								AXLContext cont = AXLHelper.service.getDefaultContext(manf.getContainerReference());
								AXLPreference pref = AXLPreference.toAXLPreference("proposed");
								boolean partCheckedOut = WorkInProgressHelper.isCheckedOut(latestPartIteration);
								LOGGER.debug("latestPartIteration is partCheckedOut " + partCheckedOut);
								LOGGER.debug("latestPartIteration is partCheckedOut " + partCheckedOut);
								String checkoutStatus = findCheckoutStatus(latestPartIteration, WTPart.class);
								LOGGER.debug("latestPartIteration checkoutStatus " + checkoutStatus);
								logWriter.info("latestPartIteration checkoutStatus " + checkoutStatus);
								if (checkoutStatus.equalsIgnoreCase("c/o") || checkoutStatus.equalsIgnoreCase("wrk")) {
									LOGGER.debug("parent part is checked out creating AML with working copy ");
									logWriter.info("parent part is checked out creating AML with working copy ");
									workingCopyPart = (WTPart) WorkInProgressHelper.service
											.workingCopyOf(latestPartIteration);
									AXLHelper.service.addAML(cont, workingCopyPart, null, manfPart, pref);
								} else {

									LOGGER.debug("parent part is not checked out creating AML with server copy ");
									logWriter.info("parent part is not checked out creating AML with server copy  ");
									AXLHelper.service.addAML(cont, latestPartIteration, null, manfPart, pref);
								}
								j = j + 2;
								LOGGER.debug("After setting Preference");
								logWriter.info("j " + j);
								LOGGER.debug("j " + j);

							}
						} else {
							orgId.setUniqueIdentifier(legacyManufacturer);
							logWriter.info("Manufaturing Org id is legacy " + legacyManufacturer);
							LOGGER.debug("Manufacturing Org id is legacy " + legacyManufacturer);
							orgId.setCodingSystem("0060");
							LOGGER.debug("After setting coding System");
							WTOrganization manfOrg = OrganizationServicesHelper.getOrganizationByOrgId(orgId);
							LOGGER.debug("Manufacturing  is " + manfOrg.getName());
							
							Manufacturer manf = null;
							
							String partNumber = RefInfo[i][1];
							
							if(partNumber==null || "".equals(partNumber)){
								partNumber = "-";
							}
							logWriter.info("Manufacturing part number is " + partNumber);
							LOGGER.debug("Manufacturing part number is less than 2 : " + partNumber);
							ManufacturerPart manfPart = WebServiceHelper.findManufacturerPart(legacyManufacturer,
									partNumber);
							if (manfPart == null) {
								logWriter.info("Manufacturing part with number " + RefInfo[i][1] + " and org id "
										+ legacyManufacturer + " not found going to create new Manuturing Part");
								LOGGER.debug("Manufacturing part with number " + RefInfo[i][1] + " and org id "
										+ legacyManufacturer + " not found going to create new Manuturing Part");
								manfPart = ManufacturerPart.newManufacturerPart(partNumber, manfOrg.getName());
								manfPart.setTypeDefinitionReference(
										TypedUtilityServiceHelper.service.getTypeDefinitionReference(
												KBTypeIdProvider.getType("SUPPLIERPART").getLeafName()));
								manfPart.setEndItem(false);
								manfPart.setDefaultUnit(QuantityUnit.toQuantityUnit("ea"));
								manfPart.setDefaultTraceCode(TraceCode.toTraceCode("S"));
								manfPart.setOrganization(manfOrg);
								manfPart.setContainer(latestPartIteration.getContainer());

								try {
									View[] views = ViewHelper.service.getAllViews();
									for (View v : views)
										if ("Design".equalsIgnoreCase(v.getName())) {
											manfPart.setView(ViewReference.newViewReference(v));
											break;
										}
								} catch (WTException e) {
									LOGGER.warn("Failed to set the view of the part", e);
								}

								manf = com.ptc.windchill.suma.supplier.SupplierHelper.service.getManufacturer(
										manfPart.getOrganization(), manfPart.getContainer().getContainer());
								LOGGER.debug("Manufacturer is " + manf.getName());

								if (manf != null) {
									try {
										manfPart.setOrganization(manf.getOrganization());
										manfPart.setContainerReference(latestPartIteration.getContainerReference());
										LOGGER.debug("After setting org and container ref");
									} catch (WTPropertyVetoException e) {
										throw new RuntimeException(
												"Failed to set organization of new manufacturing part", e);
									}
									LOGGER.debug("Persisting the manufacturer part");
									PersistenceHelper.manager.store(manfPart);
									LOGGER.debug("After Persisting the manufacturer part");
								}
								LOGGER.debug("containerName name ===" + manfPart.getContainerName());
								logWriter.info("containerName name ===" + manfPart.getContainerName());
								LOGGER.debug(
										" part domain before \"" + manfPart.getDomainRef().getName() + "\" domain");
								logWriter.info(
										" part domain before \"" + manfPart.getDomainRef().getName() + "\" domain");
								// WebServiceHelper.setCadimDomain(manfPart,
								// defaultDomain,manfPart.getContainerName());
								LOGGER.debug(" part domain After \"" + manfPart.getDomainRef().getName() + "\" domain");
								logWriter.info(
										" part domain After \"" + manfPart.getDomainRef().getName() + "\" domain");
							}

							else {
								manf = com.ptc.windchill.suma.supplier.SupplierHelper.service.getManufacturer(
										manfPart.getOrganization(), manfPart.getContainer().getContainer());
								logWriter.info("Manufacturing part with number " + RefInfo[i][1] + " and org id "
										+ legacyManufacturer + " found going to create new AML");

							}
							AXLContext cont = AXLHelper.service.getDefaultContext(manf.getContainerReference());
							AXLPreference pref = AXLPreference.toAXLPreference("proposed");
							boolean partCheckedOut = WorkInProgressHelper.isCheckedOut(latestPartIteration);
							LOGGER.debug("latestPartIteration is partCheckedOut " + partCheckedOut);
							LOGGER.debug("latestPartIteration is partCheckedOut " + partCheckedOut);
							String checkoutStatus = findCheckoutStatus(latestPartIteration, WTPart.class);
							LOGGER.debug("latestPartIteration checkoutStatus " + checkoutStatus);
							logWriter.info("latestPartIteration checkoutStatus " + checkoutStatus);
							if (checkoutStatus.equalsIgnoreCase("c/o") || checkoutStatus.equalsIgnoreCase("wrk")) {
								LOGGER.debug("parent part is checked out creating AML with working copy ");
								logWriter.info("parent part is checked out creating AML with working copy ");
								workingCopyPart = (WTPart) WorkInProgressHelper.service
										.workingCopyOf(latestPartIteration);
								AXLHelper.service.addAML(cont, workingCopyPart, null, manfPart, pref);
							} else {

								LOGGER.debug("parent part is not checked out creating AML with server copy ");
								logWriter.info("parent part is not checked out creating AML with server copy  ");
								AXLHelper.service.addAML(cont, latestPartIteration, null, manfPart, pref);
							}
						}

					} else if (yNumber == 126 || yNumber == 213) {
						orgId.setUniqueIdentifier("460000870");
						logWriter.info("Manufaturing Org id is " + 460000870);
						LOGGER.debug("Manufacturing Org id is " + 460000870);
						LOGGER.debug("After setting unique identifier");
						orgId.setCodingSystem("0060");
						LOGGER.debug("After setting coding System");
						WTOrganization manfOrg = OrganizationServicesHelper.getOrganizationByOrgId(orgId);
						LOGGER.debug("Manufacturing  is " + manfOrg.getName());
						
						Manufacturer manf = null;
						
						String partNumber = RefInfo[i][1];
						
						if(partNumber==null || "".equals(partNumber)){
							partNumber = "-";
						}
						logWriter.info("Manufacturing part number is " + partNumber);
						LOGGER.debug("Manufacturing part number is " +partNumber);
						
						ManufacturerPart manfPart = WebServiceHelper.findManufacturerPart("460000870", partNumber);
						if (manfPart == null) {
							logWriter.info("Manufacturing part with number " + RefInfo[i][1]
									+ " and org id 460000870 not found going to create new Manuturing Part");
							LOGGER.debug("Manufacturing part with number " + RefInfo[i][1]
									+ " and org id 460000870 not found going to create new Manuturing Part");
							manfPart = ManufacturerPart.newManufacturerPart(partNumber, manfOrg.getName());
							manfPart.setTypeDefinitionReference(
									TypedUtilityServiceHelper.service.getTypeDefinitionReference(
											KBTypeIdProvider.getType("SUPPLIERPART").getLeafName()));
							manfPart.setEndItem(false);
							manfPart.setDefaultUnit(QuantityUnit.toQuantityUnit("ea"));
							manfPart.setDefaultTraceCode(TraceCode.toTraceCode("S"));
							manfPart.setOrganization(manfOrg);
							manfPart.setContainer(latestPartIteration.getContainer());

							try {
								View[] views = ViewHelper.service.getAllViews();
								for (View v : views)
									if ("Design".equalsIgnoreCase(v.getName())) {
										manfPart.setView(ViewReference.newViewReference(v));
										break;
									}
							} catch (WTException e) {
								LOGGER.warn("Failed to set the view of the part", e);
							}

							manf = com.ptc.windchill.suma.supplier.SupplierHelper.service.getManufacturer(
									manfPart.getOrganization(), manfPart.getContainer().getContainer());
							LOGGER.debug("Manufacturer is " + manf.getName());

							if (manf != null) {
								try {
									manfPart.setOrganization(manf.getOrganization());
									manfPart.setContainerReference(latestPartIteration.getContainerReference());
									LOGGER.debug("After setting org and container ref");
								} catch (WTPropertyVetoException e) {
									throw new RuntimeException("Failed to set organization of new manufacturing part",
											e);
								}
								LOGGER.debug("Persisting the manufacturer part");
								PersistenceHelper.manager.store(manfPart);
								LOGGER.debug("After Persisting the manufacturer part");
							}
						} else {
							manf = com.ptc.windchill.suma.supplier.SupplierHelper.service.getManufacturer(
									manfPart.getOrganization(), manfPart.getContainer().getContainer());
							logWriter.info("Manufacturing part with number " + RefInfo[i][1]
									+ " and org id 460000870 found going to create new AML");
							LOGGER.debug("Manufacturing part with number " + RefInfo[i][1]
									+ " and org id 460000870 found going to create new AML");

						}
						AXLContext cont = AXLHelper.service.getDefaultContext(manf.getContainerReference());
						AXLPreference pref = AXLPreference.toAXLPreference("proposed");
						boolean partCheckedOut = WorkInProgressHelper.isCheckedOut(latestPartIteration);
						LOGGER.debug("latestPartIteration is partCheckedOut " + partCheckedOut);
						LOGGER.debug("latestPartIteration is partCheckedOut " + partCheckedOut);
						String checkoutStatus = findCheckoutStatus(latestPartIteration, WTPart.class);
						LOGGER.debug("latestPartIteration checkoutStatus " + checkoutStatus);
						logWriter.info("latestPartIteration checkoutStatus " + checkoutStatus);
						if (checkoutStatus.equalsIgnoreCase("c/o") || checkoutStatus.equalsIgnoreCase("wrk")) {
							LOGGER.debug("parent part is checked out creating AML with working copy ");
							logWriter.info("parent part is checked out creating AML with working copy ");
							workingCopyPart = (WTPart) WorkInProgressHelper.service.workingCopyOf(latestPartIteration);
							AXLHelper.service.addAML(cont, workingCopyPart, null, manfPart, pref);
						} else {

							LOGGER.debug("parent part is not checked out creating AML with server copy ");
							logWriter.info("parent part is not checked out creating AML with server copy  ");
							AXLHelper.service.addAML(cont, latestPartIteration, null, manfPart, pref);
						}
					}

					else {
						logWriter.info("Y Number is " + yNumber + " Going to create Configurable link");
						LOGGER.debug("Y Number is " + yNumber + " Going to create Configurable link");
						QuerySpec qsrefPart = new QuerySpec(WTPart.class);
						qsrefPart.appendWhere(new SearchCondition(WTPart.class, WTPart.NUMBER, SearchCondition.EQUAL,
								RefInfo[i][1], false));
						QueryResult qrchild = PersistenceHelper.manager.find((StatementSpec) qsrefPart);
						LOGGER.debug("qrchild.size(): " + qrchild.size());
						if (qrchild.size() > 0) {
							WTPart childPart = (WTPart) qrchild.nextElement();
							String childPartNumber = childPart.getNumber();
							LOGGER.debug("CHILDPART : "+childPart.getNumber());
							QueryResult qs = VersionControlHelper.service.allVersionsOf(childPart);
							LOGGER.debug("Querymaster : "+qs.size());
							if(qs.hasMoreElements()){
								childPart = (WTPart)qs.nextElement();
							}
							//retrieving design view part
							childPart = (WTPart)WebServiceHelper.getDesignViewPart((WTPart)childPart);
								if(childPart == null)
									throw new WTException("Design view Part with number "+childPartNumber+" not found");
							if(isCorrectType(childPart)){
								if (!partLinkExists.contains(childPart.getNumber())) {
									LOGGER.debug("childPart number " + childPart.getNumber()+" "+childPart.getVersionIdentifier().getValue()+"."+childPart.getIterationIdentifier().getValue());
									logWriter.info("childPart number " + childPart.getNumber());
									String partCategory = IBAHelper.readIBA(childPart, "KB_PART_CATEGORY");
									LOGGER.debug("childPart partCategory " + partCategory);
									logWriter.info("childPart partCategory " + partCategory);
									WTCollection configurableLinkList = null;
	
									if (partCategory.equals("10") && kitList.contains(String.valueOf(yNumber))) {
										if (!partLinkExists.contains(latestPartIteration.getNumber())) {
											boolean update = true;
											LOGGER.debug("part category is 10 and the yNumber is in the kit list ");
											logWriter.info("part category is 10 and the yNumber is in the kit list ");
											
											
											
											ArrayList<ConfigurableReferenceLink> refInfoLinks = (ArrayList<ConfigurableReferenceLink>) DBUtils
													.retrieveLinks(ConfigurableReferenceLink.class, childPart,
															ConfigurableReferenceLink.ROLE_BOBJECT_ROLE);
											LOGGER.debug("RefInfoLink for empty FreeText : "+refInfoLinks.size());
											if(refInfoLinks.size()>0){
												for (ConfigurableReferenceLink confLink : refInfoLinks) {
													LOGGER.debug("Conf RefInfo Link : "+confLink);
													WTPartMaster childMaster = (WTPartMaster)confLink.getRoleBObject();
													LOGGER.debug("ChildPartMaster : "+childMaster.getNumber()+" LatestPartIteration Number : "+latestPartIteration.getNumber());
													if(childMaster.getNumber().equals(latestPartIteration.getNumber())){
														LOGGER.debug("Both part numbers are equal....");
														String ynumber = IBAHelper.readIBA(confLink, "KB_FREE_TEXT");
														LOGGER.debug("YNUMBER : "+ynumber);
														if(ynumber==null || "".equals(ynumber) ){
															
															QueryResult queryMaster = VersionControlHelper.service.allVersionsOf(childPart);
															LOGGER.debug("Querymaster : "+queryMaster.size());
															if(queryMaster.hasMoreElements()){
																WTPart roleAPart = (WTPart)queryMaster.nextElement();
																LOGGER.debug("roleAPart : "+roleAPart.getNumber());
																String roleAPartNum = roleAPart.getNumber();
																//retrieving design view part
																roleAPart = (WTPart)WebServiceHelper.getDesignViewPart((WTPart)roleAPart);
																	if(roleAPart == null)
																		throw new WTException("Design view Part with number "+roleAPartNum+" not found");
																boolean partCheckedOut = WorkInProgressHelper.isCheckedOut(roleAPart);
																LOGGER.debug("latestPartIteration is partCheckedOut " + partCheckedOut);
																logWriter.info("latestPartIteration is partCheckedOut " + partCheckedOut);
																String checkoutStatus = findCheckoutStatus(roleAPart, WTPart.class);
																LOGGER.debug("latestPartIteration checkoutStatus " + checkoutStatus);
																logWriter.info("latestPartIteration checkoutStatus " + checkoutStatus);
																if (checkoutStatus.equalsIgnoreCase("c/o")
																		|| checkoutStatus.equalsIgnoreCase("wrk")) {
																	LOGGER.debug("parent part is checked out ");
																	logWriter.info("parent part is checked out ");
																	workingCopyPart = (WTPart) WorkInProgressHelper.service
																			.workingCopyOf(roleAPart);
																	 ObjectReference.newObjectReference(workingCopyPart);
																} else {
							
																	LOGGER.debug("parent part is not checked out ");
																	logWriter.info("parent part is not checked out ");
																	ObjectReference.newObjectReference(roleAPart);
																}
																LOGGER.debug("Sett IBA FREE Text");
																confLink = (ConfigurableReferenceLink) IBAHelper.setIba(confLink,
																		"KB_FREE_TEXT", "");
																PersistenceServerHelper.manager.update(confLink);
																confLink = (ConfigurableReferenceLink) PersistenceHelper.manager
																		.refresh(confLink);
																update = false;
																
															}															
															
														}
														
													}else{
														LOGGER.debug("ChildPartMaster :and LatestPartIteration Number are not equal ");
													}
												}
											}
											if(update){										
													LOGGER.debug("Update is true....");
													WTPartMaster kitPartMaster = (WTPartMaster) latestPartIteration.getMaster();
													WTCollection kitPartMasterList = new WTArrayList();
													kitPartMasterList.add(kitPartMaster);
													ObjectReference partRef = null;
													WTPart latestChildPartRevision = (WTPart) ObjectRevisionHelper
															.getLatestVersionByPersistable(childPart);
													WTPart latestChildPartIteration = (WTPart) VersionControlHelper
															.getLatestIteration(latestChildPartRevision);
													//retrieving design view part
													latestChildPartIteration = (WTPart)WebServiceHelper.getDesignViewPart((WTPart)latestChildPartIteration);
														if(latestChildPartIteration == null)
															throw new WTException("Design view Part with number "+latestChildPartRevision.getNumber()+" not found");
													String checkoutStatus = findCheckoutStatus(latestChildPartIteration,
															WTPart.class);
													LOGGER.debug("childPart checkoutStatus " + checkoutStatus);
													logWriter.info("childPart checkoutStatus " + checkoutStatus);
													if (checkoutStatus.equalsIgnoreCase("c/o")
															|| checkoutStatus.equalsIgnoreCase("wrk")) {
														LOGGER.debug("parent part is checked out ");
														logWriter.info("parent part is checked out ");
														workingCopyPart = (WTPart) WorkInProgressHelper.service
																.workingCopyOf(latestChildPartIteration);
														partRef = ObjectReference.newObjectReference(workingCopyPart);
													} else {
			
														LOGGER.debug("parent part is not checked out ");
														logWriter.info("parent part is not checked out ");
														partRef = ObjectReference.newObjectReference(latestChildPartIteration);
													}
													configurableLinkList = ConfigurableLinkHelper.service
															.createConfigurableReferenceLink(partRef,
																	KBTypeIdProvider.getType("KBREFINFOLINK"), kitPartMasterList,
																	true);
													if(configurableLinkList.isEmpty()){
														configurableLinkList = new WTArrayList(getConfigurableLink(latestPartIteration,
																childPart, refInfoLinks));
													
													}
													partLinkExists.add(childPart.getNumber());
													LOGGER.debug("Adding part " + childPart.getNumber() + " to list");
													logWriter.info("Adding part " + childPart.getNumber() + " to list");
													LOGGER.debug("Before setting link Attributes " + configurableLinkList.size());
													logWriter.info("Before setting link Attributes " + configurableLinkList.size());
													
													
													Iterator vi = configurableLinkList.iterator();
													ObjectReference linkRef = (ObjectReference) vi.next();
													ConfigurableReferenceLink KBRefInfoLink = (ConfigurableReferenceLink) linkRef
															.getObject();
													LOGGER.debug("KBRefInfoLink " + KBRefInfoLink);
													logWriter.info("KBRefInfoLink " + KBRefInfoLink);
													LOGGER.debug("KB_FREE_TEXT " + yNumber);
													logWriter.info("KB_FREE_TEXT  " + yNumber);
													KBRefInfoLink = (ConfigurableReferenceLink) IBAHelper.setIba(KBRefInfoLink,
															"KB_FREE_TEXT", "");
													PersistenceServerHelper.manager.update(KBRefInfoLink);
													KBRefInfoLink = (ConfigurableReferenceLink) PersistenceHelper.manager
															.refresh(KBRefInfoLink);
													updateTypeDesignation(KBRefInfoLink, String.valueOf(yNumber));
													LOGGER.debug("After link Attributes " + configurableLinkList.size());
													logWriter.info("After setting link Attributes " + configurableLinkList.size());
													LOGGER.debug("After link Attributes ");
													logWriter.info("After setting link Attributes ");
													
													String kitCheckoutStatus = findCheckoutStatus(latestChildPartIteration,
															WTPart.class);
													LOGGER.debug("latestPartIteration checkoutStatus before checkin "
															+ kitCheckoutStatus);
													logWriter.info("latestPartIteration checkoutStatus before checkin "
															+ kitCheckoutStatus);
													if (kitCheckoutStatus.equalsIgnoreCase("c/o")
															|| kitCheckoutStatus.equalsIgnoreCase("wrk")) {
														workingCopyPart = (WTPart) WorkInProgressHelper.service
																.workingCopyOf(latestChildPartIteration);
														LOGGER.debug("workingCopyPart part is " + workingCopyPart);
														logWriter.info("workingCopyPart part is " + workingCopyPart);
														if (!(workingCopyPart == null)) {
															workingCopyPart = (WTPart) WorkInProgressHelper.service.checkin(
																	workingCopyPart, "Automatich Checkin after creating Ref-Info");
															LOGGER.debug("After checkin of WTPart "
																	+ workingCopyPart.getVersionInfo().getIdentifier().getValue()
																	+ " and iteration " + workingCopyPart.getIterationInfo()
																			.getIdentifier().getValue());
															logWriter.info("After checkin of WTPart  revision "
																	+ workingCopyPart.getVersionInfo().getIdentifier().getValue()
																	+ " and iteration " + workingCopyPart.getIterationInfo()
																			.getIdentifier().getValue());
														}
													}
			
													/*Iterator vi = configurableLinkList.iterator();
													ObjectReference linkRef = (ObjectReference) vi.next();
													ConfigurableReferenceLink KBRefInfoLink = (ConfigurableReferenceLink) linkRef
															.getObject();
													LOGGER.debug("KBRefInfoLink " + KBRefInfoLink);
													logWriter.info("KBRefInfoLink " + KBRefInfoLink);
													LOGGER.debug("KB_FREE_TEXT " + yNumber);
													logWriter.info("KB_FREE_TEXT  " + yNumber);
													KBRefInfoLink = (ConfigurableReferenceLink) IBAHelper.setIba(KBRefInfoLink,
															"KB_FREE_TEXT", String.valueOf(yNumber));
													PersistenceServerHelper.manager.update(KBRefInfoLink);
													KBRefInfoLink = (ConfigurableReferenceLink) PersistenceHelper.manager
															.refresh(KBRefInfoLink);
													updateTypeDesignation(KBRefInfoLink, String.valueOf(yNumber));
													LOGGER.debug("After link Attributes " + configurableLinkList.size());
													logWriter.info("After setting link Attributes " + configurableLinkList.size());
													LOGGER.debug("After link Attributes ");
													logWriter.info("After setting link Attributes ");*/
										}
										} else {
	
											WTPart parentPart = null;
											ConfigurableReferenceLink conRefLink = null;
	
											WTPartMaster partMaster = (WTPartMaster) latestPartIteration.getMaster();
											QueryResult navQr = PersistenceHelper.manager.navigate(partMaster,
													"referencedBy", ConfigurableReferenceLink.class, false);
	
											LOGGER.debug("QR Size : " + navQr.size());
	
											while (navQr.hasMoreElements()) {
	
												conRefLink = (ConfigurableReferenceLink) navQr.nextElement();
												parentPart = (WTPart) conRefLink.getRoleAObject();
	
												if (parentPart.getNumber().equals(childPart.getNumber())) {
													break;
												}
											}
	
											LOGGER.debug("Y NUMBER : " + yNumber);
	
											if (conRefLink != null) {
												updateTypeDesignation(conRefLink, String.valueOf(yNumber));
	
												LOGGER.debug("DEBUG after updating");
											}
										}
									} else {
	
										LOGGER.debug("part category is not 10 or the yNumber is not in the kit list ");
										logWriter.info("part category is not 10 or the yNumber is not in the kit list ");
										WTPartMaster childMaster = (WTPartMaster) childPart.getMaster();
										WTCollection childMasterList = new WTArrayList();
										childMasterList.add(childMaster);
										ObjectReference partRef = null;
										boolean partCheckedOut = WorkInProgressHelper.isCheckedOut(latestPartIteration);
										LOGGER.debug("latestPartIteration is partCheckedOut " + partCheckedOut);
										logWriter.info("latestPartIteration is partCheckedOut " + partCheckedOut);
										String checkoutStatus = findCheckoutStatus(latestPartIteration, WTPart.class);
										LOGGER.debug("latestPartIteration checkoutStatus " + checkoutStatus);
										logWriter.info("latestPartIteration checkoutStatus " + checkoutStatus);
										if (checkoutStatus.equalsIgnoreCase("c/o")
												|| checkoutStatus.equalsIgnoreCase("wrk")) {
											LOGGER.debug("parent part is checked out ");
											logWriter.info("parent part is checked out ");
											workingCopyPart = (WTPart) WorkInProgressHelper.service
													.workingCopyOf(latestPartIteration);
											partRef = ObjectReference.newObjectReference(workingCopyPart);
										} else {
	
											LOGGER.debug("parent part is not checked out ");
											logWriter.info("parent part is not checked out ");
											partRef = ObjectReference.newObjectReference(latestPartIteration);
										}
										configurableLinkList = ConfigurableLinkHelper.service
												.createConfigurableReferenceLink(partRef,
														KBTypeIdProvider.getType("KBREFINFOLINK"), childMasterList, true);
										partLinkExists.add(childPart.getNumber());
										LOGGER.debug("Adding part " + childPart.getNumber() + " to list");
										logWriter.info("Adding part " + childPart.getNumber() + " to list");
										LOGGER.debug("Before setting link Attributes " + configurableLinkList.size());
										logWriter.info("Before setting link Attributes " + configurableLinkList.size());
	
										Iterator vi = configurableLinkList.iterator();
										ObjectReference linkRef = (ObjectReference) vi.next();
										ConfigurableReferenceLink KBRefInfoLink = (ConfigurableReferenceLink) linkRef
												.getObject();
										LOGGER.debug("KBRefInfoLink " + KBRefInfoLink);
										logWriter.info("KBRefInfoLink " + KBRefInfoLink);
										LOGGER.debug("KB_FREE_TEXT " + yNumber);
										logWriter.info("KB_FREE_TEXT  " + yNumber);
										KBRefInfoLink = (ConfigurableReferenceLink) IBAHelper.setIba(KBRefInfoLink,
												"KB_FREE_TEXT", "");
										PersistenceServerHelper.manager.update(KBRefInfoLink);
										KBRefInfoLink = (ConfigurableReferenceLink) PersistenceHelper.manager
												.refresh(KBRefInfoLink);
										updateTypeDesignation(KBRefInfoLink, String.valueOf(yNumber));
										LOGGER.debug("After link Attributes " + configurableLinkList.size());
										logWriter.info("After setting link Attributes " + configurableLinkList.size());
										LOGGER.debug("After link Attributes ");
										logWriter.info("After setting link Attributes ");
	
									}
	
								} else {
	
									WTPart parentPart = null;
									ConfigurableReferenceLink conRefLink = null;
	
									WTPartMaster partMaster = (WTPartMaster) childPart.getMaster();
	
									String childpartcategory = IBAHelper.readIBA(childPart, "KB_PART_CATEGORY");
									LOGGER.debug("ChildPartCategory ::>>" + childpartcategory);
									logWriter.info("ChildPartCategory ::>>" + childpartcategory);
									QueryResult navQr = new QueryResult();
									childPart = (WTPart) VersionControlHelper.getLatestIteration(childPart);
									childPartNumber = childPart.getNumber();
									//retrieving design view part
									childPart = (WTPart)WebServiceHelper.getDesignViewPart((WTPart)childPart);
										if(childPart == null)
											throw new WTException("Design view Part with number "+childPartNumber+" not found");
									logWriter.info("childPart revision "
											+ childPart.getVersionInfo().getIdentifier().getValue() + " and iteration "
											+ childPart.getIterationInfo().getIdentifier().getValue());
									ArrayList<ConfigurableReferenceLink> kbRefInfoLinksList2 = (ArrayList<ConfigurableReferenceLink>) DBUtils
											.retrieveLinks(ConfigurableReferenceLink.class, childPart,
													ConfigurableReferenceLink.ROLE_BOBJECT_ROLE);
									ArrayList<ConfigurableReferenceLink> kbRefInfoLinksList3 = (ArrayList<ConfigurableReferenceLink>) DBUtils
											.retrieveLinks(ConfigurableReferenceLink.class, childPart,
													ConfigurableReferenceLink.ROLE_AOBJECT_ROLE);
									
									
									LOGGER.debug("kbRefInfoLinksList3::>>" + kbRefInfoLinksList3.size());
									logWriter.info("kbRefInfoLinksList3::>>" + kbRefInfoLinksList3.size());
									LOGGER.debug("kbRefInfoLinksList2::>>" + kbRefInfoLinksList2.size());
									logWriter.info("kbRefInfoLinksList2 ::>>" + kbRefInfoLinksList2.size());
									
									
									if (childpartcategory.equals("10") && kitList.contains(String.valueOf(yNumber))) {
										LOGGER.debug(
												"Inside childpartcategory.equals(10) && kitList.contains(String.valueOf(yNumber))");
										logWriter.info(
												"Inside childpartcategory.equals(10) && kitList.contains(String.valueOf(yNumber))");
										// navQr =
										// PersistenceHelper.manager.navigate(partMaster,
										// "references",
										// ConfigurableReferenceLink.class, false);
										childPart = (WTPart) VersionControlHelper.getLatestIteration(childPart);
										childPartNumber = childPart.getNumber();
										//retrieving design view part
										childPart = (WTPart)WebServiceHelper.getDesignViewPart((WTPart)childPart);
											if(childPart == null)
												throw new WTException("Design view Part with number "+childPartNumber+" not found");
										logWriter.info("childPart revision "
												+ childPart.getVersionInfo().getIdentifier().getValue() + " and iteration "
												+ childPart.getIterationInfo().getIdentifier().getValue());
										ArrayList<ConfigurableReferenceLink> kbRefInfoLinksList4 = (ArrayList<ConfigurableReferenceLink>) DBUtils
												.retrieveLinks(ConfigurableReferenceLink.class, childPart,
														ConfigurableReferenceLink.ROLE_BOBJECT_ROLE);
										ArrayList<ConfigurableReferenceLink> kbRefInfoLinksList5 = (ArrayList<ConfigurableReferenceLink>) DBUtils
												.retrieveLinks(ConfigurableReferenceLink.class, childPart,
														ConfigurableReferenceLink.ROLE_AOBJECT_ROLE);
										LOGGER.debug("kbRefInfoLinksList3::>>" + kbRefInfoLinksList4.size());
										logWriter.info("kbRefInfoLinksList3::>>" + kbRefInfoLinksList4.size());
										LOGGER.debug("kbRefInfoLinksList2::>>" + kbRefInfoLinksList5.size());
										logWriter.info("kbRefInfoLinksList2 ::>>" + kbRefInfoLinksList5.size());
										navQr = PersistenceHelper.manager.navigate(childPart, "references",
												ConfigurableReferenceLink.class, false);
										LOGGER.debug("Reference QR Size ::>>" + navQr.size());
										logWriter.info("Reference QR Size ::>>" + navQr.size());
										WTPartMaster parentPartMaster = null;
										while (navQr.hasMoreElements()) {
											conRefLink = (ConfigurableReferenceLink) navQr.nextElement();
											logWriter.info("parentPartMaster:inside 123 ");
											 parentPartMaster = (WTPartMaster) conRefLink.getRoleBObject();
											logWriter.info("parentPartMaster: " + parentPartMaster.getDisplayIdentity());
											String parentNumber = parentPartMaster.getNumber();
											logWriter.info("parentpart: " + parentPartMaster.getDisplayIdentity());
											
											if(parentNumber.equals(latestPartIteration.getNumber())){
												LOGGER.debug("Breaking parent part.... : "+parentNumber);
												break;
											}else{
												conRefLink=null;
											}
										}
										if(conRefLink!=null){
											QueryResult queryMaster = VersionControlHelper.service.allVersionsOf(childPart);
											LOGGER.debug("Querymaster : "+queryMaster.size());
											if(queryMaster.hasMoreElements()){
												WTPart roleAPart = (WTPart)queryMaster.nextElement();
												LOGGER.debug("roleAPart : "+roleAPart.getNumber());
												String roleAPartNum = roleAPart.getNumber();
												//retrieving design view part
												roleAPart = (WTPart)WebServiceHelper.getDesignViewPart((WTPart)roleAPart);
													if(roleAPart == null)
														throw new WTException("Design view Part with number "+roleAPartNum+" not found");
												boolean partCheckedOut = WorkInProgressHelper.isCheckedOut(roleAPart);
												LOGGER.debug("latestPartIteration is partCheckedOut " + partCheckedOut);
												logWriter.info("latestPartIteration is partCheckedOut " + partCheckedOut);
												String checkoutStatus = findCheckoutStatus(roleAPart, WTPart.class);
												LOGGER.debug("latestPartIteration checkoutStatus " + checkoutStatus);
												logWriter.info("latestPartIteration checkoutStatus " + checkoutStatus);
												if (checkoutStatus.equalsIgnoreCase("c/o")
														|| checkoutStatus.equalsIgnoreCase("wrk")) {
													LOGGER.debug("parent part is checked out ");
													logWriter.info("parent part is checked out ");
													workingCopyPart = (WTPart) WorkInProgressHelper.service
															.workingCopyOf(roleAPart);
													 ObjectReference.newObjectReference(workingCopyPart);
												} else {
			
													LOGGER.debug("parent part is not checked out ");
													logWriter.info("parent part is not checked out ");
													ObjectReference.newObjectReference(roleAPart);
												}
												
												LOGGER.debug("Calling updateTypeDesignation ");
												
												updateTypeDesignation(conRefLink, String.valueOf(yNumber));
												
											}
										}
										
										
									} else {
										navQr = PersistenceHelper.manager.navigate(partMaster, "referencedBy",
												ConfigurableReferenceLink.class, false);
										
										while (navQr.hasMoreElements()) {
											
											conRefLink = (ConfigurableReferenceLink) navQr.nextElement();
											String parentNumber = "";
											
												parentPart = (WTPart) conRefLink.getRoleAObject();
												parentNumber = parentPart.getNumber();
												LOGGER.debug("PARENT NUMBER : "+parentNumber+" "+WorkInProgressHelper.isCheckedOut(parentPart));
												
												
												logWriter.info("parentpart: " + parentPart.getDisplayIdentity());
											
		
											if (parentNumber.equals(latestPartIteration.getNumber())) {
												if(VersionControlHelper.isLatestIteration(parentPart)){
													LOGGER.debug("EQUALS...."+parentPart.getVersionIdentifier().getValue()+"."+parentPart.getIterationIdentifier().getValue());
													break;
												}else{
													LOGGER.debug("Continuing......");
													continue;
												}
												
											}
										}
										
										LOGGER.debug("Y NUMBER : " + yNumber);
										
										if (conRefLink != null) {
											WTPart p = (WTPart) conRefLink.getRoleAObject();
											LOGGER.debug("CONFIRM PARENT PART : "+p.getNumber()+" "+p.getVersionIdentifier().getValue()+"."+p.getIterationIdentifier().getValue());
											
											boolean partCheckedOut = WorkInProgressHelper.isCheckedOut(latestPartIteration);
											LOGGER.debug("latestPartIteration is partCheckedOut " + partCheckedOut);
											logWriter.info("latestPartIteration is partCheckedOut " + partCheckedOut);
											String checkoutStatus = findCheckoutStatus(latestPartIteration, WTPart.class);
											LOGGER.debug("latestPartIteration checkoutStatus " + checkoutStatus);
											logWriter.info("latestPartIteration checkoutStatus " + checkoutStatus);
											if (checkoutStatus.equalsIgnoreCase("c/o")
													|| checkoutStatus.equalsIgnoreCase("wrk")) {
												LOGGER.debug("parent part is checked out ");
												logWriter.info("parent part is checked out ");
												workingCopyPart = (WTPart) WorkInProgressHelper.service
														.workingCopyOf(latestPartIteration);
												 ObjectReference.newObjectReference(workingCopyPart);
											} else {
		
												LOGGER.debug("parent part is not checked out ");
												logWriter.info("parent part is not checked out ");
												ObjectReference.newObjectReference(latestPartIteration);
											}
											
											
											
											updateTypeDesignation(conRefLink, String.valueOf(yNumber));
										}
									}
									
								}
							}
						} else {

							logWriter.info(
									"Part with number " + RefInfo[i][1] + " not found going to search for document");
							LOGGER.debug(
									"Part with number " + RefInfo[i][1] + " not found going to search for document");
							QuerySpec qsrefDoc = new QuerySpec(WTDocument.class);
							qsrefDoc.appendWhere(new SearchCondition(WTDocument.class, WTDocument.NUMBER,
									SearchCondition.EQUAL, RefInfo[i][1] + "-000", false));
							QueryResult qrrefDoc = PersistenceHelper.manager.find((StatementSpec) qsrefDoc);
							LOGGER.debug("qrrefDoc.size(): " + qrrefDoc.size());
							if (qrrefDoc.size() > 0) {
								WTDocument refInfoDoc = (WTDocument) qrrefDoc.nextElement();
								if (!docLinkExists.contains(refInfoDoc.getNumber())) {
									LOGGER.debug("refInfoDoc number " + refInfoDoc.getNumber());
									logWriter.info("refInfoDoc number " + refInfoDoc.getNumber());
									WTDocumentMaster refInfoDocMaster = (WTDocumentMaster) refInfoDoc.getMaster();

									WTCollection childDocMasterList = new WTArrayList();
									childDocMasterList.add(refInfoDocMaster);
									ObjectReference partRef = null;
									LOGGER.debug("latestPartIteration version "
											+ latestPartIteration.getVersionInfo().getIdentifier().getValue()
											+ " and iteration "
											+ latestPartIteration.getIterationInfo().getIdentifier().getValue());
									logWriter.info("latestPartIteration version "
											+ latestPartIteration.getVersionInfo().getIdentifier().getValue()
											+ " and iteration "
											+ latestPartIteration.getIterationInfo().getIdentifier().getValue());
									boolean partCheckedOut = WorkInProgressHelper.isCheckedOut(latestPartIteration);
									LOGGER.debug("latestPartIteration is partCheckedOut " + partCheckedOut);
									logWriter.info("latestPartIteration is partCheckedOut " + partCheckedOut);
									String checkoutStatus = findCheckoutStatus(latestPartIteration, WTPart.class);
									LOGGER.debug("latestPartIteration checkoutStatus " + checkoutStatus);
									logWriter.info("latestPartIteration checkoutStatus " + checkoutStatus);
									if (checkoutStatus.equalsIgnoreCase("c/o")
											|| checkoutStatus.equalsIgnoreCase("wrk")) {
										LOGGER.debug("parent part is checked out ");
										logWriter.info("parent part is checked out ");
										workingCopyPart = (WTPart) WorkInProgressHelper.service
												.workingCopyOf(latestPartIteration);
										partRef = ObjectReference.newObjectReference(workingCopyPart);
										logWriter.info("parent part is checked out partRef ==" + partRef);
									} else {
										LOGGER.debug("parent part is not checked out ");
										logWriter.info("parent part is not checked out ");
										partRef = ObjectReference.newObjectReference(latestPartIteration);
										logWriter.info("parent part is not checked out partRef ==" + partRef);
									}
									WTCollection configurableLinkList = ConfigurableLinkHelper.service
											.createConfigurableReferenceLink(partRef,
													KBTypeIdProvider.getType("KBREFINFOLINK"), childDocMasterList,
													true);
									docLinkExists.add(refInfoDoc.getNumber());
									LOGGER.debug("After link Attributes " + configurableLinkList.size());
									logWriter.info("After setting link Attributes " + configurableLinkList.size());
									docLinkExists.add(refInfoDocMaster.getNumber());
									LOGGER.debug("ADDED DOCUMENT " + refInfoDocMaster.getNumber() + " to list");
									Iterator vi = configurableLinkList.iterator();
									ObjectReference linkRef = (ObjectReference) vi.next();
									ConfigurableReferenceLink KBRefInfoLink = (ConfigurableReferenceLink) linkRef
											.getObject();
									LOGGER.debug("KBRefInfoLink " + KBRefInfoLink);
									logWriter.info("KBRefInfoLink " + KBRefInfoLink);
									LOGGER.debug("KB_FREE_TEXT " + yNumber);
									logWriter.info("KB_FREE_TEXT  " + yNumber);
									KBRefInfoLink = (ConfigurableReferenceLink) IBAHelper.setIba(KBRefInfoLink,
											"KB_FREE_TEXT", "");
									PersistenceServerHelper.manager.update(KBRefInfoLink);
									KBRefInfoLink = (ConfigurableReferenceLink) PersistenceHelper.manager
											.refresh(KBRefInfoLink);
									LOGGER.debug("Trying to update doc Typedesg");
									updateTypeDesignation(KBRefInfoLink, String.valueOf(yNumber));
									LOGGER.debug("After link Attributes " + configurableLinkList.size());
									logWriter.info("After setting link Attributes " + configurableLinkList.size());
								} else {

									WTPart parentPart = null;
									ConfigurableReferenceLink conRefLink = null;

									WTDocumentMaster docMaster = (WTDocumentMaster) refInfoDoc.getMaster();
									QueryResult navQr = PersistenceHelper.manager.navigate(docMaster, "referencedBy",
											ConfigurableReferenceLink.class, false);

									LOGGER.debug("QR Size : " + navQr.size());

									while (navQr.hasMoreElements()) {

										conRefLink = (ConfigurableReferenceLink) navQr.nextElement();
										parentPart = (WTPart) conRefLink.getRoleAObject();

										if (parentPart.getNumber().equals(latestPartIteration.getNumber())) {
											break;
										}
									}

									LOGGER.debug("Document Y NUMBER : " + yNumber);

									if (conRefLink != null) {
										updateTypeDesignation(conRefLink, String.valueOf(yNumber));

									}

								}

							} else {
								logWriter.info("Document with number " + RefInfo[i][1]
										+ " not found going to create Dummy part. Dummy part counter is " + counter);
								LOGGER.debug("Document with number " + RefInfo[i][1]
										+ " not found going to create Dummy part. Dummy part counter is " + counter);
								QuerySpec qsDummyPart = new QuerySpec(WTPart.class);
								String dummyPartNumber = "REF-INFO00" + counter;
								logWriter.info("Dummy part number: " + dummyPartNumber);
								LOGGER.debug("Dummy part number: " + dummyPartNumber);
								qsDummyPart.appendWhere(new SearchCondition(WTPart.class, WTPart.NUMBER,
										SearchCondition.EQUAL, dummyPartNumber, false));
								QueryResult qrDummyPart = PersistenceHelper.manager.find((StatementSpec) qsDummyPart);
								LOGGER.debug("qrchild.size(): " + qrchild.size());
								if (qrDummyPart.size() > 0) {
									WTPart dummyPart = (WTPart) qrDummyPart.nextElement();
									LOGGER.debug("dummyPart number " + dummyPart.getNumber());
									logWriter.info("dummyPart number " + dummyPart.getNumber());
									//retrieving design view part
									dummyPart = (WTPart)WebServiceHelper.getDesignViewPart((WTPart)dummyPart);
										if(dummyPart == null)
											throw new WTException("Design view Part with number "+dummyPartNumber+" not found");
									WTPartMaster dummyPartMaster = (WTPartMaster) dummyPart.getMaster();
									WTCollection dummyPartMasterList = new WTArrayList();
									dummyPartMasterList.add(dummyPartMaster);
									ObjectReference partRef = null;
									LOGGER.debug("latestPartIteration version "
											+ latestPartIteration.getVersionInfo().getIdentifier().getValue()
											+ " and iteration "
											+ latestPartIteration.getIterationInfo().getIdentifier().getValue());
									logWriter.info("latestPartIteration version "
											+ latestPartIteration.getVersionInfo().getIdentifier().getValue()
											+ " and iteration "
											+ latestPartIteration.getIterationInfo().getIdentifier().getValue());
									boolean partCheckedOut = WorkInProgressHelper.isCheckedOut(latestPartIteration);
									LOGGER.debug("latestPartIteration is partCheckedOut " + partCheckedOut);
									logWriter.info("latestPartIteration is partCheckedOut " + partCheckedOut);
									String checkoutStatus = findCheckoutStatus(latestPartIteration, WTPart.class);
									LOGGER.debug("latestPartIteration checkoutStatus " + checkoutStatus);
									logWriter.info("latestPartIteration checkoutStatus " + checkoutStatus);
									if (checkoutStatus.equalsIgnoreCase("c/o")
											|| checkoutStatus.equalsIgnoreCase("wrk")) {
										LOGGER.debug("parent part is checked out ");
										logWriter.info("parent part is checked out ");
										workingCopyPart = (WTPart) WorkInProgressHelper.service
												.workingCopyOf(latestPartIteration);
										partRef = ObjectReference.newObjectReference(workingCopyPart);
									} else {
										LOGGER.debug("parent part is not checked out ");
										logWriter.info("parent part is not checked out ");
										partRef = ObjectReference.newObjectReference(latestPartIteration);
									}
									WTCollection configurableLinkList = ConfigurableLinkHelper.service
											.createConfigurableReferenceLink(partRef,
													KBTypeIdProvider.getType("KBREFINFOLINK"), dummyPartMasterList,
													true);
									LOGGER.debug("After link Attributes " + configurableLinkList.size());
									logWriter.info("After setting link Attributes " + configurableLinkList.size());
									Iterator vi = configurableLinkList.iterator();
									ObjectReference linkRef = (ObjectReference) vi.next();
									ConfigurableReferenceLink KBRefInfoLink = (ConfigurableReferenceLink) linkRef
											.getObject();
									LOGGER.debug("KBRefInfoLink " + KBRefInfoLink);
									logWriter.info("KBRefInfoLink " + KBRefInfoLink);
									String refInfopPartNumber = RefInfo[i][1];
									LOGGER.debug("KB_FREE_TEXT " + refInfopPartNumber);
									logWriter.info("KB_FREE_TEXT  " + refInfopPartNumber);
									// Description should contain the delivered part number if the part number does not exist.
									KBRefInfoLink = (ConfigurableReferenceLink) IBAHelper.setIba(KBRefInfoLink, "KB_FREE_TEXT", refInfopPartNumber);
									PersistenceServerHelper.manager.update(KBRefInfoLink);
									if(KBRefInfoLink!=null){
										updateTypeDesignation(KBRefInfoLink, String.valueOf(yNumber));
									}
									
									KBRefInfoLink = (ConfigurableReferenceLink) PersistenceHelper.manager
											.refresh(KBRefInfoLink);
									
								}
								counter = counter + 1;
							}
						}
					}

				}
				
				String checkoutStatus = findCheckoutStatus(latestPartIteration, WTPart.class);
				LOGGER.debug("latestPartIteration checkoutStatus before checkin " + checkoutStatus);
				logWriter.info("latestPartIteration checkoutStatus before checkin " + checkoutStatus);
				if (checkoutStatus.equalsIgnoreCase("c/o") || checkoutStatus.equalsIgnoreCase("wrk")) {
					workingCopyPart = (WTPart) WorkInProgressHelper.service.workingCopyOf(latestPartIteration);
					LOGGER.debug("workingCopyPart part is " + workingCopyPart);
					logWriter.info("workingCopyPart part is " + workingCopyPart);
					if (!(workingCopyPart == null)) {
						workingCopyPart = (WTPart) WorkInProgressHelper.service.checkin(workingCopyPart,
								"Automatich Checkin after creating Ref-Info");
						LOGGER.debug("After checkin of WTPart "
								+ workingCopyPart.getVersionInfo().getIdentifier().getValue() + " and iteration "
								+ workingCopyPart.getIterationInfo().getIdentifier().getValue());
						logWriter.info("After checkin of WTPart  revision "
								+ workingCopyPart.getVersionInfo().getIdentifier().getValue() + " and iteration "
								+ workingCopyPart.getIterationInfo().getIdentifier().getValue());
					}
				}
				trx.commit();
				trx = null;
				result.add("0");
				result.add("Success");
				LOGGER.info(result);
				logWriter.info("Result of the resquest is " + result);
				return result;
			} else {
				throw new WTException("Parent Part Not found");
			}
		} catch (WTException e) {
			String message = "WTException during Ref-Info Creation exception is " + e;
			result.add("1");
			result.add(message);
			LOGGER.info(result);
			logWriter.info("Result of the resquest is " + result);
			return result;

		} catch (WTPropertyVetoException e) {
			String message = "WTException during Ref-Info Creation exception is " + e;
			result.add("1");
			result.add(message);
			LOGGER.info(result);
			logWriter.info("Result of the resquest is " + result);
			return result;
		} finally {
			LOGGER.debug("trx in finally===" + trx);
			if (trx != null) {
				trx.rollback();
			}
		}
	}

	/**
	 * deleteProcurementParts.
	 *
	 * @param WTPart
	 * @throws WTException
	 */
	private static void deleteManufacturerParts(WTPart latestPartIteration) throws WTException {
		LOGGER.debug("Inside  deleteProcurementParts ");
		WTHashSet localWTHashSet = new WTHashSet();
		AXLContext context = SumaJcaHelper
				.getDefaultSourcingContext(WTContainerHelper.service.getOrgContainer(latestPartIteration));
		WTCollection collection = AXLHelper.service.getAML(latestPartIteration, context);

		LOGGER.debug("Number of AMLs " + collection.size());

		ManufacturerPart manfPart = null;

		for (Iterator vi = collection.iterator(); vi.hasNext();) {
			AXLEntry entry = (AXLEntry) ((ObjectReference) vi.next()).getObject();

			manfPart = entry.getLatestManufacturerPart();
			String organizationUniqueIdentifier = manfPart.getOrganizationUniqueIdentifier();
			LOGGER.debug("Deleting AML for vendor id " + organizationUniqueIdentifier);
			localWTHashSet.add(entry);
		}
		AXLHelper.service.removeAXL(localWTHashSet);
		LOGGER.debug("After Deleting AML ");

	}

	public static String findCheckoutStatus(WTPart latestPartIteration, Class queriedClass)
			throws PersistenceException, QueryException, WTException {

		QuerySpec queryspec = new QuerySpec();

		int i = queryspec.addClassList(queriedClass, false);
		int partMasterIndex = queryspec.appendClassList(WTPartMaster.class, false);
		ClassAttribute checkoutStateAttribute = new ClassAttribute(queriedClass, "checkoutInfo.state");
		queryspec.appendSelect(checkoutStateAttribute, new int[] { i }, false);
		queryspec.appendWhere(new SearchCondition(WTPart.class, "masterReference.key.id", WTPartMaster.class,
				"thePersistInfo.theObjectIdentifier.id"), new int[] { i, partMasterIndex });
		queryspec.appendAnd();
		queryspec.appendWhere(new SearchCondition(WTPartMaster.class, "number", SearchCondition.EQUAL,
				latestPartIteration.getNumber()), new int[] { partMasterIndex });
		SearchCondition localSearchCondition2 = new SearchCondition(queriedClass, "versionInfo.identifier.versionId",
				SearchCondition.EQUAL, latestPartIteration.getVersionInfo().getIdentifier().getValue());
		queryspec.appendAnd();
		queryspec.appendWhere(localSearchCondition2, new int[] { i });
		SearchCondition localSearchCondition3 = new SearchCondition(queriedClass,
				"iterationInfo.identifier.iterationId", SearchCondition.EQUAL,
				latestPartIteration.getIterationInfo().getIdentifier().getValue());
		queryspec.appendAnd();
		queryspec.appendWhere(localSearchCondition3, new int[] { i });
		LOGGER.debug("SQL is " + queryspec.toString());
		QueryResult localQueryResult = PersistenceHelper.manager.find((StatementSpec) queryspec);
		LOGGER.debug("localQueryResult size is " + localQueryResult.size());
		String checkoutState = "";
		while (localQueryResult.hasMoreElements()) {
			Object[] row = (Object[]) localQueryResult.nextElement();
			checkoutState = (String) row[0];
			LOGGER.debug("checkoutState" + checkoutState);
			if (checkoutState.equalsIgnoreCase("c/o") || checkoutState.equalsIgnoreCase("wrk"))
				break;
		}
		return checkoutState;
	}

	public static void updateTypeDesignation(ConfigurableReferenceLink link, String yvalue)
			throws WTException, RemoteException, WTPropertyVetoException {
		LOGGER.debug("Inside updateTypeDesignation : " + link + " " + yvalue);
		PersistableAdapter objvp = new PersistableAdapter(link, TypeIdentifierUtility.getTypeIdentifier(link).toExternalForm(), Locale.US, null);
		String[] sValue = null;

		 //Object value = getIBAValue("KB_TYPE_DESIGNATION",link);
		Object value = IBAHelper.getIBAValue(link, "KB_TYPE_DESIGNATION");
		//Object value = AttributeService.getAttribute(link, "KB_TYPE_DESIGNATION");
		if(value!=null){
			LOGGER.debug("CLASS : "+value.getClass());
			LOGGER.debug("VALUE : "+String.valueOf(value));
		}
		
		if (value == null || value.equals("null")) {
			LOGGER.debug("Value is nulll");
			sValue = yvalue.split(",");
			LOGGER.debug("UPDATED VALUe 1 : " + sValue);

			// updateIBA("KB_TYPE_DESIGNATION",sValue,link);
			//AttributeService.setAttribute(link, "KB_TYPE_DESIGNATION", sValue);
			objvp.load("KB_TYPE_DESIGNATION");
			objvp.set("KB_TYPE_DESIGNATION", sValue);
			objvp.apply();
			IBAValueDBService ibaserv = new IBAValueDBService();
			ibaserv.updateAttributeContainer(link, ((DefaultAttributeContainer)link.getAttributeContainer()).getConstraintParameter(),null,null);

			PersistenceServerHelper.manager.update((Persistable)link);

		} else {
			String strValue = "";

			if (value instanceof String) {
				strValue = (String) value;
				sValue = strValue.split(",");
			} else {

				Object[] arrObjects = (Object[]) value;
				LOGGER.debug("Arrays are : " + Arrays.toString(arrObjects));
				String tempArray = Arrays.toString(arrObjects);
				tempArray = tempArray.substring(tempArray.indexOf("[") + 1, tempArray.indexOf("]"));
				LOGGER.debug("tempArray : " + tempArray);
				sValue = tempArray.split(",");
			}
			int currentSize = sValue.length;
			int newSize = currentSize + 1;
			String[] tempArray = new String[newSize];

			for (int i = 0; i < currentSize; i++) {
				tempArray[i] = sValue[i].trim();
				LOGGER.debug("tempArray[i] : " + tempArray[i]);
			}
			tempArray[newSize - 1] = yvalue.trim();
			sValue = tempArray;

			for (int i = 0; i < sValue.length; i++) {
				LOGGER.debug("SVALUE : " + sValue[i]);
			}
						
			//AttributeService.setAttribute(link, "KB_TYPE_DESIGNATION", sValue);
			objvp.load("KB_TYPE_DESIGNATION");
			objvp.set("KB_TYPE_DESIGNATION", sValue);
			objvp.apply();
			IBAValueDBService ibaserv = new IBAValueDBService();
			ibaserv.updateAttributeContainer(link, ((DefaultAttributeContainer)link.getAttributeContainer()).getConstraintParameter(),null,null);

			PersistenceServerHelper.manager.update((Persistable)link);
			
		}
	}

	private boolean isCorrectType(WTPart prt) {
		String parttype="";
		try {
			parttype = TypedUtilityServiceHelper.service.getTypeIdentifier(prt).getTypename();
		} catch (WTException e) {
			LOGGER.error("Failed to get part type", e);
			
		}
		LOGGER.debug("part type " + prt);
		if (parttype.contains("KBArticle")) {
			return true;
		} else {
			return false;
		}

	}
	
	private ArrayList<ConfigurableReferenceLink> getConfigurableLink(WTPart latestPartIteration, WTPart childPart,
			ArrayList<ConfigurableReferenceLink> refInfoLinks) throws WTException {
		ArrayList configurableLinkList = new ArrayList<>();
		LOGGER.debug("RefInfoLink for empty FreeText : "+refInfoLinks.size());
		if(refInfoLinks.size()>0){
			for (ConfigurableReferenceLink confLink : refInfoLinks) {
				LOGGER.debug("Conf RefInfo Link : "+confLink);
				WTPartMaster childMaster = (WTPartMaster)confLink.getRoleBObject();
				LOGGER.debug("ChildPartMaster : "+childMaster.getNumber()+" LatestPartIteration Number : "+latestPartIteration.getNumber());
				if(childMaster.getNumber().equals(latestPartIteration.getNumber())){
					configurableLinkList.add(confLink);
					
				}
			}
		}
		return configurableLinkList;
	}
	
	

}