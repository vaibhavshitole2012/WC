package ext.kb.genericInterface;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import com.ptc.jws.servlet.JaxWsWebService;
import ext.kb.genericInterface.document.DocumentObject;
import ext.kb.genericInterface.document.GenericInterfaceforDocument;


@WebService
public class GenericDocumentWebService extends JaxWsWebService {
	@WebMethod(operationName = "callDocumentOperation")
	public ArrayList<DocumentObject> callDocumentOperation(@WebParam(name = "docs") ArrayList<DocumentObject> docs) throws NoSuchMethodException, SecurityException,
			ClassNotFoundException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		ArrayList<DocumentObject> response =GenericInterfaceforDocument.performOperationonDocument(docs);		
		return response;
	}
}
