package ext.kb.ws;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.StringTokenizer;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.xml.bind.JAXBException;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import wt.configuration.TraceCode;
import wt.doc.WTDocumentMaster;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.folder.Folder;
import wt.folder.FolderEntry;
import wt.folder.FolderHelper;
import wt.iba.definition.litedefinition.AttributeDefDefaultView;
import wt.iba.definition.litedefinition.BooleanDefView;
import wt.iba.definition.litedefinition.FloatDefView;
import wt.iba.definition.litedefinition.IntegerDefView;
import wt.iba.definition.litedefinition.RatioDefView;
import wt.iba.definition.litedefinition.ReferenceDefView;
import wt.iba.definition.litedefinition.StringDefView;
import wt.iba.definition.litedefinition.TimestampDefView;
import wt.iba.definition.litedefinition.URLDefView;
import wt.iba.definition.litedefinition.UnitDefView;
import wt.iba.value.AttributeContainer;
import wt.iba.value.IBAHolder;
import wt.iba.value.IBAReferenceable;
import wt.iba.definition.AttributeDefinition;
import wt.iba.value.DefaultAttributeContainer;
import wt.iba.value.litevalue.BooleanValueDefaultView;
import wt.iba.value.litevalue.DefaultLiteIBAReferenceable;
import wt.iba.value.litevalue.FloatValueDefaultView;
import wt.iba.value.litevalue.IntegerValueDefaultView;
import wt.iba.value.litevalue.RatioValueDefaultView;
import wt.iba.value.litevalue.ReferenceValueDefaultView;
import wt.iba.value.litevalue.StringValueDefaultView;
import wt.iba.value.litevalue.TimestampValueDefaultView;
import wt.iba.value.litevalue.URLValueDefaultView;
import wt.iba.value.litevalue.UnitValueDefaultView;
import wt.iba.value.service.IBAValueDBService;
import wt.inf.container.WTContainerHelper;
import wt.inf.container.WTContainerRef;
import wt.log4j.LogR;
import wt.org.WTPrincipalReference;
import wt.part.QuantityUnit;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.pom.Transaction;
import wt.series.MultilevelSeries;
import wt.type.TypeDefinitionReference;
import wt.type.TypedUtilityServiceHelper;
import wt.util.WTException;
import wt.util.WTInvalidParameterException;
import wt.util.WTProperties;
import wt.util.WTPropertyVetoException;
import wt.vc.VersionControlHelper;
import wt.vc.VersionIdentifier;
import wt.vc.Versioned;

import com.ptc.generic.iba.IBAUtil;
import com.ptc.jws.servlet.JaxWsWebService;
import com.ptc.wpcfg.utilities.PrincipalHelper;
import com.ptc.core.lwc.server.LWCNormalizedObject;
import com.ptc.core.lwc.server.PersistableAdapter;
import com.ptc.core.meta.common.CreateOperationIdentifier;
import com.ptc.core.meta.common.FloatingPoint;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.impl.WCTypeIdentifier;

import ext.kb.service.WebServiceHelper;
import ext.kb.util.IBAHelper;
import ext.kb.util.KBConstants;
import ext.kb.util.KBUtils;
import ext.kb.util.MaterialHelper;
import ext.kb.util.NamingHelper;
import ext.tools.ToolUtils;
import wt.vc.views.View;
import wt.vc.views.ViewHelper;
import wt.vc.views.ViewReference;


@WebService()
public class KBCreatePartService extends JaxWsWebService {
	private static final Logger LOGGER = LogR.getLogger(KBCreatePartService.class.getName());
	private static final Logger logWriter = LogR.getLogger("ext.kb.ws.KBCreatePartService_Log");
	@WebMethod(operationName = "createPart")
	public List<String> createPart(
			@WebParam(name = "name") String name,
			@WebParam(name = "number") String number,
			@WebParam(name = "wtContainerPath") String wtContainerPath,
			@WebParam(name = "type") String type,
			@WebParam(name = "folderPath") String folderPath,
			@WebParam(name = "defaultTraceCode") String defaultTraceCode,
			@WebParam(name = "revisionIdentifier") String revisionIdentifier,
			@WebParam(name = "defaultUnit") String defaultUnit,
			@WebParam(name = "hidePartInStructure") String hidePartInStructure,
			@WebParam(name = "creatorName") String creatorName,
			@WebParam(name = "cadimTransferDate") String cadimTransferDate,
			@WebParam(name = "masterSystem") String masterSystem,
			@WebParam(name = "ibas") HashMap<String, String> ibas)
			throws WTException, WTPropertyVetoException, JAXBException, IOException, ParseException
	{

		Transaction trx = null;
		List<String> result = new ArrayList<String>();

	    WTProperties properties = WTProperties.getServerProperties();
		String defaultDomain = properties.getProperty("KBDefaultExternalDomain","CADIM DOMAIN");
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");

	    String commonAttributes = "collapsible|serviceable|servicekit|hidePartInStructure|defaultUnit|defaultTraceCode|containerReference|revision|state.lifeCycleId|state.state|thePersistInfo.createStamp|thePersistInfo.modifyStamp";
		
		try {

			trx = new Transaction();
			trx.start();
			LOGGER.debug("number is "+number+" and arguments is "+ibas);
			LOGGER.debug("number is "+number+" and name is "+name+" type = "+type+" wtContainerPath = "+wtContainerPath+" folderPath = "+folderPath);
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
            Date date = new Date();
            String formatedDate = sdf.format(date);
            logWriter.info("number is "+number+" and arguments is "+ibas);
			logWriter.info("number is "+number+" and name is "+name+" type = "+type+" wtContainerPath = "+wtContainerPath+" folderPath = "+folderPath);
            logWriter.info("Processing create requeston "+formatedDate+" for part where number is "+number+" and name is "+name+" type = "+type+" wtContainerPath = "+wtContainerPath+" folderPath = "+folderPath);


			WTPart part = WTPart.newWTPart();
            String MASTER_SYSTEM_IBA = "KB_MASTERSYSTEM";
			LOGGER.debug("part is "+part);
			logWriter.info("part is "+part);
			part.setName(name);
			LOGGER.debug("After name set "+part);
			logWriter.info("After name set "+part);
			part.setNumber(number);
			LOGGER.debug("After number set "+part);
			logWriter.info("After number set "+part);
			if (type == null) {
				type = WTPart.class.getName();
			}
			TypeDefinitionReference reference = TypedUtilityServiceHelper.service
					.getTypeDefinitionReference(type);
			LOGGER.debug("After TypeDefinitionReference set "+reference);
			logWriter.info("After TypeDefinitionReference set "+reference);
			part.setTypeDefinitionReference(reference);
			WTContainerRef containerReference = WTContainerHelper.service
					.getByPath(wtContainerPath);
			LOGGER.debug("After containerReference set "+containerReference);
			logWriter.info("After containerReference set "+containerReference);
			part.setContainerReference(containerReference);
			LOGGER.debug("After number set "+part);
			logWriter.info("After number set "+part);
			Folder folder = FolderHelper.service.getFolder(folderPath,
					containerReference);
			LOGGER.debug("After folder set "+folder);
			logWriter.info("After folder set "+folder);
			FolderHelper.assignLocation((FolderEntry) part, folder);
			LOGGER.debug("After assignLocation set ");
			logWriter.info("After assignLocation set ");
			part.setDefaultTraceCode(TraceCode.toTraceCode(defaultTraceCode));
			LOGGER.debug("After defaultTraceCode set ");
			part.setDefaultUnit(QuantityUnit.toQuantityUnit(defaultUnit));
			LOGGER.debug("After defaultUnit set ");
			logWriter.info("After defaultUnit set ");
			View[] views = ViewHelper.service.getAllViews();
	            for (View v : views) {
	                if ("Design".equalsIgnoreCase(v.getName())) {
	                	part.setView(ViewReference.newViewReference(v));
	                	break;
	                }
	            }
			LOGGER.debug("After view set ");
			logWriter.info("After view set ");
			part.setHidePartInStructure(Boolean.valueOf(hidePartInStructure));
			LOGGER.debug("After hidePartInStructure set ");
			logWriter.info("After hidePartInStructure set ");
			part.getMaster().setSeries("wt.series.HarvardSeries.KB_Revision");
			MultilevelSeries multilevelseries = MultilevelSeries.newMultilevelSeries("wt.series.HarvardSeries.KB_Revision", revisionIdentifier);
			LOGGER.debug("multilevelseries "+multilevelseries);
			logWriter.info("multilevelseries "+multilevelseries);
			VersionIdentifier versionidentifier = VersionIdentifier.newVersionIdentifier(multilevelseries);
			LOGGER.debug("versionidentifier "+versionidentifier.getValue());
			logWriter.info("versionidentifier "+versionidentifier.getValue());
			VersionControlHelper.setVersionIdentifier(part, versionidentifier);
			LOGGER.debug("After setting version");
			logWriter.info("After seting version ");
	        			
			LOGGER.debug("Created by =="+creatorName);
			logWriter.info("Created by =="+creatorName);
			if(creatorName != null){
				WTPrincipalReference principalReference = PrincipalHelper.getPrincipal(creatorName);
				if(principalReference != null){
				VersionControlHelper.assignIterationCreator(part, principalReference);
				VersionControlHelper.setIterationModifier(part, principalReference);
				}else{
					WTPrincipalReference principalReference1 = PrincipalHelper.getPrincipal("INTERFACE_SAP");
					VersionControlHelper.assignIterationCreator(part, principalReference1);
					VersionControlHelper.setIterationModifier(part, principalReference1);
				}
				}
			
			TypeIdentifier targetType = wt.type.TypedUtilityServiceHelper.service.getTypeIdentifier(part);
			PersistableAdapter persistanceAdapter = new PersistableAdapter((Persistable) part,
					((WCTypeIdentifier) targetType).getLeafName(), null, null);
			
			part = (WTPart)IBAHelper.setIba(part, "KB_CADIM_TRANSFER_DATE", new Timestamp(dateFormat.parse(cadimTransferDate).getTime()));
			persistanceAdapter.load(ibas.keySet());
			
			// to get translation ID from ibas
			String translationID = "";
			String namingPartValue = "";
			if (ibas.keySet().contains(KBConstants.TRANSLATION_ID_IBA)) {
				translationID = ibas.get(KBConstants.TRANSLATION_ID_IBA);
				// Getting Description 1 EN value using NamingEntry and translation ID
				if (translationID != null && !translationID.equalsIgnoreCase("")) {
					LOGGER.debug("translationID has been obtained. Translation ID is :" + translationID);
					WTPart namingPart = NamingHelper.getNamingEntryByNumber(translationID);
					LOGGER.debug("Naming catalog part obtained is :" + namingPart);
					if (namingPart != null) {
						namingPartValue = namingPart.getName();
						LOGGER.debug("Naming catalog part name is :" + namingPartValue);
					}
				}
			}
			LOGGER.debug("TranslationID is : " + translationID);
			
			for (Entry<String, String> attEntry : ibas.entrySet()) {
				AttributeDefDefaultView attributeDefinition = IBAHelper.getAttributeDefDefaultView(attEntry.getKey());
				LOGGER.debug("Attribute Definition =="+ attributeDefinition);
				logWriter.info("Attribute Definition =="+ attributeDefinition);
				LOGGER.debug("Attribute name is"+ attEntry.getKey());
				logWriter.info("Attribute name is"+ attEntry.getKey());
				
				// setting description 1 EN from translation ID - start
				if (KBConstants.DESCRIPTION_EN.equalsIgnoreCase(attEntry.getKey())) {
					attEntry.setValue(namingPartValue);
					LOGGER.debug("Setting attribute KB_DESCRIPTION_EN value as : " + namingPartValue);
				}
				
				if(attEntry.getValue() != null && !attEntry.getValue().equals(""))
				{
				
				LOGGER.debug(" Attribute Value is not null it is "+attEntry.getValue());
				logWriter.info(" Attribute Value is not null it is "+attEntry.getValue());
				
				if (KBConstants.KBMATERIAL_IBA.equalsIgnoreCase(attEntry.getKey())) {
					LOGGER.debug("Updating KB_MATERIAL");
					String value = KBUtils.convertMaterialNameNumber(part, attEntry.getValue());
					LOGGER.debug("VALUE :::::::::: " + value);
					if (StringUtils.isEmpty(value)){
						value = MaterialHelper.queryMaterialNumberByName(attEntry.getValue());
					}

					AttributeDefDefaultView attributeDefDefaultView = IBAHelper
							.getAttributeDefDefaultView(attEntry.getKey());
					Object attrValue = WebServiceHelper.parseAttributeValue(attributeDefDefaultView, value);
					LOGGER.debug("Attribute name is" + attEntry.getKey() + " Attribute Value is " + attrValue);
					if (!commonAttributes.contains(attEntry.getKey())) {
						LOGGER.debug("Attribute name isnot contained in common attributes");
						logWriter.info(
								"Attribute name is" + attEntry.getKey() + " Attribute Value is " + attrValue);
						persistanceAdapter.set(attEntry.getKey(), attrValue);
					}
				}else{
					AttributeDefDefaultView attributeDefDefaultView = IBAHelper.getAttributeDefDefaultView(attEntry.getKey());
					Object attrValue = parseAttributeValue(attributeDefDefaultView,attEntry.getValue());
					LOGGER.debug("Attribute name is"+ attEntry.getKey()+" Attribute Value is "+attrValue);
					logWriter.info("Attribute name is"+ attEntry.getKey()+" Attribute Value is "+attrValue);
					//persistanceAdapter.set(attEntry.getKey(), attEntry.getValue());
					if(!commonAttributes.contains(attEntry.getKey()))
					{
						LOGGER.debug("Attribute name isnot contained in common attributes");
						logWriter.info("Attribute name isnot contained in common attributes");
						persistanceAdapter.set(attEntry.getKey(), attrValue);
					}
				}
				
				}
			}
			persistanceAdapter.apply();
			            
            part = (WTPart) PersistenceHelper.manager.store(part);
			LOGGER.debug("After creating part "+part.getVersionIdentifier().getSeries());
			logWriter.info("After creating part "+part.getVersionIdentifier().getSeries());

			WTPartMaster master = (WTPartMaster) part.getMaster();
			master = (WTPartMaster)IBAHelper.setIba(master, MASTER_SYSTEM_IBA, masterSystem);
			//PersistenceServerHelper.manager.update(master);			
			LOGGER.debug("After setting master system");
			logWriter.info("After setting master system");
			
			 LOGGER.debug("containerName name ==="+ part.getContainerName());
			 logWriter.info("containerName name ==="+ part.getContainerName());
	         LOGGER.debug( " part domain before \"" + part.getDomainRef().getName() + "\" domain");
	         logWriter.info( " part domain before \"" + part.getDomainRef().getName() + "\" domain");
	         //WebServiceHelper.setCadimDomain(part, defaultDomain, part.getContainerName());
	         LOGGER.debug( " part domain After \"" + part.getDomainRef().getName() + "\" domain");
	         logWriter.info( " part domain After \"" + part.getDomainRef().getName() + "\" domain");
            
            logWriter.info("trx==="+trx );
			LOGGER.debug("trx== "+trx);
			trx.commit();
            trx = null;
            result.add("ReturnCode: 0");
            result.add("Text: Success");
            logWriter.info("result from the service is "+result);
			return result;
		} catch (WTException e) {
			String message = "WTException during part creation exception is "
					+ e;
			result.add("ReturnCode: 1");
            result.add("Text: "+message);
			//return message;
            logWriter.info("result from the service is "+result);
            return result;

		} catch (WTPropertyVetoException e) {
			String message = "WTPropertyVetoException during part creation exception is "
					+ e;
			result.add("ReturnCode: 1");
            result.add("Text: "+message);
			//return message;
            logWriter.info("result from the service is "+result);
            return result;
		}
		catch (IOException e) {
			String message = "IOException during log file creation exception is "
					+ e;
			result.add("ReturnCode: 1");
            result.add("Text: "+message);
			//return message;
            logWriter.info("result from the service is "+result);
            return result;
		}
		catch (ParseException e) {
			String message = "ParseException during log file creation exception is "
					+ e;
			result.add("ReturnCode: 1");
            result.add("Text: "+message);
			//return message;
            logWriter.info("result from the service is "+result);
            return result;
		}
		catch(WTInvalidParameterException e){
			String message = "WTInvalidParameterException during part creation exception is "
					+ e;
			result.add("ReturnCode: 1");
            result.add("Text: "+message);
			//return message;
            logWriter.info("result from the service is "+result);
            return result;
			}finally {
			System.out.println("trx in finally===" + trx);
			if (trx != null) {
				trx.rollback();
			}
		}
	}
	
	public static Object parseAttributeValue(AttributeDefDefaultView def, String value) throws ParseException, WTException, WTPropertyVetoException
	{
		Object obj = null;
		Object returnValue = null;
		 DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		try{
		if(def instanceof StringDefView)
		{
		   obj = new StringValueDefaultView((StringDefView) def, value);
		    returnValue = ((StringValueDefaultView)obj).getValueAsString();
		}
		else if(def instanceof TimestampDefView)
		{
		   obj = new TimestampValueDefaultView((TimestampDefView) def, new Timestamp(dateFormat.parse(value).getTime()));
		   //returnValue = ((TimestampValueDefaultView)obj).getValueAsString();
		   returnValue = ((TimestampValueDefaultView)obj).getValue();
		}
		else if(def instanceof BooleanDefView)
		{
		   obj = new BooleanValueDefaultView((BooleanDefView) def, Boolean.valueOf(value).booleanValue());
		   String returnVal = ((BooleanValueDefaultView)obj).getValueAsString();
		   returnValue = Boolean.valueOf(returnVal);
		}
		else if(def instanceof FloatDefView)
		{
		   obj = new FloatValueDefaultView((FloatDefView) def, Double.parseDouble(value), 6);
		   Double returnVal = ((FloatValueDefaultView)obj).getValue();
		   returnValue = FloatingPoint.valueOf(returnVal.toString());
		}
		else if(def instanceof IntegerDefView)
		{
		   obj = new IntegerValueDefaultView((IntegerDefView) def, Integer.parseInt(value));
		    String returnVal = ((IntegerValueDefaultView)obj).getValueAsString();
		    returnValue = Long.valueOf(returnVal);
		}
		/*else if(def instanceof RatioDefView) {
		   StringTokenizer st = new StringTokenizer(value,":");
		   obj = new RatioValueDefaultView((RatioDefView) def, Double.parseDouble(st.nextToken()), Double.parseDouble(st.nextToken()));
		}
		else if(def instanceof ReferenceDefView){ // never had this set from custom code ... 
		   // throw new WTException("ERROR: cannot set Reference IBA");
	         obj=new ReferenceValueDefaultView((ReferenceDefView)def);
		   Object obj1=ToolUtils.objFromObid(value);
		   if(obj1 instanceof IBAReferenceable)
			((ReferenceValueDefaultView)obj).setLiteIBAReferenceable(new DefaultLiteIBAReferenceable(0, ((Persistable)obj1).getPersistInfo().getObjectIdentifier(), "hallo hier"));
		   else
		      throw new WTException("obj "+value+" must be a IBAReferenceable");
		}
		else if(def instanceof UnitDefView) 
		   obj = new UnitValueDefaultView((UnitDefView) def, Double.parseDouble(value), 6);
		else if(def instanceof URLDefView)
		   obj = new URLValueDefaultView((URLDefView) def, value, null);*/
		return returnValue;
		}
		catch(WTException err){
		   err.printStackTrace();
		   throw err;
		}
		catch(ParseException err){
			   err.printStackTrace();
			   throw err;
			}
		
		
	}
}
