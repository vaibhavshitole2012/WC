package com.ptc.ssp.log4jconfig;

import java.rmi.RemoteException;

import org.apache.log4j.Level;

import wt.cache.CacheManager;
import wt.method.*;


public class Log4jSynchronizer extends CacheManager implements RemoteAccess {

	private static Log4jSynchronizer instance = null;
	
	public Log4jSynchronizer() throws RemoteException {
		super();
		System.out.println("Log4jSynchronizer instanciated");
	}
	
	public static Log4jSynchronizer getLog4jCache() throws Exception {
		if(instance==null) {
				instance=new Log4jSynchronizer();
		}
		
		if(instance==null) {
			throw new Exception("could not instanciate an instance of Log4jSynchronizer");
		}
		return instance;
	}
	
	public void synchronizeLoglevel(String loggername, String levelName) throws Exception {
		//we use the remove method for synchronization because that one is forwarded to 
		//the master (ServerManger) and all slaves (other MethodServers)
		String key = loggername + "|" + levelName;
		this.remove(key);
	}
	
	//just for testing the mechanism
	//this method is the only reason that Log4jSynchronizer needs to implement RemoteAccess
	public static void testCache() throws Exception {
		try {
		System.out.println("HERE we should be inside MS");
		Log4jSynchronizer lc = Log4jSynchronizer.getLog4jCache();
		System.out.println("lc=" + lc);
		lc.put("key1", "value1");
		lc.putEntry("key2", "value2 Entry");
		System.out.println("get(key1)=" + lc.get("key1"));
		System.out.println("getEntry(key1)=" + lc.getEntry("key1"));
		System.out.println("get(key2)=" + lc.get("key2"));
		System.out.println("getEntry(key2)=" + lc.getEntry("key2"));
		lc.remove("key1");
		
		//lc.up
		//TODO what does update do?
		//lc.update(obj1, obj2, obj3);
		} catch(Exception e) {
			e.printStackTrace();
			throw(e);
		}
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
    		RemoteMethodServer rms = RemoteMethodServer.getDefault();
    		rms.invoke("testCache", "com.ptc.ssp.log4jconfig.Log4jSynchronizer", null, (Class[])null, (Object[])null);
		} catch(Exception e) {
			e.printStackTrace();
			System.exit(1);
		}
		System.out.println("ready");
		System.exit(0);
	}

	//for debugging
//   public void remove(Object obj) {
//   	super.remove(obj);
//   	System.out.println("END remove(O)" + obj);
//   }
//   protected void remove(Object obj, int i) {
//   	super.remove(obj, i);
//   	System.out.println("END remove(O,i)" + obj + " " + i);
//   }
   protected void removeEntry(Object obj) {
   	super.removeEntry(obj);
   	
   	//split given String into logger's name and logger's level
		//this is how the key is constructed in the calling methods
		//String key = loggername + "|" + levelName;
   	if(obj instanceof String) {
   		String key = (String)obj;
   		int i = key.indexOf("|");
   		if(i>=0) {
   			String loggername = key.substring(0, i);
   			String levelName = key.substring(i+1);
   			try {
   				Log4jHelper.setLevel(false, false, loggername, levelName); //need to use 'false': we want to execute this in exactly the JVM we are currently in 
   			} catch(Exception e) {
   				e.printStackTrace();
   			}
   		}
   	}
   	//else: ignore
   }
//   public void removeEntry(Object obj, int i) {
//   	super.removeEntry(obj, i);
//   	System.out.println("END removeEntry(O,i)" + obj + " " + i);
//   }
}
