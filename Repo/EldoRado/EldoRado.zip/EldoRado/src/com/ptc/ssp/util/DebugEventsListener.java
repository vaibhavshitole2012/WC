package com.ptc.ssp.util;


import java.io.*;
import java.util.*;

import org.apache.log4j.Logger;

import wt.events.*;
import wt.services.*;
import wt.util.*;


public class DebugEventsListener extends StandardManager {

   /**
	 * 
	 */
	private static final long serialVersionUID = -700706305866014292L;
   private static final String CLASSNAME = DebugEventsListener.class.getName();
   private static final Logger logger = Logger.getLogger(CLASSNAME);
   private static String propsPath = null;
   private static Properties props = new Properties();
   private static Map<String, Map<String, Logger>> mLoggers = null; //key=EventName+";"+classname (e.g. "*/wt.fc.PersistenceManagerEvent/PRE_STORE;wt.part.WTPart")
                                       //value=the logger for this event
   
   
   
   static {
   	try {
   	   propsPath = WTProperties.getLocalProperties().getProperty ("wt.home") + "/codebase/com/ptc/ssp/util/DebugEventsListener.properties";
   	   File f = new File(propsPath);
   	   props.load(new FileInputStream(f));
   	   mLoggers = new HashMap<String, Map<String, Logger>>();
   	   System.out.println("DebugEventsListener END OF STATIC");
   	} catch(Throwable throwable) {
            throwable.printStackTrace(System.err);
         	logger.error("Could not initialize properties! propsPath=" + propsPath);
     }
  }
   
   public String getConceptualClassname() {
      return CLASSNAME;
   }
   
   public static DebugEventsListener newDebugEventsListener() throws WTException {
   	DebugEventsListener instance = new DebugEventsListener();
		//instance.initialize();
		return instance;
	}
   
   protected synchronized void performStartupProcess() throws ManagerException {
      super.performStartupProcess();
      
      //create a listener for all events
      KeyedEventListener listener = new InnerListener(CLASSNAME);

      //read props:
      if(mLoggers==null) {
      	logger.error("Could not initialize mLoggers map!");
      }
      Enumeration<Object> eKeys = props.keys();
      while(eKeys.hasMoreElements()) {
      	String eventString = (String)eKeys.nextElement();
      	String eventClasses = props.getProperty(eventString);
      	logger.debug("eventString=" + eventString + " eventClasses=" + eventClasses);
      	try {
      		getManagerService().addEventListener(listener, eventString);
      	} catch(Exception w) {
      		logger.error("could not add event listener: eventString=" + eventString);
      	}
      	StringTokenizer st = new StringTokenizer(eventClasses, ",");
      	while(st.hasMoreElements()) {
      		String cn = st.nextToken();
      		Logger l = Logger.getLogger(CLASSNAME + "_" + eventString + "_" + cn);
      		Map<String, Logger> mInternal = mLoggers.get(eventString);
      		if(mInternal==null) {
      			mInternal = new HashMap<String, Logger>();
      		}
      		mInternal.put(cn, l);
      		mLoggers.put(eventString, mInternal);
      	}
      }//end while
      //getManagerService().printAllEventBranches();
      System.out.println("mLoggers=" + mLoggers);
      System.out.println("STARTED LISTENER: " + CLASSNAME);
	}


   class InnerListener extends ServiceEventListenerAdapter {
	   public InnerListener(String managerName) {
		   super(managerName);
	   }

	   public void notifyEvent(Object obj) {
		   try {
			   logEvent(obj, "event");
		   } catch(WTException e) {
			   e.printStackTrace();
		   }
	   }

	   public void notifyVetoableEvent(Object obj) throws WTException {
		   logEvent(obj, "vetoable event");
	   }
	   
	   private void logEvent(Object obj, String type) throws WTException {
		   if (!(obj instanceof KeyedEvent)) {
			   return;
		   }

		   KeyedEvent keyedEvent = (KeyedEvent) obj;
		   String eventKey = keyedEvent.getEventKey();
		   Object target = keyedEvent.getEventTarget();
		   boolean eventWasLogged = false;
		   if(logger.isDebugEnabled()) {
			   logger.debug(type + ": " + eventKey + " for: " + target);
			   eventWasLogged = true;
		   }
		   Map<String, Logger> mInternal = mLoggers.get(eventKey);
		   if(mInternal!=null) {
			   //logger.debug("found internal logMap for eventKey=" + eventKey);
			   Logger l = mInternal.get(target.getClass().getName()); 
			   if(l!=null) {
				   if(!eventWasLogged) {
					   l.warn(type + ": " + eventKey + " for: " + target);
				   }
				   if(l.isDebugEnabled()) {
					   (new Exception("who called " + eventKey + " for " + target + "?")).printStackTrace();
				   }
			   } else {
				   //System.out.println("no logger for: " + target.getClass().getName());
			   }
		   }
	   }
   }
}

