package com.ptc.ssp.log4jconfig.swing;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.*;
import javax.swing.table.TableColumn;
import javax.swing.table.TableModel;

import org.apache.log4j.Level;

public class Log4jConfigFrame extends JFrame {
	private JPanel		mainPanel;
	private JTextField 	filterValueField;
	private JTable		table;
	private JScrollPane scrollPane;

	private Log4jConfigTableModel tableModel;

	public Log4jConfigFrame() {
		// Set the frame characteristics
		setTitle("Entwicklertool: Log4j configurator");
		setSize(750, 400);
//		setBackground( Color.gray );

		// Create a panel to hold all other components
		mainPanel = new JPanel();
		mainPanel.setLayout( new BorderLayout() ); getContentPane().add( mainPanel );

		// Create the filter value entry field
		filterValueField = new JTextField();
		filterValueField.setText("");
		filterValueField.addKeyListener(new KeyListener() {
			public void keyTyped(KeyEvent e) {}
			public void keyReleased(KeyEvent e) {doFilterList();}
			public void keyPressed(KeyEvent e) {}
		});

		mainPanel.add(filterValueField, BorderLayout.NORTH);

		// Create tableModel
		tableModel = Log4jConfigTableModel.newLog4jConfigTableModel();

		// Create a new table instance
		table = new Log4jJTable(tableModel);
		table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

		//set comboBox for column with Levels
		JComboBox cb = new JComboBox();
		String[] allLevels = tableModel.getPossibleLevels();
		for(int i=0, n=allLevels.length; i<n; i++) {
			cb.addItem(allLevels[i]);
		}
		TableColumn tcName = table.getColumnModel().getColumn(0);
		TableColumn tcLevel = table.getColumnModel().getColumn(1);
		tcLevel.setCellEditor(new DefaultCellEditor(cb));

		//configure column size
		tcName.setPreferredWidth(600);
		tcLevel.setPreferredWidth(80);


		// Configure some of JTable's paramters
//		table.setShowHorizontalLines( false );
//		table.setRowSelectionAllowed( true );
//		table.setColumnSelectionAllowed( true );

		// Change the selection colour
//		table.setSelectionForeground( Color.white );
//		table.setSelectionBackground( Color.red );

		// Add the table to a scrolling pane
		scrollPane = new JScrollPane(table);
		scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		mainPanel.add( scrollPane, BorderLayout.CENTER );

		getContentPane().add(mainPanel);

		//this.setDefaultCloseOperation(EXIT_ON_CLOSE);
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Log4jConfigFrame frame = new Log4jConfigFrame();
		frame.setVisible(true);
	}

	private void doFilterList() {
		tableModel.filterRows(filterValueField.getText());
		tableModel.fireTableDataChanged();
	}

}
