package com.ptc.ssp.util;

import com.infoengine.object.factory.Att;
import com.infoengine.object.factory.Element;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.impl.TypeIdentifierHelperImplementation;
import com.ptc.core.meta.descriptor.common.DefinitionDescriptor;
import com.ptc.core.meta.descriptor.common.DefinitionDescriptorFactory;
import com.ptc.core.meta.type.mgmt.server.impl.WTTypeDefinition;
import com.ptc.core.meta.type.runtime.server.TypeModel;
import com.ptc.core.rule.server.delegate.init.TypeHelper;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;
import org.apache.log4j.Logger;
import wt.enterprise.BasicTemplateProcessor;
import wt.fc.*;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.services.applicationcontext.implementation.DefaultServiceProvider;
import wt.type.TypeDefinitionReference;
import wt.type.Typed;
import wt.type.TypedUtility;
import wt.type.TypedUtilityServiceHelper;
import wt.util.WTContext;
import wt.util.WTException;
import wt.vc.VersionControlHelper;

/**
 * This class contains utility methods around softtypes
 *
 * @author Logemann
 * @author lberger@ptc.com
 */
public class SoftTypeHelper implements RemoteAccess {
    
    private static final String CLASSNAME = SoftTypeHelper.class.getName();
    private static final Logger logger = Logger.getLogger(CLASSNAME);
    
    private static TypeIdentifierHelperImplementation tiHelper;  
    
    //contains softtype names
    //value is the long name that is machine dependent
    //  (e.g. 'wt.part.WTPart|com.ptc.ptcnet.lberger_pdm80.pdm80_ToplevelOrg.Verwendung')
    private static Map<String, String> mTypeNames = null; //key is the short name (e.g. 'Verwendung')
    
    private static Map<String, String> mTypeIds = null; //key is id, value is short name (used for icons)
    
    //the starting points below we try to find our custom softtypes
    private static final String[] startPoints = {
    	"wt.part.WTPart", 
    	"wt.doc.WTDocument", 
    	"wt.part.WTPartUsageLink", 
    	"wt.change2.WTChangeOrder2", 
    	"wt.change2.WTChangeActivity2", 
    	"com.ptc.projectmanagement.plan.PlanActivity" //added for ECA5.0 P1-2015 CR_2013_113
    };
    
    
    
    /** Creates a new instance of HLOTypeUtils */
    public SoftTypeHelper() {
    }
    
    public static TypeIdentifierHelperImplementation getTIHelperInstance() {
   	 if(tiHelper==null) {
   		 tiHelper = new TypeIdentifierHelperImplementation();
   	 }
   	 return tiHelper;
    }
    
    /**
     *  It gets a Vector of siblings of a soft type passed as a parameter (typeName).
     *  In the result vector, each siblings name is a Element type, which contain
     *  "typename" Attribute and optionaly "selected" Attribute.
     *  @param typeName Name of a soft type to return it's siblings and children
     *  @return Vector names (string) of children soft types
     *  @throws WTException 
     * @author Logemann
     */
    static public Vector<Element> getSoftTypeSiblings(String typeName) throws WTException {
        Vector<Element> v = new Vector<Element>();
        DefinitionDescriptorFactory fac = (DefinitionDescriptorFactory) DefaultServiceProvider.getService(DefinitionDescriptorFactory.class, "default");
        
        /** is needed to browse through all types */
        TypeModel typemodel = (TypeModel)DefaultServiceProvider.getService(com.ptc.core.meta.type.runtime.server.TypeModel.class, null);
        
        if (typeName != null && typeName.length() > 0) {
            TypeIdentifier ident = TypeHelper.getTypeId(typeName);
            /* get Parent identifier */
            //TypeIdentifier parent_identifier = ident;
            TypeIdentifier parent_identifier = typemodel.getParent(ident);
            
            /* get all children from parent */
            TypeIdentifier[] siblings_identifiers = typemodel.getChildren(parent_identifier);
            
            if (logger.isDebugEnabled()) {
                logger.debug("getSoftTypeSiblings--> typeName              " + typeName);
                logger.debug("getSoftTypeSiblings--> TypeIdentifier        " + ident.toString());
                logger.debug("getSoftTypeSiblings--> parent TypeIdentifier " + parent_identifier.toString());
            }
            /* for all siblings */
            for (int x=0; x<=siblings_identifiers.length-1; x++) {
                TypeIdentifier child_identifier = siblings_identifiers[x];
                if (logger.isDebugEnabled()) {
                    logger.debug("getSoftTypeSiblings--> sibling TypeIdentifier "+child_identifier.toString());
                }
                
                DefinitionDescriptor descriptor = fac.get(child_identifier);
                String value = descriptor.getLongDescription();
                Element e = new Element();
                e.addAtt(new Att("typename", value));
                if (child_identifier.isEquivalentTypeIdentifier(ident)) {
                    e.addAtt(new Att("selected", "selected"));
                }
                v.add(e);
            }
        }
        
        return v;
    }
    
    /**
     * get full Softtype name from short name.
     * Should be used to avoid machine dependent code when trying to access a certain Softtype
     * To fill the list of available names we navigate the type model from a few starting points down, otherwise it would contain all classes below WTObject
     * @param shortName last word in the Softtype full name, e.g. 'Verwendung'
     * @return longName the full name of the Softtype, e.g. 'wt.part.WTPart|com.ptc.ptcnet.lberger_pdm80.pdm80_ToplevelOrg.Verwendung'
     * @throws WTException
     * @author lberger@ptc.com
     */
    public static String getFullTypeName(String shortName) throws WTException {
   	 try {
   		if(RemoteMethodServer.ServerFlag) {
   			return _getFullTypeName(shortName);
                } else {
   			//we're on client side. Check if we have the name inside cache first before trying to retrieve it from server
   			String fullTN = null;
   			if(mTypeNames!=null) {
   				fullTN = mTypeNames.get(shortName);
   				logger.debug("SoftTypeHelper.CLIENT: fullTN=" + fullTN);
   			} else {
   				mTypeNames = new HashMap<String, String>();
   			}
   			if(fullTN==null) {
   				fullTN = (String)RemoteMethodServer.getDefault().invoke("_getFullTypeName", "com.ptc.ssp.util.SoftTypeHelper", null, new Class[] { java.lang.String.class }, new Object[] { shortName });
   				mTypeNames.put(shortName, fullTN);
   				logger.warn("SoftTypeHelper.CLIENT: didn't find entry for shortN=" + shortName + ". retrieved it from server. now mTypeNames=" + mTypeNames);
   			}
   			return fullTN;
   		}
   	 } catch(Exception e) {
   		 if(e instanceof WTException) {
   			 throw (WTException) e;
   		 } else {
   			 throw new WTException(e);
   		 }
   	 }
    }
    
    public static String _getFullTypeName(String shortName) throws WTException {
        logger.debug("params: shortName=" + shortName);
        if(mTypeNames==null) {
            //create and fill hash
            mTypeNames = new HashMap<String, String>();
            SoftTypeHelper.fillTypeNames();
            logger.debug("initial fill of mTypeNames was done");
        }
        
        //here we can assume that the tree was once navigated completely
        //maybe the softtype was added after we initially filled the mTypeNames
        if(!mTypeNames.containsKey(shortName)) {
            logger.debug("not found, trying to refill mTypeNames (maybe SoftType was added after MS start");
            SoftTypeHelper.fillTypeNames();
            logger.debug("refilled mTypeNames");
        }
        
        //if we still don't find the name, let's check if the given name was already a full name
        if(mTypeNames.containsValue(shortName)) {
      	  return shortName;
        }
        //now it's really missing
        if(!mTypeNames.containsKey(shortName)) {
            throw new WTException("no Softtype found that ends with '" + shortName + "'");
        }
        logger.debug("found: " + mTypeNames.get(shortName) + " class=" + mTypeNames.get(shortName).getClass().getName());
        
        return mTypeNames.get(shortName);
    }
    
    public static String getWTClassname(String fullTypeName) throws WTException {
   	 int i = fullTypeName.indexOf("|");
   	 if(i<0) {
   		 throw new WTException("could not find '|' inside fullTypeName=" + fullTypeName);
   	 }
   	 return fullTypeName.substring(0, i);
    }
    
    public static String getIconString(Object id) throws WTException {
   	 logger.debug("params: id=" + id + " class=" + id.getClass().getName());
   	 if(mTypeIds==null) {
   		 mTypeIds = new HashMap<String, String>();
   		 SoftTypeHelper.fillTypeNames();
   	 }

   	 //here we can assume that the tree was once navigated completely
       //maybe the softtype was added after we initially filled the mTypeNames
   	 if(!mTypeIds.containsKey(id.toString())) {
   		 SoftTypeHelper.fillTypeNames();
   	 }
   	 
   	 if(!mTypeIds.containsKey(id.toString())) {
   		 throw new WTException("no Softtype shortname found for id=" + id);
   	 }
   	 
   	 return mTypeIds.get(id.toString());
    }
    
    /**
     *
     * @param obj 
     * @param object
     * @return the full typename, e.g. wt.part.WTPart|de.volkswagen.Baustufe
     */
    public static String getTypeName(Object obj){
        if (obj == null) {
            return "";
        }
        
        String typeName = null;
        
            if( obj instanceof wt.type.Typed ){
            	//8.0:
                //typeName = com.ptc.core.meta.common.TypeIdentifierUtilityHelper.service.getTypeIdentifier((wt.type.Typed)obj).getTypename();
                //9.1:
                typeName = getTIHelperInstance().getType((Typed)obj).getTypename();
            } else{
                return obj.getClass().getName();
            }
        logger.debug("typeName2="+typeName);
        return typeName;
    }
    
    /**
     * 
     * @param obj
     * @return the last section of the type name, e.g. 'Baustufe'
     */
    public static String getShortTypeName(Object obj) {
    	String longTypeName = getTypeName(obj);
    	String shortTypeName = longTypeName; //default in case it doesn't have a '.'
    	int iDot = longTypeName.lastIndexOf('.');
    	if(iDot!=-1) {
    		shortTypeName = longTypeName.substring(iDot+1);
    	}
    	return shortTypeName;
    }
    
    
    /**
     * Can be used to replace instanceof statements
     * Old code: if( object instanceof PIC ) ...
     * New code: if( SoftTypeHelper.isType(object, "MyShortSofttypeName") ) ...
     *
     * @param object
     * @param type 
     * @return
     */
    static public boolean isType(Object object, String type){
        if( object == null ) {
            return false;
        }
        if( !(object instanceof wt.type.Typed) ) {
            return false;
        }
        
        //lberger 20100616: old code was not correct if the objects is of any SUB-softtype of the given one
        //  we need to look at the full blown softtype name
        //TODO ECA 4.0: re-use WCOM library once we have it for performance reasons
        //String typeName = SoftTypeHelper.getTypeName(object);
        String typeName = null;
        try {
      	  typeName = TypedUtilityServiceHelper.service.getExternalTypeIdentifier((Typed)object);
        } catch(Exception re) {
      	  //lberger 20100616: I don't like not to throw such an exception, but we would need to change many calling classes otherwise
      	  logger.error(re.getLocalizedMessage(), re);
      	  return false;
        }
        
        if( typeName!=null && typeName.indexOf(type) >= 0 ) {
            return true;
        } else {
            return false;
        }
    }
    
    
    /////////////////////////////////////////////////////////////////////////////////
    // private methods
    /////////////////////////////////////////////////////////////////////////////////
    
    private static void fillTypeNames() throws WTException {
   	 if(mTypeNames==null) {
   		 mTypeNames = new HashMap<String, String>();
   	 }
   	 if(mTypeIds==null) {
   		 mTypeIds = new HashMap<String, String>();
   	 }
        for(int i=0; i<startPoints.length; i++) {
            TypeIdentifier idStartPoint = TypeHelper.getTypeId(startPoints[i]);
            SoftTypeHelper.fillTypeNamesInternal(idStartPoint);
        }
        SoftTypeHelper.fillTypeIds();
        //old code just for reference how to get parents:
//       TypeIdentifier idParent = typemodel.getParent(idWTPart);
//       if(logger.isDebugEnabled()) {
//      	 logger.debug("idWTPart=" + idWTPart);
//      	 logger.debug("idParent=" + idParent);
//       }
//       //can we get another parent?
//       TypeIdentifier idParent2 = typemodel.getParent(idParent);
//       if(logger.isDebugEnabled()) {
//      	 logger.debug("idParent2=" + idParent2);
//       }
//       if(idParent2!=null) {
//      	 SoftTypeHelper.fillTypeNamesInternal(idParent2);
//       } else {
//      	 SoftTypeHelper.fillTypeNamesInternal(idParent);
//       }
    }
    
    private static void fillTypeNamesInternal(TypeIdentifier tiActualNode) throws WTException {
        TypeModel typemodel = (TypeModel)DefaultServiceProvider.getService(com.ptc.core.meta.type.runtime.server.TypeModel.class, null);
        
        if( tiActualNode == null ) {
            return;
        }
        
        logger.debug("start, type-id="+tiActualNode.toExternalForm());
        
        TypeIdentifier[] children = typemodel.getChildren(tiActualNode);
        String childName = null;
        if( children == null ) {
            logger.debug("no children");
        } else {
            logger.debug("child#="+children.length);
        }
        
        if( children != null ){
            for (int i=0; i<children.length; i++) {
                childName = children[i].getTypename();
                logger.debug("child.typname: " + childName);
                String lastName = childName.substring(childName.lastIndexOf(".")+1);
                logger.debug("lastName=" + lastName);
                mTypeNames.put(lastName, childName);
                //now recurse into substructure
                SoftTypeHelper.fillTypeNamesInternal(children[i]);
            }
        }
    }
    
    private static void fillTypeIds() throws WTException {
   	 QuerySpec qs = new QuerySpec(WTTypeDefinition.class);
   	 qs.appendWhere(VersionControlHelper.getSearchCondition(WTTypeDefinition.class, true));
   	 QueryResult qr = PersistenceHelper.manager.find(qs);
   	 while(qr.hasMoreElements()) {
   		 WTTypeDefinition td = (WTTypeDefinition)qr.nextElement();
//   		 logger.error("name=" + td.getName());
//   		 logger.error("icon=" + td.getIcon());
//   		 logger.error("branch=" + VersionControlHelper.getBranchIdentifier(td));
   		 mTypeIds.put(String.valueOf(VersionControlHelper.getBranchIdentifier(td)), td.getIcon());
   	 }
    }
    
    public static String getIconURL(Object obj) throws WTException {
   	 try {
   		if(RemoteMethodServer.ServerFlag) {
                    return _getIconURL(obj);
                } else {
                    return (String)RemoteMethodServer.getDefault().invoke("getIconURL", "com.ptc.ssp.util.SoftTypeHelper", null, new Class[] { java.lang.Object.class }, new Object[] { obj });
                }
   	 } catch(Exception e) {
   		 if(e instanceof WTException) {
   			 throw (WTException) e;
   		 } else {
   			 throw new WTException(e);
   		 }
   	 }
    }
    
    private static String _getIconURL(Object obj) throws WTException {
   	 WTObject wto = null;
   	 if(obj instanceof WTObject) {
   		 wto = (WTObject) obj;
   	 } else if(obj instanceof String) {
   		 WTReference ref = (new ReferenceFactory()).getReference((String)obj);
   		 wto = (WTObject) ref.getObject();
   	 }
   	 try {
   		 return BasicTemplateProcessor.getObjectIconImgTag(wto);
   	 } catch(Exception e) {
   		 if(e instanceof WTException) {
   			 throw (WTException)e;
   		 } else {
   			 throw new WTException(e);
   		 }
   	 }
    }
    
    
    /////////////////////////////////////////////////////////////////////////////////
    // main method
    /////////////////////////////////////////////////////////////////////////////////
    
    //example use:
    // - windchill com.ptc.ssp.util.SoftTypeHelper -u wcadmin -p wcadmin -sn TheoTeil
    //   should return: fullName=wt.part.WTPart|de.volkswagen.TheoTeil
    // - windchill com.ptc.ssp.util.SoftTypeHelper -u wcadmin -p wcadmin -o VR:wt.part.WTPart:15211
    //   should return something like: typename=wt.part.WTPart|de.volkswagen.Baustufe
    public static void main(String[] args) {
        try {
            WTContext.init(args);
            AuthenticationHelper.authenticateUser(args);
   			String oid = null;
   			String shortName = null;
   			for (int j = 0; j < args.length; j++) {
   				if (args[j].equals("-o")) {
   					if (++j < args.length) {
   						oid = args[j];
   					} else {
   						System.out.println("awaiting argument after '-o'");
   					}
   				} else if (args[j].equals("-sn")) {
   					if (++j < args.length) {
   						shortName = args[j];
   					} else {
   						System.out.println("awaiting argument after '-sn'");
   					}
   				} 
   			}
            
            if(shortName!=null) {
                String fullName = (String) RemoteMethodServer.getDefault().invoke("getFullTypeName",CLASSNAME, null, new Class[] {String.class}, new Object[] {shortName});
                System.out.println("fullName=" + fullName);
            }
            
            if(oid!=null) {
            	ReferenceFactory RF = new ReferenceFactory();
            	WTReference ref = RF.getReference(oid);
            	Persistable p = ref.getObject();
            	String typename = SoftTypeHelper.getTypeName(p);
            	System.out.println("typename=" + typename);
            }
            
        } catch(Exception w) {
            w.printStackTrace();
            System.exit(1);
        }
    }
    
    /**
     *
     *  @param softTypeName Name of a soft type to return its and children e.g. EAProduct
     *  @param containsParent 
     * @return Vector TypeDefinitionReference of children soft types
     *  @throws WTException 
     * @author Graf Simone
     */
    public static Vector<TypeDefinitionReference> getSoftTypeChildrenAsTypeDefinitionReference(String softTypeName, boolean containsParent) throws WTException {
   	 try {
   		 if(RemoteMethodServer.ServerFlag) {
   			 return _getSoftTypeChildrenAsTypeDefinitionReference(softTypeName, Boolean.valueOf(containsParent));
   		 } else {
   			 return (Vector<TypeDefinitionReference>)RemoteMethodServer.getDefault().invoke("_getSoftTypeChildrenAsTypeDefinitionReference", "com.ptc.ssp.util.SoftTypeHelper", null, new Class[] { String.class, Boolean.class }, new Object[] { softTypeName, Boolean.valueOf(containsParent) });
   		 }
   	 } catch(Exception e) {
   		 if(e instanceof WTException) {
   			 throw (WTException) e;
   		 } else {
   			 throw new WTException(e);
   		 }
   	 }

    }
    public static Vector<TypeDefinitionReference> _getSoftTypeChildrenAsTypeDefinitionReference(String softTypeName, Boolean containsParent) throws WTException {
        Vector<TypeDefinitionReference> vectorOfChildren  = new Vector<TypeDefinitionReference>();
        String softTypeFullName  = SoftTypeHelper.getFullTypeName(softTypeName);
        if (softTypeFullName != null && softTypeFullName.length() > 0) {
            DefinitionDescriptorFactory fac = (DefinitionDescriptorFactory) DefaultServiceProvider.getService(DefinitionDescriptorFactory.class, "default");
            // is needed to browse through all types
            TypeModel typemodel = (TypeModel)DefaultServiceProvider.getService(com.ptc.core.meta.type.runtime.server.TypeModel.class, null);
            
            if (containsParent.booleanValue()) {
                vectorOfChildren.add(TypedUtility.getTypeDefinitionReference(softTypeFullName));
            }
            
            TypeIdentifier ident = TypeHelper.getTypeId(softTypeFullName);
            
            /* get all children from parent */
            TypeIdentifier[] siblings_identifiers = typemodel.getChildren(ident);
            
            if (logger.isDebugEnabled()) {
                logger.debug("softType              " + softTypeFullName);
                logger.debug("TypeIdentifier        " + ident.toString());
            }
            
            /* for all children */
            for (int x=0; x <= siblings_identifiers.length-1; x++) {
                TypeIdentifier child_identifier = siblings_identifiers[x];
                
                if (logger.isDebugEnabled()) {
                    logger.debug("_getSoftTypeChildrenAsTypeDefinitionReference--> sibling TypeIdentifier "+child_identifier.toString());
                }

                TypeDefinitionReference typeRef = TypedUtility.getTypeDefinitionReference(child_identifier.getTypename());
                
                vectorOfChildren.add(typeRef);
            }
        }
        
        return vectorOfChildren;
    }
    
    public static QuerySpec appendSearchCondition(QuerySpec qs, String fullSoftTypeName, boolean bWithChildren, boolean bAppendAnd, Class searchClass) throws WTException {
   	 TypeDefinitionReference typeRef = getTDR(fullSoftTypeName);
   	 if(typeRef==null) {
   		 throw new WTException("could not create SearchCondition for given fullSoftTypeName=" + fullSoftTypeName);
   	 }
   	 //int ai[]                    = {0, 1};
   	 //QuerySpec qs                = new QuerySpec(searchClass);
   	 SearchCondition scType      = new SearchCondition(searchClass, "typeDefinitionReference.key.branchId", SearchCondition.EQUAL, typeRef.getKey().getBranchId());
   	 Vector<TypeDefinitionReference> softTypeSiblings     = null;

   	 if(bAppendAnd) {
   		 qs.appendAnd();
   	 }

   	 //search for all soft type
   	 if (bWithChildren) {
   		 //will also contain start value (shortSoftTypeName)
   		 softTypeSiblings = getSoftTypeChildrenAsTypeDefinitionReference(fullSoftTypeName, false);
   	 }
   	 if (bWithChildren && softTypeSiblings != null && !softTypeSiblings.isEmpty()) {
   		 qs.appendOpenParen();
   		 qs.appendWhere(scType);
   		 for (int i = 0; i < softTypeSiblings.size(); i++) {
   			 TypeDefinitionReference typeRefSibling = (TypeDefinitionReference)softTypeSiblings.get(i);
   			 SearchCondition scSibling = new SearchCondition(searchClass, "typeDefinitionReference.key.branchId", SearchCondition.EQUAL, typeRefSibling.getKey().getBranchId());
   			 qs.appendOr();
   			 qs.appendWhere(scSibling);
   		 }
   		 qs.appendCloseParen();
   	 } else {
   		 //search only paren class
   		 qs.appendWhere(scType);
   	 }

   	 return qs;
    }
    
    public static TypeDefinitionReference getTDR(String fullSoftTypeName) throws WTException {
   	 try {
   		 if(RemoteMethodServer.ServerFlag) {
   			 return TypedUtility.getTypeDefinitionReference(fullSoftTypeName);
   		 } else {
   			 return (TypeDefinitionReference)RemoteMethodServer.getDefault().invoke("getTDR", "com.ptc.ssp.util.SoftTypeHelper", null, new Class[] { java.lang.String.class }, new Object[] { fullSoftTypeName });
   		 }
   	 } catch(Exception e) {
   		 if(e instanceof WTException) {
   			 throw (WTException) e;
   		 } else {
   			 throw new WTException(e);
   		 }
   	 }
    }
}
