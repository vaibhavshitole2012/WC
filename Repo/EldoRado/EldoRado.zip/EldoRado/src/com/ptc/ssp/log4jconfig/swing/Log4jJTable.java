package com.ptc.ssp.log4jconfig.swing;

import java.awt.Component;

import javax.swing.DefaultCellEditor;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableModel;

import org.apache.log4j.Level;

public class Log4jJTable extends JTable {

	public Log4jJTable(TableModel tm) {
		super(tm);
	}
	
	public Component prepareEditor(TableCellEditor editor, int row, int column) {
		//System.out.println("prepareEditor()");
		Component comp = super.prepareEditor(editor, row, column);
		//TODO make more generic instead of hardcoding column
		if(column==1) {
    		Level item = (Level) getModel().getValueAt(row, column);
//    		System.out.println("item in table=" + item);
//    		System.out.println("selected item in cb=" + ((JComboBox)((DefaultCellEditor)editor).getComponent()).getSelectedItem());
    		((JComboBox)((DefaultCellEditor)editor).getComponent()).setSelectedItem( item.toString() );
//    		System.out.println("selected item in cb=" + ((JComboBox)((DefaultCellEditor)editor).getComponent()).getSelectedItem());
		}
		return comp;
	}
}
