package com.ptc.ssp.util;

import java.util.*;

import org.apache.log4j.Logger;

import wt.fc.ReferenceFactory;
import wt.fc.WTReference;
import wt.inf.container.*;
import wt.inf.team.*;
import wt.method.*;
import wt.org.*;
import wt.util.*;

/**
 * 
 * @author lberger
 *
 */
public class ContainerTools implements RemoteAccess {
   private static final String CLASSNAME = ContainerTools.class.getName();
   private static final RemoteMethodServer RMS = RemoteMethodServer.getDefault();
   private static final Logger logger = Logger.getLogger(CLASSNAME);
   private static final ReferenceFactory RF = new ReferenceFactory();
   
   /**
    * checks if the given user is a member of the mentioned container team group (container is derived from the given containedObject oid)
    * @param OID of containedObject
    * @param containerRoleName
    * @param user
    * @return
    * @throws WTException
    */
   public static boolean isUserMemberOfContainerTeam( String containedOid, String containerRoleName, WTUser user)
            throws WTException {
       WTContained containedObj = (WTContained) RF.getReference(containedOid).getObject();
       return isUserMemberOfContainerTeam(containedObj, containerRoleName, user);
   }

   /**
    * checks if the given user is a member of the mentioned container team group (container is derived from the given containedObject)
    * @param containedObject
    * @param containerRoleName
    * @param user
    * @return
    * @throws WTException
    */
   public static boolean isUserMemberOfContainerTeam(WTContained containedObject, String containerRoleName, WTUser user) throws WTException {
       return isUserMemberOfContainerTeam(containedObject.getContainer(), containerRoleName, user);
   }
   
   /**
    * checks if the given user is a member of the mentioned container team group
    * @param container
    * @param containerRoleName
    * @param user
    * @return
    * @throws WTException
    */
	public static boolean isUserMemberOfContainerTeam(WTContainer container, String containerRoleName, WTUser user) throws WTException {
		// TODO: not sure if we need to switch to Admin mode here first if this
		// is called from someone that is not an Admin
		if (container == null || containerRoleName == null || containerRoleName.length() == 0 || user == null) {
			throw new WTException("ContainerTools.isUserMemberOfContainerTeam() must be called with 3 non-null parameters");
		}

		if (RemoteMethodServer.ServerFlag) {
			return _isUserMemberOfContainerTeam(container, containerRoleName, user);
		} else {
			Class[] remoteInvokeClasses = new Class[] { WTContainer.class, String.class, WTUser.class };
			Object[] remoteInvokeObj = new Object[] { container, containerRoleName, user };
			Boolean isMember = Boolean.FALSE; // default return value
			try {
				isMember = (Boolean) RMS.invoke("_isUserMemberOfContainerTeam", CLASSNAME, null, remoteInvokeClasses, remoteInvokeObj);
			} catch (Exception e) {
				if (e instanceof WTException) {
					throw (WTException) e;
				} else {
					throw new WTException(e);
				}
			}
			return isMember.booleanValue();
		}
	}
   
   /**
    * NOT TO BE USED DIRECTLY. Please use isUserMemberOfContainerTeam(ContainerTeamManaged container, String containerRoleName, String userName) instead.
    * @param container
    * @param containerRoleName
    * @param userName
    * @return
    * @throws WTException
    */
   public static Boolean _isUserMemberOfContainerTeam(WTContainer container, String containerRoleName, WTUser user) throws WTException {
   	
   	//somehow the ContainerTeamHelper needs a container object in the form of ContainerTeamManaged
   	//ContainerTeamManaged is an interface which extends WTContainer !
   	if(! (container instanceof ContainerTeamManaged)) {
   		throw new WTException("this method can only be executed for container objects that implement the interface ContainerTeamManaged");
   	}
   	ContainerTeamManaged ctm = (ContainerTeamManaged)container;
   	
	//would print out all container team groups:
	if (logger.isDebugEnabled()) {
		@SuppressWarnings("unchecked")
		Enumeration<WTGroup> eGroups = ContainerTeamHelper.service.findContainerTeamGroups(ctm, ContainerTeamHelper.ROLE_GROUPS);
		while (eGroups.hasMoreElements()) {
			Object o = eGroups.nextElement();
			System.out.println("o=" + o + " o.class=" + (o == null ? "NULL" : o.getClass().getName()));
		}
	}
   		
   	boolean isMemberOfGroup = false;
   	//searches for a container team with a specific name:
      WTGroup g = ContainerTeamHelper.service.findContainerTeamGroup(ctm, ContainerTeamHelper.ROLE_GROUPS, containerRoleName);
	   if(logger.isDebugEnabled()) {
	   	 logger.debug("found container team group: " + g + " g==null?: " + (g==null));
	   }
	   if(g==null) {
	   	logger.warn("could not find containerTeamGroup '" + containerRoleName + "'");
	   	return Boolean.FALSE;
	   	//throw new WTException("could not find containerTeamGroup '" + containerRoleName + "'");
	   }
 		isMemberOfGroup = OrganizationServicesHelper.manager.isMember(g, user);
 		if(logger.isDebugEnabled()) {
 			logger.debug(user.getFullName() + " member of Container Team Role '" + containerRoleName + "': " + isMemberOfGroup);
 		}
 		return isMemberOfGroup;//this is possible in JDK 1.5 :-)
   }
   
   
   
   
   
   
   
   
   ////////////////////////////////////////////////////////////////
   //TODO ECA 4.0: check all below code in ContainerTools
   //below methods are currently only used on a jsp page that helps finding user/role access control issues. This page is not yet supported for production!
   
   /**
    * returns a Map with info about the given user in the context of the given container
    * e.g. if the user is a member of some container role, ...
    * 
    * @param container
    * @param user
    * @return
    * @throws Exception
    */
   @SuppressWarnings("unchecked")
   public static Map<String, Object> getContainerInfo(WTContainer container, WTUser user) throws Exception {
   	if(RemoteMethodServer.ServerFlag) {
   	   return _getContainerInfo(container, user);
   	} else {
	   	Class<?>[] remoteInvokeClasses = new Class<?>[] {WTContainer.class, WTUser.class};
	      Object[] remoteInvokeObj = new Object[] { container, user };
	      return (Map<String, Object>) RMS.invoke( "_getContainerInfo", CLASSNAME, null, remoteInvokeClasses, remoteInvokeObj );
   	}
   }
   @SuppressWarnings("rawtypes")
public static Map<String, Object> _getContainerInfo(WTContainer container, WTUser user) throws Exception {
   	Map<String, Object> map = new HashMap<String, Object>();
   	
   	if(user!=null) {
   		map.put("isContainerAdmin", Boolean.valueOf(WTContainerHelper.service.isAdministrator (WTContainerRef.newWTContainerRef (container), user)));
   	}
   	//somehow the ContainerTeamHelper needs a container object in the form of ContainerTeamManaged
   	//ContainerTeamManaged is an interface which extends WTContainer !
      if (container instanceof ContainerTeamManaged) {
      	ContainerTeamManaged ctm = (ContainerTeamManaged)container;
      	
	      ContainerTeam containerTeam = ContainerTeamHelper.service.getContainerTeam((ContainerTeamManaged) container);
	      map.put("containerTeam", containerTeam);
	      if(user!=null) { 
	      	//search for all container team groups
	         @SuppressWarnings("unchecked")
			Enumeration<WTGroup> eGroups = ContainerTeamHelper.service.findContainerTeamGroups(ctm, ContainerTeamHelper.ROLE_GROUPS);
	         List<String> containerTeamGroupsOfUser = new ArrayList<String>();
	         while(eGroups.hasMoreElements()) {
	         	WTGroup g = eGroups.nextElement();
	         	boolean bUserIsMember = OrganizationServicesHelper.manager.isMember(g, user);
	         	if(bUserIsMember) {
	         		containerTeamGroupsOfUser.add(g.getName());
	         	}
	         }
		      map.put("user is member of this container team roles:", containerTeamGroupsOfUser);
	      }
	      
	      Map rolePrincipalMap = containerTeam.getRolePrincipalMap();
	      Iterator itKeys = rolePrincipalMap.keySet().iterator();
	      Map<Object, List> newRPM = new HashMap<Object, List>();
	      while(itKeys.hasNext()) {
	      	Object r = itKeys.next();
	      	//System.out.println(rolePrincipalMap.get(r).getClass().getName());
	      	List v = (List)((ArrayList)rolePrincipalMap.get(r)).clone();//Wincom fix (nbouayad@wincom-consulting.co.uk)
	      	for(int i=0, n=v.size(); i<n; i++) {
	      		//System.out.println("v: " + v.get(i) + " " + v.get(i).getClass().getName());
	      		if(v.get(i) instanceof WTPrincipalReference) {
		      		WTPrincipalReference wtpr = (WTPrincipalReference)v.get(i);
		      		v.set(i, wtpr.toString() + "/" + wtpr.getFullName());
	      		}
	      	}
	      	newRPM.put(r, v);
	      }
	      map.put("rolePrincipalMap", newRPM.toString());
//	      map.put("rolePrincipalMap", rolePrincipalMap.toString());
      }
   	return map;
   }
   
   public static void main(String args[]) {
      try {
          WTPrincipal user = AuthenticationHelper.authenticateUser(args);
          System.out.println("authenticated as: " + user.getName());
      } catch (WTException w) {
          System.out.println("could not authenticate user. Exception:" + w.getLocalizedMessage());
          w.printStackTrace();
          System.exit(1);
      }

              String container = null;
      String containedObject = null;
      @SuppressWarnings("unused")
      String roleName = null;
      String userName = null;
      for (int j = 0; j < args.length; j++) {
          if (args[j].equals("-container")) {
              if (++j < args.length) {
                  container = args[j];
              }
          } else if (args[j].equals("-containedObject")) {
              if (++j < args.length) {
                  containedObject = args[j];
              }
          } else if (args[j].equals("-roleName")) {
              if (++j < args.length) {
                  roleName = args[j];
              }
          } else if (args[j].equals("-checkUser")) {
              if (++j < args.length) {
                  userName = args[j];
              }
          }
      }

      if (containedObject==null && container==null) {
          System.out.println("ERROR: invalid parameter");
          printUsage(); //includes System.exit(1);
      }

      // init WTContext and set locale
      WTContext.init(args);

      try {
                      WTContainer conti = null;
                      if (container != null) {
                              WTReference ref = RF.getReference(container);
                              if(ref==null) {
                                      throw new WTException("ref for container is null");
                              }
                              conti = (WTContainer) ref.getObject();
                      }
                      if (conti == null) {
                              WTReference ref = RF.getReference(containedObject);
                              if(ref==null) {
                                      throw new WTException("ref for containedObject is null");
                              }
                              if(!(ref.getObject() instanceof WTContained)) {
                                      throw new WTException("containedObject is not WTContained");
                              }
                              WTContained obj = (WTContained) ref.getObject();
                              conti = obj.getContainer();
                      }

                      
                      System.out.println("Getting members of container: '" + conti.getName() + " and checking user '" + userName);
                      logger.debug("userName='" + userName + "'");
                      if(userName!=null && userName.length()>0) {
                        WTUser user = OrganizationServicesHelper.manager.getUser(userName);
                        logger.debug("found user=" + (user==null?"NULL":user.getName()));
                        if(user==null) {
                       	 System.out.println("could not find user for userName=" + userName);
                        } else {
                        	Map<String, Object> containerInfo = ContainerTools.getContainerInfo(conti, user);
                        	System.out.println(containerInfo.toString());
                        	boolean isMember = ContainerTools.isUserMemberOfContainerTeam(containedObject, "PRODUCT MANAGER", user);
                        	System.out.println("is member of 'PRODUCT MANAGER': " + isMember);
                        }
                      } else {
                    	  System.out.println("no userName given");
                      }

      } catch (Exception w) {
          w.printStackTrace();
          printUsage();
      }
      System.exit(0);
  }

   

   public static void printUsage() {
       System.out.println("windchill com.ptc.ssp.util.ContainerTools -u <username> -p <pwd> [[-container <oid>] OR [-containedObject <oid>]] -roleName <role name> [-checkUser <user name>]");
       System.out.println("  example: list the members of the given container by the contained object and role");
       System.exit(1);
   }
}
