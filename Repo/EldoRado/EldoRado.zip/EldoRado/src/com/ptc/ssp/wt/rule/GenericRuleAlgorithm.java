package com.ptc.ssp.wt.rule;

import java.util.StringTokenizer;

import org.apache.log4j.Logger;

import wt.inf.container.WTContainerRef;
import wt.log4j.LogR;
import wt.rule.algorithm.InvalidAlgorithmArgumentException;
import wt.rule.algorithm.RuleAlgorithm;
import wt.util.WTException;

import com.ptc.ssp.wt.identity.IdentityProperties;
import com.ptc.ssp.wt.identity.StandardNumberService;


/**
 *
 * Copyright (c) 1998-2008 Parametric Technology. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Parametric Technology. You shall not disclose such
 * confidential information and shall use it only in accordance with the terms of the license agreement you entered into
 * with Parametric Technology.
 *
 * ecwti
 */

/*
	This class can be included in an object initialization rule such as:

	<AttributeValues objType="wt.part.WTPart">
	<AttrValue id="number" algorithm="com.ptc.ssp.wt.rule.GenericRuleAlgorithm" ignore="false" force="false" final="false">
	  <Arg>infoengine/examples/fsmith/querySequence.xml</Arg>
	  <Arg>group:element:attribute</Arg>
	  <Arg>prefix</Arg>
	  <Attr id="partType"/>
	  <Arg>separator</Arg>
	  <Arg>-</Arg>
	</AttrValue>
	</AttributeValues>

	The above rule invokes the Info*Engine task specified by the URI specified in the first argument.  The second argument is
	a colon-separated triple which specifies the name of the group, the number of the element, and the name of the attribute to
	retrieve from the VDB created by the task.  If any member of the triple is "ANY", the first one encountered in the VDB
	will be returned.  Therefore, "ANY:ANY:name" will return the name attribute of the first element of the first group.

	The third and fourth arguments, and subsequent pairs are assumed to be attribute/value pairs that will be appended to the
	URL, thus passing arguments to the task.  The URL for the above task would be:

	infoengine/examples/fsmith/querySequence.xml?prefix=<partType>&separator=-

	Any Info*Engine task that generates a VDB similar to the following can be used as an attribute generator.

	    <?xml version="1.0" encoding="UTF-8" ?>
	      <wc:COLLECTION xmlns:wc="http://www.ptc.com/infoengine/1.0">
	        <Unknown-Class-Name NAME="response" TYPE="Unknown" STATUS="0">
	          <wc:INSTANCE>
	            <Number>000000000000000442</Number>
	          </wc:INSTANCE>
	        </Unknown-Class-Name>
	      </wc:COLLECTION>

 */
/**
 * <!-- this is the source readable comment
 *
 * This class can be included in an object initialization rule such as:
 *
 * <AttributeValues objType="wt.part.WTPart">
 *  <AttrValue id="number" algorithm="ext.adapter.ExternalAttributeGeneratorAlgorithm" ignore="false" force="false" final="false">
 *    <Arg>infoengine/examples/fsmith/querySequence.xml</Arg>
 *    <Arg>group:element:attribute</Arg>
 *    <Arg>prefix</Arg>
 *    <Attr id="partType"/>
 *    <Arg>separator</Arg>
 *    <Arg>-</Arg>
 *  </AttrValue>
 *  </AttributeValues>
 *
 *  The above rule invokes the Info*Engine task specified by the URI specified in the first argument.  The second argument is
 *  a colon-separated triple which specifies the name of the group, the number of the element, and the name of the attribute to
 *  retrieve from the VDB created by the task.  If any member of the triple is "ANY", the first one encountered in the VDB
 *  will be returned.  Therefore, "ANY:ANY:name" will return the name attribute of the first element of the first group.
 *
 *  The third and fourth arguments, and subsequent pairs are assumed to be attribute/value pairs that will be appended to the
 *  URL, thus passing arguments to the task.  The URL for the above task would be:
 *
 *  infoengine/examples/fsmith/querySequence.xml?prefix=<partType>&separator=-
 *
 *  Any Info*Engine task that generates a VDB similar to the following can be used as an attribute generator.
 *
 *      <?xml version="1.0" encoding="UTF-8" ?>
 *        <wc:COLLECTION xmlns:wc="http://www.ptc.com/infoengine/1.0">
 *          <Unknown-Class-Name NAME="response" TYPE="Unknown" STATUS="0">
 *            <wc:INSTANCE>
 *              <Number>000000000000000442</Number>
 *            </wc:INSTANCE>
 *          </Unknown-Class-Name>
 *        </wc:COLLECTION>
 *
 *
 * following is the javadoc readable comment -->
 *
 * @author mvonhasselbach
 *
 * This class can be included in an object initialization rule such as:<br>
 *  <br>
 * &lt;AttributeValues objType="wt.part.WTPart"&gt;<br>
 *  &lt;AttrValue id="number" algorithm="ext.adapter.ExternalAttributeGeneratorAlgorithm" ignore="false" force="false" final="false"&gt;<br>
 *    &lt;Arg&gt;infoengine/examples/fsmith/querySequence.xml&lt;/Arg&gt;<br>
 *    &lt;Arg&gt;group:element:attribute&lt;/Arg&gt;<br>
 *    &lt;Arg&gt;prefix&lt;/Arg&gt;<br>
 *    &lt;Attr id="partType"/&gt;<br>
 *    &lt;Arg&gt;separator&lt;/Arg&gt;<br>
 *    &lt;Arg&gt;-&lt;/Arg&gt;<br>
 *  &lt;/AttrValue&gt;<br>
 *  &lt;/AttributeValues&gt;<br>
 *  <br>
 *  The above rule invokes the Info*Engine task specified by the URI specified in the first argument.  The second argument is<br>
 *  a colon-separated triple which specifies the name of the group, the number of the element, and the name of the attribute to<br>
 *  retrieve from the VDB created by the task.  If any member of the triple is "ANY", the first one encountered in the VDB<br>
 *  will be returned.  Therefore, "ANY:ANY:name" will return the name attribute of the first element of the first group.<br>
 *  <br>
 *  The third and fourth arguments, and subsequent pairs are assumed to be attribute/value pairs that will be appended to the<br>
 *  URL, thus passing arguments to the task.  The URL for the above task would be:<br>
 *  <br>
 *  infoengine/examples/fsmith/querySequence.xml?prefix=&lt;partType&gt;&separator=-<br>
 *  <br>
 *  Any Info*Engine task that generates a VDB similar to the following can be used as an attribute generator.<br>
 *  <br>
 *      &lt;?xml version="1.0" encoding="UTF-8" ?&gt;<br>
 *        &lt;wc:COLLECTION xmlns:wc="http://www.ptc.com/infoengine/1.0"&gt;<br>
 *          &lt;Unknown-Class-Name NAME="response" TYPE="Unknown" STATUS="0"&gt;<br>
 *            &lt;wc:INSTANCE&gt;<br>
 *              &lt;Number&gt;000000000000000442&lt;/Number&gt;<br>
 *            &lt;/wc:INSTANCE&gt;<br>
 *          &lt;/Unknown-Class-Name&gt;<br>
 *        &lt;/wc:COLLECTION&gt;<br>
 *   */
public class GenericRuleAlgorithm implements RuleAlgorithm {
	private static final String CLASSNAME = GenericRuleAlgorithm.class.getName();
	static Logger logger = LogR.getLogger(CLASSNAME);


	public GenericRuleAlgorithm () {}
	
	/**
	 * Method validateArgs.
	 * @param as String[]
	 * @throws InvalidAlgorithmArgumentException
	 * @see wt.rule.algorithm.RuleAlgorithm#validateArgs(String[])
	 */
	public void validateArgs(String as[]) throws InvalidAlgorithmArgumentException {
		if (as.length >= 2 && !validTarget(as[1])) {
			// throw new InvalidAlgorithmArgumentException("Invalid target attribute specification as second argument (" + as[1] + ").");
			throw new InvalidAlgorithmArgumentException();
		}
	}
	
	/**
	 * Method calculate.
	 * @param aobj Object[]
	 * @param wtcontainerref WTContainerRef
	 * @return Object
	 * @throws WTException
	 * @see wt.rule.algorithm.RuleAlgorithm#calculate(Object[], WTContainerRef)
	 */
	public Object calculate(Object aobj[], WTContainerRef wtcontainerref) throws WTException {
		
		logger.debug("calculate start");
		StandardNumberService numberService = StandardNumberService.getStandardNumberService();
		String value = numberService.getNumber();
		logger.debug("Value = " + value);
		return value;
	}

	/**
	 * Method validTarget.
	 * 
	 * @param t   String
	 * @return boolean
	 */
	private boolean validTarget(String t) {
		StringTokenizer st = new StringTokenizer(t, ":");
		return (st.countTokens() == 3);
	}
}