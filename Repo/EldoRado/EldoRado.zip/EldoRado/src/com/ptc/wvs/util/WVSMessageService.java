package com.ptc.wvs.util;

@wt.method.RemoteInterface
public interface WVSMessageService {

}
