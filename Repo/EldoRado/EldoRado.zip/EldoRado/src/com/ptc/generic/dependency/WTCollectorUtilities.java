package com.ptc.generic.dependency;
/*
 * @(#)WTCollectorUtilities.java   13/05/28
 *
 * Copyright (c) 2004 Parametric Technology Corporation (PTC).
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC.
 * You shall not disclose such confidential information and shall use it
 * only in accordance with the terms of the license agreement.
 *
 * Alfred Weyerer
 */





//~--- non-JDK imports --------------------------------------------------------

import java.util.*;

import org.apache.log4j.Logger;

import com.ptc.prowt.nd.nd3pobject_j01.nd3pobject_j01;
import com.ptc.smb.helper.HelperBase;

import com.vw.aop.annotations.ServerOnly;

import wt.doc.WTDocument;
import wt.enterprise.RevisionControlled;
import wt.epm.EPMDocConfigSpec;
import wt.epm.EPMDocument;
import wt.epm.build.EPMBuildRule;
import wt.epm.navigator.*;
import wt.epm.navigator.Filter.Comparison;
import wt.epm.navigator.Filter.Condition;
import wt.epm.navigator.configuration.ConfigSpecRuleAdapter;
import wt.epm.navigator.configuration.WorkspaceConfiguration;
import wt.epm.navigator.relationship.*;
import wt.epm.navigator.relationship.AssociatedCADDocs.Type;
import wt.epm.structure.EPMDependencyLink;
import wt.epm.structure.EPMMemberLink;
import wt.epm.workspaces.EPMAsStoredConfigSpec;
import wt.epm.workspaces.EPMWorkspace;
import wt.fc.Persistable;
import wt.fc.collections.*;
import wt.filter.NavigationCriteria;
import wt.filter.NavigationCriteriaHelper;
import wt.navigation.DTRequest;
import wt.navigation.DTRequest.VisibleFilteredStatus;
import wt.navigation.DependencyHelper;
import wt.navigation.NavigationUnit;
import wt.navigation.PartRequest;
import wt.navigation.PartRequest.AssociatedEPMDocuments;
import wt.navigation.PartRequest.OccurrenceInfo;
import wt.navigation.PartRequest.Occurrences;
import wt.part.PartDocHelper;
import wt.part.WTPart;
import wt.pom.Transaction;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
//~--- JDK imports ------------------------------------------------------------

/**
 *
 * $URL: http://127.0.0.1/svn/KB_04082016/components/Generic-Utilities/src/com/ptc/generic/dependency/WTCollectorUtilities.java $
 * @version    $Revision: 1.1.1.3 $
 * @serial     $Id: WTCollectorUtilities.java 1.1.1.3 2015/12/10 21:01:36IST kbil Exp  $
 * @author     $Author: kbil $
 */
public class WTCollectorUtilities {

    /**
     *
     */
    public static final String  svnRev    = "$Revision: 1.1.1.3 $ $Date: 2015/12/10 21:01:36IST $";
    public static final String  svnUrl    = "$URL: http://127.0.0.1/svn/KB_04082016/components/Generic-Utilities/src/com/ptc/generic/dependency/WTCollectorUtilities.java $";
    
    private static final String CLASSNAME = WTCollectorUtilities.class.getName();
    private static final Logger logger    = Logger.getLogger(CLASSNAME);
    /**
     * A type of build rule. This determines what 'build roles' the build rule is involved
     */ 
    public enum CADDocAssociationType {
        OWNER, CONTRIBUTING_IMAGE, CONTRIBUTING_CONTENT, CONTENT, IMAGE, ALL, DRAWINGS;
    }

    public enum CADDocCollections {
		WTDOCUMENTS, FT_GENERICS, FT_GENERICS_ONLY_FOR_SEEDS, FT_INSTANCES, FT_INSTANCES_ONLY_FOR_SEEDS, DRAWINGS_ONLY_FOR_SEEDS, DRAWINGS, ASSOCIATED_WTPARTS, ASSOCIATED_WTPARTS_ONLY_FOR_SEEDS, DEPENDENT_EPMDOCS, FILTER_CATIAV5_ADDITIONS, CATIAV5_ADDITIONS;
    }

    /**
     * Method description
     *
     *
     * @param part
     *
     * @return
     *
     * @throws WTException
     */
    @ServerOnly
    public static WTCollection getWTDocumentsByDescribeLink(WTPart wtpart) throws WTException {
    	
    	WTKeyedMap map = PartDocHelper.service.getAssociatedDescribeDocuments(CollectionsHelper.singletonWTList(wtpart));
    	
    	if(map!=null && !map.isEmpty()) {
			return (WTCollection) map.get(wtpart);
		}
    	
		return new WTArrayList();
    	
    }

    /**
     * Method description
     *
     *
     * @param part
     *
     * @return
     *
     * @throws WTException
     */
    @ServerOnly
    public static WTCollection getWTDocumentsByReferenceLink(WTPart wtpart) throws WTException {
    	
    	WTKeyedMap map = PartDocHelper.service.getAssociatedReferenceDocuments(CollectionsHelper.singletonWTList(wtpart));
    	
    	if(map!=null && !map.isEmpty()) {
			return (WTCollection) map.get(wtpart);
		}
    	
		return new WTArrayList();
    }

    private static WTCollection getUnitElements(Class<?> className, NavigationUnit nUnit) throws WTException {
        WTCollection                                    wtCollectionItems = new WTHashSet();
        @SuppressWarnings("unchecked") Set<Persistable> set               = (Set<Persistable>) nUnit.getElements(className, true);

        wtCollectionItems.addAll(set);

        return wtCollectionItems;
    }

    /**
     * Returns all EPMDocument including substructure linked to this WTPart
     *
     *
     *
     * @param wtpart
     *
     * @return typed Collection of EPMDocument(s). Internally a WTArrayList is returned.
     *
     * @throws WTException 
     * @Deprecated
     */
    @SuppressWarnings("unchecked") @ServerOnly
    public static Collection<EPMDocument> getLinkedEPMs(WTPart wtpart) throws WTException {
        WTCollection     epms        = new WTArrayList();
        WTCollection     partSeeds   = CollectionsHelper.singletonWTList(wtpart);
        PartRequest      partRequest = createPartRequest(partSeeds, null, 1);
        NavigationUnit[] nunits      = getNavigatedUnitsFromDTHelper(partRequest);

        for (NavigationUnit nUnit : nunits) {
            epms.addAll(getUnitElements(EPMDocument.class, nUnit));
        }

        return epms;
    }

    private static NavigationUnit[] getNavigatedUnitsFromDTHelper(DTRequest dtRequest) throws WTException {
        DependencyHelper helper             = new DependencyHelper(dtRequest);
        NavigationUnit[] navigatedUnitArray = helper.getCollectedNavigationUnits();

        dtRequest.setCacheID(helper.getCacheID());

        return navigatedUnitArray;
    }

    private static PartRequest createPartRequest(WTCollection partSeeds, EPMWorkspace ws, int expandLevel) throws WTException {
        NavigationCriteria          navigationCriteria = NavigationCriteriaHelper.service.getDefaultNavigationCriteria(partSeeds, null);
        DTRequest.Scope             scope              = DTRequest.Scope.PDMLINK;
        DTRequest.DependencyTracing dependencyTracing  = DTRequest.DependencyTracing.ALL;
        PartRequest                 dtRequest          = new PartRequest(partSeeds, navigationCriteria, scope, expandLevel, dependencyTracing);

        dtRequest.setConfigSpecs(navigationCriteria.getConfigSpecs());

        // dtRequest.setPattern();
        if (ws != null) {
            dtRequest.setWorkspace(ws);
        }

        dtRequest.setRetrieveLinks(true);
        dtRequest.setOccurrences(Occurrences.ONLY_FOR_SEEDS);
        dtRequest.setOccurrenceInfo(OccurrenceInfo.ALL);
        dtRequest.setVisibleFilteredStatus(VisibleFilteredStatus.EXCLUDE_FILTERED);
        dtRequest.setCollectorCache(DTRequest.CollectorCache.USE_AND_KEEP);
        dtRequest.setAssociatedEPMDocuments(AssociatedEPMDocuments.ALL);

        return dtRequest;
    }

    private static Configuration newNavConfiguration(EPMDocument[] topSeeds, EPMWorkspace ws, boolean asStored) throws WTException {

        /**
         * Creating configuration dependent on given parameters:
         * - WorkspaceConfiguration
         * - Configuration latest rule
         * - Configuration asStored rule, if available, otherwise latest rule
         */
        Configuration.Rule latest   = new ConfigSpecRuleAdapter(EPMDocConfigSpec.newEPMDocConfigSpec());
        Configuration.Rule asstored = null;

        try {
            if (asStored) {
            	EPMAsStoredConfigSpec asStoredConfigSpec = EPMAsStoredConfigSpec.newEPMAsStoredConfigSpec(Arrays.asList(topSeeds));
            	asstored = new ConfigSpecRuleAdapter(asStoredConfigSpec);
            }
        } catch (WTException e) {
        	/**
        	 * AW: Fix for VW_ECA-18128
        	 * Caused by: (wt.epm.util.EPMResource/373) 
        	 * wt.util.WTException: The selected CAD Documents do not have any as stored baselines.
        	 */
        	if(asstored == null){
        		//Fallback to latest configspec
        		asStored = false;
        	}
        } catch (WTPropertyVetoException e) {
            throw new WTException(e);
        }
        
        Configuration config = null;

        if (ws == null) {
            config = new Configuration();

            if (asStored) {
                config.addRules(new Configuration.Rule[] {asstored});
            } else {
                config.addRules(new Configuration.Rule[] {latest});
            }
        } else {
            if (asStored) {
                config = new WorkspaceConfiguration(ws, asstored);
            } else {
                config = new WorkspaceConfiguration(ws, latest);
            }
        }

        return config;
    }
    /**
     *
     * Retrieves different kind of RevisionControlled object collections by the given CADDocCollections enumeration type.<br>
     * <code>CADDocCollections.DEPENDENT_EPMDOCS</code> is always part of the returned Map.<br>
     * <br>
     * If the calling code is running inside a transaction and getDependencies is called at least twice<br>
     * the previous cached map is reused and not called again.<br>
     * For the keys the passed topSeeds array is used.<br>
     * 
     * @param topSeeds
     * @param ws
     * @param asStored
     * @param required
     * @param collections
     * @return
     * @throws WTException
     */
    @SuppressWarnings("unchecked")
	@ServerOnly
    public static Map<CADDocCollections, Collection<? extends RevisionControlled>> getDependencies(EPMDocument[] topSeeds, EPMWorkspace ws, boolean asStored, boolean required, CADDocCollections... collections) throws WTException {
    	Transaction trx = Transaction.getCurrentTransaction();
		if (trx != null) {
			Map<CADDocCollections, Collection<? extends RevisionControlled>> existingMap = (Map<CADDocCollections, Collection<? extends RevisionControlled>>) Transaction.getInContext(topSeeds, false, false);
			if (existingMap != null) {
				return existingMap;
			}
		}

		Map<CADDocCollections, Collection<? extends RevisionControlled>> typedMap = getDependencies(topSeeds, ws, asStored, required, false, collections);
		if (trx != null) {
			trx.getLocalMap().put(topSeeds, typedMap);
		}
		return typedMap;
    }
    
    /**
     * Retrieves different kind of RevisionControlled object collections by the given CADDocCollections enumeration type.<br>
     * <code>CADDocCollections.DEPENDENT_EPMDOCS</code> is always part of the returned Map.
     *
     *
     * @param topSeeds
     * @param ws
     * @param asStored
     * @param required
     * @param objRefs if false collections of ObjectReference objects are put into the map, else heavy persistable objects 
     * @param collections
     *
     * @return
     *
     * @throws WTException
     */
    @SuppressWarnings("unchecked") @ServerOnly
    public static Map<CADDocCollections, Collection<? extends RevisionControlled>> getDependencies(EPMDocument[] topSeeds, EPMWorkspace ws, boolean asStored, boolean required, boolean objRefs, CADDocCollections... collections) throws WTException {
        EPMNavigator navigator = new EPMNavigator();

        /**
         * List of includes
         */
        List<CADDocCollections> list = Arrays.asList(collections);
        EnumSet<CADDocCollections>    colltypes = java.util.EnumSet.copyOf(list);

        /**
         * Getting navigation configuration
         */
        Configuration config        = newNavConfiguration(topSeeds, ws, asStored);
        CADDependents cadDependents = new CADDependents(config);

        cadDependents.requiredOnly(required);

        if (colltypes.contains(CADDocCollections.WTDOCUMENTS)) {
            cadDependents.ignoreWTDocs(false);
        } else {
            cadDependents.ignoreWTDocs(true);
        }

		// FILTER_DEP_T_3P_CATIA_V5_CCP
		// TODO verify that the CATIA additional parts are related to DEP_TYPE
		// attribute on the EPMDependencyLink?
		// For Audisport, they shouldn't be part of the results, thus they are
		// filtered out.
		if (colltypes.contains(CADDocCollections.FILTER_CATIAV5_ADDITIONS)) {
			Filter fCCP = new Filter(ClassAlias.LINK, EPMDependencyLink.DEP_TYPE, Comparison.NOT_EQUAL, Integer.valueOf(nd3pobject_j01.DEP_T_3P_CATIA_V5_CCP));
			Filter fKWE = new Filter(ClassAlias.LINK, EPMDependencyLink.DEP_TYPE, Condition.NOT_EQUAL, Integer.valueOf(nd3pobject_j01.DEP_T_3P_CATIA_V5_KWE));
			Filter fMML = new Filter(ClassAlias.LINK, EPMDependencyLink.DEP_TYPE, Condition.NOT_EQUAL, Integer.valueOf(nd3pobject_j01.DEP_T_3P_CATIA_V5_MML));
			cadDependents.filterBy(fCCP, fKWE, fMML);
		}

		// Include the above filtered out documents by adding a new relationship
		// (visitor) for this parts.
		if (colltypes.contains(CADDocCollections.CATIAV5_ADDITIONS)) {
			cadDependents.include(CADDocCollections.CATIAV5_ADDITIONS.name(), Connector.OTHERSIDE, Relationships.newCATIAV5Additions(config));
			cadDependents.include(CADDocCollections.CATIAV5_ADDITIONS.name(), Connector.SEED, Relationships.newCATIAV5Additions(config));
		}

        /*
         *  INCLUDE drawings of the dependents and the seeds.
         *
         * By specifying the same tag, "drawings", the drawings of the dependents
         * and the drawings of the seeds will be mixed together.
         */
        if (colltypes.contains(CADDocCollections.DRAWINGS)) {
            cadDependents.include(CADDocCollections.DRAWINGS.name(), Connector.OTHERSIDE, new CADDrawing(config.duplicate()));
            cadDependents.include(CADDocCollections.DRAWINGS.name(), Connector.SEED, new CADDrawing(config.duplicate()));
        }

        if (colltypes.contains(CADDocCollections.DRAWINGS_ONLY_FOR_SEEDS)) {
            cadDependents.include(CADDocCollections.DRAWINGS_ONLY_FOR_SEEDS.name(), Connector.SEED, new CADDrawing(config.duplicate()));
        }
        
        
        /*
         *  INCLUDE Familiytable instances
         * Selects the instances of the seeds and their dependents.
         * The tag name associated to the drawing found is "instances".
         */
        if (colltypes.contains(CADDocCollections.FT_INSTANCES)) {
            cadDependents.include(CADDocCollections.FT_INSTANCES.name(), Connector.SEED, new Instances());
            cadDependents.include(CADDocCollections.FT_INSTANCES.name(), Connector.OTHERSIDE, new Instances());
        }

        if (colltypes.contains(CADDocCollections.FT_INSTANCES_ONLY_FOR_SEEDS)) {
            cadDependents.include(CADDocCollections.FT_INSTANCES_ONLY_FOR_SEEDS.name(), Connector.SEED, new Instances());
        }

        /*
         *  INCLUDE Familiytable generics
         * Selects the generics of the seeds and their dependents.
         * The tag name associated to the drawing found is "generics".
         */
        if (colltypes.contains(CADDocCollections.FT_GENERICS)) {
            cadDependents.include(CADDocCollections.FT_GENERICS.name(), Connector.SEED, new Generics());
            cadDependents.include(CADDocCollections.FT_GENERICS.name(), Connector.OTHERSIDE, new Generics());
        }

        if (colltypes.contains(CADDocCollections.FT_GENERICS_ONLY_FOR_SEEDS)) {
            cadDependents.include(CADDocCollections.FT_GENERICS_ONLY_FOR_SEEDS.name(), Connector.SEED, new Generics());
        }

        /*
         *  JOINT Parts: Finds the actively and passively associated WTParts
         * of the dependents and the drawings.
         *
         * When using OTHERSIDE as the connector for the JOINT relationship,
         * the otherside objects returned by navigating all INCLUDE relationships
         * will also be used as seeds. In this case, the dependents, their
         * drawings and the drawings of the (seed) assembly will be used as the
         * seeds to navigate CADAssociatedParts.
         *
         * When using SEED as the connector, only the initial seeds are used, in
         * this case the assembly.
         */
        if (colltypes.contains(CADDocCollections.ASSOCIATED_WTPARTS)) {
            cadDependents.joint(CADDocCollections.ASSOCIATED_WTPARTS.name(), Connector.OTHERSIDE, new CADAssociatedParts());
            cadDependents.joint(CADDocCollections.ASSOCIATED_WTPARTS.name(), Connector.SEED, new CADAssociatedParts());
        }

        if (colltypes.contains(CADDocCollections.ASSOCIATED_WTPARTS_ONLY_FOR_SEEDS)) {
            cadDependents.joint(CADDocCollections.ASSOCIATED_WTPARTS_ONLY_FOR_SEEDS.name(), Connector.SEED, new CADAssociatedParts());
        }
        
        // Recusively navigate EPM dependents.
        navigator.includeRecursively(CADDocCollections.DEPENDENT_EPMDOCS.name(), cadDependents);
        
        // Recursively navigate CADDependents plus INCLUDE drawings and JOINT parts.
        // 2013-12-09 MC: added SEED condition to the collector to get a 3D related to a source drawing
        StandardCollector collector = new StandardCollector(CollectItem.OTHERSIDE, CollectItem.SEED);

        navigator.execute(collector, topSeeds);

        /**
         * Retrieving and sorting results by CADDocCollections
         */
        WTHashSet                                                            resultList         = null;
        Collection<? extends RevisionControlled>                             filteredResultList = null;
        EnumMap<CADDocCollections, Collection<? extends RevisionControlled>> results            = new EnumMap<CADDocCollections, Collection<? extends RevisionControlled>>(CADDocCollections.class);

        for (CADDocCollections cadDocCollection : colltypes) {
            resultList = collector.getResults(new WTHashSet(), cadDocCollection.name());

            switch (cadDocCollection) {
              case WTDOCUMENTS :
                  if(objRefs) {
                	  filteredResultList = resultList.subCollection(WTDocument.class);
                  } else {
                      filteredResultList = resultList.subCollection(WTDocument.class).persistableCollection();
                  }
                  results.put(CADDocCollections.WTDOCUMENTS, filteredResultList);
                  break;
              case FT_GENERICS :
                  if(objRefs) {
                	  filteredResultList = resultList.subCollection(EPMDocument.class);
                  } else {
                      filteredResultList = resultList.subCollection(EPMDocument.class).persistableCollection();
                  }
                  results.put(CADDocCollections.FT_GENERICS, filteredResultList);

                  break;

              case FT_GENERICS_ONLY_FOR_SEEDS :
                  if(objRefs) {
                	  filteredResultList = resultList.subCollection(EPMDocument.class);
                  } else {
                      filteredResultList = resultList.subCollection(EPMDocument.class).persistableCollection();
                  }
                  results.put(CADDocCollections.FT_GENERICS_ONLY_FOR_SEEDS, filteredResultList);

                  break;

              case FT_INSTANCES :
            	  if(objRefs) {
                	  filteredResultList = resultList.subCollection(EPMDocument.class);
                  } else {
                      filteredResultList = resultList.subCollection(EPMDocument.class).persistableCollection();
                  }
                  results.put(CADDocCollections.FT_INSTANCES, filteredResultList);

                  break;

              case FT_INSTANCES_ONLY_FOR_SEEDS :
            	  if(objRefs) {
                	  filteredResultList = resultList.subCollection(EPMDocument.class);
                  } else {
                      filteredResultList = resultList.subCollection(EPMDocument.class).persistableCollection();
                  }
                  results.put(CADDocCollections.FT_INSTANCES_ONLY_FOR_SEEDS, filteredResultList);

                  break;

              case DRAWINGS :
            	  if(objRefs) {
                	  filteredResultList = resultList.subCollection(EPMDocument.class);
                  } else {
                      filteredResultList = resultList.subCollection(EPMDocument.class).persistableCollection();
                  }
                  results.put(CADDocCollections.DRAWINGS, filteredResultList);

                  break;

              case DRAWINGS_ONLY_FOR_SEEDS :
            	  if(objRefs) {
                	  filteredResultList = resultList.subCollection(EPMDocument.class);
                  } else {
                      filteredResultList = resultList.subCollection(EPMDocument.class).persistableCollection();
                  }
                  results.put(CADDocCollections.DRAWINGS_ONLY_FOR_SEEDS, filteredResultList);

                  break;

              case ASSOCIATED_WTPARTS :
                  // WTKeyedMap docsToParts = collector.getJointValues(new WTKeyedHashMap(), cadDocCollection.name());
                  // removes Master object from result in case of access issues.
                  if(objRefs) {
                	  filteredResultList = resultList.subCollection(WTPart.class);
                  } else {
                      filteredResultList = resultList.subCollection(WTPart.class).persistableCollection();
                  }
                  results.put(CADDocCollections.ASSOCIATED_WTPARTS, filteredResultList);

                  break;

              case ASSOCIATED_WTPARTS_ONLY_FOR_SEEDS :
                  // removes Master object from result in case of access issues.
            	  if(objRefs) {
                	  filteredResultList = resultList.subCollection(WTPart.class);
                  } else {
                      filteredResultList = resultList.subCollection(WTPart.class).persistableCollection();
                  }
                  results.put(CADDocCollections.ASSOCIATED_WTPARTS_ONLY_FOR_SEEDS, filteredResultList);

                  break;

              case DEPENDENT_EPMDOCS :
                  // removes Master object from result in case of access issues.
                  if(objRefs) {
                	  filteredResultList = resultList.subCollection(EPMDocument.class);
                  } else {
                      filteredResultList = resultList.subCollection(EPMDocument.class).persistableCollection();
                  }
                  results.put(CADDocCollections.DEPENDENT_EPMDOCS, filteredResultList);

				break;

			case CATIAV5_ADDITIONS:
				// removes Master object from result in case of access issues.
				if(objRefs) {
              	  filteredResultList = resultList.subCollection(EPMDocument.class);
                } else {
                    filteredResultList = resultList.subCollection(EPMDocument.class).persistableCollection();
                }
				results.put(CADDocCollections.CATIAV5_ADDITIONS, filteredResultList);

				break;

			default:
				break;
            }
        }

        return results;
    }

    /**
     * First it retrieves all associated objects.<br>
     * A filter is finally applied to only return the desired objects defined by the given CADDocAssociationType.<br>
     * <br>
     * If the calling code is running inside a transaction and getAssociatedEPMs is called at least twice<br>
     * the previous cached map is reused and not called again.<br>
     * For the keys the passed parts list is used.<br>
     * 
     * TODO logic is not yet verified!     
     * @param type
     * @param parts
     *
     * @return
     *
     * @throws WTException
     */
    @SuppressWarnings("unchecked")
	@ServerOnly
    public static Collection<EPMDocument> getAssociatedEPMs(CADDocAssociationType type, WTPart... parts) throws WTException {
		Transaction trx = Transaction.getCurrentTransaction();
		if (trx != null) {
			Map<CADDocAssociationType, Collection<EPMDocument>> existingMap = (Map<CADDocAssociationType, Collection<EPMDocument>>) Transaction.getInContext(parts, false, false);
			if (existingMap != null) {
				return existingMap.get(type);
			}
		}

		Map<CADDocAssociationType, Collection<EPMDocument>> typedMap = getAssociatedEPMs((EPMWorkspace) null, parts);
		if (trx != null) {
			trx.getLocalMap().put(parts, typedMap);
		}
		return typedMap.get(type);
    }

    /**
     * <p>
     * <p>
     * @param parts
     * @param ws (optional)
     *
     * @return typed Collection of EPMDocument(s). Internally a WTArrayList is returned.
     *
     * @throws WTException
     */
    @ServerOnly
    public static Map<CADDocAssociationType, Collection<EPMDocument>> getAssociatedEPMs(EPMWorkspace ws, WTPart... parts) throws WTException {
        logger.debug("Getting active (also calculated ones) or passive associated CAD documents");

        EPMNavigator navigator = new EPMNavigator();

        /**
         * getting navigation configuration with latest ConfigSpec
         */
        Configuration     config       = newNavConfiguration(null, ws, false);
        AssociatedCADDocs relationship = null;

        for (CADDocAssociationType assoType : CADDocAssociationType.values()) {
            relationship = new AssociatedCADDocs();
            relationship.setConfiguration(config);

            switch (assoType) {

              /**
               * Calculated EPMBuildRule Link filters
               */
              case OWNER :
                  relationship.setTypes(Type.ACTIVE);

                  Filter FILTER_OWNER = new Filter(ClassAlias.LINK, EPMBuildRule.BUILD_TYPE, Condition.EQUAL, (EPMBuildRule.BUILD_STRUCTURE | EPMBuildRule.BUILD_ATTRIBUTES | EPMBuildRule.CAD_REPRESENTATION));

                  relationship.filterBy(FILTER_OWNER);

                  break;

              case CONTRIBUTING_IMAGE :
                  relationship.setTypes(Type.ACTIVE);

                  Filter FILTER_CONTRIBUTING_IMAGE = new Filter(ClassAlias.LINK, EPMBuildRule.BUILD_TYPE, Condition.EQUAL, (EPMBuildRule.BUILD_ATTRIBUTES | EPMBuildRule.CAD_REPRESENTATION));

                  relationship.filterBy(FILTER_CONTRIBUTING_IMAGE);

                  break;

              case CONTRIBUTING_CONTENT :
                  relationship.setTypes(Type.ACTIVE);

                  Filter FILTER_CONTRIBUTING_CONTENT = new Filter(ClassAlias.LINK, EPMBuildRule.BUILD_TYPE, Condition.EQUAL, EPMBuildRule.BUILD_ATTRIBUTES);

                  relationship.filterBy(FILTER_CONTRIBUTING_CONTENT);

                  break;

              case CONTENT :
                  relationship.setTypes(Type.PASSIVE);

                  break;

              case IMAGE :
                  relationship.setTypes(Type.ACTIVE);

                  Filter FILTER_IMAGE = new Filter(ClassAlias.LINK, EPMBuildRule.BUILD_TYPE, Condition.EQUAL, EPMBuildRule.CAD_REPRESENTATION);

                  relationship.filterBy(FILTER_IMAGE);

                  break;

              case ALL :
                  relationship.setTypes(Type.ACTIVE, Type.PASSIVE);

                  Filter FILTER_ALL_ROLES = new Filter(ClassAlias.LINK, EPMBuildRule.BUILD_TYPE, Condition.EQUAL, EPMBuildRule.ALL_BUILD_ROLES);

                  relationship.filterBy(FILTER_ALL_ROLES);

                  break;

              case DRAWINGS :
                  relationship.setTypes(AssociatedCADDocs.Type.PASSIVE, AssociatedCADDocs.Type.IMPLICIT);
                  relationship.filterBy(AssociatedCADDocs.DRAWINGS_ONLY);
              default :
                  break;
            }

            navigator.include(assoType.name(), Connector.SEED, relationship);
        }

        StandardCollector collector = new StandardCollector(CollectItem.OTHERSIDE);

        navigator.execute(collector, HelperBase.toWTList((Object[]) parts));

        EnumMap<CADDocAssociationType, Collection<EPMDocument>> results = new EnumMap<CADDocAssociationType, Collection<EPMDocument>>(CADDocAssociationType.class);

        for (CADDocAssociationType assoType : CADDocAssociationType.values()) {
            WTArrayList              epmList         = collector.getResults(new WTArrayList(), assoType.name());
            // removes Master object from result in case of access issues.
            WTCollection filteredCol = epmList.subCollection(EPMDocument.class);
            @SuppressWarnings("unchecked")    
            Collection<EPMDocument> epmListfiltered = filteredCol.persistableCollection();

            results.put(assoType, epmListfiltered);
        }

        return results;
    }

    @SuppressWarnings("unchecked")
	@ServerOnly
    public static Collection<WTPart> getAssociatedWTParts(boolean active, boolean passive, boolean implicit, EPMDocument...docs) throws WTException {

        CADAssociatedParts associatedParts = new CADAssociatedParts();
        
        Collection<CADAssociatedParts.Type> types = new ArrayList<CADAssociatedParts.Type>(3);
        
        if (active) {
            types.add(CADAssociatedParts.Type.ACTIVE);
        }
        
        if (passive) {
            types.add(CADAssociatedParts.Type.PASSIVE);
        }
        
        if (implicit) {
            types.add(CADAssociatedParts.Type.IMPLICIT);
            associatedParts.filterByType(CADAssociatedParts.Type.IMPLICIT, CADAssociatedParts.DRAWINGS_ONLY);
        }           

        if (types.size() == 0) {
            //No association types specified to navigate
            return CollectionsHelper.EMPTY_COLLECTION;
        }
        
        associatedParts.setTypes(types.toArray(new CADAssociatedParts.Type[types.size()]));
        WTCollection associatedObjects = EPMNavigateHelper.navigate(
        				new WTArrayList(Arrays.asList((Object[]) docs)),
                        associatedParts,
                        CollectItem.OTHERSIDE).getResults(new WTArrayList());
        
        return associatedObjects.subCollection(WTPart.class).persistableCollection();
    }
    
    @SuppressWarnings("unchecked")
	@ServerOnly
    public static Collection<EPMDocument> getAssociatedEPMs(boolean active, boolean passive, boolean implicit, WTPart...parts) 
    throws WTException {

        AssociatedCADDocs associatedDocs = new AssociatedCADDocs();
        
        Collection<AssociatedCADDocs.Type> types = new ArrayList<AssociatedCADDocs.Type>(3);
        
        if (active) { 
            types.add(AssociatedCADDocs.Type.ACTIVE);
        }
        
        if (passive) {
            types.add(AssociatedCADDocs.Type.PASSIVE);
        }
        
        if (implicit) {
            types.add(AssociatedCADDocs.Type.IMPLICIT);
            associatedDocs.filterByType(AssociatedCADDocs.Type.IMPLICIT, AssociatedCADDocs.DRAWINGS_ONLY);
        }           
        
        if (types.size() == 0) {
            //No association type specified to navigate
            return CollectionsHelper.EMPTY_COLLECTION;
        }
        
        associatedDocs.setTypes(types.toArray(new AssociatedCADDocs.Type[types.size()]));
        WTCollection associatedObjects = EPMNavigateHelper.navigate(
                        HelperBase.toWTList((Object[]) parts),
                        associatedDocs,
                        CollectItem.OTHERSIDE).getResults(new WTArrayList());
        
        return associatedObjects.subCollection(EPMDocument.class);
    }

   //#############################################################################
    
	private static class Relationships {

		public static LinkRelationship newCATIAV5Additions(Configuration config) throws WTException {
			/*
			 * EPMMemberLink navigation
			 */
			LinkRelationship additions = new LinkRelationship(EPMDocument.class, EPMDocument.class, EPMMemberLink.class);
			/*
			 * Apply a filter in order to restrict the search to only links
			 * related CCP,KWE and MML Links.
			 */
			Filter fCCP = new Filter(ClassAlias.LINK, EPMDependencyLink.DEP_TYPE, Condition.EQUAL, Integer.valueOf(nd3pobject_j01.DEP_T_3P_CATIA_V5_CCP));
			Filter fKWE = new Filter(ClassAlias.LINK, EPMDependencyLink.DEP_TYPE, Condition.EQUAL, Integer.valueOf(nd3pobject_j01.DEP_T_3P_CATIA_V5_KWE));
			Filter fMML = new Filter(ClassAlias.LINK, EPMDependencyLink.DEP_TYPE, Condition.EQUAL, Integer.valueOf(nd3pobject_j01.DEP_T_3P_CATIA_V5_MML));
			additions.filterBy(fCCP, fKWE, fMML);

			/*
			 * Apply the given configuration
			 */
			additions.setConfiguration(config);

			return additions;
		}
	}

	// #############################################################################
	public static void main(String[] args){
		
		
    	//Testing
    	ResourceBundle cadDocResource_de = ResourceBundle.getBundle("wt.epm.EPMDocumentTypeRB", Locale.GERMAN);
    	ResourceBundle cadDocResource_en = ResourceBundle.getBundle("wt.epm.EPMDocumentTypeRB", Locale.ENGLISH);
    	Enumeration<String> en = cadDocResource_de.getKeys();
    	java.util.SortedSet<Integer> sset = new TreeSet<Integer>();
    	while (en.hasMoreElements()) {
    		sset.add(new Integer( en.nextElement()));
    	}
    	System.out.printf("%4s  -45s %s%n", "key", "(DE)", "(EN)");
    	for (Integer key : sset) {
    		System.out.printf("%4s  -45s %s%n", key, cadDocResource_de.getString(key.toString()), cadDocResource_en.getString(key.toString()));
			//System.out.print(key + ":  \t" + cadDocResource_de.getString(key.toString()) + "(DE) \t\t\t\t\t" + cadDocResource_en.getString(key.toString()) + "(EN)"); 
		}
    }
	
	

}
