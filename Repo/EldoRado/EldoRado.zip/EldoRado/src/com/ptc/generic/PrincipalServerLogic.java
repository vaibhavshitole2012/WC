/* bcwti
 *
 * Copyright (c) 2014 Parametric Technology Corporation (PTC). All Rights
 * Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */
package com.ptc.generic;

import java.util.Enumeration;

import org.apache.log4j.Logger;

import wt.inf.container.WTContainerHelper;
import wt.org.DirectoryContextProvider;
import wt.org.OrganizationServicesHelper;
import wt.org.WTPrincipal;
import wt.org.WTUser;
import wt.util.WTException;

/**
 * @author AB
 *
 */
public class PrincipalServerLogic {
	public static final String svnUrl = "$URL: http://127.0.0.1/svn/KB_04082016/components/Generic-Utilities/src/com/ptc/generic/PrincipalServerLogic.java $";
	public static final String svnRev = "$Revision: 1.1.1.3 $ $Date: 2015/12/10 21:01:36IST $";

	private static final String CLASSNAME = PrincipalServerLogic.class.getName();
	private static Logger logger = Logger.getLogger(CLASSNAME);
	
	
	/**
	 * get the user oid of the given name
	 * 
	 * @param fullUserName
	 *            - e.g. Projektabwickler01
	 * @return user oid
	 */
	public static WTPrincipal getUser(String fullUserName) throws WTException {
		return getUser(fullUserName, WTUser.FULL_NAME);
	}
	
	/**
	 * get the user oid of the given name
	 * 
	 * @param fullUserName
	 *            - e.g. Projektabwickler01
	 * @return user oid
	 */
	public static WTPrincipal getUser(String fullUserName, String attribute) throws WTException {
		DirectoryContextProvider contextProvider = WTContainerHelper.service.getExchangeContainer().getContextProvider();
		Enumeration<WTPrincipal> eUsers = OrganizationServicesHelper.manager.findLikeUsers(attribute, fullUserName, contextProvider);
		while (eUsers.hasMoreElements()) {
			WTPrincipal p = eUsers.nextElement();
			logger.debug("found user: " + p);
			return p;
		}

		return null;
	}
}
