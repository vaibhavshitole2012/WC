package com.ptc.generic;

import com.ptc.ssp.util.SoftTypeHelper;
import java.util.Arrays;
import wt.fc.Persistable;
import wt.util.WTException;
import wt.vc.baseline.Baseline;

public class BaselineServerLogic {

    /**
     * converts the given object o (either String, WTReference, or WTPart) to a Baseline
     * if shortSofttypeNames isn't empty, then check if the converted object is of one of the given softtypes
     * method should only be used on server!
     * 
     * @param o 
     * @param shortSofttypeNames array of short names of softtype without full hierarchy, e.g. VWConstants.SOFTTYPE_BKBASELINE
     * @return a Baseline
     * @throws WTException if the given object can not be converted to a Baseline, or if the Baseline has not the required softtype
     */
	public static Baseline convertToBaseline(Object o, String[] shortSofttypeNames) throws WTException {
		Baseline bl = null;
		
		try {
			Persistable p = FcHelper.convertToPersistable(o);
			if(p instanceof Baseline) {
				bl = (Baseline)p;
			} else {
				throw new WTException("BaselineServerLogic.convertToBaseline: given object does not represent a Baseline: p=" + p + " p.class=" + p.getClass().getName());
			}

			//check for softtype if it was given
			if(shortSofttypeNames!=null && shortSofttypeNames.length!=0) {
				//there are softtype names given
				boolean foundCorrectST = false;
				for(String stname : shortSofttypeNames) {
					if(SoftTypeHelper.isType(bl, stname)) {
						foundCorrectST = true;
						break;
					}
				}
				if(!foundCorrectST) {
					throw new WTException("BaselineServerLogic.convertToBaseline: given object is Baseline but does not represent one of the needed softtypes: neededShortSTName="
							+ Arrays.toString(shortSofttypeNames) + " object.fullSTName=" + SoftTypeHelper.getTypeName(bl));
				}
			}
		} catch(Exception e) {
                    if (e instanceof WTException) {
                        throw (WTException) e;
                    } else {
                        throw new WTException(e);
                    }
		}
		return bl;
	}
}
