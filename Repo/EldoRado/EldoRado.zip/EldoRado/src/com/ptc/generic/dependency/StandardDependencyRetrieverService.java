/*
 * @(#)StandardDependencyRetrieverService.java   11/09/26
 *
 * Copyright (c) 2004 Parametric Technology Corporation (PTC).
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC.
 * You shall not disclose such confidential information and shall use it
 * only in accordance with the terms of the license agreement.
 *
 * Alfred Weyerer
 */
package com.ptc.generic.dependency;

import java.io.Serializable;
import java.util.Collection;
import java.util.Hashtable;
import java.util.Map;
import java.util.Vector;

import org.apache.log4j.Logger;

import com.ptc.generic.VersionUtil;
import com.ptc.mvc.util.ConversionHelper;
import com.ptc.service.annotations.GenerateService;

import ext.tools.ToolUtils;
import wt.epm.EPMCADNamespace;
import wt.epm.EPMDocConfigSpec;
import wt.epm.EPMDocument;
import wt.epm.EPMDocumentMaster;
import wt.epm.EPMDocumentType;
import wt.epm.familytable.EPMSepFamilyTable;
import wt.epm.interfaces.WorkspaceTrackable;
import wt.epm.retriever.DependencyRetrieverHelper;
import wt.epm.retriever.EPMRetrieverCache;
import wt.epm.retriever.FamilyTableResult;
import wt.epm.retriever.ResultList;
import wt.epm.structure.EPMContainedIn;
import wt.epm.structure.EPMMemberLink;
import wt.epm.structure.EPMReferenceLink;
import wt.epm.structure.EPMStructureHelper;
import wt.epm.structure.EPMVariantLink;
import wt.epm.workspaces.EPMAsStoredConfigSpec;
import wt.epm.workspaces.EPMAsStoredHelper;
import wt.fc.QueryResult;
import wt.fc.ResultProcessor;
import wt.fc.collections.WTArrayList;
import wt.fc.collections.WTCollection;
import wt.fc.collections.WTSet;
import wt.services.StandardManager;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.vc.VersionControlHelper;
import wt.vc.baseline.Baseline;
import wt.vc.baseline.BaselineHelper;
import wt.vc.config.ConfigSpec;
import wt.vc.config.LatestConfigSpec;

/**
 * Provides service methods to retrieve dependent EPMDocuments.<br>
 * relationships between EPMDocuments <br>
 * EPMMemberLink, EPMReferenceLink, EPMVariantLink:<br>
 * <br>
 * EPMMemberLink.class - assembly with epm<br>
 * EPMReferenceLink.class - epm with drawing<br>
 * EPMVariantLink.class - epm with family table (epm), e.g. generic with instance<br>
 *
 * @version    Enter version here..., 11/09/26
 * @author     Alfred Weyerer
 */
@GenerateService
public class StandardDependencyRetrieverService extends StandardManager implements DependencyRetrieverService, Serializable {

	public static final String  svnRev    = "$Revision: 1.2.1.3 $ $Date: 2016/03/17 19:31:31IST $";
    public static final String  svnUrl    = "$URL: http://127.0.0.1/svn/KB_04082016/components/Generic-Utilities/src/com/ptc/generic/dependency/StandardDependencyRetrieverService.java $";
    
    // --- Attribute Section ---
    private static final long serialVersionUID = -8387680112118824547L;
    private static final String CLASSNAME = StandardDependencyRetrieverService.class.getName();
    private static final Logger logger = Logger.getLogger(CLASSNAME);
    private static final Logger loggerDrwFor3D = Logger.getLogger(CLASSNAME + "_DrwFor3D");
    
    public static final int MAX_RETRIEVAL_DEPTH = -1; 

    public static enum ConfSpec {
        LATEST, ASSTORED
    }

    /**
     * Default factory for the class.
     *
     * @return    StandardDependencyRetrieverService instance
     *
     * @throws WTException
     */
    public static StandardDependencyRetrieverService newStandardDependencyRetrieverService() throws WTException {
        StandardDependencyRetrieverService instance = new StandardDependencyRetrieverService();

        instance.initialize();

        return instance;
    }

    /**
     * Returns a {@link Collection} of dependent {@link EPMDocument} & {@link EPMSepFamilyTables} instances based on the given {@link EPMDocument} instance.<br>
     * The {@link ConfigSpec} is used of the pathed parameter {@code configSpec}.<br>
     * The documents are collected by recognizing required dependents.<br>
     * Drawings are excluded.
     *
     * @param epmDocs as Collection
     * @param confSpec enum
     *
     * @return A {@link Collection} of {@link EPMDocument} & {@link EPMSepFamilyTables} instances
     *
     * @throws WTException
     * @throws WTPropertyVetoException
     */
	public Collection<WorkspaceTrackable> getDependentEPMs(Collection<EPMDocument> epmDocs, ConfSpec configSpec) throws WTException {
        return getDependentEPMs(epmDocs, configSpec, true, false, true);
    }
    
    /**
     * Returns a {@link Collection} of dependent {@link EPMDocument}s based on the given parameters.
     *
     *
     * @param epmDocs: The base {@link EPMDocument}'s as Collection
     * @param configSpec: e.g.: {@link EPMAsStoredConfigSpec} or {@link LatestConfigSpec}
     * @param collectRequired: if <code>true</code> searches <code>REQUIRED_DEPENDENTS</code> else <code>ALL_DEPENDENTS</code>.
     * @param includeDrawings: if <code>true</code> includes DRWs in the result.
     * @param includeInstances: if <code>true</code> includes family tables (EPMSepFamilyTable & EPMDocument classes)
     *
     * @return {@link Collection}
     *
     * @throws WTException
     * @throws WTPropertyVetoException
     */
	public Collection<WorkspaceTrackable> getDependentEPMs(Collection<EPMDocument> epmDocs, ConfSpec configSpec, boolean collectRequired, boolean includeDrawings, boolean includeFTables) throws WTException {
    	WTArrayList output = new WTArrayList();
    	return getDependentEPMs(epmDocs, configSpec, collectRequired, includeDrawings, includeFTables, output, MAX_RETRIEVAL_DEPTH);
    }
    
    /**
     * Returns a {@link Collection} of dependent {@link EPMDocument}s based on the given parameters.
     *
     *
     * @param epmDocs: The base {@link EPMDocument}'s as Collection
     * @param configSpec: e.g.: {@link EPMAsStoredConfigSpec} or {@link LatestConfigSpec}
     * @param collectRequired: if <code>true</code> searches <code>REQUIRED_DEPENDENTS</code> else <code>ALL_DEPENDENTS</code>.
     * @param includeDrawings: if <code>true</code> includes DRWs in the result.
     * @param includeInstances: if <code>true</code> includes family tables (EPMSepFamilyTable & EPMDocument classes)
     * @param retrievalDepth : specifies the number of levels which will be retrieved. e.g. 1 = only first level (current asm); -1 = all
     * @param 
     *
     * @return {@link Collection}
     *
     * @throws WTException
     * @throws WTPropertyVetoException
     */
	public Collection<WorkspaceTrackable> getDependentEPMs(Collection<EPMDocument> epmDocs, ConfSpec configSpec, boolean collectRequired, boolean includeDrawings, boolean includeFTables, int retrievalDepth) throws WTException {
    	WTArrayList output = new WTArrayList();
    	return getDependentEPMs(epmDocs, configSpec, collectRequired, includeDrawings, includeFTables, output, retrievalDepth);
    }
    
    /**
     * Returns a {@link Collection} of dependent {@link EPMDocument}s based on the given parameters.
     *
     *
     * @param epmDocs: The base {@link EPMDocument}'s as Collection
     * @param configSpec : e.g.: {@link EPMAsStoredConfigSpec} or {@link LatestConfigSpec}
     * @param collectRequired : if <code>true</code> searches <code>REQUIRED_DEPENDENTS</code> else <code>ALL_DEPENDENTS</code>.
     * @param includeDrawings : if <code>true</code> includes DRWs in the result.
     * @param includeFTables : if <code>true</code> includes family tables (EPMSepFamilyTable & EPMDocument classes)
     * @param output : if <code>WTCollection</code> WTCollection instance to be filled. This Collection is returned as <code>Collection<code>
     *
     * @return {@link Collection}
     *
     * @throws WTException
     * @throws WTPropertyVetoException
     */
	public Collection<WorkspaceTrackable> getDependentEPMs(Collection<EPMDocument> epmDocs, ConfSpec configSpec, boolean collectRequired, boolean includeDrawings, boolean includeFTables, WTArrayList output) throws WTException {
    	return getDependentEPMs(epmDocs, configSpec, collectRequired, includeDrawings, includeFTables, output, MAX_RETRIEVAL_DEPTH);
    }
    
    /**
     * Returns a {@link Collection} of dependent {@link EPMDocument}s based on the given parameters.
     *
     *
     * @param epmDocs: The base {@link EPMDocument}'s as Collection
     * @param configSpec : e.g.: {@link EPMAsStoredConfigSpec} or {@link LatestConfigSpec}
     * @param collectRequired : if <code>true</code> searches <code>REQUIRED_DEPENDENTS</code> else <code>ALL_DEPENDENTS</code>.
     * @param includeDrawings : if <code>true</code> includes DRWs in the result.
     * @param includeFTables : if <code>true</code> includes family tables (EPMSepFamilyTable & EPMDocument classes)
     * @param output : if <code>WTCollection</code> WTCollection instance to be filled. This Collection is returned as <code>Collection<code>
     * @param retrievalDepth : specifies the number of levels which will be retrieved. e.g. 1 = only first level (current asm); -1 = all
     *
     * @return {@link Collection}
     *
     * @throws WTException
     * @throws WTPropertyVetoException
     */
	@SuppressWarnings("unchecked")
	public Collection<WorkspaceTrackable> getDependentEPMs(Collection<EPMDocument> epmDocs, ConfSpec configSpec, boolean collectRequired, boolean includeDrawings, boolean includeFTables, WTArrayList output, int retrievalDepth) throws WTException {
    	Collection<WorkspaceTrackable> result = null;
    	
    	try {
    		WTArrayList epms = (WTArrayList) getDependentEPMs(epmDocs, configSpec, collectRequired, includeDrawings, includeFTables, (ResultProcessor)output, retrievalDepth);
            if (epms != null) {
                /*
                 * TODO ECA 4.2: don't think that's good idea to cast the
                 * AbstractWTCollection$PersistableCollection to the
                 * Collection<WorkspaceTrackable>. Not each Persistable
                 * is WorkspaceTrackable. This lead to ClassCastExceptions!
                 */
                result = epms.persistableCollection();
            }
        } catch (Exception e) {
            logger.error("While retrieving dependent EPMDocuments an error occured", e);
            throw new WTException(e);
        }

        logger.debug(result.size() + " collected.");

        return result;
    }
    
    /**
     * Returns a {@link Collection} of dependent {@link EPMDocument}s based on the given parameters.
     *
     *
     * @param epmDocs: The base {@link EPMDocument}'s as Collection
     * @param configSpec : e.g.: {@link EPMAsStoredConfigSpec} or {@link LatestConfigSpec}
     * @param collectRequired : if <code>true</code> searches <code>REQUIRED_DEPENDENTS</code> else <code>ALL_DEPENDENTS</code>.
     * @param includeDrawings : if <code>true</code> includes DRWs in the result.
     * @param includeFTables : if <code>true</code> includes family tables (EPMSepFamilyTable & EPMDocument classes)
     * @param output : if <code>ResultProcessor</code> A ResultProcessor implemetation. This implementation is returned but filled.
     *
     * @return {@link Collection}
     *
     * @throws WTException
     * @throws WTPropertyVetoException
     */
	public ResultProcessor getDependentEPMs(Collection<EPMDocument> epmDocs, ConfSpec configSpec, boolean collectRequired, boolean includeDrawings, boolean includeFTables, ResultProcessor output) throws WTException {
		return getDependentEPMs(epmDocs, configSpec, collectRequired, includeDrawings, includeFTables, output, MAX_RETRIEVAL_DEPTH);
	}
    
    /**
     * Returns a {@link Collection} of dependent {@link EPMDocument}s based on the given parameters.
     *
     *
     * @param epmDocs: The base {@link EPMDocument}'s as Collection
     * @param configSpec : e.g.: {@link EPMAsStoredConfigSpec} or {@link LatestConfigSpec}
     * @param collectRequired : if <code>true</code> searches <code>REQUIRED_DEPENDENTS</code> else <code>ALL_DEPENDENTS</code>.
     * @param includeDrawings : if <code>true</code> includes DRWs in the result.
     * @param includeFTables : if <code>true</code> includes family tables (EPMSepFamilyTable & EPMDocument classes)
     * @param output : if <code>ResultProcessor</code> A ResultProcessor implemetation. This implementation is returned but filled.
     * @param retrievalDepth : specifies the number of levels which will be retrieved. e.g. 1 = only first level (current asm); -1 = all
     *
     * @return {@link Collection}
     *
     * @throws WTException
     * @throws WTPropertyVetoException
     */
	public ResultProcessor getDependentEPMs(Collection<EPMDocument> epmDocs, ConfSpec configSpec, boolean collectRequired, boolean includeDrawings, boolean includeFTables, ResultProcessor output, int retrievalDepth) throws WTException {
        
        Class<?>[] EPMDOCUMENT_LINKS = new Class<?>[]{EPMMemberLink.class};

        if (includeDrawings) {
            EPMDOCUMENT_LINKS = addToArray(new Class<?>[]{EPMReferenceLink.class}, EPMDOCUMENT_LINKS);
        }
        if (includeFTables) {
            EPMDOCUMENT_LINKS = addToArray(new Class<?>[]{EPMVariantLink.class}, EPMDOCUMENT_LINKS);
        }

        Class<?>[] EPMDOCUMENT_NODES = new Class<?>[]{EPMDocument.class};
        
        WTCollection seeds = null;
        if(epmDocs instanceof WTCollection) {
			seeds = (WTCollection) epmDocs;
		} else{
        	seeds = new WTArrayList(epmDocs);
		}
        
        ConfigSpec epmcs = null;
        if (configSpec != null && configSpec.equals(ConfSpec.LATEST)) {
            epmcs = new LatestConfigSpec();
        } else if (configSpec != null && configSpec.equals(ConfSpec.ASSTORED)) {
            EPMAsStoredConfigSpec epmscs;
            try {
                epmscs = EPMAsStoredConfigSpec.newEPMAsStoredConfigSpec(ConversionHelper.getInstance().toList((Object)seeds));
            } catch (WTPropertyVetoException e) {
                logger.error("Could not create asStored configuration.", e);
                throw new WTException(e);
            }
            epmcs = EPMDocConfigSpec.newEPMDocConfigSpec(epmscs);
        } else {
            return new WTArrayList();
        }
        
        
        try {
        	output = findEPMDeps(seeds, epmcs, collectRequired, includeDrawings, includeFTables, EPMDOCUMENT_NODES, EPMDOCUMENT_LINKS, output, retrievalDepth);
        } catch (Exception e) {
            logger.error("While retrieving dependent EPMDocuments an error occured", e);
        }

        logger.debug(output.size() + " collected.");

        return output;
    }
	
    /**
     * Suggestion of gettting a 3D Model on a given drawing.
     * It just a demo method! <br>
     * <b>Do not without testing!!!!<b>
     *
     * supported API false
     *
     * @param cad3dDoc
     * @param configSpec
     * @return
     * @throws WTException
     */
	public Collection<WorkspaceTrackable> getDrawingsFor3D(EPMDocument cad3dDoc, ConfSpec configSpec) throws WTException {
        Class<?>[]   EPMDOCUMENT_LINKS = new Class<?>[] {EPMReferenceLink.class};   //Links to navigate
        Class<?>[]   EPMDOCUMENT_NODES = new Class<?>[] {EPMDocument.class};		//root doc
        WTCollection seeds             = new WTArrayList();

        seeds.add(cad3dDoc);

        ConfigSpec epmcs = null;
        if ((configSpec != null) && configSpec.equals(ConfSpec.LATEST)) {
            epmcs = new LatestConfigSpec();
        } else if ((configSpec != null) && configSpec.equals(ConfSpec.ASSTORED)) {
            EPMAsStoredConfigSpec epmscs;
            try {
                epmscs = EPMAsStoredConfigSpec.newEPMAsStoredConfigSpec(cad3dDoc);
            } catch (WTPropertyVetoException e) {
                logger.error("Could not create asStored configuration.", e);
                throw new WTException(e);
            }
            epmcs = EPMDocConfigSpec.newEPMDocConfigSpec(epmscs);
        } else {
            return new Vector<WorkspaceTrackable>();
        }
        /*
         * Configuring retrieving helper
         */
        DependencyRetrieverHelper helper = new DependencyRetrieverHelper(seeds, epmcs);

        helper.addAuxConfigSpec(epmcs);
        helper.setLinks(EPMDOCUMENT_LINKS);
        helper.setIncludeDependents(DependencyRetrieverHelper.REQUIRED_DEPENDENTS);
        helper.setIncludeDrawings(DependencyRetrieverHelper.ALL_DRAWINGS);
        helper.setIncludeDrawingDependents(DependencyRetrieverHelper.DRAWING_ALL_DEPENDENTS);
        helper.setIncludeFTMembers(DependencyRetrieverHelper.NO_FT_MEMBERS);
        /*
         * Define the depth.
         * Just navigate ONE level.
         */
        int level = 0;
        helper.setRepeatLimit(level + 1);
        /*
         * Initiating Cache
         */
        EPMRetrieverCache cache;
        try {
            cache = helper.getDependencies();
        } catch (WTPropertyVetoException e) {
            throw new WTException(e);       }
        /*
         * Populating dependencies into result list.
         */
        ResultList results = new ResultList();
        cache.populate(results, EPMDOCUMENT_NODES, EPMDOCUMENT_LINKS);

        WTCollection nodes = results.getNodes();
        // casting to return type and getting persistable collection instead of refs
        @SuppressWarnings("unchecked") Collection<WorkspaceTrackable> m3Ds = nodes.persistableCollection();

        // TODO: a possible filter on EPMDocument with DocumentType drawing
        return m3Ds;
    }
    
	/**
	 * Returns the 'drawings' that are connected with the given EPMDocument.
	 *  
	 * Navigates the EPMReferenceLink and only adds a drawing if the given EPMDocument is inside the AsStored-Baseline of the drawing 
	 * Might be enhanced in the future that it also returns drawings, when the given EPMDocument is not inside the AsStored Baseline of the drawing
	 * If multiple iterations/versions of the same drawing have AsStored Baselines that all contain the given EPMDocument,
	 * then the drawing with the highest version+iteration is returned.
	 *  
	 * @param epmDoc An EPMDocument that should represent a 3D model. This is not checked inside this method
	 * @param getLatestIfNotInAsStoredBL
	 * 
	 * @author lberger@ptc.com
	 */
	public Collection<EPMDocument> getDrawingsFor3D (EPMDocument epmDoc, boolean getLatestIfNotInAsStoredBL) throws WTException {
    	//lberger 20120807: this method was copied from old ECA code (StandardECEPMService) and modified.

    	// tempDrawingsMap helps to keep latest iterations of right drawings
    	// example: .asm A.3 has two EPMAsStoredConfig links to two iterations of 2D model,
    	// we should choose then the latest one
    	Map<String, EPMDocument> exactDrawingsMap = new Hashtable<String, EPMDocument>(); //key is EPMDocument.getNumber()
    	
    	//another map for those drawings that were not found via AsStoredBaseline. This is only used if getLatestIfNotInAsStoredBL=true
    	Map<String, EPMDocument> latestDrawingsMap = new Hashtable<String, EPMDocument>(); //key is EPMDocument.getNumber()
    	
    	//both above maps will be used at the end: if possible the entry from exactDrawingsMap is returned

    	// part 1 :
    	// - find drawings referenced by links starting from given 3D model
    	// - get EPMAsStoredConfig for the drawing and check if it contains given 3D model

    	//get EPMReferenceLinks starting from the master of given 3D model
    	//TODO ECA4.2 (low) performance: could filter on EPMDocumentType and DepType already here in query instead of checking later in the loop
    	QueryResult referenceLinks = EPMStructureHelper.service.navigateReferencedBy((EPMDocumentMaster)epmDoc.getMaster(), null, false);
    	loggerDrwFor3D.debug("for epmDoc=" + ToolUtils.prettyPrint(epmDoc, false) + " found referenceLinks.size(): " + referenceLinks.size());
    	// loop through all these EPMReferenceLinks

    	while (referenceLinks.hasMoreElements()) {
    		EPMReferenceLink erl = (EPMReferenceLink) referenceLinks.nextElement();
    		if(loggerDrwFor3D.isDebugEnabled()) {
    			loggerDrwFor3D.debug("reflink=" + ToolUtils.prettyPrint(erl) + " depType=" + erl.getDepType());
    		}
    		// choose only links with dependency type equal to 4 (for drawings)
    		if (erl.getDepType() == 4) {
    			try {
    				// get EPMDocument referenced by the link
    				EPMDocument drawing = erl.getReferencedBy();
    				if(loggerDrwFor3D.isDebugEnabled()) {
    					loggerDrwFor3D.debug("drawing=" + ToolUtils.prettyPrint(drawing) + " docType=" + drawing.getDocType().toString());
    				}
    				// process just drawings
    				if ("CADDRAWING".equals(drawing.getDocType().toString())) {
    					// get EPMAsStoredConfig object for the drawing
    					Baseline epmAsStoredConfig = EPMAsStoredHelper.getAsStoredConfig(drawing);
    					if (epmAsStoredConfig != null) {
    						if(loggerDrwFor3D.isDebugEnabled()) {
    							loggerDrwFor3D.debug("epmAsStoredConfig of drw: " + ToolUtils.prettyPrint(epmAsStoredConfig));
    						}
    						// check if given 3D is contained in this baseline
    						if (BaselineHelper.service.isInBaseline(epmDoc, epmAsStoredConfig)) {
    							// get the number of drawing - the key for tempDrawingsMap
    							String drawingNumber = drawing.getNumber();
    							loggerDrwFor3D.debug("given epmDoc is inside AsStoredBL of this drawing. drw.number=" + drawingNumber);
    							// create temporary Hashtable (drawing:note)
    							Hashtable<EPMDocument, String> tempDrawingWithNote = new Hashtable<EPMDocument, String>();
    							tempDrawingWithNote.put(drawing, "");
    							// if tempDrawingsMap does not contain value for the current drawing number add it
    							if (!exactDrawingsMap.containsKey(drawingNumber)) {
    								exactDrawingsMap.put(drawingNumber, drawing);
    								loggerDrwFor3D.debug("added to tempDrawingsMap: key=" + drawingNumber + " drw=" + drawing);
    							} else {
    								// if not check which iteration is higher and keep it
    								EPMDocument tempDrawing = exactDrawingsMap.get(drawingNumber);
    								Object[] tempDrawingVersionInfo = VersionUtil.getVersionIteration(tempDrawing);
    								//logger.debug("TEMP V.I: "+"("+tempDrawingVersionInfo[0].toString()+"."+tempDrawingVersionInfo[1].toString()+")");
    								Object[] drawingVersionInfo = VersionUtil.getVersionIteration(drawing);
    								//logger.debug("DRW V.I: "+"("+drawingVersionInfo[0].toString()+"."+drawingVersionInfo[1].toString()+")");
    								if (VersionUtil.compareTo(drawingVersionInfo, tempDrawingVersionInfo) > 0) {
    									exactDrawingsMap.put(drawingNumber, drawing);
    									loggerDrwFor3D.debug("replaced in tempDrawingsMap: key=" + drawingNumber + " with drw=" + drawing);
    								}
    							}
    						} else if(getLatestIfNotInAsStoredBL && VersionControlHelper.isLatestIteration(drawing)) {
    							loggerDrwFor3D.debug("given epmDoc is NOT inside AsStoredBL of this drawing. But drw is latest and getLatestIfNotInAsStoredBL=true. drw.number=" + drawing.getNumber());
    							latestDrawingsMap.put(drawing.getNumber(), drawing);
    						} else {
    							loggerDrwFor3D.debug("given epmDoc is NOT inside AsStoredBL of this drawing.");
    						}
    					} 
    				}
    			} catch (Exception exception) {
    				continue;
    			}
    		}
    	}
    	
    	//now check if we found some drawings that had not the same AsStored-BL as the active (3D) EPMDocument
    	if(getLatestIfNotInAsStoredBL) {
    		for(String drwNumber : latestDrawingsMap.keySet()) {
    			if(!exactDrawingsMap.containsKey(drwNumber)) {
    				exactDrawingsMap.put(drwNumber, latestDrawingsMap.get(drwNumber));
    				loggerDrwFor3D.debug("added a latest DRW without AsStoredBL to returned map: " + ToolUtils.prettyPrint(drwNumber, false));
    			}
    		}
    	}

    	if(loggerDrwFor3D.isDebugEnabled()) {
    		loggerDrwFor3D.debug("returning from getDrawingsFor3D: " + exactDrawingsMap.values());
    	}
    	return exactDrawingsMap.values();
    }

    /**
     * 
     * @param cadDocs
     * @param output
     * @return
     * @throws WTException
     */
	public Collection<EPMCADNamespace> getEPMCADNamespaces(Collection<EPMDocument> cadDocs, ResultProcessor output) throws WTException {
        Class<?>[]   EPMDOCUMENT_LINKS = new Class<?>[] {wt.epm.NamespaceMaster.class};  //Links to navigate
        Class<?>[]   EPMDOCUMENT_NODES = new Class<?>[] {EPMCADNamespace.class,};
        WTCollection seeds             = new WTArrayList();

        seeds.add(cadDocs);

        /*
         * Configuring retrieving helper
         */
        DependencyRetrieverHelper helper = new DependencyRetrieverHelper(seeds);

        helper.setLinks(EPMDOCUMENT_LINKS);
        /*
         * Define the depth.
         * Just navigate ONE level. should be enough!
         */
        int level = 0;
        helper.setRepeatLimit(level + 1);
        /*
         * Initiating Cache
         */
        EPMRetrieverCache cache;
        try {
            cache = helper.getDependencies();
        } catch (WTPropertyVetoException e) {
            throw new WTException(e);       }
        /*
         * Populating dependencies into result list.
         */
        ResultList results = new ResultList();
        cache.populate(results, EPMDOCUMENT_NODES, EPMDOCUMENT_LINKS);

        WTCollection nodes = results.getNodes();
        // casting to return type and getting persistable collection instead of refs
        @SuppressWarnings("unchecked") Collection<EPMCADNamespace> persistables = nodes.persistableCollection();
        
        if(output != null){
	        for (Object node : persistables) {
	        	output.addElement(node);
			}
	        return (Collection<EPMCADNamespace>) output;
        } else {
			return persistables;
		}
    }
    
    
	////////////////////////////////////////////////////////////////////////////////////
	// private methods
	////////////////////////////////////////////////////////////////////////////////////
	
    /**
     * Finds dependent EPMDocuments
     * @param seeds
     * @param spec
     * @param collectRequired
     * @param includeDrawings
     * @param includeInstances
     * @param nodeClasses
     * @param linkClasses
     * @param output
     * @param retrievalDepth
     * @return Collection of dependent EPMDocuments
     * @throws WTException
     * @throws WTPropertyVetoException
     */
	private ResultProcessor findEPMDeps(WTCollection seeds, ConfigSpec spec, boolean collectRequired, boolean includeDrawings, boolean includeFTables, Class<?>[] nodeClasses, Class<?>[] linkClasses, ResultProcessor output, int retrievalDepth) throws WTException, WTPropertyVetoException {
        DependencyRetrieverHelper helper = new DependencyRetrieverHelper(seeds, spec);

        helper.addAuxConfigSpec(spec);
        helper.setLinks(linkClasses);
        helper.setIncludeDependents(collectRequired ? DependencyRetrieverHelper.REQUIRED_DEPENDENTS : DependencyRetrieverHelper.ALL_DEPENDENTS);
        helper.setIncludeDrawings(includeDrawings ? DependencyRetrieverHelper.ALL_DRAWINGS : DependencyRetrieverHelper.NO_DRAWINGS);
        helper.setIncludeDrawingDependents(DependencyRetrieverHelper.NO_DRAWING_DEPENDENTS);
        helper.setIncludeFTMembers(includeFTables ? DependencyRetrieverHelper.ALL_FT_MEMBERS : DependencyRetrieverHelper.NO_FT_MEMBERS);
        /*
         * AW: Defines the depth of navigation
         * int level = 0; helper.setRepeatLimit(level + 1);
         */
        helper.setRepeatLimit(retrievalDepth);
        
        EPMRetrieverCache cache = helper.getDependencies();
        ResultList results = new ResultList();

        cache.populate(results, nodeClasses, linkClasses);

        WTCollection nodes = results.getNodes();
        for (Object node : nodes) {
        	output.addElement(node);
		}
        
        if (includeFTables) {
            FamilyTableResult ft = new FamilyTableResult();
            cache.populate(ft, new Class[]{EPMDocument.class, EPMSepFamilyTable.class}, new Class[]{EPMVariantLink.class, EPMContainedIn.class});
            WTSet ftversions = ft.getFTVersions(null);
            for (Object ftversion : ftversions) {
            	output.addElement(ftversion);
			}
        }

        return output;
    }

    /**
     * Appends an Object[] to an array instance.<br>
     * The result array is returned.
     *
     *
     * @param toAdd
     * @param destArray
     *
     * @return The array with the appended object.
     *
     * @throws Exception
     */
    private Class<?>[] addToArray(Class<?>[] toAdd, Class<?>[] destArray) throws WTException {
        Class<?>[] src = toAdd;
        int i = (src != null)
                ? src.length
                : 0;
        int j = (destArray != null)
                ? destArray.length
                : 0;
        int k = i + j;
        Class<?>[] temp = null;

        if (k > 0) {
            temp = new Class<?>[k];

            if (i > 0) {
                System.arraycopy(src, 0, temp, 0, i);
            }

            if (j > 0) {
                System.arraycopy(destArray, 0, temp, i, j);
            }
        }

        return temp;
    }

    private boolean isDrawing(EPMDocument epmdoc) {
        if (epmdoc == null) {
            return false;
        }

        EPMDocumentType epmdocumenttype = epmdoc.getDocType();

        return epmdocumenttype.equals(EPMDocumentType.toEPMDocumentType("CADDRAWING"));
    }
}
