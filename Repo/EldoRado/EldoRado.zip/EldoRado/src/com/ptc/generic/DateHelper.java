package com.ptc.generic;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;

public class DateHelper {
	
	
	/**
	 * Returns the date in the format yyyy-mm-dd. Note that PDMLink has its own
	 * date formatter wt.util.WTStandardDateFormat, but that uses the deprecated
	 * (in Java) class java.util.Date.
	 *
	 * @param calendar The date
	 * @return Formatted date: yyyy-mm-dd-hh-mm-ss
	 */
	private static String format(Calendar calendar) {
		Calendar cal = new GregorianCalendar();
		int year = cal.get(Calendar.YEAR);
		int month = 1 + cal.get(Calendar.MONTH);
		int day = cal.get(Calendar.DAY_OF_MONTH);
		int hour = cal.get(Calendar.HOUR);
		int minute = cal.get(Calendar.MINUTE);
		int second = cal.get(Calendar.SECOND);

		String formattedDate =
				year
				+ "-"
				+ prepend("" + month, '0', 2)
				+ "-"
				+ prepend("" + day, '0', 2)
				+ "-"
				+ prepend("" + hour, '0', 2)
				+ "-"
				+ prepend("" + minute, '0', 2)
				+ "-"
				+ prepend("" + second, '0', 2);

		return formattedDate;
	}

	/**
	 * Prepend the string with char until a total length of n. If the string
	 * already has more than n characters, nothing is prepended and the string
	 * is just returned.
	 *
	 * @param s The string to prepend
	 * @param c Prepending character
	 * @param n Total string length
	 * @return String with prepended characters with a total length of n. If s
	 * already has more than n characters, nothing is prepended and the string
	 * is just returned.
	 */
	private static String prepend(String s, char c, int n) {
		char[] array = new char[Math.max(0, n - s.length())];
		for (int i = 0; i < array.length; i++) {
			array[i] = c;
		}

		return String.valueOf(array) + s;
	}

	/**
	 * @return Current date and time in the format yyyy-mm-dd-hh-mm-ss.
	 */
	public static String getDateAndTime() {
		return format(new GregorianCalendar());
	}

	/**
	 * Compares two dates given as strings. Used to compare MOD_DATEs between
	 * KVS and Windchill attributes. Returns true if the two strings are equal
	 * when parsed as dates. The format can be short (03.04.08, like Windchill
	 * attributes) or a variant of short (03.04.2008, like in KVS).
	 *
	 * @param sDate1
	 * @param sDate2
	 * @return
	 */
	public static boolean isDatesEqual(String sDate1, String sDate2) {
		boolean flag;
		/*
		 * Handle nulls.
		 */
		if (sDate1 == null || sDate2 == null) {
			flag = (sDate1 == null) && (sDate2 == null);
		} else {
			/*
			 * Both dates are not null here, but can consist of blanks.
			 */
			sDate1 = sDate1.trim();
			sDate2 = sDate2.trim();
			/*
			 * If you trim blanks, you get the empty string.
			 */
			if (sDate1.equals("") && sDate2.equals("")) {
				flag = true;
			} else {
				/*
				 * Handle normal case.
				 */
				DateFormat dateFormat = DateFormat.getDateInstance(DateFormat.SHORT, Locale.GERMANY);
				Date date1;
				Date date2;
				try {
					date1 = dateFormat.parse(sDate1);
					date2 = dateFormat.parse(sDate2);
					flag = date1.equals(date2);
				} catch (ParseException e) {
					flag = sDate1.equals(sDate2);
				}
			}
		}
		return flag;
	}
	
	/**
	 * calculates calendar week for given date according to ISO 8601
	 * 
	 * @param t
	 * @return integer representing the week number
	 */
	public static int getCalendarWeek(Timestamp t) {
		/* Build a calendar suitable to extract ISO8601 week numbers
		 * (see http://en.wikipedia.org/wiki/ISO_week_date) */
		Calendar calendar = Calendar.getInstance();
		calendar.setMinimalDaysInFirstWeek(4);
		calendar.setFirstDayOfWeek(Calendar.MONDAY);

		/* Set date */
		calendar.setTime(t);

		/* Get ISO8601 week number */
		return calendar.get(Calendar.WEEK_OF_YEAR);

	}
}
