package com.ptc.generic.validators;

import java.text.MessageFormat;

import com.ptc.generic.validators.validatorsResource;

import wt.inf.container.WTContained;
import wt.inf.team.ContainerTeamHelper;
import wt.inf.team.ContainerTeamManaged;
import wt.org.WTGroup;
import wt.util.WTException;
import wt.util.WTMessage;

/**
 * GenericContainerTeamExistValidator
 *
 * Validates a windchill container if a set of container team roles exist in the container team
 *
 * @author cherrmann
 *
 */
public class GenericContainerTeamRoleExistValidator<T extends WTContained> implements GenericValidator<T> {

	private ValidationResult validationResult;
	private String errorMessage;
	private static final String defaultErrorMessage = WTMessage.getLocalizedMessage(VALIDATION_RESOURCE, validatorsResource.INVALID_GROUP_NOT_EXISTANT, null);

	private String[] roleNames;

	/**
	 * GenericContainerTeamExistValidator
	 *
	 * @param roleNames a list of group names which should exist during validation
	 */
	public GenericContainerTeamRoleExistValidator(String... roleNames) {
		this(null, roleNames);
	}

	/**
	 * GenericContainerTeamExistValidator
	 *
	 * @param errorMessage the default error message
	 * @param roleNames a list of group names which should exist during validation
	 */
	public GenericContainerTeamRoleExistValidator(String errorMessage, String[] roleNames){
		this.roleNames = roleNames;
		this.errorMessage = errorMessage;
	}

	/**
	 * Checks if <b>all</b> the given roles exist in the passed container.
	 *
	 * @param object an object of type WTContained
	 * @return true if all the given groups exist
	 * @see com.ptc.generic.validators.GenericValidator#validate(java.lang.Object)
	 */
	public boolean validate(WTContained object) {
		resetValidationResult();

		if (object != null){
			if (this.roleNames != null){
				WTContained wtcObject = object;
				for (int i = 0; i < roleNames.length; i++){
					try {
						WTGroup group = ContainerTeamHelper.service.findContainerTeamGroup((ContainerTeamManaged) wtcObject.getContainer(), ContainerTeamHelper.ROLE_GROUPS, roleNames[i]);
						if (group == null){
							if (errorMessage == null){
								this.validationResult = new ValidationResult(MessageFormat.format(defaultErrorMessage, roleNames[i]), false);
							} else {
								this.validationResult = new ValidationResult(errorMessage, false);
							}
							break;
						}
					} catch (WTException e) {
						this.validationResult = new ValidationResult(MessageFormat.format(EXCEPTION_THROWN, e.getLocalizedMessage()), false, null, e);
						e.printStackTrace();
					}
				}
			}
		} else {
			this.validationResult = new ValidationResult(INVALID_PARAMETER_WAS_NULL, false);
		}

		if (this.validationResult == null){
			this.validationResult = new ValidationResult(SUCCESS_MESSAGE, true);
		}

		return this.validationResult.getIsValid();
	}

	public ValidationResult getValidationResult() {
		return this.validationResult;
	}

	public void resetValidationResult(){
		this.validationResult = null;
	}

}
