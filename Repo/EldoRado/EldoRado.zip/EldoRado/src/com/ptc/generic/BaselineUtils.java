/* bcwti
 *
 *  Copyright (c) 2012 Parametric Technology Corporation (PTC). All Rights
 *  Reserved.
 *
 *  This software is the confidential and proprietary information of PTC.
 *  You shall not disclose such confidential information and shall use it
 *  only in accordance with the terms of the license agreement.
 *
 *  ecwti
 */
package com.ptc.generic;

import org.apache.log4j.Logger;
import wt.fc.IdentityHelper;
import wt.part.WTPart;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.vc.baseline.ManagedBaseline;
import wt.vc.baseline.ManagedBaselineIdentity;

/**
 * custom utility methods for Baselines
 * 
 * @author pielab
 */
public class BaselineUtils {
    public static final String svnRev = "$Revision: 1.1.1.3 $ $Date: 2016/02/23 22:21:36IST $";
    public static final String svnUrl = "$URL: http://127.0.0.1/svn/KB_04082016/components/Generic-Utilities/src/com/ptc/generic/BaselineUtils.java $";
    private static final String CLASSNAME = BaselineUtils.class.getName();
    private static final Logger logger = Logger.getLogger(CLASSNAME);
    
    /**
     * Creates ManagedBaseline with given name and number, set given part as baseline's top object.
     * 
     * @param name
     * @param number
     * @param part
     * @return
     * @throws WTException 
     */
    public static ManagedBaseline createManagedBaseline(String name, String number, WTPart part) throws WTException {
        logger.debug("Preparing Managed baseline for part = " + part.getName() + ":" + part.getNumber());
        ManagedBaseline baseline = null;
        try {
            baseline = ManagedBaseline.newManagedBaseline();
            baseline.setName(name);
            baseline.setNumber(number);
            baseline.setContainer(part.getContainer());
            baseline.setTopObject(part);
        } catch (WTPropertyVetoException ex) {
            logger.error(ex.getLocalizedMessage(), ex);
            throw new WTException(ex);
        }
        return baseline;
    }
    
    /**
     * Renames given baseline to given new name.
     * 
     * @param baseline
     * @param name
     * @return
     * @throws WTPropertyVetoException
     * @throws WTException
     */
    public static ManagedBaseline renameBaseline(ManagedBaseline baseline, String name) throws WTPropertyVetoException,
            WTException {
        logger.debug("Renaming baseline = " + baseline.getName() + ":" + baseline.getNumber() + " to name = " + name);
        ManagedBaselineIdentity baselineIdentity = (ManagedBaselineIdentity) baseline.getIdentificationObject();
        baselineIdentity.setName(name);
        baseline = (ManagedBaseline) IdentityHelper.service.changeIdentity(baseline, baselineIdentity);
        return baseline;
    }
}
