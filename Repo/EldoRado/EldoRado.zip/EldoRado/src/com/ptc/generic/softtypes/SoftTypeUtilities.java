/*
 * HLOTypeUtils.java
 *
 * Created on November 20, 2006, 10:11 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.ptc.generic.softtypes;

import com.ptc.ssp.util.*;

//LB 29.03.2010:
//instead of changing all references to SoftTypeUtilities in all our code to SoftTypeHelper, I just made SoftTypeUtilities extend SoftTypeHelper 
public class SoftTypeUtilities extends SoftTypeHelper {
}
