/*
 * FcHelper.java
 */
package com.ptc.generic;


import com.ptc.generic.softtypes.SoftTypeUtilities;
import com.ptc.ssp.util.AuthenticationHelper;

import ext.tools.ToolUtils;

import java.util.List;
import java.util.Vector;

import org.apache.log4j.Logger;

import wt.fc.ObjectIdentifier;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.fc.WTReference;
import wt.inf.container.WTContainer;
import wt.introspection.ClassInfo;
import wt.introspection.WTIntrospector;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.org.WTPrincipal;
import wt.pds.DatabaseInfoUtilities;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.type.TypeDefinitionReference;
import wt.type.TypedUtility;
import wt.util.WTContext;
import wt.util.WTException;

/**
 * This class contains generic methods to the fc-package
 * 
 * The main() method can be used to print Windchill column names vs. database table name mapping
 * 
 * @author  Simone Graf, Lorenz Berger (lberger@ptc.com)
 */
public class FcHelper implements RemoteAccess {

	//TODO ECA 4.0: check if all these methods in here belong here. Some should maybe moved to SoftTypeUtilities, as they are not Baustufen-specific

	private static final ReferenceFactory RF = new ReferenceFactory();

	private static final Logger logger = Logger.getLogger(FcHelper.class.getName());


	/**
	 * Convenient method to get the oid of a persistable
	 * @param persistable the persistable
	 * @return the oid of the persistable
	 * @throws WTException when an error occurs
	 */
	public static String getOIDFromObject(Persistable persistable)
			throws WTException {

		return RF.getReferenceString(persistable);
	}


	/**
	 * converts the given object o (either String, WTReference, Persistable, ObjectIdentifier) to a Persistable
	 * method should only be used on server!
	 * 
	 * @param o 
	 * @return a Persistable
	 * @throws WTException if the given object can not be converted to a Persistable
	 */
	public static Persistable convertToPersistable(Object o) throws WTException {

		//not nice to set o to a new object class several times, but then the whole stuff below becomes quite easy
		Persistable persistable = null;
		try {
			if (o == null) {
				throw new WTException("FcHelper.convertToPersistable: given object was null");
			}
			if (o instanceof String) {
				o = RF.getReference((String) o);
			} 

			if (o instanceof WTReference) {
				o = ((WTReference) o).getObject();
			} else if (o instanceof ObjectIdentifier) {
				final ObjectReference objRef = ObjectReference.newObjectReference((ObjectIdentifier) o);
				if (objRef != null) {
					o = objRef.getObject();
				}
			}
			persistable = (Persistable) o;
		} catch(Exception e) {
			if (e instanceof WTException) {
				throw (WTException) e;
			} else {
				throw new WTException(e);
			}
		}
		return persistable;
	}

	/**
	 * Convenient method to search for all softtypes in a container
	 * @param  container     the container e.g. for a EAProduct it is the PDMLinkProduct
	 * @param  softTypeName  the short name of a softtype e.g. Baustufe
	 * @param  searchClass   the search class e.g. WTProduct.class
	 * @param  isLatest      defines if the search only returns the latest iteration
	 * @return the search results
	 * @throws WTException when an error occurs
	 */
	public static QueryResult findAllSoftTypesInAWTContainer(final WTContainer container, String softTypeName, Class searchClass, boolean isLatest, boolean searchSiblings) throws WTException {
		String fullSoftTypeName     = SoftTypeUtilities.getFullTypeName(softTypeName);
		Vector softTypeSiblings     = null;
		TypeDefinitionReference typeRef = TypedUtility.getTypeDefinitionReference(fullSoftTypeName);
		int ai[]                    = {0, 1};
		QuerySpec qs                = new QuerySpec(searchClass);
		SearchCondition scType      = new SearchCondition(searchClass, "typeDefinitionReference.key.branchId", SearchCondition.EQUAL, typeRef.getKey().getBranchId());
		SearchCondition scContainer = new SearchCondition(searchClass, "containerReference.key.id",            SearchCondition.EQUAL, PersistenceHelper.getObjectIdentifier(container).getId());        

		//search for all soft type children too
		if (searchSiblings) {
			softTypeSiblings     = SoftTypeUtilities.getSoftTypeChildrenAsTypeDefinitionReference(softTypeName, false);
		}
		if (searchSiblings && softTypeSiblings != null && softTypeSiblings.size() > 0) {
			qs.appendOpenParen();
			qs.appendWhere(scType);
			for (int i = 0; i < softTypeSiblings.size(); i++) {
				TypeDefinitionReference typeRefSibling = (TypeDefinitionReference)softTypeSiblings.get(i);
				SearchCondition scSibling              = new SearchCondition(searchClass, "typeDefinitionReference.key.branchId", SearchCondition.EQUAL, typeRefSibling.getKey().getBranchId());
				qs.appendOr();
				qs.appendWhere(scSibling);
			}
			qs.appendCloseParen();

			//search only paren class
		} else {
			qs.appendWhere( scType);
		}
		qs.appendAnd();
		qs.appendWhere(scContainer);

		if (isLatest) {
			SearchCondition scIteration = new SearchCondition(searchClass, "iterationInfo.latest", "TRUE");
			qs.appendAnd();
			qs.appendWhere(scIteration);
		}
		QueryResult qr = PersistenceHelper.manager.find(qs);
		return qr;
	}

	/**
	 * Convenient method to search for all softtypes with a certain name in a container
	 * IMPORTANT: the name is master attribut, master>name
	 * @param  container      the container e.g. for a EAProduct it is the PDMLinkProduct
	 * @param  softTypeName   the short name of a softtype e.g. Baustufe
	 * @param  searchClass    the search class e.g. WTProduct.class
	 * @param  isLatest       defines if the search only returns the latest iteration
	 * @param  searchSiblings if true, search also all children of soft type
	 * @param  name           the search criteria name
	 * @return the search results
	 * @throws WTException when an error occurs
	 */
	public static QueryResult findSoftTypeInAWTContainer(final WTContainer container, String softTypeName, Class searchClass, boolean isLatest, boolean searchSiblings, String name)
			throws WTException {
		String fullSoftTypeName     = SoftTypeUtilities.getFullTypeName(softTypeName);
		Vector softTypeSiblings     = null;
		TypeDefinitionReference typeRef = TypedUtility.getTypeDefinitionReference(fullSoftTypeName);

		if(logger.isDebugEnabled()) {
			logger.debug("fullSoftTypeName=" + fullSoftTypeName);
			logger.debug("typeRef=" + ToolUtils.prettyPrint(typeRef, false));
		}

		int ai[]                    = {0, 1};
		QuerySpec qs                = new QuerySpec(searchClass);
		SearchCondition scType      = new SearchCondition(searchClass, "typeDefinitionReference.key.branchId", SearchCondition.EQUAL, typeRef.getKey().getBranchId());
		SearchCondition scContainer = new SearchCondition(searchClass, "containerReference.key.id",            SearchCondition.EQUAL, PersistenceHelper.getObjectIdentifier(container).getId());
		SearchCondition scName      = new SearchCondition(searchClass, "master>name",                          SearchCondition.EQUAL, name);

		//search for all soft type children too
		if (searchSiblings) {
			softTypeSiblings     = SoftTypeUtilities.getSoftTypeChildrenAsTypeDefinitionReference(softTypeName, false);
		}
		if (searchSiblings && softTypeSiblings != null && softTypeSiblings.size() > 0) {
			qs.appendOpenParen();
			qs.appendWhere(scType);
			for (int i = 0; i < softTypeSiblings.size(); i++) {
				TypeDefinitionReference typeRefSibling = (TypeDefinitionReference)softTypeSiblings.get(i);
				SearchCondition scSibling              = new SearchCondition(searchClass, "typeDefinitionReference.key.branchId", SearchCondition.EQUAL, typeRefSibling.getKey().getBranchId());
				qs.appendOr();
				qs.appendWhere(scSibling);
			}
			qs.appendCloseParen();

			//search only paren class
		} else {
			qs.appendWhere( scType);
		}
		qs.appendAnd();
		qs.appendWhere(scContainer);
		qs.appendAnd();
		qs.appendWhere(scName);

		if (isLatest) {
			SearchCondition scIteration = new SearchCondition(searchClass, "iterationInfo.latest", "TRUE");
			qs.appendAnd();
			qs.appendWhere(scIteration);
		}

		if(logger.isDebugEnabled()) {
			logger.debug("qs=" + qs);
		}

		QueryResult qr = PersistenceHelper.manager.find(qs);
		logger.debug("found results: " + qr.size());
		return qr;
	}

	/**
	 * Convenient method to search for all softtypes with a certain name
	 * IMPORTANT: the name is master attribut, master>name
	 * @param  container     the container e.g. for a EAProduct it is the PDMLinkProduct
	 * @param  softTypeName  the short name of a softtype e.g. Baustufe
	 * @param  searchClass   the search class e.g. WTProduct.class
	 * @param  isLatest      defines if the search only returns the latest iteration
	 * @param  searchSiblings if true, search also all children of soft type
	 * @param  name          the search criteria name
	 * @return the search results
	 * @throws WTException when an error occurs
	 */
	public static QueryResult findSoftType(String softTypeName, Class searchClass, boolean isLatest, boolean searchSiblings, String name)
			throws WTException {

		Vector softTypeSiblings     = null;
		TypeDefinitionReference typeRef = TypedUtility.getTypeDefinitionReference(SoftTypeUtilities.getFullTypeName(softTypeName));
		int ai[]                    = {0, 1};
		QuerySpec qs                = new QuerySpec(searchClass);
		SearchCondition scType      = new SearchCondition(searchClass, "typeDefinitionReference.key.branchId", SearchCondition.EQUAL, typeRef.getKey().getBranchId());
		SearchCondition scName      = new SearchCondition(searchClass, "master>name",                          SearchCondition.EQUAL, name);

		//search for all soft type children too
		if (searchSiblings) {
			softTypeSiblings     = SoftTypeUtilities.getSoftTypeChildrenAsTypeDefinitionReference(softTypeName, false);
		}
		if (searchSiblings && softTypeSiblings != null && softTypeSiblings.size() > 0) {
			qs.appendOpenParen();
			qs.appendWhere(scType);
			for (int i = 0; i < softTypeSiblings.size(); i++) {
				TypeDefinitionReference typeRefSibling = (TypeDefinitionReference)softTypeSiblings.get(i);
				SearchCondition scSibling              = new SearchCondition(searchClass, "typeDefinitionReference.key.branchId", SearchCondition.EQUAL, typeRefSibling.getKey().getBranchId());
				qs.appendOr();
				qs.appendWhere(scSibling);
			}
			qs.appendCloseParen();

			//search only paren class
		} else {
			qs.appendWhere( scType);
		}
		qs.appendAnd();
		qs.appendWhere(scName);

		if (isLatest) {
			SearchCondition scIteration = new SearchCondition(searchClass, "iterationInfo.latest", "TRUE");
			qs.appendAnd();
			qs.appendWhere(scIteration);
		}

		QueryResult qr = PersistenceHelper.manager.find(qs);
		return qr;
	}

	public static void appendSearchCondition(QuerySpec qs, String softTypeName, Class searchClass, boolean searchSiblings) throws WTException {
		Vector softTypeSiblings = null;
		TypeDefinitionReference typeRef = TypedUtility.getTypeDefinitionReference(SoftTypeUtilities.getFullTypeName(softTypeName));
		SearchCondition scType = new SearchCondition(searchClass, "typeDefinitionReference.key.branchId", SearchCondition.EQUAL, typeRef.getKey().getBranchId());

		//search for all soft type children too
		if (searchSiblings) {
			softTypeSiblings = SoftTypeUtilities.getSoftTypeChildrenAsTypeDefinitionReference(softTypeName, false);
		}
		if (searchSiblings && softTypeSiblings != null && softTypeSiblings.size() > 0) {
			qs.appendOpenParen();
			qs.appendWhere(scType);
			for (int i = 0; i < softTypeSiblings.size(); i++) {
				TypeDefinitionReference typeRefSibling = (TypeDefinitionReference)softTypeSiblings.get(i);
				SearchCondition scSibling = new SearchCondition(searchClass, "typeDefinitionReference.key.branchId", SearchCondition.EQUAL, typeRefSibling.getKey().getBranchId());
				qs.appendOr();
				qs.appendWhere(scSibling);
			}
			qs.appendCloseParen();

			//search only paren class
		} else {
			qs.appendWhere( scType);
		}
	}


	public static void forcedDelete(List<Persistable> aList) throws WTException {
		if (RemoteMethodServer.ServerFlag) {
			_forcedDelete(aList);
		} else {
			try {
				Class[] classes = {List.class};
				Object[] params = {aList};
				RemoteMethodServer.getDefault().invoke("forcedDelete", "com.ptc.generic.FcHelper", null, classes, params);
			} catch (Exception ex) {
				throw new WTException(ex);
			}
		}
	}

	private static void _forcedDelete(List<Persistable> aList) throws WTException {
		for (Persistable p : aList) {
			System.out.println("_forcedDelete: going to delete: " + p);
			try {
				PersistenceServerHelper.manager.remove(p);
			} catch (Exception exw) {
				exw.printStackTrace();
			}
		}
	}

	//moved deflate() to ListAll in order to avoid package dependencies from ext.tools into com.ptc



	/**
	 * 
	 * Prints Windchill column names vs. database table name mapping to console
	 * 
	 * Run in Windchill Shell:
	 * windchill com.ptc.generic.FcHelper -u wcadmin -p wcadmin wt.part.WTPart
	 * 
	 * output like this:
	 * wt.introspection.ColumnDescriptor changeStateTime/changeStateTime
	 * wt.introspection.ColumnDescriptor configuration/configuration
	 * wt.introspection.ColumnDescriptor containerReference.key.classname/classnamekeycontainerReferen
	 * wt.introspection.ColumnDescriptor containerReference.key.id/idA3containerReference
	 * wt.introspection.ColumnDescriptor context/context
	 * wt.introspection.ColumnDescriptor creator/creatorIsNull
	 * wt.introspection.ColumnDescriptor creator.key.classname/classnamekeyB7
	 * wt.introspection.ColumnDescriptor creator.key.id/idA3B7
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		@SuppressWarnings("rawtypes")    
		Vector v = null;
		try {
			v = AuthenticationHelper.authenticateUser(args, true); //remove \-u .. \-p .. \-url .. args        
			if(v==null || v.size()==0) {
				throw new WTException("Could not authenticate a Windchill user with the given params. authenticateUser() returned empty or null collection.");
			}

			WTPrincipal user = (WTPrincipal)v.elementAt(0);
			System.out.println("authenticated as: " + user.getName());
		} catch (WTException w) {
			System.out.println("could not authenticate user. Exception:" + w.getLocalizedMessage());
			w.printStackTrace();
			System.exit(1);    
		}  

		// init WTContext and set locale   
		WTContext.init(args);

		System.out.println("remaining v.size=" + v.size() + " v=" + v);
		try {
			if(v.size()<2) {
				throw new WTException("no classname given");
			}
			String className = (String)v.get(1);
			ClassInfo ci = WTIntrospector.getClassInfo(className);
			Object columnDesc[] = DatabaseInfoUtilities.getValidColumnDescriptors(ci);
			for(Object o : columnDesc) {
				System.out.println(o);
			}
		} catch (Exception w) {
			w.printStackTrace();
			System.exit(1);
		}
		System.exit(0);
	}
}
