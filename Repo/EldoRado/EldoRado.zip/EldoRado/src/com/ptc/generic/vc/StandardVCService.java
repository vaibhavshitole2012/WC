package com.ptc.generic.vc;


import com.ptc.service.annotations.GenerateService;
import com.ptc.generic.vc.VCService;

import ext.tools.ToolUtils;

import org.apache.log4j.Logger;

import wt.fc.*;
import wt.services.StandardManager;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.vc.Mastered;
import wt.vc.VersionControlHelper;
import wt.vc.Versioned;
import wt.vc.wip.WorkInProgressHelper;
import wt.vc.wip.Workable;


@GenerateService
public class StandardVCService extends StandardManager implements VCService {

    // --- Attribute Section ---
    private static final String RESOURCE = "com.ptc.generic.workinprogress.workinprogressResource";
    private static final String CLASSNAME = StandardVCService.class.getName();
    private static Logger logger = Logger.getLogger(CLASSNAME);

    /**
     * Default factory for the class.
     *
     * @return    StandardVCService
     * @exception wt.util.WTException
     **/
    public static StandardVCService newStandardVCService()
            throws WTException {
        StandardVCService instance = new StandardVCService();
        instance.initialize();
        return instance;
    }

    /**
     * Returns the latest iteration of a Mastered object that fits to the given version string (e.g. 'A')
     * 
     * If given version is null, then returns the latest iteration of the latest version.
     * More precise: the first entry from the result of VersionControlHelper.service.allVersionsOf(m);
     * 
     * In all cases a working copy is returned if the found object is checked out by the current user
     * 
     * @param m
     * @param version
     * @return
     * @throws WTException
     */
    public Versioned getLatestIterationForGivenVersion(Mastered m, String version) throws WTException {
    	logger.debug("m=" + ToolUtils.prettyPrint(m) + " version=" + version);
    	
    	//javadoc from OOTB:
    	//Finds all of the versions to the very first one created associated
		//with the given master. The result is an ordered list of versions (i.e.,
		//latest iterations) from the most recent one to the first one created.
    	QueryResult qrLatestIterationsOfAllVersions = VersionControlHelper.service.allVersionsOf(m);

    	Versioned v = null;
    	while(qrLatestIterationsOfAllVersions.hasMoreElements()) {
    		Versioned o = (Versioned)qrLatestIterationsOfAllVersions.nextElement();
    		String versionDB = VersionControlHelper.getVersionIdentifier(o).getValue();
    		if(logger.isDebugEnabled()) {
    		logger.debug("found latest it with versionDB=" + versionDB + ": " + ToolUtils.prettyPrint(o));
    		}
    		if(version==null) {
    			//we return the latest iteration of the latest version
    			//because above query returns the latest version as first element, we can leave the loop here
    			logger.debug("using first entry from queryResult, should be the latest version");
    			v = o;
    			break;
    		} else if(version.equals(versionDB)) {
    			logger.debug("found correct version");
    			v = o;
    			break;
    		} else {
    			logger.debug("found a version that doesn't fit to required version");
    		}
    	}
    	
    	//we assume that a versioned object can always be checked out. At least, we don't know a different usecase in Windchill
    	Workable w = (Workable)v;
    	
    	if(WorkInProgressHelper.isCheckedOut(w, SessionHelper.getPrincipal()) 
    			&& !WorkInProgressHelper.isWorkingCopy(w)) {
    		w = WorkInProgressHelper.service.workingCopyOf(w);
    		logger.debug("retrieved w/c. now w=" + w);
    	}
    	return (Versioned)w;
    }
}
