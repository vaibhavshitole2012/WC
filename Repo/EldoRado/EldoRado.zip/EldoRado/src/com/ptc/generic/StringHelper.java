/*
 * StringHelper.java
 *
 * Created on 27. Mai 2003, 14:57
 */
package com.ptc.generic;

import java.util.Locale;
import org.apache.commons.lang.ArrayUtils;
import org.apache.log4j.Category;

import wt.httpgw.EncodingConverter;
import wt.util.LocaleUtilities;

/**
 *
 * @author  avs
 */
public class StringHelper
{
    public  static final String   CLASSNAME                  = StringHelper.class.getName();
    private static final Category logCategory                = Category.getInstance( CLASSNAME );
    private static final String   HTML_NEWLINE               = "<br/>";
    private static final String   HTML_SPACE                 = "&nbsp;";
    private static final int      LENGTH_OF_LINE             = 50;
    // private static final char     BOESER_BUCHSTABE           = '\160';
    public  static final char     BOESER_BUCHSTABE           = '\u00A0';
    private static final char     EMPTY                      = ' ';
    private static final char     CHAR_COMMENTED_OUT_NEWLINE = '\u2656';
    private static final char     CHAR_COMMENTED_OUT_SPACE   = '\u2657';
    private static final String   COMMENTED_OUT_NEWLINE      = new String( new char[]{ StringHelper.CHAR_COMMENTED_OUT_NEWLINE, StringHelper.EMPTY } );
    private static final String   COMMENTED_OUT_SPACE        = new String( new char[]{ StringHelper.CHAR_COMMENTED_OUT_SPACE,   StringHelper.EMPTY } );

    private static final char     AMP                        = '&';
    private static final char     LT                         = '<';
    private static final char     GT                         = '>';
    private static final char     QUOT                       = '\"';
    private static final char     APOS                       = '\'';
    private static final char     EURO                       = '�';

    private static final String   AMP_XML                    = "&amp;" ;
    private static final String   LT_XML                     = "&lt;" ;
    private static final String   GT_XML                     = "&gt;" ;

    private static final String   QUOT_EURO                  = "&#8364;" ;
    private static final String   QUOT_XML                   = "&quot;" ;
    private static final String   APOS_XML                   = "&apos;" ;
    private static final String   SPACE_XML                  = "&#160;" ;
    private static final String   ZSBT_SEP                   = ".";

    @Deprecated
    public static String replace( String string, String boeserString, char ersatzString )
    {
        return( StringHelper.replace( string, boeserString, new String( new char[]{ ersatzString } ) ) );
    }

    @Deprecated
    public static String replace( String string, char boeserString, String ersatzString )
    {
        return( StringHelper.replace( string, new String( new char[]{ boeserString } ), ersatzString ) );
    }


    @Deprecated
    public static String deleteBRs( String in )
    {
        if( in == null || in.length() < 2 )
        {
            return( in );
        }

        in = StringHelper.replace( in, "<br>", StringHelper.EMPTY );
        in = StringHelper.replace( in, "<BR>", StringHelper.EMPTY );
        in = StringHelper.replace( in, "<br/>", StringHelper.EMPTY );
        in = StringHelper.replace( in, "<BR/>", StringHelper.EMPTY );

        return( in );
    }


    @Deprecated
    public static String replaceBRs( String in )
    {
        if( in == null || in.length() < 2 )
        {
            return( in );
        }

        in = StringHelper.replace( in, "<br>", StringHelper.HTML_NEWLINE );
        in = StringHelper.replace( in, "<BR>", StringHelper.HTML_NEWLINE );
        in = StringHelper.replace( in, "<BR/>", StringHelper.HTML_NEWLINE );

        return( in );
    }

    @Deprecated
    public static String replaceToBRs( String in )
    {
        if( in == null || in.length() < 2 )
        {
            return( in );
        }

        in = StringHelper.replace( in, "\n", StringHelper.HTML_NEWLINE );

        return( in );
    }

    @Deprecated
    public static String prepareForXml( String in )
    {
        if( in == null || in.length() < 1 )
        {
            return( in );
        }

        in = StringHelper.replace( in, AMP, AMP_XML );
        in = StringHelper.replace( in, LT, LT_XML );
        in = StringHelper.replace( in, GT, GT_XML );
        in = StringHelper.replace( in, QUOT, QUOT_XML );
        in = StringHelper.replace( in, APOS, APOS_XML );
        in = StringHelper.replace( in, HTML_SPACE, SPACE_XML );
        in = StringHelper.replace( in, EURO, QUOT_EURO );

        return ( in );
    }

    @Deprecated
    public static String getHtmlBR( String in )
    {
        return( StringHelper.getHtmlBR( in, StringHelper.LENGTH_OF_LINE ) );
    }

    @Deprecated
    public static String getHtmlBR( String in, int maxLengthOfLine )
    {
        return( StringHelper.getString( in, maxLengthOfLine, true ) );
    }


    @Deprecated
    private static String getString( String in, int maxLengthOfLine, boolean withBR )
    {
        // logCategory.debug( "maxLengthOfLine=" + maxLengthOfLine + " in=" + in );

        if( in == null || maxLengthOfLine < 5 )
        {
            return( in );
        }

        --maxLengthOfLine;
        String returnString = in;



        try
        {
            // logCategory.debug( "am Anfang : returnString = " + returnString );

            returnString = StringHelper.replaceBRs( returnString );
            returnString = StringHelper.replaceCrlfWithBr( returnString );

            returnString = StringHelper.replace( returnString, StringHelper.HTML_SPACE, StringHelper.COMMENTED_OUT_SPACE );
            returnString = StringHelper.replace( returnString, StringHelper.HTML_NEWLINE, StringHelper.COMMENTED_OUT_NEWLINE );

            returnString = StringHelper.convertWhitespace( returnString );

            // logCategory.debug( "vor dem Zeilensetzen : returnString = " + returnString );

            returnString = StringHelper.setBrs( returnString, maxLengthOfLine, StringHelper.COMMENTED_OUT_NEWLINE );

            returnString = StringHelper.replace( returnString, StringHelper.COMMENTED_OUT_SPACE,   StringHelper.HTML_SPACE );
            returnString = StringHelper.replace( returnString, StringHelper.COMMENTED_OUT_NEWLINE, StringHelper.HTML_NEWLINE );
            returnString = StringHelper.replace( returnString, "-" + StringHelper.HTML_NEWLINE + StringHelper.HTML_NEWLINE, "-" + StringHelper.HTML_NEWLINE );
            returnString = StringHelper.replace( returnString, StringHelper.CHAR_COMMENTED_OUT_SPACE,   StringHelper.HTML_SPACE );
            returnString = StringHelper.replace( returnString, StringHelper.CHAR_COMMENTED_OUT_NEWLINE, StringHelper.HTML_NEWLINE );
            returnString = StringHelper.replace( returnString, StringHelper.EMPTY,                 StringHelper.HTML_SPACE );

            // logCategory.debug( "am Ende : returnString = " + returnString );
        }
        catch( Exception e )
        {
            logCategory.info( "could not generate String from " + in + " with maxLengthOfLine=" + maxLengthOfLine, e );
            returnString = StringHelper.convertWhitespace( in );
        }

        if( ! withBR )
        {
            returnString = StringHelper.replace( returnString, StringHelper.HTML_NEWLINE, StringHelper.EMPTY );
        }

        return( returnString );
    }


    private static String setBrs( String in, int len, String separator )
    {
        return( StringHelper.setBrs( in,  len, separator, true ) );
    }

    public static int getOccurance( String[] unsetRequiredAttributeNames, String string )
    {
        int i = -1;

        if( unsetRequiredAttributeNames != null && string != null )
        {
            for( int j = 0; j < unsetRequiredAttributeNames.length; ++j )
            {
                if( string.equalsIgnoreCase( unsetRequiredAttributeNames[ j ] ) )
                {
                    return( j );
                }
            }
        }

//        StringBuffer debug = new StringBuffer( " -- could not find " );
//        debug.append( string );
//        debug.append( " in " );
//        if( unsetRequiredAttributeNames != null )
//        {
//            for( int j = 0; j < unsetRequiredAttributeNames.length; ++j )
//            {
//                debug.append( " || " );
//                debug.append( unsetRequiredAttributeNames[ j ] );
//            }
//        }
//        logCategory.error(  debug.toString()  );

        return( i );
    }

    public static boolean isInArray( String[] unsetRequiredAttributeNames, String string )
    {
        boolean answer = false;

        if( StringHelper.getOccurance( unsetRequiredAttributeNames, string ) > 0 )
        {
            answer = true;
        }

        return( answer );
    }

    public static String[] replace( String[] unsetRequiredAttributeNames, String string1, String string2, String replacement )
    {
        int i = StringHelper.getOccurance( unsetRequiredAttributeNames, string1 );
        int j = StringHelper.getOccurance( unsetRequiredAttributeNames, string2 );
        if( i > -1 && j > -1 )
        {
            return( StringHelper.replace( unsetRequiredAttributeNames, i, j, replacement ) );
        }
        else
        {
            return( unsetRequiredAttributeNames );
        }
    }

    public static String[] replace( String[] unsetRequiredAttributeNames, int i, int j, String replacement )
    {
        if( unsetRequiredAttributeNames != null  )
        {
            int number_i = i;
            int number_j = j;
            if( i < j )
            {
                number_i = j;
                number_j = i;
            }



            if( unsetRequiredAttributeNames.length > i )
            {
                String[] temp = new String[ unsetRequiredAttributeNames.length - 2 ];
                System.arraycopy( unsetRequiredAttributeNames, 0, temp, 0, i );
                System.arraycopy( unsetRequiredAttributeNames, i + 1 , temp, i , j - ( i + 1 ) );
                System.arraycopy( unsetRequiredAttributeNames, j + 1 , temp, j - 1 , unsetRequiredAttributeNames.length - j - 1 );

                return( temp );
            }
        }
        return( unsetRequiredAttributeNames );
    }


//    public static void main( String[] adfgdfa )
//    {
//        String[] strings = new String[]{ "0", "1", "2", "3", "4", "5" };
//        strings = StringHelper.deleteFromStringArray( strings, 3 );
//        for( int i = 0; i < strings.length; ++i )
//        {
//            System.out.print( " ", strings[ i ] );
//        }
//        if( true )
//        {
//            return;
//        }
//
//        System.out.println( "<html><body><p>" );
//
//        String string = "hgfgfffffffffffffffffffffggggjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj";
//        System.out.println( "<br/>string      = " + string + "<br/>" );
//        String string2 = StringHelper.getHtmlBR( string, 30 );
//        System.out.println( "<br/>getHtmlBr() = " + string2 );
//
//        System.out.println( "</p><p>" );
//
//        string = "hgfgffff ffffffffffffff fffggggjjjjjjjjjjjjjj jjjjjjjjjjjjjjjjjjjjjj jjjjjjjjj";
//        System.out.println( "<br/>string      = " + string + "<br/>" );
//        string2 = StringHelper.getHtmlBR( string, 30 );
//        System.out.println( "<br/>getHtmlBr() = " + string2 );
//
//        System.out.println( "</p><p>" );
//
//        string = "hgfgffffffffff fffffffffffggggjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjjj jjjjj";
//        System.out.println( "<br/>string      = " + string + "<br/>" );
//        string2 = StringHelper.getHtmlBR( string, 30 );
//        System.out.println( "<br/>getHtmlBr() = " + string2 );
//
//        System.out.println( "</p><p>" );
//
//        string = "Dies ist Text. Text\n - besteht aus Buchstaben.\n     ( Diese Voraussetzung ist erf�llt! )\n - sollte einen Sinn ergeben, was aber nicht in der Definition erhalten ist und auch nicht sein sollte. Der Donaudampfschifffahrtskapit�nsm�tzenkrempenbandbuchstabe sollte eben auch die M�glichkeit haben, ein Text zu sein.";
//        System.out.println( "<br/>string      = " + string + "<br/>" );
//        string2 = StringHelper.getHtmlBR( string, 30 );
//        System.out.println( "<br/>getHtmlBr() = " + string2 );
//
//        System.out.println( "</p><p>" );
//
//        string = "hgfgfffffffffffffffffffffggggjjjjjjjjjjjjj<br>jjjj<br><br>jjjjjjjjjjjjjjjjjjjjjjjjjjjj";
//        System.out.println( "<br/>string      = " + string + "<br/>" );
//        string2 = StringHelper.getHtmlBR( string, 30 );
//        System.out.println( "<br/>getHtmlBr() = " + string2 );
//
//        System.out.println( "</p><p>" );
//
//        string = "Das ist ein Satz mit einigen Worten, die ohne irgendein <CRLF> hintereinander stehen. Da� dieser Satz nicht wirklich Sinn macht, tut eigentlich nichts zur Sache. Die Daseinsberechtigung f�r diesen Satz sind seine Worte, insbesondere das Wort Donaudampfschifffahrtsgesellschaftskapit�nsm�tzenkrempenband, hinter dem aber noch Worte kommen sollten.";
//        System.out.println( "<br/>string      = " + string + "<br/>" );
//        string2 = StringHelper.getHtmlBR( string, 30 );
//        System.out.println( "<br/>getHtmlBr() = " + string2 );
//
//        System.out.println( "</p></body></html>" );
//    }


    private static String setBrs( String in, int len, String separator, boolean firstTime )
    {
        return( StringHelper.setBrs( in, len, separator, firstTime, StringHelper.HTML_NEWLINE ) );
    }
    private static String setBrs( String in, int len, String separator, boolean firstTime, String newLine )
    {
        // logCategory.debug( "<br>setBrs() gets len=" + len + " separator=|" + separator + "| firstTime=" + firstTime + " in=" + in );

        if( in == null || in.length() < len )
        {
            // logCategory.debug( "<br>setBrs() returns " + in );
            return( in );
        }

        String[] array = StringHelper.separateByDelimiter( in, separator );

        if( array != null && array.length > 1 )
        {
            // logCategory.debug( "<br>1. array.length " + array.length );

            StringBuilder sb = new StringBuilder();
            for( int i = 0; i < array.length; ++i )
            {

                // logCategory.debug( "<br>1. array[ " + i + " ] = " + array[ i ] );

                if( array[ i ] != null && array[ i ].length() < len)
                {
                    if( firstTime )
                    {
                        sb.append( array[ i ] );
                        sb.append( newLine );
                    }
                    else
                    {
                        boolean done = false;

                        StringBuilder temp_sb = new StringBuilder();

                        while( ! done )
                        {
                            if( array.length > i )
                            {
                                if( temp_sb.length() + array[ i ].length() < len )
                                {
                                    temp_sb.append( array[ i ] );

                                    if( array.length > ( i + 1 ) )
                                    {
                                        if( array[ i + 1 ] != null )
                                        {
                                            if( temp_sb.length() + array[ i + 1 ].length() < len )
                                            {
                                                temp_sb.append( " " );
                                                temp_sb.append( array[ i + 1 ] );
                                                temp_sb.append( " " );
                                                i += 2;
                                            }
                                            else
                                            {
                                                done = true;
                                            }
                                        }
                                        else
                                        {
                                            done = true;
                                        }
                                    }
                                    else
                                    {
                                        done = true;
                                    }
                                }
                                else
                                {
                                    --i;
                                    done = true;
                                }
                            }
                            else
                            {
                                done = true;
                            }
                        }

                        // logCategory.debug( "temp_sb.toString() : " + temp_sb.toString() );

                        sb.append( temp_sb.toString() );
                        sb.append( newLine );
                    }
                }
                else
                {
                    sb.append( StringHelper.setBrs( array[ i ], len, separator, false ) );
                    sb.append( newLine );
                }
            }

            // logCategory.debug( "<br>setBrs() returns " + sb.toString() );

            return( sb.toString() );
        }
        else
        {
            array = StringHelper.separateByDelimiter( in, " " );
            if( array != null && array.length > 1 )
            {
                // logCategory.debug( "<br>setBrs() rekursion" );
                return( StringHelper.setBrs( in, len, " ", false, newLine ) );
            }
            else
            {
                StringBuilder sb = new StringBuilder();
                sb.append( in.substring( 0, len ) );
                sb.append( "-" );
                sb.append( newLine );
                sb.append( StringHelper.setBrs( in.substring( len ), len, separator, false, newLine ) );

                // logCategory.debug( "<br>setBrs() returns " + sb.toString() );

                return( sb.toString() );
            }
        }
    }


    public static String replaceCrlfWithBr( String in )
    {
        if( in == null )
        {
            return( null );
        }

        StringBuilder sb = new StringBuilder();
        char[] feld = in.toCharArray();
        for( int i = 0 ; i < feld.length ; i++ )
        {
            if( Character.getType( feld[ i ] ) == Character.CONTROL )
            {
                sb.append( StringHelper.HTML_NEWLINE );
            }else
            {
                sb.append( feld[i] );
            }
        }

        return( sb.toString() );
    }


    public static String convertWhitespace( String in )
    {
        return( StringHelper.convertWhitespace( in, false ) );
    }


    public static boolean contains( String string, String delimiter )
    {
        boolean contains = false;

        if( string != null && string.length() > delimiter.length() )
        {
            if( string.equals( delimiter ) )
            {
                contains = true;
            }
            else if( string.lastIndexOf( delimiter ) > 0 )
            {
                contains = true;
            }
        }

        return( contains );
    }


    public static String convertWhitespace( String in, boolean strict )
    {
        if( logCategory.isDebugEnabled() )
        {
            logCategory.debug( getStringAsAsciiValues( in ) );
        }
        if( in == null )
        {
            return( null );
        }


        char[] feld = in.toCharArray();
        for( int i = 0 ; i < feld.length ; i++ )
        {
            if( feld[ i ] == StringHelper.CHAR_COMMENTED_OUT_NEWLINE )
            {
                // nothing
            }
            else if( feld[ i ] == StringHelper.CHAR_COMMENTED_OUT_SPACE )
            {
                // nothing
            }
            else if( feld[ i ] == '<' || feld[ i ] == '>' )
            {
                // nix passiert: ist evtl. HTML
            }
            else if( feld[ i ] == '(' || feld[ i ] == ')' )
            {
                // nothing
            }
            else if( strict )
            {
                int value = Character.getNumericValue( feld[ i ] );
                if( ( value < 0 || value > 36 ) && feld[ i ] != '-' )
                {
                    feld[ i ] = EMPTY;
                }
            }
            else if( Character.isLetterOrDigit( feld[ i ] ) )
            {
                // do nothing.
            }
            else if( Character.getType( feld[ i ] ) == Character.OTHER_PUNCTUATION )
            {
                // do nothing.
            }
            else if( Character.getType( feld[ i ] ) == Character.DASH_PUNCTUATION )
            {
                // do nothing.
            }
            else if( Character.getType( feld[ i ] ) == Character.LINE_SEPARATOR )
            {
                // logCategory.debug( "-------FOUND CRLF-----------" );
                // do nothing.
            }
            else if( Character.isISOControl( feld[ i ] ) )
            {
                feld[ i ] = EMPTY;
            }
            else if( Character.isWhitespace( feld[ i ] ) )
            {
                feld[ i ] = EMPTY;
            }
            else
            {
                feld[ i ] = EMPTY;
            }
        }

        return( String.valueOf( feld ) );
    }



    // TODO: fix or replace this method! It is not working correctly!
    /**
     * This method is not working in the folowing cases:<br>
     * 1. The complete string equals the remplacement, e.g. string=";", boeserString=";", ersatzString="#semicolon#" => result=""<br>
     * 2. The string which has to be replaced is at the end of the string, e.g. string="123;", boeserString=";", ersatzString="#semicolon#" => result="123"
     * @param string
     * @param boeserString
     * @param ersatzString
     * @return
     * @deprecated
     */
    @Deprecated
    public static String replace( String string, String boeserString, String ersatzString )
    {
        if( string == null || string.length() < 1 )
        {
            return( string );
        }

        if( boeserString == null || boeserString.length() < 1 )
        {
            return( string );
        }

        if( ersatzString == null )
        {
            ersatzString = "";
        }

        if( boeserString.equals( ersatzString ) )
        {
            return( string );
        }

        try
        {
            if( string.lastIndexOf( boeserString ) > -1)
            {
                String[] strings = StringHelper.separateByDelimiter( string, boeserString );

                if( strings != null && strings.length > 0 )
                {
                    StringBuilder sb1 = new StringBuilder();
                    for( int j = 0; j < strings.length; ++j )
                    {
                        sb1.append( ersatzString );
                        sb1.append( strings[ j ] );
                    }
                    string = sb1.toString();
                    string = string.substring( ersatzString.length(), string.length() );
                }
            }
            // string = string.trim();
        }
        catch( Exception e )
        {
            logCategory.info( "while trying to replace " + boeserString + " with " + ersatzString + " in " + string );
        }

        return( string );
    }

    @Deprecated
    public static String getUnderlineConcatinated( String[] strings )
    {
        String string = StringHelper.getConcatinated( strings, "_" );
        string = StringHelper.convertWhitespace( string, true );
        string = StringHelper.replace( string, " ", "_" );
        return( string );
    }


    public static String getConcatinated( String[] strings, String inBetween )
    {
        if( strings == null || strings.length == 0 )
        {
            return( "" );
        }

        if( inBetween == null )
        {
            inBetween = "";
        }

        StringBuilder sb = new StringBuilder();

        for( int i = 0; i < strings.length; ++i )
        {

            sb.append( strings[ i ] );
            sb.append( inBetween );
        }

        String string = sb.toString();
        string = string.substring( 0, string.length() - inBetween.length() );

        return( string );
    }


    public static String getCommaSeparated( String[] strings )
    {
        return( StringHelper.getConcatinated( strings, ", " ) );
    }


    public static String[] separateByDelimiter( String string, String delimiter, int fixLength )
    {
        if( fixLength == 0 )
        {
            return( new String[ 0 ] );
        }

        String[] returns = StringHelper.separateByDelimiter( string, delimiter );

        if( returns == null )
        {
            return( new String[ 0 ] );
        }
        else if( returns.length == fixLength )
        {
            return( returns );
        }
        else
        {
            String[] realReturn = new String[ fixLength ];
            for( int i = 0; i < fixLength; ++i )
            {
                if( i < returns.length )
                {
                    realReturn[ i ] = returns[ i ];
                }
                else
                {
                    realReturn[ i ] = " ";
                }
            }
            return( realReturn );
        }
    }


    public static String[] separateByDelimiter( String string, String delimiter )
    {
        String[] strings = null;

        while( string != null && string.length() > 0 )
        {
            try
            {
                String temp = null;
                int index_2 = string.indexOf( delimiter );
                if( index_2 >= 0 )
                {
                    temp = string.substring( 0, index_2 );
                }
                else
                {
                    temp = string;
                }
                if( temp == null )
                {
                    temp = "";
                }

                strings = StringHelper.addToStringArray( strings,  temp );

                int index_1 = string.indexOf( delimiter );

                if( index_1 >= 0 )
                {
                    string = string.substring( index_1 + delimiter.length() );
                }
                else
                {
                    string = null;
                }
            }
            catch( Exception e )
            {
                logCategory.info( "", e );
            }
        }
        return( strings );
    }


    public static String encode( String string, Locale locale )
    {
        if( string == null || string.length() == 0 || string.equalsIgnoreCase( "&nbsp;" ) )
        {
            string = "";
        }
        else
        {
            try
            {
                EncodingConverter encodingconverter = new EncodingConverter();
                string = encodingconverter.encode( string, LocaleUtilities.getEncoding( locale ) );
            }
            catch( Exception e )
            {
                logCategory.info( "while trying to encode " + string, e );
            }
        }
        return( string );
    }


    public static String decode( String string, Locale locale )
    {
        if( string == null || string.length() == 0 )
        {
            string = "";
        }
        else
        {
            try
            {
                EncodingConverter encodingconverter = new EncodingConverter();
                string = encodingconverter.decode( string, LocaleUtilities.getEncoding( locale ) );
            }
            catch( Exception e )
            {
                logCategory.info( "while trying to decode " + string, e );
            }
        }
        return( string );
    }


   public static String convertToHTML(String s){
   StringBuilder sb = new StringBuilder();
   int n = s.length();
   for (int i = 0; i < n; i++) {
      char c = s.charAt(i);
      switch (c) {
         case '<': sb.append("&lt;"); break;
         case '>': sb.append("&gt;"); break;
         case '&': sb.append("&amp;"); break;
         case '"': sb.append("&quot;"); break;
         case '�': sb.append("&agrave;");break;
         case '�': sb.append("&Agrave;");break;
         case '�': sb.append("&acirc;");break;
         case '�': sb.append("&Acirc;");break;
         case '�': sb.append("&auml;");break;
         case '�': sb.append("&Auml;");break;
         case '�': sb.append("&aring;");break;
         case '�': sb.append("&Aring;");break;
         case '�': sb.append("&aelig;");break;
         case '�': sb.append("&AElig;");break;
         case '�': sb.append("&ccedil;");break;
         case '�': sb.append("&Ccedil;");break;
         case '�': sb.append("&eacute;");break;
         case '�': sb.append("&Eacute;");break;
         case '�': sb.append("&egrave;");break;
         case '�': sb.append("&Egrave;");break;
         case '�': sb.append("&ecirc;");break;
         case '�': sb.append("&Ecirc;");break;
         case '�': sb.append("&euml;");break;
         case '�': sb.append("&Euml;");break;
         case '�': sb.append("&iuml;");break;
         case '�': sb.append("&Iuml;");break;
         case '�': sb.append("&ocirc;");break;
         case '�': sb.append("&Ocirc;");break;
         case '�': sb.append("&ouml;");break;
         case '�': sb.append("&Ouml;");break;
         case '�': sb.append("&oslash;");break;
         case '�': sb.append("&Oslash;");break;
         case '�': sb.append("&szlig;");break;
         case '�': sb.append("&ugrave;");break;
         case '�': sb.append("&Ugrave;");break;
         case '�': sb.append("&ucirc;");break;
         case '�': sb.append("&Ucirc;");break;
         case '�': sb.append("&uuml;");break;
         case '�': sb.append("&Uuml;");break;
         case '�': sb.append("&reg;");break;
         case '�': sb.append("&copy;");break;
         case '�': sb.append("&euro;"); break;
         default:  sb.append(c); break;
      }
   }
   return sb.toString();
}



    public static String cleanHTML( String string )
    {
        return( StringHelper.clean( string,  '+' ) );
    }

    public static String cleanString( String string )
    {
        return( StringHelper.clean( string, StringHelper.EMPTY ) );
    }

    @Deprecated
    public static String deleteBadChar( String string )
    {
        // Warum auch immer: BOESER_BUCHSTABE ist ploetzlich ein 'p'
        return( StringHelper.replace( string, new String( new char[]{ StringHelper.BOESER_BUCHSTABE } ), StringHelper.EMPTY ) );
        // return( string );
    }

    @Deprecated
    private static String clean( String string, char replace )
    {


        String str1 = new String( new char[]{ StringHelper.BOESER_BUCHSTABE } );
        String str2 = "%A0";
        String str3 = "&nbsp;";
        String[] boeseStrings = new String[]{ str3, str1, str2 };

        if( string == null || string.length() < 1 )
        {
            return( string );
        }

        for( int i = 0; i < boeseStrings.length; ++i )
        {
            try
            {
                string = StringHelper.replace( string, boeseStrings[ i ], replace );
            }
            catch( Exception e )
            {
                logCategory.info( "while trying to delete " + boeseStrings[ i ] + " from " + string, e );
            }
        }

        string = StringHelper.convertWhitespace( string, true );

        return( string );
    }


    public static String[] deleteFromStringArray( String[] array, int number )
    {
        if( array == null || array.length == 0 )
        {
            return( array );
        }
        if( number < 0 || number > array.length )
        {
            return( array );
        }
        String[] returnArray = null;

        for( int i = 0; i < array.length; ++i )
        {
            if( i != number )
            {
                returnArray = StringHelper.addToStringArray( returnArray, array[ i ] );
            }
        }

        return( returnArray );
    }


    public static String[] sort( String[] array )
    {
        return( StringHelper.sort( array, false ) );
    }


    public static String[] sort( String[] array, boolean ascending )
    {
        String[] returnArray = null;

        if( array != null )
        {
            int[] order = StringHelper.getOrder( array );

//            // <debug>
//            StringBuffer dBuffer = new StringBuffer();
//            dBuffer.append( "\nJetzt kommen die " );
//            dBuffer.append( order.length );
//            dBuffer.append( " Reihenfolge:" );
//            for( int i = 0; i < order.length; ++i )
//            {
//                dBuffer.append( "\n      " );
//                dBuffer.append( order[ i ] );
//                dBuffer.append( " => " );
//                dBuffer.append( array[ order[ i ] ] );
//            }
//            logCategory.error( dBuffer.toString() );
//            // </debug>

            returnArray = StringHelper.sort( array, order );
//            if( order != null )
//            {
//                for( int  i = 0; i < order.length; ++i )
//                {
//                    returnArray = StringHelper.addToStringArray( returnArray, array[ order[ i ] ], true );
//                }
//            }
        }

        if( ! ascending )
        {
            returnArray = StringHelper.revert( returnArray );
        }

        return( returnArray );
    }


    public static String[] sort( String[] strings, int[] ints )
    {
        String[] returnArray = null;

        if( strings != null )
        {
            if( ints != null )
            {
                if( strings.length == ints.length )
                {
                    for( int  i = 0; i < ints.length; ++i )
                    {
                        returnArray = StringHelper.addToStringArray( returnArray, strings[ ints[ i ] ], true );
                    }
                }
                else
                {
                    return( strings );
                }
            }
            else
            {
                return( strings );
            }
        }

        return( returnArray );
    }


    public static String[] revert( String[] array )
    {
        String[] returnArray = null;
        if( array != null )
        {
            for( int i = ( array.length - 1 ); i >= 0; --i )
            {
                returnArray = StringHelper.addToStringArray( returnArray, array[ i ], true );
            }
        }

        return( returnArray );
    }


    public static void main( String[] dfth )
    {
        String[] array = new String[]{ "Peter", "Paul", "Mary", "Bl�dmann", "Bloedmann" };
//        for( int i = 0; i < array.length; ++i )
//        {
//            System.out.println( "unsortiert[ " + i + " ] = " + array[ i ] );
//        }
//        array = StringHelper.sort( array );
//        for( int i = 0; i < array.length; ++i )
//        {
//            System.out.println( "sortiert[ " + i + " ] = " + array[ i ] );
//        }

        array = new String[]{ null, "Martina", "Maryann", "Mary", "Marx", "MaryAnn", null };
        for( int i = 0; i < array.length; ++i )
        {
            System.out.println( "unsortiert[ " + i + " ] = " + array[ i ] );
        }
        array = StringHelper.sort( array );
        for( int i = 0; i < array.length; ++i )
        {
            System.out.println( "sortiert[ " + i + " ] = " + array[ i ] );
        }

        array = new String[]{ null, "Martina", "Maryann", "Mary", "Marx", "MaryAnn", null };
//        for( int i = 0; i < array.length; ++i )
//        {
//            System.out.println( "unsortiert[ " + i + " ] = " + array[ i ] );
//        }
        array = StringHelper.sort( array, true );
        for( int i = 0; i < array.length; ++i )
        {
            System.out.println( "andersrum sortiert[ " + i + " ] = " + array[ i ] );
        }

//        array = new String[]{ "Martina", "Maryann", null, "Mary", "MaryAnn" };
//        for( int i = 0; i < array.length; ++i )
//        {
//            System.out.println( "unsortiert[ " + i + " ] = " + array[ i ] );
//        }
//        array = StringHelper.sort( array );
//        for( int i = 0; i < array.length; ++i )
//        {
//            System.out.println( "sortiert[ " + i + " ] = " + array[ i ] );
//        }
//
//        array = new String[]{ "CC", "cc", null, "bb", "", "CCCC", "cccccc", "BB", "cccc" };
//        for( int i = 0; i < array.length; ++i )
//        {
//            System.out.println( "unsortiert[ " + i + " ] = " + array[ i ] );
//        }
//        array = StringHelper.sort( array );
//        for( int i = 0; i < array.length; ++i )
//        {
//            System.out.println( "sortiert[ " + i + " ] = " + array[ i ] );
//        }
//
//        array = new String[]{ "10", "5", "88", "3", "0" };
//        for( int i = 0; i < array.length; ++i )
//        {
//            System.out.println( "unsortiert[ " + i + " ] = " + array[ i ] );
//        }
//        array = StringHelper.sort( array );
//        for( int i = 0; i < array.length; ++i )
//        {
//            System.out.println( "sortiert[ " + i + " ] = " + array[ i ] );
//        }
//        array = new String[]{ "10", null, "88", "3", "0", null };
//        for( int i = 0; i < array.length; ++i )
//        {
//            System.out.println( "unsortiert[ " + i + " ] = " + array[ i ] );
//        }
//        array = StringHelper.sort( array );
//        for( int i = 0; i < array.length; ++i )
//        {
//            System.out.println( "sortiert[ " + i + " ] = " + array[ i ] );
//        }
    }


//    private static String[] cloneArray( String[] array )
//    {
//        String[] returnArray = null;
//
//        if( array != null )
//        {
//            for( int i = 0; i < array.length; ++i )
//            {
//                if( array[ i ] != null )
//                {
//                    returnArray = StringHelper.addToStringArray( returnArray, new String( array[ i ] ) );
//                }
//                else
//                {
//                    returnArray = StringHelper.addToStringArray( returnArray, null );
//                }
//            }
//        }
//
//        return( returnArray );
//    }


    public static int[] getOrder( String[] array )
    {
        int[] returnArray = new int[ 0 ];

        if( array != null )
        {
            for( int i = 0; i < array.length; ++i )
            {
                int    biggest = -1;

                // already done
                if( ArrayUtils.contains( returnArray, i ) )
                {
                    // logCategory.debug( i + " already in array => continue" );
                    continue;
                }

                // already completed
                if( array.length == returnArray.length )
                {
                    // logCategory.debug( " array completed in size => break" );
                    break;
                }

                // to compare to
                biggest = i;

                logCategory.debug( "compare = " + array[ biggest ] + " biggest = " + biggest );

                for( int j = 0; j < array.length; ++j )
                {
                    // already done
                    if( ! ArrayUtils.contains( returnArray, j ) )
                    {
                        // do comparison
                        // if( biggest != j )
                        {
                            if( StringHelper.isBigger( array[ biggest ], array[ j ] ) )
                            {
                                biggest = j;
                                j       = -1;
                            }
                        }
                    }
                }

                if( biggest != -1 && ! ArrayUtils.contains( returnArray, biggest ) )
                {
                    returnArray = NumberHelper.addToIntArray( returnArray, biggest );
                    i = -1;
                }
                // <debug>
                StringBuilder debug = new StringBuilder();
                if( returnArray != null )
                {
                    for( int k = 0; k < returnArray.length; ++k )
                    {
                        debug.append(" a[ ").append(returnArray[ k ]).append(" ] = ").append(array[ returnArray[ k ] ]).append( ";");
                    }
                }
                logCategory.debug( "          biggest = " + biggest + " : " + debug.toString() );
                // </debug>
            }
        }
        return( returnArray );
    }


    /**
     *  default is false
     *  "null" > Peter
     * @param string1
     * @param string2
     * @return
     */
    public static boolean isBigger( String string1, String string2 )
    {
        boolean isBigger = false;

        if( string1 == null && string2 != null )
        {
            isBigger = true;
        }
        else if( string1 != null && string2 != null )
        {
            int i = 0;
            char[] chars1 = string1.toCharArray();
            char[] chars2 = string2.toCharArray();

            while( ! isBigger && i < chars1.length && i < chars2.length )
            {
                // logCategory.debug( "" + chars1[ i ] + "<" + chars2[ i ] + "? " + " bzw. " + ( int )chars1[ i ] + "<" + ( int )chars2[ i ] + "? " );
                if( chars1[ i ] != chars2[ i ] )
                {
                    if( chars1[ i ] < chars2[ i ] )
                    {
                        isBigger = true;
                    }
                    else
                    {
                        // get out
                        i = chars1.length + 1;
                    }
                }
                ++i;
            }
        }
        logCategory.debug( "   " + string1 + " < " + string2 + " ? " + isBigger );

        return( isBigger );
    }


    public static String[] addToStringArray( String[] array, String value )
    {
        return( StringHelper.addToStringArray( array, value, false ) );
    }


    public static String[] addToStringArray( String[] array, String value, boolean allowNull )
    {
        String[] returnArray = null;
        if( array == null )
        {
            returnArray = new String[ 0 ];
            return( StringHelper.addToStringArray( returnArray, value, allowNull ) );
        }

        if( value == null && ! allowNull )
        {
            return( array );
        }

        returnArray = new String[ array.length + 1 ];
        System.arraycopy( array, 0, returnArray, 0, array.length );
        returnArray[ array.length ] = value;

        return( returnArray );
    }


    public static String getFirstToken( String string, String delimiter )
    {
        String returnString = null;

        try
        {
            String[] temps = StringHelper.separateByDelimiter( string, delimiter );

            if( temps != null && temps.length >= 1 )
            {
                returnString = temps[ 0 ];
            }
        }
        catch( Exception e )
        {
            returnString = null;

            logCategory.error( "Unhandled: This should not happen :", e );
        }

        return( returnString );
    }


    public static String fillWithLeading( String eanummer, int newLength, String fillString )
    {
        if( eanummer != null )
        {
            if( eanummer.length() < newLength )
            {
                int len = eanummer.length();
                String nullen = "";
                for( int i = len; i < newLength; ++i )
                {
                    nullen += fillString;
                }
                eanummer = nullen + eanummer;
            }

            eanummer = new String( eanummer );
        }

        return( eanummer );
    }


    public static String[] deleteDuplicatesByFirstToken( String[] array, String delimiter )
    {
        if( delimiter == null || delimiter.length() < 1 )
        {
            return( array );
        }

        String[] returnArray = new String[ 0 ];

        if( array != null && array.length > 0 )
        {
            for( int i = array.length - 1; i >= 0; --i )
            {
                try
                {
                    String actual = array[ i ];
                    String id     = StringHelper.getFirstToken( actual, delimiter );

                    boolean toBeAdded = true;
                    for( int j = 0; j < returnArray.length; ++j )
                    {
                        String inLoop = returnArray[ j ];
                        String loopId = StringHelper.getFirstToken( inLoop, delimiter );

                        if( id.equals( loopId ) )
                        {
                            toBeAdded = false;
                            break;
                        }
                    }

                    if( toBeAdded )
                    {
                        returnArray = StringHelper.addToStringArray( returnArray, actual );
                    }
                }
                catch( Exception e )
                {
                    logCategory.info( "Unexplainable exception from outer space. Worry about the planet, not about this server.. : ", e );
                }
            }
        }

        return( returnArray );
    }


    public static String baseName( String folder )
    {
        String FOLDER_SEPARATOR = "/";
        if( folder == null )
        {
            return( null );
        }

        int last = folder.lastIndexOf( FOLDER_SEPARATOR );

        if( last < 1 )
        {
            return( null );
        }

        return( folder.substring( 0, last ) );
    }


    public static String toUpperCase( String string )
    {
        if( string == null )
        {
            return( null );
        }
        return( string.toUpperCase() );
    }


    public static String getStringAsAsciiValues( String string )
    {
        if( string != null )
        {
            StringBuilder sb = new StringBuilder();
            for( int i = 0; i < string.length(); ++i )
            {
                Character buchstabe = Character.valueOf( string.charAt( i ) );
                int code = Character.getNumericValue( buchstabe.charValue() );
                sb.append( "\n|" );
                sb.append( buchstabe.charValue() );
                sb.append( "|    unicode=" );
                sb.append( code );
                sb.append( " type=" );
                sb.append( StringHelper.getCharacterType( Character.getType( buchstabe.charValue() ) ) );
                // sb.append( " isDefined=" );
                // sb.append( buchstabe.isDefined( buchstabe.charValue() ) );
                // sb.append( " isDigit=" );
                // sb.append( buchstabe.isDigit( buchstabe.charValue() ) );
                sb.append( " letterOrDigit=" );
                sb.append( Character.isLetterOrDigit( buchstabe.charValue() ) );
                // sb.append( " isISOControl=" );
                sb.append( " escapeSeq=" );
                sb.append( Character.isISOControl( buchstabe.charValue() ) );
                // sb.append( " isIdentifierIgnorable=" );
                // sb.append( buchstabe.isIdentifierIgnorable( buchstabe.charValue() ) );
                // sb.append( " isJavaIdentifierPart=" );
                // sb.append( buchstabe.isJavaIdentifierPart( buchstabe.charValue() ) );
                // sb.append( " isJavaIdentifierStart=" );
                // sb.append( buchstabe.isJavaIdentifierStart( buchstabe.charValue() ) );
                sb.append( " letter=" );
                sb.append( Character.isLetter( buchstabe.charValue() ) );
                sb.append( " spaceChar=" );
                sb.append( Character.isSpaceChar( buchstabe.charValue() ) );
                sb.append( " whiteSpace=" );
                sb.append( Character.isWhitespace( buchstabe.charValue() ) );
                // sb.append( " isTitleCase=" );
                // sb.append( buchstabe.isTitleCase( buchstabe.charValue() ) );
                // sb.append( " isUnicodeIdentifierPart=" );
                // sb.append( buchstabe.isUnicodeIdentifierPart( buchstabe.charValue() ) );
                // sb.append( " isUnicodeIdentifierStart=" );
                // sb.append( buchstabe.isUnicodeIdentifierStart( buchstabe.charValue() ) );
            }
            return( sb.toString() );
        }
        return( string );
    }

    public static String getCharacterType( int type )
    {
        //switch type :
        // return( "" + type );
        if( type == Character.COMBINING_SPACING_MARK )
        {
            return( "Character.COMBINING_SPACING_MARK" );
        }
        else if( type == Character.CONNECTOR_PUNCTUATION )
        {
            return( "Character.CONNECTOR_PUNCTUATION" );
        }
        else if( type == Character.CONTROL )
        {
            return( "Character.CONTROL" );
        }
        else if( type == Character.CURRENCY_SYMBOL )
        {
            return( "Character.CURRENCY_SYMBOL" );
        }
        else if( type == Character.DASH_PUNCTUATION )
        {
            return( "Character.DASH_PUNCTUATION" );
        }
        else if( type == Character.DECIMAL_DIGIT_NUMBER )
        {
            return( "Character.DECIMAL_DIGIT_NUMBER" );
        }
        else if( type == Character.ENCLOSING_MARK )
        {
            return( "Character.ENCLOSING_MARK" );
        }
        else if( type == Character.END_PUNCTUATION )
        {
            return( "Character.END_PUNCTUATION" );
        }
        else if( type == Character.FORMAT )
        {
            return( "Character.FORMAT" );
        }
        else if( type == Character.LETTER_NUMBER )
        {
            return( "Character.LETTER_NUMBER" );
        }
        else if( type == Character.LINE_SEPARATOR )
        {
            return( "Character.LINE_SEPARATOR" );
        }
        else if( type == Character.LOWERCASE_LETTER )
        {
            return( "Character.LOWERCASE_LETTER" );
        }
        else if( type == Character.MATH_SYMBOL )
        {
            return( "Character.MATH_SYMBOL" );
        }
        else if( type == Character.MODIFIER_LETTER )
        {
            return( "Character.MODIFIER_LETTER" );
        }
        else if( type == Character.MODIFIER_SYMBOL )
        {
            return( "Character.MODIFIER_SYMBOL" );
        }
        else if( type == Character.NON_SPACING_MARK )
        {
            return( "Character.NON_SPACING_MARK" );
        }
        else if( type == Character.OTHER_LETTER )
        {
            return( "Character.OTHER_LETTER" );
        }
        else if( type == Character.OTHER_NUMBER )
        {
            return( "Character.OTHER_NUMBER" );
        }
        else if( type == Character.OTHER_PUNCTUATION )
        {
            return( "Character.OTHER_PUNCTUATION" );
        }
        else if( type == Character.OTHER_SYMBOL )
        {
            return( "Character.OTHER_SYMBOL" );
        }
        else if( type == Character.PARAGRAPH_SEPARATOR )
        {
            return( "Character.PARAGRAPH_SEPARATOR" );
        }
        else if( type == Character.PRIVATE_USE )
        {
            return( "Character.PRIVATE_USE" );
        }
        else if( type == Character.SPACE_SEPARATOR )
        {
            return( "Character.SPACE_SEPARATOR" );
        }
        else if( type == Character.START_PUNCTUATION )
        {
            return( "Character.START_PUNCTUATION" );
        }
        else if( type == Character.SURROGATE )
        {
            return( "Character.SURROGATE" );
        }
        else if( type == Character.TITLECASE_LETTER )
        {
            return( "Character.TITLECASE_LETTER" );
        }
        else if( type == Character.UNASSIGNED )
        {
            return( "Character.UNASSIGNED" );
        }
        else if( type == Character.UPPERCASE_LETTER )
        {
            return( "Character.UPPERCASE_LETTER" );
        }
        else
        {
            return( "UNKNOWN" );
        }

    }


    /**
     * Returns a formatted ZSBT-Nr 12345678912 will get 123.456.789.12
     * If there is a blank at first char.
     * If there is no blank at first position you will also get a ZSBT_SEP after that
     * additional character.
     * @param number the number-string without points
     * @return a nice formatted ZSBT-Number-Sting
     */
    @SuppressWarnings("fallthrough")
    public static String makeNiceZSBTNumber(String number){
        StringBuilder niceZsb = new StringBuilder();
        if (number != null){
            for (int i=0; i<number.length(); i++){
                switch(i){ // in front of which character print a ZSBT_SEP
                    case 1: if (Character.isWhitespace(number.charAt(0))) {
                        break;
                    }
                    case 4:
                    case 7:
                    case 10:
                    case 12:
                    case 16: niceZsb.append(ZSBT_SEP);
                }
                niceZsb.append(number.charAt(i));
            }
        }
        return niceZsb.toString();
    }

    /**
     * Removes all '.' from given returned String.
     * AND gives a leading SPACE if the second char is not '.'
     * @param number The number-String with '.' chars in it.
     * @return  a string without '.' chars and possibly with leading ' '.
     */
    public static String getVDSSearchStringFromZSBTNumber( String number ){
        StringBuilder zsbtnr = new StringBuilder();

        if (number != null){
            if (number.charAt(1) != '.') {
                zsbtnr.append(' ');
            }
            for (int i=0; i<number.length(); i++){
                char c = number.charAt(i);
                if (c != '.') {
                    zsbtnr.append(c);
                }
            }
            if (zsbtnr.length()<12) {
                zsbtnr.append(' ');
            } //just complete if last char is 1 chat index (ZSBT-Nr!)
        }
        return zsbtnr.toString();
    }

    /**
     * gets an Array of objects and
     * returns array as String in following
     * form:
     * \\nelement1\\nelement2\\nelement3 ...
     *
     * @param array Object to print out
     * @return String representation of Array
     */
    public static String convertArrayToString(Object[] array)
    {
        StringBuilder outstring = new StringBuilder();
       for (int x=0; x<=array.length-1; x++)
       {
           outstring.append("\n").append(array[x].toString());
       }
        return outstring.toString();
    }

    /**
     * Convert array of arrays (or 2 dimensional array into single dimensional one)
     * @param arrays
     * @return
     */
    public static String[] toSingleDimensionArray(String[][] arrays) {
        int length = 0;
        for (int i = 0; i < arrays.length; i++) {
            String[] strings = arrays[i];
            length += strings.length;
}

        String[] newArray = new String[length];

        for (int i = 0, pointer = 0; i < arrays.length; i++) {
            String[] strings = arrays[i];
            System.arraycopy(strings, 0, newArray, pointer, strings.length);
            pointer += strings.length;
        }

        return newArray;
    }

    /**
     * Check if one of toCheck is equal to base String
     * Check is null safe. Also if array contains null then it will be equal
     * to null base
     * @param base Check if toCheck contains this string
     * @param trim if base and all toCheck should be trimmed before comparison
     * @param toCheck
     * @return true if any string in toCheck array equals base string
     */
    public static boolean equalsOneOf(String base, boolean trim, String... toCheck) {
        if (trim) {
            for (String string : toCheck) {
                if (base == null ? string == null : base.trim().equals(string == null ? null : string.trim())) {
                    return true;
                }
            }
        } else {
            for (String string : toCheck) {
                if (base == null ? string == null : base.equals(string)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Checks if given String is longer then given max length
     * @param value
     * @param length
     * @return
     */
    public static boolean isLongerThan(String value, int length) {
        return value.length() > length;
    }

    /**
     * Checks if the given String contains an invalid character.
     * Used for input check inside validators.
     *
     * @param sequence Input String to check
     * @return true if the given String contains an invalid character
     */
    public static boolean hasInvalidCharacter(final String sequence) {

    	final char[] invalidChars = {'/', '\\', '!', '@', '#', '$', '%', '^', '&', '*', '(', ')', ':', '?', '"', '<', '>', '|'};

    	if (sequence != null && sequence.length() > 0) {

    		for (int i = 0; i < invalidChars.length; i++) {

				char invalidChar = invalidChars[i];

				if (sequence.contains(String.valueOf(invalidChar))) {
					return true;
				}
			}
		}

    	return false;
    }
}
