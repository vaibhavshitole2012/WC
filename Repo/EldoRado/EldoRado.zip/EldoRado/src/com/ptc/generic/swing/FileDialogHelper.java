package com.ptc.generic.swing;

import java.awt.FileDialog;
import java.awt.Frame;
import java.io.File;
import java.io.FileOutputStream;
import org.apache.log4j.Logger;
import wt.security.FileAccess;

/**
 *
 * @author mcendrowicz
 */
public class FileDialogHelper {
    
    private static final Logger logger = Logger.getLogger(FileDialogHelper.class.getName());

    /**
     * Opens an appropriate FileDialog and returns the selected file.
     * This method is alternative to {@link #getFileFromChooser()}to overcome
     * security issues with plugin 1.4.2_05 and above.
     * Note(s): FilenameFilters don't work on Windows operating systems.
     *
     * @return
     * @throws Exception
     */
    public static FileOutputStream getFileFromDialog(Frame parentFrame, FileDialog fd,
            String phaseName, String projectName, String extension)
            throws Exception {
        // <editor-fold defaultstate="collapsed" desc="Logging">
        if (logger.isDebugEnabled()) {
            logger.debug("getFileFromDialog() starts.");
        }// </editor-fold>
        phaseName = phaseName.replaceFirst("/", "_");
        // <editor-fold defaultstate="collapsed" desc="Logging">
        if (logger.isDebugEnabled()) {
            logger.debug("parentFrame = " + parentFrame);
            logger.debug("phaseName = " + phaseName);
            logger.debug("projectName = " + projectName);
        }// </editor-fold>
        /*
         * Return value.
         */
        FileOutputStream fileoutputstream = null;
        /*
         * Get FileAccess object to use the Windchill security.
         */
        FileAccess fileaccess = FileAccess.getFileAccess(parentFrame);
        /*
         * Instantiate a new FileDialog for the given Frame and FileAccess.
         * Set the save mode for the FileDialog.
         */
        fd = fileaccess.newFileDialog(parentFrame);       
        fd.setMode(1); // save mode
        // <editor-fold defaultstate="collapsed" desc="Logging">
        if (logger.isDebugEnabled()) {
            logger.debug("fileaccess = " + fileaccess);
            logger.debug("fd = " + fd);
        }// </editor-fold>
        /*
         * FilenameFilter are not supported for the moment as they are not
         * working for some Windows operating systems.
         */
        // fd.setFilenameFilter(VWFileDialog.FILENAME_FILTER_CSV);
        /*
         * Set selected directory and file.
         */
        fd.setFile(projectName + "_" + phaseName + "." + extension);
        fileaccess.FileDialog_show(fd);
        String fileName = fd.getFile();
        String dirName = fd.getDirectory();
        // <editor-fold defaultstate="collapsed" desc="Logging">
        if (logger.isDebugEnabled()) {
            logger.debug("fileName = " + fileName);
            logger.debug("dirName = " + dirName);
        }// </editor-fold>
        if (fileName == null || dirName == null) {
            fileoutputstream = null;
        } else {
            File file = new File(dirName + fileName);
            fileoutputstream = fileaccess.getFileOutputStream(file);
        }
        // <editor-fold defaultstate="collapsed" desc="Logging">
        if (logger.isDebugEnabled()) {
            logger.debug("getFileFromDialog() ends. Return value is " + fileoutputstream);
        }// </editor-fold>
        return fileoutputstream;
    }
}