/* bcwti
 * 
 *  Copyright (c) 2011 Parametric Technology Corporation (PTC). All Rights
 *  Reserved.
 * 
 *  This software is the confidential and proprietary information of PTC.
 *  You shall not disclose such confidential information and shall use it
 *  only in accordance with the terms of the license agreement.
 * 
 *  ecwti
 */
package com.ptc.generic;

import java.rmi.RemoteException;
import java.util.Enumeration;
import java.util.Vector;
import java.util.concurrent.ThreadFactory;

import wt.method.MethodServerInfo;
import wt.method.RemoteMethodServer;
import wt.session.SessionThread;

/**
 * Thread factory to be used by executors from java.util.concurrent package.
 * It keeps Windchill session context from executor thread in all threads
 * created by it.
 * 
 * @author piechutm
 */
public class SessionThreadFactory implements ThreadFactory {

    public Thread newThread(Runnable r) {
        Thread thread = new SessionThread(r);
        return thread;
    }
    
    /**
     * PM01066807 - EC-list now and then slow due to too many active contexts and hence insufficient database connections.
     * These active contexts arise from SessionThreads that are used to parallelize retrieval of IBA's.
     * This method returns some relevant info to a SessionThread.
     * @param ecaName - Name for the SessionThread that expresses the purpose of it. You can choose whatever you want.
     * @param sessionThread - The SessionThread to print info for.
     * @return
     */
	public static String getSessionThreadInfo(String ecaName, SessionThread sessionThread) {
		String info = "SessionThread - ECA-name = " + ecaName
				+ ", name = " + sessionThread.getName()
				+ ", tid = " + sessionThread.getId()
				+ ", state = " + sessionThread.getState()
				+ ", appr. number of active threads in this thread group = " + SessionThread.activeCount();

		return info;
	}
	
	/**
     * PM01066807 - EC-list now and then slow due to too many active contexts and hence insufficient database connections.
     * This method returns the active and total contexts in this method server.
	 * @return Number of active and total method contexts.
	 */
	public static String getMethodServerInfo() {
		String info = "";
		RemoteMethodServer ms = RemoteMethodServer.getDefault();
		Vector<MethodServerInfo> methodServerInfoList = new Vector<MethodServerInfo>();

		try {
			methodServerInfoList = ms.getAllInfo();
		} catch (RemoteException e) {
			e.printStackTrace();
		}

		Enumeration<MethodServerInfo> methodServerInfoEnum = methodServerInfoList.elements();

		while (methodServerInfoEnum.hasMoreElements())
		{
			MethodServerInfo localMethodServerInfo = (MethodServerInfo) methodServerInfoEnum.nextElement();
			info = "Active method contexts = " + localMethodServerInfo.activeContexts + ", "
			+ "total method contexts  = " + localMethodServerInfo.totalContexts;

			if (methodServerInfoEnum.hasMoreElements()) {
				info += "\n";
            }
		}

		return info;
	}
}
