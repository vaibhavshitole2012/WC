/*
 * @(#)GenericContextAdminRoleValidator.java   11/12/20
 *
 * Copyright (c) 2004 Parametric Technology Corporation (PTC).
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC.
 * You shall not disclose such confidential information and shall use it
 * only in accordance with the terms of the license agreement.
 *
 * Alfred Weyerer
 */



package com.ptc.generic.validators;

import com.ptc.generic.validators.validatorsResource;

import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerHelper;
import wt.inf.container.WTContainerRef;
import wt.inf.team.ContainerTeamHelper;
import wt.inf.team.ContainerTeamManaged;
import wt.org.OrganizationServicesHelper;
import wt.org.WTGroup;
import wt.org.WTOrganization;
import wt.org.WTPrincipal;
import wt.project.Role;
import wt.util.WTException;
import wt.util.WTMessage;

/**
 * 3 types of validations <br>
 * - organisation administrator <br>
 * - site administrator <br>
 * - user is part of a role in the given application container <br>
 * <br>
 * Checks should also run without server context
 *
 * @author aweyerer
 *
 */
public class GenericContextAdminRoleValidator<T extends WTPrincipal> implements GenericValidator<T> {
    private WTContainer             container				= null;
    private Role                    role					= null;
    private WTPrincipal             user					= null;
    private ValidationResult        validationResult		= null;
    private boolean					checkOrgSiteAdminOnly	= false;

    /**
     * Validation will check if the given user is part of the specified role in
     * the container team.
     *
     * @param container
     * @param role
     * @throws WTException
     *
     */
    public GenericContextAdminRoleValidator(WTContainer container, Role role) throws WTException {
        this.container = container;
        this.role      = role;
    }

    /**
     * Validation will check if the given user is part of the specified role in
     * the container team.
     *
     * @param container
     * @param role
     * @throws WTException
     */
    public GenericContextAdminRoleValidator(WTContainer container, String role) throws WTException {
        this(container, Role.toRole(role));
    }

    /**
     * Validation will check if the given user is administrator in site or org
     * container. The constructor only allows site or org container. <br>
     * If container is null or not site container the org container is
     * calculated the user belongs to.
     *
     * @param container
     * @param user
     * @throws WTException
     *
     */
    public GenericContextAdminRoleValidator(WTContainer container, WTPrincipal user) throws WTException {
        if (!WTContainerHelper.isExchangeContainer(container)) {
            WTOrganization wtorganization = OrganizationServicesHelper.manager.getOrganization(user);
            WTContainerRef containerRef   = WTContainerHelper.service.getOrgContainerRef(wtorganization);

            if (containerRef != null) {
                this.container = containerRef.getReferencedContainer();
            } else {
            	this.container = WTContainerHelper.service.getExchangeRef().getReferencedContainer();
            }
        } else {
            this.container = container;
        }

        this.checkOrgSiteAdminOnly = true;
        this.user = user;
    }

    public boolean validate(T object) {
        resetValidationResult();

        if (object == null) {
            this.validationResult = new ValidationResult(WTMessage.getLocalizedMessage(VALIDATION_RESOURCE, validatorsResource.INVALID_PARAMETER_WAS_NULL, null), false);

            return false;
        } else {
            try {
                this.user = object;
                
                /*
                 * Org-/Site-Admin check
                 */
                boolean validated = WTContainerHelper.service.isAdministrator(container == null ? null : WTContainerRef.newWTContainerRef(container), user, !checkOrgSiteAdminOnly);

                if (validated) {
                    this.validationResult = new ValidationResult(SUCCESS_MESSAGE, validated, user);
                    return validated;
                } else {
                    this.validationResult = new ValidationResult(FAILURE_MESSAGE, validated, user);
                    if (checkOrgSiteAdminOnly) {
                        return validated;
                    }
                }

                /*
                 * Role check in the Context Team
                 */
                WTOrganization wtorganization  = OrganizationServicesHelper.manager.getOrganization(user);
                WTContainerRef orgContainerRef = WTContainerHelper.service.getOrgContainerRef(wtorganization);

                // Check for the users application containers
                if (WTContainerHelper.service.isDescendedFrom(orgContainerRef, WTContainerRef.newWTContainerRef(this.container))) {

                    WTGroup containerTeamRole = ContainerTeamHelper.service.findContainerTeamGroup((ContainerTeamManaged)this.container, ContainerTeamHelper.ACCESS_GROUPS, role.toString());

                    if (containerTeamRole != null) {
                        validated = OrganizationServicesHelper.manager.isMember(containerTeamRole, user);

                        if (validated) {
                            this.validationResult = new ValidationResult(SUCCESS_MESSAGE, validated, user);
                        } else {
                            this.validationResult = new ValidationResult(FAILURE_MESSAGE, validated, user);
                        }

                        return validated;
                    } else {
                        this.validationResult = new ValidationResult(FAILURE_MESSAGE, false, user);

                        return false;
                    }
                } else {
                    this.validationResult = new ValidationResult(WTMessage.getLocalizedMessage(VALIDATION_RESOURCE, validatorsResource.INVALID_APP_CONTAINER, null), false, user);
                }
            } catch (WTException e) {
                this.validationResult = new ValidationResult(WTMessage.getLocalizedMessage(VALIDATION_RESOURCE, validatorsResource.ERROR_EXCEPTION_THROWN, null), false, user, e);
            }
        }

        if (this.validationResult == null) {
            this.validationResult = new ValidationResult(FAILURE_MESSAGE, false, user);
        }

        return false;
    }

    public ValidationResult getValidationResult() {
        return this.validationResult;
    }

    /**
     * Resets, deletes the ValidationResult and the rolePrincipleMap
     *
     */
    public void resetValidationResult() {
        this.validationResult = null;
    }
}
