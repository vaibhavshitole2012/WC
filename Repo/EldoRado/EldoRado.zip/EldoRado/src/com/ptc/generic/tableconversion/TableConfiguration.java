package com.ptc.generic.tableconversion;

/**
 * This Interface specifies those characteristics that are used by all TableConfigurations. Don't specifiy Methods here
 * that are used for specialised Implementations like CSV or Excel or ... Export.
 *
 * @see TableConfigurationFactory
 * @author carsten.trautmann@plussysteme.de
 * @since 2011-03
 */
public interface TableConfiguration {
}
