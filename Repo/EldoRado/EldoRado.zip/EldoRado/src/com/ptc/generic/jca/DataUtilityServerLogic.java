/**
 * 
 */
package com.ptc.generic.jca;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import wt.fc.QueryResult;
import wt.iba.value.StringValue;
import wt.part.WTPart;
import wt.util.WTException;

import com.ptc.core.components.descriptor.ComponentDescriptor;
import com.ptc.core.components.descriptor.JCAObject;
import com.ptc.core.components.descriptor.JCAObjectList;
import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.generic.VersionUtil;
import com.ptc.generic.iba.IBAQueryParameters;
import com.ptc.generic.iba.IBAQueryServerUtils;
import com.ptc.generic.query.QueryServerUtils;

/**
 * @author sgraf
 * 
 *         Contains Generic Code for Data Utilities
 * 
 */
public class DataUtilityServerLogic {

	/**
	 * Returns an oid array of all rows in a table / tree
	 * 
	 * In case no rows exists in the table it returns an empty array.
	 * 
	 * @param mc the modelContext
	 * @return an array with all object oids
	 * @throws WTException
	 */
	public static long[] getIdsOfAllTableRows(ModelContext mc) throws WTException {
		long ids[];
		
		ComponentDescriptor cd = mc.getDescriptor();
		JCAObjectList jcaObjList = mc.getObjectSource().getTargetObjects(cd);
		List<JCAObject> jcaObjs = jcaObjList.getJCAObjects();
		
		if (jcaObjs != null && jcaObjs.size() > 0) {
			ids = new long[jcaObjs.size()];
		} else {
			ids = new long[0];
		}
		int i = 0;
		for (JCAObject jcaObj : jcaObjs) {
			String oid = jcaObj.getBackingObject().toString();
			ids[i++] = VersionUtil.getId(oid);
		}
		return ids;
	}
	
	/**
	 * Returns a map with (at the moment) Ids to StringIBAValue
	 * 
	 * @id an array of oids
	 * @ibaName the name of the IBA
	 * @return a mpa Id to StringIBAValue
	 */
	public static HashMap<Long, String> getMapIdToIBAValue(long[] ids, String ibaName) throws WTException {
		HashMap<Long, String> idToIBAValue = new HashMap<Long, String>();
		
		// Empty ID List
		if (ids == null || ids.length == 0) {
			return idToIBAValue;
		}
		
		IBAQueryParameters ibaQueryParameters = new IBAQueryParameters();
		ibaQueryParameters.setSelectAttributes(StringValue.VALUE);
		ibaQueryParameters.setSelectAttributes(QueryServerUtils.IBA_HOLDER_REFERENCE_ID);
		ibaQueryParameters.setIbaDefinitionId(IBAQueryServerUtils.getIdIBADefinition(ibaName));
		ibaQueryParameters.setIbaHolderClass(WTPart.class.getName());
		ibaQueryParameters.setIbaHolderIds(ids); // wt.part.WTPart%3A57869

		QueryResult qr = IBAQueryServerUtils.executeQuerySpecIBAValues(ibaQueryParameters);

		if (qr != null && qr.size() > 0) {
			idToIBAValue = new HashMap<Long, String>(qr.size());

			while (qr.hasMoreElements()) {
				Object[] result = (Object[]) qr.nextElement();
				String indStatus = (String) result[0];
				long id = ((BigDecimal) result[1]).longValue();

				idToIBAValue.put(new Long(id), indStatus);
			}
		}
		
		return idToIBAValue;
	}
}
