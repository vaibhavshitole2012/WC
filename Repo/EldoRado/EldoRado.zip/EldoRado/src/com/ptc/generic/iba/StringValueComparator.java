/* bcwti
 *
 * Copyright (c) 2011 Parametric Technology Corporation (PTC). All Rights
 * Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */
package com.ptc.generic.iba;

import java.util.Comparator;
import org.apache.commons.lang.StringUtils;
import wt.iba.value.StringValue;

/**
 *
 * @author pielab
 */
public class StringValueComparator implements Comparator<StringValue> {

    public static final String svnRev = "$Revision: 1.1.1.3 $ $Date: 2015/12/10 21:01:36IST $";
    public static final String svnUrl = "$URL: http://127.0.0.1/svn/KB_04082016/components/Generic-Utilities/src/com/ptc/generic/iba/StringValueComparator.java $";

    public int compare(StringValue stringValue1, StringValue stringValue2) {
        String value1 = stringValue1.getValue();
        String value2 = stringValue2.getValue();
        return getPosition(value1) - getPosition(value2);
    }
    
    /**
     * Converts line position in multi valued IBA with product view definition
     * to position it should be concatenated at
     * @param value
     * @return position
     */
    private static int getPosition(String value) {
        String position = StringUtils.substringBefore(value, ":");
        return Integer.parseInt(position);
    }
}
