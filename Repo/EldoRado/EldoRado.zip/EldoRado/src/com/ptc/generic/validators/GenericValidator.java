package com.ptc.generic.validators;
/*
 * This is a generic validation interface.
 *
 * Whenever there are a lot of different object validations to be made,
 * this interface and the GenericValidatorImpl may help in runnning them
 * and analysing the result.
 *
 * During the validate function, the validationResult should be set.
 * Generally: If no validation has been run, return null as result.
 * In special cases it might make sense to return a default validationResult
 * which is set in the constructor.
 *
 * Exceptions should be handeled within the implementation of the validate method
 * and returned as validation result!
 */

import com.ptc.generic.validators.validatorsResource;

import wt.util.WTMessage;

/**
 * Generic validator interface
 *
 * @param <T> 
 * @author cherrmann
 *
 */
public interface GenericValidator<T> {

	public static final String VALIDATION_RESOURCE = "com.ptc.generic.validators.validatorsResource";
	public static final String SUCCESS_MESSAGE = WTMessage.getLocalizedMessage(VALIDATION_RESOURCE, validatorsResource.VALIDATION_OK, null);
	public static final String FAILURE_MESSAGE = WTMessage.getLocalizedMessage(VALIDATION_RESOURCE, validatorsResource.VALIDATION_NOTOK, null);
	public static final String WRONG_OBJECT_TYPE = WTMessage.getLocalizedMessage(VALIDATION_RESOURCE, validatorsResource.INVALID_OBJECT, null);
	public static final String EXCEPTION_THROWN = WTMessage.getLocalizedMessage(VALIDATION_RESOURCE, validatorsResource.ERROR_EXCEPTION_THROWN, null);
	public static final String INVALID_PARAMETER_WAS_NULL = WTMessage.getLocalizedMessage(VALIDATION_RESOURCE, validatorsResource.INVALID_PARAMETER_WAS_NULL, null);

	/**
	 * Validates the given object.
	 *
         * @param object 
	 * @return
	 */
	public boolean validate(T object);

	/**
	 * Returns the validation result set during validation.
	 * If validationResult is null, the validation has not run yet.
	 *
	 * @return
	 */
	public ValidationResult getValidationResult();

	/**
	 * Resets the validation result to null
	 */
	public void resetValidationResult();
}
