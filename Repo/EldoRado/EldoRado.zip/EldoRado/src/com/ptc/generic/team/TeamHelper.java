/* bcwti
 *
 * Copyright (c) 2008 Parametric Technology Corporation (PTC). All Rights
 * Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */

package com.ptc.generic.team;

import java.util.Enumeration;
import java.util.Vector;

import org.apache.log4j.Logger;

import com.ptc.generic.team.TeamService;

import wt.enterprise.RevisionControlled;
import wt.fc.ObjectIdentifier;
import wt.fc.ObjectReference;
import wt.fc.QueryResult;
import wt.inf.container.WTContained;
import wt.inf.container.WTContainer;
import wt.inf.team.ContainerTeam;
import wt.inf.team.ContainerTeamManaged;
import wt.lifecycle.LifeCycleHelper;
import wt.method.MethodContext;
import wt.org.WTPrincipal;
import wt.org.WTPrincipalReference;
import wt.project.Role;
import wt.services.ServiceFactory;
import wt.team.Team;
import wt.team.TeamManaged;
import wt.team.TeamReference;
import wt.team.TeamTemplate;
import wt.util.WTException;

/**
 *
 * @version   1.0
 **/
public class TeamHelper {

   private static final String RESOURCE = "com.ptc.generic.team.teamResource";
   private static final String CLASSNAME = TeamHelper.class.getName();

   public static final TeamService service = ServiceFactory.getService(TeamService.class);

   private static final Logger logger = Logger.getLogger(TeamHelper.class);
   
   /**
    * * Adds roles and principals to Team of given Object.
    *
    *
    * @param     object
    * @param     roles
    * @param     principals
    * @param     ignoreErrors
    * @param     insertDuplicates
    * @exception wt.util.WTException
    **/
   public static void addRoleParticipants ( TeamManaged object, Vector roles, Vector principals, boolean ignoreErrors, boolean insertDuplicates )
   throws WTException
   {
       try
       {
           Team theTeam = wt.team.TeamHelper.service.getTeam (object);
// 09.06.2006 Lars fragen, wo diese Bedingung herkommt!!!
//            if (AccessControlHelper.manager.hasAccess(object, AccessPermission.ADMINISTRATIVE))
//            {
           if (roles.size () == principals.size ())
           {
               for (int x=0; x< roles.size (); x++)
               {
                   try
                   {
                       Role theRole = (Role) roles.get (x);
                       WTPrincipal thePrincipal = (WTPrincipal) principals.get (x);
                       if (!insertDuplicates)
                       {
                           QueryResult qrs = wt.team.TeamHelper.service.findRolePrincipalMap (theRole, thePrincipal, theTeam);
                           if (!qrs.hasMoreElements ()) wt.team.TeamHelper.service.addRolePrincipalMap (theRole, thePrincipal, theTeam);
                       }
                       else {
                    	   wt.team.TeamHelper.service.addRolePrincipalMap (theRole, thePrincipal, theTeam);
                       }
                   }
                   catch(WTException wtex)
                   {
                       if (!ignoreErrors) {
                           throw wtex;
                       }
                   }
               }
           }
           else
           {
               if (!ignoreErrors) {
                   throw new WTException ("Parameters roles and principals must have the same size");
               }
           }
           Team teamneu = wt.team.TeamHelper.service.getTeam (object);
           MethodContext.getContext ().remove (wt.team.StandardTeamService.TEAM);
           LifeCycleHelper.service.augmentRoles (wt.team.TeamHelper.service.getTeam (object));
       }
       catch (WTException ex)
       {
           if (!ignoreErrors) {
               throw ex;
           }
       }
   }
   
    /**
    * This Helper method uses addRoleParticipants service. In difference to service method,
    * it only adds ONE principal to ONE role
    * @param object Object to modify team
    * @param role Role in which the principal should be added to team
    * @param principal Principal to add
    * @param ignoreErrors should errors be ignored?
    * @param insertDuplicates should duplicates be inserted?
    * @since Rel 2.10
    */
   public static void addRoleParticipant( TeamManaged object, Role role, WTPrincipal principal, boolean ignoreErrors, boolean insertDuplicates )
            throws WTException
   {
       Vector roles = new Vector();
       roles.add(role);
       Vector principals = new Vector();
       principals.add(principal);
       addRoleParticipants(object, roles, principals, ignoreErrors, insertDuplicates);
   }
   
   /**
    * This method copies all principals in one role from team template to team
    * @param neues_template source template
    * @param theteam destination team
    * @param role Role to copy
    * @param delete 
    * @param merge_teams should previous principals be deleted?
    * @throws WTException  
    */
    public static void copyOneRoleFromTemplate(TeamTemplate neues_template, Team theteam, Role role, boolean delete) throws WTException
    {
        if (delete) 
        {
            Enumeration en2 = theteam.getPrincipalTarget(role);
            while (en2.hasMoreElements())
            {
            	wt.team.TeamHelper.service.deleteRolePrincipalMap(role, ((WTPrincipalReference) en2.nextElement()).getPrincipal(), theteam);   
            }
        }
        Enumeration en = neues_template.getPrincipalTarget(role);
        Vector roles = new Vector();
        roles.add(role);
        while (en.hasMoreElements())
        {
        	wt.team.TeamHelper.service.addRolePrincipalMap(role, ((WTPrincipalReference) en.nextElement()).getPrincipal(), theteam);
        }
    }
    
    /**
     * copies all Principals from all roles of given team template into given team
    * @param neues_template source template
    * @param theteam destination team
    * @param merge_teams should previous principals be deleted?
   */
    public static void copyAllRolesFromTemplate(TeamTemplate neues_template, Team theteam, boolean delete) throws WTException
    {
        Vector roles = neues_template.getRoles ();
        for (int x=0; x<roles.size (); x++)
        {
            Role theRole = (Role) roles.get (x);
            copyOneRoleFromTemplate (neues_template, theteam, theRole, delete);
        }
    }
    
     public static TeamManaged deleteRoleParticipants( TeamManaged object, Role role )
            throws WTException {
        Team theTeam = wt.team.TeamHelper.service.getTeam(object);
        //QueryResult qrs = TeamHelper.service.findRolePrincipalMap(role, thePrincipal, theTeam); 
        Enumeration en = theTeam.getPrincipalTarget(role);
        while (en.hasMoreElements())
        {
            WTPrincipal principal = ((WTPrincipalReference) en.nextElement()).getPrincipal();
            wt.team.TeamHelper.service.deleteRolePrincipalMap(role, principal, theTeam);
        }
       MethodContext.getContext().remove(wt.team.StandardTeamService.TEAM);       
       LifeCycleHelper.service.augmentRoles(wt.team.TeamHelper.service.getTeam(object));
       return object;
   }



    /**
     * Check if container team of contained object contains any role from array.
     * It checks roles until it finds first thats in team.
     *
     * @param contained
     * @param requireOneOfRole
     * @return true if team contains ANY role from array
     */
    public static boolean isAnyRoleInTeam(WTContained contained, Role[] requireOneOfRole) {
        boolean containsRole = false;

        if (contained != null) {
            WTContainer container = contained.getContainer();
            if (container instanceof ContainerTeamManaged) {
                ContainerTeam team = (ContainerTeam) ((ContainerTeamManaged) container).getContainerTeamReference().getObject();
                try {
                    Vector roles = team.getRoles();
                    for (int i = 0; i < requireOneOfRole.length; i++) {
                        Role role = requireOneOfRole[i];
                        if(roles.contains(role)) {
                            containsRole = true;
                            if (logger.isDebugEnabled()) {
                                logger.debug("Container: " + container.getName() + " team contains role: " + role);
                            }
                            break;
                        }
                    }
                } catch (WTException ex) {
                    logger.error("Could not check if team contains required roles", ex);
                }
            }
        }
        return containsRole;
    }
    
    /**
     * retrieves the ObjectId of the Team that belongs to the given object. 
     * Might return null if given object does not have a team (simple LC)
     * 
     * @param rc
     * @return
     */
    public static ObjectIdentifier getTeamObjectIdentifier(RevisionControlled rc) {
    	TeamReference tr = rc.getTeamId();
    	if(tr!=null) {
    		return tr.getObjectId();
    	} else {
    		return null;
    	}
    }
}
