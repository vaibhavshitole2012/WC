/* bcwti
 *
 *  Copyright (c) 2012 Parametric Technology Corporation (PTC). All Rights
 *  Reserved.
 *
 *  This software is the confidential and proprietary information of PTC.
 *  You shall not disclose such confidential information and shall use it
 *  only in accordance with the terms of the license agreement.
 *
 *  ecwti
 */
package com.ptc.generic;

import java.util.concurrent.locks.ReentrantReadWriteLock;

import org.apache.commons.collections.map.MultiKeyMap;

import wt.introspection.WTIntrospectionException;
import wt.introspection.WTIntrospector;

/**
 * This class provides methods to get information about database columns.
 *
 * @author Bartek Lach (blach@ptc.com)
 */
public class Introspector {

    public static final String svnRev = "$Revision: 1.1.1.3 $ $Date: 2015/12/10 21:01:36IST $";
    public static final String svnUrl = "$URL: http://127.0.0.1/svn/KB_04082016/components/Generic-Utilities/src/com/ptc/generic/Introspector.java $";
    private static final MultiKeyMap COLUMN_LENGTH_CACHE = new MultiKeyMap();
    private static final ReentrantReadWriteLock LOCK = new ReentrantReadWriteLock();
    
    private Introspector() {
    }
    
    /**
     * Method retrieves column length in database for specific attribute.
     * 
     * @param classType Class object to get the value from
     * @param column Column name that is to be introspected
     * @return Database limit of given column
     * @throws WTIntrospectionException 
     */
    public static int introspectColumnLength(Class<?> classType, String column) throws WTIntrospectionException {
    	try {
	    	lockRead();
	    	Integer value = (Integer) COLUMN_LENGTH_CACHE.get(classType, column);
	    	if (value == null) {
	    		unlockRead();
	    		lockWrite();
	    		value = (Integer) COLUMN_LENGTH_CACHE.get(classType, column);
	    		if (value == null) {
	    			value = ((Integer) WTIntrospector.getClassInfo(classType).getPropertyDescriptor(column).getValue(WTIntrospector.UPPER_LIMIT)).intValue();
	    			COLUMN_LENGTH_CACHE.put(classType, column, value);
	    		}
	    		lockRead();
	    		unlockWrite();
	    	}
	    	return value;
    	} finally {
    		unlockRead();
    	}
    }

	private static void unlockWrite() {
		LOCK.writeLock().unlock();
	}

	private static void lockWrite() {
		LOCK.writeLock().lock();
	}

	private static void unlockRead() {
		LOCK.readLock().unlock();
	}

	private static void lockRead() {
		LOCK.readLock().lock();
	}
}
