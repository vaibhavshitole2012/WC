/*
 * Responsible: PTC
 * Code is partially from T-System (old patch tool used with BIF 1.1.2)
 */
package com.ptc.generic.patch.lib;