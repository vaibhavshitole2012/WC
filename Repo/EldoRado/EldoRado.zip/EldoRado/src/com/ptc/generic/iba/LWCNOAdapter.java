/*
 * bcwti Copyright (c) 2012 Parametric Technology Corporation (PTC). All Rights Reserved. This software is the confidential and proprietary information of PTC.
 * You shall not disclose such confidential information and shall use it only in accordance with the terms of the license agreement. ecwti
 */
package com.ptc.generic.iba;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.util.WTContext;
import wt.util.WTException;

import com.ptc.core.lwc.server.PersistableAdapter;
import com.ptc.core.meta.common.FloatingPoint;
import com.ptc.core.meta.common.OperationIdentifier;
import com.ptc.core.meta.common.TypeInstanceIdentifier;
import com.ptc.core.meta.container.common.AttributeTypeSummary;
import com.ptc.core.meta.descriptor.common.DefinitionDescriptor;

/**
 * @author pielab, AB, cherrmann
 * 
 * Adapter for OOTB LWCNormalizedObject.
 * Does automatic conversion of passed attributes' types.
 * If no locale is passed in constructor uses default locale found in WTContext.
 * 
 * ATTENTION: in Windchill 10.2 the LWCNormalizedObject is renamed to PerstistableAdapter
 * 
 * ATTENTION 2: make sure that the wtobject used here is refreshed! Otherwise you may run into strange Verify Exceptions.
 */
public class LWCNOAdapter {
	public static final String svnRev = "$Revision: 1.1.1.3 $ $Date: 2015/12/10 21:01:36IST $";
	public static final String svnUrl = "$URL: http://127.0.0.1/svn/KB_04082016/components/Generic-Utilities/src/com/ptc/generic/iba/LWCNOAdapter.java $";
	private static final String CLASSNAME = LWCNOAdapter.class.getName();
	private static final Logger logger = Logger.getLogger(CLASSNAME);
	private final PersistableAdapter persistableAdapter;

	public LWCNOAdapter(Persistable persistable, String type, Locale locale, OperationIdentifier operation) throws WTException {
		persistableAdapter = new PersistableAdapter(persistable, type, setLocale(locale), operation);
	}

	public LWCNOAdapter(ObjectReference reference, String type, Locale locale, OperationIdentifier operation) throws WTException {
		persistableAdapter = new PersistableAdapter(reference, type, setLocale(locale), operation);
	}

	public LWCNOAdapter(TypeInstanceIdentifier identifier, String type, Locale locale, OperationIdentifier operation) throws WTException {
		persistableAdapter = new PersistableAdapter(identifier, type, setLocale(locale), operation);
	}

	public LWCNOAdapter(String type, Locale locale, OperationIdentifier operation) throws WTException {
		persistableAdapter = new PersistableAdapter(type, setLocale(locale), operation);
	}
	
	public LWCNOAdapter(Persistable persistable) throws WTException {
		this(persistable, null, null, null);
	}
	
	public LWCNOAdapter(Persistable persistable, Locale locale) throws WTException {
		this(persistable, null, locale, null);
	}

	private Locale setLocale(Locale locale) {
		return locale != null ? locale : WTContext.getContext().getLocale();
	}

	public void setIBAsPreLoaded(boolean ibasPreLoaded) {
		persistableAdapter.setIBAsPreLoaded(ibasPreLoaded);
	}

	public DefinitionDescriptor getTypeDescriptor() throws WTException {
		return persistableAdapter.getTypeDescriptor();
	}

	public AttributeTypeSummary getAttributeDescriptor(String attribute) throws WTException {
		return persistableAdapter.getAttributeDescriptor(attribute);
	}

	public List<String> load(String... attributes) {
		return load(new HashSet<String>(Arrays.asList(attributes)));
	}

	public List<String> load(Collection<String> attributes) {
		if (logger.isDebugEnabled()) {
			logger.debug("Loading attributes: " + attributes);
		}
		
		List<String> errorList = new ArrayList<String>();
		
		if (attributes == null) {
		    return errorList;
		}
		
		// we need to single-load, because it will break after the first error.
		for (String attribute : attributes) {
		    try {
		        persistableAdapter.load(attribute);
		    } catch (WTException e) {
		        errorList.add(attribute);
		        logger.warn("Could not load attribute '" + attribute + "'. This is not necessarily an error.");
		        logger.debug(e.getLocalizedMessage(), e);
		    }
		}
		
		return errorList;
	}

	public Object get(String attribute) throws WTException {
		if (logger.isDebugEnabled()) {
			logger.debug("Getting value for attribute: " + attribute);
		}
		return persistableAdapter.get(attribute);
	}

	/**
	 * Returns list of values as Strings for given attribute.
	 * 
	 * @param attribute
	 * @return
	 * @throws WTException
	 */
	public List<String> getAsString(String attribute) throws WTException {
		if (logger.isDebugEnabled()) {
			logger.debug("Getting value for attribute: " + attribute);
		}
		Object value = persistableAdapter.getAsString(attribute);
		if (value instanceof String) {
			return Collections.singletonList((String) value);
		} else {
			// default LWCNormalizedObject's getAsString method returns array of Objects instead of Strings...
			String[] stringValue = Arrays.copyOf((Object[]) value, ((Object[]) value).length, String[].class);
			return Arrays.asList(stringValue);
		}
	}
	
	public List<Entry<String, ?>> set(Map<String, ?> attributes) throws WTException  {
		List<Entry<String, ?>> errorList = new ArrayList<Entry<String, ?>>();
		
		for (Entry<String, ?> attribute : attributes.entrySet()) {
			boolean success = set(attribute.getKey(), attribute.getValue());
			
			if (!success) {
			    errorList.add(attribute);
			}

			if (logger.isDebugEnabled()) {
				logger.debug("set attribute in LWCNOAdapter - key: " + attribute.getKey() + " value: " + attribute.getValue());
			}
		}
		
		return errorList;
	}

	/**
	 * Converts Java's OOTB types to appropriate Windchill's types if necessary and invokes LWCNormalizedObject's default method.
	 * 
	 * @param attribute
	 * @param value
	 * @throws WTException
	 */
	public boolean set(String attribute, Object value) {
	    boolean success = false;
	    
		if (!isEmpty(value) && !isEmpty(attribute)) {
			if (logger.isDebugEnabled()) {
				logger.debug("Setting " + attribute + "'s value to: " + value);
			}
			try {
				persistableAdapter.set(attribute, convertType(value));
				success = true;
			} catch (Exception e) {
			    logger.warn("Cannot set '" + attribute + "' to '" + value + "'.");
				logger.debug(e.getLocalizedMessage(), e);
			}
		} else {
			if (logger.isDebugEnabled()) {
				logger.debug(attribute + "'s value is " + value + " and won't be set");
			}
		}
		
		return success;
	}

	private boolean isEmpty(Object value) {
		if (value == null) {
			return true;
		}
		return value instanceof String && StringUtils.isBlank((String) value);
	}

	/**
	 * Converts attributes' types from Java's OOTB to Windchill's. Float/Double -> FloatingPoint; Integer -> Long;
	 * 
	 * @param value
	 * @return
	 */
	private Object convertType(Object value) {
		Object convertedValue = value;
		if (value != null) {
			if (isDecimalNumber(value)) {
				convertedValue = Long.valueOf(value.toString());
			} else if (isFloatingPointNumber(value)) {
				convertedValue = FloatingPoint.valueOf(value.toString());
			}
			if (logger.isDebugEnabled()) {
				logger.debug("Converted " + value.getClass() + " to " + convertedValue.getClass());
			}
		}
		return convertedValue;
	}

	private boolean isDecimalNumber(Object value) {
		return value instanceof Integer || value instanceof Long;
	}

	private boolean isFloatingPointNumber(Object value) {
		return value instanceof Float || value instanceof Double;
	}

	public void validate() throws WTException {
		persistableAdapter.validate();
	}
	
	public Persistable apply() throws WTException {
		return persistableAdapter.apply();
	}
	
	public TypeInstanceIdentifier persist() throws WTException {
        return persistableAdapter.persist();
	} 
	
	public String toString() {
		return persistableAdapter.toString();
	}
}
