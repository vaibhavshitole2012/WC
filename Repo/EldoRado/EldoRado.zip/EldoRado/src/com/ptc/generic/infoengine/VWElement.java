/*
 * VWElement.java
 *
 * Created on 17. April 2007, 15:43
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.ptc.generic.infoengine;

import java.util.HashMap;

/**
 *
 * @author Simone Graf
 */
public class VWElement extends HashMap {
    
    /** Creates a new instance of VWElement */
    public VWElement() {
    }
    
}
