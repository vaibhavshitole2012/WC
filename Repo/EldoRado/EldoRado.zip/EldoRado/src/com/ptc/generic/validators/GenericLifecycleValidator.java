package com.ptc.generic.validators;

import org.apache.commons.lang.ArrayUtils;

import com.ptc.generic.validators.validatorsResource;

import wt.lifecycle.LifeCycleManaged;
import wt.util.WTMessage;

/**
 * GenericLifecycleValidator
 *
 * Checks if a given object is running in one of the specified life cycles
 *
 * @author cherrmann
 *
 */
public class GenericLifecycleValidator<T extends LifeCycleManaged> implements GenericValidator<T> {

	private ValidationResult validationResult;
	private String errorMessage;

	private String[] validLifeCycleNames;

	/**
	 * GenericLifecycleValidator
	 *
	 * @param lifeCycleNames a list of valid life cycle names
	 */
	public GenericLifecycleValidator(String... lifeCycleNames) {
		this(WTMessage.getLocalizedMessage(VALIDATION_RESOURCE, validatorsResource.INVALID_LIFECYCLE, null), lifeCycleNames);
	}

	/**
	 * GenericLifecycleValidator
	 *
	 * @param errorMessage the default error message
	 * @param lifeCycleNames a list of valid life cycle names
	 */
	public GenericLifecycleValidator(String errorMessage, String[] lifeCycleNames){
		this.validLifeCycleNames = lifeCycleNames;
		this.errorMessage = errorMessage;
	}

	/**
	 * Checks if the given object is running in one of the specified life cylces
	 *
	 * @param object an object of type LifeCycleManaged
	 * @return true if the given object is running in one of the specified life cycles
	 * @see com.ptc.generic.validators.GenericValidator#validate(java.lang.Object)
	 */
	public boolean validate(LifeCycleManaged object) {
		resetValidationResult();

		if (object != null){
			if (this.validLifeCycleNames != null){
				String lcName = ((LifeCycleManaged)object).getLifeCycleName();
				if (!ArrayUtils.contains(this.validLifeCycleNames, lcName)){
					this.validationResult = new ValidationResult(errorMessage, false);
				}
			}
		} else {
			this.validationResult = new ValidationResult(INVALID_PARAMETER_WAS_NULL, false);
		}

		if (this.validationResult == null){
			this.validationResult = new ValidationResult(SUCCESS_MESSAGE, true);
		}

		return this.validationResult.getIsValid();
	}

	public ValidationResult getValidationResult() {
		return this.validationResult;
	}

	public void resetValidationResult(){
		this.validationResult = null;
	}

}
