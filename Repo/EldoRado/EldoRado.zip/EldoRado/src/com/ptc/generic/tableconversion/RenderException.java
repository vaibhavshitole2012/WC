package com.ptc.generic.tableconversion;

public class RenderException extends Exception
{
    /**
     * generated UID
     */
    private static final long serialVersionUID = 4113518921841266405L;

    public RenderException(String s)
    {
        super(s);
    }
  
    public RenderException(String message, Throwable cause) {
        super(message, cause);
    }
}
