/** 

Class for table configuration implementation of the CSV API (used for excel).

@author of extensions for universal rendering: Lothar Germund, PLUS-Systeme GmbH
@since 19.10.2010
*/
package com.ptc.generic.tableconversion;

public class CsvConfigurationImpl extends AbstractExportTableConfiguration
{
    private char delimiter = ';';
    private char quote = '\"'; // switch off with blank ' '
    private int bufferSize = 1;
    /** forces Excel to Ignore Value Contents -> All Values interpreted as String-Values */
    private boolean forceExcelIgnore = false;

    // Strings for the JSP response object
    private final static String RESPONSE_CONTENTTYPE   = "text/comma-separated-values";
    private final static String RESPONSE_FILEEXTENSION = ".csv";

    
    /**
     * Constructor
     */
    public CsvConfigurationImpl() {
        setResponseContentType(RESPONSE_CONTENTTYPE);
        setFileExtensionName(RESPONSE_FILEEXTENSION);
        setEncoding(AbstractExportTableConfiguration.ENCODING_UTF8);
    }

    
    /**
     * @param delimiter to set
     */
    public void setDelimiter(char delimiter)
    {
        this.delimiter = delimiter;
    }


    /**
     * @return the delimiter
     */
    public char getDelimiter()
    {
        return delimiter;
    }

    
    /**
     * @param bufferSize to set
     */
    public void setBufferSize(int bufferSize)
    {
        this.bufferSize = bufferSize;
    }


    /**
     * @return bufferSize
     */
    public int getBufferSize()
    {
        return bufferSize;
    }

    
    /**
     * @param quote to set, blank means no quote
     */
    public void setQuote(char quote)
    {
        this.quote = quote;
    }


    /**
     * @return quote
     */
    public char getQuote()
    {
        return quote;
    }

    /**
     * Excel should be forced to ignore all Values and display them as String-Values.
     * @return
     */
    public boolean isForceExcelIgnore() {
    
        return forceExcelIgnore;
    }

    /**
     * Excel should be forced to ignore all Values and display them as String-Values.
     * @return
     */
    public void setForceExcelIgnore(boolean forceExcelIgnore) {
    
        this.forceExcelIgnore = forceExcelIgnore;
    }
}
