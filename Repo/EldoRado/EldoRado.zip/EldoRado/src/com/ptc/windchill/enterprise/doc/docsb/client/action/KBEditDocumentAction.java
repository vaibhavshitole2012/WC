package com.ptc.windchill.enterprise.doc.docsb.client.action;

import com.ptc.cat.ui.client.action.ActionDefinition;
import com.ptc.cat.ui.client.internal.action.DefaultActionDefinition;

public class KBEditDocumentAction extends EditDocumentAction {

    private static final String FORM_PROCESSOR_CLASS = "ext.kb.processors.KBEditDocFormProcessor";

    public KBEditDocumentAction(ActionDefinition definition) {
        super(definition);
    }

    @Override
    protected void populateActionDefinition(ActionDefinition actionDefinition) {
        super.populateActionDefinition(actionDefinition);
        if (actionDefinition instanceof DefaultActionDefinition) {
            DefaultActionDefinition defaultActionDefinition = (DefaultActionDefinition) actionDefinition;
            defaultActionDefinition.setFormProcessorClass(FORM_PROCESSOR_CLASS);
        }
    }

}
