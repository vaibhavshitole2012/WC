/**
 * 
 */
package com.ptc.windchill.mpml.algorithm;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import wt.fc.ObjectReference;
import wt.inf.container.WTContainerRef;
import wt.log4j.LogR;
import wt.rule.ruleResource;
import wt.rule.algorithm.InvalidAlgorithmArgumentException;
import wt.rule.algorithm.RuleAlgorithm;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.vc.views.View;

import com.ptc.core.meta.common.TypeInstanceIdentifier;
import com.ptc.core.meta.server.TypeIdentifierUtility;

/**
 * @author bankowskie
 *
 */
public class KBViewToLifeCycleAlgorithm implements RuleAlgorithm {

	static final Logger LOG = LogR.getLogger(KBViewToLifeCycleAlgorithm.class.getName());

	@Override
	public Object calculate(Object[] args, WTContainerRef container) throws WTException {
		String message = null;

		if (args.length < 4) {
			Object[] params = { 4, args.length };
			message = WTMessage.getLocalizedMessage(ruleResource.class.getName(), ruleResource.INVALID_ARGUMNET_NUMBER,
					params);
		} else if (args.length % 2 == 1) {
			Object[] params = { args.length, args.length + 1 };
			message = WTMessage.getLocalizedMessage(ruleResource.class.getName(), ruleResource.INVALID_ARGUMNET_NUMBER,
					params);
		}

		if (message != null) {
			if (LOG.isDebugEnabled()) {
				LOG.debug(message);
			}

			throw new InvalidAlgorithmArgumentException(message);
		}

		String lifeCycleName = null;

		if (args[0] != null) {
			TypeInstanceIdentifier tii = (TypeInstanceIdentifier) args[0];
			ObjectReference objectRef = TypeIdentifierUtility.getObjectReference(tii);
			View view = (View) objectRef.getObject();
			Map<String, String> viewToLifeCycle = new HashMap<>();

			for (int i = 2; i < args.length; i++) {

				String viewArg = String.valueOf(args[i++]);
				String lifeCycleArg = String.valueOf(args[i]);

				viewToLifeCycle.put(viewArg, lifeCycleArg);
			}
			lifeCycleName = viewToLifeCycle.get(view.getName());
		}

		if (lifeCycleName == null) {
			lifeCycleName = String.valueOf(args[1]);
		}
		return lifeCycleName;
	}

}
