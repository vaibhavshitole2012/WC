package com.ptc.windchill.enterprise.doc.docsb.client.action;

import com.ptc.cat.ui.client.action.ActionDefinition;
import com.ptc.cat.ui.client.internal.action.DefaultActionDefinition;

public class KBInsertNewDocumentAction extends InsertNewDocumentAction {

    private static final String FORM_PROCESSOR_CLASS = "ext.kb.processors.KBCreateDocFormProcessor";

    public KBInsertNewDocumentAction(ActionDefinition definition) {
        super(definition);
    }

    /**
     * Populate the action definition to execute wizard to create a single new document
     */
    @Override
    protected void populateActionDefinition(ActionDefinition actionDefinition) {

        String url = actionDefinition.getUrl();
        if (actionDefinition instanceof DefaultActionDefinition) {
            DefaultActionDefinition defaultActionDefinition = (DefaultActionDefinition) actionDefinition;

            defaultActionDefinition.setFormProcessorClass(FORM_PROCESSOR_CLASS);
            defaultActionDefinition.setUrl(url);
        }
    }
}