package com.ptc.ssp.load;

import com.infoengine.object.factory.Group;
import com.infoengine.SAK.IeService;
import com.infoengine.SAK.Webject;

import java.util.StringTokenizer;
import java.util.Vector;

import org.apache.log4j.Logger;

import wt.fc.Persistable;
import wt.fc.ReferenceFactory;
import wt.log4j.LogR;
import wt.org.OrganizationServicesHelper;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.util.WTProperties;

public class LoadHelper{
	private static Logger logger = null;
	private static String instance;
	
		
	/**
	 * Setup the Log4j logging and read wt.properties for the Windchill instance name
	 */
	static{
		try{
			logger = LogR.getLogger("com.ptc.ssp.load");
		}catch(Throwable t){
			System.out.println("Error Loading Logging Resource");
			t.printStackTrace();
			throw new ExceptionInInitializerError(t);
		}
		
		try{
			WTProperties props = WTProperties.getLocalProperties();
			instance = props.getProperty("wt.federation.ie.VMName");
		}catch(Throwable t){
			System.out.println("Error reading WTProperties");
			t.printStackTrace();
			throw new ExceptionInInitializerError(t);
		}
	}
	
	/**
	 * Queries for an object using the given type and where clause fragments
	 *
	 * @param objType- A String containing the object type to query for
	 * @param where- A string containing the where clause to use for the query
	 *
	 * @return Persistable that is the object matching the given terms, or null if that object doesn't exist
	 */
	public static Persistable queryForObject(String objType, String where){
		Vector<String> v = new Vector<String>();
		v.add(where);
		
		return queryForObject(objType, v);
	}
	
	/**
	 * Queries for an object using the given type and where clause fragments
	 *
	 * @param objType- A String containing the object type to query for
	 * @param whereClause- A Vector where each element contains a where clause
	 *
	 * @return Persistable that is the object matching the biven terms, or null if that object doesn't exist
	 */
	public static Persistable queryForObject(String objType, Vector<String> whereClause){
		Persistable p = null;
		
		try{
			logger.debug("Entering LoadServerHelper.queryForObject");
			
			IeService ie = new IeService();
			Webject task = new Webject("Query-Objects", "OBJ", ie);
			
			task.setUserName(SessionHelper.getPrincipal().getName());
			task.addParam("INSTANCE", instance);
			task.addParam("TYPE", objType);
			task.addParam("GROUP_OUT", "obj");
			
			if(whereClause.size() < 1){
				throw new WTException("The where clause must contain at least 1 expression");
			}
			
			for(int i=0; i<whereClause.size(); i++){
				task.addParam("WHERE", (String)whereClause.get(i));
			}
			
			task.invoke();
			
			Group obj = ie.getGroup("obj");
			
			if(obj.getElementCount() > 0){
				if(obj.getElementCount() > 1){
					throw new WTException("Multiple results returned when querying for obj of type " + objType);
				}
				
				logger.debug("queryForObject: obid = " + (String)obj.getAttributeValue(0, "obid"));
				
				if("wt.org.WTPrincipal".equals(objType) || "wt.org.WTUser".equals(objType) || "wt.org.WTGroup".equals(objType)){
					String obid = (String)obj.getAttributeValue(0, "obid");
					String oid = obid.substring(0, obid.indexOf(":"));
					p = (Persistable)OrganizationServicesHelper.manager.getPrincipalByDN(oid);
				}else{
					p = convertOidtoObject((String)obj.getAttributeValue(0, "obid"));
				}
			}
		}catch(Exception e){
			e.printStackTrace();
			System.out.println("Error in queryForObject(String, Vector)");
		}
		
		return p;
	}
	
	/**
	 * method to take an oid in string form and convert it to a Persistable object
	 *
	 * @param oid- The oid to convert from String to Persistable
	 *
	 * @return Persistable- the Persistable object represented by the given oid
	 */
	private static Persistable convertOidtoObject(String oid) throws Exception{
		ReferenceFactory rf = new ReferenceFactory();
		StringTokenizer st = new StringTokenizer(oid, ":");
		String obid = st.nextToken();
		obid = st.nextToken() + ":" + st.nextToken();
		
		return rf.getReference(obid).getObject();		
	}
}