/* bcwti
 *
 * Copyright (c) 2009 Parametric Technology Corporation (PTC). All Rights
 * Reserved.
 *
 * This software is the confidential and proprietary information of PTC.
 * You shall not disclose such confidential information and shall use it
 * only in accordance with the terms of the license agreement.
 *
 * ecwti
 */
package com.deploy.util;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.TypeIdentifierHelper;
import com.ptc.core.meta.type.mgmt.server.impl.association.AssociationConstraintHelper;
import com.ptc.core.meta.type.mgmt.server.impl.association.AssociationConstraintItem;

import com.ptc.core.meta.type.mgmt.server.impl.association.DefaultAssociationConstraintItem;
import org.apache.solr.client.solrj.request.CoreAdminRequest;
import wt.fc.PersistInfo;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.load.LoadServerHelper;
import wt.util.WTException;

public class DeleteRelationshipConstraintsLoader {

	private static final String ROLE_A_TYPE = "roleAType";
	private static final String ROLE_B_TYPE = "roleBType";
	private static final String LINK_TYPE = "linkType";

	@SuppressWarnings("rawtypes")
	public static boolean remove(Hashtable values, Hashtable cmdLine, Vector returnObjects) throws WTException {

		final String linkType = getValue(LINK_TYPE, values, cmdLine, LoadServerHelper.REQUIRED);

		TypeIdentifier typeId = TypeIdentifierHelper.getTypeIdentifier(linkType);
		List<AssociationConstraintItem> listAssociation = AssociationConstraintHelper.service.getAssociationConstraintItemsByExplicitLinkType(typeId);

		Iterator<AssociationConstraintItem> it = listAssociation.iterator();

		while (it.hasNext()) {
			Object obj = it.next();
			if (obj instanceof DefaultAssociationConstraintItem) {
				boolean shouldBeRemoved = shouldBeRemoved(values, (Persistable) obj);
				PersistInfo info = ((Persistable) obj).getPersistInfo();
				if (info != null && info.isPersisted() && shouldBeRemoved) {
						PersistenceHelper.manager.delete((Persistable) obj);
				}
			}
		}

		return true;
	}

	@SuppressWarnings("rawtypes")
	protected static String getValue(String name, Hashtable values, Hashtable cmdLine, int requiredValue) throws WTException {

		String value = LoadServerHelper.getValue(name, values, cmdLine, requiredValue);

		if (value != null) {
			value = value.trim();

			if ("".equals(value)) {
				value = null;
			}
		}

		return value;
	}

	private static TypeIdentifier getTypeIdentifierForRole(Hashtable values, String role) {
		String roleType = (String) values.get(role);
		return TypeIdentifierHelper.getTypeIdentifier(roleType);
	}

	private static boolean shouldBeRemoved(Hashtable values, Persistable persistable){
		DefaultAssociationConstraintItem constraintItem;
		if(persistable instanceof DefaultAssociationConstraintItem){
			constraintItem = (DefaultAssociationConstraintItem) persistable;
		}else{
			return false;
		}

		TypeIdentifier roleATypeIdentifierFromFile = getTypeIdentifierForRole(values, ROLE_A_TYPE);
		TypeIdentifier roleBTypeIdentifierFromFile = getTypeIdentifierForRole(values, ROLE_B_TYPE);
		TypeIdentifier roleATypeIdentifier = constraintItem.getRoleATypeIdentifier();
		TypeIdentifier roleBTypeIdentifier = constraintItem.getRoleBTypeIdentifier();

		if(roleATypeIdentifier.equals(roleATypeIdentifierFromFile) &&
			roleBTypeIdentifier.equals(roleBTypeIdentifierFromFile)){
			return true;
		}else {
			return false;
		}
	}
}
