package com.deploy.util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

import org.apache.log4j.Appender;
import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Layout;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;

import wt.access.AccessPolicyRule;
import wt.access.WTAclEntry;
import wt.admin.AdministrativeDomain;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.inf.container.WTContainer;
import wt.inf.team.ContainerTeam;
import wt.inf.team.ContainerTeamHelper;
import wt.inf.team.ContainerTeamManaged;
import wt.method.RemoteMethodServer;
import wt.org.OrganizationServicesHelper;
import wt.org.WTGroup;
import wt.org.WTPrincipal;
import wt.org.WTPrincipalReference;
import wt.org.WTRolePrincipal;
import wt.org.WTUser;
import wt.pds.StatementSpec;
import wt.project.Role;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;

import com.ptc.wpcfg.utilities.PrincipalHelper;

// TODO: Auto-generated Javadoc
/**
 * The Class DeletePrincipal.
 */
public class DeletePrincipal {

	/**
	 * The Constant CLASSNAME.
	 */
	private static final String CLASSNAME = DeletePrincipal.class.getName();

	/**
	 * The args.
	 */
	private String[] args;

	/**
	 * The logger.
	 */
	private static Logger logger = null;

	static {
		logger = Logger.getLogger(CLASSNAME);
		Layout layout = new PatternLayout("");
		Appender console = new ConsoleAppender(layout);
		logger.addAppender(console);
		Level level = Level.DEBUG;
		logger.setLevel(level);
	}

	/**
	 * Instantiates a new delete principal.
	 *
	 * @param args
	 *            the args
	 */
	public DeletePrincipal(String[] args) {
		this.args = args;
	}

	/**
	 * The main method.
	 *
	 * @param args
	 *            the arguments
	 */
	public static void main(String[] args) {
		new DeletePrincipal(args).run();
	}

	/**
	 * Run.
	 */
	public void run() {
		logger.info("DeletePrincipal starts");
		if (args.length < 4 || args.length > 14) {
			printUsage();
			logger.info("DeletePrincipal ends with status 1");
			System.exit(1);
		}

		// Authenticate to Windchill as wcadmin
		String login = args[0];
		String password = args[1];
		authenticate(login, password);

		// start processing part
		process();
		logger.info("DeletePrincipal ends with status 0");
		System.exit(0);
	}

	/**
	 * Authenticate.
	 *
	 * @param username
	 *            the username
	 * @param password
	 *            the password
	 */
	private void authenticate(String username, String password) {
		RemoteMethodServer remoteMethodServer = RemoteMethodServer.getDefault();
		remoteMethodServer.setUserName(username);
		remoteMethodServer.setPassword(password);
		try {
			WTPrincipal currentUser = SessionHelper.manager.getPrincipal();
			WTPrincipal wtAdministrator = SessionHelper.manager.getAdministrator();
			if (!currentUser.equals(wtAdministrator)) {
				logger.info("Invalid user! DeletePrincipal may be launched by Windchill Administrator only \nDeletePrincipal ends with status 1");
				System.exit(1);
			}
		} catch (WTException e) {
			logger.error("Authentication failed! " + e.getLocalizedMessage() + "\nDeletePrincipal ends with status 1");
			logger.error(" Exception :" + e.toString());
			System.exit(1);
		}
	}

	/**
	 * Process.
	 */
	public void process() {
		try {
			List<String> arguments = Arrays.asList(args);
			// if file has been specified
			Map<String, String> argumentMap = new HashMap<String, String>();

      //Preprocess actions arguments except -f
			String[] theActions = new String[] { "-u", "-uW", "-g", "-gW", "-r" };
			for (String action : theActions) {
				 	if (arguments.contains(action)) {
									String argValue = arguments.get(arguments.indexOf(action) + 1);
			            argumentMap.put (action,argValue);
			    }
			}
	
			logger.info("arguments= "+ arguments);
			if (arguments.contains("-f")) {
				// process contents from file
				try {
					int indexOfFilePath = arguments.indexOf("-f") + 1;
					String filePath = arguments.get(indexOfFilePath);
					
					BufferedReader reader = new BufferedReader(new FileReader(filePath));
					String textLine = "";
					String unknown="UNKNOWN";
					// read file line by line
					while ((textLine = reader.readLine()) != null) {
						// for all possible actions (like delete user in WT and
						// LDAP -u)
						textLine = textLine.trim();
						String[] possibleActions = new String[] { "-u", "-uW", "-g", "-gW", "-r" };
						boolean foundAction = false;
						for (String action : possibleActions) {
							
							if (textLine.startsWith(action)) {
								foundAction=true;
								logger.info("action= "+ action);
								// remove "action's" part of string
								textLine = textLine.replaceFirst(action, "");
								textLine = textLine.trim();
								// if list of arguments contains already the
								// same action
							  String previousValue = "";
							  if (argumentMap.containsKey(action) ) {
							        previousValue=argumentMap.get(action);
                 			// concatenate both values (new and
									    // from textline)
                      String nextvalue=previousValue.concat(",").concat(textLine);
							        argumentMap.put (action,nextvalue);
							  }else{
							      argumentMap.put (action,textLine);	     
                }									  
							}
						}
						if(!foundAction){
								if (!argumentMap.containsKey(unknown)){
									argumentMap.put (unknown,textLine);
							  }else{
							  	String texUnknown=argumentMap.get(unknown);
							  	texUnknown=texUnknown.concat(",").concat(textLine);
							  	logger.info("texUnknown= "+ texUnknown);
							  	argumentMap.put (unknown,texUnknown);
						  	}
						  	
					  }
					  foundAction=false;
					}
						
					
					if (argumentMap.containsKey(unknown)){
						    String text2=argumentMap.get(unknown);
					      throw new IOException("Some data can from "+ filePath +" not be processed: \n"+text2);
				  }else{
				  	logger.info("Data in file processed successfully");
				  	
				  }
				} catch (IOException e) {
					logger.error("Unable to load data from file specified.\nDeletePrincipal ends with status 1");
					logger.error(" Exception :" + e.toString());
				}
			}
			if (argumentMap.containsKey("-u")) {
				// users to delete from Windchill and LDAP
				String[] usernames = argumentMap.get("-u").split(",");
				logger.info("Removing WTUser instances from Windchill and LDAP.");
				for (String username : usernames) {
					logger.info("User to remove: " + username);
					WTPrincipalReference principalReference = PrincipalHelper.getPrincipal(username);
					if (principalReference != null) {
						WTPrincipal principal = principalReference.getPrincipal();
						if (principal instanceof WTUser) {
							WTUser user = (WTUser) principal;
							user = OrganizationServicesHelper.manager.delete(user);
							logger.info("User '" + user.getName() + "' has been deleted from Windchill and LDAP");
						} else {
							logger.warn("Principal isn't instance of WTUser class! Skipping...");
						}
					} else {
						logger.warn("Principal not found! Skipping...");
					}
				}
			}
			if (argumentMap.containsKey("-uW")) {
				// users to delete from Windchill only
				String[] usernames = argumentMap.get("-uW").split(",");
				logger.info("Removing WTUser instances from Windchill.");
				for (String username : usernames) {
					logger.info("User to remove: " + username);
					WTPrincipalReference principalReference = PrincipalHelper.getPrincipal(username);
					if (principalReference != null) {
						WTPrincipal principal = principalReference.getPrincipal();
						if (principal instanceof WTUser) {
							WTUser user = (WTUser) principal;
							user = (WTUser) OrganizationServicesHelper.manager.disablePrincipal(user);
							logger.info("User '" + user.getName() + "' has been deleted from Windchill");
						} else {
							logger.warn("Principal isn't instance of WTUser class! Skipping...");
						}
					} else {
						logger.warn("Principal not found! Skipping...");
					}
				}
			}
			if (argumentMap.containsKey("-g")) {
				// groups to delete from Windchill and LDAP
				String[] groups = argumentMap.get("-g").split(",");
				logger.info("Removing WTGroup instances from Windchill and LDAP.");
				for (String groupWithContext : groups) {
					logger.info("Group to remove: " + groupWithContext);
					String[] groupAndContext = groupWithContext.split(":");
					String groupName = groupAndContext[0];
					String groupContext = null;
					if (groupAndContext.length > 1) {
						groupContext = groupAndContext[1];
					}
					QuerySpec qs = new QuerySpec(WTGroup.class);
					qs.appendWhere(new SearchCondition(WTGroup.class, WTGroup.NAME, SearchCondition.EQUAL, groupName),
							new int[] { 0 });
					QueryResult qr = PersistenceHelper.manager.find((StatementSpec) qs);

					if (qr.hasMoreElements()) {
						while (qr.hasMoreElements()) {
						WTGroup group = (WTGroup) qr.nextElement();
							if (groupContext != null) {
								if (group.getContainerPath().equals(groupContext)) {
						group = OrganizationServicesHelper.manager.delete(group);
									logger.info("Group '" + group.getName() + "' has been deleted from context '"
											+ group.getContainerPath() + "' from Windchill and LDAP");
									break;
								}
							} else {
								group = OrganizationServicesHelper.manager.delete(group);
								logger.info("Group '" + group.getName() + "' has been deleted from context '"
										+ group.getContainerPath() + "' from Windchill and LDAP");
							}
						}
					} else {
						logger.warn("Group not found! Skipping...");
					}
				}
			}
			if (argumentMap.containsKey("-gW")) {
				// groups to delete from Windchill only
				String[] groups = argumentMap.get("-gW").split(",");
				logger.info("Removing WTGroup instances from Windchill.");
				for (String groupWithContext : groups) {
					logger.info("Group to remove: " + groupWithContext);
					String[] groupAndContext = groupWithContext.split(":");
					String groupName = groupAndContext[0];
					String groupContext = null;
					if (groupAndContext.length > 1) {
						groupContext = groupAndContext[1];
					}
					QuerySpec qs = new QuerySpec(WTGroup.class);
					qs.appendWhere(new SearchCondition(WTGroup.class, WTGroup.NAME, SearchCondition.EQUAL, groupName),
							new int[] { 0 });
					QueryResult qr = PersistenceHelper.manager.find((StatementSpec) qs);

					if (qr.hasMoreElements()) {
						while (qr.hasMoreElements()) {
						WTGroup group = (WTGroup) qr.nextElement();
							if (groupContext != null) {
								if (group.getContainerPath().equals(groupContext)) {
						group = (WTGroup) OrganizationServicesHelper.manager.disablePrincipal(group);
									logger.info("Group '" + group.getName() + "' has been deleted from context '"
											+ group.getContainerPath() + "' from Windchill");
									break;
								}
							} else {
								group = (WTGroup) OrganizationServicesHelper.manager.disablePrincipal(group);
								logger.info("Group '" + group.getName() + "' has been deleted from context '"
										+ group.getContainerPath() + "' from Windchill");
							}
						}
					} else {
						logger.warn("Group not found! Skipping...");
					}
				}
			}
			if (argumentMap.containsKey("-r")) {
				logger.info("Finally Removing roles to from Windchill container.");
				String[] roleContainerPairs = argumentMap.get("-r").split(",");
				logger.info("Specified roleContainerPairs: " + roleContainerPairs);
				for (String roleContainerPair : roleContainerPairs) {
					String[] roleNameAndContainer = roleContainerPair.split(":");
					String roleName=roleNameAndContainer[0];
					String classAndNameContainer = null;
					String containerClassName="";
					String containerName="";
					
				if (roleNameAndContainer.length > 1){
					    classAndNameContainer=roleNameAndContainer[1];
							String[] containerData = classAndNameContainer.split("/");
					    containerClassName = containerData[0];
					    if (containerData.length > 1){
						    containerName = containerData[1];
						    if (containerClassName!=null && containerName!=null ){
									logger.info("Specified role: " + roleName + ", specified container: " + containerData);
									Role role = Role.toRole(roleName);
									Class<WTContainer> containerClass = (Class<WTContainer>) Class.forName(containerClassName);
									QuerySpec containerQuery = new QuerySpec(containerClass);
									containerQuery.appendWhere(new SearchCondition(containerClass, "containerInfo.name",
											SearchCondition.EQUAL, containerName), new int[] { 0 });
									QueryResult foundContainer = PersistenceHelper.manager.find((StatementSpec) containerQuery);
									if (!foundContainer.hasMoreElements()) {
										throw new WTException("No container found with name: " + containerName);
									}
									WTContainer container = (WTContainer) foundContainer.nextElement();
									logger.info("Found role: " + roleName + ", found container: " + container.getName());
				
									ContainerTeam containerTeam = ContainerTeamHelper.service
											.getContainerTeam((ContainerTeamManaged) container);
				
									// check whether the role might be removed (role cannot have
									// any ACLs related)
									QueryResult wtAclEntries = getRelatedAclEntries(role, container);
									if (wtAclEntries.size() > 0) {
										logger.info("Role "+roleName+"cannot be deleted, as it's used in ACL entries directly.");
										// display related ACLs
										while (wtAclEntries.hasMoreElements()) {
											WTAclEntry aclEntry = (WTAclEntry) wtAclEntries.nextElement();
											logger.warn("Access permissions: "
													+ aclEntry.getPermissionSet().getDisplay()
													+ ", Access role: "
													+ aclEntry.getPrincipalReference().getDisplayName()
													+ ", Lifecycle state: "
													+ ((AccessPolicyRule) aclEntry.getAcl()).getSelector().getStateName()
													+ ", Object's type: "
													+ ((AccessPolicyRule) aclEntry.getAcl()).getSelector().getTypeId()
													+ ", Container: "
													+ ((AdministrativeDomain) ((AccessPolicyRule) aclEntry.getAcl()).getDomainRef()
															.getObject()).getContainerName()
													+ ", Domain: "
													+ ((AdministrativeDomain) ((AccessPolicyRule) aclEntry.getAcl()).getDomainRef()
															.getObject()).getName());
										}
									} else {
										// check whether there the role has been added to the
										// container
										if (containerTeam.getRoles().contains(role)) {
											// delete and display confirmation
											containerTeam.deleteRole(role);
											logger.info("Role '" + roleName + "' has been deleted from container '"
													+ container.getName() + "'.");
										} else {
											// display warning if the role is not assigned to
											// the container
											logger.info("Role '" + roleName + "' not found in container '" + container.getName() + "'.");
										}
									}
								}
				      }
				    }
				  }
			}

		} catch (WTException e) {
			logger.error("Exception!! " + e.getLocalizedMessage() + "  \nDeletePrincipal ends with status 1");
			logger.error(" Exception :" + e.toString());
			System.exit(1);
		} catch (ClassNotFoundException e) {
			logger.error("Exception while retrieving container!! " + e.getLocalizedMessage()
					+ "  \nDeletePrincipal ends with status 1");
			logger.error(" Exception :" + e.toString());
			System.exit(1);
		}
	}

	/**
	 * Prints the usage.
	 */
	private void printUsage() {
		System.out
				.println("Usage: DeletePrincipal <login> <password> -r <role1:container1,..> -u <user1,..> -g <group1,..> -f <path to file with list of users/roles/groups> \n"
						+ "Delete users/groups/roles from the WT system and LDAP\n"
						+ "<login> - login of Windchill administrator\n"
						+ "<password> - password of Windchill administrator\n"
						+ "-r <roles> - comma separated list of roles to be deleted \n"
						+ "-g <groups> - comma separated list of groups to be deleted from LDAP and Windchill\n"
						+ "-gW <groups> - comma separated list of groups to be deleted  only from Windchill\n"
						+ "-u <users> - comma separated list of users to be deleted from LDAP and Windchill\n"
						+ "-uW <users> - comma separated list of users to be deleted only from Windchill\n"
						+ "-f <path to file with users/roles/groups> - path to file with users/roles/groups to be deleted\n"
						+ "EXAMPLE: windchill com.eads.efw.common.tools.DeletePrincipal <login> <password> -r <roles> -u <users> -g <groups> -f <path to file with users/roles/groups>");
	}

	// @deprecated
	/**
	 * Test.
	 */
	private static void test() {
		try {

			QuerySpec qs = new QuerySpec(WTAclEntry.class);
			QueryResult qr = PersistenceHelper.manager.find(qs);
			logger.debug(qr.hasMoreElements());
			WTAclEntry aclEntry = (WTAclEntry) qr.nextElement();
			logger.debug(aclEntry.getPrincipalReference());
		} catch (WTException e) {
			// TODO Auto-generated catch block
			logger.error(" Exception :" + e.toString());
		}
	}

	// search for ACLs based on role (principal) and container (context)
	/**
	 * Gets the related acl entries.
	 *
	 * @param role
	 *            the role
	 * @param container
	 *            the container
	 * @return the related acl entries
	 * @throws WTException
	 *             the wT exception
	 */
	private static QueryResult getRelatedAclEntries(Role role, WTContainer container) throws WTException {
		String roleName = role.getDisplay();
		// get container's classname and id
		long containerId = container.getPersistInfo().getObjectIdentifier().getId();
		String containerClassname = container.getPersistInfo().getObjectIdentifier().getClassname();
		try {
			// query for acl entry
			QuerySpec wtAclEntryQuery = new QuerySpec(WTAclEntry.class);
			// add related tables (WTACLENTRY, WTROLEPRINCIPAL,
			// WTACCESSPOLICYRULE, ADMINISTRATIVEDOMAIN)
			int wtAclEntryIndex = wtAclEntryQuery.addClassList(WTAclEntry.class, true);
			int wtRolePrincipalIndex = wtAclEntryQuery.addClassList(WTRolePrincipal.class, false);
			int wtAccessPolicyRuleIndex = wtAclEntryQuery.addClassList(AccessPolicyRule.class, false);
			int administrativeDomainIndex = wtAclEntryQuery.addClassList(AdministrativeDomain.class, false);
			wtAclEntryQuery.setQuerySet(false);
			// add where for related role
			SearchCondition roleWhere = new SearchCondition(WTAclEntry.class, "principalReference.key.id",
					WTRolePrincipal.class, "thePersistInfo.theObjectIdentifier.id");
			wtAclEntryQuery.appendWhere(roleWhere, new int[] { wtAclEntryIndex, wtRolePrincipalIndex });
			wtAclEntryQuery.appendAnd();
			// add where for rolename
			SearchCondition roleNameWhere = new SearchCondition(WTRolePrincipal.class, WTRolePrincipal.NAME,
					SearchCondition.EQUAL, roleName);
			wtAclEntryQuery.appendWhere(roleNameWhere, new int[] { wtRolePrincipalIndex, -1 });
			wtAclEntryQuery.appendAnd();
			// add where for related AccessPolicyRule
			SearchCondition wtAclEntryWhere = new SearchCondition(WTAclEntry.class, "aclReference.key.id",
					AccessPolicyRule.class, "thePersistInfo.theObjectIdentifier.id");
			wtAclEntryQuery.appendWhere(wtAclEntryWhere, new int[] { wtAclEntryIndex, wtAccessPolicyRuleIndex });
			wtAclEntryQuery.appendAnd();
			// add where for related AdministrativeDomain
			SearchCondition administrativeDomainWhere = new SearchCondition(AccessPolicyRule.class, "domainRef.key.id",
					AdministrativeDomain.class, "thePersistInfo.theObjectIdentifier.id");
			wtAclEntryQuery.appendWhere(administrativeDomainWhere, new int[] { wtAccessPolicyRuleIndex,
					administrativeDomainIndex });
			wtAclEntryQuery.appendAnd();
			// add where for container's class
			SearchCondition containerClassnameWhere = new SearchCondition(AdministrativeDomain.class,
					"containerReference.key.classname", SearchCondition.EQUAL, containerClassname);
			wtAclEntryQuery.appendWhere(containerClassnameWhere, new int[] { administrativeDomainIndex, -1 });
			wtAclEntryQuery.appendAnd();
			// add where for container's id
			SearchCondition containerIdWhere = new SearchCondition(AdministrativeDomain.class,
					"containerReference.key.id", SearchCondition.EQUAL, containerId);
			wtAclEntryQuery.appendWhere(containerIdWhere, new int[] { administrativeDomainIndex, -1 });
			return PersistenceHelper.manager.find((StatementSpec) wtAclEntryQuery);
		} catch (WTException e) {
			logger.warn("Unable to execute query for ACLs related to role '" + roleName
					+ "' in order check, whether the role may be deleted. Exception: ");
			logger.error(" Exception :" + e.toString());
			throw e;
		} catch (WTPropertyVetoException e) {
			logger.warn("Unable to execute query for ACLs related to role '" + roleName
					+ "' in order check, whether the role may be deleted. Exception: ");
			logger.error(" Exception :" + e.toString());
			throw new WTException(e);
		}
	}
}
