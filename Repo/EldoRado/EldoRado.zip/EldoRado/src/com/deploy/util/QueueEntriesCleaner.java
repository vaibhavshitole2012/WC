package com.deploy.util;

import wt.method.RemoteMethodServer;
import wt.queue.ProcessingQueue;
import wt.queue.QueueHelper;
import wt.queue.ScheduleQueue;
import wt.queue.WtQueue;
import wt.session.SessionHelper;
import wt.util.WTException;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Scanner;
import java.util.Vector;

/**
 * @author pozniewskip Utility class, created for automation of queue entries
 *         cleaning
 * 
 */
public class QueueEntriesCleaner {
	private static final String FAILED = "FAILED";
	private static final String SEVERE = "SEVERE";
	private static final String WAITING = "READY";

	static final boolean SERVER = RemoteMethodServer.ServerFlag;
	private static List<String> validQueuesList = new ArrayList<String>();
	private static String siteAdmin;
	private static String siteAdminPassword;
	private static String fullQueueLstPath;
	private static Boolean help = false;
	private static Boolean silent = false;
	private static Boolean severe = false;
	private static Boolean failed = false;
	private static Boolean waiting = false;
	private static Boolean fullClean = false;

	/**
	 * @param args
	 *            Arguments taken from command line: site administrator name and
	 *            password
	 * @throws IOException
	 * @throws WTException
	 */
	public static void main(String[] args) throws IOException, WTException {

		String sep = System.getProperty("file.separator");

		parseArgs(args);
		File queueLstFile = new File(fullQueueLstPath);

		// Fill the queueList with strings from clean_queue.lst file
		ArrayList<String> queueList = new ArrayList<String>();
		Scanner s = new Scanner(queueLstFile);
		while (s.hasNext()) {
			queueList.add(s.next());
		}
		s.close();

		try {
			if (siteAdmin != null && siteAdminPassword != null) {

				RemoteMethodServer rms = RemoteMethodServer.getDefault();
				rms.setUserName(siteAdmin);
				rms.setPassword(siteAdminPassword);

				// start session
				SessionHelper.manager.setAdministrator();

				// Start deletion of queues
				startDeleteQueues(queueList);
			} else {
				startDeleteQueues(queueList);
			}

		} catch (WTException wte) {
			System.out.println("WTException:  ");
			wte.printStackTrace();
		}

	}

	private static void parseArgs(String[] args) {
		for (int i = 0; i < args.length; i++) {
			String arg = args[i];

			if (arg.equalsIgnoreCase("-h") || arg.equalsIgnoreCase("--help")) {
				printHelp();
				System.exit(1);
			}
			if (arg.equalsIgnoreCase("-u")) {
				siteAdmin = args[i + 1];
			}
			if (arg.equalsIgnoreCase("-p")) {
				siteAdminPassword = args[i + 1];
			}
			if (arg.equalsIgnoreCase("-t")) {
				fullQueueLstPath = args[i + 1];
			}
			if (arg.equalsIgnoreCase("-s") || arg.equalsIgnoreCase("--silent")) {
				silent = true;
			}
			if (arg.equalsIgnoreCase("--option=failed")) {
				failed = true;
			}
			if (arg.equalsIgnoreCase("--option=severed")) {
				severe = true;
			}
			if (arg.equalsIgnoreCase("--option=waiting")) {
				waiting = true;
			}
			if (arg.equalsIgnoreCase("--option=all")) {
				fullClean = true;
			}
		}
		if (fullQueueLstPath == null) {
			System.out.println("Error: Path for clean_queue.lst file is missing!  \n");
			printHelp();
			System.exit(1);
		}
	}

	private static void startDeleteQueues(List<String> queueList) throws WTException {
		System.out.println("\n\n========QueueEntriesCleaner==========");

		checkIfQueueListIsValid(queueList); // check if queues are valid

		if (!(validQueuesList.isEmpty())) {
			System.out.println("\n QueueEntriesCleaner will remove entries of following queues:");
			System.out.println("-----------------------------------------------");
			for (String queue : validQueuesList) {
				System.out.println("\t" + queue);
			}
			System.out.println("\n\n");

		} else {
			System.out.println("\n queue.lst is empty!");
			System.out.println("=======EXITING=========");
			System.exit(1);
		}
		if (!silent) {
			System.out.println("\n Continue?[Y/N]");
			Scanner sc = new Scanner(System.in);
			if (sc.hasNext() && (sc.nextLine().equalsIgnoreCase("y"))) {
				executeDeleteQueues();
			} else {
				System.out.println("=========EXITING=============");
				System.exit(1);
			}
		} else {
			executeDeleteQueues();
		}

	}

	private static void executeDeleteQueues() throws WTException {
		if (!fullClean && !failed && !severe && !waiting) {
			System.out.println("Missing --option=<option> argument !! ");
			printHelp();
		}
		if (fullClean) {
			deleteAllQueueEntries();
		} else {
			if (failed) {
				deleteSpecificEntries(FAILED);
			}
			if (severe) {
				deleteSpecificEntries(SEVERE);
			}
			if (waiting) {
				deleteSpecificEntries(WAITING);
			}
		}

	}

	private static void deleteSpecificEntries(String entryOption) throws WTException {
		Vector validQueues = fillQueuesFromValidQueuesList();
		WtQueue wtqueue;
		String entryOptStr = "";

		if (entryOption.equalsIgnoreCase(FAILED)) {
			entryOptStr = "failed";
		}
		if (entryOption.equalsIgnoreCase(SEVERE)) {
			entryOptStr = "severed";
		}
		if (entryOption.equalsIgnoreCase(WAITING)) {
			entryOptStr = "waiting";
		}

		for (Object q : validQueues) {
			wtqueue = (WtQueue) q;

			try {
				if (wtqueue instanceof ProcessingQueue) {
					System.out.println("CLEANING \"" + entryOptStr + "\" entries of: " + wtqueue.getName());
					QueueHelper.manager.deleteEntries((ProcessingQueue) wtqueue, entryOption);
					System.out.println("\t  " + wtqueue.getName() + " has been cleaned\n");
				} else {
					System.out.println("CLEANING \"" + entryOptStr + "\" entries of: " + wtqueue.getName());
					QueueHelper.manager.deleteEntries((ScheduleQueue) wtqueue, entryOption);
					System.out.println("\t  " + wtqueue.getName() + " has been cleaned\n");
				}

			} catch (WTException e) {
				System.out.println(e.getLocalizedMessage());
			}
		}

	}

	/**
	 * Deletes entries of queues from validQueues list
	 * 
	 * @throws WTException
	 */
	private static void deleteAllQueueEntries() throws WTException {

		Vector validQueues = fillQueuesFromValidQueuesList();
		WtQueue wtqueue;
		for (Object q : validQueues) {
			wtqueue = (WtQueue) q;

			try {
				if (wtqueue instanceof ProcessingQueue) {
					System.out.println("CLEANING all entries of queue : " + wtqueue.getName());
					QueueHelper.manager.deleteEntries((ProcessingQueue) wtqueue);
					System.out.println("\t  " + wtqueue.getName() + " has been cleaned\n");
				} else {
					System.out.println("CLEANING all entries of queue : " + wtqueue.getName());
					QueueHelper.manager.deleteEntries((ScheduleQueue) wtqueue);
					System.out.println("\t  " + wtqueue.getName() + " has been cleaned\n");
				}

			} catch (WTException wte) {
				System.out.println(wte.getLocalizedMessage());
				return;
			}
		}
	}

	private static Vector fillQueuesFromValidQueuesList() throws WTException {
		Vector queues = getAllQueues();
		WtQueue wtqueue;
		Vector validQueues = new Vector();

		for (String q : validQueuesList) {
			String queueFromLst = q;
			for (Object w : queues) {

				wtqueue = (WtQueue) w;
				String wtqueueStr = wtqueue.getName();

				if (wtqueueStr.equalsIgnoreCase(queueFromLst)) {
					validQueues.add(w);
				}
			}
		}
		return validQueues;
	}

	/**
	 * @param queueList
	 *            Takes String list of queues to be cleaned and checks if queues
	 *            are valid. Fills validQueues list with queues which are
	 *            available on the system
	 * @throws WTException
	 */
	private static void checkIfQueueListIsValid(List<String> queueList) throws WTException {
		Vector queues = getAllQueues();
		WtQueue wtqueue;

		System.out.println("\n Validating clean_queue.lst file:");
		System.out.println("-------------------------------");
		for (String q : queueList) {
			Boolean status = false;
			String queueFromLst = q;
			for (Object w : queues) {

				wtqueue = (WtQueue) w;
				String wtqueueStr = wtqueue.getName();

				if (wtqueueStr.equalsIgnoreCase(queueFromLst)) {
					status = true;
					validQueuesList.add(wtqueueStr);
				}
			}
			if (status == true) {
				System.out.println("\t " + queueFromLst + " queue is valid");
			} else {
				System.out.println("\t " + queueFromLst + " queue doesn't exists");
			}
		}
	}

	/**
	 * @return List of all queues (WtQueues) existing in the system
	 * @throws WTException
	 */
	private static Vector getAllQueues() throws WTException {
		Vector queues = new Vector();
		allQueues(ProcessingQueue.class, queues);
		allQueues(ScheduleQueue.class, queues);
		return queues;
	}

	/**
	 * Gets all queues (WtQueue) of specific type and fill the vector list those
	 * queues
	 * 
	 * @param qtype
	 *            Type of the queue (ProcessingQueue or ScheduleQueue)
	 * @param qz
	 *            Vector list which will be filled with queues
	 * @throws WTException
	 */
	private static void allQueues(Class qtype, Vector qz) throws WTException {
		WtQueue queue;
		Enumeration queueEnum = QueueHelper.manager.queues(qtype);
		while (queueEnum.hasMoreElements()) {
			queue = (WtQueue) queueEnum.nextElement();
			qz.addElement(queue);
		}
	}

	private static void printHelp() {
		System.out.println("\n=========QueueEntriesCleaner Usage: =========");
		System.out.println("\n1) Create and fill the clean_queue.lst file with queues to be cleaned ");
		System.out.println(
				"2) Run queue entries cleaner: \n windchill ext.mtu.utils.QueueEntriesCleaner -u <site admin> -p <site admin password> -t <full path to queue.lst> --option=<entries which you want to delete (all, severed, failed, waiting)>");
		System.out.println(
				"   Or just run:\n windchill ext.mtu.utils.QueueEntriesCleaner -t <full path to queue.lst> \n (you will be explicitly asked for site admin credentials in authorization panel)");
		System.out.println(
				"3) To delete only failed, severed or waiting entries add following argument accordingly: --option=failed, --option=severed, --option=waiting");
		System.out.println("4) To execute full queue clean use \"--option=all\" argument");

	}
}