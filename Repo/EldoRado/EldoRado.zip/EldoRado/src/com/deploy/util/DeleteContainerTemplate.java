package com.deploy.util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.apache.log4j.Appender;
import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Layout;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;

import com.ptc.wvs.livecycle.assembler.ContainerTemplate;

import wt.doc.WTDocument;
import wt.enterprise.EnterpriseHelper;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.inf.container.LookupSpec;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerHelper;
import wt.inf.container.WTContainerRef;
import wt.inf.container.WTContainerTemplate;
import wt.inf.container.WTContainerTemplateRef;
import wt.inf.template.ContainerTemplateHelper;
import wt.inf.template.WTContainerTemplateMaster;
import wt.method.RemoteMethodServer;
import wt.org.WTPrincipal;
import wt.pds.StatementSpec;
import wt.query.OrderBy;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;

// TODO: Auto-generated Javadoc
/**
 * The Class DeleteTemplate.
 */
public class DeleteContainerTemplate {

	/**
	 * The Constant CLASSNAME.
	 */
	private static final String CLASSNAME = DeleteContainerTemplate.class.getName();

	/**
	 * The args.
	 */
	private String[] args;

	/**
	 * The logger.
	 */
	private static Logger logger = null;

	static {
		logger = Logger.getLogger(CLASSNAME);
		Layout layout = new PatternLayout("");
		Appender console = new ConsoleAppender(layout);
		logger.addAppender(console);
		Level level = Level.DEBUG;
		logger.setLevel(level);
	}

	/**
	 * Instantiates a new delete template.
	 *
	 * @param args
	 *            the args
	 */
	public DeleteContainerTemplate(String[] args) {
		this.args = args;
	}

	/**
	 * The main method.
	 *
	 * @param args
	 *            the arguments
	 */
	public static void main(String[] args) {
		new DeleteContainerTemplate(args).run();
	}

	/**
	 * Run.
	 */
	public void run() {
		logger.info("DeleteTemplate starts");
		if (args.length > 5 || args.length < 4) {
			printUsage();
			logger.info("DeleteTemplate ends with status 1");
			System.exit(1);
		}

		// Authenticate to Windchill as wcadmin
		String login = args[0];
		String password = args[1];
		authenticate(login, password);

		// start processing part
		process();
		logger.info("DeleteTemplate ends with status 0");
		System.exit(0);
	}

	/**
	 * Authenticate.
	 *
	 * @param username
	 *            the username
	 * @param password
	 *            the password
	 */
	private void authenticate(String username, String password) {
		RemoteMethodServer remoteMethodServer = RemoteMethodServer.getDefault();
		remoteMethodServer.setUserName(username);
		remoteMethodServer.setPassword(password);
		try {
			WTPrincipal currentUser = SessionHelper.manager.getPrincipal();
			WTPrincipal wtAdministrator = SessionHelper.manager.getAdministrator();
			if (!currentUser.equals(wtAdministrator)) {
				logger.info(
						"Invalid user! DeleteTemplate may be launched by Windchill Administrator only \nDeleteTemplate ends with status 1");
				System.exit(1);
			}
		} catch (WTException e) {
			logger.error("Authentication failed! " + e.getLocalizedMessage() + "\nDeletePrincipal ends with status 1");
			logger.error(" Exception :" + e.toString());
			System.exit(1);
		}
	}

	/**
	 * Process.
	 */
	public void process() {
		try {
			// parse arguments
			String templateType = args[2];
			String[] templateNames = null;
			if (args.length == 6 && args[2].equalsIgnoreCase("-f")) {
				templateNames = retrieveTemplateNamesFromFile(args[3]).split(",");
			} else {
				templateNames = args[3].split(",");
			}
			if (templateNames != null) {
				for (String containerName : templateNames) {
					WTContainerTemplate containerTemplate = findProductTemplate(templateType, containerName);
					if (containerTemplate != null) {
						logger.info("Deleting '" + (containerTemplate).getName() + "'...");
						ContainerTemplateHelper.service.deleteContainerTemplate(
								WTContainerTemplateRef.newWTContainerTemplateRef(containerTemplate));
						logger.info("OK");
					} else {
						logger.info("No specified templates found with name: " + containerName + " for container type "
								+ templateType);
					}
				}
			} else {
				logger.info("No specified templates ");
			}
		} catch (WTException e) {
			logger.error(e.getLocalizedMessage() + " Exiting!!!");
			logger.error(" Exception :" + e.toString());
			System.exit(1);
		}
	}

	/**
	 * Retrieve template names from file.
	 *
	 * @param fileName
	 *            the file name
	 * @return the string
	 */
	private static String retrieveTemplateNamesFromFile(String fileName) {
		StringBuilder templateNamesBuilder = new StringBuilder();
		try {
			BufferedReader reader = new BufferedReader(new FileReader(fileName));
			String line = "";
			while ((line = reader.readLine()) != null) {
				templateNamesBuilder.append(line);
				if (!line.endsWith(",")) {
					templateNamesBuilder.append(',');
				}
			}
			return templateNamesBuilder.toString();
		} catch (Exception e) {
			logger.error(" Exception :" + e.toString());
			return "";
		}
	}

	public static WTContainerTemplate findProductTemplate(String containerPath, String containerTemplateStr)
			throws WTException {
		if (containerPath == null || containerPath.length() == 0) {
			throw new WTException("null/empty param 'containerPath' given");
		}
		if (containerTemplateStr == null || containerTemplateStr.length() == 0) {
			throw new WTException("null/empty param 'containerTemplateStr' given");
		}
		WTContainerRef containerRef = WTContainerHelper.service
				.getByPath("/wt.inf.container.OrgContainer=" + containerPath);
		if (logger.isDebugEnabled()) {
			logger.debug("given containerPath is valid. Found containerRef=" + containerRef);
		}

		QuerySpec query = new QuerySpec(WTContainerTemplateMaster.class);

		SearchCondition where = new SearchCondition(WTContainerTemplateMaster.class, "name", "=", containerTemplateStr);
		query.appendWhere(where, new int[] { 0, 1 });
		LookupSpec lookup = new LookupSpec(query, containerRef);
		try {
			lookup.setFirstMatchOnly(true);
		} catch (WTPropertyVetoException pve) {
			throw new WTException(pve);
		}
		QueryResult results = WTContainerHelper.service.lookup(lookup);
		WTContainerTemplate containerTemplate = null;
		while (results.hasMoreElements()) {

			WTContainerTemplateMaster templateMaster = (WTContainerTemplateMaster) results.nextElement();
			containerTemplate = ContainerTemplateHelper.service.getContainerTemplateRef(templateMaster).getTemplate();

		}
		return containerTemplate;
	}

	/**
	 * Prints the usage.
	 */
	private void printUsage() {
		System.out.println(
				"Usage: DeleteTemplate <login> <password> <containerName> <templateName1[, templateName2]> | <-f pathToFileWithTemplateNames> \n"
						+ "Delete users/groups/roles from the WT system and LDAP\n"
						+ "<login> - login of Windchill administrator\n"
						+ "<password> - password of Windchill administrator\n"
						+ "<containerName> - name of the container where templates are stored (for example HVAC)\n"
						+ "<templateName1[, templateName2]> - comma separated list of templates to be deleted or -f path to file with template names\n"
						+ "EXAMPLE: windchill com.deploy.util.DeleteTemplate <login> <password> HVAC \"HVAC_SYD_OEM_PDMProject_Template,HVAC_WES_OEM_PDMProject_Template,HVAC_WUX_OEM_PDMProject_Template\"");
	}

}
