/**
 * SI_SOAPRequest_ProvideResponse_Abs_Sync.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.knorr_bremse.xi._003.WINDCHILL.CHECK;

public interface SI_SOAPRequest_ProvideResponse_Abs_Sync extends java.rmi.Remote {
	public com.knorr_bremse.xi._003.WINDCHILL.GLOBAL.DT_ProvideResponse SI_SOAPRequest_ProvideResponse_Abs_Sync(com.ecs.pi.ERPXPDM20.SOAPRequest_DT SOAPRequest_MT) throws java.rmi.RemoteException;
}
