package ext.kb.bom;

import java.util.ArrayList;

public class OutputBOMDetails {
	
	String childpartnumber;
	ArrayList<String> refdesignator;
	String returncode;
	String parentpartnumber;
	String message;
	String linenumber;
	String findNumber;
	ArrayList<Substitute> substitute;
	double quantity;
	String KB_REPAIR_FLAG;
	String KB_DELIVERY_FLAG;
	String KB_FREE_TEXT;
	String KB_REMARK_COL1;
	String KB_REMARK_COL2;
	String KB_REMARK_COL3;
	String KB_REMARK_COL4;
	String KB_ELECTR_REF;
	String childPartType;
	String CADIM_CID;
	String defaultUnit;
	String masterSystem;
	String type;
	long obid;
	String version;
	String state;
	
	
	public OutputBOMDetails(String partnumber,ArrayList<String> refdes,String linenumber,String findNumber,double quantity,String KB_REPAIR_FLAG,String KB_FREE_TEXT,
			String KB_REMARK_COL1,String KB_REMARK_COL2,String KB_REMARK_COL3,String KB_REMARK_COL4,String KB_ELECTR_REF,String childPartType,String CADIM_CID,String defaultUnit,String masterSystem,ArrayList<Substitute>substitute,String type,long obid,String version,String state){
		super();
	
		this.childpartnumber=partnumber;
		this.refdesignator=refdes;
		this.linenumber=linenumber;
		this.findNumber = findNumber;
		this.quantity=quantity;
		this.KB_REPAIR_FLAG=KB_REPAIR_FLAG;
		this.KB_FREE_TEXT=KB_FREE_TEXT;
		this.KB_REMARK_COL1=KB_REMARK_COL1;
		this.KB_REMARK_COL2=KB_REMARK_COL2;
		this.KB_REMARK_COL3=KB_REMARK_COL3;
		this.KB_REMARK_COL4=KB_REMARK_COL4;
		this.KB_ELECTR_REF=KB_ELECTR_REF;
		this.childPartType=childPartType;
		this.CADIM_CID=CADIM_CID;
		this.defaultUnit=defaultUnit;
		this.masterSystem=masterSystem;
		this.substitute = substitute;
		this.type = type;
		this.obid=obid;
		this.version=version;
		this.state=state;
	}
	
	public OutputBOMDetails(){
		
	}
	
	public String getFindNumber() {
		return findNumber;
	}


	public void setFindNumber(String findNumber) {
		this.findNumber = findNumber;
	}


	public double getQuantity() {
		return quantity;
	}


	public void setQuantity(double quantity) {
		this.quantity = quantity;
	}


	public String getKB_REPAIR_FLAG() {
		return KB_REPAIR_FLAG;
	}


	public void setKB_REPAIR_FLAG(String kB_REPAIR_FLAG) {
		KB_REPAIR_FLAG = kB_REPAIR_FLAG;
	}


	public String getKB_DELIVERY_FLAG() {
		return KB_DELIVERY_FLAG;
	}


	public void setKB_DELIVERY_FLAG(String kB_DELIVERY_FLAG) {
		KB_DELIVERY_FLAG = kB_DELIVERY_FLAG;
	}


	public String getKB_FREE_TEXT() {
		return KB_FREE_TEXT;
	}


	public void setKB_FREE_TEXT(String kB_FREE_TEXT) {
		KB_FREE_TEXT = kB_FREE_TEXT;
	}


	public String getKB_REMARK_COL1() {
		return KB_REMARK_COL1;
	}


	public void setKB_REMARK_COL1(String kB_REMARK_COL1) {
		KB_REMARK_COL1 = kB_REMARK_COL1;
	}


	public String getKB_REMARK_COL2() {
		return KB_REMARK_COL2;
	}


	public void setKB_REMARK_COL2(String kB_REMARK_COL2) {
		KB_REMARK_COL2 = kB_REMARK_COL2;
	}


	public String getKB_REMARK_COL3() {
		return KB_REMARK_COL3;
	}


	public void setKB_REMARK_COL3(String kB_REMARK_COL3) {
		KB_REMARK_COL3 = kB_REMARK_COL3;
	}


	public String getKB_REMARK_COL4() {
		return KB_REMARK_COL4;
	}


	public void setKB_REMARK_COL4(String kB_REMARK_COL4) {
		KB_REMARK_COL4 = kB_REMARK_COL4;
	}


	public String getKB_ELECTR_REF() {
		return KB_ELECTR_REF;
	}


	public void setKB_ELECTR_REF(String kB_ELECTR_REF) {
		KB_ELECTR_REF = kB_ELECTR_REF;
	}


	public String getChildPartType() {
		return childPartType;
	}


	public void setChildPartType(String childPartType) {
		this.childPartType = childPartType;
	}


	public String getCADIM_CID() {
		return CADIM_CID;
	}


	public void setCADIM_CID(String cADIM_CID) {
		CADIM_CID = cADIM_CID;
	}


	public String getDefaultUnit() {
		return defaultUnit;
	}


	public void setDefaultUnit(String defaultUnit) {
		this.defaultUnit = defaultUnit;
	}


	public String getMasterSystem() {
		return masterSystem;
	}


	public void setMasterSystem(String masterSystem) {
		this.masterSystem = masterSystem;
	}

	public ArrayList<String> getRefdesignator() {
		return refdesignator;
	}


	public void setRefdesignator(ArrayList<String> refdesignator) {
		this.refdesignator = refdesignator;
	}

	public String getChildpartnumber() {
		return childpartnumber;
	}

	public void setChildpartnumber(String childpartnumber) {
		this.childpartnumber = childpartnumber;
	}


	public String getReturncode() {
		return returncode;
	}


	public void setReturncode(String returncode) {
		this.returncode = returncode;
	}


	public String getParentpartnumber() {
		return parentpartnumber;
	}


	public void setParentpartnumber(String parentpartnumber) {
		this.parentpartnumber = parentpartnumber;
	}


	public String getMessage() {
		return message;
	}


	public void setMessage(String message) {
		this.message = message;
	}


	public String getLinenumber() {
		return linenumber;
	}


	public void setLinenumber(String linenumber) {
		this.linenumber = linenumber;
	}
	
	public ArrayList<Substitute> getSubstitute() {
		return substitute;
	}

	public void setSubstitute(ArrayList<Substitute> substitute) {
		this.substitute = substitute;
	}
	
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
	public long getObid() {
		return obid;
	}

	public void setObid(long obid) {
		this.obid = obid;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}
	
	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

}
