/**
 * 
 */
package ext.kb.builder.table;

/**
 * @author bankowskie
 *
 */

import java.util.ArrayList;
import java.util.List;

import com.ptc.core.components.rendering.guicomponents.IconComponent;
import com.ptc.core.components.rendering.guicomponents.UrlDisplayComponent;
import com.ptc.mvc.components.AbstractComponentBuilder;
import com.ptc.mvc.components.ColumnConfig;
import com.ptc.mvc.components.ComponentBuilder;
import com.ptc.mvc.components.ComponentConfig;
import com.ptc.mvc.components.ComponentConfigFactory;
import com.ptc.mvc.components.ComponentParams;
import com.ptc.mvc.components.TableConfig;
import com.ptc.mvc.util.ClientMessageSource;

import ext.kb.change2.helper.ChangeNoticeUtils;
import ext.kb.resources.KBWorkitemRB;
import ext.kb.util.KBConstants;
import ext.kb.util.KBUtils;
import wt.change2.WTChangeActivity2;
import wt.change2.WTChangeOrder2;
import wt.doc.WTDocument;
import wt.epm.EPMDocument;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.part.WTPart;
import wt.util.WTException;
import wt.vc.VersionControlHelper;
import wt.vc.Versioned;
import wt.vc.baseline.BaselineHelper;
import wt.vc.baseline.ManagedBaseline;
import wt.workflow.work.WorkItem;

@ComponentBuilder("ext.kb.builder.table.WorkItemValidateBaselineTableBuilder")
public class WorkItemValidateBaselineTableBuilder extends AbstractComponentBuilder {

	private static final String RESOURCE = "ext.kb.resources.KBWorkitemRB";
	private final ClientMessageSource messageSource = getMessageSource(RESOURCE);

	public static final class Record {
		private IconComponent dataType;
		private UrlDisplayComponent numberLink;
		private String name;
		private UrlDisplayComponent latestVersion;
		private String latestVersionState;
		private UrlDisplayComponent latestReleasedVersion;
		private String latestReleasedVersionState;

		public IconComponent getDataType() {
			return dataType;
		}

		public void setDataType(IconComponent dataType) {
			this.dataType = dataType;
		}

		public UrlDisplayComponent getNumberLink() {
			return numberLink;
		}

		public void setNumberLink(UrlDisplayComponent numberLink) {
			this.numberLink = numberLink;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public UrlDisplayComponent getLatestVersion() {
			return latestVersion;
		}

		public void setLatestVersion(UrlDisplayComponent latestVersion) {
			this.latestVersion = latestVersion;
		}

		public String getLatestVersionState() {
			return latestVersionState;
		}

		public void setLatestVersionState(String latestVersionState) {
			this.latestVersionState = latestVersionState;
		}

		public UrlDisplayComponent getLatestReleasedVersion() {
			return latestReleasedVersion;
		}

		public void setLatestReleasedVersion(UrlDisplayComponent latestReleasedVersion) {
			this.latestReleasedVersion = latestReleasedVersion;
		}

		public String getLatestReleasedVersionState() {
			return latestReleasedVersionState;
		}

		public void setLatestReleasedVersionState(String latestReleasedVersionState) {
			this.latestReleasedVersionState = latestReleasedVersionState;
		}
	}

	@Override
	public List<Record> buildComponentData(ComponentConfig config, ComponentParams params) throws Exception {
		Object obj = params.getContextObject();
		WorkItem workItem = null;
		if (obj instanceof WorkItem) {
			workItem = (WorkItem) obj;
		}
		WTChangeActivity2 ect = (WTChangeActivity2) workItem.getPrimaryBusinessObject().getObject();
		WTChangeOrder2 changeNotice = ChangeNoticeUtils.getECN(ect);
		ManagedBaseline baseline = ext.kb.workflow.BaselineHelper.findReleasedBaseline(ect, changeNotice);
		QueryResult baselineItems = BaselineHelper.service.getBaselineItems(baseline);
		List<Record> result = new ArrayList<>();
		while (baselineItems.hasMoreElements()) {
			Object object = baselineItems.nextElement();
			Persistable item;
			if (object instanceof EPMDocument || object instanceof WTDocument || object instanceof WTPart) {
				item = (Persistable) object;
				Record record = new Record();
				Persistable latestVersion = KBUtils.getLatestVersion(item);
				Persistable latestReleasedVersion = getLatestReleasedVersion(latestVersion);
				record.setDataType(KBUtils.getIconComponent(item));
				record.setNumberLink(KBUtils.getUrlDisplayComponent(getNumber(item), KBUtils.getUrl(item)));
				record.setName(getName(item));
				if (latestVersion != null) {
					record.setLatestVersion(KBUtils.getUrlDisplayComponent(getIdentifier(latestVersion), KBUtils.getUrl(latestVersion)));
					record.setLatestVersionState(getState(latestVersion));
				}
				if (latestReleasedVersion != null) {
					record.setLatestReleasedVersion(KBUtils.getUrlDisplayComponent(getIdentifier(latestReleasedVersion), KBUtils.getUrl(latestReleasedVersion)));
					record.setLatestReleasedVersionState(getState(latestReleasedVersion));
				}
				result.add(record);
			}
		}
		return result;
	}

	@Override
	public ComponentConfig buildComponentConfig(ComponentParams params) throws WTException {
		ComponentConfigFactory factory = getComponentConfigFactory();
		TableConfig table = factory.newTableConfig();
		table.setLabel(messageSource.getMessage("BASELINE_OBJECTS_TABLE"));
		table.setShowCount(true);
		ColumnConfig config = factory.newColumnConfig(KBWorkitemRB.BASELINE_OBJECTS_COL1_ID, false);
		config.setLabel(KBWorkitemRB.BASELINE_OBJECTS_COL1_LABEL);
		table.addComponent(config);
		config = factory.newColumnConfig(KBWorkitemRB.BASELINE_OBJECTS_COL2_ID, false);
		config.setLabel(KBWorkitemRB.BASELINE_OBJECTS_COL2_LABEL);
		table.addComponent(config);
		config = factory.newColumnConfig(KBWorkitemRB.BASELINE_OBJECTS_COL3_ID, false);
		config.setLabel(KBWorkitemRB.BASELINE_OBJECTS_COL3_LABEL);
		table.addComponent(config);
		config = factory.newColumnConfig(KBWorkitemRB.BASELINE_OBJECTS_COL4_ID, false);
		config.setLabel(KBWorkitemRB.BASELINE_OBJECTS_COL4_LABEL);
		table.addComponent(config);
		config = factory.newColumnConfig(KBWorkitemRB.BASELINE_OBJECTS_COL5_ID, false);
		config.setLabel(KBWorkitemRB.BASELINE_OBJECTS_COL5_LABEL);
		table.addComponent(config);
		config = factory.newColumnConfig(KBWorkitemRB.BASELINE_OBJECTS_COL6_ID, false);
		config.setLabel(KBWorkitemRB.BASELINE_OBJECTS_COL6_LABEL);
		table.addComponent(config);
		config = factory.newColumnConfig(KBWorkitemRB.BASELINE_OBJECTS_COL7_ID, false);
		config.setLabel(KBWorkitemRB.BASELINE_OBJECTS_COL7_LABEL);
		table.addComponent(config);
		return table;
	}

	private String getIdentifier(Persistable persistable) {
		String result = "";
		if (persistable instanceof EPMDocument) {
			result = ((EPMDocument) persistable).getIterationDisplayIdentifier().toString();
		} else if (persistable instanceof WTDocument) {
			result = ((WTDocument) persistable).getIterationDisplayIdentifier().toString();
		} else if (persistable instanceof WTPart) {
			result = ((WTPart) persistable).getIterationDisplayIdentifier().toString();
		}
		return result;
	}

	private String getState(Persistable persistable) {
		String result = "";
		if (persistable instanceof EPMDocument) {
			result = ((EPMDocument) persistable).getState().toString();
		} else if (persistable instanceof WTDocument) {
			result = ((WTDocument) persistable).getState().toString();
		} else if (persistable instanceof WTPart) {
			result = ((WTPart) persistable).getState().toString();
		}
		return result;
	}
	
	private String getName(Persistable persistable){
		String result = "";
		if (persistable instanceof EPMDocument) {
			result = ((EPMDocument) persistable).getName();
		} else if (persistable instanceof WTDocument) {
			result = ((WTDocument) persistable).getName();;
		} else if (persistable instanceof WTPart) {
			result = ((WTPart) persistable).getName();;
		}
		return result;
	}

	private String getNumber(Persistable persistable){
		String result = "";
		if (persistable instanceof EPMDocument) {
			result = ((EPMDocument) persistable).getNumber();
		} else if (persistable instanceof WTDocument) {
			result = ((WTDocument) persistable).getNumber();
		} else if (persistable instanceof WTPart) {
			result = ((WTPart) persistable).getNumber();
		}
		return result;
	}
	
	private Persistable getLatestReleasedVersion(Persistable latestVersion) throws WTException {
		Persistable latestReleased = null;
		QueryResult result = VersionControlHelper.service.allVersionsOf((Versioned)latestVersion);
		while(result.hasMoreElements()){
			Persistable persistable = (Persistable) result.nextElement();
			if(latestVersion instanceof EPMDocument){
				EPMDocument obj = (EPMDocument) persistable;
				if ((latestReleased == null && (obj).getState().toString().equals(KBConstants.RELEASED)) || (latestReleased!=null && VersionControlHelper.getVersionIdentifier(obj).getSeries().greaterThan(VersionControlHelper.getVersionIdentifier((EPMDocument) latestReleased).getSeries()) && (obj).getState().toString().equals(KBConstants.RELEASED))) 
					latestReleased = obj;			
			}else if(latestVersion instanceof WTDocument){
				WTDocument obj = (WTDocument) persistable;
				if ((latestReleased == null && (obj).getState().toString().equals(KBConstants.RELEASED)) || (latestReleased!=null && VersionControlHelper.getVersionIdentifier(obj).getSeries().greaterThan(VersionControlHelper.getVersionIdentifier((WTDocument) latestReleased).getSeries()) && (obj).getState().toString().equals(KBConstants.RELEASED)))
					latestReleased = obj;		
			}else if(latestVersion instanceof WTPart){
				WTPart obj = (WTPart) persistable;
				if ((latestReleased == null && (obj).getState().toString().equals(KBConstants.RELEASED)) || (latestReleased!=null && VersionControlHelper.getVersionIdentifier(obj).getSeries().greaterThan(VersionControlHelper.getVersionIdentifier((WTPart) latestReleased).getSeries()) && (obj).getState().toString().equals(KBConstants.RELEASED)))
					latestReleased = obj;
			}
		}
		return latestReleased;
	}
}
