package ext.kb.builder.table;

import com.ptc.core.components.rendering.guicomponents.UrlDisplayComponent;
import com.ptc.mvc.components.*;
import ext.kb.ui.report.methods.AttributesMethods;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import wt.content.ApplicationData;
import wt.content.ContentHelper;
import wt.content.ContentRoleType;
import wt.doc.WTDocument;
import wt.doc.WTDocumentMaster;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.part.WTPart;
import wt.part.WTPartHelper;
import wt.part.WTPartReferenceLink;
import wt.query.ArrayExpression;
import wt.query.ClassAttribute;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.type.TypedUtilityServiceHelper;
import wt.util.WTException;
import wt.vc.VersionControlHelper;
import wt.vc.wip.WorkInProgressHelper;

import java.util.*;

import static com.ptc.wvs.server.util.Util.COMMA;

@ComponentBuilder("ext.kb.builder.table.DocumentsAndFilesReport")
public class DocumentsAndFilesReport extends AbstractComponentConfigBuilder implements ComponentDataBuilder {

    private static final Logger logger = Logger.getLogger(DocumentsAndFilesReport.class);
    private static final String PIPE = "\\|";
    private static final String ARTICLE_NUMBER_PARAMETER = "Article_Number";
    private static final String DOCUMENTS_AND_FILES_TABLE = "documentsAndFiles";
    private static final String DOCUMENTS_AND_FILES_TABLE_LABEL = "Documents and Files Names Report";
    private static final String ARTICLE_NUMBER = "Article Number";
    private static final String ARTICLE_VERSION = "Article Version";
    private static final String STATE = "State";
    private static final String RESPONSIBLE_DEVISION = "Responsible Devisison";
    private static final String DOCUMENT_NUMBER = "Document Number";
    private static final String DOCUMENT_VERSION = "Document Version";
    private static final String DOCUMENT_STATE = "Document State";
    private static final String DOCUMENT_NAME = "Name";
    private static final String VALID_FROM = "Valid From";
    private static final String TYPE_OF_DOCUMENT = "Type of Documnent";
    private static final String RAW_PART_NUMBER = "Raw Part Number";
    private static final String NO_OF_PAGES = "No. of Pages";
    private static final String LANGUAGE = "Language";
    private static final String DESIGN_RESPONSIBILITY = "Design Responsibility";
    private static final String SUPPLEMENTARY_TEXT = "Supplementary Text";
    private static final String ADDITIONAL_TEXT = "Additional Text";
    private static final String PRIMARY_CONTENT = "Primary Content";
    private static final String SECONDARY_CONTENT = "Secondary Content";
    private static final String DOWNLOAD = "Download";
    private static final String DOWNLOAD_ICON = "netmarkets/images/download.gif";
    private static final String KB_ARTICLE = "com.ptc.KBArticle";
    private static final String EXPORT_ACTIONS = "report results table actions";

    @Override
    public ComponentConfig buildComponentConfig(ComponentParams componentParams) throws WTException {
        ComponentConfigFactory factory = getComponentConfigFactory();
        TableConfig tableConfig = factory.newTableConfig();
        tableConfig.setId(DOCUMENTS_AND_FILES_TABLE);
        tableConfig.setLabel(DOCUMENTS_AND_FILES_TABLE_LABEL);
        tableConfig.setFreezable(true);
        tableConfig.setShowCount(true);
        tableConfig.setShowCustomViewLink(false);
        tableConfig.setSelectable(true);
        tableConfig.setConfigurable(false);
        tableConfig.setActionModel(EXPORT_ACTIONS);
        tableConfig.addComponent(factory.newColumnConfig(ARTICLE_NUMBER, true));
        tableConfig.addComponent(factory.newColumnConfig(ARTICLE_VERSION, true));
        tableConfig.addComponent(factory.newColumnConfig(STATE, true));
        tableConfig.addComponent(factory.newColumnConfig(RESPONSIBLE_DEVISION, true));
        tableConfig.addComponent(factory.newColumnConfig(DOCUMENT_NUMBER, true));
        tableConfig.addComponent(factory.newColumnConfig(DOCUMENT_VERSION, true));
        tableConfig.addComponent(factory.newColumnConfig(DOCUMENT_STATE, true));
        tableConfig.addComponent(factory.newColumnConfig(DOCUMENT_NAME, true));
        tableConfig.addComponent(factory.newColumnConfig(VALID_FROM, true));
        tableConfig.addComponent(factory.newColumnConfig(TYPE_OF_DOCUMENT, true));
        tableConfig.addComponent(factory.newColumnConfig(RAW_PART_NUMBER, true));
        tableConfig.addComponent(factory.newColumnConfig(NO_OF_PAGES, true));
        tableConfig.addComponent(factory.newColumnConfig(LANGUAGE, true));
        tableConfig.addComponent(factory.newColumnConfig(DESIGN_RESPONSIBILITY, true));
        tableConfig.addComponent(factory.newColumnConfig(SUPPLEMENTARY_TEXT, true));
        tableConfig.addComponent(factory.newColumnConfig(ADDITIONAL_TEXT, true));
        tableConfig.addComponent(factory.newColumnConfig(PRIMARY_CONTENT, true));
        tableConfig.addComponent(factory.newColumnConfig(SECONDARY_CONTENT, true));
        tableConfig.addComponent(factory.newColumnConfig(DOWNLOAD, true));
        return tableConfig;
    }

    @Override
    public Object buildComponentData(ComponentConfig componentConfig, ComponentParams componentParams) throws Exception {
        logger.debug("DocumentsAndFilesReport - buildComponentData started");
        String[] articlesNumbers = componentParams.getParameter(ARTICLE_NUMBER_PARAMETER).toString().split(PIPE);
        logger.debug("articlesNumbers: " + Arrays.toString(articlesNumbers));
        List<Map<String, Object>> objectsForReport = new ArrayList<>();
        QueryResult articles = getArticlesByNumbers(articlesNumbers);
        while (articles.hasMoreElements()) {
            WTPart wtPart = (WTPart) articles.nextElement();
            if (!WorkInProgressHelper.isWorkingCopy(wtPart)) {
                objectsForReport.addAll(getReferencedDocuments(wtPart));
                objectsForReport.addAll(getDescribedByDocuments(wtPart));
            }
        }
        logger.debug("DocumentsAndFilesReport - buildComponentData finished");
        return objectsForReport;
    }

    private QueryResult getArticlesByNumbers(String[] articlesNumbers) throws WTException {
        QuerySpec queryForArticles = new QuerySpec(WTPart.class);
        if (articlesNumbers.length > 1 || !articlesNumbers[0].equals(StringUtils.EMPTY)) {
            queryForArticles.appendWhere(new SearchCondition(new ClassAttribute(WTPart.class, WTPart.NUMBER),
                    SearchCondition.IN, new ArrayExpression(articlesNumbers)), new int[]{0});
            queryForArticles.appendAnd();
        }
        queryForArticles.appendWhere(new SearchCondition(WTPart.class, WTPart.LATEST_ITERATION,
                SearchCondition.IS_TRUE), new int[]{0});
        queryForArticles.appendAnd();
        queryForArticles.appendWhere(TypedUtilityServiceHelper.service.getSearchCondition(
                TypedUtilityServiceHelper.service.getTypeIdentifier(KB_ARTICLE), true), new int[]{0});
        return PersistenceServerHelper.manager.query(queryForArticles);
    }

    private List<Map<String, Object>> getReferencedDocuments(WTPart wtPart) throws WTException {
        QueryResult referencedDocuments = PersistenceHelper.navigate(wtPart, WTPartReferenceLink.REFERENCES_ROLE,
                WTPartReferenceLink.class, true);
        List<Map<String, Object>> objectsForReport = new ArrayList<>();
        while (referencedDocuments.hasMoreElements()) {
            WTDocumentMaster documentMaster = (WTDocumentMaster) referencedDocuments.nextElement();
            WTDocument document = (WTDocument) VersionControlHelper.service.allIterationsOf(documentMaster).nextElement();
            QueryResult documentContents = getDocumentContents(document);
            if (documentContents.size() == 0) {
                objectsForReport.add(addWTDocumentToReport(document, wtPart, null));
            }
            while (documentContents.hasMoreElements()) {
                ApplicationData content = (ApplicationData) documentContents.nextElement();
                objectsForReport.add(addWTDocumentToReport(document, wtPart, content));
            }
        }
        return objectsForReport;
    }

    private List<Map<String, Object>> getDescribedByDocuments(WTPart wtPart) throws WTException {
        QueryResult describedByWTDocuments = WTPartHelper.service.getDescribedByWTDocuments(wtPart);
        List<Map<String, Object>> objectsForReport = new ArrayList<>();
        while (describedByWTDocuments.hasMoreElements()) {
            WTDocument document = (WTDocument) describedByWTDocuments.nextElement();
            QueryResult documentContents = getDocumentContents(document);
            if (documentContents.size() == 0) {
                objectsForReport.add(addWTDocumentToReport(document, wtPart, null));
            }
            while (documentContents.hasMoreElements()) {
                ApplicationData content = (ApplicationData) documentContents.nextElement();
                objectsForReport.add(addWTDocumentToReport(document, wtPart, content));
            }
        }
        return objectsForReport;
    }

    private QueryResult getDocumentContents(WTDocument document) throws WTException {
        QueryResult primaryContent = ContentHelper.service.getContentsByRole(document, ContentRoleType.PRIMARY);
        QueryResult secondaryContent = ContentHelper.service.getContentsByRole(document, ContentRoleType.SECONDARY);
        primaryContent.append(secondaryContent.getObjectVectorIfc());
        return primaryContent;
    }

    private Map<String, Object> addWTDocumentToReport(WTDocument document, WTPart wtPart, ApplicationData applicationData) throws WTException {
        logger.debug("WTDocument: " + document);
        logger.debug("WTPart: " + wtPart);
        Map<String, Object> row = new HashMap<>();
        row.put(ARTICLE_NUMBER, wtPart.getNumber());
        row.put(ARTICLE_VERSION, AttributesMethods.getRevision(wtPart));
        row.put(STATE, wtPart.getLifeCycleState().getDisplay());
        row.put(RESPONSIBLE_DEVISION, AttributesMethods.getDepartment(wtPart));
        row.put(DOCUMENT_NUMBER, document.getNumber());
        row.put(DOCUMENT_VERSION, AttributesMethods.getRevision(document));
        row.put(DOCUMENT_STATE, document.getLifeCycleState().getDisplay());
        row.put(DOCUMENT_NAME, document.getName());
        row.put(VALID_FROM, AttributesMethods.getValidFrom(document));
        row.put(TYPE_OF_DOCUMENT, AttributesMethods.getDocContentType(document));
        row.put(RAW_PART_NUMBER, AttributesMethods.getRawPartNumber(document));
        row.put(NO_OF_PAGES, AttributesMethods.getNoOfPages(document));
        row.put(LANGUAGE, AttributesMethods.getLanguage(document));
        row.put(DESIGN_RESPONSIBILITY, AttributesMethods.getDepartment(document));
        row.put(SUPPLEMENTARY_TEXT, AttributesMethods.getSupplementaryText(document));
        row.put(ADDITIONAL_TEXT, AttributesMethods.getAdditionalText(document));
        if (applicationData != null) {
            boolean isPrimary = ContentRoleType.PRIMARY.equals(applicationData.getRole());
            if (isPrimary) {
                row.put(PRIMARY_CONTENT, applicationData.getFileName());
                row.put(SECONDARY_CONTENT, StringUtils.EMPTY);
            } else {
                row.put(PRIMARY_CONTENT, StringUtils.EMPTY);
                row.put(SECONDARY_CONTENT, applicationData.getFileName());
            }
            row.put(DOWNLOAD, getDownloadLink(document, applicationData));
        }
        return row;
    }

    private UrlDisplayComponent getDownloadLink(WTDocument document, ApplicationData applicationData) throws WTException {
        String downloadUrl = ContentHelper.getDownloadURL(document, applicationData, false).toString();
        return new UrlDisplayComponent(DOWNLOAD, StringUtils.EMPTY, downloadUrl, DOWNLOAD_ICON);
    }
}
