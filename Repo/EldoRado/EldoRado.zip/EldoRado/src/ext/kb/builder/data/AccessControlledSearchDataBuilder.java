package ext.kb.builder.data;

import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.ptc.jca.mvc.components.JcaComponentParams;
import com.ptc.mvc.components.ComponentBuilder;
import com.ptc.mvc.components.ComponentBuilderType;
import com.ptc.mvc.components.ComponentConfig;
import com.ptc.mvc.components.ComponentParams;
import com.ptc.mvc.components.OverrideComponentBuilder;
import com.ptc.windchill.enterprise.search.mvc.builders.SearchDataBuilder;
import com.ptc.windchill.enterprise.search.server.SearchConstants;

import wt.access.AccessControlled;
import wt.access.AccessPermission;
import wt.access.AccessPermissionSet;
import wt.log4j.LogR;
import wt.org.WTPrincipal;
import wt.session.SessionHelper;
import wt.vc.VersionReference;

/**
 * Access controlled search data builder.
 *
 */

@Component
@OverrideComponentBuilder
@ComponentBuilder(value = { "ext.kb.accesscontrolled.search" }, type = ComponentBuilderType.DATA_ONLY)
public class AccessControlledSearchDataBuilder extends SearchDataBuilder {
	
	private static final Logger LOG = LogR.getLogger(AccessControlledSearchDataBuilder.class.getName());

	static {
		if (SearchConstants.VERBOSE_SEARCH) {
			LOG.setLevel(Level.ALL);
		}
	}

	@Override
	protected Object buildRawData(ComponentConfig paramComponentConfig, ComponentParams paramComponentParams)
			throws Exception {

		JcaComponentParams componentParams = (JcaComponentParams) paramComponentParams;
		List<?> list = (List<?>) super.buildRawData(paramComponentConfig, paramComponentParams);
		boolean controllPermission = isPermissionControlled(componentParams);
		if (controllPermission) {
			WTPrincipal principal = SessionHelper.manager.getPrincipal();
			Iterator<?> it = list.iterator();
			while (it.hasNext()) {
				Object o = it.next();
				if (o instanceof VersionReference) {
					VersionReference vr = (VersionReference) o;
					if (vr.getObject() instanceof AccessControlled) {
						AccessControlled accessControlled = (AccessControlled) vr.getObject();
						AccessPermissionSet persmissionsSet = wt.access.AccessControlHelper.manager
								.getPermissions(principal, accessControlled);
						if (!persmissionsSet.includes(AccessPermission.DOWNLOAD)) {
							it.remove();
						}
					}
				}
			}
		}
		return list;
	}

	private boolean isPermissionControlled(JcaComponentParams componentParams) {
		try {
			List<?> neededPermissions = (List<?>) componentParams.getHelperBean().getNmCommandBean().getComboBox().get("permission1_SearchComboBox");
			if(neededPermissions!=null){
				if (neededPermissions.contains("Download")) {
					return true;
				}
			}
		} catch (Exception e) {
			LOG.error(e);
		}
		return false;
	}
}
