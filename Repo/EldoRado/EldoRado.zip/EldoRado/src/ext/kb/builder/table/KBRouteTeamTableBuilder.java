/* bcwti
 *
 * Copyright (c) 2010 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */
package ext.kb.builder.table;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import com.ptc.core.htmlcomp.tableview.ConfigurableTable;
import com.ptc.core.ui.resources.ComponentMode;
import com.ptc.jca.mvc.components.JcaComponentParams;
import com.ptc.jca.mvc.components.JcaTableConfig;
import com.ptc.mvc.components.ColumnConfig;
import com.ptc.mvc.components.ComponentBuilder;
import com.ptc.mvc.components.ComponentConfig;
import com.ptc.mvc.components.ComponentConfigFactory;
import com.ptc.mvc.components.ComponentParams;
import com.ptc.mvc.components.TableConfig;
import com.ptc.mvc.components.ds.DataSourceMode;
import com.ptc.mvc.util.ClientMessageSource;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import com.ptc.netmarkets.workflow.RouteDescriptorConstants;
import com.ptc.netmarkets.workflow.workflowResource;
import com.ptc.netmarkets.workflow.mvc.builders.RouteTeamTableBuilder;
import com.ptc.netmarkets.workflow.mvc.tableViews.RouteTeamStepTableViews;

import ext.kb.builder.helper.KBRouteTeamParticipantsHelper;
import wt.fc.ReferenceFactory;
import wt.fc.WTReference;
import wt.org.WTPrincipal;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.util.WTMessage;

/**
 * MVC builder class for /netmarkets/jsp/workflow/route_step1.jsp
 *
 */
@ComponentBuilder("workflow.routeTeamComponentStep_custom")
public class KBRouteTeamTableBuilder extends RouteTeamTableBuilder {

	private static final String TABLE_ID = "TABLE_ID";
	private static final String WORKFLOW_RESOURCE = "com.ptc.netmarkets.workflow.workflowResource";
	private static final String LIFECYCLE_RESOURCE = "com.ptc.netmarkets.lifecycle.lifecycleResource";

	ClientMessageSource messageWorkflowSource = getMessageSource(WORKFLOW_RESOURCE);
	ClientMessageSource messageLifecycleSource = getMessageSource(LIFECYCLE_RESOURCE);

	public ConfigurableTable buildConfigurableTable(String arg0) throws WTException {
		return new RouteTeamStepTableViews();
	}

	public Object buildComponentData(ComponentConfig config, ComponentParams params) throws Exception {
		if (params instanceof JcaComponentParams) {
			JcaComponentParams jcaParams = (JcaComponentParams) params;
			NmCommandBean cb = jcaParams.getHelperBean().getNmCommandBean();
			HashMap<?, ?> textMap = cb.getText();
			cb.addToMap(textMap, TABLE_ID, config.getId(), true);

			return KBRouteTeamParticipantsHelper.getParticipantList(cb);
		}
		return new ArrayList<Object>();
	}

	public ComponentConfig buildComponentConfig(ComponentParams params) throws WTException {
		ComponentConfigFactory factory = getComponentConfigFactory();
		TableConfig table = factory.newTableConfig();
		table.setId(RouteDescriptorConstants.TableIdentifiers.ROUTE_TEAM_TABLE);
		table.setType("java.lang.Object");
		table.setLabel(WTMessage.getLocalizedMessage(WORKFLOW_RESOURCE, workflowResource.PICK_TEAM, null,
				SessionHelper.getLocale()));
		table.setSelectable(false);
		table.setShowCustomViewLink(false);

		if (table instanceof JcaTableConfig) {
			((JcaTableConfig) table).setDataSourceMode(DataSourceMode.DISABLED);
		}

		addColumn(RouteDescriptorConstants.ColumnIdentifiers.PARTICIPANTS_TYPE, table, factory, true, false);
		addColumn(RouteDescriptorConstants.ColumnIdentifiers.PARTICIPANT_NAME, table, factory, true, false);

		ColumnConfig rolesColumn = createColumn(RouteDescriptorConstants.ColumnIdentifiers.ROUTE_TEAM_ROLES, factory,
				false, false);
		addColumn(table, rolesColumn);
		return table;
	}

	private void addColumn(String id, TableConfig table, ComponentConfigFactory factory, boolean isSortable,
			boolean isHidden) {
		ColumnConfig column = createColumn(id, factory, isSortable, isHidden);
		addColumn(table, column);
	}

	private void addColumn(TableConfig table, ColumnConfig column) {
		table.addComponent(column);
	}

	private ColumnConfig createColumn(String id, ComponentConfigFactory factory, boolean isSortable, boolean isHidden) {
		ColumnConfig column = factory.newColumnConfig(id, true);
		column.setSortable(isSortable);
		column.setHidden(isHidden);
		column.setComponentMode(ComponentMode.EDIT);
		return column;
	}

	private Collection<WTPrincipal> getRolePrincipalMap(HashMap checkedOrUnChecked) throws WTException {
		Set<WTPrincipal> participants = new HashSet<>();
		for (Iterator itr = checkedOrUnChecked.keySet().iterator(); itr.hasNext();) {
			String str = (String) itr.next();
			String[] arr = str.split("#");
			if (arr.length >= 2) {
				String principalStr = arr[1];
				ReferenceFactory rf = new ReferenceFactory();
				WTReference objRef = rf.getReference(principalStr);
				WTPrincipal principal = (WTPrincipal) objRef.getObject();
				participants.add(principal);
			}
		}
		return participants;
	}

}
