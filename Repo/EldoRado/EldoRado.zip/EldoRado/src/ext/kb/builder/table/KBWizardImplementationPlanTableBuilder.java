package ext.kb.builder.table;

import com.ptc.mvc.components.ComponentConfig;
import com.ptc.mvc.components.ComponentParams;
import com.ptc.mvc.components.OverrideComponentBuilder;
import com.ptc.mvc.components.TableConfig;
import com.ptc.windchill.enterprise.change2.mvc.builders.tables.WizardImplementationPlanTableBuilder;
import ext.kb.util.KBConstants;
import wt.util.WTException;

import java.util.List;

@OverrideComponentBuilder
public class KBWizardImplementationPlanTableBuilder extends WizardImplementationPlanTableBuilder {

    @Override
    public ComponentConfig buildComponentConfig(ComponentParams componentParams) throws WTException {
        ComponentConfig componentConfig = super.buildComponentConfig(componentParams);
        TableConfig tableConfig = (TableConfig) componentConfig;
        List<ComponentConfig> components = tableConfig.getComponents();
        for (ComponentConfig component : components) {
            if ("changeTask_ROLE_REVIEWER".equalsIgnoreCase(component.getId())) {
                String display = KBConstants.REVIEWER_ROLE.getDisplay();
                component.setLabel(display);
            }
        }
        return componentConfig;
    }
}
