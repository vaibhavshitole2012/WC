/**
 * 
 */
package ext.kb.builder.table;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

import org.apache.log4j.Logger;

import com.ptc.core.components.rendering.guicomponents.IconComponent;
import com.ptc.core.components.rendering.guicomponents.UrlDisplayComponent;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.TypeIdentifierHelper;
import com.ptc.generic.iba.AttributeService;
import com.ptc.jca.mvc.components.JcaComponentParams;
import com.ptc.mvc.components.AbstractComponentBuilder;
import com.ptc.mvc.components.ColumnConfig;
import com.ptc.mvc.components.ComponentBuilder;
import com.ptc.mvc.components.ComponentConfig;
import com.ptc.mvc.components.ComponentConfigFactory;
import com.ptc.mvc.components.ComponentParams;
import com.ptc.mvc.components.TableConfig;
import com.ptc.mvc.util.ClientMessageSource;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import com.ptc.netmarkets.util.misc.NmContext;
import com.ptc.netmarkets.util.misc.NmContextItem;
import com.ptc.netmarkets.util.misc.NmElementAddress;

import ext.kb.resources.ActionsRB;
import ext.kb.util.IBAHelper;
import ext.kb.util.KBConstants;
import ext.kb.util.KBUtils;
import wt.configurablelink.ConfigurableRevisionLink;
import wt.epm.EPMDocument;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.util.WTException;

/**
 * @author bankowskie
 *
 */
@ComponentBuilder("ext.kb.builder.table.VariantEPMDocumentsTableBuilder")
public class VariantEPMDocumentsTableBuilder extends AbstractComponentBuilder {

	private static final String RESOURCE = "ext.kb.resources.ActionsRB";
	private final ClientMessageSource messageSource = getMessageSource(RESOURCE);
	private static final Logger LOGGER = Logger.getLogger(VariantEPMDocumentsTableBuilder.class);
	
	public static final class Record {
		private IconComponent dataType;
		private UrlDisplayComponent numberLink;
		private String name;
		private String status;
		private String language;
		private String leadingLanguage;
		private String variantLangs;
		private String isVariant;
		private String cadimCid;

		public IconComponent getDataType() {
			return dataType;
		}

		public void setDataType(IconComponent dataType) {
			this.dataType = dataType;
		}

		public UrlDisplayComponent getNumberLink() {
			return numberLink;
		}

		public void setNumberLink(UrlDisplayComponent numberLink) {
			this.numberLink = numberLink;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getStatus() {
			return status;
		}

		public void setStatus(String status) {
			this.status = status;
		}

		public String getLanguage() {
			return language;
		}

		public void setLanguage(String language) {
			this.language = language;
		}

		public String getLeadingLanguage() {
			return leadingLanguage;
		}

		public void setLeadingLanguage(String leadingLanguage) {
			this.leadingLanguage = leadingLanguage;
		}

		public String getVariantLangs() {
			return variantLangs;
		}

		public void setVariantLangs(String variantLangs) {
			this.variantLangs = variantLangs;
		}

		public String getIsVariant() {
			return isVariant;
		}

		public void setIsVariant(String isVariant) {
			this.isVariant = isVariant;
		}

		public String getCadimCid() {
			return cadimCid;
		}

		public void setCadimCid(String cadimCid) {
			this.cadimCid = cadimCid;
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ptc.mvc.components.ComponentDataBuilder#buildComponentData(com.ptc.
	 * mvc.components.ComponentConfig, com.ptc.mvc.components.ComponentParams)
	 */
	@Override
	public Object buildComponentData(ComponentConfig arg0, ComponentParams arg1) throws Exception {
		JcaComponentParams params = (JcaComponentParams) arg1;
		NmCommandBean commandBean = params.getHelperBean().getNmCommandBean();
		ArrayList<EPMDocument> documents = getParams(commandBean);
		if (documents.isEmpty()) {
			Stack elementContext = commandBean.getElementContext().getContextItems();
			for (Object obj : elementContext) {
				NmContextItem contextItem = (NmContextItem) obj;
				NmOid nmoid = (NmOid) NmElementAddress.fromString(contextItem.getElemAddress().getElemAddressStr())
						.getOids().peek();
				Object refObject = nmoid.getRefObject();
				if (refObject instanceof EPMDocument)
					documents.add((EPMDocument) refObject);
			}
		}
		List<Record> records = new ArrayList<>();
		for (EPMDocument document : documents) {
			Record record = new Record();
			record.setDataType(KBUtils.getIconComponent(document));
			record.setNumberLink(KBUtils.getUrlDisplayComponent(document.getNumber(), KBUtils.getUrl(document)));
			record.setName(document.getName());
			String language = IBAHelper.getStringIBAValue(document, KBConstants.KBLANGUAGE_IBA);
			record.setLanguage(language);
			String leadingLanguage = (String) IBAHelper.getIBAValue(document, "KB_LEADING_LANGUAGE");
			record.setLeadingLanguage(leadingLanguage);
			List<EPMDocument> variants = getVariants(document);
			String variantLangs = "";
			for (EPMDocument variant : variants) {
				String variantLang = IBAHelper.getStringIBAValue(variant, KBConstants.KBLANGUAGE_IBA);
				String variantLeadingLang = (String) IBAHelper.getIBAValue(variant, "KB_LEADING_LANGUAGE");
				variantLangs += variantLeadingLang + "/" + variantLang + "+";
			}
			if (isVariantDocument(document)) {
				record.setIsVariant("true");
			} else {
				record.setIsVariant("false");
			}
			if (hasCadimCid(document)) {
				record.setCadimCid("true");
			} else {
				record.setCadimCid("false");
			}
			record.setVariantLangs(variantLangs);
			records.add(record);
		}
		return records;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ptc.mvc.components.ComponentConfigBuilder#buildComponentConfig(com.
	 * ptc.mvc.components.ComponentParams)
	 */
	@Override
	public ComponentConfig buildComponentConfig(ComponentParams arg0) throws WTException {
		ComponentConfigFactory factory = getComponentConfigFactory();
		TableConfig table = factory.newTableConfig();
		table.setLabel(messageSource.getMessage(ActionsRB.DOCUMENT_VARIANTS_TABLE));
		table.setShowCount(true);
		ColumnConfig config = factory.newColumnConfig(ActionsRB.DOCUMENT_VARIANTS_TABLE_COL1_ID, false);
		config.setLabel(ActionsRB.DOCUMENT_VARIANTS_TABLE_COL1_LABEL);
		table.addComponent(config);
		config = factory.newColumnConfig(ActionsRB.DOCUMENT_VARIANTS_TABLE_COL2_ID, false);
		config.setLabel(ActionsRB.DOCUMENT_VARIANTS_TABLE_COL2_LABEL);
		table.addComponent(config);
		config = factory.newColumnConfig(ActionsRB.DOCUMENT_VARIANTS_TABLE_COL3_ID, false);
		config.setLabel(ActionsRB.DOCUMENT_VARIANTS_TABLE_COL3_LABEL);
		table.addComponent(config);
		config = factory.newColumnConfig(ActionsRB.DOCUMENT_VARIANTS_TABLE_COL5_ID, false);
		config.setLabel(ActionsRB.DOCUMENT_VARIANTS_TABLE_COL5_LABEL);
		table.addComponent(config);
		config = factory.newColumnConfig(ActionsRB.DOCUMENT_VARIANTS_TABLE_COL6_ID, false);
		config.setLabel(ActionsRB.DOCUMENT_VARIANTS_TABLE_COL6_LABEL);
		table.addComponent(config);
		config = factory.newColumnConfig("variantLangs", false);
		config.setLabel("variantLangs");
		table.addComponent(config);
		config = factory.newColumnConfig("isVariant", false);
		config.setLabel("isVariant");
		table.addComponent(config);
		config = factory.newColumnConfig("cadimCid", false);
		config.setLabel("cadimCid");
		table.addComponent(config);
		config = factory.newColumnConfig(ActionsRB.DOCUMENT_VARIANTS_TABLE_COL4_ID, false);
		config.setLabel(ActionsRB.DOCUMENT_VARIANTS_TABLE_COL4_LABEL);
		table.addComponent(config);
		return table;
	}

	public static ArrayList<EPMDocument> getParams(NmCommandBean commandBean) throws WTException {
		ArrayList<EPMDocument> documents = new ArrayList<>();
		ArrayList selectedInOpener = commandBean.getSelectedInOpener();
		for (Object selectedObj : selectedInOpener) {
			if (selectedObj instanceof NmContext) {
				NmOid oid = ((NmContext) selectedObj).getTargetOid();
				Object refObject = oid.getRefObject();
				if (refObject instanceof EPMDocument)
					documents.add((EPMDocument) refObject);
			}
		}
		return documents;
	}

	private ArrayList<EPMDocument> getVariants(EPMDocument document) {
		ArrayList<EPMDocument> documents = new ArrayList<>();
		try {
			QueryResult allLinks = PersistenceHelper.manager.navigate(document, ConfigurableRevisionLink.ALL_ROLES,
					ConfigurableRevisionLink.class, true);
			while (allLinks.hasMoreElements()) {
				Object obj = allLinks.nextElement();
				if (obj instanceof EPMDocument) {
					EPMDocument doc = (EPMDocument) obj;
					TypeIdentifier targetType = wt.type.TypedUtilityServiceHelper.service.getTypeIdentifier(doc);
					boolean hasValidType = isDocumentAppropriateType(targetType);
					if (hasValidType)
						documents.add((EPMDocument) obj);
				}
			}
		} catch (WTException e) {
			LOGGER.error("Unable to query for source document.", e);
		}
		return documents;
	}

	private boolean isVariantDocument(Persistable persistable) {
		String sapIdx = AttributeService.getAttribute(persistable, KBConstants.KBSAP_IDX_IBA);
		if (sapIdx == null) {
			return false;
		}
		if (Integer.parseInt(sapIdx) > 0) {
			return true;
		}
		return false;
	}

	private boolean hasCadimCid(Persistable persistable) {
		String cadimCid = AttributeService.getAttribute(persistable, "KB_CADIM_CID");
		return cadimCid != null && !cadimCid.isEmpty();
	}

	private boolean isDocumentAppropriateType(TypeIdentifier targetType) {
		return targetType.isEquivalentTypeIdentifier(TypeIdentifierHelper.getTypeIdentifier("com.ptc.KBCertificate"))
				|| targetType.isEquivalentTypeIdentifier(TypeIdentifierHelper.getTypeIdentifier("com.ptc.KBStandard"))
				|| targetType.isEquivalentTypeIdentifier(
						TypeIdentifierHelper.getTypeIdentifier("com.ptc.KBTechnicalDocument"))
				|| targetType.isEquivalentTypeIdentifier(
						TypeIdentifierHelper.getTypeIdentifier("com.ptc.KBTechnicalDrawing"));
	}

}
