package ext.kb.builder.table;

import wt.util.WTException;

import com.ptc.core.htmlcomp.tableview.ConfigurableTable;
import com.ptc.mvc.components.ColumnConfig;
import com.ptc.mvc.components.ComponentConfig;
import com.ptc.mvc.components.ComponentConfigFactory;
import com.ptc.mvc.components.ComponentParams;
import com.ptc.mvc.components.OverrideComponentBuilder;
import com.ptc.windchill.enterprise.part.reports.mvc.builders.MultiLevelComponentsListTableBuilder;

import ext.kb.tableview.KBMultiLevelComponentsListTableView;

@OverrideComponentBuilder
public class KBMultiLevelComponentsListTableBuilder extends MultiLevelComponentsListTableBuilder {
	public KBMultiLevelComponentsListTableBuilder() {
	}

	public ComponentConfig buildComponentConfig(ComponentParams componentparams) throws WTException {
		ComponentConfig componentConfig = super.buildComponentConfig(componentparams);

		ComponentConfigFactory componentconfigfactory = getComponentConfigFactory();

		ColumnConfig columnconfig = columnConfigBuilder.getFindNumberColumnConfig(componentconfigfactory, getMessageSource("com.ptc.windchill.enterprise.part.reports.partReportsRB"));
		componentConfig.addComponent(columnconfig);

		return componentConfig;
	}

	public ConfigurableTable buildConfigurableTable(String s) throws WTException {
		return new KBMultiLevelComponentsListTableView();
	}
}
