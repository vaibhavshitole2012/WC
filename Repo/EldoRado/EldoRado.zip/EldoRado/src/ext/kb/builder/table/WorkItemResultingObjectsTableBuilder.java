package ext.kb.builder.table;

import java.util.ArrayList;
import java.util.List;

import com.ptc.core.components.rendering.guicomponents.UrlDisplayComponent;

/**
 * @author bankowskie
 *
 */

import com.ptc.mvc.components.AbstractComponentBuilder;
import com.ptc.mvc.components.ColumnConfig;
import com.ptc.mvc.components.ComponentBuilder;
import com.ptc.mvc.components.ComponentConfig;
import com.ptc.mvc.components.ComponentConfigFactory;
import com.ptc.mvc.components.ComponentParams;
import com.ptc.mvc.components.TableConfig;
import com.ptc.mvc.util.ClientMessageSource;
import com.ptc.windchill.enterprise.workitem.WorkItemCommands;
import ext.kb.util.DBUtils;
import ext.kb.util.KBTypeIdProvider;
import ext.kb.util.KBUtils;
import ext.kb.workflow.EPMChangeUtils;
import wt.change2.WTChangeActivity2;
import wt.content.ContentHelper;
import wt.content.ContentRoleType;
import wt.doc.WTDocument;
import wt.epm.EPMDocument;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.fc.collections.WTArrayList;
import wt.part.WTPart;
import wt.part.WTPartDescribeLink;
import wt.util.WTException;
import wt.workflow.engine.ProcessData;
import wt.workflow.engine.WfProcess;
import wt.workflow.work.WorkItem;


@ComponentBuilder("ext.kb.builder.table.WorkItemResultingObjectsTableBuilder")
public class WorkItemResultingObjectsTableBuilder extends AbstractComponentBuilder {

	private static final String RESOURCE = "ext.kb.resources.KBWorkitemRB";
	private final ClientMessageSource messageSource = getMessageSource(RESOURCE);
	
	public static final class Record{
		private String cadType;
		private UrlDisplayComponent numberLink;
		private String name;
		private String revisionVersion;
		private String lcstate;
		private String publishingStatus;
		private String publishingErrorMessage;
		private UrlDisplayComponent neutralData;
		private String neutralDataFiles;
		private String neutralDataParts;

		public String getCadType() {
			return cadType;
		}

		public void setCadType(String cadType) {
			this.cadType = cadType;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getPublishingStatus() {
			return publishingStatus;
		}

		public void setPublishingStatus(String publishingStatus) {
			this.publishingStatus = publishingStatus;
		}

		public String getPublishingErrorMessage() {
			return publishingErrorMessage;
		}

		public void setPublishingErrorMessage(String publishingErrorMessage) {
			this.publishingErrorMessage = publishingErrorMessage;
		}

		public UrlDisplayComponent getNeutralData() {
			return neutralData;
		}

		public void setNeutralData(UrlDisplayComponent neutralData) {
			this.neutralData = neutralData;
		}

		public String getNeutralDataFiles() {
			return neutralDataFiles;
		}

		public void setNeutralDataFiles(String neutralDataFiles) {
			this.neutralDataFiles = neutralDataFiles;
		}

		public String getNeutralDataParts() {
			return neutralDataParts;
		}

		public void setNeutralDataParts(String neutralDataParts) {
			this.neutralDataParts = neutralDataParts;
		}

		public String getRevisionVersion() {
			return revisionVersion;
		}

		public void setRevisionVersion(String revisionVersion) {
			this.revisionVersion = revisionVersion;
		}

		public String getLcstate() {
			return lcstate;
		}

		public void setLcstate(String lcstate) {
			this.lcstate = lcstate;
		}

		public UrlDisplayComponent getNumberLink() {
			return numberLink;
		}

		public void setNumberLink(UrlDisplayComponent numberLink) {
			this.numberLink = numberLink;
		}
	}

	@Override
	public List<Record> buildComponentData(ComponentConfig config, ComponentParams params) throws Exception {
		Object obj = params.getContextObject();
		WorkItem workItem = null;
		if(obj instanceof WorkItem){
			workItem = (WorkItem) obj;
			
		}
		WorkItemCommands commands = new WorkItemCommands();
		WfProcess process = commands.getProcessFromWorkItem(workItem);
		ProcessData context = process.getContext();
		WTArrayList successfulObjects = (WTArrayList) context.getValue("succesfulObjects");
		WTArrayList failedObjects = (WTArrayList) context.getValue("failedObjects");
		WTArrayList pendingObjects = (WTArrayList) context.getValue("publishedObjects");
		WTChangeActivity2 ect = (WTChangeActivity2) workItem.getPrimaryBusinessObject().getObject();
		QueryResult resultingObjQs = EPMChangeUtils.getResultingItems(ect);
		List<Record> resultingObjects = new ArrayList<>();
		while (resultingObjQs.hasMoreElements()){
			Record record = new Record();
			EPMDocument cad;
			Object object = resultingObjQs.nextElement();
			if(object instanceof EPMDocument){
				cad = (EPMDocument) object;
				record.setCadType(KBTypeIdProvider.isDescendant(cad, "KBCADDRW") ? "2D" : "3D");
				record.setNumberLink(KBUtils.getUrlDisplayComponent(cad.getNumber(), KBUtils.getUrl(cad)));			
				record.setName(cad.getName());
				record.setLcstate(cad.getLifeCycleState().toString());
				record.setRevisionVersion(cad.getIterationDisplayIdentifier().toString());
				record.setPublishingStatus(getPublishingStatus(cad,pendingObjects,successfulObjects,failedObjects));
				record.setPublishingErrorMessage("");
				WTDocument neutralData = EPMChangeUtils.getNeutralData(cad);
				if(neutralData!=null){
					record.setNeutralData(KBUtils.getUrlDisplayComponent(neutralData.getNumber(), KBUtils.getUrl(neutralData)));
					record.setNeutralDataFiles(getNeutralDataFilesInfoAsString(neutralData));
					record.setNeutralDataParts(getNeutralDataPartsInfoAsString(neutralData));
				}
				resultingObjects.add(record);
			}
		}
		return resultingObjects;
	}

	@Override
	public ComponentConfig buildComponentConfig(ComponentParams params) throws WTException {
		ComponentConfigFactory factory = getComponentConfigFactory();
		TableConfig table = factory.newTableConfig();
		table.setLabel(messageSource.getMessage("RESULTING_OBJECTS_TABLE"));
		table.setShowCount(true);
		ColumnConfig cadType = factory.newColumnConfig("cadType", false);
		cadType.setLabel("CAD Type");
		table.addComponent(cadType);
		ColumnConfig number = factory.newColumnConfig("numberLink", false);
		number.setLabel("Number");
		number.setInfoPageLink(true);
		table.addComponent(number);
		ColumnConfig name = factory.newColumnConfig("name", false);
		name.setLabel("Name");
		table.addComponent(name);
		ColumnConfig revisionVersion = factory.newColumnConfig("revisionVersion", false);
		revisionVersion.setLabel("Revision");
		table.addComponent(revisionVersion);
		ColumnConfig lcstate = factory.newColumnConfig("lcstate", false);
		lcstate.setLabel("LifeCycle State");
		table.addComponent(lcstate);
		ColumnConfig publishingStatus = factory.newColumnConfig("publishingStatus", false);
		publishingStatus.setLabel("Publishing Status");
		table.addComponent(publishingStatus);
		ColumnConfig publishingErrorMessage = factory.newColumnConfig("publishingErrorMessage", false);
		publishingErrorMessage.setLabel("Publishing Error Message");
		table.addComponent(publishingErrorMessage);
		ColumnConfig neutralData = factory.newColumnConfig("neutralData", false);
		neutralData.setLabel("Neutral Data");
		neutralData.setInfoPageLink(true);
		table.addComponent(neutralData);
		ColumnConfig neutralDataFiles = factory.newColumnConfig("neutralDataFiles", false);
		neutralDataFiles.setLabel("Neutral Data Files");
		table.addComponent(neutralDataFiles);
		ColumnConfig neutralDataParts = factory.newColumnConfig("neutralDataParts", false);
		neutralDataParts.setLabel("Neutral Data Parts");
		table.addComponent(neutralDataParts);
		return table;
	}
	
		
	private String getNeutralDataFilesInfoAsString(WTDocument neutralData) throws WTException{
		String result = "";
			QueryResult primaryContent = ContentHelper.service.getContentsByRole(neutralData, ContentRoleType.PRIMARY);
			if(primaryContent.hasMoreElements()){
				Persistable content = (Persistable) primaryContent.nextElement();
				result += content.getIdentity() +"\n";
			}
			QueryResult secondaryContent = ContentHelper.service.getContentsByRole(neutralData, ContentRoleType.SECONDARY);
			if(secondaryContent.hasMoreElements()){
				Persistable content = (Persistable) secondaryContent.nextElement();
				result += content.getIdentity() +"\n";
			}
		return result;
	}
	
	private String getNeutralDataPartsInfoAsString(WTDocument neutralData) throws WTException{
		String result = "";
		List<WTPart> relatedParts = DBUtils.navigateBetweenObjects(WTPart.class, WTPartDescribeLink.class, neutralData, WTPartDescribeLink.ALL_ROLES);
		for(WTPart part : relatedParts){
			result+=part.getIdentity()+"\n";
		}
		return result;
	}
	
	private String getPublishingStatus(EPMDocument cad, WTArrayList pending, WTArrayList successful, WTArrayList failed){
		if(successful.contains(cad)){
			return "Job successful";
		}else if(failed.contains(cad)){
			return "Job failed";
		}else if(pending.contains(cad)){
			return "Job executing";
		}else{
			return "Job not found";
		}
	}
}
