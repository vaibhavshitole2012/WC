package ext.kb.cache.instance;

import java.rmi.RemoteException;
import java.util.List;

import ext.kb.cache.KBCacheManager;
import ext.kb.dynamiclist.naming.MaterialCatalogueEnumerationInfoProvider;

public class MaterialCacheManager extends KBCacheManager {

	private static final long serialVersionUID = -2736248152914703585L;
	private static final String KEY = "MATERIAL_ID";
	private static final String KEY_INFO_PROVIDER = "MATERIAL_ID_INFO_PROVIDER";
	private static MaterialCacheManager instance = null;

	public MaterialCatalogueEnumerationInfoProvider getMaterialCatalogueEnumerationInfoProvider() {
		return (MaterialCatalogueEnumerationInfoProvider) retrieve(KEY_INFO_PROVIDER);
	}

	public void setMaterialCatalogueEnumerationInfoProvider(
			MaterialCatalogueEnumerationInfoProvider materialCatalogueEnumerationInfoProvider) {
		store(KEY_INFO_PROVIDER, materialCatalogueEnumerationInfoProvider);
	}

	public MaterialCacheManager() throws RemoteException {
		super(KEY);
	}

	public static synchronized void createCache() throws RemoteException {
		if (instance == null) {
			instance = new MaterialCacheManager();
		}
	}

	public static MaterialCacheManager getCache() throws RemoteException {
		if (instance == null) {
			createCache();
		}
		return instance;
	}

	public void store(List<?> list) {
		synchronized (MaterialCacheManager.class) {
			super.store(list);
		}
	}
}
