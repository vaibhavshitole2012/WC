package ext.kb.change2.dataUtilities;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.rendering.guicomponents.TextDisplayComponent;
import com.ptc.core.ui.resources.ComponentMode;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import com.ptc.windchill.enterprise.change2.ChangeManagementClientHelper;
import com.ptc.windchill.enterprise.change2.dataUtilities.ImplementationPlanTableDataUtility;
import com.ptc.windchill.enterprise.change2.forms.ChangeManagementFormProcessorHelper;
import ext.kb.workflow.ChangeTaskUtils;
import wt.org.WTPrincipal;
import wt.util.WTException;

import static com.ptc.windchill.enterprise.change2.ChangeManagementDescriptorConstants.ColumnIdentifiers.IMPLEMENTATION_PLAN_TABLE_LAST_ROLE_REVIEWER;


public class KBImplementationPlanTableDataUtility extends ImplementationPlanTableDataUtility {

    private static final String ACTIVITY_REVIEWER = "changeTask_ReviewerPicker_dn";

    @Override
    public Object getDataValue(String component_id, Object datum, ModelContext mc) throws WTException {
        NmCommandBean commandBean = mc.getNmCommandBean();
        boolean isReviewer = component_id
                .equals(IMPLEMENTATION_PLAN_TABLE_LAST_ROLE_REVIEWER);
        if (isReviewer && ChangeTaskUtils.isAllowedBlankReviewer()) {
            ComponentMode mode = ChangeManagementClientHelper.getMode(mc);
            WTPrincipal selectedReviewer = ChangeManagementFormProcessorHelper.getUser(ACTIVITY_REVIEWER, commandBean);
            if (ComponentMode.CREATE.equals(mode) && selectedReviewer == null) {
                return TextDisplayComponent.NBSP;
            }
        }
        return super.getDataValue(component_id, datum, mc);
    }
}
