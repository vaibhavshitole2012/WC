package ext.kb.change2.helper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;

import com.ptc.netmarkets.util.misc.NmAction;
import com.ptc.netmarkets.util.misc.NmActionServiceHelper;

import wt.change2.WTChangeActivity2;
import wt.change2._ChangeActivity2;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.httpgw.URLFactory;
import wt.identity.IdentityFactory;
import wt.pds.StatementSpec;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;

/**
 * This class is expected to have most of the utility/Query methods for Change
 * Management..
 *
 * @author Shreyas
 *
 */

public class ChangeQueries {

	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(ChangeQueries.class);

	/**
	 *
	 * This method return change activity for number
	 *
	 * @param number
	 * @return
	 * @throws WTException
	 */
	public static WTChangeActivity2 getChangeActByNumber(final String number) throws WTException {

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Searching for change activity ->" + number);
		}

		final QuerySpec qSpec = new QuerySpec(WTChangeActivity2.class);
		final SearchCondition numberCond = new SearchCondition(WTChangeActivity2.class, _ChangeActivity2.NUMBER, SearchCondition.EQUAL, number, false);
		qSpec.appendWhere(numberCond, new int[] {});
		final QueryResult results = PersistenceHelper.manager.find((StatementSpec) qSpec);

		WTChangeActivity2 changeActivity2 = null;
		if (results.hasMoreElements()) {
			changeActivity2 = (WTChangeActivity2) results.nextElement();
		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("returned Change Activity IS: " + changeActivity2);
		}
		return changeActivity2;
	}

	/**
	 * Returns the details page URL of the object
	 *
	 * @param request
	 * @return
	 * @throws WTException
	 */
	public static List<String> getEctInfoPageURL(final String number) throws WTException {

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Number is " + number);
		}
		final List<String> result = new ArrayList<>();

		Persistable persistable = null;

		if (number != null) {
			persistable = getChangeActByNumber(number);
		}

		if (persistable == null) {
			result.add("ERROR");
			result.add(number + " Does not exist.");
		} else {
			result.add("SUCCESS ");
			result.add(getInfoPageURL(persistable));

		}

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("returing result list " + result);
		}
		return result;
	}

	/**
	 * Return information page link for the input persistable object.
	 *
	 * @param obj - a persistable object.
	 * @return - Information page URL.
	 * @throws WTException
	 */
	public static String getInfoPageURL(final Persistable obj) throws WTException {

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("obj: " + IdentityFactory.getDisplayIdentifier(obj));
		}

		final NmAction nmAction = NmActionServiceHelper.service.getAction(NmAction.Type.OBJECT, "view");

		final HashMap<String, String> paramMap = new HashMap<>();
		paramMap.put("oid", new ReferenceFactory().getReferenceString(obj));

		final String url = new URLFactory().getHREF(nmAction.getUrl(), paramMap, true);

		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("URLs: " + url);
		}

		return url;
	}

}
