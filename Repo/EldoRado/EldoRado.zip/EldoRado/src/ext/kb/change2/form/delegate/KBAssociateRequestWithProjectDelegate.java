package ext.kb.change2.form.delegate;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Vector;

import org.apache.log4j.Logger;

import wt.change2.ChangeItemIfc;
import wt.change2.WTChangeRequest2;
import wt.fc.ObjectIdentifier;
import wt.fc.QueryResult;
import wt.fc.collections.WTArrayList;
import wt.fc.collections.WTCollection;
import wt.folder.Folder;
import wt.folder.FolderHelper;
import wt.folder.SubFolder;
import wt.inf.sharing.DataSharingHelper;
import wt.inf.sharing.SharedContainerMap;
import wt.log4j.LogR;
import wt.projmgmt.admin.Project2;
import wt.projmgmt.admin.Project2Reference;
import wt.util.WTException;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.FormResult;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import com.ptc.netmarkets.util.misc.NmContextStringTokenizer;
import com.ptc.windchill.enterprise.change2.forms.delegates.ChangeItemFormDelegate;

import ext.kb.util.DBUtils;
import ext.kb.util.KBContextService;
import ext.kb.util.KBTypeIdProvider;

public class KBAssociateRequestWithProjectDelegate extends ChangeItemFormDelegate {

    private static final Logger LOG = LogR.getLogger(KBAssociateRequestWithProjectDelegate.class.getName());
    
    private Project2 association;
    private ObjectIdentifier oid;
    private String optionalFolderName;

    public KBAssociateRequestWithProjectDelegate() {
        KBAssociateRequestWithProjectDelegate del = KBContextService.getContext().getBean(KBAssociateRequestWithProjectDelegate.class);
        this.optionalFolderName = del.optionalFolderName;
    }

    public KBAssociateRequestWithProjectDelegate(String s) {
        optionalFolderName = s;
    }

    @Override
    public FormResult postProcess(NmCommandBean paramNmCommandBean, List<ObjectBean> paramList) throws WTException {
        
    	Object o = paramList.get(0).getObject();
    	if  (KBTypeIdProvider.isDescendant(o, "RED")) {
    	
	    	@SuppressWarnings("unchecked")
	        HashMap<String, String> idValues = paramNmCommandBean.getOldText();
	        Iterator<Entry<String, String>> it = idValues.entrySet().iterator();
	        while (it.hasNext()) {
	            Entry<String, String> item = it.next();
	            if (item.getKey().startsWith("projectItemPicker")) {
	                NmContextStringTokenizer t = new NmContextStringTokenizer(item.getValue(), ':');
	                String identifierType = t.nextToken();
	                String classText = t.nextToken();
	                String id = t.nextToken();
	                if (identifierType.endsWith("OR")) {
	                    try {
	                        oid = new ObjectIdentifier(Class.forName(classText), Long.parseLong(id));
	                        association = DBUtils.queryObjectById(Project2.class, oid);
	                    } catch (NumberFormatException e) {
	                        throw new RuntimeException("Unable to parse project id", e);
	                    } catch (ClassNotFoundException e) {
	                        throw new RuntimeException("Unable to look up project", e);
	                    }
	                }
	                break;
	            }
	        }
    	}
        FormResult res = super.postProcess(paramNmCommandBean, paramList);
        return res;
    }

    @Override
    protected Class getAssociationClass(ChangeItemIfc paramChangeItemIfc) {
        return Project2.class;
    }

    @Override
    protected String getDefaultTableId() {
        return "kbred.kbdefineprojectdependency";
    }

    @Override
    protected String getDelegateName() {
        return KBAssociateRequestWithProjectDelegate.class.toString();
    }

    @Override
    protected Vector getItemsToStoreForAssociation(List paramList) throws WTException {
        Vector<Project2> v = new Vector<Project2>();
        v.add(association);
        return v;
    }

    @Override
    protected WTCollection getRefreshedAssociationLinks(ChangeItemIfc paramChangeItemIfc) throws WTException {
        WTCollection col = new WTArrayList();
        if (association != null) {
        	col.add(association);
        }
        return col;
    }

    @Override
    protected WTCollection processLinkAttributes(ChangeItemIfc paramChangeItemIfc, WTCollection paramWTCollection)
            throws WTException {
        if (!paramWTCollection.isEmpty()) {
            WTChangeRequest2 cr = (WTChangeRequest2) paramChangeItemIfc;
            WTCollection col = new WTArrayList();
            Project2Reference projectRef = new Project2Reference();
            projectRef.setObject(association);
            QueryResult cc = FolderHelper.service.findSubFolders(association.getDefaultCabinet());
            Folder f = null;
            while (cc.hasMoreElements()) {
                Object o = cc.nextElement();
                if (o instanceof SubFolder) {
                    SubFolder sf = (SubFolder) o;
                    if (optionalFolderName.equals(sf.getName())) {
                        f = sf;
                        break;
                    }
                }
            }
            if (f == null) {
                f = association.getDefaultCabinet();
            }
            SharedContainerMap localSharedContainerMap = DataSharingHelper.service.shareVersion(cr, projectRef, f);
            if (localSharedContainerMap != null) {            
                col.add(localSharedContainerMap);
            }
            return col;
        }
        LOG.info("No projects found, skipping changeRequest sharing");
        return new WTArrayList();
    }

}
