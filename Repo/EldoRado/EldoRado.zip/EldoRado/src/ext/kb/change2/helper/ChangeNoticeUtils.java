package ext.kb.change2.helper;

import org.apache.log4j.Logger;

import ext.kb.piint.service.PiInterfaceService;
import ext.kb.workflow.EPMChangeUtils;
import wt.change2.ChangeHelper2;
import wt.change2.ChangeOrderIfc;
import wt.change2.ChangeRecord2;
import wt.change2.ChangeRequest2;
import wt.change2.Changeable2;
import wt.change2.WTChangeActivity2;
import wt.change2.WTChangeOrder2;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.services.ServiceFactory;
import wt.util.WTException;

public class ChangeNoticeUtils {

	private static final String C_NAME = EPMChangeUtils.class.getName();
	private static final Logger LOG = Logger.getLogger(C_NAME);

	/**
	 * Get ECR state from CADIM. This method retrieves the ECR in Windchill,
	 * this ECR number is used for look up in CADIM
	 * 
	 * @param ecn
	 *            - primary business object
	 * @return ECR state from CADIM , return null if no ECR number
	 * @throws WTException
	 */

	public static String getECRState(WTChangeOrder2 ecn) throws WTException {
		LOG.debug("Starting getECRState method for ecn: " +ecn.getNumber());
		String state = null;
		ChangeRequest2 changeRequest2 = null;
		QueryResult changeRequests = ChangeHelper2.service.getLatestChangeRequest((ChangeOrderIfc) ecn);
		if (changeRequests.hasMoreElements()) {
			changeRequest2 = (ChangeRequest2) changeRequests.nextElement();
			String ecrNumber = changeRequest2.getNumber();
			LOG.debug("ECRNumber is : " + ecrNumber);
			PiInterfaceService service = ServiceFactory.getService(PiInterfaceService.class);
			state = service.performGetECRStateFunction(ecn, ecrNumber);
			if (state.equals("0")) {
				state = null;
			}
		}
		LOG.debug("Output from ECR state : " + state);
		return state;
	}

	/**
	 * Gets Change Notice object associated with given Change Activity
	 * 
	 * @param changeActivity
	 * @return Change Notice associated with given Change Activity or null if no
	 *         Change Notices were found
	 * @throws WTException
	 */
	public static WTChangeOrder2 getECN(WTChangeActivity2 changeActivity) throws WTException {

		WTChangeOrder2 ecn = null;
		QueryResult changeOrderQR = ChangeHelper2.service.getChangeOrder(changeActivity);
		if (changeOrderQR.hasMoreElements()) {
			ecn = (WTChangeOrder2) changeOrderQR.nextElement();
		}
		return ecn;
	}

	/**
	 * Gets Change Record object associated with given persistable and its
	 * Change Activity
	 * 
	 * @param persistable
	 * @return Change Record object associated with persistable or null if none
	 *         was found
	 * @throws WTException
	 */
	public static ChangeRecord2 getChangeRecord(Persistable persistable) throws WTException {

		ChangeRecord2 changeRecord = null;
		QueryResult changingChangeActivities = ChangeHelper2.service
				.getChangingChangeActivities((Changeable2) persistable, false);
		while (changingChangeActivities.hasMoreElements()) {
			Object nextElement = changingChangeActivities.nextElement();
			changeRecord = (ChangeRecord2) nextElement;
		}
		return changeRecord;
	}

}
