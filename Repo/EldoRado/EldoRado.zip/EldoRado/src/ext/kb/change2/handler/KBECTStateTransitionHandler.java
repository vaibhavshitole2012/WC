package ext.kb.change2.handler;

import java.util.Enumeration;

import wt.change2.ChangeActivity2;
import wt.change2.ChangeHelper2;
import wt.change2.ChangeRecord2;
import wt.change2.handler.DefaultChangeTransitionHandler;
import wt.doc.WTDocument;
import wt.fc.ObjectVectorIfc;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.util.WTException;

/**
 * Custom implementation for TransitionHanlder. It's purpose is to filter
 * objects that will be promoted and leave only WTDOcuments
 * 
 * @author zycha
 *
 */
public class KBECTStateTransitionHandler extends DefaultChangeTransitionHandler {

	@Override
	protected QueryResult getTargets(Object paramObject) throws WTException {
		QueryResult changeablesAfter = ChangeHelper2.service.getChangeablesAfter((ChangeActivity2) paramObject, false);
		ObjectVectorIfc objectVectorIfc = changeablesAfter.getObjectVectorIfc();

		Enumeration elements = objectVectorIfc.elements();
		while (elements.hasMoreElements()) {
			Object nextElement = elements.nextElement();
			if (nextElement instanceof ChangeRecord2) {
				ChangeRecord2 cr = (ChangeRecord2) nextElement;
				Persistable roleBObject = cr.getRoleBObject();
				if (!(roleBObject instanceof WTDocument)) {
					objectVectorIfc.removeElement(nextElement);
				}
			}
		}

		QueryResult filteredChangeables = new QueryResult(objectVectorIfc);
		return filteredChangeables;
	}
}
