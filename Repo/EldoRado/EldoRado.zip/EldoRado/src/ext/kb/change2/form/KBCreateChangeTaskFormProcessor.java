package ext.kb.change2.form;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.FormProcessingStatus;
import com.ptc.core.components.forms.FormResult;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import com.ptc.windchill.enterprise.change2.forms.ChangeManagementFormProcessorHelper;
import com.ptc.windchill.enterprise.change2.forms.processors.CreateChangeTaskFormProcessor;
import ext.kb.util.KBTeamUtils;
import ext.kb.util.KBType;
import org.apache.log4j.Logger;
import wt.change2.WTChangeActivity2;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.log4j.LogR;
import wt.org.WTPrincipal;
import wt.session.SessionServerHelper;
import wt.util.WTException;

import java.util.List;

import static ext.kb.change2.form.ChangeTaskFormProcessorHelper.ACTIVITY_REVIEWER;

public class KBCreateChangeTaskFormProcessor extends CreateChangeTaskFormProcessor {

    protected static final Logger logger = LogR.getLogger(KBCreateChangeTaskFormProcessor.class.getName());

    @Override
    public FormResult postProcess(NmCommandBean cmdBeans, List<ObjectBean> objBeans) throws WTException {
        FormResult result = null;
        boolean flag = SessionServerHelper.manager.isAccessEnforced();
        try {
            result = super.postProcess(cmdBeans, objBeans);
            if (result.getStatus() == FormProcessingStatus.SUCCESS) {
                flag = SessionServerHelper.manager.setAccessEnforced(false);
                for (ObjectBean bean : objBeans) {
                    Object object = bean.getObject();
                    if (KBType.isDescendedFrom(object, "com.ptc.KBECT")) {
                        ChangeTaskFormProcessorHelper.validateChangeTaskName(bean, result);
                        if (!KBType.isOfType(object, "com.ptc.KBSCT")) {
                            ChangeTaskFormProcessorHelper.validateChangeTaskAssignee(bean, result);
                        }
                    }
                    if (KBType.isOfType(object, "com.ptc.KBSCT")) {
                        if(!ChangeTaskFormProcessorHelper.isUserInWFApproverRole(bean, result)) return result;
                        ChangeTaskFormProcessorHelper.handleReadyForApprovalValue(bean, result);
                        WTChangeActivity2 ect = (WTChangeActivity2) PersistenceHelper.manager.refresh((Persistable) bean.getObject());
                        ChangeTaskFormProcessorHelper.removeSystemBomFromResulting(ect);
                        ChangeTaskFormProcessorHelper.removeSystemBomFromAffected(ect);
                        WTPrincipal approver = ChangeManagementFormProcessorHelper.getUser(ACTIVITY_REVIEWER, bean);
                        KBTeamUtils.resetTeamForRoles(ect, "CAD-APPROVER", approver);
                        logger.debug("WF Approver updated");
                    }
                }
            }
        } catch (Exception e) {
            result = ChangeManagementFormProcessorHelper.handleFormResultException(result, getLocale(), e,
                    getProcessorErrorMessage());
            logger.error(e);
        } finally {
            flag = SessionServerHelper.manager.setAccessEnforced(flag);
        }
        return result;
    }

}
