package ext.kb.datautility;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.ptc.core.components.rendering.guicomponents.AttributeInputComponent;
import com.ptc.core.components.rendering.guicomponents.AttributeInputCompositeComponent;
import com.ptc.core.components.rendering.guicomponents.HTMLGuiComponent;

import ext.kb.util.*;

import org.apache.log4j.Logger;

import wt.doc.WTDocument;
import wt.fc.Persistable;
import wt.inf.container.WTContained;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerHelper;
import wt.inf.team.ContainerTeamManaged;
import wt.lifecycle.LifeCycleManaged;
import wt.log4j.LogR;
import wt.org.WTPrincipal;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.util.WTProperties;

public class DataUtilityHelper {

    private static final Logger LOGGER = LogR.getLogger(DataUtilityHelper.class.getName());
    private static final String KB_ORGANIZATION_NAME;
    private static final String HVAC_ORGANIZATION_NAME;
    private static final Set<String> PRODUCT_MANAGEMENT_EDITABLE_ATTRIBUTES;
    private static final Set<String> ATTRIBUTE_MANAGER_EDITABLE_ATTRIBUTES;
    private static final List<String> ROLES_ELIGIBLE_TO_EDIT_DOC_ATTRIBUTES = Arrays.asList("DATA MANAGEMENT", "CAD-DESIGNER",
                                                                                            "DESIGNER-LIMITED", "SYSTEM ENGINEER");

    static {
        try {
            WTProperties properties = WTProperties.getServerProperties();

            String articleEditableAttributesString = properties.getProperty("ext.kb.articleEditableAttributesByProductManager", "");
            PRODUCT_MANAGEMENT_EDITABLE_ATTRIBUTES = new HashSet<String>(
                    Arrays.asList(articleEditableAttributesString.split(",")));

            String articleEditableAttributesByAttributeManagerString = properties
                    .getProperty("ext.kb.articleEditableAttributesByAttributeManager", "");
            ATTRIBUTE_MANAGER_EDITABLE_ATTRIBUTES = new HashSet<String>(
                    Arrays.asList(articleEditableAttributesByAttributeManagerString.split(",")));

            KB_ORGANIZATION_NAME = properties.getProperty("ext.organization.kb.name", "KB");
            HVAC_ORGANIZATION_NAME = properties.getProperty("ext.organization.hvac.name", "HVAC");

        } catch (Throwable t) {
            System.err.println("Error initializing " + EditArticleAttributesDataUtility.class.getName());
            t.printStackTrace(System.err);
            throw new ExceptionInInitializerError(t);
        }
    }

    private DataUtilityHelper() {
    }

    public static String getProperty(String property) {
        WTProperties wtProperties = null;
        try {
            wtProperties = WTProperties.getLocalProperties();
            if (wtProperties != null) {
                return wtProperties.getProperty(property, "");
            }
        } catch (IOException localIOException) {
            LOGGER.error(localIOException);
        }
        return null;
    }

    public static boolean isValidObjectType(Class<?> neededClass, Class<?> paramObject, Object dataUtility) {

        if (!neededClass.isAssignableFrom(paramObject)) {
            StringBuffer localStringBuffer = new StringBuffer(256);
            localStringBuffer.append(dataUtility.getClass()).append(".getDataValue() - datum: ").append(paramObject);
            LOGGER.warn(localStringBuffer);
            return false;
        }
        return true;
    }

    /**
     * Checks edit possibility of given attribute depends on user assignment.
     *
     * @param persistable Edited article.
     * @param componentId Id of attribute.
     * @return True or false depending on that which roles user is assigned to.
     * @throws WTException
     */
    public static boolean shouldBeEditableOnPart(Persistable persistable, String componentId) throws WTException {
        boolean editable = true;

        WTPrincipal currentUser = SessionHelper.manager.getPrincipal();
        WTPrincipal wtAdministrator = SessionHelper.manager.getAdministrator();
        final boolean isProductMgr = KBTeamUtils.isUserInRole(SessionHelper.getPrincipal(),
                (ContainerTeamManaged) ((WTContained) persistable).getContainer(), KBConstants.PRODUCT_MANAGEMENT_ROLE);
        final boolean isDataMgr = KBTeamUtils.isUserInRole(SessionHelper.getPrincipal(),
                (ContainerTeamManaged) ((WTContained) persistable).getContainer(), KBConstants.DATA_MANAGEMENT);
        final boolean isAttributeMgr = KBTeamUtils.isUserInRole(SessionHelper.getPrincipal(),
                (ContainerTeamManaged) ((WTContained) persistable).getContainer(), KBConstants.ATTRIBUTE_MANAGER_ROLE);
        final boolean isDocumentMgr = KBTeamUtils.isUserInRole(SessionHelper.getPrincipal(),
                (ContainerTeamManaged) ((WTContained) persistable).getContainer(), KBConstants.DOCUMENT_MANAGEMENT_ROLE);
        final boolean isCostEditor = KBTeamUtils.isUserInRole(SessionHelper.getPrincipal(),
                (ContainerTeamManaged) ((WTContained) persistable).getContainer(), KBConstants.COST_EDITOR_ROLE);
        final boolean isProductionMgr = KBTeamUtils.isUserInRole(SessionHelper.getPrincipal(),
                (ContainerTeamManaged) ((WTContained) persistable).getContainer(), KBConstants.PRODUCTION_MANAGER_ROLE);
        final boolean isDesignerOrDesignerLimited = isDesigner(persistable);

        boolean isKbOrHvacOrg = ValidationHelper.isObjectInOrganization(persistable, HVAC_ORGANIZATION_NAME)
                || ValidationHelper.isObjectInOrganization(persistable, KB_ORGANIZATION_NAME);
        boolean isIn1010State = KBUtils.isObjectInState((LifeCycleManaged) persistable, KBConstants.IN_WORK);


        if (isDataMgr) {
            LOGGER.debug("Data Manager can edit: " + componentId);
            return true;
        }

        if (isDesignerOrDesignerLimited && isIn1010State){
            LOGGER.debug("Designer and Designer Limited can edit: " + componentId);
            return true;
        }

        if (isProductMgr && isAttributeMgr && isKbOrHvacOrg) {
            return shouldProductManagerBeAbleToEdit(componentId) || shouldAttributeManagerBeAbleToEdit(componentId);
        }

        if (isProductMgr && isKbOrHvacOrg) {
            return shouldProductManagerBeAbleToEdit(componentId);
        }

        if (isAttributeMgr) {
            return shouldAttributeManagerBeAbleToEdit(componentId);
        }

        if ((isDocumentMgr || isProductionMgr || isCostEditor)) {
            LOGGER.debug("User cannot edit: " + componentId);
            return false;
        }

        if (ValidationHelper.isObjectInStateReleased(persistable) && !currentUser.equals(wtAdministrator)) {
            LOGGER.debug("State released. Only Admin and Data Manager can edit: " + componentId);
            return false;
        }

        return editable;
    }

    /**
     * Checks edit possibility of given attribute depends on user assignment.
     *
     * @param document Edited document.
     * @return True or false depending on that which roles user is assigned to.
     * @throws WTException
     */
    public static boolean shouldBeEditableOnDocument(WTDocument document) throws WTException {
        WTPrincipal currentUser = SessionHelper.manager.getPrincipal();
        WTPrincipal wtAdministrator = SessionHelper.manager.getAdministrator();
        WTContainer container = document.getContainer();
        boolean isAdministrator = WTContainerHelper.service.isAdministrator(container.getContainerReference(), currentUser, true);

        boolean isDocumentMgr = KBTeamUtils.isUserInRole(SessionHelper.getPrincipal(),
                                            (ContainerTeamManaged) container, KBConstants.DOCUMENT_MANAGEMENT_ROLE);
        boolean isDataMgr = KBTeamUtils.isUserInRole(SessionHelper.getPrincipal(),
                (ContainerTeamManaged) container, KBConstants.DATA_MANAGEMENT);
        boolean isDesigner = isDesigner(document);
        boolean isUserInAnyOfValidRoles = KBTeamUtils.isUserInAnyOfRoles(currentUser, (ContainerTeamManaged) container,
                                                                            ROLES_ELIGIBLE_TO_EDIT_DOC_ATTRIBUTES);
        boolean isIn1010State = KBUtils.isObjectInState(document, KBConstants.IN_WORK);

        if(isDocumentMgr && !isUserInAnyOfValidRoles){
            return false;
        } else if(isDesigner && isIn1010State){
            return true;
        } else if(isUserInAnyOfValidRoles && !isDesigner){
            return true;
        } else if (!(isDataMgr || currentUser.equals(wtAdministrator) || isAdministrator)) {
            return false;
        }

        return true;
    }
    private static boolean isDesigner(Persistable persistable) throws WTException{
        boolean isDesigner =  KBTeamUtils.isUserInRole(SessionHelper.getPrincipal(),
                (ContainerTeamManaged) ((WTContained) persistable).getContainer(),
                KBConstants.DESIGNER_ROLE);
        boolean isDesignerLimited = KBTeamUtils.isUserInRole(SessionHelper.getPrincipal(),
                (ContainerTeamManaged) ((WTContained) persistable).getContainer(),
                KBConstants.DESIGNER_LIMITED_ROLE);
        boolean isSystemEngineer = KBTeamUtils.isUserInRole(SessionHelper.getPrincipal(),
                (ContainerTeamManaged) ((WTContained) persistable).getContainer(),
                KBConstants.SYSTEM_ENGINEER);
        return isDesigner || isDesignerLimited || isSystemEngineer;
    }

    private static boolean shouldAttributeManagerBeAbleToEdit(String componentId){
        if (ATTRIBUTE_MANAGER_EDITABLE_ATTRIBUTES.contains(componentId)) {
            LOGGER.debug("Attribute Manager can edit: " + componentId);
            return true;
        } else {
            LOGGER.debug("Attribute Manager cannot edit: " + componentId);
            return false;
        }
    }

    private static boolean shouldProductManagerBeAbleToEdit(String componentId){
        if (PRODUCT_MANAGEMENT_EDITABLE_ATTRIBUTES.contains(componentId)) {
            LOGGER.debug("Product Manager can edit: " + componentId);
            return true;
        } else {
            LOGGER.debug("Product Manager cannot edit: " + componentId);
            return false;
        }
    }

    /**
     * Checks type of component, casts and sets field editable on component object.
     * @param component Attribute component object.
     * @param shouldBeEditable Value which should be set as editable field in component.
     */
    public static void setEditableFieldOnComponent(Object component, boolean shouldBeEditable) {
        if (component instanceof AttributeInputComponent) {
            AttributeInputComponent att = (AttributeInputComponent) component;
            att.setEditable(shouldBeEditable);
        } else if (component instanceof AttributeInputCompositeComponent) {
            AttributeInputCompositeComponent att = (AttributeInputCompositeComponent) component;
            att.getValueInputComponent().setEditable(shouldBeEditable);

        } else if (component instanceof HTMLGuiComponent) {
            HTMLGuiComponent att = (HTMLGuiComponent) component;
            att.setEditable(shouldBeEditable);
        }
    }
    /**
     * Verify and return true for admins and for Data and Document Management role 
     * @param wtdocument
     */
    public static boolean isEditableOnDocument(WTDocument document) 
			throws WTException {
    	LOGGER.debug("INSIDE method shouldBeEditableOnTechDocDocument");
		WTPrincipal currentUser = SessionHelper.manager.getPrincipal();
		WTPrincipal wtAdministrator = SessionHelper.manager.getAdministrator();
		WTContainer container = document.getContainer();
		boolean isAdministrator = WTContainerHelper.service.isAdministrator(
				container.getContainerReference(), currentUser, true);
		boolean isDocumentMgr = KBTeamUtils.isUserInRole(
				SessionHelper.getPrincipal(), (ContainerTeamManaged) container,
				KBConstants.DOCUMENT_MANAGEMENT_ROLE);
		boolean isDataMgr = KBTeamUtils.isUserInRole(
				SessionHelper.getPrincipal(), (ContainerTeamManaged) container,
				KBConstants.DATA_MANAGEMENT);
		LOGGER.debug("isAdministrator" + isAdministrator);
		LOGGER.debug("isDocumentMgr" + isDocumentMgr);
		LOGGER.debug("isDataMgr" + isDataMgr);
		if (isDocumentMgr || isDataMgr || currentUser.equals(wtAdministrator)
				|| isAdministrator)
			return true;
		return false;
	}
}
