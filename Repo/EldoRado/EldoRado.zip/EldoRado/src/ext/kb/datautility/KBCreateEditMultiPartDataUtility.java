package ext.kb.datautility;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.util.OidHelper;
import com.ptc.windchill.enterprise.object.dataUtilities.RequiredATISetUtility;

import ext.kb.util.KBUtils;
import wt.doc.WTDocument;
import wt.fc.Persistable;
import wt.part.WTPart;
import wt.util.WTException;

public class KBCreateEditMultiPartDataUtility extends RequiredATISetUtility {

	@Override
	public Object getDataValue(String paramString, Object paramObject, ModelContext paramModelContext)
			throws WTException {
		if (KBUtils.isCreateMode(paramModelContext.getDescriptorMode())) {
			Object dataValue = correspondingDataUtility(paramString, paramObject, paramModelContext);
			return dataValue;
		}else if (KBUtils.isEditMode(paramModelContext.getDescriptorMode())){
            Object dataValue = correspondingDataUtility(paramString, paramObject, paramModelContext);
            setEditableFieldOnDataValue(paramString, paramObject, dataValue);
            return dataValue;
        }
		return super.getDataValue(paramString, paramObject, paramModelContext);
	}

	private Object correspondingDataUtility(String paramString, Object paramObject, ModelContext paramModelContext)
			throws WTException {

		switch (paramString) {
		case "IBA|KB_GEKLA":
			DynamicListItemPickerDataUtility geklaUtility = new DynamicListItemPickerDataUtility();
			return geklaUtility.getDataValueInternal(paramString, paramObject, paramModelContext);
		case "IBA|KB_MATERIAL":
			KBMaterialDataUtility materialUtility = new KBMaterialDataUtility();
			return materialUtility.getDataValueInternal(paramString, paramObject, paramModelContext);
		case "IBA|KB_TRANSLATION_ID":
			KBTranslationIDPickerDataUtility translationUtility = new KBTranslationIDPickerDataUtility();
			return translationUtility.getDataValueInternal(paramString, paramObject, paramModelContext);
		case "IBA|KB_TRANSLATION2_ID":
			KBTranslation2IDPickerDataUtility translation2Utility = new KBTranslation2IDPickerDataUtility();
			return translation2Utility.getDataValueInternal(paramString, paramObject, paramModelContext);
		case "IBA|KB_SURFACE":
			KBCoatingDataUtility coatingUtility = new KBCoatingDataUtility();
			return coatingUtility.getDataValueInternal(paramString, paramObject, paramModelContext);
		}

		return super.getDataValue(paramString, paramObject, paramModelContext);
	}

	private void setEditableFieldOnDataValue(String paramString, Object paramObject, Object dataValue) throws WTException {
		Persistable persistable = OidHelper.getPersistable(paramObject);
		boolean shouldBeEditable;
		if(persistable instanceof WTPart){
			shouldBeEditable = DataUtilityHelper.shouldBeEditableOnPart(persistable, paramString);
		} else {
			shouldBeEditable = DataUtilityHelper.shouldBeEditableOnDocument((WTDocument) persistable);
		}
		DataUtilityHelper.setEditableFieldOnComponent(dataValue,shouldBeEditable);
	}
}
