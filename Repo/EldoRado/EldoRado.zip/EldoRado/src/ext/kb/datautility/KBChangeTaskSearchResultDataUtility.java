package ext.kb.datautility;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.dataUtilities.AbstractAttributeDataUtility;
import com.ptc.core.components.rendering.guicomponents.TextDisplayComponent;

import ext.kb.workflow.ChangeRequestUtils;
import wt.change2.ChangeRequest2;
import wt.change2.WTChangeActivity2;
import wt.util.WTException;

public class KBChangeTaskSearchResultDataUtility extends AbstractAttributeDataUtility {
	
	private static final String ECR_NUMBER = "ECR_NUMBER";

	@Override
	public Object getDataValue(String paramString, Object paramObject,
			ModelContext paramModelContext) throws WTException {

		TextDisplayComponent component = new TextDisplayComponent(paramString);

		if (paramObject instanceof WTChangeActivity2 && ECR_NUMBER.equals(paramString)) {
			ChangeRequest2 changeRequest = ChangeRequestUtils.getChangeRequestFromChangeActivity((WTChangeActivity2) paramObject);
			if (changeRequest != null) {
				component.setValue(changeRequest.getNumber());
			}
		}

		return component;
	}

}
