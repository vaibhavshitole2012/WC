package ext.kb.datautility;


import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.dataUtilities.DefaultDataUtility;
import com.ptc.core.components.rendering.guicomponents.AttributeDisplayCompositeComponent;
import com.ptc.core.components.rendering.guicomponents.AttributeInputCompositeComponent;
import com.ptc.core.components.rendering.guicomponents.StringInputComponent;
import com.ptc.core.components.rendering.guicomponents.TextArea;
import com.ptc.core.components.util.OidHelper;
import com.ptc.core.meta.common.AttributeTypeIdentifier;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.impl.InstanceBasedAttributeTypeIdentifier;
import com.ptc.core.meta.type.common.impl.DefaultTypeInstance;

import com.ptc.generic.iba.AttributeService;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import com.ptc.swlink.adaptersAdminUI.AdapterClientUtils;
import ext.kb.util.KBType;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import wt.log4j.LogR;
import ext.kb.namecatalogue.NameCatalogueLanguage;
import ext.kb.util.KBConstants;
import ext.kb.util.KBTypeIdProvider;
import ext.kb.util.KBUtils;
import wt.fc.Persistable;
import wt.util.WTException;

import java.util.Arrays;
import java.util.List;

public class EditArticleAttributesDataUtility extends DefaultDataUtility {

	private static final Logger LOG = LogR.getLogger(EditArticleAttributesDataUtility.class.getName());
	private static final String KB_DESCRIPTION_EN = "KB_DESCRIPTION_EN";
	private static final String KB_NATIVE_LANGUAGE = "KB_NATIVE_LANGUAGE";
	private static final List<String> DESC2_ATTRIBUTES = Arrays.asList(KBConstants.DESCRIPTION2_EN, KBConstants.DESCRIPTION2_NATIVE);
	@Override
	public Object getDataValue(String paramString, Object paramObject, ModelContext paramModelContext)
			throws WTException {

        if(paramObject == null && paramString.equalsIgnoreCase("defaultUnit")){
            NmCommandBean nmCommandBean = paramModelContext.getNmCommandBean();
            String primaryOid = nmCommandBean.getPrimaryOid().toString();
            Persistable context = AdapterClientUtils.getObjectByOid( primaryOid );
            return AttributeService.getAttribute(context, paramString);
        }
		Object customValue = getDataValueInternal(paramString, paramObject, paramModelContext);
		boolean isArticle = KBTypeIdProvider.isDescendant(paramObject, KBConstants.ARTICLE_TYPE);
		boolean isEPMDoc = KBTypeIdProvider.isDescendant(paramObject, KBConstants.KB_CAD_DOCUMENT_TYPE);
		boolean isKBDocument = KBTypeIdProvider.isDescendant(paramObject, KBConstants.KB_DOCUMENT_TYPE);
		boolean isRefDoc = KBTypeIdProvider.isDescendant(paramObject, KBConstants.REFERENCE_DOCUMENT_TYPE);
		boolean isEditMode = KBUtils.isEditMode(paramModelContext.getDescriptorMode());
		boolean isCreateMode = KBUtils.isCreateMode(paramModelContext.getDescriptorMode());
		boolean isViewMode = KBUtils.isViewMode(paramModelContext.getDescriptorMode());
		boolean isSystemDoc = KBType.isDescendedFrom(paramObject, KBConstants.KBSALES_DOCUMENT) || KBType
				.isDescendedFrom(paramObject, KBConstants.KBSALES_DRAWING) || KBType
				.isDescendedFrom(paramObject, "com.ptc.KBProjectInput");

        if (DESC2_ATTRIBUTES.contains(paramString) && isViewMode && isSystemDoc) {
			AttributeDisplayCompositeComponent component = (AttributeDisplayCompositeComponent) customValue;
			component.setComponentHidden(true);
        }

		if ((isKBDocument || isRefDoc || isArticle) && isEditMode) {
			Persistable localPersistable = OidHelper.getPersistable(paramObject);
			boolean isAttributeEditable = DataUtilityHelper.shouldBeEditableOnPart(localPersistable, paramString);
			DataUtilityHelper.setEditableFieldOnComponent(customValue, isAttributeEditable);
		}

		if (KB_DESCRIPTION_EN.equals(paramString) && isViewMode) {
			AttributeDisplayCompositeComponent component = (AttributeDisplayCompositeComponent) customValue;
			if (component.getPrintableValue().length() > 45) {
				TextArea area = new TextArea();
				area.setReadOnly(true);
				area.setEditable(false);
				area.setEnabled(true);
				area.setColumnName(component.getColumnName());
				area.setLabel(component.getLabel());
				area.setValue(component.getPrintableValue());
				return area;
			} else {
				return component;
			}
		}

		if (KB_NATIVE_LANGUAGE.equals(paramString) && isCreateMode
				&& (isArticle || isEPMDoc || isKBDocument || isRefDoc)) {
			AttributeInputCompositeComponent att = (AttributeInputCompositeComponent) customValue;
			StringInputComponent comp = (StringInputComponent) att.getValueInputComponent();
			comp.setDefaultValue(NameCatalogueLanguage.getKBLanguagePreference());
		}
		return customValue;
	}

	protected Object getDataValueInternal(String paramString, Object paramObject, ModelContext paramModelContext)
			throws WTException {
		return super.getDataValueInternal(paramString, paramObject, paramModelContext, false);
	}

	protected String getValueForEdit(Object paramObject, String type, String iba) {
		try {
			DefaultTypeInstance dti = (DefaultTypeInstance) paramObject;
			TypeIdentifier typeId;
			typeId = KBTypeIdProvider.getType(type);
			AttributeTypeIdentifier attId = new InstanceBasedAttributeTypeIdentifier(iba, typeId);
			return (String) dti.get(attId);
		} catch(ClassCastException e) {
			return StringUtils.EMPTY;
		}
	}
}
