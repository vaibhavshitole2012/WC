package ext.kb.datautility;

import java.io.IOException;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import wt.org.WTOrganization;
import wt.org.WTPrincipal;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.util.WTProperties;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.dataUtilities.DefaultDataUtility;
import com.ptc.core.components.rendering.guicomponents.AttributeInputCompositeComponent;
import com.ptc.core.components.rendering.guicomponents.StringInputComponent;

import ext.kb.util.KBTypeIdProvider;
import ext.kb.util.KBUtils;

public abstract class AbstractCadDocumentDataUtility extends DefaultDataUtility{

	private String propertyToSet = null;
	private static final Logger LOG = Logger.getLogger(AbstractCadDocumentDataUtility.class);
	
	{
		WTProperties properties = null;
		try {
			properties = WTProperties.getServerProperties();
		} catch (IOException e) {
			LOG.error(String.format("%s could not be read, due to ",getPropertyNameToLoad()),e);
		}

		propertyToSet = properties.getProperty(getPropertyNameToLoad(), "");
		

	}
	
	@Override
	public Object getDataValue(String paramString, Object paramObject, ModelContext paramModelContext)
			throws WTException {
		
		Object mainComponent = super.getDataValue(paramString, paramObject, paramModelContext);
		if(StringUtils.isEmpty(propertyToSet)){
			return mainComponent;
		}
		
		boolean isCadDoc = KBTypeIdProvider.isDescendant(paramObject, "CADDOC");
		if (isCadDoc) {
		    WTPrincipal currentUser = SessionHelper.manager.getPrincipal();
		   
			WTOrganization organization = currentUser.getOrganization();
			if (KBUtils.isHVAC(organization)){
				  if(KBUtils.isCreateMode(paramModelContext.getDescriptorMode())){
					  if(!isDefaultExecutionSufficient()){
						  executeSpecific(mainComponent, propertyToSet);
					  }
					  else{
						  executeDefault(mainComponent, propertyToSet);
					  }
				  }
			}
		}
		
		return mainComponent;
	}

	protected abstract void executeSpecific(Object parentResult, String propertyToSet);
	protected abstract String getPropertyNameToLoad();	
	
	protected void executeDefault(Object parentResult, String property){
		 AttributeInputCompositeComponent component = (AttributeInputCompositeComponent) parentResult; 
		 StringInputComponent sip =(StringInputComponent) component.getValueInputComponent();
		 sip.setDefaultValue(property);
	}
	
	protected abstract boolean isDefaultExecutionSufficient();
	
}
