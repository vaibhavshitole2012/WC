package ext.kb.datautility;

import com.ptc.core.components.beans.FormDataHolder;
import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.meta.common.TypeIdentifierHelper;
import com.ptc.core.meta.common.impl.WCTypeIdentifier;
import com.ptc.core.ui.resources.ComponentMode;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import com.ptc.netmarkets.util.misc.NmContext;
import com.ptc.windchill.enterprise.change2.beans.ChangeLinkAttributeBean;
import ext.kb.util.ObjectRevisionHelper;
import org.apache.commons.collections.ExtendedProperties;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import wt.change2.WTChangeActivity2;
import wt.doc.WTDocument;
import wt.epm.EPMDocument;
import wt.fc.Persistable;
import wt.fc.WTReference;
import wt.inf.container.WTContained;
import wt.inf.container.WTContainerRef;
import wt.lifecycle.LifeCycleManaged;
import wt.lifecycle.Transition;
import wt.org.OrganizationOwned;
import wt.org.WTOrganization;
import wt.part.WTPart;
import wt.util.WTException;
import wt.util.WTProperties;

import java.util.*;

public class KBChangeTransitionHelper {
    private static final Logger LOG = Logger.getLogger(KBChangeTransitionHelper.class);

    private static final String CONFIG_KEY = "ext.kb.datautility.RestrictTransitionForType";
    private static final String PROP_PREFIX = "ext.kb.datautility";
    private static final String PROP_PREDECESSOR = "predecessorInState";
    private static final String PROP_CURRENTOBJECT = "currentObjectInState";
    private static final String PROP_KEYSEPARATOR = ".";
    private static final String PROP_VALUESEPARATOR = ",";
    private static final String WTPART = "WTPart";
    private static final String EPM_DOCUMENT = "EPMDocument";
    private static final String WTDOCUMENT = "WTDocument";
    private static String affectedTypes = null;
    private static String[] targetTypes = {WTPART, EPM_DOCUMENT, WTDOCUMENT};

    private static final HashMap<String, HashMap<String, ArrayList<String>>> predecessorValidStates = new HashMap<>();
    private static final HashMap<String, HashMap<String, ArrayList<String>>> currentObjectValidStates = new HashMap<>();


    static {
        WTProperties properties = null;
        try {
            properties = WTProperties.getServerProperties();
            affectedTypes = properties.getProperty(CONFIG_KEY, StringUtils.EMPTY);

            for (String type : affectedTypes.split(",")) {
                type = type.trim();
                for (String targetType : targetTypes) {
                    HashMap<String, ArrayList<String>> tmpMap = getValidStatesFromProperties(properties, PROP_PREFIX + PROP_KEYSEPARATOR + type + PROP_KEYSEPARATOR + targetType + PROP_KEYSEPARATOR + PROP_PREDECESSOR);
                    if (!tmpMap.isEmpty()) {
                        predecessorValidStates.put(type + targetType, tmpMap);
                    }
                    tmpMap = getValidStatesFromProperties(properties, PROP_PREFIX + PROP_KEYSEPARATOR + type + PROP_KEYSEPARATOR + targetType + PROP_KEYSEPARATOR + PROP_CURRENTOBJECT);
                    if (!tmpMap.isEmpty()) {
                        currentObjectValidStates.put(type + targetType, tmpMap);
                    }
                }
            }
        } catch (Exception e) {
            LOG.error(String.format("%s could not be read, due to ", CONFIG_KEY), e);
        }
    }

    public static void updateObjectTransitions(ChangeLinkAttributeBean linkBean) throws WTException {
        Map<WTReference, List<Transition>> transitionMap = linkBean.getTransitionMap();

        if (ComponentMode.CREATE.equals(linkBean.getMode()) || ComponentMode.EDIT.equals(linkBean.getMode())) {
            for (Object reference : transitionMap.keySet()) {
                Persistable targetObject = ((WTReference) reference).getObject();
                filterTransitions(transitionMap.get(reference), targetObject, linkBean);
            }
            linkBean.addObjectTransitions(transitionMap);
        }
    }

    /**
     * Checks if the given transition is valid
     * @param transition
     * @param targetObject
     * @param linkBean
     * @return
     * @throws WTException
     */
    public static boolean isValidTransition(Transition transition, Persistable targetObject, ChangeLinkAttributeBean linkBean) throws WTException {
        if (transition == null) {
            return true;
        }
        Object predecessor = ObjectRevisionHelper.getPreviousVersionLatestIteration(targetObject);
        List<String> targetStatesForPredecessor = getTargetStatesFromProperties((Persistable) predecessor, linkBean, predecessorValidStates);
        List<String> targetStatesForCurrentObject = getTargetStatesFromProperties(targetObject, linkBean, currentObjectValidStates);
        //return true if there is no defined property for the given target object
        if (targetStatesForCurrentObject == null && targetStatesForPredecessor == null) {
            return true;
        }
        //check both collections if they allow the given transition
        if (targetStatesForPredecessor != null && !targetStatesForPredecessor.contains(transition.toString())
                || targetStatesForCurrentObject != null && !targetStatesForCurrentObject.contains(transition.toString())) {
            return false;
        }
        return true;
    }

    /**
     * Removes invalid transitions. The transition is valid only when both collections (transitions for predecessor and transitions for current object)
     * contain the given transition
     * @param transitionList
     * @param targetObject
     * @param linkBean
     * @throws WTException
     */
    public static void filterTransitions(List<Transition> transitionList, Persistable targetObject, ChangeLinkAttributeBean linkBean) throws WTException {
        Object predecessor = ObjectRevisionHelper.getPreviousVersionLatestIteration(targetObject);
        List<String> targetStatesForPredecessor = getTargetStatesFromProperties((Persistable) predecessor, linkBean, predecessorValidStates);
        if (LOG.isDebugEnabled()) {
            LOG.debug("Matching predecessor states for " + getIdentity(predecessor) + "(target object: " + getIdentity(targetObject) + "): " + targetStatesForPredecessor);
        }
        List<String> targetStatesForCurrentObject = getTargetStatesFromProperties(targetObject, linkBean, currentObjectValidStates);
        if (LOG.isDebugEnabled()) {
            LOG.debug("Matching current object states for " + getIdentity(targetObject) + ": " + targetStatesForCurrentObject);
        }
        if (targetStatesForPredecessor == null && targetStatesForCurrentObject == null) {
            LOG.debug("No properties defined for object predecessor's state and for current object's state");
            //no properties defined so no filtering required
            return;
        }
        List<Transition> transitionListCopy = new ArrayList<>(transitionList);
        for (Transition transition : transitionListCopy) {
            if (targetStatesForPredecessor != null && !targetStatesForPredecessor.contains(transition.toString())
                    || targetStatesForCurrentObject != null && !targetStatesForCurrentObject.contains(transition.toString())) {
                transitionList.remove(transition);
            }
        }
    }

    private static List<String> getTargetStatesFromProperties(Persistable targetObject, ChangeLinkAttributeBean linkBean,
                                                              HashMap<String, HashMap<String, ArrayList<String>>> validTargetStatesMap) {
        //get the key (based on the task and resulting object type)
        WCTypeIdentifier currentChangeTaskType = null;
        FormDataHolder formData = linkBean.getFormData();
        if (formData instanceof NmCommandBean) {
            //from the data utility class
            NmCommandBean cb =  (NmCommandBean) formData;
            if (linkBean.getMode().equals(ComponentMode.EDIT)) {
                Object typeContextObject = cb.getRequestAttribute("typeContextObject");
                if(typeContextObject instanceof String){
                    currentChangeTaskType = getEctTypeIdentifier(cb);
                }else{
                    WTChangeActivity2 ca = (WTChangeActivity2) cb.getRequestAttribute("typeContextObject");
                    currentChangeTaskType = (WCTypeIdentifier) TypeIdentifierHelper.getType(ca);
                }
            }
            if (linkBean.getMode().equals(ComponentMode.CREATE)) {
                currentChangeTaskType = (WCTypeIdentifier) cb.getRequestAttribute("typeContextObject");
            }
            LOG.debug("Getting current change task type from NmCommandBean: " + currentChangeTaskType);
        } else if (formData instanceof ObjectBean) {
            //from the form delegate class
            Object object = ((ObjectBean) formData).getObject();
            if (object instanceof WTChangeActivity2) {
                currentChangeTaskType = (WCTypeIdentifier) TypeIdentifierHelper.getType(object);
            }
            LOG.debug("Getting current change task type from ObjectBean: " + currentChangeTaskType);
        }
        if (currentChangeTaskType == null) {
            LOG.debug("Change task type identifier was null");
            return null;
        }
        if (targetObject != null && currentChangeTaskType != null) {
            String targetType = getTargetType(targetObject);
            String typeNameWithTargetType = currentChangeTaskType.getLeafName() + targetType;
            if (LOG.isDebugEnabled()) {
                LOG.debug("Checking states for " + getIdentity(targetObject) + "Key: " + typeNameWithTargetType);
            }
            //check if there are properties defined for the given key
            if (validTargetStatesMap.containsKey(typeNameWithTargetType)) {
                HashMap<String, ArrayList<String>> validStates = validTargetStatesMap.get(typeNameWithTargetType);
                //check if there are properties defined for the given state
                String lifeCycleState = getLifeCycleState(targetObject);
                WTOrganization organization = getOrganization(targetObject);
                if (LOG.isDebugEnabled()) {
                    LOG.debug("Checking states for " + getIdentity(targetObject) + "State: " + lifeCycleState + ", Organization: " + organization != null ? organization.getName() : "-");
                }
                //check first if there are organisation-based properties
                if (organization != null && validStates.containsKey(lifeCycleState + PROP_KEYSEPARATOR + organization.getName())) {
                    return validStates.get(lifeCycleState + PROP_KEYSEPARATOR + organization.getName());
                } else if (validStates.containsKey(lifeCycleState)) {
                    return validStates.get(lifeCycleState);
                }
            }
        }
        //return null if there is no defined property for the given key and state
        return null;
    }

    private static WCTypeIdentifier getEctTypeIdentifier(NmCommandBean cb){
        WCTypeIdentifier currentChangeTaskType = null;
        try {
            Set<NmContext> selectedECT = new HashSet<>();
            CollectionUtils.addAll(selectedECT, cb.getSelected());
            NmContext context = selectedECT.iterator().next();
            NmOid targetOid = context.getTargetOid();
            Persistable object = targetOid.getWtRef().getObject();
            if (object instanceof WTChangeActivity2) {
                currentChangeTaskType = (WCTypeIdentifier) TypeIdentifierHelper.getType(object);
            }
        } catch (Exception ex) {
            LOG.error("Error in getEctTypeIdentifier " + ex);
            ex.printStackTrace();
        }
        return currentChangeTaskType;
    }

    private static HashMap<String, ArrayList<String>> getValidStatesFromProperties(WTProperties properties, String property) {
        HashMap<String, ArrayList<String>> result = new HashMap<>();

        Iterator<String> it = getProperties(properties, property);
        while (it != null && it.hasNext()) {
            String allowedTargetStatesKey = it.next();

            String allowedTargetStatesValue = properties.getProperty(allowedTargetStatesKey);
            allowedTargetStatesKey = allowedTargetStatesKey.replace(property + PROP_KEYSEPARATOR, "");
            String[] tokenizer = allowedTargetStatesKey.split("\\" + PROP_KEYSEPARATOR);
            String definedState = tokenizer[0];
            // check if this is organization-based property
            if (tokenizer.length > 2) {
                definedState += PROP_KEYSEPARATOR + tokenizer[2];
            }

            String[] targetStatesArray = allowedTargetStatesValue.split(PROP_VALUESEPARATOR);
            ArrayList<String> targetStatesList = new ArrayList<>();
            if (!StringUtils.isEmpty(allowedTargetStatesValue)) {
                for (int i = 0; i < targetStatesArray.length; i++) {
                    targetStatesList.add(targetStatesArray[i].trim());
                }
            }
            result.put(definedState.trim(), targetStatesList);
        }
        return result;
    }

    @SuppressWarnings("unchecked")
    private static Iterator<String> getProperties(WTProperties serverProps, String property) {
        ExtendedProperties extendedProps = ExtendedProperties.convertProperties(serverProps);
        return extendedProps.getKeys(property);
    }


    private static String getLifeCycleState(Object paramObject) {
        String lifeCycleState = "";
        if (paramObject instanceof LifeCycleManaged) {
            LifeCycleManaged lcManaged = (LifeCycleManaged) paramObject;
            lifeCycleState = lcManaged.getLifeCycleState().toString();
        }
        return lifeCycleState;
    }

    private static String getLifeCycleName(Object paramObject) {
        String lifeCycleName = "";
        if (paramObject instanceof LifeCycleManaged) {
            LifeCycleManaged lcManaged = (LifeCycleManaged) paramObject;
            lifeCycleName = lcManaged.getLifeCycleName();
        }
        return lifeCycleName;
    }

    private static String getIdentity(Object paramObject) {
        String identity = "";
        if (paramObject instanceof WTPart) {
            identity = ((WTPart) paramObject).getIdentity();
        } else if (paramObject instanceof EPMDocument) {
            identity = ((EPMDocument) paramObject).getIdentity();
        }
        return identity;
    }

    private static WTContainerRef getContainerReference(Object paramObject) {
        WTContainerRef wtRef = null;
        if (paramObject instanceof WTContained) {
            wtRef = ((WTContained) paramObject).getContainerReference();
        }
        return wtRef;
    }

    private static String getTargetType(Object paramObject) {
        if (paramObject instanceof WTPart) {
            return WTPART;
        } else if (paramObject instanceof EPMDocument) {
            return EPM_DOCUMENT;
        } else if (paramObject instanceof WTDocument) {
            return WTDOCUMENT;
        } else {
            return "";
        }
    }

    private static WTOrganization getOrganization(Object paramObject) {
        if (paramObject instanceof OrganizationOwned) {
            return ((OrganizationOwned) paramObject).getOrganization();
        } else {
            return null;
        }
    }
}
