package ext.kb.datautility;

import wt.util.WTException;

import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.dataUtilities.DefaultDataUtility;
import com.ptc.core.components.rendering.guicomponents.AttributeInputCompositeComponent;
import com.ptc.core.components.rendering.guicomponents.StringInputComponent;
import com.ptc.core.meta.common.AttributeIdentifier;
import com.ptc.core.meta.type.common.TypeInstance;

public class ArticleCategoryDataUtility extends EditArticleAttributesDataUtility {
	
	@Override
	public Object getDataValueInternal(String componentId, Object datum, ModelContext modelContext) throws WTException {
		DefaultDataUtility defaultDataUtility = new DefaultDataUtility();
		Object object = defaultDataUtility.getDataValue(componentId, datum, modelContext);

		if (object instanceof AttributeInputCompositeComponent && datum instanceof TypeInstance) {
			TypeInstance typeInstance = (TypeInstance) datum;
			AttributeInputCompositeComponent attributeInputCompositeComponent = (AttributeInputCompositeComponent) object;
			StringInputComponent attributeInputComponent = (StringInputComponent) attributeInputCompositeComponent.getValueInputComponent();

			AttributeIdentifier[] ai = typeInstance.getAttributeIdentifiers("docType");

			String category = null;
			for (int i = 0; i < ai.length; i++) {
				AttributeIdentifier a = ai[i];

				Object value = typeInstance.get(a);

				if (value instanceof String)
					category = (String) value;
			}
			
			if (category != null) {
				if (category.equals("CADASSEMBLY"))
					attributeInputComponent.setDefaultValue("1");
				else if (category.equals("CADCOMPONENT"))
					attributeInputComponent.setDefaultValue("3");
			}
		}

		return object;
	}
}
