package ext.kb.autoassociate;

import com.ptc.core.meta.server.TypeIdentifierUtility;
import com.ptc.generic.iba.AttributeService;
import com.ptc.windchill.uwgm.common.associate.AssociatePartDescriptor;
import com.ptc.windchill.uwgm.common.autoassociate.AutoAssociateHelper;
import com.ptc.windchill.uwgm.common.autoassociate.DefaultAutoAssociatePartFinderCreator;
import com.ptc.windchill.uwgm.common.query.QueryHelper;
import ext.kb.resources.AutoAssociateRB;
import ext.kb.util.IBAHelper;
import ext.kb.util.KBConstants;
import ext.kb.util.KBTypeIdProvider;
import ext.kb.util.KBUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import wt.epm.EPMDocument;
import wt.epm.EPMDocumentMaster;
import wt.epm.EPMDocumentType;
import wt.epm.modelitems.ModelItem;
import wt.epm.workspaces.EPMWorkspace;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.inf.container.WTContainerRef;
import wt.log4j.LogR;
import wt.org.WTUser;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.pds.StatementSpec;
import wt.preference.PreferenceClient;
import wt.preference.PreferenceHelper;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.query.WhereExpression;
import wt.session.SessionHelper;
import wt.type.Typed;
import wt.type.TypedUtilityServiceHelper;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.WTProperties;
import wt.util.WTPropertyVetoException;
import wt.vc.VersionControlHelper;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

public class KBAutoAssociatePartFinderCreator extends DefaultAutoAssociatePartFinderCreator {

	private static final Logger LOG = LogR.getLogger(KBAutoAssociatePartFinderCreator.class.getName());
	private static final String ASSEMBLIES_AND_COMPONENTS = "com.ptc.KBAssemblyComponent";
	private static final String STANDARD_PART = "com.ptc.KBStandardPart";
	private static final String KBRAW_PART = "com.ptc.KBRaw";
	private static final String KBKITBOM_PART = "com.ptc.KBKitBOM";
	public static final ArrayList<String> PART_CATEGORY_AUTO_ASSOCIATE_ASSEMBLY;
	public static final ArrayList<String> PART_CATEGORY_AUTO_ASSOCIATE_STANDARD;
	public static final ArrayList<String> PART_CATEGORY_AUTO_ASSOCIATE_KBRAW;
	public static final ArrayList<String> PART_CATEGORY_AUTO_ASSOCIATE_KBKITBOM;
	private static final HashMap<String, String> ATTRIBUTES_TO_COPY_FROM_CAD;
	private static final String RESOURCE = "ext.kb.resources.AutoAssociateRB";
	private static final String DOT = ".";
	private static final String KB_SAP_IDX = "KB_SAP_IDX";
	private static final String KB_ARTICLE_NUM = "KB_ARTICLE_NUM";
	private static final String DESIGN_VIEW = "Design";

	static {
		try {
			PART_CATEGORY_AUTO_ASSOCIATE_ASSEMBLY = new ArrayList<String>();
			PART_CATEGORY_AUTO_ASSOCIATE_STANDARD = new ArrayList<String>();
			PART_CATEGORY_AUTO_ASSOCIATE_KBRAW = new ArrayList<String>();
			PART_CATEGORY_AUTO_ASSOCIATE_KBKITBOM=new ArrayList<String>();
			ATTRIBUTES_TO_COPY_FROM_CAD = new HashMap<>();

			String partCategoryAutoAssociateAssembliesPropertyName = "ext.kb.part.category.autoassociate.assemblies";
			String partCategoryAutoAssociateStandardsPropertyName = "ext.kb.part.category.autoassociate.standards";
			String partCategoryAutoAssociateKBRawsPropertyName = "ext.kb.part.category.autoassociate.kbraws";
			String partCategoryAutoAssociateKBkitbomPropertyName = "ext.kb.part.category.autoassociate.kbkitbom";
			String partAttributesToCopyFormCadPropertyName = "ext.kb.autoassociate.part.attributes.to.copy.from.cad";
			WTProperties wp = WTProperties.getLocalProperties();
			String partCategoryAutoAssociateAssemblies = wp
					.getProperty(partCategoryAutoAssociateAssembliesPropertyName);
			String partCategoryAutoAssociateStandards = wp.getProperty(partCategoryAutoAssociateStandardsPropertyName);
			String partCategoryAutoAssociateKBRaws = wp.getProperty(partCategoryAutoAssociateKBRawsPropertyName);
			String partCategoryAutoAssociateKBkitbom=wp.getProperty(partCategoryAutoAssociateKBkitbomPropertyName);

			String partAttributesToCopyFormCad = wp.getProperty(partAttributesToCopyFormCadPropertyName);

			for (String value : partCategoryAutoAssociateAssemblies.split(",")) {
				PART_CATEGORY_AUTO_ASSOCIATE_ASSEMBLY.add(value);
			}
			for (String value : partCategoryAutoAssociateStandards.split(",")) {
				PART_CATEGORY_AUTO_ASSOCIATE_STANDARD.add(value);
			}
			for (String value : partCategoryAutoAssociateKBRaws.split(",")) {
				PART_CATEGORY_AUTO_ASSOCIATE_KBRAW.add(value);
			}
			for (String value : partCategoryAutoAssociateKBkitbom.split(",")) {
				PART_CATEGORY_AUTO_ASSOCIATE_KBKITBOM.add(value);
			}
			for (String attribute : partAttributesToCopyFormCad.split(",")) {
				if (attribute.contains("=")) {
					String[] attribiuteMap = attribute.split("=");
					ATTRIBUTES_TO_COPY_FROM_CAD.put(attribiuteMap[0], attribiuteMap[1]);
				} else {
					ATTRIBUTES_TO_COPY_FROM_CAD.put(attribute, attribute);
				}
			}
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	private List<String> validPartCategoryValues = null;
	{
		validPartCategoryValues = new ArrayList<>();
		validPartCategoryValues.addAll(PART_CATEGORY_AUTO_ASSOCIATE_ASSEMBLY);
		validPartCategoryValues.addAll(PART_CATEGORY_AUTO_ASSOCIATE_STANDARD);
		validPartCategoryValues.addAll(PART_CATEGORY_AUTO_ASSOCIATE_KBRAW);
		validPartCategoryValues.addAll(PART_CATEGORY_AUTO_ASSOCIATE_KBKITBOM);
	}

	public WTPart findOrCreateWTPart(EPMDocument document, EPMWorkspace workspace)
			throws WTException, WTPropertyVetoException {
		if (LOG.isDebugEnabled()) {
			LOG.debug("entering findOrCreateWTPart(EPMDocument,EPMWorkspace)");
			LOG.debug("document: " + document);
			LOG.debug("workspace: " + workspace);
		}
		if (isUnassociatedDrawingOrPhantomCadPart(document) == false) {
			String partNumberToSearch = IBAHelper.getStringIBAValue(document, KB_ARTICLE_NUM);
			if (KBUtils.isEmpty(partNumberToSearch)) {
				partNumberToSearch = document.getNumber();
				boolean isNumberEndinWithExtension = endsWithExtension(partNumberToSearch);
				if (isNumberEndinWithExtension) {
					int index = partNumberToSearch.lastIndexOf(DOT);
					if (index > 0) {
						partNumberToSearch = partNumberToSearch.replace(partNumberToSearch.substring(index), "");
					}
				}
				String kbSapIdx = IBAHelper.getStringIBAValue(document, KB_SAP_IDX);
				String suffix = "-" + kbSapIdx;
				int index = partNumberToSearch.lastIndexOf(suffix);
				if (index > 0) {
					partNumberToSearch = partNumberToSearch.replace(partNumberToSearch.substring(index), "");
				}
			} else if (DOT.equals(partNumberToSearch)) {
				partNumberToSearch = document.getNumber();
				boolean isNumberEndinWithExtension = endsWithExtension(partNumberToSearch);
				if (isNumberEndinWithExtension) {
					int index = partNumberToSearch.lastIndexOf(DOT);
					if (index > 0) {
						partNumberToSearch = partNumberToSearch.replace(partNumberToSearch.substring(index), "");
					}
				}
				String kbSapIdx = IBAHelper.getStringIBAValue(document, KB_SAP_IDX);
				String suffix = "-" + kbSapIdx;
				int index = partNumberToSearch.lastIndexOf(suffix);
				if (index > 0) {
					partNumberToSearch = partNumberToSearch.replace(partNumberToSearch.substring(index), "");
				}
			}
			try {
				String articleNum = IBAHelper.getStringIBAValue(document, KB_ARTICLE_NUM);
				if(KBUtils.isEmpty(articleNum) || DOT.equals(articleNum)){
					IBAHelper.updateIBAAttributeValueWithoutCheckout(document, KB_ARTICLE_NUM, partNumberToSearch);
				}
			} catch (RemoteException | ClassNotFoundException e) {
				throw new WTException(e);
			}
			WTPart p = searchArticle(partNumberToSearch, document, workspace);
			if (LOG.isDebugEnabled()) {
				LOG.debug(p != null ? "type of p:" + TypeIdentifierUtility.getTypeIdentifier(p).getTypename() : "null");
				LOG.debug("exiting findOrCreateWTPart()");
				LOG.debug("returning: " + p);
			}
			if (p != null) {
				copyAttributes(p, document);
			}
			return p;
		} else {
			if (LOG.isDebugEnabled()) {
				LOG.debug("findOrCreateWTPart return null " + document.getNumber());
				LOG.debug("exiting findOrCreateWTPart()");
				LOG.debug("returning: " + null);
			}
			return null;
		}
	}

	private boolean endsWithExtension(String partNumberToSearch) {
		if (LOG.isDebugEnabled()) {
			LOG.debug("entering endsWithExtension(String)");
			LOG.debug("partNumberToSearch: \"" + partNumberToSearch + "\"");
			LOG.debug("exiting endsWithExtension()");
		}
		return partNumberToSearch.endsWith(KBConstants.CAD_ASSEMBLY_EXTENSION)
				|| partNumberToSearch.endsWith(KBConstants.CAD_ASSEMBLY_EXTENSION.toLowerCase())
				|| partNumberToSearch.endsWith(KBConstants.CAD_DRAWING_EXTENSION)
				|| partNumberToSearch.endsWith(KBConstants.CAD_DRAWING_EXTENSION.toLowerCase())
				|| partNumberToSearch.endsWith(KBConstants.CAD_PART_EXTENSION)
				|| partNumberToSearch.endsWith(KBConstants.CAD_PART_EXTENSION.toLowerCase());
	}

	public WTPart findOrCreateWTPart(EPMDocument document, ModelItem modelItem, EPMWorkspace workspace)
			throws WTException, WTPropertyVetoException {
		if (LOG.isDebugEnabled()) {
			LOG.debug("entering findOrCreateWTPart(EPMDocument,ModelItem,EPMWorkspace)");
			LOG.debug("document: " + document);
			LOG.debug("modelItem: " + modelItem);
			LOG.debug("workspace: " + workspace);
		}
		if (isUnassociatedDrawingOrPhantomCadPart(document) == false) {
			if (LOG.isDebugEnabled()) {
				LOG.debug("findOrCreateWTPart with modelItem" + document.getNumber());
			}
			String partNumberToSearch = IBAHelper.getStringIBAValue(document, KB_ARTICLE_NUM);
			if (KBUtils.isEmpty(partNumberToSearch)) {
				final String [] partNumbers = AutoAssociateHelper.getPartNumberToSearch(workspace, document, modelItem);
				if (partNumbers == null || partNumbers.length == 0){ 
					partNumberToSearch = null;
				}
				else{
					partNumberToSearch = partNumbers[0];
				}
				boolean isNumberEndinWithExtension = endsWithExtension(partNumberToSearch);
				if (isNumberEndinWithExtension) {
					int index = partNumberToSearch.lastIndexOf(DOT);
					if (index > 0) {
						partNumberToSearch = partNumberToSearch.replace(partNumberToSearch.substring(index), "");
					}
				}
				String kbSapIdx = IBAHelper.getStringIBAValue(document, KB_SAP_IDX);
				String suffix = "-" + kbSapIdx;
				int index = partNumberToSearch.lastIndexOf(suffix);
				if (index > 0) {
					partNumberToSearch = partNumberToSearch.replace(partNumberToSearch.substring(index), "");
				}
			} else if (DOT.equals(partNumberToSearch)) {
				final String [] partNumbers = AutoAssociateHelper.getPartNumberToSearch(workspace, document, modelItem);
				if (partNumbers == null || partNumbers.length == 0) {
					partNumberToSearch = null; 
				}
				else{
					partNumberToSearch = partNumbers[0];
				}
				boolean isNumberEndinWithExtension = endsWithExtension(partNumberToSearch);
				if (isNumberEndinWithExtension) {
					int index = partNumberToSearch.lastIndexOf(DOT);
					if (index > 0) {
						partNumberToSearch = partNumberToSearch.replace(partNumberToSearch.substring(index), "");
					}
				}
				String kbSapIdx = IBAHelper.getStringIBAValue(document, KB_SAP_IDX);
				String suffix = "-" + kbSapIdx;
				int index = partNumberToSearch.lastIndexOf(suffix);
				if (index > 0) {
					partNumberToSearch = partNumberToSearch.replace(partNumberToSearch.substring(index), "");
				}
			}
			WTPart p = searchArticle(partNumberToSearch, modelItem, workspace);
			if (LOG.isDebugEnabled()) {
				LOG.debug(p != null ? "type of p:" + TypeIdentifierUtility.getTypeIdentifier(p).getTypename() : "null");
				LOG.debug("exiting findOrCreateWTPart()");
				LOG.debug("returning: " + p);
			}
			if (p != null) {
				copyAttributes(p, document);
			}
			return p;
		} else {
			if (LOG.isDebugEnabled()) {
				LOG.debug("findOrCreateWTPart with modelItem return null " + document.getNumber());
				LOG.debug("exiting findOrCreateWTPart()");
				LOG.debug("returning: " + null);
			}
			return null;
		}
	}

	private void copyAttributes(WTPart wtPart, EPMDocument epmDocument) {
		if (LOG.isDebugEnabled()) {
			LOG.debug("entering copyAttributes(WTPart,EPMDocument)");
			LOG.debug("wtPart: " + wtPart);
			LOG.debug("epmDocument: " + epmDocument);
		}
		Set<Entry<String, String>> entrySet = ATTRIBUTES_TO_COPY_FROM_CAD.entrySet();
		for (Entry<String, String> entry : entrySet) {
			if (LOG.isDebugEnabled()) {
				LOG.debug("value: " + entry.getValue());
				LOG.debug("key: " + entry.getKey());
			}
			String partValue = IBAHelper.readIBA(wtPart, entry.getValue());
			String epmValue = IBAHelper.readIBA(epmDocument, entry.getKey());
			if (!KBUtils.isEmpty(partValue)) {
				continue;
			}
			if (!KBUtils.isEmpty(epmValue)) {
				try {
					IBAHelper.setIba(wtPart, entry.getValue(), epmValue);
				} catch (RemoteException | WTException e) {
					e.printStackTrace();
				} catch (WTPropertyVetoException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		if (LOG.isDebugEnabled()) {
			LOG.debug("exiting copyAttributes()");
		}

	}

	private WTPart searchArticle(String partNumber, Persistable paramPersistable, EPMWorkspace epmWorkspace)
			throws WTException {
		if (LOG.isDebugEnabled()) {
			LOG.debug("entering searchArticle(String,Persistable,EPMWorkspace)");
			LOG.debug("partNumber: \"" + partNumber + "\"");
			LOG.debug("paramPersistable: " + paramPersistable);
			LOG.debug("epmWorkspace: " + epmWorkspace);
		}
		QuerySpec qs = new QuerySpec(WTPartMaster.class);
		String[] arrayOfString = { partNumber };
		SearchCondition localSearchCondition = QueryHelper.getSearchConditionByName(WTPartMaster.class, "number",
				arrayOfString);
		qs.appendWhere(localSearchCondition, new int[] { 0 });

		WhereExpression localWhereExpression = QueryHelper.getWhereExpressionNotInProjects(WTPartMaster.class,
				epmWorkspace.getContainer());
		if (localWhereExpression != null) {
			qs.appendAnd();
			qs.appendWhere(localWhereExpression, new int[] { 0, 0 });
		}
		QueryResult qr = PersistenceHelper.manager.find((StatementSpec) qs);
		while (qr.hasMoreElements()) {
			WTPartMaster wtPartMaster = (WTPartMaster) qr.nextElement();
			QueryResult result = VersionControlHelper.service.allIterationsOf(wtPartMaster);
			while (result.hasMoreElements()) {
				WTPart wtPart = (WTPart) result.nextElement();
				boolean isEbomPart = KBUtils.isEbomPart(wtPart);
				if (KBTypeIdProvider.isDescendant(wtPart, "ARTICLE") && isEbomPart) {
					LOG.info("ARTICLE FOUND.  Part Name: " + wtPart.getName() + " Part Number: " + wtPart.getNumber());
					if (LOG.isDebugEnabled()) {
						LOG.debug("exiting searchArticle()");
						LOG.debug("returning: " + wtPart);
					}
					return wtPart;
				}
			}
		}
		if (LOG.isDebugEnabled()) {
			LOG.debug("exiting searchArticle()");
			LOG.debug("returning: " + null);
		}
		return null;
	}

	private boolean isUnassociatedDrawingOrPhantomCadPart(EPMDocument document) throws WTException {
		if (LOG.isDebugEnabled()) {
			LOG.debug("isUnassociatedDrawingOrPhantomCadPart" + document.getNumber());
		}
		if (isDrawing(document)) {
			QueryResult connected3DParts = KBUtils.navigateEPMReferenceLinkGetCadParts(document);

			if (connected3DParts.size() == 0){
				return true;
			}
			else {
				EPMDocumentMaster connected3DPartMaster = (EPMDocumentMaster) connected3DParts.nextElement();

				Persistable connected3DPart = KBUtils.getLatestIteration(connected3DPartMaster);
				if (LOG.isDebugEnabled()) {

					LOG.debug("Retrieved 3D Cad Object for Tech drawing is:" + connected3DPart);
				}

				if (connected3DPart != null) {
					Boolean kbPhantom = ext.kb.util.IBAHelper.readIBA(connected3DPart, KBConstants.KB_PHANTOM_IBA);

					if (kbPhantom != null && kbPhantom.equals(Boolean.TRUE)) {
						return true;
					}
				}
			}
		}

		return false;
	}

	

	@Override
	public WTPart createNewWTPart(AssociatePartDescriptor associatepartdescriptor)
			throws WTException, WTPropertyVetoException {
		EPMDocument doc = associatepartdescriptor.getSourceDoc();
		if (LOG.isDebugEnabled()) {
			LOG.debug("entering createNewWTPart(AssociatePartDescriptor)");
			LOG.debug("associatepartdescriptor: " + associatepartdescriptor);
			LOG.debug("Part number: " + associatepartdescriptor.getPartNumber());
			if (doc != null) {
				LOG.debug("EPM number: " + associatepartdescriptor.getSourceDoc().getNumber());
			}
		}
		EPMDocument document = associatepartdescriptor.getSourceDoc();
		String partNumber = associatepartdescriptor.getPartNumber();
		KBUtils.checkNumberForInvalidCharactersForAssociation(partNumber);
		if (LOG.isDebugEnabled()) {
			LOG.debug("createNewWTPart:");
		}
		WTPart newPart = null;
		if (isUnassociatedDrawingOrPhantomCadPart(document) == false) {
			if (LOG.isDebugEnabled()) {
				LOG.debug("isUnassociatedDrawingOrPhantomCadPart(document) == false");
			}
			String attribute = IBAHelper.readIBA(document, KBConstants.KB_PART_CATEGORY_IBA);
			newPart = super.createNewWTPart(associatepartdescriptor);

			String descriptionDyn1 = AttributeService.getAttribute(document, KBConstants.TRANSLATION_ID_IBA);
			String descriptionDyn2 = AttributeService.getAttribute(document, KBConstants.TRANSLATION2_ID_IBA);
			String supplementaryText = AttributeService.getAttribute(document, KBConstants.KB_SUPPL_TEXT_IBA);
			try {
				newPart = (WTPart) IBAHelper.setStringIBAValue(newPart, KBConstants.TRANSLATION_ID_IBA,
						descriptionDyn1);
				if (!KBUtils.isEmpty(descriptionDyn2)) {
					newPart = (WTPart) IBAHelper.setStringIBAValue(newPart, KBConstants.TRANSLATION2_ID_IBA,
							descriptionDyn2);
				}
				if (!KBUtils.isEmpty(supplementaryText)) {
					newPart = (WTPart) IBAHelper.setStringIBAValue(newPart, KBConstants.KB_SUPPL_TEXT_IBA,
							supplementaryText);
				}
			} catch (RemoteException e) {
				LOG.error("Unable to set IBA", e);
			}
			if (PART_CATEGORY_AUTO_ASSOCIATE_ASSEMBLY.contains(attribute)) {
				newPart = setSofttype(newPart, ASSEMBLIES_AND_COMPONENTS);
			} else if (PART_CATEGORY_AUTO_ASSOCIATE_STANDARD.contains(attribute)) {
				newPart = setSofttype(newPart, STANDARD_PART);
			} else if (PART_CATEGORY_AUTO_ASSOCIATE_KBRAW.contains(attribute)) {
				newPart = setSofttype(newPart, KBRAW_PART);
			} else if(PART_CATEGORY_AUTO_ASSOCIATE_KBKITBOM.contains(attribute)){
				newPart = setSofttype(newPart, KBKITBOM_PART);
				
			}else {
				throw new WTException(RESOURCE, AutoAssociateRB.INVALID_PART_CATEGORY2,
						new Object[] { document.getNumber(), StringUtils.join(validPartCategoryValues, ',') });
			}
			validateWTPartCreation(document);
			newPart = setAttributes(newPart);
		} else {
			if (LOG.isDebugEnabled()) {
				LOG.debug("NOT in HVAC");
			}
			newPart = super.createNewWTPart(associatepartdescriptor);
			String descriptionDyn1 = AttributeService.getAttribute(document, KBConstants.TRANSLATION_ID_IBA);
			String descriptionDyn2 = AttributeService.getAttribute(document, KBConstants.TRANSLATION2_ID_IBA);

			try {
			    if (!KBUtils.isEmpty(descriptionDyn1)) {
                    IBAHelper.setStringIBAValue(newPart, KBConstants.TRANSLATION_ID_IBA, descriptionDyn1);
                }
				if (!KBUtils.isEmpty(descriptionDyn2)) {
					IBAHelper.setStringIBAValue(newPart, KBConstants.TRANSLATION2_ID_IBA, descriptionDyn2);
				}
			} catch (RemoteException e) {
				LOG.error("Unable to set IBA", e);
			}
		}

		if (LOG.isDebugEnabled()) {
			LOG.debug("returning: "
					+ (newPart != null ? TypeIdentifierUtility.getTypeIdentifier(newPart).getTypename() : "null"));
			LOG.debug("returning number: " + newPart != null ? newPart.getNumber() : "null");

		}
		// Remove extension from part number
		String pNumber = newPart != null ? newPart.getNumber() : "";
		if (KBUtils.isEmpty(pNumber) || DOT.equals(pNumber)) {
			pNumber = document.getNumber();
			newPart.setNumber(pNumber);
		}
		boolean isNumberEndingWithExtension = endsWithExtension(pNumber);
		if (isNumberEndingWithExtension) {
			int indedOf = pNumber.lastIndexOf('.');
			if (indedOf > 0) {
				pNumber = pNumber.substring(0, indedOf);
				newPart.setNumber(pNumber);
				LOG.debug("returning number after change: " + newPart.getNumber());
			}
		}
		KBUtils.checkPartNumberLength(pNumber);
		if (LOG.isDebugEnabled()) {
			LOG.debug("exiting createNewWTPart()");
			LOG.debug("returning: " + newPart);
		}
		if(!("".equalsIgnoreCase(newPart.getViewName()) || DESIGN_VIEW.equalsIgnoreCase(newPart.getViewName()) )) {
			throw new WTException(AutoAssociateRB.INVALID_PART_VIEW);
		}
		WTUser user = (WTUser) SessionHelper.getPrincipal();
		WTContainerRef containerRef = WTContainerRef.newWTContainerRef(newPart.getContainerReference());
		String pref = (String) PreferenceHelper.service.getValue(containerRef, KBConstants.CONTAINER_PREFERENCE_DESIGN_PART_VIEW,
				PreferenceClient.WINDCHILL_CLIENT_NAME, user);
		if(LOG.isDebugEnabled()){
			LOG.debug("pref "+pref);
		}
		if(null != pref &&("" == pref || !pref.equalsIgnoreCase(DESIGN_VIEW))){
			throw new WTException(AutoAssociateRB.INVALID_PART_LOCATION);
		}
		copyAttributes(newPart, doc);
		return newPart;

	}

	/**
	 * Sets soft type attribute for newly created part.
	 *
	 * @param wtPart
	 *            part for which soft type attribute is set
	 * @param softtypeName
	 *            name of softtype
	 * @return the wT part
	 * @throws WTException
	 *             the wT exception
	 */
	private WTPart setSofttype(WTPart wtPart, String softtypeName) throws WTException {
		if (LOG.isDebugEnabled()) {
			LOG.debug("entering setSofttype(WTPart,String)");
			LOG.debug("wtPart: " + wtPart);
			LOG.debug("softtypeName: \"" + softtypeName + "\"");
		}
		try {
			if (LOG.isDebugEnabled()) {
				LOG.debug("KBAutoAssociatePartFinderCreator: print IBA attributes before retyping");
				wt.occurrence.IBAHelper.printIBAValues(wtPart);
			}
			((Typed) wtPart).setTypeDefinitionReference(
					TypedUtilityServiceHelper.service.getTypeDefinitionReference(softtypeName));
			if (LOG.isDebugEnabled()) {
				LOG.debug("KBAutoAssociatePartFinderCreator: print IBA attributes after retyping");
				wt.occurrence.IBAHelper.printIBAValues(wtPart);
			}
		} catch (Exception e) {
			throw new WTException(e);
		}
		if (LOG.isDebugEnabled()) {
			LOG.debug("exiting setSofttype()");
			LOG.debug("returning: " + wtPart);
		}
		return wtPart;
	}

	/**
	 * Sets soft type attribute for newly created part.
	 *
	 * @param wtPart
	 *            part for which soft type attribute is set
	 * @return the wtPart
	 * @throws WTException
	 *             the wT exception
	 */
	private WTPart setAttributes(WTPart wtPart) throws WTException {
		if (LOG.isDebugEnabled()) {
			LOG.debug("entering setAttributes(WTPart)");
			LOG.debug("wtPart: " + wtPart);
		}
		WTPart part = wtPart;
		try {
			if (LOG.isDebugEnabled()) {
				LOG.debug("KBAutoAssociatePartFinderCreator: print IBA attributes after setting attribute");
				wt.occurrence.IBAHelper.printIBAValues(wtPart);
			}
		} catch (Exception e) {
			throw new WTException(e);
		}
		if (LOG.isDebugEnabled()) {
			LOG.debug("exiting setAttributes()");
			LOG.debug("returning: " + part);
		}
		return part;
	}

	/**
	 * Validates for KB-HVAC Part Category attribute for Autoassociation In case
	 * Part Category is not equals 1,2,3 the autocreation is rejected, as this
	 * requires different type, which cannot be created automatically.
	 *
	 * @param document
	 *            EPMDocument
	 * @throws WTException
	 *             the wT exception
	 */
	public void validateWTPartCreation(EPMDocument document) throws WTException {
		if (LOG.isDebugEnabled()) {
			LOG.debug("entering validateWTPartCreation(EPMDocument)");
			LOG.debug("document: " + document);
		}
		String partCategoryValue = ext.kb.util.IBAHelper.readIBA(document, KBConstants.KB_PART_CATEGORY_IBA);
		if (!validPartCategoryValues.contains(partCategoryValue)) {
			WTMessage errorMessage = new WTMessage(RESOURCE, AutoAssociateRB.INVALID_PART_CATEGORY, new Object[] {
					document.getNumber(), partCategoryValue, StringUtils.join(validPartCategoryValues, ',') });
			throw new WTException(errorMessage);
		}
	}
	public static boolean isDrawingWithArticleNum(EPMDocument document) {
		if (LOG.isDebugEnabled()) {
			LOG.debug("isDrawingWithArticleNum " + document.getNumber());
		}
		String kbArticleNumber = "";
		if (isDrawing(document)) {
			try {
				kbArticleNumber = ext.kb.util.IBAHelper.getStringIBAValue(document, "KB_ARTICLE_NUM");
			} catch (WTException e) {
				e.printStackTrace();
			}
			if (LOG.isDebugEnabled()) {
				LOG.debug("kbArticleNumber on drawing " + kbArticleNumber);
			}

			return ((!(KBUtils.isEmpty(kbArticleNumber))) && (!(".".equals(kbArticleNumber))));
		}

		return false;
	}
	private static boolean isDrawing(EPMDocument document) {
		if (LOG.isDebugEnabled()) {
			LOG.debug("entering isDrawing(EPMDocument)");
			LOG.debug("document: " + document);
			LOG.debug("exiting isDrawing()");
		}
		return EPMDocumentType.toEPMDocumentType("CADDRAWING").equals(document.getDocType());
	}
}
