package ext.kb.businessrule.validation;

import com.ptc.core.businessRules.feedback.RuleFeedbackType;

public class KBGeklaWarningValidation extends KBGeklaValidation {

    public KBGeklaWarningValidation() {
        setFeedbackType(RuleFeedbackType.WARNING);
    }
}
