package ext.kb.businessrule.validation;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.util.StringUtils;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.generic.iba.AttributeService;

import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.KBConstants;
import ext.kb.util.KBTypeIdProvider;
import ext.kb.util.KBUtils;
import wt.epm.EPMDocument;
import wt.epm.EPMDocumentMaster;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.log4j.LogR;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.WTProperties;

public class KBCADDrwQualityCheckValidator extends KBValidation {

	public static final String PROE = "PROE";
	protected static final Logger LOG = LogR.getLogger(KBCADDrwQualityCheckValidator.class.getName());

	private static final Set<String> containersToSkipCadim;

	static {
		WTProperties wtprop = null;
		try {
			wtprop = WTProperties.getLocalProperties();
		} catch (IOException e) {
			LOG.error(e);
			throw new ExceptionInInitializerError(e);
		}
		containersToSkipCadim = new HashSet<>();
		String standardWorkerProducts = wtprop.getProperty("ext.workflow.standardWorkerProducts");
		if (standardWorkerProducts != null && !standardWorkerProducts.isEmpty()) {
			String[] standardWorkerProductsArray = standardWorkerProducts.split("\\|");
			containersToSkipCadim.addAll(Arrays.asList(standardWorkerProductsArray));
		}
	}

	@Override
	public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList) throws WTException {
		if (LOG.isDebugEnabled()) {
			LOG.debug("entering isRulesValid(Persistable,Map<String,Set<AttributeRuleSet>>,List<RuleFeedbackMessage>)");
			LOG.debug("paramPersistable: " + paramPersistable);
			LOG.debug("paramMap: " + paramMap);
			LOG.debug("paramList: " + paramList);
		}
		boolean isInternalrelease = false;
		if (LOG.isDebugEnabled()) {
			LOG.debug("exiting isRulesValid()");
		}
		return validateObject(paramPersistable, paramList, isInternalrelease);
	}

	boolean validateObject(Persistable paramPersistable, List<RuleFeedbackMessage> paramList, boolean isInternalrelease)
			throws WTException {
		if (LOG.isDebugEnabled()) {
			LOG.debug("entering validateObject(Persistable,List<RuleFeedbackMessage>,boolean)");
			LOG.debug("paramPersistable: " + paramPersistable);
			LOG.debug("paramList: " + paramList);
			LOG.debug("isInternalrelease: " + isInternalrelease);
		}
		boolean isValid = true;

		if (paramPersistable instanceof EPMDocument) {
			EPMDocument epmDoc = (EPMDocument) paramPersistable;
			boolean isACAD = KBConstants.ACAD_AUTHORING_APPLICATION_TYPE.equals(epmDoc.getAuthoringApplication());
			if (isACAD) {
				if (LOG.isDebugEnabled()) {
					LOG.debug("exiting validateObject()");
					LOG.debug("returning: " + isValid);
				}
				return isValid;
			}
			String containerName = epmDoc.getContainerName();
			LOG.debug("EpmDoc number: " + epmDoc.getNumber());
			LOG.debug(String.format("Container of EPMDocument is: [%s]", containerName));
			if (containersToSkipCadim != null && containersToSkipCadim.contains(containerName)) {
				LOG.debug(String.format("Skipping business rule for EPMDocument [%s]", epmDoc.getNumber()));
				if (LOG.isDebugEnabled()) {
					LOG.debug("exiting validateObject()");
					LOG.debug("returning: " + true);
				}
				return true;
			}
			boolean isKBCadDrw = KBTypeIdProvider.isDescendant(epmDoc, "KBCADDRW");
			if (LOG.isInfoEnabled()) {
				LOG.info("EPMDocument is Cad doc " + isKBCadDrw);
			}
			if (KBConstants.KB.equals(epmDoc.getOrganizationName()) && isKBCadDrw) {
				// 1. The attribute value of KB_CHANGE_INDEX must match the
				// revision (0,1,2,...)
				boolean hasValidRevision = hasValidRevision(paramList, isInternalrelease, epmDoc);
				// 2. Each result object of type CAD Drawing must have a Drawing
				// Format associated (navigation from Drawing via EPM reference
				// "Drawing Format" must find at least one).
				boolean hasDrawingFormatAssociated = hasDrawingFormatAssociated(paramList, epmDoc);
				isValid = hasValidRevision && hasDrawingFormatAssociated;
			}
		}
		LOG.debug("Returning: " + isValid);
		if (LOG.isDebugEnabled()) {
			LOG.debug("exiting validateObject()");
			LOG.debug("returning: " + isValid);
		}
		return isValid;
	}

	private boolean hasDrawingFormatAssociated(List<RuleFeedbackMessage> paramList, EPMDocument epmDoc)
			throws WTException {
		if (LOG.isDebugEnabled()) {
			LOG.debug("entering hasDrawingFormatAssociated(List<RuleFeedbackMessage>,EPMDocument)");
			LOG.debug("paramList: " + paramList);
			LOG.debug("epmDoc: " + epmDoc);
		}
		boolean isValid = true;
		boolean hasDrawingFormatAssociated = false;
		QueryResult connected3DParts = KBUtils.navigateEPMReferenceLinkGetCadParts(epmDoc);
		while (connected3DParts.hasMoreElements() && !hasDrawingFormatAssociated) {
			EPMDocumentMaster connected3DPartMaster = (EPMDocumentMaster) connected3DParts.nextElement();
			if (LOG.isDebugEnabled()) {
				LOG.debug("EPMDocument (name=" + connected3DPartMaster.getName() + " number="
						+ connected3DPartMaster.getNumber() + ") doc type=" + connected3DPartMaster.getDocType());
			}
			if (KBConstants.DRAWING_FORMAT.equals(connected3DPartMaster.getDocType())) {
				hasDrawingFormatAssociated = true;
			}
		}
		if (!hasDrawingFormatAssociated) {
			paramList.add(new RuleFeedbackMessage(
					new WTMessage(RESOURCE, BusinessRuleRB.NO_DRAWING_FORMAT_ASS, new Object[] {}), getFeedbackType()));
			isValid = false;
		}
		if (LOG.isDebugEnabled()) {
			LOG.debug("exiting hasDrawingFormatAssociated()");
			LOG.debug("returning: " + isValid);
		}
		return isValid;
	}

	private boolean hasValidRevision(List<RuleFeedbackMessage> paramList, boolean isInternalrelease, EPMDocument epmDoc)
			throws WTException {
		if (LOG.isDebugEnabled()) {
			LOG.debug("entering hasValidRevision(List<RuleFeedbackMessage>,boolean,EPMDocument)");
			LOG.debug("paramList: " + paramList);
			LOG.debug("isInternalrelease: " + isInternalrelease);
			LOG.debug("epmDoc: " + epmDoc);
		}
		boolean isValid = true;
		String revision = (String) KBUtils.getMBAValue(epmDoc, "revision");
		String changeIndex = AttributeService.getAttribute(epmDoc, KBConstants.KB_CHANGE_INDEX);
		String internalRevision = AttributeService.getAttribute(epmDoc, KBConstants.KB_INTERNAL_REVISION_IBA);
		String convertedRevision = getConvertedRevision(revision, internalRevision);
		boolean isCreo = KBConstants.PROE_AUTHORING_APPLICATION_TYPE.equals(epmDoc.getAuthoringApplication());
		boolean isEmpty = StringUtils.isEmpty(internalRevision) || "-".equalsIgnoreCase(internalRevision);

		if (isInternalrelease && isCreo && !isEmpty) {
			isValid = isRevisionValid(paramList, convertedRevision, changeIndex);
		} else if (isInternalrelease && isEmpty) {
			isValid = isRevisionValid(paramList, revision, changeIndex);
		} else if (!isInternalrelease) {
			isValid = isRevisionValid(paramList, revision, changeIndex);
		}
		if (LOG.isDebugEnabled()) {
			LOG.debug("exiting hasValidRevision()");
			LOG.debug("returning: " + isValid);
		}
		return isValid;
	}

	private String getConvertedRevision(String revision, String internalRevision) {
		if (LOG.isDebugEnabled()) {
			LOG.debug("entering getConvertedRevision(String,String)");
			LOG.debug("revision: \"" + revision + "\"");
			LOG.debug("internalRevision: \"" + internalRevision + "\"");
		}
		if (!StringUtils.isEmpty(revision) && !StringUtils.isEmpty(internalRevision)) {
			if (LOG.isDebugEnabled()) {
				LOG.debug("exiting getConvertedRevision()");
				LOG.debug("returning: " + (revision + "." + internalRevision));
			}
			return revision + "." + internalRevision;
		}
		if (LOG.isDebugEnabled()) {
			LOG.debug("exiting getConvertedRevision()");
			LOG.debug("returning: " + null);
		}
		return null;
	}

	private boolean isRevisionValid(List<RuleFeedbackMessage> paramList, String revision, String changeIndex) {
		if (LOG.isDebugEnabled()) {
			LOG.debug("entering isRevisionValid(List<RuleFeedbackMessage>,String,String)");
			LOG.debug("paramList: " + paramList);
			LOG.debug("revision: \"" + revision + "\"");
			LOG.debug("changeIndex: \"" + changeIndex + "\"");
		}
		boolean isValid = true;
		if (changeIndex != null) {
			changeIndex = changeIndex.trim();
		}
		if (revision != null) {
			if (!revision.equals(changeIndex)) {
				paramList.add(getErrorMessage(revision, changeIndex));
				isValid = false;
			}
		} else {
			if (changeIndex != null) {
				paramList.add(getErrorMessage(revision, changeIndex));
				isValid = false;
			}
		}
		if (LOG.isDebugEnabled()) {
			LOG.debug("exiting isRevisionValid()");
			LOG.debug("returning: " + isValid);
		}
		return isValid;
	}

	private RuleFeedbackMessage getErrorMessage(String revision, String changeIndex) {
		if (LOG.isDebugEnabled()) {
			LOG.debug("entering getErrorMessage(String,String)");
			LOG.debug("revision: \"" + revision + "\"");
			LOG.debug("changeIndex: \"" + changeIndex + "\"");
			LOG.debug("exiting getErrorMessage()");
		}
		return new RuleFeedbackMessage(new WTMessage(RESOURCE, BusinessRuleRB.CHGIDX_AND_REV_NOT_EQUAL,
				new Object[] { changeIndex, revision }), getFeedbackType());
	}

}
