package ext.kb.businessrule.validation;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import wt.change2.ChangeRecord2;
import wt.change2.Changeable2;
import wt.change2.WTChangeActivity2;
import wt.enterprise.RevisionControlled;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.fc.collections.WTHashSet;
import wt.identity.IdentityFactory;
import wt.lifecycle.State;
import wt.part.WTPart;
import wt.part.WTPartHelper;
import wt.part.WTPartUsageLink;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.util.WTMessage;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.core.businessRules.feedback.RuleFeedbackType;
import com.ptc.core.businessRules.validation.RuleValidationCriteria;
import com.ptc.core.businessRules.validation.RuleValidationKey;

import ext.kb.change2.helper.ChangeNoticeUtils;
import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.KBConstants;
import ext.kb.util.KBUtils;
import ext.kb.util.ObjectRevisionHelper;
import ext.kb.workflow.ChangeTaskUtils;

public class KBBOMComponent1070StateValidator extends KBValidation {

	private static final String INVALIDNUMBERS2 = "INVALIDNUMBERS";

	private static final Logger LOG = Logger.getLogger(KBBOMComponent1070StateValidator.class);
			
	private static final Set<String> ALLOWED_PARENT_TARGET_STATES;
	private static final String INVALID_STATE = "1070";

	static {
		ALLOWED_PARENT_TARGET_STATES = new HashSet<>(Arrays.asList("1030", "1045", "1050", "1058"));
	}

	@Override
	public boolean isRulesValid(Persistable object, Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList, RuleValidationKey validationKey) throws WTException {
		if (LOG.isDebugEnabled()) {
			LOG.debug("entering  isRulesValid(Persistable, Map<String, Set<AttributeRuleSet>>, List<RuleFeedbackMessage>)");
		}
		boolean isValid = true;
		String objNumber = getObjectNumber(object);
		if (LOG.isDebugEnabled()){
			LOG.debug(String.format("resulting object number: [%s]", objNumber));
		}
		HashSet invalidNumbers = (HashSet) validationKey.getProcessingMapValue(INVALIDNUMBERS2);
		
		if (!invalidNumbers.isEmpty() && invalidNumbers.contains(objNumber)){
			isValid = false;
			RuleFeedbackMessage m = getWarningFeedbackMessage();
			paramList.add(m);
			invalidNumbers.clear();
		}
		if (LOG.isDebugEnabled()){
			LOG.debug("remaining invalid numbers: " + invalidNumbers);
			LOG.debug("exiting isRulesValid(Persistable, Map, List), returning " + isValid);
		}
		return isValid;
		
	}

	private boolean processChangeActivity(WTChangeActivity2 changeActivity, WTHashSet resultingObjectsInContext, RuleValidationKey validationKey) throws WTException {
		boolean isValid = true;
		if (LOG.isDebugEnabled()){
			LOG.debug(String.format("Processing Change Activity [%s]", changeActivity.getNumber()));
		}

		Set<Object> changeRecords = ChangeTaskUtils.getResultingObjects(changeActivity, false);
		if (LOG.isDebugEnabled()){
			LOG.debug(String.format("Got [%d] resulting objects", changeRecords.size()));
		}
		for (Object object : changeRecords) {

			ChangeRecord2 changeRecord = (ChangeRecord2) object;
			Changeable2 changeable = changeRecord.getChangeable2();

			if (!isApplicableForValidation(changeRecord)) {
				if (LOG.isDebugEnabled()){
					LOG.debug(String.format("Object [%s] is not applicable for validation", getObjectNumber(changeRecord) + ":" + getObjectNumber(changeRecord.getRoleAObject()) + "-" + getObjectNumber(changeRecord.getRoleBObject())));
				}
				continue;
			}
			WTPart resultingObject = (WTPart) changeable;
			boolean isEbomPart = KBUtils.isEbomPart(resultingObject);
			if(!isEbomPart) {
				LOG.info("Found part is MBOM, skipping.");
				continue;
			}
			List<Persistable> childParts = getChildParts(resultingObject);
			if (LOG.isDebugEnabled()){
				LOG.debug(String.format("Got [%d] children for the object [%s]", childParts.size(), getObjectNumber(resultingObject)));
			}
			HashSet<String> invalidNumbers = (HashSet<String>) validationKey.getProcessingMapValue(INVALIDNUMBERS2);
			for (Persistable childPart : childParts) {
				String childState = KBUtils.getKBStateNumericValueString((RevisionControlled) childPart);
				
				if (resultingObjectsInContext.contains(childPart)){
					ChangeRecord2 cr = ChangeNoticeUtils.getChangeRecord(childPart);
					String childTargetState = null;
					if (cr != null && cr.getTargetTransition() != null) {
						childTargetState = cr.getTargetTransition().toString();
					}
					if (LOG.isDebugEnabled()){
						LOG.debug(String.format("Child [%s] is on the change context, validating its targetState [%s]", getObjectNumber(childPart), childTargetState));
					}
					if (isChildStateInvalid(childTargetState)){
						if (LOG.isDebugEnabled()){
							LOG.debug(String.format("Child [%s] has wrong target state [%s]", getObjectNumber(childPart), childTargetState));
						}
						invalidNumbers.add(getObjectNumber(resultingObject));
						isValid = false;
						
					}
				} else {
					if (LOG.isDebugEnabled()){
						LOG.debug(String.format("Child [%s] is not on the change context, validating its current state [%s]", getObjectNumber(childPart), childState));
					}
					if (Integer.valueOf(childState) < 1030) {
						if (!isChildPreviousVersionValid(childPart)){
							invalidNumbers.add(getObjectNumber(resultingObject));
							isValid = false;
						}
					} else if (isChildStateInvalid(childState)) {
						if (LOG.isDebugEnabled()){
							LOG.debug(String.format("Child [%s] is in the wrong state [%s]", getObjectNumber(childPart), childState));
						}
						invalidNumbers.add(getObjectNumber(resultingObject));
						isValid = false;
					}  
				}
			}
		}
		return isValid;
	}

	private boolean isChildPreviousVersionValid(Persistable persistable) throws WTException {
		Persistable previousVersion = ObjectRevisionHelper.getPreviousVersionLatestIteration(persistable);
		if (previousVersion != null) {
			String prevState = KBUtils.getKBStateNumericValueString((RevisionControlled) previousVersion);
			if (isChildStateInvalid(prevState)) {
				if (LOG.isDebugEnabled()){
					LOG.debug(String.format("Child previous version [%s] is in the wrong state [%s]", getObjectNumber(previousVersion), prevState));
				}
				return false;
			}
		}
		return true;
	}

	private boolean isChildStateInvalid(String childState) {
		return childState != null && INVALID_STATE.equals(childState);
	}

	private boolean isApplicableForValidation(ChangeRecord2 changeRecord) {
		boolean isWTPart = changeRecord.getChangeable2() instanceof WTPart;
		if (!isWTPart || changeRecord.getTargetTransition() == null) {
			return false;
		}
		String targetTransition = KBUtils.getKBTargetStateNumericValueString(changeRecord.getTargetTransition());
		return ALLOWED_PARENT_TARGET_STATES.contains(targetTransition);
	}

	private List<Persistable> getChildParts(WTPart parentPart) throws WTException {
		ArrayList<Persistable> childParts = new ArrayList<>();
		QueryResult result = WTPartHelper.service.getUsesWTPartMasters(parentPart);
		while (result.hasMoreElements()) {
			WTPartUsageLink link = (WTPartUsageLink) result.nextElement();
			Persistable child = ObjectRevisionHelper.getLatestIterationByMastered(link.getUses());
			childParts.add(child);
		}
		return childParts;
	}

	private String getObjectNumber(Persistable persistable) throws WTException {
		return IdentityFactory.getDisplayIdentifier(persistable).getLocalizedMessage(SessionHelper.manager.getLocale());
	}

	private RuleFeedbackMessage getWarningFeedbackMessage() {
		WTMessage message = new WTMessage(BusinessRuleRB.class.getName(), BusinessRuleRB.BOM_COMPONENT_1070_STATE_RULE,
				new Object[] {});
		return new RuleFeedbackMessage(message, RuleFeedbackType.WARNING);
	}

	@Override
	public void prepareForValidation(RuleValidationKey validationKey, RuleValidationCriteria paramRuleValidationCriteria) throws WTException {
		WTChangeActivity2 currentCA = (WTChangeActivity2) paramRuleValidationCriteria.getPrimaryBusinessObject();
		
		validationKey.addToProcessingMap(INVALIDNUMBERS2, new HashSet<String>());
		
		boolean isValid = true;
		State caState = currentCA.getLifeCycleState();
		if (KBConstants.STATE_CANCELED.equals(caState)) {
			if (LOG.isDebugEnabled()){
				LOG.debug("Change Activity state CANCELLED, return");
			}
			return;
		}

		QueryResult activitiesFromChangeContext = ChangeTaskUtils.getActivitiesFromChangeContext(currentCA);
		if (LOG.isDebugEnabled()){
			LOG.debug(String.format("Got [%d] change activities in the change context", activitiesFromChangeContext.size()));
		}
		WTHashSet resultingObjectsInContext = ChangeTaskUtils.getResultingObjects(activitiesFromChangeContext);
		activitiesFromChangeContext.reset();
		while (activitiesFromChangeContext.hasMoreElements()) {
			WTChangeActivity2 changeActivity = (WTChangeActivity2) activitiesFromChangeContext.nextElement();
			isValid = processChangeActivity(changeActivity, resultingObjectsInContext, validationKey) && isValid;
		}
	}

	@Override
	public boolean isRulesValid(Persistable paramPersistable,
			Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList) throws WTException {
		// TODO Auto-generated method stub
		return false;
	}

}
