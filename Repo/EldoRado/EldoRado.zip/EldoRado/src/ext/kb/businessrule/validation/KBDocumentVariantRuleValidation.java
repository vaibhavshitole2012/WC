/**
 * 
 */
package ext.kb.businessrule.validation;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.generic.iba.AttributeService;

import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.DBUtils;
import ext.kb.util.KBConstants;
import ext.kb.workflow.EPMChangeUtils;
import wt.change2.ChangeRecord2;
import wt.change2.WTChangeOrder2;
import wt.configurablelink.ConfigurableRevisionLink;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.util.WTException;
import wt.util.WTMessage;

/**
 * @author bankowskie
 *
 */
public class KBDocumentVariantRuleValidation extends KBValidation {

	private static final Logger LOG = Logger.getLogger(KBDocumentVariantRuleValidation.class.getName());
	 
	@Override
	public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap, List<RuleFeedbackMessage> paramList) throws WTException{ 
		boolean isVariant = isVariantDocument(paramPersistable);
		LOG.debug("Is given document a variant? " + isVariant);
		if (!isVariant) return true;
		Persistable sourceDocument = getSourceFromVariant(paramPersistable);
		LOG.debug("Retrieved source document: "+sourceDocument);
		if(sourceDocument == null) return true;
		boolean isStateTransitionValid = isStateValid(paramPersistable, sourceDocument);
		LOG.debug("Is transition valid? "+isStateTransitionValid);
		if(isStateTransitionValid) return true;
		boolean isSourceIncludedInProcess = isSourceIncludedInProcess(paramPersistable,sourceDocument);
		if(isSourceIncludedInProcess) return true;
		if(!isStateTransitionValid) paramList.add(new RuleFeedbackMessage(new WTMessage(RESOURCE, BusinessRuleRB.SOURCE_VARIANT_INVALID_STATE, new Object[]{}), getFeedbackType()));
		else if(!isSourceIncludedInProcess) paramList.add(new RuleFeedbackMessage(new WTMessage(RESOURCE, BusinessRuleRB.SOURCE_NOT_INCLUDED, new Object[]{}), getFeedbackType()));
		return isStateTransitionValid;
	}

	/**
	 * Method that checks if given object is a variant document
	 * 
	 * @param persistable Object to check
	 * @return status of validation
	 */
	private boolean isVariantDocument(Persistable persistable) {
		String sapIdx = AttributeService.getAttribute(persistable, KBConstants.KBSAP_IDX_IBA);
		if (sapIdx == null) {
			LOG.debug("Sap idx is empty, returning.");
			return false;
		}
		LOG.debug("Got sap idx: " + sapIdx);
		if (Integer.parseInt(sapIdx) > 0) {
			return true;
		}
		return false;
	}

	/**
	 * Method used to query source document from given persistable.
	 * 
	 * @param persistable Object to query source document from
	 * @return Found source document
	 * 
	 */
	private Persistable getSourceFromVariant(Persistable persistable) {
		Persistable sourceDocument = null;
		try {
			QueryResult allLinks = PersistenceHelper.manager.navigate(persistable, ConfigurableRevisionLink.ALL_ROLES, ConfigurableRevisionLink.class, true);
			while (allLinks.hasMoreElements()) {
				Object obj = allLinks.nextElement();
				LOG.debug("Got: " + obj);
				if (obj instanceof Persistable) {
					return (Persistable) obj;
				}
			}
		} catch (WTException e) {
			LOG.error("Unable to query for source document of " + persistable, e);
		}
		return sourceDocument;
	}
	
	/**
	 * Method comparing state of source document and target state of variant document
	 * 
	 * @param variantDocument Variant document
	 * @param sourceDocument Source document
	 * @return status of compare
	 * 
	 */
	private boolean isStateValid(Persistable variantDocument, Persistable sourceDocument){
		boolean status = false;
		String sourceState = AttributeService.getAttribute(sourceDocument, "state.state");
		String targetVariantState = getTargetState(variantDocument);
		LOG.debug("Target state for variant is: "+targetVariantState+" ,source state is: "+sourceState);
		if(sourceState.equals(KBConstants.RELEASED)){
			status = targetVariantState.equals(KBConstants.RELEASED) || targetVariantState.equals(KBConstants.INVALID);
		}else if(sourceState.equals(KBConstants.INVALID)){
			status = targetVariantState.equals(KBConstants.INVALID);
		}
		LOG.debug("Returning status: "+status);
		return status;
	}
	
	/**
	 * Method used to query for change links of given persistable, and retrieve target state
	 * 
	 * @param persistable Object to query for target state
	 * @return 4 digit state value
	 * 
	 */
	private String getTargetState(Persistable persistable){
		String targetState = "";
		try {
			List<ChangeRecord2> list = DBUtils.retrieveLinks(ChangeRecord2.class, persistable, ChangeRecord2.ALL_ROLES);
			if (!list.isEmpty()) {
				LOG.debug("Found change records for "+persistable);
				ChangeRecord2 changeLink = list.get(0);
				if (changeLink.getTargetTransition() != null) {
					targetState = changeLink.getTargetTransition().getDisplay();
					LOG.debug("Found target state is: "+targetState);
					targetState = targetState.substring(0, 4);
					LOG.debug("Target state trimmed to 4digit: "+targetState);
				}
			}
		} catch (WTException e) {
			LOG.error("Unable to query for target state of "+persistable);
		}
		LOG.debug("Returning "+targetState+" target state for "+persistable);
		return targetState;
	}
	
	/**
	 * Method used to check if given source/variant pair is included in the ECT. Needed to bypass state check if source is included alongside variant.
	 * @param variant
	 * @param source
	 * @return boolean value
	 */
	private boolean isSourceIncludedInProcess(Persistable variant, Persistable source) {
		try {
			WTChangeOrder2 changeNotice = EPMChangeUtils.getChangeNoticeFromPersistable(variant);
			if(changeNotice == null) {
				LOG.debug("No ECN found for "+variant+", returning false.");
				return false;
			}
			QueryResult affectedList = EPMChangeUtils.getResultingItems(changeNotice);	
			LOG.debug("Found ECN from given object: "+changeNotice);
			while(affectedList.hasMoreElements()) {
				if(affectedList.nextElement().equals(source)) {
					LOG.debug("Found source document in ECN, returning true");
					return true;
				}
			}
		} catch (WTException e) {
			LOG.error("Unable to query for source document in ECN", e);
			return false;
		}
		LOG.debug("Source document not found in ECN, returning false");
		return false;
	}
	
	
}
