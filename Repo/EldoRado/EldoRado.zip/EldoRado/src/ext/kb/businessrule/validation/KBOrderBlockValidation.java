package ext.kb.businessrule.validation;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import wt.change2.ChangeActivity2;
import wt.change2.ChangeHelper2;
import wt.change2.ChangeRecord2;
import wt.enterprise.RevisionControlled;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.fc.collections.WTArrayList;
import wt.lifecycle.Transition;
import wt.util.WTException;
import wt.util.WTMessage;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.core.businessRules.feedback.RuleFeedbackType;
import com.ptc.core.businessRules.validation.RuleValidationCriteria;
import com.ptc.core.businessRules.validation.RuleValidationKey;
import com.ptc.core.meta.common.TypeIdentifierHelper;
import com.ptc.generic.iba.AttributeService;

import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.KBConstants;
import ext.kb.util.KBTypeIdProvider;
import ext.kb.util.KBUtils;

public class KBOrderBlockValidation extends KBValidation {

	private static final Logger LOG = Logger.getLogger(KBOrderBlockValidation.class);
	private static final String PART1070 = "PART1070";
	private static final String DOC1050 = "DOC1050";

	/*
	 * If any resulting WTPart has release target 1070, a document of
	 * KB_DOC_CONTENT_TYPE 700 (Order Block / Sperrantrag) must be a result
	 * object on the same ECT, and must have release target 1050
	 * 
	 * (non-Javadoc)
	 * 
	 * @see
	 * ext.kb.businessrule.validation.KBValidation#isRulesValid(wt.fc.Persistable
	 * , java.util.Map, java.util.List)
	 */
	@Override
	public boolean isRulesValid(Persistable paramPersistable,Map<String, Set<AttributeRuleSet>> paramMap, 
			List<RuleFeedbackMessage> paramList, RuleValidationKey paramRuleValidationKey) throws WTException {
		if (LOG.isDebugEnabled()){
			LOG.debug("entering isRulesValid(Persistable, Map, List);");
		}
		boolean hasWTPartWithTargetTransition1070 = (boolean) paramRuleValidationKey.getProcessingMapValue(PART1070);
		boolean hasWTDocWithContentType700WithTargetTransition1050 = (boolean) paramRuleValidationKey.getProcessingMapValue(DOC1050);
		if (hasWTPartWithTargetTransition1070 && ! hasWTDocWithContentType700WithTargetTransition1050){
			if (LOG.isDebugEnabled()){
				LOG.debug("WTPart with target transition 1070 added to ECT, a DOC with content type 700 required on ECT, rule is NOT valid.");
			}
			paramList.add(new RuleFeedbackMessage(new WTMessage(RESOURCE, BusinessRuleRB.WTPART_RELEASE_TARGET_1070, new Object[]{}), RuleFeedbackType.WARNING));
			return false;
		}
		return true;
	}

	/*
	 * This method is responsible for collecting all the resulting objects
	 * transitions to a map
	 */
	@Override
	public void prepareForValidation(RuleValidationKey paramRuleValidationKey, 
			RuleValidationCriteria paramRuleValidationCriteria) throws WTException {
		boolean hasWTPartWithTargetTransition1070 = false;
		boolean hasWTDocWithContentType700WithTargetTransition1050 = false;
		
		ChangeActivity2 currentActivity = (ChangeActivity2) paramRuleValidationCriteria.getPrimaryBusinessObject();

		QueryResult resultingItems = ChangeHelper2.service.getChangeablesAfter(currentActivity, false);
		Collection resItemsAsColl = new WTArrayList(resultingItems).persistableCollection();
		for (Object o : resItemsAsColl) {
			if (o instanceof ChangeRecord2) {
				ChangeRecord2 cr = (ChangeRecord2) o;
				Transition targetTransition = cr.getTargetTransition();
				if (LOG.isDebugEnabled()){
					LOG.debug("Resulting object: " + KBUtils.getIdentityWithStateAndRevision((RevisionControlled)cr.getRoleBObject()) + " type:"+ TypeIdentifierHelper.getType(cr.getRoleBObject()) + " with targetTransition: " + targetTransition );
				}
				if (targetTransition == null){
					// targetTransition is required, Release Target Rule raises an error
					paramRuleValidationKey.addToProcessingMap(PART1070, hasWTPartWithTargetTransition1070);
					paramRuleValidationKey.addToProcessingMap(DOC1050, hasWTDocWithContentType700WithTargetTransition1050);
					return;
				}
				if (targetTransition.equals(Transition.toTransition(KBConstants.ORDER_BLOCK))) {
					Persistable roleBObject = cr.getRoleBObject();
					if (KBTypeIdProvider.isDescendant(roleBObject, "ARTICLE")){
						hasWTPartWithTargetTransition1070 = true;
					}

				}
				if (targetTransition.equals(Transition.toTransition(KBConstants.RELEASED))) {
					Persistable roleBObject = cr.getRoleBObject();
					if (KBTypeIdProvider.isDescendant(roleBObject, "KBDOC")){
						Object contentType = AttributeService.getAttribute(roleBObject, "KB_DOC_CONTENT_TYPE");
						if ("700".equals(contentType)){
							hasWTDocWithContentType700WithTargetTransition1050 = true;
						}
					}
					
				}
			}
		}
		paramRuleValidationKey.addToProcessingMap(PART1070, hasWTPartWithTargetTransition1070);
		paramRuleValidationKey.addToProcessingMap(DOC1050, hasWTDocWithContentType700WithTargetTransition1050);
		if (LOG.isDebugEnabled()){
			LOG.debug("ECT hasWTPartWithTargetTransition1070=" + hasWTPartWithTargetTransition1070 + ", hasWTDocWithContentType700WithTargetTransition1050=" + hasWTDocWithContentType700WithTargetTransition1050);
		}
	}

	@Override
	public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList) throws WTException {
		return false;
	}
}
