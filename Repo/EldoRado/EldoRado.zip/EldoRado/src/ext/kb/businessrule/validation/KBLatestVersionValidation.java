package ext.kb.businessrule.validation;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;

import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.ObjectRevisionHelper;
import wt.doc.WTDocument;
import wt.epm.EPMDocument;
import wt.fc.Persistable;
import wt.part.WTPart;
import wt.util.WTException;
import wt.util.WTMessage;

public class KBLatestVersionValidation extends KBValidation {

	@Override
	public boolean isRulesValid(Persistable persistable, Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList) throws WTException {

		boolean result = true;
		

		if (!isValidType(persistable)) {
			return result;
		}

		if (!isLatestVersion(persistable)) {
			result = false;
			paramList.add(new RuleFeedbackMessage(
					new WTMessage(RESOURCE, BusinessRuleRB.NOT_LATEST_VERSION,
							new Object[] { getObjectNumber(persistable) }),
					getFeedbackType()));
		}

		return result;
	}

	private boolean isLatestVersion(Persistable persistable) throws WTException {
		Persistable latestVersion = null;
		if (persistable instanceof EPMDocument) {
			latestVersion = ObjectRevisionHelper.getLatestVersion((EPMDocument) persistable);
		} else {
			latestVersion = ObjectRevisionHelper.getLatestVersionByPersistable(persistable);
		}
		return persistable.equals(latestVersion);
	}

	protected String getObjectNumber(Persistable persistable) {
		if (persistable instanceof WTDocument) {
			return ((WTDocument) persistable).getNumber();
		} else if (persistable instanceof EPMDocument) {
			return ((EPMDocument) persistable).getNumber();
		} else if (persistable instanceof WTPart) {
			return ((WTPart) persistable).getNumber();
		} else {
			return "";
		}
	}

	private boolean isValidType(Persistable persistable) {
		return persistable instanceof WTPart
				|| persistable instanceof WTDocument
				|| persistable instanceof EPMDocument;
	}

}
