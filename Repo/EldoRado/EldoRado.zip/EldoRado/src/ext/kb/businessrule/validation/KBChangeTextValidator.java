package ext.kb.businessrule.validation;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.core.businessRules.feedback.RuleFeedbackType;
import com.ptc.core.businessRules.validation.RuleValidationCriteria;
import com.ptc.core.businessRules.validation.RuleValidationKey;

import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.KBType;
import ext.kb.util.KBUtils;
import ext.kb.util.ObjectRevisionHelper;
import ext.kb.workflow.ChangeTaskUtils;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import wt.change2.AffectedActivityData;
import wt.change2.ChangeRecord2;
import wt.change2.WTChangeActivity2;
import wt.doc.WTDocument;
import wt.enterprise.RevisionControlled;
import wt.epm.EPMDocument;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.part.WTPart;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.vc.Mastered;
import wt.vc.VersionControlHelper;
import wt.vc.Versioned;

import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class KBChangeTextValidator extends KBValidation {
    private static final Logger logger = Logger.getLogger(KBChangeTextValidator.class);
    private static final String[] supportedTypes = new String[]{"com.ptc.DesignCADDrw", "com.ptc.KBTechnicalDocument", "com.ptc.KBTechnicalDrawing",
            "com.ptc.KBCertificate", "com.ptc.KBStandard"};

    public KBChangeTextValidator() {
        setFeedbackType(RuleFeedbackType.WARNING);
    }

    @Override
    public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap, List<RuleFeedbackMessage> paramList, RuleValidationKey validationKey) throws WTException {
    	WTChangeActivity2 currentActivity = (WTChangeActivity2) validationKey.getProcessingMapValue(ECT);
        if (logger.isDebugEnabled()) {
            logger.debug("checking comment fields for " + paramPersistable + " and " + currentActivity);
        }
        if (!KBType.isOneOfTypes(paramPersistable, supportedTypes)) {
            return true;
        }
        //check if the object is in the first version or the comment is not empty
        if(ObjectRevisionHelper.isInFirstRevision((RevisionControlled) paramPersistable)
                || VersionControlHelper.service.allVersionsFrom((Versioned) paramPersistable).size() <= 1) {
            if (logger.isDebugEnabled()) {
                logger.debug(paramPersistable + " is in the first version");
            }
            return true;
        }
        if(!StringUtils.isEmpty(ChangeTaskUtils.getChangeRecord(paramPersistable, currentActivity).getDescription())) {
            if (logger.isDebugEnabled()) {
                logger.debug("Comment is not empty for resulting object - " + paramPersistable);
            }
            return true;
        }
        String number = getNumber(paramPersistable);
        Set<Object> affectedObjects = ChangeTaskUtils.getAffectedObjects(currentActivity, false);
        for (Object affectedObject : affectedObjects) {
            AffectedActivityData affectedActivityDataLink = (AffectedActivityData) affectedObject;
            //check if given resulting object is attached also as affected activity data, check the comment
            if (StringUtils.equals(getNumber(affectedActivityDataLink.getRoleBObject()), number)) {
                if (!StringUtils.isEmpty(affectedActivityDataLink.getDescription())) {
                    if (logger.isDebugEnabled()) {
                        logger.debug("Comment is not empty for affected activity data - " + affectedActivityDataLink.getRoleBObject());
                    }
                    return true;
                }
            }
        }
        paramList.add(new RuleFeedbackMessage(new WTMessage(RESOURCE, BusinessRuleRB.NO_CHANGE_TEXT_DEFINED, null), getFeedbackType()));
        if (logger.isDebugEnabled()) {
            logger.debug("Comment is empty for " + paramPersistable);
        }
        return false;
    }

    @Override
    public void prepareForValidation(RuleValidationKey ruleValidationKey, RuleValidationCriteria ruleValidationCriteria) throws WTException {
        if (logger.isDebugEnabled()) {
            logger.debug("entering prepareForValidation(RuleValidationKey,RuleValidationCriteria)");
            logger.debug("ruleValidationKey: " + ruleValidationKey);
            logger.debug("ruleValidationCriteria: " + ruleValidationCriteria);
        }
        ruleValidationKey.addToProcessingMap(ECT, (WTChangeActivity2) ruleValidationCriteria.getPrimaryBusinessObject());
        if (logger.isDebugEnabled()) {
            logger.debug("exiting prepareForValidation()");
        }
    }

    private String getNumber(Persistable persistable) {
        if (persistable instanceof WTDocument) {
            return ((WTDocument) persistable).getNumber();
        } else if (persistable instanceof EPMDocument) {
            return ((EPMDocument) persistable).getNumber();
        } else if (persistable instanceof WTPart) {
            return ((WTPart) persistable).getNumber();
        }
        return "";
    }

	@Override
	public boolean isRulesValid(Persistable paramPersistable,
			Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList) throws WTException {
		// TODO Auto-generated method stub
		return false;
	}
}
