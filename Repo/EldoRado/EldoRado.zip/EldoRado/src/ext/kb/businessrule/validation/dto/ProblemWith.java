package ext.kb.businessrule.validation.dto;

public enum ProblemWith {

	SELF,REVISIONS, NORELEASETARGET, RELEASETARGET
}
