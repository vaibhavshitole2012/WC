package ext.kb.businessrule.validation;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;

import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.DocumentVariantHelper;
import ext.kb.util.KBConstants;
import ext.kb.util.ObjectRevisionHelper;
import wt.doc.WTDocument;
import wt.fc.Persistable;
import wt.log4j.LogR;
import wt.pom.PersistenceException;
import wt.util.WTException;
import wt.util.WTMessage;

public class KBSourceDocVersionStateValidation extends KBValidation {
	private static final Logger logger = LogR.getLogger(KBSourceDocVersionStateValidation.class.getName());
	@Override
	public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList) throws WTException {

		boolean isRulesValid = true;
		if(DocumentVariantHelper.isVariantDocument(paramPersistable)) {
			logger.debug("Is given document a variant? " + true);
			Persistable sourceDocument = DocumentVariantHelper.getSourceFromVariant(paramPersistable);
			logger.debug("Retrieved source document: " + sourceDocument);
			if (sourceDocument != null) {
				if (sourceDocument instanceof WTDocument && paramPersistable instanceof WTDocument) {
					isRulesValid = isStateValid((WTDocument) paramPersistable, (WTDocument) sourceDocument);
					logger.debug("Is transition valid? " + isRulesValid);
					if (!isRulesValid) {
						paramList.add(new RuleFeedbackMessage(
								new WTMessage(RESOURCE, BusinessRuleRB.SOURCE_VARIANT_INVALID_STATE, new Object[] {}),
								getFeedbackType()));
					}
				}
			}
		}
		return isRulesValid;

	}

	/**
	 * Method comparing state of source document and target state of variant
	 * document for the same and different revisions
	 * 
	 * @param variantDocument
	 *            Variant document
	 * @param sourceDocument
	 *            Source document
	 * @return status of compare
	 * @throws WTException 
	 * @throws PersistenceException 
	 * 
	 */
	private boolean isStateValid(WTDocument variantDocument, WTDocument sourceDocument) throws PersistenceException, WTException {
		boolean status = false;
		WTDocument sourceWithSameRevOfVar ;
		String sourceDocState = sourceDocument.getState().toString();
		logger.debug("Source state is: " + sourceDocState);
		sourceWithSameRevOfVar = DocumentVariantHelper.getSourceDocWithSameRevisionOfVariant(variantDocument , sourceDocument);
		boolean isSameRevision = ObjectRevisionHelper.isTheSameRevision(variantDocument, sourceWithSameRevOfVar);
		logger.debug("Is same revision : " + isSameRevision);
		if (isSameRevision && (sourceWithSameRevOfVar.getLifeCycleState().toString().equals(KBConstants.INVALID) || sourceWithSameRevOfVar.getLifeCycleState().toString().equals(KBConstants.RELEASED)))
			status = true;
		logger.debug("Returning status: " + status);
		return status;
	}

}
