package ext.kb.businessrule.validation;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.core.businessRules.feedback.RuleFeedbackType;
import com.ptc.windchill.uwgm.common.container.OrganizationHelper;

import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.KBConstants;
import ext.kb.util.KBTypeIdProvider;
import wt.doc.WTDocument;
import wt.epm.EPMDocument;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.inf.container.WTContainerRef;
import wt.log4j.LogR;
import wt.org.WTOrganization;
import wt.pds.StatementSpec;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.representation.PublishedContentLink;
import wt.util.WTAttributeNameIfc;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.vc.Iterated;
import wt.vc.IterationInfo;
import wt.vc.config.LatestConfigSpec;

public class KBEpmAssociatedNeutralDataValidation extends KBValidation {

	protected static final Logger LOG = LogR.getLogger(KBEpmAssociatedNeutralDataValidation.class.getName());

	public KBEpmAssociatedNeutralDataValidation() {
		setFeedbackType(RuleFeedbackType.ERROR);
	}

	/*
	 * This method executes 2 constraints on an EPMDocument First it can have
	 * associated parts, when it is not marked as phantom, secondly when it is
	 * of type Drawing it must have associtated parts
	 */
	@Override
	public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList) throws WTException {

		if (LOG.isDebugEnabled()) {
			LOG.debug("entering isRulesValid(Persistable,Map<String,Set<AttributeRuleSet>>,List<RuleFeedbackMessage>)");
			LOG.debug("paramPersistable: " + paramPersistable);
			LOG.debug("paramMap: " + paramMap);
			LOG.debug("paramList: " + paramList);
		}
		boolean isRuleValid = true;

		EPMDocument epmDoc = (EPMDocument) paramPersistable;
		String epmContainer = epmDoc.getContainerName();

		QueryResult result = PersistenceHelper.manager.navigate(epmDoc,
				PublishedContentLink.PUBLISHED_CONTENT_HOLDER_ROLE, PublishedContentLink.class, true);
		while (result.hasMoreElements()) {
			Object o = result.nextElement();
			if (o instanceof WTDocument) {
				WTDocument wtDoc = (WTDocument) o;
				if (LOG.isDebugEnabled()) {
					LOG.debug("doc :" + wtDoc);
					LOG.debug("ContainerName :" + wtDoc.getContainerName());
				}
				String epmIdentity = epmDoc.getIdentity();
				String wtDocIdentity = wtDoc.getIdentity();
				String wtDocContainer = wtDoc.getContainerName();
				if (LOG.isDebugEnabled()) {
					LOG.debug("epmIdentity " + epmIdentity);
					LOG.debug("wtDocIdentity " + wtDocIdentity);
					LOG.debug("wtDocNumber " + wtDoc.getNumber());
					LOG.debug("wtDocContainer " + wtDocContainer);
					LOG.debug("epmContainer " + epmContainer);
					LOG.debug("returning false");
				}
				if (!epmContainer.equals(wtDoc.getContainerName())) {

					paramList
							.add(new RuleFeedbackMessage(
									new WTMessage(RESOURCE, BusinessRuleRB.KBCAD_NEUTRAL_DATA_ASSOCIATED,
											new Object[] { wtDocContainer }),
									getFeedbackType()));
					return false;
				}

			}
		}
		String epmNumber = epmDoc.getNumber();
	//	WTContainerRef containerReference = epmDoc.getContainerReference();
		WTDocument wtDoc = (WTDocument) getLatestIteration(epmNumber);
		String epmIdentity = epmDoc.getIdentity();
		
		if (LOG.isDebugEnabled()) {
			LOG.debug("epmIdentity " + epmIdentity);
			LOG.debug("epmContainer " + epmContainer);
			LOG.debug("returning false");
		}
		if (wtDoc != null) {
			String wtDocIdentity = wtDoc.getIdentity();
			String wtDocContainer = wtDoc.getContainerName();
			if (LOG.isDebugEnabled()) {
				LOG.debug("epmIdentity " + epmIdentity);
				LOG.debug("wtDocIdentity " + wtDocIdentity);
				LOG.debug("wtDocNumber " + wtDoc.getNumber());
				LOG.debug("wtDocContainer " + wtDocContainer);
				LOG.debug("epmContainer " + epmContainer);
				LOG.debug("returning false");
			}
			if (!epmContainer.equals(wtDoc.getContainerName())) {
				paramList
						.add(new RuleFeedbackMessage(
								new WTMessage(RESOURCE, BusinessRuleRB.KBCAD_NEUTRAL_DATA_ASSOCIATED,
										new Object[] { epmIdentity, wtDocIdentity, wtDocContainer }),
								getFeedbackType()));
				return false;
			}
		}
		if (LOG.isDebugEnabled()) {
			LOG.debug("exiting isRulesValid()");
			LOG.debug("returning: " + isRuleValid);
		}

		return isRuleValid;
	}

	protected Iterated getLatestIteration(String number) throws WTException {

		if (LOG.isDebugEnabled()) {
			LOG.debug("entering getLatestIteration(String,String)");
			LOG.debug("number: \"" + number + "\"");
			//LOG.debug("theAttribValue2: \"" + theAttribValue2 + "\"");
		}
		WTDocument latestIteration = null;

		try {
			int[] fromIndicies = { 0, 1 };
			QuerySpec qs = new QuerySpec(WTDocument.class);
			qs.appendWhere(new SearchCondition(WTDocument.class, WTDocument.NUMBER, SearchCondition.EQUAL, number),
					fromIndicies);
			qs.appendAnd();
			/*if ((WTDocument.CONTAINER_ID != null) && (theAttribValue2 != null)) {
				// Parasing the WTContainer Reference to just the ID
				theAttribValue2 = theAttribValue2.substring(theAttribValue2.indexOf(":") + 1, theAttribValue2.length());
				Long id = new Long(theAttribValue2);
				qs.appendWhere(
						new SearchCondition(WTDocument.class, WTDocument.CONTAINER_ID, SearchCondition.EQUAL, id),
						fromIndicies);
				qs.appendAnd();
			}
			WTOrganization org = null;
			try {
				org = OrganizationHelper.getOrganizationByName("HVAC");
			} catch (WTException e) {
				LOG.info("Organization has not been found");
			}
			qs.appendWhere(new SearchCondition(WTDocument.class,
					"master>organizationReference" + '.' + WTAttributeNameIfc.REF_OBJECT_ID, SearchCondition.EQUAL,
					PersistenceHelper.getObjectIdentifier(org).getId()), fromIndicies);
			qs.appendAnd();*/
			qs.appendWhere(new SearchCondition(WTDocument.class, Iterated.ITERATION_INFO + "." + IterationInfo.LATEST,
					SearchCondition.IS_TRUE), fromIndicies);
			LatestConfigSpec latestConfigSpec = new LatestConfigSpec();
			qs = latestConfigSpec.appendSearchCriteria(qs);
			QueryResult qr = PersistenceHelper.manager.find((StatementSpec) qs);
			qr = latestConfigSpec.process(qr);

			if (qr.size() == 1) {
				latestIteration = (WTDocument) qr.nextElement();
			} else if (qr.size() != 0) {
				while (qr.hasMoreElements()) {
					Iterated iterated = (Iterated) qr.nextElement();
					if (iterated instanceof WTDocument) {
						WTDocument doc = (WTDocument) iterated;
						//if (doc.getOrganizationName().equalsIgnoreCase(KBConstants.HVAC)) {
							latestIteration = doc;
							break;
						//}
					}
				}

			}
		} catch (Exception e) {
			throw new WTException(e, "Exception searching for latest iteration");
		}

		if (latestIteration != null && !KBTypeIdProvider.isDescendant(latestIteration, "TECHDRWDOC")) {
			latestIteration = null;
		}
		/*if (latestIteration != null) {
			if (!latestIteration.getOrganizationName().equalsIgnoreCase(KBConstants.HVAC)) {
				latestIteration = null;
			}
		}*/

		if (LOG.isDebugEnabled()) {
			LOG.debug("exiting getLatestIteration()");
			LOG.debug("returning: " + latestIteration);
		}
		return latestIteration;
	}
}
