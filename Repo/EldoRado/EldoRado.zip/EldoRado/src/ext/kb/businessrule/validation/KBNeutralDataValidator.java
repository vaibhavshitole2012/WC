package ext.kb.businessrule.validation;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.ObjectRevisionHelper;
import ext.kb.workflow.EPMChangeUtils;
import wt.doc.WTDocument;
import wt.epm.EPMDocument;
import wt.fc.Persistable;
import wt.util.WTException;
import wt.util.WTMessage;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class KBNeutralDataValidator extends KBValidation {

    private static final String HVAC = "HVAC";

    @Override
    public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap, List<RuleFeedbackMessage> paramList) throws WTException {
        boolean isValid = true;
        EPMDocument epmDocument = (EPMDocument) paramPersistable;
        String orgName = epmDocument.getOrganization().getName();
        logger.debug("epmDocument: " + epmDocument.getNumber());
        logger.debug("Organization:" + orgName);
        if (HVAC.equalsIgnoreCase(orgName) && !isValidObject(epmDocument)) {
            isValid = false;
            paramList.add(getMessage());
        }
        logger.debug("Result of KBNeutralDataValidator" + isValid);
        logger.debug("paramList" + paramList);
        return isValid;
    }

    private boolean isValidObject(EPMDocument epmDocument) throws WTException {
        WTDocument neutralData = EPMChangeUtils.getNeutralData(epmDocument);
        EPMDocument predecessor = (EPMDocument) ObjectRevisionHelper.getPreviousVersionLatestIteration(epmDocument);
        WTDocument predecessorNeutralData = predecessor != null ? EPMChangeUtils.getNeutralData(predecessor) : null;
        String neutralDataNumber = neutralData != null ? neutralData.getNumber() : null;
        if (neutralData != null || predecessorNeutralData != null) {
            logger.debug("NeutralDataNumber:" + neutralDataNumber);
            return false;
        }
        return true;
    }

    private RuleFeedbackMessage getMessage() {
        return new RuleFeedbackMessage(new WTMessage(RESOURCE, BusinessRuleRB.KB_NEUTRAL_DATA_RULE, null), getFeedbackType());
    }
}
