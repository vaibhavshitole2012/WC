package ext.kb.businessrule.validation.specific;

import com.ptc.core.businessRules.validation.RuleValidationKey;
import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;
import wt.fc.BinaryLink;
import wt.log4j.LogR;
import wt.part.LineNumber;
import wt.part.WTPartUsageLink;
import wt.util.WTException;

import java.util.List;

public class CheckInFillLineNumbersExecutable extends AutoFillLineNumbersExecutable {


    private static final Logger LOGGER = LogR.getLogger(CheckInFillLineNumbersExecutable.class.getName());

    /*
     * Responsible for checking if find and lineNumber attributes
     * are set.In case they are empty it fills them out with values
     * in a specific order.
     */
    @Override
    public void executeSpecific(WTPartUsageLink link,
                                List<BinaryLink> linksOnSameLevel, RuleValidationKey paramRuleValidationKey) throws WTException {
        LOGGER.debug("inside CheckInFillLineNumbersExecutable = " + link);
        LineNumber lineNumber = link.getLineNumber();
        if (null != lineNumber) {
            return;
        }
        int nrOfUpdatedLineNumbers = super.executeFixOnLineNumber(link, linksOnSameLevel);
        LOGGER.debug("nrOfUpdatedFindNumbers = " + nrOfUpdatedLineNumbers);
    }

    @Override
    public void executeSpecificPreProcess(final List<BinaryLink> links) {
        if (!CollectionUtils.isEmpty(links)) {
            sortBeforeProcess(links);
        }
    }

    private void sortBeforeProcess(final List<BinaryLink> links) {
        WTPartUsageLinkSorter sorter = new WTPartUsageLinkSorter(links);
        sorter.sortByNumberGeklaAndBuildStatus();
    }
}
