package ext.kb.businessrule.validation;

import java.util.List;

import com.ptc.core.businessRules.validation.RuleValidationKey;

import wt.fc.BinaryLink;
import wt.part.WTPartUsageLink;
import wt.util.WTException;

public interface PartUsageLinkLogicExecutable {

	public void executeSpecific(WTPartUsageLink link,List<BinaryLink> linksOnSameLevel, RuleValidationKey paramRuleValidationKey) throws WTException;
	
	public boolean isOnlyToplevel();
	
	public void executeSpecificPreProcess(List<BinaryLink> links) throws WTException;
}
