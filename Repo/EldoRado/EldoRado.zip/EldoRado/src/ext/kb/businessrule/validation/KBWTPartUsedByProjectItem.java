package ext.kb.businessrule.validation;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import ext.kb.util.KBTypeIdProvider;
import org.apache.log4j.Logger;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.part.WTPart;
import wt.part.WTPartUsageLink;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.vc.config.LatestConfigSpec;
import wt.vc.struct.StructHelper;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static ext.kb.resources.BusinessRuleRB.NO_PROJECT_ITEM;
import static ext.kb.util.KBConstants.PROJECT_ITEM_TYPE;

public class KBWTPartUsedByProjectItem extends KBValidation {

    private static final Logger LOG = Logger.getLogger(KBWTPartWhereUsedStateValidator.class);

    @Override
    public boolean isRulesValid(Persistable persistable, Map<String, Set<AttributeRuleSet>> paramMap, List<RuleFeedbackMessage> paramList) throws WTException {
        WTPart child = (WTPart) persistable;
        Set<WTPart> list = new HashSet<>();
        LOG.debug("validating part number: " + child.getNumber());
        Set<WTPart> parents = getParentParts(child, list);
        LOG.debug("found parents " + parents.size());
        for (WTPart part : parents) {
            boolean isProjectItem = KBTypeIdProvider.isDescendant(part, PROJECT_ITEM_TYPE);
            LOG.debug("parent part" + part.getNumber() + "is project item " + isProjectItem);
            if (isProjectItem) {
                return true;
            }
        }
        WTMessage message = new WTMessage(RESOURCE, NO_PROJECT_ITEM, new Object[]{});
        paramList.add(new RuleFeedbackMessage(message, getFeedbackType()));
        LOG.debug("validating part has no Project Item: " + child.getNumber());
        return false;
    }


    private Set<WTPart> getParentParts(WTPart childPart, Set<WTPart> parents) throws WTException {
        QueryResult result = StructHelper.service
                .navigateUsedByToIteration(childPart, WTPartUsageLink.class, true, new LatestConfigSpec());
        while (result.hasMoreElements()) {
            WTPart part = (WTPart) result.nextElement();
            if (!parents.contains(part)) {
                parents.add(part);
                getParentParts(part, parents);
            }
        }
        return parents;
    }

}
