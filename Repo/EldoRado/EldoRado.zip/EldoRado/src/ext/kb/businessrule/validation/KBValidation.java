package ext.kb.businessrule.validation;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import org.apache.log4j.Logger;

import wt.fc.BinaryLink;
import wt.fc.Persistable;
import wt.fc.WTReference;
import wt.log4j.LogR;
import wt.util.WTException;

import com.ptc.core.businessRules.attributes.AttributeRuleBean;
import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.core.businessRules.feedback.RuleFeedbackType;
import com.ptc.core.businessRules.validation.RuleValidation;
import com.ptc.core.businessRules.validation.RuleValidationCriteria;
import com.ptc.core.businessRules.validation.RuleValidationKey;
import com.ptc.core.businessRules.validation.RuleValidationObject;
import com.ptc.core.businessRules.validation.RuleValidationResult;
import com.ptc.core.businessRules.validation.RuleValidationStatus;

public abstract class KBValidation implements RuleValidation {
	
	protected static final String ECT = "ECT";

    protected static final Logger logger = LogR.getLogger(KBValidation.class.getName());
    
    protected static final String RESOURCE = "ext.kb.resources.BusinessRuleRB";
    
    private RuleFeedbackType feedbackType = RuleFeedbackType.ERROR;

    private Map<RuleValidationKey, AttributeRuleBean> attributeRuleBeans = new HashMap<RuleValidationKey, AttributeRuleBean>();

    public RuleFeedbackType getFeedbackType() {
        return feedbackType;
    }

    public void setFeedbackType(RuleFeedbackType feedbackType) {
        this.feedbackType = feedbackType;
    }

    @Override
    public Class[] getSupportedClasses(RuleValidationKey arg0) {

        AttributeRuleBean bean = getAttributeRuleBean(arg0);
        if (attributeRuleBeans.size() == 1) {
            return new Class[] { bean.getObjecTypeClass() };
        }
        Iterator<Entry<RuleValidationKey, AttributeRuleBean>> it = attributeRuleBeans.entrySet().iterator();
        Class[] classes = new Class[attributeRuleBeans.size()];
        int i = 0;
        while (it.hasNext()) {
            classes[i++] = it.next().getValue().getObjecTypeClass();
        }
        return classes;
    }

    @Override
    public RuleValidationResult performValidation(RuleValidationKey paramRuleValidationKey,
            RuleValidationObject paramRuleValidationObject, RuleValidationCriteria paramRuleValidationCriteria) throws WTException {
        RuleValidationStatus ruleValidationStatus = RuleValidationStatus.SUCCESS;

        WTReference targetObject = paramRuleValidationObject.getTargetObject();

        AttributeRuleBean attributeRuleBean = getAttributeRuleBean(paramRuleValidationKey);

        if (BinaryLink.class.isAssignableFrom(attributeRuleBean.getClass())) {
            logger.debug("Processing target link");
            targetObject = paramRuleValidationObject.getTargetObjectLink();
        }

        RuleValidationResult ruleValidationResult = new RuleValidationResult(ruleValidationStatus);

        List<RuleFeedbackMessage> feedbackMessages = new ArrayList<RuleFeedbackMessage>();

        if ((attributeRuleBean.isValidObjectType(targetObject.getObject()))
                && (!isRulesValid(targetObject.getObject(), attributeRuleBean.getAttributeRules(), feedbackMessages, paramRuleValidationKey))) {
            logger.debug("Attribute rules for object are not valid setting result status to failed.");

            ruleValidationResult.setStatus(RuleValidationStatus.FAILURE);

            ruleValidationResult.addFeedbackMessages(feedbackMessages);
        }

        ruleValidationResult.setTargetObject(targetObject);

        ruleValidationResult.setValidationKey(paramRuleValidationKey);

        return ruleValidationResult;
    }

    protected AttributeRuleBean getAttributeRuleBean(RuleValidationKey paramRuleValidationKey) {
        AttributeRuleBean bean = attributeRuleBeans.get(paramRuleValidationKey);
        if (bean == null) {
            bean = AttributeRuleBean.newAttributeRuleBean(paramRuleValidationKey);
            attributeRuleBeans.put(paramRuleValidationKey, bean);
        }
        return bean;
    }

    @Override
    public boolean isConfigurationValid(RuleValidationKey paramRuleValidationKey) throws WTException {
        return getAttributeRuleBean(paramRuleValidationKey).isAttributeRuleConfigValid();
    }

    @Override
    public void prepareForValidation(RuleValidationKey arg0, RuleValidationCriteria arg1) throws WTException {
        // maybe load valid Materials eagerly from lib?, moving into abstract
        // impl as not needed currently.
    }

    public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
            List<RuleFeedbackMessage> paramList, RuleValidationKey paramRuleValidationKey) throws WTException {
    	return isRulesValid(paramPersistable, paramMap, paramList);
    }
    
    public abstract boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
            List<RuleFeedbackMessage> paramList) throws WTException;
}
