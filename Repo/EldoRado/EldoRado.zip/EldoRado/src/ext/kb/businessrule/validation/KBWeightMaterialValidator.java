package ext.kb.businessrule.validation;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import java.util.Set;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.core.businessRules.feedback.RuleFeedbackType;
import com.ptc.core.businessRules.validation.RuleValidationCriteria;
import com.ptc.core.businessRules.validation.RuleValidationKey;
import com.ptc.generic.iba.AttributeService;

import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.KBType;
import ext.kb.workflow.ChangeTaskUtils;
import wt.change2.ChangeRecord2;
import wt.change2.WTChangeActivity2;
import wt.fc.Persistable;
import wt.lifecycle.Transition;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.WTProperties;

public class KBWeightMaterialValidator extends KBValidation {

	private static final Map<String, List<String>> VALID_TYPES;
	private static final String COMMA = ",";
	private static final String PROPERTY_NAME = "ext.kb.businessrule.validation.weightmaterialrule.doccontenttypes";
	private static final Logger logger = Logger.getLogger(KBWeightMaterialValidator.class);
	private static final Transition RELEASE_TARGET_1050 = Transition.toTransition("1050");

	static {
		VALID_TYPES = new HashMap<>();
		VALID_TYPES.put("com.ptc.KBTechnicalDrawing", Arrays.asList("KB_WEIGHT"));
		VALID_TYPES.put("com.ptc.DesignCADDrw", Arrays.asList("KB_WEIGHT", "KB_MATERIAL_PRIMARY"));
	}

	public KBWeightMaterialValidator() {
		setFeedbackType(RuleFeedbackType.WARNING);
	}

	@Override
	public boolean isRulesValid(Persistable persistable, Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList, RuleValidationKey validationKey) throws WTException {
		logger.debug("Validation: " + BusinessRuleRB.WEIGHT_MATERIAL_RULE);
		String property = null;
		WTChangeActivity2 currentECT = (WTChangeActivity2) validationKey.getProcessingMapValue(ECT);
		ChangeRecord2 childChengeRecord = ChangeTaskUtils.getChangeRecord(persistable, currentECT);
		Transition targetTransition = childChengeRecord.getTargetTransition();
		try {
			WTProperties localProperties = WTProperties.getLocalProperties();
			property = localProperties.getProperty(PROPERTY_NAME);
			logger.debug("property loaded successfully: " + PROPERTY_NAME);
		} catch (IOException e) {
			logger.debug("cannot load property: " + PROPERTY_NAME);
			logger.debug(e);
		}
		if (property != null && RELEASE_TARGET_1050 == targetTransition) {
			Set<String> keySet = VALID_TYPES.keySet();
			List<String> contentTypes = Arrays.asList(property.split(COMMA));
			String[] validTypesTab = keySet.toArray(new String[keySet.size()]);
			Object contentType = AttributeService.getAttribute(persistable, "KB_DOC_CONTENT_TYPE");

			if (contentTypes.contains(contentType) && KBType.isOneOfTypes(persistable, validTypesTab)) {
				logger.debug("Contains valid type and requaried contentType " + contentType);

				String type = KBType.getType(persistable);
				List<String> attributes = VALID_TYPES.get(type);
				if (!hasValidAttributes(persistable, attributes)) {
					paramList.add(new RuleFeedbackMessage(
							new WTMessage(RESOURCE, BusinessRuleRB.WEIGHT_MATERIAL_RULE, null), getFeedbackType()));
					logger.debug("Object is not valid");
					return false;
				}
			}
		}
		return true;
	}

	@Override
	public void prepareForValidation(RuleValidationKey validationKey, RuleValidationCriteria paramRuleValidationCriteria)
			throws WTException {
		logger.debug("preparing valdation for WeighMaterialValidator");
		WTChangeActivity2 currentECT = (WTChangeActivity2) paramRuleValidationCriteria.getPrimaryBusinessObject();
		validationKey.addToProcessingMap(ECT, currentECT);
		logger.debug("Checking weight and material attributes for ECT:" + currentECT.getNumber());

	}

	/**
	 * Checking if attributes are not null or empty
	 * 
	 * @param persistable
	 *            - validated object
	 * @param attributes
	 *            - checked attributes
	 * @return true if all attributes are not null otherwise return false
	 * 
	 */
	private boolean hasValidAttributes(Persistable persistable, List<String> attributes) {
		for (String attributeName : attributes) {
			if (AttributeService.isEmpty(persistable, attributeName)) {
				logger.debug("object has invalid attributes");
				return false;
			}
		}
		return true;
	}

	@Override
	public boolean isRulesValid(Persistable paramPersistable,
			Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList) throws WTException {
		// TODO Auto-generated method stub
		return false;
	}

}
