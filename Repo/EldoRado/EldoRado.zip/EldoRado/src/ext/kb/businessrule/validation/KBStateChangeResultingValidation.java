package ext.kb.businessrule.validation;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import wt.doc.WTDocument;
import wt.enterprise.RevisionControlled;
import wt.fc.Persistable;
import wt.part.WTPart;
import wt.util.WTException;
import wt.util.WTMessage;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.core.businessRules.feedback.RuleFeedbackType;
import com.ptc.generic.iba.AttributeService;

import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.KBTypeIdProvider;
import ext.kb.util.KBUtils;

public class KBStateChangeResultingValidation extends KBValidation {

	private static final Logger LOG = Logger.getLogger(KBStateChangeResultingValidation.class);
	/*
	 * Only WTParts and WTDocs with KB_DOC_CONTENT_TYPEs 700 ("Order Block") or 541 ("Release Report") 
	 * are allowed as resulting objects (i.e. no CAD Documents, no other WTDocs)
	 * (non-Javadoc)
	 * 
	 * @see
	 * ext.kb.businessrule.validation.KBValidation#isRulesValid(wt.fc.Persistable
	 * , java.util.Map, java.util.List)
	 */
	@Override
	public boolean isRulesValid(Persistable paramPersistable,Map<String, Set<AttributeRuleSet>> paramMap, List<RuleFeedbackMessage> paramList) throws WTException {
		if (LOG.isDebugEnabled()){
			LOG.debug("entering isRulesValid(Persistable, Map, List);");
		}
		if (KBTypeIdProvider.isDescendant(paramPersistable, "ARTICLE")){
			if (LOG.isDebugEnabled()){
				LOG.debug("Article: " + ((WTPart)paramPersistable).getNumber() + " rule is valid");
			}
			return true;
		} else if (KBTypeIdProvider.isDescendant(paramPersistable, "KBDOC")){
			Object contentType = AttributeService.getAttribute(paramPersistable, "KB_DOC_CONTENT_TYPE");
			if ("700".equals(contentType) || "541".equals(contentType)){
				if (LOG.isDebugEnabled()){
					LOG.debug("Document: " + ((WTDocument)paramPersistable).getNumber() + " with valid content type " + contentType + ", rule is valid");
				}
				return true;
			}
			if (LOG.isDebugEnabled()){
				LOG.debug("Document: " + ((WTDocument)paramPersistable).getNumber() + " with NOT valid content type " + contentType + ", rule is NOT valid");
			}
		}
		if (LOG.isDebugEnabled()){
			LOG.debug("Object: " + KBUtils.getIdentityWithStateAndRevision((RevisionControlled) paramPersistable) + ", rule is NOT valid.");
		}
		paramList.add(new RuleFeedbackMessage(new WTMessage(RESOURCE, BusinessRuleRB.KBSCT_ALLOWED_OBJECTS, new Object[]{}), RuleFeedbackType.ERROR));
		return false;
	}

}
