package ext.kb.businessrule.validation;

import com.ptc.core.businessRules.attributes.AttributeRuleRB;
import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.generic.iba.AttributeService;
import ext.kb.util.KBConstants;
import ext.kb.util.KBTypeIdProvider;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import wt.epm.EPMDocument;
import wt.epm.EPMDocumentMaster;
import wt.fc.Persistable;
import wt.log4j.LogR;
import wt.util.WTException;
import wt.util.WTMessage;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class KBCadDrawingRequiredAttributeRule extends KBValidation {

    protected static final Logger LOG = LogR.getLogger(KBCadDrawingRequiredAttributeRule.class.getName());
    private static final String ATTRIBUTE_RULE_RESOURCE = "com.ptc.core.businessRules.attributes.AttributeRuleRB";
    public static final String KBCADDRW = "KBCADDRW";

    @Override
    public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
                                List<RuleFeedbackMessage> paramList) throws WTException {
        if (LOG.isDebugEnabled()) {
            LOG.debug("paramPersistable: " + paramPersistable);
            LOG.debug("paramMap: " + paramMap);
            LOG.debug("paramList: " + paramList);
        }
        boolean isValid = true;
        if (paramPersistable instanceof EPMDocument && KBTypeIdProvider.isDescendant(paramPersistable, KBCADDRW)) {
            isValid = isValidObject((EPMDocument) paramPersistable, paramList);
        }
        if (LOG.isDebugEnabled()) {
            LOG.debug("paramPersistable: " + paramPersistable);
            LOG.debug("returning: " + isValid);
            LOG.debug("paramList: " + paramList);
        }
        return isValid;
    }

    private boolean isValidObject(EPMDocument epmDoc, List<RuleFeedbackMessage> paramList) {
        boolean isValid;
        String docContentType = AttributeService.getAttribute(epmDoc, KBConstants.DOC_CONTENT_TYPE);
        EPMDocumentMaster master = (EPMDocumentMaster) epmDoc.getMaster();
        String sapIdx = AttributeService.getAttribute(master, KBConstants.KBSAP_IDX_IBA);
        String kbDocumentId = AttributeService.getAttribute(master, KBConstants.KBDOCUMENT_ID_IBA);

        if ((!KBConstants.KB.equals(epmDoc.getOrganizationName())) && StringUtils.isEmpty(docContentType)) {
            addErrorMessage(paramList, "DOC content type");
        }
        if (StringUtils.isEmpty(sapIdx)) {
            addErrorMessage(paramList, "SAP Sub Index");
        }
        if (StringUtils.isEmpty(kbDocumentId)) {
            addErrorMessage(paramList, "KB Doc. ID");
        }
        isValid = CollectionUtils.isEmpty(paramList);
        if (LOG.isDebugEnabled()) {
            LOG.debug("Sap idx:'" + sapIdx + "', kbDocumentId :'" + kbDocumentId + "',docContentType:"
                    + docContentType + ",");
        }
        return isValid;
    }

    private void addErrorMessage(List<RuleFeedbackMessage> paramList, String errorMessage) {
        paramList.add(new RuleFeedbackMessage(new WTMessage(ATTRIBUTE_RULE_RESOURCE,
                AttributeRuleRB.NOT_SET_ERROR_MSG, new Object[]{errorMessage}),
                getFeedbackType()));
    }

}
