package ext.kb.businessrule.validation;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;

import wt.epm.EPMDocument;
import wt.epm.EPMDocumentMaster;
import wt.fc.Persistable;
import wt.log4j.LogR;
import wt.util.WTException;
import wt.util.WTMessage;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;

import ext.kb.util.IBAHelper;
import ext.kb.util.KBConstants;
import ext.kb.util.KBTypeIdProvider;

public class KBCadDocAttributeValidator extends KBValidation {

	protected static final Logger LOG = LogR.getLogger(KBCadDocAttributeValidator.class.getName());
	
	@Override
	public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList) throws WTException {
		boolean isValid = true;
		if(paramPersistable instanceof EPMDocument){
			EPMDocument epmDoc = (EPMDocument)paramPersistable;
			boolean isKBCadDoc = KBTypeIdProvider.isDescendant(epmDoc, "KBCADDOC");
			boolean isKBCadDrw = KBTypeIdProvider.isDescendant(epmDoc, "KBCADDRW");
			boolean isKBOrg = "KB".equalsIgnoreCase(epmDoc.getOrganizationName());
			LOG.info("EPMDocument is Cad doc "+ isKBCadDoc);
			LOG.info("EPMDocument is Cad drw "+ isKBCadDrw);
			LOG.info("EPMDocument is in Kb org "+ isKBOrg);
			if((isKBCadDrw && isKBOrg) || (isKBCadDoc && !isKBOrg)){
				isValid = isValid(paramList, epmDoc);
			} 
		}
		return isValid;
	}

	private boolean isValid(List<RuleFeedbackMessage> paramList, EPMDocument epmDoc) {
		boolean isValid;
		EPMDocumentMaster epmDocMaster = (EPMDocumentMaster)epmDoc.getMaster();
		String epmsKbDocumentId = IBAHelper.readIBA(epmDocMaster, KBConstants.KBDOCUMENT_ID_IBA);
		LOG.debug("epmsKbDocumentId: "+ epmsKbDocumentId);
		if (epmsKbDocumentId != null && epmsKbDocumentId.length() > 19){
			paramList.add(new RuleFeedbackMessage(new WTMessage(
					RESOURCE, "KB_EPM_HAS_TOO_LONG_NUMBER", new String[]{epmDoc.getNumber()}),
					getFeedbackType()));
		}
		isValid = CollectionUtils.isEmpty(paramList);
		return isValid;
	}

}
