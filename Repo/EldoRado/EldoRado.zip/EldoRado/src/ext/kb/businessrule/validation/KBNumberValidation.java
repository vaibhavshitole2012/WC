package ext.kb.businessrule.validation;

import java.util.List;
import java.util.Map;
import java.util.Set;

import wt.doc.WTDocument;
import wt.epm.EPMDocument;
import wt.fc.Persistable;
import wt.part.WTPart;
import wt.util.WTException;
import wt.util.WTMessage;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.core.businessRules.feedback.RuleFeedbackType;
import com.ptc.core.meta.common.TypeIdentifierHelper;
import com.ptc.windchill.suma.part.VendorPart;

import ext.kb.resources.NumberValidatorRB;
import ext.kb.util.KBUtils;
import ext.kb.util.SupplierHelper;
import org.apache.log4j.Logger;

public class KBNumberValidation extends KBValidation{

	
	private static final Logger logger = Logger.getLogger(KBNumberValidation.class);
	private static final String NUMBERVALIDATIONRESOURCE = "ext.kb.resources.NumberValidatorRB";
	
	@Override
	public boolean isRulesValid(Persistable paramPersistable,
			Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList) throws WTException {
		
		if (logger.isDebugEnabled()) {
					logger.debug(
							"entering isRulesValid(Persistable,Map<String,Set<AttributeRuleSet>>,List<RuleFeedbackMessage>)");
					logger.debug("paramPersistable: " + paramPersistable);
					logger.debug("paramMap: " + paramMap);
					logger.debug("paramList: " + paramList);
				}
		String fieldValue = null;
		if (paramPersistable instanceof WTPart){
			boolean isEbom = KBUtils.isEbomPart(((WTPart) paramPersistable));
			if(!isEbom) {
				logger.debug("Mbom part found, will not validate");
				return true;
			}
			fieldValue = ((WTPart)paramPersistable).getNumber();
			try{
				logger.debug("Inside Part");
				KBUtils.checkPartNumberForInvalidCharacters(fieldValue);
			} catch (Exception e){
				paramList.add(
					new RuleFeedbackMessage(
						new WTMessage(NUMBERVALIDATIONRESOURCE, NumberValidatorRB.INVALID_PART_NUMBER_INPUT, new Object[]{fieldValue}),
						RuleFeedbackType.ERROR));
				if (logger.isDebugEnabled()) {
					logger.debug("exiting isRulesValid()");
					logger.debug("returning: " + false);
				}
				return false;
			}
			
		} else if (paramPersistable instanceof EPMDocument) {
			fieldValue = ((EPMDocument)paramPersistable).getNumber();
			logger.debug("Inside epm");
			try{
				KBUtils.checkNumberForInvalidCharacters(fieldValue);
			} catch (Exception e){
				paramList.add(
					new RuleFeedbackMessage(
						new WTMessage(NUMBERVALIDATIONRESOURCE, NumberValidatorRB.INVALID_INPUT, new Object[]{fieldValue}),
						RuleFeedbackType.ERROR));
				if (logger.isDebugEnabled()) {
					logger.debug("exiting isRulesValid()");
					logger.debug("returning: " + false);
				}
				return false;
			}
			
		} else if (paramPersistable instanceof WTDocument) {
			fieldValue = ((WTDocument)paramPersistable).getNumber();
			logger.debug("Inside WTDoc");
			try{
				KBUtils.checkNumberForInvalidCharacters(fieldValue);
			} catch (Exception e){
				paramList.add(
					new RuleFeedbackMessage(
						new WTMessage(NUMBERVALIDATIONRESOURCE, NumberValidatorRB.INVALID_INPUT, new Object[]{fieldValue}),
						RuleFeedbackType.ERROR));
				if (logger.isDebugEnabled()) {
					logger.debug("exiting isRulesValid()");
					logger.debug("returning: " + false);
				}
				return false;
			}
			
		} else {
			logger.debug("Skipping KBNumberValidation rule for: " + TypeIdentifierHelper.getType(paramPersistable).getTypename());
			if (logger.isDebugEnabled()) {
				logger.debug("exiting isRulesValid()");
				logger.debug("returning: " + true);
			}
			return true;
		}
		
		
		if (paramPersistable instanceof WTPart){
			logger.debug("Inside Proc Part");
			VendorPart procPart = SupplierHelper.getProcurementPart((WTPart)paramPersistable);
			if (procPart != null){
				try{
					KBUtils.checkPartNumberForInvalidCharacters(procPart.getNumber());
					if (!fieldValue.equals(procPart.getNumber())){
						paramList.add(
								new RuleFeedbackMessage(
										new WTMessage(NUMBERVALIDATIONRESOURCE, NumberValidatorRB.ARTICLE_AND_PROC_PART_NUMBER_NOT_EQUAL, new Object[]{fieldValue, procPart.getNumber()}),
										RuleFeedbackType.ERROR));
						if (logger.isDebugEnabled()) {
							logger.debug("exiting isRulesValid()");
							logger.debug("returning: " + false);
						}
						return false;
					}
				} catch (Exception e){
					paramList.add(
							new RuleFeedbackMessage(
									new WTMessage(NUMBERVALIDATIONRESOURCE, NumberValidatorRB.INVALID_INPUT_PROC_PART, new Object[]{procPart.getNumber()}),
									RuleFeedbackType.ERROR));
					if (logger.isDebugEnabled()) {
						logger.debug("exiting isRulesValid()");
						logger.debug("returning: " + false);
					}
					return false;
				}
			}
		}
		if (logger.isDebugEnabled()) {
			logger.debug("exiting isRulesValid()");
			logger.debug("returning: " + true);
		}
		return true;
	}
}
