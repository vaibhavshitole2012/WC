package ext.kb.businessrule.validation;

import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.ptc.core.businessRules.attributes.AttributeRuleSet;
import com.ptc.core.businessRules.feedback.RuleFeedbackMessage;
import com.ptc.core.businessRules.validation.RuleValidationCriteria;
import com.ptc.core.businessRules.validation.RuleValidationKey;

import ext.kb.resources.BusinessRuleRB;
import ext.kb.util.KBUtils;
import ext.kb.util.ObjectRevisionHelper;
import ext.kb.workflow.ChangeTaskUtils;
import wt.change2.ChangeRecord2;
import wt.change2.WTChangeActivity2;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.fc.collections.WTArrayList;
import wt.fc.collections.WTHashSet;
import wt.lifecycle.Transition;
import wt.part.WTPart; 
import wt.part.WTPartUsageLink;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.WTProperties;
import wt.vc.VersionControlHelper;
import wt.vc.config.LatestConfigSpec;
import wt.vc.struct.StructHelper;
 
public class KBWTPartWhereUsedStateValidator extends KBValidation {   
	
	private static final Logger logger = Logger.getLogger(KBWTPartWhereUsedStateValidator.class);
	
	private static final String COMMA = ",";
	private static final Map<String, List<String>> ALLOWED_TARGET_STATES;
	private static final Map<String, String> PROPERTIES;
	private static final String STATE_1030 = "1030"; 
	private static final String STATE_1045 = "1045"; 
	private static final String STATE_1050 = "1050";
	private static final String STATE_1058 = "1058";
	private static final String STATE_1070 = "1070";
	private static final String STATE_1075 = "1075";
	private static final String STATE_1080 = "1080";
	
	static {
		ALLOWED_TARGET_STATES = new HashMap<>();
		PROPERTIES = new HashMap<>();
		PROPERTIES.put(STATE_1030, "ext.kb.businessrule.validation.wtpart.whereused.1030.allowedTargetStates");
		PROPERTIES.put(STATE_1045, "ext.kb.businessrule.validation.wtpart.whereused.1045.allowedTargetStates");
		PROPERTIES.put(STATE_1050, "ext.kb.businessrule.validation.wtpart.whereused.1050.allowedTargetStates");
		PROPERTIES.put(STATE_1058, "ext.kb.businessrule.validation.wtpart.whereused.1058.allowedTargetStates");
		PROPERTIES.put(STATE_1070, "ext.kb.businessrule.validation.wtpart.whereused.1070.allowedTargetStates");
		PROPERTIES.put(STATE_1075, "ext.kb.businessrule.validation.wtpart.whereused.1075.allowedTargetStates");
		PROPERTIES.put(STATE_1080, "ext.kb.businessrule.validation.wtpart.whereused.1080.allowedTargetStates");
	}
 
	@Override
	public boolean isRulesValid(Persistable paramPersistable, Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList, RuleValidationKey validationKey) throws WTException {
		boolean isRuleValid = true;  
		if (paramPersistable instanceof WTPart) {
			boolean isPartValid = true; 
			WTPart child = (WTPart) paramPersistable;
			boolean isEbom = KBUtils.isEbomPart(child);
			if(!isEbom) {
				logger.debug("MBOM Part found, will not validate.");
				return isPartValid;
			}
			String childNumber = child.getNumber();
			QueryResult parentsPart = StructHelper.service.navigateUsedByToIteration(child, WTPartUsageLink.class, true, new LatestConfigSpec());
			WTChangeActivity2 currentECT = (WTChangeActivity2) validationKey.getProcessingMapValue(ECT);
			ChangeRecord2 childChengeRecord = ChangeTaskUtils.getChangeRecord(child, currentECT);
			Transition targetTransition = childChengeRecord.getTargetTransition();
			String childTargetState = null;
			if(targetTransition != null){
				childTargetState = childChengeRecord.getTargetTransition().toString();
			}	 
			QueryResult activitiesFromChangeContext = ChangeTaskUtils.getActivitiesFromChangeContext(currentECT);
			WTHashSet resultingObjects = ChangeTaskUtils.getResultingObjects(activitiesFromChangeContext);
						
			while(parentsPart.hasMoreElements()) {
				WTPart parent = (WTPart) parentsPart.nextElement();
				String parentNumber = parent.getNumber();
                String childView = child.getViewName() != null ? child.getViewName() : StringUtils.EMPTY;
                String parentView = parent.getViewName() != null ? parent.getViewName() : StringUtils.EMPTY;
                logger.debug("Child " + childNumber + " in view " + childView + ", Parent " + parentNumber + " in view "+ parentView);
                if(!childView.equals(parentView)) {
                    logger.debug("Different views, will not validate. ");
                    return true;
                }

                String parentState = parent.getState().toString();
				isPartValid = true;

				if (logger.isDebugEnabled()) {
					logger.debug("Start validation for parent part" + parentNumber);
				}
				if (resultingObjects.contains(parent) && childTargetState != null) {
					WTArrayList activitiesList = new WTArrayList(activitiesFromChangeContext);
					for (Object object : activitiesList) {
						ObjectReference objectReference = (ObjectReference) object;
						WTChangeActivity2 activity = (WTChangeActivity2) objectReference.getObject();
						ChangeRecord2 parentChangeRecord = ChangeTaskUtils.getChangeRecord(parent, activity);						
						if (parentChangeRecord != null) { 
							Transition parentTargetTransition = parentChangeRecord.getTargetTransition();
							if(parentTargetTransition != null){
								String parentTargetState = parentChangeRecord.getTargetTransition().toString();
								isPartValid = isParentPartValid(childTargetState, parentTargetState);
								if (!isPartValid) {
									paramList.add(new RuleFeedbackMessage( new WTMessage(RESOURCE, BusinessRuleRB.WTPART_WHERE_USED_TARGET_STATE,
															new String[] { parentNumber, childNumber }),getFeedbackType()));
									break;
								}
							}
						}
						if (logger.isDebugEnabled()) {
							logger.debug("target state of parent part " + parentNumber + " is valid: " + isPartValid);
						}
					}

				} else if (Integer.valueOf(parentState) > 1020 && childTargetState != null) {
					isPartValid = isParentPartValid(childTargetState, parentState);
					if (!isPartValid) {
						paramList.add(
								new RuleFeedbackMessage(new WTMessage(RESOURCE, BusinessRuleRB.WTPART_WHERE_USED_STATE,
										new String[] { parentNumber, childNumber }), getFeedbackType()));
					}
  
					if (logger.isDebugEnabled()) {
						logger.debug("state of parent part " + parentNumber + " is valid: " + isPartValid);
					}

				} else if (Integer.valueOf(parentState) <= 1020 && childTargetState != null) {
					WTPart previousRevisionPart = getPreviousVersion(parent);
					if (previousRevisionPart != null) {
						logger.debug("previousRevisionPart version-" + previousRevisionPart.getVersionIdentifier().getValue()+" iteration--"+ previousRevisionPart.getIterationIdentifier().getValue());
						String previousRevisionState = ((WTPart) previousRevisionPart).getState().toString();
						logger.debug("state of parent part previousRevisionState-" + previousRevisionState);
						isPartValid = isParentPartValid(childTargetState, previousRevisionState);
						if (!isPartValid) { 
							paramList.add(new RuleFeedbackMessage(
									new WTMessage(RESOURCE, BusinessRuleRB.WTPART_WHERE_USED_PREVIOUS_VERSION_STATE,
											new String[] { parentNumber, childNumber }),getFeedbackType()));
						}
					}
					if (logger.isDebugEnabled()) {
						logger.debug("previous version of parent part " + parentNumber + " is valid: " + isPartValid);
					}
				}
				isRuleValid = (!isPartValid && isRuleValid) ? false : isRuleValid;
			}
		} 
		return isRuleValid;
	} 

	/**
	 * Method comparing state or target state of parent part and target state of child part
	 * 
	 * @param  target state of child part
	 * @param state or target state of parent part
	 * @return status of compare 
	 * 
	 */
	private boolean isParentPartValid(String childTargetState, String parentState) {
		List<String> allowedSet = ALLOWED_TARGET_STATES.get(childTargetState);
		if (allowedSet != null) {
			return allowedSet.contains(parentState);
		} else {
			return false;
		}
	}
	
	
	@Override
	public void prepareForValidation(RuleValidationKey validationKey, RuleValidationCriteria paramRuleValidationCriteria) throws WTException {
		if (logger.isDebugEnabled()) {
					logger.debug("entering prepareForValidation(RuleValidationKey,RuleValidationCriteria)");
					logger.debug("arg0: " + validationKey);
					logger.debug("paramRuleValidationCriteria: " + paramRuleValidationCriteria);
				}				
		loadAllowedStates();
		validationKey.addToProcessingMap(ECT, (WTChangeActivity2) paramRuleValidationCriteria.getPrimaryBusinessObject());
		if (logger.isDebugEnabled()) {
			logger.debug("exiting prepareForValidation()");
		}
	}

	private void loadAllowedStates() {
		try {
			WTProperties localProperties = WTProperties.getLocalProperties();
			String property = null;
			for (Entry<String, String> entry : PROPERTIES.entrySet()) {
				String state = entry.getKey();
				String propertyName = entry.getValue();
				property = localProperties.getProperty(propertyName);
				logger.debug("property loaded successfully: " + propertyName);
				List<String> allowedStates = Arrays.asList(property.split(COMMA));
				ALLOWED_TARGET_STATES.put(state, allowedStates);
			}
		} catch (IOException e) {
			logger.debug("cannot load property: ");
			logger.debug(e);
		}
	}

	@Override
	public boolean isRulesValid(Persistable paramPersistable,
			Map<String, Set<AttributeRuleSet>> paramMap,
			List<RuleFeedbackMessage> paramList) throws WTException {
		return false;
	}
	
	private final WTPart getPreviousVersion(final WTPart currentPart) throws WTException {
		final QueryResult previousVersions = VersionControlHelper.service.allVersionsFrom(currentPart);
		if (!previousVersions.hasMoreElements()) {
			return null;
		} else {
			previousVersions.nextElement();
		}
		if (previousVersions.hasMoreElements()) {
			final WTPart previousVersion = (WTPart) previousVersions.nextElement();
			final String currentPartVersion = currentPart.getVersionIdentifier().getValue();
			final String previousVersionOfPart = previousVersion.getVersionIdentifier().getValue();
			if (!(currentPartVersion.equals(previousVersionOfPart))) {
				return previousVersion;
			}
		}
		return null;
	}
}
