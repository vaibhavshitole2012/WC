package ext.kb.action;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import wt.log4j.LogR;
import wt.part.WTPart;
import wt.util.WTException;

import com.ptc.core.components.beans.FormDataHolder;
import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.FormResult;
import com.ptc.core.components.forms.NameNumberPropertyProcessorHelper;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import com.ptc.windchill.pdmlink.object.operations.pasteAsCopy.forms.PasteFormProcessor;

import ext.kb.util.KBUtils;

public class KBPasteActionFormProcessor extends PasteFormProcessor {

	private static final Logger LOGGER = LogR.getLogger(KBPasteActionFormProcessor.class.getName());
	
	@Override
	public FormResult preProcess(NmCommandBean paramNmCommandBean, List<ObjectBean> paramList) throws WTException {
		FormResult result = super.preProcess(paramNmCommandBean, paramList);
		ObjectBean bean = paramList.get(0);
		if(bean != null) {
			Object objectToCopy = bean.getObject();
			if(LOGGER.isDebugEnabled()){
				LOGGER.debug("objectToCopy is instance of WTPart "+(objectToCopy instanceof WTPart));
			}
			if(objectToCopy instanceof WTPart){
				String newNumber = NameNumberPropertyProcessorHelper.getValueFromFormData((FormDataHolder)paramNmCommandBean, "number");
				if(LOGGER.isDebugEnabled()){
					LOGGER.debug("New number is "+(newNumber));
				}
				if(StringUtils.isNotEmpty(newNumber) && !"(GENERATED)".equals(StringUtils.upperCase(newNumber))){
					KBUtils.checkNumberForInvalidCharactersExtended(StringUtils.upperCase(newNumber));
				}
			}
		}
		return result;
	}
}
