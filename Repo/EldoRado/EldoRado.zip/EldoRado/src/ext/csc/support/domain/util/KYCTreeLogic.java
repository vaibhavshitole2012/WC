package ext.csc.support.domain.util;

import java.awt.Cursor;
import java.awt.DisplayMode;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.lang.reflect.InvocationTargetException;
import java.net.URL;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.Vector;
import javax.imageio.ImageIO;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTree;
import javax.swing.event.TreeExpansionEvent;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.event.TreeWillExpandListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.ExpandVetoException;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;
import wt.access.AccessControlHelper;
import wt.access.AccessControlManager;
import wt.access.AccessPolicyRule;
import wt.access.AclEntryLink;
import wt.access.WTAclEntry;
import wt.admin.AdminDomainRef;
import wt.admin.AdministrativeDomain;
import wt.admin.AdministrativeDomainHelper;
import wt.admin.AdministrativeDomainManager;
import wt.change2.WTChangeActivity2;
import wt.change2.WTChangeIssue;
import wt.change2.WTChangeOrder2;
import wt.change2.WTChangeRequest2;
import wt.enterprise.RevisionControlled;
import wt.fc.ObjectIdentifier;
import wt.fc.ObjectVector;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceManager;
import wt.fc.QueryResult;
import wt.fc.WTObject;
import wt.folder.Cabinet;
import wt.folder.Folder;
import wt.folder.FolderHelper;
import wt.folder.FolderService;
import wt.inf.container.ContainerSpec;
import wt.inf.container.ExchangeContainer;
import wt.inf.container.OrgContainer;
import wt.inf.container.WTContainerHelper;
import wt.inf.container.WTContainerRef;
import wt.inf.container.WTContainerService;
import wt.lifecycle.LifeCycleTemplate;
import wt.lifecycle.State;
import wt.load.LoadServerHelper;
import wt.method.RemoteMethodServer;
import wt.pdmlink.PDMLinkProduct;
import wt.projmgmt.admin.Project2;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.query.template.ReportTemplate;
import wt.team.TeamTemplate;
import wt.util.WTContext;
import wt.util.WTException;
import wt.util.WTProperties;
import wt.workflow.definer.WfTemplateObject;

public class KYCTreeLogic
  implements TreeWillExpandListener, TreeSelectionListener
{
  private JFrame parentComponent;
  private JTree theTree;
  private DefaultTreeModel treeModel;
  private WTObject selectedRootPart;
  private LinkedList rootParts;
  private Hashtable treeHash = new Hashtable();
  private boolean unlimitedTree = false;
  private boolean saveAvailable = true;
  private boolean editedFlag = false;
  private KYCWTObjectNode preOpenNode = null;
  boolean DEBUG = false;

  private String rootLabel = "Ä³ï¿½ï¿½ï¿½" + RENDER_CHECK;
  private String oid;
  public static LinkedList clipboard = new LinkedList();

  protected static Cursor waitCursor = new Cursor(3);
  protected static Cursor defaultCursor = new Cursor(0);

  public static String OPEN_STATUS = "openStatus";
  public static String LOAD_CHILD = "loadChild";
  public static String WATING_NODE = "watingNode";

  public static String NEW_FOLDER = "new_folder";
  public static String DELETE_FOLDER = "delete_folder";
  public static String NEW_DOCUMENT = "new_document";
  public static String NEW_DRAWING = "new_drawing";
  public static String NEW_PART = "new_part";

  public static String VIEW_XML = "view_xml";
  public static String VIEW_CSV = "view_csv";
  public static String EXPORT_XML = "export_xml";
  public static String EXPORT_CSV = "export_csv";
  public static String CLEAR_CHILD = "clear_child";
  public static String REFRESH = "refresh";
  public static String CREATE_DOMAIN = "create_domain";
  public static String REMOVE_DOMAIN = "remove_domain";
  public static String REMOVE_ACCESS = "remove_access";

  public static String RENDER_CHECK = ":@";
  private static final int[] FROM_INDEX = new int[1];

  public KYCTreeLogic(JFrame parentComponent, KYCDraggableTree theTree)
    throws WTException
  {
    this.parentComponent = parentComponent;
    this.theTree = theTree;
    theTree.setLogic(this);

    theTree.addTreeWillExpandListener(this);
    theTree.addTreeSelectionListener(this);
    this.rootParts = new LinkedList();
    resetTree();
  }

  public KYCTreeLogic(JFrame parentComponent, KYCDraggableTree theTree, String sOid)
    throws WTException
  {
    this.parentComponent = parentComponent;
    this.theTree = theTree;
    this.oid = sOid;
    this.selectedRootPart = KYCViewerHelper.getSelectedObject(this.oid);
    clipboard.clear();

    theTree.setLogic(this);

    theTree.addTreeWillExpandListener(this);
    theTree.addTreeSelectionListener(this);

    addRootPart(KYCViewerHelper.getSelectedObject(this.oid));
  }

  public KYCTreeLogic(JFrame parentComponent, KYCDraggableTree theTree, String sOid, String labelName) throws WTException
  {
    this.parentComponent = parentComponent;
    this.theTree = theTree;
    this.oid = sOid;
    this.selectedRootPart = KYCViewerHelper.getSelectedObject(this.oid);
    clipboard.clear();

    if ((labelName != null) && (!labelName.equals(""))) this.rootLabel = (labelName + RENDER_CHECK);

    theTree.setLogic(this);

    theTree.addTreeWillExpandListener(this);
    theTree.addTreeSelectionListener(this);
    addRootPart(KYCViewerHelper.getSelectedObject(this.oid));
  }

  public void addRootPart(WTObject theObject)
    throws WTException
  {
    this.rootParts = new LinkedList();

    this.selectedRootPart = theObject;
    this.rootParts.add(theObject);

    resetTree();
  }

  public QueryResult getSubDomains(WTObject domain) throws WTException
  {
    AdministrativeDomain domainObject = (AdministrativeDomain)domain;
    AdminDomainRef domainRef = new AdminDomainRef();
    domainRef.setObject(domainObject);
    ArrayList list = AdministrativeDomainHelper.manager.getChildDomains(domainRef);

    if ((list == null) || (list.size() == 0)) return null;

    ObjectVector listVector = new ObjectVector();
    for (int i = 0; i < list.size(); i++) {
      listVector.addElement(((AdminDomainRef)list.get(i)).getObject());
    }

    return new QueryResult(listVector);
  }

  public QueryResult getSubFolders(WTObject theFolder)
  {
    try {
      if ((theFolder instanceof Folder))
      {
        QueryResult result1 = FolderHelper.service.findFolderContents((Folder)theFolder);
        QueryResult result2 = FolderHelper.service.findSubFolders((Folder)theFolder);
        ObjectVector oifc = new ObjectVector();
        if (result1 != null)
          for (int i = 0; i < result1.size(); i++)
          {
            oifc.addElement(result1.nextElement());
          }
        if (result2 != null)
          for (int i = 0; i < result2.size(); i++)
          {
            oifc.addElement(result2.nextElement());
          }
        return new QueryResult(oifc);
      }

      if ((theFolder instanceof ExchangeContainer))
      {
        QuerySpec spec = new QuerySpec(OrgContainer.class);
        QueryResult result1 = PersistenceHelper.manager.find(spec);

        WTContainerRef ref = WTContainerRef.newWTContainerRef((ExchangeContainer)theFolder);
        QuerySpec cabinetSpec = new QuerySpec(Cabinet.class);
        long oid = ref.getObjectId().getId();
        SearchCondition cond = new SearchCondition(Cabinet.class, "containerReference.key.id", "=", oid);
        cabinetSpec.appendWhere(cond);
        QueryResult result2 = PersistenceHelper.manager.find(cabinetSpec);

        ObjectVector oifc = new ObjectVector();
        if (result1 != null)
          for (int i = 0; i < result1.size(); i++)
          {
            oifc.addElement(result1.nextElement());
          }
        if (result2 != null)
          for (int i = 0; i < result2.size(); i++)
          {
            oifc.addElement(result2.nextElement());
          }
        return new QueryResult(oifc);
      }

      if ((theFolder instanceof OrgContainer))
      {
        ContainerSpec cSpec = new ContainerSpec();
        WTContainerRef ref = WTContainerRef.newWTContainerRef((OrgContainer)theFolder);
        cSpec.addSearchContainer(ref);
        QueryResult result1 = WTContainerHelper.service.getContainers(cSpec);

        QuerySpec cabinetSpec = new QuerySpec(Cabinet.class);
        long oid = ref.getObjectId().getId();
        SearchCondition cond = new SearchCondition(Cabinet.class, "containerReference.key.id", "=", oid);
        cabinetSpec.appendWhere(cond);
        QueryResult result2 = PersistenceHelper.manager.find(cabinetSpec);

        ObjectVector oifc = new ObjectVector();
        if (result1 != null)
          for (int i = 0; i < result1.size(); i++)
          {
            oifc.addElement(result1.nextElement());
          }
        if (result2 != null)
          for (int i = 0; i < result2.size(); i++)
          {
            oifc.addElement(result2.nextElement());
          }
        return new QueryResult(oifc);
      }

      if ((theFolder instanceof PDMLinkProduct))
      {
        WTContainerRef ref = WTContainerRef.newWTContainerRef((PDMLinkProduct)theFolder);

        QuerySpec cabinetSpec = new QuerySpec(Cabinet.class);
        long oid = ref.getObjectId().getId();
        SearchCondition cond = new SearchCondition(Cabinet.class, "containerReference.key.id", "=", oid);
        cabinetSpec.appendWhere(cond);
        return PersistenceHelper.manager.find(cabinetSpec);
      }

      if ((theFolder instanceof Project2))
      {
        WTContainerRef ref = WTContainerRef.newWTContainerRef((Project2)theFolder);

        QuerySpec cabinetSpec = new QuerySpec(Cabinet.class);
        long oid = ref.getObjectId().getId();
        SearchCondition cond = new SearchCondition(Cabinet.class, "containerReference.key.id", "=", oid);
        cabinetSpec.appendWhere(cond);
        return PersistenceHelper.manager.find(cabinetSpec);
      }

    }
    catch (WTException wte)
    {
      wte.printStackTrace();
    }
    return null;
  }

  public void clearTree() throws WTException
  {
    this.rootParts = new LinkedList();
    resetTree();
  }

  public void resetTree() throws WTException
  {
    DefaultMutableTreeNode rootNode = new DefaultMutableTreeNode(this.rootLabel);
    this.treeModel = new DefaultTreeModel(rootNode);

    this.editedFlag = false;

    for (int index = 0; index < this.rootParts.size(); index++)
    {
      WTObject rootPart = (WTObject)this.rootParts.get(index);
      KYCWTObjectNode partNode = createNewNode(rootPart, 0);
      rootNode.add(partNode);
    }

    this.theTree.setModel(this.treeModel);
  }

  public KYCWTObjectNode createNewNode(WTObject theElements, int curLevel) throws WTException
  {
    KYCWTObjectNode newNode = new KYCWTObjectNode(theElements);
    newNode.setProperty(LOAD_CHILD, "false");
    if ((!(theElements instanceof RevisionControlled)) && 
      (!(theElements instanceof LifeCycleTemplate)) && 
      (!(theElements instanceof WfTemplateObject)) && 
      (!(theElements instanceof ReportTemplate)) && 
      (!(theElements instanceof TeamTemplate)) && 
      (!(theElements instanceof WTChangeIssue)) && 
      (!(theElements instanceof WTChangeRequest2)) && 
      (!(theElements instanceof WTChangeOrder2)) && 
      (!(theElements instanceof WTChangeActivity2)))
    {
      DefaultMutableTreeNode workingNode = new DefaultMutableTreeNode("ï¿½ï¿½ï¿½ï¿½ï¿½ï¿½ ï¿½Ð´ï¿½ï¿½ï¿½ï¿½Ô´Ï´ï¿½.");
      newNode.add(workingNode);
    }
    return newNode;
  }

  public KYCWTObjectNode createNewNode(KYCWTObjectNode parentNode, int curLevel) throws WTException
  {
    QueryResult enumeration = FolderHelper.service.findSubFolders((Folder)parentNode.getObject());

    if (enumeration.size() > 0)
    {
      LinkedList sortedEnum = KYCViewerHelper.getQuerySort(enumeration, KYCViewerHelper.FOLDER_NAME);

      for (int index = 0; index < sortedEnum.size(); index++)
      {
        WTObject theElement = (WTObject)sortedEnum.get(index);
        KYCWTObjectNode childNode = createNewNode(theElement, curLevel + 1);
        if (childNode != null)
          parentNode.add(childNode);
      }
      parentNode.setProperty(LOAD_CHILD, "true");
    }

    return parentNode;
  }

  public void valueChanged(TreeSelectionEvent e)
  {
    TreePath thePath = e.getPath();
    Object treeNode = thePath.getLastPathComponent();
    if (!(treeNode instanceof KYCWTObjectNode)) return;

    if (this.preOpenNode != null) this.preOpenNode.setProperty(OPEN_STATUS, "false");

    KYCWTObjectNode theNode = (KYCWTObjectNode)thePath.getLastPathComponent();

    this.preOpenNode = theNode;

    theNode.setProperty(OPEN_STATUS, "true");
  }

  public void refresh()
  {
    DefaultMutableTreeNode rootNode = (DefaultMutableTreeNode)this.treeModel.getRoot();
    Enumeration children = rootNode.children();
    while (children.hasMoreElements()) {
      refreshNode((KYCWTObjectNode)children.nextElement());
    }
    this.theTree.repaint();
  }

  public void refreshNew(KYCWTObjectNode node, boolean changed)
    throws WTException
  {
    if (isRootNode(node)) {
      this.rootParts = new LinkedList();
      this.rootParts.add(node.getObject());
    }

    resetTree();
  }

  public void refreshNode(KYCWTObjectNode theNode)
  {
    try
    {
      Cursor hourglassCursor = new Cursor(3);
      Cursor defaultCursor = new Cursor(0);

      this.parentComponent.setCursor(hourglassCursor);
      theNode.removeAllChildren();
      this.treeModel.nodeStructureChanged(theNode);
      theNode.setProperty(LOAD_CHILD, "false");

      KYCWTObjectNode node = theNode;

      int nodeLevel = node.getLevel();
      if (node.getProperty(LOAD_CHILD).equals("true")) return;
      node.removeAllChildren();
      WTObject part = node.getObject();

      QueryResult children = null;
      if ((part instanceof KYCAccessPolicyInfo)) return;
      children = getSubDomains(part);

      if (children != null) {
        WTObject oneObject = null;
        while (children.hasMoreElements())
        {
          oneObject = (WTObject)children.nextElement();
          KYCWTObjectNode childNode = createNewNode(oneObject, nodeLevel + 1);
          node.add(childNode);
        }

      }

      if ((part instanceof AdministrativeDomain))
      {
        AdminDomainRef domainRef = new AdminDomainRef();
        domainRef.setObject((AdministrativeDomain)part);

        Enumeration collection = AccessControlHelper.manager.getAccessPolicyRules(domainRef);

        QueryResult result = null;
        AccessPolicyRule policy = null;
        Hashtable aclHash = null;
        Enumeration elements = null;
        Vector aclSet = null;
        KYCAccessPolicyInfo aPolicyInfo = null;

        while (collection.hasMoreElements()) {
          policy = (AccessPolicyRule)collection.nextElement();
          if (domainRef.toString().equals(policy.getDomainRef().toString())) {
            result = PersistenceHelper.manager.navigate(policy, "entry", AclEntryLink.class);

            if ((result != null) && (result.size() > 0)) {
              aclHash = filteringPermission(result);
              elements = aclHash.elements();
              while (elements.hasMoreElements()) {
                aclSet = (Vector)elements.nextElement();
                aPolicyInfo = new KYCAccessPolicyInfo(policy, aclSet);
                KYCWTObjectNode childNode = createNewNode(aPolicyInfo, nodeLevel + 1);
                node.add(childNode);
              }
            }
          }
        }
      }

      this.parentComponent.setCursor(defaultCursor);
      node.setProperty(LOAD_CHILD, "true");
    }
    catch (Exception wte) {
      this.parentComponent.setCursor(defaultCursor);
      wte.printStackTrace();
    }
  }

  public void addNode(KYCWTObjectNode parentNode, KYCWTObjectNode childNode)
  {
    parentNode.add(childNode);
    setStructureChanged(parentNode, true);
  }

  private void setStructureChanged(KYCWTObjectNode theNode, boolean structuralChange)
  {
    this.editedFlag = true;

    if (structuralChange)
      this.treeModel.nodeStructureChanged(theNode);
    else
      this.treeModel.nodeChanged(theNode);
  }

  public void removeNode(KYCWTObjectNode childNode)
  {
    TreeNode parent = childNode.getParent();
    if ((parent instanceof KYCWTObjectNode))
      try {
        KYCWTObjectNode parentNode = (KYCWTObjectNode)parent;

        WTObject childFolder = childNode.getObject();

        PersistenceHelper.manager.delete(childFolder);
        childNode.removeFromParent();

        this.treeModel.nodeStructureChanged(parentNode);
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
  }

  public void treeWillExpand(TreeExpansionEvent event)
    throws ExpandVetoException
  {
    try
    {
      if (!(getTreeNode(event.getPath()) instanceof KYCWTObjectNode)) return;

      KYCWTObjectNode node = (KYCWTObjectNode)getTreeNode(event.getPath());

      int nodeLevel = node.getLevel();
      if (node.getProperty(LOAD_CHILD).equals("true")) return;
      node.removeAllChildren();
      WTObject part = node.getObject();

      QueryResult children = null;
      if ((part instanceof KYCAccessPolicyInfo)) return;
      children = getSubDomains(part);

      if (children != null) {
        WTObject oneObject = null;
        while (children.hasMoreElements())
        {
          oneObject = (WTObject)children.nextElement();
          KYCWTObjectNode childNode = createNewNode(oneObject, nodeLevel + 1);
          node.add(childNode);
        }

      }

      if ((part instanceof AdministrativeDomain))
      {
        AdminDomainRef domainRef = new AdminDomainRef();
        domainRef.setObject((AdministrativeDomain)part);

        Enumeration collection = AccessControlHelper.manager.getAccessPolicyRules(domainRef);

        QueryResult result = null;
        AccessPolicyRule policy = null;
        Hashtable aclHash = null;
        Enumeration elements = null;
        Vector aclSet = null;
        KYCAccessPolicyInfo aPolicyInfo = null;

        while (collection.hasMoreElements()) {
          policy = (AccessPolicyRule)collection.nextElement();
          if (domainRef.toString().equals(policy.getDomainRef().toString())) {
            result = PersistenceHelper.manager.navigate(policy, "entry", AclEntryLink.class);

            if ((result != null) && (result.size() > 0)) {
              aclHash = filteringPermission(result);
              elements = aclHash.elements();
              while (elements.hasMoreElements()) {
                aclSet = (Vector)elements.nextElement();
                aPolicyInfo = new KYCAccessPolicyInfo(policy, aclSet);
                KYCWTObjectNode childNode = createNewNode(aPolicyInfo, nodeLevel + 1);
                node.add(childNode);
              }
            }
          }
        }
      }
      node.setProperty(LOAD_CHILD, "true");
    } catch (WTException wte) {
      wte.printStackTrace();
    }
  }

  public Hashtable filteringPermission(QueryResult result) throws WTException
  {
    Hashtable returnHash = new Hashtable();
    Vector aclVector = new Vector();

    WTAclEntry aclEntry = null;
    while (result.hasMoreElements()) {
      aclEntry = (WTAclEntry)result.nextElement();

      if (returnHash.get(aclEntry.getPrincipalReference()) == null) {
        aclVector = new Vector();
        aclVector.add(aclEntry);
        returnHash.put(aclEntry.getPrincipalReference(), aclVector);
      } else {
        aclVector = (Vector)returnHash.get(aclEntry.getPrincipalReference());
        aclVector.add(aclEntry);
        returnHash.put(aclEntry.getPrincipalReference(), aclVector);
      }
    }

    return returnHash;
  }

  public void treeWillCollapse(TreeExpansionEvent event) throws ExpandVetoException
  {
    try
    {
      if (!(getTreeNode(event.getPath()) instanceof KYCWTObjectNode));
    }
    catch (Exception wte)
    {
      wte.printStackTrace();
    }
  }

  public DefaultMutableTreeNode getTreeNode(TreePath path) {
    return (DefaultMutableTreeNode)path.getLastPathComponent();
  }

  public KYCWTObjectNode getNode(int x, int y)
  {
    TreePath thePath = this.theTree.getClosestPathForLocation(x, y);
    Object theObject = thePath.getLastPathComponent();
    if ((theObject instanceof KYCWTObjectNode))
      return (KYCWTObjectNode)theObject;
    return null;
  }

  public void setRenderType(boolean type)
  {
    if (type)
      KYCPartTreeCellRenderer.setRenderType("standard");
    else
      KYCPartTreeCellRenderer.setRenderType("released");
    this.theTree.repaint();
  }

  public void processViewProperty(KYCWTObjectNode theNode)
  {
    WTObject oPartInfo = theNode.getObject();
    String partOID = oPartInfo.toString();
    String codebase = KYCPartTreeCellRenderer.CODEBASE;
    try
    {
      WTContext.getContext().showDocument(new URL(codebase + "/pdmx/part/partinfo_view.jsp?viewmode=applet&part_oid=" + partOID), ""); } catch (Exception localException) {
    }
  }

  public void commitNewFolder(KYCWTObjectNode theNode) {
    TreeModel treeModel = this.theTree.getModel();

    this.theTree.scrollPathToVisible(new TreePath(theNode.getPath()));
    this.theTree.setSelectionPath(new TreePath(theNode.getPath()));
  }

  public void commitViewXML(KYCWTObjectNode theNode)
  {
    TreeModel treeModel = this.theTree.getModel();

    this.theTree.scrollPathToVisible(new TreePath(theNode.getPath()));
    this.theTree.setSelectionPath(new TreePath(theNode.getPath()));

    KYCViewDialog viewDialog = new KYCViewDialog(this.parentComponent, true, theNode, KYCViewDialog.XML_TYPE);
    viewDialog.setTitle("View XML Format");

    GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
    GraphicsDevice[] gs = ge.getScreenDevices();
    int screenWidth = 0;
    int screenHeight = 0;
    int posX = 0;
    int posY = 0;

    for (int i = 0; i < gs.length; i++) {
      DisplayMode dm = gs[i].getDisplayMode();
      screenWidth = dm.getWidth();
      screenHeight = dm.getHeight();
    }

    posX = screenWidth / 2 - viewDialog.getWidth() / 2;
    posY = screenHeight / 2 - viewDialog.getHeight() / 2;

    if (posX < 0) posX = 0;
    if (posY < 0) posY = 0;

    viewDialog.setLocation(posX, posY);

    viewDialog.setVisible(true);
  }

  public void commitViewCSV(KYCWTObjectNode theNode)
  {
    TreeModel treeModel = this.theTree.getModel();

    this.theTree.scrollPathToVisible(new TreePath(theNode.getPath()));
    this.theTree.setSelectionPath(new TreePath(theNode.getPath()));

    KYCViewDialog viewDialog = new KYCViewDialog(this.parentComponent, true, theNode, KYCViewDialog.CSV_TYPE);
    viewDialog.setTitle("View CSV Format");

    GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
    GraphicsDevice[] gs = ge.getScreenDevices();
    int screenWidth = 0;
    int screenHeight = 0;
    int posX = 0;
    int posY = 0;

    for (int i = 0; i < gs.length; i++) {
      DisplayMode dm = gs[i].getDisplayMode();
      screenWidth = dm.getWidth();
      screenHeight = dm.getHeight();
    }
    posX = screenWidth / 2 - viewDialog.getWidth() / 2;
    posY = screenHeight / 2 - viewDialog.getHeight() / 2;

    if (posX < 0) posX = 0;
    if (posY < 0) posY = 0;

    viewDialog.setLocation(posX, posY);

    viewDialog.setVisible(true);
  }

  public void commitLoadXML(KYCWTObjectNode theNode)
    throws IOException, SAXException, WTException, ParserConfigurationException
  {
    TreeModel treeModel = this.theTree.getModel();

    this.theTree.scrollPathToVisible(new TreePath(theNode.getPath()));
    this.theTree.setSelectionPath(new TreePath(theNode.getPath()));

    Cursor hourglassCursor = new Cursor(3);
    Cursor defaultCursor = new Cursor(0);

    JFileChooser jfc = new JFileChooser();
    KYCDomainFileFilter fileFilter = new KYCDomainFileFilter("kml");
    fileFilter.setDescription("KYC XML File");
    jfc.setFileFilter(fileFilter);

    int result = jfc.showSaveDialog(this.parentComponent);
    if (result == 1) return;

    this.parentComponent.setCursor(hourglassCursor);

    File selectedFile = jfc.getSelectedFile();

    KYCXMLReader reader = new KYCXMLReader(selectedFile, KYCXMLReader.XML, false);
    Vector data = reader.reading();

    boolean returnValue = true;

    RemoteMethodServer methodServer = RemoteMethodServer.getDefault();

    Object returnObject = null;
    try {
      returnObject = methodServer.invoke("addAccessRule", KYCLoadAccessRule.class.getName(), null, 
        new Class[] { KYCWTObjectNode.class, Vector.class }, 
        new Object[] { theNode, data });
    }
    catch (RemoteException e)
    {
      this.parentComponent.setCursor(defaultCursor);
      e.printStackTrace();
    }
    catch (InvocationTargetException e) {
      this.parentComponent.setCursor(defaultCursor);
      e.printStackTrace();
    }

    this.parentComponent.setCursor(defaultCursor);
    if (!((Boolean)returnObject).booleanValue())
      JOptionPane.showMessageDialog(this.parentComponent, "Load Failed. Check MethodServer logs.", "Load Error", 0);
    else {
      JOptionPane.showMessageDialog(this.parentComponent, "Load Complete");
    }
    refreshNode(theNode);
  }

  public void commitLoadCSV(KYCWTObjectNode theNode)
    throws IOException, SAXException, WTException, ParserConfigurationException
  {
    TreeModel treeModel = this.theTree.getModel();

    this.theTree.scrollPathToVisible(new TreePath(theNode.getPath()));
    this.theTree.setSelectionPath(new TreePath(theNode.getPath()));

    Cursor hourglassCursor = new Cursor(3);
    Cursor defaultCursor = new Cursor(0);

    JFileChooser jfc = new JFileChooser();
    KYCDomainFileFilter fileFilter = new KYCDomainFileFilter("ksv");
    fileFilter.setDescription("KYC CSV File");
    jfc.setFileFilter(fileFilter);

    int result = jfc.showSaveDialog(this.parentComponent);
    if (result == 1) return;

    this.parentComponent.setCursor(hourglassCursor);
    File selectedFile = jfc.getSelectedFile();

    KYCXMLReader reader = new KYCXMLReader(selectedFile, KYCXMLReader.CSV, false);
    Vector data = reader.reading();

    boolean returnValue = true;

    RemoteMethodServer methodServer = RemoteMethodServer.getDefault();

    Object returnObject = null;
    try {
      returnObject = methodServer.invoke("addAccessRule", KYCLoadAccessRule.class.getName(), null, 
        new Class[] { KYCWTObjectNode.class, Vector.class }, 
        new Object[] { theNode, data });
    }
    catch (RemoteException e)
    {
      this.parentComponent.setCursor(defaultCursor);
      e.printStackTrace();
    }
    catch (InvocationTargetException e) {
      this.parentComponent.setCursor(defaultCursor);
      e.printStackTrace();
    }

    this.parentComponent.setCursor(defaultCursor);
    if (!((Boolean)returnObject).booleanValue())
      JOptionPane.showMessageDialog(this.parentComponent, "Load Failed. Check MethodServer logs.");
    else {
      JOptionPane.showMessageDialog(this.parentComponent, "Load Complete");
    }
    refreshNode(theNode);
  }

  public void commitClearChild(KYCWTObjectNode theNode)
  {
    TreeModel treeModel = this.theTree.getModel();
    try
    {
      this.theTree.scrollPathToVisible(new TreePath(theNode.getPath()));
      this.theTree.setSelectionPath(new TreePath(theNode.getPath()));

      int resultChoice = JOptionPane.showConfirmDialog(this.parentComponent, "It will clear all Access Rule in just targeted Domain.\nIt desn't delete parent or child acess rules.\nDo you want to clear?", "Clear Access Rules", 0);

      Cursor hourglassCursor = new Cursor(3);
      Cursor defaultCursor = new Cursor(0);

      if (resultChoice == 0) {
        this.parentComponent.setCursor(hourglassCursor);

        AdminDomainRef domainRef = new AdminDomainRef();
        domainRef.setObject((AdministrativeDomain)theNode.getObject());

        Enumeration collection = AccessControlHelper.manager.getAccessPolicyRules(domainRef);

        QueryResult result = null;
        AccessPolicyRule policy = null;
        Hashtable aclHash = null;
        Enumeration elements = null;
        Vector aclSet = null;
        KYCAccessPolicyInfo aPolicyInfo = null;

        while (collection.hasMoreElements()) {
          policy = (AccessPolicyRule)collection.nextElement();
          if (domainRef.toString().equals(policy.getDomainRef().toString())) {
            result = PersistenceHelper.manager.navigate(policy, "entry", AclEntryLink.class);

            if ((result != null) && (result.size() > 0)) {
              aclHash = filteringPermission(result);
              elements = aclHash.elements();
              while (elements.hasMoreElements()) {
                aclSet = (Vector)elements.nextElement();
                aPolicyInfo = new KYCAccessPolicyInfo(policy, aclSet);
                removeAccessRule(aPolicyInfo);
              }
            }
          }

        }

        refreshNode(theNode);
        this.parentComponent.setCursor(defaultCursor);
      }

    }
    catch (WTException e)
    {
      e.printStackTrace();
    }
  }

  public void commitCreateDomain(KYCWTObjectNode theNode)
  {
    TreeModel treeModel = this.theTree.getModel();
    try
    {
      String inputDomianName = JOptionPane.showInputDialog(this.parentComponent, "Enter New Domain Name:");

      if (inputDomianName != null)
        if (inputDomianName.trim().length() == 0) {
          JOptionPane.showMessageDialog(this.parentComponent, "You must input domain name\nBlank can not use!", "Inputted Blank", 0);
        } else {
          Cursor hourglassCursor = new Cursor(3);
          Cursor defaultCursor = new Cursor(0);

          this.parentComponent.setCursor(hourglassCursor);
          AdministrativeDomain domain = (AdministrativeDomain)theNode.getObject();
          AdminDomainRef domainRef = new AdminDomainRef();
          domainRef.setObject(domain);

          WTContainerRef containerRef = domain.getContainerReference();

          AdministrativeDomainHelper.manager.createDomain(domainRef, inputDomianName, inputDomianName, containerRef);

          this.parentComponent.setCursor(defaultCursor);
          refreshNode(theNode);
        }
    }
    catch (Exception e) {
      this.parentComponent.setCursor(defaultCursor);
      e.printStackTrace();
    }
  }

  public void commitDeleteDomain(KYCWTObjectNode theNode)
  {
    TreeModel treeModel = this.theTree.getModel();
    try
    {
      int resultChoice = JOptionPane.showConfirmDialog(this.parentComponent, "Do you want to delete selected domain?", "Remove Domain", 0);

      if (resultChoice == 0) {
        Cursor hourglassCursor = new Cursor(3);
        Cursor defaultCursor = new Cursor(0);

        this.parentComponent.setCursor(hourglassCursor);
        KYCWTObjectNode parentNode = (KYCWTObjectNode)theNode.getParent();
        AdministrativeDomain domain = (AdministrativeDomain)theNode.getObject();
        AdminDomainRef domainRef = new AdminDomainRef();
        domainRef.setObject(domain);

        AdministrativeDomainHelper.manager.delete(domainRef);
        this.parentComponent.setCursor(defaultCursor);

        refreshNode(parentNode);
      }
    } catch (Exception e) {
      this.parentComponent.setCursor(defaultCursor);
      JOptionPane.showMessageDialog(this.parentComponent, "Couldn't target domain. Beecause of following:\n" + e.getLocalizedMessage(), "Error", 0);
    }
  }

  public void commitRemoveAccessRule(KYCWTObjectNode theNode)
  {
    TreeModel treeModel = this.theTree.getModel();
    try
    {
      int resultChoice = JOptionPane.showConfirmDialog(this.parentComponent, "Do you want to delete selected access?", "Remove Access", 0);

      if (resultChoice == 0) {
        Cursor hourglassCursor = new Cursor(3);
        Cursor defaultCursor = new Cursor(0);

        this.parentComponent.setCursor(hourglassCursor);
        KYCWTObjectNode parentNode = (KYCWTObjectNode)theNode.getParent();
        KYCAccessPolicyInfo policy = (KYCAccessPolicyInfo)theNode.getObject();

        AccessPolicyRule policyRule = policy.getObject();
        String stateName = null;
        stateName = policy.getStateName();

        String appliesTo = policy.getAppliesToFile();

        if (this.DEBUG) {
          System.out.println("DEBUG: policy id=" + policyRule);
          System.out.println("DEBUG: getFullTypeObjectName=" + policy.getFullTypeObjectName());
          System.out.println("DEBUG: stateName=" + stateName);
          System.out.println("DEBUG: appliesTo=" + appliesTo);
          System.out.println("DEBUG: policy.getPrincipalReference()=" + policy.getPrincipalReference());
        }
        State stateInstance = null;
        if (!stateName.equals("ALL")) {
          stateInstance = State.toState(stateName);
          if (stateInstance == null) {
            LoadServerHelper.printMessage("\n\n########ERROR-0005: Do not have State '" + stateName + "'.");
            throw new WTException("ERROR-0005: Do not have State '" + stateName + "'.");
          }
        }

        boolean isAppliesTo = false;
        if (appliesTo == null)
          isAppliesTo = false;
        else if (appliesTo.equals("true")) {
          isAppliesTo = true;
        }

        AccessControlHelper.manager.deleteAccessControlRule(policyRule.getDomainRef(), policy.getFullTypeObjectName(), stateInstance, policy.getPrincipalReference(), isAppliesTo);
        this.parentComponent.setCursor(defaultCursor);

        refreshNode(parentNode);
      }
    } catch (Exception e) {
      this.parentComponent.setCursor(defaultCursor);
      JOptionPane.showMessageDialog(this.parentComponent, "Couldn't target domain. Beecause of following:\n" + e.getLocalizedMessage(), "Error", 0);
    }
  }

  public void commitAbout(KYCWTObjectNode theNode)
  {
    try
    {
      WTProperties wt = WTProperties.getLocalProperties();
      String wt_home = wt.getProperty("wt.home");
      String path = wt_home + "\\codebase\\ext\\csc\\support\\domain\\util\\KYC.jpg";

      BufferedImage image = ImageIO.read(new File(path));
      KYCAboutDialog aboutDialog = new KYCAboutDialog(this.parentComponent, true, image);
      aboutDialog.setSize(400, 370);

      GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
      GraphicsDevice[] gs = ge.getScreenDevices();
      int screenWidth = 0;
      int screenHeight = 0;
      int posX = 0;
      int posY = 0;

      for (int i = 0; i < gs.length; i++) {
        DisplayMode dm = gs[i].getDisplayMode();
        screenWidth = dm.getWidth();
        screenHeight = dm.getHeight();
      }
      posX = screenWidth / 2 - aboutDialog.getWidth() / 2;
      posY = screenHeight / 2 - aboutDialog.getHeight() / 2;

      if (posX < 0) posX = 0;
      if (posY < 0) posY = 0;

      aboutDialog.setLocation(posX, posY);

      aboutDialog.setTitle("About...");
      aboutDialog.setVisible(true);
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  public LinkedList getSelectedObjects()
  {
    LinkedList objects = new LinkedList();
    TreePath[] paths = this.theTree.getSelectionPaths();
    if (paths != null) {
      for (int i = 0; i < paths.length; i++) {
        TreeNode node = (TreeNode)paths[i].getLastPathComponent();
        objects.add(node);
      }
    }

    return objects;
  }

  public LinkedList getFromRoot(KYCWTObjectNode node) {
    LinkedList gotSameNode = new LinkedList();
    getChildNode((TreeNode)this.treeModel.getRoot(), gotSameNode, node);

    LinkedList nodeList = new LinkedList();
    for (int index = 0; index < gotSameNode.size(); index++) {
      TreeNode[] paths = this.treeModel.getPathToRoot((KYCWTObjectNode)gotSameNode.get(index));
      for (int i = 0; i < paths.length; i++) {
        if ((paths[i] instanceof KYCWTObjectNode)) {
          nodeList.addLast(((KYCWTObjectNode)paths[i]).getObject());
        }
      }
    }
    return nodeList;
  }

  public void getChildNode(TreeNode node, LinkedList link, KYCWTObjectNode compareNode) {
    Enumeration gotChild = node.children();

    while (gotChild.hasMoreElements()) {
      TreeNode rNode = (TreeNode)gotChild.nextElement();
      if (((KYCWTObjectNode)rNode).getObject().toString().equals(compareNode.getObject().toString())) {
        link.addLast((KYCWTObjectNode)rNode);
      }
      getChildNode(rNode, link, compareNode);
    }
  }

  public int getSelectionCount() {
    TreePath[] paths = this.theTree.getSelectionPaths();
    if (paths == null) return 0;
    return paths.length;
  }

  public boolean checkLabelNodeSelect()
  {
    boolean isLabelNode = false;
    LinkedList temp = getSelectedObjects();
    for (int i = 0; i < temp.size(); i++) {
      if (!(temp.get(i) instanceof KYCWTObjectNode)) isLabelNode = true;
    }
    if (isLabelNode) JOptionPane.showMessageDialog(this.parentComponent, "ï¿½Ø½ï¿½Æ® ï¿½ï¿½ï¿½ï¿½ ï¿½ï¿½ï¿½ï¿½ï¿½ï¿½ï¿½ï¿½ ï¿½ï¿½ï¿½Ê½Ã¿ï¿½!");
    return isLabelNode;
  }

  public boolean isRootNode(KYCWTObjectNode node) {
    boolean checkRootNode = false;

    Object rootNode = node.getParent();
    if (!(rootNode instanceof KYCWTObjectNode)) checkRootNode = true;
    return checkRootNode;
  }

  public boolean checkMultiSelect() {
    if (getSelectionCount() == 1) return false;

    JOptionPane.showMessageDialog(this.parentComponent, "ï¿½Ï³ï¿½ï¿½ï¿½ ï¿½ï¿½å¸¸ ï¿½ï¿½ï¿½ï¿½ï¿½Ï½Åµï¿½ ï¿½Ù½ï¿½ ï¿½ï¿½ï¿½ï¿½ï¿½Ï½Ê½Ã¿ï¿½");
    return true;
  }

  public JFrame getParentComponent()
  {
    return this.parentComponent;
  }

  public JTree getTheTree()
  {
    return this.theTree;
  }

  public void removeAccessRule(KYCAccessPolicyInfo policy) throws WTException {
    AccessPolicyRule policyRule = policy.getObject();
    String stateName = null;
    stateName = policy.getStateName();

    String appliesTo = policy.getAppliesToFile();

    if (this.DEBUG) {
      System.out.println("DEBUG: policy id=" + policyRule);
      System.out.println("DEBUG: getFullTypeObjectName=" + policy.getFullTypeObjectName());
      System.out.println("DEBUG: stateName=" + stateName);
      System.out.println("DEBUG: appliesTo=" + appliesTo);
      System.out.println("DEBUG: policy.getPrincipalReference()=" + policy.getPrincipalReference());
    }
    State stateInstance = null;
    if (!stateName.equals("ALL")) {
      stateInstance = State.toState(stateName);
      if (stateInstance == null) {
        LoadServerHelper.printMessage("\n\n########ERROR-0005: Do not have State '" + stateName + "'.");
        throw new WTException("ERROR-0005: Do not have State '" + stateName + "'.");
      }
    }

    boolean isAppliesTo = false;
    if (appliesTo == null)
      isAppliesTo = false;
    else if (appliesTo.equals("true")) {
      isAppliesTo = true;
    }

    AccessControlHelper.manager.deleteAccessControlRule(policyRule.getDomainRef(), policy.getFullTypeObjectName(), stateInstance, policy.getPrincipalReference(), isAppliesTo);
  }
}