package ext.csc.support.domain.util;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Frame;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import javax.swing.BorderFactory;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.GroupLayout.ParallelGroup;
import javax.swing.GroupLayout.SequentialGroup;
import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.LayoutStyle;
import javax.swing.LayoutStyle.ComponentPlacement;

public class KYCAboutDialog extends JDialog
{
  BufferedImage image;
  Dimension size = new Dimension();
  private JLabel jLabel1;
  private JLabel jLabel2;
  private JLabel jLabel3;
  private JLabel jLabel4;
  private JLabel jLabel5;
  private JLabel jLabel6;

  public KYCAboutDialog(Frame parent, boolean modal)
  {
    super(parent, modal);
    initComponents();
  }

  public KYCAboutDialog(Frame parent, boolean modal, BufferedImage image) {
    super(parent, modal);
    this.image = image;
    this.size.setSize(image.getWidth(), image.getHeight());
    initComponents();
  }
  public Dimension getPreferredSize() {
    return this.size;
  }

  private void initComponents()
  {
    ImageIcon icon = new ImageIcon(this.image);

    this.jLabel1 = new JLabel();
    this.jLabel2 = new JLabel();
    this.jLabel3 = new JLabel();
    this.jLabel4 = new JLabel();
    this.jLabel5 = new JLabel();
    this.jLabel6 = new JLabel(icon, 0);

    setDefaultCloseOperation(2);

    this.jLabel1.setText("Creator       : Eric Kim (Kim, Young Chul Eric)");

    this.jLabel2.setText("Oganization : China Solution Center");

    this.jLabel3.setText("Role           : Principal Consultant");

    this.jLabel4.setText("E-Mail        : yckim@ptc.com");

    this.jLabel5.setText("S/W Ver      : ACL Tool V0.92(WC10 M010)");
    this.jLabel6.setBorder(BorderFactory.createBevelBorder(0));

    GroupLayout layout = new GroupLayout(getContentPane());
    getContentPane().setLayout(layout);
    layout.setHorizontalGroup(
      layout.createParallelGroup(GroupLayout.Alignment.LEADING)
      .addGroup(layout.createSequentialGroup()
      .addContainerGap()
      .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
      .addComponent(this.jLabel2, -2, 340, -2)
      .addComponent(this.jLabel1, -2, 477, -2)
      .addComponent(this.jLabel3)
      .addComponent(this.jLabel4, -2, 400, -2)
      .addComponent(this.jLabel5)
      .addComponent(this.jLabel6))
      .addContainerGap(-1, 32767)));

    layout.setVerticalGroup(
      layout.createParallelGroup(GroupLayout.Alignment.LEADING)
      .addGroup(layout.createSequentialGroup()
      .addContainerGap()
      .addComponent(this.jLabel6)
      .addGap(10, 10, 10)
      .addComponent(this.jLabel5)
      .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
      .addComponent(this.jLabel1)
      .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
      .addComponent(this.jLabel2)
      .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
      .addComponent(this.jLabel3)
      .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
      .addComponent(this.jLabel4)
      .addContainerGap(29, 32767)));

    pack();
  }

  public static void main(String[] args)
  {
    EventQueue.invokeLater(new Runnable() {
      public void run() {
        KYCAboutDialog dialog = new KYCAboutDialog(new JFrame(), true);
        dialog.addWindowListener(new WindowAdapter() {
          public void windowClosing(WindowEvent e) {
            System.exit(0);
          }
        });
        dialog.setVisible(true);
      }
    });
  }
}