package ext.csc.support.domain.util;

import java.util.Enumeration;
import java.util.Hashtable;
import javax.swing.tree.DefaultMutableTreeNode;
import wt.admin.AdminDomainRef;
import wt.admin.AdministrativeDomain;
import wt.admin.AdministrativeDomainHelper;
import wt.admin.AdministrativeDomainManager;
import wt.change2.WTChangeActivity2;
import wt.change2.WTChangeIssue;
import wt.change2.WTChangeOrder2;
import wt.change2.WTChangeRequest2;
import wt.enterprise.RevisionControlled;
import wt.fc.WTObject;
import wt.folder.Cabinet;
import wt.folder.SubFolder;
import wt.inf.container.ExchangeContainer;
import wt.inf.container.OrgContainer;
import wt.inf.container.WTContainer;
import wt.inf.library.WTLibrary;
import wt.lifecycle.LifeCycleTemplate;
import wt.pdmlink.PDMLinkProduct;
import wt.projmgmt.admin.Project2;
import wt.query.template.ReportTemplate;
import wt.team.TeamTemplate;
import wt.util.WTException;
import wt.workflow.definer.WfTemplateObject;
import wt.workflow.engine.WfProcess;

class KYCWTObjectNode extends DefaultMutableTreeNode
{
  private WTObject theObject;
  private Hashtable params;

  public KYCWTObjectNode(WTObject theFolder)
  {
    this.theObject = theFolder;
    this.params = new Hashtable();
  }

  public KYCWTObjectNode(KYCWTObjectNode theNode)
  {
    this(theNode, false);
  }

  public KYCWTObjectNode(KYCWTObjectNode theNode, boolean deepCopy)
  {
    this.theObject = theNode.getObject();
    this.params = new Hashtable();

    Enumeration enumeration = theNode.children();
    while (enumeration.hasMoreElements())
    {
      KYCWTObjectNode childNode = (KYCWTObjectNode)enumeration.nextElement();
      KYCWTObjectNode newChildNode = new KYCWTObjectNode(childNode, true);
      add(newChildNode);
    }
  }

  public WTObject getObject()
  {
    return this.theObject;
  }

  public void setObject(WTObject theObject)
  {
    this.theObject = theObject;
  }

  public void setProperty(String propertyName, String value)
  {
    this.params.put(propertyName, value);
  }

  public Hashtable getParams() {
    return this.params;
  }

  public String getProperty(String propertyName) {
    return (String)this.params.get(propertyName);
  }

  public String getDomainPath() throws WTException {
    if ((this.theObject instanceof AdministrativeDomain))
    {
      AdminDomainRef dRef = AdminDomainRef.newAdminDomainRef((AdministrativeDomain)this.theObject);
      return AdministrativeDomainHelper.manager.getPathOfDomain(dRef);
    }
    return null;
  }

  public String toString()
  {
    if (this.theObject == null) {
      return "No Object Specified";
    }

    if ((this.theObject instanceof SubFolder))
    {
      return "[F]" + ((SubFolder)this.theObject).getName();
    }
    if ((this.theObject instanceof Cabinet))
    {
      return "[C]" + ((Cabinet)this.theObject).getName();
    }
    if ((this.theObject instanceof ExchangeContainer))
    {
      return "[SITE]" + ((ExchangeContainer)this.theObject).getName();
    }
    if ((this.theObject instanceof OrgContainer))
    {
      return "[ORG]" + ((OrgContainer)this.theObject).getName();
    }
    if ((this.theObject instanceof PDMLinkProduct))
    {
      return "[PDM]" + ((PDMLinkProduct)this.theObject).getName();
    }
    if ((this.theObject instanceof Project2))
    {
      return "[PJT]" + ((Project2)this.theObject).getName();
    }
    if ((this.theObject instanceof WTLibrary))
    {
      return "[LIB]" + ((WTLibrary)this.theObject).getName();
    }
    if ((this.theObject instanceof WfProcess))
    {
      return ((WfProcess)this.theObject).getName();
    }
    if ((this.theObject instanceof RevisionControlled))
    {
      return ((RevisionControlled)this.theObject).getIdentity();
    }
    if ((this.theObject instanceof LifeCycleTemplate))
    {
      return "[LCT]" + ((LifeCycleTemplate)this.theObject).getName();
    }
    if ((this.theObject instanceof WfTemplateObject))
    {
      return "[WFT]" + ((WfTemplateObject)this.theObject).getName();
    }
    if ((this.theObject instanceof ReportTemplate))
    {
      return "[RT]" + ((ReportTemplate)this.theObject).getName();
    }
    if ((this.theObject instanceof TeamTemplate))
    {
      return "[TT]" + ((TeamTemplate)this.theObject).getName();
    }
    if ((this.theObject instanceof WTChangeIssue))
    {
      return "[ISSUE]" + ((WTChangeIssue)this.theObject).getName();
    }
    if ((this.theObject instanceof WTChangeRequest2))
    {
      return "[ECR]" + ((WTChangeRequest2)this.theObject).getName();
    }
    if ((this.theObject instanceof WTChangeOrder2))
    {
      return "[ECO]" + ((WTChangeOrder2)this.theObject).getName();
    }
    if ((this.theObject instanceof WTChangeActivity2))
    {
      return "[ECN]" + ((WTChangeActivity2)this.theObject).getName();
    }
    if ((this.theObject instanceof AdministrativeDomain))
    {
      WTContainer container = ((AdministrativeDomain)this.theObject).getContainer();
      return ((AdministrativeDomain)this.theObject).getName() + "(" + container.getType() + " - " + container.getName() + ")";
    }
    if ((this.theObject instanceof KYCAccessPolicyInfo))
    {
      KYCAccessPolicyInfo policyInfo = (KYCAccessPolicyInfo)this.theObject;
      return policyInfo.toString();
    }

    return this.theObject.toString();
  }
}