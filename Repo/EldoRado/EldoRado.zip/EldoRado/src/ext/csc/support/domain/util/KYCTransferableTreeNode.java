package ext.csc.support.domain.util;

import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import javax.swing.tree.DefaultMutableTreeNode;

public class KYCTransferableTreeNode extends DefaultMutableTreeNode
  implements Transferable
{
  static final int TREE = 0;
  static final int STRING = 1;
  static final int PLAIN_TEXT = 2;
  public static final DataFlavor DEFAULT_MUTABLE_TREENODE_FLAVOR = new DataFlavor(DefaultMutableTreeNode.class, "Default Mutable Tree Node");

  static DataFlavor[] flavors = { DEFAULT_MUTABLE_TREENODE_FLAVOR, DataFlavor.stringFlavor, DataFlavor.plainTextFlavor };
  private DefaultMutableTreeNode data;

  public KYCTransferableTreeNode(DefaultMutableTreeNode data)
  {
    this.data = data;
  }

  public DataFlavor[] getTransferDataFlavors()
  {
    return flavors;
  }

  public Object getTransferData(DataFlavor flavor)
    throws UnsupportedFlavorException, IOException
  {
    Object returnObject;
    if (flavor.equals(flavors[0])) {
      Object userObject = this.data.getUserObject();
      if (userObject == null)
        returnObject = this.data;
      else
        returnObject = userObject;
    }
    else
    {
      if (flavor.equals(flavors[1])) {
        Object userObject = this.data.getUserObject();
        if (userObject == null)
          returnObject = this.data.toString();
        else
          returnObject = userObject.toString();
      }
      else
      {
        if (flavor.equals(flavors[2])) {
          Object userObject = this.data.getUserObject();
          String string;
          if (userObject == null)
            string = this.data.toString();
          else {
            string = userObject.toString();
          }
          returnObject = new ByteArrayInputStream(string.getBytes());
        } else {
          throw new UnsupportedFlavorException(flavor);
        }
      }
    }
    return returnObject;
  }
  public boolean isDataFlavorSupported(DataFlavor flavor) {
    boolean returnValue = false;
    int i = 0; for (int n = flavors.length; i < n; i++) {
      if (flavor.equals(flavors[i])) {
        returnValue = true;
        break;
      }
    }
    return returnValue;
  }
}