package ext.csc.support.domain.util;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.DisplayMode;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.io.PrintStream;
import java.util.Locale;
import javax.swing.JFrame;
import javax.swing.JRootPane;
import javax.swing.UIManager;
import wt.admin.AdministrativeDomain;
import wt.admin.AdministrativeDomainHelper;
import wt.admin.AdministrativeDomainManager;
import wt.fc.ObjectIdentifier;
import wt.fc.PersistenceHelper;
import wt.org.OrganizationServicesHelper;
import wt.org.OrganizationServicesManager;
import wt.org.WTGroup;
import wt.org.WTPrincipal;
import wt.session.SessionHelper;
import wt.session.SessionManager;
import wt.util.WTContext;
import wt.util.WTException;

public class KYCAccessRuleUtil extends JFrame
{
  private KYCTreeLogic theLogic;
  static int WIDTH = 600;
  static int HEIGHT = 450;

  private static double PERCENTAGE = 0.5D;

  private static String rootCabinet = null;
  private static String rootLabel = null;
  private static KYCTreePanel panel1;

  public static void main(String[] args)
  {
    KYCAccessRuleUtil application = new KYCAccessRuleUtil();
    try
    {
      WTContext.init(application);

      WTPrincipal principal = SessionHelper.manager.getPrincipal();
      WTGroup group = OrganizationServicesHelper.manager.getGroup("Administrators");
      if (!OrganizationServicesHelper.manager.isMember(group, principal)) {
        System.out.println("You must login Administrators group's user!!\nThis tool can not be used by normal user.");
        System.exit(0);
      }

      application.getRootPane().putClientProperty("defeatSystemEventQueueCheck", Boolean.TRUE);

      AdministrativeDomain domain = AdministrativeDomainHelper.manager.getDomain("Root");

      long longID = PersistenceHelper.getObjectIdentifier(domain).getId();
      String theElementOid = domain.getConceptualClassname() + ":" + longID;

      rootCabinet = theElementOid;
      rootLabel = "ACL EXPLORER";
      try
      {
        UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
      } catch (Exception localException) {
      }
      GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
      GraphicsDevice[] gs = ge.getScreenDevices();

      int screenWidth = 0;
      int screenHeight = 0;
      int changedWidth = 0;
      int changedHeight = 0;

      for (int i = 0; i < gs.length; i++) {
        DisplayMode dm = gs[i].getDisplayMode();
        screenWidth = dm.getWidth();
        screenHeight = dm.getHeight();

        if (screenWidth < WIDTH) changedWidth = screenWidth; else
          changedWidth = WIDTH;
        if (screenHeight < HEIGHT) changedHeight = screenHeight; else {
          changedHeight = HEIGHT;
        }
        application.setSize(changedWidth, changedHeight);
      }

      if (rootCabinet == null) rootCabinet = "";
      if (rootCabinet.equals("")) panel1 = new KYCTreePanel(application, false); else {
        panel1 = new KYCTreePanel(application, false, rootCabinet, rootLabel);
      }
      panel1.setPreferredSize(new Dimension((int)(PERCENTAGE * WIDTH), HEIGHT));
      application.getContentPane().add(panel1, "Center");
      application.setLocale(Locale.US);
      application.setLocation(screenWidth / 2 - changedWidth / 2, screenHeight / 2 - changedHeight / 2);
      application.setVisible(true);
      application.setDefaultCloseOperation(3);
      application.setTitle("ACL Tool - V0.92(WC10 M010) - Internal Only");
    }
    catch (WTException wte)
    {
      wte.printStackTrace();
    }
  }

  public KYCTreePanel getPanel() {
    return panel1;
  }
}