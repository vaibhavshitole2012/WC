package ext.csc.support.domain.util;

import java.io.Serializable;
import wt.fc.WTObject;

public class KYCWTObjectWrapper
  implements Serializable
{
  private WTObject WTObject;

  public KYCWTObjectWrapper(WTObject theWTObject)
  {
    this.WTObject = theWTObject;
  }

  public WTObject getObject()
  {
    return this.WTObject;
  }

  public String toString()
  {
    WTObject theObject = getObject();
    return theObject.getIdentity();
  }
}