package ext.csc.support.domain.util;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JTree;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;

public class KYCDraggableTree extends JTree
  implements MouseListener
{
  boolean sourceOnly;
  KYCTreeLogic theLogic;

  private void checkPopup(MouseEvent e)
  {
    if (e.isPopupTrigger()) {
      Object tempObject = this.theLogic.getNode(e.getX(), e.getY());

      if ((tempObject instanceof KYCWTObjectNode)) {
        KYCWTObjectNode popupNode = (KYCWTObjectNode)tempObject;
        TreeNode[] nodes = popupNode.getPath();
        TreePath treepath = new TreePath(nodes);
        setSelectionPath(treepath);
        new KYCTreePopup(popupNode, this.theLogic).show(this, e.getX(), e.getY());
      }
    }
  }

  public void mousePressed(MouseEvent e) { checkPopup(e); } 
  public void mouseClicked(MouseEvent e) { checkPopup(e); } 
  public void mouseEntered(MouseEvent e) {  } 
  public void mouseExited(MouseEvent e) {  } 
  public void mouseReleased(MouseEvent e) { checkPopup(e); }

  public void setLogic(KYCTreeLogic theLogic) {
    this.theLogic = theLogic;
  }

  public KYCDraggableTree(boolean droppable)
  {
    addMouseListener(this);
  }

  public KYCDraggableTree() {
    this(true);
  }
}