I. For build creation on Windchill follow these instructions

1. delete folder 'src_gen_for_eclipse'
2. use component_FullBuild.xml; delete component.xml and then rename
   component_FullBuild.xml --> component.xml

------------------

II. For compiling in eclipse

1. include folder 'src_gen_for_eclipse'
2. ignore  folder 'src_gen'
