package ext.kb.util;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Set;

import org.junit.Test;

public class KBUtilsTest {

    @Test
    public void testIsEmpty() {
        assertTrue(KBUtils.isEmpty((String)null));
        assertTrue(KBUtils.isEmpty(""));
        assertTrue(KBUtils.isEmpty(" "));
        assertFalse(KBUtils.isEmpty("s"));
        assertFalse(KBUtils.isEmpty("s "));
        assertFalse(KBUtils.isEmpty(" s "));
    }

    @Test
    public void testIsEmptyCollection()
    {
        assertTrue(KBUtils.isEmpty((Collection<?>)null));
        assertTrue(KBUtils.isEmpty(new ArrayList<String>()));
        assertFalse(KBUtils.isEmpty(Arrays.asList("a", "b")));
    }

    @Test
    public void testPopulateAdditionalInventoryColumns()
    {
        
    }
    
    @Test
    public void testGetDateFields() {
        
        Set<String> results = KBUtils.split("singleProperty");
        assertTrue(results.size() == 1);
        assertTrue(results.contains("singleProperty"));
        results = KBUtils.split("prop1,prop2.sub, prop3");
        assertTrue(results.size() == 3);
        assertTrue(results.contains("prop2.sub"));
    }
    
    @Test (expected=RuntimeException.class)
    public void testInvalidCharacters () {
        KBUtils.checkNumberForInvalidCharacters("adak12 4");
    }
    
}
