package ext.kb.dynamiclist.element;

import static org.junit.Assert.*;

import java.util.Set;

import org.junit.Test;

import com.infoengine.object.factory.Att;
import com.infoengine.object.factory.Element;
import com.infoengine.object.factory.Group;
import com.ptc.core.meta.container.common.State;

public class ElementReaderTest {

    @Test
    public void testReadStringElementForDynamicList() {
        //fail("Not yet implemented");
    }

    @Test(expected=NullPointerException.class)
    public void testReadStringElement() {
        
        Group g = new Group();
        Att a = new Att("value", "Value", State.NEW);
        Element e = new Element("testParam");
        e.addAtt(a);
        g.addElement(e);
        Set<String> result = ElementReader.readStringElement(g, "value");
        assertNotNull(result);
        assertEquals(1, result.size());
        assertTrue(result.contains("Value"));

        a = new Att("obid", "Value", State.NEW);
        
        ElementReader.readStringElement(g, "noSuchElement");
    }

}
