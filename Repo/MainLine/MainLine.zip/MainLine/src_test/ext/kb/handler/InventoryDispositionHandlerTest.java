package ext.kb.handler;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import wt.change2.InventoryDisposition;

import ext.kb.enumconstant.InventoryDispositions;

public class InventoryDispositionHandlerTest {

	InventoryDispositionHandler handler = new InventoryDispositionHandler();
	
	@Test
	public void testGetDispositionValue() {
		//handler.getDispositionValue("inventoryDisposition", paramBinaryLink);
	}

	@Test
	public void testSetDispositionValue() {
		//handler.setDispositionValue("finishedDisposition", paramBinaryLink, paramInventoryDisposition);
	}

	@Test
	public void testGetDefaultInventoryDisposition() {
		assertEquals(InventoryDispositions.NOT_AFFECTED, handler.getDefaultInventoryDisposition(null, ""));
	}

	@Test
	public void testGetInventoryDispositionSet() {
		List<InventoryDisposition> dispositions = handler.getInventoryDispositionSet(null, "");
		assertEquals(5, dispositions.size());
		assertTrue(dispositions.contains(InventoryDispositions.DISPOSAL));
		assertTrue(dispositions.contains(InventoryDispositions.NOT_AFFECTED));
		assertTrue(dispositions.contains(InventoryDispositions.RECONDITION));
		assertTrue(dispositions.contains(InventoryDispositions.USE_UP));
		assertTrue(dispositions.contains(InventoryDispositions.SPECIAL_CASES));
	}

}
