package ext.kb.ws;

import java.beans.PropertyVetoException;
import java.io.IOException;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;

import org.apache.log4j.Logger;

import wt.log4j.LogR;
import wt.util.WTException;
import wt.util.WTRuntimeException;

import com.ptc.jws.servlet.JaxWsWebService;

import ext.kb.service.KBECTReportUrlService;

/**
 * Windchill web service to retrieve ECT Report Urls for download. <br>
 */
@WebService()
public class KBECTReportDownloadUrlService extends JaxWsWebService {
    private static Logger log = LogR.getLogger(KBECTReportDownloadUrlService.class.getName());

    /**
     * The exposed web service method to retrieve content Urls.
     * 
     * @param oid the object Id of the content holder in the format:
     *            <b>widchill_object_type:id</b><br>
     *            E.g.: <code>wt.epm.EPMDocument:123456</code>
     * @param user Windchill user name that has access to the given content
     *            holder
     * @return
     */
    @WebMethod(operationName = "getECTReportUrl")
    public List<String> getECTReportUrl(String oid, String user,String mastersystem) {
        log.debug("Web service operation getContentUrls called with OID " + oid);
        try {
            final List<String> result = KBECTReportUrlService.getECTReportUrl(oid, user,mastersystem);
        	//log.debug("oid is "+oid+"user is "+user+"content is "+content);
            return result;
        } catch (WTRuntimeException | WTException | PropertyVetoException | IOException e) {
            log.error(e);
        }
        return null;
    }
}