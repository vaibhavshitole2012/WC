package ext.kb.ws;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import ext.kb.util.UpdateUtil;

import com.ptc.jws.servlet.JaxWsWebService;

@WebService()

public class KBMassUpdateLinkService extends JaxWsWebService
{
    @WebMethod(operationName="massupdate")
    
    public void massupdate( String inputFile, String logDir )
    {
      try {
            UpdateUtil.massUpdateObjects(inputFile, logDir);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}