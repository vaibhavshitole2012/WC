package ext.kb.ws;

import com.ptc.jws.servlet.JaxWsWebService;
import ext.kb.tool.ContractsImportTool;
import org.apache.log4j.Logger;
import wt.log4j.LogR;

import javax.jws.Oneway;
import javax.jws.WebMethod;
import javax.jws.WebService;

@WebService()
public class ContractsImportWebService extends JaxWsWebService
{
    private static Logger log = LogR.getLogger(ContractsImportWebService.class.getName());

    @WebMethod(operationName="importContracts")
    @Oneway
    public void importContracts (String inputFile, String logsPath)
    {
        try {
            ContractsImportTool.importContracts(inputFile, logsPath);
        } catch (Exception e) {
            log.error(e);
        }
    }
}