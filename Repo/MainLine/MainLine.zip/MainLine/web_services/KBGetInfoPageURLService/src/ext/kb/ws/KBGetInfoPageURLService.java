package ext.kb.ws;

import java.util.ArrayList;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

import org.apache.log4j.Logger;

import com.ptc.jws.servlet.JaxWsWebService;

import ext.kb.change2.helper.ChangeQueries;
import wt.util.WTException;

@WebService()
public class KBGetInfoPageURLService extends JaxWsWebService {
	/**
	 * Logger
	 */
	private static final Logger LOGGER = Logger.getLogger(KBGetInfoPageURLService.class);

	@WebMethod(operationName = "getEctInfoURL")
	public List<String> getEctInfoURL(String ectNumber) {
		List<String> result = new ArrayList<String>();

		try {
			result = ChangeQueries.getEctInfoPageURL(ectNumber);
		} catch (WTException exception) {
			LOGGER.error("Exception while getting URL for " + ectNumber, exception);
		}
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Returning  URL ->" + result);
		}
		return result;
	}
}