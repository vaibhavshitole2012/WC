package ext.kb.genericInterface;

import java.util.ArrayList;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

import com.ptc.jws.servlet.JaxWsWebService;
import ext.kb.genericInterface.part.partwebservice.PartObject;
import ext.kb.genericInterface.part.partwebservice.GenericPartHelper;

@WebService()
public class GenericPartWebService extends JaxWsWebService{
	
	@WebMethod(operationName="genericPartService")
	
	public List<String> genericPartService(@WebParam(name="partDetails") ArrayList<PartObject> partDetails)
    {
		List<String>message = new ArrayList();
      try {
            message =  GenericPartHelper.processPart(partDetails);
            
        } catch (Exception e) {
            e.printStackTrace();
        }
      return message;
    }

}
