package ext.kb.ws;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.xml.bind.JAXBException;

import org.apache.log4j.Logger;

import wt.change2.ChangeHelper2;
import wt.change2.WTChangeActivity2;
import wt.doc.WTDocument;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.log4j.LogR;
import wt.part.PartDocHelper;
import wt.part.WTPart;
import wt.pds.StatementSpec;
import wt.pom.Transaction;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.type.TypedUtilityServiceHelper;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import com.ptc.jws.servlet.JaxWsWebService;

import ext.kb.service.WebServiceHelper;
import ext.kb.util.IBAHelper;


@WebService()
public class KBCreateTableDataService extends JaxWsWebService {
	private static final Logger LOGGER = LogR
			.getLogger(KBCreateTableDataService.class.getName());

	@WebMethod(operationName = "CreateTableData")
	public ArrayList<CreateECTTableDataOutput> KBCreateTableData1Service(@WebParam(name = "ectNumber") String ectNumber) throws WTException,
			WTPropertyVetoException, JAXBException, IOException
	{

		 Transaction trx = null;
		 String wtHome = WebServiceHelper.getWindchillHome();
		 LOGGER.debug("WT_HOME : "+wtHome);
		 String LOG_FILE_NAME = wtHome+"/logs/interface";
		 WebServiceHelper.createDirIfNotExisting(LOG_FILE_NAME);
	     LOG_FILE_NAME = wtHome+"/logs/interface/Cadim2WctKBCreateTableData.log";
		// String LOG_FILE_NAME = "/opt/ptc/wt111/Cadim2WctKBCreateTableData.log";
		 PrintWriter logPw = null;
		 FileWriter fw = null;
		 BufferedWriter bw = null;
		 File file = new File(LOG_FILE_NAME);
		 file.setExecutable(true, false);
         file.setReadable(true, false);
         file.setWritable(true, false);
         LOGGER.debug("After getting log file ==="+file);
         fw = new FileWriter(LOG_FILE_NAME,true);
         bw = new BufferedWriter(fw);
         logPw = new PrintWriter(bw);
         SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
         Date date = new Date();
         String formatedDate = sdf.format(date);
		 List<String> result = new ArrayList<String>();
		 HashMap <String,WTPart> affectedParts = new HashMap<String,WTPart>();
		 HashMap <String,WTPart> resultingParts = new HashMap<String,WTPart>();

		 ArrayList<CreateECTTableDataOutput> outputArr = new ArrayList<CreateECTTableDataOutput>();
		 		
		try {

			trx = new Transaction();
			trx.start();
			logPw.println("Processing KBCreateTableDataService request on "+formatedDate+" for object where number is "+ectNumber);
			QuerySpec qsect = new QuerySpec(WTChangeActivity2.class);
			LOGGER.debug("ectNumber" + ectNumber);
			qsect.appendWhere(new SearchCondition(WTChangeActivity2.class, WTChangeActivity2.NUMBER, SearchCondition.EQUAL, ectNumber, false));
			QueryResult qrect = PersistenceHelper.manager.find((StatementSpec) qsect);
			LOGGER.debug("qrect.size(): " + qrect.size());
			if(qrect.size()>0)
			{
				WTChangeActivity2 ect =  (WTChangeActivity2)qrect.nextElement();
				LOGGER.debug("ect number " + ect.getNumber());
				logPw.println("ect number " + ect.getNumber());
				QueryResult affectedObjects = ChangeHelper2.service.getChangeablesBefore(ect);
				QueryResult resultingObjects = ChangeHelper2.service.getChangeablesAfter(ect);
		
			
				while(affectedObjects.hasMoreElements())
				{
					Object nextElement = affectedObjects.nextElement();
					if(nextElement instanceof WTPart){
						WTPart part=(WTPart)nextElement;
						if("Design".equalsIgnoreCase(part.getViewName()))
						affectedParts.put(part.getNumber(),part);
						LOGGER.debug("Affected Part :: "+nextElement);
					}
				}
				while(resultingObjects.hasMoreElements())
				{
					Object nextElement = resultingObjects.nextElement();
					if(nextElement instanceof WTPart){
						WTPart part=(WTPart)nextElement;
						if(!affectedParts.containsValue(part) && "Design".equalsIgnoreCase(part.getViewName())){
						resultingParts.put(part.getNumber(),part);
						}
						LOGGER.debug("resultingParts Part :: "+nextElement);
					}
				}
				
				
				Iterator itResPart = resultingParts.keySet().iterator();
				LOGGER.debug("resultingPart size::>>"+resultingParts.size());
				while(itResPart.hasNext())
				{
					String resultingPartnumber = (String) itResPart.next();
					LOGGER.debug("resultingpartNumber" + resultingPartnumber);
					logPw.println("resultingpartNumber " + resultingPartnumber);

					if(affectedParts.containsKey(resultingPartnumber)){
						WTPart affectedPart=affectedParts.get(resultingPartnumber);
						WTPart resultingPart = resultingParts.get(resultingPartnumber);
						LOGGER.debug("affectedPartNumber" + affectedPart.getNumber());
						logPw.println("affectedPartNumber " + affectedPart.getNumber());
						QueryResult resPartDocs = PartDocHelper.service.getAssociatedDocuments(resultingPart);
							LOGGER.debug("resPartDocs size " + resPartDocs.size());
							logPw.println("resPartDocs size " + resPartDocs.size());
							HashMap<String,WTDocument> resultingpartdoc=new HashMap<>();
							while(resPartDocs.hasMoreElements())
							{
								Persistable relatedDoc = (Persistable) resPartDocs.nextElement();
								if(relatedDoc instanceof WTDocument)
								{
									String relatedDocNumber = ((WTDocument) relatedDoc).getNumber();
									LOGGER.debug("relatedDocNumber " + relatedDocNumber);
									logPw.println("relatedDocNumber " + relatedDocNumber);
									resultingpartdoc.put(relatedDocNumber, (WTDocument) relatedDoc);
								}
							}
							QueryResult affPartDocs = PartDocHelper.service.getAssociatedDocuments(affectedPart);
							LOGGER.debug("affPartDocs size " + affPartDocs.size());
							logPw.println("affPartDocs size " + affPartDocs.size());
							HashMap<String,WTDocument> relatedaffectedocmap=new HashMap<>();
							
							while(affPartDocs.hasMoreElements())
							{
								Persistable relatedAffDoc = (Persistable) affPartDocs.nextElement();
								if(relatedAffDoc instanceof WTDocument)
								{
									String relatedAffDocNumber = ((WTDocument) relatedAffDoc).getNumber();
									LOGGER.debug("relatedAffDocNumber " + relatedAffDocNumber);
									relatedaffectedocmap.put(relatedAffDocNumber, (WTDocument) relatedAffDoc);
								}
							}
							Iterator iterator=resultingpartdoc.keySet().iterator();
							
						
							while(iterator.hasNext()){
								String relatedDocNumber=(String) iterator.next();
								if(!relatedaffectedocmap.containsKey(relatedDocNumber)){
								WTDocument resultingdoc=resultingpartdoc.get(relatedDocNumber);
								String docRev = resultingdoc.getVersionInfo().getIdentifier().getValue();
								String typeName = TypedUtilityServiceHelper.service.getTypeIdentifier(resultingdoc).getTypename();
								String contentType = IBAHelper.readIBA(resultingdoc,"KB_DOC_CONTENT_TYPE");
								CreateECTTableDataOutput output = new CreateECTTableDataOutput();
								output.setPartNumber(resultingPartnumber);
								output.setDocNumber(relatedDocNumber);
								output.setRevision(docRev);
								output.setType(typeName);
								output.setContentType(contentType);
								output.setSign("+");
								outputArr.add(output);	
								LOGGER.debug("doc added to Changed Document " + ((WTDocument) resultingdoc).getNumber());
								logPw.println("doc added to Changed Document " + ((WTDocument) resultingdoc).getNumber());
								}
							}
							
							Iterator iterator1=relatedaffectedocmap.keySet().iterator();
							while(iterator1.hasNext()){
								String relatedDocNumber=(String) iterator1.next();
								if(!resultingpartdoc.containsKey(relatedDocNumber)){
								WTDocument affecteddoc=relatedaffectedocmap.get(relatedDocNumber);
								String docRev = affecteddoc.getVersionInfo().getIdentifier().getValue();
								String typeName = TypedUtilityServiceHelper.service.getTypeIdentifier(affecteddoc).getTypename();
								String contentType = IBAHelper.readIBA(affecteddoc,"KB_DOC_CONTENT_TYPE");
								CreateECTTableDataOutput output = new CreateECTTableDataOutput();
								output.setPartNumber(resultingPartnumber);
								output.setDocNumber(relatedDocNumber);
								output.setRevision(docRev);
								output.setType(typeName);
								output.setContentType(contentType);
								output.setSign("-");
								outputArr.add(output);	
								LOGGER.debug("doc added to Changed Document " + ((WTDocument) affecteddoc).getNumber());
								logPw.println("doc added to Changed Document " + ((WTDocument) affecteddoc).getNumber());
								}
							}
						}
						}
				}
				else{
					throw new WTException("ECT with number "+ectNumber+" not found");
				}
			System.out.println("trx===" + trx);
			trx.commit();
			trx = null;
			trx = null;
			SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
         		Date date1 = new Date();
        		 String formatedDate1 = sdf1.format(date1);
			logPw.println("Processing KBCreateTableDataService request  ends on "+formatedDate1+" for object where number is "+ectNumber);

			return outputArr;
		} catch (WTException e) {
			ArrayList<CreateECTTableDataOutput> errorOutputArr = new ArrayList<CreateECTTableDataOutput>();
			CreateECTTableDataOutput errorOutput = new CreateECTTableDataOutput();
			String message = "WTException during Table Data creation exception is " + e;
			errorOutput.setError(message);
			errorOutputArr.add(errorOutput);
            return errorOutputArr;

		}  finally {
			System.out.println("trx in finally===" + trx);
			if (trx != null) {
				trx.rollback();
				}
				logPw.flush();
	            logPw.close();
			
		}
	}
	
}