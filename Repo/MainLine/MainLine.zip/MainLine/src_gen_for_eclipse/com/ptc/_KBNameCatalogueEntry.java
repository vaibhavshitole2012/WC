package com.ptc;

@SuppressWarnings({"cast", "deprecation", "rawtypes", "unchecked"})
public abstract class _KBNameCatalogueEntry extends wt.fc.WTObject implements wt.access.AccessControlled, wt.access.PolicyAccessControlled, wt.inf.container.WTContained, wt.type.TypeManaged, java.io.Externalizable {
   static final long serialVersionUID = 1;

   static final java.lang.String RESOURCE = "com.ptc.ptcResource";
   static final java.lang.String CLASSNAME = KBNameCatalogueEntry.class.getName();

   /**
    * @see com.ptc.KBNameCatalogueEntry
    */
   public static final java.lang.String SOURCE_LANGUAGE = "sourceLanguage";
   static int SOURCE_LANGUAGE_UPPER_LIMIT = -1;
   java.lang.String sourceLanguage;
   /**
    * @see com.ptc.KBNameCatalogueEntry
    */
   public java.lang.String getSourceLanguage() {
      return sourceLanguage;
   }
   /**
    * @see com.ptc.KBNameCatalogueEntry
    */
   public void setSourceLanguage(java.lang.String sourceLanguage) throws wt.util.WTPropertyVetoException {
      sourceLanguageValidate(sourceLanguage);
      this.sourceLanguage = sourceLanguage;
   }
   void sourceLanguageValidate(java.lang.String sourceLanguage) throws wt.util.WTPropertyVetoException {
      if (sourceLanguage == null || sourceLanguage.trim().length() == 0)
         throw new wt.util.WTPropertyVetoException("wt.fc.fcResource", wt.fc.fcResource.REQUIRED_ATTRIBUTE,
               new java.lang.Object[] { new wt.introspection.PropertyDisplayName(CLASSNAME, "sourceLanguage") },
               new java.beans.PropertyChangeEvent(this, "sourceLanguage", this.sourceLanguage, sourceLanguage));
      if (SOURCE_LANGUAGE_UPPER_LIMIT < 1) {
         try { SOURCE_LANGUAGE_UPPER_LIMIT = (java.lang.Integer) wt.introspection.WTIntrospector.getClassInfo(CLASSNAME).getPropertyDescriptor("sourceLanguage").getValue(wt.introspection.WTIntrospector.UPPER_LIMIT); }
         catch (wt.introspection.WTIntrospectionException e) { SOURCE_LANGUAGE_UPPER_LIMIT = 200; }
      }
      if (sourceLanguage != null && !wt.fc.PersistenceHelper.checkStoredLength(sourceLanguage.toString(), SOURCE_LANGUAGE_UPPER_LIMIT, true))
         throw new wt.util.WTPropertyVetoException("wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT,
               new java.lang.Object[] { new wt.introspection.PropertyDisplayName(CLASSNAME, "sourceLanguage"), java.lang.String.valueOf(java.lang.Math.min(SOURCE_LANGUAGE_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) },
               new java.beans.PropertyChangeEvent(this, "sourceLanguage", this.sourceLanguage, sourceLanguage));
   }

   /**
    * @see com.ptc.KBNameCatalogueEntry
    */
   public static final java.lang.String ENGLISH = "english";
   static int ENGLISH_UPPER_LIMIT = -1;
   java.lang.String english;
   /**
    * @see com.ptc.KBNameCatalogueEntry
    */
   public java.lang.String getEnglish() {
      return english;
   }
   /**
    * @see com.ptc.KBNameCatalogueEntry
    */
   public void setEnglish(java.lang.String english) throws wt.util.WTPropertyVetoException {
      englishValidate(english);
      this.english = english;
   }
   void englishValidate(java.lang.String english) throws wt.util.WTPropertyVetoException {
      if (ENGLISH_UPPER_LIMIT < 1) {
         try { ENGLISH_UPPER_LIMIT = (java.lang.Integer) wt.introspection.WTIntrospector.getClassInfo(CLASSNAME).getPropertyDescriptor("english").getValue(wt.introspection.WTIntrospector.UPPER_LIMIT); }
         catch (wt.introspection.WTIntrospectionException e) { ENGLISH_UPPER_LIMIT = 200; }
      }
      if (english != null && !wt.fc.PersistenceHelper.checkStoredLength(english.toString(), ENGLISH_UPPER_LIMIT, true))
         throw new wt.util.WTPropertyVetoException("wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT,
               new java.lang.Object[] { new wt.introspection.PropertyDisplayName(CLASSNAME, "english"), java.lang.String.valueOf(java.lang.Math.min(ENGLISH_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) },
               new java.beans.PropertyChangeEvent(this, "english", this.english, english));
   }

   /**
    * @see com.ptc.KBNameCatalogueEntry
    */
   public static final java.lang.String GERMAN = "german";
   static int GERMAN_UPPER_LIMIT = -1;
   java.lang.String german;
   /**
    * @see com.ptc.KBNameCatalogueEntry
    */
   public java.lang.String getGerman() {
      return german;
   }
   /**
    * @see com.ptc.KBNameCatalogueEntry
    */
   public void setGerman(java.lang.String german) throws wt.util.WTPropertyVetoException {
      germanValidate(german);
      this.german = german;
   }
   void germanValidate(java.lang.String german) throws wt.util.WTPropertyVetoException {
      if (GERMAN_UPPER_LIMIT < 1) {
         try { GERMAN_UPPER_LIMIT = (java.lang.Integer) wt.introspection.WTIntrospector.getClassInfo(CLASSNAME).getPropertyDescriptor("german").getValue(wt.introspection.WTIntrospector.UPPER_LIMIT); }
         catch (wt.introspection.WTIntrospectionException e) { GERMAN_UPPER_LIMIT = 200; }
      }
      if (german != null && !wt.fc.PersistenceHelper.checkStoredLength(german.toString(), GERMAN_UPPER_LIMIT, true))
         throw new wt.util.WTPropertyVetoException("wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT,
               new java.lang.Object[] { new wt.introspection.PropertyDisplayName(CLASSNAME, "german"), java.lang.String.valueOf(java.lang.Math.min(GERMAN_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) },
               new java.beans.PropertyChangeEvent(this, "german", this.german, german));
   }

   /**
    * @see com.ptc.KBNameCatalogueEntry
    */
   public static final java.lang.String FRENCH = "french";
   static int FRENCH_UPPER_LIMIT = -1;
   java.lang.String french;
   /**
    * @see com.ptc.KBNameCatalogueEntry
    */
   public java.lang.String getFrench() {
      return french;
   }
   /**
    * @see com.ptc.KBNameCatalogueEntry
    */
   public void setFrench(java.lang.String french) throws wt.util.WTPropertyVetoException {
      frenchValidate(french);
      this.french = french;
   }
   void frenchValidate(java.lang.String french) throws wt.util.WTPropertyVetoException {
      if (FRENCH_UPPER_LIMIT < 1) {
         try { FRENCH_UPPER_LIMIT = (java.lang.Integer) wt.introspection.WTIntrospector.getClassInfo(CLASSNAME).getPropertyDescriptor("french").getValue(wt.introspection.WTIntrospector.UPPER_LIMIT); }
         catch (wt.introspection.WTIntrospectionException e) { FRENCH_UPPER_LIMIT = 200; }
      }
      if (french != null && !wt.fc.PersistenceHelper.checkStoredLength(french.toString(), FRENCH_UPPER_LIMIT, true))
         throw new wt.util.WTPropertyVetoException("wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT,
               new java.lang.Object[] { new wt.introspection.PropertyDisplayName(CLASSNAME, "french"), java.lang.String.valueOf(java.lang.Math.min(FRENCH_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) },
               new java.beans.PropertyChangeEvent(this, "french", this.french, french));
   }

   /**
    * @see com.ptc.KBNameCatalogueEntry
    */
   public static final java.lang.String ITALIAN = "italian";
   static int ITALIAN_UPPER_LIMIT = -1;
   java.lang.String italian;
   /**
    * @see com.ptc.KBNameCatalogueEntry
    */
   public java.lang.String getItalian() {
      return italian;
   }
   /**
    * @see com.ptc.KBNameCatalogueEntry
    */
   public void setItalian(java.lang.String italian) throws wt.util.WTPropertyVetoException {
      italianValidate(italian);
      this.italian = italian;
   }
   void italianValidate(java.lang.String italian) throws wt.util.WTPropertyVetoException {
      if (ITALIAN_UPPER_LIMIT < 1) {
         try { ITALIAN_UPPER_LIMIT = (java.lang.Integer) wt.introspection.WTIntrospector.getClassInfo(CLASSNAME).getPropertyDescriptor("italian").getValue(wt.introspection.WTIntrospector.UPPER_LIMIT); }
         catch (wt.introspection.WTIntrospectionException e) { ITALIAN_UPPER_LIMIT = 200; }
      }
      if (italian != null && !wt.fc.PersistenceHelper.checkStoredLength(italian.toString(), ITALIAN_UPPER_LIMIT, true))
         throw new wt.util.WTPropertyVetoException("wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT,
               new java.lang.Object[] { new wt.introspection.PropertyDisplayName(CLASSNAME, "italian"), java.lang.String.valueOf(java.lang.Math.min(ITALIAN_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) },
               new java.beans.PropertyChangeEvent(this, "italian", this.italian, italian));
   }

   /**
    * @see com.ptc.KBNameCatalogueEntry
    */
   public static final java.lang.String SPANISH = "spanish";
   static int SPANISH_UPPER_LIMIT = -1;
   java.lang.String spanish;
   /**
    * @see com.ptc.KBNameCatalogueEntry
    */
   public java.lang.String getSpanish() {
      return spanish;
   }
   /**
    * @see com.ptc.KBNameCatalogueEntry
    */
   public void setSpanish(java.lang.String spanish) throws wt.util.WTPropertyVetoException {
      spanishValidate(spanish);
      this.spanish = spanish;
   }
   void spanishValidate(java.lang.String spanish) throws wt.util.WTPropertyVetoException {
      if (SPANISH_UPPER_LIMIT < 1) {
         try { SPANISH_UPPER_LIMIT = (java.lang.Integer) wt.introspection.WTIntrospector.getClassInfo(CLASSNAME).getPropertyDescriptor("spanish").getValue(wt.introspection.WTIntrospector.UPPER_LIMIT); }
         catch (wt.introspection.WTIntrospectionException e) { SPANISH_UPPER_LIMIT = 200; }
      }
      if (spanish != null && !wt.fc.PersistenceHelper.checkStoredLength(spanish.toString(), SPANISH_UPPER_LIMIT, true))
         throw new wt.util.WTPropertyVetoException("wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT,
               new java.lang.Object[] { new wt.introspection.PropertyDisplayName(CLASSNAME, "spanish"), java.lang.String.valueOf(java.lang.Math.min(SPANISH_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) },
               new java.beans.PropertyChangeEvent(this, "spanish", this.spanish, spanish));
   }

   /**
    * @see com.ptc.KBNameCatalogueEntry
    */
   public static final java.lang.String PORTUGUESE = "portuguese";
   static int PORTUGUESE_UPPER_LIMIT = -1;
   java.lang.String portuguese;
   /**
    * @see com.ptc.KBNameCatalogueEntry
    */
   public java.lang.String getPortuguese() {
      return portuguese;
   }
   /**
    * @see com.ptc.KBNameCatalogueEntry
    */
   public void setPortuguese(java.lang.String portuguese) throws wt.util.WTPropertyVetoException {
      portugueseValidate(portuguese);
      this.portuguese = portuguese;
   }
   void portugueseValidate(java.lang.String portuguese) throws wt.util.WTPropertyVetoException {
      if (PORTUGUESE_UPPER_LIMIT < 1) {
         try { PORTUGUESE_UPPER_LIMIT = (java.lang.Integer) wt.introspection.WTIntrospector.getClassInfo(CLASSNAME).getPropertyDescriptor("portuguese").getValue(wt.introspection.WTIntrospector.UPPER_LIMIT); }
         catch (wt.introspection.WTIntrospectionException e) { PORTUGUESE_UPPER_LIMIT = 200; }
      }
      if (portuguese != null && !wt.fc.PersistenceHelper.checkStoredLength(portuguese.toString(), PORTUGUESE_UPPER_LIMIT, true))
         throw new wt.util.WTPropertyVetoException("wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT,
               new java.lang.Object[] { new wt.introspection.PropertyDisplayName(CLASSNAME, "portuguese"), java.lang.String.valueOf(java.lang.Math.min(PORTUGUESE_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) },
               new java.beans.PropertyChangeEvent(this, "portuguese", this.portuguese, portuguese));
   }

   /**
    * @see com.ptc.KBNameCatalogueEntry
    */
   public static final java.lang.String CHINESE = "chinese";
   static int CHINESE_UPPER_LIMIT = -1;
   java.lang.String chinese;
   /**
    * @see com.ptc.KBNameCatalogueEntry
    */
   public java.lang.String getChinese() {
      return chinese;
   }
   /**
    * @see com.ptc.KBNameCatalogueEntry
    */
   public void setChinese(java.lang.String chinese) throws wt.util.WTPropertyVetoException {
      chineseValidate(chinese);
      this.chinese = chinese;
   }
   void chineseValidate(java.lang.String chinese) throws wt.util.WTPropertyVetoException {
      if (CHINESE_UPPER_LIMIT < 1) {
         try { CHINESE_UPPER_LIMIT = (java.lang.Integer) wt.introspection.WTIntrospector.getClassInfo(CLASSNAME).getPropertyDescriptor("chinese").getValue(wt.introspection.WTIntrospector.UPPER_LIMIT); }
         catch (wt.introspection.WTIntrospectionException e) { CHINESE_UPPER_LIMIT = 200; }
      }
      if (chinese != null && !wt.fc.PersistenceHelper.checkStoredLength(chinese.toString(), CHINESE_UPPER_LIMIT, true))
         throw new wt.util.WTPropertyVetoException("wt.introspection.introspectionResource", wt.introspection.introspectionResource.UPPER_LIMIT,
               new java.lang.Object[] { new wt.introspection.PropertyDisplayName(CLASSNAME, "chinese"), java.lang.String.valueOf(java.lang.Math.min(CHINESE_UPPER_LIMIT, wt.fc.PersistenceHelper.DB_MAX_SQL_STRING_SIZE/wt.fc.PersistenceHelper.DB_MAX_BYTES_PER_CHAR)) },
               new java.beans.PropertyChangeEvent(this, "chinese", this.chinese, chinese));
   }

   /**
    * @see com.ptc.KBNameCatalogueEntry
    */
   public static final java.lang.String SELECTABLE = "selectable";
   java.lang.Boolean selectable;
   /**
    * @see com.ptc.KBNameCatalogueEntry
    */
   public java.lang.Boolean getSelectable() {
      return selectable;
   }
   /**
    * @see com.ptc.KBNameCatalogueEntry
    */
   public void setSelectable(java.lang.Boolean selectable) throws wt.util.WTPropertyVetoException {
      selectableValidate(selectable);
      this.selectable = selectable;
   }
   void selectableValidate(java.lang.Boolean selectable) throws wt.util.WTPropertyVetoException {
      if (selectable == null)
         throw new wt.util.WTPropertyVetoException("wt.fc.fcResource", wt.fc.fcResource.REQUIRED_ATTRIBUTE,
               new java.lang.Object[] { new wt.introspection.PropertyDisplayName(CLASSNAME, "selectable") },
               new java.beans.PropertyChangeEvent(this, "selectable", this.selectable, selectable));
   }

   boolean inheritedDomain;
   /**
    * A boolean indicating whether the administrative domain is inherited. If the value is true, the domain is inherited from a parent object.
    *
    * @see wt.admin.DomainAdministered
    */
   public boolean isInheritedDomain() {
      return inheritedDomain;
   }
   /**
    * A boolean indicating whether the administrative domain is inherited. If the value is true, the domain is inherited from a parent object.
    *
    * @see wt.admin.DomainAdministered
    */
   public void setInheritedDomain(boolean inheritedDomain) throws wt.util.WTPropertyVetoException {
      inheritedDomainValidate(inheritedDomain);
      this.inheritedDomain = inheritedDomain;
   }
   void inheritedDomainValidate(boolean inheritedDomain) throws wt.util.WTPropertyVetoException {
   }

   wt.admin.AdminDomainRef domainRef;
   /**
    * @see wt.admin.DomainAdministered
    */
   public wt.admin.AdminDomainRef getDomainRef() {
      return domainRef;
   }
   /**
    * @see wt.admin.DomainAdministered
    */
   public void setDomainRef(wt.admin.AdminDomainRef domainRef) {
      this.domainRef = domainRef;
   }

   wt.fc.adminlock.AdministrativeLock administrativeLock;
   /**
    * An administrative lock. An administrative lock requires some form of validation to determine whether an authenticated user is authorized to perform actions on an instance.<P><B>Note:</B>This property is only to be modified by the <code>wt.fc.adminlock</code> package. Other code should use the methods provided by the <code>wt.fc.adminlock.AdministrativeLockHelper</code> and <code>wt.fc.adminlock.AdministrativeLockServerHelper</code> to get or set the administrative lock.
    *
    * @see wt.fc.adminlock.AdministrativelyLockable
    */
   public wt.fc.adminlock.AdministrativeLock getAdministrativeLock() {
      return administrativeLock;
   }
   /**
    * An administrative lock. An administrative lock requires some form of validation to determine whether an authenticated user is authorized to perform actions on an instance.<P><B>Note:</B>This property is only to be modified by the <code>wt.fc.adminlock</code> package. Other code should use the methods provided by the <code>wt.fc.adminlock.AdministrativeLockHelper</code> and <code>wt.fc.adminlock.AdministrativeLockServerHelper</code> to get or set the administrative lock.
    *
    * @see wt.fc.adminlock.AdministrativelyLockable
    */
   public void setAdministrativeLock(wt.fc.adminlock.AdministrativeLock administrativeLock) throws wt.util.WTPropertyVetoException {
      administrativeLockValidate(administrativeLock);
      this.administrativeLock = administrativeLock;
   }
   void administrativeLockValidate(wt.fc.adminlock.AdministrativeLock administrativeLock) throws wt.util.WTPropertyVetoException {
   }

   /**
    * Derived from {@link wt.inf.container.WTContainerRef#getName()}
    *
    * @see wt.inf.container.WTContained
    */
   public java.lang.String getContainerName() {
      try { return (java.lang.String) ((wt.inf.container.WTContainerRef) getContainerReference()).getName(); }
      catch (java.lang.NullPointerException npe) { return null; }
   }

   wt.inf.container.WTContainerRef containerReference;
   /**
    * @see wt.inf.container.WTContained
    */
   public wt.inf.container.WTContainer getContainer() {
      return (containerReference != null) ? (wt.inf.container.WTContainer) containerReference.getObject() : null;
   }
   /**
    * @see wt.inf.container.WTContained
    */
   public wt.inf.container.WTContainerRef getContainerReference() {
      return containerReference;
   }
   /**
    * @see wt.inf.container.WTContained
    */
   public void setContainer(wt.inf.container.WTContainer the_container) throws wt.util.WTPropertyVetoException, wt.util.WTException {
      setContainerReference(the_container == null ? null : wt.inf.container.WTContainerRef.newWTContainerRef((wt.inf.container.WTContainer) the_container));
   }
   /**
    * @see wt.inf.container.WTContained
    */
   public void setContainerReference(wt.inf.container.WTContainerRef the_containerReference) throws wt.util.WTPropertyVetoException {
      containerReferenceValidate(the_containerReference);
      containerReference = (wt.inf.container.WTContainerRef) the_containerReference;
   }
   void containerReferenceValidate(wt.inf.container.WTContainerRef the_containerReference) throws wt.util.WTPropertyVetoException {
      if (the_containerReference == null || the_containerReference.getReferencedClass() == null)
         throw new wt.util.WTPropertyVetoException("wt.introspection.introspectionResource", wt.introspection.introspectionResource.REQUIRED_ATTRIBUTE,
               new java.lang.Object[] { new wt.introspection.PropertyDisplayName(CLASSNAME, "containerReference") },
               new java.beans.PropertyChangeEvent(this, "containerReference", this.containerReference, containerReference));
      if (the_containerReference != null && the_containerReference.getReferencedClass() != null &&
            !wt.inf.container.WTContainer.class.isAssignableFrom(the_containerReference.getReferencedClass()))
         throw new wt.util.WTPropertyVetoException("wt.introspection.introspectionResource", wt.introspection.introspectionResource.WRONG_TYPE,
               new java.lang.Object[] { new wt.introspection.PropertyDisplayName(CLASSNAME, "containerReference"), "WTContainerRef" },
               new java.beans.PropertyChangeEvent(this, "containerReference", this.containerReference, containerReference));
   }

   public java.lang.String getConceptualClassname() {
      return CLASSNAME;
   }

   public wt.introspection.ClassInfo getClassInfo() throws wt.introspection.WTIntrospectionException {
      return wt.introspection.WTIntrospector.getClassInfo(getConceptualClassname());
   }

   public java.lang.String getType() {
      try { return getClassInfo().getDisplayName(); }
      catch (wt.introspection.WTIntrospectionException wte) { return wt.util.WTStringUtilities.tail(getConceptualClassname(), '.'); }
   }

   public static final long EXTERNALIZATION_VERSION_UID = -371502941203076502L;

   public void writeExternal(java.io.ObjectOutput output) throws java.io.IOException {
      output.writeLong( EXTERNALIZATION_VERSION_UID );

      super.writeExternal( output );

      output.writeObject( administrativeLock );
      output.writeObject( chinese );
      output.writeObject( containerReference );
      output.writeObject( domainRef );
      output.writeObject( english );
      output.writeObject( french );
      output.writeObject( german );
      output.writeBoolean( inheritedDomain );
      output.writeObject( italian );
      output.writeObject( portuguese );
      output.writeObject( selectable );
      output.writeObject( sourceLanguage );
      output.writeObject( spanish );
   }

   protected void super_writeExternal_KBNameCatalogueEntry(java.io.ObjectOutput output) throws java.io.IOException {
      super.writeExternal(output);
   }

   public void readExternal(java.io.ObjectInput input) throws java.io.IOException, java.lang.ClassNotFoundException {
      long readSerialVersionUID = input.readLong();
      readVersion( (com.ptc.KBNameCatalogueEntry) this, input, readSerialVersionUID, false, false );
   }
   protected void super_readExternal_KBNameCatalogueEntry(java.io.ObjectInput input) throws java.io.IOException, java.lang.ClassNotFoundException {
      super.readExternal(input);
   }

   public void writeExternal(wt.pds.PersistentStoreIfc output) throws java.sql.SQLException, wt.pom.DatastoreException {
      super.writeExternal( output );

      output.writeObject( "administrativeLock", administrativeLock, wt.fc.adminlock.AdministrativeLock.class, false );
      output.setString( "chinese", chinese );
      output.writeObject( "containerReference", containerReference, wt.inf.container.WTContainerRef.class, true );
      output.writeObject( "domainRef", domainRef, wt.admin.AdminDomainRef.class, true );
      output.setString( "english", english );
      output.setString( "french", french );
      output.setString( "german", german );
      output.setBoolean( "inheritedDomain", inheritedDomain );
      output.setString( "italian", italian );
      output.setString( "portuguese", portuguese );
      output.setBooleanObject( "selectable", selectable );
      output.setString( "sourceLanguage", sourceLanguage );
      output.setString( "spanish", spanish );
   }

   public void readExternal(wt.pds.PersistentRetrieveIfc input) throws java.sql.SQLException, wt.pom.DatastoreException {
      super.readExternal( input );

      administrativeLock = (wt.fc.adminlock.AdministrativeLock) input.readObject( "administrativeLock", administrativeLock, wt.fc.adminlock.AdministrativeLock.class, false );
      chinese = input.getString( "chinese" );
      containerReference = (wt.inf.container.WTContainerRef) input.readObject( "containerReference", containerReference, wt.inf.container.WTContainerRef.class, true );
      domainRef = (wt.admin.AdminDomainRef) input.readObject( "domainRef", domainRef, wt.admin.AdminDomainRef.class, true );
      english = input.getString( "english" );
      french = input.getString( "french" );
      german = input.getString( "german" );
      inheritedDomain = input.getBoolean( "inheritedDomain" );
      italian = input.getString( "italian" );
      portuguese = input.getString( "portuguese" );
      selectable = input.getBooleanObject( "selectable" );
      sourceLanguage = input.getString( "sourceLanguage" );
      spanish = input.getString( "spanish" );
   }

   boolean readVersion_371502941203076502L( java.io.ObjectInput input, long readSerialVersionUID, boolean superDone ) throws java.io.IOException, java.lang.ClassNotFoundException {
      if ( !superDone )
         super.readExternal( input );

      administrativeLock = (wt.fc.adminlock.AdministrativeLock) input.readObject();
      chinese = (java.lang.String) input.readObject();
      containerReference = (wt.inf.container.WTContainerRef) input.readObject();
      domainRef = (wt.admin.AdminDomainRef) input.readObject();
      english = (java.lang.String) input.readObject();
      french = (java.lang.String) input.readObject();
      german = (java.lang.String) input.readObject();
      inheritedDomain = input.readBoolean();
      italian = (java.lang.String) input.readObject();
      portuguese = (java.lang.String) input.readObject();
      selectable = (java.lang.Boolean) input.readObject();
      sourceLanguage = (java.lang.String) input.readObject();
      spanish = (java.lang.String) input.readObject();
      return true;
   }

   protected boolean readVersion( KBNameCatalogueEntry thisObject, java.io.ObjectInput input, long readSerialVersionUID, boolean passThrough, boolean superDone ) throws java.io.IOException, java.lang.ClassNotFoundException {
      boolean success = true;

      if ( readSerialVersionUID == EXTERNALIZATION_VERSION_UID )
         return readVersion_371502941203076502L( input, readSerialVersionUID, superDone );
      else
         success = readOldVersion( input, readSerialVersionUID, passThrough, superDone );

      if (input instanceof wt.pds.PDSObjectInput)
         wt.fc.EvolvableHelper.requestRewriteOfEvolvedBlobbedObject();

      return success;
   }
   protected boolean super_readVersion_KBNameCatalogueEntry( _KBNameCatalogueEntry thisObject, java.io.ObjectInput input, long readSerialVersionUID, boolean passThrough, boolean superDone ) throws java.io.IOException, java.lang.ClassNotFoundException {
      return super.readVersion(thisObject, input, readSerialVersionUID, passThrough, superDone);
   }

   boolean readOldVersion( java.io.ObjectInput input, long readSerialVersionUID, boolean passThrough, boolean superDone ) throws java.io.IOException, java.lang.ClassNotFoundException {
      throw new java.io.InvalidClassException(CLASSNAME, "Local class not compatible: stream classdesc externalizationVersionUID="+readSerialVersionUID+" local class externalizationVersionUID="+EXTERNALIZATION_VERSION_UID);
   }
}
