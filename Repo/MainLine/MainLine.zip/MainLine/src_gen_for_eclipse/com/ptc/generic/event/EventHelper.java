package com.ptc.generic.event;


public class EventHelper {

    
    public static final com.ptc.generic.event.EventService service = wt.services.ServiceFactory.getService(com.ptc.generic.event.EventService.class);

}
