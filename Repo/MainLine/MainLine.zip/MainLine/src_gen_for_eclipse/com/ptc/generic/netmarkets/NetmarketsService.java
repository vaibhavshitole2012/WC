package com.ptc.generic.netmarkets;



@wt.method.RemoteInterface
public interface NetmarketsService extends wt.method.RemoteAccess {

    
    public java.net.URL getInfoPageActionURL(java.lang.String oid, java.lang.String actionType, java.lang.String actionName, boolean useLatest)
        throws wt.util.WTException;

    
    public java.net.URL getInfoPageURL(java.lang.String oid, boolean useLatest)
        throws wt.util.WTException;

    
    public java.net.URL getDirectWizardURL(java.lang.String oid, java.lang.String actionType, java.lang.String actionName, boolean useLatest)
        throws wt.util.WTException;

    
    public java.net.URL getDirectWizardURL(java.lang.String oid, java.lang.String actionType, java.lang.String actionName, boolean useLatest, java.util.Map<java.lang.String,java.lang.String> addtionalParams)
        throws wt.util.WTException;

    
    public java.net.URL createUrlToInfoPageOfObject(java.lang.String oid)
        throws wt.util.WTException;

    public java.lang.Object getSessionValue(com.ptc.netmarkets.util.beans.NmCommandBean commandBean, java.lang.String context, java.lang.String attribute);

    public java.lang.Object getSessionValue(com.ptc.core.ui.validation.UIValidationCriteria criteria, java.lang.String context, java.lang.String attribute);

    public void putSessionValue(com.ptc.netmarkets.util.beans.NmCommandBean commandBean, java.lang.String context, java.lang.String name, java.lang.Object value);

    public void putSessionValue(com.ptc.core.ui.validation.UIValidationCriteria criteria, java.lang.String context, java.lang.String name, java.lang.Object value);

}
