package com.ptc.generic.userprefs;


public class UserPrefsHelper {

    
    public static final com.ptc.generic.userprefs.UserPrefsService service = wt.services.ServiceFactory.getService(com.ptc.generic.userprefs.UserPrefsService.class);

}
