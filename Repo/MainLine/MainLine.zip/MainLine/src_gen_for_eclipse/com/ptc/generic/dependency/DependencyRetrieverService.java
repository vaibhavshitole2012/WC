package com.ptc.generic.dependency;



@wt.method.RemoteInterface
public interface DependencyRetrieverService extends wt.method.RemoteAccess {

    
    public java.util.Collection<wt.epm.interfaces.WorkspaceTrackable> getDependentEPMs(java.util.Collection<wt.epm.EPMDocument> epmDocs, com.ptc.generic.dependency.StandardDependencyRetrieverService.ConfSpec configSpec)
        throws wt.util.WTException;

    
    public java.util.Collection<wt.epm.interfaces.WorkspaceTrackable> getDependentEPMs(java.util.Collection<wt.epm.EPMDocument> epmDocs, com.ptc.generic.dependency.StandardDependencyRetrieverService.ConfSpec configSpec, boolean collectRequired, boolean includeDrawings, boolean includeFTables)
        throws wt.util.WTException;

    
    public java.util.Collection<wt.epm.interfaces.WorkspaceTrackable> getDependentEPMs(java.util.Collection<wt.epm.EPMDocument> epmDocs, com.ptc.generic.dependency.StandardDependencyRetrieverService.ConfSpec configSpec, boolean collectRequired, boolean includeDrawings, boolean includeFTables, int retrievalDepth)
        throws wt.util.WTException;

    
    public java.util.Collection<wt.epm.interfaces.WorkspaceTrackable> getDependentEPMs(java.util.Collection<wt.epm.EPMDocument> epmDocs, com.ptc.generic.dependency.StandardDependencyRetrieverService.ConfSpec configSpec, boolean collectRequired, boolean includeDrawings, boolean includeFTables, wt.fc.collections.WTArrayList output)
        throws wt.util.WTException;

    
    public java.util.Collection<wt.epm.interfaces.WorkspaceTrackable> getDependentEPMs(java.util.Collection<wt.epm.EPMDocument> epmDocs, com.ptc.generic.dependency.StandardDependencyRetrieverService.ConfSpec configSpec, boolean collectRequired, boolean includeDrawings, boolean includeFTables, wt.fc.collections.WTArrayList output, int retrievalDepth)
        throws wt.util.WTException;

    
    public wt.fc.ResultProcessor getDependentEPMs(java.util.Collection<wt.epm.EPMDocument> epmDocs, com.ptc.generic.dependency.StandardDependencyRetrieverService.ConfSpec configSpec, boolean collectRequired, boolean includeDrawings, boolean includeFTables, wt.fc.ResultProcessor output)
        throws wt.util.WTException;

    
    public wt.fc.ResultProcessor getDependentEPMs(java.util.Collection<wt.epm.EPMDocument> epmDocs, com.ptc.generic.dependency.StandardDependencyRetrieverService.ConfSpec configSpec, boolean collectRequired, boolean includeDrawings, boolean includeFTables, wt.fc.ResultProcessor output, int retrievalDepth)
        throws wt.util.WTException;

    
    public java.util.Collection<wt.epm.interfaces.WorkspaceTrackable> getDrawingsFor3D(wt.epm.EPMDocument cad3dDoc, com.ptc.generic.dependency.StandardDependencyRetrieverService.ConfSpec configSpec)
        throws wt.util.WTException;

    
    public java.util.Collection<wt.epm.EPMDocument> getDrawingsFor3D(wt.epm.EPMDocument epmDoc, boolean getLatestIfNotInAsStoredBL)
        throws wt.util.WTException;

    
    public java.util.Collection<wt.epm.EPMCADNamespace> getEPMCADNamespaces(java.util.Collection<wt.epm.EPMDocument> cadDocs, wt.fc.ResultProcessor output)
        throws wt.util.WTException;

}
