package com.ptc.generic.netmarkets;


public class NetmarketsHelper {

    
    public static final com.ptc.generic.netmarkets.NetmarketsService service = wt.services.ServiceFactory.getService(com.ptc.generic.netmarkets.NetmarketsService.class);

}
