package com.ptc.ssp.multilcupdate;

/**
 * Faked.
 * Created on 22.06.2018 10:52:08<p>
 * @author ext-wangc
 *
 */
public class multilcupdateResource {

	public static final String REPORT_MODE = "Report mode:";
	public static final String UPDATE_MODE = "Update mode:";
	public static final String REPORT_USAGE = "Usage: windchill com.ptc.ssp.multilcupdate.MassLCUpdateBatch -u <user> -p <password> -m report -o <object_type> -f <file_name> -l <lifecyle_name> [-batch <batch size>]";
	public static final String UPDATE_USAGE = "Usage: windchill com.ptc.ssp.multilcupdate.MassLCUpdateBatch -u <user> -p <password> -m update -f <file_name> [-batch <batch size>]";
	public static final String REPORT_EXAMPLE = "i.e. windchill com.ptc.ssp.multilcupdate.MassLCUpdateBatch -m report -f $WT_HOME/input.txt -u wcadmin -p wcadmin -o Baustufe -l ECAPhaseMasterlisteLC";
	public static final String UPDATE_EXAMPLE = "i.e. windchill com.ptc.ssp.multilcupdate.MassLCUpdateBatch -m update -f $WT_HOME/input.txt -u wcadmin -p wcadmin";
	public static final String PARENT_NOT_FOUND = "Parent not found, using type as class name.";
	public static final String CLASS_NOT_FOUND = "MassLCUpdateBatch: Class not found: {0}";
	public static final String PROCESSING_BATCH = "Processing batch:";
	public static final String OBJECT_NOT_FOUND = "Object type not found";
	public static final String LOOKUP_ERROR = "Error looking up of a class type:";
	public static final String WRITING_ERROR = "Error writing to file:";
	public static final String UPDATE_DONE = "Update done in";
	public static final String APPLY_ERROR_CO = "Error applying new LC on checked out item:";
	public static final String STARTED = "Mass LifeCycle Update launched !!";
	public static final String FILE_NOT_EXIST = "File does not exist:";
	public static final String CORRUPTED_ENTRY = "Corrupted entry:";
	public static final String TRESHOLD = "Treshold reached for state:";
	public static final String PROCESSED = ", processed:";
	public static final String PARTS = " parts (batch size :";
	public static final String REFERENCE_ERROR = "Error getting reference from";
	public static final String OVERALL_STATUS = "Overall status:";
	public static final String PROCESSED_CI = "Processed (checked in) part(s) for state";
	public static final String PROCESSED_CO = "Processed (checked out) part(s) for state";
	public static final String FAILED = "Failed:";
	public static final String DETAILS = " objects, details in MethodServer log file.";
	public static final String READING_ERROR = "Error reading file:";
	public static final String SUCCESSFULLY_UPDATED = "Successfully updated a total of :";
	public static final String OBJECTS = " objects.";
	public static final String UPDATE_DONE_IN = "Update done in";
	public static final String BATCH_INTEGER = "Batch must be integer value.";
	public static final String UPDATE_USING_FILE = "Updating objects using input file:";
	public static final String ERROR_OCCURED = "Error occured:";
	public static final String DONE_IN = "Done in";
	public static final String SUCCESSFULLY = "Successfully:";
	public static final String UPDATED_OBJECTS = " updated objects.";
	public static final String LOGGED_IN = "Logged in.";
	public static final String EXECUTING = "Executing action on MethodServer, please wait.";
	public static final String FOUND = "Found:";
	public static final String UPDATE_OBJECTS = " objects to update.";
	public static final String CREATE_IN_FILE = "Creating report in file";
	public static final String FOR_OBJECT = " for object";
}
