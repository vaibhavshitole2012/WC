/* bcwti
 *
 * Copyright (c) 2010 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */
package com.ptc.windchill.enterprise.change2;

import wt.util.resource.*;

@RBUUID("com.ptc.windchill.enterprise.change2.change2ClientResource")
public final class change2ClientResource_fr extends WTListResourceBundle {
   /**
    *
    * This file contains all the strings used by the DCA based Change Management clients
    *
    * ##############################################################################
    *
    * Object class names
    *
    * ##############################################################################
    **/
   @RBEntry("Variation")
   @RBComment("see wt.change2.change2ModelRB:WTVariance key")
   public static final String PRIVATE_CONSTANT_0 = "VARIANCE";

   @RBEntry("Rapport de problème")
   @RBComment("The name of the object \"Problem Report\".")
   public static final String PRIVATE_CONSTANT_1 = "PROBLEM_REPORT";

   @RBEntry("Demande de modification")
   @RBComment("The name of the object \"Change Request\".")
   public static final String PRIVATE_CONSTANT_2 = "CHANGE_REQUEST";

   @RBEntry("Avis de modification")
   @RBComment("The name of the object \"Change Notice\".")
   public static final String PRIVATE_CONSTANT_3 = "CHANGE_NOTICE";

   /**
    * ##############################################################################
    *
    * Legacy Strings used by the local search tooltips
    * @deprecated
    *
    * ##############################################################################
    **/
   @RBEntry("Afficher la page d'informations du rapport de problème")
   @RBComment("Tooltip for the info page action.")
   public static final String PRIVATE_CONSTANT_4 = "CHANGE_ISSUE_INFO_PAGE_TT";

   @RBEntry("Afficher la page d'informations de l'avis de modification")
   @RBComment("Tooltip for the info page action.")
   public static final String PRIVATE_CONSTANT_5 = "CHANGE_ORDER_INFO_PAGE_TT";

   @RBEntry("Afficher la page d'informations de la demande de modification")
   @RBComment("Tooltip for the info page action.")
   public static final String PRIVATE_CONSTANT_6 = "CHANGE_REQUEST_INFO_PAGE_TT";

   @RBEntry("Afficher la page d'informations du rapport de problème")
   @RBComment("Tooltip for the info page action.")
   public static final String PRIVATE_CONSTANT_7 = "PR_DETAIL_TT";

   @RBEntry("Afficher la page d'informations de la demande de modification")
   @RBComment("Tooltip for the info page action.")
   public static final String PRIVATE_CONSTANT_8 = "ECR_DETAIL_TT";

   @RBEntry("Afficher la page d'informations de l'avis de modification")
   @RBComment("Tooltip for the info page action.")
   public static final String PRIVATE_CONSTANT_9 = "ECN_DETAIL_TT";

   @RBEntry("Afficher la page d'informations de la proposition de modification")
   @RBComment("Tooltip for the info page action.")
   public static final String PRIVATE_CONSTANT_10 = "CHANGE_PROPOSAL_INFO_TT";

   @RBEntry("Afficher la page d'informations de la tâche")
   @RBComment("Tooltip for the info page action.")
   public static final String PRIVATE_CONSTANT_11 = "CHANGE_ACTIVITY_INFO_TT";

   @RBEntry("Afficher la page d'informations de l'investigation de la modification")
   @RBComment("Tooltip for the info page action.")
   public static final String PRIVATE_CONSTANT_12 = "CHANGE_INVESTIGATION_INFO_TT";

   @RBEntry("Afficher la page d'informations de l'analyse")
   @RBComment("Tooltip for the info page action.")
   public static final String PRIVATE_CONSTANT_13 = "ANALYSIS_ACTIVITY_INFO_TT";

   @RBEntry("Associer les modifications")
   @RBComment("The Associated Problem Reports step in the wizard.")
   public static final String PRIVATE_CONSTANT_14 = "RELATED_CHANGES";

   /**
    * ##############################################################################
    *
    * Picker titles
    *
    * ##############################################################################
    **/
   @RBEntry("Rechercher les problèmes et les variations associés")
   @RBComment("The title for the action \"Add Associated Changes\"")
   public static final String PRIVATE_CONSTANT_15 = "FIND_ASSOCIATED_CHANGEISSUES";

   @RBEntry("Rechercher les demandes de modification associées")
   @RBComment("The title for the action \"Add Associated Changes\"")
   public static final String PRIVATE_CONSTANT_16 = "FIND_ASSOCIATED_CHANGEREQUESTS";

   @RBEntry("Rechercher les produits finis affectés")
   @RBComment("The title for the action \"Add Affected End Items\"")
   public static final String PRIVATE_CONSTANT_17 = "FIND_AFFECTED_END_ITEMS";

   @RBEntry("Rechercher les objets affectés")
   @RBComment("The title for the action \"Add Affected Objects\"")
   public static final String PRIVATE_CONSTANT_18 = "FIND_AFFECTED_DATA";

   @RBEntry("Rechercher les objets résultants")
   @RBComment("The title for the action \"Add Resulting Objects\"")
   public static final String PRIVATE_CONSTANT_19 = "FIND_RESULTING_DATA";

   @RBEntry("Rechercher les avis de modification")
   @RBComment(" The title for the Change Notice Summary Report input page (from the Cognos reports page).")
   public static final String PRIVATE_CONSTANT_20 = "FIND_CHANGE_NOTICES";

   @RBEntry("Rechercher des demandes de modification")
   @RBComment(" The title for the Change Request Summary Report input page (from the Cognos reports page).")
   public static final String PRIVATE_CONSTANT_21 = "FIND_CHANGE_REQUESTS";

   @RBEntry("Rechercher des variations")
   @RBComment(" The title for the Variance Summary Report input page (from the Cognos reports page).")
   public static final String PRIVATE_CONSTANT_22 = "FIND_VARIANCES";

   @RBEntry("Rechercher des rapports de problème")
   @RBComment(" The title for the Problem Reports Summary Report input page (from the Cognos reports page).")
   public static final String PRIVATE_CONSTANT_23 = "FIND_PROBLEM_REPORTS";

   /**
    * ##############################################################################
    *
    * Table titles
    *
    * ##############################################################################
    **/
   @RBEntry("Objets affectés")
   @RBComment("The Affected Items table title.")
   public static final String PRIVATE_CONSTANT_24 = "AFFECTED_ITEMS_TABLE";

   @RBEntry("Directives de modification ayant un impact")
   @RBComment("The Impacting Directive table title.")
   public static final String PRIVATE_CONSTANT_25 = "IMPACTING_ITEMS_TABLE";

   @RBEntry("Actions de modification")
   @RBComment("The Change Actions table.")
   public static final String PRIVATE_CONSTANT_26 = "CHANGE_ACTIONS_TABLE";

   @RBEntry("Objets résultants")
   @RBComment("The Resulting Items table title.")
   public static final String PRIVATE_CONSTANT_27 = "RESULTING_ITEMS_TABLE";

   @RBEntry("Valider les objets résultants")
   @RBComment("The table title for the review resulting objects table on a review workflow task.")
   public static final String REVIEW_TASK_RESULTING_ITEMS_TABLE = "REVIEW_TASK_RESULTING_ITEMS_TABLE";   

   @RBEntry("Terminer les objets résultants")
   @RBComment("The table title for the complete resulting objects table on a workflow task.")
   public static final String COMPLETE_TASK_RESULTING_ITEMS_TABLE = "COMPLETE_TASK_RESULTING_ITEMS_TABLE";
   
   @RBEntry("Objets affectés")
   @RBComment("The Affected Objects (change request, problem report, Variance) table title.")
   public static final String PRIVATE_CONSTANT_28 = "AFFECTED_DATA_TABLE";

   @RBEntry("Produits finis affectés")
   @RBComment("The Affected End Items table title.")
   public static final String PRIVATE_CONSTANT_29 = "AFFECTED_END_ITEMS_TABLE";

   @RBEntry("Récapitulatif des modifications")
   @RBComment("Affected and Resulting Data for all Change Tasks on a Change Notice")
   public static final String CHANGE_NOTICE_SUMMARY_TABLE = "CHANGE_NOTICE_SUMMARY_TABLE";

   @RBEntry("Récapitulatif des modifications de l'audit")
   @RBComment("The table title for the audit change summary table.")
   public static final String AUDIT_CHANGE_NOTICE_SUMMARY_TABLE = "AUDIT_CHANGE_NOTICE_SUMMARY_TABLE";   

   @RBEntry("Problèmes et variations associés")
   @RBComment("The table title for the Related Problem Reports (as well as other issues) and Variances.")
   public static final String RELATED_CHANGEISSUES_TABLE = "RELATED_CHANGEISSUES_TABLE";

   @RBEntry("Demandes de modification associées")
   @RBComment("The table title for the related change requests.")
   public static final String RELATED_CHANGEREQUESTS_TABLE = "RELATED_CHANGEREQUESTS_TABLE";

   @RBEntry("Problèmes et variations")
   @RBComment("The table title for the Related Problem Reports (and other issues) and Variances.")
   public static final String PRIVATE_CONSTANT_30 = "CHANGE_ISSUES_TABLE";

   @RBEntry("Demandes de modification")
   @RBComment("The plural name of the object \"Change Request\".")
   public static final String PRIVATE_CONSTANT_31 = "CHANGE_REQUESTS_TABLE";

   @RBEntry("Avis de modification")
   @RBComment("The plural name of the object \"Change Notice\".")
   public static final String PRIVATE_CONSTANT_32 = "CHANGE_NOTICES_TABLE";

   @RBEntry("Affectés par les avis de modification")
   @RBComment("The table title for the Affected by Change Notices info page table")
   public static final String PRIVATE_CONSTANT_33 = "AFFECTED_BY_CHANGE_NOTICES_TABLE";

   @RBEntry("Résultant des avis de modification")
   @RBComment("The table title for the Resulting from Change Notices info page table")
   public static final String PRIVATE_CONSTANT_34 = "RESULTING_FROM_CHANGE_NOTICES_TABLE";

   @RBEntry("Jeux d'annotations")
   @RBComment("The table title for the Annotation Set table")
   public static final String PRIVATE_CONSTANT_35 = "ANNOTATION_SET_TABLE";

   @RBEntry("Attributs")
   @RBComment("The table title for the Variance Analysis attribute table.")
   public static final String VARIANCE_ANALYSIS_TABLE = "VARIANCE_ANALYSIS_TABLE";

   @RBEntry("Attributs")
   @RBComment("The table tile for the Attributes table from the information pages.")
   public static final String PRIVATE_CONSTANT_36 = "ATTRIBUTES_TABLE";

   @RBEntry("Modifications non incorporées")
   @RBComment("The table title for the Unincorporated changes table")
   public static final String PRIVATE_CONSTANT_37 = "UNINCORPORATED_CHANGE_TABLE";

   @RBEntry("Propositions et investigations")
   @RBComment("The table title for the Change Proposals and Change Investigations")
   public static final String PRIVATE_CONSTANT_38 = "PROPOSALS_AND_INVESTIGATIONS_TABLE";

   @RBEntry("Opérations d'analyse")
   @RBComment("The table title for Analysis Activities")
   public static final String PRIVATE_CONSTANT_39 = "ANALYSIS_ACTIVITIES_TABLE";

   @RBEntry("Avis de modification")
   @RBComment("The column name for the Change Notice Id")
   public static final String HC_CHANGENOTICE = "HC_CHANGENOTICE";

   @RBEntry("Etat")
   @RBComment("The column name for the Change Notice State")
   public static final String HC_CHANGENOTICE_STATE = "HC_CHANGENOTICE_STATE";

   @RBEntry("Tâche de modification")
   @RBComment("The column name for the Change Task Id")
   public static final String HC_CHANGETASK = "HC_CHANGETASK";

   @RBEntry("Plan d'incorporation")
   @RBComment("The column name for Incorporation Plan")
   public static final String HC_INCORPOPTION = "HC_INCORPOPTION";

   @RBEntry("Révision prévue")
   @RBComment("The column name for Planned Revision")
   public static final String HC_INCORPREVISION = "HC_INCORPREVISION";

   @RBEntry("Problèmes")
   @RBComment("The title for the All Open Issues table.")
   public static final String OPEN_ISSUES_TITLE = "OPEN_ISSUES_TITLE";

   @RBEntry("Demandes de modification")
   @RBComment("The title for the All Open Change Requests table.")
   public static final String OPEN_CHANGE_REQUESTS_TITLE = "OPEN_CHANGE_REQUESTS_TITLE";

   @RBEntry("Avis de modification")
   @RBComment("The title for the All Open Change Notices table.")
   public static final String OPEN_CHANGE_NOTICES_TITLE = "OPEN_CHANGE_NOTICES_TITLE";

   @RBEntry("Variations")
   @RBComment("The title for the All Open Variances table.")
   public static final String OPEN_VARIANCES_TITLE = "OPEN_VARIANCES_TITLE";

   @RBEntry("L'une des méthodes permettant de créer un rapport de problème consiste à accéder à la page d'informations d'un objet modifiable, comme un article ou un document, et à sélectionner \"Nouveau rapport de problème\" dans la liste d'actions. Pour plus d'informations, reportez-vous à l'aide en ligne disponible depuis le tableau \"Rapports de problème\".")
   @RBComment("Informational text to create problem reports.")
   public static final String OPEN_PROBLEM_REPORTS_HELP = "OPEN_PROBLEM_REPORTS_HELP";

   @RBEntry("L'une des méthodes permettant de créer un avis de modification consiste à accéder à la page d'informations d'une demande de modification et à sélectionner \"Nouvel avis de modification\" dans la liste d'actions. Pour plus d'informations, reportez-vous à l'aide en ligne disponible depuis la table \"Avis de modification\".")
   @RBComment("Informational text to create change notices.")
   public static final String OPEN_CHANGE_NOTICES_HELP = "OPEN_CHANGE_NOTICES_HELP";

   @RBEntry("L'une des méthodes permettant de créer une demande de modification consiste à accéder à la page d'informations d'un rapport de problème et à sélectionner \"Nouvelle demande de modification\" dans la liste d'actions. Pour plus d'informations, reportez-vous à l'aide en ligne disponible depuis le tableau \"Demandes de modification\".")
   @RBComment("Informational text to create requests notices.")
   public static final String OPEN_CHANGE_REQUESTS_HELP = "OPEN_CHANGE_REQUESTS_HELP";

   @RBEntry("L'une des méthodes permettant de créer une variation consiste à accéder à la page d'informations d'un objet modifiable, comme un article ou un document, et à sélectionner \"Nouvelle variation\" dans la liste d'actions. Pour plus d'informations, reportez-vous à l'aide en ligne disponible depuis le tableau \"Variations\".")
   @RBComment("Informational text to create variances.")
   public static final String OPEN_VARIANCES_HELP = "OPEN_VARIANCES_HELP";

   @RBEntry("Exigences associées")
   @RBComment("Title for the fulfill requirements table")
   public static final String PRIVATE_CONSTANT_40 = "FULFILL_CHANGEACTIONS_TABLE";

   @RBEntry("Configuration de référence des modifications")
   @RBComment("Title for the Change Baseline report tree")
   public static final String CHANGE_BASELINE_TABLE = "CHANGE_BASELINE_TABLE";


   /**
    * ##############################################################################
    *
    * Table views
    *
    * ##############################################################################
    */

   @RBEntry("Rapports de problèmes")
   public static final String PROBLEM_REPORT_TABLEVIEW_NAME = "PROBLEM_REPORT_TABLEVIEW_NAME";

   @RBEntry("Affiche uniquement les rapports de problèmes.")
   public static final String PROBLEM_REPORT_TABLEVIEW_DESCRIPTION = "PROBLEM_REPORT_TABLEVIEW_DESCRIPTION";

   @RBEntry("Variations")
   public static final String VARIANCE_TABLEVIEW_NAME = "VARIANCE_TABLEVIEW_NAME";

   @RBEntry("Affiche uniquement les variations.")
   public static final String VARIANCE_TABLEVIEW_DESCRIPTION = "VARIANCE_TABLEVIEW_DESCRIPTION";

   @RBEntry("Intention de modification")
   public static final String CHANGE_INTENT = "CHANGE_INTENT";

   @RBEntry("Contenu de version")
   public static final String RELEASE_CONTENT = "RELEASE_CONTENT";

   @RBEntry("Articles affectés")
   public static final String AFFECTED_PARTS = "AFFECTED_PARTS";

   @RBEntry("Par défaut")
   @RBComment("The default table view name for the Change Baseline report")
   public static final String CHANGE_BASELINE_REPORT_TABLE_VIEW_DEFAULT_NAME = "CHANGE_BASELINE_REPORT_TABLE_VIEW_DEFAULT_NAME";

   @RBEntry("Vue par défaut")
   @RBComment("The default table view description for the Change Baseline report")
   public static final String CHANGE_BASELINE_REPORT_TABLE_VIEW_DEFAULT_DESC = "CHANGE_BASELINE_REPORT_TABLE_VIEW_DEFAULT_DESC";

   /**
    * ##############################################################################
    *
    * Table columns specific to change
    *
    * ##############################################################################
    **/
   @RBEntry("With suppliers")
   @RBComment("The label for the disposition column.")
   public static final String ONORDERDISPOSITION = "ONORDERDISPOSITION";

   @RBEntry("In warehouse")
   @RBComment("The label for the disposition column.")
   public static final String INVENTORYDISPOSITION = "INVENTORYDISPOSITION";

   @RBEntry("In production")
   @RBComment("The label for the disposition column.")
   public static final String FINISHEDDISPOSITION = "FINISHEDDISPOSITION";

   @RBEntry("With customer")
   @RBComment("The label for the disposition column.")
   public static final String WITHCUSTOMERDISPOSITION = "WITHCUSTOMERDISPOSITION";

   @RBEntry("In assembled parts")
   @RBComment("The label for the disposition column.")
   public static final String INASSEMBLEDPARTSDISPOSITION = "INASSEMBLEDPARTSDISPOSITION";

   @RBEntry("Commentaires de disposition")
   @RBComment("The label for the disposition comment column.")
   public static final String DISPOSITIONCOMMENTS = "DISPOSITIONCOMMENTS";

   @RBEntry("Quantité approuvée")
   @RBComment("The label for Approved Quantity column.")
   public static final String APPROVEDQUANTITY = "APPROVEDQUANTITY";

   @RBEntry("Commentaires")
   @RBComment("Label to be used in the Table Views")
   public static final String CHANGE_LINK_DESCRIPTION = "CHANGE_LINK_DESCRIPTION";

   @RBEntry("Paramètres de la table")
   @RBComment("Label used in the table views. This column is a hidden parameter column.")
   public static final String CHANGE_TABLE_DATA_COLUMN = "CHANGE_TABLE_DATA_COLUMN";

   @RBEntry("Modification non incorporée")
   @RBComment("Label used in the table views. This column is a hidden parameter column.")
   public static final String INCORP_HANGINGCHANGE_TABLE_DATA_COLUMN = "INCORP_HANGINGCHANGE_TABLE_DATA_COLUMN";

   @RBEntry("Objets ayant un impact")
   @RBComment("This column is used to filter the display of affected and resulting objects. This column is only displayed on the filter step of the table view wizard.")
   public static final String IMPACTING_OBJECTS_COLUMN = "IMPACTING_OBJECTS_COLUMN";

   @RBEntry("Relation")
   @RBComment("This column is used to display the link relation ship of the affected or resulting objects.")
   public static final String RELATIONSHIP = "RELATIONSHIP";

   @RBEntry("Nom de la tâche")
   @RBComment("This column is to display the name of the change task on a affected or resulting link.")
   public static final String TASK_NAME_COLUMN = "TASK_NAME_COLUMN";

   @RBEntry("Numéro de tâche")
   @RBComment("This column is to display the number of the change task on a affected or resulting link.")
   public static final String TASK_NUMBER_COLUMN = "TASK_NUMBER_COLUMN";
   
   @RBEntry("Etat de la tâche")
   @RBComment("This column is to display the state of the change task on a affected or resulting link.")
   public static final String TASK_STATE_COLUMN = "TASK_STATE_COLUMN";  

   @RBEntry("Statut affecté")
   @RBComment("This column is to indicate if the Affected Status is shown for any item which is added as a resulting object or unincorporated change on a change task but does not have a corresponding equal or predecessor revision as an affected object.")
   public static final String AFFECTED_STATUS = "AFFECTED_STATUS";

   @RBEntry("Aucun objet affecté")
   @RBComment("A message is to indicate if the Affected Status is shown for any item which is added as a resulting object or unincorporated change on a change task but does not have a corresponding equal or predecessor revision as an affected object.")
   public static final String AFFECTED_STATUS_MSG = "AFFECTED_STATUS_MSG";

   @RBEntry("Etat cible")
   @RBComment("This column is to indicate if the Change target state of the change task resulting objects.")
   public static final String CHANGE_TARGET_STATE = "CHANGE_TARGET_STATE";

   @RBEntry("Nouvelle version")
   @RBComment("This column is to indicate if the new version of the successor object in the Change Baseline report table.")
   public static final String NEW_VERSION = "NEW_VERSION";

   @RBEntry("Autorisation planifiée")
   @RBComment("This column is to indicate if the planned authorization of the successor object in the Change Baseline report table.")
   public static final String PLANNED_AUTHORIZATION = "PLANNED_AUTHORIZATION";

   @RBEntry("Action")
   @RBComment("This column is to indicate if the action of the successor object in the Change Baseline report table.")
   public static final String PLANNED_ACTION = "PLANNED_ACTION";
   
   @RBEntry("Cible d'officialisation")
   @RBComment("This column is to indicate the change management transition for the resulting object.")
   public static final String CHANGE_TARGET_TRANSITION = "CHANGE_TARGET_TRANSITION";
   
   @RBEntry("Ouvrir les intervenants de la tâche")
   @RBComment("Set of columns intended to show the users that have open workflow tasks on a change task")
   public static final String CHANGE_TASK_ASSIGNEES = "CHANGE_TASK_ASSIGNEES";

   @RBEntry("Identité")
   @RBComment("This column is to display the attributes that uniquely identify an object.")
   public static final String IDENTITY_COLUMN_NAME = "IDENTITY_COLUMN_NAME";

   /**
    * ##############################################################################
    *
    * The action types for the Successor objects in the Change Baseline report
    *
    * ##############################################################################
    */

    @RBEntry("Ajouter")
    @RBComment("Indicates that the object was added.")
    public static final String PLANNED_ACTION_TYPE_ADD = "PLANNED_ACTION_TYPE_ADD";

    @RBEntry("Supprimer")
    @RBComment("Indicates that object was removed was removed.")
    public static final String PLANNED_ACTION_TYPE_REMOVE = "PLANNED_ACTION_TYPE_REMOVE";

    @RBEntry("Changer de version")
    @RBComment("Indicates that the successor object was revised.")
    public static final String PLANNED_ACTION_TYPE_REVISE = "PLANNED_ACTION_TYPE_REVISE";

   /**
    * ##############################################################################
    *
    * labels for impacting objects
    *
    * ##############################################################################
    **/

   @RBEntry("Objets affectés")
   @RBComment("This label is used to filter affected objects.")
   public static final String SHOW_AFFECTED_OBJECTS = "SHOW_AFFECTED_OBJECTS";

   @RBEntry("Objets résultants")
   @RBComment("This label is used to filter resulting objects.")
   public static final String SHOW_RESULTING_OBJECTS = "SHOW_RESULTING_OBJECTS";

   @RBEntry("Objets affectés/résultants")
   @RBComment("This label is used to filter affected and resulting objects.")
   public static final String SHOW_AFFECTED_RESULTING_OBJECTS = "SHOW_AFFECTED_RESULTING_OBJECTS";


   /**
    * ##############################################################################
    *
    * labels specific to annotation
    *
    * ##############################################################################
    **/
   @RBEntry("Objet affecté")
   @RBComment("Affected data label.")
   public static final String PRIVATE_CONSTANT_41 = "AFFECTED_DATA_LABEL";

   @RBEntry("Jeux d'annotations")
   @RBComment("The label for related affected data column.")
   public static final String ANNOTATION_SET_LABEL = "ANNOTATION_SET_LABEL";

   @RBEntry("Liste de jeux d'annotations")
   @RBComment("The label for related affected data column.")
   public static final String PRIVATE_CONSTANT_42 = "ANNOTATION_SET_LIST_LABEL";

   /**
    * #######################################################
    *
    * Owning Change Object
    *
    * #######################################################
    **/
   @RBEntry("Avis de modification")
   @RBComment("Label for the Owning Change Notice")
   public static final String OWNING_CHANGE_NOTICE = "OWNING_CHANGE_NOTICE";

   @RBEntry("Nom de l'avis de modification")
   @RBComment("Label for the Owning Change Notice Name")
   public static final String OWNING_CHANGE_NOTICE_NAME = "OWNING_CHANGE_NOTICE_NAME";

   @RBEntry("Demande de modification")
   @RBComment("Label for the Owning Change Request")
   public static final String OWNING_CHANGE_REQUEST = "OWNING_CHANGE_REQUEST";

   @RBEntry("Nom de la demande de modification")
   @RBComment("Label for the Owning Change Request Name")
   public static final String OWNING_CHANGE_REQUEST_NAME = "OWNING_CHANGE_REQUEST_NAME";

   @RBEntry("Proposition de modification")
   @RBComment("Label for the Owning Change Proposal")
   public static final String OWNING_CHANGE_PROPOSAL = "OWNING_CHANGE_PROPOSAL";

   @RBEntry("Nom de proposition de modification")
   @RBComment("Label for the Owning Change Proposal Name")
   public static final String OWNING_CHANGE_PROPOSAL_NAME = "OWNING_CHANGE_PROPOSAL_NAME";

   @RBEntry("Investigation de la modification")
   @RBComment("Label for the Owning Change Investigation")
   public static final String OWNING_CHANGE_INVESTIGATION = "OWNING_CHANGE_INVESTIGATION";

   @RBEntry("Nom d'investigation de la modification")
   @RBComment("Label for the Owning Change Investigation Name")
   public static final String OWNING_CHANGE_INVESTIGATION_NAME = "OWNING_CHANGE_INVESTIGATION_NAME";

   @RBEntry("Objet de modification")
   @RBComment("Label for the Owning Change Object")
   public static final String OWNING_CHANGE_OBJECT = "OWNING_CHANGE_OBJECT";

   @RBEntry("Nom d'objet de modification")
   @RBComment("Label for the Owning Change Object Name")
   public static final String OWNING_CHANGE_OBJECT_NAME = "OWNING_CHANGE_OBJECT_NAME";

   @RBEntry("(Non disponible)")
   @RBComment("Label for an object that is unavailable")
   public static final String UNAVAILABLE = "UNAVAILABLE";

   /**
    * #######################################################
    *
    * Implementation Plan Table
    *
    * #######################################################
    **/
   @RBEntry("Plan d'implémentation")
   @RBComment("The title of the Implementaiton Plan")
   public static final String IMPLEMENTATION_PLAN_TABLE = "IMPLEMENTATION_PLAN_TABLE";

   @RBEntry("Icône Modifier")
   @RBComment("Selectable Column name")
   public static final String IMPLEMENTATION_PLAN_TABLE_ICON_ACTIONS = "IMPLEMENTATION_PLAN_TABLE_ICON_ACTIONS";

   @RBEntry("Révision")
   @RBComment("Revision Column name")
   public static final String IMPLEMENTATION_PLAN_TABLE_REVISION = "IMPLEMENTATION_PLAN_TABLE_REVISION";

   @RBEntry("Numéro")
   @RBComment("Number Column name")
   public static final String IMPLEMENTATION_PLAN_TABLE_NUMBER = "IMPLEMENTATION_PLAN_TABLE_NUMBER";

   @RBEntry("Nom")
   @RBComment("Name Column name")
   public static final String IMPLEMENTATION_PLAN_TABLE_NAME = "IMPLEMENTATION_PLAN_TABLE_NAME";

   @RBEntry("Etat")
   @RBComment("State Column name")
   public static final String IMPLEMENTATION_PLAN_TABLE_STATE = "IMPLEMENTATION_PLAN_TABLE_STATE";

   @RBEntry("Intervenant")
   @RBComment("Assignee Column name")
   public static final String IMPLEMENTATION_PLAN_TABLE_LAST_ROLE_ASSIGNEE = "IMPLEMENTATION_PLAN_TABLE_LAST_ROLE_ASSIGNEE";

   @RBEntry("Validateur")
   @RBComment("Reviewer Column name")
   public static final String IMPLEMENTATION_PLAN_TABLE_LAST_ROLE_REVIEWER = "IMPLEMENTATION_PLAN_TABLE_LAST_ROLE_REVIEWER";

   @RBEntry("Dû le")
   @RBComment("Need DateColumn name")
   public static final String IMPLEMENTATION_PLAN_TABLE_NEED_DATE = "IMPLEMENTATION_PLAN_TABLE_NEED_DATE";

   @RBEntry("Séquence")
   @RBComment("Change task sequence column name")
   public static final String IMPLEMENTATION_PLAN_TABLE_SEQUENCE = "IMPLEMENTATION_PLAN_TABLE_SEQUENCE";

   @RBEntry("Statut d'Implémentation")
   @RBComment("Label for Implementation Status column in the implementation plan table")
   public static final String IMPLEMENTATION_PLAN_TABLE_STATUS = "IMPLEMENTATION_PLAN_TABLE_STATUS";

   /**
    * Added to resolve compile issue
    **/
   @RBEntry("Plan d'implémentation")
   @RBComment("Change Notice table header.")
   public static final String CHANGE_NOTICE_TABLE_HEADER = "CHANGE_NOTICE_TABLE_HEADER";

   /**
    * ########################################################
    *
    * Revise Client Strings (ChangeItem Reissue Dialog)
    *
    * ########################################################
    **/
   @RBEntry("Impact")
   @RBComment("The impact of the revise.  Either Modify of Proceed")
   public static final String REVISE_IMPACT = "REVISE_IMPACT";

   @RBEntry("Nouveau changement de version")
   @RBComment("The label for the new revision")
   public static final String NEW_REVISION = "NEW_REVISION";

   @RBEntry("Une erreur s'est produite lors du changement de version de l'objet.")
   @RBComment("The message header (ATTENTION:) is already added.")
   public static final String REVISE_ERROR_HEADER = "REVISE_ERROR";

   @RBEntry("Objet de modification")
   @RBComment("The label for the change item Identity")
   public static final String CHANGE_ITEM_IDENTITY = "CHANGE_ITEM_IDENTITY";

   /**
    * #########################################################
    *
    * Change Status Column Strings
    *
    * #########################################################
    **/
   @RBEntry("Statut de modification")
   @RBComment("The column header for the change status column.")
   public static final String CHANGE_STATUS_COLUMN = "statusFamily_Change";

   /**
    * #########################################################
    *
    * Specialized Attribute handling messages.
    *
    * #########################################################
    **/
   @RBEntry("Le propriétaire de variation spécifié n'est pas valide.")
   @RBComment("The message when the user picked a user but this uid is not valid in the system.")
   public static final String VARIANCEOWNER_NOTFOUND = "VarianceOwner_NotFound";

   @RBEntry("Impossible de créer la variation.")
   public static final String VARIANCE_CREATE_CANNOTCREATE = "Variance_Create_CanNotCreate";

   @RBEntry("Effacer les commentaires de disposition existants")
   @RBComment("Text display value for the check box to clear disposition comments.")
   public static final String CLEAR_DISPOSITION_COMMENTS = "CLEAR_DISPOSITION_COMMENTS";

   /**
    * #########################################################
    *
    * Propagation Message Strings
    *
    * #########################################################
    **/
   @RBEntry("Propager les informations du rapport de problème")
   @RBComment("Option label to indicate propagation of meta-data, affected data, etc.from a Problem Report to a Change Request")
   public static final String PROPAGATE_DATA_FROM_PR_LABEL = "PropagateProblemReport_label";

   @RBEntry("Propager les informations de la variation")
   @RBComment("Option label to indicate propagation of meta-data, affected data, etc.from a Variance to a Change Request")
   public static final String PROPAGATE_DATA_FROM_VARIANCE_LABEL = "PropagateVariance_label";

   @RBEntry("Propager les informations de la demande de modification")
   @RBComment("Option label to indicate propagation of meta-data, affected data, etc.from a Change Request to a Change Notice.")
   public static final String PROPAGATE_DATA_FROM_CR_LABEL = "PropagateChangeRequest_label";

   /**
    * #########################################################
    *
    * Wizard Error messages.
    *
    * #########################################################
    **/
   @RBEntry("Echec lors du traitement des objets affectés.")
   public static final String AFFECTED_ITEMS_PROCESSING_ERROR = "AffectedItems_Processing_Error";

   @RBEntry("Impossible de traiter les objets affectés.")
   public static final String AFFECTED_ITEMS_PROCESSING_ERRORHEADER = "AffectedItems_Processing_ErrorHeader";

   @RBEntry("Echec du traitement des produits finis affectés.")
   public static final String AFFECTED_END_ITEMS_PROCESSING_ERROR = "AffectedEndItems_Processing_Error";

   @RBEntry("Impossible de traiter les produits finis affectés.")
   public static final String AFFECTED_END_ITEMS_PROCESSING_ERRORHEADER = "AffectedEndItems_Processing_ErrorHeader";

   @RBEntry("Echec lors du traitement des objets résultants.")
   public static final String RESULTING_ITEMS_PROCESSING_ERROR = "ResultingItems_Processing_Error";

   @RBEntry("Impossible de traiter les objets résultants.")
   public static final String RESULTING_ITEMS_PROCESSING_ERRORHEADER = "ResultingItems_Processing_ErrorHeader";

   @RBEntry("Une erreur s'est produite lors de la création des versions dérivées. Contactez votre administrateur.")
   public static final String NEWONEOFFVERISON_ACTION_CANNOT_CREATE = "NewOneOffVersion_Action_CannotCreate";

   @RBEntry("<b>ATTENTION</b> : Echec de la création des versions dérivées.")
   @RBComment("The <b> tags are added to bold the attention as per UI message design.  This is using a Ext dialog which supports Bold tags.")
   public static final String NEWONEOFFVERSION_ACTION_HEADER_MSG = "NewOneOffVersion_Action_HeaderMsg";

   @RBEntry("Nombre d'objets incorrect : {0}\n\nLe premier message envoyé indique :\n{1}")
   public static final String NEWONEOFFVERSION_ACTION_TOOMANYERRORS = "NewOneOffVersion_Action_TooManyErrors";

   @RBEntry("ATTENTION : Impossible de définir la disposition.")
   @RBComment("Header message for the diposition dialog.")
   public static final String SETDISPOSITION_ACTION_HEADER_MSG = "SetDisposition_Action_HeaderMsg";

   @RBEntry("Aucun des objets sélectionnés ne sont compatibles avec cette opération.")
   @RBComment("Message when the action is launched and the objects are not applicable.")
   public static final String INVALIDOBJECTS = "InvalidObjects";

   @RBEntry("Solution proposée")
   public static final String PRIVATE_CONSTANT_43 = "CHANGE_PROPOSEDCHANGES";

   @RBEntry("Contactez votre administrateur.")
   public static final String CHANGEMANAGEMENT_PROCESSING_ERRORMSG = "ChangeManagement_Processing_ErrorMsg";

   @RBEntry("Impossible de créer le rapport de problème.")
   public static final String CREATEPROBLEMREPORT_PROCESSING_ERROR = "CreateProblemReport_Processing_Error";

   @RBEntry("Impossible de créer la variation")
   public static final String CREATEVARIANCE_PROCESSING_ERROR = "CreateVariance_Processing_Error";

   @RBEntry("Impossible de créer la demande de modification.")
   public static final String CREATECHANGEREQUEST_PROCESSING_ERROR = "CreateChangeRequest_Processing_Error";

   @RBEntry("Impossible de créer le modèle d'avis de modification.")
   public static final String CREATECHANGENOTICETEMPLATE_PROCESSING_ERROR = "CreateChangeNoticeTemplate_Processing_Error";
   
   @RBEntry("Impossible de créer le modèle de tâche de modification.")
   public static final String CREATECHANGETASKTEMPLATE_PROCESSING_ERROR = "CreateChangeTaskTemplate_Processing_Error";
   
   @RBEntry("Impossible de créer l'avis de modification.")
   public static final String CREATECHANGENOTICE_PROCESSING_ERROR = "CreateChangeNotice_Processing_Error";

   @RBEntry("Une erreur non fatale est survenue lors de la création de l'avis de modification.")
   public static final String CreateChangeNotice_ImpactMatrix_ErrorHeader = "CreateChangeNotice_ImpactMatrix_ErrorHeader";

   @RBEntry("Impossible d'associer la matrice d'impact des modifications à cet avis de modification. Pour plus d'informations, contactez l'administrateur.")
   public static final String CreateChangeNotice_ImpactMatrix_Error = "CreateChangeNotice_ImpactMatrix_Error";

   @RBEntry("Impossible de créer la tâche de modification.")
   public static final String CREATECHANGETASK_PROCESSING_ERROR = "CreateChangeTask_Processing_Error";

   @RBEntry("Impossible de créer la proposition de modification.")
   public static final String CREATECHANGEPROPOSAL_PROCESSING_ERROR = "CreateChangeProposal_Processing_Error";

   @RBEntry("Impossible de modifier le rapport de problème.")
   public static final String EDITPROBLEMREPORT_PROCESSING_ERROR = "EditProblemReport_Processing_Error";

   @RBEntry("Impossible de modifier la variation")
   public static final String EDITVARIANCE_PROCESSING_ERROR = "EditVariance_Processing_Error";

   @RBEntry("Impossible de modifier la demande de modification.")
   public static final String EDITCHANGEREQUEST_PROCESSING_ERROR = "EditChangeRequest_Processing_Error";

   @RBEntry("Impossible de modifier l'avis de modification.")
   public static final String EDITCHANGENOTICE_PROCESSING_ERROR = "EditChangeNotice_Processing_Error";
   
   @RBEntry("Impossible de modifier le modèle d'avis de modification.")
   public static final String EDITCHANGENOTICETEMPLATE_PROCESSING_ERROR = "EditChangeNoticeTemplate_Processing_Error";

   @RBEntry("Impossible de modifier la tâche de modification.")
   public static final String EDITCHANGETASK_PROCESSING_ERROR = "EditChangeTask_Processing_Error";
   
   @RBEntry("Impossible de modifier le modèle de tâche de modification.")
   public static final String EDITCHANGETASKTEMPLATE_PROCESSING_ERROR = "EditChangeTaskTemplate_Processing_Error";

   @RBEntry("Impossible de modifier la proposition de modification.")
   public static final String EDITCHANGEPROPOSAL_PROCESSING_ERROR = "EditChangeProposal_Processing_Error";

   @RBEntry("Impossible de supprimer la tâche de modification.")
   public static final String DELETECHANGETASK_PROCESSING_ERROR = "DeleteChangeTask_Processing_Error";

   @RBEntry("Impossible de créer un plan de modification.")
   public static final String CREATE_CHANGE_PLAN_ERROR = "CREATE_CHANGE_PLAN_ERROR";

   @RBEntry("ATTENTION : Informations obligatoires manquantes.\n\nUne tâche de modification au moins est obligatoire. Créez une tâche de modification pour continuer.")
   public static final String IMPLEMENTATION_TABLE_NO_TASKS = "Implementation_Table_No_Tasks";

   @RBEntry("ATTENTION : Une erreur est survenue.\n\nImpossible de trouver le tableau de plan d'implémentation")
   public static final String UNABLE_TO_FIND_IMPL_TABLE = "Unable_To_Find_Impl_Table";

   @RBEntry("ATTENTION : Une demande de modification est nécessaire.\n\nAu moins une demande de modification doit être associée à l'avis de modification.")
   @RBComment("Message displayed when a Change Notice needs to have associated Change Request but it is missing")
   public static final String CHANGENOTICE_VALIDATE_ASSOCIATED_CR = "CHANGENOTICE_VALIDATE_ASSOCIATED_CR";

   @RBEntry("ATTENTION : Action non disponible.\n\nUne tâche de modification est nécessaire pour créer un nouvel avis de modification.\nVous n'êtes pas autorisé à créer une tâche de modification.")
   @RBComment("Error message for the Create Change Notice wizard when the user does not have access to create any Change Task types.")
   public static final String CREATECHANGENOTICE_NO_TASK_TYPES = "CreateChangeNotice_No_Task_Types";

   @RBEntry("Il n'existe aucune définition pour {0} dans le système de création de rapport tiers.")
   public static final String THIRDPARTYREPORTING_NODEFEXISTS_ERROR = "ThirdPartyReporting_NoDefExists_Error";

   @RBEntry("Ce rapport n'existe pas : {0}")
   public static final String REPORT_NOTEXISTS_ERROR = "Report_NotExists_Error";

   @RBEntry("Aucun rapport pour le type d'objet {0}")
   public static final String REPORT_NOTSUPPORTED_ERROR = "Report_NotSupported_Error";

   @RBEntry("Relation non valide pour {0}.")
   @RBComment("Message for validationg the association of an object for an AssociationConstrainable link when peforming a client action.")
   public static final String INVALID_ROLE_B_TYPE = "INVALID_ROLE_B_TYPE";

   @RBEntry("ATTENTION : Des informations obligatoires sont introuvables. \n\nVous devez impérativement indiquer le numéro de la tâche de modification. Modifiez cette tâche et spécifiez son numéro.")
   public static final String CHANGE_TASK_NUMBER_REQUIRED = "CHANGE_TASK_NUMBER_REQUIRED";

   @RBEntry("ATTENTION : Des informations obligatoires sont introuvables. \n\nVous devez impérativement indiquer le numéro de la tâche de modification par défaut. Modifiez cette tâche et spécifiez son numéro.")
   public static final String DEFAULT_CHANGE_TASK_NUMBER_REQUIRED = "DEFAULT_CHANGE_TASK_NUMBER_REQUIRED";

   @RBEntry("Vous ne disposez pas de l'autorisation de création pour le contexte sélectionné.")
   @RBComment("Error message for the change create wizard context step.")
   public static final String NO_CREATE_FOR_CONTEXT = "NO_CREATE_FOR_CONTEXT";
   
   @RBEntry("Attention : Impossible de créer l'avis de modification.\n\nVous ne disposez pas de la permission de création pour un ou plusieurs types de tâche de modification dans le modèle d'avis de modification sélectionné.")
   @RBComment("Error message for the Create Change Notice wizard when the user does not have access to create the Change Task types in the selected change notice template.")
   public static final String CREATE_CHANGE_NOTICE_FROM_TEMPLATE_NO_TASK_TYPES = "CREATE_CHANGE_NOTICE_FROM_TEMPLATE_NO_TASK_TYPES";

   /**
    * ##############################################################################
    *
    * Change Management specific workflow strings
    *
    * ##############################################################################
    **/
   @RBEntry("Créer automatiquement un avis de modification")
   @RBComment("Label for the Automate the fast-track checkbox")
   public static final String AUTOMATE_FASTTRACK = "AUTOMATE_FASTTRACK";

   @RBEntry("ATTENTION : Champs obligatoires non renseignés.\n\nLes champs Intervenant et Validateur sont obligatoires mais ne sont pas spécifiés. Utilisez le bouton \"Rechercher...\" pour sélectionner un utilisateur valide.")
   public static final String CHANGETASK_VALIDATE_USER = "CHANGETASK_VALIDATE_USER";

   @RBEntry("CONFIRMATION : Supprimer la tâche de modification \n\nVoulez-vous supprimer la tâche de modification sélectionnée ?")
   @RBComment("Message displayed to ask user whether they are sure they wish to delete change tasks")
   public static final String CONFIRM_DELETE_CHANGE_TASK = "CONFIRM_DELETE_CHANGE_TASK";

   @RBEntry("Attention : Impossible de poursuivre la modification.\n\nCet objet a été mis à jour par un autre utilisateur et l'assistant doit être actualisé. Les modifications apportées au cours de cette session de modification seront perdues.")
   @RBComment("Message displayed when the system detects a change is made.")
   public static final String CONFIRM_UPDATE_CHANGEITEM = "CONFIRM_UPDATE_CHANGEITEM";

   @RBEntry("Impossible d'officialiser cet avis de modification car les objets résultants suivants sont récupérés :")
   @RBComment("Special Instructions that appear in the \"Resolve Change Notice Conflicts\" Change Notice workflow task.  It is followed by a list of objects that are checked out.")
   public static final String PRERELEASE_VALIDATION_MSG = "PRERELEASE_VALIDATION_MSG";
   
   @RBEntry("Impossible d'exécuter l'officialisation de cet avis de modification car les règles métier suivantes ont échoué :")
   @RBComment("Special Instructions that appear in the \"Resolve Change Notice Conflicts\" Change Notice workflow task.  It is followed by a list of business rules that failed.")
   public static final String BUSINESS_RULES_PRERELEASE_VALIDATION_MSG = "BUSINESS_RULES_PRERELEASE_VALIDATION_MSG";

   @RBEntry("CONFIRMATION : Voulez-vous vraiment quitter cette page ? Si vous continuez, toutes les données entrées dans cette page du tableau seront perdues.")
   @RBComment("Message displayed to ask user whether they are sure they wish to go to next page in a change table")
   public static final String CONFIRM_PAGING_CHANGE_TABLES = "CONFIRM_PAGING_CHANGE_TABLES";

   @RBEntry("Impossible d'officialiser cet avis de modification, car les tâches de modification suivantes ne sont pas prêtes pour l'implémentation :")
   @RBComment("Special Instructions that appear in the \"Assignee or Reviewer Conflicts\" Change Notice workflow task.  It is followed by a list of change tasks that are not ready for implementation.")
   public static final String IMPLEMENTATION_VALIDATION_MSG = "IMPLEMENTATION_VALIDATION_MSG";

   @RBEntry("Echec de la collecte")
   @RBComment("Message for when none of the objects collected are valid for the table.")
   public static final String COLLECTED_FAILED = "COLLECTED_FAILED";

   @RBEntry("Impossible d'ajouter tous les objets collectés à cet emplacement.")
   @RBComment("Detailed message for when none of the objects collected are valid for the table.")
   public static final String COLLECTED_FAILED_MSG = "COLLECTED_FAILED_MSG";

   @RBEntry("Echec partiel de la collecte")
   @RBComment("Message for when some of the objects collected are not valid for the table.")
   public static final String COLLECTED_PARTIALLY_FAILED = "COLLECTED_PARTIALLY_FAILED";

   @RBEntry("Impossible d'ajouter certains objets collectés à cet emplacement :")
   @RBComment("Detailed message for when some of the objects collected are not valid for the table.")
   public static final String COLLECTED_PARTIALLY_FAILED_MSG = "COLLECTED_PARTIALLY_FAILED_MSG";

   @RBEntry("Echec de l'ajout des objets révisés")
   @RBComment("Message for when the revise is successful but none of the objects revised are valid for the table.")
   public static final String REVISE_FAILED = "REVISE_FAILED";

   @RBEntry("Les objets ont été révisés mais ne peuvent pas être ajoutés à cet emplacement.")
   @RBComment("Detailed message for when the revise is successful but none of the objects revised are valid for the table.")
   public static final String REVISE_FAILED_MSG = "REVISE_FAILED_MSG";

   @RBEntry("Echec partiel de l'ajout des objets révisés")
   @RBComment("Message for when the revise is successful but some of the objects revised are invalid for the table.")
   public static final String REVISE_PARTIALLY_FAILED = "REVISE_PARTIALLY_FAILED";

   @RBEntry("Les objets ont été révisés mais certains d'entre eux ne peuvent pas être ajoutés à cet emplacement :")
   @RBComment("Detailed message for when the revise is successful but some of the objects revised are invalid for the table.")
   public static final String REVISE_PARTIALLY_FAILED_MSG = "REVISE_PARTIALLY_FAILED_MSG";
   
   @RBEntry("Aucune cible d'officialisation commune n'a été trouvée")
   @RBComment("Message for when no common release targets are found when launching the release target table action.")
   public static final String NO_COMMON_RELEASE_TARGETS = "NO_COMMON_RELEASE_TARGETS";


   /**
    * ##############################################################################
    *
    * Submit Now / Submit Later messages
    *
    * ##############################################################################
    **/
   @RBEntry("<br><b>CONFIRMATION</b> : Soumettre l'objet de modification maintenant ?<br><br>Cliquez sur Soumettre maintenant, pour soumettre l'objet de modification dès maintenant.<br>Cliquez sur Soumettre plus tard, pour le soumettre à un autre moment.")
   @RBComment("The string displayed to a user when they attempt to submit a change object where Submit Now is enabled.  The <br> and <b> tags are needed because this text is dumped directly into HTML content at runtime.  There are three distinct sentences.  the first is the header message.  The remaining two are the instructions.")
   public static final String SUBMIT_NOW_MESSAGE = "SUBMIT_NOW_MESSAGE";

   @RBEntry("Soumettre maintenant")
   @RBComment("Label for the JS Dojo button.  Equivalent of the \"Ok\" on a confirmation dialog.  See SUBMIT_NOW_MESSAGE above for context text.")
   public static final String SUBMIT_NOW_BUTTON = "SUBMIT_NOW_BUTTON";

   @RBEntry("Soumettre plus tard")
   @RBComment("Label for the JS Dojo button.  Equivalent of the \"Cancel\" on a confirmation dialog.  See SUBMIT_NOW_MESSAGE above for context text.")
   public static final String SUBMIT_LATER_BUTTON = "SUBMIT_LATER_BUTTON";

   /**
    * ##############################################################################
    *
    * Change object attributes to support proper localization in client
    *
    * ##############################################################################
    **/
   @RBEntry("Complexité")
   public static final String PRIVATE_CONSTANT_44 = "WTChangeOrder2.theChangeNoticeComplexity";

   @RBEntry("Catégorie")
   public static final String THE_VARIANCE_CATEGORY = "WTVariance.theVarianceCategory";

   @RBEntry("<U class='mnemonic'>O</U>bjets associés")
   @RBComment("Used for the text on the Related Objects third level nav menu.  The <U class=mnemonic> </U> tag should be put around the character that is the access key.")
   public static final String PRIVATE_CONSTANT_45 = "object.relatedDirItems.description";

   @RBEntry("o")
   @RBPseudo(false)
   @RBComment("Mnemonic for the Related Objects third level nav menu. This should be a character that matches the character surrounded by the <U class=mnemonic> </U> tag in the value line above.")
   public static final String PRIVATE_CONSTANT_46 = "object.relatedDirItems.hotkey";

   @RBEntry("<U class='mnemonic'>D</U>irectives associées")
   @RBComment("Used for the text on the Related Objects third level nav menu.  The <U class=mnemonic> </U> tag should be put around the character that is the access key.")
   public static final String PRIVATE_CONSTANT_49 = "object.relatedPartItems.description";

   @RBEntry("d")
   @RBPseudo(false)
   @RBComment("Mnemonic for the Related Objects third level nav menu. This should be a character that matches the character surrounded by the <U class=mnemonic> </U> tag in the value line above.")
   public static final String PRIVATE_CONSTANT_50 = "object.relatedPartItems.hotkey";

   @RBEntry("Aucune validation requise")
   @RBComment("Label for the Change Task no review required check box.")
   public static final String NO_REVIEW_REQUIRED = "NO_REVIEW_REQUIRED";

   @RBEntry("Non obligatoire")
   @RBComment("Label for the Change Task reviewer role when no review is required")
   public static final String ROLE_NOT_REQUIRED = "ROLE_NOT_REQUIRED";

   /**
    * ##############################################################################
    * Location field for Change Directive, Change Action
    * ##############################################################################
    **/
   @RBEntry("Emplacement")
   @RBComment("Label for the Location")
   public static final String LOCATION_LABEL = "LOCATION";

   @RBEntry("Directive de modification")
   @RBComment("Label for the Change Directive")
   public static final String CHANGE_DIRECTIVE = "CHANGE_DIRECTIVE";

   @RBEntry("Critère d'effectivité")
   @RBComment("Label for the Configuration Item")
   public static final String CONFIGURATION_ITEM = "CONFIGURATION_ITEM";

   @RBEntry("Directives de modification ayant un impact")
   @RBComment("The table title for the Change Directives")
   public static final String CHANGE_DIRECTIVES_TABLE = "CHANGE_DIRECTIVES_TABLE";

   @RBEntry("Actions de modification associées")
   @RBComment("Label for the related Change Actions")
   public static final String RELATEDCHANGEACTIONS = "RELATEDCHANGEACTIONS";

   @RBEntry("Effectivité")
   @RBComment("The column name for Effectivity")
   public static final String EFFECTIVITY = "EFFECTIVITY";

   @RBEntry("Statut du calcul")
   @RBComment("The column name for Calculation Status")
   public static final String CALCULATIONSTATUS = "CALCULATIONSTATUS";

   @RBEntry("Par défaut")
   @RBComment("change directive info page default table view name")
   public static final String CHANGE_DIRECTIVES_VIEW_DEFAULT_NAME = "CHANGE_DIRECTIVES_VIEW_DEFAULT_NAME";

   @RBEntry("Nom du tableau par défaut ")
   @RBComment(" change directive info page description default table view name")
   public static final String CHANGE_DIRECTIVES_VIEW_DEFAULT_DESC = "CHANGE_DIRECTIVES_VIEW_DEFAULT_DESC";

   @RBEntry("Page d'informations")
   @RBComment(" change directive info page description default table view name")
   public static final String INFO_PAGE = "CHANGE_DIRECTIVES_VIEW_INFO_PAGE";


   @RBEntry("Planifié")
   @RBComment(" status indicating that the task is scheduled not started")
   public static final String SCHEDULED = "SCHEDULED";

   @RBEntry("En cours")
   @RBComment(" status indicating that the task is in progress")
   public static final String INPROGRESS = "INPROGRESS";

   @RBEntry("Terminé")
   @RBComment(" status indicating that the task has been completed")
   public static final String COMPLETED = "COMPLETED";

   @RBEntry("En retard")
   @RBComment(" status indicating that the task is over due")
   public static final String OVERDUE = "OVERDUE";

   @RBEntry("Catégorie de confirmation")
   public static final String CONFIRMATION_CATEGORY = "CONFIRMATION_CATEGORY";

   @RBEntry("Vérification des confirmations")
   public static final String CONFIRMATION_AUDIT = "CONFIRMATION_AUDIT";
   
   @RBEntry("-- Sélectionner un modèle --")
   public static final String SELECT_TEMPLATE = "SELECT_TEMPLATE";
   
   @RBEntry("-- Aucun modèle disponible --")
   public static final String NO_TEMPLATES_AVAILABLE = "NO_TEMPLATES_AVAILABLE";
   
   @RBEntry("Modèle")
   public static final String CHANGE_TEMPLATE_PICKER_LABEL = "CHANGE_TEMPLATE_PICKER_LABEL";

  @RBEntry("Dû le")
  public static final String NEED_DATE = "NEED_DATE";
  
  @RBEntry("Type")
  public static final String TYPE = "TYPE";
  

  /**
   * ##############################################################################
   * Labels for Available attributes to avoid labels showing as duplicates
   * ##############################################################################
   **/
  @RBEntry("Complexité de l'avis de modification")
  public static final String CHANGE_ORDER_COMPLEXITY = "CHANGE_ORDER_COMPLEXITY";
  
  @RBEntry("Priorité de l'origine de la modification")
  public static final String ISSUE_PRIORITY = "ISSUE_PRIORITY";
  
  @RBEntry("Catégorie d'origine de la modification")
  public static final String ISSUE_CATEGORY = "ISSUE_CATEGORY";
  
  @RBEntry("Catégorie")
  public static final String ISSUE_THECATEGORY = "ISSUE_THECATEGORY";
  
  @RBEntry("Priorité de la demande de modification")
  public static final String REQUEST_PRIORITY = "REQUEST_PRIORITY";
  
  @RBEntry("Catégorie de demande de modification")
  public static final String REQUEST_CATEGORY = "REQUEST_CATEGORY";
  
  @RBEntry("Catégorie")
  public static final String REQUEST_THECATEGORY = "REQUEST_THECATEGORY"; 
  
  @RBEntry("Complexité de la demande de modification")
  public static final String REQUEST_COMPLEXITY = "REQUEST_COMPLEXITY";

  @RBEntry("Propriétaire de la variation")
  public static final String VARIANCE_OWNER = "VARIANCE_OWNER";
  
  @RBEntry("Catégorie de variation")
  public static final String VARIANCE_CATEGORY = "VARIANCE_CATEGORY";

  /*Business rules resource bundle entry START*/
  @RBEntry("Validation de pré-officialisation des modifications")
  @RBComment("Name of the rule set that will be used to display to the user when the workflow fails the check before releasing the change object.")
  public static final String CHANGE_PRE_RELEASE_RULESET_NAME = "CHANGE_PRE_RELEASE_RULESET_NAME";

  @RBEntry("Jeu de règles métier utilisé avant l'officialisation des objets dans le cadre du processus de modification")
  @RBComment("Description for the CHANGE PRE RELEASE RULESET.")
  public static final String CHANGE_PRE_RELEASE_RULESET_DESC = "CHANGE_PRE_RELEASE_RULESET_DESC";

  @RBEntry("Règle de récupération")
  @RBComment("Rule Validator to check no objects are checked out.")
  public static final String CHECK_OUT_VALIDATOR_RULE_NAME = "CHECK_OUT_VALIDATOR_RULE_NAME";

  @RBEntry("Cette règle permet de détecter si des objets sont récupérés. Si des objets sont récupérés, la règle échoue. Sinon, elle réussit.")
  @RBComment("Description for CHECK_OUT_VALIDATOR_RULE_NAME")
  public static final String CHECK_OUT_VALIDATOR_RULE_DESC = "CHECK_OUT_VALIDATOR_RULE_DESC";
  
  @RBEntry("Règle de cible d'officialisation")
  public static final String RELEASE_TARGET_RULE_NAME = "RELEASE_TARGET_RULE_NAME";

  @RBEntry("La règle de cible d'officialisation permet de vérifier que la cible d'officialisation spécifiée est valide compte tenu de l'état actuel de l'objet résultant. La règle est valide même si aucune cible d'officialisation n'a été spécifiée pour l'objet résultant et que la cible d'officialisation des modifications est valide compte tenu de l'état actuel d'un objet résultant.")
  @RBComment("Description for Release Target Rule")
  public static final String RELEASE_TARGET_RULE_DESC = "RELEASE_TARGET_RULE_DESC";
  /*Business rules resource bundle entry END*/
  
  /* Workflow task tab names */
  @RBEntry("Objets résultants")
  @RBComment("Workflow task tab name for Change Task resulting objects")
  public static final String WFTASK_RESULTING_OBJECTS_TAB_NAME = "WFTASK_RESULTING_OBJECTS_TAB_NAME";
  
  @RBEntry("Impacts")
  @RBComment("Workflow task tab name for Change Request, Change Notice, Problem Report or Variance impacts")
  public static final String WFTASK_IMPACTS_TAB_NAME = "WFTASK_IMPACTS_TAB_NAME";

}
