/* bcwti
 *
 * Copyright (c) 2013 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */
package com.ptc.windchill.enterprise.search.client;

import wt.util.resource.RBComment;
import wt.util.resource.RBEntry;
import wt.util.resource.RBPseudo;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

/**
 * searchResource message resource bundle [English/US]
 */
@RBUUID("com.ptc.windchill.enterprise.search.client.searchClientResource")
public final class searchClientResource_es extends WTListResourceBundle {
   @RBEntry("Recordar selección de objetos en la sesión.")
   @RBComment("Decscription for preference 'remember object selection'.")
   public static final String PRIVATE_CONSTANT_0 = "STICKY_PICKER_SHORT_DESCRIPTION";

   @RBEntry("Recordar selección de objetos en la sesión.")
   @RBComment("Decscription for preference 'remember object selection'.")
   public static final String PRIVATE_CONSTANT_1 = "STICKY_PICKER_DESCRIPTION";

   @RBEntry("Recordar selección de objetos")
   @RBComment("Preference Remember object selection.")
   public static final String PRIVATE_CONSTANT_2 = "STICKY_PICKER";

   @RBEntry("Esta preferencia se utiliza para aplicar el control de acceso a los resultados de la búsqueda.")
   @RBComment("This preference is used to apply access control on search results.")
   public static final String PRIVATE_CONSTANT_3 = "ACCESS_CONTROL_FLAG_SHORT_DESCRIPTION";

   @RBEntry("Esta preferencia se utiliza para aplicar el control de acceso a los resultados de la búsqueda.")
   @RBComment("This preference is used to apply access control on search results.")
   public static final String PRIVATE_CONSTANT_4 = "ACCESS_CONTROL_FLAG_DESCRIPTION";

   @RBEntry("Aplicar control de acceso a resultados de la búsqueda")
   @RBComment("Apply Access Control to Search Results")
   public static final String PRIVATE_CONSTANT_5 = "ACCESS_CONTROL_FLAG";

   @RBEntry("Esta preferencia se utiliza para aplicar el control de acceso a los resultados de la búsqueda.")
   @RBComment("This preference is used to apply access control on search results.")
   public static final String PRIVATE_CONSTANT_6 = "ACCESS_CONTROL_FLAG_LONGDESCRIPTION";

   @RBEntry("Utilice un asterisco (*) como carácter comodín para obtener más resultados.")
   @RBComment("Wildcard suggestion for keyword field")
   public static final String PRIVATE_CONSTANT_7 = "WILDCARD_SUGGESSTION";

   @RBEntry("Ayuda")
   @RBComment("Search page help icon tooltip")
   public static final String PRIVATE_CONSTANT_8 = "HELP";

   @RBEntry("Búsqueda")
   @RBComment("Label for the page title of the search page.")
   public static final String SEARCH_LABEL = "SEARCH_LABEL";

   @RBEntry("Despejar")
   @RBComment("Label for the clear button .")
   public static final String PRIVATE_CONSTANT_9 = "CLEAR_BUTTON";

   @RBEntry("Buscar")
   @RBComment("Label for the type property on the search page.")
   public static final String PRIVATE_CONSTANT_10 = "SEARCH_FOR";

   @RBEntry("Preferencias")
   @RBComment("Label for the \"Preferences\" link on search page.")
   public static final String PRIVATE_CONSTANT_11 = "PREFERENCES_LNK";

   @RBEntry("Abrir preferencias del usuario")
   @RBComment("Tooltip for the \"Preferences\" link on search page.")
   public static final String PRIVATE_CONSTANT_12 = "PREFERENCES_LNK_TT";

   @RBEntry("Buscar")
   @RBComment("Label for the \"Show Results\" input field")
   public static final String PRIVATE_CONSTANT_13 = "RANGE_OF_SEARCH_PROPTY";

   @RBEntry("Con cualquiera de estos criterios")
   @RBComment("Label for one of the values in the \"Show Results\" pull down list")
   public static final String PRIVATE_CONSTANT_14 = "RANGE_OF_SEARCH_VALUE_OR";

   @RBEntry("Con todos estos criterios")
   @RBComment("Label for one of the values in the \"Show Results\" pull down list")
   public static final String PRIVATE_CONSTANT_15 = "RANGE_OF_SEARCH_VALUE_AND";

   @RBEntry("Definir el ámbito de la búsqueda")
   @RBComment("Label for search scope <HR> separator of the search criteria")
   public static final String PRIVATE_CONSTANT_16 = "SCOPE_SEPARATOR_LABEL";

   @RBEntry("Seleccionar criterios de búsqueda")
   @RBComment("Label for search criteria <HR> separator of the search criteria")
   public static final String PRIVATE_CONSTANT_17 = "CRITERIA_SEPARATOR_LABEL";

   @RBEntry("Todos los contextos")
   @RBComment("The default element in the container drop down list on search page.")
   public static final String PRIVATE_CONSTANT_18 = "ALL_CONTAINERS";

   @RBEntry("Todos los proyectos")
   @RBComment("Label for All Projects.")
   public static final String PRIVATE_CONSTANT_19 = "ALL_PROJECTS";

   @RBEntry("Todos los productos")
   @RBComment("Label for All Products.")
   public static final String PRIVATE_CONSTANT_20 = "ALL_PRODUCTS";

   @RBEntry("Todas las bibliotecas")
   @RBComment("Label for All Libraries.")
   public static final String PRIVATE_CONSTANT_21 = "ALL_LIBRARIES";

   @RBEntry("Sin relación")
   @RBComment("The default value for relationship on search in network page.")
   public static final String PRIVATE_CONSTANT_22 = "NO_RELATIONS";

   @RBEntry("Contexto")
   @RBComment("Label for the property \"Search In:\" on the search page.")
   public static final String PRIVATE_CONSTANT_23 = "CONTAINER_TYPE_PROPTY";

   @RBEntry("De los que soy miembro")
   @RBComment("Label for the membership checkbox on the search page")
   public static final String PRIVATE_CONSTANT_24 = "MEMBER_OF_CONTAINER_CHKBX";

   @RBEntry("De mi organización")
   @RBComment("Label for the search only in contexts in my organization checkbox on the search page")
   public static final String PRIVATE_CONSTANT_25 = "SEARCH_IN_USER_ORG_CHKBX";

   @RBEntry("Resultados por página")
   @RBComment("Label for the \"Results Per Page:\" input field")
   public static final String PRIVATE_CONSTANT_26 = "ADHOC_PAGE_COUNT_PROPTY";

   @RBEntry("Búsqueda de clasificación")
   @RBComment("Label for the \"Classification Search\" link on search page.")
   public static final String PRIVATE_CONSTANT_27 = "CLASSIFICATION_SEARCH_LNK";

   @RBEntry("Abrir búsqueda de clasificación")
   @RBComment("Tooltip for the \"Classification Search\" link on search page.")
   public static final String PRIVATE_CONSTANT_28 = "CLASSIFICATION_SEARCH_LNK_TT";

   @RBEntry("Búsqueda avanzada")
   @RBComment("Label for the page title of the advanced search page.")
   public static final String ADVANCED_SEARCH_LABEL = "ADVANCED_SEARCH_LABEL";

   @RBEntry("Personalizar...")
   @RBComment("Label for the link to the customize saved search table.")
   public static final String PRIVATE_CONSTANT_29 = "CUSTOMIZE_LINK_LABEL";

   @RBEntry("Personalizar la lista de búsquedas guardadas")
   @RBComment("Tool tip for the link to the customize saved search table.")
   public static final String PRIVATE_CONSTANT_30 = "CUSTOMIZE_LINK_TT";

   @RBEntry("Grupos")
   @RBComment("Label for header of groups table in saved search create clerk.")
   public static final String PRIVATE_CONSTANT_31 = "GROUP_TABLE_HEADER";

   @RBEntry("Añadir")
   @RBComment("Label for 'Add' action on the Group Access table of saved search create clerk.")
   public static final String PRIVATE_CONSTANT_32 = "ADD_GROUP_LABEL";

   @RBEntry("Añadir grupos para búsqueda guardada")
   @RBComment("Tool tip for 'Add' action on the Group Access table of saved search create clerk.")
   public static final String PRIVATE_CONSTANT_33 = "ADD_GROUP_TT";

   @RBEntry("Acceso de grupo")
   @RBComment("Label for the Group Access Tab in the saved search create clerk.")
   public static final String PRIVATE_CONSTANT_34 = "GROUP_ACCESS_TAB_LABEL";

   @RBEntry("Definir acceso de grupo para esta búsqueda")
   @RBComment("Tool tip for the Group Access Tab in the saved search create clerk.")
   public static final String PRIVATE_CONSTANT_35 = "GROUP_ACCESS_TAB_TT";

   @RBEntry("- Seleccionar una acción -")
   @RBComment("Label for table action dropdown list.")
   public static final String PRIVATE_CONSTANT_36 = "TABLE_ACTION_LIST_PROMPT";

   @RBEntry("Borrar esta búsqueda")
   @RBComment("Label for delete action in customize saved search table.")
   public static final String PRIVATE_CONSTANT_37 = "DELETE_LABEL";

   @RBEntry("Mostrar")
   @RBComment("Label for show action in customize saved search table.")
   public static final String PRIVATE_CONSTANT_38 = "SHOW_LABEL";

   @RBEntry("Ocultar")
   @RBComment("Label for hide action in customize saved search table.")
   public static final String PRIVATE_CONSTANT_39 = "HIDE_LABEL";

   @RBEntry("Búsquedas guardadas")
   @RBComment("Label for header of customize saved search table.")
   public static final String PRIVATE_CONSTANT_40 = "CUSTOMIZE_SAVED_SEARCH_TABLE_LABEL";

   @RBEntry("Mostrar en la lista de búsquedas guardadas")
   @RBComment("Label for display search check box on saved search create clerk.")
   public static final String PRIVATE_CONSTANT_41 = "DISPLAY_SEARCH_LABEL";

   @RBEntry("Exportar a un fichero")
   @RBComment("Label for the export button.")
   public static final String PRIVATE_CONSTANT_42 = "EXPORT_TO_FILE_LABEL";

   @RBEntry("Exportar a un fichero")
   @RBComment("Tool tip for the export button.")
   public static final String PRIVATE_CONSTANT_43 = "EXPORT_TO_FILE_TT";

   @RBEntry("Guardar fichero exportado como")
   @RBComment("Label for the File name in the export wizard")
   public static final String PRIVATE_CONSTANT_44 = "EXPORT_FILE_SAVE";

   @RBEntry("Formato:")
   @RBComment("Label for the File format in the export wizard")
   public static final String PRIVATE_CONSTANT_45 = "EXPORT_FILE_FORMAT";

   @RBEntry("csv")
   @RBComment("Label for csv format to export")
   public static final String PRIVATE_CONSTANT_46 = "EXPORT_FORMAT_CSV";

   @RBEntry("xml")
   @RBComment("Label for xml format to export")
   public static final String PRIVATE_CONSTANT_47 = "EXPORT_FORMAT_XML";

   @RBEntry("Informe HTML")
   @RBComment("Label for html format to export")
   public static final String PRIVATE_CONSTANT_48 = "EXPORT_FORMAT_HTML";

   @RBEntry("Informe XLS")
   @RBComment("Label for xls format to export")
   public static final String PRIVATE_CONSTANT_49 = "EXPORT_FORMAT_XLS";

   @RBEntry("xls")
   @RBComment("Label for xls format to SUMA export")
   public static final String PRIVATE_CONSTANT_50 = "EXPORT_FORMAT_SUMA_XLS";

   @RBEntry("Descargando el fichero de exportación...")
   @RBComment("Label for downloading the export file")
   public static final String PRIVATE_CONSTANT_51 = "ACT_LBL_DOWNLOAD";

   @RBEntry("Cierre la ventana al terminar.")
   @RBComment("Close window message")
   public static final String PRIVATE_CONSTANT_52 = "ACT_LBL_CLOSE_MSG";

   @RBEntry("Es igual a")
   @RBComment("Label for the operator pulldown on the advanced search, search criteria table")
   public static final String PRIVATE_CONSTANT_53 = "OP_EQ";

   @RBEntry("No es igual a")
   @RBComment("Label for the operator pulldown on the advanced search, search criteria table")
   public static final String PRIVATE_CONSTANT_54 = "OP_NE";

   @RBEntry("Menor que")
   @RBComment("Label for the operator pulldown on the advanced search, search criteria table")
   public static final String PRIVATE_CONSTANT_55 = "OP_LT";

   @RBEntry("Menor que o igual a")
   @RBComment("Label for the operator pulldown on the advanced search, search criteria table")
   public static final String PRIVATE_CONSTANT_56 = "OP_LE";

   @RBEntry("Mayor que")
   @RBComment("Label for the operator pulldown on the advanced search, search criteria table")
   public static final String PRIVATE_CONSTANT_57 = "OP_GT";

   @RBEntry("Mayor que o igual a")
   @RBComment("Label for the operator pulldown on the advanced search, search criteria table")
   public static final String PRIVATE_CONSTANT_58 = "OP_GE";

   @RBEntry("Buscar búsquedas guardadas para borrar")
   @RBComment("Label for the \"Administrative Delete\" action for saved searches.")
   public static final String PRIVATE_CONSTANT_59 = "ADMIN_DELETE";

   @RBEntry("Elegir tipos de objeto")
   @RBComment("Label for the object type picker on the simple search page.")
   public static final String PRIVATE_CONSTANT_60 = "CHANGE_OBJECT_TYPES";

   @RBEntry("Seleccionar")
   @RBComment("Button to select a saved search and populate criteria")
   public static final String PRIVATE_CONSTANT_61 = "SELECT_BTN";

   @RBEntry("--Seleccionar--")
   @RBComment("Label for the default element for the \"Criteria\" pulldown on the Advanced Search page")
   public static final String PRIVATE_CONSTANT_62 = "SELECT_CRITERION";

   @RBEntry("Cerrar")
   @RBComment("Label for an action button that closes a window")
   public static final String PRIVATE_CONSTANT_63 = "CLOSE_BUTTON";

   @RBEntry("Buscar búsquedas guardadas para borrar")
   @RBComment("Label for the saved search administrative delete clerk")
   public static final String ADMIN_DELETE_PICKER_LABEL = "ADMIN_DELETE_PICKER_LABEL";

   @RBEntry("Creador")
   @RBComment("Label for the saved search admin delete picker for created by")
   public static final String PRIVATE_CONSTANT_64 = "ADMIN_DELETE_CREATED_BY_LABEL";

   @RBEntry("Fecha de creación")
   @RBComment("Label for the saved search admin delete picker for created on")
   public static final String PRIVATE_CONSTANT_65 = "ADMIN_DELETE_CREATED_ON_LABEL";

   @RBEntry("Fecha de modificación")
   @RBComment("Label for the saved search admin delete picker for last modified criteria")
   public static final String PRIVATE_CONSTANT_66 = "ADMIN_DELETE_LAST_UPDATED_LABEL";

   @RBEntry("Creador")
   @RBComment("Label for the saved search customize table \"created by\" column")
   public static final String PRIVATE_CONSTANT_67 = "CREATED_BY_LABEL";

   @RBEntry("Cliente propietario")
   @RBComment("Label for the saved search customize table owningclient (owner) column")
   public static final String PRIVATE_CONSTANT_68 = "QUERY_OWNING_CLIENT";

   @RBEntry("Acceso de grupo")
   @RBComment("Label for the saved search customize table group access column")
   public static final String PRIVATE_CONSTANT_69 = "QUERY_GROUP_ACCESS";

   @RBEntry("�?mbito")
   @RBComment("Label for the saved search table scope column")
   public static final String PRIVATE_CONSTANT_70 = "SAVED_QUERY_SCOPE";

   @RBEntry("Nombre")
   @RBComment("Label for the saved search customize table name column")
   public static final String PRIVATE_CONSTANT_71 = "NAME_LABEL";

   @RBEntry("Mostrar")
   @RBComment("Label for the saved search customize table show column")
   public static final String PRIVATE_CONSTANT_72 = "QUERY_SHOW";

   @RBEntry("Todos los tipos de objeto pertinentes")
   @RBComment("Label for the type property")
   public static final String PRIVATE_CONSTANT_73 = "ALL_ITEMS";

   @RBEntry("Nombre")
   @RBComment("Label for the name attribute")
   public static final String PRIVATE_CONSTANT_74 = "NAME_ATTRIBUTE";

   @RBEntry("Número")
   @RBComment("Label for the number attribute")
   public static final String PRIVATE_CONSTANT_75 = "NUMBER_ATTRIBUTE";

   @RBEntry("Fecha de modificación")
   @RBComment("Label for the last modified attribute")
   public static final String PRIVATE_CONSTANT_76 = "LAST_UPDATED_ATTRIBUTE";

   @RBEntry("Desde")
   @RBComment("Label for the From date attribute")
   public static final String PRIVATE_CONSTANT_77 = "FROM_DATE_ATTRIBUTE";

   @RBEntry("Hasta")
   @RBComment("Label for the To date attribute")
   public static final String PRIVATE_CONSTANT_78 = "TO_DATE_ATTRIBUTE";

   @RBEntry("Fecha de creación")
   @RBComment("Label for the created attribute")
   public static final String PRIVATE_CONSTANT_79 = "CREATED_ATTRIBUTE";

   @RBEntry("Todas")
   @RBComment("All")
   public static final String PRIVATE_CONSTANT_80 = "VERSION_ALL";

   @RBEntry("Más reciente")
   @RBComment("Latest")
   public static final String PRIVATE_CONSTANT_81 = "VERSION_LATEST";

   @RBEntry("Palabra clave")
   @RBComment("Keyword")
   public static final String PRIVATE_CONSTANT_82 = "KEYWORD_LABEL";

   @RBEntry("Búsquedas guardadas")
   @RBComment("Saved Searches")
   public static final String PRIVATE_CONSTANT_83 = "SAVED_SEARCH_LABEL";

   @RBEntry("--Seleccionar--")
   @RBComment("-- Select a Search --")
   public static final String PRIVATE_CONSTANT_84 = "SELECT_SEARCH_LABEL";

   @RBEntry("Revisión")
   @RBComment("Version")
   public static final String PRIVATE_CONSTANT_85 = "VERSION_LABEL";

   @RBEntry("Seleccionar")
   @RBComment("Select")
   public static final String PRIVATE_CONSTANT_86 = "SELECT_LABEL";

   @RBEntry("Especificar")
   @RBComment("Specify")
   public static final String PRIVATE_CONSTANT_87 = "SPECIFY_LABEL";

   @RBEntry("Iteración")
   @RBComment("Iteration")
   public static final String PRIVATE_CONSTANT_88 = "ITERATION_LABEL";

   @RBEntry("Criterios:")
   @RBComment("Criteria")
   public static final String PRIVATE_CONSTANT_89 = "CRITERIA_LABEL";

   /**
    * Picker Related localized values
    **/
   @RBEntry("Nombre de usuario")
   @RBComment("User Name")
   public static final String PRIVATE_CONSTANT_90 = "USER_NAME_LABEL";

   @RBEntry("Nombre completo")
   @RBComment("Full Name")
   public static final String PRIVATE_CONSTANT_91 = "FULL_NAME_LABEL";

   @RBEntry("Correo electrónico")
   @RBComment("Email")
   public static final String PRIVATE_CONSTANT_92 = "EMAIL_LABEL";

   @RBEntry("Nombre de la organización")
   @RBComment("Organization Name")
   public static final String PRIVATE_CONSTANT_93 = "ORG_NAME_LABEL";

   @RBEntry("ID de organización")
   @RBComment("Organization ID")
   public static final String PRIVATE_CONSTANT_94 = "ORG_ID_LABEL";

   @RBEntry("Nombre del grupo")
   @RBComment("Group Name")
   public static final String PRIVATE_CONSTANT_95 = "GROUP_NAME_LABEL";

   @RBEntry("Descripción")
   @RBComment("Description")
   public static final String PRIVATE_CONSTANT_96 = "DESCRIPTION_LABEL";

   @RBEntry("Nombre del contexto")
   @RBComment("Context Name")
   public static final String PRIVATE_CONSTANT_97 = "CONTEXT_NAME_LABEL";

   @RBEntry("Estado")
   @RBComment("State")
   public static final String PRIVATE_CONSTANT_98 = "STATE_LABEL";

   @RBEntry("Contexto")
   @RBComment("Context")
   public static final String PRIVATE_CONSTANT_99 = "CONTEXT_LABEL";

   @RBEntry("Número")
   @RBComment("Number")
   public static final String PRIVATE_CONSTANT_100 = "NUMBER_LABEL";

   @RBEntry("Nombre del participante")
   @RBComment("Participant Name")
   public static final String PRIVATE_CONSTANT_101 = "PARTICIPANT_NAME_LABEL";

   @RBEntry("Escriba el nombre completo del usuario, el nombre del grupo (Grupo azul) o el nombre de la organización (Organización XYZ). Separe las entradas con un punto y coma (;). Puede utilizar el asterisco (*) como carácter comodín. Por ejemplo: J* Rodríguez; María Pérez; Grupo azul; Organización *.")
   @RBComment("Principal Picker Help Text")
   public static final String PRIVATE_CONSTANT_102 = "PRINCIPAL_PICKER_HELP_TEXT";

   @RBEntry("Escriba el nombre completo del usuario. Separe las entradas con un punto y coma (;). Puede utilizar el asterisco (*) como carácter comodín. Por ejemplo: *, Mike; Smith, Jane; J*, Doe.")
   @RBComment("User Picker Help Text")
   public static final String PRIVATE_CONSTANT_103 = "USER_PICKER_HELP_TEXT";

   @RBEntry("Por ejemplo: Mary Smith; *Smith; Mary*")
   @RBComment("User Picker Short Help Text")
   public static final String PRIVATE_CONSTANT_104 = "USER_PICKER_SHORT_HELP_TEXT";

   @RBEntry("Escriba el nombre del usuario (nombre de usuario). Separe las entradas con punto y coma (;). El comodín * puede utilizarse en representación de caracteres. Por ejemplo: Admin*; Mike")
   @RBComment("User Picker User Name Help Text")
   public static final String PRIVATE_CONSTANT_105 = "USER_PICKER_NAME_HELP_TEXT";

   @RBEntry("Por ejemplo: Admin*; Mike")
   @RBComment("User Picker User Name Short Help Text")
   public static final String PRIVATE_CONSTANT_106 = "USER_PICKER_NAME_SHORT_HELP_TEXT";

   @RBEntry("Escriba el nombre de la organización que quiere buscar. Separe las entradas con un punto y coma (;). Puede utilizar el carácter comodín (*). Por ejemplo: Organización XYZ; Organización *; Organización AB*")
   @RBComment("Org Picker Help Text")
   public static final String PRIVATE_CONSTANT_107 = "ORG_PICKER_HELP_TEXT";

   @RBEntry("Escriba el nombre del grupo que quiere buscar. Separe las entradas con un punto y coma (;). Puede utilizar el carácter comodín (*). Por ejemplo: Grupo rojo; * rojo; Grupo * ")
   @RBComment("Group Picker Help Text")
   public static final String PRIVATE_CONSTANT_108 = "GROUP_PICKER_HELP_TEXT";

   @RBEntry("Nombre del objeto")
   @RBComment("Object Name lable comment")
   public static final String PRIVATE_CONSTANT_109 = "ITEM_NAME_LABEL";

   @RBEntry("Versión del objeto")
   @RBComment("Object Version comment")
   public static final String PRIVATE_CONSTANT_110 = "ITEM_VERSION_LABEL";

   @RBEntry("Número del objeto")
   @RBComment("Object Number label")
   public static final String PRIVATE_CONSTANT_111 = "ITEM_NUMBER_LABEL";

   @RBEntry("Iteración del objeto")
   @RBComment("Object Iteration label")
   public static final String PRIVATE_CONSTANT_112 = "ITEM_ITERATION_LABEL";

   @RBEntry("Nombre del fichero CAD del objeto")
   @RBComment("Object CAD File Name label")
   public static final String PRIVATE_CONSTANT_113 = "ITEM_CAD_FILE_NAME_LABEL";

   @RBEntry("Estado del objeto")
   @RBComment("Object State label")
   public static final String PRIVATE_CONSTANT_114 = "ITEM_STATE_LABEL";

   @RBEntry("Contexto del objeto")
   @RBComment("Object Context Path label")
   public static final String PRIVATE_CONSTANT_115 = "ITEM_CONTEXT_PATH_LABEL";

   @RBEntry("Vista del objeto")
   @RBComment("Object View label")
   public static final String PRIVATE_CONSTANT_116 = "ITEM_VIEW_LABEL";

   @RBEntry("Creador del objeto")
   @RBComment("Object Creator label")
   public static final String PRIVATE_CONSTANT_117 = "ITEM_CREATOR_LABEL";

   @RBEntry("Todos los tipos de contexto")
   @RBComment("Text to be displayed in case of context picker for all object types")
   public static final String PRIVATE_CONSTANT_118 = "ALL_CONTEXT_ITEMS";

   /**
    * Picker Titles
    **/
   @RBEntry("Buscar usuario")
   @RBComment("User Picker Title")
   public static final String PRIVATE_CONSTANT_119 = "USER_PICKER_TITLE";

   @RBEntry("Buscar organización")
   @RBComment("Organization Picker Title")
   public static final String PRIVATE_CONSTANT_120 = "ORG_PICKER_TITLE";

   /**
    * Query Builder table column headings
    **/
   @RBEntry("Criterios de búsqueda")
   @RBComment("Search Criteria")
   public static final String QB_TABLE_HEADING_LABEL = "QB_TABLE_HEADING_LABEL";

   @RBEntry("Nombre")
   @RBComment("Name")
   public static final String QB_NAME_LABEL = "QB_NAME_LABEL";

   @RBEntry("Operador")
   @RBComment("Operator")
   public static final String PRIVATE_CONSTANT_121 = "QB_OPERATOR_LABEL";

   @RBEntry("Valor")
   @RBComment("Value")
   public static final String PRIVATE_CONSTANT_122 = "QB_VALUE_LABEL";

   @RBEntry("Resultados de la búsqueda")
   @RBComment("Search Results")
   public static final String PRIVATE_CONSTANT_123 = "SEARCH_RESULTS_TABLE";

   @RBEntry("La sesión ha vencido. Repita la acción")
   @RBComment("Session Expired")
   public static final String SESSION_EXPIRED_MSG = "SESSION_EXPIRED_MSG";

   @RBEntry("Esta página ha caducado y puede que los resultados de la búsqueda no sean correctos. Vuelva a realizar la búsqueda.")
   @RBComment("Back Button Clicked before Search")
   public static final String PRIVATE_CONSTANT_124 = "CHECK_BACKBUTTON_CLICKED";

   @RBEntry("Añadir")
   @RBComment("Add text for attribute menu drop down")
   public static final String PRIVATE_CONSTANT_125 = "ADD_CRITERIA";

   @RBEntry("Despejar")
   @RBComment("Clear criteria link")
   public static final String PRIVATE_CONSTANT_126 = "CLEAR_CRITERIA";

   @RBEntry("Exportar lista a fichero")
   public static final String PRIVATE_CONSTANT_127 = "search.exportSearchResults.description";

   @RBEntry("Exportar lista a fichero")
   public static final String PRIVATE_CONSTANT_128 = "search.exportSearchResults.tooltip";

   @RBEntry("../../com/ptc/core/ui/images/export.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_129 = "search.exportSearchResults.icon";

   @RBEntry("height=300,width=600")
   @RBPseudo(false)
   @RBComment("DO NOT TRANSLATE")
   public static final String PRIVATE_CONSTANT_130 = "search.exportSearchResults.moreurlinfo";

   @RBEntry("Guardar esta búsqueda")
   public static final String PRIVATE_CONSTANT_131 = "search.saveThisSearch.description";

   @RBEntry("Guardar esta búsqueda")
   public static final String PRIVATE_CONSTANT_132 = "search.saveThisSearch.tooltip";

   @RBEntry("Seleccionar")
   public static final String PRIVATE_CONSTANT_133 = "search.selectSearch.description";

   @RBEntry("Buscar")
   public static final String PRIVATE_CONSTANT_134 = "search.search.description";

   @RBEntry("Quitar")
   public static final String PRIVATE_CONSTANT_135 = "search.remove.description";

   @RBEntry("Quitar")
   public static final String PRIVATE_CONSTANT_136 = "search.remove.tooltip";

   @RBEntry("../../wtcore/images/com/ptc/core/ca/web/misc/delete.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_137 = "search.remove.icon";

   @RBEntry("Buscar en la red")
   public static final String PRIVATE_CONSTANT_138 = "search.networkSearch.description";

   @RBEntry("Buscar en la red")
   public static final String PRIVATE_CONSTANT_139 = "search.networkSearch.tooltip";

   @RBEntry("netmarkets/images/search_tbar16.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_140 = "search.networkSearch.icon";

   @RBEntry("Buscar en nodo")
   public static final String PRIVATE_CONSTANT_141 = "search.searchInNode.description";

   @RBEntry("Buscar en nodo")
   public static final String PRIVATE_CONSTANT_142 = "search.searchInNode.tooltip";

   @RBEntry("../../netmarkets/images/search.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_143 = "search.searchInNode.icon";

   @RBEntry("Buscar objetos relacionados")
   public static final String PRIVATE_CONSTANT_144 = "search.relatedItemSearch.description";

   @RBEntry("Buscar objetos relacionados")
   public static final String PRIVATE_CONSTANT_145 = "search.relatedItemSearch.tooltip";

   @RBEntry("netmarkets/images/related_objects_search.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_146 = "search.relatedItemSearch.icon";

   @RBEntry("Personalizar...")
   public static final String PRIVATE_CONSTANT_147 = "search.relationPicker.description";

   @RBEntry("Personalizar...")
   public static final String PRIVATE_CONSTANT_148 = "search.relationPicker.tooltip";

   @RBEntry("Elegir relaciones para búsqueda")
   public static final String PRIVATE_CONSTANT_149 = "search.relationPicker.title";

   @RBEntry("height=600,width=600")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_150 = "search.relationPicker.moreurlinfo";

   @RBEntry("Seleccionar las relaciones para la búsqueda")
   public static final String PRIVATE_CONSTANT_151 = "search.relationPickerStep.title";

   @RBEntry("Seleccionar las relaciones para la búsqueda")
   public static final String PRIVATE_CONSTANT_152 = "search.relationPickerStep.tooltip";

   @RBEntry("Seleccionar relaciones")
   public static final String PRIVATE_CONSTANT_153 = "search.relationPickerStep.description";

   @RBEntry("Borrar esta búsqueda")
   public static final String PRIVATE_CONSTANT_154 = "SavedQuery.deleteQuery.description";

   @RBEntry("Borrar esta búsqueda")
   public static final String PRIVATE_CONSTANT_155 = "SavedQuery.deleteQuery.tooltip";

   @RBEntry("netmarkets/images/delete.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_156 = "SavedQuery.deleteQuery.icon";

   @RBEntry("Mostrar")
   public static final String PRIVATE_CONSTANT_157 = "SavedQuery.showQuery.description";

   @RBEntry("Mostrar")
   public static final String PRIVATE_CONSTANT_158 = "SavedQuery.showQuery.tooltip";

   @RBEntry("../../wtcore/images/search_show.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_159 = "SavedQuery.showQuery.icon";

   @RBEntry("Ocultar")
   public static final String PRIVATE_CONSTANT_160 = "SavedQuery.hideQuery.description";

   @RBEntry("Ocultar")
   public static final String PRIVATE_CONSTANT_161 = "SavedQuery.hideQuery.tooltip";

   @RBEntry("../../wtcore/images/search_hide.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_162 = "SavedQuery.hideQuery.icon";

   @RBEntry("Borrar")
   public static final String PRIVATE_CONSTANT_163 = "SavedQuery.deleteRowQuery.description";

   @RBEntry("Borrar")
   public static final String PRIVATE_CONSTANT_164 = "SavedQuery.deleteRowQuery.tooltip";

   @RBEntry("../../wtcore/images/com/ptc/core/ca/web/misc/delete.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_165 = "SavedQuery.deleteRowQuery.icon";

   @RBEntry("Mostrar")
   public static final String PRIVATE_CONSTANT_166 = "SavedQuery.showRowQuery.description";

   @RBEntry("Mostrar")
   public static final String PRIVATE_CONSTANT_167 = "SavedQuery.showRowQuery.tooltip";

   @RBEntry("../../wtcore/images/search_show.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_168 = "SavedQuery.showRowQuery.icon";

   @RBEntry("Ocultar")
   public static final String PRIVATE_CONSTANT_169 = "SavedQuery.hideRowQuery.description";

   @RBEntry("Ocultar")
   public static final String PRIVATE_CONSTANT_170 = "SavedQuery.hideRowQuery.tooltip";

   @RBEntry("../../wtcore/images/search_hide.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_171 = "SavedQuery.hideRowQuery.icon";

   @RBEntry("Borrar para administradores")
   public static final String PRIVATE_CONSTANT_172 = "search.adminDelete.description";

   @RBEntry("Borrar para administradores")
   public static final String PRIVATE_CONSTANT_173 = "search.adminDelete.tooltip";

   @RBEntry("../../wtcore/images/search_deletesaved.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_174 = "search.adminDelete.icon";

   /**
    * Entries for simplesearch typepicker "Customize" link.
    * Copied from \wcEnterprise\EnterpriseUI\src\com\ptc\windchill\enterprise\picker\type\typePickerResource.rbInfo
    **/
   @RBEntry("Añadir/Actualizar")
   @RBComment("Used as the label for the find action for a SimpleSearch page Type Picker.")
   public static final String PRIVATE_CONSTANT_175 = "search.typePicker.description";

   @RBEntry("Buscar tipo")
   @RBComment("Used as the title for the find action pop-up wizard for a Type Picker.")
   public static final String PRIVATE_CONSTANT_176 = "search.typePicker.title";

   @RBEntry("height=600,width=500")
   @RBPseudo(false)
   @RBComment("DO NOT TRANSLATE")
   public static final String PRIVATE_CONSTANT_177 = "search.typePicker.moreurlinfo";

   /**
    * Entries for simplesearch newtypepicker "Customize" link.
    * Copied from \wcEnterprise\EnterpriseUI\src\com\ptc\windchill\enterprise\picker\type\typePickerResource.rbInfo
    **/
   @RBEntry("Añadir/Actualizar...")
   @RBComment("Used as the label for the find action for a SimpleSearch page Type Picker.")
   public static final String PRIVATE_CONSTANT_178 = "search.newtypePicker.description";

   @RBEntry("Buscar tipo")
   @RBComment("Used as the title for the find action pop-up wizard for a Type Picker.")
   public static final String PRIVATE_CONSTANT_179 = "search.newtypePicker.title";

   @RBEntry("height=600,width=375")
   @RBPseudo(false)
   @RBComment("DO NOT TRANSLATE")
   public static final String PRIVATE_CONSTANT_180 = "search.newtypePicker.moreurlinfo";

   @RBEntry("Lista completa de resultados")
   @RBComment("Full Result List option in the picker dropdown")
   public static final String FULL_RESULT_LIST = "FULL_RESULT_LIST";

   @RBEntry("Borrar para administradores")
   public static final String PRIVATE_CONSTANT_181 = "SavedQuery.finalDelete.description";

   @RBEntry("Borrar para administradores")
   public static final String PRIVATE_CONSTANT_182 = "SavedQuery.finalDelete.tooltip";

   @RBEntry("netmarkets/images/delete.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_183 = "SavedQuery.finalDelete.icon";

   @RBEntry("isAdminDelete=true")
   @RBPseudo(false)
   @RBComment("DO NOT TRANSLATE")
   public static final String PRIVATE_CONSTANT_184 = "SavedQuery.finalDelete.moreurlinfo";

   @RBEntry("Exportar")
   public static final String PRIVATE_CONSTANT_185 = "SavedQuery.savedQueryExport.description";

   @RBEntry("netmarkets/images/export.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_186 = "SavedQuery.savedQueryExport.icon";

   @RBEntry("Exportar consultas guardadas")
   public static final String PRIVATE_CONSTANT_187 = "SavedQuery.savedQueryExport.title";

   @RBEntry("Exportar búsquedas guardadas")
   public static final String PRIVATE_CONSTANT_188 = "SavedQuery.savedQueryExport.tooltip";

   @RBEntry("height=300,width=500")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_189 = "SavedQuery.savedQueryExport.moreurlinfo";

   @RBEntry("Importar")
   public static final String PRIVATE_CONSTANT_190 = "SavedQuery.savedQueryImport.description";

   @RBEntry("netmarkets/images/import.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_191 = "SavedQuery.savedQueryImport.icon";

   @RBEntry("Importar consultas guardadas")
   public static final String PRIVATE_CONSTANT_192 = "SavedQuery.savedQueryImport.title";

   @RBEntry("Importar búsquedas guardadas")
   public static final String PRIVATE_CONSTANT_193 = "SavedQuery.savedQueryImport.tooltip";

   @RBEntry("height=300,width=500")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_194 = "SavedQuery.savedQueryImport.moreurlinfo";

   @RBEntry("Importar")
   public static final String PRIVATE_CONSTANT_195 = "search.import.description";

   @RBEntry("Importar búsquedas guardadas")
   public static final String PRIVATE_CONSTANT_196 = "search.import.title";

   @RBEntry("Importar")
   public static final String PRIVATE_CONSTANT_197 = "search.import_step.description";

   @RBEntry("Importar búsquedas guardadas")
   public static final String PRIVATE_CONSTANT_198 = "search.import_step.title";

   @RBEntry("Ir")
   public static final String PRIVATE_CONSTANT_199 = "search.typeChange.description";

   @RBEntry("Despejar todo")
   public static final String PRIVATE_CONSTANT_200 = "search.clearSearch.description";

   @RBEntry("Buscar...")
   public static final String PRIVATE_CONSTANT_201 = "search.callSearchPicker.description";

   @RBEntry("Buscar...")
   public static final String PRIVATE_CONSTANT_202 = "search.callSearchPicker.tooltip";

   @RBEntry("height=768,width=550")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_203 = "search.callSearchPicker.moreurlinfo";

   @RBEntry("Añadir grupos")
   public static final String PRIVATE_CONSTANT_204 = "search.callSavedSearchGroupPicker.description";

   @RBEntry("Añadir grupos")
   public static final String PRIVATE_CONSTANT_205 = "search.callSavedSearchGroupPicker.title";

   @RBEntry("Añadir grupos")
   public static final String PRIVATE_CONSTANT_206 = "search.callSavedSearchGroupPicker.tooltip";

   @RBEntry("height=550,width=400")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_207 = "search.callSavedSearchGroupPicker.moreurlinfo";

   @RBEntry("netmarkets/images/add16x16.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_208 = "search.callSavedSearchGroupPicker.icon";

   @RBEntry("Quitar grupos")
   public static final String PRIVATE_CONSTANT_209 = "search.removeSavedSearchGroups.description";

   @RBEntry("Quitar grupos")
   public static final String PRIVATE_CONSTANT_210 = "search.removeSavedSearchGroups.title";

   @RBEntry("Quitar grupos")
   public static final String PRIVATE_CONSTANT_211 = "search.removeSavedSearchGroups.tooltip";

   @RBEntry("netmarkets/images/remove16x16.gif")
   @RBPseudo(false)
   public static final String PRIVATE_CONSTANT_212 = "search.removeSavedSearchGroups.icon";

   @RBEntry("Opciones avanzadas")
   public static final String PRIVATE_CONSTANT_213 = "search.saveThisSearchNew.description";

   @RBEntry("Opciones avanzadas")
   public static final String PRIVATE_CONSTANT_214 = "search.saveThisSearchNew.tooltip";

   @RBEntry("Opciones avanzadas")
   public static final String PRIVATE_CONSTANT_215 = "search.saveThisSearchNew.title";

   @RBEntry("Definir nombre de la búsqueda guardada")
   public static final String PRIVATE_CONSTANT_216 = "search.saveThisSearch_saveName.description";

   @RBEntry("Definir nombre de la búsqueda guardada")
   public static final String PRIVATE_CONSTANT_217 = "search.saveThisSearch_saveName.tooltip";

   @RBEntry("Definir detalles")
   public static final String PRIVATE_CONSTANT_218 = "search.saveThisSearch_saveName.title";

   @RBEntry("Definir atributos obligatorios ")
   public static final String PRIVATE_CONSTANT_219 = "search.saveThisSearch_saveRequired.description";

   @RBEntry("Definir atributos obligatorios ")
   public static final String PRIVATE_CONSTANT_220 = "search.saveThisSearch_saveRequired.tooltip";

   @RBEntry("Definir atributos obligatorios ")
   public static final String PRIVATE_CONSTANT_221 = "search.saveThisSearch_saveRequired.title";

   @RBEntry("Definir vista de tabla ")
   public static final String PRIVATE_CONSTANT_222 = "search.saveThisSearch_saveTableView.description";

   @RBEntry("Definir vista de tabla ")
   public static final String PRIVATE_CONSTANT_223 = "search.saveThisSearch_saveTableView.tooltip";

   @RBEntry("Definir vista de tabla ")
   public static final String PRIVATE_CONSTANT_224 = "search.saveThisSearch_saveTableView.title";

   @RBEntry("Definir acceso de grupo ")
   public static final String PRIVATE_CONSTANT_225 = "search.saveThisSearch_saveAccess.description";

   @RBEntry("Definir acceso de grupo ")
   public static final String PRIVATE_CONSTANT_226 = "search.saveThisSearch_saveAccess.tooltip";

   @RBEntry("Definir acceso de grupo ")
   public static final String PRIVATE_CONSTANT_227 = "search.saveThisSearch_saveAccess.title";

   /**
    * Saved Search related fields
    **/
   @RBEntry("Nombre")
   @RBComment("Search Name")
   public static final String PRIVATE_CONSTANT_228 = "SAVED_SEARCH_NAME";

   @RBEntry("Mostrar en la lista de búsquedas guardadas")
   @RBComment("Show in Saved Search list")
   public static final String PRIVATE_CONSTANT_229 = "SAVED_SEARCH_SHOW";

   @RBEntry("Escriba el nombre")
   @RBComment("Please enter Name")
   public static final String PRIVATE_CONSTANT_230 = "PLEASE_ENTER_NAME";

   @RBEntry("Crear vista de tabla")
   @RBComment("Create Table View")
   public static final String PRIVATE_CONSTANT_231 = "SAVED_SEARCH_CREATE_VIEW";

   @RBEntry("Vista en tabla")
   @RBComment("Use Existing Table View")
   public static final String PRIVATE_CONSTANT_232 = "SAVED_SEARCH_EXISTING_VIEW";

   @RBEntry("- Seleccionar una vista -")
   @RBComment("- Pick a View -")
   public static final String PRIVATE_CONSTANT_233 = "PICK_VIEW";

   @RBEntry("Atributos disponibles:")
   @RBComment("Available Attributes:")
   public static final String PRIVATE_CONSTANT_234 = "AVAILABLE_ATTRIBUTES";

   @RBEntry("Atributos obligatorios:")
   @RBComment("Required Attributes:")
   public static final String PRIVATE_CONSTANT_235 = "REQUIRED_ATTRIBUTES";

   @RBEntry("Añadir")
   @RBComment("Add")
   public static final String PRIVATE_CONSTANT_236 = "ADD_ATTRIBUTE";

   @RBEntry("Quitar")
   @RBComment("Remove")
   public static final String PRIVATE_CONSTANT_237 = "REMOVE_ATTRIBUTE";

   @RBEntry("Vista de documentos CAD por defecto")
   @RBComment("Default CAD Document View")
   public static final String PRIVATE_CONSTANT_238 = "CADDOC_TABLEVIEW_NAME";

   @RBEntry("Vista de tabla de búsqueda de documentos EPM por defecto")
   @RBComment("Default EPM Document Search Table View")
   public static final String PRIVATE_CONSTANT_239 = "CADDOC_TABLEVIEW_DESC";

   @RBEntry("Documento EPM")
   @RBComment("EPM Document")
   public static final String PRIVATE_CONSTANT_240 = "CADDOC_TABLEVIEW_LABEL";

   @RBEntry("Vista de artículos por defecto")
   @RBComment("Default Part View")
   public static final String PRIVATE_CONSTANT_241 = "WTPART_TABLEVIEW_NAME";

   @RBEntry("Vista de tabla de búsqueda de artículos por defecto")
   @RBComment("Default Part Search Table View")
   public static final String PRIVATE_CONSTANT_242 = "WTPART_TABLEVIEW_DESC";

   @RBEntry("Artículo ")
   @RBComment("Part ")
   public static final String PRIVATE_CONSTANT_243 = "WTPART_TABLEVIEW_LABEL";

   @RBEntry("Vista de documentos por defecto")
   @RBComment("Default Document View")
   public static final String PRIVATE_CONSTANT_244 = "WTDOCUMENT_TABLEVIEW_NAME";

   @RBEntry("Vista de la tabla de búsqueda de documentos por defecto")
   @RBComment("Default Document Search Table View")
   public static final String PRIVATE_CONSTANT_245 = "WTDOCUMENT_TABLEVIEW_DESC";

   @RBEntry("Documento")
   @RBComment("Document")
   public static final String PRIVATE_CONSTANT_246 = "WTDOCUMENT_TABLEVIEW_LABEL";

   @RBEntry("Vista del conjunto de trabajo por defecto")
   @RBComment("Default Work Set View")
   public static final String PRIVATE_CONSTANT_247 = "WTWORKSET_TABLEVIEW_NAME";

   @RBEntry("Vista de la tabla de búsqueda del conjunto de trabajo por defecto")
   @RBComment("Default Work Set Search Table View")
   public static final String PRIVATE_CONSTANT_248 = "WTWORKSET_TABLEVIEW_DESC";

   @RBEntry("Conjunto de trabajo")
   @RBComment("Work Set")
   public static final String PRIVATE_CONSTANT_249 = "WTWORKSET_TABLEVIEW_LABEL";

   @RBEntry("Vista de archivos por defectos")
   @RBComment("Default Archive View")
   public static final String PRIVATE_CONSTANT_250 = "ARCHIVE_TABLEVIEW_NAME";

   @RBEntry("Vista de la tabla de búsqueda de archivos por defecto")
   @RBComment("Default Archive Search Table View")
   public static final String PRIVATE_CONSTANT_251 = "ARCHIVE_TABLEVIEW_DESC";

   @RBEntry("Archivo")
   @RBComment("Archive")
   public static final String PRIVATE_CONSTANT_252 = "ARCHIVE_TABLEVIEW_LABEL";

   @RBEntry("Vista de notificaciones de cambio por defecto")
   @RBComment("Default Change Notice View")
   public static final String PRIVATE_CONSTANT_253 = "CHANGENOTICE_TABLEVIEW_NAME";

   @RBEntry("Vista de la tabla de búsqueda de notificaciones de cambio por defecto")
   @RBComment("Default Change Notice Search Table View")
   public static final String PRIVATE_CONSTANT_254 = "CHANGENOTICE_TABLEVIEW_DESC";

   @RBEntry("Notificación de cambio")
   @RBComment("Change Notice")
   public static final String PRIVATE_CONSTANT_255 = "CHANGENOTICE_TABLEVIEW_LABEL";

   @RBEntry("Vista de solicitudes de cambio por defecto")
   @RBComment("Default Change Request View")
   public static final String PRIVATE_CONSTANT_256 = "CHANGEREQUEST_TABLEVIEW_NAME";

   @RBEntry("Vista de la tabla de búsqueda de solicitudes de cambio por defecto")
   @RBComment("Default Change Request Search Table View")
   public static final String PRIVATE_CONSTANT_257 = "CHANGEREQUEST_TABLEVIEW_DESC";

   @RBEntry("Solicitud de cambio")
   @RBComment("Change Request")
   public static final String PRIVATE_CONSTANT_258 = "CHANGEREQUEST_TABLEVIEW_LABEL";

   @RBEntry("Vista de directiva de cambio por defecto")
   @RBComment("Default Change Directive View")
   public static final String PRIVATE_CONSTANT_259 = "CHANGEDIRECTIVE_TABLEVIEW_NAME";

   @RBEntry("Vista de la tabla de búsqueda de directivas de cambio por defecto")
   @RBComment("Default Change Directive Search Table View")
   public static final String PRIVATE_CONSTANT_260 = "CHANGEDIRECTIVE_TABLEVIEW_DESC";

   @RBEntry("Directiva de cambio")
   @RBComment("Change Directive")
   public static final String PRIVATE_CONSTANT_261 = "CHANGEDIRECTIVE_TABLEVIEW_LABEL";

   @RBEntry("Vista de informes de problemas por defecto")
   @RBComment("Default Problem Report View")
   public static final String PRIVATE_CONSTANT_262 = "WTCHANGEISSUE_TABLEVIEW_NAME";

   @RBEntry("Vista de tabla de búsqueda de informes de problemas por defecto")
   @RBComment("Default Problem Report Search Table View")
   public static final String PRIVATE_CONSTANT_263 = "WTCHANGEISSUE_TABLEVIEW_DESC";

   @RBEntry("Informe de problemas")
   @RBComment("Problem Report")
   public static final String PRIVATE_CONSTANT_264 = "WTCHANGEISSUE_TABLEVIEW_LABEL";

   @RBEntry("Vista de entregas por defecto")
   @RBComment("Default Deliverable View")
   public static final String PRIVATE_CONSTANT_265 = "DELIVERABLE_TABLEVIEW_NAME";

   @RBEntry("Vista de la tabla de búsquedas de entregas por defecto")
   @RBComment("Default Deliverable Search Table View")
   public static final String PRIVATE_CONSTANT_266 = "DELIVERABLE_TABLEVIEW_DESC";

   @RBEntry("Entrega")
   @RBComment("Deliverable")
   public static final String PRIVATE_CONSTANT_267 = "DELIVERABLE_TABLEVIEW_LABEL";

   @RBEntry("Lista de fabricantes por defecto")
   @RBComment("Default Manufacturer View")
   public static final String PRIVATE_CONSTANT_268 = "MANUFACTURER_TABLEVIEW_NAME";

   @RBEntry("Vista de la tabla de búsqueda de fabricantes por defecto")
   @RBComment("Default Manufacturer Search Table View")
   public static final String PRIVATE_CONSTANT_269 = "MANUFACTURER_TABLEVIEW_DESC";

   @RBEntry("Fabricante")
   @RBComment("Manufacturer")
   public static final String PRIVATE_CONSTANT_270 = "MANUFACTURER_TABLEVIEW_LABEL";

   @RBEntry("Vista de organizaciones por defecto")
   @RBComment("Default Organization View")
   public static final String PRIVATE_CONSTANT_271 = "ORGNIZATION_TABLEVIEW_NAME";

   @RBEntry("Vista de la tabla de búsqueda de organizaciones por defecto")
   @RBComment("Default Organization Search Table View")
   public static final String PRIVATE_CONSTANT_272 = "ORGNIZATION_TABLEVIEW_DESC";

   @RBEntry("Organización")
   @RBComment("Organization")
   public static final String PRIVATE_CONSTANT_273 = "ORGNIZATION_TABLEVIEW_LABEL";

   @RBEntry("Vista de proyectos por defecto")
   @RBComment("Default Project View")
   public static final String PRIVATE_CONSTANT_274 = "PROJECT2_TABLEVIEW_NAME";

   @RBEntry("Vista de tabla de búsqueda de proyectos por defecto")
   @RBComment("Default Project Search Table View")
   public static final String PRIVATE_CONSTANT_275 = "PROJECT2_TABLEVIEW_DESC";

   @RBEntry("Proyecto")
   @RBComment("Project")
   public static final String PRIVATE_CONSTANT_276 = "PROJECT2_TABLEVIEW_LABEL";

   @RBEntry("Vista de configuraciones de artículo por defecto")
   @RBComment("Default Part Configuration View")
   public static final String PRIVATE_CONSTANT_277 = "PARTCONFIGURATION_TABLEVIEW_NAME";

   @RBEntry("Vista de tabla de búsqueda de configuraciones de artículo por defecto")
   @RBComment("Default Part Configuration Search Table View")
   public static final String PRIVATE_CONSTANT_278 = "PARTCONFIGURATION_TABLEVIEW_DESC";

   @RBEntry("Configuración de artículo")
   @RBComment("Part Configuration")
   public static final String PRIVATE_CONSTANT_279 = "PARTCONFIGURATION_TABLEVIEW_LABEL";

   @RBEntry("Vista de intancias de artículo por defecto")
   @RBComment("Default Part Instance View")
   public static final String PRIVATE_CONSTANT_280 = "PARTINSTANCE_TABLEVIEW_NAME";

   @RBEntry("Vista de tabla de búsqueda de instancias de artículo por defecto")
   @RBComment("Default Part Instance Search Table View")
   public static final String PRIVATE_CONSTANT_281 = "PARTINSTANCE_TABLEVIEW_DESC";

   @RBEntry("Instancia de artículo")
   @RBComment("Part Instance")
   public static final String PRIVATE_CONSTANT_282 = "PARTINSTANCE_TABLEVIEW_LABEL";

   @RBEntry("Vista de distribuidores por defecto")
   @RBComment("Default Vendor View")
   public static final String PRIVATE_CONSTANT_283 = "VENDOR_TABLEVIEW_NAME";

   @RBEntry("Vista de la tabla de búsqueda de distribuidores por defecto")
   @RBComment("Default Vendor Search Table View")
   public static final String PRIVATE_CONSTANT_284 = "VENDOR_TABLEVIEW_DESC";

   @RBEntry("Distribuidor")
   @RBComment("Vendor")
   public static final String PRIVATE_CONSTANT_285 = "VENDOR_TABLEVIEW_LABEL";

   @RBEntry("Vista de recopilaciones gestionadas por defecto")
   @RBComment("Default Managed Collection View")
   public static final String PRIVATE_CONSTANT_286 = "MANAGEDCOLLECTION_TABLEVIEW_NAME";

   @RBEntry("Vista en tabla de búsquedas de recopilaciones gestionadas por defecto")
   @RBComment("Default Managed Collection Search Table View")
   public static final String PRIVATE_CONSTANT_287 = "MANAGEDCOLLECTION_TABLEVIEW_DESC";

   @RBEntry("Recopilación gestionada")
   @RBComment("Managed Collection")
   public static final String PRIVATE_CONSTANT_288 = "MANAGEDCOLLECTION_TABLEVIEW_LABEL";

   @RBEntry("Modificado por")
   @RBComment("Modified By")
   public static final String MC_MODIFIED_BY = "MC_MODIFIED_BY";

   @RBEntry("Vista de paquetes por defecto")
   @RBComment("Default Package View")
   public static final String PRIVATE_CONSTANT_289 = "WORKPACKAGE_TABLEVIEW_NAME";

   @RBEntry("Vista de la tabla de búsqueda de paquetes por defecto")
   @RBComment("Default Package Search Table View")
   public static final String PRIVATE_CONSTANT_290 = "WORKPACKAGE_TABLEVIEW_DESC";

   @RBEntry("Paquete")
   @RBComment("Package")
   public static final String PRIVATE_CONSTANT_291 = "WORKPACKAGE_TABLEVIEW_LABEL";

   /** The Constant LOCKED_ATTR_TABLE_LABEL. */
   @RBEntry("Estatus de bloqueo")
   public static final String LOCKED_ATTR_TABLE_LABEL = "LOCKED_ATTR_TABLE_LABEL";

   @RBEntry("Vista de solicitudes de artículo por defecto")
   @RBComment("Default Part Request View")
   public static final String PRIVATE_CONSTANT_292 = "WTPARTREQUEST_TABLEVIEW_NAME";

   @RBEntry("Vista de la tabla de búsqueda de solicitudes de artículo por defecto")
   @RBComment("Default Part Request Search Table View")
   public static final String PRIVATE_CONSTANT_293 = "WTPARTREQUEST_TABLEVIEW_DESC";

   @RBEntry("Solicitud de artículo")
   @RBComment("Part Request")
   public static final String PRIVATE_CONSTANT_294 = "WTPARTREQUEST_TABLEVIEW_LABEL";

   @RBEntry("Vista de variaciones por defecto")
   @RBComment("Default Variance View")
   public static final String PRIVATE_CONSTANT_295 = "WTVARIANCE_TABLEVIEW_NAME";

   @RBEntry("Vista de la tabla de búsqueda de variaciones por defecto")
   @RBComment("Default Variance Search Table View")
   public static final String PRIVATE_CONSTANT_296 = "WTVARIANCE_TABLEVIEW_DESC";

   @RBEntry("Variación")
   @RBComment("Variance")
   public static final String PRIVATE_CONSTANT_297 = "WTVARIANCE_TABLEVIEW_LABEL";

   @RBEntry("Vista de especificaciones de variante por defecto")
   @RBComment("Default Variant Spec View")
   public static final String PRIVATE_CONSTANT_298 = "VARIANTSPEC_TABLEVIEW_NAME";

   @RBEntry("Vista de la tabla de búsqueda de especificaciones de variante por defecto")
   @RBComment("Default Variant Spec Search Table View")
   public static final String PRIVATE_CONSTANT_299 = "VARIANTSPEC_TABLEVIEW_DESC";

   @RBEntry("Especificación de variante")
   @RBComment("Variant Spec")
   public static final String PRIVATE_CONSTANT_300 = "VARIANTSPEC_TABLEVIEW_LABEL";

   @RBEntry("Vista de usuarios por defecto")
   @RBComment("Default User View")
   public static final String PRIVATE_CONSTANT_301 = "WTUSER_TABLEVIEW_NAME";

   @RBEntry("Vista de tabla de búsqueda de usuarios por defecto")
   @RBComment("Default User Search Table View")
   public static final String PRIVATE_CONSTANT_302 = "WTUSER_TABLEVIEW_DESC";

   @RBEntry("Usuario")
   @RBComment("User")
   public static final String PRIVATE_CONSTANT_303 = "WTUSER_TABLEVIEW_LABEL";

   @RBEntry("Vista de elementos de acción por defecto")
   @RBComment("Default Action Item View")
   public static final String PRIVATE_CONSTANT_304 = "DISCRETEACTIONITEM_TABLEVIEW_NAME";

   @RBEntry("Vista de tabla de elementos de acción por defecto")
   @RBComment("Default Action Item Search Table View")
   public static final String PRIVATE_CONSTANT_305 = "DISCRETEACTIONITEM_TABLEVIEW_DESC";

   @RBEntry("Elemento de acción")
   @RBComment("Action Item")
   public static final String PRIVATE_CONSTANT_306 = "DISCRETEACTIONITEM_TABLEVIEW_LABEL";

   @RBEntry("Vista de documentos EPM maestros por defecto")
   @RBComment("Default EPM Document Master View")
   public static final String PRIVATE_CONSTANT_307 = "EPMDOCUMENTMASTER_TABLEVIEW_NAME";

   @RBEntry("Vista de la tabla de búsqueda de documentos EPM maestros por defecto")
   @RBComment("Default EPM Document Master Search Table View")
   public static final String PRIVATE_CONSTANT_308 = "EPMDOCUMENTMASTER_TABLEVIEW_DESC";

   @RBEntry("Documento EPM maestro")
   @RBComment("EPM Document Master")
   public static final String PRIVATE_CONSTANT_309 = "EPMDOCUMENTMASTER_TABLEVIEW_LABEL";

   @RBEntry("Vista de documentos maestros por defecto")
   @RBComment("Default Document Master View")
   public static final String PRIVATE_CONSTANT_310 = "WTDOCUMENTMASTER_TABLEVIEW_NAME";

   @RBEntry("Vista de la tabla de búsqueda de documentos maestros por defecto")
   @RBComment("Default Document Master Search Table View")
   public static final String PRIVATE_CONSTANT_311 = "WTDOCUMENTMASTER_TABLEVIEW_DESC";

   @RBEntry("Documento maestro")
   @RBComment("Document Master")
   public static final String PRIVATE_CONSTANT_312 = "WTDOCUMENTMASTER_TABLEVIEW_LABEL";

   @RBEntry("Vista de artículos maestros por defecto")
   @RBComment("Default Part Master View")
   public static final String PRIVATE_CONSTANT_313 = "WTPARTMASTER_TABLEVIEW_NAME";

   @RBEntry("Vista de la tabla de búsqueda de artículos maestros por defecto")
   @RBComment("Default Part Master Search Table View")
   public static final String PRIVATE_CONSTANT_314 = "WTPARTMASTER_TABLEVIEW_DESC";

   @RBEntry("Artículo maestro")
   @RBComment("Part Master")
   public static final String PRIVATE_CONSTANT_315 = "WTPARTMASTER_TABLEVIEW_LABEL";

   @RBEntry("Vista de formatos por defecto")
   @RBComment("Default Format View")
   public static final String PRIVATE_CONSTANT_316 = "FORMAT_TABLEVIEW_NAME";

   @RBEntry("Vista de tabla de búsqueda de formatos por defecto")
   @RBComment("Default Format Search Table View")
   public static final String PRIVATE_CONSTANT_317 = "FORMAT_TABLEVIEW_DESC";

   @RBEntry("Formato")
   @RBComment("Format")
   public static final String PRIVATE_CONSTANT_318 = "FORMAT_TABLEVIEW_LABEL";

   @RBEntry("Vista de grupos por defecto")
   @RBComment("Default Group View")
   public static final String PRIVATE_CONSTANT_319 = "GROUP_TABLEVIEW_NAME";

   @RBEntry("Vista de la tabla de búsqueda de grupos por defecto")
   @RBComment("Default Group Search Table View")
   public static final String PRIVATE_CONSTANT_320 = "GROUP_TABLEVIEW_DESC";

   @RBEntry("Grupo")
   @RBComment("Group")
   public static final String PRIVATE_CONSTANT_321 = "GROUP_TABLEVIEW_LABEL";

   @RBEntry("Vista de organizaciones por defecto")
   @RBComment("Default Organization View")
   public static final String PRIVATE_CONSTANT_322 = "ORG_TABLEVIEW_NAME";

   @RBEntry("Vista de la tabla de búsqueda de organizaciones por defecto")
   @RBComment("Default Organization Search Table View")
   public static final String PRIVATE_CONSTANT_323 = "ORG_TABLEVIEW_DESC";

   @RBEntry("Organización")
   @RBComment("Organization")
   public static final String PRIVATE_CONSTANT_324 = "ORG_TABLEVIEW_LABEL";

   @RBEntry("Vista de adjuntos de referencia por defecto")
   @RBComment("Default Reference Attachment View")
   public static final String PRIVATE_CONSTANT_325 = "IMPORTEDBOOKMARK_TABLEVIEW_NAME";

   @RBEntry("Vista de la tabla de búsqueda de adjuntos de referencia por defecto")
   @RBComment("Default Reference Attachment Search Table View")
   public static final String PRIVATE_CONSTANT_326 = "IMPORTEDBOOKMARK_TABLEVIEW_DESC";

   @RBEntry("Adjunto de referencia")
   @RBComment("Reference Attachment")
   public static final String PRIVATE_CONSTANT_327 = "IMPORTEDBOOKMARK_TABLEVIEW_LABEL";

   @RBEntry("Vista de subproyecto/subprograma por defecto")
   @RBComment("Default Sub Project/Program View")
   public static final String PRIVATE_CONSTANT_328 = "PROJECTPROXY_TABLEVIEW_NAME";

   @RBEntry("Vista de tabla de búsqueda de subproyectos/subprogramas por defecto")
   @RBComment("Default Sub Project/Program Search Table View")
   public static final String PRIVATE_CONSTANT_329 = "PROJECTPROXY_TABLEVIEW_DESC";

   @RBEntry("Subproyecto/Subprograma")
   @RBComment("Sub Project/Program")
   public static final String PRIVATE_CONSTANT_330 = "PROJECTPROXY_TABLEVIEW_LABEL";

   @RBEntry("Vista de archivadores por defecto")
   @RBComment("Default Cabinet View")
   public static final String PRIVATE_CONSTANT_331 = "CABINET_TABLEVIEW_NAME";

   @RBEntry("Vista de tabla de búsqueda de archivadores por defecto")
   @RBComment("Default Cabinet Search Table View")
   public static final String PRIVATE_CONSTANT_332 = "CABINET_TABLEVIEW_DESC";

   @RBEntry("Archivador")
   @RBComment("Cabinet")
   public static final String PRIVATE_CONSTANT_333 = "CABINET_TABLEVIEW_LABEL";

   @RBEntry("Vista de instantáneas gestionadas por defecto")
   @RBComment("Default Managed Baseline View")
   public static final String PRIVATE_CONSTANT_334 = "MANAGEDBASELINE_TABLEVIEW_NAME";

   @RBEntry("Vista de tabla de búsqueda de instantáneas gestionadas por defecto")
   @RBComment("Default Managed Baseline Search Table View")
   public static final String PRIVATE_CONSTANT_335 = "MANAGEDBASELINE_TABLEVIEW_DESC";

   @RBEntry("Instantánea gestionada")
   @RBComment("Managed Baseline")
   public static final String PRIVATE_CONSTANT_336 = "MANAGEDBASELINE_TABLEVIEW_LABEL";

   @RBEntry("Vista de plan de proceso por defecto")
   @RBComment("Default Process Plan View")
   public static final String PRIVATE_CONSTANT_337 = "MPMPROCESSPLAN_TABLEVIEW_NAME";

   @RBEntry("Vista de tabla de búsqueda de planes de proceso por defecto")
   @RBComment("Default Process Plan Search Table View")
   public static final String PRIVATE_CONSTANT_338 = "MPMPROCESSPLAN_TABLEVIEW_DESC";

   @RBEntry("Plan de proceso")
   @RBComment("Process Plan")
   public static final String PRIVATE_CONSTANT_339 = "MPMPROCESSPLAN_TABLEVIEW_LABEL";

   @RBEntry("Vista de secuencias por defecto")
   @RBComment("Default Sequence View")
   public static final String PRIVATE_CONSTANT_340 = "MPMSEQUENCE_TABLEVIEW_NAME";

   @RBEntry("Vista de la tabla de búsqueda de secuencias por defecto")
   @RBComment("Default Sequence Search Table View")
   public static final String PRIVATE_CONSTANT_341 = "MPMSEQUENCE_TABLEVIEW_DESC";

   @RBEntry("Secuencia")
   @RBComment("Sequence")
   public static final String PRIVATE_CONSTANT_342 = "MPMSEQUENCE_TABLEVIEW_LABEL";

   @RBEntry("Vista de operaciones por defecto")
   @RBComment("Default Operation View")
   public static final String PRIVATE_CONSTANT_343 = "MPMOPERATION_TABLEVIEW_NAME";

   @RBEntry("Vista de la tabla de búsqueda de operaciones por defecto")
   @RBComment("Default Operation Search Table View")
   public static final String PRIVATE_CONSTANT_344 = "MPMOPERATION_TABLEVIEW_DESC";

   @RBEntry("Operación")
   @RBComment("Operation")
   public static final String PRIVATE_CONSTANT_345 = "MPMOPERATION_TABLEVIEW_LABEL";

   @RBEntry("Vista de grupos de normas de fabricación por defecto")
   @RBComment("Default Manufacturing Standard Group View")
   public static final String PRIVATE_CONSTANT_346 = "MPMMFGSTANDARDGROUP_TABLEVIEW_NAME";

   @RBEntry("Vista de la tabla de búsqueda de grupos de normas de fabricación por defecto")
   @RBComment("Default Manufacturing Standard Group Search Table View")
   public static final String PRIVATE_CONSTANT_347 = "MPMMFGSTANDARDGROUP_TABLEVIEW_DESC";

   @RBEntry("Grupo de normas de fabricación")
   @RBComment("Manufacturing Standard Group")
   public static final String PRIVATE_CONSTANT_348 = "MPMMFGSTANDARDGROUP_TABLEVIEW_LABEL";

   @RBEntry("Vista de procesos de fabricación por defecto")
   @RBComment("Default Manufacturing Process View")
   public static final String PRIVATE_CONSTANT_349 = "MPMMFGPROCESS_TABLEVIEW_NAME";

   @RBEntry("Vista de la tabla de búsqueda de procesos de fabricación por defecto")
   @RBComment("Default Manufacturing Process Search Table View")
   public static final String PRIVATE_CONSTANT_350 = "MPMMFGPROCESS_TABLEVIEW_DESC";

   @RBEntry("Proceso de fabricación")
   @RBComment("Manufacturing Process")
   public static final String PRIVATE_CONSTANT_351 = "MPMMFGPROCESS_TABLEVIEW_LABEL";

   @RBEntry("Vista de recursos por defecto")
   @RBComment("Default Resource View")
   public static final String PRIVATE_CONSTANT_352 = "MPMRESOURCE_TABLEVIEW_NAME";

   @RBEntry("Vista de la tabla de búsqueda de recursos por defecto")
   @RBComment("Default Resource Search Table View")
   public static final String PRIVATE_CONSTANT_353 = "MPMRESOURCE_TABLEVIEW_DESC";

   @RBEntry("Recurso")
   @RBComment("Resource")
   public static final String PRIVATE_CONSTANT_354 = "MPMRESOURCE_TABLEVIEW_LABEL";

   @RBEntry("Vista de planta por defecto")
   @RBComment("Default Plant View")
   public static final String PRIVATE_CONSTANT_355 = "MPMPLANT_TABLEVIEW_NAME";

   @RBEntry("Vista de tabla de búsqueda de plantas por defecto")
   @RBComment("Default Plant Search Table View")
   public static final String PRIVATE_CONSTANT_356 = "MPMPLANT_TABLEVIEW_DESC";

   @RBEntry("Planta")
   @RBComment("Plant")
   public static final String PRIVATE_CONSTANT_357 = "MPMPLANT_TABLEVIEW_LABEL";

   @RBEntry("Vista de grupos de recursos por defecto")
   @RBComment("Default Resource Group View")
   public static final String PRIVATE_CONSTANT_358 = "MPMRESOURCEGROUP_TABLEVIEW_NAME";

   @RBEntry("Vista de la tabla de búsqueda de grupos de recursos por defecto")
   @RBComment("Default Resource Group Search Table View")
   public static final String PRIVATE_CONSTANT_359 = "MPMRESOURCEGROUP_TABLEVIEW_DESC";

   @RBEntry("Grupo de recursos")
   @RBComment("Resource Group")
   public static final String PRIVATE_CONSTANT_360 = "MPMRESOURCEGROUP_TABLEVIEW_LABEL";

   @RBEntry("Vista de unidades de trabajo por defecto")
   @RBComment("Default Work Item View")
   public static final String PRIVATE_CONSTANT_361 = "WORKITEM_TABLEVIEW_NAME";

   @RBEntry("Vista de la tabla de búsqueda de unidades de trabajo por defecto")
   @RBComment("Default Work Item Search Table View")
   public static final String PRIVATE_CONSTANT_362 = "WORKITEM_TABLEVIEW_DESC";

   @RBEntry("Unidad de trabajo")
   @RBComment("Work Item")
   public static final String PRIVATE_CONSTANT_363 = "WORKITEM_TABLEVIEW_LABEL";

   @RBEntry("Vista de informes por defecto")
   @RBComment("Default Report View")
   public static final String PRIVATE_CONSTANT_364 = "REPORT_TABLEVIEW_NAME";

   @RBEntry("Vista de tabla de búsqueda de informes por defecto")
   @RBComment("Default Report Search Table View")
   public static final String PRIVATE_CONSTANT_365 = "REPORT_TABLEVIEW_DESC";

   @RBEntry("Informe")
   @RBComment("Report")
   public static final String PRIVATE_CONSTANT_366 = "REPORT_TABLEVIEW_LABEL";

   @RBEntry("Vista de búsqueda guardada por defecto")
   @RBComment("Default Saved Search View")
   public static final String PRIVATE_CONSTANT_367 = "SAVEDQUERY_TABLEVIEW_NAME";

   @RBEntry("Vista de la tabla de búsquedas guardadas por defecto")
   @RBComment("Default Saved Search Table View")
   public static final String PRIVATE_CONSTANT_368 = "SAVEDQUERY_TABLEVIEW_DESC";

   @RBEntry("Vista del selector de búsquedas guardadas por defecto")
   @RBComment("Default Saved Search Picker View")
   public static final String PRIVATE_CONSTANT_369 = "SAVEDQUERY_PICKER_TABLEVIEW_NAME";

   @RBEntry("Vista de la tabla del selector de búsquedas guardadas por defecto")
   @RBComment("Default Saved Search Picker Table View")
   public static final String PRIVATE_CONSTANT_370 = "SAVEDQUERY_PICKER_TABLEVIEW_DESC";

   @RBEntry("Búsqueda guardada")
   @RBComment("Saved Search")
   public static final String PRIVATE_CONSTANT_371 = "SAVEDQUERY_TABLEVIEW_LABEL";

   @RBEntry("Por defecto")
   @RBComment("Default View")
   public static final String PRIVATE_CONSTANT_372 = "PERSISTABLE_TABLEVIEW_NAME";

   @RBEntry("Vista de tabla por defecto")
   @RBComment("Default Table View")
   public static final String PRIVATE_CONSTANT_373 = "PERSISTABLE_TABLEVIEW_DESC";

   @RBEntry("Búsqueda sencilla")
   @RBComment("Simple Search")
   public static final String PRIVATE_CONSTANT_374 = "PERSISTABLE_TABLEVIEW_LABEL";

   @RBEntry("Vista de mensajes de discusión por defecto")
   @RBComment("Default Discussion Posting View")
   public static final String PRIVATE_CONSTANT_375 = "DISCUSSIONPOSTING_TABLEVIEW_NAME";

   @RBEntry("Vista de la tabla de búsqueda de mensajes de discusión por defecto")
   @RBComment("Default Discussion Posting Search Table View")
   public static final String PRIVATE_CONSTANT_376 = "DISCUSSIONPOSTING_TABLEVIEW_DESC";

   @RBEntry("Mensaje de la discusión")
   @RBComment("Discussion Posting")
   public static final String PRIVATE_CONSTANT_377 = "DISCUSSIONPOSTING_TABLEVIEW_LABEL";

   @RBEntry("Vista de reuniones por defecto")
   @RBComment("Default Meeting View")
   public static final String PRIVATE_CONSTANT_378 = "MEETING_TABLEVIEW_NAME";

   @RBEntry("Vista de la tabla de búsqueda de reuniones por defecto")
   @RBComment("Default Meeting Search Table View")
   public static final String PRIVATE_CONSTANT_379 = "MEETING_TABLEVIEW_DESC";

   @RBEntry("Reunión")
   @RBComment("Meeting")
   public static final String PRIVATE_CONSTANT_380 = "MEETING_TABLEVIEW_LABEL";

   /**
    * L10N CHANGE BEGIN: comment out duplicate resource id
    * PDMLINKPRODUCT_TABLEVIEW_NAME.comment=Default Product View
    * PDMLINKPRODUCT_TABLEVIEW_NAME.value=Default Product View
    * L10N CHANGE END
    * L10N CHANGE BEGIN: comment out duplicate resource id
    * PDMLINKPRODUCT_TABLEVIEW_DESC.comment=Default Product Search Table View
    * PDMLINKPRODUCT_TABLEVIEW_DESC.value=Default Product Search Table View
    * L10N CHANGE END
    * L10N CHANGE BEGIN: comment out duplicate resource id
    * PDMLINKPRODUCT_TABLEVIEW_LABEL.comment=Product
    * PDMLINKPRODUCT_TABLEVIEW_LABEL.value=Product
    * L10N CHANGE END
    **/
   @RBEntry("Vista de plantillas de informe por defecto")
   @RBComment("Default Report Template View")
   public static final String PRIVATE_CONSTANT_381 = "REPORTTEMPLATE_TABLEVIEW_NAME";

   @RBEntry("Vista de tabla de búsqueda de plantillas de informe por defecto")
   @RBComment("Default Report Template Search Table View")
   public static final String PRIVATE_CONSTANT_382 = "REPORTTEMPLATE_TABLEVIEW_DESC";

   @RBEntry("Plantilla de informe")
   @RBComment("Report Template")
   public static final String PRIVATE_CONSTANT_383 = "REPORTTEMPLATE_TABLEVIEW_LABEL";

   @RBEntry("Vista de procesos de trabajo por defecto")
   @RBComment("Default Workflow Process View")
   public static final String PRIVATE_CONSTANT_384 = "WORKFLOWPROCESS_TABLEVIEW_NAME";

   @RBEntry("Vista de tabla de búsqueda de procesos de trabajo por defecto")
   @RBComment("Default Workflow Process Search Table View")
   public static final String PRIVATE_CONSTANT_385 = "WORKFLOWPROCESS_TABLEVIEW_DESC";

   @RBEntry("Proceso de trabajo")
   @RBComment("Workflow Process")
   public static final String PRIVATE_CONSTANT_386 = "WORKFLOWPROCESS_TABLEVIEW_LABEL";

   @RBEntry("Vista de bibliotecas por defecto")
   @RBComment("Default Library View")
   public static final String PRIVATE_CONSTANT_387 = "WTLIBRARY_TABLEVIEW_NAME";

   @RBEntry("Vista de la tabla de búsqueda de bibliotecas por defecto")
   @RBComment("Default Library Search Table View")
   public static final String PRIVATE_CONSTANT_388 = "WTLIBRARY_TABLEVIEW_DESC";

   @RBEntry("Biblioteca")
   @RBComment("Library")
   public static final String PRIVATE_CONSTANT_389 = "WTLIBRARY_TABLEVIEW_LABEL";

   @RBEntry("Vista de trabajos de importación por defecto")
   @RBComment("Default Import Job View")
   public static final String PRIVATE_CONSTANT_390 = "IMPORTJOB_TABLEVIEW_NAME";

   @RBEntry("Vista de la tabla de búsqueda de trabajos de importación por defecto")
   @RBComment("Default Import Job Search Table View")
   public static final String PRIVATE_CONSTANT_391 = "IMPORTJOB_TABLEVIEW_DESC";

   @RBEntry("Trabajo de importación")
   @RBComment("Import Job")
   public static final String PRIVATE_CONSTANT_392 = "IMPORTJOB_TABLEVIEW_LABEL";

   @RBEntry("Vista de hitos por defecto")
   @RBComment("Default Milestone View")
   public static final String PRIVATE_CONSTANT_393 = "MILESTONE_TABLEVIEW_NAME";

   @RBEntry("Vista de la tabla de búsqueda de hitos por defecto")
   @RBComment("Default Milestone Search Table View")
   public static final String PRIVATE_CONSTANT_394 = "MILESTONE_TABLEVIEW_DESC";

   @RBEntry("Hito")
   @RBComment("Milestone")
   public static final String PRIVATE_CONSTANT_395 = "MILESTONE_TABLEVIEW_LABEL";

   @RBEntry("Vista de recursos de proyecto por defecto")
   @RBComment("Default Project Resource View")
   public static final String PRIVATE_CONSTANT_396 = "PROJECTRESOURCE_TABLEVIEW_NAME";

   @RBEntry("Vista de la tabla de búsqueda de recursos de proyecto por defecto")
   @RBComment("Default Project Resource Search Table View")
   public static final String PRIVATE_CONSTANT_397 = "PROJECTRESOURCE_TABLEVIEW_DESC";

   @RBEntry("Recurso de proyecto")
   @RBComment("Project Resource")
   public static final String PRIVATE_CONSTANT_398 = "PROJECTRESOURCE_TABLEVIEW_LABEL";

   @RBEntry("Vista de actividades de proyecto por defecto")
   @RBComment("Default Project Activity View")
   public static final String PRIVATE_CONSTANT_399 = "PROJECTACTIVITY_TABLEVIEW_NAME";

   @RBEntry("Vista de tabla de búsqueda de actividades de proyecto por defecto")
   @RBComment("Default Project Activity Search Table View")
   public static final String PRIVATE_CONSTANT_400 = "PROJECTACTIVITY_TABLEVIEW_DESC";

   @RBEntry("Actividad de proyecto")
   @RBComment("Project Activity")
   public static final String PRIVATE_CONSTANT_401 = "PROJECTACTIVITY_TABLEVIEW_LABEL";

   @RBEntry("Vista de solicitudes de promoción por defecto")
   @RBComment("Default Promotion Request View")
   public static final String PRIVATE_CONSTANT_402 = "PROMOTIONNOTICE_TABLEVIEW_NAME";

   @RBEntry("Vista de la tabla de búsqueda de solicitudes de promoción por defecto")
   @RBComment("Default Promotion Request Search Table View")
   public static final String PRIVATE_CONSTANT_403 = "PROMOTIONNOTICE_TABLEVIEW_DESC";

   @RBEntry("Solicitud de promoción")
   @RBComment("Promotion Request")
   public static final String PRIVATE_CONSTANT_404 = "PROMOTIONNOTICE_TABLEVIEW_LABEL";

   @RBEntry("Vista de actividades de resumen por defecto")
   @RBComment("Default Summary Activity View")
   public static final String PRIVATE_CONSTANT_405 = "SUMMARYACTIVITY_TABLEVIEW_NAME";

   @RBEntry("Vista de tabla de búsqueda de actividades de resumen por defecto")
   @RBComment("Default Summary Activity Search Table View")
   public static final String PRIVATE_CONSTANT_406 = "SUMMARYACTIVITY_TABLEVIEW_DESC";

   @RBEntry("Actividad de resumen")
   @RBComment("Summary Activity")
   public static final String PRIVATE_CONSTANT_407 = "SUMMARYACTIVITY_TABLEVIEW_LABEL";

   @RBEntry("Vista de proveedores por defecto")
   @RBComment("Default Supplier View")
   public static final String PRIVATE_CONSTANT_408 = "SUPPLIER_TABLEVIEW_NAME";

   @RBEntry("Vista de tabla de búsqueda de proveedores por defecto")
   @RBComment("Default Supplier Search Table View")
   public static final String PRIVATE_CONSTANT_409 = "SUPPLIER_TABLEVIEW_DESC";

   @RBEntry("Proveedor")
   @RBComment("Supplier")
   public static final String PRIVATE_CONSTANT_410 = "SUPPLIER_TABLEVIEW_LABEL";

   @RBEntry("Vista de artículos de proveedor por defecto")
   @RBComment("Default Supplier Part View")
   public static final String PRIVATE_CONSTANT_411 = "SUPPLIERPART_TABLEVIEW_NAME";

   @RBEntry("Vista de tabla de búsqueda de artículos de proveedor por defecto")
   @RBComment("Default Supplier Part Search Table View")
   public static final String PRIVATE_CONSTANT_412 = "SUPPLIERPART_TABLEVIEW_DESC";

   @RBEntry("Artículo de proveedor")
   @RBComment("Supplier Part")
   public static final String PRIVATE_CONSTANT_413 = "SUPPLIERPART_TABLEVIEW_LABEL";

   @RBEntry("Vista de productos por defecto")
   @RBComment("Default Product View")
   public static final String PRIVATE_CONSTANT_414 = "PDMLINKPRODUCT_TABLEVIEW_NAME";

   @RBEntry("Vista de la tabla de búsqueda de productos por defecto")
   @RBComment("Default Product Search Table View")
   public static final String PRIVATE_CONSTANT_415 = "PDMLINKPRODUCT_TABLEVIEW_DESC";

   @RBEntry("Producto")
   @RBComment("Product")
   public static final String PRIVATE_CONSTANT_416 = "PDMLINKPRODUCT_TABLEVIEW_LABEL";

   @RBEntry("Vista de contextos por defecto")
   @RBComment("Default Context View")
   public static final String PRIVATE_CONSTANT_417 = "CONTAINER_TABLEVIEW_NAME";

   @RBEntry("Vista de la tabla de búsqueda de contextos por defecto")
   @RBComment("Default Context Search Table View")
   public static final String PRIVATE_CONSTANT_418 = "CONTAINER_TABLEVIEW_DESC";

   @RBEntry("Contexto")
   @RBComment("Context")
   public static final String PRIVATE_CONSTANT_419 = "CONTAINER_TABLEVIEW_LABEL";

   @RBEntry("Sí")
   @RBComment("Label for True")
   public static final String PRIVATE_CONSTANT_420 = "TRUE_LABEL";

   @RBEntry("No")
   @RBComment("Label for False")
   public static final String PRIVATE_CONSTANT_421 = "FALSE_LABEL";

   @RBEntry("Formato XML de consulta guardada no válido")
   @RBComment("Invalid Saved Query XML Format")
   public static final String PRIVATE_CONSTANT_422 = "INVALID_SAVED_QUERY_FORMAT";

   @RBEntry("-Seleccionar-")
   @RBComment("Label for No Selection")
   public static final String PRIVATE_CONSTANT_423 = "NO_SELECTION_LABEL";

   @RBEntry("Definir como búsqueda global")
   @RBComment("Mark as Global Search")
   public static final String PRIVATE_CONSTANT_424 = "GLOBAL_SEARCH_SHOW";

   @RBEntry("Sobrescribir la búsqueda guardada existente")
   @RBComment("Overwrite Existing Saved Search")
   public static final String PRIVATE_CONSTANT_425 = "OVERWRITE_EXISTING";

   @RBEntry("�?mbito de búsqueda global:")
   @RBComment("Set Scope of Global Search")
   public static final String PRIVATE_CONSTANT_426 = "SCOPE_OF_GLOBAL_SEARCH";

   @RBEntry("Buscar en la red")
   @RBComment("Label for search in network")
   public static final String PRIVATE_CONSTANT_427 = "SEARCH_IN_NETWORK_LABEL";

   @RBEntry("Buscar objetos relacionados")
   @RBComment("Label for search related to objects in a particular context")
   public static final String PRIVATE_CONSTANT_428 = "SEARCH_FOR_ITEMS_IN_CONTEXT_LABEL";

   @RBEntry("Contextos de red:")
   @RBComment("Label for the property \"Search In:\" on the search page when the request comes from Program tab.")
   public static final String PRIVATE_CONSTANT_429 = "SEARCH_IN_NETWORK_CONTEXT";

   @RBEntry("Buscar tipos:")
   @RBComment("Label for the type property on the search page when the request comes from Program tab.")
   public static final String PRIVATE_CONSTANT_430 = "SEARCH_FOR_TYPE";

   @RBEntry("Relaciones:")
   @RBComment("Label for the relationship property on the search page when the request comes from Program tab.")
   public static final String PRIVATE_CONSTANT_431 = "SEARCH_FOR_RELATIONSHIP";

   @RBEntry("Fichero:")
   @RBComment("Select jar or zip to import")
   public static final String PRIVATE_CONSTANT_432 = "SELECT_FILE_IMPORT";

   @RBEntry("(.jar, .zip)")
   @RBComment("File types allowed for Import Saved Query wizard")
   public static final String PRIVATE_CONSTANT_433 = "IMPORT_FILE_TYPES";

   @RBEntry("El fichero debe ser del tipo .jar o .zip")
   @RBComment("Error message displayed when user tries to import a file other than a jar or zip file.")
   public static final String PRIVATE_CONSTANT_434 = "EXPORT_IMPORT_FILE_ERROR";

   @RBEntry("Resolver conflictos desestimables")
   @RBComment("Label for the resolve overridable conflicts checkbox")
   public static final String PRIVATE_CONSTANT_435 = "RESOLVE_OVERRIDABLE_CONFLICTS";

   @RBEntry("Fichero:")
   @RBComment("File name into which the savedquery should be exported")
   public static final String PRIVATE_CONSTANT_436 = "SELECT_FILE_EXPORT";

   @RBEntry("(Introduzca el nombre y la ruta del fichero con la extensión .jar o .zip)")
   @RBComment("File types allowed for Export Saved Query wizard")
   public static final String PRIVATE_CONSTANT_437 = "EXPORT_FILE_TYPES";

   @RBEntry("Registro detallado")
   @RBComment("Label for detailed log link")
   public static final String PRIVATE_CONSTANT_438 = "EXPORT_IMPORT_DETAILED_LOG";

   @RBEntry("No se han podido borrar los siguientes elementos seleccionados: {0}")
   @RBComment("Message showing list of queries couldn't be deleted")
   public static final String PRIVATE_CONSTANT_439 = "DELETE_QUERY_MESSAGE";

   @RBEntry("Vista de búsqueda de carpetas por defecto")
   @RBComment("Default Folder Search View")
   public static final String PRIVATE_CONSTANT_440 = "FOLDER_TABLEVIEW_NAME";

   @RBEntry("Tabla de búsqueda de carpetas por defecto")
   @RBComment("Default Folder Search Table")
   public static final String PRIVATE_CONSTANT_441 = "FOLDER_TABLEVIEW_DESC";

   @RBEntry("Carpeta")
   @RBComment("Folder")
   public static final String PRIVATE_CONSTANT_442 = "FOLDER_TABLEVIEW_LABEL";

   @RBEntry("ATENCIÓN: Los campos obligatorios no pueden quitarse\n\nLos siguientes campos son obligatorios y no pueden quitarse: \n{0}")
   @RBComment("Message for alert when one tries to remove criteria which is marked required.")
   public static final String PRIVATE_CONSTANT_443 = "REMOVE_QUERYBUILDER_ROW";

   @RBEntry("ATENCIÓN: Falta información obligatoria \n \n{0} es un campo obligatorio. \nDebe especificar información válida en todos los campos obligatorios que tienen un asterisco (*).")
   @RBComment("Message for alert if the required attributes are not filled.")
   public static final String REQ_INFO_MISSING = "REQ_INFO_MISSING";

   @RBEntry("ATENCIÓN: Falta información obligatoria.\n \nRellene con datos válidos todos los campos que tienen un asterisco (*).")
   public static final String SAVED_SEARCH_NAME_MISSING = "SAVED_SEARCH_NAME_MISSING";

   @RBEntry("Nombre de fichero")
   @RBComment("CADName")
   public static final String PRIVATE_CONSTANT_444 = "CADNAME";

   @RBEntry("¿Quiso decir?: ")
   @RBComment("The query suggestion message.")
   public static final String QUERY_SUGGESTION_MESSAGE = "QUERY_SUGGESTION_MESSAGE";

   @RBEntry("Propietario")
   @RBComment("Owner")
   public static final String PRIVATE_CONSTANT_445 = "OWNER_LABEL";

   @RBEntry("Extraído por")
   @RBComment("Checked Out By")
   public static final String PRIVATE_CONSTANT_446 = "CHECKED_OUT_BY";

   @RBEntry("Actualizado por")
   @RBComment("Updated By")
   public static final String PRIVATE_CONSTANT_447 = "UPDATED_BY";

   @RBEntry("Texto de nota")
   @RBComment("Note Text")
   public static final String PRIVATE_CONSTANT_448 = "PTC_NOTE_TEXT";

   @RBEntry("Menor que")
   @RBComment("Less than")
   public static final String PRIVATE_CONSTANT_449 = "OP_LESS";

   @RBEntry("Menor que o igual a")
   @RBComment("Less than equal to")
   public static final String PRIVATE_CONSTANT_450 = "OP_LESS_THAN_EQUAL_TO";

   @RBEntry("Mayor que")
   @RBComment("Greater than")
   public static final String PRIVATE_CONSTANT_451 = "OP_GREATOR";

   @RBEntry("Mayor que o igual a")
   @RBComment("Greater than equal to")
   public static final String PRIVATE_CONSTANT_452 = "OP_GREATOR_THAN_EQUAL_TO";

   @RBEntry("Nombre del rol")
   @RBComment("Role Name")
   public static final String PRIVATE_CONSTANT_453 = "ROLE_NAME";

   @RBEntry("Rol ")
   @RBComment("Role")
   public static final String PRIVATE_CONSTANT_454 = "ROLE";

   @RBEntry("Refinar la búsqueda")
   @RBComment("Refine search")
   public static final String PRIVATE_CONSTANT_455 = "REFINE_SEARCH";

   @RBEntry("Buscar objeto")
   @RBComment("Item Picker Title")
   public static final String PRIVATE_CONSTANT_456 = "ITEM_PICKER_TITLE";

   @RBEntry("Selector de objetos")
   @RBComment("Item Picker Label")
   public static final String PRIVATE_CONSTANT_457 = "ITEM_PICKER_LABEL";

   @RBEntry("Buscar contexto")
   @RBComment("Context Picker Title")
   public static final String PRIVATE_CONSTANT_458 = "CONTEXTS_PICKER_TITLE";

   @RBEntry("Selector de contexto")
   @RBComment("Context Picker Label")
   public static final String PRIVATE_CONSTANT_459 = "CONTEXTS_PICKER_LABEL";

   @RBEntry("Buscar")
   @RBComment("Find")
   public static final String PRIVATE_CONSTANT_460 = "FIND_PICKER_LABEL";

   @RBEntry("Vista")
   @RBComment("View")
   public static final String PRIVATE_CONSTANT_461 = "VIEW_PICKER_LABEL";

   @RBEntry("Vista de búsqueda de contextos de abastecimiento por defecto")
   @RBComment("Default Sourcing Context Search View")
   public static final String PRIVATE_CONSTANT_462 = "AXLCONTEXT_TABLEVIEW_NAME";

   @RBEntry("Tabla de búsqueda de contextos de abastecimiento por defecto")
   @RBComment("Default Sourcing Context Search Table")
   public static final String PRIVATE_CONSTANT_463 = "AXLCONTEXT_TABLEVIEW_DESC";

   @RBEntry("Contexto de abastecimiento")
   @RBComment("Sourcing Context")
   public static final String PRIVATE_CONSTANT_464 = "AXLCONTEXT_TABLEVIEW_LABEL";

   @RBEntry("Vista de nota por defecto")
   @RBComment("Default Note View")
   public static final String PRIVATE_CONSTANT_465 = "NOTE_TABLEVIEW_NAME";

   @RBEntry("Tabla de búsqueda de nota por defecto")
   @RBComment("Default Note Search Table")
   public static final String PRIVATE_CONSTANT_466 = "NOTE_TABLEVIEW_DESC";

   @RBEntry("Resultados de búsqueda exportados")
   @RBComment("Exported search results header")
   public static final String PRIVATE_CONSTANT_467 = "EXPORTED_SEARCH_RESULTS";

   @RBEntry("Nota")
   @RBComment("Note")
   public static final String PRIVATE_CONSTANT_468 = "NOTE_TABLEVIEW_LABEL";

   @RBEntry("Buscar")
   public static final String PRIVATE_CONSTANT_469 = "search.pickerSearch.description";

   @RBEntry("Despejar")
   public static final String PRIVATE_CONSTANT_470 = "search.pickerClear.description";

   @RBEntry("No se ha definido la función de callback o hay algún error en ella:")
   @RBComment("Error on picker call back")
   public static final String PICKER_CALL_BACK_ERROR = "PICKER_CALL_BACK_ERROR";

   @RBEntry("Nombre")
   @RBComment("Name")
   public static final String SAVED_QUERY_NAME = "SAVED_QUERY_NAME";

   @RBEntry("Creador")
   @RBComment("Creator")
   public static final String SAVED_QUERY_CREATOR = "SAVED_QUERY_CREATOR";

   @RBEntry("Página propietaria")
   @RBComment("Owning Page")
   public static final String SAVED_QUERY_OWNINGPAGE = "SAVED_QUERY_OWNINGPAGE";

   @RBEntry("Fecha de creación")
   @RBComment("Created")
   public static final String SAVED_QUERY_CREATEDON = "SAVED_QUERY_CREATEDON";

   @RBEntry("Última actualización")
   @RBComment("Last Updated")
   public static final String SAVED_QUERY_UPDATEDON = "SAVED_QUERY_UPDATEDON";

   @RBEntry("Propietario")
   @RBComment("Owner")
   public static final String SAVED_QUERY_OWNER = "SAVED_QUERY_OWNER";

   @RBEntry("Mostrar")
   @RBComment("Show")
   public static final String SAVED_QUERY_SHOW = "SAVED_QUERY_SHOW";

   @RBEntry("La ventana de apertura está cerrada")
   @RBComment("Message thrown when picker opener is closed")
   public static final String OPENER_WINDOW_CLOSED = "OPENER_WINDOW_CLOSED";

   @RBEntry("No hay nada seleccionado")
   @RBComment("Nothing has been selected")
   public static final String NOTHING_SELECTED = "NOTHING_SELECTED";

   @RBEntry("Especifique los criterios de búsqueda o introduzca una palabra clave válida.")
   @RBComment("Please specify search criteria or enter a valid keyword.")
   public static final String EMPTY_CRITERAI_MESSAGE = "EMPTY_CRITERAI_MESSAGE";

   @RBEntry("Incluir todos los artículos")
   @RBComment("Include All Parts")
   public static final String SEARCH_CRITERIA_INCLUDE_ALL_PARTS = "SEARCH_CRITERIA_INCLUDE_ALL_PARTS";

   @RBEntry("Incluir sólo")
   @RBComment("Include Only")
   public static final String SEARCH_CRITERIA_INCLUDE_ONLY = "SEARCH_CRITERIA_INCLUDE_ONLY";

   @RBEntry("Código de trazabilidad por defecto")
   @RBComment("Default Trace Code")
   public static final String DEFAULT_TRACE_CODE = "DEFAULT_TRACE_CODE";
 
   @RBEntry("Elemento final")
   @RBComment("End Item")
   public static final String DDL_OPTIONS_ENDITEM = "DDL_OPTIONS_ENDITEM";

   @RBEntry("Lote")
   @RBComment("Lot")
   public static final String DDL_OPTIONS_LOT = "DDL_OPTIONS_LOT";

   @RBEntry("Número de serie ")
   @RBComment("serialNumber")
   public static final String DDL_OPTIONS_SERIALNUMBER = "DDL_OPTIONS_SERIALNUMBER";

   @RBEntry("Nº de serie/lote")
   @RBComment("lotSerialNumber")
   public static final String DDL_OPTIONS_LOTSERIALNUMBER = "DDL_OPTIONS_LOTSERIALNUMBER";

   @RBEntry("Estándar")
   @RBComment("standard")
   public static final String DDL_OPTIONS_STANDARD = "DDL_OPTIONS_STANDARD";

   @RBEntry("Genérico")
   @RBComment("genericParts")
   public static final String DDL_OPTIONS_GENERICPARTS = "DDL_OPTIONS_GENERICPARTS";

   @RBEntry("Genérico configurable")
   @RBComment("configurableGenericParts")
   public static final String DDL_OPTIONS_CONFIGURABLEGENERICPARTS = "DDL_OPTIONS_CONFIGURABLEGENERICPARTS";

   @RBEntry("Variante")
   @RBComment("variantParts")
   public static final String DDL_OPTIONS_VARIANTPARTS = "DDL_OPTIONS_VARIANTPARTS";

   @RBEntry("Configurable avanzado")
   @RBComment("advancedConfigurableParts")
   public static final String DDL_OPTIONS_ADVANCEDCONFIGURABLEPARTS = "DDL_OPTIONS_ADVANCEDCONFIGURABLEPARTS";

   @RBEntry("Elemento final configurable avanzado")
   @RBComment("advanced Configurable End Items")
   public static final String DDL_OPTIONS_ADVANCEDCONFIGURABLEENDITEMS = "DDL_OPTIONS_ADVANCEDCONFIGURABLEENDITEMS";

   @RBEntry("Configurable")
   @RBComment("configurableParts")
   public static final String DDL_OPTIONS_CONFIGURABLEPARTS = "DDL_OPTIONS_CONFIGURABLEPARTS";

   @RBEntry("Módulo configurable")
   @RBComment("genericType")
   public static final String GENERIC_TYPE = "GENERIC_TYPE";
  
   @RBEntry("Campo de nombre de fichero en página de búsqueda simple")
   @RBComment("Property need to set to Search for CAD Name from Simple search page.")
   public static final String CADNAME_FILENAME_ENABLED = "CADNAME_FILENAME_ENABLED";

   @RBEntry("Mostrar campo de nombre de fichero en página de búsqueda simple con la que el usuario puede buscar el documento CAD con nombre CAD.")
   @RBComment("Property need to set to Search for CAD Name from Simple search page.")
   public static final String CADNAME_FILENAME_ENABLED_DESCRIPTION = "CADNAME_FILENAME_ENABLED_DESCRIPTION";

   @RBEntry("Mostrar campo de nombre de fichero en página de búsqueda simple con la que el usuario puede buscar el documento CAD con nombre CAD.")
   @RBComment("Property need to set to Search for CAD Name from Simple search page.")
   public static final String CADNAME_FILENAME_ENABLED_LONGDESCRIPTION = "CADNAME_FILENAME_ENABLED_LONGDESCRIPTION";

   @RBEntry("Imagen reducida")
   @RBComment("Thumbnail column label")
   public static final String THUMBNAIL = "THUMBNAIL";

   @RBEntry("Resultados por página requiere un valor numérico válido.")
   @RBComment("Message thrown when user enters invalid number for result per page.")
   public static final String MESSAGE_RESULT_PER_PAGE = "MESSAGE_RESULT_PER_PAGE";

   @RBEntry("Lista de tipos por defecto para la búsqueda global")
   @RBComment("display name for global search type list in preference manager")
   public static final String GLOBAL_SEARCH_TYPE_LIST_NAME = "GLOBAL_SEARCH_TYPE_LIST_NAME";

   @RBEntry("Esta preferencia permite especificar los tipos de objetos mostrados en la lista desplegable de la búsqueda global.")
   @RBComment("short description of global search type list in preference manager")
   public static final String GLOBAL_SEARCH_TYPE_LIST_DESC = "GLOBAL_SEARCH_TYPE_LIST_DESC";

   @RBEntry("Esta preferencia permite especificar los tipos de objetos mostrados en la lista desplegable de la búsqueda global.")
   @RBComment("long description of global search type list in preference manager")
   public static final String GLOBAL_SEARCH_TYPE_LIST_LONG_DESC = "GLOBAL_SEARCH_TYPE_LIST_LONG_DESC";

   @RBEntry("Visualización de imágenes reducidas en los resultados de la búsqueda")
   @RBComment("Display name for thumbnailsOnWCSearch option in Preferences client")
   public static final String THUMBNAILS_ON_WC_SEARCH = "THUMBNAILS_ON_WC_SEARCH";

   @RBEntry("Elegir si se deben mostrar imágenes reducidas en las páginas de resultados de búsquedas.")
   @RBComment("Description for thumbnailsOnWCSearch option in the Preferences client")
   public static final String THUMBNAILS_ON_WC_SEARCH_DESCRIPTION = "THUMBNAILS_ON_WC_SEARCH_DESCRIPTION";

   @RBEntry("Esta preferencia la utiliza el cliente de búsqueda. Sólo tienen imágenes reducidas los objetos que se pueden visualizar en Creo View. Los resultados de búsqueda se cargan con más rapidez si no se visualizan las imágenes reducidas. La opción por defecto del sistema es no mostrar las imágenes reducidas.")
   @RBComment("Long description for thumbnailsOnWCSearch option in the Preferences client")
   public static final String THUMBNAILS_ON_WC_SEARCH_LONGDESCRIPTION = "THUMBNAILS_ON_WC_SEARCH_LONGDESCRIPTION";

   @RBEntry("Redefinir selección de GlobalType")
   @RBComment("Display name for ResetGlobalTypeSelection option in Preferences client")
   public static final String RESET_GLOBAL_TYPESELECTION = "RESET_GLOBAL_TYPESELECTION";

   @RBEntry("Permitir al usuario redefinir el tipo global")
   @RBComment("Description for ResetGlobalTypeSelection option in the Preferences client")
   public static final String RESET_GLOBAL_TYPESELECTION_DESCRIPTION = "RESET_GLOBAL_TYPESELECTION_DESCRIPTION";

   @RBEntry("Permitir al usuario redefinir el tipo global")
   @RBComment("Long description for ResetGlobalTypeSelection option in the Preferences client")
   public static final String RESET_GLOBAL_TYPESELECTION_LONGDESCRIPTION = "RESET_GLOBAL_TYPESELECTION_LONGDESCRIPTION";

   @RBEntry("Búsqueda de todos los tipos de objeto pertinentes")
   @RBComment("Display name for allSearchTypes option in Preferences client")
   public static final String ALLSEARCHTYPES = "ALLSEARCHTYPES";

   @RBEntry("Lista de los tipos que aparecen en el Selector de tipos de las páginas de Búsqueda. También la lista de objetos que se buscan cuando el usuario selecciona \"Todos los tipos de objeto pertinentes\" como tipo de objeto en la página de búsqueda simple.")
   @RBComment("Description for allSearchTypes option in the Preferences client.When you search within a specific context, the object types listed are set by the context administrator and may differ from the object types that you select for this preference.")
   public static final String ALLSEARCHTYPES_DESCRIPTION = "ALLSEARCHTYPES_DESCRIPTION";

   @RBEntry("Lista de los tipos que aparecen en la ventana Tipo de las páginas de búsqueda. También es una lista de objetos que se buscan cuando el usuario selecciona Todos los tipos de objeto pertinentes como tipo de objeto en la página de búsqueda simple. Al instalar el servidor Windchill, la preferencia Búsqueda de todos los tipos de objeto pertinentes no tiene ningún valor. Al acceder a la página de búsqueda de Windchill, el valor por defecto de la preferencia se define según el fichero SearchableTypes.properties. Para poder cambiar la preferencia de búsqueda, es necesario acceder a la página de búsqueda al menos una vez. ")
   @RBComment("Long description for allSearchTypes option in the Preferences client.When you search within a specific context, the object types listed are set by the context administrator and may differ from the object types that you select for this preference.")
   public static final String ALLSEARCHTYPES_LONGDESCRIPTION = "ALLSEARCHTYPES_LONGDESCRIPTION";

   @RBEntry("Selección de tipos global")
   @RBComment("Display name for globalTypeSelection option in Preferences client")
   public static final String GLOBAL_TYPE_SELECTION = "GLOBAL_TYPE_SELECTION";

   @RBEntry("Preferencia para la elección de tipos en la página de búsqueda sencilla. Cuando el usuario selecciona diferentes tipos de objetos, la preferencia cambia.")
   @RBComment("Description for Default Type Selection option in the Preferences client")
   public static final String GLOBAL_TYPE_SELECTION_DESCRIPTION = "GLOBAL_TYPE_SELECTION_DESCRIPTION";

   @RBEntry("Preferencia para la elección de tipos en la página de búsqueda sencilla. Cuando el usuario selecciona diferentes tipos de objetos, la preferencia cambia.")
   @RBComment("Long description for Default Type Selection option in the Preferences client")
   public static final String GLOBAL_TYPE_SELECTION_LONGDESCRIPTION = "GLOBAL_TYPE_SELECTION_LONGDESCRIPTION";

   @RBEntry("Lista de tipos por defecto para la búsqueda avanzada")
   @RBComment("Display name for searchTypeSelection ")
   public static final String SEARCH_TYPE_SELECTION = "SEARCH_TYPE_SELECTION";

   @RBEntry("Esta preferencia permite especificar los tipos de objetos mostrados por defecto en la página de búsqueda avanzada.")
   @RBComment("Description for Default Type Selection option in the Preferences client")
   public static final String SEARCH_TYPE_SELECTION_DESCRIPTION = "SEARCH_TYPE_SELECTION_DESCRIPTION";

   @RBEntry("Esta preferencia permite especificar los tipos de objetos mostrados por defecto en la página de búsqueda avanzada.")
   @RBComment("Long description for Default Type Selection option in the Preferences client")
   public static final String SEARCH_TYPE_SELECTION_LONGDESCRIPTION = "SEARCH_TYPE_SELECTION_LONGDESCRIPTION";

   @RBEntry("Nombres internos de búsquedas guardadas para el usuario.")
   @RBComment("Display name for savedSearches option in Preferences client")
   public static final String SAVEDSEARCHES = "SAVEDSEARCHES";

   @RBEntry("Nombres internos de búsquedas guardadas para el usuario.")
   @RBComment("Description for savedSearches option in the Preferences client")
   public static final String SAVEDSEARCHES_DESCRIPTION = "SAVEDSEARCHES_DESCRIPTION";

   @RBEntry("Nombres internos de búsquedas guardadas para el usuario.")
   @RBComment("Long description for savedSearches option in the Preferences client")
   public static final String SAVEDSEARCHES_LONGDESCRIPTION = "SAVEDSEARCHES_LONGDESCRIPTION";

   /**
    * added for fixing SPR 1350174
    **/
   @RBEntry("Se ha producido un error al realizar esta tarea. Informe al administrador del sistema, indicando lo que estaba haciendo cuando se produjo el problema.")
   @RBComment("This value is will be displayed as a warning alert for exceptions which are thrown from Server side without proper embedded messages ")
   public static final String GENERIC_ERROR_MESSAGE = "GENERIC_EXCEPTION_MESSAGE";

   @RBEntry("Aviso: la búsqueda ha funcionado correctamente, pero es posible que no se hayan encontrado algunos objetos y que los resultados estén incompletos. Pulse en \"Modificar criterios\" e introduzca criterios más restrictivos en el campo de la palabra clave y garantizar que se devuelven todos los resultados. Si desea más información sobre el uso del campo \"Palabra clave\", consulte la ayuda en línea.")
   @RBComment("Message to display to a user when there are possible additional search results in Rware and they need to make their criteria more specific")
   public static final String INCOMPLETE_RESULT_SET_WARNING = "INCOMPLETE_RESULT_SET_WARNING";

   @RBEntry("Aviso: la búsqueda se ha realizado correctamente, pero es posible que no se hayan encontrado algunos objetos y que los resultados estén incompletos. Pulse en Modificar criterios e introduzca criterios más restrictivos en el campo de palabra clave para asegurarse de que se devuelvan todos los resultados. Para obtener más información sobre el uso de los criterios de búsqueda, consulte la ayuda en línea.")
   @RBComment("Message to display to a user when there are possible additional search results at DB and they need to make their criteria more specific")
   public static final String INCOMPLETE_DB_RESULT_SET_WARNING = "INCOMPLETE_DB_RESULT_SET_WARNING";

   @RBEntry("Resultados por página")
   @RBComment("Display name for result per page in Preferences client")
   public static final String SEARCHTABLELIMIT = "SEARCHTABLELIMIT";

   @RBEntry("En esta preferencia se define el valor por defecto del número de resultados por página. El valor por defecto es 15.")
   @RBComment("Description for Results per page option in the Preferences client")
   public static final String RESULT_PER_PAGE_DESCRIPTION = "SEARCHTABLELIMIT_DESCRIPTION";

   @RBEntry("En esta preferencia se define el valor por defecto del número de resultados por página. El valor por defecto es 15.")
   @RBComment("Long description for Results per page option in the Preferences client")
   public static final String RESULT_PER_PAGE_LONGDESCRIPTION = "SEARCHTABLELIMIT_LONGDESCRIPTION";

   @RBEntry("Atención: Hay elementos que ya se encuentran en la lista de objetos seleccionados...\n\nLa lista de objetos seleccionados ya contiene algunos de los elementos que está intentando trasladar:\n{0}\n\nSe añadirán sólo los objetos que no se encuentren en la lista de objetos seleccionados.")
   @RBComment("Attention: Item(s) already in Selected object list...\n\nThe Selected list already contains some of the items you are attempting to move:\n{0}\n\nItems you indicated that are not already in the Selected list will be added.")
   public static final String SOME_ITEMS_ALREADY_SELECTED = "SOME_ITEMS_ALREADY_SELECTED";

   @RBEntry("Atención: Hay elementos que ya se encuentran en la lista de objetos seleccionados...\n\nLa lista de objetos seleccionados ya contiene los objetos que está intentando trasladar:\n{0}")
   @RBComment("Attention: Item(s) already in Selected object list...\n\nThe Selected list already contains the items you are attempting to move:\n{0}")
   public static final String ALL_ITEMS_ALREADY_SELECTED = "ALL_ITEMS_ALREADY_SELECTED";

   @RBEntry("Sin trazabilidad")
   @RBComment("untracedParts")
   public static final String DDL_OPTIONS_UUNTRACED = "DDL_OPTIONS_UUNTRACED";

   @RBEntry("Con la opción \"Incluir sólo\" es necesario haber seleccionado una opción como mínimo.")
   @RBComment("Alert message if user selects no checkbox from include only radio.")
   public static final String DDLALERT = "DDLALERT";

   @RBEntry("El valor ya existe en el sistema.\n\nEl nombre que ha introducido en esta página ya existe. Pulse en Aceptar para sobrescribir el nombre o pulse en Cancelar para volver a la página e introducir otro nombre diferente.")
   @RBComment("Alert message for same saved search name")
   public static final String SAVEDSEARCHNAMEALERT = "SAVEDSEARCHNAMEALERT";

   @RBEntry("Número de elemento de línea de contrato")
   @RBComment("search attribute for CDRLBasePackage")
   public static final String CONTRACT_LINE_ITEM = "CONTRACT_LINE_ITEM";

   @RBEntry("Número de contrato")
   @RBComment("search attribute for CDRLBasePackage")
   public static final String CONTRACT_NUMBER = "CONTRACT_NUMBER";

   @RBEntry("ATENCIÓN: Se han seleccionado objetos no válidos para la acción Borrar. \n\n Los objetos no válidos para la acción Borrar no se borrarán.")
   @RBComment("Delete action is invalid for one or more selected objects")
   public static final String DELETE_ACTION_INVALID = "DELETE_ACTION_INVALID";

   @RBEntry("Carpeta")
   @RBComment("Label for folder search picker.")
   public static final String LOCATION_PICKER_LABEL = "LOCATION_PICKER_LABEL";

   @RBEntry("Última búsqueda")
   @RBComment("Last Search")
   public static final String LAST_SEARCH = "LAST_SEARCH";

   @RBEntry("Aplicación de origen")
   @RBComment("Label for EPMDocument authoring application")
   public static final String EPM_AUTHORING_APPLICATION = "EPM_AUTHORING_APPLICATION";

   @RBEntry("Categoría de documento")
   @RBComment("Label for EPMDocument document category")
   public static final String EPM_DOCUMENT_TYPE = "EPM_DOCUMENT_TYPE";

   @RBEntry("Vista de acuerdos por defecto")
   @RBComment("Default Agreement View")
   public static final String PRIVATE_CONSTANT_471 = "AUTHORIZATIONAGREEMENT_TABLEVIEW_NAME";

   @RBEntry("Vista de la tabla de búsqueda de acuerdos por defecto")
   @RBComment("Default Agreement Search Table View")
   public static final String PRIVATE_CONSTANT_472 = "AUTHORIZATIONAGREEMENT_TABLEVIEW_DESC";

   @RBEntry("Acuerdo")
   @RBComment("Agreement")
   public static final String PRIVATE_CONSTANT_473 = "AUTHORIZATIONAGREEMENT_TABLEVIEW_LABEL";

   @RBEntry("Tipo de recurso")
   @RBComment("Label for Resource User Type dropdown having values Windchill User and Other")
   public static final String PLAN_RESOURCE_NAME_LABEL = "PLAN_RESOURCE_NAME_LABEL";

   @RBEntry("Código CAGE")
   @RBComment("Org field name on search page when wadam is installed")
   public static final String WADMORG = "WADMORG";

   @RBEntry("Nombre de configuración de artículo")
   @RBComment("Label for configuration name in the configuration compare search picker")
   public static final String PART_CONFIGURATION_NAME_LABEL = "PART_CONFIGURATION_NAME_LABEL";

   @RBEntry("Nombre de artículo base")
   @RBComment("Label for base part name in the configuration compare search picker")
   public static final String BASE_PART_NAME_LABEL = "BASE_PART_NAME_LABEL";

   @RBEntry("Nº de artículo base")
   @RBComment("Label for base part number in the configuration compare search picker")
   public static final String BASE_PART_NUMBER_LABEL = "BASE_PART_NUMBER_LABEL";

   @RBEntry("Contacto")
   @RBComment("Label for the saved search customize table contact column")
   public static final String PRIVATE_CONSTANT_474 = "CONTACT_LABEL";

   @RBEntry("Mostrar búsqueda avanzada")
   @RBComment("Label used at picker")
   public static final String ADVANCED_SEARCH_LBL = "ADVANCED_SEARCH_LBL";

   @RBEntry("Ocultar búsqueda avanzada")
   @RBComment("Label used at picker")
   public static final String BASIC_SEARCH_LBL = "BASIC_SEARCH_LBL";

   @RBEntry("Tipo")
   @RBComment("Label used at object type picker")
   public static final String OBJECT_TYPE_LBL = "OBJECT_TYPE_LBL";

   @RBEntry("Tipo")
   @RBComment("Label used at object type picker on advanced search page")
   public static final String TYPE_LBL = "TYPE_LBL";

   @RBEntry("Código")
   @RBComment("Label for the code field in Choice Search")
   public static final String PRIVATE_CONSTANT_475 = "CODE_LABEL";

   @RBEntry("Opción")
   @RBComment("Label for the option field in Choice Search")
   public static final String PRIVATE_CONSTANT_476 = "OPTION_LABEL";

   @RBEntry("Grupo")
   @RBComment("Label for the group field in Choice Search")
   public static final String PRIVATE_CONSTANT_477 = "GROUP_LABEL";

   @RBEntry("Contextos específicos")
   @RBComment("Static Find Specific Context option added in context picker dropdown")
   public static final String PRIVATE_CONSTANT_478 = "FIND_CONTEXT";

   @RBEntry("Icono de formato")
   @RBComment("Label for the column \"Format Icon\" in tables")
   public static final String FORMAT_ICON = "FORMAT_ICON";

   @RBEntry("Los resultados por página deben ser menor que ")
   @RBComment("Max result per page cap.")
   public static final String RESULT_PER_PAGEMAX_CAP = "RESULT_PER_PAGEMAX_CAP";

   @RBEntry("Elegir rango de fechas")
   @RBComment("Choose Date Range")
   public static final String DATE_DATE_RANGE = "DATE_DATE_RANGE";

   @RBEntry("Elegir rango de días")
   @RBComment("Choose Day Range")
   public static final String DATE_DAY_RANGE = "DATE_DAY_RANGE";

   @RBEntry("Ayer")
   @RBComment("Yesterday")
   public static final String DATE_YESTERDAY = "DATE_YESTERDAY";

   @RBEntry("Hoy")
   @RBComment("Today")
   public static final String DATE_TODAY = "DATE_TODAY";

   @RBEntry("Mañana")
   @RBComment("Tomorrow")
   public static final String DATE_TOMORROW = "DATE_TOMORROW";

   @RBEntry("días")
   @RBComment("days ago")
   public static final String DAYS_AGO = "DAYS_AGO";

   @RBEntry("días a partir de ahora")
   @RBComment("days from now")
   public static final String DAYS_NOW = "DAYS_NOW";

   @RBEntry("Nueva vista")
   public static final String PRIVATE_CONSTANT_479 = "search.newView.description";

   @RBEntry("Criterios obsoletos.")
   @RBComment("Message for alert when some of the criteria's are missing after upgrade.")
   public static final String MISSING_QUERYBUILDER_ROW = "MISSING_QUERYBUILDER_ROW";

   @RBEntry("Estos criterios están obsoletos después de actualizar a la versión más reciente. Borre estos criterios y añada criterios nuevos de la lista de criterios y vuelva a guardar la búsqueda. En el caso de que el administrador hubiese asignado la búsqueda guardada, pídale que vuelva a crear la búsqueda guardada.")
   @RBComment("Message for alert when some of the criteria's are missing after upgrade.")
   public static final String INVALID_QUERYBUILDER_ROW = "INVALID_QUERYBUILDER_ROW";

   @RBEntry("ID")
   @RBComment("Label for Project Plan Activity ID.")
   public static final String PLAN_ACTIVITY_ID = "PLAN_ACTIVITY_ID";

   @RBEntry("Tipo no válido para la búsqueda avanzada.")
   @RBComment("wt.fc.Persistable is not a valid type for advanced search")
   public static final String INVALID_TYPE_FOR_ADVANCED_SEARCH = "INVALID_TYPE_FOR_ADVANCED_SEARCH";

   @RBEntry("Nueva vista")
   @RBComment("new view")
   public static final String NEWVIEW = "NEWVIEW";

   @RBEntry("Cerrar")
   public static final String PRIVATE_CONSTANT_480 = "search.searchCloseButton.description";

   @RBEntry("Fabricación")
   public static final String PRIVATE_CONSTANT_481 = "MAKE_FACET";

   @RBEntry("Compra")
   public static final String PRIVATE_CONSTANT_482 = "BUY_FACET";

   @RBEntry("Trabajo en curso")
   public static final String PRIVATE_CONSTANT_483 = "INWORK_FACET";

   @RBEntry("Liberado")
   public static final String PRIVATE_CONSTANT_484 = "RELEASED_FACET";

   @RBEntry("Artículos")
   public static final String PRIVATE_CONSTANT_485 = "WTPART_FACET";

   @RBEntry("Documentos")
   public static final String PRIVATE_CONSTANT_486 = "WTDOCUMENT_FACET";

   @RBEntry("Nombre del destinatario")
   @RBComment("Field name for recipent name in delta delivery picker")
   public static final String RECIPIENT_NAME = "RECIPIENT_NAME";

   @RBEntry("Gestionar")
   public static final String PRIVATE_CONSTANT_487 = "search.savedSearchTable.description";

   @RBEntry("Gestionar")
   public static final String PRIVATE_CONSTANT_488 = "search.savedSearchTable.tooltip";

   @RBEntry("Gestionar búsquedas guardadas")
   public static final String PRIVATE_CONSTANT_489 = "search.savedSearchTable.title";

   @RBEntry("height=450,width=920")
   public static final String PRIVATE_CONSTANT_523 = "search.savedSearchTable.moreurlinfo";

   @RBEntry("Guardar esta búsqueda")
   public static final String PRIVATE_CONSTANT_490 = "search.saveThisSearchDefaultName.description";

   @RBEntry("height=250,width=450")
   public static final String PRIVATE_CONSTANT_491 = "search.saveThisSearchDefaultName.moreurlinfo";

   @RBEntry("Guardar esta búsqueda")
   public static final String PRIVATE_CONSTANT_492 = "search.saveThisSearchDefaultName.title";

   @RBEntry("Nombre")
   public static final String SAVED_SEARCH_DISPLAY_NAME = "SAVED_SEARCH_DISPLAY_NAME";

   @RBEntry("Cerrar")
   public static final String PRIVATE_CONSTANT_493 = "search.savedSearchLightBoxCloseButton.description";

   @RBEntry("Historial de búsquedas y búsquedas guardadas")
   public static final String PRIVATE_CONSTANT_494 = "search.searchHistSavedSearch.description";

   @RBEntry("Búsqueda avanzada")
   public static final String PRIVATE_CONSTANT_495 = "search.advancedSearch.description";

   @RBEntry("Búsqueda de clasificación")
   public static final String PRIVATE_CONSTANT_496 = "search.classificationSearch.description";

   @RBEntry("Historial de búsquedas")
   @RBComment("Heading for Search History Display")
   public static final String SEARCH_HISTORY_HEADING = "SEARCH_HISTORY_HEADING";

   @RBEntry("Búsquedas guardadas")
   @RBComment("Heading for Saved Search Display")
   public static final String SAVED_SEARCH_HEADING = "SAVED_SEARCH_HEADING";

   @RBEntry("Creadas por mí")
   @RBComment("Saved Search section for queries saved by current user")
   public static final String SAVED_SEARCH_CREATED_BY_ME = "SAVED_SEARCH_CREATED_BY_ME";

   @RBEntry("Compartidos conmigo")
   @RBComment("Saved Search section for queries saved by current user")
   public static final String SAVED_SEARCH_SHARED_WITH_ME = "SAVED_SEARCH_SHARED_WITH_ME";

   @RBEntry("Hoy")
   @RBComment(" Search History for today's searches.")
   public static final String SEARCH_HISTORY_TODAY = "SEARCH_HISTORY_TODAY";

   @RBEntry("Más antiguas ")
   @RBComment(" Search History for older searches.")
   public static final String SEARCH_HISTORY_OLDER = "SEARCH_HISTORY_OLDER";

   @RBEntry("Hoy no se ha ejecutado ninguna búsqueda")
   @RBComment("label when no records found in todays history")
   public static final String SEARCH_HISTORY_TODAY_NO_RECORDS_LABEL = "SEARCH_HISTORY_TODAY_NO_RECORDS_LABEL";

   @RBEntry("Ninguna")
   @RBComment("label when no records found in Saved Searches.")
   public static final String SAVED_SEARCH_NO_RECORDS_LABEL = "SAVED_SEARCH_NO_RECORDS_LABEL";

   @RBEntry("Editar criterios")
   @RBComment("Label for Edit action in saved search & search history display.")
   public static final String PRIVATE_CONSTANT_497 = "EDIT_LABEL";

   @RBEntry("Palabra clave")
   @RBComment("Being used in the search history display page in search history link.")
   public static final String KEYWORD_FOR_SEARCH_HISTORY_LINK = "KEYWORD_FOR_SEARCH_HISTORY_LINK";

   @RBEntry("Tipo")
   @RBComment("Being used in the search history display page in search history link.")
   public static final String TYPE_FOR_SEARCH_HISTORY_LINK = "TYPE_FOR_SEARCH_HISTORY_LINK";

   @RBEntry("Vista del conjunto de opciones por defecto")
   @RBComment("Default Option Set View")
   public static final String PRIVATE_CONSTANT_498 = "OPTIONSET_TABLEVIEW_NAME";

   @RBEntry("Vista de la tabla de búsqueda del conjunto de opciones por defecto")
   @RBComment("Default Option Set Search Table View")
   public static final String PRIVATE_CONSTANT_499 = "OPTIONSET_TABLEVIEW_DESC";

   @RBEntry("Conjunto de opciones  ")
   @RBComment("Option Set ")
   public static final String PRIVATE_CONSTANT_500 = "OPTIONSET_TABLEVIEW_LABEL";

   @RBEntry("Aceptar")
   @RBComment("Label for Ok button in Ext Window for lightbix.")
   public static final String PRIVATE_CONSTANT_501 = "Ok_LABEL";

   @RBEntry("Cancelar")
   @RBComment("Label for Cancel button in Ext Window for lightbix.")
   public static final String PRIVATE_CONSTANT_502 = "Cancel_LABEL";

   @RBEntry("Criterios adicionales para artículos:")
   @RBComment("Label for Additonal Criteria for Parts")
   public static final String PRIVATE_CONSTANT_503 = "PART_ADDITIONAL_CRITERIA";

   @RBEntry("Guardar")
   @RBComment("Label for Save button in Ext Window for lightbix.")
   public static final String PRIVATE_CONSTANT_504 = "Save_LABEL";

   @RBEntry("Opciones")
   @RBComment("Caption text at type picker launch point at search page")
   public static final String TYPE_PICKER_MENU_CAPTION = "TYPE_PICKER_MENU_CAPTION";

   @RBEntry("Añadir")
   @RBComment("Caption text at type picker launch point at search page")
   public static final String TYPE_PICKER_MENU_ADD_UPDATE = "TYPE_PICKER_MENU_ADD_UPDATE";

   @RBEntry("Restaurar opciones por defecto")
   @RBComment("Caption text at type picker launch point at search page")
   public static final String TYPE_PICKER_MENU_RESTORE_DEFAULT = "TYPE_PICKER_MENU_RESTORE_DEFAULT";

   @RBEntry("Todos los tipos")
   @RBComment("display name for persistable type")
   public static final String ALL_TYPES = "ALL_TYPES";

   @RBEntry("Seleccionar relaciones")
   @RBComment("label for relations")
   public static final String SELECT_RELATIONS = "SELECT_RELATIONS";

   @RBEntry("Vista de elecciones por defecto")
   @RBComment("Default Choice View")
   public static final String PRIVATE_CONSTANT_505 = "CHOICE_TABLEVIEW_NAME";

   @RBEntry("Vista de la tabla de búsqueda de elecciones por defecto")
   @RBComment("Default Choice Search Table View")
   public static final String PRIVATE_CONSTANT_506 = "CHOICE_TABLEVIEW_DESC";

   @RBEntry("Elección ")
   @RBComment("Choice ")
   public static final String PRIVATE_CONSTANT_507 = "CHOICE_TABLEVIEW_LABEL";

   @RBEntry("No se ha podido cargar la búsqueda seleccionada porque se han borrado uno o varios objetos relacionados.")
   @RBComment(" Error message to be shown when user selects a deleted saved query for edit or execute.")
   public static final String SAVED_SEARCH_DELETED_MESSAGE = "SAVED_SEARCH_DELETED_MESSAGE";

   /**
    * special column labels
    **/
   @RBEntry("Nombre")
   public static final String PACKAGE_NAME = "PACKAGE_NAME";

   @RBEntry("Número de paquete")
   public static final String PACKAGE_NUMBER = "PACKAGE_NUMBER";

   @RBEntry("Versión del paquete")
   public static final String PACKAGE_VERSION = "PACKAGE_VERSION";

   @RBEntry("Todo")
   public static final String ALL_VIEW = "ALL_VIEW";

   @RBEntry("Todo")
   public static final String ALL_VIEW_DESCRIPTION = "ALL_VIEW_DESCRIPTION";

   @RBEntry("Nombre de la búsqueda guardada ")
   @RBComment("Label of the saved search name being displayed on advanced search screen.")
   public static final String SAVED_SEARCH_NAME_LABEL = "SAVED_SEARCH_NAME_LABEL";

   @RBEntry("Iniciar una nueva búsqueda ")
   @RBComment("label for start a new search link on the search page")
   public static final String START_A_NEW_SEARCH_LINK = "START_A_NEW_SEARCH_LINK";

   @RBEntry("Guardar esta búsqueda")
   @RBComment("label for save this search link on the search page ")
   public static final String SAVE_THIS_SEARCH_LINK = "SAVE_THIS_SEARCH_LINK";

   @RBEntry("Editar criterios de búsqueda  ")
   @RBComment(" label for edit search criteria link on the search page ")
   public static final String EDIT_SEARCH_CRITERIA_LINK = "EDIT_SEARCH_CRITERIA_LINK";

   @RBEntry("Ver historial de búsquedas y búsquedas guardadas")
   @RBComment("Label of the view saved search option")
   public static final String VIEW_SAVED_SEARCH_LABEL = "VIEW_SAVED_SEARCH_LABEL";

   @RBEntry("Elija un tipo")
   @RBComment("Label of the choose type option")
   public static final String CHOOSE_TYPE_LABEL = "CHOOSE_TYPE_LABEL";

   @RBEntry("Todos los tipos de objeto")
   @RBComment("Label of the all type option")
   public static final String ALL_TYPE_LABEL = "ALL_TYPE_LABEL";

   @RBEntry("Historial de búsquedas y búsquedas guardadas ")
   @RBComment("Tab label for history & saved searches page")
   public static final String PRIVATE_CONSTANT_508 = "navigation.historySaved.description";

   @RBEntry("Búsqueda avanzada")
   @RBComment("Tab label for Advanced search page")
   public static final String PRIVATE_CONSTANT_509 = "navigation.advanced.description";

   @RBEntry("Búsqueda de clasificaciones")
   @RBComment("Tab label for Classification search page")
   public static final String PRIVATE_CONSTANT_510 = "navigation.classification.description";

   @RBEntry("Criterios adicionales")
   @RBComment("Label for Additional Criteria on search info page for search history and saved searches")
   public static final String ADDITIONAL_CRITERIA_LABEL = "ADDITIONAL_CRITERIA_LABEL";


   @RBEntry("Fecha de última realización")
   @RBComment("Label for Last Performed on search info page for search history and saved searches")
   public static final String LAST_PERFORMED_ON_LABEL = "LAST_PERFORMED_ON_LABEL";


   @RBEntry("Tamaño de la lista del selector de contextos visitados recientemente")
   @RBComment("Determines maximum number of items in recently visited Context Picker drop-down.")
   public static final String MULTISELECT_CONTEXTPICKER_LIMIT = "MULTISELECT_CONTEXTPICKER_LIMIT";

   @RBEntry("Puede seleccionar un máximo de {0} contextos de los resultados. Anule la selección de algunos contextos para continuar. ")
   @RBComment("Alert to be shown for user if selects more contexts than preference set for search page.")
   public static final String MULTISELECT_CONTEXTPICKER_LIMIT_ALERT = "MULTISELECT_CONTEXTPICKER_LIMIT_ALERT";

   @RBEntry("Relaciones de red")
   @RBComment("Label for the network realtionship display in search criteria string ")
   public static final String NETWORK_RELATIONSHIP_LABEL = "NETWORK_RELATIONSHIP_LABEL";


   @RBEntry("Contexto de red")
   @RBComment("Label for the network context display in search criteria string ")
   public static final String NETWORK_CONTEXT_LABEL = "NETWORK_CONTEXT_LABEL";


   @RBEntry("Editar criterios")
   @RBComment("Link for edit criteria on search info page for search history and saved searches")
   public static final String EDIT_CRITERIA_LINK = "EDIT_CRITERIA_LINK";

   @RBEntry("Criterios DDL")
   @RBComment("DDL  Criteria label on search info page for search history and saved searches")
   public static final String DDL_CRITERIA_LABEL = "DDL_CRITERIA_LABEL";

   @RBEntry("Objeto relacionado")
   @RBComment("Related Object label on search info page for search history and saved searches")
   public static final String RELATED_OBJECT_LABEL = "RELATED_OBJECT_LABEL";


   @RBEntry("Panel de archivo")
   @RBComment("Archive Panel label on search info page for search history and saved searches")
   public static final String ARCHIVE_PANEL_LABEL = "ARCHIVE_PANEL_LABEL";

   @RBEntry("Vista de especialización por defecto")
   @RBComment("Default Skill View")
   public static final String PRIVATE_CONSTANT_511 = "MPMPSKILL_TABLEVIEW_NAME";

   @RBEntry("Vista en tabla de búsquedas de especializaciones por defecto")
   @RBComment("Default Skill Search Table View")
   public static final String PRIVATE_CONSTANT_512 = "MPMPSKILL_TABLEVIEW_DESC";

   @RBEntry("Especialización")
   @RBComment("Skill")
   public static final String PRIVATE_CONSTANT_513 = "MPMPSKILL_TABLEVIEW_LABEL";

   @RBEntry("Vista de conjunto de herramientas por defecto")
   @RBComment("Default Tooling View")
   public static final String PRIVATE_CONSTANT_514 = "MPMTOOLING_TABLEVIEW_NAME";

   @RBEntry("Vista en tabla de búsquedas de conjuntos de herramientas por defecto")
   @RBComment("Default Tooling Search Table View")
   public static final String PRIVATE_CONSTANT_515 = "MPMTOOLING_TABLEVIEW_DESC";

   @RBEntry("Herramientas")
   @RBComment("Tooling")
   public static final String PRIVATE_CONSTANT_516 = "MPMTOOLING_TABLEVIEW_LABEL";

   @RBEntry("Vista del centro de trabajo por defecto")
   @RBComment("Default WorkCenter View")
   public static final String PRIVATE_CONSTANT_517 = "MPMWORKCENTER_TABLEVIEW_NAME";

   @RBEntry("Vista en tabla de búsquedas del centro de trabajo por defecto")
   @RBComment("Default WorkCenter Search Table View")
   public static final String PRIVATE_CONSTANT_518 = "MPMWORKCENTER_TABLEVIEW_DESC";

   @RBEntry("Centro de trabajo")
   @RBComment("WorkCenter")
   public static final String PRIVATE_CONSTANT_519 = "MPMWORKCENTER_TABLEVIEW_LABEL";

   @RBEntry("Vista de material de proceso por defecto")
   @RBComment("Default Process Material View")
   public static final String PRIVATE_CONSTANT_520 = "MPMPROCESSMATERIAL_TABLEVIEW_NAME";

   @RBEntry("Vista en tabla de búsquedas de material de proceso por defecto")
   @RBComment("Default Process Material Search Table View")
   public static final String PRIVATE_CONSTANT_521 = "MPMPROCESSMATERIAL_TABLEVIEW_DESC";

   @RBEntry("Material de proceso")
   @RBComment("Process Material")
   public static final String PRIVATE_CONSTANT_522 = "MPMPROCESSMATERIAL_TABLEVIEW_LABEL";



   @RBEntry("Guardar esta búsqueda")
   public static final String saveThisSearchProEDesc = "search.saveThisSearchProE.description";

   @RBEntry("Guardar esta búsqueda")
   public static final String saveThisSearchProEToolT = "search.saveThisSearchProE.tooltip";

   @RBEntry("Guardar esta búsqueda")
   public static final String saveThisSearchProETitle = "search.saveThisSearchProE.title";

   @RBEntry("Hasta")
   public static final String uoToLabel = "UP_TO_ATTRIBUTE";

   @RBEntry("hace {0} días")
   public static final String daysAgoAttrib = "DAYS_AGO_TO_ATTRIBUTE";

   @RBEntry("{0} días desde hoy")
   public static final String daysFromNowAttrib = "DAYS_FROM_NOW_ATTRIBUTE";

   @RBEntry("Más")
   @RBComment("More lable in query builder")
   public static final String moreQBLabel = "MORE_QB_LABEL";


   @RBEntry("Opciones")
   public static final String options = "OPTIONS";

   @RBEntry("Añadir contexto")
   public static final String addContext = "ADD_CONTEXT";

   @RBEntry("Más opciones")
   public static final String moreOptions = "MORE_OPTIONS";

   @RBEntry("Aceptar")
   public static final String ok = "OK";

   @RBEntry("Cancelar")
   public static final String cancel = "CANCEL";

   @RBEntry("Buscar en")
   public static final String searchIn = "SEARCH_IN";

   @RBEntry("Afiliación")
   public static final String membership = "MEMBERSHIP";

   @RBEntry("Soy miembro de")
   public static final String iAmAMemberOf = "I_AM_A_MEMBER_OF";

   @RBEntry("Están en mi organización")
   public static final String areInMyOrganization = "ARE_IN_MY_ORGANIZATION";

   @RBEntry("Introduzca un valor numérico válido.")
   @RBComment("Msg for invalid numeric entry.")
   public static final String INVALID_NUMBER = "INVALID_NUMBER";

   @RBEntry("Nuevo")
   @RBComment("Label of submenu New")
   public static final String new_submenu = "object.new_submenu.description";

   @RBEntry("Añadir a")
   @RBComment("Label of submenu Add to")
   public static final String add_to_submenu = "object.add_to_submenu.description";

   @RBEntry("Comparar")
   @RBComment("Label of submenu Compare")
   public static final String compare_submenu = "object.compare_submenu.description";

   @RBEntry("Procesar")
   @RBComment("Label of submenu Process")
   public static final String process_submenu = "object.process_submenu.description";

   @RBEntry("Sin definir")
   public static final String UNDEFINED_LABEL = "UNDEFINED_LABEL";

   @RBEntry("Seleccionar criterios de archivo")
   @RBComment("Label of link to launch archive panel on search page")
   public static final String ARCHIVE_LINK_LEVEL = "ARCHIVE_LINK_LEVEL";

   @RBEntry("Ninguno de los objetos seleccionados soporta esta acción")
   @RBComment("Warning messafe to user when invalid objects are selected to perform Email object owners action")
   public static final String INVALID_OBJECT_EMAIL = "INVALID_OBJECT_EMAIL";

   @RBEntry("Algunos de los objetos seleccionados no soportan esta acción. Pulse en Aceptar para continuar")
   @RBComment("Warning messafe to user when invalid objects are selected to perform Email object owners action")
   public static final String FEW_INVALID_OBJECT_EMAIL = "FEW_INVALID_OBJECT_EMAIL";


   @RBEntry("{0} no se puede buscar con otros tipos.")
   @RBComment("Message alerting the individual type cannot be searched with other types. ")
   public static final String INDIVIDUAL_SEARCH_TYPE = "INDIVIDUAL_SEARCH_TYPE";


   @RBEntry("ID alternativo")
   @RBComment("Field name for user record key in Quality People or Places")
   public static final String ALTERNATE_IDENTIFIER = "ALTERNATE_IDENTIFIER";

   @RBEntry("Nº de teléfono")
   @RBComment("Field name for Phone number in Quality People or Places")
   public static final String PHONE_NUMBER = "PHONE_NUMBER";

   @RBEntry("Correo electrónico")
   @RBComment("Field name for E-mail address in Quality People or Places")
   public static final String EMAIL_ADDRESS = "EMAIL_ADDRESS";

   @RBEntry("Código postal")
   @RBComment("Field name for Postal code in Quality People or Places")
   public static final String POSTAL_CODE = "POSTAL_CODE";

   @RBEntry("Guardar consulta: ")
   @RBComment("Saved Search Create Message")
   public static final String SAVED_SEARCH_CREATED = "SAVED_SEARCH_CREATED";

   @RBEntry("Confirmación: La operación Crear se ha realizado corretamente")
   @RBComment("Saved Search Create Message Title")
   public static final String SAVED_SEARCH_CREATED_TITLE = "SAVED_SEARCH_CREATED_TITLE";

   @RBEntry("Vista de plantilla de proceso de trabajo por defecto")
   @RBComment("Default Workflow Process Template View")
   public static final String PRIVATE_CONSTANT_530 = "WFTEMPLATE_TABLEVIEW_NAME";

   @RBEntry("Vista de tabla de búsqueda de plantilla de proceso de trabajo por defecto")
   @RBComment("Default Workflow Process Template Search Table View")
   public static final String PRIVATE_CONSTANT_531 = "WFTEMPLATE_TABLEVIEW_DESC";

   @RBEntry("Plantilla de proceso de trabajo")
   @RBComment("Workflow Process Template")
   public static final String PRIVATE_CONSTANT_532 = "WFTEMPLATE_TABLEVIEW_LABEL";
   @RBEntry("ATENCIÓN: Para objetos iterados, se borrarán todas las iteraciones de la revisión seleccionada.")
   @RBComment("If one or more of the selected objects are iterated. All iterations for the selected object revisions will be deleted.")
   public static final String CONFIRM_DELETE = "CONFIRM_DELETE";

   @RBEntry("Vista de envío recibido por defecto")
   @RBComment("Default Received Delivery View")
   public static final String PRIVATE_CONSTANT_533 = "RECEIVEDDELIVERY_TABLEVIEW_NAME";

   @RBEntry("Vista de la tabla de búsqueda de envíos recibidos por defecto")
   @RBComment("Default Received Delivery Search Table View")
   public static final String PRIVATE_CONSTANT_534 = "RECEIVEDDELIVERY_TABLEVIEW_DESC";

   @RBEntry("Envío recibido")
   @RBComment("Received Delivery")
   public static final String PRIVATE_CONSTANT_535 = "RECEIVEDDELIVERY_TABLEVIEW_LABEL";

   @RBEntry("Nombre de la vista")
   @RBComment("view name label")
   public static final String PRIVATE_CONSTANT_536 = "VIEW_NAME_LABEL";

   // resources for Clear icon in Structured Enumeration Picker
   @RBEntry("Despejar...")
   public static final String PRIVATE_CONSTANT_537 = "search.callSearchPickerClear.description";

   // resources for Clear icon in Structured Enumeration Picker
   @RBEntry("Despejar...")
   public static final String PRIVATE_CONSTANT_538 = "search.callSearchPickerClear.tooltip";

   @RBEntry("Número")
   public static final String PRIVATE_CONSTANT_539 = "2";

   @RBEntry("Nombre")
   public static final String PRIVATE_CONSTANT_540 = "1";

   @RBEntry("Especifique un criterio de búsqueda")
   @RBComment("Alert shown to the user when empty search is executed with mulitple object types or multiple object types.")
   public static final String MULTI_TYPE_EMPTY_SEARCH_MESSAGE_TITLE = "MULTI_TYPE_EMPTY_SEARCH_MESSAGE_TITLE";

   @RBEntry("La fecha no tiene el formato correcto (dd/mm/aaaa) o se encuentra fuera del rango.")
   public static final String DATE_ERROR = "DATE_ERROR";

   @RBEntry("La búsqueda no se ha realizado correctamente. Puede deberse a un problema con los criterios de búsqueda o bien a que no tenga acceso a los objetos encontrados con esta búsqueda. Modifique los criterios de búsqueda y vuelva a intentarlo o póngase en contacto con el administrador del sistema para obtener ayuda.")
   @RBComment("Message to display to a user when there is there is an invalid search criteria.")
   public static final String INVALID_CRITERIA_ERROR = "INVALID_CRITERIA_ERROR";

   /*
    * ***********************************************************
    * Search in Folder Resources
    *************************************************************
    */
   @RBEntry("Buscar en la carpeta seleccionada")
   @RBComment("Empty text for the Search in Folder component")
   public static final String SEARCH_IN_FOLDER_PROMPT = "SEARCH_IN_FOLDER_PROMPT";

   @RBEntry("Despejar")
   @RBComment("Clear text in Search in Folder component. Reset the text to Empty text string")
   public static final String CLEAR_SEARCH_IN_FOLDER = "CLEAR_SEARCH_IN_FOLDER";

   @RBEntry("El servidor de índices está desconectado")
   @RBComment("Index Server down title")
   public static final String WARN_INDEX_SERER_DOWN_FALLBACK_TO_DB_SEAR_TITLE = "WARN_INDEX_SERER_DOWN_FALLBACK_TO_DB_SEARCH_TITLE";

   @RBEntry("La función de búsqueda de índices no está disponible. Se ha utilizado la búsqueda de atributos. Puede que los resultados de búsqueda no contengan todos los objetos que cabría esperar. Póngase en contacto con el administrador del sistema Windchill.")
   @RBComment("Index Server down. Fall back to DB Search.")
   public static final String WARN_INDEX_SERER_DOWN_FALLBACK_TO_DB_SEARCH = "WARN_INDEX_SERER_DOWN_FALLBACK_TO_DB_SEARCH";

   /*
    ************************************************************
    * Structured Enumeration Picker Resources
    ************************************************************
    */
   @RBEntry("�?rbol de clasificación")
   @RBComment("Title for Classification Tree")
   public static final String CLASSIFICATION_TREE_TITLE = "csm.clfTree.title";

   @RBEntry("Clase")
   @RBComment("Title for the column in Classification Tree")
   public static final String CLASSIFICATION_TREE_COLUMN_NAME = "csm.clfTreeColumnName.title";

   // following entries are added as a part of story B-100525
   @RBEntry("Revise los tipos de objeto seleccionados y vuelva a ejecutar la búsqueda")
   @RBComment("The message to be shown to user when the parent and child types both are selected and parent types should be removed")
   public static final String PARENT_TYPE_SELECTED_MESSAGE = "PARENT_TYPE_SELECTED_MESSAGE";

   @RBEntry("La búsqueda no se puede ejecutar para los objetos de jerarquía.")
   @RBComment("The title to be shown to user when the parent and child types both are selected and parent types should be removed")
   public static final String PARENT_TYPE_SELECTED_MESSAGE_TITLE = "PARENT_TYPE_SELECTED_MESSAGE_TITLE";

   @RBEntry("Mis contextos favoritos")
   @RBComment("Message for My Context Display")
   public static final String MY_FAVOURITE_CONTEXT_LBL = "MY_FAVOURITE_CONTEXT_LBL";

   @RBEntry("Ejemplos de sintaxis de las consultas")
   @RBComment("Examples for query mode syntax")
   public static final String EXAMPLES_FOR_QUERY_MODE_SYNTAX = "EXAMPLES_FOR_QUERY_MODE_SYNTAX";

   @RBEntry("Mis tipos favoritos")
   @RBComment("Label for My Favorite Type checkbox shown on the search page")
   public static final String  MY_FAVOURITE_TYPE_LBL = "MY_FAVOURITE_TYPE_LBL";

   @RBEntry("Criterios")
   @RBComment("Criteria label for the criteria fieldset on the advanced search page.")
   public static final String CRITERIA_LABEL = "CRITERIA_LBL";

   @RBEntry("Selección de varias carpetas")
   @RBComment("Warning Heading message when My Fav checkbox selected and only folders present inside it.")
   public static final String MULTIPLE_FOLDER_SELECTION_HEADING = "MULTIPLE_FOLDER_SELECTION_HEADING";
   
   @RBEntry("No se puede seleccionar más de una carpeta a la vez.")
   @RBComment("Warning message when My Fav checkbox selected and only folders present inside it.")
   public static final String MULTIPLE_FOLDER_SELECTION_MSG = "MULTIPLE_FOLDER_SELECTION_MSG";

    @RBEntry("en")
    @RBComment("Description has format 'Type in Organization', localizing word 'in' ")
    public static final String SAVE_SEARCH_COMBO_BOX_TOOLTIP_DESCRIPTION = "SAVE_SEARCH_COMBO_BOX_TOOLTIP_DESCRIPTION";

    @RBEntry("Sitio")
    @RBComment("Site")
    public static final String PRIVATE_CONSTANT_541 = "Site";
    
    /*Adding Secondary Attachments column*/
    @RBEntry("Adjuntos")
    @RBComment("Label for Secondary Attachments column")
    public static final String SECONDARY_ATTACHMENTS = "SECONDARY_ATTACHMENTS";

    @RBEntry("Etiqueta")
    @RBComment("Label for Tag column")
    public static final String TAG_LABEL = "TAG_LABEL";
    
    @RBEntry("Filtro")
    @RBComment("Label for Filter column")
    public static final String FILTER_LABEL = "FILTER_LABEL";
    
    @RBEntry("{0} no se puede buscar en un solo contexto.")
    @RBComment("Message alerting type can not be searched with single context. ")
    public static final String DENY_SINGLE_CONTEXT_SEARCH = "DENY_SINGLE_CONTEXT_SEARCH";
}
