/* bcwti
 *
 * Copyright (c) 2010 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */

package com.ptc.windchill.suma.axl;

import static com.ptc.windchill.suma.axl.OEMPartAXLContextLink.CONTEXT_CLASSNAME;
import static com.ptc.windchill.suma.axl.OEMPartAXLContextLink.CONTEXT_ID;
import static com.ptc.windchill.suma.axl.OEMPartAXLContextLink.OEM_PART_CLASSNAME;
import static com.ptc.windchill.suma.axl.OEMPartAXLContextLink.OEM_PART_ID;
import static com.ptc.windchill.suma.axl._OEMPartAXLContextLink.OEM_PREFERENCE_DATA;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import ext.kb.util.KBConstants;
import ext.kb.util.KBTeamUtils;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import wt.access.AccessControlHelper;
import wt.access.AccessPermission;
import wt.admin.AdminDomainRef;
import wt.admin.DomainAdministeredHelper;
import wt.doc.docResource;
import wt.enterprise.CopyObjectInfo;
import wt.enterprise.EnterpriseServiceEvent;
import wt.facade.suma.SourcingStatus;
import wt.fc.ObjectIdentifier;
import wt.fc.ObjectReference;
import wt.fc.ObjectVector;
import wt.fc.PersistInfo;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceManagerEvent;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryKey;
import wt.fc.QueryResult;
import wt.fc.WTReference;
import wt.fc.WTStringSet;
import wt.fc.collections.CollectionsHelper;
import wt.fc.collections.WTArrayList;
import wt.fc.collections.WTCollection;
import wt.fc.collections.WTHashSet;
import wt.fc.collections.WTKeyedHashMap;
import wt.fc.collections.WTKeyedMap;
import wt.fc.collections.WTList;
import wt.fc.collections.WTSet;
import wt.fc.collections.WTValuedHashMap;
import wt.fc.collections.WTValuedMap;
import wt.inf.container.OrgContainer;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerHelper;
import wt.inf.container.WTContainerRef;
import wt.inf.container.WTContainerServiceEvent;
import wt.inf.team.ContainerTeamManaged;
import wt.introspection.ClassInfo;
import wt.introspection.WTIntrospector;
import wt.log4j.LogR;
import wt.method.MethodContext;
import wt.notify.NotificationException;
import wt.notify.NotificationServerHelper;
import wt.notify.notifyResource;
import wt.org.WTOrganization;
import wt.org.WTPrincipal;
import wt.part.Source;
import wt.part.WTPart;
import wt.pds.PersistenceCloner;
import wt.pds.StatementSpec;
import wt.pom.Transaction;
import wt.query.ArrayExpression;
import wt.query.ClassAttribute;
import wt.query.ClassTableExpression;
import wt.query.ClassViewExpression;
import wt.query.ConstantExpression;
import wt.query.ExistsExpression;
import wt.query.NegatedExpression;
import wt.query.NullTableExpression;
import wt.query.OrderBy;
import wt.query.QueryException;
import wt.query.QuerySpec;
import wt.query.SQLFunction;
import wt.query.SearchCondition;
import wt.query.SubSelectExpression;
import wt.query.TableColumn;
import wt.query.TableExpression;
import wt.queue.ProcessingQueue;
import wt.queue.QueueHelper;
import wt.services.ManagerException;
import wt.services.ManagerService;
import wt.services.StandardManager;
import wt.session.SessionContext;
import wt.session.SessionHelper;
import wt.session.SessionServerHelper;
import wt.util.LocalizableMessageCollection;
import wt.util.WTAttributeNameIfc;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.WTProperties;
import wt.util.WTPropertyVetoException;
import wt.vc.VersionControlHelper;
import wt.vc.VersionControlServiceEvent;
import wt.vc.config.ConfigHelper;
import wt.vc.config.LatestConfigSpec;
import wt.vc.config.OwnershipIndependentLatestConfigSpec;
import wt.vc.wip.WorkInProgressHelper;
import wt.vc.wip.WorkInProgressServiceEvent;

import com.ptc.core.foundation.type.server.impl.TypeHelper;
import com.ptc.core.lwc.common.view.TypeDefinitionReadView;
import com.ptc.core.lwc.server.PersistableAdapter;
import com.ptc.core.lwc.server.TypeDefinitionServiceHelper;
import com.ptc.core.meta.common.AttributeTypeIdentifier;
import com.ptc.core.meta.common.OperationIdentifier;
import com.ptc.core.meta.common.OperationIdentifierConstants;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.impl.InstanceBasedAttributeTypeIdentifier;
import com.ptc.windchill.suma.SumaServerHelper;
import com.ptc.windchill.suma.axlrule.AXLRuleHelper;
import com.ptc.windchill.suma.ixb.SuMaIxbHndHelper;
import com.ptc.windchill.suma.part.ManufacturerPart;
import com.ptc.windchill.suma.part.ManufacturerPartMaster;
import com.ptc.windchill.suma.part.SupplierPart;
import com.ptc.windchill.suma.part.SupplierPartMaster;
import com.ptc.windchill.suma.part.VendorPart;
import com.ptc.windchill.suma.part.VendorPartMaster;
import com.ptc.windchill.suma.supplier.Manufacturer;
import com.ptc.windchill.suma.supplier.SupplierHelper;
import com.ptc.windchill.suma.supplier.SupplierIfc;
import com.ptc.windchill.suma.supplier.Vendor;
import com.ptc.windchill.suma.supplier.supplierResource;
import com.ptc.windchill.suma.util.SumaConfigHelper;

/**
 *
 * <p>
 * Use the <code>newStandardAXLService</code> static factory method(s),
 * not the <code>StandardAXLService</code> constructor, to construct instances
 * of this class.  Instances must be constructed using the static factory(s),
 * in order to ensure proper initialization of the instance.
 * <p>
 * @see com.ptc.windchill.suma.axl.AXLService
 * @see com.ptc.windchill.suma.axl.AXLServerService
 * @see com.ptc.windchill.suma.axl.AXLEventManager
 *
 * <BR><BR><B>Supported API: </B>true
 * <BR><BR><B>Extendable: </B>false
 */
@SuppressWarnings("serial")
public final class StandardAXLService extends StandardManager implements AXLService, AXLEventManager, AXLServerService {

   private static final String RESOURCE = "com.ptc.windchill.suma.axl.axlResource";
   private static final String CLASSNAME = StandardAXLService.class.getName();

   public static final String DEFAULT_CONTEXT_NAME;
   private static final Object SUMA_LINKS_FOR_REFRESH = new Object() {
      @Override
    public String toString() { return "SUMA_LINKS_FOR_REFRESH"; }
   };
   public static final boolean WT_NOTIFY_USE_QUEUE;

   private static final Logger logger = LogR.getLogger(CLASSNAME);
private static final Object WBM_CONTEXT_KEY = "WBM_CONTEXT_KEY";
   static {
      try {
         String localizedDefault = new WTMessage(RESOURCE, axlResource.DEFAULT_SOURCING_CONTEXT_NAME, null).getLocalizedMessage();
         WTProperties wtp = WTProperties.getServerProperties();
         DEFAULT_CONTEXT_NAME = wtp.getProperty(CLASSNAME+".defaultContextName",localizedDefault);
         WT_NOTIFY_USE_QUEUE = wtp.getProperty("wt.notify.useQueue", true);
      }
      catch (Exception e) {
         throw new ExceptionInInitializerError(e);
      }
   }

   /**
    * Returns the conceptual (modeled) name for the class.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @deprecated
    *
    * @return    String
    **/
   @Deprecated
    @Override
public String getConceptualClassname() {
      return CLASSNAME;
   }

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @exception wt.services.ManagerException
    **/
   @Override
   protected synchronized void performStartupProcess()
            throws ManagerException {
      super.performStartupProcess();
       //Initialize cache listeners
      AXLContextCache.getInstance();
   }

   /**
    * Default factory for the class.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @return    StandardAXLService
    * @exception wt.util.WTException
    **/
   public static StandardAXLService newStandardAXLService()
            throws WTException {
      StandardAXLService instance = new StandardAXLService();
      instance.initialize();
      return instance;
   }

   /**
    * {@inheritDoc}
    * <BR><BR><B>Supported API: </B>true
    */
   @Override
   public AXLEntry addAML( AXLContext context, WTPart oemPart, VendorPart vendorPart, ManufacturerPart manufacturerPart, AXLPreference amlPreference)
            throws WTException {
       validateManufacturerPart(manufacturerPart);
       VendorPartMaster vendorPartMaster = vendorPart == null ? null : (VendorPartMaster) vendorPart.getMaster();
       return addAML(context, oemPart, vendorPartMaster, (ManufacturerPartMaster) manufacturerPart.getMaster(), amlPreference);
   }

   /**
    * {@inheritDoc}
    * <BR><BR><B>Supported API: </B>true
    */
   @Override
   public AXLEntry addAVL( AXLContext context, WTPart oemPart, ManufacturerPart manufacturerPart, VendorPart vendorPart, AXLPreference avlPreference )
            throws WTException {
      validateVendorPart(vendorPart);
      ManufacturerPartMaster manufacturerPartMaster = manufacturerPart == null ? null : (ManufacturerPartMaster) manufacturerPart.getMaster();
      return addAVL(context, oemPart, manufacturerPartMaster, (VendorPartMaster) vendorPart.getMaster(), avlPreference);
   }

   /**
    * {@inheritDoc}
    * <BR><BR><B>Supported API: </B>true
    */
   @Override
   public void removeAML( AXLContext context, WTPart oemPart, ManufacturerPart manufacturerPart  ) throws WTException {
       validateManufacturerPart(manufacturerPart);
       ManufacturerPartMaster manufacturerPartMaster = (ManufacturerPartMaster)manufacturerPart.getMaster();
       removeAML( context, oemPart, manufacturerPartMaster);
   }

   /**
    * {@inheritDoc}
    * <BR><BR><B>Supported API: </B>true
    */
   @Override
   public void removeAML( AXLContext context, WTPart oemPart, ManufacturerPartMaster manufacturerPartMaster )
            throws WTException {
        AXLPreference preference = null;
        AXLPreference oldPreference = null;

        validateContext(context);
        validateOemPart(oemPart, AXLServiceEvent.REMOVE_AML);
        validateManufacturerPartMaster(manufacturerPartMaster);

        Transaction trx = new Transaction();
        try {
            trx.start();

            // SELECT *
            // FROM AXLEntry
            // WHERE IdA3D4 = <ctx-id>
            // AND IdA3C4 = <oem-part-id>
            // AND IdA3A4 = <mfr-part-master-id>
            // FOR UPDATE;
            QuerySpec qs = new QuerySpec();
            qs.setLock(true);
            int idx = qs.appendClassList(AXLEntry.class, true);
            qs.appendWhere(getAXLSearchCondition(AXLContext.class, context), new int[] { idx });
            qs.appendAnd();
            qs.appendWhere(getAXLSearchCondition(WTPart.class, oemPart), new int[] { idx });
            qs.appendAnd();
            qs.appendWhere(getAXLSearchCondition(ManufacturerPartMaster.class, manufacturerPartMaster), new int[] { idx });

            WTHashSet entries = new WTHashSet();
            entries = (WTHashSet) PersistenceHelper.manager.find(qs, entries);
            entries = (WTHashSet) PersistenceHelper.manager.delete(entries);
            for (Iterator i = entries.persistableIterator(); i.hasNext();) {
                AXLEntry entry = (AXLEntry) i.next();
                try{
                    preference = entry.getAmlPreference();
                }catch(WTException sourcingStatusNoMoreExp){
                    // Skip WTException in the case Manufacturer sourcing status preference value invalid then it should be possible
                    // to delete it from UI.
                    if (logger.isDebugEnabled())
                        logger.debug(sourcingStatusNoMoreExp.getLocalizedMessage());
                }
            }

            oldPreference = getOldPreference(oemPart, null, manufacturerPartMaster, context);

            AXLServiceEventData eventData = new AXLServiceEventData(context);
            eventData.setManufacturerPart(manufacturerPartMaster);
            if (oldPreference != null && preference != oldPreference)
            {
                eventData.setOldPreference(oldPreference);
            }
            if (preference != null)
            {
                eventData.setPreference(preference);
            }
            dispatchAXLServiceEvent(AXLServiceEvent.REMOVE_AML, oemPart, eventData);

            trx.commit();
            trx = null;
      }
      finally {
         if (trx != null) {
            trx.rollback();
         }
      }
   }

   /**
    * {@inheritDoc}
    * <BR><BR><B>Supported API: </B>true
    */
   @Override
   public void removeAVL( AXLContext context, WTPart oemPart, VendorPart vendorPart)
            throws WTException {
      validateVendorPart(vendorPart);
      VendorPartMaster vendorPartMaster = (VendorPartMaster)vendorPart.getMaster();
      removeAVL( context, oemPart, vendorPartMaster);

   }

   /**
    * {@inheritDoc}
    * <BR><BR><B>Supported API: </B>true
    */
   @Override
   public void removeAXL( WTSet entries )
            throws WTException {
      if (entries == null || entries.size() == 0) {
          return;
      }

      Transaction trx = new Transaction();

      try {
            trx.start();
            AXLContext context = null;
            WTPart oemPart = null;
            WTKeyedHashMap mfrPartToVdrPartCountMap = new WTKeyedHashMap();
            WTHashSet mfrPartsForRemoval = new WTHashSet();
            WTHashSet vdrPartsForRemoval = new WTHashSet();
            AXLPreference amlPreference = null;
            AXLPreference avlPreference = null;
            AXLPreference oldAvlPreference = null;
            AXLPreference oldAmlPreference = null;
            ManufacturerPartMaster mfrPart = null;
            VendorPartMaster vdrPart = null;

            for (Iterator i = entries.persistableIterator(); i.hasNext();) {
                AXLEntry entry = (AXLEntry) i.next();
                // make sure these entries belong to the same context
                if (context == null) {
                    context = entry.getContext();

                }
                else {
                    if (!context.equals(entry.getContext())) {
                        throw new AXLException(RESOURCE, axlResource.MSG_REMOVE_AXL_MULTIPLE_CONTEXT, null);
                    }
                }

                // make sure these entries belong to the same oem part
                if (oemPart == null) {
                    oemPart = entry.getOemPart();
                }
                else {
                    if (!oemPart.equals(entry.getOemPart())) {
                        throw new AXLException(RESOURCE, axlResource.MSG_REMOVE_AXL_MULTIPLE_OEM_PART, null);
                    }
                }
                try{
                    amlPreference = entry.getAmlPreference();
                    avlPreference = entry.getAvlPreference();
                }catch(WTException sourcingStatusNoMoreExp){
                    // Skip WTException in the case sourcing status preference value changed in rbinfo file after
                    // some entries created with previous value. 
                       if (logger.isDebugEnabled())
                           logger.debug(sourcingStatusNoMoreExp.getLocalizedMessage());
                }
                validateOemPart(oemPart, AXLServiceEvent.REMOVE_AML);

                mfrPart = entry.getManufacturerPart();
                vdrPart = entry.getVendorPart();
                // this is the case where we need to count number of vdr parts and compare it
                // to total number of existing vdr parts for the mfr part in database in order
                // to decide if this is REMOVE_AML - it only applies when those counts match,
                // which means all related vdr parts are removed thus the mfr part should also
                // be removed.
                if (mfrPart != null && vdrPart != null) {
                    if (mfrPartToVdrPartCountMap.containsKey(mfrPart)) {
                        Integer count = (Integer) mfrPartToVdrPartCountMap.get(mfrPart);
                        count = new Integer(count.intValue() + 1);
                    }
                    else {
                        mfrPartToVdrPartCountMap.put(mfrPart, new Integer(1));
                    }
                }

                // for any vdr part we should do REMOVE_AVL
                if (vdrPart != null) {
                    vdrPartsForRemoval.add(vdrPart);
                }

                // for AML entry only, we can safely do REMOVE_AML
                if (vdrPart == null && mfrPart != null) {
                    mfrPartsForRemoval.add(mfrPart);
                }
            }

            // SELECT ClassnameKeyA4, idA3A4, COUNT(idA3B4)
            // FROM AXLEntry
            // WHERE idA3C4 = <oem-part-id>
            // AND idA3D4 = <ctx-id>
            // AND idA3A4 > 0
            // AND idA3B4 > 0
            // GROUP BY ClassnameKeyA4, idA3A4;
            QuerySpec qs = new QuerySpec();
            qs.setAdvancedQueryEnabled(true);
            int idx = qs.appendClassList(AXLEntry.class, false);
            ClassAttribute mfrPartClass = new ClassAttribute(AXLEntry.class, AXLEntry.MFR_PART_CLASSNAME);
            ClassAttribute mfrPartId = new ClassAttribute(AXLEntry.class, AXLEntry.MFR_PART_ID);
            qs.appendSelect(mfrPartClass, idx, false);
            qs.appendSelect(mfrPartId, idx, false);
            qs.appendSelect(SQLFunction.newSQLFunction(SQLFunction.COUNT,
                    new ClassAttribute(AXLEntry.class, AXLEntry.VDR_PART_ID)), false);

            qs.appendWhere(getAXLSearchCondition(AXLContext.class, context), new int[] { idx });
            qs.appendAnd();
            qs.appendWhere(getAXLSearchCondition(WTPart.class, oemPart), new int[] { idx });
            qs.appendAnd();
            qs.appendWhere(new SearchCondition(AXLEntry.class, AXLEntry.MFR_PART_ID,
                    SearchCondition.GREATER_THAN, 0L),
                    new int[] { idx });
            qs.appendAnd();
            qs.appendWhere(new SearchCondition(AXLEntry.class, AXLEntry.VDR_PART_ID,
                    SearchCondition.GREATER_THAN, 0L),
                    new int[] { idx });

            qs.appendGroupBy(mfrPartClass, new int[] { idx }, false);
            qs.appendGroupBy(mfrPartId, new int[] { idx }, false);

            WTKeyedHashMap mfrPartToVdrPartDBCountMap = new WTKeyedHashMap();
            PersistenceServerHelper.manager.query(qs, mfrPartToVdrPartDBCountMap);

            for (Iterator i = mfrPartToVdrPartCountMap.wtKeySet().persistableIterator(); i.hasNext();) {
                ManufacturerPartMaster mfrPart1 = (ManufacturerPartMaster) i.next();
                int rmCount = ((Number) mfrPartToVdrPartDBCountMap.get(mfrPart1)).intValue();
                if (mfrPartToVdrPartDBCountMap.containsKey(mfrPart1)) {
                    int dbCount = ((Number) mfrPartToVdrPartDBCountMap.get(mfrPart1)).intValue();
                    if (rmCount == dbCount) {
                        mfrPartsForRemoval.add(mfrPart1);
                    }
                }
            }

            PersistenceHelper.manager.delete(entries);

            for (Iterator i = vdrPartsForRemoval.persistableIterator(); i.hasNext();) {

                VendorPartMaster ven = (VendorPartMaster) i.next();
                oldAvlPreference = getOldPreference(oemPart, ven, null, context);
                AXLServiceEventData eventData = new AXLServiceEventData(context);
                eventData.setVendorPart(ven);

                if (avlPreference != null)
                    eventData.setPreference(avlPreference);
                if (oldAvlPreference != null && avlPreference != oldAvlPreference)
                    eventData.setOldPreference(oldAvlPreference);
                dispatchAXLServiceEvent(AXLServiceEvent.REMOVE_AVL, oemPart, eventData);
            }
            for (Iterator i = mfrPartsForRemoval.persistableIterator(); i.hasNext();) {

                ManufacturerPartMaster man = (ManufacturerPartMaster) i.next();
                oldAmlPreference = getOldPreference(oemPart, null, man, context);
                AXLServiceEventData eventData = new AXLServiceEventData(context);
                eventData.setManufacturerPart(man);
                if (amlPreference != null)
                    eventData.setPreference(amlPreference);
                if (oldAmlPreference != null && amlPreference != oldAmlPreference)
                    eventData.setOldPreference(oldAmlPreference);
                dispatchAXLServiceEvent(AXLServiceEvent.REMOVE_AML, oemPart, eventData);
            }

            trx.commit();
            trx = null;
        } finally {
            if (trx != null) {
                trx.rollback();
            }
        }
   }


    private AXLPreference getOldPreference(WTPart oemPart, VendorPartMaster venPart, ManufacturerPartMaster manPart, AXLContext context)
            throws WTException {
        AXLPreference oldPreference = null;
        QuerySpec qs = new QuerySpec();
        String axlStr = null;
        SupplierPartMaster supplierPart = null;
        if (manPart != null)
        {
            axlStr = "MODIFY_AML";
            supplierPart = manPart;
        }
        if (venPart != null)
        {
            axlStr = "MODIFY_AVL";
            supplierPart = venPart;
        }
        int idx1 = qs.appendClassList(AXLChangeEvent.class, true);

        qs.appendWhere(new SearchCondition(AXLChangeEvent.class, "oemPartReference.key.id", SearchCondition.EQUAL, oemPart.getPersistInfo()
                .getObjectIdentifier().getId()),
                new int[] { idx1 });
        qs.appendAnd();

        qs.appendWhere(new SearchCondition(AXLChangeEvent.class, "eventKey", SearchCondition.EQUAL,
                "*/com.ptc.windchill.suma.axl.AXLServiceEvent/" + axlStr), new int[] { idx1 });
        qs.appendAnd();
        qs.appendWhere(new SearchCondition(AXLChangeEvent.class, "supplierPartReference.key.id", SearchCondition.EQUAL, supplierPart.getPersistInfo()
                .getObjectIdentifier().getId()),
                new int[] { idx1 });
        qs.appendAnd();
        qs.appendWhere(new SearchCondition(AXLChangeEvent.class, "axlContextReference.key.id", SearchCondition.EQUAL, context.getPersistInfo()
                .getObjectIdentifier().getId()),
                new int[] { idx1 });
        qs.appendOrderBy(new OrderBy(new ClassAttribute(AXLChangeEvent.class, "thePersistInfo.theObjectIdentifier.id"), true),
                new int[] { idx1 });

        QueryResult result = PersistenceHelper.manager.find((StatementSpec) qs);
        if (result.size() != 0)
        {
            Persistable[] obj = (Persistable[]) result.nextElement();
            AXLChangeEvent event = (AXLChangeEvent) obj[0];
            oldPreference = event.getOldPreference();
        }

        return oldPreference;
    }
   @Override
   public void removeAllAXL( AXLContext context, WTPart oemPart )
            throws WTException {
      validateContext(context);
      validateOemPart(oemPart, AXLServiceEvent.REMOVE_AML);

      Transaction trx = new Transaction();
      try {
         trx.start();

         // 1. finds the entries to be deleted
         // SELECT *
         // FROM   AXLEntry
         // WHERE  IdA3D4 = <ctx-id>
         //  AND   IdA3C4 = <oem-part-id>
         // FOR UPDATE;
         QuerySpec qs = new QuerySpec();
         qs.setLock(true);
         int idx = qs.appendClassList(AXLEntry.class, true);
         qs.appendWhere(getAXLSearchCondition(AXLContext.class, context), new int[] {idx});
         qs.appendAnd();
         qs.appendWhere(getAXLSearchCondition(WTPart.class, oemPart), new int[] {idx});

         WTHashSet entries = new WTHashSet();
         entries = (WTHashSet) PersistenceHelper.manager.find(qs, entries);

         // 2. constructs event data
         HashSet<ManufacturerPartMaster> mfrParts = new HashSet<ManufacturerPartMaster>();
         HashSet<VendorPartMaster> vdrParts = new HashSet<VendorPartMaster>();
         for (Iterator i = entries.persistableIterator(); i.hasNext();) {
            AXLEntry entry = (AXLEntry) i.next();
            ManufacturerPartMaster mfrPartMaster = entry.getManufacturerPart();
            VendorPartMaster vdrPartMaster = entry.getVendorPart();
            if (mfrPartMaster != null) {
               mfrParts.add(mfrPartMaster);
            }
            else if (vdrPartMaster != null) {
               vdrParts.add(vdrPartMaster);
            }
            else {
               if (logger.isDebugEnabled()) {
                  logger.debug("warning: neither mfr nor vdr part exists for axl1");
               }
            }
         }

         // 3. removes entries
         entries = (WTHashSet) PersistenceHelper.manager.delete(entries);

         // 4. dispatches events
         // REMOVE_AML event
         if (!mfrParts.isEmpty()) {
            HashSet<AXLServiceEventData> removeAmlEventData = new HashSet<AXLServiceEventData>();
            for (ManufacturerPartMaster mfrPart : mfrParts) {
               AXLServiceEventData eventData = new AXLServiceEventData(context);
               eventData.setManufacturerPart(mfrPart);
               removeAmlEventData.add(eventData);
            }
            dispatchAXLServiceEvent(AXLServiceEvent.REMOVE_AML, oemPart, removeAmlEventData);
         }

         // REMOVE_AVL event
         if (!vdrParts.isEmpty()) {
            HashSet<AXLServiceEventData> removeAvlEventData = new HashSet<AXLServiceEventData>();
            for (VendorPartMaster vdrPart : vdrParts) {
               AXLServiceEventData eventData = new AXLServiceEventData(context);
               eventData.setVendorPart(vdrPart);
               removeAvlEventData.add(eventData);
            }
            dispatchAXLServiceEvent(AXLServiceEvent.REMOVE_AVL, oemPart, removeAvlEventData);
         }

         trx.commit();
         trx = null;
      }
      finally {
         if (trx != null) {
            trx.rollback();
         }
      }
   }

   @Override
   public void setAMLPreference( AXLContext context, WTPart oemPart, ManufacturerPart manufacturerPart, AXLPreference amlPreference )
            throws WTException {
      validateManufacturerPart(manufacturerPart);
      setAMLPreference(context, oemPart, (ManufacturerPartMaster) manufacturerPart.getMaster(), amlPreference);
   }

   @Override
   public void setAMLPreference( AXLContext context, WTPart oemPart, ManufacturerPartMaster manufacturerPartMaster, AXLPreference amlPreference )
            throws WTException {
      validateContext(context);
      validateOemPart(oemPart, AXLServiceEvent.MODIFY_AML);
      validateAMLPreference(amlPreference);

      Transaction trx = new Transaction();
      try {
         trx.start();

         // SELECT *
         // FROM   AXLEntry
         // WHERE  IdA3D4 = <ctx-id>
         //  AND   IdA3C4 = <oem-part-id>
         //  AND   IdA3A4 = <mfr-part-master-id>
         // FOR UPDATE;
         QuerySpec qs = new QuerySpec();
         qs.setLock(true);
         int idx = qs.appendClassList(AXLEntry.class, true);
         qs.appendWhere(getAXLSearchCondition(AXLContext.class, context), new int[] {idx});
         qs.appendAnd();
         qs.appendWhere(getAXLSearchCondition(WTPart.class, oemPart), new int[] {idx});
         qs.appendAnd();
         qs.appendWhere(getAXLSearchCondition(ManufacturerPartMaster.class, manufacturerPartMaster), new int[] {idx});
         WTHashSet entries = new WTHashSet();
         entries = (WTHashSet) PersistenceHelper.manager.find(qs, entries);
         AXLPreference oldPreference = null;
         for (Iterator i = entries.persistableIterator(); i.hasNext();) {
            AXLEntry entry = (AXLEntry) i.next();
            if (oldPreference == null) {
                try{
                    oldPreference = entry.getAmlPreference();
                }catch(WTException sourcingStatusNoMoreExp){
                 // Skip WTException in the case sourcing status preference value changed in rbinfo file after
                 // some entries created with previous value. 
                    if (logger.isDebugEnabled())
                        logger.debug(sourcingStatusNoMoreExp.getLocalizedMessage());
                }
            }
            entry.setAmlPreference(amlPreference);
         }

         entries = (WTHashSet) PersistenceHelper.manager.modify(entries);

         AXLServiceEventData eventData = new AXLServiceEventData(context);
         eventData.setManufacturerPart(manufacturerPartMaster);
         eventData.setPreference(amlPreference);
         eventData.setOldPreference(oldPreference);
         dispatchAXLServiceEvent(AXLServiceEvent.MODIFY_AML, oemPart, eventData);

         trx.commit();
         trx = null;
      }
      catch (WTPropertyVetoException e) {
         logger.error(e.getLocalizedMessage());
         throw new AXLException(e);
      }
      finally {
         if (trx != null) {
            trx.rollback();
         }
      }
   }

   @Override
   public void setAVLPreference( AXLContext context, WTPart oemPart, VendorPart vendorPart, AXLPreference avlPreference )
            throws WTException {
      validateVendorPart(vendorPart);
      setAVLPreference(context, oemPart, (VendorPartMaster) vendorPart.getMaster(), avlPreference);
   }

   @Override
   public void setAVLPreference( AXLContext context, WTPart oemPart, VendorPartMaster vendorPartMaster, AXLPreference avlPreference )
            throws WTException {
      validateOemPart(oemPart, AXLServiceEvent.MODIFY_AVL);
      validateAVLPreference(avlPreference);

      QuerySpec qs = new QuerySpec();
      int idx = qs.appendClassList(AXLEntry.class, true);

      qs.appendWhere(getAXLSearchCondition(AXLContext.class, context), new int[] {idx});
      qs.appendAnd();
      qs.appendWhere(getAXLSearchCondition(WTPart.class, oemPart), new int[] {idx});
      qs.appendAnd();
      qs.appendWhere(getAXLSearchCondition(VendorPartMaster.class, vendorPartMaster), new int[] {idx});
      QueryResult qr = PersistenceHelper.manager.find(qs);
      if (qr.size() == 0) {
         logger.error("No axl with oem part " +
                  oemPart.getIdentity() + " vendor part " +
                  vendorPartMaster.getIdentity());
         throw new AXLDoesNotExistException(RESOURCE, axlResource.MSG_NO_AXL_WITH_OEM_PART_VDR_PART, new Object[] {oemPart.getIdentity(), vendorPartMaster.getIdentity()});
      }
      else if (qr.size() > 1) {
         logger.error("To many axl with oem part " +
                  oemPart.getIdentity() + " vendor part " +
                  vendorPartMaster.getIdentity());
         throw new AXLException(RESOURCE, axlResource.MSG_TOO_MANY_AXL_WITH_OEM_PART_VDR_PART, new Object[] {oemPart.getIdentity(), vendorPartMaster.getIdentity()});
      }

      try {
         AXLEntry entry = (AXLEntry) unfoldQueryResult(qr);

         AXLServiceEventData eventData = new AXLServiceEventData(context);
         eventData.setVendorPart(vendorPartMaster);
         try{
             eventData.setOldPreference(entry.getAvlPreference());
         }catch(WTException sourcingStatusNoMoreExp){
          // Skip WTException in the case sourcing status preference value changed in rbinfo file after
          // some entries created with previous value. 
             if (logger.isDebugEnabled())
                 logger.debug(sourcingStatusNoMoreExp.getLocalizedMessage());
         }

         entry.setAvlPreference(avlPreference);
         entry = (AXLEntry) PersistenceHelper.manager.modify(entry);

         eventData.setPreference(avlPreference);
         eventData.setEntryId(entry.getPersistInfo().getObjectIdentifier().getId());

         dispatchAXLServiceEvent(AXLServiceEvent.MODIFY_AVL, oemPart, eventData);
      }
      catch (WTPropertyVetoException e) {
         logger.error(e.getLocalizedMessage());
         throw new AXLException(e);
      }
   }

   @Override
   public WTCollection getAXL( WTPart oem_part, AXLContext context )
            throws WTException {
      if(oem_part == null) throw new WTException();
      if(context == null) throw new WTException();

      QuerySpec qs = constructAXLQuerySpec(oem_part, context, null);
      if (logger.isTraceEnabled()) logger.trace("qs = " + qs);
      WTArrayList entries = new WTArrayList();
      entries =  (WTArrayList) PersistenceHelper.manager.find(qs, entries);
      if (logger.isDebugEnabled()) logger.debug("found " + entries.size() + " AXL entries.");
      return entries;
   }

   /**
    * {@inheritDoc}
    * <BR><BR><B>Supported API: </B>true
    */
   @Override
   public WTCollection getAML( WTPart oem_part, AXLContext context )
            throws WTException {
      QuerySpec qs = constructAXLQuerySpec(oem_part, context, ManufacturerPartMaster.class);
      if (logger.isTraceEnabled()) logger.trace("qs = " + qs);
      WTArrayList entries = new WTArrayList();
      HashSet<ObjectReference> mfr_parts = new HashSet<ObjectReference>();
      QueryResult qr = PersistenceHelper.manager.find((StatementSpec) qs);
      while (qr.hasMoreElements()) {
         AXLEntry entry = (AXLEntry) qr.nextElement();
         ObjectReference mp = entry.getManufacturerPartReference();
         assert(mp != null);
         if (!mfr_parts.contains(mp)) {
            mfr_parts.add(mp);
            entries.add(entry);
         }
         else {
            if (logger.isDebugEnabled()) logger.debug("skip duplicate mfr part " + mp);
         }
      }
      if (logger.isDebugEnabled()) logger.debug("found " + entries.size() + " AML entries.");
      return entries;
   }

   /**
    * {@inheritDoc}
    * <BR><BR><B>Supported API: </B>true
    */
   @Override
   public WTCollection getAVL( WTPart oem_part, AXLContext context, ManufacturerPartMaster mfr_part_master )
            throws WTException {
      QuerySpec qs = constructAXLQuerySpec(oem_part, context, VendorPartMaster.class);
      if (mfr_part_master != null) {
         if (qs.getConditionCount() > 0) qs.appendAnd();
         qs.appendWhere(getAXLSearchCondition(ManufacturerPartMaster.class, mfr_part_master), new int[] {0});
      }
      if (logger.isTraceEnabled()) logger.trace("qs = " + qs);

      WTArrayList entries = new WTArrayList();
      entries =  (WTArrayList) PersistenceHelper.manager.find(qs, entries);
      if (logger.isDebugEnabled()) logger.debug("found " + entries.size() + " AVL entries.");
      return entries;
   }

   @Override
   public AXLPreference getAMLPreference( AXLContext context, WTPart oemPart, ManufacturerPart manufacturerPart )
            throws WTException {
      validateManufacturerPart(manufacturerPart);
      return getAMLPreference(context, oemPart, (ManufacturerPartMaster) manufacturerPart.getMaster());
   }

   @Override
   public AXLPreference getAVLPreference( AXLContext context, WTPart oemPart, VendorPart vendorPart )
            throws WTException {
      validateVendorPart(vendorPart);
      return getAVLPreference(context, oemPart, (VendorPartMaster) vendorPart.getMaster());
   }

   @Override
   public AXLPreference getOEMPreference( AXLContext context, WTPart oemPart )
            throws WTException {
      OEMPartAXLContextLink link = getLink(context, oemPart);
      if (link == null) {
         throw new AXLException(RESOURCE, axlResource.MSG_OEM_PART_HAS_NO_AML_IN_CONTEXT,
            new Object[] {oemPart.getIdentity(), context.getName()});
      }
      return link.getOemPreference();
   }

   @Override
   public WTKeyedMap getOEMPreferencesForDisplay( AXLContext context, WTCollection oemParts, boolean includeIcon, boolean includeText )
            throws WTException {
      validateContext(context);
      if (oemParts == null || oemParts.size() == 0) {
         return null;
      }

      // at least one of includeIcon and includeText should be true, otherwise nothing to return
      if (!includeIcon && !includeText) {
         throw new AXLException(RESOURCE, axlResource.MSG_NONE_OF_ICON_AND_TEXT_REQUESTED, null);
      }

      // SELECT part.ClassnameA2A2, part.IdA2A2, part.source,
      //        link.oemPreference, link.singleSource
      // FROM   OEMPartAXLContextLink link, WTPart part
      // WHERE  link.IdA3B5(+) = <ctx-id>
      //  AND   link.IdA3A5(+) = part.IdA2A2
      //  AND   link.IdA3A5 IN <oem-ids>;

      try {
         QuerySpec qs = new QuerySpec();
         qs.setAdvancedQueryEnabled(true);

         ClassViewExpression partTable = getOEMPartClassViewExpression();
         ClassViewExpression linkTable = new ClassViewExpression(OEMPartAXLContextLink.class);
         List excludeClassList = new ArrayList();
         excludeClassList.add(SupplierPart.class);
         partTable.setExcludedDescendants(excludeClassList);

         int idxPart = qs.appendFrom(partTable);
         int idxLink = qs.appendFrom(linkTable);

         qs.appendSelectAttribute(WTAttributeNameIfc.OID_CLASSNAME, idxPart, false);
         qs.appendSelectAttribute(WTAttributeNameIfc.ID_NAME, idxPart, false);
         qs.appendSelectAttribute(WTPart.SOURCE, idxPart, false);
         qs.appendSelectAttribute(OEMPartAXLContextLink.OEM_PREFERENCE_DATA, idxLink, false);
         qs.appendSelectAttribute(OEMPartAXLContextLink.SINGLE_SOURCE, idxLink, false);

         SearchCondition sc = null;
         sc = new SearchCondition(OEMPartAXLContextLink.class,
                                  OEMPartAXLContextLink.CONTEXT_ID,
                                  SearchCondition.EQUAL,
                                  context.getPersistInfo().getObjectIdentifier().getId());
         sc.setOuterJoin(SearchCondition.LEFT_OUTER_JOIN);
         qs.appendWhere(sc, new int[] {idxLink});

         qs.appendAnd();
         sc = new SearchCondition(WTPart.class, WTAttributeNameIfc.ID_NAME,
                                  OEMPartAXLContextLink.class, OEMPartAXLContextLink.OEM_PART_ID);
         sc.setOuterJoin(SearchCondition.RIGHT_OUTER_JOIN);
         qs.appendWhere(sc, new int[] {idxPart, idxLink});

         qs.appendAnd();
         qs.appendWhere(new SearchCondition(WTPart.class,
                                            WTAttributeNameIfc.ID_NAME,
                                            oemParts.toIdArray()),
                        new int[] {idxPart});

         logger.trace("qs = " + qs.toString());
         QueryResult qr = PersistenceServerHelper.manager.query(qs);

         String resourceKey = (includeIcon && includeText) ? axlResource.GUI_OEM_PREFERENCE_ICON_AND_TEXT
                                                           : includeIcon ? axlResource.GUI_OEM_PREFERENCE_ICON_ONLY
                                                           : axlResource.GUI_OEM_PREFERENCE_TEXT_ONLY;
         WTKeyedHashMap map = new WTKeyedHashMap();
         while (qr.hasMoreElements()) {
            Object[] o = (Object[]) qr.nextElement();
            if (o.length != 5) {
               throw new AXLException(RESOURCE, axlResource.MSG_UNEXPECTED_QUERY_RESULT, null);
            }

            ObjectIdentifier key = ObjectIdentifier.newObjectIdentifier(Class.forName((String) o[0]), ((Number) o[1]).longValue());
            Source source = (Source) o[2];
            WTMessage message = null;
            Object pref = o[3];
            if (!SumaConfigHelper.isOEMPart(source)) {
               message = null;
            }
            else {
               if (pref == null || ((Number) pref).intValue() == 0) { // no aml at all, show warning, no need to proceed
                  message = new WTMessage(RESOURCE, resourceKey, new Object[] {
                              AXLHelper.getOEMPreferenceIconURL(new NoAmlIconSelector()),
                              new WTMessage(RESOURCE, axlResource.GUI_OEM_PREFERENCE_NO_AML_TEXT, null)});
               }
               else { // pref is ok, has aml
                  boolean isSingleSource = ((Number) o[4]).intValue() == 1;
                  AXLPreference oemPreference = AXLHelper.intToPreference(((Number) pref).intValue());
                  // must be multi source OEM part, show single source warning if applicable
                  if (isSingleSource && SumaConfigHelper.isMultiSourceOEMPart(source)) {
                     message = new WTMessage(RESOURCE, resourceKey, new Object[] {
                                 AXLHelper.getOEMPreferenceIconURL(new SingleSourceIconSelector(oemPreference)),
                                 new WTMessage(RESOURCE, resourceKey, new Object[] {
                                   AXLHelper.getOEMPreferenceIconURL(new DefaultIconSelector(oemPreference)), oemPreference})});
                  }
                  else { // preference without any decorations
                   message = new WTMessage(RESOURCE, resourceKey, new Object[] {
                        AXLHelper.getOEMPreferenceIconURL(new DefaultIconSelector(oemPreference)), oemPreference});
                  }
               }
            }
            map.put(key, message);
            logger.debug("" + o[0] + "/" + o[1] + "/" + o[2] +"/" + o[3] + "/" + o[4]
                              + (message == null ? "" : message.getLocalizedMessage()));
         }

         return map;
      }
      catch (WTPropertyVetoException e) {
         throw new AXLException(e);
      }
      catch (ClassNotFoundException e) {
         throw new AXLException(e);
      }
   }

   @Override
   public WTKeyedMap getContextOEMPreferenceMap( WTPart oemPart )
            throws WTException {
      validateOemPart(oemPart, null);

      // SELECT CLASSNAMEKEYROLEBOBJECTREF, IdA3B5, oemPreference
      // FROM   OEMPartAXLContextLink
      // WHERE  IdA3A5 = <oem-part-id>;

      QuerySpec qs = new QuerySpec();
      int idx = qs.appendClassList(OEMPartAXLContextLink.class, false);
      qs.appendSelectAttribute(OEMPartAXLContextLink.CONTEXT_CLASSNAME, idx, false);
      qs.appendSelectAttribute(OEMPartAXLContextLink.CONTEXT_ID, idx, false);
      qs.appendSelectAttribute(OEMPartAXLContextLink.OEM_PREFERENCE_DATA, idx, false);

      qs.appendWhere(new SearchCondition(OEMPartAXLContextLink.class, OEMPartAXLContextLink.OEM_PART_ID,
                                         SearchCondition.EQUAL, oemPart.getPersistInfo().getObjectIdentifier().getId()),
                     new int[] {idx});
      WTKeyedHashMap map = new WTKeyedHashMap();
      return (WTKeyedHashMap) PersistenceHelper.manager.find(qs, map);
   }


    @Override
    public Map<ObjectIdentifier, WTKeyedMap> getWTPartContextOEMPreferenceMap(WTCollection oemParts) throws WTException {

        // SELECT CLASSNAMEKEYROLEBOBJECTREF, IdA3A5,
        // CLASSNAMEKEYROLEBOBJECTREF,IdA3B5, oemPreference
        // FROM OEMPartAXLContextLink
        // WHERE IdA3A5 IN <oem-part-ids>;

        QuerySpec qs = new QuerySpec();
        int idx = qs.appendClassList(OEMPartAXLContextLink.class, false);
        qs.appendSelectAttribute(OEM_PART_CLASSNAME, idx, false);
        qs.appendSelectAttribute(OEM_PART_ID, idx, false);
        qs.appendSelectAttribute(CONTEXT_CLASSNAME, idx, false);
        qs.appendSelectAttribute(CONTEXT_ID, idx, false);
        qs.appendSelectAttribute(OEM_PREFERENCE_DATA, idx, false);
        qs.appendWhere(new SearchCondition(new ClassAttribute(OEMPartAXLContextLink.class, OEM_PART_ID), SearchCondition.IN,
                new ArrayExpression(oemParts.toIdArray())), new int[] { idx });
        Map<ObjectIdentifier, WTKeyedMap> partToContextPrefMap = new HashMap<ObjectIdentifier, WTKeyedMap>();
        QueryResult qr = PersistenceHelper.manager.find(qs);
        while (qr.hasMoreElements()) {
            Object[] o = (Object[]) qr.nextElement();
            if (o.length != 5) {
                throw new AXLException(RESOURCE, axlResource.MSG_UNEXPECTED_QUERY_RESULT, null);
            }
            try {
                ObjectIdentifier part = ObjectIdentifier.newObjectIdentifier(Class.forName((String) o[0]), ((Number) o[1]).longValue());
                ObjectIdentifier sourcingContext = ObjectIdentifier.newObjectIdentifier(Class.forName((String) o[2]), ((Number) o[3]).longValue());
                Object preference = o[4];
                WTKeyedHashMap contextPreferenceMap = (WTKeyedHashMap) partToContextPrefMap.get(part);
                if (contextPreferenceMap == null) {
                    contextPreferenceMap = new WTKeyedHashMap();
                    partToContextPrefMap.put(part, contextPreferenceMap);
                }
                contextPreferenceMap.put(sourcingContext, preference);

            } catch (ClassNotFoundException e) {
                logger.debug("err", e);
            }

        }
        return partToContextPrefMap;
    }

   @Override
   public WTKeyedMap getContextToStatusMap( WTPart oemPart )
            throws WTException {
      validateOemPart(oemPart, null);

      // SELECT CLASSNAMEKEYROLEBOBJECTREF, IdA3B5, oemPreference, isSingleSource
      // FROM   OEMPartAXLContextLink
      // WHERE  IdA3A5 = <oem-part-id>;

      try {
         QuerySpec qs = new QuerySpec();
         int idx = qs.appendClassList(OEMPartAXLContextLink.class, false);
         qs.appendSelectAttribute(OEMPartAXLContextLink.CONTEXT_CLASSNAME, idx, false);
         qs.appendSelectAttribute(OEMPartAXLContextLink.CONTEXT_ID, idx, false);
         qs.appendSelectAttribute(OEMPartAXLContextLink.OEM_PREFERENCE_DATA, idx, false);
         qs.appendSelectAttribute(OEMPartAXLContextLink.SINGLE_SOURCE, idx, false);

         qs.appendWhere(new SearchCondition(OEMPartAXLContextLink.class, OEMPartAXLContextLink.OEM_PART_ID,
                                            SearchCondition.EQUAL, oemPart.getPersistInfo().getObjectIdentifier().getId()),
                        new int[] {idx});
         QueryResult qr = PersistenceHelper.manager.find(qs);
         WTKeyedHashMap map = new WTKeyedHashMap();
         Source source = oemPart.getSource();
         while (qr.hasMoreElements()) {
            Object[] o = (Object[]) qr.nextElement();
            if (o.length != 4) {
               throw new AXLException(RESOURCE, axlResource.MSG_UNEXPECTED_QUERY_RESULT, null);
            }

            ObjectIdentifier key = ObjectIdentifier.newObjectIdentifier(Class.forName((String) o[0]), ((Number) o[1]).longValue());
            Object pref = o[2];
            SourcingStatus status = null;
            if (SumaConfigHelper.isOEMPart(source)) {
               if (pref == null || ((Number) pref).intValue() == 0) { // no aml at all
                  status = (SourcingStatus) SourcingStatusFactory.getInstance().getSourcingStatus(new SourcingStatusSelector(source));
               }
               else { // pref is ok, has aml
                  boolean isSingleSource = ((Number) o[3]).intValue() == 1;
                  isSingleSource = isSingleSource && SumaConfigHelper.isMultiSourceOEMPart(source);
                  AXLPreference oemPreference = AXLHelper.intToPreference(((Number) pref).intValue());
                  status = (SourcingStatus) SourcingStatusFactory.getInstance().getSourcingStatus(
                     new SourcingStatusSelector(source, isSingleSource, oemPreference));
               }
            }
            map.put(key, status);
            logger.debug("getContextToStatusMap:" + o[0] + "/" + o[1] + "/" + o[2] +"/" + o[3] + ":" + status);
         }

         return map;
      }
      catch (ClassNotFoundException e) {
         throw new AXLException(e);
      }
   }

   @Override
   public WTKeyedMap getPartToStatusMap( AXLContext context, WTCollection oemParts )
            throws WTException {
      validateContext(context);
      if (oemParts == null || oemParts.size() == 0) {
         return null;
      }

      // SELECT part.ClassnameA2A2, part.IdA2A2, part.source,
      //        link.oemPreference, link.singleSource
      // FROM   OEMPartAXLContextLink link, WTPart part
      // WHERE  link.IdA3B5(+) = <ctx-id>
      //  AND   link.IdA3A5(+) = part.IdA2A2
      //  AND   link.IdA3A5 IN <oem-ids>;

      try {
         QuerySpec qs = new QuerySpec();
         qs.setAdvancedQueryEnabled(true);

         ClassViewExpression partTable = getOEMPartClassViewExpression();
         ClassViewExpression linkTable = new ClassViewExpression(OEMPartAXLContextLink.class);
         List excludeClassList = new ArrayList();
         excludeClassList.add(SupplierPart.class);
         partTable.setExcludedDescendants(excludeClassList);

         int idxPart = qs.appendFrom(partTable);
         int idxLink = qs.appendFrom(linkTable);

         qs.appendSelectAttribute(WTAttributeNameIfc.OID_CLASSNAME, idxPart, false);
         qs.appendSelectAttribute(WTAttributeNameIfc.ID_NAME, idxPart, false);
         qs.appendSelectAttribute(WTPart.SOURCE, idxPart, false);
         qs.appendSelectAttribute(OEMPartAXLContextLink.OEM_PREFERENCE_DATA, idxLink, false);
         qs.appendSelectAttribute(OEMPartAXLContextLink.SINGLE_SOURCE, idxLink, false);

         SearchCondition sc = null;
         sc = new SearchCondition(OEMPartAXLContextLink.class,
                                  OEMPartAXLContextLink.CONTEXT_ID,
                                  SearchCondition.EQUAL,
                                  context.getPersistInfo().getObjectIdentifier().getId());
         sc.setOuterJoin(SearchCondition.LEFT_OUTER_JOIN);
         qs.appendWhere(sc, new int[] {idxLink});

         qs.appendAnd();
         sc = new SearchCondition(WTPart.class, WTAttributeNameIfc.ID_NAME,
                                  OEMPartAXLContextLink.class, OEMPartAXLContextLink.OEM_PART_ID);
         sc.setOuterJoin(SearchCondition.RIGHT_OUTER_JOIN);
         qs.appendWhere(sc, new int[] {idxPart, idxLink});

         qs.appendAnd();
         qs.appendWhere(new SearchCondition(WTPart.class,
                                            WTAttributeNameIfc.ID_NAME,
                                            oemParts.toIdArray()),
                        new int[] {idxPart});

         logger.trace("queryspec = " + qs.toString());
         QueryResult qr = PersistenceServerHelper.manager.query(qs);

         WTKeyedHashMap map = new WTKeyedHashMap();
         while (qr.hasMoreElements()) {
            Object[] o = (Object[]) qr.nextElement();
            if (o.length != 5) {
               throw new AXLException(RESOURCE, axlResource.MSG_UNEXPECTED_QUERY_RESULT, null);
            }

            ObjectIdentifier key = ObjectIdentifier.newObjectIdentifier(Class.forName((String) o[0]), ((Number) o[1]).longValue());
            Source source = (Source) o[2];
            Object pref = o[3];
            SourcingStatusFactory statusFactory = SourcingStatusFactory.getInstance();
            SourcingStatus status = null;
            if (SumaConfigHelper.isOEMPart(source)) {
               if (pref == null || ((Number) pref).intValue() == 0) { // no aml at all, show warning, no need to proceed
                  status = (SourcingStatus) statusFactory.getSourcingStatus(new SourcingStatusSelector(source));
               }
               else { // pref is ok, has aml
                  boolean isSingleSource = ((Number) o[4]).intValue() == 1;
                  isSingleSource = isSingleSource && SumaConfigHelper.isMultiSourceOEMPart(source);
                  AXLPreference oemPreference = AXLHelper.intToPreference(((Number) pref).intValue());
                  status = (SourcingStatus) statusFactory.getSourcingStatus(
                     new SourcingStatusSelector(source, isSingleSource, oemPreference));
               }
            }
            map.put(key, status);
            logger.debug("getPartToStatusMap:" + o[0] + "/" + o[1] + "/" + o[2] +"/" + o[3] + "/" + o[4] + ":" + status);
         }

         return map;
      }
      catch (WTPropertyVetoException e) {
         throw new AXLException(e);
      }
      catch (ClassNotFoundException e) {
         throw new AXLException(e);
      }
   }

   /**
    * {@inheritDoc}
    * <BR><BR><B>Supported API: </B>true
    */
   @Override
   public WTCollection getManufacturerParts( AXLContext context, WTPart oemPart )
            throws WTException {
       QueryResult qr = findManufacturerParts(context, oemPart);
       // Flat result to remove arrays
       ObjectVector ov = new ObjectVector();
       while (qr.hasMoreElements()) ov.addElement(qr.nextElement());
       qr = new QueryResult(ov);
       // Get latest iteration of supplier parts given supplier masters
       QueryResult partsQr = ConfigHelper.service.filteredIterationsOf(qr, new LatestConfigSpec());
       WTCollection result = new WTHashSet(partsQr);
       if(logger.isTraceEnabled()) logger.trace("manufacturer parts result = " + result);
      return result;
   }

   /**
    * {@inheritDoc}
    * <BR><BR><B>Supported API: </B>true
    */
   @Override
   public WTCollection getVendorParts( AXLContext context, WTPart oemPart )
            throws WTException {
      return getVendorParts(context, oemPart, (ManufacturerPart) null);
   }

   /**
    * {@inheritDoc}
    * <BR><BR><B>Supported API: </B>true
    */
   @Override
   public WTCollection getVendorParts( AXLContext context, WTPart oemPart, ManufacturerPart manufacturerPart )
            throws WTException {
       ManufacturerPartMaster mpm = manufacturerPart == null ? null : (ManufacturerPartMaster) manufacturerPart.getMaster();
       return getVendorParts(context, oemPart, mpm);
   }

   /**
    * {@inheritDoc}
    * <BR><BR><B>Supported API: </B>true
    */
   @Override
   public WTCollection getVendorParts( AXLEntry aml )
            throws WTException {
      return getVendorParts(aml.getContext(), aml.getOemPart(), aml.getManufacturerPart());
   }

   /**
    * {@inheritDoc}
    * <BR><BR><B>Supported API: </B>true
    */
   @Override
   public WTCollection getSupplierParts( AXLContext context, WTPart oemPart )
            throws WTException {
      QueryResult mQr = findManufacturerParts(context, oemPart);
      // Flat result to remove arrays
      ObjectVector ov = new ObjectVector();
      while (mQr.hasMoreElements()) ov.addElement(mQr.nextElement());
      QueryResult vQr = findVendorParts(context, oemPart, null);
      while (vQr.hasMoreElements()) ov.addElement(vQr.nextElement());
      QueryResult sQr = new QueryResult(ov);
      // Get latest iteration of supplier parts given supplier masters
      QueryResult partsQr = ConfigHelper.service.filteredIterationsOf(sQr, new LatestConfigSpec());
      WTCollection result = new WTHashSet(partsQr);
      if(logger.isTraceEnabled()) logger.trace("supplier parts result = " + result);
      return result;
   }

   private QueryResult findManufacturerParts(AXLContext context, WTPart oemPart) throws QueryException, WTException {
      // SELECT A0.*
      // FROM ManufacturerPartMaster mfrM,
      //      AXLEntry axl
      // WHERE axl.idA3D4 = <ctx-id>
      //       AND axl.idA3C4 = <oem-part-id>
      //       AND mfrM.idA2A2 = axl.idA3A4
      QuerySpec mQs = new QuerySpec();
      int idxMnfr = mQs.appendClassList(ManufacturerPartMaster.class, true);
      int idxAxlEntry = mQs.appendClassList(AXLEntry.class, false);
      if (context != null) {
          mQs.appendWhere(getAXLSearchCondition(AXLContext.class, context), new int[] {idxAxlEntry});
          mQs.appendAnd();
      }
      mQs.appendWhere(getAXLSearchCondition(WTPart.class, oemPart), new int[] {idxAxlEntry});
      mQs.appendAnd();
      mQs.appendWhere(new SearchCondition(ManufacturerPartMaster.class, WTAttributeNameIfc.ID_NAME, AXLEntry.class,AXLEntry.MFR_PART_ID),   new int[]{idxMnfr,idxAxlEntry});
      if(logger.isTraceEnabled()) logger.trace("mQs = " + mQs.toString());
      QueryResult mQr = PersistenceHelper.manager.find((StatementSpec)mQs);
      return mQr;
   }

   private QueryResult findVendorParts(AXLContext context, WTPart oemPart, ManufacturerPartMaster manufacturerPartMaster) throws QueryException, WTException {
      // SELECT A0.*
      // FROM VendorPartMaster vdrM,
      //      AXLEntry axl
      // WHERE axl.idA3D4 = <ctx-id>
      //       AND axl.idA3C4 = <oem-part-id>
      //       AND vdrM.idA2A2 = axl.idA3B4
      //       AND axl.idA3A4 = <mfr-part-master-id>
      QuerySpec vQs = new QuerySpec();
      int idxVnrd = vQs.appendClassList(VendorPartMaster.class, true);
      int idxAxlEntry = vQs.appendClassList(AXLEntry.class, false);
      vQs.setSelect(idxVnrd, true);
      if (context != null) {
         vQs.appendWhere(getAXLSearchCondition(AXLContext.class, context), new int[] {idxAxlEntry});
         vQs.appendAnd();
      }
      vQs.appendWhere(getAXLSearchCondition(WTPart.class, oemPart), new int[] {idxAxlEntry});
      vQs.appendAnd();
      vQs.appendWhere(new SearchCondition(VendorPartMaster.class, WTAttributeNameIfc.ID_NAME, AXLEntry.class,AXLEntry.VDR_PART_ID),    new int[]{idxVnrd,idxAxlEntry});
      if (manufacturerPartMaster != null) {
          vQs.appendAnd();
          vQs.appendWhere(getAXLSearchCondition(ManufacturerPartMaster.class, manufacturerPartMaster), new int[]{idxAxlEntry});
      }
      if(logger.isTraceEnabled()) logger.trace("vQs = " + vQs.toString());
      QueryResult vQr = PersistenceHelper.manager.find((StatementSpec)vQs);
      return vQr;
   }

   @Override
   public boolean isSingleSourceForMultiSourceOEMPart( AXLContext context, WTPart oemPart )
            throws WTException {
      validateContext(context);
      validateOemPart(oemPart, null);
      if (!SumaConfigHelper.isMultiSourceOEMPart(oemPart.getSource())) {
         return false;
      }

      OEMPartAXLContextLink link = getLink(context, oemPart);
      return (link != null) && link.isSingleSource();
   }
//
//   @Override
//   public boolean isMultiSourceForSingleSourceOEMPart( AXLContext context, WTPart oemPart )
//            throws WTException {
//      validateContext(context);
//      validateOemPart(oemPart, null);
//      if (!SumaConfigHelper.isSingleSourceOEMPart(oemPart.getSource())) {
//         return false;
//      }
//
//      OEMPartAXLContextLink link = getLink(context, oemPart);
//      return (link != null) && !link.isSingleSource();
//   }

   @Override
   public boolean hasAML( AXLContext context, WTPart oemPart )
            throws WTException {
      // SELECT 1
      // FROM [NullTableExpression]
      // WHERE EXISTS (
      //    SELECT axl.IdA2A2
      //    FROM AXLEntry axl
      //    WHERE axl.IdA3D4 = <ctt-id>
      //    AND   axl.IdA3C4 = <oem-part-id>
      //    AND   axl.IdA3A4 > 0
      // )
      QuerySpec qs = new QuerySpec();
      qs.setAdvancedQueryEnabled( true );
      qs.appendSelect(new ConstantExpression(Boolean.TRUE), false);
      int idxNull = qs.appendFrom(new NullTableExpression());
      QuerySpec qsSub = new QuerySpec();
      int idxEntry = qsSub.appendClassList(AXLEntry.class, false);
      qsSub.appendSelectAttribute(WTAttributeNameIfc.ID_NAME, idxEntry, true);
      if (context != null) {
      qsSub.appendWhere(getAXLSearchCondition(AXLContext.class, context), new int[] {idxEntry});
      qsSub.appendAnd();
      }
      qsSub.appendWhere(getAXLSearchCondition(WTPart.class, oemPart), new int[] {idxEntry});
      qsSub.appendAnd();
      qsSub.appendWhere(new SearchCondition(AXLEntry.class,
                                            AXLEntry.MFR_PART_ID,
                                            SearchCondition.GREATER_THAN,
                                            0L),
                        new int[] {idxEntry});
      qsSub.setAdvancedQueryEnabled(true);
      qs.appendWhere(new ExistsExpression(qsSub), new int[] {idxNull});
      QueryResult qr = PersistenceHelper.manager.find(qs);
      return qr.hasMoreElements();
   }

   @Override
   public boolean hasAML( AXLContext context, WTPart oemPart, ManufacturerPart manufacturerPart )
            throws WTException {
      validateManufacturerPart(manufacturerPart);
      return hasAML(context, oemPart, (ManufacturerPartMaster) manufacturerPart.getMaster());
   }

   @Override
   public boolean hasAVL( AXLContext context, WTPart oemPart, VendorPart vendorPart )
            throws WTException {
      validateVendorPart(vendorPart);
      return hasAVL(context, oemPart, (VendorPartMaster) vendorPart.getMaster());
   }

   @Override
   public boolean hasAMLOrAVL( AXLContext context, WTPart oemPart, ManufacturerPart manufacturerPart, VendorPart vendorPart )
            throws WTException {
      validateManufacturerPart(manufacturerPart);
      validateVendorPart(vendorPart);
      return hasAMLOrAVL(context, oemPart, (ManufacturerPartMaster) manufacturerPart.getMaster(), (VendorPartMaster) vendorPart.getMaster());
   }

   @Override
   public boolean hasAXL( AXLContext context, WTPart oemPart, ManufacturerPart manufacturerPart, VendorPart vendorPart )
            throws WTException {
      validateManufacturerPart(manufacturerPart);
      validateVendorPart(vendorPart);
      return hasAXL(context, oemPart, (ManufacturerPartMaster) manufacturerPart.getMaster(), (VendorPartMaster) vendorPart.getMaster());
   }

   @Override
   public boolean hasAnyAXL( AXLContext context, WTPart oemPart )
            throws WTException {
      return hasAXL(context, oemPart, (ManufacturerPartMaster) null, (VendorPartMaster) null);
   }

   @Override
   public AXLContext getContext( WTContainerRef container, String name )
            throws WTException {
      if (container == null) {
         logger.error("container reference is null");
         throw new AXLException(RESOURCE, axlResource.MSG_CONTAINER_REFERENCE_IS_NULL, null);
      }

      if (name == null) {
         logger.error("sourcing context name is null");
         throw new AXLException(RESOURCE, axlResource.MSG_CONTEXT_NAME_IS_NULL, null);
      }

      if (!OrgContainer.class.isAssignableFrom(container.getReferencedClass())) {
         logger.error("container is not an org container");
         throw new AXLException(RESOURCE, axlResource.MSG_CONTAINER_IS_NOT_ORG_CONTAINER, null);
      }

      AXLContext result = AXLContextCache.getInstance().get(container,name,/*read only*/false);
      if (!AccessControlHelper.manager.hasAccess(result, AccessPermission.READ)) {
         result = null;
      }
      return result;
   }

   @Override
   public WTCollection getContexts( WTContainerRef container )
            throws WTException {
      QuerySpec qs = new QuerySpec(AXLContext.class);
      qs.appendWhere(new SearchCondition(AXLContext.class, AXLContext.IS_DEFAULT, false), new int[] {0});
      if (container != null) {
         qs.appendAnd();
         qs.appendWhere(WTContainerHelper.getWhereContainerIs(container), new int[] {0});
      }
      QueryResult qr = PersistenceHelper.manager.find((StatementSpec) qs);
      if (logger.isDebugEnabled()) logger.debug("found " + qr.size() + " sourcing contexts");
      return SupplierHelper.toWTCollection(qr);
   }

   @Override
   public AXLContext getDefaultContext( WTContainerRef container )
            throws WTException {
      if (container == null) {
         throw new AXLException(RESOURCE, axlResource.MSG_ORG_CONTAINER_IS_NULL, null);
      }

      if (!OrgContainer.class.isAssignableFrom(container.getReferencedClass())) {
         throw new AXLException(RESOURCE, axlResource.MSG_CONTAINER_IS_NOT_ORG_CONTAINER, null);
      }

      AXLContext result = AXLContextCache.getInstance().get(container,/*read only*/false);
      if (result == null) {
         logger.log(Level.INFO, "Creating default context. Container: " + container);
         result = createDefaultContext(container);
      }
      if (!AccessControlHelper.manager.hasAccess(result, AccessPermission.READ)) {
         result = null;
      }
      return result;
   }

   @Override
   public AXLEntry saveAs( AXLEntry entry, AXLContext anotherContext )
            throws WTException {
      validateAXLEntry(entry);
      if (entry.getContext().equals(anotherContext)) {
         throw new AXLException(RESOURCE, axlResource.MSG_CANNOT_SAVE_AS_INTO_SAME_CONTEXT, null);
      }

      WTPart oem = entry.getOemPart();
      ManufacturerPartMaster mfr = entry.getManufacturerPart();
      VendorPartMaster vdr = entry.getVendorPart();

      AXLPreference amlPref = getAnotherContextPreference( oem, mfr, anotherContext, entry );
      AXLPreference avlPref = getAnotherContextPreference( oem, vdr, anotherContext, entry );

      boolean hasMfr = mfr != null;
      boolean hasVdr = vdr != null;
      boolean hasAVL = hasAVL(anotherContext, oem, vdr);
      boolean hasAML = hasAML(anotherContext, oem, mfr);

      if (hasMfr && hasVdr) {
         if (hasAVL && hasAML) {
            throw new AXLAlreadyExistsException(RESOURCE, axlResource.MSG_AVL_WITH_OEM_VDR_ALREADY_EXISTS,
               new Object[] {oem.getIdentity(), vdr.getIdentity()});
         }
         else if (hasAVL) {
            return addAML(anotherContext, oem, vdr, mfr, amlPref, entry);
         }
         else if (hasAML) {
            return addAVL(anotherContext, oem, mfr, vdr, avlPref, entry);
         }
         else {
            return addAXL(anotherContext, oem, mfr, amlPref, vdr, avlPref, entry);
         }
      }
      else if (hasMfr) {
         if (hasAML) {
            throw new AXLAlreadyExistsException(RESOURCE, axlResource.MSG_AML_WITH_OEM_MFR_ALREADY_EXISTS,
               new Object[] {oem.getIdentity(), mfr.getIdentity()});
         }
         else {
            return addAML(anotherContext, oem, null, mfr, amlPref,entry);
         }
      }
      else if (hasVdr) {
         if (hasAVL) {
            throw new AXLAlreadyExistsException(RESOURCE, axlResource.MSG_AVL_WITH_OEM_VDR_ALREADY_EXISTS,
               new Object[] {oem.getIdentity(), vdr.getIdentity()});
         }
         else {
            return addAVL(anotherContext, oem, null, vdr, avlPref, entry);
         }
      }

      // this never happens
      throw new AXLException(RESOURCE, axlResource.MSG_AXL_HAS_NO_MFR_NO_VDR, null);
   }

   /**
    * {@inheritDoc}
    * <BR><BR><B>Supported API: </B>true
    */
   @Override
   public AXLEntry addAVL( AXLContext context, WTPart oemPart, ManufacturerPartMaster manufacturerPartMaster, VendorPartMaster vendorPartMaster, AXLPreference avlPreference)
            throws WTException {
       return addAVL(context, oemPart, manufacturerPartMaster, vendorPartMaster, avlPreference, null);
   }

   /**
    * {@inheritDoc}
    * <BR><BR><B>Supported API: </B>true
    */
   @Override
   public AXLEntry addAVL( AXLContext context, WTPart oemPart, ManufacturerPartMaster manufacturerPartMaster, VendorPartMaster vendorPartMaster, AXLPreference avlPreference, AXLEntry sourceEntry)
            throws WTException {
      validateContext(context);
      validateOemPart(oemPart, AXLServiceEvent.ADD_AVL);
      validateAMLPreference(avlPreference);

      Transaction trx = new Transaction();
      try {
         trx.start();

         WTCollection entries = validateBeforeAddAVL(context, oemPart, manufacturerPartMaster, vendorPartMaster);
         AXLEntry entry = null;
         // case 1: create new AVL (in this case, manufacturer part must be null
         if (entries == null || entries.isEmpty()) {
            if (manufacturerPartMaster != null) {
               logger.error("##### addAVL: this should not happen - entries is null and mfr is not null");
            }
            entry = AXLEntry.newAXLEntry(context, oemPart, null, vendorPartMaster);
         }
         else {
            AXLEntry entry1 = (AXLEntry) entries.persistableIterator().next();
            // case 2: update existing AVL
            if (entry1.getVendorPart() == null) {
               entry = entry1;
               entry.setVendorPart(vendorPartMaster);
            }
            // case 3: create new AXL entry (reusing mfr info from existing entries)
            else {
               entry = AXLEntry.newAXLEntry(context, oemPart, manufacturerPartMaster, vendorPartMaster);
               entry.setAmlPreference(entry1.getAmlPreference());
            }
         }
         entry.setAvlPreference(avlPreference);
         entry = (AXLEntry) PersistenceHelper.manager.save(entry);

         prepareAndUpdateTI(sourceEntry, entry);


         AXLServiceEventData eventData = new AXLServiceEventData(context);
         eventData.setVendorPart(vendorPartMaster);
         eventData.setPreference(avlPreference);
         eventData.setEntryId(entry.getPersistInfo().getObjectIdentifier().getId());
         dispatchAXLServiceEvent(AXLServiceEvent.ADD_AVL, oemPart, eventData);

         trx.commit();
         trx = null;
         return entry;
      }
      catch (WTPropertyVetoException e) {
         logger.error("error set aml preference");
         throw new AXLException(e, RESOURCE, axlResource.MSG_ERROR_SET_AML_PREF, new Object[] {oemPart.getIdentity(), manufacturerPartMaster.getIdentity()});
      }
      finally {
         if (trx != null) {
            trx.rollback();
         }
      }
   }

   /**
    * {@inheritDoc}
    * <BR><BR><B>Supported API: </B>true
    */
   @Override
   public void removeAVL( AXLContext context, WTPart oemPart, VendorPartMaster vendorPartMaster )
            throws WTException {
       AXLPreference preference = null;
       AXLPreference oldPreference = null;
       validateContext(context);
       validateVendorPartMaster(vendorPartMaster);
       validateOemPart(oemPart, AXLServiceEvent.REMOVE_AVL);

       // Step 1: finds the matching entry for the oem part and vendor part
       QuerySpec qs = new QuerySpec();

       int idx = qs.appendClassList(AXLEntry.class, true);
       qs.appendWhere(getAXLSearchCondition(AXLContext.class, context), new int[] {idx});
       qs.appendAnd();
       qs.appendWhere(getAXLSearchCondition(WTPart.class, oemPart), new int[] {idx});
       qs.appendAnd();
       qs.appendWhere(getAXLSearchCondition(VendorPartMaster.class, vendorPartMaster), new int[] {idx});
       QueryResult qr = PersistenceHelper.manager.find(qs);
       if (qr.size() == 0) {
          logger.error("No axl with the OEM part " +
                   oemPart.getIdentity() + " and vendor part " + vendorPartMaster.getIdentity());
          throw new AXLDoesNotExistException(RESOURCE, axlResource.MSG_NO_AXL_WITH_OEM_PART_VDR_PART, new Object[] {oemPart.getIdentity(), vendorPartMaster.getIdentity()});
       }
       else if (qr.size() > 1) {
          logger.error("To many axl with the specified OEM part " +
                   oemPart.getMaster().getPersistInfo().getObjectIdentifier().getId() +
                   " vendor part " + vendorPartMaster.getIdentity());
          throw new AXLException(RESOURCE, axlResource.MSG_TOO_MANY_AXL_WITH_OEM_PART_VDR_PART, new Object[] {oemPart.getIdentity(), vendorPartMaster.getIdentity()});
       }

       Object o = unfoldQueryResult(qr);
       AXLEntry entry = (AXLEntry) o;
       ManufacturerPartMaster mfrPartMaster = entry.getManufacturerPart();
        if (preference == null){
            try{
                preference = entry.getAvlPreference();
            }catch(WTException sourcingStatusNoMoreExp){
                // Skip WTException in the case vendor sourcing status preference value invalid then it should be possible
                // to delete it from UI.
                if (logger.isDebugEnabled())
                    logger.debug(sourcingStatusNoMoreExp.getLocalizedMessage());
            }
        }
       // Step 2: gets count of entries that match the oem part and manufacturer part
       if (mfrPartMaster != null) {
          qs = new QuerySpec();
          qs.setAdvancedQueryEnabled(true);
          idx = qs.appendClassList(AXLEntry.class, false);
          qs.appendWhere(getAXLSearchCondition(AXLContext.class, context), new int[] {idx});
          qs.appendAnd();
          qs.appendWhere(getAXLSearchCondition(WTPart.class, oemPart), new int[] {idx});
          qs.appendAnd();
          qs.appendWhere(getAXLSearchCondition(ManufacturerPartMaster.class, mfrPartMaster), new int[] {idx});
          qs.appendSelect(SQLFunction.newSQLFunction(SQLFunction.COUNT, new ConstantExpression(new Integer(1))), false);
          qr = PersistenceServerHelper.manager.query(qs);

          int count = 0;
          if (qr.hasMoreElements()) {
             o = unfoldQueryResult(qr);
             if (o instanceof Number) {
                count = ((Number) o).intValue();
             }
             else {
                logger.error("Unexpected query result " + qs.toString());
                throw new AXLException(RESOURCE, axlResource.MSG_UNEXPECTED_QUERY_RESULT, new Object[]{qs.toString(), o.getClass().getName()});
             }
          }

          // When there's only 1 entry that matches the oem part and manufacturer part, the
          // entry will be updated instead of deleted.
         if (count == 1) {
             try {
                entry.setVendorPart(null);
                entry.setAvlPreference(null);
                entry = (AXLEntry) PersistenceHelper.manager.modify(entry);
             }
            catch (WTPropertyVetoException e) {
                // this should not happen, but just in case
                logger.error(e.getLocalizedMessage());
                throw new AXLException(e);
         }
          }else{
            // In all other cases, the entry is simply removed
            PersistenceHelper.manager.delete(entry);
          }
       }

        oldPreference = getOldPreference(oemPart, vendorPartMaster, null, context);
        AXLServiceEventData eventData = new AXLServiceEventData(context);
        if (preference != null)
            eventData.setPreference(preference);
        if (oldPreference != null && preference != oldPreference)
            eventData.setOldPreference(oldPreference);
        eventData.setVendorPart(vendorPartMaster);
       dispatchAXLServiceEvent(AXLServiceEvent.REMOVE_AVL, oemPart, eventData);
   }

   @Override
   public WTCollection getAXLChangeHistory( WTPart oem_part, AXLContext context )
            throws WTException {
      validateOemPart(oem_part, null);
      QuerySpec qs = new QuerySpec(AXLChangeEvent.class);
      qs.appendWhere(
         new SearchCondition(AXLChangeEvent.class, AXLChangeEvent.OEM_PART_ID,
                             SearchCondition.EQUAL, oem_part.getPersistInfo().getObjectIdentifier().getId()),
         new int[] {0});
      if (context != null) {
         qs.appendAnd();
         qs.appendWhere(
            new SearchCondition(AXLChangeEvent.class, AXLChangeEvent.AXL_CONTEXT_ID,
                                SearchCondition.EQUAL, context.getPersistInfo().getObjectIdentifier().getId()),
            new int[] {0});
      }

      if (logger.isTraceEnabled()) logger.trace("qs = " + qs);
      WTArrayList history = new WTArrayList();
      history = (WTArrayList) PersistenceHelper.manager.find(qs, history);
      if (logger.isDebugEnabled()) logger.debug("found " + history.size() + " AML/AVL change history record.");
      return history;
   }

   @Override
   public void dispatchAXLServiceEvent( String eventType, WTPart eventTarget, AXLServiceEventData eventData )
            throws WTException {
      AXLServiceEvent event = new AXLServiceEvent(eventType, eventTarget);
      WTKeyedMap map = new WTKeyedHashMap(1);
      Collection data = new ArrayList(1);
      data.add(eventData);
      map.put(eventTarget, data);
      event.setEventData(map);
      logger.debug("dispatching AXLServiceEvent: " + event);
      SumaServerHelper.service.dispatchVetoableEvent(event, event.getEventKey());
      AXLChangeEventHelper.recordEvent(event);
   }

   @Override
   public void dispatchAXLServiceEvent( String eventType, WTPart eventTarget, Collection eventData )
            throws WTException {
      AXLServiceEvent event = new AXLServiceEvent(eventType, eventTarget);
      WTKeyedMap map = new WTKeyedHashMap(1);
      map.put(eventTarget, eventData);
      event.setEventData(map);
      logger.debug("dispatching AXLServiceEvent: " + event);
      SumaServerHelper.service.dispatchVetoableEvent(event, event.getEventKey());
      AXLChangeEventHelper.recordEvent(event);
   }

   @Override
   public void dispatchMultiObjectAXLServiceEvent( String eventType, WTCollection eventTarget, WTKeyedMap eventData )
            throws WTException {
      AXLServiceEvent event = new AXLServiceEvent(eventType, eventTarget);
      event.setEventData(eventData);
      logger.debug("dispatching multi object AXLServiceEvent: " + event);
      SumaServerHelper.service.dispatchVetoableMultiObjectEvent(event, event.getEventKey());
      AXLChangeEventHelper.recordMultiObjectEvent(event);
   }

   @Override
   public void dispatchOEMPartCopyEvent( String eventType, WTPart eventTarget, WTKeyedMap eventData )
            throws WTException {
      OEMPartCopyEvent event = new OEMPartCopyEvent(eventType, eventTarget);
      event.setAxlEntryMap(eventData);
      logger.debug("dispatching OEMPartCopyEvent: " + event);
      SumaServerHelper.service.dispatchVetoableEvent(event, event.getEventKey());
   }

   @Override
   public void processPreStoreEvent( PersistenceManagerEvent event )
            throws WTException {
      logger.trace("processPreStoreEvent");
      WTCollection allTargets = (WTCollection) event.getEventTarget();

      WTCollection contexts = allTargets.subCollection(AXLContext.class);
      if (!contexts.isEmpty()) {
         processPreStoreForAXLContext(contexts);
      }

      WTCollection entries = allTargets.subCollection(AXLEntry.class);
      if (!entries.isEmpty()) {
         processPreStoreForAXLEntry(entries);
      }

      WTCollection parts = allTargets.subCollection(SupplierPart.class);
      if (!parts.isEmpty()) {
         processPreStoreForSupplierPart(parts);
      }
   }

   @Override
   public void processPostStoreEvent( PersistenceManagerEvent event )
            throws WTException {
      logger.trace("processPostStoreEvent");
      WTCollection allTargets = (WTCollection) event.getEventTarget();
      WTCollection entries = allTargets.subCollection(AXLEntry.class);
      // Adding a check to see if the call has been made from WBM, refer spr#2245776 for more details
      if (!entries.isEmpty()&&!(Transaction.getGlobalMap().containsKey(WBM_CONTEXT_KEY))) {
         processPostStoreForAXLEntry(entries);
      }
   }

   @Override
   public void processPreDeleteEvent( PersistenceManagerEvent event )
            throws WTException {
      logger.trace("processPreDeleteEvent()");
      WTCollection allTargets = (WTCollection) event.getEventTarget();

      WTCollection contexts = allTargets.subCollection(AXLContext.class);
      if (!contexts.isEmpty()) {
         logger.trace("processPreDeleteEvent: contexts.size=" + contexts.size());
         processPreDeleteForAXLContext(contexts);
      }

      WTCollection entries = allTargets.subCollection(AXLEntry.class);
      if (!entries.isEmpty()) {
         logger.trace("processPreDeleteEvent: entries.size=" + entries.size());
         processPreDeleteForAXLEntry(entries);
      }

      WTCollection mfrPartMasters = allTargets.subCollection(ManufacturerPartMaster.class);
      if (!mfrPartMasters.isEmpty()) {
         logger.trace("processPreDeleteEvent: mfrPartMasters.size=" + mfrPartMasters.size());
         processPreDeleteForManufacturerPartMaster(mfrPartMasters);
      }

      WTCollection vdrPartMasters = allTargets.subCollection(VendorPartMaster.class);
      if (!vdrPartMasters.isEmpty()) {
         logger.trace("processPreDeleteEvent: vdrPartMasters.size=" + vdrPartMasters.size());
         processPreDeleteForVendorPartMaster(vdrPartMasters);
      }
   }

   @Override
   public void processPostDeleteEvent( PersistenceManagerEvent event )
            throws WTException {
      logger.trace("processPostDeleteEvent()");
      WTCollection allTargets = (WTCollection) event.getEventTarget();
      WTCollection entries = allTargets.subCollection(AXLEntry.class);
      if (!entries.isEmpty()) {
         logger.trace("processPostDeleteEvent: entries.size=" + entries.size());
         processPostDeleteForAXLEntry();
      }
   }

   @Override
   public void processPreModifyEvent( PersistenceManagerEvent event )
            throws WTException {
      logger.trace("processPreModifyEvent()");
      WTCollection allTargets = (WTCollection) event.getEventTarget();

      WTCollection entries = allTargets.subCollection(AXLEntry.class);
      if (!entries.isEmpty()) {
         logger.trace("processPreModifyEvent: entries.size=" + entries.size());
         processPreModifyForAXLEntry(entries);
      }
   }

   @Override
   public void processPostModifyEvent( PersistenceManagerEvent event )
            throws WTException {
      logger.trace("processPostModifyEvent");
      WTCollection allTargets = (WTCollection) event.getEventTarget();
      WTCollection entries = allTargets.subCollection(AXLEntry.class);
      if (!entries.isEmpty()) {
         processPostModifyForAXLEntry();
      }
   }

   @Override
   public void processNewIterationEvent( VersionControlServiceEvent event )
            throws WTException {
      logger.trace("processNewIterationEvent():");
      WTCollection allTargets = event.getTargetCollection();
      WTCollection oemParts = new WTHashSet();
      oemParts.addAll(allTargets.subCollection(WTPart.class, true));
      oemParts.removeAll(allTargets.subCollection(SupplierPart.class, true));
      if (!oemParts.isEmpty()) {
         processNewIterationForOEMPart(oemParts);
      }
   }

   @Override
   public void processPostCheckinEvent( WorkInProgressServiceEvent event )
            throws WTException {
      logger.debug("processPostCheckinEvent - start");

      WTValuedMap map = event.getTargetMap();
      if (map == null || map.isEmpty()) {
         return;
      }

      WTValuedHashMap oemPartMap = new WTValuedHashMap();
      for (Iterator i = map.wtKeySet().persistableIterator(); i.hasNext();) {
         Persistable oldPart = (Persistable) i.next();
         if (oldPart instanceof WTPart && !(oldPart instanceof SupplierPart)) {
            Persistable newPart = map.getPersistable(oldPart);
            oemPartMap.put(oldPart, newPart);
         }
      }

      if (oemPartMap.isEmpty()) {
         return;
      }

      try {
            processPostCheckinForOEMPart(oemPartMap);
      }
      catch (Exception e) {
         logger.error("==============================================================");
         e.printStackTrace();
         throw new AXLException(e);
      }
      logger.debug("processPostCheckinEvent - end");
   }

   @Override
   public void processPostCreateEvent( WTContainerServiceEvent event )
            throws WTException {
      Object target = event.getEventTarget();
      if (target instanceof OrgContainer) {
         logger.debug("OrgContainer is " + ((OrgContainer) target).getContainerInfo().getName());
         processPostCreateForOrgContainer((OrgContainer) target);
      }
   }

   @Override
   public void processCleanupLinkEvent( PersistenceManagerEvent event )
            throws WTException {
      WTKeyedMap objects_to_links = (WTKeyedMap)event.getEventTarget();
      WTSet links_to_dispatch = null;
      for (Iterator i = objects_to_links.values().iterator(); i.hasNext();) {
         WTSet next = (WTSet)i.next();
         if (next.containsInstance(OEMPartAXLContextLink.class)) {
            if (links_to_dispatch == null) {
               links_to_dispatch = new WTHashSet();
            }
            links_to_dispatch.addAll(next.subCollection(OEMPartAXLContextLink.class));
         }
      }
      if (links_to_dispatch != null) {
         dispatchOEMPreferenceEvent(links_to_dispatch, OEMPreferenceEvent.REMOVE_PREFERENCE);
      }
   }

   @Override
   public void processPostCopyEvent( EnterpriseServiceEvent event )
            throws WTException {
      logger.trace("processPostCopyEvent()");
      CopyObjectInfo[] copyInfo = event.getCopyObjectInfo();

      WTValuedMap originalToCopyMap = null;
      if (copyInfo != null && copyInfo.length > 0) {
         logger.debug("multiple object save-as, calling getCopyObjectInfo()...");
         originalToCopyMap = new WTValuedHashMap(copyInfo.length);
         for (int i = 0; i < copyInfo.length; i++) {
            originalToCopyMap.put(copyInfo[i].getOriginal(), copyInfo[i].getCopy());
         }
      }
      else {
         logger.debug("single object copy, calling getCopy() and getOriginal()...");
         originalToCopyMap = new WTValuedHashMap(1);
         originalToCopyMap.put(event.getOriginal(), event.getCopy());
      }

      if (logger.isTraceEnabled()) logger.trace("number of copied objects: " + originalToCopyMap.size());
      processPostCopyForOEMPart(originalToCopyMap);
   }

   @Override
   public void registerEvents( ManagerService managerService ) {
      managerService.addEventBranch(AXLServiceEvent.generateEventKey(AXLServiceEvent.ADD_AML),
                                    AXLServiceEvent.class.getName(), AXLServiceEvent.ADD_AML);
      managerService.addEventBranch(AXLServiceEvent.generateEventKey(AXLServiceEvent.ADD_AVL),
                                    AXLServiceEvent.class.getName(), AXLServiceEvent.ADD_AVL);
      managerService.addEventBranch(AXLServiceEvent.generateEventKey(AXLServiceEvent.REMOVE_AML),
                                    AXLServiceEvent.class.getName(), AXLServiceEvent.REMOVE_AML);
      managerService.addEventBranch(AXLServiceEvent.generateEventKey(AXLServiceEvent.REMOVE_AVL),
                                    AXLServiceEvent.class.getName(), AXLServiceEvent.REMOVE_AVL);
      managerService.addEventBranch(AXLServiceEvent.generateEventKey(AXLServiceEvent.MODIFY_AML),
                                    AXLServiceEvent.class.getName(), AXLServiceEvent.MODIFY_AML);
      managerService.addEventBranch(AXLServiceEvent.generateEventKey(AXLServiceEvent.MODIFY_AVL),
                                    AXLServiceEvent.class.getName(), AXLServiceEvent.MODIFY_AVL);

      managerService.addEventBranch(OEMPartCopyEvent.generateEventKey(OEMPartCopyEvent.COPY_PART),
                                    OEMPartCopyEvent.class.getName(), OEMPartCopyEvent.COPY_PART);

      managerService.addEventBranch(OEMPreferenceEvent.generateEventKey(OEMPreferenceEvent.CREATE_PREFERENCE),
                                    OEMPreferenceEvent.class.getName(), OEMPreferenceEvent.CREATE_PREFERENCE);
      managerService.addEventBranch(OEMPreferenceEvent.generateEventKey(OEMPreferenceEvent.MODIFY_PREFERENCE),
                                    OEMPreferenceEvent.class.getName(), OEMPreferenceEvent.MODIFY_PREFERENCE);
      managerService.addEventBranch(OEMPreferenceEvent.generateEventKey(OEMPreferenceEvent.REMOVE_PREFERENCE),
                                    OEMPreferenceEvent.class.getName(), OEMPreferenceEvent.REMOVE_PREFERENCE);
   }

   /**
    * {@inheritDoc}
    * <BR><BR><B>Supported API: </B>true
    */
   @Override
   public AXLEntry addAML( AXLContext context, WTPart oemPart, VendorPartMaster vendorPartMaster, ManufacturerPartMaster manufacturerPartMaster, AXLPreference amlPreference)
            throws WTException {
       return addAML(context, oemPart, vendorPartMaster, manufacturerPartMaster, amlPreference, null);
   }

   /**
    * {@inheritDoc}
    * <BR><BR><B>Supported API: </B>true
    */
   @Override
   public AXLEntry addAML( AXLContext context, WTPart oemPart, VendorPartMaster vendorPartMaster, ManufacturerPartMaster manufacturerPartMaster, AXLPreference amlPreference, AXLEntry sourceEntry)
            throws WTException {
      validateContext(context);
      validateOemPart(oemPart, AXLServiceEvent.ADD_AML);
      validateAMLPreference(amlPreference);

      Transaction trx = new Transaction();
      try {
         trx.start();

         AXLEntry entry = validateBeforeAddAML(context, oemPart, vendorPartMaster, manufacturerPartMaster);
         if (entry == null) {
            entry = AXLEntry.newAXLEntry(context, oemPart, manufacturerPartMaster, null);
         }
         else {
            entry.setManufacturerPart(manufacturerPartMaster);
         }
         entry.setAmlPreference(amlPreference);
         entry = (AXLEntry) PersistenceHelper.manager.save(entry);

         prepareAndUpdateTI(sourceEntry, entry);

         AXLServiceEventData eventData = new AXLServiceEventData(context);
         eventData.setManufacturerPart(manufacturerPartMaster);
         eventData.setPreference(amlPreference);
         eventData.setEntryId(entry.getPersistInfo().getObjectIdentifier().getId());
         dispatchAXLServiceEvent(AXLServiceEvent.ADD_AML, oemPart, eventData);

         trx.commit();
         trx = null;
         return entry;
      }
      catch (WTPropertyVetoException e) {
         logger.error("error set aml preference");
         throw new AXLException(e, RESOURCE, axlResource.MSG_ERROR_SET_AML_PREF, new Object[] {oemPart.getIdentity(), manufacturerPartMaster.getIdentity()});
      }
      finally {
         if (trx != null) {
            trx.rollback();
         }
      }
   }

   @Override
   public AXLEntry addAXL( AXLContext context, WTPart oemPart, ManufacturerPartMaster manufacturerPartMaster, AXLPreference amlPreference, VendorPartMaster vendorPartMaster, AXLPreference avlPreference )
            throws WTException {
       return addAXL(context, oemPart, manufacturerPartMaster, amlPreference, vendorPartMaster, avlPreference, null);
   }

   @Override
   public AXLEntry addAXL( AXLContext context, WTPart oemPart, ManufacturerPartMaster manufacturerPartMaster, AXLPreference amlPreference, VendorPartMaster vendorPartMaster, AXLPreference avlPreference, AXLEntry sourceEntry )
            throws WTException {
      validateContext(context);
      validateOemPart(oemPart, AXLServiceEvent.ADD_AML);
      validateAMLPreference(amlPreference);
      validateAVLPreference(avlPreference);

      Transaction trx = new Transaction();
      try {
         trx.start();
         // checks for possible conflicts. if existing row needs update
         // the row will be locked for update - the lock will be released
         // when the transaction is either commited or rolled back
         validateBeforeAddAXL(context, oemPart, manufacturerPartMaster, vendorPartMaster);

         AXLEntry entry = AXLEntry.newAXLEntry(context, oemPart, manufacturerPartMaster, vendorPartMaster);
         entry.setAmlPreference(amlPreference);
         entry.setAvlPreference(avlPreference);
         entry = (AXLEntry) PersistenceHelper.manager.store(entry);

         prepareAndUpdateTI(sourceEntry, entry);

         // we emit 2 events here, an ADD_AML and an ADD_AVL
         AXLServiceEventData eventData = new AXLServiceEventData(context);
         eventData.setManufacturerPart(manufacturerPartMaster);
         eventData.setPreference(amlPreference);
         eventData.setEntryId(entry.getPersistInfo().getObjectIdentifier().getId());
         dispatchAXLServiceEvent(AXLServiceEvent.ADD_AML, oemPart, eventData);

         eventData = new AXLServiceEventData(context);
         eventData.setVendorPart(vendorPartMaster);
         eventData.setPreference(avlPreference);
         eventData.setEntryId(entry.getPersistInfo().getObjectIdentifier().getId());
         dispatchAXLServiceEvent(AXLServiceEvent.ADD_AVL, oemPart, eventData);

         trx.commit();
         trx = null;

         return entry;
      }
      catch (WTPropertyVetoException e) {
         logger.error(e.getLocalizedMessage());
         throw new AXLException(e);
      }
      finally {
         if (trx != null) {
            trx.rollback();
         }
      }
   }

   private void prepareAndUpdateTI(AXLEntry source, AXLEntry target) throws WTPropertyVetoException, WTException{
       if(source != null){
           logger.debug("sourceEntry = "+source);
           WTArrayList srcEntry = new WTArrayList();
           srcEntry.add(source);

           WTArrayList targetEntry = new WTArrayList();
           targetEntry.add(target);
           logger.debug("AML = "+target);
           logger.debug("Updating TypeInstance information");
           updateTI(srcEntry, targetEntry);
       }
   }

   @Override
   public boolean hasAML( AXLContext context, WTPart oemPart, ManufacturerPartMaster manufacturerPartMaster )
            throws WTException {
      validateOemPart(oemPart, null);

      // SELECT 1
      // FROM [NullTableExpression]
      // WHERE EXISTS (
      //    SELECT axl.IdA2A2
      //    FROM AXLEntry axl
      //    WHERE axl.IdA3D4 = <ctx-id>
      //    AND   axl.IdA3C4 = <oem-part-id>
      //    AND   axl.IdA3A4 = <mfr-part-master-id>
      // );

      QuerySpec qs = new QuerySpec();
      qs.setAdvancedQueryEnabled( true );
      qs.appendSelect(new ConstantExpression(Boolean.TRUE), false);
      int idxNull = qs.appendFrom(new NullTableExpression());
      QuerySpec qsSub = new QuerySpec();
      int idxEntry = qsSub.appendClassList(AXLEntry.class, false);
      qsSub.appendSelectAttribute(WTAttributeNameIfc.ID_NAME, idxEntry, true);
      if (context != null) {
      qsSub.appendWhere(getAXLSearchCondition(AXLContext.class, context), new int[] {idxEntry});
      qsSub.appendAnd();
      }
      qsSub.appendWhere(getAXLSearchCondition(WTPart.class, oemPart), new int[] {idxEntry});
      qsSub.appendAnd();
      qsSub.appendWhere(getAXLSearchCondition(ManufacturerPartMaster.class, manufacturerPartMaster), new int[] {idxEntry});
      qsSub.setAdvancedQueryEnabled(true);
      qs.appendWhere(new ExistsExpression(qsSub), new int[] {idxNull});
      QueryResult qr = PersistenceHelper.manager.find(qs);

      return qr.hasMoreElements();
   }

   @Override
   public boolean hasAVL( AXLContext context, WTPart oemPart, VendorPartMaster vendorPartMaster )
            throws WTException {
      validateOemPart(oemPart, null);

      // SELECT 1
      // FROM [NullTableExpression]
      // WHERE EXISTS (
      //    SELECT axl.IdA2A2
      //    FROM AXLEntry axl
      //    WHERE axl.IdA3D4 = <ctx-id>
      //    AND   axl.IdA3C4 = <oem-part-id>
      //    AND   axl.IdA3B4 = <vdr-part-master-id>
      // );

      QuerySpec qs = new QuerySpec();
      qs.setAdvancedQueryEnabled( true );
      qs.appendSelect(new ConstantExpression(Boolean.TRUE), false);
      int idxNull = qs.appendFrom(new NullTableExpression());
      QuerySpec qsSub = new QuerySpec();
      int idxEntry = qsSub.appendClassList(AXLEntry.class, false);
      qsSub.appendSelectAttribute(WTAttributeNameIfc.ID_NAME, idxEntry, true);
      if (context != null) {
      qsSub.appendWhere(getAXLSearchCondition(AXLContext.class, context), new int[] {idxEntry});
      qsSub.appendAnd();
      }
      qsSub.appendWhere(getAXLSearchCondition(WTPart.class, oemPart), new int[] {idxEntry});
      qsSub.appendAnd();
      qsSub.appendWhere(getAXLSearchCondition(VendorPartMaster.class, vendorPartMaster), new int[] {idxEntry});
      qsSub.setAdvancedQueryEnabled(true);
      qs.appendWhere(new ExistsExpression(qsSub), new int[] {idxNull});
      QueryResult qr = PersistenceHelper.manager.find(qs);

      return qr.hasMoreElements();
   }

   @Override
   public boolean hasAMLOrAVL( AXLContext context, WTPart oemPart, ManufacturerPartMaster manufacturerPartMaster, VendorPartMaster vendorPartMaster )
            throws WTException {
      validateOemPart(oemPart, null);

      // SELECT 1
      // FROM [NullTableExpression]
      // WHERE EXISTS (
      //    SELECT axl.IdA2A2
      //    FROM AXLEntry axl
      //    WHERE axl.IdA3D4 = <ctx-id>
      //     AND  axl.IdA3C4 = <oem-part-id>
      //     AND (axl.IdA3A4 = <mfr-part-master-id>
      //     OR   axl.IdA3B4 = <vdr-part-master-id>)
      // );

      QuerySpec qs = new QuerySpec();
      qs.setAdvancedQueryEnabled( true );
      qs.appendSelect(new ConstantExpression(Boolean.TRUE), false);
      int idxNull = qs.appendFrom(new NullTableExpression());
      QuerySpec qsSub = new QuerySpec();
      int idxEntry = qsSub.appendClassList(AXLEntry.class, false);
      qsSub.appendSelectAttribute(WTAttributeNameIfc.ID_NAME, idxEntry, true);
      if (context != null) {
      qsSub.appendWhere(getAXLSearchCondition(AXLContext.class, context), new int[] {idxEntry});
      qsSub.appendAnd();
      }
      qsSub.appendWhere(getAXLSearchCondition(WTPart.class, oemPart), new int[] {idxEntry});
      qsSub.appendAnd();
      qsSub.appendOpenParen();
      qsSub.appendWhere(getAXLSearchCondition(ManufacturerPartMaster.class, manufacturerPartMaster), new int[] {idxEntry});
      qsSub.appendOr();
      qsSub.appendWhere(getAXLSearchCondition(VendorPartMaster.class, vendorPartMaster), new int[] {idxEntry});
      qsSub.appendCloseParen();
      qsSub.setAdvancedQueryEnabled(true);
      qs.appendWhere(new ExistsExpression(qsSub), new int[] {idxNull});
      QueryResult qr = PersistenceHelper.manager.find(qs);

      return qr.hasMoreElements();
   }

   @Override
   public boolean hasAXL( AXLContext context, WTPart oemPart, ManufacturerPartMaster manufacturerPartMaster, VendorPartMaster vendorPartMaster )
            throws WTException {
      validateOemPart(oemPart, null);

      // SELECT 1
      // FROM [NullTableExpression]
      // WHERE EXISTS (
      //    SELECT axl.IdA2A2
      //    FROM AXLEntry axl
      //    WHERE axl.IdA3D4 = <ctx-id>
      //     AND  axl.IdA3C4 = <oem-part-id>
      //     AND  axl.IdA3A4 = <mfr-part-master-id>
      //     AND  axl.IdA3B4 = <vdr-part-master-id>
      // );

      QuerySpec qs = new QuerySpec();
      qs.setAdvancedQueryEnabled( true );
      qs.appendSelect(new ConstantExpression(Boolean.TRUE), false);
      int idxNull = qs.appendFrom(new NullTableExpression());
      QuerySpec qsSub = new QuerySpec();
      int idxEntry = qsSub.appendClassList(AXLEntry.class, false);
      qsSub.appendSelectAttribute(WTAttributeNameIfc.ID_NAME, idxEntry, true);
      if (context != null) {
      qsSub.appendWhere(getAXLSearchCondition(AXLContext.class, context), new int[] {idxEntry});
      qsSub.appendAnd();
      }
      qsSub.appendWhere(getAXLSearchCondition(WTPart.class, oemPart), new int[] {idxEntry});

      if (manufacturerPartMaster != null) {
      qsSub.appendAnd();
         qsSub.appendWhere(getAXLSearchCondition(ManufacturerPartMaster.class, manufacturerPartMaster), new int[] {idxEntry});
      }

      if (vendorPartMaster != null) {
         qsSub.appendAnd();
         qsSub.appendWhere(getAXLSearchCondition(VendorPartMaster.class, vendorPartMaster), new int[] {idxEntry});
      }

      qsSub.setAdvancedQueryEnabled(true);
      qs.appendWhere(new ExistsExpression(qsSub), new int[] {idxNull});
      QueryResult qr = PersistenceHelper.manager.find(qs);

      return qr.hasMoreElements();
   }

   @Override
   public WTCollection findAML( AXLContext context, WTPart oemPart, ManufacturerPartMaster manufacturerPartMaster, boolean isSetLock )
            throws WTException {
      validateContext(context);
      validateOemPart(oemPart, null);

      QuerySpec qs = new QuerySpec();
      qs.setLock(isSetLock);
      int idxEntry = qs.appendClassList(AXLEntry.class, true);
      qs.appendWhere(getAXLSearchCondition(AXLContext.class, context), new int[] {idxEntry});
      qs.appendAnd();
      qs.appendWhere(getAXLSearchCondition(WTPart.class, oemPart), new int[] {idxEntry});
      qs.appendAnd();
      qs.appendWhere(getAXLSearchCondition(ManufacturerPartMaster.class, manufacturerPartMaster), new int[] {idxEntry});
      WTHashSet set = new WTHashSet();
      return (WTCollection) PersistenceHelper.manager.find(qs, set);
   }

   @Override
   public AXLEntry findAVL( AXLContext context, WTPart oemPart, VendorPartMaster vendorPartMaster, boolean isSetLock )
            throws WTException {
      validateContext(context);
      validateOemPart(oemPart, null);

      QuerySpec qs = new QuerySpec();
      qs.setLock(isSetLock);
      int idxEntry = qs.appendClassList(AXLEntry.class, true);
      qs.appendWhere(getAXLSearchCondition(AXLContext.class, context), new int[] {idxEntry});
      qs.appendAnd();
      qs.appendWhere(getAXLSearchCondition(WTPart.class, oemPart), new int[] {idxEntry});
      qs.appendAnd();
      qs.appendWhere(getAXLSearchCondition(VendorPartMaster.class, vendorPartMaster), new int[] {idxEntry});
      QueryResult qr = PersistenceHelper.manager.find(qs);
      if (!qr.hasMoreElements()) {
         return null;
      }
      return (AXLEntry) unfoldQueryResult(qr);
   }

   @Override
   public AXLPreference getAMLPreference( AXLContext context, WTPart oemPart, ManufacturerPartMaster manufacturerPartMaster )
            throws WTException {
      validateContext(context);
      validateOemPart(oemPart, null);

      QuerySpec qs = new QuerySpec();
      qs.setAdvancedQueryEnabled(true);

      int idxEntry = qs.appendClassList(AXLEntry.class, false);
      ClassAttribute amlPref = new ClassAttribute(AXLEntry.class, AXLEntry.AML_PREFERENCE_DATA);
      qs.appendSelect(amlPref, false);

      qs.appendWhere(getAXLSearchCondition(AXLContext.class, context), new int[] {idxEntry});
      qs.appendAnd();
      qs.appendWhere(getAXLSearchCondition(WTPart.class, oemPart), new int[] {idxEntry});
      qs.appendAnd();
      qs.appendWhere(getAXLSearchCondition(ManufacturerPartMaster.class, manufacturerPartMaster), new int[] {idxEntry});

      QueryResult qr = PersistenceHelper.manager.find(qs);
      if (qr.hasMoreElements()) {
         Object o = unfoldQueryResult(qr);
         if (o instanceof Number) {
            return AXLHelper.intToPreference(((Number) o).intValue());
         }
         else {
            logger.trace("Unexpected query result " + qs.toString());
            throw new AXLException(RESOURCE, axlResource.MSG_UNEXPECTED_QUERY_RESULT, new Object[]{qs.toString(), o.getClass().getName()});
         }
      }
      return null;
   }

   @Override
   public AXLPreference getAVLPreference( AXLContext context, WTPart oemPart, VendorPartMaster vendorPartMaster )
            throws WTException {
      validateContext(context);
      validateOemPart(oemPart, null);
      QuerySpec qs = new QuerySpec();
      qs.setAdvancedQueryEnabled(true);

      int idxEntry = qs.appendClassList(AXLEntry.class, false);
      ClassAttribute avlPref = new ClassAttribute(AXLEntry.class, AXLEntry.AVL_PREFERENCE_DATA);
      qs.appendSelect(avlPref, false);

      qs.appendWhere(getAXLSearchCondition(AXLContext.class, context), new int[] {idxEntry});
      qs.appendAnd();
      qs.appendWhere(getAXLSearchCondition(WTPart.class, oemPart), new int[] {idxEntry});
      qs.appendAnd();
      qs.appendWhere(getAXLSearchCondition(VendorPartMaster.class, vendorPartMaster), new int[] {idxEntry});

      QueryResult qr = PersistenceHelper.manager.find(qs);
      if (qr.hasMoreElements()) {
         Object o = unfoldQueryResult(qr);
         if (o instanceof Number) {
            return AXLHelper.intToPreference(((Number) o).intValue());
         }
         else {
            logger.trace("Unexpected query result " + qs.toString());
            throw new AXLException(RESOURCE, axlResource.MSG_UNEXPECTED_QUERY_RESULT, new Object[]{qs.toString(), o.getClass().getName()});
         }
      }
      return null;
   }

   @Override
   public AXLContext createDefaultContext( WTContainerRef container )
            throws WTException {
      AXLContext context = AXLContextCache.getInstance().get(container, /*read only*/false);
      if (context != null) {
         AccessControlHelper.manager.checkAccess(context, AccessPermission.READ);
         return context;
      }

      context = AXLContext.newAXLContext(container, DEFAULT_CONTEXT_NAME);
      context.setDomainRef(container.getReferencedContainerReadOnly().getSystemDomainReference());
      context.setDefault(true);
      context = (AXLContext) PersistenceHelper.manager.store(context);

      return context;
   }

   @Override
   public void setAMLPreferences( WTCollection entries, AXLPreference amlPreference )
            throws WTException {
      if (entries == null || entries.isEmpty()) {
         return;
      }
      validateAMLPreference(amlPreference);

      try {
         WTCollection oemParts = getOemPartsForEntries(entries);
         WTKeyedMap eventDataMap = new WTKeyedHashMap(oemParts.size());
         for (Iterator i = entries.persistableIterator(); i.hasNext();) {
            AXLEntry entry = (AXLEntry) i.next();
            if (entry.getManufacturerPart() == null) {
               throw new AXLException(RESOURCE, axlResource.MSG_CANNOT_SET_AML_PREFERENCE_FOR_NON_AML, null);
            }

            WTPart oemPart = entry.getOemPart();

            AXLServiceEventData eventData = new AXLServiceEventData(entry.getContext());
            eventData.setManufacturerPart(entry.getManufacturerPart());
            eventData.setOldPreference(entry.getAmlPreference());
            eventData.setPreference(amlPreference);
            entry.setAmlPreference(amlPreference);

            Collection eventDataCollection = (Collection) eventDataMap.get(oemPart);
            if (eventDataCollection == null) {
               eventDataCollection = new ArrayList();
               eventDataCollection.add(eventData);
               eventDataMap.put(oemPart, eventDataCollection);
            }
            else {
               eventDataCollection.add(eventData);
            }
         }

         entries = PersistenceHelper.manager.modify(entries);
         dispatchMultiObjectAXLServiceEvent(AXLServiceEvent.MODIFY_AML, oemParts, eventDataMap);
      }
      catch (WTPropertyVetoException e) {
         throw new AXLException(e);
      }
   }

   @Override
   public void setAVLPreferences( WTCollection entries, AXLPreference avlPreference )
            throws WTException {
      if (entries == null || entries.isEmpty()) {
         return;
      }

      validateAVLPreference(avlPreference);

      try {
         WTCollection oemParts = getOemPartsForEntries(entries);
         WTKeyedMap eventDataMap = new WTKeyedHashMap(oemParts.size());

         for (Iterator i = entries.persistableIterator(); i.hasNext();) {
            AXLEntry entry = (AXLEntry) i.next();
            if (entry.getVendorPartReference() == null) {
               throw new AXLException(RESOURCE, axlResource.MSG_CANNOT_SET_AVL_PREFERENCE_FOR_NON_AVL, null);
            }

            WTPart oemPart = entry.getOemPart();

            AXLServiceEventData eventData = new AXLServiceEventData(entry.getContext());
            eventData.setVendorPart(entry.getVendorPart());
            eventData.setOldPreference(entry.getAvlPreference());
            eventData.setPreference(avlPreference);
            entry.setAvlPreference(avlPreference);

            Collection eventDataCollection = (Collection) eventDataMap.get(oemPart);
            if (eventDataCollection == null) {
               eventDataCollection = new ArrayList();
               eventDataCollection.add(eventData);
               eventDataMap.put(oemPart, eventDataCollection);
            }
            else {
               eventDataCollection.add(eventData);
            }
         }

         PersistenceHelper.manager.modify(entries);
         dispatchMultiObjectAXLServiceEvent(AXLServiceEvent.MODIFY_AVL, oemParts, eventDataMap);
      }
      catch (WTPropertyVetoException e) {
         throw new AXLException(e);
      }
   }

   @Override
   public void removeAXL( AXLContext context, WTPart oemPart, ManufacturerPartMaster manufacturerPartMaster, VendorPartMaster vendorPartMaster )
            throws WTException {
      AXLEntry axlEntry = findExactAXLEntry(context, oemPart, manufacturerPartMaster, vendorPartMaster, true);
      if (axlEntry == null) {
         // At this point, manufacturerPartMaster and vendorPartMaster can not both be null.
         if (manufacturerPartMaster == null && vendorPartMaster != null) {
            throw new AXLException(RESOURCE, axlResource.MSG_NO_AXL_WITH_OEM_PART_VDR_PART,
               new Object[]{oemPart.getNumber(), vendorPartMaster.getNumber()});
         }
         else if (manufacturerPartMaster != null && vendorPartMaster == null) {
             throw new AXLException(RESOURCE, axlResource.MSG_NO_AXL_WITH_OEM_PART_MFR_PART,
                new Object[]{oemPart.getNumber(), manufacturerPartMaster.getNumber()});
         }
         else if (manufacturerPartMaster != null && vendorPartMaster != null) {
            throw new AXLException(RESOURCE, axlResource.MSG_NO_AXL_WITH_OEM_PART_MFR_PART_VDR_PART,
               new Object[]{oemPart.getNumber(), manufacturerPartMaster.getNumber(), vendorPartMaster.getNumber()});
         }
      }
      else {
         WTSet wtSet = new WTHashSet();
         wtSet.add(axlEntry);
         removeAXL(wtSet);
      }
   }

   /**
    * Returns a query spec that handles AML/AVL/AXL queries based on arguments
    *
    * If OEM part is null, queries for entries related to any OEM parts.
    * If sourcing context is null, queries for entries related to any sourcing contexts.
    * If supplier part master class is manufacturer part master, queries for AMLs;
    * @param oem_part - OEM part. If null, queries for entries matching any OEM parts
    * @param context - sourcing context. If null, queries for entries matching any sourcing contexts
    * @param supplier_part_master_class - supplier part master class. If manufacturer part master class,
    *    queries for AML; if vendor part master class, queries for AVL; if null, queries for all AML/AVL
    * @return a constructed query spec that queries for AML/AVL
    * @throws WTException
    */
   private static QuerySpec constructAXLQuerySpec(WTPart oem_part, AXLContext context, Class supplier_part_master_class) throws WTException {
      QuerySpec qs = new QuerySpec();
      int idx = qs.appendClassList(AXLEntry.class, true);
      try {
         qs.setQuerySet(false);
      }
      catch (WTPropertyVetoException e) {
         throw new WTException(e);
      }

      boolean hasWhere = false;

      if (oem_part != null) {
         qs.appendWhere(getAXLSearchCondition(WTPart.class, oem_part), new int[] {idx});
         hasWhere = true;
      }

      if (context != null) {
         if (hasWhere) qs.appendAnd();
         qs.appendWhere(getAXLSearchCondition(AXLContext.class, context), new int[] {idx});
         hasWhere = true;
      }

      if (supplier_part_master_class != null) {
         if (hasWhere) qs.appendAnd();
         qs.appendWhere(getAXLSearchCondition(supplier_part_master_class, false), new int[] {idx});
      }
      if (logger.isTraceEnabled()) logger.trace("qs = " + qs);
      return qs;
   }

   /**
    * Copies AMLs and AVLs from old parts to new ones
    *
    * @param old2newMap a map between old parts and new parts
    */
   private void copyAXL(WTValuedMap old2newMap) throws WTException {
      logger.debug("processPostCopyForOEMPart, size  = " + old2newMap.size());

      // Finds and copies all AXLEntries
      WTCollection oldParts = old2newMap.wtKeySet();
      QuerySpec qs = new QuerySpec();
      qs.setAdvancedQueryEnabled(true);

      int idx = qs.appendClassList(AXLEntry.class, false);
      qs.appendSelectAttribute(WTAttributeNameIfc.OID_CLASSNAME, idx, false);
      qs.appendSelectAttribute(WTAttributeNameIfc.ID_NAME, idx, false);

      qs.appendWhere(getAXLSearchCondition(WTPart.class, oldParts), new int[] {idx});
      WTArrayList entries = new WTArrayList();
      entries = (WTArrayList) PersistenceHelper.manager.find(qs, entries);
      if (entries.isEmpty()) {
         logger.debug("entries are empty .");
         return;
      }
      logger.trace("Found " + entries.size() + " AML/AVL associated with the old parts");

      WTArrayList persistables = new WTArrayList();

      try {
         Iterator iterator = entries.persistableIterator();
         while (iterator.hasNext()) {
            AXLEntry entry = (AXLEntry) iterator.next();
            ObjectReference newPartRef = (ObjectReference) old2newMap.get(entry.getOemPart());
            AXLEntry newAxl = (AXLEntry) new PersistenceCloner(entry).getClone();
            newAxl.setOemPartReference(newPartRef);
            newAxl.setPersistInfo(null);
            persistables.add(newAxl);
         }
      }
      catch (WTPropertyVetoException e) {
         throw new AXLException(e);
      }
      logger.debug("processed " + persistables.size() + " AXLEntry(s)");

      // Finds and copies all OEMPartAXLContextLinks
      qs = new QuerySpec();
      qs.setAdvancedQueryEnabled(true);

      idx = qs.appendClassList(OEMPartAXLContextLink.class, false);
      qs.appendSelectAttribute(WTAttributeNameIfc.OID_CLASSNAME, idx, false);
      qs.appendSelectAttribute(WTAttributeNameIfc.ID_NAME, idx, false);

      qs.appendWhere(new SearchCondition(OEMPartAXLContextLink.class,
                                         OEMPartAXLContextLink.OEM_PART_ID,
                                         oldParts.toIdArray()),
                     new int[] {idx});
      WTHashSet links = new WTHashSet();
      links = (WTHashSet) PersistenceHelper.manager.find(qs, links);
      if (links.isEmpty()) {
         logger.debug("processNewIterationForOEMPart(): links are empty.");
      }
      else {
         logger.trace("Found " + links.size() + " OEMPartAXLContextLink(s) associated with old parts");

         Iterator iterator = links.persistableIterator();
         while (iterator.hasNext()) {
            OEMPartAXLContextLink link = (OEMPartAXLContextLink) iterator.next();
            ObjectReference newPartRef = (ObjectReference) old2newMap.get(link.getRoleAObjectId());
            OEMPartAXLContextLink newLink = (OEMPartAXLContextLink) new PersistenceCloner(link).getClone();
            newLink.setRoleAObjectRef(newPartRef);
            newLink.setPersistInfo(null);
            persistables.add(newLink);
         }
         logger.debug("processed " + links.size() + " OEMPartAXLContextLink(s)");
      }

      // Persists entries and links
      PersistenceServerHelper.manager.insert(persistables);

      /*
       * Now that AML/AVL table is configurable, AXLEntry soft attributes can be shown in this table.
       * Hence when OEMPart is checked-out, the AXLEntry clone should also get the source TI information
       * so that the soft attributes information is retained after checkout.
       */
      try {
        updateTI(entries, persistables.subCollection(AXLEntry.class));
      } catch (WTPropertyVetoException e) {
          throw new WTException(e);
      }
   }


   private void updateTI(WTArrayList srcEntries, WTCollection targetEntries ) throws WTException, WTPropertyVetoException{
       logger.debug("updateTI() started >>> ");
       List<AttributeTypeIdentifier> softAttrs = new ArrayList<>();
       TypeIdentifier tid = TypeHelper.getTypeIdentifier("WCTYPE|" + AXLEntry.class.getName());
       TypeDefinitionReadView typReadVw = TypeDefinitionServiceHelper.service.getTypeDefView(tid);
       Set<AttributeTypeIdentifier> attrs = typReadVw.getAttributeTypeIdentifiers();
       List<String> attributes = new ArrayList<>();
       logger.debug("IBAs to copy");
       for(AttributeTypeIdentifier ati : attrs){
           if((ati instanceof InstanceBasedAttributeTypeIdentifier)){
               softAttrs.add(ati);
               attributes.add(ati.getAttributeName());
               logger.debug(ati.getAttributeName());
           }
       }
       WTHashSet entriesToUpdate = new WTHashSet();
       Iterator targetIterator = targetEntries.persistableIterator();
       for(Iterator it = srcEntries.persistableIterator(); it.hasNext();){
           AXLEntry srcEntry = (AXLEntry) it.next();
           Persistable targetEntry  = (Persistable)targetIterator.next();
           OperationIdentifier op = OperationIdentifier.newOperationIdentifier(OperationIdentifierConstants.CREATE);
           PersistableAdapter sourceAdapter = new PersistableAdapter(srcEntry,null,null,null);
           PersistableAdapter targetAdapter  = new PersistableAdapter(targetEntry,null,null,op);
           sourceAdapter.load(attributes);
           targetAdapter.load(attributes);
           for(String attribute: attributes){
               logger.debug("attribute="+attribute +" ---- value="+sourceAdapter.get(attribute));
               targetAdapter.set(attribute,sourceAdapter.get(attribute));
           }
           targetAdapter.apply();
           PersistenceHelper.setVerified(targetEntry, true);
           entriesToUpdate.add(targetEntry);
       }
       PersistenceHelper.manager.modify(entriesToUpdate);
       logger.debug("updateTI() finished <<<");
   }

   /**
    * Finds the exact AXL entry that matches the specified context, OEM part, manufacturer part master and vendor part master.
    * Either manufacturerPartMaster or vendorPartMaster argument could have a null value, but they can not all be null. One
    * of these two arguments being null indicates that this is either a AVL or a AML entry.
    */
   private AXLEntry findExactAXLEntry( AXLContext context, WTPart oemPart, ManufacturerPartMaster manufacturerPartMaster, VendorPartMaster vendorPartMaster, boolean isSetLock )
      throws WTException {
      AXLEntry axlEntry = null;
      validateContext(context);
      validateOemPart(oemPart, null);
      validateManufacturerPartAndVendorPart(manufacturerPartMaster, vendorPartMaster);
      QuerySpec qs = new QuerySpec();
      int axlEntryIndex = qs.appendClassList(AXLEntry.class, true);
      int partIndex = qs.appendClassList(WTPart.class, false);
      qs.setLock(isSetLock);
      // Join the WTPart class to the AXLEntry class via the oem part reference
      SearchCondition sc1 = new SearchCondition(
               AXLEntry.class,
               AXLEntry.OEM_PART_ID, // .OEM_PART_REFERENCE,
               WTPart.class,
               wt.part.WTPart.PERSIST_INFO + "." + PersistInfo.OBJECT_IDENTIFIER + "." + ObjectIdentifier.ID);
      qs.appendWhere(sc1, new int[] {axlEntryIndex, partIndex});
      /*
       * Only find the matching axl entry that has lastest iteration wtpart
       */
      qs.appendAnd();
      qs.appendWhere(new SearchCondition(
               WTPart.class,
               WTPart.LATEST_ITERATION,
               SearchCondition.IS_TRUE),
               new int[] {partIndex});
      qs.appendAnd();
      qs.appendWhere(getAXLSearchCondition(AXLContext.class, context), new int[] {0});
      qs.appendAnd();
      qs.appendWhere(getAXLSearchCondition(WTPart.class, oemPart), new int[] {0});
      /*
       * At this point manufacturerPartMaster and vendorPartMaster can not both be null.
       */
      qs.appendAnd();
      qs.appendWhere(getAXLSearchCondition(ManufacturerPartMaster.class, manufacturerPartMaster), new int[] {0});
      qs.appendAnd();
      qs.appendWhere(getAXLSearchCondition(VendorPartMaster.class, vendorPartMaster), new int[] {0});
      QueryResult qr = PersistenceHelper.manager.find((StatementSpec)qs);
      if (qr.hasMoreElements()) {
         Persistable persistableObject[] = (Persistable[])qr.nextElement();
         axlEntry = (AXLEntry)persistableObject[0];
      }
      else {
         String message = "In context " + context.getName() +
            ", no AXL entry has been found for oem part " + oemPart.getNumber();
         if (manufacturerPartMaster != null)
            message += ", manufacturer part " + manufacturerPartMaster.getNumber();
         if (vendorPartMaster != null)
            message += ", vendor part " + vendorPartMaster.getNumber();
         logger.trace(message);
      }
      return axlEntry;
   }

   /**
    * Appends a ClassViewExpression of OEM part to the query spec, the expression
    * contains all descendants of WTPart except any descendants of SupplierPart.
    * @return a class view expression of OEM part
    * @throws WTException
    */
   private static ClassViewExpression getOEMPartClassViewExpression() throws WTException {
      try {
         ClassViewExpression view = new ClassViewExpression(WTPart.class);
         List excludeClassList = new ArrayList(1);
         excludeClassList.add(SupplierPart.class);
         view.setExcludedDescendants(excludeClassList);
         return view;
      }
      catch (WTPropertyVetoException e) {
         throw new AXLException(e);
      }
   }

   /**
    * Returns a set of OEMPartAXLContextLinks that will be affected by changes to
    * the specified collection of AXLEntry. The match is based on context
    * and OEM part.
    * @param entries a collection of AXL entries
    * @throws WTException
    * @return a set of OEMPartAXLContextLink
    */
   private WTSet getAffectedLinks(WTCollection entries) throws WTException {
      logger.trace("getAffectedLinks: entry size=" + entries.size());
      // SELECT UNIQUE link.*
      // FROM   OEMPartAXLContextLink link, AXLEntry entry
      // WHERE  entry.idA3C4 = link.idA3A5
      //  AND   entry.idA3D4 = link.idA3B5
      //  AND   entry.idA2A2 IN <entry-ids>;

      QuerySpec qs = new QuerySpec();
      try {
         qs.setDistinct(true);
      }
      catch (WTPropertyVetoException e) {
         throw new AXLException(e);
      }

      int idxLink  = qs.appendClassList(OEMPartAXLContextLink.class, true);
      int idxEntry = qs.appendClassList(AXLEntry.class, false);

      qs.appendWhere(new SearchCondition(AXLEntry.class, AXLEntry.CONTEXT_ID,
                                         OEMPartAXLContextLink.class, OEMPartAXLContextLink.CONTEXT_ID),
                     new int[] {idxEntry, idxLink});
      qs.appendAnd();
      qs.appendWhere(new SearchCondition(AXLEntry.class, AXLEntry.OEM_PART_ID,
                                         OEMPartAXLContextLink.class, OEMPartAXLContextLink.OEM_PART_ID),
                     new int[] {idxEntry, idxLink});
      qs.appendAnd();
      qs.appendWhere(new SearchCondition(AXLEntry.class, WTAttributeNameIfc.ID_NAME,
                                         entries.toIdArray()), new int[] {idxEntry});

      WTHashSet linkSet = new WTHashSet();
      PersistenceServerHelper.manager.query(qs, linkSet);
      logger.debug("getAffectedLinks: found " + linkSet.size() + " links.");
      return linkSet;
   }

   /**
    * Returns an attribute name to be used in search condition of AXLEntry
    * @param objectClass an object class that participates AXLEntry as an attribute
    * @throws WTException If the object class is not related to AXLEntry
    * @return  an attribute name that can be used to construct a search condition for AXLEntry
    */
   private static String getAXLQueryAttribute(Class objectClass) throws WTException {
      if (objectClass.isAssignableFrom(AXLEntry.class)) {
         return WTAttributeNameIfc.ID_NAME;
      }
      else if (objectClass.isAssignableFrom(AXLContext.class)) {
         return AXLEntry.CONTEXT_ID;
      }
      else if (objectClass.isAssignableFrom(WTPart.class)) {
         return AXLEntry.OEM_PART_ID;
      }
      else if (objectClass.isAssignableFrom(ManufacturerPartMaster.class)) {
         return AXLEntry.MFR_PART_ID;
      }
      else if (objectClass.isAssignableFrom(VendorPartMaster.class)) {
         return AXLEntry.VDR_PART_ID;
      }
      else {
         throw new AXLException(RESOURCE, axlResource.MSG_INVALID_OBJECT_CLASS, new Object[] {objectClass.getName()});
      }
   }

   /**
    * Returns a search condition indicating that the targeted AXLEntry(s) must be
    * associated with the specified object.
    * @return a search condition that relates the AXL entries being searched to the specified object
    * @param object an object that the AXL entries being searched must relate to
    * @param objectClass the object class of the object
    * @throws wt.util.WTException
    */
   private static SearchCondition getAXLSearchCondition(Class objectClass, Persistable object) throws WTException {
      long id = (object == null) ? 0L : object.getPersistInfo().getObjectIdentifier().getId();
      return new SearchCondition(AXLEntry.class, getAXLQueryAttribute(objectClass), SearchCondition.EQUAL, id);
   }

   /**
    * Returns a search condition indicating that the targeted AXLEntry(s) must be
    * associated with the specified object.
    * @return a search condition that relates the AXL entries being searched to the specified object
    * @param object an object that the AXL entries being searched must relate to
    * @param objectClass the object class of the object
    * @throws wt.util.WTException
    */
   private static SearchCondition getAXLSearchCondition(Class objectClass, boolean isNull) throws WTException {
      String operator = isNull ? SearchCondition.EQUAL : SearchCondition.NOT_EQUAL;
      return new SearchCondition(AXLEntry.class, getAXLQueryAttribute(objectClass), operator, 0L);
   }

   /**
    * Returns a search condition indicating that the targeted AXL entries must be
    * associated to the collection of objects.
    * @return a search condition that relates the AXL entries being searched to the specified objects
    * @param objects a collection of objects
    * @param objectClass the class for each of the objects in the collection
    * @throws wt.util.WTException
    */
   private static SearchCondition getAXLSearchCondition(Class objectClass, WTCollection objects) throws WTException {
      return new SearchCondition(AXLEntry.class, getAXLQueryAttribute(objectClass), objects.toIdArray());
   }

   /**
    * Queries the database and returns a collection of distinct OEM parts
    * that are related to the specified AXLEntries
    *
    * @param entries
    * @throws WTException
    * @return a collection of OEM parts
    */
   private WTCollection getOemPartsForEntries(WTCollection entries) throws WTException {
      // SELECT entry.ClassnameKeyC4, entry.idA3C4
      // FROM   AXLEntry entry
      // WHERE  entry.idA2A2 IN <entry-ids>;
      try {
         QuerySpec qs = new QuerySpec();
         qs.setDistinct(true);
         int idx = qs.appendClassList(AXLEntry.class, false);
         qs.appendSelectAttribute(AXLEntry.OEM_PART_CLASSNAME, idx, false);
         qs.appendSelectAttribute(AXLEntry.OEM_PART_ID       , idx, false);
         qs.appendWhere(getAXLSearchCondition(AXLEntry.class, entries), new int[] {idx});
         WTHashSet oemParts = new WTHashSet();
         return (WTSet) PersistenceHelper.manager.find(qs, oemParts);
      }
      catch (WTPropertyVetoException e) {
         throw new AXLException(e);
      }
   }

   /**
    * Queries the database to find oem preference rollup for all context oem part
    * pairs related to the given axl entries collection.
    * @return  a map where the keys are OEMPartAXLContextLink and values are {@link java.lang.Number}
    * that represent the rollup preferences of corresponding links
    * @param links a collection of OEMPartAXLContextLink whose rollups are being queried
    * @throws WTException
    */
   private static WTKeyedMap getOemRollupMap(WTCollection links) throws WTException {
      // SELECT link.classnameA2A2, link.idA2A2, MAX(entry.amlPreference) AS ROLLUP
      // FROM   AXLEntry entry, OEMPartAXLContextLink link
      // WHERE  entry.idA3D4 = link.idA3B5
      //  AND   entry.idA3C4 = link.idA3A5
      //  AND   entry.idA3A4 > 0
      //  AND   link.idA2A2 IN <link-ids>
      // GROUP BY link.classnameA2A2, link.idA2A2;

      QuerySpec qs = new QuerySpec();
      qs.setAdvancedQueryEnabled(true);

      int idxEntry = qs.appendClassList(AXLEntry.class, false);
      int idxLink  = qs.appendClassList(OEMPartAXLContextLink.class, false);
      ClassAttribute linkName = new ClassAttribute(OEMPartAXLContextLink.class, WTAttributeNameIfc.OID_CLASSNAME);
      ClassAttribute linkId   = new ClassAttribute(OEMPartAXLContextLink.class, WTAttributeNameIfc.ID_NAME);
      qs.appendSelect(linkName, false);
      qs.appendSelect(linkId, false);
      qs.appendSelect(SQLFunction.newSQLFunction(SQLFunction.MAXIMUM,
         new ClassAttribute(AXLEntry.class, AXLEntry.AML_PREFERENCE_DATA)), false);

      qs.appendWhere(new SearchCondition(AXLEntry.class, AXLEntry.CONTEXT_ID,
                                         OEMPartAXLContextLink.class, OEMPartAXLContextLink.CONTEXT_ID),
                     new int[] {idxEntry, idxLink});
      qs.appendAnd();
      qs.appendWhere(new SearchCondition(AXLEntry.class, AXLEntry.OEM_PART_ID,
                                         OEMPartAXLContextLink.class, OEMPartAXLContextLink.OEM_PART_ID),
                     new int[] {idxEntry, idxLink});
      qs.appendAnd();
      qs.appendWhere(new SearchCondition(AXLEntry.class, AXLEntry.MFR_PART_ID,
                                         SearchCondition.GREATER_THAN, 0L), new int[] {idxEntry});
      qs.appendAnd();
      qs.appendWhere(new SearchCondition(OEMPartAXLContextLink.class, WTAttributeNameIfc.ID_NAME,
                                         links.toIdArray()), new int[] {idxLink});

      qs.appendGroupBy(linkName, new int[] {idxLink}, false);
      qs.appendGroupBy(linkId  , new int[] {idxLink}, false);

      WTKeyedHashMap oemRollupMap = new WTKeyedHashMap();
      PersistenceServerHelper.manager.query(qs, oemRollupMap);
      return oemRollupMap;
   }

   /**
    * Queries the db for manufacturer part source counts for all OEMPartAXLContextLinks.
    * A preference threshold is used to only calculate count of sources that has AML
    * preference greater than the specified value. The threshold is DoNotUse for
    * SingleSource determination and 0 for NoAML.
    * @return  a map where the keys are {@link com.ptc.windchill.suma.axl.OEMPartAXLContextLink}
    * and values are {@link java.lang.Number} that contain the source counts for the
    * corresponding links.
    * @param links a collection of {@link com.ptc.windchill.suma.axl.OEMPartAXLContextLink}
    * @param preferenceThreshold a threshold for AML preference. A manufacturer part participating an AXL entry
    * can be counted as a source only if its AML preference is greater than this
    * threshold value.
    * @throws WTException
    */
   private static WTKeyedMap getSourceCountMap(WTCollection links, AXLPreference preferenceThreshold) throws WTException {
      // The ORIGINAL QUERY that contains COUNT(DISTINCT xxx) is not supported by Windchill
      // query layer, however, this can be achieved by an alternative approach. The alternative
      // approach is implemented.

      // ORIGINAL QUERY
      // SELECT link.classnameA2A2, link.idA2A2, COUNT(DISTINCT entry.idA3A4) AS SOURCE_COUNT
      // FROM   AXLEntry entry, OEMPartAXLContextLink link
      // WHERE  entry.idA3D4 = link.idA3B5
      //  AND   entry.idA3C4 = link.idA3A5
      //  AND   entry.idA3A4 > 0
      //  AND   entry.amlPreference > preferenceThreshold
      //  AND   link.idA2A2 IN <link-ids>
      // GROUP BY link.classnameA2A2, link.idA2A2;

      // ALTERNATIVE APPROACH
      // SELECT link.classnameA2A2, link.idA2A2, count_table.count
      // FROM OEMPartAXLContextLink link,
      //      (
      //       SELECT mfr_table.oem, mfr_table.ctx, COUNT(mfr_table.mfr) count
      //       FROM (
      //            SELECT DISTINCT e.idA3C4 oem, e.idA3D4 ctx, e.idA3A4 mfr
      //            FROM   AXLEntry e, OEMPartAXLContextLink l
      //            WHERE  e.idA3D4 = l.idA3B5
      //             AND   e.idA3C4 = l.idA3A5
      //             AND   e.idA3A4 > 0
      //             AND   e.amlPreferenceData > 20
      //             AND   l.idA3A5 IN (30557)
      //             ) mfr_table
      //       GROUP BY mfr_table.oem, mfr_table.ctx
      //      ) count_table
      // WHERE count_table.oem = link.ida3a5
      //  AND  count_table.ctx = link.ida3b5;

      try {
         // inner most query: gets unique mfr part ids
         QuerySpec qsMfr = new QuerySpec();
         qsMfr.setDistinct(true);
         qsMfr.setAdvancedQueryEnabled(true);
         int idxEntry = qsMfr.appendClassList(AXLEntry.class, false);
         int idxLink1 = qsMfr.appendClassList(OEMPartAXLContextLink.class, false);
         qsMfr.getFromClause().setAliasPrefix("C");

         ClassAttribute oemId = new ClassAttribute(AXLEntry.class, AXLEntry.OEM_PART_ID);
         ClassAttribute ctxId = new ClassAttribute(AXLEntry.class, AXLEntry.CONTEXT_ID);
         ClassAttribute mfrId = new ClassAttribute(AXLEntry.class, AXLEntry.MFR_PART_ID);

         oemId.setColumnAlias("oem");
         ctxId.setColumnAlias("ctx");
         mfrId.setColumnAlias("mfr");

         qsMfr.appendSelect(oemId, new int[] {idxEntry}, false);
         qsMfr.appendSelect(ctxId, new int[] {idxEntry}, false);
         qsMfr.appendSelect(mfrId, new int[] {idxEntry}, false);

         qsMfr.appendWhere(new SearchCondition(AXLEntry.class, AXLEntry.OEM_PART_ID,
                                               OEMPartAXLContextLink.class, OEMPartAXLContextLink.OEM_PART_ID),
                           new int[] {idxEntry, idxLink1});
         qsMfr.appendAnd();
         qsMfr.appendWhere(new SearchCondition(AXLEntry.class, AXLEntry.CONTEXT_ID,
                                               OEMPartAXLContextLink.class, OEMPartAXLContextLink.CONTEXT_ID),
                           new int[] {idxEntry, idxLink1});
         qsMfr.appendAnd();
         qsMfr.appendWhere(new SearchCondition(AXLEntry.class, AXLEntry.MFR_PART_ID,
                                               SearchCondition.GREATER_THAN, 0L),
                           new int[] {idxEntry});
         if (preferenceThreshold != null) {
            qsMfr.appendAnd();
            qsMfr.appendWhere(new SearchCondition(AXLEntry.class, AXLEntry.AML_PREFERENCE_DATA,
                                                  SearchCondition.GREATER_THAN, preferenceThreshold.getOrder()),
                              new int[] {idxEntry});
         }
         qsMfr.appendAnd();
         qsMfr.appendWhere(new SearchCondition(OEMPartAXLContextLink.class, WTAttributeNameIfc.ID_NAME,
                                               links.toIdArray()),
                           new int[] {idxLink1});

         // inner query: gets mfr part id count
         QuerySpec qsCount = new QuerySpec();
         qsCount.setAdvancedQueryEnabled(true);

         int idxMfr = qsCount.appendFrom(new SubSelectExpression(qsMfr));
         qsCount.getFromClause().setAliasPrefix("B");
         String mfrAlias = qsCount.getFromClause().getAliasAt(idxMfr);

         TableColumn mfrOem = new TableColumn(mfrAlias, "oem");
         TableColumn mfrCtx = new TableColumn(mfrAlias, "ctx");
         TableColumn mfrMfr = new TableColumn(mfrAlias, "mfr");
         SQLFunction mfrCount = SQLFunction.newSQLFunction(SQLFunction.COUNT, mfrMfr);
         mfrOem.setColumnAlias("mfrOem");
         mfrCtx.setColumnAlias("mfrCtx");
         mfrCount.setColumnAlias("mfrCount");

         qsCount.appendSelect(mfrOem, new int[] {idxMfr}, false);
         qsCount.appendSelect(mfrCtx, new int[] {idxMfr}, false);
         qsCount.appendSelect(mfrCount, new int[] {idxMfr}, false);

         qsCount.appendGroupBy(mfrOem, new int[] {idxMfr}, false);
         qsCount.appendGroupBy(mfrCtx, new int[] {idxMfr}, false);

         // outer query: gets link to count map
         QuerySpec qs = new QuerySpec();
         qs.setAdvancedQueryEnabled(true);
         int idxLink2 = qs.appendFrom(new ClassTableExpression(OEMPartAXLContextLink.class));
         int idxCount = qs.appendFrom(new SubSelectExpression(qsCount));
         String countAlias = qs.getFromClause().getAliasAt(idxCount);

         ClassAttribute linkName = new ClassAttribute(OEMPartAXLContextLink.class, WTAttributeNameIfc.OID_CLASSNAME);
         ClassAttribute linkId   = new ClassAttribute(OEMPartAXLContextLink.class, WTAttributeNameIfc.ID_NAME);
         ClassAttribute linkOem  = new ClassAttribute(OEMPartAXLContextLink.class, OEMPartAXLContextLink.OEM_PART_ID);
         ClassAttribute linkCtx  = new ClassAttribute(OEMPartAXLContextLink.class, OEMPartAXLContextLink.CONTEXT_ID);
         TableColumn countCount = new TableColumn(countAlias, "mfrCount");
         TableColumn countOem = new TableColumn(countAlias, "mfrOem");
         TableColumn countCtx = new TableColumn(countAlias, "mfrCtx");

         qs.appendSelect(linkName, new int[] {idxLink2}, false);
         qs.appendSelect(linkId,   new int[] {idxLink2}, false);
         qs.appendSelect(countCount, new int[] {idxCount}, false);

         SearchCondition scOem = new SearchCondition(countOem, SearchCondition.EQUAL, linkOem);
         scOem.setFromIndicies(new int[] {idxCount, idxLink2}, 0);
         qs.appendWhere(scOem);
         qs.appendAnd();
         SearchCondition scCtx = new SearchCondition(countCtx, SearchCondition.EQUAL, linkCtx);
         scCtx.setFromIndicies(new int[] {idxCount, idxLink2}, 0);
         qs.appendWhere(scCtx);

         WTKeyedHashMap sourceCountMap = new WTKeyedHashMap();
         if (logger.isTraceEnabled()) logger.trace("qs = " + qs);
         PersistenceServerHelper.manager.query(qs, sourceCountMap);
         return sourceCountMap;
      }
      catch (WTPropertyVetoException e) {
         throw new AXLException(e);
      }
   }

   /**
    * Returns all vendor parts that are related to the specified context,
    * OEM part, and manufacturer part master.
    * If context is null, returns all related vendor parts regardless of sourcing context.
    *
    * <BR><BR><B>Supported API: </B>false
    * @param context an AXL context
    * @param oemPart an OEM part
    * @param manufacturerPartMaster a manufacturer part master
    * @return  a collection of vendor parts that meet the search criteria
    * @exception wt.util.WTException
    */
   private WTCollection getVendorParts(AXLContext context, WTPart oemPart, ManufacturerPartMaster manufacturerPartMaster)
   throws WTException {
       QueryResult qr = findVendorParts(context, oemPart, manufacturerPartMaster);
       // Flat result to remove arrays
       ObjectVector ov = new ObjectVector();
       while (qr.hasMoreElements()) ov.addElement(qr.nextElement());
       qr = new QueryResult(ov);
       // Get latest iteration of supplier parts given supplier masters
       QueryResult partsQr = ConfigHelper.service.filteredIterationsOf(qr, new LatestConfigSpec());
       WTCollection result = new WTHashSet(partsQr);
       if(logger.isTraceEnabled()) logger.trace("Vendor parts result = " + result);
      return result;
   }

   /**
    * Returns an OEMParAXLContextLink that is associated with the context and oem part
    * @param context an AXL context
    * @param oemPart an OEM part
    * @throws WTException If no links exist for the specified condition
    * @return  the link that is found
    */
   public OEMPartAXLContextLink getLink(AXLContext context, WTPart oemPart) throws WTException {
      validateContext(context);
      validateOemPart(oemPart, null);

      // SELECT *
      // FROM   OEMPartAXLContextLink
      // WHERE  IdA3B5 = <ctx-id>
      //  AND   IdA3A5 = <oem-part-id>;
      QuerySpec qs = new QuerySpec();
      int idx = qs.appendClassList(OEMPartAXLContextLink.class, true);
      qs.appendWhere(new SearchCondition(OEMPartAXLContextLink.class,
                                         OEMPartAXLContextLink.OEM_PART_ID,
                                         SearchCondition.EQUAL,
                                         oemPart.getPersistInfo().getObjectIdentifier().getId()),
                     new int[] {idx});
      qs.appendAnd();
      qs.appendWhere(new SearchCondition(OEMPartAXLContextLink.class,
                                         OEMPartAXLContextLink.CONTEXT_ID,
                                         SearchCondition.EQUAL,
                                         context.getPersistInfo().getObjectIdentifier().getId()),
                     new int[] {idx});
      QueryResult qr = PersistenceHelper.manager.find(qs);
      if (qr.hasMoreElements()) {
         return (OEMPartAXLContextLink) unfoldQueryResult(qr);
      }

      return null;
   }

   /**
    * Processes NEW_ITERATION event for OEM parts
    * Copy forward all AXLEntries and OEMPartAXLContextLinks from the old to the new iteration
    * @param oemParts a collection of OEM parts
    * @throws WTException
    */
   private void processNewIterationForOEMPart(WTCollection oemParts) throws WTException {
      logger.trace("processNewIterationForOEMPart: size=" + oemParts.size());

      // Gets all the predecessors
      WTValuedMap predecessorsToTargetsMap = new WTValuedHashMap(WTValuedHashMap.getInitialCapacity(oemParts.size()));
      Iterator iterator = oemParts.persistableIterator();
      while (iterator.hasNext()) {
         WTPart oemPart = (WTPart) iterator.next();
         ObjectReference predecessor = oemPart.getIterationInfo().getPredecessor();
         if (predecessor != null && predecessor.getKey() != null) {
            predecessorsToTargetsMap.put(predecessor, oemPart);
         }
      }
      WTCollection predecessors = predecessorsToTargetsMap.wtKeySet();
      logger.trace("Found " + predecessors.size() + " predecessors.");
      // there's nothing to copy forward for the first iteration
      if (predecessors.size() == 0) {
         return;
      }

      // Copies all AML/AVL and OEM to Context links
      copyAXL(predecessorsToTargetsMap);

      // Queries for replacement mapping and dispatches OEMPartCopyEvent
      for (Iterator i = predecessors.persistableIterator(); i.hasNext();) {
         WTPart oldOemPart = (WTPart) i.next();
         WTPart newOemPart = (WTPart) ((ObjectReference) predecessorsToTargetsMap.get(oldOemPart)).getObject();
         // SELECT old.ClassnameKeyA2, old.idA2A2, new.ClassnameKeyA2, new.idA2A2
         // FROM   AXLEntry old, AXLEntry new
         // WHERE  old.idA3C4 = <old-oem-part-id>
         //  AND   new.idA3C4 = <new-oem-part-id>j
         //  AND   old.idA3A4 = new.idA3A4
         //  AND   old.idA3B4 = new.idA3B4
         //  AND   old.idA3D4 = new.idA3D4;

         QuerySpec qsMap = new QuerySpec();
         int idxOld = qsMap.appendFrom(new ClassViewExpression(AXLEntry.class));
         int idxNew = qsMap.appendFrom(new ClassViewExpression(AXLEntry.class));

         qsMap.appendSelectAttribute(WTAttributeNameIfc.OID_CLASSNAME, idxOld, false);
         qsMap.appendSelectAttribute(WTAttributeNameIfc.ID_NAME,       idxOld, false);
         qsMap.appendSelectAttribute(WTAttributeNameIfc.OID_CLASSNAME, idxNew, false);
         qsMap.appendSelectAttribute(WTAttributeNameIfc.ID_NAME,       idxNew, false);

         qsMap.appendWhere(getAXLSearchCondition(WTPart.class, oldOemPart), new int[] {idxOld});
         qsMap.appendAnd();
         qsMap.appendWhere(getAXLSearchCondition(WTPart.class, newOemPart), new int[] {idxNew});
         qsMap.appendAnd();
         qsMap.appendWhere(new SearchCondition(AXLEntry.class, AXLEntry.MFR_PART_ID,
                                               AXLEntry.class, AXLEntry.MFR_PART_ID),
                           new int[] {idxOld, idxNew});
         qsMap.appendAnd();
         qsMap.appendWhere(new SearchCondition(AXLEntry.class, AXLEntry.VDR_PART_ID,
                                               AXLEntry.class, AXLEntry.VDR_PART_ID),
                           new int[] {idxOld, idxNew});
         qsMap.appendAnd();
         qsMap.appendWhere(new SearchCondition(AXLEntry.class, AXLEntry.CONTEXT_ID,
                                               AXLEntry.class, AXLEntry.CONTEXT_ID),
                           new int[] {idxOld, idxNew});

         WTKeyedHashMap entryMap = new WTKeyedHashMap();
         entryMap = (WTKeyedHashMap) PersistenceHelper.manager.find(qsMap, entryMap);
         dispatchOEMPartCopyEvent(OEMPartCopyEvent.COPY_PART, newOemPart, entryMap);
      }

      logger.debug("processNewIterationForOEMPart():  AXLEntry(s) and OEMPartAXLContextLink(s) successfully inserted.");
   }

   /**
    * Processes WorkInProgressServiceEvent.POST_CHECKIN event for OEM part (WTPart)
    * Sends suma notifications
    * @param postCheckinMap
    * @throws wt.util.WTException
    */
   private void processPostCheckinForOEMPart(WTValuedMap postCheckinMap) throws WTException {
      logger.debug("processPostCheckinForOEMPart - start");

      // filters out entries where AML/AVL information does not exist in either
      // previous iteration or the latest iteration
      // TODO: does this need to be run here or should be moved into the queued task?
      //       the queries doesn't seem to be expensive, though.

      WTSet oldParts = postCheckinMap.wtKeySet();
      WTCollection newParts = postCheckinMap.wtValues();
      // finds new parts that are not associated with any AXL
      WTSet oldPartsWithoutAxl = ObjectNotificationHelper.getOemPartsWithoutAxl(oldParts);
      WTSet newPartsWithoutAxl = ObjectNotificationHelper.getOemPartsWithoutAxl(newParts);

      WTValuedHashMap updatedPostCheckinMap = new WTValuedHashMap();
      for (Iterator i = postCheckinMap.wtKeySet().persistableIterator(); i.hasNext();) {
         WTPart oldPart = (WTPart) i.next();
         WTPart newPart = (WTPart) postCheckinMap.getPersistable(oldPart);
         if (oldPartsWithoutAxl.contains(oldPart) && newPartsWithoutAxl.contains(newPart)) {
            continue;
         }
         updatedPostCheckinMap.put(oldPart, newPart);
      }

      ObjectNotificationHelper.doObjectNotification(updatedPostCheckinMap);

      logger.debug("processPostCheckinForOEMPart - done.");
   }

   /**
    * Processes EnterpriseServiceEvent.POST_CHECKIN event for OEM part (WTPart)
    * Copies all AXL
    * @param postCheckinMap
    * @throws wt.util.WTException
    */
   private void processPostCopyForOEMPart(WTValuedMap originalToCopyMap) throws WTException {
      logger.debug("processPostCopyForOEMPart, size = " + originalToCopyMap.size());
      copyAXL(originalToCopyMap);
      logger.debug("processPostCopyForOEMPart:  AXLEntry(s) and OEMPartAXLContextLink(s) successfully inserted.");
   }

   /**
    * Processes POST_CREATE event for OrgContainer
    * Creates the default context for the org container
    *
    * @param container an organization container
    * @throws WTException
    */
   private void processPostCreateForOrgContainer(OrgContainer container) throws WTException {
      logger.trace("POST_CREATE: create default AXLContext for OrgContainer: " + container.getContainerInfo().getName());
      createDefaultContext(WTContainerRef.newWTContainerRef(container));
   }

   /**
    * Processes PersistenceManagerEvent.POST_DELETE for AXLEntry
    * <p>
    * Retrieve collection of affected links [OEMPartAXLContextLink] that were
    * previously stored in the transaction global map, and updates the links.
    *
    * @throws WTException
    */
   private void processPostDeleteForAXLEntry() throws WTException {
      logger.trace("processPostDeleteForAXLEntry");
      Map globalMap = Transaction.getGlobalMap();
      if (globalMap.containsKey(SUMA_LINKS_FOR_REFRESH)) {
         WTCollection links = (WTCollection) globalMap.get(SUMA_LINKS_FOR_REFRESH);
         if (links != null && !links.isEmpty()) {
            updateLinks(links);
         }
      }
   }

   /**
    * Processes POST_MODIFY event for AXLEntry
    * Updates/Deletes OEMPartAXLContextLink
    * @throws WTException
    */
   private void processPostModifyForAXLEntry() throws WTException {
      logger.trace("processPostModifyForAXLEntry: started");
      WTCollection links = (WTCollection) Transaction.getGlobalMap().get(SUMA_LINKS_FOR_REFRESH);
      updateLinks(links);
      logger.trace("processPostModifyForAXLEntry: completed");
   }

   /**
    * Processes PersistenceManagerEvent.POST_STORE for AXLEntry
    * Insert or update links as necessary
    *
    * @param entries
    * @throws WTException
    */
   private void processPostStoreForAXLEntry(WTCollection entries) throws WTException {
      logger.trace("processPostStoreForAXLEntry: size=" + entries.size());

      try {
         // Step 1. Create links for all entries that do not have a link yet

         // original implementation, not supported by SQL Server!!!
         // SELECT idA3D4, idA3C4, classnamekeyC4
         // FROM AXLEntry A0
         // WHERE A0.idA2A2 IN <entry-ids>
         //  MINUS
         // SELECT idA3B5, idA3A5, classnamekeyroleAObjectRef
         // FROM OEMPartAXLContextLink B0
         // WHERE (B0.idA3B5, B0.idA3A5, B0.classnamekeyroleAObjectRef) IN (
         //       SELECT C0.idA3D4, C0.idA3C4, C0.classnamekeyC4
         //       FROM AXLEntry C0 WHERE C0.idA2A2 IN <entry-ids> )

         // alternative approach (not implemented)
         // SELECT DISTINCT IdA3D4, IdA3C4, ClassnameKeyC4
         // FROM   AXLEntry
         // WHERE  IdA2A2 IN <entry-ids>
         //  AND   (IdA3D4, IdA3C4) NOT IN (
         //       SELECT IdA3B5, IdA3A5
         //       FROM   OEMPartAXLContextLink
         //       WHERE  (IdA3B5, IdA3A5) IN (
         //             SELECT IdA3D4, IdA3C4
         //             FROM   AXLEntry
         //             WHERE  IdA2A2 IN <entry-ids>
         //       )
         // );

         /*
         // entry related ctx-oem pairs
         QuerySpec qsSub = new QuerySpec();
         qsSub.getFromClause().setAliasPrefix("C");
         qsSub.setAdvancedQueryEnabled(true);
         int idxSub = qsSub.appendClassList(AXLEntry.class, false);
         qsSub.appendSelectAttribute(AXLEntry.CONTEXT_ID, idxSub, false);
         qsSub.appendSelectAttribute(AXLEntry.OEM_PART_ID, idxSub, false);
         qsSub.appendSelectAttribute(AXLEntry.OEM_PART_CLASSNAME, idxSub, false);
         qsSub.appendWhere(getAXLSearchCondition(AXLEntry.class, entries), new int[] {idxSub});

         // all ctx-oem pairs in links
         QuerySpec qsLink = new QuerySpec();
         qsLink.getFromClause().setAliasPrefix("B");
         //qsLink.setAdvancedQueryEnabled(true);
         int idxLink = qsLink.appendClassList(OEMPartAXLContextLink.class, false);
         qsLink.appendSelectAttribute(OEMPartAXLContextLink.CONTEXT_ID, idxLink, false);
         qsLink.appendSelectAttribute(OEMPartAXLContextLink.OEM_PART_ID, idxLink, false);
         qsLink.appendSelectAttribute( OEMPartAXLContextLink.OEM_PART_CLASSNAME, idxLink, false );
         ColumnListExpression linkCtxOem = new ColumnListExpression();
         linkCtxOem.addColumn(new ClassAttribute(OEMPartAXLContextLink.class, OEMPartAXLContextLink.CONTEXT_ID));
         linkCtxOem.addColumn(new ClassAttribute(OEMPartAXLContextLink.class, OEMPartAXLContextLink.OEM_PART_ID));
         linkCtxOem.addColumn(new ClassAttribute(OEMPartAXLContextLink.class,  OEMPartAXLContextLink.OEM_PART_CLASSNAME));

         qsLink.appendWhere(new SearchCondition(
            linkCtxOem, SearchCondition.IN, new SubSelectExpression(qsSub)), new int[] {idxLink, idxLink, idxLink});

         // all ctx-oem pairs in entries
         QuerySpec qsEntry = new QuerySpec();
         qsEntry.getFromClause().setAliasPrefix("A");
         qsEntry.setDistinct(true);
         int idxEntry = qsEntry.appendClassList(AXLEntry.class, false);
         qsEntry.appendSelectAttribute(AXLEntry.CONTEXT_ID, idxEntry, false);
         qsEntry.appendSelectAttribute(AXLEntry.OEM_PART_ID, idxEntry, false);
         qsEntry.appendSelectAttribute(AXLEntry.OEM_PART_CLASSNAME, idxEntry, false);
         qsEntry.appendWhere(getAXLSearchCondition(AXLEntry.class, entries), new int[] {idxEntry});

         CompoundQuerySpec cqs = new CompoundQuerySpec();
         cqs.setAdvancedQueryEnabled(true);
         cqs.setSetOperator(SetOperator.MINUS);
         cqs.addComponent(qsEntry);
         cqs.addComponent(qsLink);

         logger.trace( "processPostStoreForAXLEntry: CompoundQuerySpec:\n" + cqs.toString());

         QueryResult qr = PersistenceServerHelper.manager.query(cqs);
         */
         // new implementation (as of X-05 M030 Build 07) supported by SQL Server
         // SELECT DISTINCT Axl.IdA3D4, Axl.IdA3C4, Axl.classnameKeyC4
         // FROM   AXLEntry Axl
         // WHERE  Axl.IdA2A2 IN <entry-ids> AND
         // NOT EXISTS (SELECT 1
         //             FROM   OEMPartAXLContextLink Link
         //             WHERE  (Link.IdA3B5 = Axl.idA3D4)
         //              AND   (Link.IdA3A5 = Axl.IdA3C4))

         QuerySpec qsAxl = new QuerySpec();
         qsAxl.getFromClause().setAliasPrefix("Axl");
         qsAxl.setDistinct(true);
         qsAxl.setAdvancedQueryEnabled(true);
         int idxAxl = qsAxl.appendClassList(AXLEntry.class, false);
         ClassAttribute axlCtxId = new ClassAttribute(AXLEntry.class, AXLEntry.CONTEXT_ID);
         ClassAttribute axlOemId = new ClassAttribute(AXLEntry.class, AXLEntry.OEM_PART_ID);
         ClassAttribute axlOemCN = new ClassAttribute(AXLEntry.class, AXLEntry.OEM_PART_CLASSNAME);
         qsAxl.appendSelect(axlCtxId, new int[] {idxAxl}, false);
         qsAxl.appendSelect(axlOemId, new int[] {idxAxl}, false);
         qsAxl.appendSelect(axlOemCN, new int[] {idxAxl}, false);
         qsAxl.appendWhere(getAXLSearchCondition(AXLEntry.class, entries), new int[] {idxAxl});
         qsAxl.appendAnd();

         QuerySpec qsLink = new QuerySpec();
         qsLink.getFromClause().setAliasPrefix("Link");
         qsLink.setAdvancedQueryEnabled(true);
         int idxLink = qsLink.appendClassList(OEMPartAXLContextLink.class, false);
         qsLink.appendSelect(new ConstantExpression(Boolean.TRUE), false);
         ClassAttribute linkCtxId = new ClassAttribute(OEMPartAXLContextLink.class, OEMPartAXLContextLink.CONTEXT_ID);
         ClassAttribute linkOemId = new ClassAttribute(OEMPartAXLContextLink.class, OEMPartAXLContextLink.OEM_PART_ID);
         TableExpression[] tables = new TableExpression[] {
               qsAxl.getFromClause().getTableExpressionAt(idxAxl),
               qsLink.getFromClause().getTableExpressionAt(idxLink)
         };
         String[] aliases = new String[] {
               qsAxl.getFromClause().getAliasAt(idxAxl),
               qsLink.getFromClause().getAliasAt(idxLink)
         };
         qsLink.appendWhere(new SearchCondition(axlCtxId, SearchCondition.EQUAL, linkCtxId), tables, aliases);
         qsLink.appendAnd();
         qsLink.appendWhere(new SearchCondition(axlOemId, SearchCondition.EQUAL, linkOemId), tables, aliases);

         qsAxl.appendWhere(new NegatedExpression(new ExistsExpression(qsLink)), null);
         logger.trace( "processPostStoreForAXLEntry: Query =\n" + qsAxl.toString());

         QueryResult qr = PersistenceServerHelper.manager.query(qsAxl);

         WTHashSet linksToCreate = new WTHashSet();
         while (qr.hasMoreElements()) {
            Object[] ctxOem = (Object[]) qr.nextElement();
            long ctxId = ((Number) ctxOem[0]).longValue();
            long oemId = ((Number) ctxOem[1]).longValue();
            String partClassName = (String) ctxOem[2];

            AXLContext context = (AXLContext) PersistenceHelper.manager.refresh(
                                 ObjectIdentifier.newObjectIdentifier(AXLContext.class, ctxId));

            ObjectIdentifier oemOid = ObjectIdentifier.newObjectIdentifier(Class.forName(partClassName), oemId);
            WTPart oemPart = (WTPart) PersistenceHelper.manager.refresh(oemOid);

            OEMPartAXLContextLink link = OEMPartAXLContextLink.newOEMPartAXLContextLink(oemPart, context);

            linksToCreate.add(link);
         }

         if (!linksToCreate.isEmpty()) {
            PersistenceServerHelper.manager.insert(linksToCreate);
         }
         logger.debug("processPostStoreForAXLEntry: inserted " + linksToCreate.size() + " links");
      }
      catch (WTPropertyVetoException e) {
         throw new AXLException(e);
      }
      catch (ClassNotFoundException e) {
         throw new AXLException(e);
      }

      // Step 2. Finds all affected links and updates them
      WTCollection links = getAffectedLinks(entries);
      updateLinks(links);
      logger.debug("processPostStoreForAXLEntry: " + links.size() + " links updated (including newly inserted ones).");
   }


   /**
    * Processes multi-object PersistenceManagerEvent.PRE_DELETE for AXLContext
    * Vetoes deletion if any context is associated with any AXLEntry(s)
    *
    * @param contexts
    * @throws WTException
    */
   private void processPreDeleteForAXLContext(WTCollection contexts) throws WTException {
      logger.trace("processPreDeleteForAXLContexts: contexts.size=" + contexts.size());

      // SELECT 1
      // FROM [NullTableExpression]
      // WHERE EXISTS (
      //    SELECT axl.IdA2A2
      //    FROM AXLEntry axl
      //    WHERE axl.IdA3D4 IN (<ctx-ids>)
      // );

      QuerySpec qs = new QuerySpec();
      qs.setAdvancedQueryEnabled( true );
      qs.appendSelect(new ConstantExpression(Boolean.TRUE), false);
      int idxNull = qs.appendFrom(new NullTableExpression());

      QuerySpec qsSub = new QuerySpec();
      qsSub.setAdvancedQueryEnabled(true);
      int idxEntry = qsSub.appendClassList(AXLEntry.class, false);
      qsSub.appendSelectAttribute(WTAttributeNameIfc.ID_NAME, idxEntry, true);
      qsSub.appendWhere(getAXLSearchCondition(AXLContext.class, contexts), new int[] {idxEntry});
      qs.appendWhere(new ExistsExpression(qsSub), new int[] {idxNull});

      QueryResult qr = PersistenceHelper.manager.find(qs);
      if (qr.hasMoreElements()) {
         throw new AXLException(RESOURCE, axlResource.MSG_CANNOT_DELETE_REFERENCED_CONTEXTS, null);
      }

      logger.debug("processPreDeleteForAXLContexts: deletion permitted.");
   }

   /**
    * Processes multi-object PersistenceManagerEvent.PRE_DELETE for AXLEntry
    * Stores affected OEMPartAXLContextLink(s) to transaction context so that
    * during POST_DELETE the links can be retrieved.
    *
    * @param entries AXLEntry(s) being deleted
    * @throws WTException
    */
   private void processPreDeleteForAXLEntry(WTCollection entries) throws WTException {
      logger.trace("processPreDeleteForAXLEntries: size=" + entries.size());
      WTCollection links = getAffectedLinks(entries);
      logger.debug("processPreDeleteForAXLEntries: found " + links.size() + " links.");

      WTSet set = (WTSet) Transaction.getGlobalMap().get(SUMA_LINKS_FOR_REFRESH);
      if (set == null) {
         Transaction.getGlobalMap().put(SUMA_LINKS_FOR_REFRESH, links);
      }
      else {
         set.addAll(links);
      }
   }

   /**
    * Processes multi-object PersistenceManagerEvent.PRE_DELETE for ManufacturerPartMaster
    * Vetoes the deletion if any mfr parts participate AMLs.
    *
    * @param mfrPartMasters the manufacturer part masters being deleted
    * @throws WTException
    */
   private void processPreDeleteForManufacturerPartMaster(WTCollection mfrPartMasters) throws WTException {
      logger.trace("processPreDeleteForManufacturerPartMaster: size=" + mfrPartMasters.size());
      validateBeforeDeleteSupplierPartMasters(ManufacturerPartMaster.class, mfrPartMasters);
      logger.trace("processPreDeleteForManufacturerPartMaster: deletion permitted");
   }

   /**
    * Processes multi-object PersistenceManagerEvent.PRE_DELETE for VendorPartMaster
    * Vetoes deletion if vdr parts are related to any AVLs.
    *
    * @param vdrPartMasters vendor part masters being deleted
    * @throws WTException
    */
   private void processPreDeleteForVendorPartMaster(WTCollection vdrPartMasters) throws WTException {
      logger.trace("processPreDeleteForVendorPartMaster: size=" + vdrPartMasters.size());
      validateBeforeDeleteSupplierPartMasters(VendorPartMaster.class, vdrPartMasters);
      logger.trace("processPreDeleteForVendorPartMaster: deletion permitted");
   }

   /**
    * Processes multi-object PersistenceManagerEvent.PRE_MODIFY for AXLEntry
    * Stores affected OEMPartAXLCon2textLink(s) to transaction context so that
    * during POST_MODIFY the links can be retrieved.
    *
    * @param entries a collection of AXLEntry being deleted
    * @throws WTException
    */
   private void processPreModifyForAXLEntry(WTCollection entries) throws WTException {
      logger.trace("processPreModifyForAXLEntry: entries.size=" + entries.size());
      validateAXLEntriesBeforeModifyOrStore(entries);
      WTCollection links = getAffectedLinks(entries);
      logger.trace("processPreModifyForAXLEntry: links.size=" + links.size());

      WTSet set = (WTSet) Transaction.getGlobalMap().get(SUMA_LINKS_FOR_REFRESH);
      if (set == null) {
         Transaction.getGlobalMap().put(SUMA_LINKS_FOR_REFRESH, links);
      }
      else {
         set.addAll(links);
      }
   }

   /**
    * Processes PersistenceManagerEvent.PRE_STORE event for AXLEntry
    * Vetoes the operation to prevent data integrity violations
    *
    * @param entries
    * @throws WTException
    */
   private void processPreStoreForAXLEntry(WTCollection entries) throws WTException {
      logger.trace("processPreStoreForAXLEntry: size=" + entries.size());
      validateAXLEntriesBeforeModifyOrStore(entries);
      logger.trace("processPreStoreForAXLEntry: end.");
   }

   /**
    * Processes PersistenceManagerEvent.PRE_STORE event for SupplierPart
    * Vetoes the operation to prevent data integrity violations
    *
    * @param entries
    * @throws WTException
    */
   private void processPreStoreForSupplierPart(WTCollection parts) throws WTException {
      logger.trace("processPreStoreForSupplierPart: size=" + parts.size());
      for (Iterator i = parts.persistableIterator(); i.hasNext();) {
         SupplierPart part = (SupplierPart) i.next();
         //WTContainerRef container = WTContainerHelper.getContainerRef(part);
         WTContainerRef container = WTContainerHelper.service.getOrgContainerRef(part);
         WTOrganization organization = part.getOrganization();
         Class supplierClass = (part instanceof VendorPart) ? Vendor.class : Manufacturer.class;
         ClassInfo classInfo = WTIntrospector.getClassInfo(supplierClass);
         if (!SupplierHelper.service.isSupplierOrganization(organization, supplierClass, container) ) {
            throw new AXLException(RESOURCE, axlResource.MSG_ORG_IS_NOT_A_SUPPLIER_ORG,
                  new Object[] { organization.getDisplayIdentifier(), classInfo.toDisplayNameMessage()});
         }
      }
      logger.trace("processPreStoreForSupplierPart: end.");
   }

   /**
    * Convenient method to get rid of the guess work of whether
    * an object in a query result is an object array
    * @param qr a query result
    * @throws WTException
    * @return
    */
   private Object unfoldQueryResult(QueryResult qr) throws WTException {
      Object o = qr.nextElement();
      if (o instanceof Object[]) {
         o = ((Object[]) o)[0];
      }
      return o;
   }

   /**
    * Updates links [OEMPartAXLContextLink] after entries [AXLEntry] are
    * deleted/modified.
    *
    * @param links [OEMPartAXLContextLink] links that need to be refreshed
    * @throws WTException
    */
   private void updateLinks(WTCollection links) throws WTException {
      if (links == null || links.isEmpty()) {
         logger.debug("updateLinks: no links found.");
         return;
      }
      logger.debug("updateLinks: input size="+links.size());

      // Step 1. Finds NO AML info for all ctx-part pairs
      WTKeyedMap amlCountMap = getSourceCountMap(links, null);
      logger.debug("*** amlCountMap ***");
      if (logger.isDebugEnabled()) {
         for (Iterator i = amlCountMap.wtKeySet().queryKeyIterator(); i.hasNext();) {
            QueryKey key = (QueryKey) i.next();
            logger.debug(key.toString() + " ==> " + amlCountMap.get(key));
         }
      }

      // Step 2. Finds SINGLE SOURCE info for all ctx-part pairs
      WTKeyedMap singleSourceMap = getSourceCountMap(links, AXLPreference.DO_NOT_USE);
      logger.debug("*** singleSourceMap ***");
      if (logger.isDebugEnabled()) {
         for (Iterator i = singleSourceMap.wtKeySet().queryKeyIterator(); i.hasNext();) {
            QueryKey key = (QueryKey) i.next();
            logger.debug(key.toString() + " ==> " + singleSourceMap.get(key));
         }
      }

      // Step 3. Finds OEM rollup prefs for all ctx-part pairs
      WTKeyedMap oemRollupMap = getOemRollupMap(links);
      logger.debug("*** oemRollupMap ***");
      if (logger.isDebugEnabled()) {
         for (Iterator i = oemRollupMap.wtKeySet().queryKeyIterator(); i.hasNext();) {
            QueryKey key = (QueryKey) i.next();
            logger.debug(key.toString() + " ==> " + AXLHelper.intToPreference(((Number) oemRollupMap.get(key)).intValue()));
         }
      }

      // Step 4. Finds all OEMPartAXLContextLinks for all ctx-part pairs and processes
      //         link objects as appropriate (delete, update)
      WTSet deleteSet = null;
      WTCollection updateSet = null;
      WTCollection createEventSet = null;
      for (Iterator i = links.persistableIterator(); i.hasNext();) {
         OEMPartAXLContextLink link = (OEMPartAXLContextLink) i.next();

         // check hasAML
         boolean hasAML = amlCountMap.containsKey(link) && ((Number) amlCountMap.get(link)).intValue() > 0;
         if (!hasAML) {
            if (deleteSet == null) {
               deleteSet = new WTHashSet(links.size());
            }
            deleteSet.connect(link, links);
            continue;
         }

         // check single source
         boolean isSingleSource = singleSourceMap.containsKey(link)
                        && ((Number) singleSourceMap.get(link)).intValue() == 1;
         if (!(link.isSingleSource() == isSingleSource)) {
            link.setSingleSource(isSingleSource);
            if (updateSet == null) {
               updateSet = new WTHashSet();
            }
            updateSet.connect(link, links);
         }
         AXLPreference rollup = null;
         AXLPreference linkPref=null;
         try{
             rollup = AXLHelper.intToPreference(((Number) oemRollupMap.get(link)).intValue());
         }catch(WTException exp){
             // Skip WTException in the case sourcing status preference value changed in rbinfo file after
                // some entries created with previous value. 
                if (logger.isDebugEnabled())
                    logger.debug(exp.getLocalizedMessage());
         }
         try{
             logger.debug("rollup=" + rollup + " oem pref=" + link.getOemPreference());
             linkPref = link.getOemPreference();
         }catch(WTException exp){
          // Skip WTException in the case sourcing status preference value changed in rbinfo file after
             // some entries created with previous value. 
             if (logger.isDebugEnabled())
                 logger.debug(exp.getLocalizedMessage());
         }
         if (linkPref == null) {
            if (rollup != null) {
               if (createEventSet == null) {
                  createEventSet = new WTHashSet();
               }
               createEventSet.add(link);
               if (updateSet == null) {
                  updateSet = new WTHashSet();
               }
               updateSet.connect(link, links);
               link.setOemPreference(rollup);
            }
         }
         else if (!linkPref.equals(rollup)) {
            // Added this null check as if after updating the AXL Entries if there are any invalid Manufactuer Souring status
            // with higher ranking it would prevent the updating the link as Invalid Sourcing status will be added as OEM Sourcing Status.
            if(rollup == null){
                rollup = AXLHelper.intToPreference(((Number) oemRollupMap.get(link)).intValue());
            }
            if (updateSet == null) {
               updateSet = new WTHashSet();
            }
            updateSet.connect(link, links);
            link.setOemPreference(rollup);
         }
      }

      if (deleteSet != null) {
         logger.debug("deleteSet:"+deleteSet.size() + " " + deleteSet);
         PersistenceServerHelper.manager.remove(deleteSet);
         dispatchOEMPreferenceEvent(deleteSet,OEMPreferenceEvent.REMOVE_PREFERENCE);
      }
      else {
         logger.debug("no links need to be deleted.");
      }

      if (updateSet != null) {
         logger.debug("updateSet: "+updateSet.size() + " " + updateSet);
         PersistenceServerHelper.manager.update(updateSet);
         if (createEventSet != null) {
            dispatchOEMPreferenceEvent(createEventSet, OEMPreferenceEvent.CREATE_PREFERENCE);
            updateSet.removeAll(createEventSet);
         }
         if (!updateSet.isEmpty()) {
            dispatchOEMPreferenceEvent(updateSet,OEMPreferenceEvent.MODIFY_PREFERENCE);
         }
      }
      else {
         logger.debug("no links need to be updated.");
      }

      links.clear();
      logger.debug("updateLinks succeeded.");
   }

   /**
    * Checks if AML with the specified OEM part and manufacturer part already exists.
    * This is to avoid an attemp to create C1-O1-M1 when C1-O1-M1-V1 already exists.
    *
    * @param vendorPartMaster
    * @param context
    * @param oemPart
    * @param manufacturerPartMaster
    * @throws WTException
    * @return
    */
   private AXLEntry validateBeforeAddAML(AXLContext context, WTPart oemPart, VendorPartMaster vendorPartMaster, ManufacturerPartMaster manufacturerPartMaster) throws WTException {
      // Checks if an AML with ctx, oem, mfr already exists
      if (hasAML(context, oemPart, manufacturerPartMaster)) {
         throw new AXLAlreadyExistsException(RESOURCE, axlResource.MSG_AML_WITH_OEM_MFR_ALREADY_EXISTS,
                              new Object[]{oemPart.getIdentity(), manufacturerPartMaster.getIdentity()});
      }

      if (vendorPartMaster == null) {
         return null;
      }

      // If vendor part is specified, find the AVL entry for update. throws exception if not found
      AXLEntry entry = findAVL(context, oemPart, vendorPartMaster, true);
      if (entry == null) {
         throw new AXLDoesNotExistException(RESOURCE, axlResource.MSG_AVL_WITH_OEM_VDR_DOES_NOT_EXIST,
                              new Object[] {oemPart.getIdentity(), vendorPartMaster.getIdentity()});
      }

      return entry;
   }

   /**
    * Checks if AVL with the specified OEM part and vendor part already exists.
    * This is to avoid an attempt to create C1-O1-V1 when C1-O1-M1-V1 already exists.
    *
    * @param manufacturerPartMaster
    * @param context
    * @param oemPart
    * @param vendorPartMaster
    * @throws WTException
    * @return
    */
   private WTCollection validateBeforeAddAVL(AXLContext context, WTPart oemPart, ManufacturerPartMaster manufacturerPartMaster, VendorPartMaster vendorPartMaster) throws WTException {
      // Checks if an AVL with ctx, oem, vdr already exists
      if (hasAVL(context, oemPart, vendorPartMaster)) {
         throw new AXLAlreadyExistsException(RESOURCE, axlResource.MSG_AVL_WITH_OEM_VDR_ALREADY_EXISTS,
                              new Object[]{oemPart.getIdentity(), vendorPartMaster.getIdentity()});
      }

      if (manufacturerPartMaster == null) {
         return null;
      }

      // If manufacturer part is specified, find all related AML/AXL entries.Throws exception if not found.
      WTCollection entries = findAML(context, oemPart, manufacturerPartMaster, true);
      if (entries == null || entries.isEmpty()) {
         throw new AXLDoesNotExistException(RESOURCE, axlResource.MSG_AML_WITH_OEM_MFR_DOES_NOT_EXIST,
                              new Object[] {oemPart.getIdentity(), manufacturerPartMaster.getIdentity()});
      }

      return entries;
   }

   /**
    * Checks if AML with the OEM part, manufacturer part, or AVL with the OEM part and vendor
    * part already exists before inserting a new entry.
    * For situations where existing row needs to be updated the row is locked for subsequent
    * update and the oid of the row returned. The lock will be released upon transcation commit.
    *
    * @param manufacturerPartMaster
    * @param vendorPartMaster
    * @param context
    * @param oemPart
    * @throws WTException
    */
   private void validateBeforeAddAXL(AXLContext context, WTPart oemPart, ManufacturerPartMaster manufacturerPartMaster, VendorPartMaster vendorPartMaster) throws WTException {
      // Step 1. Checks if AML or AVL already exists
      if (hasAXL(context, oemPart, manufacturerPartMaster, vendorPartMaster)) {
         throw new AXLAlreadyExistsException(RESOURCE, axlResource.MSG_AVL_WITH_OEM_VDR_ALREADY_EXISTS,
                              new Object[]{oemPart.getIdentity(), vendorPartMaster.getIdentity()});
      }
   }

   /**
    * Vetoes deletion of supplier part masters if they are referenced by any OEM
    * parts. Throws exception with list of OEM parts as part of the message.
    *
    * @param partMasterClass this is either ManufacturerPartMaster.class or VendorPartMaster.class
    * @param supplierPartMasters the supplier part masters being deleted
    * @throws WTException
    */
   private void validateBeforeDeleteSupplierPartMasters(Class partMasterClass, WTCollection supplierPartMasters) throws WTException {
      logger.trace("validateBeforeDeleteSupplierPartMasters: class=" + partMasterClass.getName() + " size=" + supplierPartMasters.size());
      // SELECT DISTINCT oem.ClassnameA2, oem.IdA2A2
      // FROM   AXLEntry axl, WTPart oem
      // WHERE  axl.IdA3A4 IN <mfr-part-master-ids>
      // AND    axl.IdA3C4 = oem.IdA2A2
      QuerySpec qs = new QuerySpec();

      int idxOem = qs.appendClassList(WTPart.class, false);
      int idxAxl = qs.appendClassList(AXLEntry.class, false);

      ClassAttribute oemClass = new ClassAttribute(WTPart.class, WTAttributeNameIfc.OID_CLASSNAME);
      ClassAttribute oemId    = new ClassAttribute(WTPart.class, WTAttributeNameIfc.ID_NAME);
      qs.appendSelect(oemClass, new int[] {idxOem}, false);
      qs.appendSelect(oemId,    new int[] {idxOem}, false);

      qs.appendWhere(getAXLSearchCondition(partMasterClass, supplierPartMasters), new int[] {idxAxl});
      qs.appendAnd();
      qs.appendWhere(new SearchCondition(AXLEntry.class,
                                         AXLEntry.OEM_PART_ID,
                                         WTPart.class,
                                         WTAttributeNameIfc.ID_NAME),
                     new int[] {idxAxl, idxOem});

      logger.debug("validateBeforeDeleteSupplierPartMasters: query = " + qs.toString());
      WTArrayList oemParts = new WTArrayList();
      oemParts = (WTArrayList) PersistenceHelper.manager.find(qs, oemParts);

      if (oemParts != null && oemParts.size() > 0) {
         // DISTINCT cannot be used in the query due to the access control
         // blob. Duplicates are filtered out via post processing.
         Set partIds = new HashSet(oemParts.size());
         Collection msgs = new ArrayList(oemParts.size());
         for (Iterator i = oemParts.persistableIterator(); i.hasNext();) {
            WTPart part = (WTPart) i.next();
            String partId = part.getDisplayIdentifier().toString();
            if (partIds.contains(partId)) {
               logger.trace("skipped " + partId + "[" + part.getDisplayIdentifier() + "]");
               continue;
            }
            msgs.add(part.getDisplayIdentifier());
            partIds.add(partId);
            logger.trace("added " + partId + "[" + part.getDisplayIdentifier() + "]");
         }
         String key = partMasterClass.isAssignableFrom(VendorPartMaster.class)
                    ? axlResource.MSG_CANNOT_DELETE_REFERENCED_VDR_PARTS
                    : axlResource.MSG_CANNOT_DELETE_REFERENCED_MFR_PARTS;
         throw new AXLException(RESOURCE, key, new Object[] {new LocalizableMessageCollection(msgs)});
      }
      logger.trace("validateBeforeDeleteSupplierPartMasters: validation success");
   }

   /**
    * Validates AML preference
    *  for now only checks if it is null
    * @param amlPreference
    * @throws WTException
    */
   private void validateAMLPreference(AXLPreference amlPreference) throws WTException {
      if (amlPreference == null) {
         logger.error("aml preference is null");
         throw new AXLException(RESOURCE, axlResource.MSG_AML_PREFERENCE_IS_NULL, null);
      }
   }

   /**
    * Validates AML preference
    *  for now only checks if it is null
    * @param avlPreference
    * @throws WTException
    */
   private void validateAVLPreference(AXLPreference avlPreference) throws WTException {
      if (avlPreference == null) {
         logger.error("avl preference is null");
         throw new AXLException(RESOURCE, axlResource.MSG_AVL_PREFERENCE_IS_NULL, null);
      }
   }

   /**
    * Validates AXLEntries
    *  for now only checks if it is null
    * @param entries
    * @throws WTException
    */
   private void validateAXLEntriesBeforeModifyOrStore(WTCollection entries) throws WTException {
      for (Iterator i = entries.persistableIterator(); i.hasNext();) {
         AXLEntry entry = (AXLEntry) i.next();
         ObjectReference mfrRef = entry.getManufacturerPartReference();
         ObjectReference vdrRef = entry.getVendorPartReference();
         if (mfrRef == null && vdrRef == null) {
            throw new AXLException(RESOURCE, axlResource.MSG_CANNOT_CREATE_AXL_BOTH_ARE_NULL, null);
         }

         if (mfrRef != null && mfrRef.hasPersistence() && entry.getAmlPreference() == null) {
            throw new AXLException(RESOURCE, axlResource.MSG_AML_PREFERENCE_IS_NULL, null);
         }

         if (vdrRef != null && vdrRef.hasPersistence() && entry.getAvlPreference() == null) {
            throw new AXLException(RESOURCE, axlResource.MSG_AVL_PREFERENCE_IS_NULL, null);
         }
      }
   }

   /**
    * Validates an AXLEntry
    * @param entry
    * @throws wt.util.WTException
    */
   private void validateAXLEntry(AXLEntry entry) throws WTException {
      if (entry == null) {
         throw new AXLException(RESOURCE, axlResource.MSG_AXL_IS_NULL, null);
      }

      ObjectReference ref = entry.getManufacturerPartReference();
      if (ref != null && ref.hasPersistence() && entry.getAmlPreference() == null) {
         throw new AXLException(RESOURCE, axlResource.MSG_AML_HAS_NO_AML_PREFERENCE, null);
      }

      ref = entry.getVendorPartReference();
      if (ref != null && ref.hasPersistence() && entry.getAvlPreference() == null) {
         throw new AXLException(RESOURCE, axlResource.MSG_AVL_HAS_NO_AVL_PREFERENCE, null);
      }
   }

   /**
    * Validates manufacturer part
    *  for now only checks if it is null
    * @param context
    * @throws WTException
    */
   private void validateContext(AXLContext context) throws WTException {
      if (context == null) {
         logger.error("Context is null");
         throw new AXLException(RESOURCE, axlResource.MSG_CONTEXT_IS_NULL, null);
      }
   }

   /**
    * Validates manufacturer part
    *  for now only checks if it is null
    * @param manufacturerPart
    * @throws WTException
    */
   private void validateManufacturerPart(ManufacturerPart manufacturerPart) throws WTException {
      if (manufacturerPart == null) {
         logger.error("Manufacturer part is null");
         throw new AXLException(RESOURCE, axlResource.MSG_MFR_PART_IS_NULL, null);
      }
   }

   /**
    * Validates manufacturer part
    *  for now only checks if it is null
    * @param manufacturerPart
    * @throws WTException
    */
   private void validateManufacturerPartMaster(ManufacturerPartMaster manufacturerPartMaster) throws WTException {
      if (manufacturerPartMaster == null) {
         logger.error("Manufacturer part master is null");
         throw new AXLException(RESOURCE, axlResource.MSG_MFR_PART_IS_NULL, null);
      }
   }

   /**
    * Validates manufacturer part master and vendor part master
    * to check if they both are null
    * @param manufacturerPartMaster
    * @param vendorPartMaster
    * @throws WTException
    */
   private void validateManufacturerPartAndVendorPart(ManufacturerPartMaster manufacturerPartMaster, VendorPartMaster vendorPartMaster) throws WTException {
      if (manufacturerPartMaster == null && vendorPartMaster == null) {
         logger.debug("Both manufacturer part and vendor part are null");
         throw new AXLException(RESOURCE, axlResource.MSG_BOTH_MFR_PART_AND_VENDOR_PART_ARE_NULL, null);
      }
   }

   /**
    * Validates OEM part to ensure:
    * A. it is not null
    * B. the principal has proper permission to perform the operation.
    * Here are the access control rules, these rules are evaluated
    * in the order shown:
    *   - access OK if the part is checked out by the current principal
    *   - no access if the part is checked out by a different principal
    *   - access OK if the current principal is a Supplier Administrator
    *   - access OK if the current principal has MODIFY permission on the part
    *   - no access
    *
    * However, the above rules do not apply to IXB and bulk update.
    * @param oemPart
    * @param operation
    * @throws WTException
    */
   public void validateOemPart(WTPart oemPart, String operation) throws WTException {
      logger.trace("StandardAXLService:validateOemPart:start: oemPart=" + oemPart + " opearation=" + operation);
      if (oemPart == null) {
         logger.error("oem part is null");
         throw new AXLException(RESOURCE, axlResource.MSG_OEM_PART_IS_NULL, null);
      }

      if (operation == null) {
         return;
      }

      // bypasses access control for IXB and bulk update
      if (MethodContext.getContext().containsKey(SuMaIxbHndHelper.SUMA_IXB_CONTEXT_KEY) ||
          MethodContext.getContext().containsKey(AXLHelper.BULK_UPDATE_CONTEXT_KEY)) {
         return;
      }

      validateOperationType(operation);

      WTPrincipal principal = SessionHelper.manager.getPrincipal();
      if (principal == null) {
         throw new AXLException(RESOURCE, axlResource.MSG_PRINCIPAL_IS_NULL, null);
      }

      if (WorkInProgressHelper.isCheckedOut(oemPart)) {
         if (WorkInProgressHelper.isCheckedOut(oemPart, principal)) {
            logger.debug(principal.getDisplayIdentity() + " is authorized to make AML/AVL changes to OEM part " + oemPart + " [part checked out]");
            return;
         }
         logger.debug(principal.getDisplayIdentity() + " is not authorized to make AML/AVL changes to OEM part " + oemPart + " [part checked out]");
         throw new AXLException(RESOURCE, axlResource.MSG_OPERATION_NOT_AUTHORIZED_CHECKEDOUT_BY_OTHER, new Object[] {
            principal.getDisplayIdentity(), oemPart.getDisplayIdentity()});
      }

      final boolean enforce = SessionServerHelper.manager.setAccessEnforced(false);
      try {
         WTContainerRef org_container_ref = WTContainerHelper.service.getOrgContainerRef(oemPart);
         if (SupplierHelper.service.isAdministrator(principal, org_container_ref)) {
            logger.debug(principal.getDisplayIdentity() + " is authorized to make AML/AVL changes to OEM part " + oemPart + " [Supplier Administrator]");
            return;
         }
      }
      finally {
         SessionServerHelper.manager.setAccessEnforced(enforce);
      }
       boolean isProductionManager = KBTeamUtils.isUserInRole(principal, (ContainerTeamManaged) oemPart
               .getContainer(), KBConstants.PRODUCTION_MANAGER_ROLE);
       logger.debug("isProductionManager: " + isProductionManager);
      if ((!SumaConfigHelper.isIterateOnAddRemoveAXL() || !SumaConfigHelper.isIterateOnModifyPreference()) && (AccessControlHelper.manager.hasAccess(oemPart, AccessPermission.MODIFY) || isProductionManager)) {
         logger.debug(principal.getDisplayIdentity() + " is authorized to make AML/AVL changes to OEM part " + oemPart + " [has MODIFY permission]");
         return;
      }

      throw new AXLException(RESOURCE, axlResource.MSG_OPERATION_NOT_AUTHORIZED, new Object[] {principal.getDisplayIdentity(), oemPart.getIdentity()});
   }

   /**
    * Validates operation type - should be listed in AXLServiceEvent
    * @param operation
    * @throws WTException
    */
   private void validateOperationType(String operation) throws WTException {
      if (!operation.equals(AXLServiceEvent.ADD_AML)    &&
          !operation.equals(AXLServiceEvent.ADD_AVL)    &&
          !operation.equals(AXLServiceEvent.REMOVE_AML) &&
          !operation.equals(AXLServiceEvent.REMOVE_AVL) &&
          !operation.equals(AXLServiceEvent.MODIFY_AML) &&
          !operation.equals(AXLServiceEvent.MODIFY_AVL)) {
         logger.error("Invalid operation type");
         throw new AXLException(RESOURCE, axlResource.MSG_INVALID_OPERATION_TYPE, new Object[] {operation});
      }
   }

   /**
    * Validates vendor part
    * for now only checks if it is null
    * @param vendorPart
    * @throws WTException
    */
   private void validateVendorPart(VendorPart vendorPart) throws WTException {
      if (vendorPart == null) {
         logger.error("Vendor part is null");
         throw new AXLException(RESOURCE, axlResource.MSG_VDR_PART_IS_NULL, null);
      }
   }

   /**
    * Validates vendor part master
    * for now only checks if it is null
    * @param vendorPart
    * @throws WTException
    */
   private void validateVendorPartMaster(VendorPartMaster vendorPartMaster) throws WTException {
      if (vendorPartMaster == null) {
         logger.error("Vendor part master is null");
         throw new AXLException(RESOURCE, axlResource.MSG_VDR_PART_IS_NULL, null);
      }
   }

   /**
    *
    * @param links
    * @param event_key
    * @throws wt.util.WTException
    */
   private void dispatchOEMPreferenceEvent(WTCollection links, String event_key) throws WTException {
      WTValuedMap parts_to_contexts = new WTValuedHashMap(WTKeyedHashMap.getInitialCapacity(links.size()));
      WTKeyedMap parts_to_preferences = new WTKeyedHashMap(WTKeyedHashMap.getInitialCapacity(links.size()));
      for (Iterator i = links.persistableIterator(); i.hasNext();) {
         OEMPartAXLContextLink next = (OEMPartAXLContextLink)i.next();
         WTReference part_ref = next.getRoleAObjectRef();
         WTReference context_ref = next.getRoleBObjectRef();
         AXLPreference pref = null;
         try{
             pref = next.getOemPreference();
         }catch(WTException sourcingStatusNoMoreExp){
             // Skip WTException in the case sourcing status preference value changed in rbinfo file after
             // some entries created with previous value. As This will allow to update the link to valid preference. 
             if (logger.isDebugEnabled())
             logger.debug(sourcingStatusNoMoreExp.getLocalizedMessage());
         }
         parts_to_contexts.put(part_ref, context_ref);
         parts_to_preferences.put(part_ref, pref);
      }
      parts_to_contexts = CollectionsHelper.unmodifiableWTValuedMap(parts_to_contexts);
      parts_to_preferences = CollectionsHelper.unmodifiableWTKeyedMap(parts_to_preferences);
      OEMPreferenceEvent event = new OEMPreferenceEvent(event_key, parts_to_contexts, parts_to_preferences);
      logger.debug("Dispatching preference event: " + event);
      SumaServerHelper.service.dispatchVetoableMultiObjectEvent(event, event.getEventKey());
   }

   /**
    *
    * @param link
    * @param event_key
    * @throws wt.util.WTException
    */
   private void dispatchOEMPreferenceEvent(OEMPartAXLContextLink link, String event_key) throws WTException {
      WTReference part_ref = link.getRoleAObjectRef();
      WTReference context_ref = link.getRoleBObjectRef();
      AXLPreference pref = link.getOemPreference();
      WTValuedMap parts_to_contexts = new WTValuedHashMap(1);
      WTKeyedMap parts_to_preferences = new WTKeyedHashMap(1);
      parts_to_contexts.put(part_ref, context_ref);
      parts_to_preferences.put(part_ref, pref);
      parts_to_contexts = CollectionsHelper.unmodifiableWTValuedMap(parts_to_contexts);
      parts_to_preferences = CollectionsHelper.unmodifiableWTKeyedMap(parts_to_preferences);
      OEMPreferenceEvent event = new OEMPreferenceEvent(event_key, parts_to_contexts, parts_to_preferences);
      logger.debug("Dispatching preference event: " + event);
      SumaServerHelper.service.dispatchVetoableMultiObjectEvent(event, event.getEventKey());
   }

   /**
    *
    * @param contexts
    * @throws wt.util.WTException
    */
   private void processPreStoreForAXLContext(WTCollection contexts) throws WTException {
      for (Iterator i = contexts.persistableIterator(); i.hasNext();) {
         AXLContext next = (AXLContext)i.next();
         WTContainer container = WTContainerHelper.getContainerRef(next).getReferencedContainerReadOnly();
         AdminDomainRef domain_ref = DomainAdministeredHelper.getAdminDomainRef(next);
         if (domain_ref == null || domain_ref.equals(container.getDefaultDomainReference())) {
            DomainAdministeredHelper.setAdminDomain(next, container.getSystemDomainReference());
         }
      }
   }

   /**
    * Analyzes the POST_CHECKIN event data and sends object notification accordingly
    * This method has to be public because it needs to be invoked from queue services.
    * It simply calls its private counterpart in ObjectNotificationHelper.
    *
    * @param postCheckinMap the POST_CHECKIN data
    * @throws wt.util.WTException
    */
   public static void analyzeAndNotify(WTValuedMap postCheckinMap) throws WTException {
      ObjectNotificationHelper.analyzeAndNotify(postCheckinMap);
   }

   /** ---------------------------------------------------------------------------------------------
    * A container class for a context, an OEM part, and a manufacturer part master.
    * This is mainly used to allow these objects to be added to a collection.
    * ----------------------------------------------------------------------------------------------
    */
   private static class ContextOemPartMfrPartMasterTrio {
      /**
       * context id
       */
      protected long ctxId;
      /**
       * oem part id
       */
      protected long oemId;
      /**
       * manufacturer part master id
       */
      protected long mfrId;

      /**
       * Factory method to create a trio with a context, an oem part, and a manufacturer part master.
       * @param oemId an OEM part id
       * @param mfrId a manufacturer part id
       * @param ctxId an AXLContext id
       * @throws WTException
       * @return  a constructed trio object
       */
      public static ContextOemPartMfrPartMasterTrio newContextOemPartMfrPartMasterTrio(long ctxId, long oemId, long mfrId) throws WTException {
         ContextOemPartMfrPartMasterTrio trio = new ContextOemPartMfrPartMasterTrio();
         trio.initialize(ctxId, oemId, mfrId);
         return trio;
      }

      /**
       * Factory method that takes an AXLEntry
       * @param entry an AXLEntry
       * @throws WTException
       * @return  a constructed trio
       */
      public static ContextOemPartMfrPartMasterTrio newContextOemPartMfrPartMasterTrio(AXLEntry entry) throws WTException {
         if (entry == null) {
            return null;
         }

         AXLContext ctx = entry.getContext();
         WTPart oem = entry.getOemPart();
         ManufacturerPartMaster mfr = entry.getManufacturerPart();
         return newContextOemPartMfrPartMasterTrio(
            ctx.getPersistInfo().getObjectIdentifier().getId(),
            oem.getPersistInfo().getObjectIdentifier().getId(),
            mfr == null ? 0L : mfr.getPersistInfo().getObjectIdentifier().getId());
      }

      /**
       * Returns a string representation of the instance
       * @return  a string representation of the instance
       */
      @Override
    public String toString() {
         return new StringBuffer().append(ctxId).append(":").append(oemId).append(":").append(oemId).toString();
      }

      /**
       * Overriden equals() method
       * @param o an objecd that the instance of the class compares to
       * @return  a boolean indicating whether the two objects are equal
       */
      @Override
    public boolean equals(Object o) {
         if (this == o) {
            return true;
         }

         if (o == null) {
            return false;
         }

         return (((ContextOemPartMfrPartMasterTrio) o).ctxId == ctxId)
            &&  (((ContextOemPartMfrPartMasterTrio) o).oemId == oemId)
            &&  (((ContextOemPartMfrPartMasterTrio) o).mfrId == mfrId);
      }

      /**
       * Overriden hashcode method
       * @return  the hashcode of the instance
       */
      @Override
    public int hashCode() {
         int hash = 17;
         hash = 37 * hash + (int) (ctxId ^ (ctxId >>> 32));
         hash = 37 * hash + (int) (oemId ^ (oemId >>> 32));
         hash = 37 * hash + (int) (mfrId ^ (mfrId >>> 32));
         return hash;
      }

      /**
       * Initializes the class with a context id, OEM part id, and manufacturer part id
       * @param ctxId an AXLContext id
       * @param oemId an OEM part id
       * @param mfrId a manufacturer part id
       * @throws WTException
       */
      private void initialize(long ctxId, long oemId, long mfrId) throws WTException {
         if (ctxId == 0L) {
               throw new AXLException(RESOURCE, axlResource.MSG_CONTEXT_IS_NULL, null);
         }
         if (oemId == 0L) {
               throw new AXLException(RESOURCE, axlResource.MSG_OEM_PART_IS_NULL, null);
         }
         this.ctxId = ctxId;
         this.oemId = oemId;
         this.mfrId = mfrId;
      }

      /**
       * A private constructor
       */
      private ContextOemPartMfrPartMasterTrio() {}
   } // end of class ContextOemPartMfrPartMasterTrio

   /** ---------------------------------------------------------------------------------------------
    * Helper class for AXLServiceEvent object notification
    * ----------------------------------------------------------------------------------------------
    */
   private static final class ObjectNotificationHelper {
      /** Same string as wt.notify.StandardNotificationManager.NOTIFICATION_QUEUE_NAME */
      private static final String NOTIFICATION_QUEUE_NAME = "NotificationQueue";
      private static ProcessingQueue notificationQueue;

      /**
       * Starts object notification processing for the post checkin data
       * @param postCheckinMap contains previous iteration to latest iteration map
       *        for AML/AVL related OEM parts (WTPart)
       * @throws wt.util.WTException
       */
      private static void doObjectNotification(WTValuedMap postCheckinMap) throws WTException {
         logger.debug("ObjectNotificationHelper.doObjectNotification()");
         if (postCheckinMap == null || postCheckinMap.isEmpty()) {
            return;
         }

         checkNotificationQueue();

         try {
            postCheckinMap.setDeflatedOnSerialization(true);
         }
         catch (WTPropertyVetoException e) {
            throw new AXLException(e);
         }

         Class[] argTypes = new Class[] { WTValuedMap.class };
         Object[] args = new Object[] { postCheckinMap };
         if (WT_NOTIFY_USE_QUEUE) {
            WTPrincipal administrator = SessionHelper.manager.getAdministrator();
            if (administrator == null) {
               throw new NotificationException(null, "wt.notify.notifyResource", notifyResource.MISSING_ADMINISTRATOR, null);
            }
            WTPrincipal previous = SessionContext.setEffectivePrincipal (administrator);
            try {
               notificationQueue.addEntry(administrator, "analyzeAndNotify", CLASSNAME, argTypes, args);
            }
            finally {
               SessionContext.setEffectivePrincipal (previous);
            }
         }
         else {
            analyzeAndNotify(postCheckinMap);
         }
      }

      /**
       * Ensures notification queue exists
       * @throws wt.util.WTException
       */
      private static void checkNotificationQueue() throws WTException {
         if (notificationQueue == null) {
             boolean origPolicy = SessionServerHelper.manager.setAccessEnforced(false);
             try{
                 notificationQueue = QueueHelper.manager.getQueue (NOTIFICATION_QUEUE_NAME);
             }finally{
                 SessionServerHelper.manager.setAccessEnforced(origPolicy);
             }
             if (notificationQueue == null) {
               // TODO: is this a valid case? should we create the queue if it is not yet available?
               throw new AXLException(RESOURCE, axlResource.MSG_NOTIFICATION_QUEUE_NOT_FOUND, null);
            }
         }
      }

      /**
       * Analyzes the post checkin data to find out necessary information for
       * AXLServiceEvent releated object notification.
       * The HashMap eventTypeToOemPartsMap is updated to reflect the analysis
       * result, where the keys are AXLServiceEvent event types (as String) and
       * values are their corresponding OEM parts collections (in WTSet).
       * @param postCheckinMap a previous iteration to latest iteration map obtained
       *        from POST_CHECKIN event, this only contains those WTParts that
       *        have to do with AML/AVL
       * @throws wt.util.WTException
       */
      public static void analyzeAndNotify(WTValuedMap postCheckinMap) throws WTException {
         HashMap eventTypeToOemPartsMap = new HashMap(AXLServiceEvent.AXL_SERVICE_EVENT_KEY_SET.length);
         for (int i = 0; i < AXLServiceEvent.AXL_SERVICE_EVENT_KEY_SET.length; i++) {
            eventTypeToOemPartsMap.put(AXLServiceEvent.AXL_SERVICE_EVENT_KEY_SET[i], new WTHashSet());
         }

         // for each pair of previous/latest iteration
         for (Iterator i = postCheckinMap.wtKeySet().persistableIterator(); i.hasNext();) {
            WTPart oldPart = (WTPart) i.next();
            WTPart newPart = (WTPart) postCheckinMap.getPersistable(oldPart);

            // filters out parts without suma specific event subscriptions
            WTStringSet eventSet = newPart.getEventSet();
            if (!ObjectNotificationHelper.hasAXLServiceEvent(eventSet)) {
               continue;
            }

            // compares AML/AVL information between previous and latest iteration
            // - gets all entries for old and new part
            // key -> AXLContext, value -> WTSet of AXLEntry
            HashMap oldCtxEntryMap = getContextToEntriesMap(oldPart);
            HashMap newCtxEntryMap = getContextToEntriesMap(newPart);

            // - gets union of contexts
            WTHashSet allContexts = new WTHashSet();
            allContexts.addAll(oldCtxEntryMap.keySet());
            allContexts.addAll(newCtxEntryMap.keySet());

            // - compares entries for each context and updates existing event set map
            for (Iterator ic = allContexts.persistableIterator(); ic.hasNext();) {
               AXLContext context = (AXLContext) ic.next();
               ObjectIdentifier ctxID = context.getPersistInfo().getObjectIdentifier();
               WTSet oldEntries = (WTSet) oldCtxEntryMap.get(ctxID);
               WTSet newEntries = (WTSet) newCtxEntryMap.get(ctxID);
               ObjectNotificationHelper.compare(newPart, oldEntries, newEntries, eventTypeToOemPartsMap);
            }

            // Step 4. sends out notification
            for (int j = 0; j < AXLServiceEvent.AXL_SERVICE_EVENT_KEY_SET.length; j++) {
               String eventKey = AXLServiceEvent.AXL_SERVICE_EVENT_KEY_SET[j];
               WTSet targets = (WTSet) eventTypeToOemPartsMap.get(eventKey);
               if (!targets.isEmpty()) {
                  WTList targetsList = new WTArrayList();
                  targetsList.addAll(targets);
                  NotificationServerHelper.manager.queueObjectNotification(targetsList, eventKey);
               }
            }
         }
      }

      /**
       * HashMap contains event key to oem parts mapping
       * @param oemPart the OEM part for which AXL related changes are being compared
       *                this is the newly checked in copy (latest iteration)
       * @param oldAxls set of AXL entries with the previous iteration
       * @param newAxls set of AXL entries with the latest iteration
       * @param eventToPartsMap event type to OEM parts (as a WTSet) map
       * @throws wt.util.WTException
       */
      private static void compare(WTPart oemPart, WTSet oldAxls, WTSet newAxls, HashMap eventToPartsMap) throws WTException {
         if (oldAxls == null && newAxls == null) {
            return;
         }

         // keys are supplier part masters, values are corresponding axl preferences
         WTKeyedMap oldMfrParts = new WTKeyedHashMap();
         WTKeyedMap oldVdrParts = new WTKeyedHashMap();
         WTKeyedMap newMfrParts = new WTKeyedHashMap();
         WTKeyedMap newVdrParts = new WTKeyedHashMap();

         updateSupplierPartMaps(oldAxls, oldMfrParts, oldVdrParts);
         updateSupplierPartMaps(newAxls, newMfrParts, newVdrParts);

         // all manufacturer part masters
         WTSet allMfrParts = new WTHashSet();
         allMfrParts.addAll(oldMfrParts.wtKeySet());
         allMfrParts.addAll(newMfrParts.wtKeySet());

         for (Iterator i = allMfrParts.queryKeyIterator(); i.hasNext();) {
            QueryKey key = (QueryKey) i.next();
            boolean hasOld = oldMfrParts.containsKey(key);
            boolean hasNew = newMfrParts.containsKey(key);
            if (hasOld && hasNew) {
               AXLPreference oldPref = (AXLPreference) oldMfrParts.get(key);
               AXLPreference newPref = (AXLPreference) newMfrParts.get(key);
               if ((oldPref == null && newPref != null) ||(oldPref != null && !oldPref.equals(newPref))) {
                  ((WTSet) eventToPartsMap.get(AXLServiceEvent.MODIFY_AML_EVENT_KEY)).add(oemPart);
               }
            }
            if (hasOld && !hasNew) {
               ((WTSet) eventToPartsMap.get(AXLServiceEvent.REMOVE_AML_EVENT_KEY)).add(oemPart);
            }
            else if (!hasOld && hasNew) {
               ((WTSet) eventToPartsMap.get(AXLServiceEvent.ADD_AML_EVENT_KEY)).add(oemPart);
            }
         }

         // all vendor part masters
         WTSet allVdrParts = new WTHashSet();
         allVdrParts.addAll(oldVdrParts.wtKeySet());
         allVdrParts.addAll(newVdrParts.wtKeySet());

         for (Iterator i = allVdrParts.queryKeyIterator(); i.hasNext();) {
            QueryKey key = (QueryKey) i.next();
            boolean hasOld = oldVdrParts.containsKey(key);
            boolean hasNew = newVdrParts.containsKey(key);
            if (hasOld && hasNew) {
               AXLPreference oldPref = (AXLPreference) oldVdrParts.get(key);
               AXLPreference newPref = (AXLPreference) newVdrParts.get(key);
               if ((oldPref == null && newPref != null) || (oldPref != null && !oldPref.equals(newPref))) {
                  ((WTSet) eventToPartsMap.get(AXLServiceEvent.MODIFY_AVL_EVENT_KEY)).add(oemPart);
               }
            }
            if (hasOld && !hasNew) {
               ((WTSet) eventToPartsMap.get(AXLServiceEvent.REMOVE_AVL_EVENT_KEY)).add(oemPart);
            }
            else if (!hasOld && hasNew) {
               ((WTSet) eventToPartsMap.get(AXLServiceEvent.ADD_AVL_EVENT_KEY)).add(oemPart);
            }
         }
      }

      /**
       * Queries AXLEntry table for a given OEM part, returns a HashMap where the
       * keys are AXLContexts and values are the corresponding AXLEntries.
       * @param oemPart an OEM part
       * @throws wt.util.WTException
       * @return AXLContext to AXL entries (as a WTSet) map
       */
      private static HashMap getContextToEntriesMap(WTPart oemPart) throws WTException {
         HashMap result = new HashMap();

         if (oemPart == null) {
            return result;
         }

         // SELECT ClassnameKeyD4, idA3D4, ClassnameA2A2, idA2A2
         // FROM   AXLEntry
         // WHERE  idA3C4 = <oem-part-id>;

         try {
            QuerySpec qs = new QuerySpec();
            int idx = qs.addClassList(AXLEntry.class, false);

            qs.appendSelectAttribute(AXLEntry.CONTEXT_CLASSNAME,       idx, false);
            qs.appendSelectAttribute(AXLEntry.CONTEXT_ID,              idx, false);
            qs.appendSelectAttribute(WTAttributeNameIfc.OID_CLASSNAME, idx, false);
            qs.appendSelectAttribute(WTAttributeNameIfc.ID_NAME,       idx, false);

            qs.appendWhere(getAXLSearchCondition(WTPart.class, oemPart), new int[] {idx});
            //qs.appendOrderBy(new OrderBy(new ClassAttribute(AXLEntry.class, AXLEntry.CONTEXT_ID), true), new int[] {idx});

            logger.debug("qs=" + qs);
            QueryResult qr = PersistenceHelper.manager.find(qs);
            while (qr.hasMoreElements()) {
               Object[] o = (Object[]) qr.nextElement();
               if (o.length != 4) {
                  throw new AXLException(RESOURCE, axlResource.MSG_UNEXPECTED_QUERY_RESULT, null);
               }
               ObjectIdentifier ctxID = ObjectIdentifier.newObjectIdentifier(Class.forName((String) o[0]),
                                                                             ((Number) o[1]).longValue());
               ObjectIdentifier axlID = ObjectIdentifier.newObjectIdentifier(Class.forName((String) o[2]),
                                                                             ((Number) o[3]).longValue());
               if (result.containsKey(ctxID)) {
                  WTSet axls = (WTSet) result.get(ctxID);
                  axls.add(axlID);
               }
               else {
                  WTSet axls = new WTHashSet();
                  axls.add(axlID);
                  result.put(ctxID, axls);
               }
            }

            return result;
         }
         catch (ClassNotFoundException e) {
            throw new AXLException(e);
         }
      }

      /**
       * Queries the database and finds from the given OEM parts collection the OEM parts that
       * do not have any associated AXL
       * @param oemParts a collection of OEM parts
       * @throws wt.util.WTException
       * @return set of OEM parts that do not have any associated AXL entries
       */
      private static WTSet getOemPartsWithoutAxl(WTCollection oemParts) throws WTException {
         // finds parts that are not associated with any AXL
         // SELECT ClassnameA2, iDA2A2
         // FROM   WTPart
         // WHERE  iDA2A2 IN <oem-part-ids>
         //  AND   iDA2A2 NOT IN
         //     (SELECT DISTINCT iDA3C4
         //      FROM   AXLEntry
         //      WHERE  iDA3C4 IN <oem-part-ids>);
         WTHashSet result = new WTHashSet();
         try {
            QuerySpec qsAxl = new QuerySpec();
            qsAxl.setDistinct(true);
            int idxAxl = qsAxl.appendClassList(AXLEntry.class, false);
            qsAxl.appendSelectAttribute(AXLEntry.OEM_PART_ID, idxAxl, false);
            qsAxl.appendWhere(getAXLSearchCondition(WTPart.class, oemParts), new int[] {idxAxl});

            QuerySpec qsOem = new QuerySpec();
            qsOem.setAdvancedQueryEnabled(true);
            int idxOem = qsOem.appendClassList(WTPart.class, false);
            ClassAttribute oemClass = new ClassAttribute(WTPart.class, WTAttributeNameIfc.OID_CLASSNAME);
            ClassAttribute oemId    = new ClassAttribute(WTPart.class, WTAttributeNameIfc.ID_NAME);
            qsOem.appendSelect(oemClass, new int[] {idxOem}, false);
            qsOem.appendSelect(oemId,    new int[] {idxOem}, false);
            qsOem.appendWhere(new SearchCondition(
               WTPart.class, WTAttributeNameIfc.ID_NAME, oemParts.toIdArray()), new int[] {idxOem});
            qsOem.appendAnd();
            qsOem.appendWhere(new SearchCondition(oemId, SearchCondition.NOT_IN,
               new SubSelectExpression(qsAxl)), new int[] {idxOem, idxAxl});
            logger.debug("qs = " + qsOem);
            result = (WTHashSet) PersistenceHelper.manager.find(qsOem, result);
            return result;
         }
         catch (WTPropertyVetoException e) {
            throw new AXLException(e);
         }
      }

      /**
       * Determines if the event set contains any AXLServiceEvents
       * These events are notifiable through object subscription
       * @param eventSet
       * @return boolean indicating whether the event set contains any AXL service related events
       */
      private static boolean hasAXLServiceEvent(WTStringSet eventSet) {
         for (int i = 0; eventSet != null && i < AXLServiceEvent.AXL_SERVICE_EVENT_KEY_SET.length; i++) {
            if (eventSet.contains(AXLServiceEvent.AXL_SERVICE_EVENT_KEY_SET[i])) {
               return true;
            }
         }
         return false;
      }

      /**
       * Walks through the set of AXLs and adds if necessary to manufacturer part map and vendor part map.
       * The maps contains the manufacturer/vendor part masters and their corresponding preferences
       * @param axls a set of AXL entries
       * @param mfrParts manufacturer part master to aml preference map
       * @param vdrParts vendor part master to avl preference map
       * @throws wt.util.WTException
       */
      private static void updateSupplierPartMaps(WTSet axls, WTKeyedMap mfrParts, WTKeyedMap vdrParts) throws WTException {
         if (axls == null) {
            return;
         }

         for (Iterator i = axls.persistableIterator(); i.hasNext();) {
            AXLEntry axl = (AXLEntry) i.next();
            ManufacturerPartMaster mfrPart = axl.getManufacturerPart();
            VendorPartMaster vdrPart = axl.getVendorPart();
            if (mfrPart != null) {
               mfrParts.put(mfrPart, axl.getAmlPreference());
            }
            if (vdrPart != null) {
               vdrParts.put(vdrPart, axl.getAvlPreference());
            }
         }
      }
   }
   private static final String DOC_RESOURCE = "wt.doc.docResource";
   private static final String SUPPLIER_RESOURCE = "wt.doc.docResource";

   /**
    * Find a new default AXLPreference for the SupplierPart in the new AXLContext
    */
   private AXLPreference getAnotherContextPreference ( WTPart oemPart, SupplierPartMaster master, AXLContext context, AXLEntry entry )
      throws WTException {
      if ( logger.isDebugEnabled() ) logger.debug( "getAnotherContextPreference()" );
      // If there is now SupplierPartMaster - return default EnumerationType value
      AXLPreference newAXLPreference = null;
      if ( master == null ) {
        newAXLPreference = AXLPreference.getAXLPreferenceDefault();
        if ( logger.isDebugEnabled() ) logger.debug( "master == null, newAXLPreference = " + newAXLPreference.getDisplay() );
        if ( newAXLPreference == null ) {
          return AXLPreference.getAXLPreferenceSet()[ 0 ];
        }
        return newAXLPreference;
      }
      // Find the latest Version Iteration of the Supplier Part related to this Master Part
      SupplierPart latestVerIter = null;
      try
      {
        QueryResult result = VersionControlHelper.service.allVersionsOf( master );
        result = new OwnershipIndependentLatestConfigSpec().process( result );
        while (result.hasMoreElements()) {
          latestVerIter = (SupplierPart)result.nextElement();
          // Logging
          String latestVersion = VersionControlHelper.getVersionIdentifier( latestVerIter ).getValue();
          String latestIteration = VersionControlHelper.getIterationIdentifier( latestVerIter ).getValue();
          if ( logger.isDebugEnabled() ) logger.debug( "latest version = " + latestVersion + ", latest iteration = " + latestIteration);
        }
      }
      catch(WTException wte){
        throw new WTException( wte, DOC_RESOURCE, docResource.LATESTVER_ITER, null );
      }
      if ( latestVerIter == null ) {
        throw new WTException( DOC_RESOURCE, docResource.LATESTVER_ITER, null );
      }
      // Get Supplier for this Part
      SupplierIfc supplier = SupplierHelper.service.getSupplier( oemPart, latestVerIter );
      if ( logger.isDebugEnabled() ) logger.debug( "Supplier = " + supplier );
      if ( supplier == null ) {
       throw new WTException( SUPPLIER_RESOURCE, supplierResource.CANNOT_FIND_SUPPLIER, null );
      }
      // Get new default AXLPreference for the SupplierPart in the new AXLContext
      newAXLPreference = AXLRuleHelper.service.getDefaultPreference( supplier, context, latestVerIter, true );
      /**
       * If null is returned from <code>getDefaultPreference</code> API which means there are no existing
       * sourcing rules defined in <code>context</code> then we want to retain the sourcing status of
       * original entry which is being saved.
       */
      if(newAXLPreference == null){
          if(master instanceof ManufacturerPartMaster)
              newAXLPreference = entry.getAmlPreference();
          if( master instanceof VendorPartMaster)
              newAXLPreference = entry.getAvlPreference();
      }
      if ( logger.isDebugEnabled() ) logger.debug( "newAXLPreference = " + newAXLPreference.getDisplay() );
      return newAXLPreference;
   }


}
