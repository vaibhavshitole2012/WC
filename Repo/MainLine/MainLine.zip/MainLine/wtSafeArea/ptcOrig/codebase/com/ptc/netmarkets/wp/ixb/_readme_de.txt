﻿Diese ZIP-Datei enthält aus Windchill extrahierte Paketinformationen. Sie können den Inhalt dieses Pakets durchsuchen, indem Sie den web-basierten Offline-Viewer in dieser ZIP-Datei verwenden. Sie können auch direkt auf die Paketinhalts-Dateien zugreifen und sie in Ihr System importieren.

Der Prozess kann abhängig von der Konfiguration Ihres Systems variieren. Die folgenden grundlegenden Schritte helfen Ihnen bei der Navigation zu den Paketinformationen:

1. Verwenden Sie ein ZIP-Dienstprogramm, wie z.B. WinZip, um dieses Paket in einen neuen Ordner auf Ihrer Festplatte zu extrahieren.

2. Navigieren Sie zum ausgewählten Speicherort der ZIP-Paketdatei. Der Ordner enthält eine Liste mit Daten. Es gibt zwei Möglichkeiten, um den Inhalt der ZIP-Paketdatei anzuzeigen:
- Doppelklicken Sie auf die Datei index.html, um die Paketinformationen in Ihrem Webbrowser anzuzeigen. Abhängig von Ihrer Systemkonfiguration, wird das Paket in dem von Ihnen gewählten Webbrowser geöffnet.
- Öffnen Sie den Ordner Contents, wenn Sie die Paketinformationen nicht mithilfe des Offline-Viewers anzeigen möchten. Dieser Ordner enthält alle im Paket enthaltenen Darstellungen, Teiledateien und Anhänge. Sie können diesen Ordner verwenden, um Paketdateien direkt in Ihr System zu importieren.

3. Wenn Sie die Datei index.html öffnen, wird die Seite Package Details in Ihrem Browser geöffnet.

Klicken Sie auf die Hilfeschaltfläche oben auf der Seite, um weitere Informationen zu den in der Offline-Anzeige verfügbaren Paketinformationen zu erhalten.
