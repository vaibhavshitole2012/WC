// Write your custom js functions here
// Please specify your custom js functions in netmarket/javascript/util/validate.js

function geklaPickerCallback(objects, pickerID)
{ 
   var updateHiddenField = document.getElementById(pickerID);
   var parent = updateHiddenField.parentNode.parentNode.parentNode;
   var attrMap = parent.getElementsByTagName("button")[0].getAttribute("pickerjson");
   var attrArray = attrMap.split(",")
   var updateDisplayField;
   var compId;
   for (var i=0; i<attrArray.length; i++) {
		var index = attrArray[i].search("displayFieldId"); //alternate could be pickerId as well
		if (index>0 && index<=2) {
				updateDisplayField = attrArray[i].substring(attrArray[i].indexOf(":")+2, attrArray[i].length-1);
		}
		index = attrArray[i].search("openerCompContext");
		if (index>0 && index<=2) {
				compId = attrArray[i].substring(attrArray[i].indexOf(":")+2, attrArray[i].length-1);
		}
   }
   var x = compId.concat(updateDisplayField).replace(/"/g, "");
   var x2 = x.concat(pickerID);
   var field = document.getElementById(x2);//mandatory field is marked like this
   if (field == null)
		field = document.getElementById(x);//not mandatory field
   var myJSONObjects = objects.pickedObject;
   for(var i=0; i< myJSONObjects.length;i++) {
     var oid = myJSONObjects[i].oid;
     // Here �name� is the displayAttribute requested 
     var displayAttr = eval("myJSONObjects[i].number");
     updateHiddenField.value=displayAttr;
     field.value=displayAttr;
   }
}

function cataloguePickerCallback(objects, pickerID)
{ 
   var updateHiddenField = document.getElementById(pickerID);
   var parent = updateHiddenField.parentNode.parentNode.parentNode;
   var attrMap = parent.getElementsByTagName("button")[0].getAttribute("pickerjson");
   var attrArray = attrMap.split(",")
   var updateDisplayField;
   var compId;
   for (var i=0; i<attrArray.length; i++) {
		var index = attrArray[i].search("displayFieldId"); //alternate could be pickerId as well
		if (index>0 && index<=2) {
				updateDisplayField = attrArray[i].substring(attrArray[i].indexOf(":")+2, attrArray[i].length-1);
		}
		index = attrArray[i].search("openerCompContext");
		if (index>0 && index<=2) {
				compId = attrArray[i].substring(attrArray[i].indexOf(":")+2, attrArray[i].length-1);
		}
   }
   var x = compId.concat(updateDisplayField).replace(/"/g, "");
   var x2 = x.concat(pickerID);
   var field = document.getElementById(x2);//mandatory field is marked like this
   if (field == null)
		field = document.getElementById(x);//not mandatory field
   var myJSONObjects = objects.pickedObject;
   for(var i=0; i< myJSONObjects.length;i++) {
     var oid = myJSONObjects[i].oid;
     // Here �name� is the displayAttribute requested 
     var displayAttr = eval("myJSONObjects[i].sourceLanguage");
     field.value=displayAttr;
	 var oid = eval("myJSONObjects[i].oid");
	 var hiddenOid = oid.substring(oid.lastIndexOf(":")+1, oid.length);
     updateHiddenField.value=hiddenOid;
   }
}