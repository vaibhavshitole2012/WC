/* bcwti
 *
 * Copyright (c) 2010 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */
package com.ptc.windchill.enterprise.wvs.wvsQueueMonitor.forms;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

import org.apache.commons.lang3.StringEscapeUtils;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.DefaultObjectFormProcessor;
import com.ptc.core.components.forms.FormProcessingStatus;
import com.ptc.core.components.forms.FormResult;
import com.ptc.core.components.forms.FormResultAction;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.model.NmSimpleOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import com.ptc.windchill.enterprise.wvs.wvsQueueMonitor.queueMonitorResource;
import com.ptc.windchill.enterprise.wvs.wvsQueueMonitor.utils.QueueMonitorRow;
import com.ptc.wvs.common.util.WVSProperties;
import com.ptc.wvs.server.publish.ClashJob;
import com.ptc.wvs.server.publish.PublishJob;
import com.ptc.wvs.server.publish.PublishQueueHelper;
import com.ptc.wvs.server.publish.WVSProcessingJob;
import com.ptc.wvs.server.util.PublishUtils;

import wt.epm.EPMDocument;
import wt.org.WTPrincipal;
import wt.queue.StatusInfo;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.wvs.WVSLogger;

public class ResubmitJobsProcessor extends DefaultObjectFormProcessor {
    private static final WVSLogger logger = WVSLogger.getLogger(ResubmitJobsProcessor.class, WVSLogger.UI_PUBLISHMONITOR_GROUP);
    private static final String RESOURCE = "com.ptc.windchill.enterprise.wvs.wvsQueueMonitor.queueMonitorResource";

    /**
     * Returns a FormResult with alert message if there where any QueueMonitorRow(s) that the user was not able to resubmit.
     *
     * @param _cmdBean   A MnCommandBean with the selected rows.
     * @param _objBeanList   List of objects.
     *
     * @return   New FormResult with status and possible messages.
     */
    @Override
    public FormResult doOperation(NmCommandBean _cmdBean, List<ObjectBean> _objBeanList ) throws WTException {
        return null;
    }

    /* (non-Javadoc)
     * @see com.ptc.core.components.forms.DefaultObjectFormProcessor#postTransactionProcess(com.ptc.netmarkets.util.beans.NmCommandBean, java.util.List)
     */
    @Override
    public FormResult postTransactionProcess(NmCommandBean clientData, List<ObjectBean> objectBeans) throws WTException {
        // This is a workaround. DefaultFormProcessorController always starts a transaction.
        // But QueueService's resubmit API has to be called outside of a transaction.
        return doResubmit(clientData, objectBeans);
    }

    private FormResult doResubmit(NmCommandBean _cmdBean, List<ObjectBean> _objBeanList ) throws WTException {
        final boolean DEBUG = logger.isDebugEnabled();
        if (DEBUG) logger.debug("Entering the doResubmit(): ");

        List <QueueMonitorRow> selectedQMRs = new ArrayList<QueueMonitorRow>();


        ArrayList<NmOid> selectedItems = _cmdBean.getNmOidArrayList (_cmdBean.getSelected());
        //Checks to see if there was not any QueueMonitorRow SELECTED and if not look at the row the delete action fired from.
        if ( selectedItems == null || selectedItems.isEmpty() ){
            NmOid qmrOid = _cmdBean.getElementOid();
            if ((qmrOid != null) && (qmrOid instanceof NmSimpleOid)) {
                QueueMonitorRow qmr = QueueMonitorRow.newInstance((NmSimpleOid) qmrOid);
                if (qmr != null) {
                    selectedQMRs.add(qmr);
                }
                else {
                    if (DEBUG) logger.debug("Job " + qmrOid.toString() +
                            ") cannot be resubmitted because it does not exist anymore.");
                }
            }
        }
        else{
            //Moving the the list of selected items and removing the NmContext item to get the QueueMonitorRow out.
            for (NmOid qmrOid : selectedItems) {
                QueueMonitorRow qmr = QueueMonitorRow.newInstance((NmSimpleOid)qmrOid);
                if (qmr != null) {
                    selectedQMRs.add(qmr);
                }
                else {
                    if (DEBUG) logger.debug("Job " + qmrOid.toString() +
                            ") cannot be resubmitted because it does not exist anymore.");
                }
            }
        }

        if (DEBUG) logger.debug("The number of rows selected : " + selectedQMRs.size() );
        
        List <QueueMonitorRow> notDuplicatedQMRs = null;
        if(selectedQMRs.size() > 0)
            notDuplicatedQMRs = getNotDuplicatedJobInResubmittedJobs(selectedQMRs, DEBUG);
        
        List <QueueMonitorRow> notResubmittedQMRs = new ArrayList<QueueMonitorRow>();
        if(notDuplicatedQMRs != null){
            if(notDuplicatedQMRs.size() != selectedQMRs.size()){
                selectedQMRs.removeAll(notDuplicatedQMRs);
                notResubmittedQMRs=selectedQMRs;
                selectedQMRs = notDuplicatedQMRs;
            }
        }

        int numberOfJobsResubmitted = 0;
        WTPrincipal entryPrincipal = null;
        for (QueueMonitorRow qmr : selectedQMRs ){
            boolean isResubmittable = isJobResubmittable(qmr, DEBUG);
            if (isResubmittable) {
                WVSProcessingJob newJob = qmr.getJob().newInstance(false);
                entryPrincipal = qmr.getQueueEntry().getEntryOwner().getPrincipal();
                PublishQueueHelper.addPublishEntry(newJob, entryPrincipal);
                numberOfJobsResubmitted ++;
            }
            else {
                notResubmittedQMRs.add(qmr);
            }
        }

        StringBuilder feedbackMsg = new StringBuilder();
        Locale userLocale = _cmdBean.getLocale();
        String displayType = "SUCCESS";
        if (numberOfJobsResubmitted > 0) {
            Object[] jobCount = new Object[]{numberOfJobsResubmitted};
            String messageKey = queueMonitorResource.TWO_OR_MORE_JOBS_RESUBMITTED;
            if (numberOfJobsResubmitted == 1) {
                messageKey = queueMonitorResource.ONE_JOB_RESUBMITTED;
            }
            feedbackMsg.append(WTMessage.getLocalizedMessage(
                    RESOURCE, messageKey, jobCount, userLocale));
        }

        if ( !notResubmittedQMRs.isEmpty() ){
            //Message displayed if there are jobs select but can not be displayed
            //User that made the resubmit request
            displayType = "WARNING";
            feedbackMsg.append(WTMessage.getLocalizedMessage(RESOURCE,
                    queueMonitorResource.ONE_OR_MORE_JOBS_NOT_RESUBMITTED, null, userLocale));
            feedbackMsg.append("<br /> ");
            for (Iterator<QueueMonitorRow> i = notResubmittedQMRs.iterator(); i.hasNext();) {
                QueueMonitorRow currntRow = i.next();
                StringBuilder jobInfo = new StringBuilder();
                jobInfo.append(currntRow.getQueueEntry().getEntryNumber()).append(", ");
                jobInfo.append(currntRow.getTargetNumber()).append(", ");
                jobInfo.append(currntRow.getTargetName());
                feedbackMsg.append(StringEscapeUtils.escapeHtml3(jobInfo.toString()).replace("\'", "&apos")).append("<br /> ");
            }
            if (DEBUG) logger.debug(feedbackMsg.toString());
        }


        FormResult result = new FormResult();
        result.setStatus(FormProcessingStatus.NON_FATAL_ERROR);
        result.setNextAction(FormResultAction.JAVASCRIPT);
        //adding quotes for the javascript
        feedbackMsg.insert(0, "\"").append("\"");
        displayType = "\"" + displayType + "\"";
        result.setJavascript("PTC.wvs.QueueMonitorUtils.displayEncodedInlineMessage(" +
                feedbackMsg.toString() + "," + displayType + " );");
        return result;
    }
    
    private List<QueueMonitorRow> getNotDuplicatedJobInResubmittedJobs(List<QueueMonitorRow> selectedQMRs, boolean DEBUG) throws WTException {
        
        if (!WVSProperties.isDuplicateJobValidationEnabled())
            return selectedQMRs;
        
        Boolean exist =false;
        List <QueueMonitorRow> newList = new ArrayList<QueueMonitorRow>();
        newList.add(selectedQMRs.get(0));
        
        for(int i = 1;i<selectedQMRs.size();i++)
        {
            WVSProcessingJob selectedIterator = selectedQMRs.get(i).getJob().newInstance(false);
            for(int j=0; j<newList.size() ;j++){
                WVSProcessingJob newListIterator = newList.get(j).getJob().newInstance(false);
                if(selectedIterator.getTargetNumber() == newListIterator.getTargetNumber())
                    continue;
                
                if(!(selectedIterator instanceof PublishJob))
                    continue;
                WVSProcessingJob postJob = selectedIterator.getPostExecuteJob();
                if(postJob != null && (postJob instanceof ClashJob))
                    continue;

                if ((selectedIterator.getRequestSource() == WVSProcessingJob.JOB_SOURCE_MANUAL
                        || selectedIterator.getRequestSource() == WVSProcessingJob.JOB_SOURCE_MANUAL_POST)
                        && selectedIterator.getPersistableRef().equals(newListIterator.getPersistableRef())
                        && selectedIterator.getName().equals(newListIterator.getName())) {   
                    exist=true;
                }
            }
            
            if(!exist)
                newList.add(selectedQMRs.get(i));
        }

        
        return newList;
    }

    /**
     * Determines if a job can be resubmitted.
     *
     * @param qmr - the job.
     * @return <tt>true</tt> if the job can be resubmitted. Otherwise, <tt>false</tt>.
     * @throws WTException
     */
    private boolean isJobResubmittable(QueueMonitorRow qmr, boolean DEBUG) throws WTException
    {
        boolean isResubmittable = false;

        //Resubmitting is not allowed on jobs that are in the ready or executing state.
        String currentStatus  = qmr.getQueueEntry().getStatusInfo().getCode();
        if ( !currentStatus.equals(StatusInfo.READY) && !currentStatus.equals(StatusInfo.EXECUTING) ){
            WVSProcessingJob theJob = qmr.getJob();
            String persistableRef = theJob.getPersistableRef();
            if (persistableRef == null) { // account for Print jobs
                isResubmittable = true;
            }
            else if (theJob.getPersistable() != null) {
                if (PublishJob.class.isInstance(theJob)) {
                    // only allow resubmit if it is not a file sync job and
                    // it is not publishing with local data.
                    PublishJob publishJob = (PublishJob)theJob;
                    if (publishJob.getSyncInfoRef() == null && !publishJob.isPublishWithLocalData()) {
                        // Make sure publish is not prohibited
                        EPMDocument epmdoc = PublishUtils.findEPMDocument(theJob.getPersistable());
                        if (epmdoc != null && PublishUtils.isMarkedNotPublishable(epmdoc, true)) {
                            if (DEBUG) logger.debug("Job " + qmr.getQueueEntryNumberString() + " (" + qmr.getTargetName() +
                                    ") cannot be resubmitted because it was marked not publishable.");
                        }
                        else {
                            isResubmittable = true;
                        }
                    }
                    else {
                        if (DEBUG) logger.debug("Job " + qmr.getQueueEntryNumberString() + " (" + qmr.getTargetName() +
                                ") cannot be resubmitted because it was published from local data.");
                    }
                }
                else { // account for Clash jobs
                    isResubmittable = true;
                }
            }
            else {
                if (DEBUG) logger.debug("Job " + qmr.getQueueEntryNumberString() + " (" + qmr.getTargetName() +
                        ") cannot be resubmitted because the persistable the job originally executed on does not exist anymore.");
            }
            
            if(isResubmittable){
                isResubmittable = !PublishQueueHelper.isDuplicatedJob(theJob);
            }
        }
        else{
            if (DEBUG) logger.debug("Job " + qmr.getQueueEntryNumberString() + " (" + qmr.getTargetName() +
                    ") cannot be resubmitted because it was in a ready or executing state.");
        }

        return isResubmittable;
    }
}



