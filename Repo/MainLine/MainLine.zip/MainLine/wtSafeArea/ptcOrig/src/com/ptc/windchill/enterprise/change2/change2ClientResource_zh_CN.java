/* bcwti
 *
 * Copyright (c) 2010 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */
package com.ptc.windchill.enterprise.change2;

import wt.util.resource.*;

@RBUUID("com.ptc.windchill.enterprise.change2.change2ClientResource")
public final class change2ClientResource_zh_CN extends WTListResourceBundle {
   /**
    *
    * This file contains all the strings used by the DCA based Change Management clients
    *
    * ##############################################################################
    *
    * Object class names
    *
    * ##############################################################################
    **/
   @RBEntry("超差")
   @RBComment("see wt.change2.change2ModelRB:WTVariance key")
   public static final String PRIVATE_CONSTANT_0 = "VARIANCE";

   @RBEntry("问题报告")
   @RBComment("The name of the object \"Problem Report\".")
   public static final String PRIVATE_CONSTANT_1 = "PROBLEM_REPORT";

   @RBEntry("更改请求")
   @RBComment("The name of the object \"Change Request\".")
   public static final String PRIVATE_CONSTANT_2 = "CHANGE_REQUEST";

   @RBEntry("更改通告")
   @RBComment("The name of the object \"Change Notice\".")
   public static final String PRIVATE_CONSTANT_3 = "CHANGE_NOTICE";

   /**
    * ##############################################################################
    *
    * Legacy Strings used by the local search tooltips
    * @deprecated
    *
    * ##############################################################################
    **/
   @RBEntry("显示问题报告信�?�页�?�")
   @RBComment("Tooltip for the info page action.")
   public static final String PRIVATE_CONSTANT_4 = "CHANGE_ISSUE_INFO_PAGE_TT";

   @RBEntry("显示更改通告信�?�页�?�")
   @RBComment("Tooltip for the info page action.")
   public static final String PRIVATE_CONSTANT_5 = "CHANGE_ORDER_INFO_PAGE_TT";

   @RBEntry("显示更改请求信�?�页�?�")
   @RBComment("Tooltip for the info page action.")
   public static final String PRIVATE_CONSTANT_6 = "CHANGE_REQUEST_INFO_PAGE_TT";

   @RBEntry("显示问题报告信�?�页�?�")
   @RBComment("Tooltip for the info page action.")
   public static final String PRIVATE_CONSTANT_7 = "PR_DETAIL_TT";

   @RBEntry("显示更改请求信�?�页�?�")
   @RBComment("Tooltip for the info page action.")
   public static final String PRIVATE_CONSTANT_8 = "ECR_DETAIL_TT";

   @RBEntry("显示更改通告信�?�页�?�")
   @RBComment("Tooltip for the info page action.")
   public static final String PRIVATE_CONSTANT_9 = "ECN_DETAIL_TT";

   @RBEntry("显示更改�??议信�?�页�?�")
   @RBComment("Tooltip for the info page action.")
   public static final String PRIVATE_CONSTANT_10 = "CHANGE_PROPOSAL_INFO_TT";

   @RBEntry("显示任务信�?�页�?�")
   @RBComment("Tooltip for the info page action.")
   public static final String PRIVATE_CONSTANT_11 = "CHANGE_ACTIVITY_INFO_TT";

   @RBEntry("显示更改调查信�?�页�?�")
   @RBComment("Tooltip for the info page action.")
   public static final String PRIVATE_CONSTANT_12 = "CHANGE_INVESTIGATION_INFO_TT";

   @RBEntry("显示分�?活动信�?�页�?�")
   @RBComment("Tooltip for the info page action.")
   public static final String PRIVATE_CONSTANT_13 = "ANALYSIS_ACTIVITY_INFO_TT";

   @RBEntry("关�?�更改")
   @RBComment("The Associated Problem Reports step in the wizard.")
   public static final String PRIVATE_CONSTANT_14 = "RELATED_CHANGES";

   /**
    * ##############################################################################
    *
    * Picker titles
    *
    * ##############################################################################
    **/
   @RBEntry("查找关�?�的问题和超差")
   @RBComment("The title for the action \"Add Associated Changes\"")
   public static final String PRIVATE_CONSTANT_15 = "FIND_ASSOCIATED_CHANGEISSUES";

   @RBEntry("查找关�?�的更改请求")
   @RBComment("The title for the action \"Add Associated Changes\"")
   public static final String PRIVATE_CONSTANT_16 = "FIND_ASSOCIATED_CHANGEREQUESTS";

   @RBEntry("查找�?�影�?的�?�?")
   @RBComment("The title for the action \"Add Affected End Items\"")
   public static final String PRIVATE_CONSTANT_17 = "FIND_AFFECTED_END_ITEMS";

   @RBEntry("查找�?�影�?的对象")
   @RBComment("The title for the action \"Add Affected Objects\"")
   public static final String PRIVATE_CONSTANT_18 = "FIND_AFFECTED_DATA";

   @RBEntry("查找产生的对象")
   @RBComment("The title for the action \"Add Resulting Objects\"")
   public static final String PRIVATE_CONSTANT_19 = "FIND_RESULTING_DATA";

   @RBEntry("查找更改通告")
   @RBComment(" The title for the Change Notice Summary Report input page (from the Cognos reports page).")
   public static final String PRIVATE_CONSTANT_20 = "FIND_CHANGE_NOTICES";

   @RBEntry("查找更改请求")
   @RBComment(" The title for the Change Request Summary Report input page (from the Cognos reports page).")
   public static final String PRIVATE_CONSTANT_21 = "FIND_CHANGE_REQUESTS";

   @RBEntry("查找超差")
   @RBComment(" The title for the Variance Summary Report input page (from the Cognos reports page).")
   public static final String PRIVATE_CONSTANT_22 = "FIND_VARIANCES";

   @RBEntry("查找问题报告")
   @RBComment(" The title for the Problem Reports Summary Report input page (from the Cognos reports page).")
   public static final String PRIVATE_CONSTANT_23 = "FIND_PROBLEM_REPORTS";

   /**
    * ##############################################################################
    *
    * Table titles
    *
    * ##############################################################################
    **/
   @RBEntry("�?�影�?对象")
   @RBComment("The Affected Items table title.")
   public static final String PRIVATE_CONSTANT_24 = "AFFECTED_ITEMS_TABLE";

   @RBEntry("影�?更改指令")
   @RBComment("The Impacting Directive table title.")
   public static final String PRIVATE_CONSTANT_25 = "IMPACTING_ITEMS_TABLE";

   @RBEntry("更改�?作")
   @RBComment("The Change Actions table.")
   public static final String PRIVATE_CONSTANT_26 = "CHANGE_ACTIONS_TABLE";

   @RBEntry("产生的对象")
   @RBComment("The Resulting Items table title.")
   public static final String PRIVATE_CONSTANT_27 = "RESULTING_ITEMS_TABLE";

   @RBEntry("审阅产生的对象")
   @RBComment("The table title for the review resulting objects table on a review workflow task.")
   public static final String REVIEW_TASK_RESULTING_ITEMS_TABLE = "REVIEW_TASK_RESULTING_ITEMS_TABLE";   

   @RBEntry("完�?产生的对象")
   @RBComment("The table title for the complete resulting objects table on a workflow task.")
   public static final String COMPLETE_TASK_RESULTING_ITEMS_TABLE = "COMPLETE_TASK_RESULTING_ITEMS_TABLE";
   
   @RBEntry("�?�影�?对象")
   @RBComment("The Affected Objects (change request, problem report, Variance) table title.")
   public static final String PRIVATE_CONSTANT_28 = "AFFECTED_DATA_TABLE";

   @RBEntry("�?�影�?的�?�?")
   @RBComment("The Affected End Items table title.")
   public static final String PRIVATE_CONSTANT_29 = "AFFECTED_END_ITEMS_TABLE";

   @RBEntry("更改汇总")
   @RBComment("Affected and Resulting Data for all Change Tasks on a Change Notice")
   public static final String CHANGE_NOTICE_SUMMARY_TABLE = "CHANGE_NOTICE_SUMMARY_TABLE";

   @RBEntry("审计更改汇总")
   @RBComment("The table title for the audit change summary table.")
   public static final String AUDIT_CHANGE_NOTICE_SUMMARY_TABLE = "AUDIT_CHANGE_NOTICE_SUMMARY_TABLE";   

   @RBEntry("关�?�的问题和超差")
   @RBComment("The table title for the Related Problem Reports (as well as other issues) and Variances.")
   public static final String RELATED_CHANGEISSUES_TABLE = "RELATED_CHANGEISSUES_TABLE";

   @RBEntry("关�?�的更改请求")
   @RBComment("The table title for the related change requests.")
   public static final String RELATED_CHANGEREQUESTS_TABLE = "RELATED_CHANGEREQUESTS_TABLE";

   @RBEntry("问题和超差")
   @RBComment("The table title for the Related Problem Reports (and other issues) and Variances.")
   public static final String PRIVATE_CONSTANT_30 = "CHANGE_ISSUES_TABLE";

   @RBEntry("更改请求")
   @RBComment("The plural name of the object \"Change Request\".")
   public static final String PRIVATE_CONSTANT_31 = "CHANGE_REQUESTS_TABLE";

   @RBEntry("更改通告")
   @RBComment("The plural name of the object \"Change Notice\".")
   public static final String PRIVATE_CONSTANT_32 = "CHANGE_NOTICES_TABLE";

   @RBEntry("�?�更改通告的影�?")
   @RBComment("The table title for the Affected by Change Notices info page table")
   public static final String PRIVATE_CONSTANT_33 = "AFFECTED_BY_CHANGE_NOTICES_TABLE";

   @RBEntry("由更改通告产生")
   @RBComment("The table title for the Resulting from Change Notices info page table")
   public static final String PRIVATE_CONSTANT_34 = "RESULTING_FROM_CHANGE_NOTICES_TABLE";

   @RBEntry("注释集")
   @RBComment("The table title for the Annotation Set table")
   public static final String PRIVATE_CONSTANT_35 = "ANNOTATION_SET_TABLE";

   @RBEntry("属性")
   @RBComment("The table title for the Variance Analysis attribute table.")
   public static final String VARIANCE_ANALYSIS_TABLE = "VARIANCE_ANALYSIS_TABLE";

   @RBEntry("属性")
   @RBComment("The table tile for the Attributes table from the information pages.")
   public static final String PRIVATE_CONSTANT_36 = "ATTRIBUTES_TABLE";

   @RBEntry("未�?�并更改")
   @RBComment("The table title for the Unincorporated changes table")
   public static final String PRIVATE_CONSTANT_37 = "UNINCORPORATED_CHANGE_TABLE";

   @RBEntry("�??议和调查")
   @RBComment("The table title for the Change Proposals and Change Investigations")
   public static final String PRIVATE_CONSTANT_38 = "PROPOSALS_AND_INVESTIGATIONS_TABLE";

   @RBEntry("分�?活动")
   @RBComment("The table title for Analysis Activities")
   public static final String PRIVATE_CONSTANT_39 = "ANALYSIS_ACTIVITIES_TABLE";

   @RBEntry("更改通告")
   @RBComment("The column name for the Change Notice Id")
   public static final String HC_CHANGENOTICE = "HC_CHANGENOTICE";

   @RBEntry("状�?")
   @RBComment("The column name for the Change Notice State")
   public static final String HC_CHANGENOTICE_STATE = "HC_CHANGENOTICE_STATE";

   @RBEntry("更改任务")
   @RBComment("The column name for the Change Task Id")
   public static final String HC_CHANGETASK = "HC_CHANGETASK";

   @RBEntry("�?�并计划")
   @RBComment("The column name for Incorporation Plan")
   public static final String HC_INCORPOPTION = "HC_INCORPOPTION";

   @RBEntry("计划的修订版本")
   @RBComment("The column name for Planned Revision")
   public static final String HC_INCORPREVISION = "HC_INCORPREVISION";

   @RBEntry("问题")
   @RBComment("The title for the All Open Issues table.")
   public static final String OPEN_ISSUES_TITLE = "OPEN_ISSUES_TITLE";

   @RBEntry("更改请求")
   @RBComment("The title for the All Open Change Requests table.")
   public static final String OPEN_CHANGE_REQUESTS_TITLE = "OPEN_CHANGE_REQUESTS_TITLE";

   @RBEntry("更改通告")
   @RBComment("The title for the All Open Change Notices table.")
   public static final String OPEN_CHANGE_NOTICES_TITLE = "OPEN_CHANGE_NOTICES_TITLE";

   @RBEntry("超差")
   @RBComment("The title for the All Open Variances table.")
   public static final String OPEN_VARIANCES_TITLE = "OPEN_VARIANCES_TITLE";

   @RBEntry("创建问题报告的方法之一是: �?览至�?�更改对象 (如部件或文档) 信�?�页�?�，并在�?作列表内选择“新建问题报告�?。有关详细信�?�，请�?�阅�?�机帮助中“问题报告�?表格相关内容。")
   @RBComment("Informational text to create problem reports.")
   public static final String OPEN_PROBLEM_REPORTS_HELP = "OPEN_PROBLEM_REPORTS_HELP";

   @RBEntry("创建更改通告的方法之一是，�?览至更改请求信�?�页�?�，并在�?作列表内选择“新建更改通告�?。有关详细信�?�，请�?�阅�?�机帮助中“更改通告�?表格相关内容。")
   @RBComment("Informational text to create change notices.")
   public static final String OPEN_CHANGE_NOTICES_HELP = "OPEN_CHANGE_NOTICES_HELP";

   @RBEntry("创建更改请求的方法之一是，�?览至问题报告的信�?�页�?�，并在�?作列表内选择“新建更改请求�?。有关详细信�?�，请�?�阅�?�机帮助中“更改请求�?表格相关内容。")
   @RBComment("Informational text to create requests notices.")
   public static final String OPEN_CHANGE_REQUESTS_HELP = "OPEN_CHANGE_REQUESTS_HELP";

   @RBEntry("创建超差的方法之一是，�?览至�?�更改对象 (如部件或文档) 信�?�页�?�，并在�?作列表内选择“新建超差�?。有关详细信�?�，请�?�阅�?�机帮助中“超差�?表格相关内容。")
   @RBComment("Informational text to create variances.")
   public static final String OPEN_VARIANCES_HELP = "OPEN_VARIANCES_HELP";

   @RBEntry("相关的需求")
   @RBComment("Title for the fulfill requirements table")
   public static final String PRIVATE_CONSTANT_40 = "FULFILL_CHANGEACTIONS_TABLE";

   @RBEntry("更改基线")
   @RBComment("Title for the Change Baseline report tree")
   public static final String CHANGE_BASELINE_TABLE = "CHANGE_BASELINE_TABLE";


   /**
    * ##############################################################################
    *
    * Table views
    *
    * ##############################################################################
    */

   @RBEntry("问题报告")
   public static final String PROBLEM_REPORT_TABLEVIEW_NAME = "PROBLEM_REPORT_TABLEVIEW_NAME";

   @RBEntry("仅显示问题报告的视图。")
   public static final String PROBLEM_REPORT_TABLEVIEW_DESCRIPTION = "PROBLEM_REPORT_TABLEVIEW_DESCRIPTION";

   @RBEntry("超差")
   public static final String VARIANCE_TABLEVIEW_NAME = "VARIANCE_TABLEVIEW_NAME";

   @RBEntry("仅显示超差的视图。")
   public static final String VARIANCE_TABLEVIEW_DESCRIPTION = "VARIANCE_TABLEVIEW_DESCRIPTION";

   @RBEntry("更改�?图")
   public static final String CHANGE_INTENT = "CHANGE_INTENT";

   @RBEntry("版本内容")
   public static final String RELEASE_CONTENT = "RELEASE_CONTENT";

   @RBEntry("�?�影�?部件")
   public static final String AFFECTED_PARTS = "AFFECTED_PARTS";

   @RBEntry("默认值")
   @RBComment("The default table view name for the Change Baseline report")
   public static final String CHANGE_BASELINE_REPORT_TABLE_VIEW_DEFAULT_NAME = "CHANGE_BASELINE_REPORT_TABLE_VIEW_DEFAULT_NAME";

   @RBEntry("默认视图")
   @RBComment("The default table view description for the Change Baseline report")
   public static final String CHANGE_BASELINE_REPORT_TABLE_VIEW_DEFAULT_DESC = "CHANGE_BASELINE_REPORT_TABLE_VIEW_DEFAULT_DESC";

   /**
    * ##############################################################################
    *
    * Table columns specific to change
    *
    * ##############################################################################
    **/
   @RBEntry("已订")
   @RBComment("The label for the disposition column.")
   public static final String ONORDERDISPOSITION = "ONORDERDISPOSITION";

   @RBEntry("工作正在进行")
   @RBComment("The label for the disposition column.")
   public static final String INVENTORYDISPOSITION = "INVENTORYDISPOSITION";

   @RBEntry("已完�?")
   @RBComment("The label for the disposition column.")
   public static final String FINISHEDDISPOSITION = "FINISHEDDISPOSITION";

   @RBEntry("处置备注")
   @RBComment("The label for the disposition comment column.")
   public static final String DISPOSITIONCOMMENTS = "DISPOSITIONCOMMENTS";

   @RBEntry("批准的数�?")
   @RBComment("The label for Approved Quantity column.")
   public static final String APPROVEDQUANTITY = "APPROVEDQUANTITY";

   @RBEntry("备注")
   @RBComment("Label to be used in the Table Views")
   public static final String CHANGE_LINK_DESCRIPTION = "CHANGE_LINK_DESCRIPTION";

   @RBEntry("表格�?�数")
   @RBComment("Label used in the table views. This column is a hidden parameter column.")
   public static final String CHANGE_TABLE_DATA_COLUMN = "CHANGE_TABLE_DATA_COLUMN";

   @RBEntry("未�?�并的更改")
   @RBComment("Label used in the table views. This column is a hidden parameter column.")
   public static final String INCORP_HANGINGCHANGE_TABLE_DATA_COLUMN = "INCORP_HANGINGCHANGE_TABLE_DATA_COLUMN";

   @RBEntry("影�?的对象")
   @RBComment("This column is used to filter the display of affected and resulting objects. This column is only displayed on the filter step of the table view wizard.")
   public static final String IMPACTING_OBJECTS_COLUMN = "IMPACTING_OBJECTS_COLUMN";

   @RBEntry("关系")
   @RBComment("This column is used to display the link relation ship of the affected or resulting objects.")
   public static final String RELATIONSHIP = "RELATIONSHIP";

   @RBEntry("任务�??称")
   @RBComment("This column is to display the name of the change task on a affected or resulting link.")
   public static final String TASK_NAME_COLUMN = "TASK_NAME_COLUMN";

   @RBEntry("任务编�?�")
   @RBComment("This column is to display the number of the change task on a affected or resulting link.")
   public static final String TASK_NUMBER_COLUMN = "TASK_NUMBER_COLUMN";
   
   @RBEntry("任务状�?")
   @RBComment("This column is to display the state of the change task on a affected or resulting link.")
   public static final String TASK_STATE_COLUMN = "TASK_STATE_COLUMN";  

   @RBEntry("�?�影�?的状�?")
   @RBComment("This column is to indicate if the Affected Status is shown for any item which is added as a resulting object or unincorporated change on a change task but does not have a corresponding equal or predecessor revision as an affected object.")
   public static final String AFFECTED_STATUS = "AFFECTED_STATUS";

   @RBEntry("没有�?�影�?的对象")
   @RBComment("A message is to indicate if the Affected Status is shown for any item which is added as a resulting object or unincorporated change on a change task but does not have a corresponding equal or predecessor revision as an affected object.")
   public static final String AFFECTED_STATUS_MSG = "AFFECTED_STATUS_MSG";

   @RBEntry("目标状�?")
   @RBComment("This column is to indicate if the Change target state of the change task resulting objects.")
   public static final String CHANGE_TARGET_STATE = "CHANGE_TARGET_STATE";

   @RBEntry("新版本")
   @RBComment("This column is to indicate if the new version of the successor object in the Change Baseline report table.")
   public static final String NEW_VERSION = "NEW_VERSION";

   @RBEntry("计划授�?�")
   @RBComment("This column is to indicate if the planned authorization of the successor object in the Change Baseline report table.")
   public static final String PLANNED_AUTHORIZATION = "PLANNED_AUTHORIZATION";

   @RBEntry("�?作")
   @RBComment("This column is to indicate if the action of the successor object in the Change Baseline report table.")
   public static final String PLANNED_ACTION = "PLANNED_ACTION";
   
   @RBEntry("�?�布目标")
   @RBComment("This column is to indicate the change management transition for the resulting object.")
   public static final String CHANGE_TARGET_TRANSITION = "CHANGE_TARGET_TRANSITION";
   
   @RBEntry("具有未完�?任务的工作负责人")
   @RBComment("Set of columns intended to show the users that have open workflow tasks on a change task")
   public static final String CHANGE_TASK_ASSIGNEES = "CHANGE_TASK_ASSIGNEES";

   @RBEntry("标识")
   @RBComment("This column is to display the attributes that uniquely identify an object.")
   public static final String IDENTITY_COLUMN_NAME = "IDENTITY_COLUMN_NAME";

   /**
    * ##############################################################################
    *
    * The action types for the Successor objects in the Change Baseline report
    *
    * ##############################################################################
    */

    @RBEntry("添加")
    @RBComment("Indicates that the object was added.")
    public static final String PLANNED_ACTION_TYPE_ADD = "PLANNED_ACTION_TYPE_ADD";

    @RBEntry("删除")
    @RBComment("Indicates that object was removed was removed.")
    public static final String PLANNED_ACTION_TYPE_REMOVE = "PLANNED_ACTION_TYPE_REMOVE";

    @RBEntry("修订")
    @RBComment("Indicates that the successor object was revised.")
    public static final String PLANNED_ACTION_TYPE_REVISE = "PLANNED_ACTION_TYPE_REVISE";

   /**
    * ##############################################################################
    *
    * labels for impacting objects
    *
    * ##############################################################################
    **/

   @RBEntry("�?�影�?对象")
   @RBComment("This label is used to filter affected objects.")
   public static final String SHOW_AFFECTED_OBJECTS = "SHOW_AFFECTED_OBJECTS";

   @RBEntry("产生的对象")
   @RBComment("This label is used to filter resulting objects.")
   public static final String SHOW_RESULTING_OBJECTS = "SHOW_RESULTING_OBJECTS";

   @RBEntry("�?�影�?的/产生的对象")
   @RBComment("This label is used to filter affected and resulting objects.")
   public static final String SHOW_AFFECTED_RESULTING_OBJECTS = "SHOW_AFFECTED_RESULTING_OBJECTS";


   /**
    * ##############################################################################
    *
    * labels specific to annotation
    *
    * ##############################################################################
    **/
   @RBEntry("�?�影�?的对象")
   @RBComment("Affected data label.")
   public static final String PRIVATE_CONSTANT_41 = "AFFECTED_DATA_LABEL";

   @RBEntry("注释集")
   @RBComment("The label for related affected data column.")
   public static final String ANNOTATION_SET_LABEL = "ANNOTATION_SET_LABEL";

   @RBEntry("注释集列表")
   @RBComment("The label for related affected data column.")
   public static final String PRIVATE_CONSTANT_42 = "ANNOTATION_SET_LIST_LABEL";

   /**
    * #######################################################
    *
    * Owning Change Object
    *
    * #######################################################
    **/
   @RBEntry("更改通告")
   @RBComment("Label for the Owning Change Notice")
   public static final String OWNING_CHANGE_NOTICE = "OWNING_CHANGE_NOTICE";

   @RBEntry("更改通告�??称")
   @RBComment("Label for the Owning Change Notice Name")
   public static final String OWNING_CHANGE_NOTICE_NAME = "OWNING_CHANGE_NOTICE_NAME";

   @RBEntry("更改请求")
   @RBComment("Label for the Owning Change Request")
   public static final String OWNING_CHANGE_REQUEST = "OWNING_CHANGE_REQUEST";

   @RBEntry("更改请求�??称")
   @RBComment("Label for the Owning Change Request Name")
   public static final String OWNING_CHANGE_REQUEST_NAME = "OWNING_CHANGE_REQUEST_NAME";

   @RBEntry("更改�??议")
   @RBComment("Label for the Owning Change Proposal")
   public static final String OWNING_CHANGE_PROPOSAL = "OWNING_CHANGE_PROPOSAL";

   @RBEntry("更改�??议�??称")
   @RBComment("Label for the Owning Change Proposal Name")
   public static final String OWNING_CHANGE_PROPOSAL_NAME = "OWNING_CHANGE_PROPOSAL_NAME";

   @RBEntry("更改调查")
   @RBComment("Label for the Owning Change Investigation")
   public static final String OWNING_CHANGE_INVESTIGATION = "OWNING_CHANGE_INVESTIGATION";

   @RBEntry("更改调查�??称")
   @RBComment("Label for the Owning Change Investigation Name")
   public static final String OWNING_CHANGE_INVESTIGATION_NAME = "OWNING_CHANGE_INVESTIGATION_NAME";

   @RBEntry("更改对象")
   @RBComment("Label for the Owning Change Object")
   public static final String OWNING_CHANGE_OBJECT = "OWNING_CHANGE_OBJECT";

   @RBEntry("更改对象�??称")
   @RBComment("Label for the Owning Change Object Name")
   public static final String OWNING_CHANGE_OBJECT_NAME = "OWNING_CHANGE_OBJECT_NAME";

   @RBEntry("(�?�?�用)")
   @RBComment("Label for an object that is unavailable")
   public static final String UNAVAILABLE = "UNAVAILABLE";

   /**
    * #######################################################
    *
    * Implementation Plan Table
    *
    * #######################################################
    **/
   @RBEntry("实施计划")
   @RBComment("The title of the Implementaiton Plan")
   public static final String IMPLEMENTATION_PLAN_TABLE = "IMPLEMENTATION_PLAN_TABLE";

   @RBEntry("编辑图标")
   @RBComment("Selectable Column name")
   public static final String IMPLEMENTATION_PLAN_TABLE_ICON_ACTIONS = "IMPLEMENTATION_PLAN_TABLE_ICON_ACTIONS";

   @RBEntry("修订版本")
   @RBComment("Revision Column name")
   public static final String IMPLEMENTATION_PLAN_TABLE_REVISION = "IMPLEMENTATION_PLAN_TABLE_REVISION";

   @RBEntry("编�?�")
   @RBComment("Number Column name")
   public static final String IMPLEMENTATION_PLAN_TABLE_NUMBER = "IMPLEMENTATION_PLAN_TABLE_NUMBER";

   @RBEntry("�??称")
   @RBComment("Name Column name")
   public static final String IMPLEMENTATION_PLAN_TABLE_NAME = "IMPLEMENTATION_PLAN_TABLE_NAME";

   @RBEntry("�?/市/自治区")
   @RBComment("State Column name")
   public static final String IMPLEMENTATION_PLAN_TABLE_STATE = "IMPLEMENTATION_PLAN_TABLE_STATE";

   @RBEntry("工作负责人")
   @RBComment("Assignee Column name")
   public static final String IMPLEMENTATION_PLAN_TABLE_LAST_ROLE_ASSIGNEE = "IMPLEMENTATION_PLAN_TABLE_LAST_ROLE_ASSIGNEE";

   @RBEntry("审阅者")
   @RBComment("Reviewer Column name")
   public static final String IMPLEMENTATION_PLAN_TABLE_LAST_ROLE_REVIEWER = "IMPLEMENTATION_PLAN_TABLE_LAST_ROLE_REVIEWER";

   @RBEntry("需�?日期")
   @RBComment("Need DateColumn name")
   public static final String IMPLEMENTATION_PLAN_TABLE_NEED_DATE = "IMPLEMENTATION_PLAN_TABLE_NEED_DATE";

   @RBEntry("�?列")
   @RBComment("Change task sequence column name")
   public static final String IMPLEMENTATION_PLAN_TABLE_SEQUENCE = "IMPLEMENTATION_PLAN_TABLE_SEQUENCE";

   @RBEntry("实施状�?")
   @RBComment("Label for Implementation Status column in the implementation plan table")
   public static final String IMPLEMENTATION_PLAN_TABLE_STATUS = "IMPLEMENTATION_PLAN_TABLE_STATUS";

   /**
    * Added to resolve compile issue
    **/
   @RBEntry("实施计划")
   @RBComment("Change Notice table header.")
   public static final String CHANGE_NOTICE_TABLE_HEADER = "CHANGE_NOTICE_TABLE_HEADER";

   /**
    * ########################################################
    *
    * Revise Client Strings (ChangeItem Reissue Dialog)
    *
    * ########################################################
    **/
   @RBEntry("影�?")
   @RBComment("The impact of the revise.  Either Modify of Proceed")
   public static final String REVISE_IMPACT = "REVISE_IMPACT";

   @RBEntry("新建修订版本")
   @RBComment("The label for the new revision")
   public static final String NEW_REVISION = "NEW_REVISION";

   @RBEntry("修订更改对象时出错。")
   @RBComment("The message header (ATTENTION:) is already added.")
   public static final String REVISE_ERROR_HEADER = "REVISE_ERROR";

   @RBEntry("更改对象")
   @RBComment("The label for the change item Identity")
   public static final String CHANGE_ITEM_IDENTITY = "CHANGE_ITEM_IDENTITY";

   /**
    * #########################################################
    *
    * Change Status Column Strings
    *
    * #########################################################
    **/
   @RBEntry("更改状况")
   @RBComment("The column header for the change status column.")
   public static final String CHANGE_STATUS_COLUMN = "statusFamily_Change";

   /**
    * #########################################################
    *
    * Specialized Attribute handling messages.
    *
    * #########################################################
    **/
   @RBEntry("您指定的“超差所有者�?用户无效。")
   @RBComment("The message when the user picked a user but this uid is not valid in the system.")
   public static final String VARIANCEOWNER_NOTFOUND = "VarianceOwner_NotFound";

   @RBEntry("无法创建超差。")
   public static final String VARIANCE_CREATE_CANNOTCREATE = "Variance_Create_CanNotCreate";

   @RBEntry("清除现有处置备注")
   @RBComment("Text display value for the check box to clear disposition comments.")
   public static final String CLEAR_DISPOSITION_COMMENTS = "CLEAR_DISPOSITION_COMMENTS";

   /**
    * #########################################################
    *
    * Propagation Message Strings
    *
    * #########################################################
    **/
   @RBEntry("传播�?自问题报告的数�?�")
   @RBComment("Option label to indicate propagation of meta-data, affected data, etc.from a Problem Report to a Change Request")
   public static final String PROPAGATE_DATA_FROM_PR_LABEL = "PropagateProblemReport_label";

   @RBEntry("传播�?自超差的数�?�")
   @RBComment("Option label to indicate propagation of meta-data, affected data, etc.from a Variance to a Change Request")
   public static final String PROPAGATE_DATA_FROM_VARIANCE_LABEL = "PropagateVariance_label";

   @RBEntry("传播�?自更改请求的数�?�")
   @RBComment("Option label to indicate propagation of meta-data, affected data, etc.from a Change Request to a Change Notice.")
   public static final String PROPAGATE_DATA_FROM_CR_LABEL = "PropagateChangeRequest_label";

   /**
    * #########################################################
    *
    * Wizard Error messages.
    *
    * #########################################################
    **/
   @RBEntry("无法顺利处�?��?�影�?的对象。")
   public static final String AFFECTED_ITEMS_PROCESSING_ERROR = "AffectedItems_Processing_Error";

   @RBEntry("无法处�?��?�影�?的对象。")
   public static final String AFFECTED_ITEMS_PROCESSING_ERRORHEADER = "AffectedItems_Processing_ErrorHeader";

   @RBEntry("无法顺利处�?��?�影�?的�?�?。")
   public static final String AFFECTED_END_ITEMS_PROCESSING_ERROR = "AffectedEndItems_Processing_Error";

   @RBEntry("无法处�?��?�影�?的�?�?。")
   public static final String AFFECTED_END_ITEMS_PROCESSING_ERRORHEADER = "AffectedEndItems_Processing_ErrorHeader";

   @RBEntry("无法顺利处�?�产生的对象。")
   public static final String RESULTING_ITEMS_PROCESSING_ERROR = "ResultingItems_Processing_Error";

   @RBEntry("无法处�?�产生的对象。")
   public static final String RESULTING_ITEMS_PROCESSING_ERRORHEADER = "ResultingItems_Processing_ErrorHeader";

   @RBEntry("创建新的一次性版本时出错。请�?�系您的管�?�员。")
   public static final String NEWONEOFFVERISON_ACTION_CANNOT_CREATE = "NewOneOffVersion_Action_CannotCreate";

   @RBEntry("<b>注�?</b>: 创建新的一次性版本�?作失败。")
   @RBComment("The <b> tags are added to bold the attention as per UI message design.  This is using a Ext dialog which supports Bold tags.")
   public static final String NEWONEOFFVERSION_ACTION_HEADER_MSG = "NewOneOffVersion_Action_HeaderMsg";

   @RBEntry("若干对象无效: {0}\n\n所报告的第一个消�?�为:\n{1}")
   public static final String NEWONEOFFVERSION_ACTION_TOOMANYERRORS = "NewOneOffVersion_Action_TooManyErrors";

   @RBEntry("注�?: 无法设置处置。")
   @RBComment("Header message for the diposition dialog.")
   public static final String SETDISPOSITION_ACTION_HEADER_MSG = "SetDisposition_Action_HeaderMsg";

   @RBEntry("选择的对象中无一�?�执行此�?作。")
   @RBComment("Message when the action is launched and the objects are not applicable.")
   public static final String INVALIDOBJECTS = "InvalidObjects";

   @RBEntry("�??议的解决方案")
   public static final String PRIVATE_CONSTANT_43 = "CHANGE_PROPOSEDCHANGES";

   @RBEntry("请与系统管�?�员�?�系。")
   public static final String CHANGEMANAGEMENT_PROCESSING_ERRORMSG = "ChangeManagement_Processing_ErrorMsg";

   @RBEntry("无法创建问题报告。")
   public static final String CREATEPROBLEMREPORT_PROCESSING_ERROR = "CreateProblemReport_Processing_Error";

   @RBEntry("无法创建超差。")
   public static final String CREATEVARIANCE_PROCESSING_ERROR = "CreateVariance_Processing_Error";

   @RBEntry("无法创建更改请求。")
   public static final String CREATECHANGEREQUEST_PROCESSING_ERROR = "CreateChangeRequest_Processing_Error";

   @RBEntry("无法创建更改通告模�?�。")
   public static final String CREATECHANGENOTICETEMPLATE_PROCESSING_ERROR = "CreateChangeNoticeTemplate_Processing_Error";
   
   @RBEntry("无法创建更改任务模�?�。")
   public static final String CREATECHANGETASKTEMPLATE_PROCESSING_ERROR = "CreateChangeTaskTemplate_Processing_Error";
   
   @RBEntry("无法创建更改通告。")
   public static final String CREATECHANGENOTICE_PROCESSING_ERROR = "CreateChangeNotice_Processing_Error";

   @RBEntry("创建更改通高时出现�?�致命错误。")
   public static final String CreateChangeNotice_ImpactMatrix_ErrorHeader = "CreateChangeNotice_ImpactMatrix_ErrorHeader";

   @RBEntry("更改影�?矩阵无法关�?�到此更改通告。请�?�系您的管�?�员，了解更多信�?�。")
   public static final String CreateChangeNotice_ImpactMatrix_Error = "CreateChangeNotice_ImpactMatrix_Error";

   @RBEntry("无法创建更改任务。")
   public static final String CREATECHANGETASK_PROCESSING_ERROR = "CreateChangeTask_Processing_Error";

   @RBEntry("无法创建更改�??议。")
   public static final String CREATECHANGEPROPOSAL_PROCESSING_ERROR = "CreateChangeProposal_Processing_Error";

   @RBEntry("无法编辑问题报告。")
   public static final String EDITPROBLEMREPORT_PROCESSING_ERROR = "EditProblemReport_Processing_Error";

   @RBEntry("无法编辑超差。")
   public static final String EDITVARIANCE_PROCESSING_ERROR = "EditVariance_Processing_Error";

   @RBEntry("无法创建更改请求。")
   public static final String EDITCHANGEREQUEST_PROCESSING_ERROR = "EditChangeRequest_Processing_Error";

   @RBEntry("无法编辑更改通告。")
   public static final String EDITCHANGENOTICE_PROCESSING_ERROR = "EditChangeNotice_Processing_Error";
   
   @RBEntry("无法编辑更改通告模�?�。")
   public static final String EDITCHANGENOTICETEMPLATE_PROCESSING_ERROR = "EditChangeNoticeTemplate_Processing_Error";

   @RBEntry("无法编辑更改任务。")
   public static final String EDITCHANGETASK_PROCESSING_ERROR = "EditChangeTask_Processing_Error";
   
   @RBEntry("无法编辑更改任务模�?�。")
   public static final String EDITCHANGETASKTEMPLATE_PROCESSING_ERROR = "EditChangeTaskTemplate_Processing_Error";

   @RBEntry("无法编辑更改�??议。")
   public static final String EDITCHANGEPROPOSAL_PROCESSING_ERROR = "EditChangeProposal_Processing_Error";

   @RBEntry("无法删除更改任务。")
   public static final String DELETECHANGETASK_PROCESSING_ERROR = "DeleteChangeTask_Processing_Error";

   @RBEntry("无法创建更改计划。")
   public static final String CREATE_CHANGE_PLAN_ERROR = "CREATE_CHANGE_PLAN_ERROR";

   @RBEntry("注�?: 缺少必需的信�?�。\n\n至少需�?一个更改任务。请创建一个新更改任务以便继续。")
   public static final String IMPLEMENTATION_TABLE_NO_TASKS = "Implementation_Table_No_Tasks";

   @RBEntry("注�?: �?些项�?正确。\n\n找�?到实施计划表")
   public static final String UNABLE_TO_FIND_IMPL_TABLE = "Unable_To_Find_Impl_Table";

   @RBEntry("注�?: 需�?更改请求。\n\n需�?至少有一个更改请求与此更改通告关�?�。")
   @RBComment("Message displayed when a Change Notice needs to have associated Change Request but it is missing")
   public static final String CHANGENOTICE_VALIDATE_ASSOCIATED_CR = "CHANGENOTICE_VALIDATE_ASSOCIATED_CR";

   @RBEntry("注�?: �?作�?�?�用\n\n新的更改通告�?求更改任务。\n您没有创建更改任务的�?��?。")
   @RBComment("Error message for the Create Change Notice wizard when the user does not have access to create any Change Task types.")
   public static final String CREATECHANGENOTICE_NO_TASK_TYPES = "CreateChangeNotice_No_Task_Types";

   @RBEntry("在第三方报告系统中，�?存在 {0} 的定义。")
   public static final String THIRDPARTYREPORTING_NODEFEXISTS_ERROR = "ThirdPartyReporting_NoDefExists_Error";

   @RBEntry("�?存在这样的报告: {0}")
   public static final String REPORT_NOTEXISTS_ERROR = "Report_NotExists_Error";

   @RBEntry("�?存在这样的报告: {0}")
   public static final String REPORT_NOTSUPPORTED_ERROR = "Report_NotSupported_Error";

   @RBEntry("{0} 的关系无效。")
   @RBComment("Message for validationg the association of an object for an AssociationConstrainable link when peforming a client action.")
   public static final String INVALID_ROLE_B_TYPE = "INVALID_ROLE_B_TYPE";

   @RBEntry("注�?: 缺少必需的信�?� \n\n在更改任务上，编�?�为必填项。编辑更改任务以包�?�一个编�?�。")
   public static final String CHANGE_TASK_NUMBER_REQUIRED = "CHANGE_TASK_NUMBER_REQUIRED";

   @RBEntry("您没有创建选定上下文的�?��?。")
   @RBComment("Error message for the change create wizard context step.")
   public static final String NO_CREATE_FOR_CONTEXT = "NO_CREATE_FOR_CONTEXT";
   
   @RBEntry("注�?: 无法创建更改通告。\n\n您没有�?��?在选定的更改通告模�?�中创建一个或多个更改任务类型。")
   @RBComment("Error message for the Create Change Notice wizard when the user does not have access to create the Change Task types in the selected change notice template.")
   public static final String CREATE_CHANGE_NOTICE_FROM_TEMPLATE_NO_TASK_TYPES = "CREATE_CHANGE_NOTICE_FROM_TEMPLATE_NO_TASK_TYPES";

   /**
    * ##############################################################################
    *
    * Change Management specific workflow strings
    *
    * ##############################################################################
    **/
   @RBEntry("自动创建更改通告")
   @RBComment("Label for the Automate the fast-track checkbox")
   public static final String AUTOMATE_FASTTRACK = "AUTOMATE_FASTTRACK";

   @RBEntry("注�?: 未填写必填字段。\n\n“工作负责人�?和“审阅者�?字段是必填字段，但尚未指定。请使用“查找...�?按钮选择有效用户。")
   public static final String CHANGETASK_VALIDATE_USER = "CHANGETASK_VALIDATE_USER";

   @RBEntry("确认:  删除更改任务 \n\n是�?�确定�?删除选定更改任务?")
   @RBComment("Message displayed to ask user whether they are sure they wish to delete change tasks")
   public static final String CONFIRM_DELETE_CHANGE_TASK = "CONFIRM_DELETE_CHANGE_TASK";

   @RBEntry("注�?: 无法继续编辑。\n\n此对象已由�?�一个用户更新，必须刷新�?�导。在此编辑会�?中所�?�的更改将丢失。")
   @RBComment("Message displayed when the system detects a change is made.")
   public static final String CONFIRM_UPDATE_CHANGEITEM = "CONFIRM_UPDATE_CHANGEITEM";

   @RBEntry("无法�?�放该更改通告，由于下列所得到的对象已被检出:")
   @RBComment("Special Instructions that appear in the \"Resolve Change Notice Conflicts\" Change Notice workflow task.  It is followed by a list of objects that are checked out.")
   public static final String PRERELEASE_VALIDATION_MSG = "PRERELEASE_VALIDATION_MSG";
   
   @RBEntry("无法�?�放该更改通告，因为�?�??以下业务规则:")
   @RBComment("Special Instructions that appear in the \"Resolve Change Notice Conflicts\" Change Notice workflow task.  It is followed by a list of business rules that failed.")
   public static final String BUSINESS_RULES_PRERELEASE_VALIDATION_MSG = "BUSINESS_RULES_PRERELEASE_VALIDATION_MSG";

   @RBEntry("确认: 确定�?导航到该表的�?�一页�?�? 这将丢失任何在该表当�?页中输入的数�?�。")
   @RBComment("Message displayed to ask user whether they are sure they wish to go to next page in a change table")
   public static final String CONFIRM_PAGING_CHANGE_TABLES = "CONFIRM_PAGING_CHANGE_TABLES";

   @RBEntry("由于以下更改任务还未实施，因而此更改通告�?能�?�布:")
   @RBComment("Special Instructions that appear in the \"Assignee or Reviewer Conflicts\" Change Notice workflow task.  It is followed by a list of change tasks that are not ready for implementation.")
   public static final String IMPLEMENTATION_VALIDATION_MSG = "IMPLEMENTATION_VALIDATION_MSG";

   @RBEntry("收集�?作失败")
   @RBComment("Message for when none of the objects collected are valid for the table.")
   public static final String COLLECTED_FAILED = "COLLECTED_FAILED";

   @RBEntry("无法将所有�?�集的对象添加至该�?置。")
   @RBComment("Detailed message for when none of the objects collected are valid for the table.")
   public static final String COLLECTED_FAILED_MSG = "COLLECTED_FAILED_MSG";

   @RBEntry("收集�?作部分失败")
   @RBComment("Message for when some of the objects collected are not valid for the table.")
   public static final String COLLECTED_PARTIALLY_FAILED = "COLLECTED_PARTIALLY_FAILED";

   @RBEntry("无法将�?些�?�集的对象添加至该�?置:")
   @RBComment("Detailed message for when some of the objects collected are not valid for the table.")
   public static final String COLLECTED_PARTIALLY_FAILED_MSG = "COLLECTED_PARTIALLY_FAILED_MSG";

   @RBEntry("添加修订的对象失败")
   @RBComment("Message for when the revise is successful but none of the objects revised are valid for the table.")
   public static final String REVISE_FAILED = "REVISE_FAILED";

   @RBEntry("对象已被修订，但无法添加至该�?置。")
   @RBComment("Detailed message for when the revise is successful but none of the objects revised are valid for the table.")
   public static final String REVISE_FAILED_MSG = "REVISE_FAILED_MSG";

   @RBEntry("添加修订的对象部分失败")
   @RBComment("Message for when the revise is successful but some of the objects revised are invalid for the table.")
   public static final String REVISE_PARTIALLY_FAILED = "REVISE_PARTIALLY_FAILED";

   @RBEntry("对象已被修订，但其中一些对象无法添加至该�?置:")
   @RBComment("Detailed message for when the revise is successful but some of the objects revised are invalid for the table.")
   public static final String REVISE_PARTIALLY_FAILED_MSG = "REVISE_PARTIALLY_FAILED_MSG";
   
   @RBEntry("未找到常用�?�布目标")
   @RBComment("Message for when no common release targets are found when launching the release target table action.")
   public static final String NO_COMMON_RELEASE_TARGETS = "NO_COMMON_RELEASE_TARGETS";


   /**
    * ##############################################################################
    *
    * Submit Now / Submit Later messages
    *
    * ##############################################################################
    **/
   @RBEntry("<br><b>确认</b>: 是�?�立�?��??交更改对象？<br><br>�?�击“立�?��??交�?立�?��??交更改对象。<br>�?在其他时间�??交该更改对象，请�?�击“�?�?��??交�?。")
   @RBComment("The string displayed to a user when they attempt to submit a change object where Submit Now is enabled.  The <br> and <b> tags are needed because this text is dumped directly into HTML content at runtime.  There are three distinct sentences.  the first is the header message.  The remaining two are the instructions.")
   public static final String SUBMIT_NOW_MESSAGE = "SUBMIT_NOW_MESSAGE";

   @RBEntry("立�?��??交")
   @RBComment("Label for the JS Dojo button.  Equivalent of the \"Ok\" on a confirmation dialog.  See SUBMIT_NOW_MESSAGE above for context text.")
   public static final String SUBMIT_NOW_BUTTON = "SUBMIT_NOW_BUTTON";

   @RBEntry("�?�?��??交")
   @RBComment("Label for the JS Dojo button.  Equivalent of the \"Cancel\" on a confirmation dialog.  See SUBMIT_NOW_MESSAGE above for context text.")
   public static final String SUBMIT_LATER_BUTTON = "SUBMIT_LATER_BUTTON";

   /**
    * ##############################################################################
    *
    * Change object attributes to support proper localization in client
    *
    * ##############################################################################
    **/
   @RBEntry("�?�?�性")
   public static final String PRIVATE_CONSTANT_44 = "WTChangeOrder2.theChangeNoticeComplexity";

   @RBEntry("类别")
   public static final String THE_VARIANCE_CATEGORY = "WTVariance.theVarianceCategory";

   @RBEntry("相关对象(<U class='mnemonic'>R</U>)")
   @RBComment("Used for the text on the Related Objects third level nav menu.  The <U class=mnemonic> </U> tag should be put around the character that is the access key.")
   public static final String PRIVATE_CONSTANT_45 = "object.relatedDirItems.description";

   @RBEntry("r")
   @RBPseudo(false)
   @RBComment("Mnemonic for the Related Objects third level nav menu. This should be a character that matches the character surrounded by the <U class=mnemonic> </U> tag in the value line above.")
   public static final String PRIVATE_CONSTANT_46 = "object.relatedDirItems.hotkey";

   @RBEntry("相关指令(<U class='mnemonic'>R</U>)")
   @RBComment("Used for the text on the Related Objects third level nav menu.  The <U class=mnemonic> </U> tag should be put around the character that is the access key.")
   public static final String PRIVATE_CONSTANT_49 = "object.relatedPartItems.description";

   @RBEntry("r")
   @RBPseudo(false)
   @RBComment("Mnemonic for the Related Objects third level nav menu. This should be a character that matches the character surrounded by the <U class=mnemonic> </U> tag in the value line above.")
   public static final String PRIVATE_CONSTANT_50 = "object.relatedPartItems.hotkey";

   @RBEntry("无需审阅")
   @RBComment("Label for the Change Task no review required check box.")
   public static final String NO_REVIEW_REQUIRED = "NO_REVIEW_REQUIRED";

   @RBEntry("�?需�?")
   @RBComment("Label for the Change Task reviewer role when no review is required")
   public static final String ROLE_NOT_REQUIRED = "ROLE_NOT_REQUIRED";

   /**
    * ##############################################################################
    * Location field for Change Directive, Change Action
    * ##############################################################################
    **/
   @RBEntry("�?置")
   @RBComment("Label for the Location")
   public static final String LOCATION_LABEL = "LOCATION";

   @RBEntry("更改指令")
   @RBComment("Label for the Change Directive")
   public static final String CHANGE_DIRECTIVE = "CHANGE_DIRECTIVE";

   @RBEntry("�?置项")
   @RBComment("Label for the Configuration Item")
   public static final String CONFIGURATION_ITEM = "CONFIGURATION_ITEM";

   @RBEntry("影�?更改指令")
   @RBComment("The table title for the Change Directives")
   public static final String CHANGE_DIRECTIVES_TABLE = "CHANGE_DIRECTIVES_TABLE";

   @RBEntry("相关的更改�?作")
   @RBComment("Label for the related Change Actions")
   public static final String RELATEDCHANGEACTIONS = "RELATEDCHANGEACTIONS";

   @RBEntry("有效性")
   @RBComment("The column name for Effectivity")
   public static final String EFFECTIVITY = "EFFECTIVITY";

   @RBEntry("计算状况")
   @RBComment("The column name for Calculation Status")
   public static final String CALCULATIONSTATUS = "CALCULATIONSTATUS";

   @RBEntry("默认值")
   @RBComment("change directive info page default table view name")
   public static final String CHANGE_DIRECTIVES_VIEW_DEFAULT_NAME = "CHANGE_DIRECTIVES_VIEW_DEFAULT_NAME";

   @RBEntry("默认表格视图�??称")
   @RBComment(" change directive info page description default table view name")
   public static final String CHANGE_DIRECTIVES_VIEW_DEFAULT_DESC = "CHANGE_DIRECTIVES_VIEW_DEFAULT_DESC";

   @RBEntry("信�?�页�?�")
   @RBComment(" change directive info page description default table view name")
   public static final String INFO_PAGE = "CHANGE_DIRECTIVES_VIEW_INFO_PAGE";


   @RBEntry("已安排")
   @RBComment(" status indicating that the task is scheduled not started")
   public static final String SCHEDULED = "SCHEDULED";

   @RBEntry("进行中")
   @RBComment(" status indicating that the task is in progress")
   public static final String INPROGRESS = "INPROGRESS";

   @RBEntry("已完�?")
   @RBComment(" status indicating that the task has been completed")
   public static final String COMPLETED = "COMPLETED";

   @RBEntry("逾期")
   @RBComment(" status indicating that the task is over due")
   public static final String OVERDUE = "OVERDUE";

   @RBEntry("确认类别")
   public static final String CONFIRMATION_CATEGORY = "CONFIRMATION_CATEGORY";

   @RBEntry("确认审计")
   public static final String CONFIRMATION_AUDIT = "CONFIRMATION_AUDIT";
   
   @RBEntry("-- 选择模�?� --")
   public static final String SELECT_TEMPLATE = "SELECT_TEMPLATE";
   
   @RBEntry("-- 无�?�用模�?� --")
   public static final String NO_TEMPLATES_AVAILABLE = "NO_TEMPLATES_AVAILABLE";
   
   @RBEntry("模�?�")
   public static final String CHANGE_TEMPLATE_PICKER_LABEL = "CHANGE_TEMPLATE_PICKER_LABEL";

  @RBEntry("需�?日期")
  public static final String NEED_DATE = "NEED_DATE";
  
  @RBEntry("类型")
  public static final String TYPE = "TYPE";
  

  /**
   * ##############################################################################
   * Labels for Available attributes to avoid labels showing as duplicates
   * ##############################################################################
   **/
  @RBEntry("更改通告�?�?�性")
  public static final String CHANGE_ORDER_COMPLEXITY = "CHANGE_ORDER_COMPLEXITY";
  
  @RBEntry("更改事项优先级")
  public static final String ISSUE_PRIORITY = "ISSUE_PRIORITY";
  
  @RBEntry("更改事项类别")
  public static final String ISSUE_CATEGORY = "ISSUE_CATEGORY";
  
  @RBEntry("类别")
  public static final String ISSUE_THECATEGORY = "ISSUE_THECATEGORY";
  
  @RBEntry("更改请求优先级")
  public static final String REQUEST_PRIORITY = "REQUEST_PRIORITY";
  
  @RBEntry("更改请求类别")
  public static final String REQUEST_CATEGORY = "REQUEST_CATEGORY";
  
  @RBEntry("类别")
  public static final String REQUEST_THECATEGORY = "REQUEST_THECATEGORY"; 
  
  @RBEntry("更改请求�?�?�性")
  public static final String REQUEST_COMPLEXITY = "REQUEST_COMPLEXITY";

  @RBEntry("超差所有者")
  public static final String VARIANCE_OWNER = "VARIANCE_OWNER";
  
  @RBEntry("超差类别")
  public static final String VARIANCE_CATEGORY = "VARIANCE_CATEGORY";

  /*Business rules resource bundle entry START*/
  @RBEntry("更改�?�布�?验�?")
  @RBComment("Name of the rule set that will be used to display to the user when the workflow fails the check before releasing the change object.")
  public static final String CHANGE_PRE_RELEASE_RULESET_NAME = "CHANGE_PRE_RELEASE_RULESET_NAME";

  @RBEntry("在更改进程中�?�布对象之�?使用的业务规则集")
  @RBComment("Description for the CHANGE PRE RELEASE RULESET.")
  public static final String CHANGE_PRE_RELEASE_RULESET_DESC = "CHANGE_PRE_RELEASE_RULESET_DESC";

  @RBEntry("检出规则")
  @RBComment("Rule Validator to check no objects are checked out.")
  public static final String CHECK_OUT_VALIDATOR_RULE_NAME = "CHECK_OUT_VALIDATOR_RULE_NAME";

  @RBEntry("此规则确定是�?�存在检出对象。如果�?�现检出对象，规则�?通过。�?�则视为通过，")
  @RBComment("Description for CHECK_OUT_VALIDATOR_RULE_NAME")
  public static final String CHECK_OUT_VALIDATOR_RULE_DESC = "CHECK_OUT_VALIDATOR_RULE_DESC";
  
  @RBEntry("�?�布目标规则")
  public static final String RELEASE_TARGET_RULE_NAME = "RELEASE_TARGET_RULE_NAME";

  @RBEntry("�?�?�布目标规则验�?，结果对象的指定�?�布目标对于结果对象的当�?状�?有效。如果没有对结果对象指定�?�布目标，并且更改�?�布目标对于结果对象的当�?状�?有效，则该规则也有效。")
  @RBComment("Description for Release Target Rule")
  public static final String RELEASE_TARGET_RULE_DESC = "RELEASE_TARGET_RULE_DESC";
  /*Business rules resource bundle entry END*/
  
  /* Workflow task tab names */
  @RBEntry("产生的对象")
  @RBComment("Workflow task tab name for Change Task resulting objects")
  public static final String WFTASK_RESULTING_OBJECTS_TAB_NAME = "WFTASK_RESULTING_OBJECTS_TAB_NAME";
  
  @RBEntry("影�?")
  @RBComment("Workflow task tab name for Change Request, Change Notice, Problem Report or Variance impacts")
  public static final String WFTASK_IMPACTS_TAB_NAME = "WFTASK_IMPACTS_TAB_NAME";

}
