/* bcwti
 *
 * Copyright (c) 2010 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */
package com.ptc.windchill.enterprise.change2;

import wt.util.resource.RBArgComment0;
import wt.util.resource.RBComment;
import wt.util.resource.RBEntry;
import wt.util.resource.RBPseudo;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("com.ptc.windchill.enterprise.change2.change2ClientResource")
public final class change2ClientResource extends WTListResourceBundle {
   /**
    *
    * This file contains all the strings used by the DCA based Change Management clients
    *
    * ##############################################################################
    *
    * Object class names
    *
    * ##############################################################################
    **/
   @RBEntry("Variance")
   @RBComment("see wt.change2.change2ModelRB:WTVariance key")
   public static final String PRIVATE_CONSTANT_0 = "VARIANCE";

   @RBEntry("Problem Report")
   @RBComment("The name of the object \"Problem Report\".")
   public static final String PRIVATE_CONSTANT_1 = "PROBLEM_REPORT";

   @RBEntry("Change Request")
   @RBComment("The name of the object \"Change Request\".")
   public static final String PRIVATE_CONSTANT_2 = "CHANGE_REQUEST";

   @RBEntry("Change Notice")
   @RBComment("The name of the object \"Change Notice\".")
   public static final String PRIVATE_CONSTANT_3 = "CHANGE_NOTICE";

   /**
    * ##############################################################################
    *
    * Legacy Strings used by the local search tooltips
    * @deprecated
    *
    * ##############################################################################
    **/
   @RBEntry("Show problem report information page")
   @RBComment("Tooltip for the info page action.")
   public static final String PRIVATE_CONSTANT_4 = "CHANGE_ISSUE_INFO_PAGE_TT";

   @RBEntry("Show change notice information page")
   @RBComment("Tooltip for the info page action.")
   public static final String PRIVATE_CONSTANT_5 = "CHANGE_ORDER_INFO_PAGE_TT";

   @RBEntry("Show change request information page")
   @RBComment("Tooltip for the info page action.")
   public static final String PRIVATE_CONSTANT_6 = "CHANGE_REQUEST_INFO_PAGE_TT";

   @RBEntry("Show problem report information page")
   @RBComment("Tooltip for the info page action.")
   public static final String PRIVATE_CONSTANT_7 = "PR_DETAIL_TT";

   @RBEntry("Show change request information page")
   @RBComment("Tooltip for the info page action.")
   public static final String PRIVATE_CONSTANT_8 = "ECR_DETAIL_TT";

   @RBEntry("Show change notice information page")
   @RBComment("Tooltip for the info page action.")
   public static final String PRIVATE_CONSTANT_9 = "ECN_DETAIL_TT";

   @RBEntry("Show change proposal information page")
   @RBComment("Tooltip for the info page action.")
   public static final String PRIVATE_CONSTANT_10 = "CHANGE_PROPOSAL_INFO_TT";

   @RBEntry("Show task information page")
   @RBComment("Tooltip for the info page action.")
   public static final String PRIVATE_CONSTANT_11 = "CHANGE_ACTIVITY_INFO_TT";

   @RBEntry("Show change investigation information page")
   @RBComment("Tooltip for the info page action.")
   public static final String PRIVATE_CONSTANT_12 = "CHANGE_INVESTIGATION_INFO_TT";

   @RBEntry("Show analysis activity information page")
   @RBComment("Tooltip for the info page action.")
   public static final String PRIVATE_CONSTANT_13 = "ANALYSIS_ACTIVITY_INFO_TT";

   @RBEntry("Associate Changes")
   @RBComment("The Associated Problem Reports step in the wizard.")
   public static final String PRIVATE_CONSTANT_14 = "RELATED_CHANGES";

   /**
    * ##############################################################################
    *
    * Picker titles
    *
    * ##############################################################################
    **/
   @RBEntry("Find Associated Issues and Variances")
   @RBComment("The title for the action \"Add Associated Changes\"")
   public static final String FIND_ASSOCIATED_CHANGEISSUES = "FIND_ASSOCIATED_CHANGEISSUES";

   @RBEntry("Find Associated Change Requests")
   @RBComment("The title for the action \"Add Associated Changes\"")
   public static final String FIND_ASSOCIATED_CHANGEREQUESTS = "FIND_ASSOCIATED_CHANGEREQUESTS";

   @RBEntry("Find Associated Changes")
   @RBComment("The title for the action \"Add Associated Changes\"")
   public static final String FIND_ASSOCIATED_CHANGEITEMS = "FIND_ASSOCIATED_CHANGEITEMS";

   @RBEntry("Find Affected End Items")
   @RBComment("The title for the action \"Add Affected End Items\"")
   public static final String PRIVATE_CONSTANT_17 = "FIND_AFFECTED_END_ITEMS";

   @RBEntry("Find Affected Objects")
   @RBComment("The title for the action \"Add Affected Objects\"")
   public static final String PRIVATE_CONSTANT_18 = "FIND_AFFECTED_DATA";

   @RBEntry("Find Resulting Objects")
   @RBComment("The title for the action \"Add Resulting Objects\"")
   public static final String PRIVATE_CONSTANT_19 = "FIND_RESULTING_DATA";

   @RBEntry("Find Change Notices")
   @RBComment(" The title for the Change Notice Summary Report input page (from the Cognos reports page).")
   public static final String PRIVATE_CONSTANT_20 = "FIND_CHANGE_NOTICES";

   @RBEntry("Find Change Requests")
   @RBComment(" The title for the Change Request Summary Report input page (from the Cognos reports page).")
   public static final String PRIVATE_CONSTANT_21 = "FIND_CHANGE_REQUESTS";

   @RBEntry("Find Variances")
   @RBComment(" The title for the Variance Summary Report input page (from the Cognos reports page).")
   public static final String PRIVATE_CONSTANT_22 = "FIND_VARIANCES";

   @RBEntry("Find Problem Reports")
   @RBComment(" The title for the Problem Reports Summary Report input page (from the Cognos reports page).")
   public static final String PRIVATE_CONSTANT_23 = "FIND_PROBLEM_REPORTS";
   
   @RBEntry("Find Associated Remote Changes")
   @RBComment("The title for the action \"Add Associated Remote Changes\"")
   public static final String FIND_ASSOCIATED_REMOTE_CHANGES = "FIND_ASSOCIATED_REMOTE_CHANGES";

   /**
    * ##############################################################################
    *
    * Table titles
    *
    * ##############################################################################
    **/
   @RBEntry("Affected Objects")
   @RBComment("The Affected Items table title.")
   public static final String PRIVATE_CONSTANT_24 = "AFFECTED_ITEMS_TABLE";

   @RBEntry("Impacting Change Directives")
   @RBComment("The Impacting Directive table title.")
   public static final String PRIVATE_CONSTANT_25 = "IMPACTING_ITEMS_TABLE";

   @RBEntry("Change Actions")
   @RBComment("The Change Actions table.")
   public static final String PRIVATE_CONSTANT_26 = "CHANGE_ACTIONS_TABLE";

   @RBEntry("Resulting Objects")
   @RBComment("The Resulting Items table title.")
   public static final String PRIVATE_CONSTANT_27 = "RESULTING_ITEMS_TABLE";

   @RBEntry("Review Resulting Objects")
   @RBComment("The table title for the review resulting objects table on a review workflow task.")
   public static final String REVIEW_TASK_RESULTING_ITEMS_TABLE = "REVIEW_TASK_RESULTING_ITEMS_TABLE";

   @RBEntry("Complete Resulting Objects")
   @RBComment("The table title for the complete resulting objects table on a workflow task.")
   public static final String COMPLETE_TASK_RESULTING_ITEMS_TABLE = "COMPLETE_TASK_RESULTING_ITEMS_TABLE";

   @RBEntry("Affected Objects")
   @RBComment("The Affected Objects (change request, problem report, Variance) table title.")
   public static final String PRIVATE_CONSTANT_28 = "AFFECTED_DATA_TABLE";

   @RBEntry("Affected End Items")
   @RBComment("The Affected End Items table title.")
   public static final String PRIVATE_CONSTANT_29 = "AFFECTED_END_ITEMS_TABLE";

   @RBEntry("Change Summary")
   @RBComment("Affected and Resulting Data for all Change Tasks on a Change Notice")
   public static final String CHANGE_NOTICE_SUMMARY_TABLE = "CHANGE_NOTICE_SUMMARY_TABLE";

   @RBEntry("Audit Change Summary")
   @RBComment("The table title for the audit change summary table.")
   public static final String AUDIT_CHANGE_NOTICE_SUMMARY_TABLE = "AUDIT_CHANGE_NOTICE_SUMMARY_TABLE";

   @RBEntry("Associated Process Objects")
   @RBComment("The table title for the Related Problem Reports (as well as other issues) and Variances.")
   public static final String RELATED_CHANGEISSUES_TABLE = "RELATED_CHANGEISSUES_TABLE";

   @RBEntry("Associated Process Objects")
   @RBComment("The table title for the related change requests.")
   public static final String RELATED_CHANGEREQUESTS_TABLE = "RELATED_CHANGEREQUESTS_TABLE";

   @RBEntry("Associated Process Objects")
   @RBComment("The table title for the related change requests.")
   public static final String RELATED_FLEXIBLE_CHANGE_TABLE = "RELATED_FLEXIBLE_CHANGE_TABLE";

   @RBEntry("Associated Reference Objects")
   @RBComment("The table title for the related change requests.")
   public static final String RELATED_FLEXIBLE_CHANGE_REFERENCE_TABLE = "RELATED_FLEXIBLE_CHANGE_REFERENCE_TABLE";

   @RBEntry("Issues and Variances")
   @RBComment("The table title for the Related Problem Reports (and other issues) and Variances.")
   public static final String PRIVATE_CONSTANT_30 = "CHANGE_ISSUES_TABLE";

   @RBEntry("Change Requests")
   @RBComment("The plural name of the object \"Change Request\".")
   public static final String PRIVATE_CONSTANT_31 = "CHANGE_REQUESTS_TABLE";

   @RBEntry("Change Notices")
   @RBComment("The plural name of the object \"Change Notice\".")
   public static final String PRIVATE_CONSTANT_32 = "CHANGE_NOTICES_TABLE";

   @RBEntry("Affected by Change Notices")
   @RBComment("The table title for the Affected by Change Notices info page table")
   public static final String PRIVATE_CONSTANT_33 = "AFFECTED_BY_CHANGE_NOTICES_TABLE";

   @RBEntry("Resulting from Change Notices")
   @RBComment("The table title for the Resulting from Change Notices info page table")
   public static final String PRIVATE_CONSTANT_34 = "RESULTING_FROM_CHANGE_NOTICES_TABLE";

   @RBEntry("Annotation Sets")
   @RBComment("The table title for the Annotation Set table")
   public static final String PRIVATE_CONSTANT_35 = "ANNOTATION_SET_TABLE";

   @RBEntry("Attributes")
   @RBComment("The table title for the Variance Analysis attribute table.")
   public static final String VARIANCE_ANALYSIS_TABLE = "VARIANCE_ANALYSIS_TABLE";

   @RBEntry("Attributes")
   @RBComment("The table tile for the Attributes table from the information pages.")
   public static final String PRIVATE_CONSTANT_36 = "ATTRIBUTES_TABLE";

   @RBEntry("Unincorporated Changes")
   @RBComment("The table title for the Unincorporated changes table")
   public static final String PRIVATE_CONSTANT_37 = "UNINCORPORATED_CHANGE_TABLE";

   @RBEntry("Proposals and Investigations")
   @RBComment("The table title for the Change Proposals and Change Investigations")
   public static final String PRIVATE_CONSTANT_38 = "PROPOSALS_AND_INVESTIGATIONS_TABLE";

   @RBEntry("Analysis Activities")
   @RBComment("The table title for Analysis Activities")
   public static final String PRIVATE_CONSTANT_39 = "ANALYSIS_ACTIVITIES_TABLE";

   @RBEntry("Change Notice")
   @RBComment("The column name for the Change Notice Id")
   public static final String HC_CHANGENOTICE = "HC_CHANGENOTICE";

   @RBEntry("State")
   @RBComment("The column name for the Change Notice State")
   public static final String HC_CHANGENOTICE_STATE = "HC_CHANGENOTICE_STATE";

   @RBEntry("Change Task")
   @RBComment("The column name for the Change Task Id")
   public static final String HC_CHANGETASK = "HC_CHANGETASK";

   @RBEntry("Incorporation Plan")
   @RBComment("The column name for Incorporation Plan")
   public static final String HC_INCORPOPTION = "HC_INCORPOPTION";

   @RBEntry("Planned Revision")
   @RBComment("The column name for Planned Revision")
   public static final String HC_INCORPREVISION = "HC_INCORPREVISION";

   @RBEntry("Issues")
   @RBComment("The title for the All Open Issues table.")
   public static final String OPEN_ISSUES_TITLE = "OPEN_ISSUES_TITLE";

   @RBEntry("Change Requests")
   @RBComment("The title for the All Open Change Requests table.")
   public static final String OPEN_CHANGE_REQUESTS_TITLE = "OPEN_CHANGE_REQUESTS_TITLE";

   @RBEntry("Change Notices")
   @RBComment("The title for the All Open Change Notices table.")
   public static final String OPEN_CHANGE_NOTICES_TITLE = "OPEN_CHANGE_NOTICES_TITLE";

   @RBEntry("Variances")
   @RBComment("The title for the All Open Variances table.")
   public static final String OPEN_VARIANCES_TITLE = "OPEN_VARIANCES_TITLE";

   @RBEntry("One of the ways to create a problem report is to navigate to the information page of an object that can be changed, such as part or document, and select \"New Problem Report\" from the actions list.  For more information, see the online help available from the \"Problem Reports\" table.")
   @RBComment("Informational text to create problem reports.")
   public static final String OPEN_PROBLEM_REPORTS_HELP = "OPEN_PROBLEM_REPORTS_HELP";

   @RBEntry("One of the ways to create a change notice is to navigate to the change request information page and select \"New Change Notice\" from the actions list.  For more information, see the online help available from the \"Change Notices\" table.")
   @RBComment("Informational text to create change notices.")
   public static final String OPEN_CHANGE_NOTICES_HELP = "OPEN_CHANGE_NOTICES_HELP";

   @RBEntry("One of the ways to create a change request is to navigate to the information page of a problem report and select \"New Change Request\" from the actions list.  For more information, see the online help available from the \"Change Requests\" table.")
   @RBComment("Informational text to create requests notices.")
   public static final String OPEN_CHANGE_REQUESTS_HELP = "OPEN_CHANGE_REQUESTS_HELP";

   @RBEntry("One of the ways to create a variance is to navigate to the information page of an object that can be changed, such as part or document, and select New Variance from the actions list.  For more information, see the online help available from the Variances table.")
   @RBComment("Informational text to create variances.")
   public static final String OPEN_VARIANCES_HELP = "OPEN_VARIANCES_HELP";

   @RBEntry("Related Requirements")
   @RBComment("Title for the fulfill requirements table")
   public static final String PRIVATE_CONSTANT_40 = "FULFILL_CHANGEACTIONS_TABLE";

   @RBEntry("Change Baseline")
   @RBComment("Title for the Change Baseline report tree")
   public static final String CHANGE_BASELINE_TABLE = "CHANGE_BASELINE_TABLE";


   /**
    * ##############################################################################
    *
    * Table views
    *
    * ##############################################################################
    */

   @RBEntry("Problem Reports")
   public static final String PROBLEM_REPORT_TABLEVIEW_NAME = "PROBLEM_REPORT_TABLEVIEW_NAME";

   @RBEntry("View showing only Problem Reports.")
   public static final String PROBLEM_REPORT_TABLEVIEW_DESCRIPTION = "PROBLEM_REPORT_TABLEVIEW_DESCRIPTION";

   @RBEntry("Variances")
   public static final String VARIANCE_TABLEVIEW_NAME = "VARIANCE_TABLEVIEW_NAME";

   @RBEntry("View showing only Variances.")
   public static final String VARIANCE_TABLEVIEW_DESCRIPTION = "VARIANCE_TABLEVIEW_DESCRIPTION";

   @RBEntry("Change Intent")
   public static final String CHANGE_INTENT = "CHANGE_INTENT";

   @RBEntry("Release Content")
   public static final String RELEASE_CONTENT = "RELEASE_CONTENT";

   @RBEntry("Affected Parts")
   public static final String AFFECTED_PARTS = "AFFECTED_PARTS";

   @RBEntry("Default")
   @RBComment("The default table view name for the Change Baseline report")
   public static final String CHANGE_BASELINE_REPORT_TABLE_VIEW_DEFAULT_NAME = "CHANGE_BASELINE_REPORT_TABLE_VIEW_DEFAULT_NAME";

   @RBEntry("Default View")
   @RBComment("The default table view description for the Change Baseline report")
   public static final String CHANGE_BASELINE_REPORT_TABLE_VIEW_DEFAULT_DESC = "CHANGE_BASELINE_REPORT_TABLE_VIEW_DEFAULT_DESC";

   /**
    * ##############################################################################
    *
    * Table columns specific to change
    *
    * ##############################################################################
    **/
   @RBEntry("On Order")
   @RBComment("The label for the disposition column.")
   public static final String ONORDERDISPOSITION = "ONORDERDISPOSITION";

   @RBEntry("Work-in-Process")
   @RBComment("The label for the disposition column.")
   public static final String INVENTORYDISPOSITION = "INVENTORYDISPOSITION";

   @RBEntry("Finished")
   @RBComment("The label for the disposition column.")
   public static final String FINISHEDDISPOSITION = "FINISHEDDISPOSITION";

   @RBEntry("Disposition Comments")
   @RBComment("The label for the disposition comment column.")
   public static final String DISPOSITIONCOMMENTS = "DISPOSITIONCOMMENTS";

   @RBEntry("Approved Quantity")
   @RBComment("The label for Approved Quantity column.")
   public static final String APPROVEDQUANTITY = "APPROVEDQUANTITY";

   @RBEntry("Comments")
   @RBComment("Label to be used in the Table Views")
   public static final String CHANGE_LINK_DESCRIPTION = "CHANGE_LINK_DESCRIPTION";

   @RBEntry("Table Parameters")
   @RBComment("Label used in the table views. This column is a hidden parameter column.")
   public static final String CHANGE_TABLE_DATA_COLUMN = "CHANGE_TABLE_DATA_COLUMN";

   @RBEntry("Unincorporated Change")
   @RBComment("Label used in the table views. This column is a hidden parameter column.")
   public static final String INCORP_HANGINGCHANGE_TABLE_DATA_COLUMN = "INCORP_HANGINGCHANGE_TABLE_DATA_COLUMN";

   @RBEntry("Impacting Objects")
   @RBComment("This column is used to filter the display of affected and resulting objects. This column is only displayed on the filter step of the table view wizard.")
   public static final String IMPACTING_OBJECTS_COLUMN = "IMPACTING_OBJECTS_COLUMN";

   @RBEntry("Relationship")
   @RBComment("This column is used to display the link relation ship of the affected or resulting objects.")
   public static final String RELATIONSHIP = "RELATIONSHIP";

   @RBEntry("Task Name")
   @RBComment("This column is to display the name of the change task on a affected or resulting link.")
   public static final String TASK_NAME_COLUMN = "TASK_NAME_COLUMN";

   @RBEntry("Task Number")
   @RBComment("This column is to display the number of the change task on a affected or resulting link.")
   public static final String TASK_NUMBER_COLUMN = "TASK_NUMBER_COLUMN";

   @RBEntry("Task State")
   @RBComment("This column is to display the state of the change task on a affected or resulting link.")
   public static final String TASK_STATE_COLUMN = "TASK_STATE_COLUMN";

   @RBEntry("Affected Status")
   @RBComment("This column is to indicate if the Affected Status is shown for any item which is added as a resulting object or unincorporated change on a change task but does not have a corresponding equal or predecessor revision as an affected object.")
   public static final String AFFECTED_STATUS = "AFFECTED_STATUS";

   @RBEntry("No affected object")
   @RBComment("A message is to indicate if the Affected Status is shown for any item which is added as a resulting object or unincorporated change on a change task but does not have a corresponding equal or predecessor revision as an affected object.")
   public static final String AFFECTED_STATUS_MSG = "AFFECTED_STATUS_MSG";

   @RBEntry("Target State")
   @RBComment("This column is to indicate if the Change target state of the change task resulting objects.")
   public static final String CHANGE_TARGET_STATE = "CHANGE_TARGET_STATE";

   @RBEntry("New Version")
   @RBComment("This column is to indicate if the new version of the successor object in the Change Baseline report table.")
   public static final String NEW_VERSION = "NEW_VERSION";

   @RBEntry("Planned Authorization")
   @RBComment("This column is to indicate if the planned authorization of the successor object in the Change Baseline report table.")
   public static final String PLANNED_AUTHORIZATION = "PLANNED_AUTHORIZATION";

   @RBEntry("Action")
   @RBComment("This column is to indicate if the action of the successor object in the Change Baseline report table.")
   public static final String PLANNED_ACTION = "PLANNED_ACTION";

   @RBEntry("Release Target")
   @RBComment("This column is to indicate the change management transition for the resulting object.")
   public static final String CHANGE_TARGET_TRANSITION = "CHANGE_TARGET_TRANSITION";

   @RBEntry("Open Task Assignees")
   @RBComment("Set of columns intended to show the users that have open workflow tasks on a change task")
   public static final String CHANGE_TASK_ASSIGNEES = "CHANGE_TASK_ASSIGNEES";

   @RBEntry("Identity")
   @RBComment("This column is to display the attributes that uniquely identify an object.")
   public static final String IDENTITY_COLUMN_NAME = "IDENTITY_COLUMN_NAME";
   
   /**
    * ##############################################################################
    *
    * The action types for the Successor objects in the Change Baseline report
    *
    * ##############################################################################
    */

    @RBEntry("Add")
    @RBComment("Indicates that the object was added.")
    public static final String PLANNED_ACTION_TYPE_ADD = "PLANNED_ACTION_TYPE_ADD";

    @RBEntry("Delete")
    @RBComment("Indicates that object was removed was removed.")
    public static final String PLANNED_ACTION_TYPE_REMOVE = "PLANNED_ACTION_TYPE_REMOVE";

    @RBEntry("Revise")
    @RBComment("Indicates that the successor object was revised.")
    public static final String PLANNED_ACTION_TYPE_REVISE = "PLANNED_ACTION_TYPE_REVISE";

   /**
    * ##############################################################################
    *
    * labels for impacting objects
    *
    * ##############################################################################
    **/

   @RBEntry("Affected Objects")
   @RBComment("This label is used to filter affected objects.")
   public static final String SHOW_AFFECTED_OBJECTS = "SHOW_AFFECTED_OBJECTS";

   @RBEntry("Resulting Objects")
   @RBComment("This label is used to filter resulting objects.")
   public static final String SHOW_RESULTING_OBJECTS = "SHOW_RESULTING_OBJECTS";

   @RBEntry("Affected/Resulting Objects")
   @RBComment("This label is used to filter affected and resulting objects.")
   public static final String SHOW_AFFECTED_RESULTING_OBJECTS = "SHOW_AFFECTED_RESULTING_OBJECTS";


   /**
    * ##############################################################################
    *
    * labels specific to annotation
    *
    * ##############################################################################
    **/
   @RBEntry("Affected Object")
   @RBComment("Affected data label.")
   public static final String PRIVATE_CONSTANT_41 = "AFFECTED_DATA_LABEL";

   @RBEntry("Annotation Sets")
   @RBComment("The label for related affected data column.")
   public static final String ANNOTATION_SET_LABEL = "ANNOTATION_SET_LABEL";

   @RBEntry("Annotation Set List")
   @RBComment("The label for related affected data column.")
   public static final String PRIVATE_CONSTANT_42 = "ANNOTATION_SET_LIST_LABEL";

   /**
    * #######################################################
    *
    * Owning Change Object
    *
    * #######################################################
    **/
   @RBEntry("Change Notice")
   @RBComment("Label for the Owning Change Notice")
   public static final String OWNING_CHANGE_NOTICE = "OWNING_CHANGE_NOTICE";

   @RBEntry("Change Notice Name")
   @RBComment("Label for the Owning Change Notice Name")
   public static final String OWNING_CHANGE_NOTICE_NAME = "OWNING_CHANGE_NOTICE_NAME";

   @RBEntry("Change Request")
   @RBComment("Label for the Owning Change Request")
   public static final String OWNING_CHANGE_REQUEST = "OWNING_CHANGE_REQUEST";

   @RBEntry("Change Request Name")
   @RBComment("Label for the Owning Change Request Name")
   public static final String OWNING_CHANGE_REQUEST_NAME = "OWNING_CHANGE_REQUEST_NAME";

   @RBEntry("Change Proposal")
   @RBComment("Label for the Owning Change Proposal")
   public static final String OWNING_CHANGE_PROPOSAL = "OWNING_CHANGE_PROPOSAL";

   @RBEntry("Change Proposal Name")
   @RBComment("Label for the Owning Change Proposal Name")
   public static final String OWNING_CHANGE_PROPOSAL_NAME = "OWNING_CHANGE_PROPOSAL_NAME";

   @RBEntry("Change Investigation")
   @RBComment("Label for the Owning Change Investigation")
   public static final String OWNING_CHANGE_INVESTIGATION = "OWNING_CHANGE_INVESTIGATION";

   @RBEntry("Change Investigation Name")
   @RBComment("Label for the Owning Change Investigation Name")
   public static final String OWNING_CHANGE_INVESTIGATION_NAME = "OWNING_CHANGE_INVESTIGATION_NAME";

   @RBEntry("Change Object")
   @RBComment("Label for the Owning Change Object")
   public static final String OWNING_CHANGE_OBJECT = "OWNING_CHANGE_OBJECT";

   @RBEntry("Change Object Name")
   @RBComment("Label for the Owning Change Object Name")
   public static final String OWNING_CHANGE_OBJECT_NAME = "OWNING_CHANGE_OBJECT_NAME";

   @RBEntry("(Unavailable)")
   @RBComment("Label for an object that is unavailable")
   public static final String UNAVAILABLE = "UNAVAILABLE";

   /**
    * #######################################################
    *
    * Implementation Plan Table
    *
    * #######################################################
    **/
   @RBEntry("Implementation Plan")
   @RBComment("The title of the Implementaiton Plan")
   public static final String IMPLEMENTATION_PLAN_TABLE = "IMPLEMENTATION_PLAN_TABLE";

   @RBEntry("Edit Icon")
   @RBComment("Selectable Column name")
   public static final String IMPLEMENTATION_PLAN_TABLE_ICON_ACTIONS = "IMPLEMENTATION_PLAN_TABLE_ICON_ACTIONS";

   @RBEntry("Revision")
   @RBComment("Revision Column name")
   public static final String IMPLEMENTATION_PLAN_TABLE_REVISION = "IMPLEMENTATION_PLAN_TABLE_REVISION";

   @RBEntry("Number")
   @RBComment("Number Column name")
   public static final String IMPLEMENTATION_PLAN_TABLE_NUMBER = "IMPLEMENTATION_PLAN_TABLE_NUMBER";

   @RBEntry("Name")
   @RBComment("Name Column name")
   public static final String IMPLEMENTATION_PLAN_TABLE_NAME = "IMPLEMENTATION_PLAN_TABLE_NAME";

   @RBEntry("State")
   @RBComment("State Column name")
   public static final String IMPLEMENTATION_PLAN_TABLE_STATE = "IMPLEMENTATION_PLAN_TABLE_STATE";

   @RBEntry("Assignee")
   @RBComment("Assignee Column name")
   public static final String IMPLEMENTATION_PLAN_TABLE_LAST_ROLE_ASSIGNEE = "IMPLEMENTATION_PLAN_TABLE_LAST_ROLE_ASSIGNEE";

   @RBEntry("Reviewer")
   @RBComment("Reviewer Column name")
   public static final String IMPLEMENTATION_PLAN_TABLE_LAST_ROLE_REVIEWER = "IMPLEMENTATION_PLAN_TABLE_LAST_ROLE_REVIEWER";

   @RBEntry("Need Date")
   @RBComment("Need DateColumn name")
   public static final String IMPLEMENTATION_PLAN_TABLE_NEED_DATE = "IMPLEMENTATION_PLAN_TABLE_NEED_DATE";

   @RBEntry("Sequence")
   @RBComment("Change task sequence column name")
   public static final String IMPLEMENTATION_PLAN_TABLE_SEQUENCE = "IMPLEMENTATION_PLAN_TABLE_SEQUENCE";

   @RBEntry("Implementation Status")
   @RBComment("Label for Implementation Status column in the implementation plan table")
   public static final String IMPLEMENTATION_PLAN_TABLE_STATUS = "IMPLEMENTATION_PLAN_TABLE_STATUS";

   /**
    * Added to resolve compile issue
    **/
   @RBEntry("Implementation Plan")
   @RBComment("Change Notice table header.")
   public static final String CHANGE_NOTICE_TABLE_HEADER = "CHANGE_NOTICE_TABLE_HEADER";

   /**
    * ########################################################
    *
    * Revise Client Strings (ChangeItem Reissue Dialog)
    *
    * ########################################################
    **/
   @RBEntry("Impact")
   @RBComment("The impact of the revise.  Either Modify of Proceed")
   public static final String REVISE_IMPACT = "REVISE_IMPACT";

   @RBEntry("New Revision")
   @RBComment("The label for the new revision")
   public static final String NEW_REVISION = "NEW_REVISION";

   @RBEntry("An error occurred revising the change object.")
   @RBComment("The message header (ATTENTION:) is already added.")
   public static final String REVISE_ERROR_HEADER = "REVISE_ERROR";

   @RBEntry("Change Object")
   @RBComment("The label for the change item Identity")
   public static final String CHANGE_ITEM_IDENTITY = "CHANGE_ITEM_IDENTITY";

   /**
    * #########################################################
    *
    * Change Status Column Strings
    *
    * #########################################################
    **/
   @RBEntry("Change Status")
   @RBComment("The column header for the change status column.")
   public static final String CHANGE_STATUS_COLUMN = "statusFamily_Change";

   /**
    * #########################################################
    *
    * Specialized Attribute handling messages.
    *
    * #########################################################
    **/
   @RBEntry("You did not specify a valid Variance Owner.")
   @RBComment("The message when the user picked a user but this uid is not valid in the system.")
   public static final String VARIANCEOWNER_NOTFOUND = "VarianceOwner_NotFound";

   @RBEntry("The variance cannot be created.")
   public static final String VARIANCE_CREATE_CANNOTCREATE = "Variance_Create_CanNotCreate";

   @RBEntry("Clear Existing Disposition Comments")
   @RBComment("Text display value for the check box to clear disposition comments.")
   public static final String CLEAR_DISPOSITION_COMMENTS = "CLEAR_DISPOSITION_COMMENTS";

   /**
    * #########################################################
    *
    * Propagation Message Strings
    *
    * #########################################################
    **/
   @RBEntry("Propagate information")
   @RBComment("Option label to indicate propagation of meta-data, attachments, etc. from a Change Object")
   public static final String PROPAGATE_DATA_FROM_CHANGE_LABEL = "PROPAGATE_DATA_FROM_CHANGE_LABEL";

   /**
    * #########################################################
    *
    * Wizard Error messages.
    *
    * #########################################################
    **/
   @RBEntry("Unable to successfully process the Affected Objects.")
   public static final String AFFECTED_ITEMS_PROCESSING_ERROR = "AffectedItems_Processing_Error";

   @RBEntry("Could not process Affected Objects.")
   public static final String AFFECTED_ITEMS_PROCESSING_ERRORHEADER = "AffectedItems_Processing_ErrorHeader";

   @RBEntry("Unable to successfully process the Affected End Items.")
   public static final String AFFECTED_END_ITEMS_PROCESSING_ERROR = "AffectedEndItems_Processing_Error";

   @RBEntry("Could not process Affected End Items.")
   public static final String AFFECTED_END_ITEMS_PROCESSING_ERRORHEADER = "AffectedEndItems_Processing_ErrorHeader";

   @RBEntry("Unable to successfully process the Resulting Objects.")
   public static final String RESULTING_ITEMS_PROCESSING_ERROR = "ResultingItems_Processing_Error";

   @RBEntry("Could not process Resulting Objects.")
   public static final String RESULTING_ITEMS_PROCESSING_ERRORHEADER = "ResultingItems_Processing_ErrorHeader";

   @RBEntry("A error occured creating the new one-off versions. Contact your Administrator.")
   public static final String NEWONEOFFVERISON_ACTION_CANNOT_CREATE = "NewOneOffVersion_Action_CannotCreate";

   @RBEntry("<b>ATTENTION</b>: Creation of the new one-off versions failed.")
   @RBComment("The <b> tags are added to bold the attention as per UI message design.  This is using a Ext dialog which supports Bold tags.")
   public static final String NEWONEOFFVERSION_ACTION_HEADER_MSG = "NewOneOffVersion_Action_HeaderMsg";

   @RBEntry("Number of objects invalid: {0}\n\nFirst reported messsage is:\n{1}")
   public static final String NEWONEOFFVERSION_ACTION_TOOMANYERRORS = "NewOneOffVersion_Action_TooManyErrors";

   @RBEntry("ATTENTION: Unable to set disposition.")
   @RBComment("Header message for the diposition dialog.")
   public static final String SETDISPOSITION_ACTION_HEADER_MSG = "SetDisposition_Action_HeaderMsg";

   @RBEntry("None of the objects selected are eligible for this operation.")
   @RBComment("Message when the action is launched and the objects are not applicable.")
   public static final String INVALIDOBJECTS = "InvalidObjects";

   @RBEntry("Proposed Solution")
   public static final String PRIVATE_CONSTANT_43 = "CHANGE_PROPOSEDCHANGES";

   @RBEntry("Please contact your administrator.")
   public static final String CHANGEMANAGEMENT_PROCESSING_ERRORMSG = "ChangeManagement_Processing_ErrorMsg";

   @RBEntry("Unable to create the Problem Report.")
   public static final String CREATEPROBLEMREPORT_PROCESSING_ERROR = "CreateProblemReport_Processing_Error";

   @RBEntry("Unable to create the Variance.")
   public static final String CREATEVARIANCE_PROCESSING_ERROR = "CreateVariance_Processing_Error";

   @RBEntry("Unable to create the Change Request.")
   public static final String CREATECHANGEREQUEST_PROCESSING_ERROR = "CreateChangeRequest_Processing_Error";

   @RBEntry("Unable to create the Change Notice Template.")
   public static final String CREATECHANGENOTICETEMPLATE_PROCESSING_ERROR = "CreateChangeNoticeTemplate_Processing_Error";

   @RBEntry("Unable to create the Change Task Template.")
   public static final String CREATECHANGETASKTEMPLATE_PROCESSING_ERROR = "CreateChangeTaskTemplate_Processing_Error";

   @RBEntry("Unable to create the Change Notice.")
   public static final String CREATECHANGENOTICE_PROCESSING_ERROR = "CreateChangeNotice_Processing_Error";

   @RBEntry("A non-fatal error occured creating the Change Notice.")
   public static final String CreateChangeNotice_ImpactMatrix_ErrorHeader = "CreateChangeNotice_ImpactMatrix_ErrorHeader";

   @RBEntry("The Change Impact Matrix was unable to be associated to this Change Notice.  Please contact your administrator for more information.")
   public static final String CreateChangeNotice_ImpactMatrix_Error = "CreateChangeNotice_ImpactMatrix_Error";

   @RBEntry("Unable to create the Change Task.")
   public static final String CREATECHANGETASK_PROCESSING_ERROR = "CreateChangeTask_Processing_Error";

   @RBEntry("Unable to create the Change Proposal.")
   public static final String CREATECHANGEPROPOSAL_PROCESSING_ERROR = "CreateChangeProposal_Processing_Error";

   @RBEntry("Unable to edit the Problem Report.")
   public static final String EDITPROBLEMREPORT_PROCESSING_ERROR = "EditProblemReport_Processing_Error";

   @RBEntry("Unable to edit the Variance.")
   public static final String EDITVARIANCE_PROCESSING_ERROR = "EditVariance_Processing_Error";

   @RBEntry("Unable to edit the Change Request.")
   public static final String EDITCHANGEREQUEST_PROCESSING_ERROR = "EditChangeRequest_Processing_Error";

   @RBEntry("Unable to edit the Change Notice.")
   public static final String EDITCHANGENOTICE_PROCESSING_ERROR = "EditChangeNotice_Processing_Error";

   @RBEntry("Unable to edit the Change Notice Template.")
   public static final String EDITCHANGENOTICETEMPLATE_PROCESSING_ERROR = "EditChangeNoticeTemplate_Processing_Error";

   @RBEntry("Unable to set default on the Change Template.\n\n {0}")
   @RBComment("Error message for setting the defaults on Change Templates.")
   public static final String SET_DEFAULT_CHANGETEMPLATE_PROCESSING_ERROR = "SET_DEFAULT_CHANGETEMPLATE_PROCESSING_ERROR";

   @RBEntry("Unable to edit the Change Task.")
   public static final String EDITCHANGETASK_PROCESSING_ERROR = "EditChangeTask_Processing_Error";

   @RBEntry("Unable to edit the Change Task Template.")
   public static final String EDITCHANGETASKTEMPLATE_PROCESSING_ERROR = "EditChangeTaskTemplate_Processing_Error";

   @RBEntry("Unable to edit the Change Proposal.")
   public static final String EDITCHANGEPROPOSAL_PROCESSING_ERROR = "EditChangeProposal_Processing_Error";

   @RBEntry("Unable to delete the Change Task.")
   public static final String DELETECHANGETASK_PROCESSING_ERROR = "DeleteChangeTask_Processing_Error";

   @RBEntry("Unable to create a change plan.")
   public static final String CREATE_CHANGE_PLAN_ERROR = "CREATE_CHANGE_PLAN_ERROR";

   @RBEntry("ATTENTION: Required Information is Missing.\n\nAt least one change task is required. Please create a new change task to continue.")
   public static final String IMPLEMENTATION_TABLE_NO_TASKS = "Implementation_Table_No_Tasks";

   @RBEntry("ATTENTION: Something bad happened.\n\nUnable to find implementation plan table")
   public static final String UNABLE_TO_FIND_IMPL_TABLE = "Unable_To_Find_Impl_Table";

   @RBEntry("ATTENTION: Change request is required.\n\nIt is required that at least one change request be associated to the change notice.")
   @RBComment("Message displayed when a Change Notice needs to have associated Change Request but it is missing")
   public static final String CHANGENOTICE_VALIDATE_ASSOCIATED_CR = "CHANGENOTICE_VALIDATE_ASSOCIATED_CR";

   @RBEntry("Attention: Action Unavailable\n\nA new change notice requires a change task.\nYou do not have permission to create a change task.")
   @RBComment("Error message for the Create Change Notice wizard when the user does not have access to create any Change Task types.")
   public static final String CREATECHANGENOTICE_NO_TASK_TYPES = "CreateChangeNotice_No_Task_Types";

   @RBEntry("There is no existing definition for {0} in the third party reporting system.")
   public static final String THIRDPARTYREPORTING_NODEFEXISTS_ERROR = "ThirdPartyReporting_NoDefExists_Error";

   @RBEntry("There is no such report: {0}")
   public static final String REPORT_NOTEXISTS_ERROR = "Report_NotExists_Error";

   @RBEntry("There is no report for object type: {0}")
   public static final String REPORT_NOTSUPPORTED_ERROR = "Report_NotSupported_Error";

   @RBEntry("Invalid relationship for {0}.")
   @RBComment("Message for validationg the association of an object for an AssociationConstrainable link when peforming a client action.")
   public static final String INVALID_ROLE_B_TYPE = "INVALID_ROLE_B_TYPE";

   @RBEntry("ATTENTION: Required Information is Missing \n\nNumber is required on the change task. Edit the change task to include a number.")
   public static final String CHANGE_TASK_NUMBER_REQUIRED = "CHANGE_TASK_NUMBER_REQUIRED";

   @RBEntry("You do not have create permission for the selected context.")
   @RBComment("Error message for the change create wizard context step.")
   public static final String NO_CREATE_FOR_CONTEXT = "NO_CREATE_FOR_CONTEXT";

   @RBEntry("Attention: Unable to create change notice.\n\nYou do not have permission to create one or more change task types in the selected change notice template.")
   @RBComment("Error message for the Create Change Notice wizard when the user does not have access to create the Change Task types in the selected change notice template.")
   public static final String CREATE_CHANGE_NOTICE_FROM_TEMPLATE_NO_TASK_TYPES = "CREATE_CHANGE_NOTICE_FROM_TEMPLATE_NO_TASK_TYPES";

   @RBEntry("Unable to create associations for this object. The associated rule may have been deleted or disabled. \n\nPlease contact your administrator.")
   @RBComment("Error message for add associated change action.")
   public static final String NO_ASSOCIATIONS_FOR_OBJECT = "NO_ASSOCIATIONS_FOR_OBJECT";
   
   @RBEntry("Unable to create remote associations for this object. The remote associated rule may have been deleted or disabled. \n\nPlease contact your administrator.")
   @RBComment("Error message for add associated remote change action.")
   public static final String NO_REMOTE_ASSOCIATIONS_FOR_OBJECT = "NO_REMOTE_ASSOCIATIONS_FOR_OBJECT";

   @RBEntry("Table not configured correctly for table ID:{0}.")
   @RBComment("Error message for associated changes tables.")
   @RBArgComment0("Generated table id.")
   public static final String ASSOCIATED_CHANGES_TABLE_CONFIG_ERROR = "ASSOCIATED_CHANGES_TABLE_CONFIG_ERROR";
   
   @RBEntry("A change task needs to be selected")
   @RBComment("Error message for adding objects to resulting objects table on a change task.")
   public static final String NO_CHANGE_TASK_SELECTED_ERROR = "NO_CHANGE_TASK_SELECTED_ERROR";

   /**
    * ##############################################################################
    *
    * Change Management specific workflow strings
    *
    * ##############################################################################
    **/
   @RBEntry("Automatically create change notice")
   @RBComment("Label for the Automate the fast-track checkbox")
   public static final String AUTOMATE_FASTTRACK = "AUTOMATE_FASTTRACK";

   @RBEntry("ATTENTION: Required field(s) not entered.\n\nThe Assignee and Reviewer Fields are required but not specified. Use the \"Find...\" button to select a valid user.")
   public static final String CHANGETASK_VALIDATE_USER = "CHANGETASK_VALIDATE_USER";

   @RBEntry("CONFIRMATION: Delete Change Task \n\nAre you sure you want to delete the selected change task?")
   @RBComment("Message displayed to ask user whether they are sure they wish to delete change tasks")
   public static final String CONFIRM_DELETE_CHANGE_TASK = "CONFIRM_DELETE_CHANGE_TASK";

   @RBEntry("Attention: Unable to continue edit.\n\nThis object has been updated by another user, and the wizard must be refreshed.  Changes made during this edit session will be lost.")
   @RBComment("Message displayed when the system detects a change is made.")
   public static final String CONFIRM_UPDATE_CHANGEITEM = "CONFIRM_UPDATE_CHANGEITEM";

   @RBEntry("The release of this change notice cannot occur because the following resulting objects are checked out:")
   @RBComment("Special Instructions that appear in the \"Resolve Change Notice Conflicts\" Change Notice workflow task.  It is followed by a list of objects that are checked out.")
   public static final String PRERELEASE_VALIDATION_MSG = "PRERELEASE_VALIDATION_MSG";

   @RBEntry("The release of this change notice cannot occur because the following business rules failed:")
   @RBComment("Special Instructions that appear in the \"Resolve Change Notice Conflicts\" Change Notice workflow task.  It is followed by a list of business rules that failed.")
   public static final String BUSINESS_RULES_PRERELEASE_VALIDATION_MSG = "BUSINESS_RULES_PRERELEASE_VALIDATION_MSG";

   @RBEntry("CONFIRMATION: Are you sure you want to navigate to another page of this table?   If so, any data entered on the current page of the table will be lost.")
   @RBComment("Message displayed to ask user whether they are sure they wish to go to next page in a change table")
   public static final String CONFIRM_PAGING_CHANGE_TABLES = "CONFIRM_PAGING_CHANGE_TABLES";

   @RBEntry("The release of this change notice cannot occur because the following change tasks are not ready for implementation:")
   @RBComment("Special Instructions that appear in the \"Assignee or Reviewer Conflicts\" Change Notice workflow task.  It is followed by a list of change tasks that are not ready for implementation.")
   public static final String IMPLEMENTATION_VALIDATION_MSG = "IMPLEMENTATION_VALIDATION_MSG";

   @RBEntry("Collect action failed")
   @RBComment("Message for when none of the objects collected are valid for the table.")
   public static final String COLLECTED_FAILED = "COLLECTED_FAILED";

   @RBEntry("All of the collected objects cannot be added into this location.")
   @RBComment("Detailed message for when none of the objects collected are valid for the table.")
   public static final String COLLECTED_FAILED_MSG = "COLLECTED_FAILED_MSG";

   @RBEntry("Collect action partially failed")
   @RBComment("Message for when some of the objects collected are not valid for the table.")
   public static final String COLLECTED_PARTIALLY_FAILED = "COLLECTED_PARTIALLY_FAILED";

   @RBEntry("Some of the collected objects cannot be added into this location:")
   @RBComment("Detailed message for when some of the objects collected are not valid for the table.")
   public static final String COLLECTED_PARTIALLY_FAILED_MSG = "COLLECTED_PARTIALLY_FAILED_MSG";

   @RBEntry("Adding revised objects failed")
   @RBComment("Message for when the revise is successful but none of the objects revised are valid for the table.")
   public static final String REVISE_FAILED = "REVISE_FAILED";

   @RBEntry("The objects were revised but cannot be added to this location.")
   @RBComment("Detailed message for when the revise is successful but none of the objects revised are valid for the table.")
   public static final String REVISE_FAILED_MSG = "REVISE_FAILED_MSG";

   @RBEntry("Adding revised object partially failed")
   @RBComment("Message for when the revise is successful but some of the objects revised are invalid for the table.")
   public static final String REVISE_PARTIALLY_FAILED = "REVISE_PARTIALLY_FAILED";

   @RBEntry("The objects were revised, but some of them cannot be added to this location:")
   @RBComment("Detailed message for when the revise is successful but some of the objects revised are invalid for the table.")
   public static final String REVISE_PARTIALLY_FAILED_MSG = "REVISE_PARTIALLY_FAILED_MSG";

   @RBEntry("No common release targets found")
   @RBComment("Message for when no common release targets are found when launching the release target table action.")
   public static final String NO_COMMON_RELEASE_TARGETS = "NO_COMMON_RELEASE_TARGETS";
   
   @RBEntry("Unable to enable the template")
   @RBComment("Setting the enabled attribute to true on the change object template failed.")
   public static final String UNABLE_TO_SET_TEMPLATE_ENABLED = "UNABLE_TO_SET_TEMPLATE_ENABLED";
   
   @RBEntry("Unable to disable the template")
   @RBComment("Setting the enabled attribute to false on the change object template failed.")
   public static final String UNABLE_TO_SET_TEMPLATE_DISABLED = "UNABLE_TO_SET_TEMPLATE_DISABLED";
   
   /**
    * ##############################################################################
    *
    * Submit Now / Submit Later messages
    *
    * ##############################################################################
    **/
   @RBEntry("<br><b>CONFIRMATION</b>: Submit the change object now?<br><br>Click \"Submit Now\" to submit the change object now.<br>Click \"Submit Later\" to submit the change object at another time.")
   @RBComment("The string displayed to a user when they attempt to submit a change object where Submit Now is enabled.  The <br> and <b> tags are needed because this text is dumped directly into HTML content at runtime.  There are three distinct sentences.  the first is the header message.  The remaining two are the instructions.")
   public static final String SUBMIT_NOW_MESSAGE = "SUBMIT_NOW_MESSAGE";

   @RBEntry("Submit Now")
   @RBComment("Label for the JS Dojo button.  Equivalent of the \"Ok\" on a confirmation dialog.  See SUBMIT_NOW_MESSAGE above for context text.")
   public static final String SUBMIT_NOW_BUTTON = "SUBMIT_NOW_BUTTON";

   @RBEntry("Submit Later")
   @RBComment("Label for the JS Dojo button.  Equivalent of the \"Cancel\" on a confirmation dialog.  See SUBMIT_NOW_MESSAGE above for context text.")
   public static final String SUBMIT_LATER_BUTTON = "SUBMIT_LATER_BUTTON";

   /**
    * ##############################################################################
    *
    * Change object attributes to support proper localization in client
    *
    * ##############################################################################
    **/
   @RBEntry("Complexity")
   public static final String PRIVATE_CONSTANT_44 = "WTChangeOrder2.theChangeNoticeComplexity";

   @RBEntry("Category")
   public static final String THE_VARIANCE_CATEGORY = "WTVariance.theVarianceCategory";

   @RBEntry("<U class='mnemonic'>R</U>elated Objects")
   @RBComment("Used for the text on the Related Objects third level nav menu.  The <U class=mnemonic> </U> tag should be put around the character that is the access key.")
   public static final String PRIVATE_CONSTANT_45 = "object.relatedDirItems.description";

   @RBEntry("r")
   @RBPseudo(false)
   @RBComment("Mnemonic for the Related Objects third level nav menu. This should be a character that matches the character surrounded by the <U class=mnemonic> </U> tag in the value line above.")
   public static final String PRIVATE_CONSTANT_46 = "object.relatedDirItems.hotkey";

   @RBEntry("<U class='mnemonic'>R</U>elated Directives")
   @RBComment("Used for the text on the Related Objects third level nav menu.  The <U class=mnemonic> </U> tag should be put around the character that is the access key.")
   public static final String PRIVATE_CONSTANT_49 = "object.relatedPartItems.description";

   @RBEntry("r")
   @RBPseudo(false)
   @RBComment("Mnemonic for the Related Objects third level nav menu. This should be a character that matches the character surrounded by the <U class=mnemonic> </U> tag in the value line above.")
   public static final String PRIVATE_CONSTANT_50 = "object.relatedPartItems.hotkey";

   @RBEntry("No review required")
   @RBComment("Label for the Change Task no review required check box.")
   public static final String NO_REVIEW_REQUIRED = "NO_REVIEW_REQUIRED";

   @RBEntry("Not Required")
   @RBComment("Label for the Change Task reviewer role when no review is required")
   public static final String ROLE_NOT_REQUIRED = "ROLE_NOT_REQUIRED";

   /**
    * ##############################################################################
    * Location field for Change Directive, Change Action
    * ##############################################################################
    **/
   @RBEntry("Location")
   @RBComment("Label for the Location")
   public static final String LOCATION_LABEL = "LOCATION";

   @RBEntry("Change Directive")
   @RBComment("Label for the Change Directive")
   public static final String CHANGE_DIRECTIVE = "CHANGE_DIRECTIVE";

   @RBEntry("Configuration Item")
   @RBComment("Label for the Configuration Item")
   public static final String CONFIGURATION_ITEM = "CONFIGURATION_ITEM";

   @RBEntry("Impacting Change Directives")
   @RBComment("The table title for the Change Directives")
   public static final String CHANGE_DIRECTIVES_TABLE = "CHANGE_DIRECTIVES_TABLE";

   @RBEntry("Related Change Actions")
   @RBComment("Label for the related Change Actions")
   public static final String RELATEDCHANGEACTIONS = "RELATEDCHANGEACTIONS";

   @RBEntry("Effectivity")
   @RBComment("The column name for Effectivity")
   public static final String EFFECTIVITY = "EFFECTIVITY";

   @RBEntry("Calculation Status")
   @RBComment("The column name for Calculation Status")
   public static final String CALCULATIONSTATUS = "CALCULATIONSTATUS";

   @RBEntry("Default")
   @RBComment("change directive info page default table view name")
   public static final String CHANGE_DIRECTIVES_VIEW_DEFAULT_NAME = "CHANGE_DIRECTIVES_VIEW_DEFAULT_NAME";

   @RBEntry("Default Table View name")
   @RBComment(" change directive info page description default table view name")
   public static final String CHANGE_DIRECTIVES_VIEW_DEFAULT_DESC = "CHANGE_DIRECTIVES_VIEW_DEFAULT_DESC";

   @RBEntry("Information Page")
   @RBComment(" change directive info page description default table view name")
   public static final String INFO_PAGE = "CHANGE_DIRECTIVES_VIEW_INFO_PAGE";


   @RBEntry("Scheduled")
   @RBComment(" status indicating that the task is scheduled not started")
   public static final String SCHEDULED = "SCHEDULED";

   @RBEntry("In Progress")
   @RBComment(" status indicating that the task is in progress")
   public static final String INPROGRESS = "INPROGRESS";

   @RBEntry("Completed")
   @RBComment(" status indicating that the task has been completed")
   public static final String COMPLETED = "COMPLETED";

   @RBEntry("Over Due")
   @RBComment(" status indicating that the task is over due")
   public static final String OVERDUE = "OVERDUE";

   @RBEntry("Confirmation Category")
   public static final String CONFIRMATION_CATEGORY = "CONFIRMATION_CATEGORY";

   @RBEntry("Confirmation Audit")
   public static final String CONFIRMATION_AUDIT = "CONFIRMATION_AUDIT";

   @RBEntry("-- Select a template --")
   public static final String SELECT_TEMPLATE = "SELECT_TEMPLATE";

   @RBEntry("-- No templates available --")
   public static final String NO_TEMPLATES_AVAILABLE = "NO_TEMPLATES_AVAILABLE";

   @RBEntry("Template")
   public static final String CHANGE_TEMPLATE_PICKER_LABEL = "CHANGE_TEMPLATE_PICKER_LABEL";

  @RBEntry("Need Date")
  public static final String NEED_DATE = "NEED_DATE";

  @RBEntry("Type")
  public static final String TYPE = "TYPE";

  @RBEntry("Complexity")
  public static final String COMPLEXITY = "COMPLEXITY";

 @RBEntry("Category")
 public static final String CATEGORY = "CATEGORY";

 @RBEntry("Priority")
 public static final String PRIORITY = "PRIORITY";



  /**
   * ##############################################################################
   * Labels for Available attributes to avoid labels showing as duplicates
   * ##############################################################################
   **/
  @RBEntry("Change Notice Complexity")
  public static final String CHANGE_ORDER_COMPLEXITY = "CHANGE_ORDER_COMPLEXITY";

  @RBEntry("Change Issue Priority")
  public static final String ISSUE_PRIORITY = "ISSUE_PRIORITY";

  @RBEntry("Change Issue Category")
  public static final String ISSUE_CATEGORY = "ISSUE_CATEGORY";

  @RBEntry("Category")
  public static final String ISSUE_THECATEGORY = "ISSUE_THECATEGORY";

  @RBEntry("Change Request Priority")
  public static final String REQUEST_PRIORITY = "REQUEST_PRIORITY";

  @RBEntry("Change Request Category")
  public static final String REQUEST_CATEGORY = "REQUEST_CATEGORY";

  @RBEntry("Category")
  public static final String REQUEST_THECATEGORY = "REQUEST_THECATEGORY";

  @RBEntry("Change Request Complexity")
  public static final String REQUEST_COMPLEXITY = "REQUEST_COMPLEXITY";

  @RBEntry("Variance Owner")
  public static final String VARIANCE_OWNER = "VARIANCE_OWNER";

  @RBEntry("Variance Category")
  public static final String VARIANCE_CATEGORY = "VARIANCE_CATEGORY";

  /*Business rules resource bundle entry START*/
  @RBEntry("Change Pre-Release Validation")
  @RBComment("Name of the rule set that will be used to display to the user when the workflow fails the check before releasing the change object.")
  public static final String CHANGE_PRE_RELEASE_RULESET_NAME = "CHANGE_PRE_RELEASE_RULESET_NAME";

  @RBEntry("Business Rule Set used before objects are released as part of the change process")
  @RBComment("Description for the CHANGE PRE RELEASE RULESET.")
  public static final String CHANGE_PRE_RELEASE_RULESET_DESC = "CHANGE_PRE_RELEASE_RULESET_DESC";

  @RBEntry("Checkout Rule")
  @RBComment("Rule Validator to check no objects are checked out.")
  public static final String CHECK_OUT_VALIDATOR_RULE_NAME = "CHECK_OUT_VALIDATOR_RULE_NAME";

  @RBEntry("This rule determines if there are checked out objects.  If checked out objects are found, then the rule will fail.  Otherwise, it will pass.")
  @RBComment("Description for CHECK_OUT_VALIDATOR_RULE_NAME")
  public static final String CHECK_OUT_VALIDATOR_RULE_DESC = "CHECK_OUT_VALIDATOR_RULE_DESC";

  @RBEntry("Release Target Rule")
  public static final String RELEASE_TARGET_RULE_NAME = "RELEASE_TARGET_RULE_NAME";

  @RBEntry("The Release Target rule validates that the specified release target on the resulting objects is valid for the resulting object's current state.  The rule is also valid when no release target has been specified for the resulting object and the Change release target is valid for the current state of a resulting object")
  @RBComment("Description for Release Target Rule")
  public static final String RELEASE_TARGET_RULE_DESC = "RELEASE_TARGET_RULE_DESC";
  /*Business rules resource bundle entry END*/

  /* Workflow task tab names */
  @RBEntry("Resulting Objects")
  @RBComment("Workflow task tab name for Change Task resulting objects")
  public static final String WFTASK_RESULTING_OBJECTS_TAB_NAME = "WFTASK_RESULTING_OBJECTS_TAB_NAME";

  @RBEntry("Impacts")
  @RBComment("Workflow task tab name for Change Request, Change Notice, Problem Report or Variance impacts")
  public static final String WFTASK_IMPACTS_TAB_NAME = "WFTASK_IMPACTS_TAB_NAME";

  @RBEntry("Change Object")
  @RBComment("Label for the change object picker search result table view")
  public static final String FLEXIBLE_SEARCH_TABLEVIEW_LABEL = "FLEXIBLE_SEARCH_TABLEVIEW_LABEL";
  @RBEntry("Remote Change Object")
  @RBComment("Label for the remote change object picker search result table view")
  public static final String REMOTE_SEARCH_TABLEVIEW_LABEL = "REMOTE_SEARCH_TABLEVIEW_LABEL";

  @RBEntry("Default Change Object View")
  @RBComment("Default view name for the change object picker search result table view")
  public static final String FLEXIBLE_SEARCH_TABLEVIEW_NAME = "FLEXIBLE_SEARCH_TABLEVIEW_NAME";
  @RBEntry("Default Remote Change Object View")
  @RBComment("Default view name for the remote change object picker search result table view")
  public static final String REMOTE_SEARCH_TABLEVIEW_NAME = "REMOTE_SEARCH_TABLEVIEW_NAME";

  @RBEntry("Default Change Object Search Table View")
  @RBComment("Default view description for the change object picker search result table view")
  public static final String FLEXIBLE_SEARCH_TABLEVIEW_DESC = "FLEXIBLE_SEARCH_TABLEVIEW_DESC";
  @RBEntry("Default Remote Change Object Search Table View")
  @RBComment("Default view description for the remote change object picker search result table view")
  public static final String REMOTE_SEARCH_TABLEVIEW_DESC = "REMOTE_SEARCH_TABLEVIEW_DESC";

  @RBEntry("Change Notice Number:")
  @RBComment("Label for Change Notice picker in Add To Change Task wizard")
  public static final String FIND_CHANGE_NOTICE_LABEL = "FIND_CHANGE_NOTICE_LABEL";

  @RBEntry("Find Change Notice")
  @RBComment("Title for Change Notice picker in Add To Change Task wizard")
  public static final String FIND_CHANGE_NOTICE_TITLE = "FIND_CHANGE_NOTICE_TITLE";

  /*
   * Labels used for Workflow Record Client Labels
   */
  @RBEntry("Workflow Records")
  public static final String WORKFLOW_RECORD_COVER_PAGE_TITLE = "WORKFLOW_RECORD_COVER_PAGE_TITLE";

  @RBEntry("Workflow Records")
  @RBComment("Label for Table listing all Workflow Record objects")
  public static final String WORKFLOW_RECORDS_TABLE_TITLE = "WORKFLOW_RECORDS_TABLE_TITLE";

  @RBEntry("All Workflow Records")
  @RBComment("Name for All Workflow Records view")
  public static final String ALL_WORKFLOW_RECORDS_VIEW = "ALL_WORKFLOW_RECORDS_VIEW";

  @RBEntry("All workflow records for this object")
  @RBComment("Description for All Workflow Recordsw view")
  public static final String ALL_WORKFLOW_RECORDS_VIEW_DESC = "ALL_WORKFLOW_RECORDS_VIEW_DESC";

  @RBEntry("All signed workflow records")
  @RBComment("Name for All Signed Workflow Records")
  public static final String ALL_SIGNED_WORKFLOW_RECORDS_VIEW = "ALL_SIGNED_WORKFLOW_RECORDS_VIEW";

  @RBEntry("All signed workflow records for this object")
  @RBComment("Description for All Signed Reviews view")
  public static final String ALL_SIGNED_WORKFLOW_RECORDS_VIEW_DESC = "ALL_SIGNED_WORKFLOW_RECORDS_VIEW_DESC";

  @RBEntry("Workflow Records")
  @RBComment("Label for Object Types in QMSReview table")
  public static final String WORKFLOW_RECORDS_CONTENTS_TEXT = "WORKFLOW_RECORDS_CONTENTS_TEXT";

  @RBEntry("Reviewer Name")
  @RBComment("Reviewer Name Label")
  public static final String REVIEWER_NAME_ATTRIBUTE_LABEL = "REVIEWER_NAME_ATTRIBUTE_LABEL";

  @RBEntry("Reviewer Role")
  @RBComment("Reviewer Role Label")
  public static final String REVIEWER_ROLE_ATTRIBUTE_LABEL = "REVIEWER_ROLE_ATTRIBUTE_LABEL";

  @RBEntry("Review Subject")
  @RBComment("Primary Business Object Label")
  public static final String PRIMARY_BUSINESS_OBJECT_ATTRIBUTE_LABEL = "PRIMARY_BUSINESS_OBJECT_ATTRIBUTE_LABEL";

  @RBEntry("Phase Name")
  @RBComment("Phase Name Label")
  public static final String PHASE_NAME_ATTRIBUTE_LABEL = "PHASE_NAME_ATTRIBUTE_LABEL";

  @RBEntry("Review Result")
  @RBComment("Review Result Label")
  public static final String REVIEW_RESULT_ATTRIBUTE_LABEL = "REVIEW_RESULT_ATTRIBUTE_LABEL";

  @RBEntry("Review Date")
  @RBComment("Review Date Label")
  public static final String REVIEW_DATE_ATTRIBUTE_LABEL = "REVIEW_DATE_ATTRIBUTE_LABEL";

  @RBEntry("eSignature")
  @RBComment("eSignature Label")
  public static final String IS_ESIGNATURE_ATTRIBUTE_LABEL = "IS_ESIGNATURE_ATTRIBUTE_LABEL";

  @RBEntry("Reviewed In")
  @RBComment("Label for primary business object of the Parent QMS Review")
  public static final String PARENT_QMS_REVIEW_ATTRIBUTE_LABEL = "PARENT_QMS_REVIEW_ATTRIBUTE_LABEL";

  @RBEntry("Task")
  @RBComment("Task Label")
  public static final String WORK_ITEM_ATTRIBUTE_LABEL = "WORK_ITEM_ATTRIBUTE_LABEL";

  @RBEntry("Not Applicable")
  @RBComment("A column value shown when a user tries to view the release target or the impact intent for an affected object on the change notice summary table")
  public static final String NOT_APPLICABLE = "NOT_APPLICABLE";
  
  @RBEntry("The Release Target is not applicable for Affected Objects.")
  @RBComment("A more detailed tooltip message indicating why the release target is not valid")
  public static final String NOT_APPLICABLE_RELEASE_TARGET = "NOT_APPLICABLE_RELEASE_TARGET";
  
  @RBEntry("The Impact Intent is not applicable for Affected Objects.")
  @RBComment("A more detailed tooltip message indicating why the impact intent is not valid")
  public static final String NOT_APPLICABLE_IMPACT_INTENT = "NOT_APPLICABLE_IMPACT_INTENT";
  
  @RBEntry("Copy Selected Object")
  public static final String INVALID_SELECTION_COPY = "INVALID_SELECTION_COPY";
  @RBEntry("Invalid Selection")
  @RBComment("Message title when an invalid operation is performed")
  public static final String INVALID_SELECTION_TITLE = "INVALID_OPERATION_TITLE";
  @RBEntry("Some of the remote change objects are not eligible for copying as they are not saved locally.")
  @RBComment("Message when non-persisted remote change items are selected for copying")
  public static final String INVALID_SELECTION_COPY_MESSAGE = "INVALID_COPY_ACTION_MESSAGE";

}
