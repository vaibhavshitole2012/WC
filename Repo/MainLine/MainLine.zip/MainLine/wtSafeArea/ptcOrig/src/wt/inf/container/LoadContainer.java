/* bcwti
 *
 * Copyright (c) 2018 PTC Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */
package wt.inf.container;

import java.io.InputStream;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Hashtable;
import java.util.Vector;

import com.ptc.core.meta.common.IdentifierFactory;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.impl.LogicalIdentifierFactory;

import wt.fc.IdentityHelper;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.inf.team.ContainerTeam;
import wt.inf.team.ContainerTeamHelper;
import wt.inf.team.ContainerTeamManaged;
import wt.inf.team.ContainerTeamReference;
import wt.inf.template.ContainerTemplateHelper;
import wt.introspection.ClassInfo;
import wt.introspection.WTIntrospectionException;
import wt.introspection.WTIntrospector;
import wt.load.LoadServerHelper;
import wt.method.MethodContext;
import wt.org.DirectoryContextProvider;
import wt.org.OrganizationServicesHelper;
import wt.org.WTGroup;
import wt.org.WTOrganization;
import wt.org.WTPrincipal;
import wt.org.WTPrincipalReference;
import wt.org.WTUser;
import wt.pom.UniquenessException;
import wt.projmgmt.admin.Project2;
import wt.projmgmt.ix.ProjMgmtConstants;
import wt.query.QuerySpec;
import wt.services.applicationcontext.implementation.DefaultServiceProvider;
import wt.session.SessionHelper;
import wt.type.Typed;
import wt.type.TypedUtility;
import wt.util.DebugProperties;
import wt.util.DebugWriter;
import wt.util.InstalledProperties;
import wt.util.WTContext;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.WTProperties;
import wt.util.WTPropertyVetoException;
import wt.util.WTStringUtilities;

/**
 * Provides utility methods for loading containers and container-related data.
 *
 * <BR><BR><B>Supported API: </B>false
 * <BR><BR><B>Extendable: </B>false
 *
 * @version   1.0
 **/
public class LoadContainer {

   /**
    * The name of the site organization, as configured during the installation process
    **/
   public static final String SITE_ORG_NAME;

   /**
    * The name of the site organization's internet domain, as configured during the
    * installation process
    **/
   public static final String SITE_ORG_DOMAIN;

   private static final String RESOURCE = containerResource.class.getName();
   private static final String CLASSNAME = LoadContainer.class.getName();
   private static final boolean DEBUG = DebugProperties.isDebugOn( CLASSNAME );
   private static final DebugWriter LOG = ( DEBUG ? DebugProperties.getWriter( CLASSNAME ) : null );
   private static final String SITE_ORG_FILE;
   private static final String SITE_ORG_NAME_PROPERTY = "wt.inf.container.SiteOrganization.name";
   private static final String SITE_ORG_DOMAIN_PROPERTY = "wt.inf.container.SiteOrganization.internetDomain";
   private static final String ORG_CONTAINER_ALREADY_EXISTS = "ORG_CONTAINER_ALREADY_EXISTS";
   private static final LogicalIdentifierFactory IDENTIFIER_FACTORY = (LogicalIdentifierFactory)DefaultServiceProvider.getService(IdentifierFactory.class, "logical");
   private static TypeIdentifier CONTAINER_TYPE;
   private static final String PROGRAM_TYPE = "WCTYPE|wt.projmgmt.admin.Project2|com.ptc.Program";
   private static TypeIdentifier PROGRAM_TYPEIDENTIFIER;
   private static final String PROGRAM_CLASSNAME = "com.ptc.Program";

   static {
      try {
         WTProperties wtp = WTProperties.getLocalProperties();
         SITE_ORG_FILE = wtp.getProperty("wt.inf.container.SiteOrganization.file", "wt/inf/container/SiteOrganization.properties");
         CONTAINER_TYPE = (TypeIdentifier)IDENTIFIER_FACTORY.get(WTContainer.class.getName());
         PROGRAM_TYPEIDENTIFIER = (TypeIdentifier)IDENTIFIER_FACTORY.get(PROGRAM_TYPE);
         InputStream istream = null;
         try {
            istream = WTContext.getContext().getResourceAsStream(SITE_ORG_FILE);
            wtp = new WTProperties(/*no defaults*/null);
            if (istream != null) {
               wtp.load(istream);
            }
            SITE_ORG_NAME = wtp.getProperty(SITE_ORG_NAME_PROPERTY);
            SITE_ORG_DOMAIN = wtp.getProperty(SITE_ORG_DOMAIN_PROPERTY);
          }
         finally {
            if (istream != null) {
               istream.close();
            }
         }
      }
      catch (Throwable t) {
         throw new ExceptionInInitializerError(t);
      }
   }

   /**
    * Loads the exchange container. The exchange container is persisted by <code>wt.admin.Install</code>.
    * This method completes the creation process by calling the exchange container's container creator
    * delegate.
    * <p>
    * <b>Note:</b> This API is only intended to be called during the administrative load of the system.
    *
    *
    * @param   nv             map of load parameters
    * @param   cmd_line       Command line overrides
    * @param   return_objects
    *
    * @return <code>true</code> If the load succeeds
    **/
   public static boolean createExchangeContainer(final Hashtable nv, final Hashtable cmd_line, final Vector return_objects) {
      if (SITE_ORG_NAME == null || "".equals(SITE_ORG_NAME)) {
         LoadServerHelper.printMessage("createExchangeContainer: The site organization name could not be found. "
                                     + "This can be configured during the installation process, or by setting"
                                     + "the property \"" + SITE_ORG_NAME_PROPERTY + "\" in property file: \""
                                     + SITE_ORG_FILE + "\"");
         return false;
      }
      if (SITE_ORG_DOMAIN == null || "".equals(SITE_ORG_DOMAIN)) {
         LoadServerHelper.printMessage("createExchangeContainer: The site organization internet domain name could not be found. "
                                     + "This can be configured during the installation process, or by setting"
                                     + "the property \"" + SITE_ORG_DOMAIN_PROPERTY + "\" in property file: \""
                                     + SITE_ORG_FILE + "\"");
         return false;
      }

      final ClassInfo info;
      try {
         info = WTIntrospector.getClassInfo(ExchangeContainer.class);
      }
      catch (WTIntrospectionException wtie) {
         LoadServerHelper.printMessage("createExchangeContainer: " + wtie.getLocalizedMessage());
         wtie.printStackTrace();
         return false;
      }
      nv.put("containerName",info.toDisplayNameMessage().getLocalizedMessage(null));
      final String description = WTMessage.getLocalizedMessage(RESOURCE,containerResource.EXCHANGE_CONTAINER_DESCRIPTION,null);
      nv.put("description",description);
      nv.put("organization", SITE_ORG_NAME);
      nv.put("internetDomain", SITE_ORG_DOMAIN);
      nv.put(LoadServerHelper.DEFAULT_CONT_PATH, "/");
      return createContainer(nv,cmd_line,return_objects);
   }


   /**
    * Loads an <code>OrgContainer</code> with the given properties. The format of the corresponding
    * load line is:
    * <pre>
    * containerName~containerTemplateRef~businessNamespace~sharingEnabled~creator~owner~subscriber~conferencingURL~description~internetDomain
    * </pre>
    *
    * @param   nv             map of load parameters
    * @param   cmd_line       Command line overrides
    * @param   return_objects
    *
    * @return <code>true</code> If the load succeeds
    **/
   public static boolean createOrgContainer(final Hashtable nv, final Hashtable cmd_line, final Vector return_objects) {
      String containerName = LoadServerHelper.getValue("containerName",nv,cmd_line,LoadServerHelper.REQUIRED);
      WTContainerRef org = null;
      try {
         org = getOrgRef(containerName);
      }
      catch (WTException wte) {
         LoadServerHelper.printMessage("createOrgContainer: " + wte.getLocalizedMessage());
         wte.printStackTrace();
         return false;
      }
      if( org != null ) {
         //Container already exists so return
    	  Object[] params = {containerName};
    	  LoadServerHelper.printMessage(WTMessage.getLocalizedMessage(RESOURCE, ORG_CONTAINER_ALREADY_EXISTS,params ));
         return_objects.add(org);
         return true;
      }

      nv.put("containerClass", OrgContainer.class.getName());
      nv.put(LoadServerHelper.DEFAULT_CONT_PATH, "/");
      return createContainer(nv, cmd_line, return_objects);
   }

   public static boolean createSiteOrgContainer(final Hashtable nv, final Hashtable cmd_line, final Vector return_objects) {
      nv.put("containerClass", OrgContainer.class.getName());
      nv.put("containerName", SITE_ORG_NAME);
      nv.put(LoadServerHelper.DEFAULT_CONT_PATH, "/");
      nv.put("description",WTMessage.getLocalizedMessage(RESOURCE,containerResource.SITE_ORG_CONTAINER_DESCRIPTION,null));
      nv.put("subscriber","true");
      nv.put("restrictedDirectorySearchScope","false");
      if (!createContainer(nv, cmd_line, new Vector())) {
         LoadServerHelper.printMessage("createSiteOrgContainer: could not create site org");
         return false;
      }
      return true;
   }

   /**
    * Loads a <code>WTContainer</code> with the given properties. The format of the corresponding
    * load line is:
    * <pre>
    * containerClass~containerName~sharedTeamName~containerExtendable~containerTemplateRef~businessNamespace~sharingEnabled~creator~owner~subscriber~conferencingURL~description~organization~creatorSelector
    * </pre>
    *
    * @param   nv             map of load parameters
    * @param   cmd_line       Command line overrides
    * @param   return_objects
    *
    * @return <code>true</code> If the load succeeds
    **/
   public static boolean createContainer(final Hashtable nv, final Hashtable cmd_line, final Vector return_objects) {
      WTContainer container = null;

      final String classname           = LoadServerHelper.getValue("containerClass",nv,cmd_line,LoadServerHelper.REQUIRED);
      final String containerName       = LoadServerHelper.getValue("containerName",nv,cmd_line,LoadServerHelper.NOT_REQUIRED);
      final String sharedTeamName      = LoadServerHelper.getValue("sharedTeamName",nv,cmd_line,LoadServerHelper.NOT_REQUIRED);
      final boolean containerExtendable= Boolean.valueOf(LoadServerHelper.getValue("containerExtendable",nv,cmd_line,LoadServerHelper.NOT_REQUIRED)).booleanValue();
      final String templateName        = LoadServerHelper.getValue("containerTemplateRef",nv,cmd_line,LoadServerHelper.NOT_REQUIRED);
      final boolean businessNamespace  = Boolean.valueOf(LoadServerHelper.getValue("businessNamespace",nv,cmd_line,LoadServerHelper.NOT_REQUIRED)).booleanValue();
      final boolean sharingEnabled     = Boolean.valueOf(LoadServerHelper.getValue("sharingEnabled",nv,cmd_line,LoadServerHelper.NOT_REQUIRED)).booleanValue();
      final String creatorName         = LoadServerHelper.getValue("creator",nv,cmd_line,LoadServerHelper.NOT_REQUIRED);
      final String ownerName           = LoadServerHelper.getValue("owner",nv,cmd_line,LoadServerHelper.NOT_REQUIRED);
      final boolean subscriber         = Boolean.valueOf(LoadServerHelper.getValue("subscriber",nv,cmd_line,LoadServerHelper.NOT_REQUIRED)).booleanValue();
      final String conferencingURL     = LoadServerHelper.getValue("conferencingURL",nv,cmd_line,LoadServerHelper.NOT_REQUIRED);
      final String description         = LoadServerHelper.getValue("description",nv,cmd_line,LoadServerHelper.NOT_REQUIRED);
      final String organization        = LoadServerHelper.getValue("organization",nv,cmd_line,LoadServerHelper.NOT_REQUIRED);
      final String creatorSelector     = LoadServerHelper.getValue("creatorSelector",nv,cmd_line,LoadServerHelper.NOT_REQUIRED);
      final String internetDomain      = LoadServerHelper.getValue("internetDomain",nv,cmd_line,LoadServerHelper.NOT_REQUIRED);
      final String organizationAddress = LoadServerHelper.getValue("OrganizationAddress", nv, cmd_line,LoadServerHelper.NOT_REQUIRED);
      final String conferencingID      = LoadServerHelper.getValue("conferencingID", nv, cmd_line,LoadServerHelper.NOT_REQUIRED);
      final boolean startProject       = Boolean.valueOf(LoadServerHelper.getValue("startProject", nv, cmd_line,LoadServerHelper.NOT_REQUIRED));
      final boolean identifyOutOfDateSharedObjects = Boolean.valueOf(LoadServerHelper.getValue("identifyOutOfDateSharedObjects", nv, cmd_line,LoadServerHelper.NOT_REQUIRED));
      final boolean autoexecution       = Boolean.valueOf(LoadServerHelper.getValue("autoExecution", nv, cmd_line,LoadServerHelper.NOT_REQUIRED)).booleanValue();

      final String isAutoExecution=String.valueOf(!autoexecution);
      //currently these are programmatically added by createExchange & createClassic, and are not in the load spec
      final String restricted          = LoadServerHelper.getValue("restrictedDirectorySearchScope",nv,cmd_line,LoadServerHelper.NOT_REQUIRED);
      final String canProjectCreate    = LoadServerHelper.getValue("canProjectCreate",nv,cmd_line,LoadServerHelper.NOT_REQUIRED);


      boolean isProject = false;
      if (classname.equals(Project2.class.getName())) { isProject = true; }
      //Retrieve command line org container
      OrgContainer orgContainer = null;
      try {
         WTContainerRef orgContainerRef = LoadServerHelper.getTargetContainer(nv, cmd_line);
         if (orgContainerRef != null) {
            WTContainer cont = orgContainerRef.getReferencedContainer();
            if (cont instanceof OrgContainer) {
               orgContainer = (OrgContainer)cont;
            }
         }
      } catch (WTException e) {
         e.printStackTrace();
      }

      WTPrincipal prev = null;
      try {
         //Set container extendability
         if (containerExtendable) {
            MethodContext.getContext().put(WTContainerHelper.EXTENDABLE_CONTAINER, true);
         }

         if (creatorName != null) {
            prev = SessionHelper.getPrincipal();
            SessionHelper.manager.setPrincipal(creatorName);
         }
         Class containerClass = null;
         String baseClassname = classname;
         TypeIdentifier type = (TypeIdentifier)IDENTIFIER_FACTORY.get(classname);
         try{
             containerClass = Class.forName(classname);
         }catch(ClassNotFoundException cnfe){
             // if classname is not hard class defined, check if its a subtype
             if(type.isDescendedFrom(CONTAINER_TYPE)){
                 baseClassname = TypedUtility.getClassname(type);
                 if (baseClassname.equals(Project2.class.getName())) {
                     isProject = true;
                 }
                 containerClass = Class.forName(baseClassname);
             }else{
                 Object[] params = {classname};
                 //Container class not found
                 throw new WTContainerException(cnfe,RESOURCE,containerResource.NOT_CONTAINER_CLASS,params);
             }
         }


         final WTContainerRef parentRef = LoadServerHelper.getTargetContainer(nv,cmd_line);
         container = newInstance(containerClass, containerName, parentRef);
         // Setup type definition reference
         if (container instanceof Typed) {
        	 ((Typed)container).setTypeDefinitionReference(TypedUtility.getTypeDefinitionReference(classname));
         }

         // if creating a program or subtype of program, making sure to set the type and resetting baseclass to original class name to retrieve template.
         if ( type != null && ( type.equals(PROGRAM_TYPEIDENTIFIER) || type.isDescendedFrom(PROGRAM_TYPEIDENTIFIER) ) ){
             if (DEBUG && DebugProperties.isReport(LoadContainer.class)){
                 LOG.report("Setting pseudoType for a Project to display it as Program");
             }
             ((Project2) container).setPseudoType(2);
             baseClassname = PROGRAM_CLASSNAME;
         }

         //set type of plan auto-execution or manual-execution
        	 MethodContext.getContext().put(ProjMgmtConstants.PROJECT_EXECUTION_CONTROL, isAutoExecution);
         //Set shared team
         if( sharedTeamName != null && orgContainer != null ) {
            ContainerTeam sharedTeam = ContainerTeamHelper.service.getSharedTeamByName(orgContainer, sharedTeamName);
            if (sharedTeam != null && container instanceof ContainerTeamManaged) {
               ContainerTeamReference sharedTeamRef = ContainerTeamReference.newContainerTeamReference(sharedTeam);
               container = ContainerTeamHelper.assignSharedTeamToContainer((ContainerTeamManaged)container, sharedTeamRef, false);
            }
         }

         if (DEBUG && DebugProperties.isReport(LoadContainer.class)) {
            LOG.report("Creating container of type: " + classname + " with name: " + containerName + " and parent: " + WTContainerHelper.getDisplayPath(parentRef));
         }

         if (templateName != null) {
            final WTContainerTemplate template = ContainerTemplateHelper.service.getContainerTemplate(parentRef, templateName, baseClassname);
            if (template==null) {
               String[] inserts = new String[]{ templateName };
               String message = WTMessage.getLocalizedMessage(RESOURCE, containerResource.TEMPLATE_NOT_FOUND, inserts, SessionHelper.getLocale());
               throw new WTException(message);
            }
            container.setContainerTemplate( template );
         }
         if (!PersistenceHelper.isPersistent(container)) {
            WTContainerHelper.setBusinessNamespace(container, businessNamespace);
         }
         container.setSharingEnabled(sharingEnabled);
         if (ownerName != null) {
            WTPrincipal owner = OrganizationServicesHelper.manager.getPrincipal(ownerName);
            container.setOwner(owner);
         }
         if (description != null) {
            container.setDescription(description);
         }
         if (isProject && identifyOutOfDateSharedObjects) {
        	 ((Project2)container).setShowOutOfDateShareIndicator(identifyOutOfDateSharedObjects);
         }

         //SPR1843004: skip csvorganization for library (and product/project) loading
         if (organization != null && !ContainerTeamManaged.class.isAssignableFrom(containerClass)) {
            final DirectoryContextProvider context = container.getContainer().getContextProvider();
            WTOrganization wtorg = OrganizationServicesHelper.manager.getOrganization(organization,context);
            if (wtorg == null) {
               wtorg = WTOrganization.newWTOrganization(organization,context);
               assignOrgProperties(wtorg, conferencingURL, internetDomain, conferencingID, organizationAddress);
               wtorg = (WTOrganization)OrganizationServicesHelper.manager.createPrincipal(wtorg);
            }
            else if (container instanceof OrgContainer) {
               assignOrgProperties(wtorg, conferencingURL, internetDomain, conferencingID, organizationAddress);
               wtorg = (WTOrganization)OrganizationServicesHelper.manager.updatePrincipal(wtorg);
            }

            final WTContainerIdentity id = (WTContainerIdentity)container.getIdentificationObject();
            id.setOrganizationReference(WTPrincipalReference.newWTPrincipalReference(wtorg));
            if (PersistenceHelper.isPersistent(container)) {
               WTOrganization current = container.getOrganization();
               if ((current == null) || (!PersistenceHelper.isEquivalent(current,wtorg))) {
                  container = (WTContainer)IdentityHelper.service.changeIdentity(container,id);
               }
            }
            else {
               IdentityHelper.setIdentity(container,id);
            }
         }
            if (container instanceof OrgContainer) {
                final OrgContainer org_container = (OrgContainer) container;
                org_container.setSubscriber(subscriber);
                if (restricted != null && !"".equals(restricted)) {
                    WTContainerHelper.setRestrictedDirectorySearchScope(org_container,
                            Boolean.valueOf(restricted).booleanValue());
                }

                // SPR: 6667680 --> Allow to create 'PROJECT CREATOR' role while creating organization using load file even Windchill have not installed Project Link module.
                //default value of canProjectCreate is false if '<csvcanProjectCreate>' element is blank in load file or not present in load file. 
                final CreatorsMap map = org_container.getCreatorsMap();
                CreatorsLink link = map.getCreatorsLink(Project2.class);
                if (link == null) {
                    link = map.addMapping(Project2.class);
                }
            
                if (canProjectCreate != null && !"".equals(canProjectCreate)) {
                    link.setAutoPopulate(Boolean.valueOf(canProjectCreate).booleanValue());
                }else{
                    if(InstalledProperties.isInstalled(InstalledProperties.PROJECTLINK)){
                        link.setAutoPopulate(true);
                    }else{
                        link.setAutoPopulate(false);
                    }
                }
            
            }

         if (PersistenceHelper.isPersistent(container)) {
            container = WTContainerCreatorFactory.getInstance().getCreator(container,creatorSelector).migrate(new WTContainerCreateRequest(container));
         }
         else {
            // SPR#1270724: check if the container already exists
            WTContainerServerHelper.service.checkIdentity(container);
            container = WTContainerHelper.service.create(container, creatorSelector);
            if (container instanceof OrgContainer && organization == null) {
               WTOrganization wtorg = ((OrgContainer) container).getOrganization();
               if (conferencingURL != null || internetDomain != null || conferencingID != null || organizationAddress != null) {
                  //must set the conferencing URL
                  assignOrgProperties(wtorg, conferencingURL, internetDomain, conferencingID, organizationAddress);
               }
               wtorg = (WTOrganization) OrganizationServicesHelper.manager.updatePrincipal(wtorg);
            }
         }

         if (isProject && startProject) {
           ContainerTeamHelper.service.activate((Project2)container);
         }

         final String display = WTContainerHelper.getDisplayPath(WTContainerRef.newWTContainerRef(container));
         LoadServerHelper.printMessage("Created container: " + display);
      }
      catch (UniquenessException ue){
         LoadServerHelper.printMessage("createContainer: " + ue.getLocalizedMessage());
         return true;
      }
      catch (WTException wte) {
         LoadServerHelper.printMessage("createContainer: " + wte.getLocalizedMessage());
         wte.printStackTrace();
         return false;
      }
      catch (WTPropertyVetoException wtpve) {
         LoadServerHelper.printMessage("createContainer: " + wtpve.getLocalizedMessage());
         wtpve.printStackTrace();
         return false;
      }
      catch (Exception e) {
         LoadServerHelper.printMessage("createContainer: " + e.getMessage());
         e.printStackTrace();
         return false;
      }
      finally {
         if (containerExtendable) {
            MethodContext.getContext().remove(WTContainerHelper.EXTENDABLE_CONTAINER);
         }
         if (prev != null) {
            try {
               SessionHelper.manager.setPrincipal(prev.getDn());
            }
            catch (Exception e) {
               LoadServerHelper.printMessage("Could not reset principal" + e.getMessage());
               return false;
            }
         }
      }

      return true;
   }

   /**
    * Assigns the conferencing url and internet domain to the given organization, if they are valid.
    *
    * @param   conferencing_url      The conferencing URL for the org
    * @param   internet_domain       The internet domain for the org
    * @param   conferencingID        The conferencing ID for the org
    * @param   organizationAddress   The organization Address for the org
    **/
   private static void assignOrgProperties(final WTOrganization org, final String conferencing_url, final String internet_domain, final String conferencingID, final String organizationAddress) throws WTException {
      if (conferencing_url != null && !"".equals(conferencing_url.trim())) {
         try {
            org.setConferencingURL(new URL(conferencing_url));
         }
         catch (MalformedURLException mue) {
            throw new WTException(mue);
         }
      }
      if (internet_domain != null && !"".equals(internet_domain.trim())) {
         org.setInternetDomain(internet_domain);
      }
      if(organizationAddress != null && !"".equals(organizationAddress.trim())) {
         org.setLocation(organizationAddress);
      }
      if(conferencingID != null && !"".equals(conferencingID.trim())) {
         org.setConferencingIdentifier(conferencingID);
      }
   }

   /**
    * Create a new container with the given name and parent. If the container class is the exchange container class,
    * then check to see if the exchange container already exists.
    *
    * @param   container_class   The class for the new container
    * @param   name              The name for the new container
    * @param   parent            The reference to the parent of the new container
    *
    * @return  The new container instance
    **/
   private static WTContainer newInstance(final Class container_class, final String name, final WTContainerRef parent) throws WTException {
      WTContainer result = null;
      if (ExchangeContainer.class.equals(container_class)) {
         final QueryResult qr = PersistenceServerHelper.manager.query(new QuerySpec(ExchangeContainer.class));
         if (qr.hasMoreElements()) {
            if (DEBUG && DebugProperties.isReport(LoadContainer.class)) {
               LOG.report("Found exchange container");
            }
            result = (ExchangeContainer)qr.nextElement();
         }
      }
      if (result == null) {
         final Object[] args;
         Method factory = getFactoryMethod(container_class, new Class[]{OrgContainer.class});
         if((factory != null) && OrgContainer.class.isAssignableFrom(parent.getReferencedClass())) {
            args = new Object[]{parent.getReferencedContainer()};
         }
         else {
            factory = getFactoryMethod(container_class, new Class[]{WTContainer.class});
            if(factory != null) {
               args = new Object[]{parent.getReferencedContainer()};
            }
            else {
               factory = getFactoryMethod(container_class, new Class[]{String.class,WTContainer.class});
               if(factory != null) {
                  args = new Object[]{name,parent.getReferencedContainer()};
               }
               else {
                  factory = getFactoryMethod(container_class, null);
                  args = null;
               }
            }
         }
         if(factory == null ) {
            throw new WTContainerException("Could not find factory method for container class: " + container_class.getName());
         }

         if (DEBUG && DebugProperties.isReport(LoadContainer.class)) {
            LOG.report("Creating container " + name + " of type " + container_class.getName());
         }

         try {
            result = (WTContainer)factory.invoke(null, args);
         }
         catch (Exception e) {
            throw new WTException(e);
         }
         try {
            if (result.getName() == null) {
               result.setName(name);
            }
            if (result.getContainer() == null) {
               result.setContainerReference(parent);
            }
         }
         catch (WTPropertyVetoException wtpve) {
            throw new WTException(wtpve);
         }
      }
      return result;
   }

   /**
    * Get a factory method of the form <code>newXXX</code> from the given class
    *
    * @param   container_class   The class to get the factory method from
    * @param   argtypes          The arguments for the factory method
    *
    * @return  The factory method
    **/
   private static Method getFactoryMethod(Class container_class, Class[] argtypes) {
      final Method result;
      try {
         result = container_class.getMethod("new" + WTStringUtilities.tail(container_class.getName(), '.'), argtypes);
      }
      catch (Exception e) {
         return null;
      }
      return result;
   }

   /**
    * Gets a reference to the org container with the given name.
    *
    * @param   name  The name of the org container
    *
    * @return A reference to the org container, or <code>null</code> if it couldn't be found.
    **/
   private static WTContainerRef getOrgRef(String org_name) throws WTException {
      StringBuffer sb = new StringBuffer();
      ContainerPathHelper.escape(org_name,sb);
      try {
         return WTContainerHelper.service.getByPath("/wt.inf.container.OrgContainer=" + sb.toString());
      }
      catch (ContainerPathException cpe) {
         return null;
      }
   }

   /**
    * Make the given user an administrator of the current org container.
    * The format of the load entry is as follows:
    * <pre>
    * userNameOrDN
    * </pre>
    *
    *
    * @param   nv             map of load parameters
    * @param   cmd_line       Command line overrides
    * @param   return_objects
    *
    * @return <code>true</code> If the load succeeds
    **/
   public static boolean addOrgAdministrator(final Hashtable nv, final Hashtable cmd_line, final Vector return_objects) {
      try {
         String user_name_or_dn = LoadServerHelper.getValue("userNameOrDN",nv,cmd_line,LoadServerHelper.REQUIRED);

         WTContainerRef container_ref = LoadServerHelper.getTargetContainer(nv,cmd_line);
         if (container_ref == null) {
            throw new WTException("No current container");
         }
         if (!OrgContainer.class.isAssignableFrom(container_ref.getReferencedClass())) {
            throw new WTException("Current container must be an org container. You supplied: " + WTContainerServerHelper.getLogPath(container_ref));
         }
         WTUser user = getUser(user_name_or_dn, nv, cmd_line);
         WTContainer container = container_ref.getContainer();
         WTGroup administrators = container.getAdministrators();
         administrators.addMember(user);

         LoadServerHelper.printMessage("Added user: \"" + user.getDn()
            + "\" to administrators group: \"" + administrators.getDn()
            + "\" for container: \"" + WTContainerServerHelper.getLogPath(container) + "\"");

         return true;
      }
      catch (WTException wte) {
         LoadServerHelper.printMessage("addOrgAdministrator: " + wte.getLocalizedMessage());
         wte.printStackTrace();
      }
      catch (Exception e) {
         LoadServerHelper.printMessage("addOrgAdministrator: " + e.getMessage());
         e.printStackTrace();
      }
      return false;
   }

   /**
    * Make the given user an administrator of the site container.
    * The format of the load entry is as follows:
    * <pre>
    * userNameOrDN
    * </pre>
    *
    *
    * @param   nv             map of load parameters
    * @param   cmd_line       Command line overrides
    * @param   return_objects
    *
    * @return <code>true</code> If the load succeeds
    **/
   public static boolean addSiteAdministrator(final Hashtable nv, final Hashtable cmd_line, final Vector return_objects) {
      try {
         String user_name_or_dn = LoadServerHelper.getValue("userNameOrDN",nv,cmd_line,LoadServerHelper.REQUIRED);
         WTContainer container = WTContainerHelper.service.getExchangeContainer();
         WTUser user = getUser(user_name_or_dn, nv, cmd_line);
         WTGroup administrators = container.getAdministrators();
         administrators.addMember(user);

         LoadServerHelper.printMessage("Added user: \"" + user.getDn()
            + "\" to administrators group: \"" + administrators.getDn()
            + "\" for container: \"" + WTContainerServerHelper.getLogPath(container) + "\"");

         return true;
      }
      catch (WTException wte) {
         LoadServerHelper.printMessage("addOrgAdministrator: " + wte.getLocalizedMessage());
         wte.printStackTrace();
      }
      catch (Exception e) {
         LoadServerHelper.printMessage("addOrgAdministrator: " + e.getMessage());
         e.printStackTrace();
      }
      return false;
   }

   /**
    * Make a user a creator for the given container type, within the current container.
    * The format of the load entry is as follows:
    * <pre>
    * userNameOrDN~containerClassName
    * </pre>
    *
    * @param   nv             map of load parameters
    * @param   cmd_line       Command line overrides
    * @param   return_objects
    *
    * @return <code>true</code> If the load succeeds
    **/
   public static boolean addCreator(final Hashtable nv, final Hashtable cmd_line, final Vector return_objects) {
      try {
         String user_name_or_dn      = LoadServerHelper.getValue("userNameOrDN",nv,cmd_line,LoadServerHelper.REQUIRED);
         String container_class_name = LoadServerHelper.getValue("containerClassName",nv,cmd_line,LoadServerHelper.REQUIRED);

         WTContainerRef container_ref = LoadServerHelper.getTargetContainer(nv,cmd_line);
         if (container_ref == null) {
            throw new WTException("No current container");
         }
         if (!OrgContainer.class.isAssignableFrom(container_ref.getReferencedClass())) {
            throw new WTException("Current container must be an org container. You supplied: " + WTContainerServerHelper.getLogPath(container_ref));
         }

         WTUser user = getUser(user_name_or_dn, nv, cmd_line);
         WTOrganization userOrg=OrganizationServicesHelper.manager.getOrganization(user);
         WTOrganization orgOrg=((OrgContainer)container_ref.getObject()).getOrganization();
         
         if (userOrg == null) {
             throw new WTException("User '" + (user != null ? user.getName() : user) +"' does not have an organization.");
         }
         else if (PersistenceHelper.getObjectIdentifier(userOrg) == null) {
             throw new WTException("Unable to find Object Identifier for WTOrganization '" + (userOrg != null ? userOrg.getName() : userOrg) + "'.");
         }
         else {
             if (!PersistenceHelper.getObjectIdentifier(userOrg).equals(PersistenceHelper.getObjectIdentifier(orgOrg)))  {
                 throw new WTException("Only members of this organization can be added to the creators group.");
             }
         }

         Class container_class = Class.forName(container_class_name);
         if (!WTContainer.class.isAssignableFrom(container_class)) {
            throw new WTException("Supplied class does not implement WTContainer: " + container_class_name);
         }

         OrgContainer container = (OrgContainer)container_ref.getContainer();
         CreatorsMap map = container.getCreatorsMap();
         CreatorsLink link = map.getCreatorsLink(container_class);
         if (link == null) {
            link = map.addMapping(container_class);
            WTContainerServerHelper.service.save(map);
         }
         WTGroup creators = link.getCreators();
         creators.addMember(user);

         LoadServerHelper.printMessage("Added user: \"" + user.getDn()
            + "\" to creators group: \"" + creators.getDn()
            + "\" for container: \"" + WTContainerServerHelper.getLogPath(container) + "\"");

         return true;
      }
      catch (WTException wte) {
         LoadServerHelper.printMessage("addOrgAdministrator: " + wte.getLocalizedMessage());
         wte.printStackTrace();
      }
      catch (Exception e) {
         LoadServerHelper.printMessage("addOrgAdministrator: " + e.getMessage());
         e.printStackTrace();
      }
      return false;
   }

   /**
    * Get the user with the givne name or dn
    *
    * @param   user_name_or_dn    A user name or full DN if necessary
    * @param   nv                 map of load parameters
    * @param   cmd_line           command line overrides
    *
    * @throws  WTException        If the user can't be found
    *
    * @return  The matching user
    **/
   private static WTUser getUser(String user_name_or_dn, Hashtable nv, Hashtable cmd_line) throws Exception {
      DirectoryContextProvider dcp = OrganizationServicesHelper.manager.newDirectoryContextProvider((String[])null,(String[])null);
      WTUser user = OrganizationServicesHelper.manager.getUser(user_name_or_dn,dcp);
      if (user == null) {
         throw new WTException("Unable to find user: \"" + user_name_or_dn + "\"");
      }
      return user;
   }
}

