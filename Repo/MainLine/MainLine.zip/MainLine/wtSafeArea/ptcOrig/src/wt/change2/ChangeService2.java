/* bcwti
 *
 * Copyright (c) 2010 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */

package wt.change2;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import com.infoengine.object.factory.Element;
import com.ptc.core.meta.common.TypeIdentifier;

import wt.fc.BinaryLink;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.fc.collections.WTCollection;
import wt.fc.collections.WTKeyedHashMap;
import wt.fc.collections.WTKeyedMap;
import wt.fc.collections.WTList;
import wt.fc.collections.WTSet;
import wt.folder.CabinetMember;
import wt.folder.Folder;
import wt.folder.FolderEntry;
import wt.lifecycle.State;
import wt.method.RemoteInterface;
import wt.org.WTOrganization;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.pom.UniquenessException;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.vc.Mastered;

/**
 * The interface describing the services available for the change2 package.
 *
 *
 * <BR><BR><B>Supported API: </B>true
 * <BR><BR><B>Extendable: </B>false
 *
 * @see wt.change2.StandardChangeService2
 * @see wt.change2.ChangeHelper2
 **/
@RemoteInterface
public interface ChangeService2 {
   /**
    * Delete the AffectedActivityData relationship only.  The ChangeActivityIfc
    * object and Changeable2 object that the AffectedActivityData relationship
    * links together will still both exist after the relationship is deleted.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see AffectedActivityData
    * @see ChangeActivityIfc
    * @see Changeable2
    *
    * @param     aad
    * @return    AffectedActivityData
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/
   public AffectedActivityData deleteAffectedActivityData( AffectedActivityData aad )
            throws WTException, ChangeException2;

   /**
    * Deletes the concrete subclass of AnalysisActivityIfc from the database.
    *
    * The associated (or relevant) DetailedByIfc concrete associations will
    * be deleted by the Persistence Manager and all related change objects
    * will be deleted by listeners on ChangeService2, with the exception
    * of related ChangeAnalysisIfc (ChangeInvestigationIfc or ChangeProposalIfc)
    * objects.
    *
    * This method should be called rather than calling the Persistence Manager
    * delete method directly.
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @param     aa
    * @return    AnalysisActivityIfc
    * @exception wt.change2.ChangeException2
    * @exception wt.util.WTException
    **/

   public AnalysisActivityIfc deleteAnalysisActivity( AnalysisActivityIfc aa )
            throws ChangeException2, WTException;

   /**
    * Deletes the concrete subclass of ChangeActivityIfc from the database.
    *
    * The associated (or relevant) IncludedInIfc concrete associations will
    * be deleted by the Persistence Manager and all related change objects
    * will be deleted by listeners on ChangeService2, with the exception
    * of related ChangeOrderIfc objects.
    *
    * This method should be called rather than calling the Persistence Manager
    * delete method directly.
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @param     ca
    * @return    ChangeActivityIfc
    * @exception wt.change2.ChangeException2
    * @exception wt.util.WTException
    **/

   public ChangeActivityIfc deleteChangeActivity( ChangeActivityIfc ca )
            throws ChangeException2, WTException;

   /**
    * Deletes the concrete subclass of ChangeInvestigationIfc from the database.
    *
    * The associated (or relevant) ResearchedByIfc concrete associations
    * will be deleted by the Persistence Manager and all related change
    * objects will be deleted by listeners on ChangeService2, with the exception
    * of related ChangeRequestIfc objects.
    *
    * This method should be called rather than calling the Persistence Manager
    * delete method directly.
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @param     ci
    * @return    ChangeInvestigationIfc
    * @exception wt.change2.ChangeException2
    * @exception wt.util.WTException
    **/

   public ChangeInvestigationIfc deleteChangeInvestigation( ChangeInvestigationIfc ci )
            throws ChangeException2, WTException;

   /**
    * Deletes the concrete subclass of ChangeIssueIfc from the database.
    *
    * The associated (or relevant) FormalizedByIfc concrete associations
    * will be deleted by the Persistence Manager and all related change
    * objects will be deleted by listeners on ChangeService2, with the exception
    * of related ChangeRequestIfc objects.
    *
    * This method should be called rather than calling the Persistence Manager
    * delete method directly.
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @param     ci
    * @return    ChangeIssueIfc
    * @exception wt.change2.ChangeException2
    * @exception wt.util.WTException
    **/

   public ChangeIssueIfc deleteChangeIssue( ChangeIssueIfc ci )
            throws ChangeException2, WTException;

   /**
    * Deletes the concrete subclass of ChangeOrderIfc from the database.
    *
    * The associated (or relevant) AddressedByIfc concrete associations
    * will be deleted by the Persistence Manager and all related change
    * objects will be deleted by listeners on ChangeService2, with the exception
    * of related ChangeRequestIfc objects.
    *
    * This method should be called rather than calling the Persistence Manager
    * delete method directly.
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @param     co
    * @return    ChangeOrderIfc
    * @exception wt.change2.ChangeException2
    * @exception wt.util.WTException
    **/

   public ChangeOrderIfc deleteChangeOrder( ChangeOrderIfc co )
            throws ChangeException2, WTException;

   /**
    * Deletes the concrete subclass of ChangeProposalIfc from the database.
    *
    * The associated (or relevant) ResearchedByIfc concrete associations
    * will be deleted by the Persistence Manager and all related change
    * objects will be deleted by listeners on ChangeService2, with the exception
    * of related ChangeRequestIfc objects.
    *
    * This method should be called rather than calling the Persistence Manager
    * delete method directly.
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @param     cp
    * @return    ChangeProposalIfc
    * @exception wt.change2.ChangeException2
    * @exception wt.util.WTException
    **/

   public ChangeProposalIfc deleteChangeProposal( ChangeProposalIfc cp )
            throws ChangeException2, WTException;

   /**
    * Delete the ChangeRecord2 relationship only.  The ChangeActivityIfc
    * object and Changeable2 object that the ChangeRecord2 relationship
    * links together will still both exist after the relationship is deleted.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see ChangeRecord2
    * @see ChangeActivityIfc
    * @see Changeable2
    *
    * @param     cr
    * @return    ChangeRecord2
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public ChangeRecord2 deleteChangeRecord( ChangeRecord2 cr )
            throws WTException, ChangeException2;

   /**
    * Deletes the concrete subclass of ChangeRequestIfc from the database.
    *
    * The associated (or relevant) FormalizedByIfc concrete associations
    * will be deleted by the Persistence Manager and all related change
    * objects will be deleted by listeners on ChangeService2, with the exception
    * of related ChangeIssueIfc objects.
    *
    * This method should be called rather than calling the Persistence Manager
    * delete method directly.
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @param     cr
    * @return    ChangeRequestIfc
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public ChangeRequestIfc deleteChangeRequest( ChangeRequestIfc cr )
            throws WTException, ChangeException2;

   /**
    * Delete the FormalizedByIfc relationship implied by the two arguments.
    *  The concrete subclasses of the ChangeRequestIfc, the ChangeIssueIfc
    * and the FormalizedByIfc relationship must already be Persistent.
    *
    * In the event there is no FormalizedByIfc (the two objects passed in
    * are not related) then there will be no exception generated, instead
    * a null will be returned.
    *
    * If the provided ChangeRequesetIfc and ChangeIssueIfc are flexible change
    * objects, then rather than deleting the FormalizedByIfc, it will delete the 
    * related flexible process association.  If this occurs, then there is no 
    * FormalizedByIfc to return and therefore it will return null.
    *
    * @deprecated The FormalizedBy link was replaced by ChangeProcessLink in 11.0.  
    * It is recommended to use the FlexibleChangeService to perform deletes. 
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @param     cr
    * @param     ci
    * @return    FormalizedByIfc
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/
   @Deprecated
   public FormalizedByIfc deleteFormalizedBy( ChangeRequestIfc cr, ChangeIssueIfc ci )
            throws WTException, ChangeException2;

   /**
    * Delete the RelevantAnalysisData relationship only.  The AnalysisActivityIfc
    * object and Changeable2 object that the RelevantAnalysisData relationship
    * links together will still both exist after the relationship is deleted.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see RelevantAnalysisData
    * @see AnalysisActivityIfc
    * @see Changeable2
    *
    * @param     rad
    * @return    RelevantAnalysisData
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public RelevantAnalysisData deleteRelevantAnalysisData( RelevantAnalysisData rad )
            throws WTException, ChangeException2;

   /**
    * Deletes the concrete subclass of ChangeReviewIfc from the database.
    *
    * The associated (or relevant) ChangeReviewItemLinkIfc concrete associations
    * will be deleted by the Persistence Manager.
    *
    * This method should be called rather than calling the Persistence Manager
    * delete method directly.
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @param     cr
    * @return    ChangeReviewIfc
    * @exception wt.change2.ChangeException2
    * @exception wt.util.WTException
    **/

   public ChangeReviewIfc deleteChangeReview( ChangeReviewIfc cr )
            throws ChangeException2, WTException;

   /**
    * Returns a QueryResult of ChangeActivity2 objects related to the given
    * Changeable2 object by the AffectedActivityData association.  These
    * Changeable2 objects represent revisions that need to be changed as
    * part of the change process
    *
    * If onlyChangeActivities is true, the QueryResult returned contains
    * a set of ChangeActivity2 objects. <p>  If onyChangeActivities is false,
    * the QueryResult returned contains a set of AffectedActivityData link
    * objects that have references to the Changeable objects.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see WTChangeActivity2
    * @see Changeable2
    *
    * @param     changeable
    * @param     onlyChangeActivities
    * @return    QueryResult
    * @exception wt.change2.ChangeException2
    * @exception wt.util.WTException
    **/

   public QueryResult getAffectingChangeActivities( Changeable2 changeable, boolean onlyChangeActivities )
            throws ChangeException2, WTException;

   /**
    * Returns a QueryResult of ChangeActivity2 objects related to the given
    * Changeable2 object by the AffectedActivityData association.  These
    * Changeable2 objects represent revisions that need to be changed as
    * part of the change process.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see WTChangeActivity2
    * @see Changeable2
    *
    * @param     changeable
    * @return    QueryResult
    * @exception wt.change2.ChangeException2
    * @exception wt.util.WTException
    **/

   public QueryResult getAffectingChangeActivities( Changeable2 changeable )
            throws ChangeException2, WTException;

   /**
    * Retrieves the AnalysisActivity objects related to the given Changeable2
    * object by the RelevantAnalysisData association.  These Changeable2
    * objects represent revisions that are important for the completion
    * of a particular AnalysisActivity.
    *
    * If onlyAnalysisActivities is true, the QueryResult returned contains
    * a set of AnalysisActivity objects. <p>  If onlyAnalysisActivities
    * is false, the QueryResult returned contains a set of RelevantAnalysisData
    * link objects that have references to the Changeable objects.
    *
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see WTChangeInvestigation
    * @see Changeable2
    *
    * @param     changeable
    * @param     onlyAnalysisActivities
    * @return    QueryResult
    * @exception wt.change2.ChangeException2
    * @exception wt.util.WTException
    **/

   public QueryResult getAnalysisActivities( Changeable2 changeable, boolean onlyAnalysisActivities )
            throws ChangeException2, WTException;

   /**
    * Retrieves the AnalysisActivity objects related to the given Changeable2
    * object by the RelevantAnalysisData association.  These Changeable2
    * objects represent revisions that are important for the completion
    * of a particular AnalysisActivity.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see WTChangeInvestigation
    * @see Changeable2
    *
    * @param     changeable
    * @return    QueryResult
    * @exception wt.change2.ChangeException2
    * @exception wt.util.WTException
    **/

   public QueryResult getAnalysisActivities( Changeable2 changeable )
            throws ChangeException2, WTException;

   /**
    * Retrieves the AnalysisActivityIfc objects related to the given ChangeAnalysisIfc
    * object by the DetailedByIfc association.  These AnalysisActivityIfc
    * objects represent activies that part of the particular ChangeAnalysisIfc.
    *
    * The QueryResult returned contains a set of AnalysisActivityIfc objects,
    * not a set of DetailedByIfc link objects that have references to the
    * ChangeAnalysisIfc objects.  Use the two parameter version of this
    * method to return the DetailedByIfc link objects.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see AnalysisActivityIfc
    * @see AnalysisActivityIfc
    * @see DetailedByIfc
    *
    * @param     ca
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getAnalysisActivities( ChangeAnalysisIfc ca )
            throws WTException, ChangeException2;

   /**
    * Retrieves the AnalysisActivityIfc objects related to the given ChangeAnalysisIfc
    * object by the DetailedByIfc association.  These AnalysisActivityIfc
    * objects represent investigations that are important for the completion
    * of a particular ChangeAnalysisIfc.
    *
    * If onlyAnalysisActivities is true, the QueryResult returned contains
    * a set of AnalysisActivityIfc objects. <p>  If onlyAnalysisActivities
    * is false, the QueryResult returned contains a set of DetailedByIfc
    * link objects that have references to the AnalysisActivityIfc objects.
    *
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see AnalysisActivityIfc
    * @see ChangeAnalysisIfc
    * @see DetailedByIfc
    *
    * @param     ca
    * @param     onlyAnalysisActivities
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getAnalysisActivities( ChangeAnalysisIfc ca, boolean onlyAnalysisActivities )
            throws WTException, ChangeException2;

   /**
    * Retrieves the Changeable2 objects related to the given AnalysisActivityIfc
    * object by the ResearchedByIfc association.  These Changeable2 objects
    * represent changeables that are relevant to the completion of a particular
    * AnalysisActivityIfc.
    *
    * The QueryResult returned contains a set of Changeable2 objects, not
    * a set of RelevantAnalysisData link objects that have references to
    * the Changeable2 objects.  There is another method that contains the
    * RelevantAnalysisData link objects.
    *
    * Get the working copy if the current user was the one who checked it
    * out, otherwise get the checked out copy.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see Changeable2
    * @see AnalysisActivityIfc
    * @see RelevantAnalysisData
    *
    * @param     aa
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/
   public QueryResult getChangeables( AnalysisActivityIfc aa )
            throws WTException, ChangeException2;

   /**
    * Retrieves the Changeable2 objects related to the given AnalysisActivityIfc
    * object by the RelevantAnalysisData association.  These Changeable2
    * objects represent investigations that are important for the completion
    * of a particular AnalysisActivityIfc.
    *
    * If onlyChangeables is true, the QueryResult returned contains a set
    * of Changeable2 objects. <p>  If onlyChangeables is false, the QueryResult
    * returned contains a set of RelevantAnalysisData link objects that
    * have references to the Changeable2 objects.
    *
    * Get the working copy if the current user was the one who checked it
    * out, otherwise get the checked out copy.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see Changeable2
    * @see AnalysisActivityIfc
    * @see RelevantAnalysisData
    *
    * @param     aa
    * @param     onlyChangeables
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/
   public QueryResult getChangeables( AnalysisActivityIfc aa, boolean onlyChangeables )
            throws WTException, ChangeException2;

   /**
    * Retrieves the Changeable2 objects related to the given ChangeRequestIfc
    * object by the RelevantRequestDataIfc association.  These Changeable2
    * objects represent additional documentation for the Change Request.
    *
    * The QueryResult returned contains a set of Changeable2 objects, not
    * a set of RelevantAnalysisData link objects that have references to
    * the Changeable2 objects.  There is another method that contains the
    * RelevantAnalysisData link objects.
    *
    * Get the working copy if the current user was the one who checked it
    * out, otherwise get the checked out copy.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see Changeable2
    * @see ChangeRequestIfc
    * @see RelevantRequestData2
    *
    * @param     cr
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/
   public QueryResult getChangeables( ChangeRequestIfc cr )
            throws WTException, ChangeException2;

   /**
    * Retrieves the Changeable2 objects related to the given ChangeRequestIfc
    * object by the RelevantRequestDataIfc association.  These Changeable2
    * objects represent additional documentation for the Change Request.
    *
    * If onlyChangeables is true, the QueryResult returned contains a set
    * of Changeable2 objects. <p>  If onlyChangeables is false, the QueryResult
    * returned contains a set of RelevantRequestDataIfc link objects that
    * have references to the Changeable2 objects.
    *
    * Get the working copy if the current user was the one who checked it
    * out, otherwise get the checked out copy.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see Changeable2
    * @see ChangeRequestIfc
    * @see RelevantRequestData2
    *
    * @param     cr
    * @param     onlyChangeables
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/
   public QueryResult getChangeables( ChangeRequestIfc cr, boolean onlyChangeables )
            throws WTException, ChangeException2;

   /**
    * Retrieves the Changeable2 objects related to the given ChangeActivityIfc
    * object by the ChangeRecord2 association.  These Changeable2 objects
    * represent changeables that have been changed to implement the ChangeActivityIfc.
    *
    * The changeables returned are only the latest iterations (wt.vc.VersionControlHelper.getSearchCondition
    * is used to do this) and then only the items that the user is allowed
    * to see are returned (wt.vc.config.MultipleLatestConfigSpec.process
    * is used to do this).
    *
    * The QueryResult returned contains a set of Changeable2 objects, not
    * a set of ChangeRecord2 link objects that have references to the Changeable2
    * objects.  There is another method that contains the ChangeRecord2
    * link objects.
    *
    * Get the working copy if the current user was the one who checked it
    * out, otherwise get the checked out copy.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see Changeable2
    * @see ChangeActivityIfc
    * @see ChangeRecord2
    * @see wt.vc.VersionControlHelper
    * @see wt.vc.config.MultipleLatestConfigSpec
    *
    * @param     ca
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getChangeablesAfter( ChangeActivityIfc ca )
            throws WTException, ChangeException2;

   /**
    * Retrieves the Changeable2 objects related to the given ChangeActivityIfc
    * object by the ChangeRecord2 association.  These Changeable2 objects
    * represent changeables that have been changed to implement the ChangeActivityIfc.
    *
    * The changeables returned are only the latest iterations (wt.vc.VersionControlHelper.getSearchCondition
    * is used to do this) and then only the items that the user is allowed
    * to see are returned (wt.vc.config.MultipleLatestConfigSpec.process
    * is used to do this).
    *
    * If onlyChangeables is true, the QueryResult returned contains a set
    * of Changeable2 objects. <p>  If onlyChangeables is false, the QueryResult
    * returned contains a set of ChangeRecord2 link objects that have references
    * to the Changeable2 objects.
    *
    * Get the working copy if the current user was the one who checked it
    * out, otherwise get the checked out copy.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see Changeable2
    * @see ChangeActivityIfc
    * @see ChangeRecord2
    *
    * @param     ca
    * @param     onlyChangeables
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getChangeablesAfter( ChangeActivityIfc ca, boolean onlyChangeables )
            throws WTException, ChangeException2;

   /**
    * Retrieves the Changeable2 objects related to the given ChangeOrderIfc
    * object through its IncludedInIfc association with its ChangeActivityIfc
    * and then by their ChangeRecord2 associations.  These Changeable2 objects
    * represent changeables that have been affected by the implementation
    * of the ChangeOrderIfc.
    *
    * The changeables returned are only the latest iterations (wt.vc.VersionControlHelper.getSearchCondition
    * is used to do this) and then only the items that the user is allowed
    * to see are returned (wt.vc.config.MultipleLatestConfigSpec.process
    * is used to do this).
    *
    * The QueryResult returned contains a set of Changeable2 objects, not
    * a set of ChangeRecord2 link objects that have references to the Changeable2
    * objects.  There is another method that contains the ChangeRecord2
    * link objects.
    *
    * Get the working copy if the current user was the one who checked it
    * out, otherwise get the checked out copy.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see Changeable2
    * @see ChangeOrderIfc
    * @see ChangeActivityIfc
    * @see IncludedInIfc
    * @see ChangeRecord2
    *
    * @param     co
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getChangeablesAfter( ChangeOrderIfc co )
            throws WTException, ChangeException2;

   /**
    * Retrieves the Changeable2 objects related to the given ChangeOrderIfc
    * object through its IncludedInIfc associations with its ChangeActivityIfc
    * object and then by their ChangeRecord2 associations.  These Changeable2
    * objects represent changeables that have been changed to implement
    * the ChangeOrderIfc.
    *
    * The changeables returned are only the latest iterations (wt.vc.VersionControlHelper.getSearchCondition
    * is used to do this) and then only the items that the user is allowed
    * to see are returned (wt.vc.config.MultipleLatestConfigSpec.process
    * is used to do this).
    *
    * If onlyChangeables is true, the QueryResult returned contains a set
    * of Changeable2 objects. <p>  If onlyChangeables is false, the QueryResult
    * returned contains a set of ChangeRecord2 link objects that have references
    * to the Changeable2 objects.
    *
    * Get the working copy if the current user was the one who checked it
    * out, otherwise get the checked out copy.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see Changeable2
    * @see ChangeOrderIfc
    * @see ChangeActivityIfc
    * @see IncludedInIfc
    * @see ChangeRecord2
    *
    * @param     co
    * @param     onlyChangeables
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getChangeablesAfter( ChangeOrderIfc co, boolean onlyChangeables )
            throws WTException, ChangeException2;

   /**
    * Retrieves the Changeable2 objects related to the given ChangeActivityIfc
    * object by the AffectedActivityData association.  These Changeable2
    * objects represent changeables that may need to be changed for the
    * completion of a particular ChangeActivityIfc.
    *
    * The QueryResult returned contains a set of Changeable2 objects, not
    * a set of AffectedActivityData link objects that have references to
    * the Changeable2 objects.  There is another method that contains the
    * AffectedActivityData link objects.
    *
    * Get the working copy if the current user was the one who checked it
    * out, otherwise get the checked out copy.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see Changeable2
    * @see ChangeActivityIfc
    * @see AffectedActivityData
    *
    * @param     ca
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getChangeablesBefore( ChangeActivityIfc ca )
            throws WTException, ChangeException2;

   /**
    * Retrieves the Changeable2 objects related to the given ChangeActivityIfc
    * object by the AffectedActivityData association.  These Changeable2
    * objects represent changeables that are may need to be changed for
    * the completion of a particular ChangeActivityIfc.
    *
    * If onlyChangeables is true, the QueryResult returned contains a set
    * of Changeable2 objects. <p>  If onlyChangeables is false, the QueryResult
    * returned contains a set of AffectedActivityData link objects that
    * have references to the Changeable2 objects.
    *
    * Get the working copy if the current user was the one who checked it
    * out, otherwise get the checked out copy.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see Changeable2
    * @see ChangeActivityIfc
    * @see AffectedActivityData
    *
    * @param     ca
    * @param     onlyChangeables
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getChangeablesBefore( ChangeActivityIfc ca, boolean onlyChangeables )
            throws WTException, ChangeException2;

   /**
    * Retrieves the Changeable2 objects related to the given ChangeOrderIfc
    * object through the IncludedInIfc association with each of its ChangeActivityIfc
    * objects and then by their AffectedActivityData association.  These
    * Changeable2 objects represent changeables that may be affected by
    * the completion of a particular ChangeOrderIfc.
    *
    * The QueryResult returned contains a set of Changeable2 objects, not
    * a set of AffectedActivityData link objects that have references to
    * the Changeable2 objects.  There is another method that contains the
    * AffectedActivityData link objects.
    *
    * Get the working copy if the current user was the one who checked it
    * out, otherwise get the checked out copy.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see Changeable2
    * @see ChangeOrderIfc
    * @see ChangeActivityIfc
    * @see IncludedInIfc
    * @see AffectedActivityData
    *
    * @param     co
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getChangeablesBefore( ChangeOrderIfc co )
            throws WTException, ChangeException2;

   /**
    * Retrieves the Changeable2 objects related to the given ChangeOrderIfc
    * object through the IncludedInIfc association of each of its ChangeActivityIfc
    * object and then by their AffectedActivityData associations.  These
    * Changeable2 objects represent changeables that are may be affected
    * by the completion of a particular ChangeOrderIfc.
    *
    * If onlyChangeables is true, the QueryResult returned contains a set
    * of Changeable2 objects. <p>  If onlyChangeables is false, the QueryResult
    * returned contains a set of AffectedActivityData link objects that
    * have references to the Changeable2 objects.
    *
    * Get the working copy if the current user was the one who checked it
    * out, otherwise get the checked out copy.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see Changeable2
    * @see ChangeOrderIfc
    * @see ChangeActivityIfc
    * @see IncludedInIfc
    * @see AffectedActivityData
    *
    * @param     co
    * @param     onlyChangeables
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getChangeablesBefore( ChangeOrderIfc co, boolean onlyChangeables )
            throws WTException, ChangeException2;

	/**
	 * Given the map of change task keys and collection of resulting object
	 * values, returns either the affected objects or affected object links that
	 * have the same change task and master reference. If onlyChangeables is
	 * true then returns affected objects.
	 *
	 * <BR>
	 * <BR>
	 * <B>Supported API: </B>true
	 *
	 * @param taskToResultingObjectMap
	 *            expected key is a change task and value is a collection of
	 *            resulting objects.
	 *
	 * @param onlyChangeables
	 * @return a collection of affected links or affected objects
	 * @throws WTException
	 */
	public WTCollection getChangeablesBefore(WTKeyedMap taskToResultingObjsMap,
			boolean onlyChangeables) throws WTException;

   /**
    * Retrieves the ChangeActivityIfc objects related to the given ChangeOrderIfc
    * object by the IncludedInIfc association.  These ChangeActivityIfc objects
    * represent activies that part of the particular ChangeOrderIfc
    *
    * The QueryResult returned contains a set of ChangeActivityIfc objects,
    * not a set of IncludedInIfc link objects that have references to the
    * ChangeOrderIfc objects.  Use the two parameter version of this method
    * to return the IncludedInIfc link objects.
    *
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see ChangeActivityIfc
    * @see ChangeOrderIfc
    * @see IncludedInIfc
    *
    * @param     co
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getChangeActivities( ChangeOrderIfc co )
            throws WTException, ChangeException2;

   /**
    * Retrieves the ChangeActivityIfc objects related to the given ChangeOrderIfc
    * object by the IncludedInIfc association.  These ChangeActivityIfc objects
    * represent investigations that are important for the completion of
    * a particular ChangeOrderIfc.
    *
    * If onlyChangeActivities is true, the QueryResult returned contains
    * a set of ChangeActivityIfc objects. <p>  If onlyChangeActivities is
    * false, the QueryResult returned contains a set of IncludedInIfc link
    * objects that have references to the ChangeActivityIfc objects.
    *
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see ChangeActivityIfc
    * @see ChangeOrderIfc
    * @see IncludedInIfc
    *
    * @param     co
    * @param     onlyChangeActivities
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getChangeActivities( ChangeOrderIfc co, boolean onlyChangeActivities )
            throws WTException, ChangeException2;

   /**
    * Retrieves the ChangeInvestigationIfc objects related to the given
    * ChangeRequestIfc object by the ResearchedByIfc association.  These
    * ChangeInvestigationIfc objects represent investigations that are important
    * for the completion of a particular ChangeRequestIfc.
    *
    * The QueryResult returned contains a set of ChangeInvestigationIfc
    * objects, not a set of ResearchedByIfc link objects that have references
    * to the ChangeRequestIfc objects.  Use the two parameter version of
    * this method to return the ResearchedByIfc link objects.
    *
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see ChangeInvestigationIfc
    * @see ChangeRequestIfc
    * @see ResearchedByIfc
    *
    * @param     cr
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getChangeInvestigations( ChangeRequestIfc cr )
            throws WTException, ChangeException2;

   /**
    * Retrieves the ChangeInvestigationIfc objects related to the given
    * ChangeRequestIfc object by the ResearchedByIfc association.  These
    * ChangeInvestigationIfc objects represent investigations that are important
    * for the completion of a particular ChangeRequestIfc.
    *
    * If onlyChangeRequests is true, the QueryResult returned contains a
    * set of ChangeInvestigationIfc objects. <p>  If onlyChangeRequests
    * is false, the QueryResult returned contains a set of ResearchedByIfc
    * link objects that have references to the ChangeInvestigationIfc objects.
    *
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see ChangeInvestigationIfc
    * @see ChangeRequestIfc
    * @see ResearchedByIfc
    *
    * @param     cr
    * @param     onlyChangeInvestigations
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getChangeInvestigations( ChangeRequestIfc cr, boolean onlyChangeInvestigations )
            throws WTException, ChangeException2;

   /**
    * Retrieves the ChangeIssueIfc objects related to the given ChangeRequestIfc
    * object by the FormalizedByIfc association.  These ChangeIssueIfc objects
    * represent issues that will formally be addressed by the particular
    * ChangeRequestIfc.
    *
    * If the given ChangeRequestIfc is a flexible change object, then it will 
    * invoke the FlexibleChangeService and return the related flexible process
    * associations.
    *
    * The QueryResult returned contains a set of ChangeIssueIfc objects,
    * not a set of FormalizedByIfc link objects that have references to
    * the ChangeRequestIfc objects.  Use the two parameter version of this
    * method to return the FormalizedByIfc link objects.
    *
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see ChangeIssueIfc
    * @see ChangeRequestIfc
    * @see FormalizedByIfc
    *
    * @param     cr
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getChangeIssues( ChangeRequestIfc cr )
            throws WTException, ChangeException2;

   /**
     * Retrieves all versions of <code>ChangeIssueIfc</code> objects related
     * to the provided version of the <code>ChangeActivityIfc</code> object by
     * the <code>IssueImplementedByIfc</code> association. These
     * <code>ChangeIssueIfc</code> objects represent issues that will be
     * implemented by the particular <code>ChangeActivityIfc</code>.
     *
     * The QueryResult returned contains a set of <code>ChangeIssueIfc</code>
     * objects.
     *
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>true
     *
     * @see ChangeIssueIfc
     * @see ChangeActivityIfc
     * @see IssueImplementedByIfc
     *
     * @param changeActivity
     * @return QueryResult
     * @exception wt.util.WTException
     * @exception wt.change2.ChangeException2
     */
   public QueryResult getChangeIssues(ChangeActivityIfc changeActivity) throws WTException, ChangeException2;

   /**
     * Retrieves the ChangeIssueIfc objects related to the given
     * ChangeRequestIfc object by the FormalizedByIfc association. These
     * ChangeIssueIfc objects represent investigations that are important for
     * the completion of a particular ChangeRequestIfc.
     *
     * If the given ChangeRequestIfc is a flexible change object, then it will 
     * invoke the FlexibleChangeService and return the related flexible process
     * associations.
     *
     * If onlyChangeIssues is true, the QueryResult returned contains a set of
     * ChangeIssueIfc objects.
     * <p>
     * If onlyChangeIssues is false, the QueryResult returned contains a set of
     * FormalizedByIfc link objects that have references to the ChangeIssueIfc
     * objects.
     *
     *
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>true
     *
     * @see ChangeIssueIfc
     * @see ChangeRequestIfc
     * @see FormalizedByIfc
     *
     * @param cr
     * @param onlyChangeIssues
     * @return QueryResult
     * @exception wt.util.WTException
     * @exception wt.change2.ChangeException2
     */

   public QueryResult getChangeIssues( ChangeRequestIfc cr, boolean onlyChangeIssues )
            throws WTException, ChangeException2;

   /**
    * Retrieves the ChangeOrderIfc objects related to the given ChangeRequestIfc
    * object by the AddressedByIfc association.  These ChangeOrderIfc objects
    * represent orders that will implement the particular ChangeRequestIfc.
    * 
    * If the given ChangeRequestIfc is a flexible change object, then it will 
    * invoke the FlexibleChangeService and return the related flexible process
    * associations.
    *
    * The QueryResult returned contains a set of ChangeOrderIfc objects,
    * not a set of AddressedByIfc link objects that have references to the
    * ChangeRequestIfc objects.  Use the two parameter version of this method
    * to return the AddressedByIfc link objects.
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see ChangeOrderIfc
    * @see ChangeRequestIfc
    * @see AddressedByIfc
    *
    * @param     cr
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getChangeOrders( ChangeRequestIfc cr )
            throws WTException, ChangeException2;

   /**
    * Retrieves the ChangeOrderIfc objects related to the given ChangeRequestIfc
    * object by the AddressedByIfc association.  These ChangeOrderIfc objects
    * represent investigations that implement the completion of a particular
    * ChangeRequestIfc.
    * 
    * If the given ChangeRequestIfc is a flexible change object, then it will 
    * invoke the FlexibleChangeService and return the related flexible process
    * associations.
    *
    * If onlyChangeOrders is true, the QueryResult returned contains a set
    * of ChangeOrderIfc objects. <p>  If onlyChangeOrders is false, the
    * QueryResult returned contains a set of AddressedByIfc link objects
    * that have references to the ChangeOrderIfc objects.
    *
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see ChangeOrderIfc
    * @see ChangeRequestIfc
    * @see AddressedByIfc
    *
    * @param     cr
    * @param     onlyChangeOrders
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getChangeOrders( ChangeRequestIfc cr, boolean onlyChangeOrders )
            throws WTException, ChangeException2;

   /**
    * Retrieves all versions of <code>ChangeOrderIfc</code> objects related
    * to the provided version of the <code>ChangeIssueIfc</code> object by
    * the <code>IssueImplementedByIfc</code> association.
    *
    * The QueryResult returned contains a set of <code>ChangeOrderIfc</code>
    * objects.
    *
    * <BR>
    * <BR>
    * <B>Supported API: </B>true
    *
    * @see ChangeIssueIfc
    * @see ChangeOrderIfc
    * @see IssueImplementedByIfc
    *
    * @param changeIssue
    * @return QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    */
   public QueryResult getChangeOrders(ChangeIssueIfc changeIssue) throws WTException, ChangeException2;

   /**
    * Retrieves the ChangeProposalIfc objects related to the given ChangeRequestIfc
    * object by the ResearchedByIfc association.  These ChangeProposalIfc
    * objects represent proposals that are proposed for the completion of
    * a particular ChangeRequestIfc.
    *
    * The QueryResult returned contains a set of ChangeProposalIfc objects,
    * not a set of ResearchedByIfc link objects that have references to
    * the ChangeRequestIfc objects.  Use the two parameter version of this
    * method to return the ResearchedByIfc link objects.
    *
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see ChangeProposalIfc
    * @see ChangeRequestIfc
    * @see ResearchedByIfc
    *
    * @param     cr
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getChangeProposals( ChangeRequestIfc cr )
            throws WTException, ChangeException2;

   /**
    * Retrieves the ChangeProposalIfc objects related to the given ChangeRequestIfc
    * object by the ResearchedByIfc association.  These ChangeProposalIfc
    * objects represent investigations that are important for the completion
    * of a particular ChangeRequestIfc.
    *
    * If onlyChangeProposals is true, the QueryResult returned contains
    * a set of ChangeProposalIfc objects. <p>  If onlyChangeProposals is
    * false, the QueryResult returned contains a set of ResearchedByIfc
    * link objects that have references to the ChangeProposalIfc objects.
    *
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see ChangeProposalIfc
    * @see ChangeRequestIfc
    * @see ResearchedByIfc
    *
    * @param     cr
    * @param     onlyChangeProposals
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getChangeProposals( ChangeRequestIfc cr, boolean onlyChangeProposals )
            throws WTException, ChangeException2;

   /**
    * Retrieves the ChangeRequest2 object that formalizes the given ChangeIssue
    * object.
    *
    * If the given ChangeIssue is a flexible change object, then it will 
    * invoke the FlexibleChangeService and return the related flexible process
    * associations.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see ChangeRequest2
    * @see ChangeIssue
    *
    * @param     ci
    * @return    ChangeRequest2
    * @exception wt.change2.ChangeException2
    * @exception wt.util.WTException
    **/

   public ChangeRequest2 getFormalizingChangeRequest( ChangeIssue ci )
            throws ChangeException2, WTException;

   /**
    * Returns a QueryResult of ChangeActivity2 objects related to the given
    * Changeable2 object by the ChangeRecord2 association.  These Changeable2
    * objects represent revisions that have been changed as part of the
    * change process
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see WTChangeActivity2
    * @see Changeable2
    *
    * @param     changeable
    * @return    QueryResult
    * @exception wt.change2.ChangeException2
    * @exception wt.util.WTException
    **/

   public QueryResult getImplementedChangeActivities( Changeable2 changeable )
            throws ChangeException2, WTException;

   /**
    * Returns a QueryResult of ChangeActivity2 objects related to the given
    * Changeable2 object by the ChangeRecord2 association.  These Changeable2
    * objects represent revisions that have been changed as part of the
    * change process
    *
    * If onlyChangeActivities is true, the QueryResult returned contains
    * a set of ChangeActivity2 objects. <p>  If onlyChangeActivities is
    * false, the QueryResult returned contains a set of ChangeRecord2 link
    * objects that have references to the Changeable objects.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see WTChangeActivity2
    * @see Changeable2
    *
    * @param     changeable
    * @param     onlyChangeActivities
    * @return    QueryResult
    * @exception wt.change2.ChangeException2
    * @exception wt.util.WTException
    **/

   public QueryResult getImplementedChangeActivities( Changeable2 changeable, boolean onlyChangeActivities )
            throws ChangeException2, WTException;

   /**
    * Creates a new version of the Change Request.
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @param     cr  The Change Request to revise
    * @param     versionLabel  The version label for this revision.
    * @return    ChangeRequestIfc
    * @exception wt.util.WTException
    **/

   public ChangeRequestIfc reviseChangeRequest( ChangeRequestIfc cr, String versionLabel )
            throws WTException;

   /**
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @param     cr
    * @return    ChangeRequestIfc
    * @exception wt.util.WTException
    **/

   public ChangeRequestIfc reviseChangeRequest( ChangeRequestIfc cr )
            throws WTException;

   /**
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @param     ci
    * @param     versionLabel
    * @return    ChangeIssueIfc
    * @exception wt.util.WTException
    **/

   public ChangeIssueIfc reviseChangeIssue( ChangeIssueIfc ci, String versionLabel )
            throws WTException;

   /**
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @param     ci
    * @return    ChangeIssueIfc
    * @exception wt.util.WTException
    **/

   public ChangeIssueIfc reviseChangeIssue( ChangeIssueIfc ci )
            throws WTException;

   /**
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @param     aa
    * @param     versionLabel
    * @return    AnalysisActivityIfc
    * @exception wt.util.WTException
    **/

   public AnalysisActivityIfc reviseAnalysisActivity( AnalysisActivityIfc aa, String versionLabel )
            throws WTException;

   /**
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @param     aa
    * @return    AnalysisActivityIfc
    * @exception wt.util.WTException
    **/

   public AnalysisActivityIfc reviseAnalysisActivity( AnalysisActivityIfc aa )
            throws WTException;

   /**
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @param     ci
    * @param     versionLabel
    * @return    ChangeInvestigationIfc
    * @exception wt.util.WTException
    **/

   public ChangeInvestigationIfc reviseChangeInvestigation( ChangeInvestigationIfc ci, String versionLabel )
            throws WTException;

   /**
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @param     ci
    * @return    ChangeInvestigationIfc
    * @exception wt.util.WTException
    **/

   public ChangeInvestigationIfc reviseChangeInvestigation( ChangeInvestigationIfc ci )
            throws WTException;

    /**
     * Will create a new version of the ChangeOrder and ChangeActivities that
     * are passed in. All the change activities passed in will be revised.
     * Revision of <code>WTChangeActivity2</code> is supported only in context
     * if revised with <code>WTChangeOrder2</code>. The passed change activities
     * should be associated to the change order object.
     *
     * If the changeActivities collection is empty or null, only change order object will be revised
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>true
     *
     * @param changeOrder
     *            -Predecessor change notices
     * @param coRevLabel
     *            - Revision Label for the revised <code>WTChangeOrder2</code>
     *            If the value is null, next revision label will be set on the
     *            object.
     * @param changeActivities
     *            - Predecessor change activities map. Key is the
     *            <code>WTChangeActivity2</code> and value is the Revision
     *            Label. If the value is null, next revision label will be set
     *            on the object.
     * @return Map containing key as revised change order and values with revised change activities
     */
	public Map<ChangeOrderIfc,WTSet> reviseChangeOrderWithChangeActivities(ChangeOrderIfc changeOrder, String coRevLabel, WTKeyedMap changeActivities) throws WTException;

   /**
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @param     co
    * @param     versionLabel
    * @return    ChangeOrderIfc
    * @exception wt.util.WTException
    **/

   public ChangeOrderIfc reviseChangeOrder( ChangeOrderIfc co, String versionLabel )
            throws WTException;

   /**
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @param     co
    * @return    ChangeOrderIfc
    * @exception wt.util.WTException
    **/

   public ChangeOrderIfc reviseChangeOrder( ChangeOrderIfc co )
            throws WTException;

   /**
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @param     cp
    * @param     versionLabel
    * @return    ChangeProposalIfc
    * @exception wt.util.WTException
    **/
   public ChangeProposalIfc reviseChangeProposal( ChangeProposalIfc cp, String versionLabel )
            throws WTException;

   /**
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @param     cp
    * @return    ChangeProposalIfc
    * @exception wt.util.WTException
    **/
   public ChangeProposalIfc reviseChangeProposal( ChangeProposalIfc cp )
            throws WTException;

   /**
    * Stores the given concrete subclass of AnalysisActivityIfc in the database
    * and associates it to the given ChangeAnalysisIfc; the ChangeAnalysisIfc
    * must be persistent already.
    *
    * If the AnalysisActivityIfc object is LifeCycleManaged, this method
    * uses Change2DelegateFactory to get a ChooseLifeCycleDelegate to programatically
    * assign the LifeCycle.
    *
    * If the ChangeAnalysistIfc object is Foldered, this method uses Change2DelegateFactory
    * to get a ChooseFolderDelegate to programatically assign the Folder.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see Change2DelegateFactory
    * @see ChooseLifeCycleDelegate
    * @see ChooseFolderDelegate
    *
    * @param     ca
    * @param     aa
    * @return    AnalysisActivityIfc
    * @exception wt.change2.ChangeException2
    * @exception wt.util.WTException
    **/

   public AnalysisActivityIfc saveAnalysisActivity( ChangeAnalysisIfc ca, AnalysisActivityIfc aa )
            throws ChangeException2, WTException;
   
   /**
    * Stores the given concrete subclass of ChangeActivityIfc in the database and associates it to the given
    * ChangeOrderIfc; the ChangeOrderIfc must be persistent already.
    *
    * If the ChangeActivityIfc object is LifeCycleManaged, this method uses Change2DelegateFactory to get a
    * ChooseLifeCycleDelegate to programatically assign the LifeCycle.
    *
    * If the ChangeActivityIfc object is Foldered, this method uses Change2DelegateFactory to get a
    * ChooseFolderDelegate to programatically assign the Folder.
    *
    * <BR>
    * <BR>
    * <B>Supported API: </B>true
    *
    * @see Change2DelegateFactory
    * @see ChooseLifeCycleDelegate
    * @see ChooseFolderDelegate
    *
    * @param co
    * @param ca
    * @return ChangeActivityIfc
    * @exception wt.change2.ChangeException2
    * @exception wt.util.WTException
    * @deprecated use {@link #saveChangeActivity(ChangeOrderIfc, ChangeActivityIfc, boolean)}
    **/
   @Deprecated
   public ChangeActivityIfc saveChangeActivity(ChangeOrderIfc co, ChangeActivityIfc ca)
           throws ChangeException2, WTException;
   
    /**
     * Stores the given concrete subclass of ChangeActivityIfc in the database and associates it to the given
     * ChangeOrderIfc; the ChangeOrderIfc must be persistent already.
     *
     * If the ChangeActivityIfc object is LifeCycleManaged, this method uses Change2DelegateFactory to get a
     * ChooseLifeCycleDelegate to programatically assign the LifeCycle.
     *
     * If the ChangeActivityIfc object is Foldered, this method uses Change2DelegateFactory to get a
     * ChooseFolderDelegate to programatically assign the Folder.
     *
     * <BR>
     * <BR>
     * The implementation plan association rules can be optionally evaluated using the <code>validate</code> parameter.
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>true
     *
     * @see Change2DelegateFactory
     * @see ChooseLifeCycleDelegate
     * @see ChooseFolderDelegate
     *
     * @param co
     * @param ca
     * @param validate
     *            False to ignore association rule validation
     * @return ChangeActivityIfc
     * @exception wt.change2.ChangeException2
     * @exception wt.util.WTException
     **/

    public ChangeActivityIfc saveChangeActivity(ChangeOrderIfc co, ChangeActivityIfc ca, boolean validate)
            throws ChangeException2, WTException;

    /**
     * Stores the given concrete subclass of ChangeInvestigationIfc in the
     * database and associates it to the given ChangeItemIfc; changeItem
     * must be persistent already.
     *
     * If the ChangeInvestigationIfc object is LifeCycleManaged, this method
     * uses Change2DelegateFactory to get a ChooseLifeCycleDelegate to
     * programatically assign the LifeCycle.
     *
     * If the ChangeInvestigationIfc object is Foldered, this method uses
     * Change2DelegateFactory to get a ChooseFolderDelegate to programatically
     * assign the Folder.
     *
     * The changeItem needs to be a primary change object like ChangeIssue,
     * ChangeOrder2 or ChangeRequest2 to get associated with ChangeInvestigation
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>true
     *
     * @see Change2DelegateFactory
     * @see ChooseLifeCycleDelegate
     * @see ChooseFolderDelegate
     *
     * @param changeItem
     * @param ci
     * @return ChangeInvestigationIfc
     * @exception wt.change2.ChangeException2
     * @exception wt.util.WTException
     **/

   public ChangeInvestigationIfc saveChangeInvestigation( ChangeItemIfc changeItem, ChangeInvestigationIfc ci )
            throws ChangeException2, WTException;

   /**
    * Stores the given concrete subclass of ChangeInvestigationIfc in the database
    *
    * If the ChangeInvestigationIfc object is LifeCycleManaged, this method uses
    * Change2DelegateFactory to get a ChooseLifeCycleDelegate to programatically
    * assign the LifeCycle.
    *
    * If the ChangeInvestigationIfc object is Foldered, this method uses Change2DelegateFactory
    * to get a ChooseFolderDelegate to programatically assign the Folder.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see Change2DelegateFactory
    * @see ChooseLifeCycleDelegate
    * @see ChooseFolderDelegate
    *
    * @param ci
    * @return
    * @throws ChangeException2
    * @throws WTException
    */
   public ChangeInvestigationIfc saveChangeInvestigation(ChangeInvestigationIfc ci) throws ChangeException2, WTException;

   /**
    * Stores the given concrete subclass of ChangeIssueIfc in the database.
    *
    * If the ChangeIssueIfc object is LifeCycleManaged, this method uses
    * Change2DelegateFactory to get a ChooseLifeCycleDelegate to programatically
    * assign the LifeCycle.
    *
    * If the ChangeIssueIfc object is Foldered, this method uses Change2DelegateFactory
    * to get a ChooseFolderDelegate to programatically assign the Folder.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see Change2DelegateFactory
    * @see ChooseLifeCycleDelegate
    * @see ChooseFolderDelegate
    *
    * @param     ci
    * @return    ChangeIssueIfc
    * @exception wt.change2.ChangeException2
    * @exception wt.util.WTException
    **/

   public ChangeIssueIfc saveChangeIssue( ChangeIssueIfc ci )
            throws ChangeException2, WTException;

   /**
    * Stores the given concrete subclass of ChangeOrderIfc in the database
    * and associates it to the given ChangeRequestIfc; theChangeRequestIfc
    * must be persistent already.
    *
    * If the ChangeOrderIfc object is LifeCycleManaged, this method uses
    * Change2DelegateFactory to get a ChooseLifeCycleDelegate to programatically
    * assign the LifeCycle.
    *
    * If the ChangeRequestIfc object is Foldered, this method uses Change2DelegateFactory
    * to get a ChooseFolderDelegate to programatically assign the Folder.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see Change2DelegateFactory
    * @see ChooseLifeCycleDelegate
    * @see ChooseFolderDelegate
    *
    * @param     cr
    * @param     co
    * @return    ChangeOrderIfc
    * @exception wt.change2.ChangeException2
    * @exception wt.util.WTException
    * @deprecated use {@link #saveChangeOrder(ChangeRequestIfc, ChangeOrderIfc, boolean)}
    **/
   @Deprecated
   public ChangeOrderIfc saveChangeOrder( ChangeRequestIfc cr, ChangeOrderIfc co )
            throws ChangeException2, WTException;


   /**
    * Stores the given concrete subclass of ChangeOrderIfc in the database
    * and associates it to the given ChangeRequestIfc; theChangeRequestIfc
    * must be persistent already.
    *
    * If the ChangeOrderIfc object is LifeCycleManaged, this method uses
    * Change2DelegateFactory to get a ChooseLifeCycleDelegate to programatically
    * assign the LifeCycle.
    *
    * If the ChangeRequestIfc object is Foldered, this method uses Change2DelegateFactory
    * to get a ChooseFolderDelegate to programatically assign the Folder.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see Change2DelegateFactory
    * @see ChooseLifeCycleDelegate
    * @see ChooseFolderDelegate
    *
    * @param     cr
    * @param     co
    * @param     validate True to validate association rules
    * @return    ChangeOrderIfc
    * @exception wt.change2.ChangeException2
    * @exception wt.util.WTException
    **/

   public ChangeOrderIfc saveChangeOrder( ChangeRequestIfc cr, ChangeOrderIfc co, boolean validate )
            throws ChangeException2, WTException;
   
   /**
    * Stores the given concrete subclass of ChangeProposalIfc in the database
    * and associates it to the given ChangeRequestIfc; theChangeRequestIfc
    * must be persistent already.
    *
    * If the theChangeRequestIfc object is LifeCycleManaged, this method
    * uses Change2DelegateFactory to get a ChooseLifeCycleDelegate to programatically
    * assign the LifeCycle.
    *
    * If the theChangeRequestIfc object is Foldered, this method uses Change2DelegateFactory
    * to get a ChooseFolderDelegate to programatically assign the Folder.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see Change2DelegateFactory
    * @see ChooseLifeCycleDelegate
    * @see ChooseFolderDelegate
    *
    * @param     cr
    * @param     cp
    * @return    ChangeProposalIfc
    * @exception wt.change2.ChangeException2
    * @exception wt.util.WTException
    **/

   public ChangeProposalIfc saveChangeProposal( ChangeRequestIfc cr, ChangeProposalIfc cp )
            throws ChangeException2, WTException;

   /**
    * Stores the given concrete subclass of ChangeRequestIfc in the database.
    *  If the object is LifeCycleManaged, this method uses Change2DelegateFactory
    * to get a ChooseLifeCycleDelegate to programatically assign the LifeCycle.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see Change2DelegateFactory
    * @see ChooseLifeCycleDelegate
    *
    * @param     cr
    * @return    ChangeRequestIfc
    * @exception wt.change2.ChangeException2
    * @exception wt.util.WTException
    **/

   public ChangeRequestIfc saveChangeRequest( ChangeRequestIfc cr )
            throws ChangeException2, WTException;

   /**
    * Stores the given concrete subclass of FormalizedByIfc in the database.
    * It constructs the FormalizedByIfc based on the ChangeRequestIfc and
    * ChangeIssueIfc objects passed in, using the FormalizedByDelegate. If the
    * provided ChangeRequestIfc and ChangeIssueIfc are both flexible change objects,
    * then this method will store a flexible association based on the defined 
    * Association Rules and will return null.
    *
    * @deprecated The FormalizedBy link was replaced by ChangeProcessLink in 11.0.  
    * It is recommended to use the FlexibleChangeService to create links. 
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see FormalizedByIfc
    * @see ChangeRequestIfc
    * @see ChangeIssueIfc
    * @see FormalizedByDelegate
    *
    * @param     cr
    * @param     ci
    * @return    FormalizedByIfc
    * @exception wt.change2.ChangeException2
    * @exception wt.util.WTException
    **/
   @Deprecated
   public FormalizedByIfc saveFormalizedBy( ChangeRequestIfc cr, ChangeIssueIfc ci )
            throws ChangeException2, WTException;

   /**
     * Save the collection of <code>ChangeIssueIfc</code> objects associated
     * to the <code>ChangeActivityIfc</code> key in the WTKeyedSet where the
     * key is the <code>ChangeActivityIfc</code> and the value is a WTSet of
     * <code>ChangeIssueIfc</code> objects.
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>true
     *
     * @see IssueImplementedByIfc
     * @see ChangeActivityIfc
     * @see ChangeIssueIfc
     * @see IssueImplementedByIfcDelegate
     *
     * @param map
     *            of change activities keys and collection of change issue
     *            values.
     * @return a collection of persisted links
     * @exception wt.change2.ChangeException2
     * @exception wt.util.WTException
     */
   public WTCollection saveIssueImplementedBy(WTKeyedHashMap map) throws ChangeException2, WTException;

   /**
     * Stores all the RelevantAnalysisData objects in the input vector and
     * returns a vector of the persisted (or updated) RelevantAnalysisData
     * objects.
     *
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>true
     *
     * @see RelevantAnalysisData
     *
     * @param radVector
     * @return Vector
     * @exception wt.change2.ChangeException2
     * @exception wt.util.WTException
     */
   @SuppressWarnings("unchecked")
   public Vector saveRelevantAnalysisData( Vector radVector )
            throws ChangeException2, WTException;

   /**
    * Stores all the AffectedActivityData objects in the input vector and
    * returns a vector of the persisted (or updated) AffectedActivityData
    * objects.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see AffectedActivityData
    *
    * @param     aadVector
    * @return    Vector
    * @exception wt.change2.ChangeException2
    * @exception wt.util.WTException
    **/
   @SuppressWarnings("unchecked")
   public Vector saveAffectedActivityData( Vector aadVector )
            throws ChangeException2, WTException;

   /**
    * Stores all the ChangeRecord2 objects in the input vector and returns
    * a vector of the persisted (or updated) ChangeRecord2 objects.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see ChangeRecord2
    *
    * @param     crVector
    * @return    Vector
    * @exception wt.change2.ChangeException2
    * @exception wt.util.WTException
    **/
   @SuppressWarnings("unchecked")
   public Vector saveChangeRecord( Vector crVector )
            throws ChangeException2, WTException;

   /**
    * Stores the given concrete subclass of ChangeReviewIfc in the database.
    *  If the object is LifeCycleManaged, this method uses Change2DelegateFactory
    * to get a ChooseLifeCycleDelegate to programatically assign the LifeCycle.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see Change2DelegateFactory
    * @see ChooseLifeCycleDelegate
    *
    * @param     cr
    * @return    ChangeReviewIfc
    * @exception wt.change2.ChangeException2
    * @exception wt.util.WTException
    **/

   public ChangeReviewIfc saveChangeReview ( ChangeReviewIfc cr )
            throws ChangeException2, WTException;

   /**
    * Retrieves the ChangeRequestIfc object related to the given ChangeIssueIfc
    * object by the FormalizedByIfc association.  These ChangeRequestIfc
    * object represents the request that will formally address the particular
    * ChangeIssueIfc.
    *
    * If the given ChangeIssueIfc is a flexible change object, then it will 
    * invoke the FlexibleChangeService and return the related flexible process
    * associations.
    *
    * The QueryResult returned contains zero or one ChangeRequestIfc object,
    * not zero or one FormalizedByIfc link object that has a reference to
    * the ChangeRequestIfc object.  There is another method that contains
    * the FormalizedByIfc link object.
    *
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see ChangeRequestIfc
    * @see ChangeIssueIfc
    * @see FormalizedByIfc
    *
    * @param     ci
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getChangeRequest( ChangeIssueIfc ci )
            throws WTException, ChangeException2;

   /**
    * Retrieves the ChangeRequestIfc object related to the given ChangeIssueIfc
    * object by the FormalizedByIfc association.  The ChangeRequestIfc object
    * represents the request that formally address the ChangeRequestIfc.
    *
    * If the given ChangeIssueIfc is a flexible change object, then it will 
    * invoke the FlexibleChangeService and return the related flexible process
    * associations.
    *
    * If onlyChangeRequest is true, the QueryResult returned contains zero
    * or one ChangeRequest objects. <p>  If onlyChangeRequest is false,
    * the QueryResult returned contains zero or one FormalizedByIfc link
    * objects that has a reference to the ChangeRequestIfc object.
    *
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see ChangeRequestIfc
    * @see ChangeIssueIfc
    * @see FormalizedByIfc
    *
    * @param     ci
    * @param     onlyChangeRequest
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getChangeRequest( ChangeIssueIfc ci, boolean onlyChangeRequest )
            throws WTException, ChangeException2;

   /**
    * Retrieves the ChangeRequestIfc object related to the given ChangeAnalysisIfc
    * object by the ResearchedByIfc association.  These ChangeRequestIfc
    * object represents the request for which the ChangeAnalysisIfc is performing
    * .
    *
    * The QueryResult returned contains zero or one ChangeRequestIfc object,
    * not zero or one ResearchedByIfc link object that has a reference to
    * the ChangeRequestIfc object.  There is another method that contains
    * the ResearchedByIfc link object.
    *
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see ChangeRequestIfc
    * @see ChangeAnalysisIfc
    * @see ResearchedByIfc
    *
    * @param     ca
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getChangeRequest( ChangeAnalysisIfc ca )
            throws WTException, ChangeException2;

   /**
    * Retrieves the ChangeRequestIfc object related to the given ChangeAnalysisIfc
    * object by the ResearchedByIfc association.  The ChangeRequestIfc object
    * represents the request that formally address the ChangeRequestIfc.
    *
    * If onlyChangeRequest is true, the QueryResult returned contains zero
    * or one ChangeRequest objects. <p>  If onlyChangeRequest is false,
    * the QueryResult returned contains zero or one ResearchedByIfc link
    * objects that has a reference to the ChangeRequestIfc object.
    *
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see ChangeRequestIfc
    * @see ChangeAnalysisIfc
    * @see ResearchedByIfc
    *
    * @param     ca
    * @param     onlyChangeRequest
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getChangeRequest( ChangeAnalysisIfc ca, boolean onlyChangeRequest )
            throws WTException, ChangeException2;

   /**
    * Retrieves the ChangeRequestIfc object related to the given ChangeOrderIfc
    * object by the AddressedByIfc association.  These ChangeRequestIfc object
    * represents the request for which the ChangeOrderIfc is performing
    * .
    *
    * The QueryResult returned contains zero or one ChangeRequestIfc object,
    * not zero or one AddressedByIfc link object that has a reference to
    * the ChangeRequestIfc object.  There is another method that contains
    * the AddressedByIfc link object.
    *
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see ChangeRequestIfc
    * @see ChangeOrderIfc
    * @see AddressedByIfc
    *
    * @param     co
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getChangeRequest( ChangeOrderIfc co )
            throws WTException, ChangeException2;

   /**
    * Retrieves the ChangeRequestIfc object related to the given ChangeOrderIfc
    * object by the AddressedByIfc association.  The ChangeRequestIfc object
    * represents the request that is addressed by the ChangeOrderIfc.
    *
    * If onlyChangeRequest is true, the QueryResult returned contains zero
    * or one ChangeRequest objects. <p>  If onlyChangeRequest is false,
    * the QueryResult returned contains zero or one AddressedByIfc link
    * objects that has a reference to the ChangeRequestIfc object.
    *
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see ChangeRequestIfc
    * @see ChangeOrderIfc
    * @see AddressedByIfc
    *
    * @param     co
    * @param     onlyChangeRequest
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getChangeRequest( ChangeOrderIfc co, boolean onlyChangeRequest )
            throws WTException, ChangeException2;

   /**
    * Retrieves the ChangeAnalysisIfc object related to the given AnalysisActivityIfc
    * object by the DetailedByIfc association.  These ChangeAnalysisIfc object
    * represents the request for which the AnalysisActivityIfc is performing
    * .
    *
    * The QueryResult returned contains zero or one ChangeAnalysisIfc object,
    * not zero or one DetailedByIfc link object that has a reference to
    * the ChangeAnalysisIfc object.  There is another method that contains
    * the DetailedByIfc link object.
    *
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see ChangeAnalysisIfc
    * @see AnalysisActivityIfc
    * @see DetailedByIfc
    *
    * @param     aa
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getChangeAnalysis( AnalysisActivityIfc aa )
            throws WTException, ChangeException2;

   /**
    * Retrieves the ChangeAnalysisIfc object related to the given AnalysisActivityIfc
    * object by the DetailedByIfc association.  The ChangeAnalysisIfc object
    * represents the request that is addressed by the AnalysisActivityIfc.
    *
    * If onlyChangeAnalysis is true, the QueryResult returned contains zero
    * or one ChangeAnalysisIfc objects. <p>  If onlyChangeAnalysis is false,
    * the QueryResult returned contains zero or one DetailedByIfc link objects
    * that has a reference to the ChangeAnalysisIfc object.
    *
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see ChangeAnalysisIfc
    * @see AnalysisActivityIfc
    * @see AddressedByIfc
    *
    * @param     aa
    * @param     onlyChangeAnalysis
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getChangeAnalysis( AnalysisActivityIfc aa, boolean onlyChangeAnalysis )
            throws WTException, ChangeException2;

   /**
    * Retrieves the ChangeOrderIfc object related to the given ChangeActivityIfc
    * object by the IncludedInIfc association.  These ChangeOrderIfc object
    * represents the request for which the ChangeActivityIfc is performing
    * .
    *
    * The QueryResult returned contains zero or one ChangeOrderIfc object,
    * not zero or one IncludedInIfc link object that has a reference to
    * the ChangeOrderIfc object.  There is another method that contains
    * the IncludedInIfc link object.
    *
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see ChangeOrderIfc
    * @see ChangeActivityIfc
    * @see IncludedInIfc
    *
    * @param     ca
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getChangeOrder( ChangeActivityIfc ca )
            throws WTException, ChangeException2;

   /**
    * Retrieves the ChangeOrderIfc object related to the given ChangeActivityIfc
    * object by the IncludedInIfc association.  The ChangeOrderIfc object
    * represents the request that is addressed by the ChangeActivityIfc.
    *
    * If onlyChangeOrder is true, the QueryResult returned contains zero
    * or one ChangeOrderIfc objects. <p>  If onlyChangeOrder is false, the
    * QueryResult returned contains zero or one IncludedInIfc link objects
    * that has a reference to the ChangeOrderIfc object.
    *
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see ChangeOrderIfc
    * @see ChangeActivityIfc
    * @see IncludedInIfc
    *
    * @param     ca
    * @param     onlyChangeActivity
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getChangeOrder( ChangeActivityIfc ca, boolean onlyChangeActivity )
            throws WTException, ChangeException2;

   /**
    * Returns a QueryResult of ChangeActivity2 objects related to the given
    * Changeable2 object by the ChangeRecord2 association.  These Changeable2
    * objects represent revisions that need to be changed as part of the
    * change process
    *
    * If onlyChangeActivities is true, the QueryResult returned contains
    * a set of ChangeActivity2 objects. <p>  If onyChangeActivities is false,
    * the QueryResult returned contains a set of AffectedActivityData link
    * objects that have references to the Changeable objects.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see WTChangeActivity2
    * @see Changeable2
    *
    * @param     changeable
    * @param     onlyChangeActivities
    * @return    QueryResult
    * @exception wt.change2.ChangeException2
    * @exception wt.util.WTException
    * @deprecated use {@link #getImplementedChangeActivities(Changeable2, boolean)}
    **/
   @Deprecated
public QueryResult getChangingChangeActivities( Changeable2 changeable, boolean onlyChangeActivities )
            throws ChangeException2, WTException;

   /**
    * Returns a QueryResult of ChangeActivity2 objects related to the given
    * Changeable2 object by the ChangeRecord2 association.  These Changeable2
    * objects represent revisions that need to be changed as part of the
    * change process
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see WTChangeActivity2
    * @see Changeable2
    *
    * @param     changeable
    * @return    QueryResult
    * @exception wt.change2.ChangeException2
    * @exception wt.util.WTException
     * @deprecated use {@link #getImplementedChangeActivities(Changeable2)}
    **/
   @Deprecated
public QueryResult getChangingChangeActivities( Changeable2 changeable )
            throws ChangeException2, WTException;

   /**
    * Retrieves the ChangeItem object that corresponds to the given Class
    * and id.  Uses ObjectIdentifier and PersistenceHelper.
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @param     theClass
    * @param     id
    * @return    ChangeItem
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/
   @SuppressWarnings("unchecked")
   public ChangeItem getChangeItem( Class theClass, long id )
            throws WTException, ChangeException2;

    /**
     * Creates and stores the correct association object type between the
     * ChangeItemIfc object and the Changeable2 objects in the input vector and
     * returns a vector of the persisted association objects.
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>true
     *
     * @param theClass
     * @param ci
     * @param changeables
     * @return Vector
     * @exception wt.change2.ChangeException2
     * @exception wt.util.WTException
     **/
   @SuppressWarnings("unchecked")
   public Vector storeAssociations( Class theClass, ChangeItemIfc ci, Vector changeables )
            throws ChangeException2, WTException;

   /**
    * Stores the association objects for the given change item.
    *
    * <BR>
    * <BR>
    * <B>Supported API: </B>true
    *
    * @param changeItem
    * @param links
    * @return collection of persisted links
    * @exception wt.change2.ChangeException2
    * @exception wt.util.WTException
    **/
  public WTCollection storeAssociations( ChangeItemIfc changeItem, WTCollection links )
           throws ChangeException2, WTException;

   /**
    * Retrieves the ChangeItem object that corresponds to the given oid.
    *  Uses the ReferenceFactory.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see wt.fc.ReferenceFactory
    *
    * @param     oid
    * @return    ChangeItem
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public ChangeItem getChangeItem( String oid )
            throws WTException, ChangeException2;

   /**
    * Uses Change2DelegateFactory and FindChangeRequestDelegate mechanism
    * to find the change request associated with the object passed in.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see ChangeRequestIfc
    * @see Change2DelegateFactory
    * @see FindChangeRequestDelegate
    *
    * @param     theObject
    * @return    ChangeRequestIfc
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public ChangeRequestIfc findChangeRequest( Object theObject )
            throws WTException, ChangeException2;

   /**
    * Returns a QueryResult of ChangeRequest2 objects related to the given
    * Changeable2 object by the RelevantRequestData2 association.  This
    * association links product data that the user considers relevant to
    * the change request.
    *
    * If onlyChangeRequests is true, the QueryResult returned contains a
    * set of ChangeActivity2 objects. <p>  If onlyChangeRequests is false,
    * the QueryResult returned contains a set of RelevantRequestData2 link
    * objects that have references to the Changeable2 object.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see wt.change2.WTChangeRequest2
    * @see wt.change2.Changeable2
    *
    *
    * @param     changeable
    * @param     onlyChangeRequests
    * @return    QueryResult
    * @exception wt.change2.ChangeException2
    * @exception wt.util.WTException
    **/

   public QueryResult getRelevantChangeRequests( Changeable2 changeable, boolean onlyChangeRequests )
            throws ChangeException2, WTException;

   /**
    * Returns a QueryResult of ChangeRequest2 objects related to the given
    * Changeable2 object by the RelevantRequestData2 association.  This
    * association links product data that the user considers relevant to
    * the change request.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see wt.change2.WTChangeRequest2
    * @see wt.change2.Changeable2
    *
    * @param     changeable
    * @return    QueryResult
    * @exception wt.change2.ChangeException2
    * @exception wt.util.WTException
    **/

   public QueryResult getRelevantChangeRequests( Changeable2 changeable )
            throws ChangeException2, WTException;

   /**
    * Deletes the association between a ChangeItem and a Changeable2.  Also
    * removes the associated working copy if the Changeable2 is checked
    * out.
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @param     refObject  A Changeable2 object to be disassociatd from a ChangeItem.
    * @param     changeItem  The ChangeItem associated to the Changeable2.
    * @param     linkClass  The associated link Class, which has a ChangeItem as role A.
    * @param     changeRole  The role name.
    * @exception wt.change2.ChangeException2
    * @exception wt.util.WTException
    **/
   @SuppressWarnings("unchecked")
   public void unattachChangeable( Changeable2 refObject, ChangeItem changeItem, Class linkClass, String changeRole )
            throws ChangeException2, WTException;

   /**
    * Retrieves the WTPartMaster objects related to the given ChangeRequestIfc
    * object by the SubjectProductIfc association.  These WTPartMaster objects
    * represent additional documentation for the Change Request.
    *
    * The QueryResult returned contains a set of WTPartMaster objects, not
    * a set of SubjectProduct link objects that have references to the WTPartMaster
    * objects.  There is another method that contains the SubjectProduct
    * link objects.
    *
    * Get the working copy if the current user was the one who checked it
    * out, otherwise get the checked out copy.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see WTPartMaster
    * @see ChangeRequestIfc
    * @see SubjectProduct
    *
    * @param     cr
    * @param     onlyProducts
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getSubjectProducts( ChangeRequestIfc cr, boolean onlyProducts )
            throws WTException, ChangeException2;

   /**
    * Retrieves the WTPartMaster objects related to the given ChangeRequestIfc
    * object by the SubjectProductIfc association.  These WTPartMaster objects
    * represent additional documentation for the Change Request.
    *
    * If onlyProducts is true, the QueryResult returned contains a set of
    * WTPartMaster objects. <p>  If onlyProducts is false, the QueryResult
    * returned contains a set of SubjectProductIfc link objects that have
    * references to the WTPartMaster objects.
    *
    * Get the working copy if the current user was the one who checked it
    * out, otherwise get the checked out copy.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see WTPartMaster
    * @see ChangeRequestIfc
    * @see SubjectProduct
    *
    * @param     cr
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getSubjectProducts( ChangeRequestIfc cr )
            throws WTException, ChangeException2;

   /**
    * Deletes the association between a PartMaster and a ChangeRequest.
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @param     refObject  A Changeable2 object to be disassociatd from a ChangeItem.
    * @param     changeItem  The ChangeItem associated to the Changeable2.
    * @param     linkClass  The associated link Class, which has a ChangeItem as role A.
    * @param     changeRole  The role name.
    * @exception wt.change2.ChangeException2
    * @exception wt.util.WTException
    **/
   @SuppressWarnings("unchecked")
   public void unattachProduct( WTPartMaster refObject, ChangeItemIfc changeItem, Class linkClass, String changeRole )
            throws ChangeException2, WTException;

   /**
    * Delete the FormalizedByIfc relationship implied by the three arguments.
    * The concrete subclasses of the ChangeRequestIfc, the ChangeIssueIfc
    * and the FormalizedByIfc relationship must already be persistent.
    *
    * In the event there is no FormalizedByIfc (the change objects passed
    * in are not related) then there will be no exception generated, instead
    * a null will be returned.
    *
    * If the provided ChangeRequesetIfc and ChangeIssueIfc are flexible change
    * objects, then rather than deleting the FormalizedByIfc, it will delete the 
    * related flexible process association.  If this occurs, then there is no 
    * FormalizedByIfc to return and therefore it will return null.
    * 
    * @deprecated The FormalizedBy link was replaced by ChangeProcessLink in 11.0.  
    * It is recommended to use the FlexibleChangeService to perform deletes. 
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @param     linkClass
    * @param     cr
    * @param     ci
    * @return    FormalizedByIfc
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/
   @SuppressWarnings("unchecked")
   @Deprecated
   public FormalizedByIfc deleteFormalizedBy( Class linkClass, ChangeRequestIfc cr, ChangeIssueIfc ci )
            throws WTException, ChangeException2;

   /**
    * Retrieves the Changeable2 objects related to the given ChangeIssueIfc
    * object by the ReportedAgainst association.
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @param     changeIssue
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getChangeables( ChangeIssueIfc changeIssue )
            throws WTException, ChangeException2;

   /**
    * Retrieves the Changeable2 objects related to the given ChangeIssueIfc
    * object by the Reported Against association.
    *
    * If onlyChangeables is true, the QueryResult returned contains a set
    * of Changeable2 objects. <p>  If onlyChangeables is false, the QueryResult
    * returned contains a set of ReportedAgainst link objects that have
    * references to the Changeable2 objects.
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @param     changeIssue
    * @param     onlyChangeables
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getChangeables( ChangeIssueIfc changeIssue, boolean onlyChangeables )
            throws WTException, ChangeException2;

   /**
    * Retrieves the WTPartMaster objects related to the given ChangeIssueIfc
    * object by the ProblemProduct association.
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @param     changeIssue
    * @param     onlyProducts
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getProblemProducts( ChangeIssueIfc changeIssue, boolean onlyProducts )
            throws WTException, ChangeException2;

   /**
    * Retrieves the WTPartMaster objects related to the given ChangeIssueIfc
    * object by the ProblemProduct association.
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @param     changeIssue
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getProblemProducts( ChangeIssueIfc changeIssue )
            throws WTException, ChangeException2;

   /**
    * Delete the AddressedByIfc relationship implied by the two arguments.
    * The concrete subclasses of the ChangeRequestIfc, the ChangeOrderIfc
    * and the AddressedByIfc relationship must already be Persistent.
    *
    * In the event there is no AddressedByIfc (the two objects passed in
    * are not related) then there will be no exception generated, instead
    * a null will be returned.
    * 
    * If the provided ChangeRequesetIfc and ChangeOrderIfc are flexible change
    * objects, then rather than deleting the AddressedByIfc, it will delete the 
    * related flexible process association.  If this occurs, then there is no 
    * AddressedByIfc to return and therefore it will return null.
    *
    * @deprecated The AddressedBy2 link was replaced by ChangeProcessLink in 11.0. 
    * It is recommended to use the FlexibleChangeService to perform deletes.
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @param     cr
    * @param     co
    * @return    AddressedByIfc
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/
   @Deprecated
   public AddressedByIfc deleteAddressedBy( ChangeRequestIfc cr, ChangeOrderIfc co )
            throws WTException, ChangeException2;

   /**
    * Returns a QueryResult of ChangeIssues objects related to the given
    * Changeable2 object by the ReportedAgainst association.
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @param     changeable
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getReportedAgainstChangeIssue( Changeable2 changeable )
            throws WTException, ChangeException2;

   /**
    * Returns a QueryResult of unique ChangeOrder2 objects that are indirectly
    * related to the given Changeable2 object.  This method obtains all
    * ChangeActivity2 objects connected to the given Changeable2 via the
    * ChangeRecord2 association, and then obtains all of the parent ChangeOrder2
    * objects via the IncludedIn2 association.  Finally, the result is filtered
    * to remove duplicates.
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @param     changeable
    * @return    QueryResult
    * @exception wt.change2.ChangeException2
    * @exception wt.util.WTException
    **/

   public QueryResult getUniqueImplementedChangeOrders( Changeable2 changeable )
            throws ChangeException2, WTException;

   /**
    * Returns a QueryResult of unique ChangeOrder2 objects that are indirectly
    * related to the given Changeable2 object. This method obtains all ChangeActivity2
    * objects connected to the given Changeable2 via the AffectedActivityData
    * association, and then obtains all of the parent ChangeOrder2 objects
    * via the IncludedIn2 association.  Finally, the result is filtered
    * to remove duplicates.
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @param     changeable
    * @return    QueryResult
    * @exception wt.change2.ChangeException2
    * @exception wt.util.WTException
    **/

   public QueryResult getUniqueAffectingChangeOrders( Changeable2 changeable )
            throws ChangeException2, WTException;

   /**
    * Stores the given concrete subclass of ResearchedByIfc in the database.
    *  It constructs the ResearchedByIfc based on the ChangeRequestIfc and
    * ChangeProposalIfc objects passed in, using the ResearchedByDelegate.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see ResearchedByIfc
    * @see ChangeRequestIfc
    * @see ChangeProposalIfc
    * @see ResearchedByDelegate
    *
    * @deprecated use {@link #saveResearchedBy(ChangeItemIfc, ChangeAnalysisIfc)
    *
    * @param     cr
    * @param     cp
    * @return    ResearchedByIfc
    * @exception wt.change2.ChangeException2
    * @exception wt.util.WTException
    **/

   @Deprecated
public ResearchedByIfc saveResearchedBy( ChangeRequestIfc cr, ChangeProposalIfc cp )
            throws ChangeException2, WTException;


   /**
    * Stores the given concrete subclass of ResearchedByIfc in the database.
    *  It constructs the ResearchedByIfc based on the ChangeItemIfc and
    * ChangeAnalysisIfc objects passed in, using the ResearchedByDelegate.
    *
    * The ChangeItemIfc is intended to be used with primary change object like ChangeRequest2, ChangeOrder2 or ChangeIssue.    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see ResearchedByIfc
    * @see ChangeItemIfc
    * @see ChangeAnalysisIfc
    * @see ResearchedByDelegate
    *
    *
    * @param     changeItem
    * @param     changeAnalysis
    * @return    ResearchedByIfc
    * @exception wt.change2.ChangeException2
    * @exception wt.util.WTException
    **/

   public ResearchedByIfc saveResearchedBy( ChangeItemIfc changeItem, ChangeAnalysisIfc changeAnalysis )
            throws ChangeException2, WTException;
   /**
    * Stores the given concrete subclass of AddressedByIfc in the database.
    * It constructs the AddresssedByIfc based on the ChangeRequestIfc and
    * ChangeOrderIfc objects passed in, using theAddressedByDelegate.  If the
    * provided ChangeRequestIfc and ChangeOrderIfc are both flexible change objects,
    * then this method will store a flexible association based on the defined 
    * Association Rules and will return null.
    *
    * @deprecated The AddressedBy2 link was replaced by ChangeProcessLink in 11.0. 
    * It is recommended to use the FlexibleChangeService to create links. 
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see AddressedByIfc
    * @see ChangeRequestIfc
    * @see ChangeOrderIfc
    *
    * @param     cr
    * @param     co
    * @return    AddressedByIfc
    * @exception wt.change2.ChangeException2
    * @exception wt.util.WTException
    **/
   @Deprecated
   public AddressedByIfc saveAddressedBy( ChangeRequestIfc cr, ChangeOrderIfc co )
            throws ChangeException2, WTException;

   /**
    * Returns the folder that is 'relevant' for the argument change object.
    *  In the case of a 'primary' change object -- a change issue, change
    * request, or change order -- this is simply the object's folder.  In
    * the case of a 'secondary' change object -- a change analysis, analysis
    * activity, or change activity -- this is the folder of its associated
    * 'primary' change object.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     changeItem
    * @return    Folder
    * @exception wt.util.WTException
    **/

   public Folder getRelevantFolder( ChangeItemIfc changeItem )
            throws WTException;

   /**
    * Queries the database to compute the subset of the argument set of
    * references to persistent Changeable2 objects whose members have variances.
    *  A Changeable2 object has a variance if it is associated with a WTVariance
    * object.
    *
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @return a new set of new wt.fc.ObjectReference objects that is the
    * subset of the argument set whose members reference Changeable2 objects
    * having variances
    *
    * @param     changeable2Refs
    * @exception wt.util.WTException
    **/
   @SuppressWarnings("unchecked")
   public Set filterForVarianceIndicator( Set changeable2Refs )
            throws WTException;

   /**
    * Queries the database to compute whether the argument reference to
    * a persistent Changeable2 object has a pending variance.
    *
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @return true if and only if the argument reference is to a Changeable2
    * object having a pending variance
    *
    * @param     changeable2Ref
    * @exception wt.util.WTException
    **/

   public boolean hasVarianceIndicator( ObjectReference changeable2Ref )
            throws WTException;

   /**
     * Retrieves the links that for the "Affected Object" with dispositions set
     * for the associated "Resulting Objects" of the given change notice.
     * Returns a KeyedMap where the key is the "Resulting Objects" and the
     * values are the "Affected Object" links (@see AffectedActivityData).
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>true
     *
     * @param changeOrder
     *            A change notice object
     * @return WTKeyedMap
     * @exception wt.util.WTException
     */

   public WTKeyedMap getSupportingDispositionLinks(ChangeOrderIfc changeOrder) throws WTException;

   /**
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     *
     * @param changeItem
     * @return WTCollection
     * @exception wt.util.WTException
     * @deprecation Use SupportingMaterialService.getSupportingMaterials( ChangeItem changeItem ) instead
     */
   @Deprecated
   public WTCollection getSupportingMaterials( ChangeItem changeItem )
            throws WTException;

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     changeItem
    * @param     changeable
    * @return    WTCollection
    * @exception wt.util.WTException
    * @deprecation Use SupportingMaterialService.getSupportingMaterials( ChangeItem changeItem, Changeable2 changeable ) instead
    **/
   @Deprecated
   public WTCollection getSupportingMaterials( ChangeItem changeItem, Changeable2 changeable )
            throws WTException;

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     changeItem
    * @param     changeables
    * @return    WTKeyedMap
    * @exception wt.util.WTException
    * @deprecation Use SupportingMaterialService.getSupportingMaterials( ChangeItem changeItem, WTCollection changeables ) instead
    **/
   @Deprecated
   public WTKeyedMap getSupportingMaterials( ChangeItem changeItem, WTCollection changeables )
            throws WTException;

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     changeItem
    * @return    WTCollection
    * @exception wt.util.WTException
    * @deprecation Use SupportingMaterialService.getAnnotationsNotTiedToAffectedData( ChangeItem changeItem ) instead
    **/
   @Deprecated
   public WTCollection getAnnotationsNotTiedToAffectedData( ChangeItem changeItem )
            throws WTException;


   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     supportingMaterials
    * @param     changeItem
    * @param     changeable
    * @return    WTCollection
    * @exception wt.util.WTException
    * @deprecation Use SupportingMaterialService.createSupportingDataForLink( WTCollection supportingMaterials, ChangeItem changeItem, Changeable2 changeable ) instead
    **/
   @Deprecated
   public WTCollection createSupportingDataForLink( WTCollection supportingMaterials, ChangeItem changeItem, Changeable2 changeable )
            throws WTException;

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     supportingMaterials
    * @param     changeItem
    * @exception wt.util.WTException
    * @deprecation Use SupportingMaterialService.unattachSupportingMaterials( WTCollection supportingMaterials, ChangeItem changeItem) instead
    **/
   @Deprecated
   public void unattachSupportingMaterials( WTCollection supportingMaterials, ChangeItem changeItem)
            throws WTException;

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     supportingMaterials
    * @param     changeItem
    * @param     changeable
    * @exception wt.util.WTException
    * @deprecation Use SupportingMaterialService.unattachSupportingMaterials( WTCollection supportingMaterials, ChangeItem changeItem, Changeable2 changeable ) instead
    **/
   @Deprecated
   public void unattachSupportingMaterials( WTCollection supportingMaterials, ChangeItem changeItem, Changeable2 changeable )
            throws WTException;
   
   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     changeItem
    * @param     supportingMaterial
    * @return    WTCollection
    * @exception wt.util.WTException
    * @deprecation Use SupportingMaterialService.getAffectedData( ChangeItem changeItem, SupportingMaterial supportingMaterial ) instead
    **/

   @Deprecated
   public WTCollection getAffectedData( ChangeItem changeItem, SupportingMaterial supportingMaterial )
            throws WTException;

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     changeItem
    * @param     changeables
    * @return    WTCollection
    * @exception wt.util.WTException
    * @deprecation Use SupportingMaterialService.getAffectedDataTiedToAnnotations( ChangeItem changeItem, WTCollection changeables ) instead
    **/
   @Deprecated
   public WTCollection getAffectedDataTiedToAnnotations( ChangeItem changeItem, WTCollection changeables )
            throws WTException;

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     changeItem
    * @param     supportingMaterials
    * @return    WTKeyedMap
    * @exception wt.util.WTException
    * @deprecation Use SupportingMaterialService.getAffectedData( ChangeItem changeItem, WTCollection supportingMaterials ) instead
    **/
   @Deprecated
   public WTKeyedMap getAffectedData( ChangeItem changeItem, WTCollection supportingMaterials )
            throws WTException;

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     supportingMaterial
    * @return    QueryResult
    * @exception wt.util.WTException
    * @deprecation Use SupportingMaterialService.getRelatedChangeItems( SupportingMaterial supportingMaterial ) instead
    **/
   @Deprecated
   public QueryResult getRelatedChangeItems( SupportingMaterial supportingMaterial )
            throws WTException;

   /**
    * Stores the given concrete subclass of ChangeOrderIfc in the database.
    *
    * If the ChangeOrderIfc object is LifeCycleManaged, this method uses
    * Change2DelegateFactory to get a ChooseLifeCycleDelegate to programatically
    * assign the LifeCycle.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see Change2DelegateFactory
    * @see ChooseLifeCycleDelegate
    * @see ChooseFolderDelegate
    *
    * @param     co
    * @return    ChangeOrderIfc
    * @exception wt.change2.ChangeException2
    * @exception wt.util.WTException
    * @deprecated use {@link #saveChangeOrder(ChangeOrderIfc, boolean)}
    **/
   @Deprecated
   public ChangeOrderIfc saveChangeOrder( ChangeOrderIfc co )
            throws ChangeException2, WTException;
   
   /**
    * Stores the given concrete subclass of ChangeOrderIfc in the database.
    *
    * If the ChangeOrderIfc object is LifeCycleManaged, this method uses
    * Change2DelegateFactory to get a ChooseLifeCycleDelegate to programatically
    * assign the LifeCycle.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see Change2DelegateFactory
    * @see ChooseLifeCycleDelegate
    * @see ChooseFolderDelegate
    *
    * @param     co
    * @param     validate True to validate association rules    
    * @return    ChangeOrderIfc
    * @exception wt.change2.ChangeException2
    * @exception wt.util.WTException
    **/

   public ChangeOrderIfc saveChangeOrder( ChangeOrderIfc co, boolean validate)
            throws ChangeException2, WTException;   

   /**
    * Retrieves the ChangeRecord2 objects related to the given ChangeActivityIfc
    * object and WTList of changeable2.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see Changeable2
    * @see ChangeActivityIfc
    * @see ChangeRecord2
    *
    * @param     ca
    * @param     changeable2
    * @return    WTList
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public WTList getChangeablesAfter( ChangeActivityIfc ca, WTList changeable2 )
            throws WTException, ChangeException2;

   /**
    * Retrieves the Reported Against links related to the given ChangeIssueIfc
    * object by changeables.
    *
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @param     changeIssue
    * @param     changeables
    * @return    WTList
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public WTList getChangeables( ChangeIssueIfc changeIssue, WTList changeables )
            throws WTException, ChangeException2;

   /**
    * Retrieves the Changeable2 objects related to the given ChangeIssueIfc
    * object by the ReviewItem association.
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @param     changeReview
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getChangeables( ChangeReviewIfc changeReview )
            throws WTException, ChangeException2;

    /**
    * Retrieves the Changeable2 objects related to the given ChangeReviewIfc
    * object by the ChagneReviewItemLinkIfc association.  These Changeable2
    * objects represent additional documentation for the Change Review.
    *
    * If onlyChangeables is true, the QueryResult returned contains a set
    * of Changeable2 objects. <p>  If onlyChangeables is false, the QueryResult
    * returned contains a set of ChangeReviewItemLinIfc link objects that
    * have references to the Changeable2 objects.
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see Changeable2
    * @see ChangeReviewIfc
    * @see ChangeReviewItemLinkIfc
    *
    * @param     changeReview
    * @param     onlyChangeables
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/
   public QueryResult getChangeables( ChangeReviewIfc changeReview, boolean onlyChangeables )
            throws WTException, ChangeException2;

   /**
    * Retrieves the AnalysisActivityIfc object related to the given ChangeAnalysisIfc
    * object by the DetailedByIfc association.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see AnalysisActivityIfc
    * @see AnalysisActivityIfc
    * @see DetailedByIfc
    *
    * @param     ca
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getLatestAnalysisActivity( ChangeAnalysisIfc ca )
            throws WTException, ChangeException2;

   /**
    * Retrieves the ChangeInvestigationIfc object related to the given ChangeRequestIfc
    * object by the ResearchedByIfc association.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see ChangeInvestigationIfc
    * @see ChangeRequestIfc
    * @see ResearchedByIfc
    *
    * @param     cr
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getLatestChangeInvestigation( ChangeRequestIfc cr )
            throws WTException, ChangeException2;

   /**
    * Retrieves the ChangeProposalIfc object related to the given ChangeRequestIfc
    * object by the ResearchedByIfc association.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see ChangeProposalIfc
    * @see ChangeRequestIfc
    * @see ResearchedByIfc
    *
    * @param     cr
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getLatestChangeProposal( ChangeRequestIfc cr )
            throws WTException, ChangeException2;

   /**
    * Retrieves the ChangeIssueIfc object related to the given ChangeRequestIfc
    * object by the FormalizedByIfc association.
    *
    * If the given ChangeRequestIfc is a flexible change object, then it will 
    * invoke the FlexibleChangeService and return the related flexible process
    * associations.
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see ChangeIssueIfc
    * @see ChangeRequestIfc
    * @see FormalizedByIfc
    *
    * @param     cr
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getLatestChangeIssue( ChangeRequestIfc cr )
            throws WTException, ChangeException2;

   /**
     * Retrieves the latest version of the <code>ChangeIssueIfc</code> objects
     * related to the provide version of the <code>ChangeActivityIfc</code>
     * object by the <code>IssueImplementedByIfc</code> association. These
     * <code>ChangeIssueIfc</code> objects represent issues that will be
     * implemented by the particular <code>ChangeActivityIfc</code>.
     *
     * The QueryResult returned contains a set of <code>ChangeIssueIfc</code>
     * objects.
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>true
     *
     * @see ChangeIssueIfc
     * @see ChangeActivityIfc
     * @see IssueImplementedByIfc
     *
     * @param changeActivity
     * @return QueryResult
     * @exception wt.util.WTException
     * @exception wt.change2.ChangeException2
     */
  public QueryResult getLatestChangeIssues(ChangeActivityIfc changeActivity) throws WTException, ChangeException2;

   /**
    * Retrieves the latest version of ChangeActivityIfc object related to
    * the given ChangeOrderIfc object by the IncludedInIfc association.
    *
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see ChangeActivityIfc
    * @see ChangeOrderIfc
    * @see IncludedInIfc
    *
    * @param     co
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getLatestChangeActivity( ChangeOrderIfc co )
            throws WTException, ChangeException2;

   /**
    * Retrieves the ChangeOrderIfc object related to the given ChangeRequestIfc
    * object by the AddressedByIfc association.
    *
    * If the given ChangeRequestIfc is a flexible change object, then it will 
    * invoke the FlexibleChangeService and return the related flexible process
    * associations.
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see ChangeOrderIfc
    * @see ChangeRequestIfc
    * @see AddressedByIfc
    *
    * @param     cr
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getLatestChangeOrder( ChangeRequestIfc cr )
            throws WTException, ChangeException2;

   /**
    * Retrieves the ChangeOrderIfc object related to the given ChangeActivityIfc
    * object by the IncludedInIfc association.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see ChangeOrderIfc
    * @see ChangeActivityIfc
    * @see IncludedInIfc
    *
    * @param     ca
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getLatestChangeOrder( ChangeActivityIfc ca )
            throws WTException, ChangeException2;

   /**
     * Retrieves the latest version of the <code>ChangeOrderIfc</code> objects
     * related to the provide version of the <code>ChangeIssueIfc</code>
     * object by the <code>IssueImplementedByIfc</code> association. These
     * <code>ChangeOrderIfc</code> objects represent change notices that will
     * be that have change tasks that implement the given
     * <code>ChangeIssueIfc</code> object.
     *
     * The QueryResult returned contains a set of <code>ChangeOrderIfc</code>
     * objects.
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>true
     *
     * @see ChangeIssueIfc
     * @see ChangeOrderIfc
     * @see IssueImplementedByIfc
     *
     * @param changeIssue
     * @return QueryResult
     * @exception wt.util.WTException
     * @exception wt.change2.ChangeException2
     */
   public QueryResult getLatestChangeOrder(ChangeIssueIfc changeIssue) throws WTException, ChangeException2;


   /**
    * Retrieves the ChangeRequestIfc object related to the given ChangeIssueIfc
    * object by the FormalizedByIfc association.
    *
    * If the given ChangeIssueIfc is a flexible change object, then it will 
    * invoke the FlexibleChangeService and return the related flexible process
    * associations.
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see ChangeRequestIfc
    * @see ChangeIssueIfc
    * @see FormalizedByIfc
    *
    * @param     ci
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getLatestChangeRequest( ChangeIssueIfc ci )
            throws WTException, ChangeException2;

   /**
    * Retrieves the ChangeRequestIfc object related to the given ChangeAnalysisIfc
    * object by the ResearchedByIfc association.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see ChangeRequestIfc
    * @see ChangeAnalysisIfc
    * @see ResearchedByIfc
    *
    * @param     ca
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getLatestChangeRequest( ChangeAnalysisIfc ca )
            throws WTException, ChangeException2;

   /**
    * Retrieves the ChangeRequestIfc object related to the given ChangeOrderIfc
    * object by the AddressedByIfc association.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see ChangeRequestIfc
    * @see ChangeOrderIfc
    * @see AddressedByIfc
    *
    * @param     co
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getLatestChangeRequest( ChangeOrderIfc co )
            throws WTException, ChangeException2;

   /**
    * Retrieves a collection of associated objects for the given change object
    * and relationship class. Currently only supports the relationships:
    *
    * <br>
    * <br>
    * <table border=1>
    * <head>
    * <td><b>changeItem</b></td>
    * <td><b>Target</b></td>
    * <td><b>Link</b></td></head>
    * <tr>
    * <td>ChangeActivityIfc</td>
    * <td>ChangeOrderIfc</td>
    * <td>IncludedIn2</td>
    * </tr>
    * <tr>
    * <td>ChangeActivityIfc</td>
    * <td>ChangeRequestIfc</td>
    * <td>AddressedBy2 & IncludedIn2</td>
    * </tr>
    * <tr>
    * <td>ChangeActivityIfc</td>
    * <td>ChangeIssueIfc</td>
    * <td>IssueImplementedBy</td>
    * </tr>
    * <tr>
    * <td>VersionableChangeItem</td>
    * <td>VersionableChangeItem</td>
    * <td>ResearchedBy</td>
    * </tr>
    * <tr>
    * <td>ChangeAnalysisIfc</td>
    * <td>AnalysisActivityIfc</td>
    * <td>DetailedBy</td>
    * </tr>
    * <tr>
    * <td>AnalysisActivityIfc</td>
    * <td>ChangeAnalysis</td>
    * <td>DetailedBy</td>
    * </tr>
    * <tr>
    * <td>AnalysisActivityIfc</td>
    * <td>VersionableChangeItem</td>
    * <td>ResearchedBy & DetailedBy</td>
    * </tr>
    * </table>
    *
    *
    * <BR>
    * <BR>
    * <B>Supported API: </B>true
    *
    * @param changeItem
    * @param targetChangeItemClass
    *            (ChangeRequestIfc.class)
    * @return Collection of associated objects
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/
   public WTCollection getAssociatedChanges(ChangeItemIfc changeItem, Class<? extends ChangeItemIfc> targetChangeItemClass)
            throws WTException, ChangeException2;

   /**
    * Retrieves the ChangeAnalysisIfc object related to the given AnalysisActivityIfc
    * object by the DetailedByIfc association.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see ChangeAnalysisIfc
    * @see AnalysisActivityIfc
    * @see DetailedByIfc
    *
    * @param     aa
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getLatestChangeAnalysis( AnalysisActivityIfc aa )
            throws WTException, ChangeException2;

   /**
    * Retrieves the latest Change Item or link.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     source  The change object known.
    * @param     targetRole  The target role for searching the associated change object or link.
    * @param     target  The target change object class.
    * @param     link  The name of the association link between the source and target class.
    * @param     onlyChangeItem  True retrieves the latest change object. False retrieves the latest link association.
    * @return    QueryResult
    * @exception wt.util.WTException
    **/
   @SuppressWarnings("unchecked")
   public QueryResult getLatestChangeItem( ChangeItemIfc source, String targetRole, Class target, Class link, boolean onlyChangeItem )
            throws WTException;

   /**
    * Given a set of ChangeItems and the proper role class return a WTKeyedHashMap
    * of Changeables associated to each ChangeItem where the key is the
    * ChangeItem and the value is a Set of changeables.
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @param     cSet  This is a WTSet of the VersionableChangeItems that you want to return the associated Changeable2 objects on.
    * @param     role  This is the role that will be used to navigate to the Changeable2.  For example:  RelevantRequestData2.CHANGEABLE2_ROLE.
    * @param     link  The link class to the Changeable
    * @param     onlyOtherSide  If true return the otherside objects, ie the changeables.  If false return the link objects.
    * @return    WTKeyedHashMap
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/
   @SuppressWarnings("unchecked")
   public WTKeyedHashMap getChangeables( WTCollection cSet, String role, Class link, boolean onlyOtherSide )
            throws WTException, ChangeException2;

   /**
    * Delete the AddressedBy2 relationship associated to the passed in roleSet.
    *  The roleSet must be a set of either ChangeIssuesIfc or ChangeOrderIfc.
    * Example call:
    * deleteAddressedBy(crSet, AddressedBy2.CHANGE_ORDER2_ROLE
    *
    * @deprecated The AddressedBy2 link was replaced by ChangeProcessLink in 11.0.
    * It is recommended to use the FlexibleChangeService to perform deletes.
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @param     roleSet  This set contains either ChangeOrderfc or ChangeRequesetIfc.  The AddressedBy2 link will be deleted to the otherside.
    * @param     role  The role variable contains the role to navigate via the AddressedBy2 link.  For example, AddressedBy2.CHANGE_ORDER_ROLE.
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/
   @Deprecated
   public void deleteAddessedBy( WTCollection roleSet, String role )
            throws WTException, ChangeException2;

   /**
    * This method returns the ChangeOrders that are associated to each changeable
    * in the changeables set through the ChangeRecord2 link of a ChangeActivity
    * and are in the specified state.  It returns these ChangeOrders as
    * values in a WTKeyedHashMap where the keys are the passed in Changeables.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     changeables  The set of changeables to query for the state in the ChangeRecord2 link of a ChangeActivity.
    * @param     state  The state of the returned ChangeOrders.
    * @return    WTKeyedHashMap
    * @exception wt.util.WTException
    **/

   public WTKeyedHashMap getChangeOrdersByChangeRecord( WTSet changeables, State state )
            throws WTException;

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     changeActivities
    * @param     state
    * @return    WTSet
    * @exception wt.util.WTException
    **/

   public WTSet getChangeOrdersByState( WTSet changeActivities, State state )
            throws WTException;

   /**
    * Change the identity of Change Master with the new name, number and
    * organization.  The newName, newNumber and newOrg parameters are optional
    * depending on what identity attributes you want to change.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     changeMaster  The master of a ChangeItem.
    * @param     newName  The new name for the ChangeItem.
    * @param     newNumber  Then new number for the Change Item.
    * @param     newOrg  The new organization of the ChangeItem.
    * @return    Mastered
    * @exception wt.util.WTException
    * @exception wt.util.WTPropertyVetoException
    * @exception wt.pom.UniquenessException
    **/

   public Mastered changeChangeItemMasterIdentity( Mastered changeMaster, String newName, String newNumber, WTOrganization newOrg )
            throws WTException, WTPropertyVetoException, UniquenessException;

   /**
    * Given a ChangeItem and a changeable2 and the linkclass return the
    * instance of the linkclass.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     changeItem  The ChangeItem RoleB
    * @param     changeable  The Changeable2 object RoleA
    * @param     linkclass
    * @return    QueryResult
    * @exception wt.util.WTException
    **/
   @SuppressWarnings("unchecked")
   public QueryResult getChangeLink( VersionableChangeItem changeItem, Changeable2 changeable, Class linkclass )
            throws WTException;

   /**
    * Delete the ChangeActivities in the WTSet.
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @param     changeActivities  This list contains ChangeActivities
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public void deleteChangeActivities( WTSet changeActivities )
            throws WTException, ChangeException2;

   /**
    * Retrieves the ChangeIssueIfc object related to the given Changeable2
    * object by the ReportedAgainstByIfc association.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see ChangeIssueIfc
    * @see Changeable2
    * @see ReportedAgainst
    *
    * @param     changeable2
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getLatestChangeIssue( ChangeableIfc changeable2 )
            throws WTException, ChangeException2;

   /**
    * Retrieves the latest Change Item or link.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     source  The changeable known.
    * @param     targetRole  The target role for searching the associated change object or link.
    * @param     target  The target change object class.
    * @param     link  The name of the association link between the source and target class.
    * @param     onlyChangeItem  True retrieves the latest change object. False retrieves the latest link association.
    * @return    QueryResult
    * @exception wt.util.WTException
    **/
   @SuppressWarnings("unchecked")
   public QueryResult getLatestChangeItem( ChangeableIfc source, String targetRole, Class target, Class link, boolean onlyChangeItem )
            throws WTException;

   /**
    * Retrieves the ChangeRequestIfc object related to the given ChangeableIfc
    * object by the FormalizedByIfc association.
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see ChangeRequestIfc
    * @see ChangeIssueIfc
    * @see RelevantRequestData2Ifc
    *
    * @param     changeable2
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getLatestChangeRequest( ChangeableIfc changeable2 )
            throws WTException, ChangeException2;

   /**
    * Returns a QueryResult of unique latest ChangeOrder2 objects that are
    * indirectly related to the given Changeable2 object. This method obtains
    * all ChangeActivity2 objects connected to the given Changeable2 via
    * the AffectedActivityData association, and then obtains all of the
    * parent ChangeOrder2 objects via the IncludedIn2 association.  Finally,
    * the result is filtered to remove duplicates.
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @param     changeable
    * @return    QueryResult
    * @exception wt.change2.ChangeException2
    * @exception wt.util.WTException
    **/

   public QueryResult getLatestUniqueAffectingChangeOrders( Changeable2 changeable )
            throws ChangeException2, WTException;
   
    /**
     * Returns a map of changeable objects and the latest change notices associated as affected and/or resulting objects
     * on change tasks owned by the change notices.
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>true
     *
     * @param changeables
     * @param linkClasses
     *            To get change notices for only affected objects use <code>wt.change2.AffectedActivityData</code>. To
     *            only get change notices for resulting objects use <code>wt.change2.ChangeRecord2</code>. To get change
     *            notices for both affected and resulting associations pass both link classes. An empty map will be
     *            returned if no valid link type is specified.
     * @return A map containing the changeable objects as keys and WTCollection of change notices associated. If not
     *         change notices are found for a given changeable the collection of change notices will be empty. The map
     *         returned is guaranteed non-null but may be empty.
     * @exception wt.change2.ChangeException2
     * @exception wt.util.WTException
     * @deprecated use {@link #getLatestChangeOrders(WTCollection, boolean, boolean)} 
     **/
   @Deprecated
   public WTKeyedMap getLatestChangeOrders( WTCollection changeables, Class... linkClasses)
            throws ChangeException2, WTException;
   
    /**
     * Returns a map of changeable objects and the latest change notices associated as affected and/or resulting objects
     * on change tasks owned by the change notices. If neither affect or resulting are specified then an empty map will
     * be returned.
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>true
     *
     * @param changeables
     * @param includeAffected
     *            True to get change notices for affected objects.
     * @param includeResulting
     *            True to get change notices for resulting objects.
     * @return A map containing the changeable objects as keys and WTCollection of change notices associated. If no
     *         change notices are found for a given changeable the collection of change notices will be null. The map
     *         returned is guaranteed non-null but may be empty. The map will use the same key mask as the passed in
     *         collection of changeable objects.
     * @exception wt.change2.ChangeException2
     * @exception wt.util.WTException
     **/
  public WTKeyedMap getLatestChangeOrders( WTCollection changeables, boolean includeAffected, boolean includeResulting)
           throws ChangeException2, WTException;
   
   /**
    * Returns a QueryResult of latest unique ChangeOrder2 objects that are
    * indirectly related to the given Changeable2 object.  This method obtains
    * all ChangeActivity2 objects connected to the given Changeable2 via
    * the ChangeRecord2 association, and then obtains all of the parent
    * ChangeOrder2 objects via the IncludedIn2 association.  Finally, the
    * result is filtered to remove duplicates.
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @param     changeable
    * @return    QueryResult
    * @exception wt.change2.ChangeException2
    * @exception wt.util.WTException
    **/

   public QueryResult getLatestUniqueImplementedChangeOrders( Changeable2 changeable )
            throws ChangeException2, WTException;

   /**
    * Retrieves the set of IncludedIn2 links associated with the passed
    * in ChangeActivities and if the RoleB (ChangeAcitivity2) points to
    * one and only one ChangeOrder2 then the RoleB object (ChangeActivity2)
    * will be deleted.  The IncludedIn2 link associated with the ChangeActivity
    * will always be deleted. This API is deprecated, use deleteIncludeIn2AndChangeTask
    *
    * <BR><BR><B>Supported API: </B>true
	* @deprecated
    *
    * @param     changeActivities  This list contains ChangeActivities
    * @exception wt.util.WTException
    **/

    @Deprecated
    public void deleteIncludeIn2(WTSet changeActivities)
            throws WTException;
   
    /**
     * Retrieves a set of IncludedIn2 links associated with the passed in change tasks. If the RoleB(Change task) points
     * to just one Change notice then the change task will be deleted. The IncludedIn2 link will be deleted if the
     * RoleAObject(ChangeNotice) is the same as the passed change notice.
     *
     * 
     * <BR>
     * <BR>
     * <B>Supported API: </B>true
     *
     * @param changeActivities
     *            This list contains ChangeActivities
     * @param co
     * @exception wt.util.WTException
     * @deprecated use {@link #deleteIncludeIn2AndChangeTask(WTSet, ChangeOrder2, boolean)}
     **/
    @Deprecated
    public void deleteIncludeIn2AndChangeTask(WTSet changeActivities, ChangeOrder2 co)
            throws WTException;

    /**
     * Retrieves a set of IncludedIn2 links associated with the passed in change tasks. If the RoleB(Change task) points
     * to just one Change notice then the change task will be deleted. The IncludedIn2 link will be deleted if the
     * RoleAObject(ChangeNotice) is the same as the passed change notice.
     * 
     * <BR>
     * <BR>
     * The implementation plan association rules can be optionally evaluated using the <code>validate</code> parameter.
     *
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>true
     *
     * @param changeActivities
     *            This list contains ChangeActivities
     * @param co
     * @param validate
     *            False to ignore association rule validation
     * @exception wt.util.WTException
     **/

    public void deleteIncludeIn2AndChangeTask(WTSet changeActivities, ChangeOrder2 co, boolean validate)
            throws WTException;
   
   /**
     * Delete the <code>IssueImplementedByIfc</code> relationships implied by
     * the two arguments. The concrete subclasses of the
     * <code>ChangeActivityIfc</code>, the collection of
     * <code>ChangeIssueIfc</code> objects and the
     * <code>IssueImplementedByIfc</code> relationship must already be
     * Persistent.
     *
     * In the event there is no <code>IssueImplementedByIfc</code> (the two
     * objects passed in are not related) then there will be no exception
     * generated, instead a null will be returned..
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>true
     *
     * @param changeActivity
     * @param changeIssues
     * @exception wt.util.WTException
     * @exception wt.change2.ChangeException2
     */
    public void deleteIssueImplementedBy(ChangeActivityIfc changeActivity, WTCollection changeIssues) throws WTException,
            ChangeException2;

    /**
     * Delete the <code>IssueImplementedByIfc</code> relationships implied by
     * the two arguments. The concrete subclasses of the
     * <code>ChangeActivityIfc</code>, the collection of
     * <code>ChangeIssueIfc</code> objects and the
     * <code>IssueImplementedByIfc</code> relationship must already be
     * Persistent.
     *
     * In the event there is no <code>IssueImplementedByIfc</code> (the two
     * objects passed in are not related) then there will be no exception
     * generated, instead a null will be returned..
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>true
     *
     * @param linkClass
     * @param changeActivity
     * @param changeIssues
     * @exception wt.util.WTException
     * @exception wt.change2.ChangeException2
     */
    public void deleteIssueImplementedBy(Class<?> linkClass, ChangeActivityIfc changeActivity,
            WTCollection changeIssues) throws WTException, ChangeException2;


   /**
    * Given a set of Changeable2 and the proper role class return a WTKeyedHashMap
    * of ChangeItems associated to each Changeable2 where the key is the
    * Changeable and the value is a Set of ChangeItems.
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @param     cSet  This is a WTSet of the VersionableChangeItems that you want to return the associated Changeable2 objects on.
    * @param     role  This is the role that will be used to navigate to the Changeable2.  For example:  RelevantRequestData2.CHANGEABLE2_ROLE.
    * @param     link  The link class to the Changeable
    * @param     onlyOtherSide  If true return the otherside objects, ie the changeables.  If false return the link objects.
    * @return    WTKeyedHashMap
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/
   @SuppressWarnings("unchecked")
   public WTKeyedHashMap getChangeItems( WTCollection cSet, String role, Class link, boolean onlyOtherSide )
            throws WTException, ChangeException2;

   /**
    * Get the trackingChangeItem Preference for a Persistable.  It checks
    * from the Org Container up to Site Container.
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @param     p
    * @return    boolean
    * @exception wt.util.WTException
    **/

   public boolean getTrackingChange( Persistable p )
            throws WTException;

   /**
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @deprecated The pending change request states are now maintained by <code>DefaultPendingChangeEventHandler</code>.
    *
    * @return    String []
    * @exception wt.util.WTException
    **/

   @Deprecated
public String [] getPendRequests()
            throws WTException;

   /**
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @deprecated The pending change order states are now maintained by <code>DefaultPendingChangeEventHandler</code>.

    * @return    String []
    * @exception wt.util.WTException
    **/

   @Deprecated
   public String [] getPendOrders()
            throws WTException;

    /**
     * Save the ChangeActivities associated to the ChangeOrder key in the WTKeyedSet where the key is the ChangeOrder
     * and the value is a WTList of ChangeActivities.
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>true
     *
     * @param coMap
     *            This WTKeyedMap contains the ChangeOrder as the key and a WTList of ChangeActivities as the value.
     * @return WTKeyedMap
     * @exception wt.util.WTException
     * @exception wt.change2.ChangeException2
     * @deprecated use {@link #saveChangeActivities(WTKeyedHashMap, boolean)}
     **/
    @Deprecated
    public WTKeyedMap saveChangeActivities(WTKeyedHashMap coMap)
            throws WTException, ChangeException2;
    
    /**
     * Save the ChangeActivities associated to the ChangeOrder key in the WTKeyedSet where the key is the ChangeOrder
     * and the value is a WTList of ChangeActivities.
     *
     * <BR>
     * <BR>
     * The implementation plan association rules can be optionally evaluated using the <code>validate</code> parameter.
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>true
     *
     * @param coMap
     *            This WTKeyedMap contains the ChangeOrder as the key and a WTList of ChangeActivities as the value.
     * @param validate
     *            False to ignore association rule validation
     * @return WTKeyedMap
     * @exception wt.util.WTException
     * @exception wt.change2.ChangeException2
     **/

    public WTKeyedMap saveChangeActivities(WTKeyedHashMap coMap, boolean validate)
            throws WTException, ChangeException2;

   /**
    * Given a VersionableChangeItem return the latest version.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     source  The change object known.
    * @return    VersionableChangeItem
    * @exception wt.util.WTException
    **/

   public VersionableChangeItem getLatestOfChangeItem( VersionableChangeItem source )
            throws WTException;

   /**
    * Stores the given concrete subclass of ChangeDirective in the database.
    *
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @param     cd
    * @return    WTChangeDirective
    * @exception wt.change2.ChangeException2
    * @exception wt.util.WTException
    **/

   public WTChangeDirective saveChangeDirective( WTChangeDirective cd )
            throws ChangeException2, WTException;

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     linkClass
    * @param     contextObject
    * @param     roleOfAddedObjects
    * @param     objectsToAdd
    * @return    WTCollection
    * @exception wt.util.WTException
    **/
   @SuppressWarnings("unchecked")
   public WTCollection getLinksThatAlreadyExist( Class linkClass, Object contextObject, String roleOfAddedObjects, WTCollection objectsToAdd )
            throws WTException;

   /**
    * Retrieves the WTPartMaster objects related to the given WTChangeDirective
    * object by the Impacts association.
    *
    * The QueryResult returned contains a set of WTPartMaster objects, not
    * a set of Impacts link objects that have references to the WTPartMaster
    * objects.  There is another method that contains the Impacts link objects.
    *
    *
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @see WTPartMaster
    * @see WTChangeDirective
    * @see Impacts
    *
    * @param     cd
    * @param     onlyDirectives
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getImpactedItems( WTChangeDirective cd, boolean onlyDirectives )
            throws WTException, ChangeException2;

   /**
    * Retrieves the WTPartMaster objects related to the given ChangeRequestIfc
    * object by the Impacts association.  These WTPartMaster objects represent
    * additional documentation for the WTChangeDirective
    *
    * If onlyItems is true, the QueryResult returned contains a set of WTPartMaster
    * objects. <p>  If onlyItems is false, the QueryResult returned contains
    * a set of Impacts link objects that have references to the WTPartMaster
    * objects.
    *
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @see WTPartMaster
    * @see WTChangeDirective
    * @see Impacts
    *
    * @param     cd
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getImpactedItems( WTChangeDirective cd )
            throws WTException, ChangeException2;

   /**
    * Retrieves the ChangeAction objects related to the given WTChangeDirective
    * object.
    *
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     cd
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getActionsOwnedBy( WTChangeDirective cd )
            throws WTException, ChangeException2;

   /**
    * Retrieves the ChangeAction objects related to the given collection
    * of WTChangeDirective objects.
    *
    * Returns a KeyedMap where the key is the Change Directives passed as
    * the parameter.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     changeDirectives  collection of Change Directives.
    * @return    WTKeyedMap
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public WTKeyedMap getActionsOwnedBy( WTCollection changeDirectives )
            throws WTException, ChangeException2;

   /**
    * Stores the given concrete subclass of ChangeAction in the database.
    *
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @param     action
    * @return    ChangeAction
    * @exception wt.change2.ChangeException2
    * @exception wt.util.WTException
    **/

   public ChangeAction saveChangeAction( ChangeAction action )
            throws ChangeException2, WTException;
   
     /**
     * Create a persisted ChangeItemResource object.
     * 
     * @param resourceType  Extended type of ChangeItemResource to be created.
     * @param testUriString URI string that identifies the remote change item.
     * @param shapeName Shape Name for the resource being added
     * 
     * @return  New persisted ChangeItemResource object.
     * 
     * @throws Exception
     * 
     * <BR><BR><B>Supported API: </B>false
     */
    
   public ChangeItemResource saveChangeItemResource(Class<?> resourceType, String uriString, String shapeName)
           throws Exception ;
   /**
    * Retrieves the WTChangeDirective objects related to the given WTPartMaster
    * object by the Impacts association.
    *
    * If onlyCDs is true, the QueryResult returned contains a set of WTPartMaster
    * objects. <p>  If onlyDirectives is false, the QueryResult returned
    * contains a set of Impacts link objects that have references to the
    * WTPartMaster objects.
    *
    *
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @see WTPartMaster
    * @see WTChangeDirective
    * @see Impacts
    *
    * @param     part
    * @param     onlyCDs
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getDirectivesImpactedBy( WTPartMaster part, boolean onlyCDs )
            throws WTException, ChangeException2;

   /**
    * Retrieves the WTChangeDirective objects related to the given WTPartMaster
    * object by the Impacts association.
    *
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @see WTPartMaster
    * @see WTChangeDirective
    * @see Impacts
    *
    * @param     part
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getDirectivesImpactedBy( WTPartMaster part )
            throws WTException, ChangeException2;

   /**
    * Retrieves the ChangeAction objects related to the given WTPartMaster
    * object by the Addresses association.
    *
    *
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @see WTPartMaster
    * @see ChangeAction
    * @see Addresses
    *
    * @param     part
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getActionsAddressedBy( WTPartMaster part )
            throws WTException, ChangeException2;

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     directive
    * @param     part
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getActionsAddressedBy( WTChangeDirective directive, WTPartMaster part )
            throws WTException, ChangeException2;

   /**
    * Retrieves the Change Actions  that are  addressed by the  given WTPartMaster
    * object and the derived from the given Change Action. If the Change
    * Action is null, it returns the Change actions that are not derived
    * from any other Change Actions and that addresses the given WTPartMaster
    *
    *
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @see WTPartMaster
    * @see ChangeAction
    *
    *
    * @param     addressedPart
    * @param     derivedFrom
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getActionsAddressedBy( WTPartMaster addressedPart, ChangeAction derivedFrom )
            throws WTException, ChangeException2;

   /**
    * Retrieves the ChangeAction predessor stack
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @param     action
    * @return    WTKeyedMap
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public WTKeyedMap getPredessorActions( ChangeAction action )
            throws WTException, ChangeException2;

   /**
    * This method accepts the Design Solution that is associated to a CI
    * and returns the Change Actions that are addressed by this CI
    *
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     part
    * @return    List<ChangeAction>
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public List<ChangeAction> getChangeActionCandidatesForFulfillment( WTPart part )
            throws WTException, ChangeException2;

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     part
    * @param     state
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getActionsAddressedByForState( WTPartMaster part, ActionState state )
            throws WTException, ChangeException2;

   /**
    * Retrieves the ChangeAction objects related to the given WTPartMaster
    * object by the Satisfy association.
    *
    *
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @see WTPartMaster
    * @see ChangeAction
    * @see Satisfy
    *
    * @param     part
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getActionsSatisfiedBy( WTPartMaster part )
            throws WTException, ChangeException2;

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     ciMaster
    * @return    List<WTPart>
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public List<WTPart> getCandidatesForFulfillmentFromChangeAction( WTPartMaster ciMaster )
            throws WTException, ChangeException2;

   /**
    * This API marks the object as modified, by updating the modify timestamp.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     targetObjectType
    * @param     targetObjects
    * @exception wt.util.WTException
    **/
   @SuppressWarnings("unchecked")
   public void markAsModified( Class targetObjectType, WTCollection targetObjects )
            throws WTException;

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     owningDirectives
    * @param     addressedPartMaster
    * @return    boolean
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public boolean hasChangeActionsInSolvedState( WTCollection owningDirectives, WTPartMaster addressedPartMaster )
            throws WTException, ChangeException2;

   /**
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     addressedParts
    * @param     owningDirective
    * @return    boolean
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public boolean hasChangeActionsInSolvedState( WTCollection addressedParts, WTChangeDirective owningDirective )
            throws WTException, ChangeException2;

   /**
    * Checks if the given part master have disassociated  change actions
    * that needs to be cleaned up.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     addressedPartMaster
    * @return    boolean
    * @exception wt.util.WTException
    **/

   public boolean needToDisassociateChangeActions( WTPartMaster addressedPartMaster )
            throws WTException;

   /**
    * Retrieves the WTChangeDirective object related to the given ChangeOrderIfc
    * object by the AddressesDirective association.  These WTChangeDirective
    * object represents the directive for which the ChangeOrderIfc is performing
    * .
    *
    *
    *
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @see WTChangeDirective
    * @see ChangeOrderIfc
    * @see AddressesDirective
    *
    * @param     co
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getChangeDirective( ChangeOrderIfc co )
            throws WTException, ChangeException2;

   /**
    * Retrieves the WTChangeDirective object related to the given ChangeOrderIfc
    * object by the AddressesDirective association.  The WTChangeDirective
    * object represents the request that is addressed by the ChangeOrderIfc.
    *
    * If onlyChangeDirective is true, the QueryResult returned contains
    * zero or one WTChangeDirective objects. <p>  If onlyChangeDirective
    * is false, the QueryResult returned contains zero or one AddressesDirective
    * link objects that has a reference to the WTChangeDirective object.
    *
    *
    *
    * <BR><BR><B>Supported API: </B>true
    *
    * @see WTChangeDirective
    * @see ChangeOrderIfc
    * @see AddressesDirective
    *
    * @param     co
    * @param     onlyChangeDirective
    * @return    QueryResult
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public QueryResult getChangeDirective( ChangeOrderIfc co, boolean onlyChangeDirective )
            throws WTException, ChangeException2;

   /**
    * Returns a WTKeyedHashMap where the key is the WTPartMaster and the
    * value is a List.
    *
    * If onlyCDs is true, the List returned contains WTChangeDirective objects.
    * <p>  If onlyCDs is false, the QueryResult returned contains a List
    * of Impacts link objects.
    *
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @see WTPartMaster
    * @see WTChangeDirective
    * @see Impacts
    *
    * @param     partMasters
    * @param     onlyCDs
    * @return    WTKeyedMap
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public WTKeyedMap getDirectivesImpactedBy( WTCollection partMasters, boolean onlyCDs )
            throws WTException, ChangeException2;

   /**
    * Delete the AddressesDirective links associated to the ChangeNotice.
    *
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     changeOrder
    * @param     changeDirectives
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public void deleteAddressesDirective( ChangeOrderIfc changeOrder, WTCollection changeDirectives )
            throws WTException, ChangeException2;

   /**
    * Delete the AddressesDirective relationship associated to the passed
    * in roleSet.
    *
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     roleSet
    * @param     role
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public void deleteAddressesDirective( WTCollection roleSet, String role )
            throws WTException, ChangeException2;

   /**
    * Retrieves the ChangeAction objects related to the given collection
    * of WTPartMaster objects through the Satisfy association
    *
    * Returns a KeyedMap where the key is the PartMaster passed as the parameter
    * and the values are a set of ChangeAction objects.
    *
    * <BR><BR><B>Supported API: </B>false
    *
    * @param     partMasters  collection of Change Directives.
    * @return    WTKeyedMap
    * @exception wt.util.WTException
    * @exception wt.change2.ChangeException2
    **/

   public WTKeyedMap getActionsSatisfiedBy( WTCollection partMasters )
            throws WTException, ChangeException2;


   	/**
	 * Dispatches an object event to each change activity associated to the given CN .
	 * The event dispatched is "CHANGE IMPLEMENTATION" which Change Activities listen for in
	 * the OOTB Change Activity Workflow.
	 *
	 * <br><br><b>Supported API:</b> false
	 * @param co A change order
	 */
    public void emitChangeImplementationEvent(ChangeOrder2 co)
    		 throws WTException;

    /**
     * Given a roleA or a roleB change object, determine if the link already exists.
     * <BR><BR><B>Supported API: </B>false
     * @return a change link if it exists otherwise returns null.
     */
    public BinaryLink getExistingChangeLink(Persistable roleA, Persistable roleB, Class linkClass)
    		 throws WTException;


    /**
     * Silently fixes the domain assignment of the non-Foldered target change object to match
     * that of the source change object only if the cabinet previously assigned by the rules service
     * (i.e., not assigned by a ChooseFolderDelegate) resulted in an incorrect domain assignment.
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param target    The non-foldered change object (change analysis, analysis activity,
     *                  or change activity) source the "parent" of the target change object
     *                  (change request, change analysis, or change order).
     *
     * @param source    The Foldered or CabinetMember source object used to set the domain
     *                  of the target object.
     *
     * @param persist   True to persist any fixes that are made, false to make changes without
     *                  persisting them.
     *
     * @return          True if target object was fixed, false if target object was already assigned correctly.
     *
     * @throws ClassCastException If the target or source is not DomainAdministered.
     */
    public boolean fixDomainAssignment(CabinetMember target, FolderEntry source, boolean persist) throws WTException;
    
    /**
     * Given a change object, return the ones that are child objects. This supports either flexible or legacy objects.
     * If the parent is Flexible, then children are obtained by navigating FlexibleChangeLink.CHILD_ROLE. Otherwise, it
     * follows this navigation rule: <br>
     * <ul>
     * <li>Change Issue -> Change Request
     * <li>ChangeRequest --> Change Notice
     * </ul>
     * 
     * If the parent is a Change Notice object, then this API gets all Change Tasks whether it is flexible or not. <br>
     * Change Notice --> Change Task
     * 
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     * 
     * @return WTCollection. Guaranteed non-null, but could be empty
     * @throws WTException
     */
    public WTCollection getChildChangeObjects(ChangeItem parent) throws WTException;

    /**
     * Given a change object, return the ones that are child objects for the given set of filtered by change type identifiers. 
     * This supports either flexible or legacy objects. If the parent is Flexible, then children are obtained by navigating 
     * FlexibleChangeLink.CHILD_ROLE. Otherwise, it follows this navigation rule: <br>
     * <ul>
     * <li>Change Issue -> Change Request
     * <li>ChangeRequest --> Change Notice
     * </ul>
     * 
     * If the parent is a Change Notice object, then this API gets all Change Tasks whether it is flexible or not. <br>
     * Change Notice --> Change Task
     * 
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     * 
     * @param changeItem
     * @param filterByChangeTypeIds
     *            Change type identifiers to filter by
     * @return WTCollection. Guaranteed non-null, but could be empty
     * @throws WTException
     */
    public WTCollection getChildChangeObjects(ChangeItem parent, Set<TypeIdentifier> filterByChangeTypeIds) throws WTException;
    
    /**
     * Given a change object, return or rejects the ones that are child objects for the given set of filtered by change
     * type identifiers depending upon the excludeFilterByChangeTypeIds flag. This supports either flexible or legacy
     * objects. If the parent is Flexible, then children are obtained by navigating FlexibleChangeLink.CHILD_ROLE.
     * Otherwise, it follows this navigation rule: <br>
     * <ul>
     * <li>Change Issue -> Change Request
     * <li>ChangeRequest --> Change Notice
     * </ul>
     * 
     * If the parent is a Change Notice object, then this API gets all Change Tasks whether it is flexible or not. <br>
     * Change Notice --> Change Task
     * 
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     * 
     * @param changeItem
     * @param filterByChangeTypeIds
     *            Change type identifiers to filter by
     * @param excludefilterByChangeTypeIds
     *            - controls whether to exclude or include the filterByChangeTypeIds
     * @return WTCollection. Guaranteed non-null, but could be empty
     * @throws WTException
     */
    public WTCollection getChildChangeObjects(ChangeItem parent, Set<TypeIdentifier> filterByChangeTypeIds,
            boolean excludeFilterByChangeTypeIds) throws WTException;

    /**
     * Given a change object, return the ones that are parents. This supports either flexible or legacy objects. This is
     * the opposite of {@link getChildChangeObjects}
     * 
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     * 
     * @param changeItem
     * @return WTCollection. Guaranteed non-null, but could be empty
     * @throws WTException
     */
    public WTCollection getParentChangeObjects(ChangeItem changeItem) throws WTException;

    /**
     * Given a change object, return the ones that are parents for the given set of filtered by change type identifiers. 
     * This supports either flexible or legacy objects. This is the opposite of {@link getChildChangeObjects}
     * 
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     * 
     * @param changeItem
     * @param filterByChangeTypeIds
     *            Change type identifiers to filter by
     * @return WTCollection. Guaranteed non-null, but could be empty
     * @throws WTException
     */
    public WTCollection getParentChangeObjects(ChangeItem changeItem, Set<TypeIdentifier> filterByChangeTypeIds) throws WTException;


    /**
     * Given a primary business object, return the related workflow records.
     * <BR>
     * <BR>
     * <B>Supported API: </B>true
     *
     * @param primaryBusinessObject
     * @param isGetOnlySignedReviews when true only workflow records that were signed as part of task completion are returned
     * @return WTCollection. Guaranteed non-null, but could be empty
     * @throws WTException
     */
    
    public WTCollection getWorkflowRecords(Persistable primaryBusinessObject, boolean isGetOnlySignedReviews) throws WTException;
    
    /**
     * returns attributes name,number etc for remote change objects
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     * @param oid
     * @return
     */
    public Element getRemoteChangeObject(String oid);
}
