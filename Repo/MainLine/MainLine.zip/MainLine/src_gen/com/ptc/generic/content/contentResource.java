package com.ptc.generic.content;

import wt.util.resource.*;

@RBUUID("com.ptc.generic.content.contentResource")
public final class contentResource extends WTListResourceBundle {
   /**
    * 
    * Copyright (c) 2001 - 2006 Parametric Technology Corporation (PTC). All Rights Reserved.
    * 
    * This software is the confidential and proprietary information of PTC.
    * You shall not disclose such confidential information and shall use it
    * only in accordance with the terms of the license agreement.
    * 
    * English
    **/
   @RBEntry("A primary content already exists on this object.")
   public static final String ERROR_PRIMARY_CONTENT_ALREADY_EXISTS = "ERROR_PRIMARY_CONTENT_ALREADY_EXISTS";

   @RBEntry("Got unsupported ContentRoleType '{0}'.")
   public static final String ERROR_UNSUPPORTED_ROLE_TYPE = "ERROR_UNSUPPORTED_ROLE_TYPE";
}
