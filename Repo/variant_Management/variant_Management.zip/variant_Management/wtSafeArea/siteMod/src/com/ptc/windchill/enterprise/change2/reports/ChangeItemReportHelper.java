/* bcwti
 *
 * Copyright (c) 2010 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */
package com.ptc.windchill.enterprise.change2.reports;

import java.io.IOException;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.log4j.Logger;
import org.json.JSONObject;

import com.infoengine.object.factory.Att;
import com.infoengine.object.factory.Element;
import com.infoengine.object.factory.Group;
import com.ptc.core.adapter.server.impl.ObjectReferenceTranslator;
import com.ptc.core.components.rendering.guicomponents.GuiComponentUtil.Delimiter;
import com.ptc.core.components.util.OidHelper;
import com.ptc.core.htmlcomp.util.DateFormatUtilities;
import com.ptc.core.meta.common.Hyperlink;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.impl.WCTypeIdentifier;
import com.ptc.core.meta.descriptor.common.DefinitionDescriptor;
import com.ptc.core.meta.descriptor.common.DefinitionDescriptorFactory;
import com.ptc.core.ocmp.framework.AdvancedComparisonSpec;
import com.ptc.core.ocmp.framework.ComparisonResult;
import com.ptc.core.ocmp.framework.ComparisonSpec;
import com.ptc.core.ocmp.framework.LinkDiffs;
import com.ptc.core.ocmp.framework.impl.XmlConfigResourceHandler;
import com.ptc.core.ocmp.framework.impl.custom.RelatedOwnerCadDocumentComparator.AbstractBinaryLinkProxy;
import com.ptc.core.ocmp.service.ObjComparisonHelper;
import com.ptc.core.richtext.HTMLTextFilter;
import com.ptc.generic.iba.AttributeService;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.misc.NmAction;
import com.ptc.netmarkets.util.misc.NmActionServiceHelper;
import com.ptc.windchill.enterprise.massChange.massChangeClientResource;
import com.ptc.windchill.enterprise.object.ActionDelegateHelper;
import com.ptc.windchill.enterprise.report.ReportHelper;
import com.ptc.windchill.enterprise.report.ReportTask;
import com.ptc.windchill.enterprise.report.utils.ReportTaskUtil;
import com.ptc.windchill.uwgm.common.associate.AssociationType;
import com.ptc.windchill.uwgm.common.associate.associateResource;

import ext.kb.enumconstant.InventoryDispositions;
import wt.access.AccessControlHelper;
import wt.access.AccessPermission;
import wt.change2.AffectedActivityData;
import wt.change2.Category;
import wt.change2.ChangeHelper2;
import wt.change2.ChangeIssue;
import wt.change2.ChangeItem;
import wt.change2.ChangeItemResource;
import wt.change2.ChangeNoticeComplexity;
import wt.change2.ChangeOrder2;
import wt.change2.ChangeRecord2;
import wt.change2.ChangeRequest2;
import wt.change2.Changeable2;
import wt.change2.Complexity;
import wt.change2.FlexibleChangeItem;
import wt.change2.FlexibleChangeLink;
import wt.change2.HangingChangeLink;
import wt.change2.IssuePriority;
import wt.change2.RequestPriority;
import wt.change2.VarianceCategory;
import wt.change2.VersionableChangeItem;
import wt.change2.WTChangeActivity2;
import wt.change2.WTChangeOrder2;
import wt.change2.flexible.FlexibleChangeHelper;
import wt.change2.hangingchange.HangingChangeCriteria;
import wt.change2.hangingchange.HangingChangeHelper;
import wt.change2.workset.WTWorkSetComponentLink;
import wt.clients.util.IconCache;
import wt.doc.WTDocumentUsageLink;
import wt.epm.build.EPMBuildHistory;
import wt.epm.build.EPMBuildRule;
import wt.epm.structure.EPMDescribeLink;
import wt.epm.structure.EPMMemberLink;
import wt.fc.BinaryLink;
import wt.fc.EnumeratedTypeUtil;
import wt.fc.IconDelegate;
import wt.fc.IconDelegateFactory;
import wt.fc.ObjectReference;
import wt.fc.ObjectToObjectLink;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceManager;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.fc.WTObject;
import wt.fc.WTReference;
import wt.fc.collections.WTArrayList;
import wt.fc.collections.WTCollection;
import wt.fc.collections.WTHashSet;
import wt.fc.collections.WTKeyedMap;
import wt.fc.collections.WTList;
import wt.identity.IdentityFactory;
import wt.inf.container.WTContained;
import wt.inf.team.ContainerTeamHelper;
import wt.introspection.WTIntrospector;
import wt.lifecycle.LifeCycleManaged;
import wt.lifecycle.State;
import wt.log4j.LogR;
import wt.method.MethodLocal;
import wt.org.OrganizationOwned;
import wt.org.OrganizationServicesHelper;
import wt.org.WTGroup;
import wt.org.WTOrganization;
import wt.org.WTPrincipal;
import wt.org.WTPrincipalReference;
import wt.org.WTUser;
import wt.part.Quantity;
import wt.part.QuantityUnit;
import wt.part.WTPart;
import wt.part.WTPartDescribeLink;
import wt.part.WTPartReferenceLink;
import wt.part.WTPartUsageLink;
import wt.part.WTProductInstance2;
import wt.pom.PersistenceException;
import wt.project.Role;
import wt.services.applicationcontext.implementation.DefaultServiceProvider;
import wt.session.SessionHelper;
import wt.session.SessionManagerSvr;
import wt.session.SessionServerHelper;
import wt.team.Team;
import wt.team.TeamManaged;
import wt.team.TeamReference;
import wt.util.HTMLEncoder;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.WTProperties;
import wt.util.WTStandardDateFormat;
import wt.util.WrappedTimestamp;
import wt.vc.Iterated;
import wt.vc.VersionControlHelper;
import wt.vc.Versioned;
import wt.vc.struct.IteratedDescribeLink;
import wt.vc.struct.IteratedReferenceLink;
import wt.vc.struct.IteratedUsageLink;
import wt.vc.views.ViewManageable;

/**
 * Helper used for the change item summary reports.
 *
 * <BR>
 * <BR>
 * <B>Supported API: </B>false <BR>
 * <BR>
 * <B>Extendable: </B>false
 */
public class ChangeItemReportHelper {

    protected static final String LINKTYPE = "LINKTYPE";

    protected static final String COMPTYPE = "COMPTYPE";

    protected static final String COMPVERSION = "COMPVERSION";

    protected static final String COMPNAME = "COMPNAME";

    protected static final String COMPNUMBER = "COMPNUMBER";

    protected static final String COMPORGID = "COMPORGID";

    protected static final String COMPVERSIONOLD = "COMPVERSIONOLD";

    protected static final String COMPNAMEOLD = "COMPNAMEOLD";

    protected static final String COMPNUMBEROLD = "COMPNUMBEROLD";

    protected static final String COMPORGIDOLD = "COMPORGIDOLD";

    protected static final String STRUCTDIFF = "STRUCTDIFF";

    private static final String OBID = "obid";

    private static final String VERSION = "version";

    private static final String NAME = "name";

    private static final String NUMBER = "number";

    private static final String MODIFIER_ID = "modifier.id";

    private static final String CREATOR_ID = "creator.id";

    private static final String DISPOSITION_COMMENTS = "DISPOSITIONCOMMENTS";

    private static final String DISPOSITION_KEY = "DISPOSITIONKEY";

    private static final String DISPOSITION_VALUE = "DISPOSITIONVALUE";

    protected String ON_ORDER_DISPOSITION;

    protected String INVENTORY_DISPOSITION;

    protected String FINISHED_DISPOSITION;
    
    protected String WITHCUSTOMER_DISPOSITION;

    protected String INASSEMBLEDPARTS_DISPOSITION;

    protected String INSERVICECENTER_DISPOSITION;

    private static final String CHANGE_ADMIN1 = "CHANGE_ADMIN1";

    private static final String VARIANCEOWNERATTRIBUTE = "varianceOwner";

    protected static final String RESOLUTIONDATEATTRIBUTE = "resolutionDate";

    protected static final String NEEDDATEATTRIBUTE = "needDate";

    protected static final String CHANGENOTICECOMPLEXITYATTRIBUTE = "theChangeNoticeComplexity";

    protected static final String VARIANCECATEGORYATTRIBUTE = "theVarianceCategory";

    protected static final String CATEGORYATTRIBUTE = "theCategory";

    protected static final String COMPLEXITYATTRIBUTE = "theComplexity";

    protected static final String REQUESTPRIORITYATTRIBUTE = "requestPriority";

    protected static final String ISSUEPRIORITYATTRIBUTE = "theIssuePriority";

    protected static final String ATTRTYPE_DATE = "date";

    protected static final String ATTRTYPE_TIMESTAMP = "timeStamp";

    protected static final String ATTRTYPE_REFERENCE = "reference";

    protected static final String ATTRTYPE_ENUMERATED = "enumerated";

    protected static final String ATTRTYPE_RICHTEXT = "richText";

    protected static final String FOLDERID_ATTRIBUTE = "folderId";

    protected static final String LONGDESCRIPTION_PLAINTEXT_ATTRIBUTE = "longDescriptionPlainText";

    protected static final String LONGDESCRIPTION_RICHTEXT_ATTRIBUTE = "longDescriptionRichText";

    protected static final String LONGDESCRIPTION_COGNOS_RICHTEXT_ATTRIBUTE = "longDescriptionCognosRichText";

    protected static final String LONGPROPOSEDSOLUTION_PLAINTEXT_ATTRIBUTE = "longProposedSolutionPlainText";

    protected static final String LONGPROPOSEDSOLUTION_RICHTEXT_ATTRIBUTE = "longProposedSolutionRichText";

    protected static final String LONGPROPOSEDSOLUTION_COGNOS_RICHTEXT_ATTRIBUTE = "longProposedSolutionCognosRichText";

    protected static final String LONGREASON_PLAINTEXT_ATTRIBUTE = "longReasonPlainText";

    protected static final String LONGREASON_RICHTEXT_ATTRIBUTE = "longReasonRichText";

    protected static final String LONGREASON_COGNOS_RICHTEXT_ATTRIBUTE = "longReasonCognosRichText";

    protected static final String MODIFYTS_ATTRIBUTE = "modifyTimeStamp";

    protected static final String CREATETS_ATTRIBUTE = "createTimeStamp";

    protected static final String CONTAINERNAME_ATTRIBUTE = "containerName";

    protected static final String ORGANIZATIONIDENTIFIER_ATTRIBUTE = "organizationIdentifier";

    protected static final String STATE_ATTRIBUTE = "state";

    protected static final String FOLDERID_INTERNALNAME = "folder.id";

    protected static final String LONGDESCRIPTION_INTERNALNAME = "longDescription.formattedtext";

    protected static final String LONGPROPOSEDSOLUTION_INTERNALNAME = "longProposedSolution.formattedtext";

    protected static final String LONGREASON_INTERNALNAME = "longReason.formattedtext";

    protected static final String TYPE = "type";

    protected static final String MODIFYTS_INTERNALNAME = "thePersistInfo.modifyStamp";

    protected static final String CREATETS_INTERNALNAME = "thePersistInfo.createStamp";

    protected static final String CONTAINERREFERENCE_INTERNALNAME = "containerReference";

    protected static final String ORGANIZATIONREFERENCE_INTERNALNAME = "masterReference^organizationReference";

    protected static final String STATE_INTERNALNAME = "state.state";

    protected static final String FINDNUMBER = "FINDNUMBER";

    protected static final String FINDNUMBEROLD = "FINDNUMBEROLD";

    protected static final String QUANTITY = "QUANTITY";

    protected static final String QUANTITYOLD = "QUANTITYOLD";

    protected static final String NUMBERATTRIBUTE = "displayIdentifier";

    protected static final String UOM = "UOM";

    protected static final String UOMOLD = "UOMOLD";
    
	//Molla
	protected static final String REVIEWER_INTERNALNAME = "ROLE_REVIEWER";
    protected static final String ASSIGNEE_INTERNALNAME = "ROLE_ASSIGNEE";
	protected static final String CHANGENOTICE_INTERNALNAME="change_owningChangeItem";
	
	protected static final String REVIEWER_ATTRIBUTE = "Approver";
    protected static final String ASSIGNEE_ATTRIBUTE = "Assignee";
	protected static final String CHANGENOTICE_ATTRIBUTE="Change Notice";


    private static final int OLD_OBJECT_INDEX = 0;

    private static final int NEW_OBJECT_INDEX = 1;

    protected Locale locale;

    static IconDelegateFactory iconDelegateFactory;

    private static final String RESOURCE = "com.ptc.windchill.enterprise.change2.reports.change2ReportsResource";

    private static final Logger logger = LogR.getLogger(ChangeItemReportHelper.class.getName());

    protected long incrementor = 0;

    protected String ADDED;

    protected String CHANGED;

    protected String DELETED;

    protected String REPLACED;

    protected static final String DESCRIBES_BY = "DESCRIBES_BY";

    protected static final String REFERENCE_TO = "REFERENCE_TO";

    protected static final String PASSIVE = "CONTENT";

    protected static final String ACTIVE = "OWNER";

    protected static final String USES = "USES";

    private static final String REPORT_FILTER_PROPERTY = "com.ptc.windchill.enterprise.change2.reports.ChangeItemSummaryReportFilter";

    protected ChangeItemReportFilter filter;

    protected static Map<Object, Object> attrMap = new HashMap<Object, Object>();

    protected static final String DEADLINE_ATTRIBUTE = "deadline";

    protected static final String ROLE_ATTRIBUTE = "role";

    private static final String ADMIN_I = "CHANGE ADMINISTRATOR I";

    private static HashMap<Element, Persistable> ElementObjMap = new HashMap<Element, Persistable>();

    private static final String sep = Delimiter.COMMA_SPACE.stringVal();

    static PersistenceManager persistenceManager = PersistenceHelper.manager;

    protected static final String VARIANCE_ITEMID = NUMBER;

    Map<Changeable2, AffectedActivityData> changeableLinkMap = new HashMap<Changeable2, AffectedActivityData>();

    private static MethodLocal<Boolean> USE_THIRD_PARTY_REPORTING = new MethodLocal<Boolean>();

    public static final String REPORTS_PAGE_SIZE_PROPERTY = "wt.change2.reports.pageSize";

    public static final int REPORTS_PAGE_SIZE_DEFAULT = 5000;

    public static final int REPORTS_PAGE_SIZE_NOLIMIT = -1;

    private ReferenceFactory rf = new ReferenceFactory();

    private static final DefinitionDescriptorFactory DESCRIPTOR_FACTORY = (DefinitionDescriptorFactory) DefaultServiceProvider
            .getService(DefinitionDescriptorFactory.class, "default");

    /**
     * Initialized the ChangeItemReportHelper using a locale.
     *
     * <br/>
     * <br/>
     * <b>Supported API: </b>false
     *
     * @param l
     *            A locale
     */
    public ChangeItemReportHelper(Locale l) {
        locale = l;
        initializeReportFilter();
        initializeIdentityHelpers();
        ADDED = WTMessage.getLocalizedMessage(RESOURCE, change2ReportsResource.ADDED, null, l);
        CHANGED = WTMessage.getLocalizedMessage(RESOURCE, change2ReportsResource.CHANGED, null, l);
        DELETED = WTMessage.getLocalizedMessage(RESOURCE, change2ReportsResource.DELETED, null, l);
        REPLACED = WTMessage.getLocalizedMessage(RESOURCE, change2ReportsResource.REPLACED, null, l);
        ON_ORDER_DISPOSITION = WTMessage.getLocalizedMessage(RESOURCE, change2ReportsResource.ONORDERDISPOSITION, null,
                l);
        INVENTORY_DISPOSITION = WTMessage.getLocalizedMessage(RESOURCE, change2ReportsResource.INVENTORYDISPOSITION,
                null, l);
        FINISHED_DISPOSITION = WTMessage.getLocalizedMessage(RESOURCE, change2ReportsResource.FINISHEDDISPOSITION, null,
                l);
        WITHCUSTOMER_DISPOSITION = WTMessage.getLocalizedMessage(RESOURCE, change2ReportsResource.WITHCUSTOMERDISPOSITION, null, l);
        INASSEMBLEDPARTS_DISPOSITION = WTMessage.getLocalizedMessage(RESOURCE, change2ReportsResource.INASSEMBLEDPARTSDISPOSITION, null, l);
        INSERVICECENTER_DISPOSITION = WTMessage.getLocalizedMessage(RESOURCE, change2ReportsResource.INSERVICECENTERDISPOSITION, null, l);

    }

    /**
     * Initialize the report filter using wt.properties. <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    protected void initializeReportFilter() {
        try {
            WTProperties properties = WTProperties.getLocalProperties();
            String filterClass = properties.getProperty(REPORT_FILTER_PROPERTY,
                    "com.ptc.windchill.enterprise.change2.reports.DefaultChangeItemReportFilter");
            Class<?> c = Class.forName(filterClass);
            filter = (ChangeItemReportFilter) c.newInstance();
        } catch (Exception e) {
            logger.error("Unable to find ChangeItemReportFilter using the DefaultChangeItemReportFilter", e);
            filter = new DefaultChangeItemReportFilter();
        }
    }

    /**
     * Initialize the Identity Factories that we'll be using later. <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    protected void initializeIdentityHelpers() {
        iconDelegateFactory = IconDelegateFactory.getInstance();
    }

    /**
     * A small wrapper around ChangeHelper2.service.getChangeablesAfter() <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    protected WTCollection getResultingObjects(WTChangeOrder2 changeNotice) throws WTException {
        createAffectedActivityLinkMap(changeNotice);
        WTCollection resultingObjects = new WTArrayList(ChangeHelper2.service.getChangeablesAfter(changeNotice, false));
        WTCollection hangingChanges = HangingChangeHelper.getService().getHangingChanges(changeNotice,
                HangingChangeHelper.getDefaultStatus(), HangingChangeCriteria.ORIGINAL,
                HangingChangeCriteria.ALL_CA_REV);
        for (Object linkObj : hangingChanges.persistableCollection()) {
            if (linkObj instanceof HangingChangeLink) {
                resultingObjects.add((HangingChangeLink) linkObj);
            }
        }
        if (logger.isDebugEnabled()) {
            logger.debug("resulting objects found are : " + resultingObjects);
        }
        return resultingObjects;
    }

	  
	  /**
   * Molla
   */
	  protected WTCollection getResultingObjects(WTChangeActivity2 changeTask) throws WTException {
      createAffectedActivityLinkMap(changeTask);
      WTCollection resultingObjects = new WTArrayList(ChangeHelper2.service.getChangeablesAfter(changeTask, false));
      WTCollection hangingChanges = HangingChangeHelper.getService().getHangingChanges(changeTask,
              HangingChangeHelper.getDefaultStatus(), HangingChangeCriteria.ORIGINAL, HangingChangeCriteria.ALL_CA_REV);
      for (Object linkObj : hangingChanges.persistableCollection()) {
          if (linkObj instanceof HangingChangeLink) {
              resultingObjects.add((HangingChangeLink) linkObj);
          }
      }
      if(logger.isDebugEnabled()) {
          logger.debug("resulting objects found are : " + resultingObjects);
      }
      return resultingObjects;
  }
    
    /**
     * A small wrapper around ChangeHelper2.service.getSupportingDispositionLinks() <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public WTKeyedMap getSupportingDispositions(WTChangeOrder2 changeNotice) throws WTException {
        createAffectedActivityLinkMap(changeNotice);
        return ChangeHelper2.service.getSupportingDispositionLinks(changeNotice);
    }

    /**
     * Molla
 	*/
	 public WTKeyedMap getSupportingDispositions(WTChangeActivity2 changeTask) throws WTException {
     createAffectedActivityLinkMap(changeTask);
     return ChangeHelper2.service.getSupportingDispositionLinks(changeTask);
	 }

    
    /**
     * Create a map of the changeable object and the affected data link. The map is created using the latest changeable
     * iteration.
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     *
     * @param changeNotice
     * @throws WTException
     */
    private void createAffectedActivityLinkMap(WTChangeOrder2 changeNotice) throws WTException {
        ActionDelegateHelper actionhelper = new ActionDelegateHelper();
        QueryResult qr = ChangeHelper2.service.getChangeablesBefore(changeNotice, false);
        WTCollection links = new WTArrayList();
        if (qr != null) {
            links = new WTArrayList(qr);
        }
        changeableLinkMap = new HashMap<Changeable2, AffectedActivityData>();
        for (Object link : links.persistableCollection()) {
            if (link instanceof AffectedActivityData) {
                Changeable2 changeable = ((AffectedActivityData) link).getChangeable2();
                changeable = (Changeable2) actionhelper.getLatestIteration(changeable);
                changeableLinkMap.put(changeable, (AffectedActivityData) link);
            }
        }
    }
	
	  /**
	   * Molla
	   */
    private void createAffectedActivityLinkMap(WTChangeActivity2 changeTask) throws WTException {
      ActionDelegateHelper actionhelper = new ActionDelegateHelper();
      QueryResult qr = ChangeHelper2.service.getChangeablesBefore(changeTask, false);
      WTCollection links = new WTArrayList();
      if (qr != null) {
          links = new WTArrayList(qr);
      }
      changeableLinkMap = new HashMap<Changeable2, AffectedActivityData>();
      for (Object link : links.persistableCollection()) {
	      if (link instanceof AffectedActivityData) {
	          Changeable2 changeable = ((AffectedActivityData) link).getChangeable2();
	          changeable = (Changeable2) actionhelper.getLatestIteration(changeable);
	          changeableLinkMap.put(changeable, (AffectedActivityData) link);
	      }
      }
    }

    /**
     * Iterate over the resulting objects, adding at least one Element per resulting object to the Group. <BR>
     * <BR>
     * <B>Supported API: </B>false
     *
     * @param resultingObjects
     * @param output
     * @throws WTException
     */
    public void processResultingObjects(WTChangeOrder2 changeNotice, Group output) throws WTException {
        WTCollection affectedObjects = new WTHashSet(ChangeHelper2.service.getChangeablesBefore(changeNotice));
        processResultingObjects(getResultingObjects(changeNotice), affectedObjects, output);
    }
    
    /**
     * Molla
     */	
	public void processResultingObjects(WTChangeActivity2 changeTask, Group output) throws WTException {
        WTCollection affectedObjects = new WTHashSet(ChangeHelper2.service.getChangeablesBefore(changeTask));
        processResultingObjects(getResultingObjects(changeTask), affectedObjects, output);
    }


    protected void processResultingObjects(WTCollection resultingObjects, WTCollection affectedObjects, Group output)
            throws WTException {
        boolean hasCompareError = false;
        for (Object obj : resultingObjects.persistableCollection()) {
            Changeable2 changeable = null;
            BinaryLink link = null;
            boolean validObject = false;
            if (obj instanceof BinaryLink) {
                link = (BinaryLink) obj;
                changeable = (Changeable2) link.getRoleBObject();
                validObject = true;
            }
            else if (obj instanceof Changeable2) {
                changeable = (Changeable2) obj;
                validObject = true;
            }
            if (validObject) {
                Changeable2 oldReleased = (Changeable2) getIterationToCompare(changeable, affectedObjects);

                if (oldReleased == null) {
                    HashMap<String, String> attributesMap = null;
                    if (link != null) {
                        attributesMap = createAttributeMapFor(link);
                    }
                    else {
                        attributesMap = createAttributeMapFor(changeable);
                    }
                    Element elem = constructElement(attributesMap);
                    output.addElement(elem);
                }
                else {
                    try {
                        processResultingObjectWithDiffs(changeable, oldReleased, link, output);
                    } catch (Exception e) {
                        hasCompareError = true;
                        if (logger.isDebugEnabled()) {
                            logger.debug(e.getMessage(), e);
                            logger.debug("changeable: " + changeable);
                            logger.debug("oldReleased: " + oldReleased);
                            logger.debug("output: " + output);
                        }
                        if (logger.isTraceEnabled()) {
                            logger.trace("Object comparison error is ", e);
                        }
                    }
                }
            }
        }
        if (hasCompareError) {
            logger.error("There was an error attempting to render one of the comparisons.");
        }
    }

    /**
     * Given a change object context oid finds all of the related Problem Reports, Variances, Change Requests or Change
     * Notices and remote change associations. The related local and remote change objects are added as elements to the
     * provided I*E group.
     * 
     * <BR>
     * <BR>
     * <B>Supported API: </B>false <BR>
     * 
     * @param contextOid
     * @param group
     * @return The comma delimited attribute sort order
     * @throws WTException
     */
    public String processRelatedChangeItems(String contextOid, Group group) throws WTException {
        String sortOrder = NUMBER;
        WTReference contextRef = ChangeItemReportHelper.getReferenceFromOidString(contextOid);
        if (contextRef != null && ChangeItem.class.isAssignableFrom(contextRef.getReferencedClass())) {
            ChangeItem changeItem = (ChangeItem) contextRef.getObject();
            Boolean orgEnabled = OrganizationServicesHelper.isOrganizationDisplayEnabled()
                    && OrganizationServicesHelper.isOrganizationDisplayEnabled(changeItem.getClass());
            Boolean trackingChangeEnabled = ChangeHelper2.isTrackingChange((WTContained) changeItem);
            WTCollection relatedChangeItems = getRelatedChangeItems(changeItem);
            if (orgEnabled) {
                sortOrder = NUMBER + "," + ORGANIZATIONIDENTIFIER_ATTRIBUTE;
            }

            if (logger.isDebugEnabled()) {
                logger.debug("contextRef: " + contextRef);
                logger.debug("orgEnabled : " + orgEnabled);
                logger.debug("trackingChangeEnabled : " + trackingChangeEnabled);
                logger.debug("has related changes ? " + !relatedChangeItems.isEmpty());
            }

            for (Object relatedChangeObj : relatedChangeItems.persistableCollection()) {
                if (!ChangeItemResource.class.isAssignableFrom(relatedChangeObj.getClass())) {
                    group.addElement(constructElement((VersionableChangeItem) relatedChangeObj, orgEnabled,
                            trackingChangeEnabled));
                }
                else {
                    group.addElement(constructRemoteChangeItemElement(relatedChangeObj));
                }
            }

            processChangeSummaryAttributes(group, true, locale);
        }

        if (logger.isDebugEnabled()) {
            logger.debug("return sort order : " + sortOrder);
        }
        return sortOrder;
    }

    /**
     * Finds all associated change objects for Problem Reports, Variances, Change Requests and Change Notices. Will find
     * the legacy associations when the Flexible association mode is set to Legacy or Mixed. Additionally finds all
     * flexible associations.
     * 
     * <BR>
     * <BR>
     * <B>Supported API: </B>false <BR>
     * 
     * @param changeItem
     * @return a collection of related change objects
     * @throws WTException
     */
    private WTCollection getRelatedChangeItems(ChangeItem changeItem) throws WTException {
        WTCollection relatedChangeItems = new WTHashSet();
        if (!FlexibleChangeHelper.isFlexibleMode() && !FlexibleChangeHelper.isFlexible(changeItem)) {
            logger.debug("finding legacy associations");
            if (changeItem instanceof ChangeIssue) {
                relatedChangeItems.addAll(ChangeHelper2.service.getLatestChangeRequest((ChangeIssue) changeItem));
                relatedChangeItems.addAll(ChangeHelper2.service.getLatestChangeOrder((ChangeIssue) changeItem));
            }
            else if (changeItem instanceof ChangeRequest2) {
                relatedChangeItems.addAll(ChangeHelper2.service.getLatestChangeIssue((ChangeRequest2) changeItem));
                relatedChangeItems.addAll(ChangeHelper2.service.getLatestChangeOrder((ChangeRequest2) changeItem));
            }
            else if (changeItem instanceof ChangeOrder2) {
                relatedChangeItems.addAll(ChangeHelper2.service.getLatestChangeRequest((ChangeOrder2) changeItem));
            }
        }

        if (changeItem instanceof FlexibleChangeItem) {
            logger.debug("finding flexible associations");
            relatedChangeItems.addAll(FlexibleChangeHelper.getService().getFlexibleChangeItems(
                    (FlexibleChangeItem) changeItem,
                    FlexibleChangeLink.ALL_ROLES, true, null));
        }

        return relatedChangeItems;
    }

    /**
     * Create an attribute map for the given changeable with basic/common attributes.
     *
     * @param link
     * @return
     * @throws WTException
     */
    HashMap<String, String> createAttributeMapFor(BinaryLink link) throws WTException {
        HashMap<String, String> attributesMap = createAttributeMapFor(link.getRoleBObject());
	    attributesMap.put("STATE", getState(link));
        if (link instanceof ChangeRecord2) {
            attributesMap.put("TARGETTRANSITION", getTargetTransition((ChangeRecord2) link));
        }
        return attributesMap;
    }

    private HashMap<String, String> createAttributeMapFor(Persistable changeable) throws WTException {
        HashMap<String, String> attributesMap = new HashMap<String, String>();
        if (changeable instanceof Changeable2) {
            attributesMap.put("NAME", getName(changeable));
            attributesMap.put("NUMBER", getNumber(changeable));
            attributesMap.put("ORGID", getOrgID(changeable));
            attributesMap.put("NEWVERSION", getVersion(changeable));
            attributesMap.put("TYPE", getTypeName(changeable));
            attributesMap.put("ICONURL", getIconURL(changeable));
            attributesMap.put("VIEWPAGEURL", getViewPageURL(changeable));
			attributesMap.put("STATE", getState(changeable));
        }
        return attributesMap;
    }

    /**
     * Returns the value of the targetTransition column for the given link
     * 
     * @param obj
     * @return
     */
    private String getTargetTransition(ChangeRecord2 link) throws WTException {
        if (link.getTargetTransition() != null) {
            return link.getTargetTransition().getDisplay(SessionHelper.getLocale());
        }
        return "";
    }

    /**
     * Wrapper for unit testing.
     *
     * @param obj
     * @return result
     * @throws WTException
     * @throws PersistenceException
     */
    QueryResult getAllVersionsFrom(Object obj) throws WTException, PersistenceException {
        return VersionControlHelper.service.allVersionsFrom((Versioned) obj);
    }

    /**
     * Given the oid string this method returns the reference.
     *
     * @param oidString
     * @return ref - the reference
     */
    public static WTReference getReferenceFromOidString(String oidString) {
        ReferenceFactory rf = new ReferenceFactory();
        WTReference ref = null;
        try {
            ref = rf.getReference(oidString);
        } catch (WTException wte) {
            logger.error("Unable to get reference from oidString.", wte);
        }
        return ref;
    }

    /**
     * Iterate over the resulting objects, adding an element for each disposition type on the AffecteedActivityData link
     * of each resulting object to the Group. <BR>
     * <BR>
     * <B>Supported API: </B>false
     *
     * @param resultingObjects
     * @param output
     * @throws WTException
     */
    public void processResultingObjectsForDispositions(WTKeyedMap resultingObjects, Group output) throws WTException {
        for (Object obj : resultingObjects.keySet()) {
            if (obj instanceof ObjectReference) {
                obj = ((ObjectReference) obj).getObject();
            }
            if (obj instanceof Changeable2) {
                Changeable2 resultingObject = (Changeable2) obj;
                AffectedActivityData link = (AffectedActivityData) resultingObjects.get(resultingObject);
                if (link != null) {
                    String disposition = (link.getOnOrderDisposition() != null)
                            ? link.getOnOrderDisposition().getDisplay(locale) : null;
                    Element elem = constructElementForDisposition(resultingObject, ON_ORDER_DISPOSITION, disposition,
                            link.getDispositionComments());
                    output.addElement(elem);
                    disposition = (link.getInventoryDisposition() != null)
                            ? link.getInventoryDisposition().getDisplay(locale) : null;
                    elem = constructElementForDisposition(resultingObject, INVENTORY_DISPOSITION, disposition,
                            link.getDispositionComments());
                    output.addElement(elem);
                    disposition = (link.getFinishedDisposition() != null)
                            ? link.getFinishedDisposition().getDisplay(locale) : null;
                    elem = constructElementForDisposition(resultingObject, FINISHED_DISPOSITION, disposition,
                            link.getDispositionComments());
                    output.addElement(elem);
                    disposition = (AttributeService.getAttribute(link, InventoryDispositions.WITH_CUSTOMERS_IBA) != null) ? (InventoryDispositions.valueOf((String) AttributeService.getAttribute(link, InventoryDispositions.WITH_CUSTOMERS_IBA))).getDisplay(locale) : null;
                    elem = constructElementForDisposition(resultingObject, WITHCUSTOMER_DISPOSITION, disposition, link.getDispositionComments());
                    output.addElement(elem);
                    disposition = (AttributeService.getAttribute(link, InventoryDispositions.IN_ASSEMLED_PARTS_IBA) != null) ? (InventoryDispositions.valueOf((String) AttributeService.getAttribute(link, InventoryDispositions.IN_ASSEMLED_PARTS_IBA))).getDisplay(locale) : null;
                    elem = constructElementForDisposition(resultingObject, INASSEMBLEDPARTS_DISPOSITION, disposition, link.getDispositionComments());
                    output.addElement(elem);
                    disposition = (AttributeService.getAttribute(link, InventoryDispositions.IN_SERVICE_CENTER_IBA) != null) ? (InventoryDispositions.valueOf((String) AttributeService.getAttribute(link, InventoryDispositions.IN_SERVICE_CENTER_IBA))).getDisplay(locale) : null;
                    elem = constructElementForDisposition(resultingObject, INSERVICECENTER_DISPOSITION, disposition, link.getDispositionComments());
                    output.addElement(elem);

                }
            }
        }
    }

    /**
     * This method is called when there is an prior released iteration of the resulting object. This method will utilize
     * a ComparisonResult to generate an Element per attribute difference as well as an Element per WTPartUsageLink
     * addition or removal. <BR>
     * <BR>
     * <B>Supported API: </B>false
     *
     * @param attributesMap
     */
    void processResultingObjectWithDiffs(Changeable2 obj, Changeable2 oldReleased, BinaryLink link, Group output)
            throws WTException {
        if (obj == null) {
            logger.error("Changeable was null.");
            return;
        }

        if (logger.isDebugEnabled()) {
            logger.debug("Changeable is " + obj);
        }

        ComparisonResult cr = getDiff(oldReleased, obj);

        HashMap<String, String> attributesMap = null;
        if (link == null) {
            attributesMap = createAttributeMapFor(obj);
        }
        else {
            attributesMap = createAttributeMapFor(link);
        }
        attributesMap.put("OLDVERSION", getVersion(oldReleased));
		attributesMap.put("OLDSTATE", getState(oldReleased));

        Map<String, List<String>> attrDiffs = getAttributeDifferences(cr);

        if (attrDiffs != null) {
            HashMap<String, String> withAttrDiffMap = new HashMap<>();
            withAttrDiffMap.putAll(attributesMap);
            Set<Entry<String, List<String>>> entries = attrDiffs.entrySet();

            List attrValues = null;
            String key = "";
            String newValue = "";
            String oldValue = "";
            for (Entry entry : entries) {
                key = "";
                newValue = "";
                oldValue = "";

                if (logger.isDebugEnabled()) {
                    logger.debug("key object is " + entry.getKey());
                    logger.debug("value object is " + entry.getValue());
                }

                if (entry.getKey() != null && entry.getValue() != null && entry.getValue() instanceof List) {
                    key = entry.getKey().toString();

                    attrValues = (List) entry.getValue();
                    if (attrValues.get(NEW_OBJECT_INDEX) != null) {
                        newValue = attrValues.get(NEW_OBJECT_INDEX).toString();
                    }
                    if (attrValues.get(OLD_OBJECT_INDEX) != null) {
                        oldValue = attrValues.get(OLD_OBJECT_INDEX).toString();
                    }
                }

                if (logger.isDebugEnabled()) {
                    logger.debug("key is " + key);
                    logger.debug("new value is " + newValue);
                    logger.debug("old value is " + oldValue);
                }

                withAttrDiffMap.put("ATTRNAME", key);
                withAttrDiffMap.put("NEWVALUE", newValue);
                withAttrDiffMap.put("OLDVALUE", oldValue);

                Element elem = constructElement(withAttrDiffMap);
                output.addElement(elem);
            }
        }
        else {
            Element elem = constructElement(attributesMap);
            output.addElement(elem);
        }

        if (obj instanceof WTPart) {
            getLinkDifferences(output, cr, attributesMap);
        }
    }

    /**
     * Create elements for each added/removed.changed/replaced associations for the given changeable object.
     *
     * @param obj
     * @param oldReleased
     * @param output
     * @param cr
     * @param typeName
     * @param iconURL
     * @throws WTException
     */
    private void getLinkDifferences(Group output, ComparisonResult cr, HashMap<String, String> attributesMap) throws WTException {

        processLinks(cr, WTPartUsageLink.class, attributesMap, output);
        processLinks(cr, WTDocumentUsageLink.class, attributesMap, output);
        processLinks(cr, EPMMemberLink.class, attributesMap, output);
        processLinks(cr, WTWorkSetComponentLink.class, attributesMap, output);
        processLinks(cr, WTPartDescribeLink.class, attributesMap, output);
        processLinks(cr, WTPartReferenceLink.class, attributesMap, output);
        processLinks(cr, EPMDescribeLink.class, attributesMap, output);
        processLinks(cr, EPMBuildHistory.class, attributesMap, output);

    }

    /**
     * Retrieve the WTPartUsageLink differences list off the ComparisonResult.
     *
     * If the ComparisonResult is null, null is returned.
     *
     * This method exists to facilitate unit testing. <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    protected List<? extends LinkDiffs> getLinks(ComparisonResult cr, String linkName) {
        if (cr == null) {
            return null;
        }
        Map<String, List<? extends LinkDiffs>> linkDiffs = cr.getLinkDiffsMap();
        if (linkDiffs != null) {
            List<? extends LinkDiffs> usageLinks = linkDiffs.get(linkName);
            return usageLinks;
        }
        return null;
    }

    /**
     * Add Usage Links to the output group. Supported UsageLinks are WTPartUsageLink, WTDocumentUsageLink,
     * EPMMemberLink,
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    protected void processLinks(ComparisonResult cr, Class<? extends BinaryLink> linkClass, HashMap<String, String> attributesMap, Group output)

                    throws WTException {
        List<? extends LinkDiffs> links = getLinks(cr, linkClass.getName());
        if (links != null) {
            ArrayList<Element> removals = new ArrayList<Element>();
            ArrayList<Element> additions = new ArrayList<Element>();

            for (LinkDiffs diff : links) {
                if (diff == null) {
                    continue;
                }
                List<? extends WTReference> linkRefs = diff.getLinkRefs();
                Persistable oldTargetRef = null;
                Persistable newTargetRef = null;
                oldTargetRef = linkRefs.get(OLD_OBJECT_INDEX) != null ? linkRefs.get(OLD_OBJECT_INDEX).getObject() : null;
                newTargetRef = linkRefs.get(NEW_OBJECT_INDEX) != null ? linkRefs.get(NEW_OBJECT_INDEX).getObject() : null;
                String typeOfDifferenceInLink = "";

                addAssociationType(linkClass, attributesMap);

                if (newTargetRef != null) {
                    addLinkSpecificAttributes(newTargetRef, false, attributesMap);
                    if (IteratedUsageLink.class.isAssignableFrom(linkClass)) {
                        addUsageLinkSpecificAttributes((IteratedUsageLink) newTargetRef, false, attributesMap);
                    }

                    if (oldTargetRef != null) {
                        // We have both an old and a new link, so this is a change.
                        typeOfDifferenceInLink = CHANGED;
                        addLinkSpecificAttributes(oldTargetRef, true, attributesMap);
                        if (IteratedUsageLink.class.isAssignableFrom(linkClass)) {
                            addUsageLinkSpecificAttributes((IteratedUsageLink) oldTargetRef, true, attributesMap);
                        }
                    }
                    else {
                        typeOfDifferenceInLink = ADDED;
                        clearOldLinkSpecificAttributes(attributesMap);
                    }
                } else if (oldTargetRef != null) {

                    // This is a delete
                    // We still use the "new" variables because of how the
                    // report is structured.
                    typeOfDifferenceInLink = DELETED;
                    addLinkSpecificAttributes(oldTargetRef, false, attributesMap);
                    clearOldLinkSpecificAttributes(attributesMap);
                    if (IteratedUsageLink.class.isAssignableFrom(linkClass)) {
                        addUsageLinkSpecificAttributes((IteratedUsageLink) oldTargetRef, false, attributesMap);
                    }
                }

                attributesMap.put(STRUCTDIFF, typeOfDifferenceInLink);

                Element elem = constructElement(attributesMap);

                if (CHANGED.equals(typeOfDifferenceInLink)) {
                    output.addElement(elem);

                }
                else if (ADDED.equals(typeOfDifferenceInLink)) {
                    additions.add(elem);
                }
                else if (DELETED.equals(typeOfDifferenceInLink)) {
                    removals.add(elem);
                }
            }
            processAdditionsAndRemovals(additions, removals, output);
        }
    }

    /**
     * Get BinaryLink from reference list and convert proxy to actual link.
     *
     * @param linkRefs
     *            List of link references.
     * @param linkIndex
     *            Index of link to retrieve.
     *
     * @return BinaryLink object at index position (may be null).
     */
    private BinaryLink getBinaryLink(List<? extends WTReference> linkRefs, int linkIndex) {
        if (linkRefs == null || linkIndex < 0 || linkIndex >= linkRefs.size())
            return null;

        BinaryLink link = (BinaryLink) (linkRefs.get(linkIndex) != null ? linkRefs.get(linkIndex).getObject() : null);

        // Beware of link proxies returned in the comparison results, for they are evil and don't work with instanceof
        // checks.
        if (link instanceof Proxy) {
            // Attempt to dig out the actual link object from the proxy.
            InvocationHandler handler = Proxy.getInvocationHandler(link);
            if (handler instanceof AbstractBinaryLinkProxy) {
                link = ((AbstractBinaryLinkProxy) handler).getBinaryLink();
            }
        }
        return link;
    }

    private void addLinkSpecificAttributes(Persistable targetRef, boolean old, HashMap<String, String> attributesMap) throws WTException {
        if (old) {
            attributesMap.put(COMPORGIDOLD, getOrgID(targetRef));
            attributesMap.put(COMPNUMBEROLD, getNumber(targetRef));
            attributesMap.put(COMPNAMEOLD, getName(targetRef));
            attributesMap.put(COMPVERSIONOLD, getVersion(targetRef));
        }
        else {
            attributesMap.put(COMPORGID, getOrgID(targetRef));
            attributesMap.put(COMPNUMBER, getNumber(targetRef));
            attributesMap.put(COMPNAME, getName(targetRef));
            attributesMap.put(COMPVERSION, getVersion(targetRef));
        }
    }

    private void clearOldLinkSpecificAttributes(Map<String, String> attributesMap) throws WTException {
        attributesMap.put(COMPORGIDOLD, "");
        attributesMap.put(COMPNUMBEROLD, "");
        attributesMap.put(COMPNAMEOLD, "");
        attributesMap.put(COMPVERSIONOLD, "");

        clearIfContains(attributesMap, FINDNUMBEROLD);
        clearIfContains(attributesMap, QUANTITYOLD);
        clearIfContains(attributesMap, UOMOLD);
    }

    /**
     * Checks if the given map contains the passed in key. If it does, it sets the value associated with that key to "".
     * 
     * @param attributesMap
     * @param key
     */
    private void clearIfContains(Map<String, String> attributesMap, String key) {
        if (attributesMap.containsKey(key)) {
            attributesMap.put(key, "");
        }
    }

    /**
     * Gets the attributes specific to IteratedUsageLink and stores it in the attrMap
     *
     * @param target
     *            IteratedUsageLink
     * @param old
     *            - indicates whether old or new target
     *
     *            <BR>
     *            <BR>
     *            <B>Supported API: </B>false
     */
    protected void addUsageLinkSpecificAttributes(IteratedUsageLink target, boolean old,
            HashMap<String, String> attributesMap) {
        String findNumber = getFindNumber(target);
        String qtyAmt = getQuantityAmount(target);
        String qtyUnit = getQuantityUnit(target);

        if (target instanceof WTPartUsageLink) {
            if (old) {
                attributesMap.put(FINDNUMBEROLD, findNumber);
            }
            else {
                attributesMap.put("FINDNUMBER", findNumber);
            }
        }

        if (old) {
            attributesMap.put(QUANTITYOLD, qtyAmt);
            attributesMap.put(UOMOLD, qtyUnit);
        }
        else {
            attributesMap.put("QUANTITY", qtyAmt);
            attributesMap.put("UOM", qtyUnit);
        }
    }

    private String getFindNumber(IteratedUsageLink target) {
        return (target instanceof WTPartUsageLink) ? ((WTPartUsageLink) target).getFindNumber() : null;
    }

    private Quantity getQuantity(IteratedUsageLink target) {
        if (target instanceof WTPartUsageLink) {
            return ((WTPartUsageLink) target).getQuantity();
        }
        else if (target instanceof EPMMemberLink) {
            return ((EPMMemberLink) target).getQuantity();
        }
        return null;
    }

    private String getQuantityAmount(IteratedUsageLink target) {
        Quantity quantity = getQuantity(target);
        String amount = (quantity != null) ? new Double(quantity.getAmount()).toString() : "";
        QuantityUnit unit = (quantity != null) ? quantity.getUnit() : null;
        if (QuantityUnit.EA.equals(unit)) {
            amount = amount.substring(0, amount.indexOf('.'));
        }
        return amount;
    }

    private String getQuantityUnit(IteratedUsageLink target) {
        Quantity quantity = getQuantity(target);
        return (quantity != null) ? quantity.getUnit().getDisplay(locale) : "";
    }

    /**
     * Rationalize any DELETE,ADD pair that happens to really be a REPLACE A Replace is when the Find Number is the same
     * for the DELETE, ADD pair.
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    protected void processAdditionsAndRemovals(ArrayList<Element> additions, ArrayList<Element> removals, Group output)
            throws WTException {
        for (Element removedComp : removals) {
            String removedFindNumber = (String) removedComp.getAtt("FINDNUMBER").getRawValue();

            if (removedFindNumber == null || "".equals(removedFindNumber)) {
                output.addElement(removedComp);
                continue;
            }

            Element matchingComp = null;

            for (Element addedComp : additions) {
                String addedFindNumber = (String) addedComp.getAtt("FINDNUMBER").getRawValue();

                if (addedFindNumber == null || "".equals(addedFindNumber)) {
                    continue;
                }

                if (addedFindNumber.equals(removedFindNumber)) {
                    matchingComp = addedComp;
                    break;
                }
            }

            if (matchingComp != null) {
                additions.remove(matchingComp);
                Element elementToAdd = convertToReplace(removedComp, matchingComp);
                output.addElement(elementToAdd);
            }
            else {
                output.addElement(removedComp);
            }
        }

        for (Element addedComp : additions) {
            output.addElement(addedComp);
        }
    }

    /**
     * This method utilizes the ObjectComparison module to compare the passed in objects. It returns a ComparisonResult
     * where the zeroth index in all lists is the oldObject and the next index is the newObject. <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    protected ComparisonResult getDiff(Iterated oldObject, Iterated newObject) throws WTException {
        WTList compareList = new WTArrayList(2);
        // Note that OLD_OBJECT_INDEX and NEW_OBJECT_INDEX are dependent on the
        // order that these two
        // elements are added to this list.
        compareList.add(oldObject);
        compareList.add(newObject);
        AdvancedComparisonSpec spec = ComparisonSpec.newAdvancedInstance(compareList);

        spec.setSelectedAttrs(filter.getAttributesToCompare(newObject));

        XmlConfigResourceHandler handler = new XmlConfigResourceHandler();
        spec.setSelectedLinks(handler.getConfiguredLinksForDomainType(compareList.getReference(0)));

        if (logger.isDebugEnabled()) {
            logger.debug("the compare spec is : " + spec);
        }

        return ObjComparisonHelper.service.compareDomainObjs(spec);
    }

    /**
     * This method will find the most recent, but prior iteration that is an affected object on the change notice. If
     * the there is no iteration that is an affected object it will use the latest iteration of the previous revision.
     * If there is no previous revision then null is returned.
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    protected Iterated getIterationToCompare(Iterated obj, WTCollection affectedObjects) throws WTException {
        if (obj instanceof Versioned) {
            Versioned versioned = (Versioned) obj;
            String currentVersion = null;
            if (versioned.getVersionIdentifier() != null) {
                currentVersion = versioned.getVersionIdentifier().getValue();
            }
            Iterated latestIterationOfPreviousRevision = null;
            QueryResult allIterations = VersionControlHelper.service.allIterationsFrom(obj);

            while (allIterations.hasMoreElements()) {
                Iterated p = (Iterated) allIterations.nextElement();

                if (!obj.equals(p)) {

                    if (affectedObjects.contains(p)) {
                        if (logger.isDebugEnabled()) {
                            logger.debug("Using the following iteration form the affected objects " + p);
                        }
                        return p;
                    }
                    else if (latestIterationOfPreviousRevision == null
                            && currentVersion != null
                            && ((Versioned) p).getVersionIdentifier().getValue() != null
                            && !currentVersion.equals(((Versioned) p).getVersionIdentifier().getValue())) {
                        latestIterationOfPreviousRevision = p;
                    }
                }
            }
            if (logger.isDebugEnabled()) {
                logger.debug("Unable to find an iteration in the affected objects, using iteration "
                        + latestIterationOfPreviousRevision);
            }
            return latestIterationOfPreviousRevision;

        }
        return null;
    }

    /**
     * 
     * /** Retrieve the attribute differences map off the ComparisonResult. If the ComparisonResult is null, null is
     * returned.
     *
     * This method exists to facilitate unit testing. <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    protected Map<String, List<String>> getAttributeDifferences(ComparisonResult cr) {
        if (cr == null || cr.getAttrDiffs() == null) {
            return null;
        }

        return cr.getAttrDiffs().getDiffs();
    }

    /**
     * Use the IdentityFactory to get the display name of the type of the passed in object. <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    protected String getTypeName(Object obj) throws WTException {
        return IdentityFactory.getDisplayType(obj).getLocalizedMessage(locale);
    }

    /**
     * Use the IconDelegateFactory to get the URL to the Icon for this object. <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    protected static String getIconURL(Persistable obj) throws WTException {
        try {
            if (iconDelegateFactory == null)
                iconDelegateFactory = IconDelegateFactory.getInstance();
            IconDelegate iconDelegate = iconDelegateFactory.getIconDelegate((WTObject) obj);
            return IconCache.getIconResource(iconDelegate, true);
        } catch (Exception e) {
            if (e instanceof WTException) {
                throw (WTException) e;
            }

            throw new WTException(e);
        }
    }

    /**
     * Use reflection to call .getName() on the passed in object.
     *
     * If the object does not have a .getName() method, then we will attempt to get the identity.<BR>
     *
     * If still no name is found, and the object is a part instance, just use number.<BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    protected String getName(Object object) {
        Object obj = object;
        if (logger.isDebugEnabled()) {
            logger.debug("Attempting to getName for " + obj);
        }
        if (obj instanceof BinaryLink) {
            obj = getOtherSideObject(obj);
        }
        String name = "";
        if(obj == null) {
            logger.debug("Other side of link not found.");
            return name;
        }

        try {
            name = (String) obj.getClass().getMethod("getName").invoke(obj);
        } catch (Exception e) {
            logger.debug("Unable to get name from object, attempt to get the display identifier", e);
            name = IdentityFactory.getDisplayIdentifier(obj).getLocalizedMessage(locale);
        }

        if ((name == null || name.isEmpty()) && obj instanceof WTProductInstance2) {
            name = getNumber(object);
        }
        return name;
    }

    /**
     * use reflection to call .getNumber() on the passed in object.
     *
     * If the object does not have a .getNumber() method then obj.toString() is returned. <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    protected String getNumber(Object object) {
        Object obj = object;
        if (logger.isDebugEnabled()) {
            logger.debug("Attempting to getName for " + obj);
        }
        if (obj instanceof BinaryLink) {
            obj = getOtherSideObject(obj);
        }
        if(obj == null) {
            logger.debug("Other side of link not found.");
            return "";
        }

        try {
            String number = (String) obj.getClass().getMethod("getNumber").invoke(obj);
            return number;
        } catch (Exception e) {
            logger.debug("Unable to get number from object, attempt to get the display identifier", e);
            return IdentityFactory.getDisplayIdentifier(obj).getLocalizedMessage(locale);
        }
    }

    /**
     * Retrieve the Organization ID of the passed in object if OrgID display is enabled.
     *
     * If OrgID Display is disabled then the empty string is returned. <BR>
     * <BR>
     * <B>Supported API: </B>false
     * 
     * @throws WTException
     */
    protected String getOrgID(Object object) throws WTException {
        if (OrganizationServicesHelper.isOrganizationDisplayEnabled()) {
            Object obj = object;
            if (object instanceof BinaryLink) {
                obj = getOtherSideObject(object);
            }

            WTOrganization org = null;

            if (obj instanceof WTOrganization) {
                org = (WTOrganization) obj;
            }
            else if (obj instanceof OrganizationOwned) {
                boolean enforced = SessionServerHelper.manager.setAccessEnforced(false);
                try {
                    org = ((OrganizationOwned) obj).getOrganization();
                } finally {
                    SessionServerHelper.manager.setAccessEnforced(enforced);
                }
            }

            if (org != null && AccessControlHelper.manager.hasAccess(org, AccessPermission.READ) &&
                    org.getOrganizationIdentifier() != null) {
                String orgId = org.getOrganizationIdentifier().getUniqueIdentifier();
                return orgId;
            }
        }
        // We aren't displaying Secured information in the case the user doesn't have access to the change objects
        // because this value is used in the identity of the object.
        return "";
    }

    /**
     * Finds the otherSide object of the association for the context Changeable.
     * 
     * @param linkObject
     * @return
     */
    private Persistable getOtherSideObject(Object linkObject) {
        Persistable obj = null;
        if(logger.isDebugEnabled()) {
            logger.debug("linkObject is " + linkObject);
            logger.debug("linkObject class " + linkObject.getClass());
            logger.debug("linkObject class name " + linkObject.getClass().getName());
        }
        if (linkObject instanceof IteratedUsageLink) {
            obj = ((IteratedUsageLink) linkObject).getUses();
        } else if (linkObject instanceof IteratedDescribeLink) {
            obj = ((IteratedDescribeLink) linkObject).getDescribedBy();
        } else if (linkObject instanceof IteratedReferenceLink) {
            obj = ((IteratedReferenceLink) linkObject).getReferences();
        } else if (linkObject instanceof EPMBuildHistory) {
            obj = ((EPMBuildHistory) linkObject).getBuiltBy();
        } else if (linkObject instanceof EPMBuildRule) {
            obj = ((EPMBuildRule)linkObject).getBuildTarget();
        }
        if(logger.isDebugEnabled()) {
            logger.debug("getOtherSideObject" + linkObject);
        }
        return obj;

    }
    
    /**
     * Return the iteration display identifier and view name.
     *
     * If any error occurs getting the version information then obj.toString() is returned. <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    protected String getVersion(Object obj) {
  

        try {
            wt.util.LocalizableMessage message = VersionControlHelper.getIterationDisplayIdentifier((Versioned) obj);
            String versionDisplay = message.getLocalizedMessage(locale);

            if (obj instanceof ViewManageable) {
                String viewName = ((ViewManageable) obj).getViewName();

                if (viewName != null) {
                    versionDisplay += " (" + viewName + ")";
                }
            }

            return versionDisplay;
        } catch (Exception e) {
            logger.error("Unable to get version for object.", e);
            return obj.toString();
        }
    }

    /**
     * A Simple wrapper to extract the raw string value of an attribute from an InfoEngine Element. <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    protected String getAtt(Element elem, String attrName) {
        Att att = elem.getAtt(attrName);

        if (att == null) {
            return null;
        }

        return (String) att.getRawValue();
    }

	/**
     * Molla
     */
	protected String getState(Persistable p) {
      
     if (!(p instanceof LifeCycleManaged)) {
         return null;
      }

      LifeCycleManaged lcm = (LifeCycleManaged) p;	  

        if (lcm == null) {
            return null;
        }

        return (String) lcm.getLifeCycleState().toString();
    }

	
	protected String getState(BinaryLink p) {
      
     if (!(p instanceof LifeCycleManaged)) {
         return null;
      }

      LifeCycleManaged lcm = (LifeCycleManaged) p;	  

        if (lcm == null) {
            return null;
        }

        return (String) lcm.getLifeCycleState().toString();
    }

    
    /**
     * Convert the passed in DELETE element and ADD element into a REPLACE element.
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    protected Element convertToReplace(Element removedComp, Element addedComp) {
        HashMap<String, String> attributesMap = new HashMap<String, String>();
        attributesMap.put("NAME", getAtt(addedComp, "NAME"));
        attributesMap.put("NUMBER", getAtt(addedComp, "NUMBER"));
        attributesMap.put("ORGID", getAtt(addedComp, "ORGID"));
        attributesMap.put("NEWVERSION", getAtt(addedComp, "NEWVERSION"));
        attributesMap.put("OLDVERSION", getAtt(addedComp, "OLDVERSION"));
        attributesMap.put("ATTRNAME", getAtt(addedComp, "ATTRNAME"));
        attributesMap.put("NEWVALUE", getAtt(addedComp, "NEWVALUE"));
        attributesMap.put("OLDVALUE", getAtt(addedComp, "OLDVALUE"));
        attributesMap.put(COMPTYPE, getAtt(addedComp, COMPTYPE));
        attributesMap.put(LINKTYPE, getAtt(addedComp, LINKTYPE));

        attributesMap.put(STRUCTDIFF, REPLACED);

        attributesMap.put("TYPE", getAtt(addedComp, "TYPE"));
        attributesMap.put("ICONURL", getAtt(addedComp, "ICONURL"));
        attributesMap.put("VIEWPAGEURL", getAtt(addedComp, "VIEWPAGEURL"));

        attributesMap.put("FINDNUMBER", getAtt(addedComp, "FINDNUMBER"));
        attributesMap.put(FINDNUMBEROLD, getAtt(removedComp, "FINDNUMBER"));

        attributesMap.put("QUANTITY", getAtt(addedComp, "QUANTITY"));
        attributesMap.put(QUANTITYOLD, getAtt(removedComp, "QUANTITY"));
        attributesMap.put("UOM", getAtt(addedComp, "UOM"));
        attributesMap.put(UOMOLD, getAtt(removedComp, "UOM"));

        attributesMap.put(COMPNUMBER, getAtt(addedComp, COMPNUMBER));
        attributesMap.put(COMPNUMBEROLD, getAtt(removedComp, COMPNUMBER));

        attributesMap.put(COMPNAME, getAtt(addedComp, COMPNAME));
        attributesMap.put(COMPNAMEOLD, getAtt(removedComp, COMPNAMEOLD));

        attributesMap.put(COMPORGID, getAtt(addedComp, COMPORGID));
        attributesMap.put(COMPORGIDOLD, getAtt(removedComp, COMPORGID));

        attributesMap.put(COMPVERSION, getAtt(addedComp, COMPVERSION));
        attributesMap.put(COMPVERSIONOLD, getAtt(removedComp, COMPVERSIONOLD));

        return constructElement(attributesMap);
    }

    /**
     * Construct an InfoEngine Element and assign it attributes for the passed in parameters.
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    protected Element constructElement(HashMap<String, String> attributesMap) {

        Element element = new Element();

        // we need to set a unique identifier for this element so that it can be
        // stored in lists and maps.
        // it only needs to be unique relative to the rest of the elements for a
        // particular resulting
        // object
        // we ensure that it's unique across all resulting objects by using a
        // simple member-variable incrementor
        element.setUfid("" + incrementor++);
        element.addAtt(new Att("NAME", getAttributeValue(attributesMap, "NAME")));
        element.addAtt(new Att("NUMBER", getAttributeValue(attributesMap, "NUMBER")));
        element.addAtt(new Att("ORGID", getAttributeValue(attributesMap, "ORGID")));
        element.addAtt(new Att("NEWVERSION", getAttributeValue(attributesMap, "NEWVERSION")));
        element.addAtt(new Att("OLDVERSION", getAttributeValue(attributesMap, "OLDVERSION")));
        element.addAtt(new Att("ATTRNAME", getAttributeValue(attributesMap, "ATTRNAME")));
        element.addAtt(new Att("NEWVALUE", getAttributeValue(attributesMap, "NEWVALUE")));
        element.addAtt(new Att("OLDVALUE", getAttributeValue(attributesMap, "OLDVALUE")));
        element.addAtt(new Att(COMPTYPE, getAttributeValue(attributesMap, COMPTYPE)));
        element.addAtt(new Att(LINKTYPE, getAttributeValue(attributesMap, LINKTYPE)));
        element.addAtt(new Att(STRUCTDIFF, getAttributeValue(attributesMap, STRUCTDIFF)));

        element.addAtt(new Att("TYPE", getAttributeValue(attributesMap, "TYPE")));
        element.addAtt(new Att("ICONURL", getAttributeValue(attributesMap, "ICONURL")));
        element.addAtt(new Att("VIEWPAGEURL", getAttributeValue(attributesMap, "VIEWPAGEURL")));
        element.addAtt(new Att("TARGETTRANSITION", getAttributeValue(attributesMap, "TARGETTRANSITION")));

        element.addAtt(new Att("FINDNUMBER", getAttributeValue(attributesMap, "FINDNUMBER")));
        element.addAtt(new Att(FINDNUMBEROLD, getAttributeValue(attributesMap, FINDNUMBEROLD)));

        element.addAtt(new Att("QUANTITY", getAttributeValue(attributesMap, "QUANTITY")));
        element.addAtt(new Att(QUANTITYOLD, getAttributeValue(attributesMap, QUANTITYOLD)));
        element.addAtt(new Att("UOM", getAttributeValue(attributesMap, "UOM")));
        element.addAtt(new Att(UOMOLD, getAttributeValue(attributesMap, UOMOLD)));

        element.addAtt(new Att(COMPNUMBER, getAttributeValue(attributesMap, COMPNUMBER)));
        element.addAtt(new Att(COMPNUMBEROLD, getAttributeValue(attributesMap, COMPNUMBEROLD)));

        element.addAtt(new Att(COMPNAME, getAttributeValue(attributesMap, COMPNAME)));
        element.addAtt(new Att(COMPNAMEOLD, getAttributeValue(attributesMap, COMPNAMEOLD)));

        element.addAtt(new Att(COMPORGID, getAttributeValue(attributesMap, COMPORGID)));
        element.addAtt(new Att(COMPORGIDOLD, getAttributeValue(attributesMap, COMPORGIDOLD)));

        element.addAtt(new Att(COMPVERSION, getAttributeValue(attributesMap, COMPVERSION)));
        element.addAtt(new Att(COMPVERSIONOLD, getAttributeValue(attributesMap, COMPVERSIONOLD)));

        return element;
    }

    /**
     * Construct an InfoEngine Element for a disposition assigning it the attributes passed in.
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    protected Element constructElementForDisposition(Changeable2 resultingObject, String dispositionKey,
            String dispositionValue,
            String dispositionComments) {

        Element element = new Element();

        // we need to set a unique identifier for this element so that it can be
        // stored in lists and maps.
        // it only needs to be unique relative to the rest of the elements for a
        // particular resulting
        // object
        // we ensure that it's unique across all resulting objects by using a
        // simple member-variable incrementor
        element.setUfid("" + incrementor++);
        element.addAtt(new Att("NUMBER", getNumber(resultingObject)));
        element.addAtt(new Att(DISPOSITION_KEY, dispositionKey));
        element.addAtt(new Att(DISPOSITION_VALUE, dispositionValue));
        element.addAtt(new Att(DISPOSITION_COMMENTS, dispositionComments));

        return element;
    }

    /**
     * Constructs a new <code>Element</code> from the given change item.
     * 
     * @param attributesMap
     * @return
     * @throws WTException
     */
    private Element constructElement(VersionableChangeItem changeItem, boolean orgEnabled,
            boolean trackingChangeEnabled)
                    throws WTException {
        Element element = new Element();
        element.setUfid(String.valueOf(incrementor++));

        element.addAtt(new Att(OBID, PersistenceHelper.getObjectIdentifier(changeItem)));
        element.addAtt(new Att(VersionableChangeItem.TYPE, changeItem.getDisplayType().getLocalizedMessage(locale)));
        element.addAtt(new Att(NUMBER, getNumber(changeItem)));

        ReferenceFactory refFactory = new ReferenceFactory();

        if (orgEnabled) {
            element.addAtt(new Att(ORGANIZATIONREFERENCE_INTERNALNAME,
                    refFactory.getReferenceString(changeItem.getOrganizationReference())));
        }

        if (trackingChangeEnabled) {
            element.addAtt(new Att(VERSION, getVersion(changeItem)));
        }

        element.addAtt(new Att(NAME, getName(changeItem)));

        if (changeItem.getState() != null) {
            element.addAtt(new Att(STATE_INTERNALNAME, changeItem.getState().toString()));
        }

        if (changeItem instanceof WTContained) {
            element.addAtt(new Att(CONTAINERREFERENCE_INTERNALNAME,
                    refFactory.getReferenceString(((WTContained) changeItem).getContainerReference())));
        }
        element.addAtt(new Att(VersionableChangeItem.DISPLAY_IDENTIFIER, changeItem.getDisplayIdentifier()));
        return element;
    }

    /**
     * Will construct an Info*Engine element for remote change item
     * 
     * @param relatedchangeItem
     * @return element
     */
    private Element constructRemoteChangeItemElement(Object relatedchangeItem) throws WTException {
        Element element = new Element();
        element.setUfid(String.valueOf(incrementor++));

        Persistable remoteObj = (Persistable) relatedchangeItem;
        WTReference objRef = OidHelper.getWTReference(remoteObj);
        String oidStr = rf.getReferenceString(objRef);

        Element node = ChangeHelper2.service.getRemoteChangeObject(oidStr);

        element.addAtt(new Att(OBID, PersistenceHelper.getObjectIdentifier(remoteObj)));
        element.addAtt(new Att(VersionableChangeItem.TYPE,
                IdentityFactory.getDisplayType(remoteObj).getLocalizedMessage(locale)));

        element.addAtt(node.getAtt(NUMBER));
        element.addAtt(node.getAtt(NAME));

        return element;
    }

    /**
     * return element; }
     *
     * /** gets the value for the given attribute from the attributeMap.
     *
     * @param attributesMap
     * @param name
     * @return
     */
    private String getAttributeValue(HashMap<String, String> attributesMap, String name) {
        String value = "";
        if (attributesMap.get(name) != null) {
            value = attributesMap.get(name);
        }
        return value;
    }

    /**
     * This would basically prune the attributes for the Change Summary Report. In some cases we would like to change
     * the attribute names for supporting internalization. In other cases we might have to replace the reference
     * attributes with attributes of the reference object.
     *
     * processAll - processes all attributes. If false, only processes attributes that are common to all attributes.
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     *
     * @throws WTException
     */
    public static void processChangeSummaryAttributes(Group group, boolean processHeader, Locale locale)
            throws WTException {

        if (group != null && group.getElementCount() > 0) {
            Enumeration<?> elements = group.getElements();
            while (elements.hasMoreElements()) {
                Element element = (Element) elements.nextElement();
                if (logger.isDebugEnabled()) {
                    logger.debug("iterating elements: " + element);
                }
                replaceAttributesWithDisplayValue(ATTRTYPE_ENUMERATED, element, STATE_INTERNALNAME, STATE_ATTRIBUTE,
                        State.class, locale);
                replaceAttributesWithDisplayValue(ATTRTYPE_REFERENCE, element, ORGANIZATIONREFERENCE_INTERNALNAME,
                        ORGANIZATIONIDENTIFIER_ATTRIBUTE,
                        null, locale);
                replaceAttributesWithDisplayValue(ATTRTYPE_REFERENCE, element, CONTAINERREFERENCE_INTERNALNAME,
                        CONTAINERNAME_ATTRIBUTE, null, locale);

                WTReference wtRef = getWTReference(element);
                if (wtRef != null) {
                    Persistable obj = wtRef.getObject();
                    if (useThirdPartyReporting()) {
                        element.addAtt(new Att("VIEWPAGEURL", getViewPageURL(obj)));
                        element.addAtt(new Att("ICONURL", getIconURL(obj)));
                    }
                    else {
                        createLinkForNumberAttribute(element, obj);
                    }
                }

                addChangeAdmin1Column(element, locale);

                if (processHeader) {
                    if (element.getValue(LONGDESCRIPTION_INTERNALNAME) != null) {
                        element.addAtt(new Att(LONGDESCRIPTION_RICHTEXT_ATTRIBUTE,
                                element.getValue(LONGDESCRIPTION_INTERNALNAME)));
                        element.addAtt(new Att(LONGDESCRIPTION_COGNOS_RICHTEXT_ATTRIBUTE, getDisplayValueForRichText(
                                (String) element.getValue(LONGDESCRIPTION_INTERNALNAME), true)));
                    }
                    if (element.getValue(LONGPROPOSEDSOLUTION_INTERNALNAME) != null) {
                        element.addAtt(new Att(LONGPROPOSEDSOLUTION_RICHTEXT_ATTRIBUTE,
                                element.getValue(LONGPROPOSEDSOLUTION_INTERNALNAME)));
                        element.addAtt(
                                new Att(LONGPROPOSEDSOLUTION_COGNOS_RICHTEXT_ATTRIBUTE, getDisplayValueForRichText(
                                        (String) element.getValue(LONGPROPOSEDSOLUTION_INTERNALNAME), true)));
                    }
                    if (element.getValue(LONGREASON_INTERNALNAME) != null) {
                        element.addAtt(
                                new Att(LONGREASON_RICHTEXT_ATTRIBUTE, element.getValue(LONGREASON_INTERNALNAME)));
                        element.addAtt(new Att(LONGREASON_COGNOS_RICHTEXT_ATTRIBUTE, getDisplayValueForRichText(
                                (String) element.getValue(LONGREASON_INTERNALNAME), true)));
                    }
                    replaceAttributesWithDisplayValue(TYPE, element, TYPE, null, null, locale);
                    replaceAttributesWithDisplayValue(ATTRTYPE_ENUMERATED, element, ISSUEPRIORITYATTRIBUTE, null,
                            IssuePriority.class, locale);
                    replaceAttributesWithDisplayValue(ATTRTYPE_ENUMERATED, element, REQUESTPRIORITYATTRIBUTE, null,
                            RequestPriority.class, locale);
                    replaceAttributesWithDisplayValue(ATTRTYPE_ENUMERATED, element, COMPLEXITYATTRIBUTE, null,
                            Complexity.class, locale);
                    replaceAttributesWithDisplayValue(ATTRTYPE_ENUMERATED, element, CATEGORYATTRIBUTE, null,
                            Category.class, locale);
                    replaceAttributesWithDisplayValue(ATTRTYPE_ENUMERATED, element, VARIANCECATEGORYATTRIBUTE, null,
                            VarianceCategory.class, locale);
                    replaceAttributesWithDisplayValue(ATTRTYPE_ENUMERATED, element, CHANGENOTICECOMPLEXITYATTRIBUTE,
                            null,
                            ChangeNoticeComplexity.class, locale);

                    replaceAttributesWithDisplayValue(ATTRTYPE_DATE, element, NEEDDATEATTRIBUTE, null, null, locale);
                    replaceAttributesWithDisplayValue(ATTRTYPE_DATE, element, RESOLUTIONDATEATTRIBUTE, null, null,
                            locale);

                    replaceAttributesWithDisplayValue(ATTRTYPE_TIMESTAMP, element, CREATETS_INTERNALNAME,
                            CREATETS_ATTRIBUTE, null, locale);
                    replaceAttributesWithDisplayValue(ATTRTYPE_TIMESTAMP, element, MODIFYTS_INTERNALNAME,
                            MODIFYTS_ATTRIBUTE, null, locale);

                    replaceAttributesWithDisplayValue(ATTRTYPE_REFERENCE, element, VARIANCEOWNERATTRIBUTE, null, null,
                            locale);
                    replaceAttributesWithDisplayValue(ATTRTYPE_REFERENCE, element, FOLDERID_INTERNALNAME,
                            FOLDERID_ATTRIBUTE, null, locale);
                    replaceAttributesWithDisplayValue(ATTRTYPE_RICHTEXT, element, LONGDESCRIPTION_INTERNALNAME,
                            LONGDESCRIPTION_PLAINTEXT_ATTRIBUTE, null, locale);
                    replaceAttributesWithDisplayValue(ATTRTYPE_RICHTEXT, element, LONGPROPOSEDSOLUTION_INTERNALNAME,
                            LONGPROPOSEDSOLUTION_PLAINTEXT_ATTRIBUTE, null, locale);
                    replaceAttributesWithDisplayValue(ATTRTYPE_RICHTEXT, element, LONGREASON_INTERNALNAME,
                            LONGREASON_PLAINTEXT_ATTRIBUTE, null, locale);
					//Molla
					
					replaceAttributesWithDisplayValue(ATTRTYPE_REFERENCE, element, REVIEWER_INTERNALNAME, REVIEWER_ATTRIBUTE, null, locale);
                    replaceAttributesWithDisplayValue(ATTRTYPE_REFERENCE, element, ASSIGNEE_INTERNALNAME, ASSIGNEE_ATTRIBUTE, null, locale);
					replaceAttributesWithDisplayValue(ATTRTYPE_REFERENCE, element, CHANGENOTICE_INTERNALNAME, CHANGENOTICE_ATTRIBUTE, null, locale);

                }
            }
        }
    }

    private static void createLinkForNumberAttribute(Element element, Persistable obj) throws WTException {
        String url = getViewPageURL(obj);
        String name = "";
        String href = "javascript:if(top){top.location='" + url + "';}else{window.location='" + url + "';}";
        Att attribute = element.getAtt(NUMBERATTRIBUTE);
        if (attribute != null) {
            element.removeAtt(NUMBERATTRIBUTE);
            attribute.setName(NUMBERATTRIBUTE);
            name = attribute.getValue().toString();
            if (logger.isDebugEnabled()) {
                logger.debug("name:" + name);
                logger.debug("url: " + href);
            }
            attribute.setValue(new Hyperlink(href, name));
            element.addAtt(attribute);
        }
    }

    /**
     * replaces the reference attributes with display value.
     *
     * @param attributeType
     * @param element
     * @param attributeInternal
     * @param attributeToRender
     * @param enumeratedType
     * @param locale
     * @throws WTException
     */
    public static void replaceAttributesWithDisplayValue(String attributeType, Element element,
            String attributeInternal, String attributeToRender, Class<?> enumeratedType, Locale locale)
                    throws WTException {
        String displayValue = null;
        if (element != null && attributeInternal != null) {
            Att attribute = element.getAtt(attributeInternal);

            if (logger.isDebugEnabled()) {
                logger.debug("attribute  " + attribute);
                logger.debug("attributeType  " + attributeType);
            }

            if (attribute != null) {
                if (ATTRTYPE_ENUMERATED.equals(attributeType)) {
                    if (enumeratedType != null) {
                        if (!(("").equals(element.getValue(attributeInternal)))) {
                            displayValue = getDisplayValueForEnumerated(enumeratedType,
                                    (String) element.getValue(attributeInternal), locale);
                        }
                    }
                    else {
                        logger.debug("The enumeratedType is null, but is required to get the localized value ");
                    }
                }
                else if (ATTRTYPE_DATE.equals(attributeType) || ATTRTYPE_TIMESTAMP.equals(attributeType)) {
                    boolean isDate = (ATTRTYPE_DATE.equals(attributeType)) ? true : false;
                    Object attrValue = element.getValue(attributeInternal);
                    Date attrDate = null;
                    if (attrValue instanceof Date) {
                        attrDate = (Date) attrValue;
                        if (attrValue instanceof WrappedTimestamp) {
                            attrDate = new Date(((WrappedTimestamp) attrValue).getTime());
                        }
                    }
                    if (attrDate != null) {
                        displayValue = getDisplayValueForDate(attrDate, locale, isDate);
                    }
                }
                else if (ATTRTYPE_REFERENCE.equals(attributeType)) {
                    displayValue = getDisplayValueForReferences((String) element.getValue(attributeInternal));

                }
                else if (ATTRTYPE_RICHTEXT.equals(attributeType)) {
                    displayValue = getDisplayValueForRichText((String) element.getValue(attributeInternal), false);
                }
                else if (TYPE.equals(attributeType)) {
                    TypeIdentifier typeId[] = null;
                    Att attType = element.getAtt(TYPE);

                    if (attType != null && attType.getAttributeTypeIdentifier() != null) {
                        typeId = new TypeIdentifier[1];
                        typeId[0] = attType.getAttributeTypeIdentifier().getContext();
                    }

                    if (logger.isDebugEnabled()) {
                        logger.debug("attType  " + attType);
                        logger.debug("Type Identifier  " + typeId);
                    }

                    if (typeId != null) {
                        Map<TypeIdentifier, String> dispNameMap = getLocalizedDisplayValueforType(typeId, locale);
                        if (dispNameMap != null && dispNameMap.size() == 1) {
                            displayValue = dispNameMap.get(typeId[0]);
                        }
                    }
                }

                if (logger.isDebugEnabled()) {
                    logger.debug("Attribute internal name  " + attributeInternal);
                    logger.debug("Attribute output name " + attributeToRender);
                    logger.debug("Value " + displayValue);
                }

                element.removeAtt(attributeInternal);
                if (attributeToRender != null) {
                    attribute.setName(attributeToRender);
                }
                if (displayValue != null) {
                    attribute.setValue(displayValue);
                }

                element.addAtt(attribute);
            }
        }
        else {
            if (logger.isDebugEnabled()) {
                logger.debug("The element is null " + element == null);
                logger.debug("The attributeInternal is null " + attributeInternal == null);
            }
        }
    }

    /**
     * returns map of display values for provided typeID
     *
     * @param typeID
     * @param locale2
     * @throws WTException
     */
    private static Map<TypeIdentifier, String> getLocalizedDisplayValueforType(TypeIdentifier[] typeID, Locale locale2)
            throws WTException {
        Map<TypeIdentifier, String> dispNameMap = null;
        if (typeID != null && typeID.length > 0) {
            DefinitionDescriptor[] descriptors = DESCRIPTOR_FACTORY.get(
                    typeID, (String[]) null, locale2);
            if (descriptors != null && descriptors.length > 0) {
                int size = descriptors.length;
                dispNameMap = new HashMap<TypeIdentifier, String>();
                String displayName = null;
                for (int count = 0; count < size; count++) {
                    if (descriptors[count] != null) {
                        displayName = descriptors[count].getDisplay();
                        String className = ((WCTypeIdentifier) typeID[count]).getTableClassName();
                        if ((displayName == null) || displayName.equals(className)) {
                            displayName = WTIntrospector.getClassInfo(className).getDisplayName(
                                    locale2);
                        }
                        dispNameMap.put((TypeIdentifier) descriptors[count].getIdentifier(), displayName);
                    }
                }
            }
        }
        return dispNameMap;
    }

    private static String getDisplayValueForReferences(String referenceString) throws WTException {
        if (referenceString != null) {
            String refStr = ObjectReferenceTranslator.toWTReference(referenceString).toString();
            return ReportTaskUtil.getDisplayName(refStr);
        }
        else
            return "";
    }

    private static String getDisplayValueForDate(Date date, Locale locale, boolean isDate) {
        if (date != null) {
            if (isDate) {
                return WTStandardDateFormat.format(date, WTStandardDateFormat.LONG_STANDARD_DATE_FORMAT_MINUS_TIME,
                        locale);
            }
            else {
                return DateFormatUtilities.formatDate(date, locale);
            }
        }
        else
            return "";

    }

    private static String getDisplayValueForEnumerated(Class<?> enumeratedType, String key, Locale locale) {
        if (enumeratedType != null && key != null)
            return EnumeratedTypeUtil.toEnumeratedType(enumeratedType.getName(), key).getDisplay(locale);
        else
            return "";
    }

    /**
     * Method to return either cognos rich text or plain text from given input Rich Text string.
     * 
     * @param richTextString
     * @param convertToCognosRichText
     *            If true, convert input rich text to cognos recognized rich text format. If false, convert input rich
     *            text to plain text format.
     * 
     * @return resultingText
     */
    private static String getDisplayValueForRichText(String richTextString, boolean convertToCognosRichText) {
        logger.debug("richTextString: " + richTextString);
        logger.debug("convertToCognosRichText: " + convertToCognosRichText);
        String resultingText = richTextString;
        if (null != resultingText) {
            try {
                String filter = null;
                if (convertToCognosRichText) {
                    filter = HTMLTextFilter.COGNOS_RICH_TEXT_FILTER;
                }
                else {
                    filter = HTMLTextFilter.PLAIN_TEXT_FILTER;
                }

                resultingText = HTMLTextFilter.filterHTMLText(richTextString, filter, true, // wrapInHTMLTag
                        false // do not add white space
                );
            } catch (Exception e) {
                logger.error(e, e);
                return richTextString;
            }
        }
        logger.debug("resultingTextString: " + resultingText);
        return resultingText;
    }

    private void addAssociationType(Class<? extends BinaryLink> linkClass, HashMap<String, String> attributesMap) {
        String compType = "";
        String linkType = "";
        if (IteratedUsageLink.class.isAssignableFrom(linkClass)) {
            compType = USES;
    	} else if (WTPartDescribeLink.class.isAssignableFrom(linkClass)) {
            compType = DESCRIBES_BY;
            linkType = WTMessage.getLocalizedMessage("com.ptc.windchill.enterprise.massChange.massChangeClientResource",
                    massChangeClientResource.DOCUMENT_DESCRIBED_BY, null, locale);
        } else if (WTPartReferenceLink.class.isAssignableFrom(linkClass)) {
            compType = REFERENCE_TO;
            linkType = WTMessage.getLocalizedMessage("com.ptc.windchill.enterprise.massChange.massChangeClientResource",
                    massChangeClientResource.DOCUMENT_REFERENCED_BY, null, locale);
        } else if (EPMBuildHistory.class.isAssignableFrom(linkClass)) {

        	compType = ACTIVE;
        	linkType = WTMessage.getLocalizedMessage("com.ptc.windchill.uwgm.common.associate.associateResource", associateResource.ASSOCTYPE_ACTIVE,
                        null, locale);
        } else if (EPMDescribeLink.class.isAssignableFrom(linkClass)) {
        	compType = PASSIVE;
            linkType = WTMessage.getLocalizedMessage("com.ptc.windchill.uwgm.common.associate.associateResource", associateResource.PASSIVE_ASSOC,
                    null, locale);
        }
        if (logger.isDebugEnabled()) {
            logger.debug("The compType is: " + compType);
            logger.debug("The linkType is: " + linkType);
        }
        attributesMap.put(COMPTYPE, compType);
        attributesMap.put(LINKTYPE, linkType);
    }


    /**
     * Returns the version of the RoleB object of the given link object
     * targetRef. <br>
     * <br>
     * <b>Supported API: </b>false
     * 
     * @param changeable
     *            The Role B object
     * @return type.
     * @throws WTException
     * @throws WTException
     */
    private String getCompVersion(Persistable linkObject) throws WTException {
        String version = "";
        if (linkObject instanceof ObjectToObjectLink) {
            ObjectToObjectLink link = (ObjectToObjectLink) linkObject;
            Persistable obj = link.getRoleBObject();
            if (obj instanceof Versioned)
                version = getVersion(obj);
        }
        if(logger.isDebugEnabled()) {
            logger.debug("the version is: " + version);
        }
        return version;
    }

    
    /**
     * This method will create the URL to the detail info page
     *
     * @param object
     *            the objectIdentifier of the part
     *
     * @return String
     *
     * @exception WTException
     **/
    public static String getViewPageURL(Persistable object) throws WTException {

        NmOid oid = new NmOid(object);
        NmAction action = NmActionServiceHelper.service.getAction("object", NmAction.Command.VIEW);
        action.setContextObject(oid);
        try {
            return action.getActionUrlExternal();
        } catch (Exception e) {
            throw new WTException(e);
        }

    }

    public static WTReference getWTReference(Element element) throws WTException {
        WTReference wtRef = null;
        if (element != null) {
            Att obid = element.getAtt(OBID);
            if (obid != null) {
                wtRef = ObjectReferenceTranslator.toWTReference(obid.getValue().toString());
            }
        }
        return wtRef;
    }

    /**
     * This would basically prune the attributes for the ChangeTask Report. In some cases we would like to change the
     * attribute names for supporting internalization.
     *
     * @param group
     *            - I*E group
     * @param locale
     *            - Locale
     *
     *            <BR>
     *            <BR>
     *            <B>Supported API: </B>false
     *
     * @throws WTException
     */
    public static void processChangeTask_WorkItem_Attributes(Group group, Locale locale) throws WTException {

        if (group != null && group.getElementCount() > 0) {
            Enumeration<?> elements = group.getElements();
            while (elements.hasMoreElements()) {
                Element element = (Element) elements.nextElement();
                if (logger.isDebugEnabled()) {
                    logger.debug("iterating elements: " + element);
                }
                replaceAttributesWithDisplayValue(ATTRTYPE_DATE, element, NEEDDATEATTRIBUTE, null, null, locale);
                replaceAttributesWithDisplayValue(ATTRTYPE_DATE, element, CREATETS_INTERNALNAME, CREATETS_ATTRIBUTE,
                        null, locale);
                replaceAttributesWithDisplayValue(ATTRTYPE_DATE, element, DEADLINE_ATTRIBUTE, null, null, locale);
                replaceAttributesWithDisplayValue(ATTRTYPE_ENUMERATED, element, STATE_INTERNALNAME, STATE_ATTRIBUTE,
                        State.class, locale);
                replaceAttributesWithDisplayValue(ATTRTYPE_ENUMERATED, element, ROLE_ATTRIBUTE, null, Role.class,
                        locale);

                Att obid = element.getAtt("changeActivityObid");
                if (obid != null) {
                    WTReference wtRef = ObjectReferenceTranslator.toWTReference(obid.getValue().toString());
                    element.addAtt(new Att("ICONURL", getIconURL(wtRef.getObject())));
                    element.addAtt(new Att("VIEWPAGEURL", getViewPageURL(wtRef.getObject())));
                }
            }
        }
    }

    /**
     * Returns the object instance associated with the row element. It also caches the instance so we don't have to
     * build it next time <BR>
     * <BR>
     * <B>Supported API: </B>false
     *
     * @param element
     *            Row element
     * @return Persistable instance
     * @throws WTException
     */
    public static Persistable getElementOBID(Element element) throws WTException {
        Persistable p = null;
        if (element != null) {
            if (ElementObjMap != null && ElementObjMap.containsKey(element)) {
                p = ElementObjMap.get(element);
            }
            else {
                Att obid = element.getAtt(OBID);
                if (obid != null && obid.getValue() != null) {
                    WTReference ref = ObjectReferenceTranslator.toWTReference(obid.getValue().toString());
                    if (ref != null && ref.getObject() != null) {
                        p = ref.getObject();
                        ElementObjMap.put(element, p);
                    }
                }
            }
        }
        return p;
    }

    /**
     * Returns the team associated with the team managed instance. <BR>
     * <BR>
     * <B>Supported API: </B>false
     *
     * @param tmo
     *            TeamManaged object
     * @return the team
     * @throws WTException
     */
    protected static Team getTeam(TeamManaged tmo) throws WTException {
        Team theTeam = null;
        boolean accessEnforced = getStandardSessionManager().setAccessEnforced(false);
        try {
            if (tmo != null && tmo.getTeamId() != null) {
                TeamReference teamRef = tmo.getTeamId();
                if (teamRef != null) {
                    theTeam = (Team) teamRef.getObject();
                    theTeam = (Team) persistenceManager.refresh(theTeam);
                }
            }
        } finally {
            getStandardSessionManager().setAccessEnforced(accessEnforced);

        }
        return theTeam;
    }

    /**
     * Returns a string (space separated) of users in change admin 1 role. Uses processPrincipal to get member users if
     * the team has nested teams as members <BR>
     * <BR>
     * <B>Supported API: </B>false
     *
     * @param team
     *            Team team
     *
     * @return users in change Admin 1 role space separated
     * @throws WTException
     */
    private static String getAdmin1RoleUsers(Team team) throws WTException {
        String str = null;
    	StringBuffer retunBuff = null;
        boolean addSeperator = false;
        String empty = "";

        boolean hasAccess = team != null && AccessControlHelper.manager.hasAccess(team, AccessPermission.READ);
        if (hasAccess) {
            Role role = Role.toRole(ADMIN_I);
            Enumeration<?> e = team.getPrincipalTarget(role);
            retunBuff = new StringBuffer();
            while (e.hasMoreElements()) {
                WTPrincipalReference ref = (WTPrincipalReference) e.nextElement();
                WTPrincipal princ = (WTPrincipal) ref.getObject();
                str = processPrincipal(princ);
                if (str != null && !"".equalsIgnoreCase(str)) {

                    if (addSeperator) {
                        retunBuff.append(sep);
                    }
                    retunBuff.append(str);
                    addSeperator = true;
                }
            }
        }
        if (retunBuff == null) {
            return empty;
        }
        return retunBuff.toString();
    }

    /**
     * Add "Change admin 1" column(attribute) to change request log report <BR>
     * To add the column to other change log reports, modify the isAssignableFrom check below <BR>
     * <BR>
     * <B>Supported API: </B>false
     *
     * @param element
     *            Element containing the attributes
     */
    public static void addChangeAdmin1Column(Element element, Locale locale) {

        try {
            Team team = null;
            Persistable obj = getElementOBID(element);
            if (obj != null && ChangeRequest2.class.isAssignableFrom(obj.getClass())) {
                TeamManaged teamManagedObj = (TeamManaged) obj;
                team = getTeam(teamManagedObj);
                if (team != null) {
                    String s = getAdmin1RoleUsers(team);
                    Att attribute = new Att(CHANGE_ADMIN1, s);
                    element.addAtt(attribute);
                }
            }
        } catch (WTException e) {
            if (logger.isDebugEnabled()) {
                logger.debug(
                        "Unable to add change admin 1 column to change request log report because there was an exception "
                                + e.getLocalizedMessage(locale));
            }
        }
    }

    /**
     * Get session Manager <BR>
     * <BR>
     * <B>Supported API: </B>false
     *
     */
    private static SessionManagerSvr getStandardSessionManager() {
        return SessionServerHelper.manager;
    }

    private static String getPrincipalDisplayName(WTPrincipalReference ref) throws WTException {
        boolean hasAccessToPrincipal = ref != null && AccessControlHelper.manager.hasAccess(ref, AccessPermission.READ);
        String principalDisplay = null;
        if (hasAccessToPrincipal) {
            WTPrincipal princ = (WTPrincipal) ref.getObject();
            principalDisplay = processPrincipal(princ);
        }
        return principalDisplay;
    }

    /**
     * Given the WTPrincipal, this method inflates it getting all the members in it <BR>
     * <BR>
     * <B>Supported API: </B>false
     *
     * @param principal
     *            WTPrincipal principal
     *
     * @return Name of the user or users associated with the principal
     * @throws WTException
     */
    public static String processPrincipal(WTPrincipal principal) throws WTException {
        StringBuffer buf = new StringBuffer();
        String name = "";

        if (principal instanceof WTUser) {
            name = ((WTUser) principal).getFullName();
            buf.append(name);
        }
        else if (principal instanceof WTGroup) {
            name = ContainerTeamHelper.getDisplayName((WTGroup) principal, SessionHelper.getLocale());
            buf.append(name);
        }
        return buf.toString();
    }

    /**
     *
     * @return
     * @throws WTException
     */
    public static String getLogReportInputParams(boolean useChangeAdmin2) throws Exception {
        JSONObject json = new JSONObject();

        json.put(ChangeReportConstants.CONTAINERID, ChangeReportConstants.INPUTPARAM_CONTAINERID);
        json.put(ChangeReportConstants.CONTAINERTYPE, ChangeReportConstants.INPUTPARAM_CONTAINERTYPE);

        if (useChangeAdmin2) {
            json.put(ChangeReportConstants.PRINCIPALID, ChangeReportConstants.INPUTPARAM_CHGADMIN2);
        }
        else {
            json.put(ChangeReportConstants.PRINCIPALID, ChangeReportConstants.INPUTPARAM_CHGADMIN1);
        }

        json.put(ChangeReportConstants.NUMBER, ChangeReportConstants.INPUTPARAM_NUMBER);
        json.put(ChangeReportConstants.NAME, ChangeReportConstants.INPUTPARAM_NAME);
        json.put(ChangeReportConstants.STATE, ChangeReportConstants.INPUTPARAM_STATE);
        json.put(ChangeReportConstants.PRIORITY, ChangeReportConstants.INPUTPARAM_PRIORITY);

        json.put(ChangeReportConstants.CATEGORY, ChangeReportConstants.INPUTPARAM_CATEGORY);
        json.put(ChangeReportConstants.VARIANCECATEGORY, ChangeReportConstants.INPUTPARAM_VARIANCECATEGORY);
        json.put(ChangeReportConstants.COMPLEXITY, ChangeReportConstants.INPUTPARAM_COMPLEXITY);

        json.put(ChangeReportConstants.CREATEDTS_RANGEFROM, ChangeReportConstants.INPUTPARAM_CREATEDTS_RANGEFROM);
        json.put(ChangeReportConstants.CREATEDTS_RANGETO, ChangeReportConstants.INPUTPARAM_CREATEDTS_RANGETO);

        json.put(ChangeReportConstants.LASTUPDATEDTS_RANGEFROM,
                ChangeReportConstants.INPUTPARAM_LASTUPDATEDTS_RANGEFROM);
        json.put(ChangeReportConstants.LASTUPDATEDTS_RANGETO, ChangeReportConstants.INPUTPARAM_LASTUPDATEDTS_RANGETO);

        String jsonString = json.toString();
        jsonString = HTMLEncoder.encodeForHTMLAttribute(jsonString);

        if (logger.isDebugEnabled()) {
            logger.debug("The json string is " + jsonString);
        }

        return jsonString;
    }

    /**
     * Helper api to get the value of the property: <br>
     * <br>
     * wt.change2.reports.pageSize <br>
     * <br>
     * if no value is found for the property, REPORTS_PAGE_SIZE_DEFAULT is returned as the default.
     * 
     * @return int - the page size
     */
    public static int getReportsPageSize() {
        int size = REPORTS_PAGE_SIZE_DEFAULT;
        try {
            size = WTProperties.getLocalProperties().getProperty(REPORTS_PAGE_SIZE_PROPERTY, REPORTS_PAGE_SIZE_DEFAULT);
        } catch (IOException e) {
            logger.error("Error getting property value for reports page size", e);
        }

        if (logger.isDebugEnabled()) {
            logger.debug("reports page size: " + size);
        }

        return size;
    }

    /**
     * Determine if third party reporting server should be used.
     *
     * @throws WTException
     */
    private static boolean useThirdPartyReporting() throws WTException {
        // Use MethodLocal to remember the result within a method context.
        Boolean useThirdPartyReporting = USE_THIRD_PARTY_REPORTING.get();
        if (useThirdPartyReporting != null)
            return useThirdPartyReporting;

        useThirdPartyReporting = false;
        try {
            if (ReportHelper.isThirdPartyReportingEnabled()) {
                // Ping third party reporting server to see if it responds.
                long pingTime = ReportHelper.manager.pingThirdPartyReportingSystem();
                if (pingTime >= 0) {
                    useThirdPartyReporting = true;

                    // It's possible that the third party reporting server is enabled and answers the ping
                    // but is still not responding for creating reports. Examine the stack trace to see
                    // if the standard reporting task is being used instead of the third party reporting server.
                    // Please replace this code if a better way to detect this situation is found.
                    StackTraceElement[] callStack = Thread.currentThread().getStackTrace();
                    String standardReportClassName = ReportTask.class.getName();

                    // Look for standard reporting class in stack trace.
                    for (StackTraceElement stackElement : callStack) {
                        if (stackElement.getClassName().equals(standardReportClassName)) {
                            useThirdPartyReporting = false;
                            break;
                        }
                    }
                }
            }
        } catch (WTException e) {
            logger.debug("Could not determine if third party reporting is responding.", e);
        }

        if (useThirdPartyReporting)
            logger.debug("Third party reporting is enabled and responding.");
        else
            logger.debug("Third party reporting is either not enabled or not responding.");

        setUserThirdPartyReporting(useThirdPartyReporting);
        return useThirdPartyReporting;
    }

    /**
     * Used for testing only
     * 
     * @param useThirdPartyReporting
     */
    static void setUserThirdPartyReporting(Boolean useThirdPartyReporting) {
        USE_THIRD_PARTY_REPORTING.set(useThirdPartyReporting);
    }
}
