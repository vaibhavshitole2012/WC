/* bcwti
 *
 * Copyright (c) 2018 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */

package com.ptc.core.components.beans;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.beanutils.ConversionException;
import org.apache.log4j.Logger;

import com.ptc.core.HTMLtemplateutil.server.processors.AttributeKey;
import com.ptc.core.components.descriptor.DescriptorConstants;
import com.ptc.core.components.forms.AttributePopulator;
import com.ptc.core.components.forms.CreateEditFormProcessorHelper;
import com.ptc.core.components.forms.DefaultAttributePopulator;
import com.ptc.core.components.forms.FolderContextHelper;
import com.ptc.core.components.rendering.AbstractRenderer;
import com.ptc.core.components.rendering.guicomponents.ComboBox;
import com.ptc.core.components.rendering.guicomponents.GuiComponentUtil;
import com.ptc.core.components.util.RenderUtil;
import com.ptc.core.components.util.converters.ComponentConvertUtils;
import com.ptc.core.foundation.type.common.TypeIdentifierSelectionHelper;
import com.ptc.core.meta.common.AttributeIdentifier;
import com.ptc.core.meta.common.AttributeTypeIdentifier;
import com.ptc.core.meta.common.Identifier;
import com.ptc.core.meta.common.IdentifierFactory;
import com.ptc.core.meta.common.RemoteWorkerHandler;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.TypeIdentifierHelper;
import com.ptc.core.meta.common.TypeInstanceIdentifier;
import com.ptc.core.meta.common.impl.GetTypeIdentifierRemoteWorker;
import com.ptc.core.meta.common.impl.GetTypeInstanceIdentifierRemoteWorker;
import com.ptc.core.meta.common.impl.WCTypeIdentifier;
import com.ptc.core.meta.type.common.TypeInstance;
import com.ptc.core.meta.type.common.TypeInstanceHelper;
import com.ptc.core.ui.componentRB;
import com.ptc.core.ui.resources.ComponentMode;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import com.ptc.netmarkets.util.misc.NmActionServiceHelper;
import com.ptc.netmarkets.util.misc.NmContext;
import com.ptc.netmarkets.util.misc.NmContextItem;

import wt.admin.DomainAdministered;
import wt.fc.ObjectIdentifier;
import wt.fc.ObjectReference;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.fc.WTReference;
import wt.fc.collections.WTArrayList;
import wt.fc.collections.WTSet;
import wt.folder.CabinetBased;
import wt.folder.Folder;
import wt.folder.FolderHelper;
import wt.inf.container.ExchangeContainer;
import wt.inf.container.OrgContainer;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerRef;
import wt.inf.library.WTLibrary;
import wt.log4j.LogR;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.pdmlink.PDMLinkProduct;
import wt.projmgmt.admin.Project2;
import wt.services.applicationcontext.implementation.DefaultServiceProvider;
import wt.session.SessionHelper;
import wt.session.SessionServerHelper;
import wt.type.TypedUtility;
import wt.util.HTMLEncoder;						   
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.WTRuntimeException;
import wt.vc.Mastered;
import wt.vc.VersionControlHelper;

import ext.kb.util.DBUtils;

/**
 * This class is used to set and retrieve information needed by an instance of an object creation or edit wizard. This
 * information includes: <BR>
 * <BR>
 * <UL>
 * <LI>wizard input parameters, such as type of operation and AttributePopulator class</LI>
 * <LI>parameters derived from the launch context of the wizard, such as default container and object base type</LI>
 * <LI>internal variables used for displaying and processing the wizard, such as selected object type and selected
 * container</LI>
 * </UL>
 * <BR>
 * If the wizard operates on multiple objects, the data specific to a given object will be identified by attaching an
 * "object handle" string to the parameter key. Data common to all objects and data in a wizard that operates on a
 * single object will have no associated object handle (the object handle will be an empty string). <BR>
 * <BR>
 * This information is used by:<BR>
 * <BR>
 * <UL>
 * <LI>Step jsps, which retrieve the data using the non-static getters on the instance of the bean associated with the
 * jsp page. These getters will retrieve the data for the current object by retrieving the current object handle stored
 * in the HTTPServletRequest attributes (preloaded steps) or HTTPServletRequest parameters (nonpreloaded steps). (Note
 * that steps marked 'preloadWizardPage="false"' in actions.xml will behave as if they were preloaded if they are the
 * first step in the wizard.)</LI>
 * <LI>The classes that acquire the data model used to display panels and tables in the wizard. These classes should
 * retrieve the current object's handle from the NmCommandBean's HTTPRequestData parameter map via a call to the static
 * getCurrentObjectHandle(FormDataHolder) method. They should then request data by calling the static getter that takes
 * this objectHandle and a NmCommandBean.</LI>
 * <LI>The renderers for input fields, which will retrieve the current object handle from the bean and attach it to the
 * name attribute of each input field.</LI>
 * <LI>The form processing classes which process the wizard data when the wizard is submitted. The
 * FormProcessorController processing classes will partition the form data by object handle and hand it off to
 * ObjectFormProcessors in ObjectBeans. The parameter keys in ObjectBeans will not have object handles so the
 * ObjectFormProcessors should retrieve the data by calling the static getter with a null object handle and an
 * ObjectBean.</LI> <BR>
 * <BR>
 * <BR>
 * <BR>
 * <B>Supported API: </B>true <BR>
 * <BR>
 * <B>Extendable: </B>false
 *
 */

public class CreateAndEditWizBean implements Serializable, RemoteAccess {

    /**
     *
     */
    private static final String CLASS_NAME = CreateAndEditWizBean.class.getName();

    private static final long serialVersionUID = 1L;

    private static final Logger log;

    private HttpServletRequest request = null;

    private NmCommandBean commandBean = null;

    private PropagationBean propagationBean = null;

    private String operation = null;

    private String typePickerType = "BOTH";

    private WTReference typePickerAdminDomainRef = null;

    private boolean typePickerShowRoot = true;

    private boolean includeTypePicker = false;

    /*
     * This property intended to be used in contextPicker for filtering not needed types. Description from contextPicker
     * tag: This parameter is used to exclude sub types from the search. The subtypes should be given as shown in the
     * example. For ex: Specifying subtypes General and Minutes of WTDocument to be excluded from the search should be
     * given as: excludeSubTypes='wt.doc.WTDocument|org.r_and_d.General,wt.doc.WTDocument|org.r_and_d.Minutes'. NOTE:
     * For a modeled type, only the fully qualified class name should be specified. Its parent should not be specified.
     */
    private String contextPickerExcludeTypes;

    /*
     * This property is intended to specify a different value for 'typeComponentId' to be used by the setContext wizard
     * step than the default of "Foundation.containerSearch". Some wizards may require this to retrict the types of
     * containers that are to be searched.
     *
     * setContext wizard step simply passes on this value to to the contextPicker tag. Here is the description of
     * 'typeComponentId' from contextPicker tag documentation: This parameter is passed to define set of types that can
     * be shown in Type Picker. The set of types for given typeComponentId are defined in the
     * <WT_HOME>/com/ptc/windchill/enterprise/search/server/SearchableTypes.properties file.
     */
    private String contextPickerTypeComponentId = "";

    private ArrayList<String> typePickerFilterTypes = null;

    private ArrayList<String> typePickerSeedTypes = null;
	
    private boolean isNamingEntry = false;

    /**
     * Value that should be passed to the InitializeItemTag for an object creation wizard <BR>
     * <BR>
     * <B>Supported API: </B>true
     */
    public static final String CREATE = ComponentMode.CREATE.name();

    /**
     * Use this value when creating a Type Instance and you don't want the OIR constraints to be applied to the Type
     * Instance at that time.
     *
     * <p>
     * This is generally used when we create a Type Instance for the attributes in the FORM, then we'll apply the FORM
     * values to the Type Instance. After the FORM values have been applied to the Type Instance, then we'll apply the
     * OIR constraints in case there is a attribute with a ServerPreGen value constraint and there is no value for the
     * attribute in the FORM.
     * </p>
     *
     * @see CreateEditFormProcessorHelper#getTypeInstanceWithFormVals(TypeInstanceIdentifier, java.util.HashMap,
     *      TypeInstanceIdentifier, String, java.util.Locale, com.ptc.core.components.forms.FormResult,
     *      TypeInstanceIdentifier[], boolean) CreateEditFormProcessorHelper.getTypeInstanceWithFormVals() <BR>
     *      <BR>
     *      <B>Supported API: </B>true
     */
    public static final String CREATE_SKIP_OIRS = ComponentMode.CREATE_SKIP_OIRS.name();

    /**
     * Value that should be passed to the InitializeItemTag for an object edit wizard <BR>
     * <BR>
     * <B>Supported API: </B>true
     */
    public static final String EDIT = ComponentMode.EDIT.name();

    public static final String VIEW = ComponentMode.VIEW.name();

    public static final String OPERATION_PARAMETER_NAME = "operation";

    public static final String BASE_TYPE_IDENTIFIER = "baseTypeIdentifier";

    public static final String CONTAINER_PARAMETER_NAME = "containerRef";

    public static final String DEF_CONTAINER_PARAMETER_NAME = "defaultContainerRef";

    public static final String IS_DEF_CONTAINER_OVERRIDABLE = "isDefContainerOverridable";

    public static final String ITEM_TIID_PARAMETER_NAME = "itemTypeInstanceId";

    public static final String ATTRIBUTE_POPULATOR_PARAMETER_NAME = "attributePopulatorClass";

    public static final String TYPE_PICKER_INIT_VALUE = "typePickerInitValue";

    public static final String WORKING_COPY_REF_PARAMETER_NAME = "checkinOid";

    public static final String EDIT_OBJ_REF_PARAMETER_NAME = "editObjectRef";

    /**
     * A parameter that is stored in the request and can be used to ensure the attribute populator is used to return the
     * container ref, rather than the request (in case the container ref is determined by an OIR). This parameter could
     * be set when the type picker is changed if the wizard is for a type that is trying to control the container ref
     * via an OIR.
     *
     * This is a special edge case only known to happen in 1 wizard for 1 customer. See case 12367843. This has not been
     * thoroughly tested for all object types and all scenarios, but works sufficiently enough for now for their use
     * case.
     */
    public static final String TYPE_PICKER_CHANGED_PARAMETER_NAME = "typePickerChanged";

    public static final String CHECK_IN_CONTEXT = "checkinContext";

    // parameter name to keep track of object handles; used for multi-object
    // creates
    public static final String OBJECT_HANDLE = "objectHandle";

    // parameter for the current object handle; for multi-object creates
    public static final String CURRENT_OBJECT_HANDLE = "currentObjectHandle";

    // prefix of all object handles
    public static final String OBJECT_HANDLE_PREFIX = "!~objectHandle~";

    // suffix of all object handles
    public static final String OBJECT_HANDLE_SUFFIX = "~!";

    public static final String USE_HIERARCHICAL_TYPE_LIST_IN_PICKER = "useHierachicalTypeListInPicker";

    public static final String FORM_PROCESSOR = "FormProcessor";

    public static final String FORM_PROCESSOR_DELEGATE = "FormProcessorDelegate";

    private static final ReferenceFactory REFERENCE_FACTORY;

    private static final IdentifierFactory IDENTIFIER_FACTORY;

    static final boolean SERVER = RemoteMethodServer.ServerFlag;

    static {
        try {
            log = LogR.getLogger(CLASS_NAME);
            REFERENCE_FACTORY = new ReferenceFactory();
            IDENTIFIER_FACTORY = (IdentifierFactory) DefaultServiceProvider.getService(IdentifierFactory.class,
                    "logical");
        } catch (Exception e) {
            throw new ExceptionInInitializerError(e);
        }
    }

    //
    // Utility Methods
    //

    /**
     * Creates an HTML name attribute for a TEXTBOX input field containing the value of an object attribute. The name
     * attribute returned will be one that is recognized by the common create form processor, which can then set it's
     * value on the object.
     */
    // This is called by the New Meeting client to create an input field for theMeetingType attribute since
    // that attribute is presented as a type picker.
    public static String createHTMLNameAttr(String attrLogicalName, String tiidExternalForm) {
        String htmlNameStr = "";
        try {
            TypeInstanceIdentifier tiid = (TypeInstanceIdentifier) IDENTIFIER_FACTORY.get(tiidExternalForm);
            AttributeTypeIdentifier atid = (AttributeTypeIdentifier) IDENTIFIER_FACTORY.get(attrLogicalName, tiid
                    .getDefinitionIdentifier());
            AttributeIdentifier ai = atid.newAttributeIdentifier(tiid);
            AttributeKey htmlNameKey = new AttributeKey(ai, (String) null, (String) null);
            htmlNameStr = CreateEditFormProcessorHelper.createFakeHTMLNameAttr(htmlNameKey);
        } catch (WTException wte) {
            log.error("createHTMLNameAttr: unable to create an html name attribute for object attribute "
                    + attrLogicalName + " with TypeInstanceIdentifier " + tiidExternalForm);
        }
        return htmlNameStr;
    }

    /**
     * To be used by multi object create wizards with tables that need a new handle for each row <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public static String getNewObjectHandle() {
        return getNewObjectHandle(String.valueOf(System.nanoTime()));
    }

    /**
     * Used by InitializeItemTag, WizardStepTag to construct a handle with common prefix <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public static String getNewObjectHandle(String handle) {
		 // verify objectHandle
        RenderUtil.verifyID(handle);
					  
	     if (handle.startsWith(OBJECT_HANDLE_PREFIX) && handle.endsWith(OBJECT_HANDLE_SUFFIX)) {
            // given string already has object handle prefix/suffix so just returning it
            return handle;
        }
        return OBJECT_HANDLE_PREFIX + handle + OBJECT_HANDLE_SUFFIX;
    }

    /**
     * Gets the object handle off the given request. If no object handle attribute or parameter is there, returns empty
     * string <BR>
     * <BR>
     * <B>Supported API: </B>false
     *
     * @return object handle
     */
    public static String getCurrentObjectHandle(ServletRequest request) {
        String objectHandle = "";
        if (request != null) {
            objectHandle = (String) request.getAttribute(CURRENT_OBJECT_HANDLE);
            if (objectHandle == null) {
                objectHandle = request.getParameter(CURRENT_OBJECT_HANDLE);
            }
            if (objectHandle == null || objectHandle.equals("null")) {
                objectHandle = "";
            }
		// verify objectHandle
        RenderUtil.verifyID(objectHandle);						  
											  
        }
        return objectHandle;
    }

    /**
     * Gets the object handle off this object's request. If no object handle attribute or parameter is there, returns
     * empty string <BR>
     * <BR>
     * <B>Supported API: </B>false
     *
     * @return object handle
     */
    public String getCurrentObjectHandle() {
        return getCurrentObjectHandle(this.request);
    }

    /**
     * Gets the encoded object handle. To be used in rendering html attribute only !<BR>
     * <BR>
     * <B>Supported API: </B>false
     *
     * @return object handle
     */
    public String getEncodedCurrentObjectHandle() {
        return HTMLEncoder.encodeForHTMLAttribute(getCurrentObjectHandle(this.request));
    }

    /**
     * Gets the object handle off the given FormDataHolder. If no object handle attribute or parameter is there, returns
     * empty string <BR>
     * <BR>
     * <B>Supported API: </B>false
     *
     * @return object handle
     */
    public static String getCurrentObjectHandle(FormDataHolder dataGetter) {

        String objectHandle = "";
        if (!(dataGetter instanceof ObjectBean)) {
            objectHandle = (String) getParameter(CURRENT_OBJECT_HANDLE, (String) null, dataGetter);
            if (objectHandle == null || "null".equals(objectHandle)) {
                objectHandle = "";
            }
		    // verify objectHandle
            RenderUtil.verifyID(objectHandle);						  
											  
        }
        return objectHandle;
    }

    /**
     * Used in the case of multi object create/edit to get the corresponding object handle for the row.<BR>
     * <BR>
     *
     * <B>Supported API: </B>false
     *
     * @return objectHandle
     * @throws WTException
     */
    public static String getCurrentObjectHandle2(FormDataHolder dataGetter, Object datum) throws WTException {
        if (datum instanceof TypeInstance) {
            TypeInstance ti = (TypeInstance) datum;
            AttributeIdentifier ai = TypeInstanceHelper.acquireSingleAttributeIdentifier(ti,
                    CreateEditFormProcessorHelper.ROWOBJNMOID_ATI);
            Object object = ti.get(ai);
            if (object != null) {
                NmOid nmoid = NmOid.newNmOid((String) object);
                if (nmoid != null) {
                    String objectHandle = CreateAndEditWizBean.getNewObjectHandle(nmoid.toNmOidStr());
                    if (log.isDebugEnabled()) {
                        log.debug("Current Object Handle: " + objectHandle);
                    }
                    return objectHandle;
                }
            }
        }
        return CreateAndEditWizBean.getCurrentObjectHandle(dataGetter);
    }

    /**
     * Sets the value of the parameter CURRENT_OBJECT_HANDLE in the parameter map of the command bean's HTTPRequestData.
     * Existing parameter value(s) for that key will be overwritten. <BR>
     * <BR>
     * <B>Supported API: </B>false
     * 
     * @param cb
     *            - command bean
     * @param objHandle
     *            - the new current object handle
     */
    public static void setCurrentObjectHandle(NmCommandBean cb, String objHandle) {
        setRequestDataParam(cb, CURRENT_OBJECT_HANDLE, getNewObjectHandle(objHandle), false);
    }

    /**
     * Adds a key-value pair to the HTTPRequestData parameter map in the given NmCommandBean. If the value is of type
     * String it will be appended to an array of values if a value already exists under the key.<br />
     * <br />
     *
     * <b>Note:</b>If the value being passed in is anything other then a type String it will add the object to the map
     * but if other values already exist with that key it will be overwritten. <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public static void setRequestDataParam(NmCommandBean cb, String key, Object value) {
        if (value instanceof String) {
            cb.addRequestDataParam(key, (String) value, true);
        }
        else {
            cb.getRequestData().getParameterMap().put(key, value);
        }
    }

    /**
     * Adds a key-value pair to the HTTPRequestData parameter map in the given NmCommandBean. If the value is of type
     * String and value(s) already exist in the map for that key, the new value will be appended to the value array if
     * appendVal is true or replace the existing value(s) if appendVal is false.<br />
     * <br />
     *
     * If the value passed in is anything other than type String it will will always overwrite any existing values. <BR>
     * <BR>
     * <B>Supported API: </B>false
     */

    public static void setRequestDataParam(NmCommandBean cb, String key, Object value, boolean appendVal) {
        if (value instanceof String) {
            cb.addRequestDataParam(key, (String) value, appendVal);
        }
        else {
            cb.getRequestData().getParameterMap().put(key, value);
        }
    }

    // formerly getParamFromCommandBean
    /**
     * Gets a parameter for the given object handle from the passed dataGetter.
     *
     * If the dataGetter is a NmCommandBean first looks for the parameter in the HTTPRequestData parameter map. If none
     * is found, then looks for the parameter in the servlet request parameter map.
     *
     * If the dataGetter is not a NmCommandBean, the parameter from its parameterMap will be returned.
     *
     * If the value is a String, it will be returned in UTF-8 format. <BR>
     * <BR>
     * <B>Supported API: </B>false
     *
     * @param PARAM_NAME
     *            - Name key for desired data value. Required. Input.
     * @param objectHandle
     *            - Optional. Input.
     * @param dataGetter
     *            - Object that provides access to form data parameter map. Required. Input.
     */
    protected static Object getParameter(final String PARAM_NAME, String objectHandle, FormDataHolder dataGetter) {
        if (log.isTraceEnabled()) {
            log.trace("=> getParamter():  trying to get [" + PARAM_NAME + "] on objecthandle [" + objectHandle + "]");
        }

        Object value = null;
        if (objectHandle == null || "null".equals(objectHandle)) {
            objectHandle = "";
        }

        if (dataGetter != null && dataGetter.getParameterMap() != null) {
            value = dataGetter.getParameterMap().get(objectHandle + PARAM_NAME);
            if (log.isTraceEnabled()) {
                log.trace(" value from dataGetter.getParameterMap() is [" + value + "]");
            }
        }

        if ((value == null || (value instanceof String && value.equals("null")))
                && dataGetter instanceof NmCommandBean) {
            log.trace("dataGetter is an instanceof an NmCommandBean");

            // If in the servlet engine, this will get parameter from servlet
            // request
            if (((NmCommandBean) dataGetter).getRequest() != null) {
                value = ((NmCommandBean) dataGetter).getRequest().getParameter(objectHandle + PARAM_NAME);
                if (log.isTraceEnabled()) {
                    log.trace(" value from the NmCommandBean.request is [" + value + "]");
                }
            }
        }

        if (value != null) {
            log.trace("converting value and selecting the first value if value is an array.");
            if (value instanceof String[]) {
                value = ((String[]) value)[0];
            }
            if (value instanceof String) {
                value = NmCommandBean.convert((String) value);
            }
        }

        if (log.isTraceEnabled()) {
            log.trace("<= getParameter():  final value [" + value + "]");
        }
        return value;
    }

    /**
     * Searches for a parameter in the request parameters of this bean using the current object handle, if any, in the
     * request parameters. If not found, tries to get the parameter from the NmCommandBean of this bean instance. <br/>
     * <br/>
     * If no parameter with the current object handle is found, repeats the search for a parameter without an object
     * handle that would apply to all objects. <BR>
     * <B>Supported API: </B>false
     */
    private Object getParameterForCurrentObject(final String PARAM_NAME) {
        if (log.isTraceEnabled()) {
            log.trace("=> getParameterForCurrentObject for param [" + PARAM_NAME + "]");
        }
        String currentObjectHandle = getCurrentObjectHandle();

        Object value = getParameterForObject(PARAM_NAME, currentObjectHandle);

        // If no parameter found with current object handle, look for parameter without object handle.
        // Parameters without object handles are general parameters that apply to all objects.
        if (null == value && !"".equals(currentObjectHandle)) {
            value = getParameterForObject(PARAM_NAME, "");
        }

        return value;
    }

    private Object getParameterForObject(final String PARAM_NAME, String objectHandle) {
        if (log.isTraceEnabled()) {
            log.trace(
                    "=> getParameterForObject for param [" + PARAM_NAME + "] and object handle [" + objectHandle + "]");
        }
        Object value = this.request.getParameter(objectHandle + PARAM_NAME);
        if (log.isTraceEnabled()) {
            log.trace("value from this.request is [" + value + "]");
        }

        if (value == null || (value instanceof String && ((String) value).equals("null"))) {
            log.trace("calling getParameter()");
            value = getParameter(PARAM_NAME, objectHandle, this.getCommandBean());
        }

        if (log.isTraceEnabled()) {
            log.trace("<= getParameterForObject   final value: [" + value + "]");
        }
        return value;
    }

    /**
     * Gets a parameter from the parameter map of passed dataHolder using the current object handle, if one exists. The
     * current object handle is retrieved from the HTTPRequestData parameter map of the dataGetter or, if not found and
     * the dataHolder is a NmCommandBean, from the servlet request parameters in the NmCommandBean. <br/>
     * <br/>
     * If no parameter with the current object handle is found, repeats the search for a parameter without an object
     * handle that would apply to all objects.
     * 
     * <BR>
     * <B>Supported API: </B>false
     */

    public static Object getParameterForCurrentObject(final String PARAM_NAME, FormDataHolder dataHolder) {
        if (log.isTraceEnabled()) {
            log.trace("=> getParameterForCurrentObject for param [" + PARAM_NAME + "] and dataHolder ["
                    + dataHolder.getClass().getName() + "]");
        }

        String currentObjectHandle = getCurrentObjectHandle(dataHolder);
        Object value = getParameter(PARAM_NAME, currentObjectHandle, dataHolder);
        if (null == value && !"".equals(currentObjectHandle)) {
            value = getParameter(PARAM_NAME, "", dataHolder);
        }
        return value;
    }

    /**
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public static Class getTypeFromContext(NmCommandBean cb) throws WTException {
        NmContext nmcontext = NmContext.fromString(cb.getCompContext());
        String baseType = ((NmContextItem) nmcontext.getContextItems().firstElement()).getType();
        return NmActionServiceHelper.getClassForType(baseType);
    }

    /**
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public static TypeInstanceIdentifier getTypeInstanceIdForNewItem(String typeNameString) {
        final IdentifierFactory idFactory = (IdentifierFactory) DefaultServiceProvider.getService(
                IdentifierFactory.class, "logical");
        TypeIdentifier typeId = idFactory.newWCTypeIdentifier(typeNameString);
        return typeId.newTypeInstanceIdentifier();
    }

    /**
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public static String getTypeInstanceIdStringForNewItem(String typeNameString) {
        String tiidString = getTypeInstanceIdForNewItem(typeNameString).toExternalForm().trim();
        if (log.isDebugEnabled()) {
            log.debug("getTypeInstanceIdStringForNewItem(): returning TypeInstanceIdentifier = " + tiidString
                    + " for type name " + typeNameString);
        }
        return tiidString;
    }

    /**
     * @param typePicker
     *            - the combo box used by TypePickerTag in create wizards.
     * @return the item type instance id for the default selected type. Used by defineItem.jspf to update necessary
     *         itemTypeInstaceId field from base type to default selected type. If the default selection is not a type
     *         (e.g. empty string or "-- Select a Type --") then null is returned.
     */
    public static TypeInstanceIdentifier getDefaultTypeInstanceIdFromTypePicker(ComboBox typePicker) {
        if (log.isDebugEnabled()) {
            log.debug("setTypeInstanceHiddenInputOnTypePicker " + typePicker);
        }
        if (typePicker == null) {
            log.debug("type picker is null, returning null");
            return null;
        }

        String defaultType = "";
        if (defaultType == null || "".equals(defaultType)) {
            List<String> selected = typePicker.getSelected();
            if (selected != null && selected.size() > 0) {
                if (selected.size() > 1) {
                    log.warn("Unexpected for there to be more than one selection in the type picker.");
                }
                defaultType = selected.get(0);
            }
        }
        String internalValue = typePicker.findInternalVal(defaultType);
        log.debug("Internal value of default type selected in type picker is: " + internalValue);

        // internal value will be an empty string in the case that a type has not been selected
        if (!"".equals(internalValue)) {
            return getTypeInstanceIdForNewItem(internalValue);
        }
        log.debug("No default type selected, returning null");
        return null;
    };

    /**
     * Returns a new TypeInstanceIdentifier string for an object represented by an oid string.
     *
     * @return TypeInstanceIdentifier String <BR>
     *         <BR>
     *         <B>Supported API: </B>false
     */
    public static String getNewTypeInstanceIdFromOidStr(String oidStr) throws WTException {
        try {
            NmOid oid = NmOid.newNmOid(oidStr);
            TypeIdentifier typeId = (TypeIdentifier) RemoteWorkerHandler.handleRemoteWorker(
                    new GetTypeIdentifierRemoteWorker(), oid.getWtRef().getObject());
            return (typeId.newTypeInstanceIdentifier().toExternalForm().trim());
        } catch (Exception e) {
            throw new WTException(e, "Could not convert the oid string to a type instance identifier.");
        }
    }

    /**
     * Will throw exception if the user doens't have READ access to the referenced object <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public static TypeInstanceIdentifier getTypeInstanceIdFromRef(WTReference ref) throws WTException {

        return getTypeInstanceIdentifier(ref);
    }

    // The next can be deleted when CreateEditFormProcessorHelper method that
    // calls it is deleted
    /**
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public static String getTypeNameFromTypePicker(NmCommandBean commandBean) throws WTException {
        String typeName = null;
        String key = AbstractRenderer.HTMLName.getLookupKeyForNmCommandBeanMaps(GuiComponentUtil.COMBO_BOX,
                DescriptorConstants.FormParameterKeys.CREATE_TYPE, (String) null, (String) null);
        Map map = commandBean.getComboBox();
        if (log.isTraceEnabled()) {
            log.trace("getTypeNameFromTypePicker(): key = " + key);
        }
        if (log.isTraceEnabled()) {
            log.trace("getTypeNameFromTypePicker(): comboBox map = " + map);
        }
        ArrayList vals = (ArrayList) map.get(key);
        if (vals != null && vals.size() > 0) {
            typeName = (String) vals.get(0);
        }
        if (log.isDebugEnabled()) {
            log.debug("getTypeIdFromTypePicker() returning value = " + typeName);
        }
        return typeName;
    }

    /**
     * Convert a request param to the specified target class.<BR>
     * <BR>
     * <B>Supported API: </B>false
     * 
     * @param paramValue
     *            request param
     * @param targetClass
     *            the class to convert the param to
     * @return converted parameter
     */
    protected static Object convertParamValueToDataType(Object paramValue, Class<?> targetClass) {
        Object val = paramValue;
        if (paramValue != null && targetClass != null) {
            if (targetClass.isInstance(paramValue)) {
                val = paramValue;
            }
            else if (paramValue instanceof String) {
                if (((String) paramValue).equalsIgnoreCase("null") && !String.class.isAssignableFrom(targetClass)) {
                    return null;
                }
                Class<?> classToConvertTo = targetClass;
                if (Identifier.class.isAssignableFrom(targetClass)) {
                    // for WCTypeIdentifier and TypeInstanceIdentifier
                    // CompoenntConvertUtils doesn't convert them correctly
                    // unless Identifier is used as the class
                    classToConvertTo = Identifier.class;
                }
                else if (WTReference.class.isAssignableFrom(targetClass)) {
                    // for WTReference and WTContainerRef classes
                    // CompoenntConvertUtils doesn't convert them correctly
                    // unless WTReference is used as the class
                    classToConvertTo = WTReference.class;
                }
                val = ComponentConvertUtils.convert((String) paramValue, classToConvertTo);
                if (!targetClass.isInstance(val)) {
                    // Need to special case container references, as their toString value does not have an OR:.
                    // The ReferenceFactory used by ConvertUtils returns an ObjectReference when this OR: is missing and
                    // further processing is needed to convert it to a container ref.
                    if (WTContainerRef.class.isAssignableFrom(targetClass) && val instanceof ObjectReference) {
                        ObjectReference objRef = (ObjectReference) val;
                        try {
                            val = WTContainerRef.newWTContainerRef((ObjectIdentifier) objRef.getKey());
                        } catch (WTException e) {
                            log.warn("WTException while trying to convert object reference \"" + objRef
                                    + "\" to a container reference.", e);
                        }
                    }
                    else {
                        // Component Convert Utils failed to convert the paramValue
                        // into an instance of targetClass so try instantiating it
                        // from scratch
                        try {
                            Class<?> clazz = Class.forName((String) paramValue);
                            val = clazz.newInstance();
                        } catch (IllegalAccessException iae) {
                            log.warn("IllegalAccessException thrown trying to create an instance of " + targetClass,
                                    iae);
                        } catch (InstantiationException ie) {
                            log
                                    .warn("InstantiationException thrown trying to create an instance of "
                                            + targetClass, ie);
                        } catch (ClassNotFoundException cnfe) {
                            log.warn("ClassNotFoundException thrown trying to create an instance of " + targetClass,
                                    cnfe);
                        }
                    }
                }
            }
        }
        return val;

    }

    //
    // Getters and setters
    //

    /**
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public String getCreate() {
        return CREATE;
    }

    /**
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public String getEdit() {
        return EDIT;
    }

    /**
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public String getView() {
        return VIEW;
    }

    /**
     * Gets the wizard operation from the NmCommandBean of this bean instance. The current object handle, if one exists,
     * will be prepended to parameter name. <BR>
     * <BR>
     * <B>Supported API: </B>false
     */

    public String getOperation() throws WTException {
        return (String) getParameterForCurrentObject(OPERATION_PARAMETER_NAME);
    }

    /**
     * Gets the wizard operation from the passed dataGetter using the current objectHandle. <BR>
     * <BR>
     * <B>Supported API: </B>false
     */

    public static String getOperation(FormDataHolder dataGetter) {
        String objectHandle = getCurrentObjectHandle(dataGetter);
        String result = (String) getParameter(OPERATION_PARAMETER_NAME, objectHandle, dataGetter);
        if (result == null) {
            // Might not be available on current object so try again with no object handle - Create Multi Part/Doc use
            // case
            result = (String) getParameter(OPERATION_PARAMETER_NAME, null, dataGetter);
        }
        if (log.isDebugEnabled()) {
            log.debug("object handle " + objectHandle + "   operation " + result);
        }
        return result;
    }

    /**
     * Sets the operation in the HTTPRequestData object of this bean's NmCommandBean <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public void setOperation(String op, String objectHandle) throws WTException {
        if (op.equalsIgnoreCase(CREATE) || op.equalsIgnoreCase(EDIT)) {
            if (operation == null) {
                operation = op;
            }
            if (!operation.equals(op)) {
                throw new WTException(
                        "Doing both Create and Edit operations in the same wizard is not supported at this time.");
            }
            // set in request data in case operation is looked up via
            // CreateAndEditWizBean.getOperation(commandBean)
            setRequestDataParam(this.getCommandBean(), objectHandle + OPERATION_PARAMETER_NAME, operation);
        }
        else {
            throw new WTException(
                    "CreateAndEditWizBean(): operation attribute must be CreateAndEditBean.create or CreateAndEditBean.edit");
        }
    }

    /**
     * Gets a reference to the object currently being edited. The current object handle, if one exists, will be
     * prepended to parameter name. <BR>
     * <BR>
     * <B>Supported API: </B>false
     */

    public WTReference getEditObjectReference() throws WTException {
        String refString = (String) getParameterForCurrentObject(EDIT_OBJ_REF_PARAMETER_NAME);
        return (WTReference) convertParamValueToDataType(refString, WTReference.class);
    }

    /**
     * Gets a reference to the object currently being edited from the passed dataGetter using the given objectHandle.
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public static WTReference getEditObjectReference(FormDataHolder dataGetter) {
        String objectHandle = getCurrentObjectHandle(dataGetter);
        return getEditObjectReference(objectHandle, dataGetter);
    }

    public static WTReference getEditObjectReference(String objectHandle, FormDataHolder dataGetter) {
        Object objref = getParameter(EDIT_OBJ_REF_PARAMETER_NAME, objectHandle, dataGetter);
        WTReference ref = null;
        if (objref instanceof String || objref instanceof WTReference) {
            ref = (WTReference) convertParamValueToDataType(objref, WTReference.class);
        }
        else {
            log.error("The object reference was neither a String nor a WTReference.");
        }
        return ref;
    }

    /**
     * If the object being edited is a Workable, returns a reference to the working copy. Otherwise, returns the object
     * selected for editing. <BR>
     * <BR>
     * <B>Supported API: </B>false
     */

    public static WTReference getWorkingCopy(FormDataHolder dataGetter) {
        String objectHandle = getCurrentObjectHandle(dataGetter);
        WTReference objRef = null;
        // If the object is a Workable, the AutoCheckOutTag will write out a
        // reference to the working copy
        String workingCopyRef = dataGetter.getTextParameter(objectHandle + WORKING_COPY_REF_PARAMETER_NAME);
        if (workingCopyRef != null && !workingCopyRef.equals("")) {
            objRef = (WTReference) convertParamValueToDataType(workingCopyRef, WTReference.class);
        }
        if (objRef == null) {
            objRef = getEditObjectReference(objectHandle, dataGetter);
        }
        return objRef;
    }

    /**
     * Gets the base type identifier from the NmCommandBean of this bean instance. The current object handle, if one
     * exists, will be prepended to parameter name. For use in the servlet engine to get parameters from servlet
     * request. <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public WCTypeIdentifier getBaseTypeIdentifier() {
        Object typeIdParam = getParameterForCurrentObject(BASE_TYPE_IDENTIFIER);
        return (WCTypeIdentifier) convertParamValueToDataType(typeIdParam, WCTypeIdentifier.class);
    }

    /**
     * Gets the base type identifier from the passed dataGetter using the given objectHandle. For use in the servlet
     * engine or in the Method Server. <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public static WCTypeIdentifier getBaseTypeIdentifier(FormDataHolder dataGetter) {
        String objectHandle = getCurrentObjectHandle(dataGetter);
        return getBaseTypeIdentifier(objectHandle, dataGetter);
    }

    private static WCTypeIdentifier getBaseTypeIdentifier(String objectHandle, FormDataHolder dataGetter) {
        Object typeIdParam = getParameter(BASE_TYPE_IDENTIFIER, objectHandle, dataGetter);
        return (WCTypeIdentifier) convertParamValueToDataType(typeIdParam, WCTypeIdentifier.class);
    }

    /**
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public void setBaseTypeIdentifier(WCTypeIdentifier type, String objectHandle) {
        setRequestDataParam(commandBean, objectHandle + BASE_TYPE_IDENTIFIER, type);
    }

    /**
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public String getTypePickerInitValue() {
        return (String) getParameterForCurrentObject(TYPE_PICKER_INIT_VALUE);
    }

    /**
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public String getTypePickerInitValue(FormDataHolder dataGetter) {
        String objectHandle = getCurrentObjectHandle(dataGetter);
        return (String) getParameter(TYPE_PICKER_INIT_VALUE, objectHandle, dataGetter);
    }

    /**
     * Adds a type picker initial value.
     *
     * @param value
     *            The value you want available for the type picker
     * @param objectHandle
     *            The key for this type picker. <BR>
     *            <BR>
     *            <B>Supported API: </B>false
     */
    public void setTypePickerInitValue(String value, String objectHandle) {
        log.debug("setTypePickerInitValue() called");
        commandBean.addRequestDataParam(objectHandle + TYPE_PICKER_INIT_VALUE, value, false);
    }

    /**
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public String getUseHierachicalTypeListInPicker() {
        return (String) getParameterForCurrentObject(USE_HIERARCHICAL_TYPE_LIST_IN_PICKER);
    }

    /*
     * public String getUseHierachicalTypeListInPicker(FormDataHolder dataGetter) { String objectHandle =
     * getCurrentObjectHandle(dataGetter); return
     * (String)getParameter(USE_HIERARCHICAL_TYPE_LIST_IN_PICKER,objectHandle,dataGetter); }
     */

    /**
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public void setUseHierachicalTypeListInPicker(String value, String objectHandle) {
        commandBean.addRequestDataParam(objectHandle + USE_HIERARCHICAL_TYPE_LIST_IN_PICKER, value, false);
    }

    /**
     * Returns the TypeInstanceIdentifier for the object being created or edited from the parameters in the
     * HttpServletRequest associated with this bean or, if not there, from the parameters stored in the NmCommandBean
     * associated with this request. If not present in either place, returns null. <BR>
     * <BR>
     * The item TypeInstanceIdentifier is typically stored in the parameter map with the key ITEM_TIID_PARAMETER_NAME by
     * the InitializeItem tag. <BR>
     * <BR>
     * If the item TypeInstanceIdentifier represents a new object and the container context is available, the
     * TypeInstanceIdentifier for the container will be stored as an instance identifier in the returned item
     * TypeInstanceIdentifier. The external form of the returned identifier will be similar to: <BR>
     * <BR>
     * &nbsp,&nbsp;&nbsp; WCTYPE|wt.part.WTPart~~NEW|5755125324080743031|wt.pdmlink.PDMLinkProduct|78018. <BR>
     * <BR>
     * Because of this, the identifier can be used to obtain container-specific attribute information from object
     * initialization rules.
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public TypeInstanceIdentifier getItemTypeInstanceId() throws WTException {
        Object itemTiIdParamVal = getParameterForCurrentObject(ITEM_TIID_PARAMETER_NAME);
        WTContainerRef cRef = (null != itemTiIdParamVal) ? null : getContainerRef();
        return getItemTypeInstanceId(itemTiIdParamVal, cRef);
    }

    /**
     * Returns the TypeInstanceIdentifier for the object being created or edited from the parameter map of the given
     * FormDataHolder. <BR>
     * <BR>
     * The item TypeInstanceIdentifier is typically stored in the parameter map with the key ITEM_TIID_PARAMETER_NAME by
     * the InitializeItem tag. <BR>
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public static TypeInstanceIdentifier getItemTypeInstanceId(FormDataHolder dataHolder) throws WTException {
        String objectHandle = getCurrentObjectHandle(dataHolder);
        Object itemTiIdParamVal = getParameter(ITEM_TIID_PARAMETER_NAME, objectHandle, dataHolder, true);
        return getItemTypeInstanceId(itemTiIdParamVal, null);
    }

    /**
     * Based on the boolean flag fetches value first with object handle and if the value is null then it tries to fetch
     * without object handle and returns that value. <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    protected static Object getParameter(String PARAM_NAME, String objectHandle, FormDataHolder dataHolder,
            boolean retryWithNullObjectHandle) {
        Object obj = getParameter(PARAM_NAME, objectHandle, dataHolder);
        if (obj == null && retryWithNullObjectHandle) {
            obj = getParameter(PARAM_NAME, null, dataHolder);
        }
        return obj;
    }

    /**
     * Similar to getItemTypeInstanceId(), but if the item TypeInstanceIdentifier represents a new object and the
     * container context is available, the TypeInstanceIdentifier for the container will be stored as an instance
     * identifier in the returned item TypeInstanceIdentifier. The external form of the returned identifier will be
     * similar to: <BR>
     * <BR>
     * &nbsp,&nbsp;&nbsp; WCTYPE|wt.part.WTPart~~NEW|5755125324080743031|wt.pdmlink.PDMLinkProduct|78018. <BR>
     * <BR>
     * Because of this, the identifier can be used to obtain container-specific attribute information from object
     * initialization rules. <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public static TypeInstanceIdentifier getItemTypeInstanceIdWithContainer(FormDataHolder dataHolder)
            throws WTException {
        String objectHandle = getCurrentObjectHandle(dataHolder);
        Object itemTiIdParamVal = getParameter(ITEM_TIID_PARAMETER_NAME, objectHandle, dataHolder);
        WTContainerRef cRef = (null != itemTiIdParamVal) ? getContainerRef(dataHolder) : null;
        return getItemTypeInstanceId(itemTiIdParamVal, cRef);
    }

    private static TypeInstanceIdentifier getItemTypeInstanceId(Object itemTypeInstanceIdParamVal,
            WTContainerRef cRef) {
        TypeInstanceIdentifier itemTypeInstanceId = null;
        if (null != itemTypeInstanceIdParamVal) {
            itemTypeInstanceId = (TypeInstanceIdentifier) convertParamValueToDataType(itemTypeInstanceIdParamVal,
                    TypeInstanceIdentifier.class);
            if (null != itemTypeInstanceId && !itemTypeInstanceId.isInitialized() && null != cRef) {
                itemTypeInstanceId = (TypeInstanceIdentifier) itemTypeInstanceId.getWithNewInstanceIdentifier(
                        IDENTIFIER_FACTORY.newUninitializedInstanceIdentifier(
                                TypedUtility.getTypeInstanceIdentifier(cRef)));
            }
        }
        if (log.isDebugEnabled()) {
            log.debug("getItemTypeInstanceId() returning: "
                    + ((itemTypeInstanceId != null) ? itemTypeInstanceId.toExternalForm() : "null"));
        }
        return itemTypeInstanceId;
    }

    // We don't need the next unless a jsp is calling it
    /*
     * public void setItemTypeInstanceId(TypeInstanceIdentifier tiid, String objectHandle) { log.debug(
     * "setItemTypeInstanceId() called"); setRequestDataParam(commandBean, objectHandle + ITEM_TIID_PARAMETER_NAME,
     * tiid); }
     */

    /**
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public String getItemType() throws WTException {
        log.debug("getItemType() called");
        String typeName = "";
        String valueFromTypePicker = getTypeNameFromTypePicker(commandBean);
        if (valueFromTypePicker != null) {
            if (log.isDebugEnabled()) {
                log.debug("getItemType() returning type = WCTYPE|" + valueFromTypePicker + " from type picker");
            }
            return "WCTYPE|" + valueFromTypePicker;
        }
        else if (getItemTypeInstanceId() != null) {
            TypeIdentifier tid = (TypeIdentifier) getItemTypeInstanceId().getDefinitionIdentifier();
            typeName = tid.getTypename();
        }
        if (log.isDebugEnabled()) {
            log.debug("getItemType() returning type =  WCTYPE|" + typeName + "from TypeInstanceId");
        }
        return "WCTYPE|" + typeName;
    }

    /**
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public AttributePopulator getAttributePopulator() {
        Object aP = getParameterForCurrentObject(ATTRIBUTE_POPULATOR_PARAMETER_NAME);
        return (AttributePopulator) convertParamValueToDataType(aP, AttributePopulator.class);
    }

    /**
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public static AttributePopulator getAttributePopulator(FormDataHolder dataGetter) {
        String objectHandle = getCurrentObjectHandle(dataGetter);
        return getAttributePopulator(objectHandle, dataGetter);
    }

    private static AttributePopulator getAttributePopulator(String objectHandle, FormDataHolder dataGetter) {
        Object populator = getParameter(ATTRIBUTE_POPULATOR_PARAMETER_NAME, objectHandle, dataGetter);
        if (populator == null) {
            // Might not be available on current object so try again with no object handle
            // populator = getParameter(ATTRIBUTE_POPULATOR_PARAMETER_NAME, null, dataGetter);
            populator = getParameter(ATTRIBUTE_POPULATOR_PARAMETER_NAME, null, dataGetter);
        }
        AttributePopulator apInstance = (AttributePopulator) convertParamValueToDataType(populator,
                AttributePopulator.class);

        if (apInstance == null) {
            log.debug("getAttributePopulator() returning null because no AttributePopulator parameter was found.");
        }
        return apInstance;
    }

    /*
     * public void setAttributePopulator(AttributePopulator ap) { log.debug("setAttributePopulator called");
     * setRequestDataParam(commandBean, ATTRIBUTE_POPULATOR_PARAMETER_NAME, ap.getClass().getName()); }
     */

    /**
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public WTContainerRef getDefaultContainerRef() throws WTException {
        WTContainerRef cRef = null;
        AttributePopulator ap = getAttributePopulator();
        if (ap == null) {
            ap = new DefaultAttributePopulator();
        }
        cRef = ap.getContainerRef(getCommandBean());
        if (cRef == null) {
            Folder f = ap.getFolderFromLaunchContext(getCommandBean(), CreateAndEditWizBean
                    .getBaseTypeIdentifier(getCommandBean()));
            if (f != null) {
                cRef = f.getContainerReference();
            }
        }
        if (cRef == null) {
            Object container = getParameterForCurrentObject(DEF_CONTAINER_PARAMETER_NAME);
            cRef = (WTContainerRef) convertParamValueToDataType(container, WTContainerRef.class);
        }
        if (cRef == null) {
            log.debug("getDefaultContainerRef(): no default container found.");
        }
        return cRef;
    }

    /**
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public static WTContainerRef getDefaultContainerRef(FormDataHolder dataGetter) throws WTException {
        String objectHandle = getCurrentObjectHandle(dataGetter);
        HashMap<String, Object> parameters = dataGetter.getParameterMap();
        String param = ((String[]) parameters.get("actionName"))[0];
        if(param.equals("createNamingEntry")){
        	return DBUtils.getLibraryByName("Corporate Catalogues");
        }

        return getDefaultContainerRef(objectHandle, dataGetter);
    }

    /**
     * Determines the default container to use for an object being created from one of the following, in order of
     * preference: <BR>
     * <BR>
     * <OL>
     * <LI>If TYPE_PICKER_CHANGED_PARAMETER_NAME param is found, then the attribute populator/launch context logic will
     * be called first. This is a special edge case only known to happen in 1 wizard for 1 customer. See case 12367843.
     * <LI>Next, the value of a parameter with the key CreateAndEditWizBean.DEF_CONTAINER_PARAMETER_NAME in the
     * parameter map of the given FormDataHolder, if any</LI>
     * <LI>Then the attribute populator/launch context logic will be called. (See
     * {@link #getContainerRefFromAttrPopulatorOrLaunchContextFolder(String, FormDataHolder)})</LI>
     * </OL>
     * <BR>
     * When the launch context is used to determine the container ref, Note that if an object is being created in the
     * context of an object shared to a container, the container for the new object will be the container associated
     * with the action launch context. For example, when creating a new problem report from a project folder browser
     * using the row-level action associated with a part shared to the project, the container of the new problem report
     * should be the project, not the shared-from container. However, when creating a new problem report from the info
     * page of the same shared part, the container of the new problem report should be the container of the part, that
     * is, the shared-from container. <BR>
     * <BR>
     * If the context object is checked out from PDM, it will be a one-off version created in the Project container.
     * Therefore, the container of a related object being created in the context of a checked-out-from-PDM object will
     * always be the checked-out-to-container, whether launched from the folder browser or the info page. <BR>
     * See {@link FolderContextHelper} javadoc for more info.
     *
     */
    private static WTContainerRef getDefaultContainerRef(String objectHandle, FormDataHolder dataGetter)
            throws WTException {
        log.debug("Enter getDefaultContainerRef");
        if (log.isDebugEnabled() && dataGetter instanceof ObjectBean) {
            log.debug(dataGetter.toString());
        }
        WTContainerRef cRef = null;

        // If the type picker has changed, there may be a different container ref that should be loaded from an OIR,
        // so force this to be read from the attribute populator rather than the request.
        if (dataGetter instanceof NmCommandBean) {
            String typePickerChanged = (String) getParameter(TYPE_PICKER_CHANGED_PARAMETER_NAME, objectHandle,
                    dataGetter);
            if ((typePickerChanged != null) && typePickerChanged.equals("true")) {
                log.debug(
                        "Type picker changed param found, try getting container ref from AttrPopulatorOrLaunchContextFolder");
                cRef = getContainerRefFromAttrPopulatorOrLaunchContextFolder(objectHandle, dataGetter);
                if (cRef != null) {
                    log.debug("setting DEF_CONTAINER_PARAMETER_NAME");
                    setRequestDataParam((NmCommandBean) dataGetter, DEF_CONTAINER_PARAMETER_NAME, cRef);
                }
            }
        }

        if (cRef == null) {
            log.debug("try getting container ref from request parameter map");
            cRef = getContainerRefRequestParam(dataGetter, objectHandle);
        }

        if (cRef == null) {
            log.debug("try getting container ref from AttrPopulatorOrLaunchContextFolder");
            cRef = getContainerRefFromAttrPopulatorOrLaunchContextFolder(objectHandle, dataGetter);

        }

        if (log.isDebugEnabled()) {
            log.debug("Returning from getDefaultContainerRef " + cRef);
        }
        return cRef;
    }

    /**
     * Determines the default container to use for an object being created from the following: <BR>
     * <BR>
     * <OL>
     * <LI>If the wizard has an attribute populator, the value returned by the populator's getContainerRef() method, if
     * any</LI>
     * <LI>Next checks the folder returned by the populator's getFolderFromLaunchContext() method, if any, and uses the
     * container of that folder. If there is no populator defined the {@link DefaultAttributePopulator} would be used
     * which will end up calling {@link FolderContextHelper#getSelectedOrContextFolder(NmCommandBean, TypeIdentifier)}.
     * This will check for the folder from the "soid", the viewing container etc. See the javadoc on that API and class
     * for details of how the launch context folder is determined.</LI></LI>
     * <LI>Next gets the container ref from the command bean (container ref of the context object)</LI>
     * </OL>
     * <BR>
     * <BR>
     * If container ref is found, sets the DEF_CONTAINER_PARAMETER_NAME request parameter.
     *
     * @param objectHandle
     *            The objectHandle for the object being created or edited.
     * @param dataGetter
     *            The FormDataHolder that is used to determine the container ref.
     * @return A WTContainerRef used to represent the default container for creation of the object.
     * @throws WTException
     */
    private static WTContainerRef getContainerRefFromAttrPopulatorOrLaunchContextFolder(String objectHandle,
            FormDataHolder dataGetter) throws WTException {
        WTContainerRef cRef = null;
        if (cRef == null) {
            log.debug("try getting container reference from attribute populator");
            cRef = getContainerRefFromAttrPopulator(objectHandle, dataGetter);
        }

        if ((cRef == null) && (dataGetter instanceof NmCommandBean)) {
            log.debug("try getting launch context folder");
            Folder f = getLaunchContextFolder((NmCommandBean) dataGetter);

            // The next check handles the case where the context object is in a personal folder, such as that of a
            // workspace. In this case we want the container returned by calling getContainerRef() on the context
            // object, not the container to which the personal folder belongs, which is the Site container.
            // An example is creating a Design Context for an EPMDocument that is uploaded to a workspace, but not yet
            // checked in. See spr 2009492.
            // Note: This should not affect checked out objects whose working copy is stored in a personal cabinet,
            // since the above call returns the folder of the original copy.
            if ((f != null) && !inPersonalCabinet(f)) {
                log.debug("try getting container from launch context folder");
                cRef = f.getContainerReference();
            }

            if (cRef == null) {
                log.debug("try getting container associated with the context object");
                cRef = ((NmCommandBean) dataGetter).getContainerRef();
            }
        }

        return cRef;
    }

    /**
     * Returns the folder associated with the launch context
     */
    protected static Folder getLaunchContextFolder(NmCommandBean cb) throws WTException {
        return FolderContextHelper.getFolderFromLaunchContext(cb, CreateAndEditWizBean.getBaseTypeIdentifier(cb));
    }

    /**
     * Returns true if the passed CabinetBased object is in a personal cabinet. Returns false otherwise.
     */

    protected static boolean inPersonalCabinet(CabinetBased obj) throws WTException {
        WTArrayList collection = new WTArrayList();
        collection.add(0, obj);
        WTSet inPersonalCab = FolderHelper.getObjsInPersonalCabinets(collection);
        return inPersonalCab.contains(obj);
    }

    protected static WTContainerRef getContainerRefFromAttrPopulator(String objectHandle, FormDataHolder dataGetter) {
        WTContainerRef ref = null;
        AttributePopulator ap = getAttributePopulator(objectHandle, dataGetter);
        if (ap != null && dataGetter instanceof NmCommandBean) {
            ref = ap.getContainerRef((NmCommandBean) dataGetter);
        }
        return ref;
    }

    protected static WTContainerRef getContainerRefRequestParam(FormDataHolder dataHolder, String objectHandle) {
        WTContainerRef val = null;
        Object containerRef = getParameter(DEF_CONTAINER_PARAMETER_NAME, objectHandle, dataHolder);
        Object obj = convertParamValueToDataType(containerRef, WTContainerRef.class);
        if (obj instanceof WTContainerRef) {
            val = (WTContainerRef) obj;
        }
        return val;
    }

    protected static WTContainerRef getContainerRefFromSelectedObj(FormDataHolder dataHolder) throws WTException {
        WTContainerRef cRef = null;
        String soid = dataHolder.getTextParameter("soid");
        NmOid selected = NmContext.fromString(soid).getTargetOid();
        if (selected != null && selected.isA(wt.folder.SubFolder.class)) {
            cRef = selected.getContainerRef();
        }
        return cRef;
    }

    public void setContainerRef(WTContainerRef container, String objectHandle) {
        setRequestDataParam(commandBean, objectHandle + CONTAINER_PARAMETER_NAME, container);
    }

	
    /**
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public String getDefaultContainerRefString() throws WTException {
        String refString = null;
        WTContainerRef cRef = getDefaultContainerRef(getCommandBean());
        if (cRef != null) {
            refString = REFERENCE_FACTORY.getReferenceString(cRef);
        }
        return refString;
    }

    // We don't need the following unless a jsp is calling it
    /*
     * public void setDefaultContainerRef(WTContainerRef ref, String objectHandle) { setRequestDataParam(commandBean,
     * objectHandle + DEF_CONTAINER_PARAMETER_NAME, ref); }
     */

    /**
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public String getDefaultContainerName() throws WTException {
        WTContainerRef cRef = getDefaultContainerRef();
        if (cRef != null) {
            return ((WTContainer) cRef.getObject()).getName();
        }
        return null;
    }

    /**
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public TypeInstanceIdentifier getDefaultContainerTypeInstanceId() throws WTException {
        WTContainerRef cRef = getDefaultContainerRef();
        if (cRef != null) {
            return getTypeInstanceIdFromRef(cRef);
        }
        return null;
    }

    /**
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public String getContainerRefString(FormDataHolder dataHolder) throws WTException {
        String result = "";
        WTContainerRef cRef = getContainerRef(dataHolder);
        result = REFERENCE_FACTORY.getReferenceString(cRef);
        return result;
    }

    /**
     * If found, returns the value of the form parameter with the key CONTAINER_PARAMETER_NAME. Looks first in the
     * parameter map of the servlet request set on this bean. If not found, looks in the NmCommandBean set on this bean.
     * Looks first for a parameter associated with the current object handle. If none is found, looks for a parameter
     * not associated to an object handle. <br/>
     * If no form parameter value is found, returns the default container reference from the launch context. <br/>
     * <br/>
     * <B>Supported API: </B>false
     */
    public WTContainerRef getContainerRef() throws WTException {
        WTContainerRef cRef = null;
        Object container = getParameterForCurrentObject(CONTAINER_PARAMETER_NAME);
        if (container != null && !(container instanceof String && (container.equals("null") || container.equals("")))) {
            cRef = (WTContainerRef) convertParamValueToDataType(container, WTContainerRef.class);
        }
        if (cRef == null) {
            cRef = getDefaultContainerRef();
        }
        return cRef;
    }

    /**
     * If found, returns the value of the form parameter with the key CONTAINER_PARAMETER_NAME from the parameter map of
     * the passed FormDataHolder. Looks first for a parameter associated with the current object handle. If none is
     * found, looks for a parameter not associated to an object handle. <br/>
     * <br/>
     * If no form parameter value is found, returns the default container reference from the launch context. <br/>
     * <br/>
     * <B>Supported API: </B>false
     */
    public static WTContainerRef getContainerRef(FormDataHolder dataGetter) throws WTException {
        Object container = getParameterForCurrentObject(CONTAINER_PARAMETER_NAME, dataGetter);
        WTContainerRef cRef = null;
        if (container != null && !(container instanceof String && ("null".equals(container) || "".equals(container)))) {
            try {
                cRef = (WTContainerRef) convertParamValueToDataType(container, WTContainerRef.class);
            } catch (ConversionException cex) {
                // SPR 4687785 - in picker, search team provides comma separated values for "containerRef"
                // In those pages, if we call this method, ConversionException is thrown
                log.warn(
                        "ConversionException while trying to convert paramValue \"" + container + "\" WTContainerRef ",
                        cex);
            }
        }
        if (cRef == null) {
            String objectHandle = getCurrentObjectHandle(dataGetter);
            cRef = getDefaultContainerRef(objectHandle, dataGetter);
        }
        if (log.isDebugEnabled()) {
            log.debug("Container ref from context step = " + cRef);
        }
        return cRef;
    }

    /**
     * Returns true if the default container is overridable. This is set by the AttributePopulator class, if any. If not
     * set, returns false. <BR>
     * <BR>
     * <B>Supported API: </B>false
     */

    public static boolean isContainerOverridable(FormDataHolder dataGetter) {
        String objectHandle = getCurrentObjectHandle(dataGetter);
        String val = (String) getParameter(IS_DEF_CONTAINER_OVERRIDABLE, objectHandle, dataGetter);
        if (val != null) {
            return val.equalsIgnoreCase("true");
        }
        return false;
    }

    /**
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public String getContainerLabel() throws WTException {
        String key = com.ptc.core.ui.componentRB.GENERIC_CONTAINER_NAME_LABEL;
        WTContainerRef cRef = getContainerRef();
        key = getContainerLabel(key, cRef);
        return WTMessage
                .getLocalizedMessage("com.ptc.core.ui.componentRB", key, new Object[0], commandBean.getLocale());
    }

    public static String getContainerLabel(String key, WTContainerRef cRef) {
        if (!SERVER) {
            try {
                Class[] argTypes = { String.class, WTContainerRef.class };
                Object[] args = { key, cRef };
                return (String) RemoteMethodServer.getDefault().invoke("getContainerLabel",
                        CLASS_NAME, null, argTypes, args);
            } catch (RemoteException e) {
                throw new WTRuntimeException(e);
            } catch (InvocationTargetException e) {
                throw new WTRuntimeException(e);
            }
        }
        else if (cRef != null) {
            Class containerClass = cRef.getReferencedClass();
            if (PDMLinkProduct.class.isAssignableFrom(containerClass)) {
                key = componentRB.PRODUCT_CONTAINER_NAME_LABEL;
            }
            else if (WTLibrary.class.isAssignableFrom(containerClass)) {
                WTLibrary library = (WTLibrary) cRef.getReferencedContainer();
                if (library.isQMSTypeContainer()) {
                    key = componentRB.QUALITY_CONTAINER_NAME_LABEL;
                }
                else {
                    key = componentRB.LIBRARY_CONTAINER_NAME_LABEL;
                }
            }
            else if (Project2.class.isAssignableFrom(containerClass)) {
                boolean origenforce = SessionServerHelper.manager.setAccessEnforced(false);
                try {
                    Project2 project = (Project2) cRef.getReferencedContainer();
                    if (project.getPseudoType() == Project2.TYPE_PROJECT) {
                        key = componentRB.PROJECT_CONTAINER_NAME_LABEL;
                    }
                    else if (project.getPseudoType() == Project2.TYPE_PROGRAM) {
                        key = componentRB.PROGRAM_CONTAINER_NAME_LABEL;
                    }
                } finally {
                    SessionServerHelper.manager.setAccessEnforced(origenforce);
                }
            }
            else if (OrgContainer.class.isAssignableFrom(containerClass)) {
                key = componentRB.ORG_CONTAINER_NAME_LABEL;
            }
            else if (ExchangeContainer.class.isAssignableFrom(containerClass)) {
                key = componentRB.SITE_CONTAINER_NAME_LABEL;
            }
        }
        return key;
    }

    /**
     * Get the TypeInstanceIdentifier, even if the user doesn't have READ access to the container <BR>
     * <B>Supported API: </B>false
     */
    public static TypeInstanceIdentifier getContainerTypeInstanceId(FormDataHolder dataGetter) throws WTException {

        if (SERVER) {
            WTContainerRef cRef = getContainerRef(dataGetter);
            if (cRef != null) {
                return getTypeInstanceIdentifier(cRef);
            }
        }
        else {
            try {
                Class[] argTypes = { FormDataHolder.class };
                Object[] argsContext = { dataGetter };
                return (TypeInstanceIdentifier) RemoteMethodServer.getDefault().invoke("getContainerTypeInstanceId",
                         CreateAndEditWizBean.class.getName(), null, argTypes, argsContext);
            } catch (RemoteException | InvocationTargetException e) {
                log.error(e);
                throw new WTRuntimeException(e);
            }
        }
        return null;
    }

        /**
     * private method to conditionally disable access control and get TypeInstanceIdentifier
     */
    private static TypeInstanceIdentifier getTypeInstanceIdentifier(WTReference cRef)
            throws WTException {
        TypeInstanceIdentifier tid = null;

        // SPR ID: 6613352
        if (cRef instanceof ObjectReference) {
            ObjectIdentifier oid = ((ObjectReference) cRef).getObjectId();
            if (oid == null)
                return null;
            boolean deflateRef = !((ObjectReference) cRef).isObjectInflated();
            boolean original_enforce = SessionServerHelper.manager.setAccessEnforced(false);
            try {
                tid = (TypeInstanceIdentifier) RemoteWorkerHandler.handleRemoteWorker(
                        new GetTypeInstanceIdentifierRemoteWorker(), cRef.getObject());
            } catch (Exception e) {
                log.error(e);
                throw new WTException(e, "Could not convert reference to type instance identifier.");
            } finally {
                SessionServerHelper.manager.setAccessEnforced(original_enforce);
                if (deflateRef) {
                    // Ensure reference is deflated before returning
                    ((ObjectReference) cRef).deflate();
                }
            }
        }
        else {
            try {
                tid = (TypeInstanceIdentifier) RemoteWorkerHandler.handleRemoteWorker(
                        new GetTypeInstanceIdentifierRemoteWorker(), cRef);
            } catch (Exception e) {
                log.error(e);
                throw new WTException(e, "Could not convert reference to type instance identifier.");
            }
        }
        return tid;
    }

    /**
     * private method to conditionally disable access control and get TypeInstanceIdentifier
     */																		 
																
	   
    private static TypeInstanceIdentifier getTypeInstanceIdentifier(WTReference cRef, Boolean byPassAccess)
            throws WTException {

        TypeInstanceIdentifier tid = null;
        // disable access check
        boolean enforce = true;
        if (byPassAccess) {
            enforce = SessionServerHelper.manager.setAccessEnforced(false);
        }
        try {
            tid = (TypeInstanceIdentifier) RemoteWorkerHandler.handleRemoteWorker(
                    new GetTypeInstanceIdentifierRemoteWorker(), cRef);
        } catch (Exception e) {
            log.error(e);
            throw new WTException(e, "Could not convert reference to type instance identifier.");
        } finally {
            if (byPassAccess) {
                // revert disable
                SessionServerHelper.manager.setAccessEnforced(enforce);
            }
        }
        return tid;
    }

    // The following methods are to get/set data local to a jsp
    /**
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public HttpServletRequest getRequest() {
        return request;
    }

    /**
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public void setRequest(HttpServletRequest theRequest) {
        request = theRequest;
    }

    /**
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public NmCommandBean getCommandBean() {
        return commandBean;
    }

    /**
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public void setCommandBean(NmCommandBean theCommandBean) {
        commandBean = theCommandBean;
    }

    /**
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public PropagationBean getPropagationBean() {
        return propagationBean;
    }

    /**
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public void setPropagationBean(PropagationBean thePropagationBean) {
        propagationBean = thePropagationBean;
    }

    /**
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public WTReference getTypePickerAdminDomainRef() {
        if (typePickerAdminDomainRef != null) {
            return typePickerAdminDomainRef;
        }
        return getDefaultAdminDomainRef();
    }

    /**
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public void setTypePickerAdminDomainRef(String adminDomainRefString) {
        log.debug("setTypePickerAdminDomainRef() called");
        ReferenceFactory rf = new ReferenceFactory();
        try {
            WTReference aref = rf.getReference(adminDomainRefString);
            typePickerAdminDomainRef = aref;
        } catch (WTException wte) {
            String mess = "Unable to find admin domain ref " + adminDomainRefString
                    + ". Default admin domain will be used.";
            log.warn(mess);
        }
    }

    // Made protected for unit testing access.
    /**
     * Gets the default administrative domain to be used for the type picker. This can be set in the configureTypePicker
     * tag. If not set there, the domain associated with the default folder value in the location picker will be used.
     *
     * Returns the domain of the defaultcabinet of the container if the object is not foldered Returns null if no
     * container can be found and its not foldered
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    protected WTReference getDefaultAdminDomainRef() {
        return getDefaultAdminDomainRef(getCommandBean());
    }

    /**
     * Gets the default administrative domain to be used for the type picker. This can be set in the configureTypePicker
     * tag. If not set there, the domain associated with the default folder value in the location picker will be used.
     *
     * Returns the domain of the defaultcabinet of the container if the object is not foldered Returns null if no
     * container can be found and its not foldered
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public static WTReference getDefaultAdminDomainRef(NmCommandBean cb) {
        try {
            Folder defaultFolder = FolderContextHelper.getFolderForTypePicker(cb);
            if (defaultFolder instanceof DomainAdministered) {
                WTReference ref = ((DomainAdministered) defaultFolder).getDomainRef();
                if (log.isDebugEnabled()) {
                    log.debug("getDefaultAdminDomainRef() returning: " + ref);
                }
                return ref;
            }
        } catch (WTException wte) {
            // Couldn't get a default domain
            log.debug("Exception trying to get default admin domain ref", wte);
        }
        return null;

    }

    /**
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public boolean getTypePickerShowRoot() {
        return typePickerShowRoot;
    }

    /**
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public void setTypePickerShowRoot(boolean value) {
        log.debug("setTypePickerShowShowRoot() called");
        typePickerShowRoot = value;
    }

    /**
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public void setIncludeTypePicker(boolean include) {
        includeTypePicker = include;
    }

    /**
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public boolean getIncludeTypePicker() {
        return includeTypePicker;
    }

    /**
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public void setTypePickerFilterTypes(ArrayList<String> types) {
        typePickerFilterTypes = types;
    }

    /**
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public ArrayList<String> getTypePickerFilterTypes() {
        return typePickerFilterTypes;
    }

    /**
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public void setTypePickerSeedTypes(ArrayList<String> types) {
        typePickerSeedTypes = types;
    }

    /**
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public ArrayList<String> getTypePickerSeedTypes() {
        if (typePickerSeedTypes != null && typePickerSeedTypes.size() > 0) {
            return typePickerSeedTypes;
        }
        else {
            WCTypeIdentifier baseType = getBaseTypeIdentifier();
            if (baseType == null) {
                log.error("base type should not be null, is the initializeItem tag missing?");
            }
            String baseTypeName = baseType.toExternalForm();
            log.debug("getTypePickerSeedTypes() returning baseTypeName: " + baseTypeName);

            ArrayList<String> seedTypes = new ArrayList<String>();
			NmCommandBean bean = this.getCommandBean();
            HashMap<String, Object> parameters = bean.getParameterMap();
            String param = ((String[]) parameters.get("actionName"))[0];
            if(param.equals("createNamingEntry")){
            	baseTypeName = "WCTYPE|wt.part.WTPart|com.ptc.Administrative|com.ptc.KBNamingEntry";
            }
            seedTypes.add(baseTypeName);
            return seedTypes;
        }
    }

    /**
     * Returns a new TypeInstanceIdentifier string for part getting a master oid string.
     *
     * @return TypeInstanceIdentifier String <BR>
     *         <BR>
     *         <B>Supported API: </B>false
     */
    public static String getTypeInstanceIdForVersion(String oidStr) throws WTException {
        QueryResult result = null;
        Mastered obj = null;

        try {
            NmOid oid = NmOid.newNmOid(oidStr);
            if (oid != null && oid.isA(Mastered.class)) {
                obj = (Mastered) oid.getRef();
            }
            result = VersionControlHelper.service.allIterationsOf(obj);
            Object version = result.nextElement();
            TypeIdentifier typeId = (TypeIdentifier) RemoteWorkerHandler.handleRemoteWorker(
                    new GetTypeIdentifierRemoteWorker(), version);
            return typeId.newTypeInstanceIdentifier().toExternalForm().trim();
        } catch (Exception e) {
            throw new WTException(e, "Could not convert the oid string to a type instance for version.");
        }
    }

    /**
     * Returns the name that should be used for a hidden form field that registers a FormProcessorDelegate for the
     * wizard
     *
     * <BR>
     * <BR>
     * <B>Supported API: </B>true
     */
    public String getFormProcessorDelegateConstant() {
        return FORM_PROCESSOR_DELEGATE;
    }

    /**
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public static boolean isCreateEditWizard(FormDataHolder cb) throws WTException {
        boolean isInWizard = false;
        if (cb != null) {
            String operation = getOperation(cb);
            if (operation != null && (operation.equals(CREATE) || operation.equals(EDIT))) {
                isInWizard = true;
            }
        }
        return isInWizard;
    }

    /**
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public String getContextPickerExcludeTypes() {
        return this.contextPickerExcludeTypes;
    }

    /**
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public void setContextPickerExcludeTypes(String contextPickerExcludeTypes) {
        this.contextPickerExcludeTypes = contextPickerExcludeTypes;
    }

    /**
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public String getContextPickerTypeComponentId() {
        return this.contextPickerTypeComponentId;
    }

    /**
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public void setContextPickerTypeComponentId(String contextPickerTypeComponentId) {
        if ((contextPickerTypeComponentId != null) && (contextPickerTypeComponentId.trim().length() > 0)) {
            this.contextPickerTypeComponentId = contextPickerTypeComponentId.trim();
        }
    }

    /**
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public String getTypePickerType() {
        return typePickerType;
    }

    /**
     * <BR>
     * <BR>
     * <B>Supported API: </B>false
     */
    public void setTypePickerType(String typePickerType) {
        this.typePickerType = typePickerType;
    }

    /**
     * creates a WCTypeIdentifier from the given string.
     *
     * @return WCTypeIdentifier created from the given string or null if a valid WCTypeIdentifier couldn't successfully
     *         be created
     */
    public final static WCTypeIdentifier newWCTypeIdentifier(String type) {
        WCTypeIdentifier typeId = null;
        if (type != null && !"".equals(type)) {
            try {
                typeId = (WCTypeIdentifier) IDENTIFIER_FACTORY.newWCTypeIdentifier(type);
                // Make sure type is a valid type and not a typo or a string
                // like "Select A Type"
                Class.forName(typeId.getClassnameFromTypename());
            } catch (Exception e) {
                if (log.isDebugEnabled()) {
                    log.debug(" in getTypeIdentifier() trying to create WCTypeIdentifier from type: " + type);
                }
                typeId = null;
            } // end try
        } // end if type
        return typeId;
    }

    /**
     * Gets a TypeIdentifier for the target object. If typePickerInitVal is null on input (because object is not Typed),
     * the base type will be used. If typePickerInitVal is a prompt string or blank and not a type name, the base type
     * will be used. Otherwise, the type name specified in typePickerInitVal will be used.
     */
    public final static TypeInstanceIdentifier newTypeInstanceIdentifier(String typePickerInitVal,
            TypeIdentifier baseTypeIdentifier) {
        TypeIdentifier tid = newWCTypeIdentifier(typePickerInitVal);
        if (tid == null) {
            if (log.isDebugEnabled()) {
                String mess = "using baseTypeIdentifier because a valid TypeIdentifier couldn't be created from the typePickerInitVal of "
                        + typePickerInitVal;
                log.debug(mess);
            }
            // typePickerInitVal must be a message string or blank so use base
            // type as default type
            tid = baseTypeIdentifier;
        } // end if tid
        if (log.isDebugEnabled()) {
            log.debug("tid is " + tid.toExternalForm());
        }
        return tid.newTypeInstanceIdentifier();
    }

    /**
     * Gets the string to display in the type picker text box when first displayed. Could be a type name such as
     * "WCTYPE|wt.part.WTPart|MySoftPart" or a string such as "Select a Type", or a blank string. The initial value will
     * be the default type set in preferences, if one exists, or the base type name otherwise.
     */
    // changed this method to protected for unit testing.
    public final static String computeTypePickerInitValue(String baseType, WTContainerRef containerRef)
            throws WTException {
        String defType = getDefaultTypePref(baseType, containerRef);
        if (log.isDebugEnabled()) {
            log.debug("default type preference value is \"" + defType + "\"");
        }
        if (defType == null) {
            defType = baseType;
        }
        else if (defType.equals(TypeIdentifierSelectionHelper.TYPE_SELECT_BLANK)) {
            defType = "";
        }
        else if (!defType.startsWith(TypeIdentifierSelectionHelper.TYPE_PREFIX)) {
            int indx = defType.indexOf(":");
            if (indx > 0) {
                String resourceClassName = defType.substring(0, indx);
                try {
                    Class resourceClass = Class.forName(resourceClassName);
                    java.lang.reflect.Field fieldName = null;
                    fieldName = resourceClass.getField(defType.substring(indx + 1));
                    defType = WTMessage.getLocalizedMessage(resourceClassName, (String) fieldName.get(resourceClass),
                            (Object[]) null, SessionHelper.getLocale());
                } catch (Exception e) {
                    throw new WTException(e,
                            "computeTypePickerInitValue(): could not obtain a resource string for initial type picker value");
                }
            }
            else {
                defType = baseType;
            }
        } // end if else if
        return defType;
    }

    /**
     * Gets the default type for the given base type from user preferences
     */
    public final static String getDefaultTypePref(String baseType, WTContainerRef containerRef) throws WTException {
        if (baseType == null || containerRef == null) {
            return null;
        }

        String prefVal = null;
        if (baseType.contains("WCTYPE|")) {
            baseType = baseType.substring(baseType.indexOf("|") + 1);
        }
        prefVal = TypeIdentifierSelectionHelper.getDefaultTypePreferenceValue(baseType, containerRef);

        if (log.isDebugEnabled()) {
            log.debug("default type preference is " + prefVal);
        }
        return prefVal;
    }
} // end class
