package com.ptc.windchill.enterprise.search.mvc.controllers;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import wt.log4j.LogR;
import wt.util.WTException;

import com.ptc.jca.mvc.components.JcaComponentParams;
import com.ptc.jca.mvc.components.JcaComponentParamsFactory;
import com.ptc.netmarkets.search.beans.SearchBean;
import com.ptc.windchill.enterprise.search.facet.SearchFacetFilter;
import com.ptc.windchill.enterprise.search.facet.SolrFacetQueryService;
import com.ptc.windchill.enterprise.search.mvc.builders.SearchDataBuilder;
import com.ptc.windchill.enterprise.search.server.SearchInfo;

@Controller
@RequestMapping("/searchFacet")
public class SearchFacetController {

    @Autowired
    private SolrFacetQueryService facetQueryService;

    @Autowired
    @Qualifier("com.ptc.windchill.enterprise.search.mvc.builders.SearchDataBuilder")
    private SearchDataBuilder dataBuilder;
    
    private static final Logger LOGGER = LogR.getLogger(SearchFacetController.class.getName());

    @RequestMapping(produces="application/json;charset=UTF-8")
    protected void processRequest(HttpServletRequest request, HttpServletResponse response, HttpSession session, 
            @RequestParam("jsonForQuery") String queryJson) throws Exception {

        ObjectMapper jacksonMapper = new ObjectMapper();
        
        SearchFacetFilter facet = null;
        if (queryJson!=null && !queryJson.isEmpty()) {
            if(LOGGER.isDebugEnabled()) LOGGER.debug("facet filter " + queryJson);
            facet = jacksonMapper.readValue(queryJson, SearchFacetFilter.class);
        }

        SearchBean searchBean = (SearchBean) session.getAttribute("searchbean");
        if(searchBean == null){
            throw new WTException("session expired");
        }
        request.setAttribute("searchbean", searchBean);

        JcaComponentParamsFactory paramsFactory = new JcaComponentParamsFactory();
        JcaComponentParams params = (JcaComponentParams) paramsFactory.createComponentParams(request, response);

        SearchInfo searchInfo = dataBuilder.getSearchCriteria(params);

        SearchFacetFilter searchFacetFilter = facetQueryService.getSearchFacetFilter(searchBean, searchInfo, facet);
        String facetJson = jacksonMapper.writeValueAsString(searchFacetFilter);
        if(LOGGER.isDebugEnabled()){
            LOGGER.debug("facet json : "+ facetJson);
        }
        response.setContentType("application/json; charset=UTF-8");
        PrintWriter writer = response.getWriter();
        writer.write(facetJson);
    }

}
