/* bcwti
 *
 * Copyright (c) 2010 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */
package com.ptc.windchill.enterprise.change2;

import wt.util.resource.*;

@RBUUID("com.ptc.windchill.enterprise.change2.change2ClientResource")
public final class change2ClientResource_it extends WTListResourceBundle {
   /**
    *
    * This file contains all the strings used by the DCA based Change Management clients
    *
    * ##############################################################################
    *
    * Object class names
    *
    * ##############################################################################
    **/
   @RBEntry("Soluzione temporanea")
   @RBComment("see wt.change2.change2ModelRB:WTVariance key")
   public static final String PRIVATE_CONSTANT_0 = "VARIANCE";

   @RBEntry("Report di problema")
   @RBComment("The name of the object \"Problem Report\".")
   public static final String PRIVATE_CONSTANT_1 = "PROBLEM_REPORT";

   @RBEntry("Richiesta di modifica")
   @RBComment("The name of the object \"Change Request\".")
   public static final String PRIVATE_CONSTANT_2 = "CHANGE_REQUEST";

   @RBEntry("Notifica di modifica")
   @RBComment("The name of the object \"Change Notice\".")
   public static final String PRIVATE_CONSTANT_3 = "CHANGE_NOTICE";

   /**
    * ##############################################################################
    *
    * Legacy Strings used by the local search tooltips
    * @deprecated
    *
    * ##############################################################################
    **/
   @RBEntry("Mostra la pagina delle informazioni per il report di problema")
   @RBComment("Tooltip for the info page action.")
   public static final String PRIVATE_CONSTANT_4 = "CHANGE_ISSUE_INFO_PAGE_TT";

   @RBEntry("Mostra la pagina delle informazioni per la notifica di modifica")
   @RBComment("Tooltip for the info page action.")
   public static final String PRIVATE_CONSTANT_5 = "CHANGE_ORDER_INFO_PAGE_TT";

   @RBEntry("Mostra la pagina delle informazioni per la richiesta di modifica")
   @RBComment("Tooltip for the info page action.")
   public static final String PRIVATE_CONSTANT_6 = "CHANGE_REQUEST_INFO_PAGE_TT";

   @RBEntry("Mostra la pagina delle informazioni per il report di problema")
   @RBComment("Tooltip for the info page action.")
   public static final String PRIVATE_CONSTANT_7 = "PR_DETAIL_TT";

   @RBEntry("Mostra la pagina delle informazioni per la richiesta di modifica")
   @RBComment("Tooltip for the info page action.")
   public static final String PRIVATE_CONSTANT_8 = "ECR_DETAIL_TT";

   @RBEntry("Mostra la pagina delle informazioni per la notifica di modifica")
   @RBComment("Tooltip for the info page action.")
   public static final String PRIVATE_CONSTANT_9 = "ECN_DETAIL_TT";

   @RBEntry("Mostra la pagina delle informazioni per la Proposta di modifica")
   @RBComment("Tooltip for the info page action.")
   public static final String PRIVATE_CONSTANT_10 = "CHANGE_PROPOSAL_INFO_TT";

   @RBEntry("Mostra la pagina delle informazioni per il task")
   @RBComment("Tooltip for the info page action.")
   public static final String PRIVATE_CONSTANT_11 = "CHANGE_ACTIVITY_INFO_TT";

   @RBEntry("Mostra la pagina delle informazioni per l'investigazione di modifica")
   @RBComment("Tooltip for the info page action.")
   public static final String PRIVATE_CONSTANT_12 = "CHANGE_INVESTIGATION_INFO_TT";

   @RBEntry("Mostra la pagina delle informazioni per l'analisi")
   @RBComment("Tooltip for the info page action.")
   public static final String PRIVATE_CONSTANT_13 = "ANALYSIS_ACTIVITY_INFO_TT";

   @RBEntry("Associa modifiche")
   @RBComment("The Associated Problem Reports step in the wizard.")
   public static final String PRIVATE_CONSTANT_14 = "RELATED_CHANGES";

   /**
    * ##############################################################################
    *
    * Picker titles
    *
    * ##############################################################################
    **/
   @RBEntry("Trova problemi e soluzioni temporanee associati")
   @RBComment("The title for the action \"Add Associated Changes\"")
   public static final String PRIVATE_CONSTANT_15 = "FIND_ASSOCIATED_CHANGEISSUES";

   @RBEntry("Trova richieste di modifica associate")
   @RBComment("The title for the action \"Add Associated Changes\"")
   public static final String PRIVATE_CONSTANT_16 = "FIND_ASSOCIATED_CHANGEREQUESTS";

   @RBEntry("Trova prodotti finali interessati")
   @RBComment("The title for the action \"Add Affected End Items\"")
   public static final String PRIVATE_CONSTANT_17 = "FIND_AFFECTED_END_ITEMS";

   @RBEntry("Trova oggetti interessati")
   @RBComment("The title for the action \"Add Affected Objects\"")
   public static final String PRIVATE_CONSTANT_18 = "FIND_AFFECTED_DATA";

   @RBEntry("Trova oggetti risultanti")
   @RBComment("The title for the action \"Add Resulting Objects\"")
   public static final String PRIVATE_CONSTANT_19 = "FIND_RESULTING_DATA";

   @RBEntry("Trova notifiche di modifica")
   @RBComment(" The title for the Change Notice Summary Report input page (from the Cognos reports page).")
   public static final String PRIVATE_CONSTANT_20 = "FIND_CHANGE_NOTICES";

   @RBEntry("Trova richieste di modifica")
   @RBComment(" The title for the Change Request Summary Report input page (from the Cognos reports page).")
   public static final String PRIVATE_CONSTANT_21 = "FIND_CHANGE_REQUESTS";

   @RBEntry("Trova soluzioni temporanee")
   @RBComment(" The title for the Variance Summary Report input page (from the Cognos reports page).")
   public static final String PRIVATE_CONSTANT_22 = "FIND_VARIANCES";

   @RBEntry("Trova report di problema")
   @RBComment(" The title for the Problem Reports Summary Report input page (from the Cognos reports page).")
   public static final String PRIVATE_CONSTANT_23 = "FIND_PROBLEM_REPORTS";

   /**
    * ##############################################################################
    *
    * Table titles
    *
    * ##############################################################################
    **/
   @RBEntry("Oggetti interessati")
   @RBComment("The Affected Items table title.")
   public static final String PRIVATE_CONSTANT_24 = "AFFECTED_ITEMS_TABLE";

   @RBEntry("Direttive di modifica che interessano")
   @RBComment("The Impacting Directive table title.")
   public static final String PRIVATE_CONSTANT_25 = "IMPACTING_ITEMS_TABLE";

   @RBEntry("Azioni di modifica")
   @RBComment("The Change Actions table.")
   public static final String PRIVATE_CONSTANT_26 = "CHANGE_ACTIONS_TABLE";

   @RBEntry("Oggetti risultanti")
   @RBComment("The Resulting Items table title.")
   public static final String PRIVATE_CONSTANT_27 = "RESULTING_ITEMS_TABLE";

   @RBEntry("Esamina oggetti risultanti")
   @RBComment("The table title for the review resulting objects table on a review workflow task.")
   public static final String REVIEW_TASK_RESULTING_ITEMS_TABLE = "REVIEW_TASK_RESULTING_ITEMS_TABLE";   

   @RBEntry("Completa oggetti risultanti")
   @RBComment("The table title for the complete resulting objects table on a workflow task.")
   public static final String COMPLETE_TASK_RESULTING_ITEMS_TABLE = "COMPLETE_TASK_RESULTING_ITEMS_TABLE";
   
   @RBEntry("Oggetti interessati")
   @RBComment("The Affected Objects (change request, problem report, Variance) table title.")
   public static final String PRIVATE_CONSTANT_28 = "AFFECTED_DATA_TABLE";

   @RBEntry("Prodotti finali interessati")
   @RBComment("The Affected End Items table title.")
   public static final String PRIVATE_CONSTANT_29 = "AFFECTED_END_ITEMS_TABLE";

   @RBEntry("Riepilogo modifiche")
   @RBComment("Affected and Resulting Data for all Change Tasks on a Change Notice")
   public static final String CHANGE_NOTICE_SUMMARY_TABLE = "CHANGE_NOTICE_SUMMARY_TABLE";

   @RBEntry("Verifica riepilogo modifiche")
   @RBComment("The table title for the audit change summary table.")
   public static final String AUDIT_CHANGE_NOTICE_SUMMARY_TABLE = "AUDIT_CHANGE_NOTICE_SUMMARY_TABLE";   

   @RBEntry("Problemi e soluzioni temporanee associati")
   @RBComment("The table title for the Related Problem Reports (as well as other issues) and Variances.")
   public static final String RELATED_CHANGEISSUES_TABLE = "RELATED_CHANGEISSUES_TABLE";

   @RBEntry("Richieste di modifica associate")
   @RBComment("The table title for the related change requests.")
   public static final String RELATED_CHANGEREQUESTS_TABLE = "RELATED_CHANGEREQUESTS_TABLE";

   @RBEntry("Problemi e soluzioni temporanee")
   @RBComment("The table title for the Related Problem Reports (and other issues) and Variances.")
   public static final String PRIVATE_CONSTANT_30 = "CHANGE_ISSUES_TABLE";

   @RBEntry("Richieste di modifica")
   @RBComment("The plural name of the object \"Change Request\".")
   public static final String PRIVATE_CONSTANT_31 = "CHANGE_REQUESTS_TABLE";

   @RBEntry("Notifiche di modifica")
   @RBComment("The plural name of the object \"Change Notice\".")
   public static final String PRIVATE_CONSTANT_32 = "CHANGE_NOTICES_TABLE";

   @RBEntry("Oggetti interessati dalle notifiche di modifica")
   @RBComment("The table title for the Affected by Change Notices info page table")
   public static final String PRIVATE_CONSTANT_33 = "AFFECTED_BY_CHANGE_NOTICES_TABLE";

   @RBEntry("Oggetti risultanti dalle notifiche di modifica")
   @RBComment("The table title for the Resulting from Change Notices info page table")
   public static final String PRIVATE_CONSTANT_34 = "RESULTING_FROM_CHANGE_NOTICES_TABLE";

   @RBEntry("Gruppi di annotazioni")
   @RBComment("The table title for the Annotation Set table")
   public static final String PRIVATE_CONSTANT_35 = "ANNOTATION_SET_TABLE";

   @RBEntry("Attributi")
   @RBComment("The table title for the Variance Analysis attribute table.")
   public static final String VARIANCE_ANALYSIS_TABLE = "VARIANCE_ANALYSIS_TABLE";

   @RBEntry("Attributi")
   @RBComment("The table tile for the Attributes table from the information pages.")
   public static final String PRIVATE_CONSTANT_36 = "ATTRIBUTES_TABLE";

   @RBEntry("Modifiche non incorporate")
   @RBComment("The table title for the Unincorporated changes table")
   public static final String PRIVATE_CONSTANT_37 = "UNINCORPORATED_CHANGE_TABLE";

   @RBEntry("Proposte e investigazioni")
   @RBComment("The table title for the Change Proposals and Change Investigations")
   public static final String PRIVATE_CONSTANT_38 = "PROPOSALS_AND_INVESTIGATIONS_TABLE";

   @RBEntry("Analisi")
   @RBComment("The table title for Analysis Activities")
   public static final String PRIVATE_CONSTANT_39 = "ANALYSIS_ACTIVITIES_TABLE";

   @RBEntry("Notifica di modifica")
   @RBComment("The column name for the Change Notice Id")
   public static final String HC_CHANGENOTICE = "HC_CHANGENOTICE";

   @RBEntry("Stato del ciclo di vita")
   @RBComment("The column name for the Change Notice State")
   public static final String HC_CHANGENOTICE_STATE = "HC_CHANGENOTICE_STATE";

   @RBEntry("Task di modifica")
   @RBComment("The column name for the Change Task Id")
   public static final String HC_CHANGETASK = "HC_CHANGETASK";

   @RBEntry("Piano di incorporazione")
   @RBComment("The column name for Incorporation Plan")
   public static final String HC_INCORPOPTION = "HC_INCORPOPTION";

   @RBEntry("Revisione pianificata")
   @RBComment("The column name for Planned Revision")
   public static final String HC_INCORPREVISION = "HC_INCORPREVISION";

   @RBEntry("Problemi")
   @RBComment("The title for the All Open Issues table.")
   public static final String OPEN_ISSUES_TITLE = "OPEN_ISSUES_TITLE";

   @RBEntry("Richieste di modifica")
   @RBComment("The title for the All Open Change Requests table.")
   public static final String OPEN_CHANGE_REQUESTS_TITLE = "OPEN_CHANGE_REQUESTS_TITLE";

   @RBEntry("Notifiche di modifica")
   @RBComment("The title for the All Open Change Notices table.")
   public static final String OPEN_CHANGE_NOTICES_TITLE = "OPEN_CHANGE_NOTICES_TITLE";

   @RBEntry("Soluzioni temporanee")
   @RBComment("The title for the All Open Variances table.")
   public static final String OPEN_VARIANCES_TITLE = "OPEN_VARIANCES_TITLE";

   @RBEntry("Per creare un report di problema, accedere alla pagina delle informazioni di un oggetto che può essere modificato, ad esempio una parte o un documento, e selezionare \"Nuovo report di problema\" dall'elenco di azioni. Per ulteriori informazioni, consultare la Guida in linea accessibile dalla tabella \"Report di problema\".")
   @RBComment("Informational text to create problem reports.")
   public static final String OPEN_PROBLEM_REPORTS_HELP = "OPEN_PROBLEM_REPORTS_HELP";

   @RBEntry("Per creare una notifica di modifica, accedere alla pagina delle informazioni della richiesta di modifica e selezionare \"Nuova notifica di modifica\" dall'elenco di azioni. Per ulteriori informazioni, consultare la Guida in linea accessibile dalla tabella \"Notifica di modifica\".")
   @RBComment("Informational text to create change notices.")
   public static final String OPEN_CHANGE_NOTICES_HELP = "OPEN_CHANGE_NOTICES_HELP";

   @RBEntry("Per creare una richiesta di modifica, accedere alla pagina delle informazioni di un report di problema e selezionare \"Nuova richiesta di modifica\" dall'elenco di azioni. Per ulteriori informazioni, consultare la Guida in linea accessibile dalla tabella \"Richieste di modifica\".")
   @RBComment("Informational text to create requests notices.")
   public static final String OPEN_CHANGE_REQUESTS_HELP = "OPEN_CHANGE_REQUESTS_HELP";

   @RBEntry("Per creare una soluzione temporanea, accedere alla pagina delle informazioni di un oggetto che può essere modificato, ad esempio una parte o un documento, e selezionare Nuova soluzione temporanea dall'elenco di azioni. Per ulteriori informazioni, consultare la guida in linea accessibile dalla tabella Soluzioni temporanee.")
   @RBComment("Informational text to create variances.")
   public static final String OPEN_VARIANCES_HELP = "OPEN_VARIANCES_HELP";

   @RBEntry("Requisiti correlati")
   @RBComment("Title for the fulfill requirements table")
   public static final String PRIVATE_CONSTANT_40 = "FULFILL_CHANGEACTIONS_TABLE";

   @RBEntry("Baseline modifiche")
   @RBComment("Title for the Change Baseline report tree")
   public static final String CHANGE_BASELINE_TABLE = "CHANGE_BASELINE_TABLE";


   /**
    * ##############################################################################
    *
    * Table views
    *
    * ##############################################################################
    */

   @RBEntry("Report di problema")
   public static final String PROBLEM_REPORT_TABLEVIEW_NAME = "PROBLEM_REPORT_TABLEVIEW_NAME";

   @RBEntry("Vista di soli report di problema")
   public static final String PROBLEM_REPORT_TABLEVIEW_DESCRIPTION = "PROBLEM_REPORT_TABLEVIEW_DESCRIPTION";

   @RBEntry("Soluzioni temporanee")
   public static final String VARIANCE_TABLEVIEW_NAME = "VARIANCE_TABLEVIEW_NAME";

   @RBEntry("Vista di sole soluzioni temporanee")
   public static final String VARIANCE_TABLEVIEW_DESCRIPTION = "VARIANCE_TABLEVIEW_DESCRIPTION";

   @RBEntry("Proposta di modifica")
   public static final String CHANGE_INTENT = "CHANGE_INTENT";

   @RBEntry("Contenuto release")
   public static final String RELEASE_CONTENT = "RELEASE_CONTENT";

   @RBEntry("Parti interessate")
   public static final String AFFECTED_PARTS = "AFFECTED_PARTS";

   @RBEntry("Default")
   @RBComment("The default table view name for the Change Baseline report")
   public static final String CHANGE_BASELINE_REPORT_TABLE_VIEW_DEFAULT_NAME = "CHANGE_BASELINE_REPORT_TABLE_VIEW_DEFAULT_NAME";

   @RBEntry("Vista di default")
   @RBComment("The default table view description for the Change Baseline report")
   public static final String CHANGE_BASELINE_REPORT_TABLE_VIEW_DEFAULT_DESC = "CHANGE_BASELINE_REPORT_TABLE_VIEW_DEFAULT_DESC";

   /**
    * ##############################################################################
    *
    * Table columns specific to change
    *
    * ##############################################################################
    **/
   @RBEntry("With suppliers")
   @RBComment("The label for the disposition column.")
   public static final String ONORDERDISPOSITION = "ONORDERDISPOSITION";

   @RBEntry("In warehouse")
   @RBComment("The label for the disposition column.")
   public static final String INVENTORYDISPOSITION = "INVENTORYDISPOSITION";

   @RBEntry("In production")
   @RBComment("The label for the disposition column.")
   public static final String FINISHEDDISPOSITION = "FINISHEDDISPOSITION";

   @RBEntry("With customer")
   @RBComment("The label for the disposition column.")
   public static final String WITHCUSTOMERDISPOSITION = "WITHCUSTOMERDISPOSITION";

   @RBEntry("In assembled parts")
   @RBComment("The label for the disposition column.")
   public static final String INASSEMBLEDPARTSDISPOSITION = "INASSEMBLEDPARTSDISPOSITION";

   @RBEntry("Commenti risoluzione")
   @RBComment("The label for the disposition comment column.")
   public static final String DISPOSITIONCOMMENTS = "DISPOSITIONCOMMENTS";

   @RBEntry("Quantità approvata")
   @RBComment("The label for Approved Quantity column.")
   public static final String APPROVEDQUANTITY = "APPROVEDQUANTITY";

   @RBEntry("Commenti")
   @RBComment("Label to be used in the Table Views")
   public static final String CHANGE_LINK_DESCRIPTION = "CHANGE_LINK_DESCRIPTION";

   @RBEntry("Parametri tabella")
   @RBComment("Label used in the table views. This column is a hidden parameter column.")
   public static final String CHANGE_TABLE_DATA_COLUMN = "CHANGE_TABLE_DATA_COLUMN";

   @RBEntry("Modifica non incorporata")
   @RBComment("Label used in the table views. This column is a hidden parameter column.")
   public static final String INCORP_HANGINGCHANGE_TABLE_DATA_COLUMN = "INCORP_HANGINGCHANGE_TABLE_DATA_COLUMN";

   @RBEntry("Oggetti che interessano")
   @RBComment("This column is used to filter the display of affected and resulting objects. This column is only displayed on the filter step of the table view wizard.")
   public static final String IMPACTING_OBJECTS_COLUMN = "IMPACTING_OBJECTS_COLUMN";

   @RBEntry("Relazione")
   @RBComment("This column is used to display the link relation ship of the affected or resulting objects.")
   public static final String RELATIONSHIP = "RELATIONSHIP";

   @RBEntry("Nome task")
   @RBComment("This column is to display the name of the change task on a affected or resulting link.")
   public static final String TASK_NAME_COLUMN = "TASK_NAME_COLUMN";

   @RBEntry("Numero task")
   @RBComment("This column is to display the number of the change task on a affected or resulting link.")
   public static final String TASK_NUMBER_COLUMN = "TASK_NUMBER_COLUMN";
   
   @RBEntry("Stato task")
   @RBComment("This column is to display the state of the change task on a affected or resulting link.")
   public static final String TASK_STATE_COLUMN = "TASK_STATE_COLUMN";  

   @RBEntry("Stato interessato")
   @RBComment("This column is to indicate if the Affected Status is shown for any item which is added as a resulting object or unincorporated change on a change task but does not have a corresponding equal or predecessor revision as an affected object.")
   public static final String AFFECTED_STATUS = "AFFECTED_STATUS";

   @RBEntry("Nessun oggetto interessato")
   @RBComment("A message is to indicate if the Affected Status is shown for any item which is added as a resulting object or unincorporated change on a change task but does not have a corresponding equal or predecessor revision as an affected object.")
   public static final String AFFECTED_STATUS_MSG = "AFFECTED_STATUS_MSG";

   @RBEntry("Stato di destinazione")
   @RBComment("This column is to indicate if the Change target state of the change task resulting objects.")
   public static final String CHANGE_TARGET_STATE = "CHANGE_TARGET_STATE";

   @RBEntry("Nuova versione")
   @RBComment("This column is to indicate if the new version of the successor object in the Change Baseline report table.")
   public static final String NEW_VERSION = "NEW_VERSION";

   @RBEntry("Autorizzazione pianificata")
   @RBComment("This column is to indicate if the planned authorization of the successor object in the Change Baseline report table.")
   public static final String PLANNED_AUTHORIZATION = "PLANNED_AUTHORIZATION";

   @RBEntry("Azione")
   @RBComment("This column is to indicate if the action of the successor object in the Change Baseline report table.")
   public static final String PLANNED_ACTION = "PLANNED_ACTION";
   
   @RBEntry("Target di rilascio")
   @RBComment("This column is to indicate the change management transition for the resulting object.")
   public static final String CHANGE_TARGET_TRANSITION = "CHANGE_TARGET_TRANSITION";
   
   @RBEntry("Assegnatari con task aperti")
   @RBComment("Set of columns intended to show the users that have open workflow tasks on a change task")
   public static final String CHANGE_TASK_ASSIGNEES = "CHANGE_TASK_ASSIGNEES";

   @RBEntry("Identificativo")
   @RBComment("This column is to display the attributes that uniquely identify an object.")
   public static final String IDENTITY_COLUMN_NAME = "IDENTITY_COLUMN_NAME";

   /**
    * ##############################################################################
    *
    * The action types for the Successor objects in the Change Baseline report
    *
    * ##############################################################################
    */

    @RBEntry("Aggiungi")
    @RBComment("Indicates that the object was added.")
    public static final String PLANNED_ACTION_TYPE_ADD = "PLANNED_ACTION_TYPE_ADD";

    @RBEntry("Elimina")
    @RBComment("Indicates that object was removed was removed.")
    public static final String PLANNED_ACTION_TYPE_REMOVE = "PLANNED_ACTION_TYPE_REMOVE";

    @RBEntry("Nuova revisione")
    @RBComment("Indicates that the successor object was revised.")
    public static final String PLANNED_ACTION_TYPE_REVISE = "PLANNED_ACTION_TYPE_REVISE";

   /**
    * ##############################################################################
    *
    * labels for impacting objects
    *
    * ##############################################################################
    **/

   @RBEntry("Oggetti interessati")
   @RBComment("This label is used to filter affected objects.")
   public static final String SHOW_AFFECTED_OBJECTS = "SHOW_AFFECTED_OBJECTS";

   @RBEntry("Oggetti risultanti")
   @RBComment("This label is used to filter resulting objects.")
   public static final String SHOW_RESULTING_OBJECTS = "SHOW_RESULTING_OBJECTS";

   @RBEntry("Oggetti interessati/risultanti")
   @RBComment("This label is used to filter affected and resulting objects.")
   public static final String SHOW_AFFECTED_RESULTING_OBJECTS = "SHOW_AFFECTED_RESULTING_OBJECTS";


   /**
    * ##############################################################################
    *
    * labels specific to annotation
    *
    * ##############################################################################
    **/
   @RBEntry("Oggetto interessato")
   @RBComment("Affected data label.")
   public static final String PRIVATE_CONSTANT_41 = "AFFECTED_DATA_LABEL";

   @RBEntry("Gruppi di annotazioni")
   @RBComment("The label for related affected data column.")
   public static final String ANNOTATION_SET_LABEL = "ANNOTATION_SET_LABEL";

   @RBEntry("Lista gruppi di annotazioni")
   @RBComment("The label for related affected data column.")
   public static final String PRIVATE_CONSTANT_42 = "ANNOTATION_SET_LIST_LABEL";

   /**
    * #######################################################
    *
    * Owning Change Object
    *
    * #######################################################
    **/
   @RBEntry("Notifica di modifica")
   @RBComment("Label for the Owning Change Notice")
   public static final String OWNING_CHANGE_NOTICE = "OWNING_CHANGE_NOTICE";

   @RBEntry("Nome notifica di modifica")
   @RBComment("Label for the Owning Change Notice Name")
   public static final String OWNING_CHANGE_NOTICE_NAME = "OWNING_CHANGE_NOTICE_NAME";

   @RBEntry("Richiesta di modifica")
   @RBComment("Label for the Owning Change Request")
   public static final String OWNING_CHANGE_REQUEST = "OWNING_CHANGE_REQUEST";

   @RBEntry("Nome richiesta di modifica")
   @RBComment("Label for the Owning Change Request Name")
   public static final String OWNING_CHANGE_REQUEST_NAME = "OWNING_CHANGE_REQUEST_NAME";

   @RBEntry("Proposta di modifica")
   @RBComment("Label for the Owning Change Proposal")
   public static final String OWNING_CHANGE_PROPOSAL = "OWNING_CHANGE_PROPOSAL";

   @RBEntry("Nome proposta di modifica")
   @RBComment("Label for the Owning Change Proposal Name")
   public static final String OWNING_CHANGE_PROPOSAL_NAME = "OWNING_CHANGE_PROPOSAL_NAME";

   @RBEntry("Investigazione di modifica")
   @RBComment("Label for the Owning Change Investigation")
   public static final String OWNING_CHANGE_INVESTIGATION = "OWNING_CHANGE_INVESTIGATION";

   @RBEntry("Nome investigazione di modifica")
   @RBComment("Label for the Owning Change Investigation Name")
   public static final String OWNING_CHANGE_INVESTIGATION_NAME = "OWNING_CHANGE_INVESTIGATION_NAME";

   @RBEntry("Oggetto di modifica")
   @RBComment("Label for the Owning Change Object")
   public static final String OWNING_CHANGE_OBJECT = "OWNING_CHANGE_OBJECT";

   @RBEntry("Nome oggetto di modifica")
   @RBComment("Label for the Owning Change Object Name")
   public static final String OWNING_CHANGE_OBJECT_NAME = "OWNING_CHANGE_OBJECT_NAME";

   @RBEntry("(Non disponibile)")
   @RBComment("Label for an object that is unavailable")
   public static final String UNAVAILABLE = "UNAVAILABLE";

   /**
    * #######################################################
    *
    * Implementation Plan Table
    *
    * #######################################################
    **/
   @RBEntry("Piano d'implementazione")
   @RBComment("The title of the Implementaiton Plan")
   public static final String IMPLEMENTATION_PLAN_TABLE = "IMPLEMENTATION_PLAN_TABLE";

   @RBEntry("Icona Modifica")
   @RBComment("Selectable Column name")
   public static final String IMPLEMENTATION_PLAN_TABLE_ICON_ACTIONS = "IMPLEMENTATION_PLAN_TABLE_ICON_ACTIONS";

   @RBEntry("Revisione")
   @RBComment("Revision Column name")
   public static final String IMPLEMENTATION_PLAN_TABLE_REVISION = "IMPLEMENTATION_PLAN_TABLE_REVISION";

   @RBEntry("Numero")
   @RBComment("Number Column name")
   public static final String IMPLEMENTATION_PLAN_TABLE_NUMBER = "IMPLEMENTATION_PLAN_TABLE_NUMBER";

   @RBEntry("Nome")
   @RBComment("Name Column name")
   public static final String IMPLEMENTATION_PLAN_TABLE_NAME = "IMPLEMENTATION_PLAN_TABLE_NAME";

   @RBEntry("Stato del ciclo di vita")
   @RBComment("State Column name")
   public static final String IMPLEMENTATION_PLAN_TABLE_STATE = "IMPLEMENTATION_PLAN_TABLE_STATE";

   @RBEntry("Assegnatario")
   @RBComment("Assignee Column name")
   public static final String IMPLEMENTATION_PLAN_TABLE_LAST_ROLE_ASSIGNEE = "IMPLEMENTATION_PLAN_TABLE_LAST_ROLE_ASSIGNEE";

   @RBEntry("Esaminatore")
   @RBComment("Reviewer Column name")
   public static final String IMPLEMENTATION_PLAN_TABLE_LAST_ROLE_REVIEWER = "IMPLEMENTATION_PLAN_TABLE_LAST_ROLE_REVIEWER";

   @RBEntry("Data consegna")
   @RBComment("Need DateColumn name")
   public static final String IMPLEMENTATION_PLAN_TABLE_NEED_DATE = "IMPLEMENTATION_PLAN_TABLE_NEED_DATE";

   @RBEntry("Sequenza")
   @RBComment("Change task sequence column name")
   public static final String IMPLEMENTATION_PLAN_TABLE_SEQUENCE = "IMPLEMENTATION_PLAN_TABLE_SEQUENCE";

   @RBEntry("Stato di implementazione")
   @RBComment("Label for Implementation Status column in the implementation plan table")
   public static final String IMPLEMENTATION_PLAN_TABLE_STATUS = "IMPLEMENTATION_PLAN_TABLE_STATUS";

   /**
    * Added to resolve compile issue
    **/
   @RBEntry("Piano d'implementazione")
   @RBComment("Change Notice table header.")
   public static final String CHANGE_NOTICE_TABLE_HEADER = "CHANGE_NOTICE_TABLE_HEADER";

   /**
    * ########################################################
    *
    * Revise Client Strings (ChangeItem Reissue Dialog)
    *
    * ########################################################
    **/
   @RBEntry("Impatto")
   @RBComment("The impact of the revise.  Either Modify of Proceed")
   public static final String REVISE_IMPACT = "REVISE_IMPACT";

   @RBEntry("Nuova revisione")
   @RBComment("The label for the new revision")
   public static final String NEW_REVISION = "NEW_REVISION";

   @RBEntry("Errore durante la revisione dell'oggetto in modifica")
   @RBComment("The message header (ATTENTION:) is already added.")
   public static final String REVISE_ERROR_HEADER = "REVISE_ERROR";

   @RBEntry("Oggetto di modifica")
   @RBComment("The label for the change item Identity")
   public static final String CHANGE_ITEM_IDENTITY = "CHANGE_ITEM_IDENTITY";

   /**
    * #########################################################
    *
    * Change Status Column Strings
    *
    * #########################################################
    **/
   @RBEntry("Stato modifica")
   @RBComment("The column header for the change status column.")
   public static final String CHANGE_STATUS_COLUMN = "statusFamily_Change";

   /**
    * #########################################################
    *
    * Specialized Attribute handling messages.
    *
    * #########################################################
    **/
   @RBEntry("Non è stato specificato un proprietario della soluzione temporanea valido.")
   @RBComment("The message when the user picked a user but this uid is not valid in the system.")
   public static final String VARIANCEOWNER_NOTFOUND = "VarianceOwner_NotFound";

   @RBEntry("Impossibile creare la soluzione temporanea.")
   public static final String VARIANCE_CREATE_CANNOTCREATE = "Variance_Create_CanNotCreate";

   @RBEntry("Cancella commenti risoluzione esistenti")
   @RBComment("Text display value for the check box to clear disposition comments.")
   public static final String CLEAR_DISPOSITION_COMMENTS = "CLEAR_DISPOSITION_COMMENTS";

   /**
    * #########################################################
    *
    * Propagation Message Strings
    *
    * #########################################################
    **/
   @RBEntry("Propaga informazioni dal report di problema")
   @RBComment("Option label to indicate propagation of meta-data, affected data, etc.from a Problem Report to a Change Request")
   public static final String PROPAGATE_DATA_FROM_PR_LABEL = "PropagateProblemReport_label";

   @RBEntry("Propaga informazioni dalla soluzione temporanea")
   @RBComment("Option label to indicate propagation of meta-data, affected data, etc.from a Variance to a Change Request")
   public static final String PROPAGATE_DATA_FROM_VARIANCE_LABEL = "PropagateVariance_label";

   @RBEntry("Propaga informazioni dalla richiesta di modifica")
   @RBComment("Option label to indicate propagation of meta-data, affected data, etc.from a Change Request to a Change Notice.")
   public static final String PROPAGATE_DATA_FROM_CR_LABEL = "PropagateChangeRequest_label";

   /**
    * #########################################################
    *
    * Wizard Error messages.
    *
    * #########################################################
    **/
   @RBEntry("Impossibile elaborare correttamente gli oggetti interessati.")
   public static final String AFFECTED_ITEMS_PROCESSING_ERROR = "AffectedItems_Processing_Error";

   @RBEntry("Impossibile elaborare gli oggetti interessati.")
   public static final String AFFECTED_ITEMS_PROCESSING_ERRORHEADER = "AffectedItems_Processing_ErrorHeader";

   @RBEntry("Impossibile elaborare correttamente i prodotti finali interessati.")
   public static final String AFFECTED_END_ITEMS_PROCESSING_ERROR = "AffectedEndItems_Processing_Error";

   @RBEntry("Impossibile elaborare i prodotti finali interessati.")
   public static final String AFFECTED_END_ITEMS_PROCESSING_ERRORHEADER = "AffectedEndItems_Processing_ErrorHeader";

   @RBEntry("Impossibile elaborare correttamente gli oggetti risultanti.")
   public static final String RESULTING_ITEMS_PROCESSING_ERROR = "ResultingItems_Processing_Error";

   @RBEntry("Impossibile elaborare gli oggetti risultanti.")
   public static final String RESULTING_ITEMS_PROCESSING_ERRORHEADER = "ResultingItems_Processing_ErrorHeader";

   @RBEntry("Si è verificato un errore durante la creazione delle nuove versioni variante. Contattare l'amministratore.")
   public static final String NEWONEOFFVERISON_ACTION_CANNOT_CREATE = "NewOneOffVersion_Action_CannotCreate";

   @RBEntry("<b>ATTENZIONE</b>: creazione delle nuove versioni variante non riuscita.")
   @RBComment("The <b> tags are added to bold the attention as per UI message design.  This is using a Ext dialog which supports Bold tags.")
   public static final String NEWONEOFFVERSION_ACTION_HEADER_MSG = "NewOneOffVersion_Action_HeaderMsg";

   @RBEntry("Numero di oggetti non validi: {0}\n\nPrimo messaggio rilevato:\n{1}")
   public static final String NEWONEOFFVERSION_ACTION_TOOMANYERRORS = "NewOneOffVersion_Action_TooManyErrors";

   @RBEntry("ATTENZIONE: impossibile impostare la risoluzione.")
   @RBComment("Header message for the diposition dialog.")
   public static final String SETDISPOSITION_ACTION_HEADER_MSG = "SetDisposition_Action_HeaderMsg";

   @RBEntry("Nessuno degli oggetti selezionati è utilizzabile per questa operazione.")
   @RBComment("Message when the action is launched and the objects are not applicable.")
   public static final String INVALIDOBJECTS = "InvalidObjects";

   @RBEntry("Soluzione proposta")
   public static final String PRIVATE_CONSTANT_43 = "CHANGE_PROPOSEDCHANGES";

   @RBEntry("Contattare l'amministratore.")
   public static final String CHANGEMANAGEMENT_PROCESSING_ERRORMSG = "ChangeManagement_Processing_ErrorMsg";

   @RBEntry("Impossibile creare il report di problema.")
   public static final String CREATEPROBLEMREPORT_PROCESSING_ERROR = "CreateProblemReport_Processing_Error";

   @RBEntry("Impossibile creare la soluzione temporanea.")
   public static final String CREATEVARIANCE_PROCESSING_ERROR = "CreateVariance_Processing_Error";

   @RBEntry("Impossibile creare la richiesta di modifica.")
   public static final String CREATECHANGEREQUEST_PROCESSING_ERROR = "CreateChangeRequest_Processing_Error";

   @RBEntry("Impossibile creare il modello di notifica di modifica.")
   public static final String CREATECHANGENOTICETEMPLATE_PROCESSING_ERROR = "CreateChangeNoticeTemplate_Processing_Error";
   
   @RBEntry("Impossibile creare il modello di task di modifica.")
   public static final String CREATECHANGETASKTEMPLATE_PROCESSING_ERROR = "CreateChangeTaskTemplate_Processing_Error";
   
   @RBEntry("Impossibile creare la notifica di modifica.")
   public static final String CREATECHANGENOTICE_PROCESSING_ERROR = "CreateChangeNotice_Processing_Error";

   @RBEntry("Errore non irreversibile durante la creazione della notifica di modifica.")
   public static final String CreateChangeNotice_ImpactMatrix_ErrorHeader = "CreateChangeNotice_ImpactMatrix_ErrorHeader";

   @RBEntry("Impossibile associare la matrice di impatto modifica con la notifica di modifica. Contattare l'amministratore per informazioni.")
   public static final String CreateChangeNotice_ImpactMatrix_Error = "CreateChangeNotice_ImpactMatrix_Error";

   @RBEntry("Impossibile creare il task di modifica.")
   public static final String CREATECHANGETASK_PROCESSING_ERROR = "CreateChangeTask_Processing_Error";

   @RBEntry("Impossibile creare la proposta di modifica.")
   public static final String CREATECHANGEPROPOSAL_PROCESSING_ERROR = "CreateChangeProposal_Processing_Error";

   @RBEntry("Impossibile modificare il report di problema.")
   public static final String EDITPROBLEMREPORT_PROCESSING_ERROR = "EditProblemReport_Processing_Error";

   @RBEntry("Impossibile modificare la soluzione temporanea.")
   public static final String EDITVARIANCE_PROCESSING_ERROR = "EditVariance_Processing_Error";

   @RBEntry("Impossibile modificare la richiesta di modifica.")
   public static final String EDITCHANGEREQUEST_PROCESSING_ERROR = "EditChangeRequest_Processing_Error";

   @RBEntry("Impossibile modificare la notifica di modifica.")
   public static final String EDITCHANGENOTICE_PROCESSING_ERROR = "EditChangeNotice_Processing_Error";
   
   @RBEntry("Impossibile modificare il modello di notifica di modifica.")
   public static final String EDITCHANGENOTICETEMPLATE_PROCESSING_ERROR = "EditChangeNoticeTemplate_Processing_Error";

   @RBEntry("Impossibile modificare il task di modifica.")
   public static final String EDITCHANGETASK_PROCESSING_ERROR = "EditChangeTask_Processing_Error";
   
   @RBEntry("Impossibile modificare il modello di task di modifica.")
   public static final String EDITCHANGETASKTEMPLATE_PROCESSING_ERROR = "EditChangeTaskTemplate_Processing_Error";

   @RBEntry("Impossibile modificare la proposta di modifica.")
   public static final String EDITCHANGEPROPOSAL_PROCESSING_ERROR = "EditChangeProposal_Processing_Error";

   @RBEntry("Impossibile eliminare il Task di modifica.")
   public static final String DELETECHANGETASK_PROCESSING_ERROR = "DeleteChangeTask_Processing_Error";

   @RBEntry("Impossibile creare un piano di modifica.")
   public static final String CREATE_CHANGE_PLAN_ERROR = "CREATE_CHANGE_PLAN_ERROR";

   @RBEntry("ATTENZIONE: informazioni necessarie mancanti.\n\nÈ necessario almeno un task di modifica. Creare un nuovo task di modifica per continuare.")
   public static final String IMPLEMENTATION_TABLE_NO_TASKS = "Implementation_Table_No_Tasks";

   @RBEntry("ATTENZIONE: si è verificato un errore.\n\nImpossibile trovare la tabella del piano d'implementazione")
   public static final String UNABLE_TO_FIND_IMPL_TABLE = "Unable_To_Find_Impl_Table";

   @RBEntry("ATTENZIONE: richiesta di modifica obbligatoria.\n\nÈ necessario che almeno una richiesta di modifica sia associata alla notifica di modifica.")
   @RBComment("Message displayed when a Change Notice needs to have associated Change Request but it is missing")
   public static final String CHANGENOTICE_VALIDATE_ASSOCIATED_CR = "CHANGENOTICE_VALIDATE_ASSOCIATED_CR";

   @RBEntry("Attenzione: azione non disponibile\n\nUna nuova notifica di modifica richiede un task di modifica.\nL'utente non dispone dei permessi necessari a crearne uno.")
   @RBComment("Error message for the Create Change Notice wizard when the user does not have access to create any Change Task types.")
   public static final String CREATECHANGENOTICE_NO_TASK_TYPES = "CreateChangeNotice_No_Task_Types";

   @RBEntry("Non esiste una definizione per {0} nel sistema di reporting di terze parti.")
   public static final String THIRDPARTYREPORTING_NODEFEXISTS_ERROR = "ThirdPartyReporting_NoDefExists_Error";

   @RBEntry("Il report {0} non esiste")
   public static final String REPORT_NOTEXISTS_ERROR = "Report_NotExists_Error";

   @RBEntry("Non esiste un report per il tipo di oggetto: {0}")
   public static final String REPORT_NOTSUPPORTED_ERROR = "Report_NotSupported_Error";

   @RBEntry("Relazione non valida per {0}.")
   @RBComment("Message for validationg the association of an object for an AssociationConstrainable link when peforming a client action.")
   public static final String INVALID_ROLE_B_TYPE = "INVALID_ROLE_B_TYPE";

   @RBEntry("ATTENZIONE: informazioni necessarie mancanti.\n\nIl numero è obbligatorio nel task di modifica. Modificare il task di modifica perché includa un numero.")
   public static final String CHANGE_TASK_NUMBER_REQUIRED = "CHANGE_TASK_NUMBER_REQUIRED";

   @RBEntry("ATTENZIONE: informazioni necessarie mancanti.\n\nIl numero è obbligatorio nel task di modifica di default. Modificare il task di modifica di default perché includa un numero.")
   public static final String DEFAULT_CHANGE_TASK_NUMBER_REQUIRED = "DEFAULT_CHANGE_TASK_NUMBER_REQUIRED";

   @RBEntry("L'utente non dispone del permesso per creare il contesto selezionato.")
   @RBComment("Error message for the change create wizard context step.")
   public static final String NO_CREATE_FOR_CONTEXT = "NO_CREATE_FOR_CONTEXT";
   
   @RBEntry("Attenzione: impossibile creare la notifica di modifica.\n\nL'utente non dispone del permesso per creare uno o più tipi di task di modifica nel modello di notifica di modifica selezionato.")
   @RBComment("Error message for the Create Change Notice wizard when the user does not have access to create the Change Task types in the selected change notice template.")
   public static final String CREATE_CHANGE_NOTICE_FROM_TEMPLATE_NO_TASK_TYPES = "CREATE_CHANGE_NOTICE_FROM_TEMPLATE_NO_TASK_TYPES";

   /**
    * ##############################################################################
    *
    * Change Management specific workflow strings
    *
    * ##############################################################################
    **/
   @RBEntry("Crea automaticamente notifica di modifica")
   @RBComment("Label for the Automate the fast-track checkbox")
   public static final String AUTOMATE_FASTTRACK = "AUTOMATE_FASTTRACK";

   @RBEntry("ATTENZIONE: campi obbligatori non completati.\n\nI campi Assegnatario ed Esaminatore cono obbligatori. Utilizzare il pulsante \"Trova...\" per individuare un utente valido.")
   public static final String CHANGETASK_VALIDATE_USER = "CHANGETASK_VALIDATE_USER";

   @RBEntry("CONFERMA: eliminazione task di modifica \n\nEliminare il task di modifica selezionato?")
   @RBComment("Message displayed to ask user whether they are sure they wish to delete change tasks")
   public static final String CONFIRM_DELETE_CHANGE_TASK = "CONFIRM_DELETE_CHANGE_TASK";

   @RBEntry("ATTENZIONE: impossibile proseguire nella modifica.\n\nL'oggetto è stato aggiornato da un altro utente ed è quindi necessario aggiornare la procedura guidata. Le modifiche apportate in questa sessione andranno perdute.")
   @RBComment("Message displayed when the system detects a change is made.")
   public static final String CONFIRM_UPDATE_CHANGEITEM = "CONFIRM_UPDATE_CHANGEITEM";

   @RBEntry("Impossibile rilasciare la notifica di modifica in quanto gli oggetti risultanti che seguono sono sottoposti a Check-Out:")
   @RBComment("Special Instructions that appear in the \"Resolve Change Notice Conflicts\" Change Notice workflow task.  It is followed by a list of objects that are checked out.")
   public static final String PRERELEASE_VALIDATION_MSG = "PRERELEASE_VALIDATION_MSG";
   
   @RBEntry("Impossibile rilasciare la notifica di modifica a causa di errori nelle seguenti regole aziendali:")
   @RBComment("Special Instructions that appear in the \"Resolve Change Notice Conflicts\" Change Notice workflow task.  It is followed by a list of business rules that failed.")
   public static final String BUSINESS_RULES_PRERELEASE_VALIDATION_MSG = "BUSINESS_RULES_PRERELEASE_VALIDATION_MSG";

   @RBEntry("CONFERMA: visualizzare un'altra pagina della tabella? I dati immessi nella pagina corrente verranno perduti.")
   @RBComment("Message displayed to ask user whether they are sure they wish to go to next page in a change table")
   public static final String CONFIRM_PAGING_CHANGE_TABLES = "CONFIRM_PAGING_CHANGE_TABLES";

   @RBEntry("Impossibile rilasciare la notifica di modifica in quanto i task di modifica che seguono non sono pronti per essere implementati:")
   @RBComment("Special Instructions that appear in the \"Assignee or Reviewer Conflicts\" Change Notice workflow task.  It is followed by a list of change tasks that are not ready for implementation.")
   public static final String IMPLEMENTATION_VALIDATION_MSG = "IMPLEMENTATION_VALIDATION_MSG";

   @RBEntry("Raccolta non riuscita")
   @RBComment("Message for when none of the objects collected are valid for the table.")
   public static final String COLLECTED_FAILED = "COLLECTED_FAILED";

   @RBEntry("Nessuno degli oggetti raccolti può essere aggiunto in questa posizione.")
   @RBComment("Detailed message for when none of the objects collected are valid for the table.")
   public static final String COLLECTED_FAILED_MSG = "COLLECTED_FAILED_MSG";

   @RBEntry("Raccolta completata parzialmente")
   @RBComment("Message for when some of the objects collected are not valid for the table.")
   public static final String COLLECTED_PARTIALLY_FAILED = "COLLECTED_PARTIALLY_FAILED";

   @RBEntry("Alcuni degli oggetti raccolti non possono essere aggiunti in questa posizione:")
   @RBComment("Detailed message for when some of the objects collected are not valid for the table.")
   public static final String COLLECTED_PARTIALLY_FAILED_MSG = "COLLECTED_PARTIALLY_FAILED_MSG";

   @RBEntry("Aggiunta degli oggetti revisionati non riuscita")
   @RBComment("Message for when the revise is successful but none of the objects revised are valid for the table.")
   public static final String REVISE_FAILED = "REVISE_FAILED";

   @RBEntry("Gli oggetti sono stati revisionati, ma non possono essere aggiunti in questa posizione.")
   @RBComment("Detailed message for when the revise is successful but none of the objects revised are valid for the table.")
   public static final String REVISE_FAILED_MSG = "REVISE_FAILED_MSG";

   @RBEntry("Aggiunta dell'oggetto revisionato completata parzialmente")
   @RBComment("Message for when the revise is successful but some of the objects revised are invalid for the table.")
   public static final String REVISE_PARTIALLY_FAILED = "REVISE_PARTIALLY_FAILED";

   @RBEntry("Gli oggetti sono stati revisionati, ma alcuni non possono essere aggiunti in questa posizione:")
   @RBComment("Detailed message for when the revise is successful but some of the objects revised are invalid for the table.")
   public static final String REVISE_PARTIALLY_FAILED_MSG = "REVISE_PARTIALLY_FAILED_MSG";
   
   @RBEntry("Impossibile trovare target di rilascio comuni")
   @RBComment("Message for when no common release targets are found when launching the release target table action.")
   public static final String NO_COMMON_RELEASE_TARGETS = "NO_COMMON_RELEASE_TARGETS";


   /**
    * ##############################################################################
    *
    * Submit Now / Submit Later messages
    *
    * ##############################################################################
    **/
   @RBEntry("<br><b>CONFERMA</b>: inviare l'oggetto in modifica al sistema?<br><br>Fare clic su \"Invia ora\" per inviare l'oggetto in modifica.<br>Fare clic su \"Invia in seguito\" se si desidera inviarlo successivamente.")
   @RBComment("The string displayed to a user when they attempt to submit a change object where Submit Now is enabled.  The <br> and <b> tags are needed because this text is dumped directly into HTML content at runtime.  There are three distinct sentences.  the first is the header message.  The remaining two are the instructions.")
   public static final String SUBMIT_NOW_MESSAGE = "SUBMIT_NOW_MESSAGE";

   @RBEntry("Invia ora")
   @RBComment("Label for the JS Dojo button.  Equivalent of the \"Ok\" on a confirmation dialog.  See SUBMIT_NOW_MESSAGE above for context text.")
   public static final String SUBMIT_NOW_BUTTON = "SUBMIT_NOW_BUTTON";

   @RBEntry("Invia in seguito")
   @RBComment("Label for the JS Dojo button.  Equivalent of the \"Cancel\" on a confirmation dialog.  See SUBMIT_NOW_MESSAGE above for context text.")
   public static final String SUBMIT_LATER_BUTTON = "SUBMIT_LATER_BUTTON";

   /**
    * ##############################################################################
    *
    * Change object attributes to support proper localization in client
    *
    * ##############################################################################
    **/
   @RBEntry("Complessità")
   public static final String PRIVATE_CONSTANT_44 = "WTChangeOrder2.theChangeNoticeComplexity";

   @RBEntry("Categoria")
   public static final String THE_VARIANCE_CATEGORY = "WTVariance.theVarianceCategory";

   @RBEntry("Oggetti co<U class='mnemonic'>r</U>relati")
   @RBComment("Used for the text on the Related Objects third level nav menu.  The <U class=mnemonic> </U> tag should be put around the character that is the access key.")
   public static final String PRIVATE_CONSTANT_45 = "object.relatedDirItems.description";

   @RBEntry("r")
   @RBPseudo(false)
   @RBComment("Mnemonic for the Related Objects third level nav menu. This should be a character that matches the character surrounded by the <U class=mnemonic> </U> tag in the value line above.")
   public static final String PRIVATE_CONSTANT_46 = "object.relatedDirItems.hotkey";

   @RBEntry("Di<U class='mnemonic'>r</U>ettive correlate")
   @RBComment("Used for the text on the Related Objects third level nav menu.  The <U class=mnemonic> </U> tag should be put around the character that is the access key.")
   public static final String PRIVATE_CONSTANT_49 = "object.relatedPartItems.description";

   @RBEntry("r")
   @RBPseudo(false)
   @RBComment("Mnemonic for the Related Objects third level nav menu. This should be a character that matches the character surrounded by the <U class=mnemonic> </U> tag in the value line above.")
   public static final String PRIVATE_CONSTANT_50 = "object.relatedPartItems.hotkey";

   @RBEntry("Riesame non necessario")
   @RBComment("Label for the Change Task no review required check box.")
   public static final String NO_REVIEW_REQUIRED = "NO_REVIEW_REQUIRED";

   @RBEntry("Non necessario")
   @RBComment("Label for the Change Task reviewer role when no review is required")
   public static final String ROLE_NOT_REQUIRED = "ROLE_NOT_REQUIRED";

   /**
    * ##############################################################################
    * Location field for Change Directive, Change Action
    * ##############################################################################
    **/
   @RBEntry("Posizione")
   @RBComment("Label for the Location")
   public static final String LOCATION_LABEL = "LOCATION";

   @RBEntry("Direttiva di modifica")
   @RBComment("Label for the Change Directive")
   public static final String CHANGE_DIRECTIVE = "CHANGE_DIRECTIVE";

   @RBEntry("Configuration item")
   @RBComment("Label for the Configuration Item")
   public static final String CONFIGURATION_ITEM = "CONFIGURATION_ITEM";

   @RBEntry("Direttive di modifica che interessano")
   @RBComment("The table title for the Change Directives")
   public static final String CHANGE_DIRECTIVES_TABLE = "CHANGE_DIRECTIVES_TABLE";

   @RBEntry("Azioni di modifica correlate")
   @RBComment("Label for the related Change Actions")
   public static final String RELATEDCHANGEACTIONS = "RELATEDCHANGEACTIONS";

   @RBEntry("Effettività")
   @RBComment("The column name for Effectivity")
   public static final String EFFECTIVITY = "EFFECTIVITY";

   @RBEntry("Stato calcolo")
   @RBComment("The column name for Calculation Status")
   public static final String CALCULATIONSTATUS = "CALCULATIONSTATUS";

   @RBEntry("Default")
   @RBComment("change directive info page default table view name")
   public static final String CHANGE_DIRECTIVES_VIEW_DEFAULT_NAME = "CHANGE_DIRECTIVES_VIEW_DEFAULT_NAME";

   @RBEntry("Nome vista tabella di default")
   @RBComment(" change directive info page description default table view name")
   public static final String CHANGE_DIRECTIVES_VIEW_DEFAULT_DESC = "CHANGE_DIRECTIVES_VIEW_DEFAULT_DESC";

   @RBEntry("Informazioni")
   @RBComment(" change directive info page description default table view name")
   public static final String INFO_PAGE = "CHANGE_DIRECTIVES_VIEW_INFO_PAGE";


   @RBEntry("Programmato")
   @RBComment(" status indicating that the task is scheduled not started")
   public static final String SCHEDULED = "SCHEDULED";

   @RBEntry("In corso")
   @RBComment(" status indicating that the task is in progress")
   public static final String INPROGRESS = "INPROGRESS";

   @RBEntry("Completato")
   @RBComment(" status indicating that the task has been completed")
   public static final String COMPLETED = "COMPLETED";

   @RBEntry("In ritardo")
   @RBComment(" status indicating that the task is over due")
   public static final String OVERDUE = "OVERDUE";

   @RBEntry("Categoria di conferma")
   public static final String CONFIRMATION_CATEGORY = "CONFIRMATION_CATEGORY";

   @RBEntry("Verifica di conferma")
   public static final String CONFIRMATION_AUDIT = "CONFIRMATION_AUDIT";
   
   @RBEntry("-- Selezionare un modello --")
   public static final String SELECT_TEMPLATE = "SELECT_TEMPLATE";
   
   @RBEntry("-- Nessun modello disponibile --")
   public static final String NO_TEMPLATES_AVAILABLE = "NO_TEMPLATES_AVAILABLE";
   
   @RBEntry("Modello")
   public static final String CHANGE_TEMPLATE_PICKER_LABEL = "CHANGE_TEMPLATE_PICKER_LABEL";

  @RBEntry("Data consegna")
  public static final String NEED_DATE = "NEED_DATE";
  
  @RBEntry("Tipo")
  public static final String TYPE = "TYPE";
  

  /**
   * ##############################################################################
   * Labels for Available attributes to avoid labels showing as duplicates
   * ##############################################################################
   **/
  @RBEntry("Complessità notifica di modifica")
  public static final String CHANGE_ORDER_COMPLEXITY = "CHANGE_ORDER_COMPLEXITY";
  
  @RBEntry("Priorità suggerimento di modifica")
  public static final String ISSUE_PRIORITY = "ISSUE_PRIORITY";
  
  @RBEntry("Categoria suggerimento di modifica")
  public static final String ISSUE_CATEGORY = "ISSUE_CATEGORY";
  
  @RBEntry("Categoria")
  public static final String ISSUE_THECATEGORY = "ISSUE_THECATEGORY";
  
  @RBEntry("Priorità richiesta di modifica")
  public static final String REQUEST_PRIORITY = "REQUEST_PRIORITY";
  
  @RBEntry("Categoria richiesta di modifica")
  public static final String REQUEST_CATEGORY = "REQUEST_CATEGORY";
  
  @RBEntry("Categoria")
  public static final String REQUEST_THECATEGORY = "REQUEST_THECATEGORY"; 
  
  @RBEntry("Complessità richiesta di modifica")
  public static final String REQUEST_COMPLEXITY = "REQUEST_COMPLEXITY";

  @RBEntry("Proprietario soluzione temporanea")
  public static final String VARIANCE_OWNER = "VARIANCE_OWNER";
  
  @RBEntry("Categoria soluzione temporanea")
  public static final String VARIANCE_CATEGORY = "VARIANCE_CATEGORY";

  /*Business rules resource bundle entry START*/
  @RBEntry("Convalida pre-release delle modifiche")
  @RBComment("Name of the rule set that will be used to display to the user when the workflow fails the check before releasing the change object.")
  public static final String CHANGE_PRE_RELEASE_RULESET_NAME = "CHANGE_PRE_RELEASE_RULESET_NAME";

  @RBEntry("Insieme di regole aziendali utilizzato prima del rilascio degli oggetti all'interno del processo di modifica")
  @RBComment("Description for the CHANGE PRE RELEASE RULESET.")
  public static final String CHANGE_PRE_RELEASE_RULESET_DESC = "CHANGE_PRE_RELEASE_RULESET_DESC";

  @RBEntry("Regola Check-Out")
  @RBComment("Rule Validator to check no objects are checked out.")
  public static final String CHECK_OUT_VALIDATOR_RULE_NAME = "CHECK_OUT_VALIDATOR_RULE_NAME";

  @RBEntry("La regola determina la presenza di oggetti sottoposti a Check-Out. Se vengono trovati oggetti sottoposti a Check-Out, l'esito della regola sarà negativo. In caso contrario, l'esito sarà positivo.")
  @RBComment("Description for CHECK_OUT_VALIDATOR_RULE_NAME")
  public static final String CHECK_OUT_VALIDATOR_RULE_DESC = "CHECK_OUT_VALIDATOR_RULE_DESC";
  
  @RBEntry("Regola target di rilascio")
  public static final String RELEASE_TARGET_RULE_NAME = "RELEASE_TARGET_RULE_NAME";

  @RBEntry("La regola del target di rilascio consente di verificare che il target di rilascio specificato sia valido per lo stato corrente degli oggetti risultanti. La regola è inoltre valida quando non viene specificato un target di rilascio per l'oggetto risultante e il target di rilascio delle modifiche è valido per lo stato corrente dell'oggetto risultante")
  @RBComment("Description for Release Target Rule")
  public static final String RELEASE_TARGET_RULE_DESC = "RELEASE_TARGET_RULE_DESC";
  /*Business rules resource bundle entry END*/
  
  /* Workflow task tab names */
  @RBEntry("Oggetti risultanti")
  @RBComment("Workflow task tab name for Change Task resulting objects")
  public static final String WFTASK_RESULTING_OBJECTS_TAB_NAME = "WFTASK_RESULTING_OBJECTS_TAB_NAME";
  
  @RBEntry("Impatti")
  @RBComment("Workflow task tab name for Change Request, Change Notice, Problem Report or Variance impacts")
  public static final String WFTASK_IMPACTS_TAB_NAME = "WFTASK_IMPACTS_TAB_NAME";

}
