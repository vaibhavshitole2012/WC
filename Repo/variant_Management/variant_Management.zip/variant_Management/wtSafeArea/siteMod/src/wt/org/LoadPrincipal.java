/* bcwti
 *
 * Copyright (c) 2010 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */
package wt.org;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Locale;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.naming.NameAlreadyBoundException;
import javax.naming.NameNotFoundException;
import javax.naming.directory.AttributeInUseException;

import org.apache.log4j.Logger;

import com.infoengine.SAK.Task;
import com.infoengine.object.factory.Group;
import com.infoengine.util.IEException;

import wt.admin.AdminDomainRef;
import wt.admin.AdministrativeDomain;
import wt.admin.DomainAdministeredHelper;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.federation.FederationUtilities;
import wt.federation.PrincipalManager.DirContext;
import wt.inf.container.ContainerIterator;
import wt.inf.container.DirectoryHelperSvr;
import wt.inf.container.ExchangeContainer;
import wt.inf.container.OrgContainer;
import wt.inf.container.PrincipalSpec;
import wt.inf.container.WTContainerHelper;
import wt.inf.container.WTContainerRef;
import wt.inf.container.WTContainerServerHelper;
import wt.load.LoadServerHelper;
import wt.log4j.LogR;
import wt.query.QueryException;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.WTProperties;
import wt.util.WTPropertyVetoException;

/**
 * Following are the use cases that this class currently performs
 * <li>
 * Creates a WTOrganization object in a Windchill repository. It does not create
 * organization container. So the organization objects created here will not be listed in Site|Organization
 * list.
 * </li>
 *
 * <li>
 * Updates all the deleted users currently existing in the Windchill database and adds values for the five full name fields (prefix, first, middle, last, suffix).
 * </li>
 *
 * This class could be invoked using the command
 *    WC_COMMAND> Windchill wt.load.LoadFromFile -d <datafileName>
 **/

public class LoadPrincipal {
    /**
     * Default constructor.
     */
    public LoadPrincipal() {
    }

    private static boolean DIRVERBOSE = false;
    private static String defaultAdapter = null;
    private static String userNameAdapter = null;
    private static String groupNameAdapter = null;
    private static String userSearchBase = null;
    private static String defaultDirectoryUser;
    private static final Logger logger = LogR.getLogger(LoadPrincipal.class.getName());
    private static final String ADMIN_FULLNAME = "Site, Administrator";
    private static final String ADMIN_LAST = "Site";

    /**
     * Creates WTUser object with properties listed in the data file in the specific format. Following is the format that needs to be specified in the input data file.
     * <NmLoader>
     * <csvUser handler="wt.load.LoadUser.createUser">
     * <csvuser></csvuser>
     * <csvnewUser>testuser1</csvnewUser>
     * <csvwebServerID>testuser1</csvwebServerID>
     * <csvfullName>testuser1.</csvfullName>
     * <csvLast>Last</csvLast>
     * <csvLocale>en_GB</csvLocale>
     * <csvEmail>testuser1@email.com</csvEmail>
     * <csvDescription>Test for loading of user's into the database</csvDescription>
     * <csvTitle></csvTitle>
     * <csvOrganization>org1</csvOrganization>
     * <csvStreet1></csvStreet1>
     * <csvStreet2></csvStreet2>
     * <csvCity></csvCity>
     * <csvState></csvState>
     * <csvCountry></csvCountry>
     * <csvZipCode></csvZipCode>
     * <csvpassword>testuser1</csvpassword>
     * </csvUser>
     * </NmLoader>
     *
     * To facilitate this functionality of adding users into non-default LDAP, we need to add an additional attribute element to the data file.
     * This element will however be optional. The element tag is <csvDirectoryService>. In this element tag we will need to provide the service name
     * for the non-default adapter (ex - com.ptc.ptcnet.abc03d.nonDefaultAdapter).
     *
     * @param nv Name/value pairs of meta data to set on the user.
     * @param cmd_line command line argument that can be substituted into the load data.
     * @param return_objects Object(s) created by this method used by
     * <code>wt.load.StandardLoadService</code> for user feedback messages.
     *
     * <BR><BR><B>Supported API: </B>true
     **/
    public static boolean createUser (Hashtable nv, Hashtable cmd_line, Vector<String> return_objects) {
        try {
            String addr = null;
            Vector values = null;
            defaultAdapter=null;

            boolean flag = true;
            HashMap<String, String> fullnameFields = new HashMap<String, String>();
            String user = LoadServerHelper.getValue("user", nv, cmd_line, LoadServerHelper.NOT_REQUIRED);
            String newUser = LoadServerHelper.getValue("newUser", nv, cmd_line, LoadServerHelper.REQUIRED);
            if ( newUser == null ) flag = false;

            String webServerID = LoadServerHelper.getValue("webServerID", nv, cmd_line, LoadServerHelper.REQUIRED);
            if ( webServerID == null ) flag = false;

            String fullName = LoadServerHelper.getValue("fullName", nv, cmd_line, LoadServerHelper.REQUIRED);
            if ( fullName == null ) flag = false;

            String last = LoadServerHelper.getValue("Last",nv,cmd_line,LoadServerHelper.NOT_REQUIRED);

            String first = LoadServerHelper.getValue("First", nv, cmd_line, LoadServerHelper.NOT_REQUIRED);
            String middle = LoadServerHelper.getValue("Middle", nv, cmd_line, LoadServerHelper.NOT_REQUIRED);
            String suffix = LoadServerHelper.getValue("Suffix", nv, cmd_line, LoadServerHelper.NOT_REQUIRED);
            String prefix = LoadServerHelper.getValue("Prefix", nv, cmd_line, LoadServerHelper.NOT_REQUIRED);


            // forming last if not provided from full name
            if (fullName != null && last == null){
                last = OrganizationServicesServerHelper.getSurNameFromFullName(fullName);
            }
            if( last == null){
                flag = false;
            }

            if ( !flag ) return false;

            String locale = LoadServerHelper.getValue("Locale", nv, cmd_line, LoadServerHelper.NOT_REQUIRED);
            String email = LoadServerHelper.getValue("Email", nv, cmd_line, LoadServerHelper.NOT_REQUIRED);
            String description = LoadServerHelper.getValue("Description", nv, cmd_line, LoadServerHelper.NOT_REQUIRED);
            String title = LoadServerHelper.getValue("Title", nv, cmd_line, LoadServerHelper.NOT_REQUIRED);
            String organization = LoadServerHelper.getValue("Organization", nv, cmd_line, LoadServerHelper.NOT_REQUIRED);
            String street1 = LoadServerHelper.getValue("Street1", nv, cmd_line, LoadServerHelper.NOT_REQUIRED);
            String street2 = LoadServerHelper.getValue("Street2", nv, cmd_line, LoadServerHelper.NOT_REQUIRED);
            String city = LoadServerHelper.getValue("City", nv, cmd_line, LoadServerHelper.NOT_REQUIRED);
            String state = LoadServerHelper.getValue("State", nv, cmd_line, LoadServerHelper.NOT_REQUIRED);
            String zipcode = LoadServerHelper.getValue("ZipCode", nv, cmd_line, LoadServerHelper.NOT_REQUIRED);
            String country = LoadServerHelper.getValue("Country", nv, cmd_line, LoadServerHelper.NOT_REQUIRED);
            String password = LoadServerHelper.getValue("password", nv, cmd_line, LoadServerHelper.NOT_REQUIRED);
            if (password != null) OrganizationServicesHelper.validateUserPasswordCharSet(password);
            /**
             * Additional attribute 'DirectoryService' has been added to facilitate adding of users into non-default LDAP.
             */
            String directoryService = LoadServerHelper.getValue("DirectoryService", nv, cmd_line, LoadServerHelper.NOT_REQUIRED);


            /**
             * Additional attribute to specify if any manual changes made to the full name or sur name attributes for this user in LDAP (after the initial creation) should be automatically
             * synchronized in the Windchill database. If the value is set to true, then synchronization will automatically happen. If value is set to false then Site Administrator needs to
             * manually update the user fields via Principal Administrator Update UI.
             */
            String allowLdapSync = LoadServerHelper.getValue("AllowLdapSync",nv,cmd_line,LoadServerHelper.NOT_REQUIRED);

            fullnameFields.put(WTUser.LAST,last);
            if( allowLdapSync != null){
                fullnameFields.put(WTUser.ALLOW_LDAPSYNCHRONIZATION,allowLdapSync);
            }

            LoadServerHelper.changePrincipal (user);
            values = new Vector ();
            String language = getPreferredLanguageFromLocale(locale);
            dirInit ();
            /**
             * Code change made to facilitate adding of users into non-default LDAP.
             */
            if(directoryService !=null){
                defaultAdapter=directoryService;
                userSearchBase =
                        DirContext.getJNDIAdapterSearchBase (defaultAdapter);
            }

            values.addElement(DirContext.getMapping (defaultAdapter, "user.preferredLanguage") + '=' + language);

            if (email != null)
                values.addElement(DirContext.getMapping (defaultAdapter, "user.mail") + '=' + email);

            if (title != null)
                values.addElement(DirContext.getMapping (defaultAdapter, "user.title") + '=' + title);

            if (description != null)
                values.addElement(DirContext.getMapping (defaultAdapter, "user.description") + '=' + description);

            if (organization != null) {

                String objectClass = DirContext.getMapping(defaultAdapter, "user.objectClass", "inetOrgPerson");
                String attr = "user.o";
                if ( !objectClass.equalsIgnoreCase ("inetOrgPerson") )
                    attr = "user.ou";

                values.addElement (DirContext.getMapping (defaultAdapter, attr) + '=' + organization);
            }

            if (street1 != null) addr = addAddrPart (addr, street1);
            if (street2 != null) addr = addAddrPart (addr, street2);
            if (city != null) addr = addAddrPart (addr, city);
            if (state != null) addr = addAddrPart (addr, state);
            if (zipcode != null) addr = addAddrPart (addr, zipcode);
            if (country != null) addr = addAddrPart (addr, country);

            if (addr != null)
                values.addElement(DirContext.getMapping (defaultAdapter, "user.postalAddress") + '=' + addr);

            if (password != null)
                values.addElement(DirContext.getMapping (defaultAdapter, "user.userPassword") + '=' + password);
            boolean created = false;

            created = loadUser (newUser, fullName, values, fullnameFields );

            String msg = "User = " + fullName;
            return_objects.addElement (msg);

            if(created)
                logger.info ("Created user <" + fullName + "> \n");
            else
                logger.info ("User <" + fullName + "> has not been created \n");

            // this block is to throw  a warning if load files with pre x24 format are used, and calculate last name if not provided.
            if(first != null || middle != null || suffix != null || prefix != null){
                LoadServerHelper.printMessage("Warning!The load file used to create the user is in a deprecated format. Starting at Windchill 10.2, only the following required fields will be stored in the database for the new user: FullName, Last. The following optional fields from previous releases will be ignored: First, Middle, Suffix, Prefix. To avoid this message update the load file to use the definition specified in the StandardX24.dtd file.");
            }
            return true;
        }
        catch ( Exception e ) {
            LoadServerHelper.printMessage (e.getLocalizedMessage ());
            e.printStackTrace ();
            return false;
        }
    }

    /**
     * Creates WTGroup object with properties listed in the data file in the specific format. Following is the format that needs to be specified in the input data file.
     *
     * <NmLoader>
     * <csvGroup handler="wt.org.LoadPrincipal.createGroup">
     * <csvuser></csvuser>
     * <csvgroupName>grp1</csvgroupName>
     * <csvdescription>Test Group1</csvdescription>
     * </csvGroup>
     * </NmLoader>
     * To facilitate this functionality of adding groups into non-default LDAP, we need to add an additional attribute element to the data file.
     * This element will however be optional. The element tag is <csvDirectoryService>. In this element tag we will need to provide the service name
     * for the non-default adapter (ex - com.ptc.ptcnet.abc03d.nonDefaultAdapter).
     *
     * @param nv Name/value pairs of meta data to set on the group.
     * @param cmd_line command line argument that can be substituted into the load data.
     * @param return_objects Object(s) created by this method used by
     * <code>wt.load.StandardLoadService</code> for user feedback messages.
     *
     * <BR><BR><B>Supported API: </B>true
     **/
    public static boolean createGroup (Hashtable nv, Hashtable cmd_line, Vector<String> return_objects) {
        defaultAdapter=null;
        boolean flag = true;
        String user = LoadServerHelper.getValue("user", nv, cmd_line, LoadServerHelper.NOT_REQUIRED);
        String groupName = LoadServerHelper.getValue("groupName", nv,cmd_line, LoadServerHelper.REQUIRED);
        if ( groupName == null ) flag = false;
        if ( !flag ) return flag;

        String description = LoadServerHelper.getValue("description", nv, cmd_line, LoadServerHelper.NOT_REQUIRED);
        /**
         * Additional attribute 'DirectoryService' has been added to facilitate adding of groups into non-default LDAP.
         */
        String directoryService = LoadServerHelper.getValue("DirectoryService", nv, cmd_line, LoadServerHelper.NOT_REQUIRED);
        try {
            dirInit ();
            /**
             * Code change made to facilitate adding of groups into non-default LDAP.
             */
            if(directoryService !=null){
                defaultAdapter=directoryService;
                userSearchBase = DirContext.getJNDIAdapterSearchBase (defaultAdapter);
            }

            if ( user == null )
                LoadServerHelper.printMessage ("Create group <" + groupName + ">");

            LoadServerHelper.changePrincipal (user);
            WTContainerRef containerRef = LoadServerHelper.getTargetContainer (nv, cmd_line);

            WTGroup newGroup = createGroupInLdapAndDatabase(groupName, description, containerRef);
            String msg = "Group = " + groupName;
            return_objects.addElement (msg);

            if(newGroup != null)
                LoadServerHelper.printMessage("Done creating group <" + groupName + "> \n");
            else
                LoadServerHelper.printMessage("Group <" + groupName + "> has not been created \n");
        }
        catch ( WTException we ) {
            LoadServerHelper.printMessage("Couldn't create group: WTException caught.");
            logger.error( "", we );
            return false;
        }
        catch ( Exception e ) {
            LoadServerHelper.printMessage ("Error detected in createGroup");
            logger.error( "", e);
            return false;
        }

        return true;
    }

    /**
     * Creates WTOrganization object with properties listed in the data file in the specific format. Following is the format that needs to be specified in the input data file.
     *  <NmLoader>
     *     <csvCreateWTOrganization handler="wt.org.LoadPrincipal.createWTOrganization">
     *        <csvname>Windchill-Marketting and Soultions</csvname>
     *        <csvcodingSystem></csvcodingSystem>
     *        <csvorganizationId></csvorganizationId>
     *        <csvdescription>Windchill Marketting and Solutions Group</csvdescription>
     *        <csvaddress>140 Kendrick Street NEEDHAM, MA, </csvaddress>
     *        <csvconferencingURL>http://www.meetingplace.com</csvconferencingURL>
     *        <csvconferencingId>492492</csvconferencingId>
     *        <csvdomain>Default</csvdomain>
     *        <csvinternetDomain>ptcnet.ptc.com</csvinternetDomain>
     *        <csvclassification></csvclassification>
     *        <csvdirectoryService></csvdirectoryService>
     *     </csvCreateWTOrganization>
     *  </NmLoader>
     * @param nv
     * @param cmd_line
     * @param return_objects
     * @return true if the creation of WTOrganization is successful.
     */
    public static boolean createWTOrganization (Hashtable nv, Hashtable cmd_line, Vector return_objects) {
        boolean ret = false;
        String name = LoadServerHelper.getValue("name",nv,cmd_line,LoadServerHelper.REQUIRED);
        String directoryService = LoadServerHelper.getValue("directoryService",nv,cmd_line,LoadServerHelper.NOT_REQUIRED);
        try {
            validatePrincipalName(name);
            DirectoryContextProvider context = getDirectoryContextProvider(directoryService);
            WTOrganization org = WTOrganization.newWTOrganization(name, context);
            applyOrgAttributes(org, nv, cmd_line);
            org = (WTOrganization)OrganizationServicesHelper.manager.createPrincipal(org);
            ret = true;
        }
        catch (Exception e) {
            LoadServerHelper.printMessage("createWTOrganization: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
        return ret;
    }

    /**
     * Adds a user to a group with properties listed in the data file in the specific format. Following is the format that needs to be specified in the input data file.
     * <NmLoader>
     * <csvUserGroup handler="wt.load.LoadUser.createUserGroup">
     * <csvuser></csvuser>
     * <csvgroupName>orggroup1</csvgroupName>
     * <csvuserName>testuser4</csvuserName>
     * </csvUserGroup>
     * </NmLoader>
     *
     * To facilitate this functionality of adding users into a group existing in a non-default LDAP, we need to add an additional attribute element to
     * the data file. This element will however be optional. The element tag is <csvDirectoryService>. In this element tag we will need to provide
     * the service name for the non-default adapter (ex - com.ptc.ptcnet.abc03d.nonDefaultAdapter) where the group exists.
     *
     * @param nv Name/value pairs representing the user name and the
     *           group name.
     * @param cmd_line command line argument that can be substituted into
     *                 the load data.
     * @param return_objects Object(s) created by this method used by
     * <code>wt.load.StandardLoadService</code> for user feedback messages.
     *
     * <BR><BR><B>Supported API: </B>true
     **/
    public static boolean createUserGroup(Hashtable nv, Hashtable cmd_line, Vector<String> return_objects) {
        boolean flag = true;
        defaultAdapter=null;
        String user = LoadServerHelper.getValue("user", nv,cmd_line, LoadServerHelper.NOT_REQUIRED);
        String groupName = LoadServerHelper.getValue("groupName", nv, cmd_line, LoadServerHelper.REQUIRED);
        String groupNameDS = LoadServerHelper.getValue("groupNameDirectoryService", nv, cmd_line, LoadServerHelper.NOT_REQUIRED);
        if ( groupName == null ) flag = false;

        String userName = LoadServerHelper.getValue("userName", nv, cmd_line, LoadServerHelper.REQUIRED);
        String userNameDS = LoadServerHelper.getValue("userNameDirectoryService", nv, cmd_line, LoadServerHelper.NOT_REQUIRED);
        if ( userName == null ) flag = false;
        if ( !flag ) return flag;

        /**
         * Additional attribute 'DirectoryService' has been added to facilitate adding of users into groups that exist in a non-default LDAP.
         */
        String directoryService = LoadServerHelper.getValue("DirectoryService", nv, cmd_line, LoadServerHelper.NOT_REQUIRED);

        if ( logger.isInfoEnabled() )
            logger.info("Add user <" + userName + "> to group <" + groupName + ">");
        try {
            dirInit ();
            LoadServerHelper.changePrincipal (user);
            WTContainerRef containerRef = LoadServerHelper.getTargetContainer (nv, cmd_line);
            /**
             * Code change made to facilitate adding of users into group that exists in a non-default LDAP.
             */
            if(directoryService !=null){
                defaultAdapter=directoryService;
                userSearchBase = DirContext.getJNDIAdapterSearchBase (defaultAdapter);
            }
            if (groupNameDS != null) { groupNameAdapter=groupNameDS; }
            if (userNameDS != null) { userNameAdapter=userNameDS; }

            addUserToGroup(groupName, userName, containerRef);

            String msg = "Add user " + userName + " to group " + groupName;
            return_objects.addElement (msg);
            if ( logger.isInfoEnabled() )
                logger.info("Done adding user <" + userName + "> to group <" + groupName + "> \n");
        }
        catch ( Exception e ) {
            LoadServerHelper.printMessage("Error detected in createUserGroup <" + userName + "/" + groupName + ">");
            logger.error( "", e );
            return false;
        }

        return true;
    }

    /**
     * Create Administrators group and administrator user.
     *
     * @param    userName        User Name
     * @param    groupName       Group Name
     * @param    sysdomain       System Domain
     * @param    webUserName     Web User Name
     *
     * <BR><BR><B>Supported API: </B>true
     **/
    public static WTGroup createAdminGroupAndUser (String adminUserName,String groupName,AdministrativeDomain sysdomain,String webUserName)throws WTException {
        dirInit ();
        String adminUserDN = null;
        String webUserDN = null;
        String userIdAtt = null;
        String adapter = null;
        DirectoryContextProvider dcp = new GenericDirectoryContextProvider((String[])null,(String[])null);
        String[] services = dcp.getSupportingServices();
        int servicesLen = services.length;
        try {
            for (int i = 0; i < servicesLen; i++) {
                adapter = services[i];
                adminUserDN = queryUser (adminUserName,adapter);
                webUserDN = queryUser (webUserName,adapter);
                if(webUserDN != null)break;
            }

            userIdAtt =DirContext.getMapping(adapter,"user.uniqueIdAttribute",DirContext.getMapping (adapter, "user.uid"));
            if ( webUserDN == null ) {
                adapter=defaultAdapter;
                userIdAtt =DirContext.getMapping(defaultAdapter,"user.uniqueIdAttribute",DirContext.getMapping (defaultAdapter, "user.uid"));
                webUserDN = userIdAtt + '=' + webUserName + ',' + userSearchBase;
                adminUserDN = createAdministratorUserInLdap(adminUserName, webUserName, adminUserDN, webUserDN, userIdAtt);
            }
            else if ( adminUserDN == null ) {
                //
                // Update existing entry to include the administrator's name amongst its unique id attribute values.
                //
                adminUserDN = webUserDN;
                addAdminUserAsAliastoWebUser(adminUserName, webUserDN, userIdAtt, adapter);
            }
        }
        catch ( IEException iee ) {
            Throwable nt = iee.getNestedThrowable ();
            if ( nt != null ) {
                if ( nt instanceof NameAlreadyBoundException )
                    logger.error(webUserName + " already exists in the directory");
                else if ( nt instanceof AttributeInUseException )
                    logger.error(webUserName + " already includes " + userIdAtt + '=' + adminUserName);
                else
                    throw new WTException (nt);
            }
            else
                throw new WTException (iee);
        }catch(IOException ioe){
            throw new WTException(ioe);
        }

        createAdminUserInDatabase(adminUserName, sysdomain, webUserName, adminUserDN, webUserDN, adapter);
        WTGroup group = createAdministratorsGroup_And_Add_AdministratorToThisGroup(groupName, sysdomain, webUserDN);

        return group;
    }
    /**
     * Provides the same functionality as <code>createUser</code>, while additionally
     * making the new user a member of the given organization.
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param   nv
     * @param   cmd_line
     * @param   return_objects
     *
     * @throws  WTException    If no organization is specified
     *
     * @return <code>true</code> if the load succeeds
     **/
    public static boolean createOrgAdmin(final Hashtable nv, final Hashtable cmd_line, final Vector<String> return_objects) {
        String user_name = LoadServerHelper.getValue("newUser", nv, cmd_line, LoadServerHelper.REQUIRED);
        String org_name = LoadServerHelper.getValue("Organization", nv, cmd_line, LoadServerHelper.REQUIRED);
        createUser(nv, cmd_line, return_objects);
        try {
            DirectoryContextProvider dcp = OrganizationServicesHelper.manager.newDirectoryContextProvider((String[])null,(String[])null);
            WTUser user = OrganizationServicesHelper.manager.getUser(user_name,dcp);
            if (user == null) {
                throw new WTException("User not found: " + user_name);
            }

            WTOrganization org = OrganizationServicesHelper.manager.getOrganization(org_name,dcp);
            if (org == null) {
                throw new WTException("Organization not found: " + org_name);
            }

            OrgContainer container = WTContainerHelper.service.getOrgContainer(org);
            if (container == null) {
                throw new WTException("No context exists for organization: " + org.getDn());
            }

            WTGroup admins = container.getAdministrators();
            boolean added = admins.addMember(user);
            if (added) {
                LoadServerHelper.printMessage("Added user: " + user.getDn() + " to administrators group for organization: " + WTContainerServerHelper.getLogPath(container));
            }
            else {
                LoadServerHelper.printMessage("User: " + user.getDn() + " was already a member of administrators group for organization: " + WTContainerServerHelper.getLogPath(container));
            }

            return true;
        }
        catch (WTException wte){
            LoadServerHelper.printMessage("\ncreateOrgAdmin: "  + wte);
            logger.error( "", wte );
        }

        return false;
    }

    /**
     * Provides the same functionality as <code>createUser</code>, while additionally
     * making the new user a site admin.
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param   nv
     * @param   cmd_line
     * @param   return_objects
     *
     * @throws  WTException
     *
     * @return <code>true</code> if the load succeeds
     **/
    public static boolean createSiteAdmin(final Hashtable nv, final Hashtable cmd_line, final Vector<String> return_objects) {
        String user_name = LoadServerHelper.getValue("newUser", nv, cmd_line, LoadServerHelper.REQUIRED);
        createUser(nv, cmd_line, return_objects);
        try{
            DirectoryContextProvider dcp = OrganizationServicesHelper.manager.newDirectoryContextProvider((String[])null,(String[])null);
            WTUser user = OrganizationServicesHelper.manager.getUser(user_name,dcp);
            if (user == null) {
                throw new WTException("User not found: " + user_name);
            }

            ExchangeContainer site = WTContainerHelper.service.getExchangeContainer();
            WTGroup admins = site.getAdministrators();
            boolean added = admins.addMember(user);
            if (added) {
                LoadServerHelper.printMessage("Added user: " + user.getDn() + " to site administrators");
            }
            else {
                LoadServerHelper.printMessage("User: " + user.getDn() + " was already a member of site administrators");
            }
            return true;
        }
        catch (WTException wte){
            LoadServerHelper.printMessage("\ncreateOrgAdmin: "  + wte);
            logger.error( "", wte);
        }
        return false;
    }


    /**
     * Load a user definition into the directory and database.
     *
     * <BR><BR><B>Supported API: </B>true
     **/
    private static boolean loadUser(String newName, String fullName, Vector values, HashMap<String, String> fullNameFields) throws WTException {

        String dn = createUserInLdap(newName, fullName, values, fullNameFields);

        //
        //  Force user to be persisted in database
        //
        if(checkIfUserAlreadyExists(newName)) {
        	LoadServerHelper.printMessage("User: " + newName + " already exists, skipping.");
        	return true;
        }
        WTUser user = (WTUser)OrganizationServicesHelper.manager.getPrincipalByDN(dn);


        String allowLdapSync = fullNameFields.get(WTUser.ALLOW_LDAPSYNCHRONIZATION);
        // If the LDAP sync property is not set, default to TRUE
        if (allowLdapSync == null) {
            allowLdapSync = Boolean.TRUE.toString();
        }
        HashMap<String, String> newFullNameFields = new HashMap<String, String>();
        newFullNameFields.put(WTUser.FULL_NAME, fullName);
        newFullNameFields.put(WTUser.ALLOW_LDAPSYNCHRONIZATION, allowLdapSync);
        // Include the last name if it was specifically mentioned
        newFullNameFields.put(WTUser.LAST, (fullNameFields.get(WTUser.LAST)!=null?fullNameFields.get(WTUser.LAST):OrganizationServicesServerHelper.getSurNameFromFullName(fullName)));
        user = applyFullNameFieldsToUserObject(newFullNameFields, user);
        PersistenceServerHelper.manager.update(user);
        return true;
    }

	private static boolean checkIfUserAlreadyExists(String newName) throws QueryException, WTException {
		QuerySpec spec = new QuerySpec(WTUser.class);
        SearchCondition condition = new SearchCondition(WTUser.class, WTUser.NAME, SearchCondition.EQUAL, newName);
        spec.appendWhere(condition);
        QueryResult find = PersistenceHelper.manager.find(spec);
        return find.hasMoreElements();
	}

    private static String createUserInLdap(String newName, String fullName,Vector values, HashMap<String, String> fullNameFields) throws  WTException {
        validatePrincipalName(newName);
        String dn = getUserDN (newName, true);

        try {
            Task task = new Task ("/wt/federation/CreatePrincipal.xml");

            for ( int i = 0; i < values.size (); ++i )
                task.addParam (LdapServices.TASK_FIELD, values.elementAt (i));

            String userIdAtt = DirContext.getMapping(defaultAdapter,"user.uniqueIdAttribute", DirContext.getMapping (defaultAdapter, "user.uid"));
            task.addParam (LdapServices.TASK_SERVICE_INSTANCE, defaultAdapter);

            /*
             * Code change made to facilitate adding of users into non-default LDAP.
             * the getUserDN API will find a user with the given name if it already exists in any of the existing services.
             * The following piece of code forces the LDAP entry to be created for the user as long as the search base of the existing user
             * is not equal to the creation base for the new user.
             */
            int index=dn.indexOf(",");
            String searchBase=dn.substring(index+1);
            String uid=null;
            StringTokenizer uid_tokenizer = new StringTokenizer(dn, ",",false);
            if (uid_tokenizer.hasMoreElements()) {
                uid = uid_tokenizer.nextToken();
            }
            if(!searchBase.equalsIgnoreCase(userSearchBase) ){
                dn=uid + "," + userSearchBase;
            }

            task.addParam (LdapServices.TASK_OBJECT, dn);
            task.addParam (LdapServices.TASK_FIELD,"objectClass=" + DirContext.getMapping(defaultAdapter, "user.objectClass", "inetOrgPerson"));
            task.addParam (LdapServices.TASK_FIELD, "objectClass=person");
            task.addParam (LdapServices.TASK_FIELD, userIdAtt + '=' + newName);
            task.addParam (LdapServices.TASK_FIELD,DirContext.getMapping (defaultAdapter, "user.cn") + '=' + fullName);
            task.addParam (LdapServices.TASK_FIELD, DirContext.getMapping (defaultAdapter, "user.sn") + '=' + fullNameFields.get(WTUser.LAST));
            task.setUsername (defaultDirectoryUser);
            task.invoke ();
        }
        catch ( IEException iee ) {
            Throwable nt = iee.getNestedThrowable ();
            if ( nt != null && (nt instanceof NameAlreadyBoundException) ) {
                logger.error(nt.getMessage() + " for user with dn: " + dn );
            }
            else
                throw new WTException (iee);
        }
        catch(IOException io){
            throw new WTException(io);
        }
        return dn;
    }

    /**
     * Query a user definition registered in the directory.
     *
     * @param userName The unique identifier for a user
     * @param adapter  - The service where the user needs to be searched.
     * @return The distinguished name of the matching entry, or null if
     *         no matches are found.
     * <BR><BR><B>Supported API: </B>false
     **/
    private static String queryUser (String userName, String adapter) throws WTException {
        String searchBase=null;
        try {
            if(adapter != null){
                searchBase = DirContext.getJNDIAdapterSearchBase(adapter);
            }
            else{
                adapter=defaultAdapter;
                searchBase = userSearchBase;
            }

            String userIdAtt =DirContext.getMapping(adapter,"user.uniqueIdAttribute",DirContext.getMapping (adapter, "user.uid"));

            Task t = new Task ("/wt/federation/QueryPrincipals.xml");
            t.addParam (LdapServices.TASK_SERVICE_INSTANCE, adapter);
            t.addParam (LdapServices.TASK_SEARCH_BASE, searchBase);
            t.addParam (LdapServices.TASK_SEARCH_FILTER,"(&(objectClass=" + DirContext.getMapping(adapter, "user.objectClass","inetOrgPerson") + ")(" + userIdAtt + '=' + userName + "))");
            t.addParam (LdapServices.TASK_GROUP_OUT, "user");
            t.setUsername (defaultDirectoryUser);
            t.invoke ();

            Group group = t.getGroup ("user");

            if ( group == null || group.getElementCount () < 1 )
                return null;
            else
                return (String)group.getAttributeValue (0, LdapServices.TASK_OBJECT);
        }
        catch ( IEException iee ) {
            Throwable nt = iee.getNestedThrowable ();
            if ( nt != null && (nt instanceof NameNotFoundException) ) {
                logger.error(userName + " does not exist in the directory yet");
                return null;
            }
            else
                throw new WTException (iee);
        }
        catch ( Exception e ) {
            if ( e instanceof WTException )
                throw (WTException)e;
            else
                throw new WTException (e);
        }
    }

    /**
     * Query a group definition registered in the directory.
     *
     * @param groupName The unique identifier for a group
     * @param adapter The service where the group needs to be searched.
     * @return The distinguished name of the matching entry, or null if no matches are found.
     * <BR><BR><B>Supported API: </B>false
     **/
    private static String queryGroup(String groupName, String adapter) throws WTException {
        String searchBase = null;
        try {
            if (adapter == null) {
                adapter = groupNameAdapter==null?defaultAdapter:groupNameAdapter;
            }
            searchBase = DirContext.getJNDIAdapterSearchBase(adapter);

            String groupIdAtt = DirContext.getMapping(adapter, "group.uniqueIdAttribute", DirContext.getMapping(adapter, "group.cn"));

            Task t = new Task("/wt/federation/QueryPrincipals.xml");
            t.addParam(LdapServices.TASK_SERVICE_INSTANCE, adapter);
            t.addParam(LdapServices.TASK_SEARCH_BASE, searchBase);
            String mapping = DirContext.getMapping(adapter, "group.objectClass", "groupOfUniqueNames");
            String filter = "(&(objectClass=" + mapping + ")(" + groupIdAtt + '=' + groupName + "))";
            t.addParam(LdapServices.TASK_SEARCH_FILTER, filter);
            t.addParam(LdapServices.TASK_GROUP_OUT, "group");
            t.setUsername(defaultDirectoryUser);
            t.invoke();

            Group group = t.getGroup("group");

            if (group == null) {
                return null;
            }
            else {
                switch(group.getElementCount()) {
                    case 0: throw new WTException(WTMessage.getLocalizedMessage("wt.org.orgResource", orgResource.GROUP_NOT_FOUND_BY_DN_IN_ADAPTER, new String[]{groupName, adapter}));
                    case 1: return (String)group.getAttributeValue(0, LdapServices.TASK_OBJECT);
                    default: throw new WTException(WTMessage.getLocalizedMessage("wt.org.orgResource", orgResource.MULTIPLE_GROUPS_FOUND, new String[]{groupName, adapter}));
                }
            }
        }
        catch (IEException iee) {
            Throwable nt = iee.getNestedThrowable();
            if (nt != null && (nt instanceof NameNotFoundException)) {
                logger.error(groupName + " does not exist in the directory yet");
                return null;
            }
            else {
                throw new WTException(iee);
            }
        }
        catch (Exception e) {
            if (e instanceof WTException) {
                throw (WTException)e;
            }
            else {
                throw new WTException(e);
            }
        }
    }

    /**
     * @param adminUserName
     * @param webUserName
     * @param adminUserDN
     * @param webUserDN
     * @param userIdAtt
     * @return
     * @throws IOException
     * @throws IEException
     */
    private static String createAdministratorUserInLdap(String adminUserName, String webUserName, String adminUserDN, String webUserDN, String userIdAtt) throws IOException, IEException, WTException {
        validatePrincipalName(adminUserName);
        validatePrincipalName(webUserName);
        Task task = new Task ( "/wt/federation/CreatePrincipal.xml" );
        task.addParam (LdapServices.TASK_SERVICE_INSTANCE, defaultAdapter);
        task.addParam (LdapServices.TASK_OBJECT, webUserDN);
        task.addParam (LdapServices.TASK_FIELD,"objectClass=" + DirContext.getMapping(defaultAdapter, "user.objectClass","inetOrgPerson"));
        task.addParam (LdapServices.TASK_FIELD, "objectClass=person");
        task.addParam (LdapServices.TASK_FIELD, userIdAtt + '=' + webUserName);

        if ( adminUserDN == null ) {
            task.addParam (LdapServices.TASK_FIELD, userIdAtt + '=' + adminUserName);
            adminUserDN = webUserDN;
        }

        task.addParam(LdapServices.TASK_FIELD,DirContext.getMapping (defaultAdapter, "user.cn") + '=' + ADMIN_FULLNAME);
        task.addParam (LdapServices.TASK_FIELD,DirContext.getMapping (defaultAdapter, "user.sn") + '=' + ADMIN_LAST);
        task.setUsername (defaultDirectoryUser);
        task.invoke ();
        return adminUserDN;
    }

    /**
     * @param adminUserName
     * @param webUserDN
     * @param userIdAtt
     * @param adapter
     * @throws IEException
     * @throws IOException
     */
    private static void addAdminUserAsAliastoWebUser(String adminUserName, String webUserDN, String userIdAtt, String adapter) throws IEException, IOException, WTException {
        validatePrincipalName(adminUserName);
        Task task = new Task ("/wt/federation/UpdatePrincipal.xml");
        task.addParam (LdapServices.TASK_OBJECT, webUserDN);
        task.addParam (LdapServices.TASK_FIELD, userIdAtt + '=' + adminUserName);
        task.addParam (LdapServices.TASK_MODIFICATION, LdapServices.UPDATE_ADD);
        task.addParam (LdapServices.TASK_SERVICE_INSTANCE, adapter);
        task.setUsername (defaultDirectoryUser);
        task.invoke ();
    }

    /**
     * @param adminUserName
     * @param sysdomain
     * @param webUserName
     * @param adminUserDN
     * @param webUserDN
     * @param adapter
     * @throws WTException
     */
    private static void createAdminUserInDatabase(String adminUserName, AdministrativeDomain sysdomain, String webUserName, String adminUserDN, String webUserDN, String adapter)
            throws WTException {
        validatePrincipalName(adminUserName);
        WTUser user =WTUser.newWTUser (adminUserName, adminUserDN, adapter);
        DomainAdministeredHelper.setAdminDomain (user, sysdomain);
        try{
            user.setFullName(ADMIN_FULLNAME);
            user.setLast(ADMIN_LAST);
        }catch(WTPropertyVetoException wtpve){
            throw new WTException(wtpve, " Error occured while trying to set the first or last name on the Site administrator user");
        }
        user = (WTUser)PersistenceHelper.manager.store (user);

        //  Read the entry via Org Services to populate the principal cache.
        OrganizationServicesHelper.manager.getPrincipalByDN (adminUserDN);
        if ( !webUserDN.equalsIgnoreCase (adminUserDN) ) {
            user =WTUser.newWTUser (webUserName, webUserDN, adapter);
            DomainAdministeredHelper.setAdminDomain (user, sysdomain);
            user = (WTUser)PersistenceHelper.manager.store (user);
            OrganizationServicesHelper.manager.getPrincipalByDN (webUserDN);
        }
    }

    /**
     * @param groupName
     * @param sysdomain
     * @param webUserDN
     * @return
     * @throws WTException
     * @throws WTPropertyVetoException
     */
    private static WTGroup createAdministratorsGroup_And_Add_AdministratorToThisGroup(String groupName, AdministrativeDomain sysdomain, String webUserDN) throws WTException {
        validatePrincipalName(groupName);
        WTContainerRef containerRef =WTContainerHelper.service.getExchangeRef ();
        String groupDN = getGroupDN (groupName, containerRef);
        createGroupInLdap (groupDN, "Site Administrators");
        WTGroup group =WTGroup.newWTGroup (groupName, groupDN, defaultAdapter);
        DomainAdministeredHelper.setAdminDomain (group, sysdomain);
        try {
            group.setContainerReference(containerRef);
        } catch (WTPropertyVetoException wtpve) {
            throw new WTException(wtpve);
        }

        group = (WTGroup)PersistenceHelper.manager.store (group);
        OrganizationServicesHelper.manager.getPrincipalByDN (groupDN);
        addMemberByDN (groupDN, webUserDN);

        return group;
    }

    /**
     * @param groupName
     * @param description
     * @param containerRef
     * @return
     * @throws WTException
     * @throws IEException
     * @throws IOException
     * @throws WTPropertyVetoException
     */
    private static WTGroup createGroupInLdapAndDatabase(String groupName, String description, WTContainerRef containerRef) throws WTException{
        validatePrincipalName(groupName);
        try{
            String groupDN = getGroupDN (groupName, containerRef);
            String service = DirContext.getJNDIAdapterForDN (groupDN);

            WTGroup group = WTGroup.newWTGroup(groupName, groupDN, service);
            group.setDescription(description);
            group.setContainerReference(containerRef);
            DomainAdministeredHelper.setAdminDomain(group, DirectoryHelperSvr.getPrincipalDomainRef(containerRef.getReferencedContainer()));
            WTGroup newGroup =  (WTGroup)OrganizationServicesHelper.manager.getPrincipalByDN(groupDN, service, false);
            if(newGroup != null){
                if(PersistenceHelper.isPersistent(newGroup))
                    return newGroup;
                else
                    return (WTGroup)PersistenceHelper.manager.store (group);
            }

            return (WTGroup)OrganizationServicesHelper.manager.createPrincipal(group);

        }catch(WTPropertyVetoException wtpve){
            throw new WTException(wtpve);
        }catch ( IEException e ) {
            throw new WTException (e);
        }catch ( IOException e ) {
            throw new WTException (e);
        }
    }

    private static void createGroupInLdap (String dn, String description)throws WTException {
        int ci = dn.indexOf (',');
        String rdn = (ci == -1)? dn.trim (): dn.substring (0, ci).trim ();
        try {
            String service = DirContext.getJNDIAdapterForDN (dn);
            Task task = new Task ( "/wt/federation/CreatePrincipal.xml" );
            task.addParam (LdapServices.TASK_OBJECT, dn);
            task.addParam (LdapServices.TASK_FIELD, FederationUtilities.unescapeDn (rdn));
            task.addParam(LdapServices.TASK_FIELD,"objectClass=" + DirContext.getMapping(service, "group.objectClass", "groupOfUniqueNames"));
            if ( description != null && !description.equals ("") )
                task.addParam(LdapServices.TASK_FIELD,DirContext.getMapping (service, "group.description") + '=' + description);
            task.addParam (LdapServices.TASK_SERVICE_INSTANCE, service);
            task.setUsername (defaultDirectoryUser);
            task.invoke ();
        }
        catch ( IEException iee ) {
            Throwable nt = iee.getNestedThrowable ();
            if ( nt != null && (nt instanceof NameAlreadyBoundException) ){
                logger.warn(nt.getMessage() + " for group with dn: " + dn);
            }
            else
                throw new WTException(iee);
        }
        catch ( IOException e ) {
            throw new WTException (e);
        }
    }

    /**
     * Adds user to a group.
     * @param groupName
     * @param userName
     * @param containerRef
     * @throws WTException
     */
    private static void addUserToGroup(String groupName, String userName, WTContainerRef containerRef) throws WTException {
        String groupDN = null;


        OrgContainer orgContainer = null;
        if (containerRef.getReferencedClass().equals(OrgContainer.class)) {
            orgContainer = (OrgContainer)containerRef.getObject();
        }
        /**
         * SPR 1180205
         * changed the implementation to facilitate loading users to default group like Administrators loaded during Windchill Loader specifically
         * for Windchill PDM, since by default the creation base for Windchill PDM maps to the "cn=Windchill PDM" node under the library container
         * instead of the "ou=people" node
         */
        WTGroup group = null;
        ContainerIterator ci = WTContainerHelper.getAncestors(containerRef);
        while (containerRef != null) {
            groupDN = getGroupDN(groupName, containerRef);
            group = (WTGroup)OrganizationServicesHelper.manager.getPrincipalByDN(groupDN);
            if (group == null) {
                if (ci.hasNext())
                    containerRef = ci.nextContainerRef();
                else
                    containerRef = null;
            } else
                break;
        }

        // As group was not found , it could be a org group which is not under public node but under org itself search
        // for it
        if (group == null && orgContainer != null) {
            DirectoryContextProvider dcp = WTContainerHelper.service.getContextProvider(orgContainer);
            String service = groupNameAdapter == null ? defaultAdapter : groupNameAdapter;
            String searchBase = dcp.getCreationBase(service);
            String groupIdAtt;
            try {
                groupIdAtt = DirContext.getMapping(service, "group.uniqueIdAttribute",
                        DirContext.getMapping(service, "group.cn"));
            } catch (Exception e) {
                throw new WTException(e);
            }

            groupDN = groupIdAtt + '=' + FederationUtilities.escapeDn(groupName) + ',' + searchBase;
            group = (WTGroup) OrganizationServicesHelper.manager.getPrincipalByDN(groupDN);

        }

        if (group == null) {
            logger.error("Group not found using name: " + groupName);
            throw new WTException("Group not found using name: " + groupName);
        }
        String userDN = getUserDN(userName, false);
        if (userDN == null) {
            logger.error("User not found using name: " + userName);
            throw new WTException("User not found using name: " + userName);
        }

        addMemberByDN(groupDN, userDN);

    }

    /**
     * perform the actual addition of user to the group.
     * @param groupDN
     * @param memberDN
     * @throws WTException
     */
    private static void addMemberByDN (String groupDN, String memberDN)throws WTException {
        WTGroup group = (WTGroup)OrganizationServicesHelper.manager.getPrincipalByDN (groupDN);
        validatePrincipalFoundByDN(group, groupDN);
        WTPrincipal member = OrganizationServicesHelper.manager.getPrincipalByDN (memberDN);
        validatePrincipalFoundByDN(member, memberDN);
        group.addMember (member);
    }

    private static void validatePrincipalFoundByDN(WTPrincipal principal, String principalDN) throws WTException {
        if (principal == null) {
            String message = WTMessage.getLocalizedMessage("wt.org.orgResource", orgResource.PRINCIPAL_NOT_FOUND_BY_DN, new String[]{principalDN});
            throw new WTException(message);
        }
    }

    /**
     * get the user's DN. If the user already exists it returns the DN, else it formulates a DN for the new user.
     * @param userName
     * @return
     * @throws WTException
     */
    private static String getUserDN (String userName, boolean create) throws WTException {
        String userDn = null;

        // First check for a persisted user
        if(!create){
            // First check for a persisted user
            WTPrincipalReference userRef = null;
            DirectoryContextProvider dcp = new GenericDirectoryContextProvider((String[])null,(String[])null);
            userRef  = OrganizationServicesHelper.manager.getPrincipalReference(userName, WTUser.class,dcp);
            if (userRef != null) {
                userDn = userRef.getDn();
                logger.info("Found persisted user with dn <" + userDn + "> for User <" + userName + ">");
                return userDn;
            }
        }

        try {
            String service = userNameAdapter==null?defaultAdapter:userNameAdapter;

            // If no persisted user, search for a user in ldap under the given search base
            // Cannot assume the user is at the search base and construct a dn
            userDn = queryUser(userName, service);
            if (userDn != null && userDn.length() > 0) {
                logger.info("Found dn <" + userDn + "> in service <" + service + "> for User <" + userName + ">");
                return userDn;
            }
            logger.info("Did not find an existing entry in service <" + service + "> for User <" + userName + ">");

            // If user does not exist in ldap either, then construct a dn for this user
            String base = DirContext.getJNDIAdapterSearchBase(service);
            if ( service == null ) dirInit ();
            String userIdAtt = DirContext.getMapping(service, "user.uniqueIdAttribute",DirContext.getMapping (service, "user.uid"));
            userDn = userIdAtt + '=' + FederationUtilities.escapeDn (userName) + ',' + base;
            logger.info("Constructed dn <" + userDn + "> in service <" + service + "> for User <" + userName + ">");
            return userDn;
        }
        catch ( Exception e ) {
            if ( e instanceof WTException )
                throw (WTException)e;
            else
                throw new WTException (e);
        }
    }

    /**
     * Formulates a DN for the group.
     * @param groupName
     * @param containerRef
     * @return
     * @throws WTException
     */
    private static String getGroupDN (String groupName, WTContainerRef containerRef)throws WTException {
        try {
            String service = groupNameAdapter==null?defaultAdapter:groupNameAdapter;
            String base = DirContext.getJNDIAdapterSearchBase(service);
            if ( containerRef != null ) {
                PrincipalSpec ps =new PrincipalSpec (containerRef, WTGroup.class);
                ps.setPerformLookup (false);
                ps.setIncludeAllServices (true);
                DirectoryContextProvider [] dcps =
                        WTContainerHelper.service.getPublicContextProviders (ps);
                boolean serviceFound=false;
                /**
                 * The following piece of code was changed to dynamically search for the group among all the existing directory services and not only the
                 * default directory service.
                 */
                String[] supportingServices=dcps[0].getSupportingServices();
                int suppServicesLength=supportingServices.length;
                for (int i = 0; i < suppServicesLength; i++) {
                    if(service.equalsIgnoreCase(supportingServices[i])){
                        serviceFound=true;
                        break;
                    }
                }
                if(!serviceFound){
                    service = dcps[0].getPrimaryService ();
                }
                base = dcps[0].getCreationBase (service);
            }

            String groupIdAtt =
                    DirContext.getMapping(service, "group.uniqueIdAttribute",DirContext.getMapping (service, "group.cn"));

            String groupDn = groupIdAtt + '=' + FederationUtilities.escapeDn (groupName) + ',' + base;
            return groupDn;
        }
        catch ( Exception e ) {
            if ( e instanceof WTException )
                throw (WTException)e;
            else
                throw new WTException (e);
        }
    }

    /**
     * @param fullNameFields
     * @param user
     * @return
     * @throws WTPropertyVetoException
     */
    private static WTUser applyFullNameFieldsToUserObject(HashMap<String, String> fullNameFields, WTUser user) throws WTException {
        try{
            String last =fullNameFields.get(WTUser.LAST);
            String allowLdapSync = fullNameFields.get(WTUser.ALLOW_LDAPSYNCHRONIZATION);
            String fullName = fullNameFields.get(WTUser.FULL_NAME);

            if(last != null){
                user.setLast(last);
            }
            if(allowLdapSync != null){
                user.setAllowLDAPSynchronization(Boolean.parseBoolean(allowLdapSync));
            }
            if(fullName != null){
                user.setFullName(fullName);
            }

            return user;
        }catch(WTPropertyVetoException wtpve){
            throw new WTException(wtpve);
        }
    }

    /**
     * Reads the argument from the data file and sets the value to the WTOrganization object.
     * @param org
     * @param nv
     * @param cmd_line
     * @throws WTException
     * @throws WTPropertyVetoException
     * @throws MalformedURLException
     */
    private static void applyOrgAttributes(WTOrganization org, Hashtable nv, Hashtable cmd_line)throws WTException, WTPropertyVetoException, MalformedURLException {
        String codingSys = LoadServerHelper.getValue("codingSystem",nv,cmd_line,LoadServerHelper.NOT_REQUIRED);
        String uniqueId = LoadServerHelper.getValue("organizationId",nv,cmd_line,LoadServerHelper.NOT_REQUIRED);
        String descr = LoadServerHelper.getValue("description",nv,cmd_line,LoadServerHelper.NOT_REQUIRED);
        String address = LoadServerHelper.getValue("address",nv,cmd_line,LoadServerHelper.NOT_REQUIRED);
        String conferencingURL = LoadServerHelper.getValue("conferencingURL",nv,cmd_line,LoadServerHelper.NOT_REQUIRED);
        String conferencingId  = LoadServerHelper.getValue("conferencingId",nv,cmd_line,LoadServerHelper.NOT_REQUIRED);
        String internetDomain = LoadServerHelper.getValue("internetDomain",nv,cmd_line,LoadServerHelper.NOT_REQUIRED);
        String classification = LoadServerHelper.getValue("classification",nv,cmd_line,LoadServerHelper.NOT_REQUIRED);

        if ( codingSys != null && uniqueId != null) {
            WTOrganizationIdentifier wtOrgId = WTOrganizationIdentifier.newWTOrganizationIdentifier();
            wtOrgId.setCodingSystem(codingSys);
            wtOrgId.setUniqueIdentifier(uniqueId);
            org.setOrganizationIdentifier(wtOrgId);
        }
        if ( descr != null ){
            org.setDescription(descr);
        }
        if ( address != null) {
            org.setLocation(address);
        }
        if (conferencingURL != null ){
            org.setConferencingURL(new URL(conferencingURL));
        }
        if (conferencingId!= null ){
            org.setConferencingIdentifier(conferencingId);
        }
        if (internetDomain != null) {
            org.setInternetDomain(internetDomain);
        }
        if ( classification != null ){
            org.setClassification(classification);
        }
        AdminDomainRef domainRef = LoadServerHelper.getTargetDomain(nv, cmd_line, "domain", false);
        if ( domainRef != null) {
            org.setDomainRef(domainRef);
        }
    }

    /**
     * Retrieves the directory context provider specified in the data file.
     * @param  directoryService Name of the directory service provider.
     * @return   If the string is null, Default directory context provider is returned.
     * @throws WTException
     */
    private static DirectoryContextProvider getDirectoryContextProvider(String directoryService)
            throws WTException {
        String [] services = null;
        if ( directoryService != null) {
            services = new String[1];
            services [0] = directoryService;
        }
        return OrganizationServicesHelper.manager.newDirectoryContextProvider( services, (String[]) null );
    }

    /**
     *
     * @param addr
     * @param addrPart
     * @return Returns a an address format seperated by "$" symbol.
     */
    private static String addAddrPart (String addr, String addrPart) {
        if (addr != null)
            addr = addr + "$" + addrPart;
        else
            addr = addrPart;
        return addr;
    }

    /**
     * This takes the locale value passed into the load file and returns the corresponding language value.
     * @param locale
     * @return
     * @throws WTException
     */
    private static String getPreferredLanguageFromLocale(String locale) throws WTException {
        Locale loc = null;

        if (locale == null || locale.equals("US"))
            loc = Locale.US;
        else{
            String lowerLocale = locale.toLowerCase();
            switch(lowerLocale){
                case "en-us" : {
                    loc = new Locale("en", "us");
                    break;
                }
                case "en-gb" : {
                    loc = new Locale("en", "gb");
                    break;
                }
                case "zh-cn" : {
                    loc = new Locale("zh", "cn");
                    break;
                }
                case "zh-tw" : {
                    loc = new Locale("zh", "tw");
                    break;
                }
                default : {
                    loc = new Locale(locale, locale);
                }
            }
        }

        String language = loc.toString ();

        Enumeration locales = new Vector ().elements ();
        locales = OrganizationServicesHelper.manager.getUserLanguages ();

        while ( locales.hasMoreElements () ) {
            Locale localeList = (Locale)locales.nextElement ();
            String localListString=localeList.toString();
            if ( localListString.equalsIgnoreCase (locale) )
                language = localListString;
        }

        language = language.replace ('_','-');
        return language;
    }

    /**
     * Initialize LDAP directory service support.
     *
     * <BR><BR><B>Supported API: </B>true
     **/
    public static void dirInit () throws WTException {
        if ( defaultAdapter != null ) return;
        try {
            WTProperties wtprops = WTProperties.getServerProperties ();
            DIRVERBOSE = wtprops.getProperty ("wt.federation.verbose", false);
            defaultDirectoryUser = wtprops.getProperty("wt.federation.org.defaultDirectoryUser", wtprops.getProperty ("wt.admin.defaultAdministratorName"));
            //
            //  Initialize the Info*Engine NamingService
            //

            //
            //  Set configuration properties
            //
            String defaultVMName = wtprops.getProperty ("wt.federation.ie.VMName");
            if ( defaultVMName != null )
                System.setProperty ("com.infoengine.vm.name", defaultVMName);

            String taskCodebase =  wtprops.getProperty ("wt.federation.taskCodebase");
            if ( taskCodebase != null )
                System.setProperty("com.infoengine.taskProcessor.codebase", taskCodebase);

            String taskRoot =  wtprops.getProperty ("wt.federation.taskRootDirectory");
            if ( taskRoot != null )
                System.setProperty("com.infoengine.taskProcessor.templateRoot", taskRoot);

            String credentialsMapper =  wtprops.getProperty ("wt.federation.task.mapCredentials");
            if ( credentialsMapper != null && System.getProperty("com.infoengine.credentialsMapper") == null )
                System.setProperty("com.infoengine.credentialsMapper", credentialsMapper);

            //
            //  Determine the directory service where users and groups will
            //  be created.
            //
            defaultAdapter = DirContext.getDefaultJNDIAdapter ();
            userSearchBase = DirContext.getJNDIAdapterSearchBase (defaultAdapter);

            if ( DIRVERBOSE ) {
                logger.info("defaultAdapter: " + defaultAdapter);
                logger.info("userSearchBase: " + userSearchBase);
            }
        }
        catch ( Exception e ) {
            logger.error( "", e );
            if ( e instanceof WTException )
                throw (WTException)e;
            else
                throw new WTException (e);
        }
    }

    /**
     * Add a group to a group.
     * To facilitate this functionality of adding groups into a group existing in a non-default LDAP, we need to add additional elements to
     * the data file. These elements will be optional. The element tags are <csvparentDirectoryService>, and <csvchildDirectoryService>.
     * In this element tag we will need to provide the service name for the non-default adapter (ex - com.ptc.ptcnet.abc03d.nonDefaultAdapter).
     *
     * @param nv Name/value pairs representing the user name and the group name.
     * @param cmd_line command line argument that can be substituted into the load data.
     * @param return_objects Object(s) created by this method used by
     * <code>wt.load.StandardLoadService</code> for user feedback messages.
     * @return
    * @throws WTException
     */
    public static boolean createGroupGroup(Hashtable<Object, Object> nv,
                                           Hashtable<Object, Object> cmd_line,
                                           Vector<Object> return_objects) throws WTException {

        defaultAdapter=null;
        String user = LoadServerHelper.getValue
                ("user", nv,cmd_line, LoadServerHelper.NOT_REQUIRED);
        String parentGroupName = LoadServerHelper.getValue
                ("parentGroupName", nv, cmd_line, LoadServerHelper.REQUIRED);

        String childGroupName = LoadServerHelper.getValue
                ("childGroupName", nv, cmd_line, LoadServerHelper.REQUIRED);

        String parentDirectoryService = LoadServerHelper.getValue
                ("parentDirectoryService", nv, cmd_line, LoadServerHelper.NOT_REQUIRED);

        String childDirectoryService = LoadServerHelper.getValue
                ("childDirectoryService", nv, cmd_line, LoadServerHelper.NOT_REQUIRED);

        WTContainerRef containerRef = LoadServerHelper.getTargetContainer (nv, cmd_line);

        if ( parentGroupName==null ||  childGroupName==null) return false;

        try {
            logger.debug(" Adding group "+childGroupName+" present in "+childDirectoryService+" as member of "+parentGroupName+" present in "+parentDirectoryService+", in container "+containerRef);
            dirInit ();

            LoadServerHelper.changePrincipal (user);


            // If the container path is for Site, allow a subtree lookup...
            if (WTContainerHelper.getExchangeRef().equals(containerRef)) {
                String parentDn = queryGroup(parentGroupName, parentDirectoryService);
                String childDn = queryGroup(childGroupName, childDirectoryService);
                addMemberByDN(parentDn, childDn);
            }
            // ...otherwise revert to previous behavior
            else {

                String parentGroupDN = getGroupDNByDirectoryService(nv, cmd_line, parentGroupName, parentDirectoryService);
                String childGroupDN = getGroupDNByDirectoryService(nv, cmd_line, childGroupName, childDirectoryService);

                if ( childGroupDN == null ){
                    DirectoryContextProvider dcp = WTContainerHelper.service.getContextProvider (containerRef);
                    WTGroup childSupplierAdmin = OrganizationServicesHelper.manager.getGroup (childGroupName, dcp);
                    childGroupDN = childSupplierAdmin.getDn ();
                }

                if ( parentGroupDN == null ){
                    DirectoryContextProvider dcp = WTContainerHelper.service.getContextProvider (containerRef);
                    WTGroup parentSupplierAdmin = OrganizationServicesHelper.manager.getGroup (parentGroupName, dcp);
                    parentGroupDN = parentSupplierAdmin.getDn ();
                }
                // Still can't find DN for the group, throw exception
                if(parentGroupDN == null ){
                    String message = WTMessage.getLocalizedMessage("wt.org.orgResource", orgResource.GROUP_NOT_FOUND_BY_DN_IN_ADAPTER, new String[]{parentGroupName, parentDirectoryService});
                    throw new WTException (message);
                }
                else if(childGroupDN == null){
                    String message = WTMessage.getLocalizedMessage("wt.org.orgResource", orgResource.GROUP_NOT_FOUND_BY_DN_IN_ADAPTER, new String[]{childGroupName, childDirectoryService});
                    throw new WTException (message);
                }
                else{
                    addMemberByDN(parentGroupDN,childGroupDN);
                }

            }

            String msg = "Add child group " + childGroupName + " to parent group " + parentGroupName;
            return_objects.addElement (msg);
            System.out.println
            ("Done adding child group <" + childGroupName + "> to parent group <"
                    + parentGroupName + "> \n");
        }
        catch ( Exception e ) {
            LoadServerHelper.printMessage
            ("Error detected in createGroupGroup <" + childGroupName + "/"
                    + parentGroupName + ">");
            e.printStackTrace ();
            return false;
        }
        return true;
    }

    /**
     * Get the distinguished name using a specified directory service. This was created to allow createGroupGroup
     * to specify a directory service for both the parent group, and the child group.
     * @param nv Name/value pairs representing the user name and the group name.
     * @param cmd_line command line argument that can be substituted into the load data.
     * @param parentGroupName
     * @param directoryService
     * @return
     * @throws WTException
     * @throws IEException
     * @throws IOException
     */
    private static String getGroupDNByDirectoryService(
                                                       Hashtable<Object, Object> nv, Hashtable<Object, Object> cmd_line,
                                                       String parentGroupName, String directoryService)
                                                               throws WTException, IEException, IOException {

        String previousDefaultAdapter = defaultAdapter;
        String previousUserSearchBase = userSearchBase;

        if (directoryService != null) {
            defaultAdapter = directoryService;
            userSearchBase = DirContext
                    .getJNDIAdapterSearchBase(defaultAdapter);
        }

        String dn = getIteratedGroupDN(nv, cmd_line, parentGroupName);

        // Set these back to their previous values.
        defaultAdapter = previousDefaultAdapter;
        userSearchBase = previousUserSearchBase;

        return dn;
    }

    /**
     * SPR 1180205
     * Changed the implementation to facilitate loading users to default group like Administrators loaded
     * during Windchill Loader specifically for Windchill PDM, since by default the creation base for
     * Windchill PDM maps to the "cn=Windchill PDM" node under the library container instead of the
     * "ou=people" node.
     * @param nv
     * @param cmd_line
     * @param groupName
     * @return
     * @throws WTException
     */
    private static String getIteratedGroupDN(Hashtable<Object, Object> nv, Hashtable<Object, Object> cmd_line,
                                             String groupName) throws WTException {
        WTContainerRef containerRef =
                LoadServerHelper.getTargetContainer (nv, cmd_line);

        String parentGroupDN=null;
        ContainerIterator ci=WTContainerHelper.getAncestors(containerRef);
        while(containerRef!=null){
            parentGroupDN=getGroupDN (groupName, containerRef);
            if(OrganizationServicesHelper.manager.getPrincipalByDN (parentGroupDN)== null){
                if(ci.hasNext()) {
                    containerRef = ci.nextContainerRef();
                }
                else {
                    containerRef=null;
                    parentGroupDN = null;
                }
            }
            else {
                return parentGroupDN;
            }
        }

        return parentGroupDN;

    }

    /* Validates that the given principal name does not contain illegal characters.
     * Note that this method will throw a PrincipalNameException if the name is not valid.
     */
    private static void validatePrincipalName(String name) throws PrincipalNameException, WTException {
        if (!OrganizationServicesHelper.isPrincipalNameValid(name)) {
            LoadServerHelper.printMessage("The name " + name + "is not valid. Participant names cannot contain the following characters: " +
                    OrganizationServicesHelper.PRINCIPAL_NAME_INVALID_CHARS_MSGSTR);
            logger.error("The name " + name + "is not valid. Participant names cannot contain the following characters: " +
                    OrganizationServicesHelper.PRINCIPAL_NAME_INVALID_CHARS_MSGSTR);
            throw new PrincipalNameException("The name " + name + "is not valid. Participant names cannot contain the following characters: " +
                    OrganizationServicesHelper.PRINCIPAL_NAME_INVALID_CHARS_MSGSTR);
        }
    }
}
