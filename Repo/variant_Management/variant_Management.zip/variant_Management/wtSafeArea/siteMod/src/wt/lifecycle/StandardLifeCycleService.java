/* bcwti
 *
 * Copyright (c) 2010 Parametric Technology Corporation (PTC). All Rights Reserved.
 *
 * This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall
 * not disclose such confidential information and shall use it only in accordance
 * with the terms of the license agreement.
 *
 * ecwti
 */

package wt.lifecycle;

import java.io.IOException;
import java.io.Serializable;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.TreeMap;
import java.util.Vector;

import org.apache.log4j.Logger;

import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.server.TypeIdentifierUtility;
import com.ptc.windchill.classproxy.WorkPackageClassProxyFoundation;

import wt.access.AccessControlEvent;
import wt.access.AccessControlHelper;
import wt.access.AccessControlServerHelper;
import wt.access.AccessPermission;
import wt.access.AdHocAccessKey;
import wt.access.AdHocAclSpec;
import wt.access.NotAuthorizedException;
import wt.admin.AdministrativeDomainManagerEvent;
import wt.clients.vc.CheckInOutTaskLogic;
import wt.container.batch.TransactionContainer;
import wt.container.batch.TransactionResult;
import wt.enterprise.RevisionControlled;
import wt.events.KeyedEvent;
import wt.events.summary.ChangeLifecycleStateSummaryEvent;
import wt.facade.ixb.ArchiveHelperConstants;
import wt.fc.Link;
import wt.fc.ObjectIdentifier;
import wt.fc.ObjectReference;
import wt.fc.ObjectVector;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceManagerEvent;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.fc.SourceLinkMapResultProcessor;
import wt.fc.StandardPersistenceManager;
import wt.fc.WTObject;
import wt.fc.WTReference;
import wt.fc.batch.DeleteBatchSpec;
import wt.fc.collections.CollectionsHelper;
import wt.fc.collections.RefreshSpec;
import wt.fc.collections.WTArrayList;
import wt.fc.collections.WTCollection;
import wt.fc.collections.WTHashSet;
import wt.fc.collections.WTKeyedHashMap;
import wt.fc.collections.WTKeyedMap;
import wt.fc.collections.WTList;
import wt.fc.collections.WTSet;
import wt.fc.collections.WTValuedHashMap;
import wt.fc.collections.WTValuedMap;
import wt.fc.collections.WTValuedMap.WTValuedEntry;
import wt.folder.Cabinet;
import wt.folder.CabinetBased;
import wt.folder.Folder;
import wt.folder.FolderEntry;
import wt.folder.FolderHelper;
import wt.htmlutil.HtmlUtil;
import wt.httpgw.GatewayURL;
import wt.iba.value.IBAHolder;
import wt.iba.value.service.IBAValueHelper;
import wt.identity.IdentityFactory;
import wt.inf.container.ClassicContainerNotFoundException;
import wt.inf.container.LookupSpec;
import wt.inf.container.WTContained;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerHelper;
import wt.inf.container.WTContainerRef;
import wt.inf.team.ContainerTeamManaged;
import wt.introspection.ClassInfo;
import wt.introspection.WTIntrospector;
import wt.lifecycle.LifeCycleTemplateNameCache.LifeCycleNameKey;
import wt.locks.LockHelper;
import wt.log4j.LogR;
import wt.maturity.Promotable;
import wt.method.MethodContext;
import wt.method.MethodServerException;
import wt.notify.Notifiable;
import wt.org.OrganizationServicesHelper;
import wt.org.UserNotFoundException;
import wt.org.WTGroup;
import wt.org.WTPrincipal;
import wt.org.WTPrincipalReference;
import wt.org.WTUser;
import wt.ownership.OwnershipHelper;
import wt.pom.DBProperties;
import wt.pom.PersistenceException;
import wt.pom.Transaction;
import wt.pom.TransactionCommitListener;
import wt.preference.PreferenceHelper;
import wt.project.Role;
import wt.projmgmt.admin.Project2;
import wt.query.ClassAttribute;
import wt.query.ClassTableExpression;
import wt.query.CompoundQuerySpec;
import wt.query.ConstantExpression;
import wt.query.ExistsExpression;
import wt.query.KeywordExpression;
import wt.query.NavigateSpec;
import wt.query.NegatedExpression;
import wt.query.OrderBy;
import wt.query.QueryCollationKeyFactory;
import wt.query.QueryException;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.query.SetOperator;
import wt.query.SubSelectExpression;
import wt.query.TableExpression;
import wt.query.WhereExpression;
import wt.rule.RuleConstants;
import wt.rule.init.InitRuleFacade;
import wt.sandbox.SandboxServiceAbandonedEvent;
import wt.sandbox.SandboxServiceCheckinEvent;
import wt.sandbox.SandboxServiceCheckoutEvent;
import wt.series.SeriesRangeSelector;
import wt.services.ManagerException;
import wt.services.ManagerService;
import wt.services.ServiceEventListenerAdapter;
import wt.services.StandardManager;
import wt.session.SessionContext;
import wt.session.SessionHelper;
import wt.session.SessionServerHelper;
import wt.team.RoleHolder2;
import wt.team.Team;
import wt.team.TeamHelper;
import wt.team.TeamManaged;
import wt.team.TeamServerHelper;
import wt.team.TeamServiceEvent;
import wt.team.TeamTemplateReference;
import wt.team.WTRoleHolder2;
import wt.type.TypedUtility;
import wt.util.Cache;
import wt.util.EnumeratorVector;
import wt.util.SortedEnumeration;
import wt.util.WTAttributeNameIfc;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.WTProperties;
import wt.util.WTPropertyVetoException;
import wt.util.WTRuntimeException;
import wt.vc.Iterated;
import wt.vc.OneOffVersioned;
import wt.vc.VersionControlHelper;
import wt.vc.VersionControlServiceEvent;
import wt.vc.VersionForeignKey;
import wt.vc.Versioned;
import wt.vc.config.ConfigHelper;
import wt.vc.config.LatestConfigSpec;
import wt.vc.sessioniteration.SessionEditedIteration;
import wt.vc.sessioniteration.SessionIterationEvent;
import wt.vc.sessioniteration.SessionIterationHelper;
import wt.vc.views.Variation1;
import wt.vc.views.Variation2;
import wt.vc.views.ViewManageable;
import wt.vc.wip.WorkInProgressHelper;
import wt.vc.wip.WorkInProgressServiceEvent;
import wt.vc.wip.WorkInProgressState;
import wt.vc.wip.Workable;
import wt.workflow.definer.WfDefinerHelper;
import wt.workflow.definer.WfProcessDefinition;
import wt.workflow.definer.WfProcessTemplate;
import wt.workflow.definer.WfProcessTemplateMaster;
import wt.workflow.definer.WfProcessTemplateMasterReference;
import wt.workflow.engine.ProcessData;
import wt.workflow.engine.WfEngineHelper;
import wt.workflow.engine.WfEngineServerHelper;
import wt.workflow.engine.WfProcess;
import wt.workflow.engine.WfProcessReference;
import wt.workflow.engine.WfState;
import wt.workflow.engine.WfTransition;
import wt.workflow.work.WorkItem;
import wt.workflow.work.WorkflowHelper;



/**
 * Standard implementation of the life cycle service interfaces
 * <p>
 * Use the <code>newStandardLifeCycleService</code> static factory method(s),
 * not the <code>StandardLifeCycleService</code> constructor, to construct
 * instances of this class.  Instances must be constructed using the static
 * factory(s), in order to ensure proper initialization of the instance.
 * <p>
 *
 *
 * <BR><BR><B>Supported API: </B>true
 * <BR><BR><B>Extendable: </B>false
 *
 * @version   1.0
 **/

public class StandardLifeCycleService extends StandardManager implements LifeCycleService, LifeCycleServiceSvr, Serializable {


    // --- Attribute Section ---


    private static final String RESOURCE = "wt.lifecycle.lifecycleResource";
    private static final String CLASSNAME = StandardLifeCycleService.class.getName();
    private static final Logger LOGGER = LogR.getLogger(StandardLifeCycleService.class.getName());

    /**
     * History event argument for onCreate of a LifeCycleManaged object
     *
     * <BR><BR><B>Supported API: </B>false
     **/
    protected static final String ENTER_PHASE = "Enter_Phase";
    protected static final String EXIT_PHASE = "Exit_Phase";


    /**
     * History event argument for onSubmit for a LifeCycleManaged object. Submit
     * moves the object to the phase gate.
     *
     * <BR><BR><B>Supported API: </B>false
     **/
    protected static final String SUBMIT = "Submit";


    /**
     * History event argument for onPromote of a LifeCycleManaged object. Promote
     * causes the object to transition to a successor phase with an associated
     * state change and application of new business rules - such as access control.
     *
     * <BR><BR><B>Supported API: </B>false
     **/
    protected static final String PROMOTE = "Promote";


    /**
     * History event argument for a onVote of a LifeCycleManaged object.  Vote
     * is the recording of a signature by a reviewer role player.
     *
     * <BR><BR><B>Supported API: </B>false
     **/
    protected static final String VOTE = "Vote";


    /**
     * History onDemote event argument for  a LifeCycleManaged object.  Demote
     * is a reverse promote.
     *
     * <BR><BR><B>Supported API: </B>false
     **/
    protected static final String DEMOTE = "Demote";


    /**
     * History onDeny event argument for a LifeCycleManaged object. Deny removes
     * the object from the gate and returns it to the submitter.
     *
     * <BR><BR><B>Supported API: </B>false
     **/
    protected static final String DENY = "Deny";


    /**
     * History onDrop event argument for a LifeCycleManaged object. Drop causes
     * the object to be removed from the life cycle and its state set to a dropped
     * state.
     *
     * <BR><BR><B>Supported API: </B>false
     **/
    protected static final String DROP = "Drop";


    /**
     * History onReassign event argument for a LifeCycleManaged object. Reassign
     * associates the object to a new life cycle.
     *
     * <BR><BR><B>Supported API: </B>false
     **/
    protected static final String REASSIGN = "Reassign";


    /**
     * Hhistory augment event argument for a LifeCycleManaged object. Augment
     * allows changes to the role principal mapping of the team.
     *
     * <BR><BR><B>Supported API: </B>false
     **/
    protected static final String AUGMENT = "Augment_Life_Cycle";


    /**
     * Hhistory on SetStatet event argument for a LifeCycleManaged object.
     * SetState assigns a particular state to the object.
     *
     * <BR><BR><B>Supported API: </B>false
     **/
    protected static final String SET_STATE = "Set_State";


    /**
     * History onReteam event argument for a LifeCycleManaged object. Reteam
     * associates the object with a new team template.
     *
     * <BR><BR><B>Supported API: </B>false
     **/
    protected static final String RETEAM = "Reteam";


    /**
     * Flag used in the MethodContext to communicate whether default transitions
     * are bypassed.
     *
     * <BR><BR><B>Supported API: </B>false
     **/
    protected static final String BYPASS_DEFAULT_TRANSITIONS = "bypassDefaultTransitions";







    // -- Hashtable that holds Phase to LifeCycleManaged object mappings
    private Cache lifeCycleManagedPhaseMap = new Cache(100);

    // -- Workflow constants
    static final String TOP_PRIORITY = "1";
    static final String PRIMARY_BUSINESS_OBJECT = "primaryBusinessObject";

    // -- TASKS & HTML
    static final String WORK_NOTIFICATION_TEMPLATES = "templates/workNotification";
    static final String URL_CLASSNAME = "wt.enterprise.URLProcessor";
    static final String URL_METHOD_NAME  = "URLTemplateAction";
    static final String ACTION_NAME = "Task";
    static final String PENDING = "PENDING";
    static final String SUBMIT_TASK = "submit";
    static final String REVIEW_TASK = "review";
    static final String PROMOTE_TASK = "promote";

    private static String URLCLASSNAME = "wt.enterprise.URLProcessor";
    private static String URLMETHODNAME = "URLTemplateAction";

    /**
     * This key is used to check in transaction. If this key exists in transaction, we are in package import context.
     */
    private static final String TRX_LISTENER_KEY = "WfTransactionListenerForFBR";

    private static final boolean SKIP_EMIT_EVENT_WHILE_PACKAGE_IMPORT;
    /**
     * Set a boolean true with this key in the method context to disable PRE_CHANGE vetoing
     * on LifeCycleManaged objects.  This is needed by an R7 migrator to relax the constraint
     * which updating lifecycle managed objects identities.
     * <p><b>Example Usage</b>
     * <pre>   MethodContext.getContext().put(DISABLE_PROHIBIT_CHANGE_AT_GATE_VETO, "true");
     *   try {
     *       ...
     *   } finally {
     *      MethodContext.getContext().remove(DISABLE_PROHIBIT_CHANGE_AT_GATE_VETO);
     *   }</pre>
     *
     * <BR><BR><B>Supported API: </B>false
     */
    public static final String DISABLE_PROHIBIT_CHANGE_AT_GATE_VETO = "wt.lifecycle.disableProhibitChangeAtGateVeto";


    // Key to track whether something is happening in the context of a SandboxCheckin
    private static final Object SB_CHECKIN_KEY = new Object();
    // Key to store the target of a merge operation for later comparison.
    private static final Object MERGE_TARGET_KEY = new Object();



    private static final String  DEFAULT_LIFECYCLE;
    private static final boolean ENABLE_HISTORY;
    private static final boolean RETAIN_SIGNATURES;
    private static final boolean RETAIN_CRITERIA;
    private static final String  SERVICE_NAME = "LifeCycleService";
    @SuppressWarnings("unused")
    private static final String  SYSTEM_DOMAIN;
    private static final String  START_WF_PROCESS_IMMEDIATE;
    @SuppressWarnings("unused")
    private static final String  DEFAULT_LC_TEAM;
    private static final long    WORKFLOW_PRIORITY;
    private static final Object UNDO_CHECK_OUT_KEY=new Object();
    private InitialPhaseCache initialPhaseCache = null;
    private LifeCycleTemplateCache lifeCycleTemplateCache = null;
    private AdHocAclSpecCache adHocAclSpecCache = null;
    private CriterionCache criterionCache = null;
    private static LifeCycleTemplateNameCache lifeCycleTemplateNameCache = null;
    private PhaseTemplateCache phaseTemplateCache = null;
    private static final boolean ALLOW_RERESOLUTION_LC_ROLES;
    private static final boolean REPAIR_HISTORY;

    private static final boolean USE_DEFAULT_LC;

    private static final boolean SETSTATECHECK;

	private static final boolean POPULATEIBAATTRIBUTESFORREVISE;

    private LifeCycleTemplateMasterCache lifeCycleTemplateMasterCache = null;

    /**
     * Variable to check whether call is made from reassignMultipleLC()
     */
    private boolean isMultipleReassign=false;
    /**
     * Map to store Object and the process initiator for that object
     */

    // private static final boolean CHECKINVALIDATION;

    private Map objectWFCreatorMap= null;
    private static final Logger logger = LogR.getLogger("wt.lifecycle");
	private static final String LC_MASTER_CACHE = "LC_MASTER_CACHE";

    static
    {
        try
        {
            WTProperties properties = WTProperties.getLocalProperties();

            DEFAULT_LIFECYCLE = properties.getProperty ("wt.lifecycle.defaultLifeCycle","Default");
            ENABLE_HISTORY = properties.getProperty ("wt.lifecycle.enableHistory", true);
            RETAIN_SIGNATURES = properties.getProperty ("wt.lifecycle.retainSignatures", true);
            RETAIN_CRITERIA = properties.getProperty ("wt.lifecycle.retainCriteria", true);
            SYSTEM_DOMAIN = properties.getProperty ("wt.admin.systemDomain", "System");
            START_WF_PROCESS_IMMEDIATE = properties.getProperty ("wt.lifecycle.startWfProcessImmediate",
                    "wt.change2.WTChangeRequest2,wt.doc.WTDocument,wt.part.WTPart,wt.epm.EPMDocument");
            WORKFLOW_PRIORITY = Long.parseLong(properties.getProperty ("wt.lifecycle.defaultWfProcessPriority", TOP_PRIORITY));
            DEFAULT_LC_TEAM = properties.getProperty("wt.lifecycle.defaultTeam","Default LC Team");
            ALLOW_RERESOLUTION_LC_ROLES = properties.getProperty("wt.team.re-resolveRoles", false);
            REPAIR_HISTORY = properties.getProperty("wt.lifecycle.repairHistory", false);

            USE_DEFAULT_LC = properties.getProperty("wt.lifecycle.useDefaultLifeCycle", true);

            SETSTATECHECK = properties.getProperty("wt.lifecycle.setstateCheck", true);
			POPULATEIBAATTRIBUTESFORREVISE = properties.getProperty("wt.lifecycle.populateIBAAttributesForRevise", false);
            //CHECKINVALIDATION =properties.getProperty("wt.lifecycle.byPassCheckinValidationForLifeCycleTemplate", false);

            // prao: Chosen not be documented this property for now.
            SKIP_EMIT_EVENT_WHILE_PACKAGE_IMPORT = properties.getProperty("wt.lifecycle.skipStateEventsOnPackageImport", true);
        }
        catch (Throwable t)
        {
            logger.error(SERVICE_NAME + ": Error reading wt.lifecycle.* properties", t);
            if(logger.isDebugEnabled()){
                logger.debug(t.getLocalizedMessage(), t);
            }
            throw new ExceptionInInitializerError(t);
        }

    }


    // --- Operation Section ---

    /**
     * Returns the conceptual (modeled) name for the class.
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @deprecated
     *
     * @return    String
     **/

    public String getConceptualClassname() {

        return CLASSNAME;
    }

    /**
     * Overrides the registration of all applicable lifecycle service events
     * with the service manager.
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     manager  the ManagerService object used to override the registration of applicable  events with the service manager
     **/

    public void registerEvents( ManagerService manager ) {

        manager.addEventBranch(
                LifeCycleServiceEvent.generateEventKey( LifeCycleServiceEvent.STATE_CHANGE ),
                LifeCycleServiceEvent.class.getName(), LifeCycleServiceEvent.STATE_CHANGE );
        manager.addEventBranch(
                LifeCycleServiceEvent.generateEventKey( LifeCycleServiceEvent.ROLEHOLDER_CHANGE ),
                LifeCycleServiceEvent.class.getName(), LifeCycleServiceEvent.ROLEHOLDER_CHANGE );
        manager.addEventBranch(
                LifeCycleServiceEvent.generateEventKey( LifeCycleServiceEvent.ENABLE_LIFECYCLE ),
                LifeCycleServiceEvent.class.getName(), LifeCycleServiceEvent.ENABLE_LIFECYCLE );
        manager.addEventBranch(
                LifeCycleServiceEvent.generateEventKey( LifeCycleServiceEvent.DISABLE_LIFECYCLE ),
                LifeCycleServiceEvent.class.getName(), LifeCycleServiceEvent.DISABLE_LIFECYCLE );
        manager.addEventBranch(
                LifeCycleServiceEvent.generateEventKey( LifeCycleServiceEvent.SUBMIT ),
                LifeCycleServiceEvent.class.getName(), LifeCycleServiceEvent.SUBMIT );
        manager.addEventBranch(
                LifeCycleServiceEvent.generateEventKey( LifeCycleServiceEvent.PROMOTE ),
                LifeCycleServiceEvent.class.getName(), LifeCycleServiceEvent.PROMOTE );
        manager.addEventBranch(
                LifeCycleServiceEvent.generateEventKey( LifeCycleServiceEvent.VOTE ),
                LifeCycleServiceEvent.class.getName(), LifeCycleServiceEvent.VOTE );
        manager.addEventBranch(
                LifeCycleServiceEvent.generateEventKey( LifeCycleServiceEvent.DEMOTE ),
                LifeCycleServiceEvent.class.getName(), LifeCycleServiceEvent.DEMOTE );
        manager.addEventBranch(
                LifeCycleServiceEvent.generateEventKey( LifeCycleServiceEvent.DENY ),
                LifeCycleServiceEvent.class.getName(), LifeCycleServiceEvent.DENY );
        manager.addEventBranch(
                LifeCycleServiceEvent.generateEventKey( LifeCycleServiceEvent.DROP ),
                LifeCycleServiceEvent.class.getName(), LifeCycleServiceEvent.DROP );
        manager.addEventBranch(
                LifeCycleServiceEvent.generateEventKey( LifeCycleServiceEvent.REASSIGN ),
                LifeCycleServiceEvent.class.getName(), LifeCycleServiceEvent.REASSIGN );
        manager.addEventBranch(
                LifeCycleServiceEvent.generateEventKey( LifeCycleServiceEvent.AUGMENT ),
                LifeCycleServiceEvent.class.getName(), LifeCycleServiceEvent.AUGMENT );
        manager.addEventBranch(
                LifeCycleServiceEvent.generateEventKey( LifeCycleServiceEvent.SET_STATE ),
                LifeCycleServiceEvent.class.getName(), LifeCycleServiceEvent.SET_STATE );

    }

    /**
     * Dispatches a LifeCycleServiceEvent that includes the event type and
     * target..
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     eventType  The name of the PersistentManagerEvent type.
     * @param     object  The target of the persistable operation.
     * @exception wt.util.WTException
     * @exception wt.util.WTPropertyVetoException
     **/

    protected void dispatchVetoableEvent( String eventType, Persistable object )
            throws WTException, WTPropertyVetoException {

        LifeCycleServiceEvent event =
                new LifeCycleServiceEvent( this, eventType, (Persistable) object );
        if (logger.isTraceEnabled())
        {
            logger.trace(">>In StandardLifeCycleService...dispatchVetoableEvent() method");
            logger.trace("--eventType -"+eventType+"--event.getEventKey()"+event.getEventKey());
        }

        getManagerService().dispatchVetoableEvent( event, event.getEventKey() );

    }

    /**
     * Dispatches a LifeCycleServiceEvent that includes the event type and
     * target.
     *
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     eventType  The name of the PersistentManagerEvent type.
     * @param     objectRef  The target of the persistable operation.
     * @exception wt.util.WTException
     * @exception wt.util.WTPropertyVetoException
     **/

    protected void dispatchEvent( String eventType, ObjectReference objectRef )
            throws WTException, WTPropertyVetoException {

        LifeCycleServiceEvent event =
                new LifeCycleServiceEvent( this, eventType, (ObjectReference) objectRef);
        getManagerService().dispatchVetoableEvent( event, event.getEventKey() );

    }

    /**
     * Dispatches a LifeCycleServiceEventthat includes the event type and
     * targets (i.e., LifeCyclemanaged objects).
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     eventType  The name of the LifeCycleServiceEvent type.
     * @param     objects  The targets of the lifecycle service event
     * @exception wt.util.WTException
     * @exception wt.util.WTPropertyVetoException
     **/

    protected void dispatchVetoableMultiObjectEvent( String eventType, WTCollection objects )
            throws WTException, WTPropertyVetoException {
        LifeCycleServiceEvent event =
                new LifeCycleServiceEvent( this, eventType, objects );

        getManagerService().dispatchVetoableMultiObjectEvent( event, event.getEventKey() );
    }

    /**
     * Default factory for the class.
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @return    StandardLifeCycleService
     * @exception wt.util.WTException
     **/

    public static StandardLifeCycleService newStandardLifeCycleService()
            throws WTException {

        StandardLifeCycleService instance = new StandardLifeCycleService();
        instance.initialize();
        return instance;
    }

    /**
     * Submit the object for review.
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     object  the LifeCycleManaged object that should be submitted for approval
     * @return    LifeCycleManaged
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public LifeCycleManaged submitForApproval( LifeCycleManaged object )
            throws WTException, LifeCycleException {
        LifeCycleManaged lcmobject = object;
        if (logger.isTraceEnabled())
        {
            logger.trace(">>In StandardLifeCycleService...submitForApproval() method");
            logger.trace("getOid"+getOid(object));
        }

        // -- Validate the submit before doing it
        lcmobject = validateSubmitForApproval(lcmobject);

        lcmobject = doSubmit(lcmobject);

        if (logger.isTraceEnabled())
            logger.trace(">>Out StandardLifeCycleService...submitForApproval() method");

        return lcmobject;

    }

    /**
     * Record a signer disposition  (Yes/No) and any comments.
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     object  the LifeCycleManaged object that should be voted on
     * @param     signature  the signature object where the vote results should be recorded
     * @return    LifeCycleSignature
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public LifeCycleSignature vote( LifeCycleManaged object, LifeCycleSignature signature )
            throws WTException, LifeCycleException {
        LifeCycleSignature lcssignature = signature;
        // -- Record a role player vote
        // -- Note: Assumption is that the signature 'vote' attribute has been set

        if (logger.isTraceEnabled())
        {
            logger.trace(">>In StandardLifeCycleService...vote(LifeCycleManaged object, LifeCycleSignature signature ) method");
            logger.trace("Enter vote:"+getOid(object)+
                    "Vote:"+signature.isVote()+" for role "+signature.getRoleName());
        }

        /* 1. Validate vote */
        lcssignature = validateVote(object,lcssignature);

        /* 2. Save or Update the signature */
        Transaction trx = new Transaction();
        try {

            trx.start();
            if (PersistenceHelper.isPersistent((Persistable)lcssignature)) {
                PersistenceServerHelper.manager.update(lcssignature);
            }
            else {
                PersistenceServerHelper.manager.insert(lcssignature);
            }

            // 3. Dispatch the vote event
            try {
                dispatchVetoableEvent( LifeCycleServiceEvent.VOTE, object );
            }
            catch (WTPropertyVetoException wtpve) {

                if(logger.isDebugEnabled()){
                    logger.debug(wtpve.getLocalizedMessage(), wtpve);
                }
                throw new LifeCycleException (wtpve);
            }

            trx.commit();
            trx = null;
        }
        catch (PersistenceException dbError) {

            if(logger.isDebugEnabled()){
                logger.debug(dbError.getLocalizedMessage(), dbError);
            }
            throw new LifeCycleException(dbError);
        }
        catch (WTException wex) {

            if(logger.isDebugEnabled()){
                logger.debug(wex.getLocalizedMessage(), wex);
            }
            throw new LifeCycleException(wex);
        }
        finally {
            if (trx != null)
                trx.rollback();
        }

        if (logger.isTraceEnabled())
            logger.trace(">>In StandardLifeCycleService...vote(LifeCycleManaged object, LifeCycleSignature signature ) method");

        return lcssignature;

    }

    /**
     * Move the object to the next phase.
     * <p>
     * The doPromote method is executed
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     object  the LifeCycleManaged object that should be promoted
     * @param     signature  the Signature object where the results and information about the promote should be recorded
     * @return    LifeCycleManaged
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public LifeCycleManaged promote( LifeCycleManaged object, LifeCycleSignature signature )
            throws WTException, LifeCycleException {
        LifeCycleManaged lcmobject = object;
        LifeCycleSignature lcssignature = signature;
        if (logger.isTraceEnabled())
        {
            logger.trace(">>In StandardLifeCycleService...promote(LifeCycleManaged object, LifeCycleSignature signature) method");
            logger.trace("=> promote: " + getOid(object));
        }
        /* 1. Validate promote */
        // -- Effective principal must be a promoter
        @SuppressWarnings("unused")
        WTPrincipal user = SessionHelper.manager.getPrincipal();
        lcssignature = validatePromote (lcmobject,lcssignature);
        // do the promote
        lcmobject = doPromote (lcmobject,lcssignature);
        if (logger.isTraceEnabled())
            logger.trace(">>Out StandardLifeCycleService...promote(LifeCycleManaged object, LifeCycleSignature signature) method");
        return lcmobject;
    }

    /**
     * Move the object to the previous phase.
     * <p>
     * The doDemote method is executed
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     object  the LifeCycleManaged object that should be demoted.
     * @param     signature  the Signature object where the results and information about the demote should be recorded
     * @return    LifeCycleManaged
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public LifeCycleManaged demote( LifeCycleManaged object, LifeCycleSignature signature )
            throws WTException, LifeCycleException {
        LifeCycleManaged lcmobject = object;
        LifeCycleSignature lcmsignature = signature;
        if (logger.isTraceEnabled()){
            logger.trace(">>In StandardLifeCycleService...demote(LifeCycleManaged object, LifeCycleSignature signature ) method");
            logger.trace("Enter demote:"+getOid(object));
        }

        /* 1. Validate demote */
        // -- Effective principal must be a promoter
        @SuppressWarnings("unused")
        WTPrincipal user = SessionHelper.manager.getPrincipal();
        lcmsignature = validateDemote(lcmobject,lcmsignature);

        lcmobject = doDemote(lcmobject,lcmsignature);

        if(logger.isDebugEnabled())
            logger.debug("Exit Demote");

        if (logger.isTraceEnabled())
            logger.trace(">>Out StandardLifeCycleService...demote(LifeCycleManaged object, LifeCycleSignature signature ) method");
        return object;

    }

    /**
     * Remove the object from the gate and return the object to the submitter
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     object  the LifeCycleManaged object that should be denied
     * @param     signature  the Signature object that the result and information about the deny is recorded
     * @return    LifeCycleManaged
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public LifeCycleManaged deny( LifeCycleManaged object, LifeCycleSignature signature )
            throws WTException, LifeCycleException {
        LifeCycleManaged lcmobject = object;
        LifeCycleSignature lcmsignature = signature;
        if (logger.isTraceEnabled()){
            logger.trace(">>In StandardLifeCycleService...deny( LifeCycleManaged object, LifeCycleSignature signature ) method");
            logger.trace("Enter deny:"+getOid(object));
        }

        /* 1. Validate deny */
        // -- Effective principal must be a promoter
        @SuppressWarnings("unused")
        WTPrincipal user = SessionHelper.manager.getPrincipal();
        lcmsignature = validateDeny(lcmobject,lcmsignature);

        lcmobject = doDeny(lcmobject,lcmsignature);

        if (logger.isTraceEnabled())
            logger.trace(">>Out StandardLifeCycleService...deny( LifeCycleManaged object, LifeCycleSignature signature ) method");

        return lcmobject;

    }

    /**
     * Transition the object to an end state
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     object  the LifeCycleManaged object that should be moved to a final/dropped state
     * @param     signature  the LifeCycleSignature object records information about the drop process
     * @return    LifeCycleManaged
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public LifeCycleManaged drop( LifeCycleManaged object, LifeCycleSignature signature )
            throws WTException, LifeCycleException {
        LifeCycleManaged lcmobject = object;
        LifeCycleSignature lcssignature = signature;
        if (logger.isTraceEnabled()){
            logger.trace(">>In StandardLifeCycleService...drop(LifeCycleManaged object, LifeCycleSignature signature) method");
            logger.trace("-- getOid:"+getOid(object));
        }

        /* 1. Validate drop */
        // -- Effective principal must be a promoter
        @SuppressWarnings("unused")
        WTPrincipal user = SessionHelper.manager.getPrincipal();
        lcssignature = validateDrop(lcmobject,lcssignature);

        lcmobject = doDrop(lcmobject,lcssignature);

        if (logger.isTraceEnabled())
            logger.trace(">>Out StandardLifeCycleService...drop(LifeCycleManaged object, LifeCycleSignature signature) method");

        return lcmobject;

    }

    /**
     * Reassign a life cycle managed object to a new life cycle.
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     object  the LifeCycleManaged object that should be assigned to a new life cycle
     * @param     lctRef  a reference to a LifeCycleTemplate, the LifeCycleTemplate that the object should be reassigned to
     * @return    LifeCycleManaged
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public LifeCycleManaged reassign( LifeCycleManaged object, LifeCycleTemplateReference lctRef )
            throws WTException, LifeCycleException {
        return reassign (object, lctRef, null);
    }

    /**
     * Answer the LifeCycleTemplate the object is assigned to
     *
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @deprecated in R4.0 - Use myObject.getLifeCycleTemplate() instead.
     *
     * @param     object  the LifeCycleManaged object used as search criteria in the retrieval of the LifeCycleTemplate
     * @return    LifeCycleTemplate
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public LifeCycleTemplate getLifeCycleTemplate( LifeCycleManaged object )
            throws WTException, LifeCycleException {

        LifeCycleTemplate lct = null;
        LifeCycleState state = null;
        if (PersistenceHelper.isPersistent((Persistable)object)) {
            state = object.getState();
            lct = (LifeCycleTemplate)state.getLifeCycleId().getObject();
        }
        return lct;
    }

    /**
     * Answer a vector of LifeCycleSignature for the current phase based
     * on object, user and role.
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     object  the LifeCycleManaged object used as search criteria in the retrieval of signature objects
     * @param     user  the WTUser object used as search criteria in the retrieval of Signature objects
     * @param     role  the Role object used as search criteria in the retrieval of the Signature objects
     * @return    Vector
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    @SuppressWarnings("deprecation")
    public Vector getSignatures( LifeCycleManaged object, WTUser user, Role role )
            throws WTException, LifeCycleException {


        LifeCycleSignature lcs = null;
        Vector lcsVector = new Vector();

        if (logger.isTraceEnabled()){
            logger.trace(">>In StandardLifeCycleService...getSignatures(LifeCycleManaged object, WTUser user, Role role ) method");
            logger.trace("Enter getSignatures:"+getOid(object)+
                    " for:"+role+" for:"+user.getFullName());
        }

        try {
            // -- Setup search on object
            SearchCondition sc0 = LifeCycleSignature.getSearchCondition(object);

            // -- Setup search by role
            SearchCondition sc1 = LifeCycleSignature.getSearchCondition(role);

            // -- Build the query spec
            QuerySpec qs = new QuerySpec(LifeCycleSignature.class);
            qs.appendWhere(sc0);
            qs.appendAnd();
            qs.appendWhere(sc1);
            qs.appendAnd();

            // -- This adds user and phase criteria
            lcsVector = getPhaseSignatures(object,user,qs);
        }
        catch (Exception e) {
            if(logger.isDebugEnabled()){
                logger.debug(e.getLocalizedMessage(), e);
            }
            throw new WTException(e);
        }

        if (logger.isTraceEnabled()){
            logger.trace("Exit getSignatures with "+lcsVector.size()+ " signatures");
            logger.trace(">>Out StandardLifeCycleService...getSignatures(LifeCycleManaged object, WTUser user, Role role ) method");
        }

        return lcsVector;

    }

    /**
     * Answer a vector of LifeCycleSignature for the current phase based
     * on object and role.
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     object  the LifeCycleManaged object used as search criteria in the retrieval of the Signature objects
     * @param     role  the Role object used as search criteria in the retrieval of Signature objects
     * @return    Vector
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    @SuppressWarnings("deprecation")
    public Vector getSignatures( LifeCycleManaged object, Role role )
            throws WTException, LifeCycleException {

        @SuppressWarnings("unused")
        LifeCycleSignature lcs = null;
        Vector lcsVector = new Vector();

        if (logger.isTraceEnabled()){
            logger.trace(">>In StandardLifeCycleService...getSignatures(LifeCycleManaged object, Role role ) method");
            logger.trace("Enter getSignatures:"+getOid(object)+
                    " for:"+role);
        }

        try {
            // -- Setup search on object
            SearchCondition sc0 = LifeCycleSignature.getSearchCondition(object);

            // -- Setup search by role
            SearchCondition sc1 = LifeCycleSignature.getSearchCondition(role);

            // -- Build the query spec
            QuerySpec qs = new QuerySpec (LifeCycleSignature.class);
            qs.appendWhere(sc0);
            qs.appendAnd();
            qs.appendWhere(sc1);
            qs.appendAnd();

            // -- This adds user and phase criteria
            lcsVector = getPhaseSignatures(object, null, qs);
        }
        catch (Exception e) {
            if(logger.isDebugEnabled()){
                logger.debug(e.getLocalizedMessage(), e);
            }
            throw new WTException(e);
        }

        if (logger.isTraceEnabled())
            logger.trace(">>Out StandardLifeCycleService...getSignatures(LifeCycleManaged object, Role role ) method");

        return lcsVector;

    }

    /**
     * Answer a vector of signatures for all roles for the object for the
     * current phase.
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     object  the LifeCycleManaged object used as search criteria in the retrieval of Signature objects
     * @return    Vector
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    @SuppressWarnings("deprecation")
    public Vector getSignatures( LifeCycleManaged object )
            throws WTException, LifeCycleException {

        @SuppressWarnings("unused")
        LifeCycleSignature lcs = null;
        Vector lcsVector = new Vector();

        if (logger.isTraceEnabled()){
            logger.trace(">>In StandardLifeCycleService...getSignatures(LifeCycleManaged object ) method");
            logger.trace("Enter getSignatures:"+getOid(object));
        }

        try {
            QuerySpec qs = new QuerySpec (LifeCycleSignature.class);

            //Need to get it for all previous iterations
            if (object instanceof Iterated) {
                QueryResult results = VersionControlHelper.service.iterationsOf((Iterated)object);
                qs.appendOpenParen();
                int count=0;
                while (results.hasMoreElements()) {
                    if (count++ > 0)
                        qs.appendOr();
                    // -- Setup search on object
                    SearchCondition sc0 = LifeCycleSignature.getSearchCondition((LifeCycleManaged)results.nextElement());
                    qs.appendWhere(sc0);
                }
                qs.appendCloseParen();
            }
            else {
                // -- Setup search on object
                SearchCondition sc0 = LifeCycleSignature.getSearchCondition(object);
                qs.appendWhere(sc0);
            }

            qs.appendAnd();

            // -- This adds phase criteria
            lcsVector = getPhaseSignatures(object,null,qs);

        }
        catch (Exception e) {
            if(logger.isDebugEnabled()){
                logger.debug(e.getLocalizedMessage(), e);
            }
            throw new WTException(e);
        }

        if (logger.isTraceEnabled())
            logger.trace(">>Out StandardLifeCycleService...getSignatures(LifeCycleManaged object ) method");

        return lcsVector;

    }

    /**
     * Answer a vector of LifeCycleSignatures based on supplied object &
     * user.
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     object  The LifeCycleManaged object used as search criteria in the retrieval of Signature objects
     * @param     user  the WTUser object used as search criteria in the retrieval of Signature objects
     * @return    Vector
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    @SuppressWarnings("deprecation")
    public Vector getSignatures( LifeCycleManaged object, WTUser user )
            throws WTException, LifeCycleException {

        Vector lcsVector = new Vector();

        if (logger.isTraceEnabled()){
            logger.trace(">>In StandardLifeCycleService...getSignatures(LifeCycleManaged object, WTUser user  ) method");
            logger.trace("Enter getSignatures:"+getOid(object)+
                    " for:"+user.getName());
        }

        try {
            QuerySpec qs = new QuerySpec (LifeCycleSignature.class);

            //Need to get it for all previous iterations
            if (object instanceof Iterated) {
                QueryResult results = VersionControlHelper.service.iterationsOf((Iterated)object);
                qs.appendOpenParen();
                int count=0;
                while (results.hasMoreElements()) {
                    if (count++ > 0)
                        qs.appendOr();
                    // -- Setup search on object
                    SearchCondition sc0 = LifeCycleSignature.getSearchCondition((LifeCycleManaged)results.nextElement());
                    qs.appendWhere(sc0);
                }
                qs.appendCloseParen();
            }
            else {
                // -- Setup search on object
                SearchCondition sc0 = LifeCycleSignature.getSearchCondition(object);
                qs.appendWhere(sc0);
            }

            qs.appendAnd();

            // -- This adds user and phase criteria
            lcsVector = getPhaseSignatures(object,user,qs);
        }
        catch (Exception e) {
            if(logger.isDebugEnabled()){
                logger.debug(e.getLocalizedMessage(), e);
            }
            throw new WTException(e);
        }

        if (logger.isTraceEnabled())
            logger.trace(">>Out StandardLifeCycleService...getSignatures(LifeCycleManaged object, WTUser user  ) method");

        return lcsVector;

    }

    public Vector getSignatures( LifeCycleManaged currentObject, Vector<LifeCycleManaged> iterations )
            throws WTException, LifeCycleException {

        LifeCycleSignature lcs = null;
        Vector lcsVector = new Vector();

        if ( logger.isDebugEnabled() )
            logger.debug("Enter getSignatures(iterations) :"+iterations);

        try {
            QuerySpec qs = new QuerySpec (LifeCycleSignature.class);

            //Need to get it for all previous iterations
            SearchCondition sc0 = LifeCycleSignature.getSearchCondition(iterations);
            qs.appendOpenParen();
            qs.appendWhere(sc0);
            qs.appendCloseParen();
            qs.appendAnd();

            // -- This adds phase criteria
            lcsVector = getPhaseSignatures(currentObject,null,qs);

        }
        catch (Exception e) {
            throw new WTException(e);
        }

        logger.debug("Exit getSignatures");

        return lcsVector;

    }

    /**
     * Answer a vector of signatures for all roles for the object for the
     * current phase and all preceeding phases.
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     object  the LifeCycleManaged object used as search criteria in the retrieval of Signature objects
     * @return    Vector
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    @SuppressWarnings("deprecation")
    public Vector getAllSignatures( LifeCycleManaged object )
            throws WTException, LifeCycleException {

        Vector lcsVector = new Vector();

        if (logger.isTraceEnabled()){
            logger.trace(">>Out StandardLifeCycleService...getAllSignatures(LifeCycleManaged object ) method");
            logger.trace("Enter getAllSignatures:"+getOid(object));
        }

        // -- Get the Life Cycle Signatures associated with the current phase object
        lcsVector = getSignatures(object);

        // -- Retrieve the History objects
        QueryResult qr = LifeCycleHelper.service.getHistory(object);
        if (logger.isTraceEnabled())
            logger.trace("Found " + qr.size() + " LifeCycleHistory objects");

        final boolean debugEnabeld = logger.isDebugEnabled();
        // -- For each history object found, retrieve the signatures
        while (qr.hasMoreElements()) {
            LifeCycleHistory lifeCycleHistory = (LifeCycleHistory)qr.nextElement();
            QuerySpec qs = new QuerySpec (wt.lifecycle.LifeCycleSignature.class, wt.lifecycle.SignatureHistory.class);
            qs.appendOrderBy( wt.lifecycle.LifeCycleSignature.class,
                    WTAttributeNameIfc.CREATE_STAMP_NAME,
                    true);
            QueryResult results = PersistenceHelper.manager.navigate(
                    lifeCycleHistory,
                    SignatureHistory.SIGNATURE_ROLE,
                    qs,
                    true);

            if (logger.isTraceEnabled())
                logger.trace("Found " + results.size() + " LifeCycleSignature objects");

            // -- Add the signature objects to the vector
            while (results.hasMoreElements()) {
                lcsVector.addElement((LifeCycleSignature)(results.nextElement()));
            }

        }

        if (logger.isTraceEnabled())
            logger.trace(">>Out StandardLifeCycleService...getAllSignatures(LifeCycleManaged object ) method");

        return lcsVector;

    }

    /**
     * Answer a vector of signatures for all roles for all iterations of object for the
     * current phase and all preceeding phases.
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     currentObject  the LifeCycleManaged object used as search criteria in the retrieval of Signature objects
     * @param     iterations all iterations of currentObject
     * @return    Vector
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/
    public Vector getAllSignaturesAllIteration(LifeCycleManaged currentObject, Vector<LifeCycleManaged> iterations) throws WTException, LifeCycleException {
        Vector lcsVector = new Vector();
        if ( logger.isDebugEnabled() )
            logger.debug("Enter getAllSignaturesAllIteration:"+getOid(currentObject));

        // -- Get the Life Cycle Signatures associated with the current phase object
        lcsVector = getSignatures(currentObject, iterations);

        // -- Retrieve the History objects
        HashMap map = LifeCycleHelper.service.getHistoryForIterations(new ArrayList(iterations));

        if ( logger.isDebugEnabled() ) {
            for(Object key:map.keySet().toArray()){
                List list = (List)map.get(key);
                logger.debug("Found " + list.size() + " LifeCycleHistory objects for "+key);
            }

        }

        Vector allIterationHistory = new Vector();
        for(Object value : map.values().toArray()){
            List list = (List)value;
            allIterationHistory.addAll(list);
        }

        // -- For each history object found, retrieve the signatures
        for (Object lch : allIterationHistory.toArray()) {
            LifeCycleHistory lifeCycleHistory = (LifeCycleHistory)lch;
            QuerySpec qs = new QuerySpec (wt.lifecycle.LifeCycleSignature.class, wt.lifecycle.SignatureHistory.class);
            qs.appendOrderBy( wt.lifecycle.LifeCycleSignature.class,
                    WTAttributeNameIfc.CREATE_STAMP_NAME,
                    true);
            QueryResult results = PersistenceHelper.manager.navigate(
                    lifeCycleHistory,
                    SignatureHistory.SIGNATURE_ROLE,
                    qs,
                    true);

            if ( logger.isDebugEnabled() )
                logger.debug("Found " + results.size() + " LifeCycleSignature objects");

            // -- Add the signature objects to the vector
            while (results.hasMoreElements()) {
                lcsVector.addElement((LifeCycleSignature)(results.nextElement()));
            }

        }

        logger.debug("Exit getAllSignaturesAllIteration");

        return lcsVector;
    }


    /**
     * Answer an initialized but unpersisted  LifeCycleSignature instance
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     object  the Persistable object that the LifeCycleSignature is associated to
     * @param     signer  the WTPrincipal who did the work
     * @param     comments  any comments the signer recorded about the work accomplished
     * @param     role  the Role object, used to represent the role the signer was participating as
     * @param     vote  a boolean signer designation, used to record the disposition
     * @return    LifeCycleSignature
     * @exception wt.util.WTException
     **/

    public LifeCycleSignature createLifeCycleSignature( Persistable object, WTPrincipal signer, String comments, Role role, boolean vote )
            throws WTException {

        // -- Answer an initialized but unpersisted LifeCycleSignature
        // -- This method is needed to keep server classes from be transported to the client

        if (logger.isTraceEnabled())
            logger.trace("Enter createLifeCycleSignature on "+getOid(object)+
                    "for "+signer.getName()+" who is voting "+vote);

        LifeCycleSignature s = LifeCycleSignature.newLifeCycleSignature(object,signer,comments,role,vote);

        if (logger.isTraceEnabled())
            logger.trace("Exit createLifeCycleSignature");

        return s;

    }

    /**
     * Answer a vector of LifeCycleSignatures
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     object  The LifeCycleManaged object used as search criteria in the retrieval of Signature objects
     * @return    Vector
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/


    public Vector getReviewerList( LifeCycleManaged object )
            throws WTException, LifeCycleException {

        Vector lcsVector = new Vector();

        if (logger.isTraceEnabled())
            logger.trace("Enter getReviewerList");

        /* 1. Get the completed signatures for this object */
        Vector signatures = getSignatures(object);

        /* 2. Get the work items for this object */
        Enumeration items = WorkflowHelper.service.getUncompletedWorkItems((Persistable)object, REVIEW_TASK);

        /* 3. Merge the two vectors. If a signature does not already exist,
         *    create an 'uncompleted' signature.  Put these signatures in the vector first.
         */
        WorkItem wi = null;
        LifeCycleSignature s = null;
        while (items.hasMoreElements()) {
            wi = (WorkItem)items.nextElement();
            //Only add wi that on incomplete.  Complete wi are from other Review tasks or already have a signature.
            if (wi.isComplete())
                continue;
            String princName = null;
            WTPrincipal p = null;
            try {
                p = OwnershipHelper.getOwner(wi);
                princName = p.getName();
            }
            catch (WTRuntimeException wtre) {
                Throwable nestedException=wtre.getNestedThrowable();
                if(logger.isDebugEnabled()){
                    logger.debug(wtre.getLocalizedMessage(), wtre);
                }
                // We want to know if the user has access to the object.  If not, bubble the exception back up
                if (nestedException != null && nestedException instanceof wt.access.NotAuthorizedException) {
                    @SuppressWarnings("unused")
                    Locale locale = SessionHelper.manager.getLocale();
                    princName = WTMessage.getLocalizedMessage("wt.access.accessResource",
                            wt.access.accessResource.SECURED_INFORMATION,
                            null);
                }
                else {throw wtre;}
            }
            Role aRole = wi.getRole();
            if ( (p instanceof WTGroup) || ((getSignatures(object, (WTUser)p, aRole)).size() == 0) ) {
                // -- create a 'display' signature to represent uncompleted work

                s = LifeCycleSignature.newLifeCycleSignature(object,
                        princName,
                        PENDING,
                        wi.getRole(),
                        false);
                lcsVector.addElement(s);
            }
        }

        Enumeration enumer = signatures.elements();
        while (enumer.hasMoreElements()){
            lcsVector.addElement((LifeCycleSignature)(enumer.nextElement()));
        }
        if (logger.isTraceEnabled())
            logger.trace("Enter getReviewerList");
        return lcsVector;

    }

    /**
     * Answer a vector of LifeCycleSignatures
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     object  The LifeCycleManaged object used as search criteria in the retrieval of Signature objects
     * @return    Vector
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/


    public Vector getAllReviewerList( LifeCycleManaged object )
            throws WTException, LifeCycleException {

        Vector lcsVector = new Vector();

        if (logger.isTraceEnabled())
            logger.trace("Enter getAllReviewerList");

        /* 1. Get the completed signatures for this object */
        Vector signatures = getAllSignatures(object);

        /* 2. Get the work items for this object */
        Enumeration items = WorkflowHelper.service.getUncompletedWorkItems((Persistable)object, REVIEW_TASK);

        /* 3. Merge the two vectors. If a signature does not already exist,
         *    create an 'uncompleted' signature.
         */
        WorkItem wi = null;
        LifeCycleSignature s = null;
        while (items.hasMoreElements()) {
            wi = (WorkItem)items.nextElement();
            WTPrincipal p = OwnershipHelper.getOwner(wi);
            Role aRole = wi.getRole();
            if ( (p instanceof WTGroup) || ((getSignatures(object, (WTUser)p, aRole)).size() == 0) ) {
                // -- create a 'display' signature to represent uncompleted work

                s = LifeCycleSignature.newLifeCycleSignature(object,
                        p.getName(),
                        PENDING,
                        wi.getRole(),
                        false);
                lcsVector.addElement(s);
            }
        }

        Enumeration enumer = signatures.elements();
        while (enumer.hasMoreElements()){
            lcsVector.addElement((LifeCycleSignature)(enumer.nextElement()));
        }
        if (logger.isTraceEnabled())
            logger.trace("Exit getAllReviewerList");
        return lcsVector;
    }

    /**
     * Answer a vector of strings - role names for the current phase
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     object  the LifeCycleManaged object used as search criteria in the retrieval of Role objects
     * @return    Vector
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/


    public Vector getRoles( LifeCycleManaged object )
            throws WTException, LifeCycleException {

        if (logger.isTraceEnabled())
            logger.trace("Enter getRoles:"+getOid(object));

        Vector roles = new Vector();

        if (object.isLifeCycleBasic()) {
            if (logger.isTraceEnabled() )
                logger.trace("getRoles: Object is basic lifecycle managed. Return empty vector.");
            return roles;
        }

        try {
            Team team=(Team)object.getTeamId().getObject();
            Enumeration e = team.getRoles().elements();

            final boolean debugEnabled =  logger.isDebugEnabled();
            while (e.hasMoreElements()) {
                Role r = (Role)(e.nextElement());
                if (logger.isTraceEnabled())
                    logger.trace("Found role:"+ r.toString());
                roles.addElement(r);
            }
        }
        catch (Exception e) {
            if(logger.isDebugEnabled()){
                logger.debug(e.getLocalizedMessage(), e);
            }
            throw new WTException(e);
        }
        if (logger.isTraceEnabled())
            logger.trace("Exit getRoles");

        return roles;

    }

    /**
     * Answer a vector of Criterion objects for the current phase
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     object  the LifeCycleManaged object used as search criteria in the retrieval of Criterion objects
     * @return    Vector
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/


    public Vector getCriteria( LifeCycleManaged object )
            throws WTException, LifeCycleException {

        if (logger.isTraceEnabled())
            logger.trace("Enter getCriteria:"+getOid(object));

        if (object.isLifeCycleBasic())
            return new Vector();
        Vector criteria = null;
        Phase aPhase=null;
        try {
            aPhase = getCurrentPhase(object);
            criteria = getPhaseCriteria(aPhase);
        }
        catch (Exception e) {
            if(logger.isDebugEnabled()){
                logger.debug(e.getLocalizedMessage(), e);
            }
            throw new WTException(e);
        }

        if (logger.isTraceEnabled()) {
            logger.trace("Exit getCriteria");
        }

        return criteria;

    }

    /**
     * Store or update a LifeCycleTemplate. This method accepts and processes
     * a batch container of persistence assertions.
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     aTran  a TransactionContainer that contains a set of LifeCycleTemplate, PhaseTemplate, AdHocAclSpec, Criterion and Transition assertions that need to be applied against one or more LifeCycleTemplate objects
     * @return    TransactionResult
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public TransactionResult saveLifeCycleTemplate( TransactionContainer aTran )
            throws WTException, LifeCycleException {
        return LifeCycleDefinitionHandler.processLifeCycleTemplateTransaction (aTran);

    }

    /**
     * Save/Update a vector of Criterion objects
     *
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @deprecated at R5.0
     *
     * @param     object  the LifeCycleManged object that the associated criteria should be applied to
     * @param     criteria  a Vector of Criterion objects that should be applied to the LifeCycleManaged object
     * @return    Vector
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/


    public Vector saveCriteria( LifeCycleManaged object, Vector criteria )
            throws WTException, LifeCycleException {

        Vector answer = new Vector();

        Phase aPhase = getCurrentPhase(object);
        answer = replaceCriteria(aPhase,criteria);

        return answer;

    }

    /**
     * Answer an array of State objects
     *
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @deprecated in R4.0.  Use the appropriate call on the EnumeratedType
     * object to get these values.
     *
     * @return    State[]
     * @exception wt.util.WTException
     **/

    public State[] allStates()
            throws WTException {

        return State.getStateSet();

    }

    /**
     * Answer an array of State objects declared selectable
     *
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @deprecated in R4.0.  Use the appropriate call on the EnumeratedType
     * object to get these values.
     *
     * @return    State[]
     * @exception wt.util.WTException
     **/


    public State[] selectableStates()
            throws WTException {

        if (logger.isTraceEnabled())
            logger.trace("Enter selectableStates");

        State states[] = allStates();
        if (logger.isTraceEnabled())
            logger.trace("--states size"+states.length);
        // -- Build a filtered array
        int ii = 0;
        int jj = 0;
        Vector v = new Vector();
        for (ii=0;ii<states.length;ii++) {
            if (states[ii].isSelectable()) {
                v.addElement(states[ii]);
                jj++;
            }
        }

        ii = 0;
        State filteredArray[] = new State[jj];
        Enumeration e = v.elements();
        while (e.hasMoreElements()) {
            filteredArray[ii]=(State)e.nextElement();
            ii++;
        }

        if (logger.isTraceEnabled())
            logger.trace("Exit selectableStates with "+filteredArray.length+" states");

        return filteredArray;

    }

    /**
     * Answer an enumeration of LifeCycleHistory objects based on supplied
     * object.
     * <p>
     * Usage:
     * <p>
     * <code>
     * LifeCycleHistory aHistory = null;
     * Enumeration e = LifeCycleHelper.service.getHistory(aLifeCycleManaged);
     * while (e.hasMoreElements()) {
     *    aHistory = (LifeCycleHistory)e.nextElement();
     *    // -- do stuff
     * }
     * </code>
     *
     *
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     object  the LifeCycleManaged object used as search criteria for the retrieval of History information
     * @return    QueryResult
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    @SuppressWarnings("deprecation")
    public QueryResult getHistory( LifeCycleManaged object )
            throws WTException, LifeCycleException {

        // -- Answer the LifeCycleHistory objects for the object
        if (logger.isTraceEnabled())
            logger.trace(">>In StandardLifeCycleService...getHistory( LifeCycleManaged object ) method");
        QueryResult results = null;

        // --  Navigate from the object to obtain LifeCycleHistory objects via the link
        if (object instanceof Iterated) {

            String objRefId = "." + ObjectReference.KEY + "." + ObjectIdentifier.ID;

            Class[] classes = { Iterated.class, ObjectHistory.class, LifeCycleHistory.class };
            QuerySpec qs = new QuerySpec(classes);

            int lcmPos = 0;
            int ohPos = 1;
            int lchPos = 2;

            //Set which classes are selectable
            qs.setSelect(ohPos, false);
            qs.setSelect(lcmPos, false);

            SearchCondition sc = new SearchCondition(
                    LifeCycleHistory.class,
                    "thePersistInfo.theObjectIdentifier.id",
                    ObjectHistory.class,
                    ObjectHistory.ROLE_BOBJECT_REF + objRefId);
            qs.appendWhere(sc,lchPos,ohPos);
            qs.appendAnd();
            SearchCondition sc2 = new SearchCondition(
                    Iterated.class,
                    "thePersistInfo.theObjectIdentifier.id",
                    ObjectHistory.class,
                    ObjectHistory.ROLE_AOBJECT_REF + objRefId);
            qs.appendWhere(sc2,lcmPos,ohPos);
            qs.appendAnd();
            SearchCondition sc3 = new SearchCondition(
                    Iterated.class,
                    Iterated.ITERATION_INFO + "." + VersionForeignKey.BRANCH_ID,
                    SearchCondition.EQUAL,
                    VersionControlHelper.getBranchIdentifier((Iterated)object));
            qs.appendWhere(sc3,lcmPos,-1);
            //Force the chronological sort by using ida2a2 instead of CREATE_TIME_STAMP.
            //Oracle DATE attributes does not support sorting to milli-second.
            qs.appendOrderBy( wt.lifecycle.LifeCycleHistory.class,
                    WTAttributeNameIfc.CREATE_STAMP_NAME,
                    true);
            qs.appendOrderBy( wt.lifecycle.LifeCycleHistory.class,
                    WTAttributeNameIfc.ID_NAME,
                    true);

            QueryResult jqResults = PersistenceHelper.manager.find(qs);
            if (logger.isTraceEnabled())
                logger.trace("FOUND " + jqResults.size() + " rows.");

            ObjectVector ov = new ObjectVector();
            while (jqResults.hasMoreElements()) {
                Persistable[] jq = (Persistable[])jqResults.nextElement();
                LifeCycleHistory lch = (LifeCycleHistory)jq[0];
                ov.addElement(lch);
            }
            results = new QueryResult(ov);
        }
        else {
            // --  Navigate from the object to obtain LifeCycleHistory objects via the link
            QuerySpec qs = new QuerySpec (wt.lifecycle.LifeCycleHistory.class,
                    wt.lifecycle.ObjectHistory.class);
            //Force the chronological sort by using ida2a2 instead of CREATE_TIME_STAMP.
            //Oracle DATE attributes does not support sorting to milli-second.
            qs.appendOrderBy( wt.lifecycle.LifeCycleHistory.class,
                    WTAttributeNameIfc.CREATE_STAMP_NAME,
                    true);
            qs.appendOrderBy( wt.lifecycle.LifeCycleHistory.class,
                    WTAttributeNameIfc.ID_NAME,
                    true);
            results = PersistenceServerHelper.manager.expand(
                    object,
                    ObjectHistory.HISTORY_ROLE,
                    qs,
                    true);
        }
        if (logger.isTraceEnabled())
            logger.trace(">>Out StandardLifeCycleService...getHistory( LifeCycleManaged object ) method");
        return results;

    }

    /**
     * Answer the object's current phase
     *
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @deprecated at R4.0  - This method should not be used outside of the
     * Life Cycle service.  This phase object should be considered private
     * to LifeCycle.  If you have a need to access information on this object,
     * please send a detailed request via Windchill Technical Marketing.
     *
     *
     * @param     object  the LifeCycleManaged object used as search criteria in the retrieval of the current phase object
     * @return    Phase
     * @exception wt.util.WTException
     **/

    public Phase getCurrentPhase( LifeCycleManaged object )
            throws WTException {

        // -- Answer the CurrentPhase link for the object
        if (logger.isTraceEnabled())
            logger.trace(">>In StandardLifeCycleService...getCurrentPhase() method");
        Phase aPhase = null;
        if (object.isLifeCycleBasic()) {
            if (logger.isTraceEnabled() ) {
                logger.trace("getCurrentPhase:   Object is basic lifecycle managed.  Returning null");
            }
            return aPhase;
        }

        // -- First, check to see if the LifeCycleManaged object has the phase object
        aPhase = object.getState().getPhase();
        if (aPhase != null) {
            if (logger.isTraceEnabled())
                logger.trace("**Found the Phase object on the LifeCycleManaged cookie");
            return aPhase;

        }

        // -- If not, navigate from the object to obtain CurrentPhase link
        QueryResult results = PersistenceServerHelper.manager.expand(
                object,
                CurrentPhase.PHASE_ROLE,
                wt.lifecycle.CurrentPhase.class,
                true);
        int size = results.size();
        if (logger.isTraceEnabled())
            logger.trace("FOUND " + size + " CurrentPhase OBJECTS");

        if (size == 0) {
            // -- Should always be only 1 element (check this?)
            /* SPR 1496443 : Life Cycle history is not displayed when an object's life cycle is dropped (by selecting `Drop' option for Promote activity)*/
            try
            {
                if((object.getState()!= null) && object.getState().toString().equalsIgnoreCase("DROPPED"))
                {
                    aPhase = Phase.newPhase();
                    aPhase.setName("DROPPED");

                }
                else
                {
                    if(VersionControlHelper.isLatestIteration((Iterated)object))
                    {
                        LifeCycleException lcExp=new LifeCycleException( RESOURCE, lifecycleResource.NO_PHASE_FOUND, null );
                        if(logger.isDebugEnabled())
                        {
                            logger.debug(lcExp.getLocalizedMessage(), lcExp);
                        }
                        throw lcExp;
                    }
                }
            }catch(Exception e)
            {
                throw new WTException(e);
            }

        }
        else
        {aPhase = (Phase)results.nextElement();}

        if (logger.isTraceEnabled())
            logger.trace("Putting the Phase object on the cookie of the LifeCycleManaged object");
        try {
            object.getState().setPhase(aPhase);
        }
        catch (WTPropertyVetoException wtpve) {

            if(logger.isDebugEnabled()){
                logger.debug(wtpve.getLocalizedMessage(), wtpve);
            }
            throw new WTException(wtpve);
        }
        if (logger.isTraceEnabled())
            logger.trace(">>Out StandardLifeCycleService...getCurrentPhase() method");
        return aPhase;
    }

    /**
     * Answer whether the designated user is validated for the designated
     * role
     *
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @deprecated at 8.0.  A user no longer has to belong to a specific
     * role in order to complete a lifecycle task
     *
     * @param     object  the LifeCycleManaged object
     * @param     user  the designated user
     * @param     role  the designated role
     * @return    boolean
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public boolean isA( LifeCycleManaged object, WTUser user, Role role )
            throws WTException, LifeCycleException {
        if (object.isLifeCycleBasic()) {
            if (logger.isTraceEnabled()) {
                logger.trace("isA:  Object is basic life cycle managed. Return false");
            }
            return false;
        }
        if (logger.isTraceEnabled())
            logger.trace("Enter isA:"+user.getName()+" is a "+role.toString());

        boolean answer = false;
        Team aTeam = null;

        /* 1. Get the 'role holder' for this object - Phase */
        aTeam = (Team)object.getTeamId().getObject();
        answer = userIsARolePlayer (aTeam, user, role);

        if (logger.isTraceEnabled())
            logger.trace("Exit isA:"+answer);

        return answer;

    }

    /**
     * Answer whether the LifeCycleManaged object is in the Initial phase
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     object  The LifeCycleManaged object
     * @return    boolean
     * @exception wt.util.WTException
     **/

    public boolean isInInitialPhase( LifeCycleManaged object )
            throws WTException {

        Phase aPhase = getCurrentPhase(object);
        PhaseTemplate currentPT = null;
        if (aPhase == null) {
            if (logger.isTraceEnabled() ) {
                logger.trace("isInInitialPhase:  Object is basic life cycle managed. Get the phase template of the object for the template of the current phase.");
            }
            currentPT = getPhaseTemplate(object);
        }
        else
        { currentPT = (PhaseTemplate)aPhase.getPhaseTemplateId().getObject();}
        return isInitialPhase(currentPT);

    }

    /**
     * Answers whether the LifeCycleManaged object is in the Final phase
     * of its LifeCycle
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     object  The LifeCycleManaged object
     * @return    boolean
     * @exception wt.util.WTException
     **/

    public boolean isInFinalPhase( LifeCycleManaged object )
            throws WTException {

        // -- Get the template associated with this phase
        if (logger.isTraceEnabled())
            logger.trace(">>In StandardLifeCycleService...isInFinalPhase(LifeCycleManaged) method");
        Phase aPhase = getCurrentPhase(object);
        PhaseTemplate currentPT = null;
        if (aPhase == null) {
            if (logger.isTraceEnabled() ) {
                logger.trace("isInFinalPhase:  Object is basic life cycle managed. Get the phase template of the object for the template of the current phase.");
            }
            currentPT = getPhaseTemplate(object);
        }
        else
        {currentPT = (PhaseTemplate)aPhase.getPhaseTemplateId().getObject();}

        return LifeCycleHelper.isFinalPhase(currentPT);
    }

    /**
     * Given a String representation of the LifeCycleTemplate name, answer
     * the enabled LifeCycleTemplate.  If no template is found, return <code>null/code>.
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     aTemplateName  the name of the LifeCycleTemplate to retrieve
     * @return    LifeCycleTemplate
     * @exception wt.lifecycle.LifeCycleException
     * @exception wt.util.WTException
     **/

    public LifeCycleTemplate getLifeCycleTemplate( String aTemplateName )
            throws LifeCycleException, WTException {

        if (logger.isTraceEnabled()) {
            logger.trace("Enter getLifeCycleTemplate:"+aTemplateName);
        }

        // - A container wasn't passed.  Presume classic container.
        // - The getLCT method will lookup the container hierarchy
        // - for us to find the template.
        LifeCycleTemplate aTemplate = getLCT(aTemplateName);

        if (logger.isTraceEnabled()) {
            logger.trace("Exit getLifeCycleTemplate");
            if (aTemplate == null)
                logger.trace("Not Found:"+aTemplateName);
            else
                logger.trace("Found:"+aTemplate.getName());
        }
        return aTemplate;
    }

    /**
     * Perform pre-submit validations
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     object  the LifeCycleManaged object to be submitted
     * @return    LifeCycleManaged
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    @SuppressWarnings("deprecation")
    public LifeCycleManaged validateSubmitForApproval(LifeCycleManaged object)
            throws WTException, LifeCycleException {
        LifeCycleManaged lcmobject = object;
        // -- Effective principal must be a submitter
        if (logger.isTraceEnabled())
            logger.trace(">>In StandardLifeCycleService...validateSubmitForApproval() method");
        WTPrincipal user = SessionHelper.manager.getPrincipal();

        lcmobject = validateSubmit(lcmobject);
        Phase aPhase = getCurrentPhase(lcmobject);
        LifeCycleException lcExp=null;

        // if no workflow is associated, the submit must be completed from within workflow
        Object[] param = { IdentityFactory.getDisplayIdentity(lcmobject) };
        if ( !lcmobject.isLifeCycleBasic() && aPhase.getWfProcessId().getObjectId() == null ){
            logger.debug(">>No Workflow is associated");
            lcExp=new LifeCycleException(RESOURCE, lifecycleResource.OBJECT_NOT_SUBMITABLE, param);
            logger.debug(lcExp.getLocalizedMessage(), lcExp);
            throw lcExp;
        }
        else {
            // if a workflow is associated, a Workitem must be found for this user
            logger.debug(">>Workflow is associated");
            Enumeration unCompletedEnum = null;
            boolean flag = false;
            Enumeration e = WorkflowHelper.service.getWorkItems(lcmobject, user, SUBMIT_TASK);
            logger.debug(">>For Principal ::"+user+"WorkItems are presents::"+e.hasMoreElements());

            ContainerTeamManaged containerTeamManaged = null;
            try {
                if (((WTContained) lcmobject).getContainer() instanceof ContainerTeamManaged)
                    containerTeamManaged = (ContainerTeamManaged) ((WTContained) lcmobject).getContainer();
            } catch (Exception excep) {
                logger.debug(excep.getLocalizedMessage(), excep);
            }

            if (containerTeamManaged != null && containerTeamManaged instanceof WTContainer) {
                WTContainer product = (WTContainer) containerTeamManaged;
                WTGroup managers = product.getAdministrators();
                flag = OrganizationServicesHelper.manager.isMember(managers, user);
                logger.debug(user +"is product Manager::"+flag);
                if(flag){
                    unCompletedEnum = WorkflowHelper.service.getUncompletedWorkItems(lcmobject,SUBMIT_TASK);
                    logger.trace("UncompletedWorkItems are presents::"+e.hasMoreElements());
                }
            }

            boolean condition =(!flag)? e.hasMoreElements():(unCompletedEnum == null ? e.hasMoreElements(): unCompletedEnum.hasMoreElements()) ;

            logger.debug("Condition Val="+ condition);

            if (!condition)
            {
                lcExp=new LifeCycleException(RESOURCE, lifecycleResource.OBJECT_NOT_SUBMITABLE, param);
                logger.debug(lcExp.getLocalizedMessage(), lcExp);
                throw lcExp;

            }

        }
        if (logger.isTraceEnabled())
            logger.trace(">>Out StandardLifeCycleService...validateSubmitForApproval() method");
        return lcmobject;
    }

    /**
     * Given a role and a LifeCycleManaged object, determines whether the
     * current user has the permissions required to update the role participants
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     role  The LifeCycleManaged object that the role/participant mapping is being added to
     * @param     object  the object whose team is being modified
     * @return    boolean
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    @SuppressWarnings("deprecation")
    public boolean hasAugmentRoleAccess( Role role, LifeCycleManaged object )
            throws WTException, LifeCycleException {

        if (logger.isTraceEnabled())
            logger.trace("Enter hasAugmentRoleAccess");

        if (object.isLifeCycleBasic()) {
            if (logger.isTraceEnabled() )
                logger.trace("hasAugmentRoleAccess: Object is basic lifecycle managed. Return false.");
            return false;
        }

        String PREF_NODE = "/wt/team/";
        String PREF_KEY_UPDATETEAM = "updateteam";
        String pref_value = (String)PreferenceHelper.service.getValue(
                PREF_NODE + "/" + PREF_KEY_UPDATETEAM,
                (wt.inf.container.WTContainer)null,
                (wt.org.WTUser)null);
        if( pref_value == null ){
            pref_value = "false";
        }

        if(logger.isTraceEnabled()){
            logger.trace(" Preference value for " + PREF_NODE + "/" + PREF_KEY_UPDATETEAM
                    + " is ==> " + pref_value);
        }

        //Chcking for modify permission on team
        if(pref_value.equalsIgnoreCase("true")){
            wt.access.AdHocControlled teamObj= (wt.access.AdHocControlled)(object.getTeamId()).getObject();
            if (AccessControlHelper.manager.hasAccess(teamObj, AccessPermission.MODIFY)){
                if (logger.isTraceEnabled())
                    logger.trace("Exit hasAugmentRoleAccess as TRUE (user has MODIFY permissions on team)");
                return true;
            }
        }
        //End SPR#1271504


        // -- if the user has administrative permission on the object and the LifeCycle, they are allowed to change roles
        if (AccessControlHelper.manager.hasAccess(object, AccessPermission.ADMINISTRATIVE)) {
            if (logger.isTraceEnabled())
                logger.trace("Exit hasAugmentRoleAccess as TRUE (user has ADMINISTRATIVE permissions on object)");
            return true;
        }

        @SuppressWarnings("unused")
        Phase currentPhase = getCurrentPhase(object);
        WTPrincipal user = SessionHelper.manager.getPrincipal();

        // -- if the role being augmented is Observer and the current user is a Promoter, Submitter or Reviewer === allow it
        if (  (role.equals(Role.OBSERVER)) &&
                (isA(object, (WTUser)user, Role.PROMOTER) ||
                        isA(object, (WTUser)user, Role.SUBMITTER) ||
                        isA(object, (WTUser)user, Role.REVIEWER))  ) {
            if (logger.isTraceEnabled())
                logger.trace("Exit hasAugmentRoleAccess as TRUE (looking for Observer and current user is Promoter/Submitter/Reviewer)");
            return true;
        }

        // -- if the role being augmented is Reviewer and the current user is a Promoter or Submitter === allow it
        if (  (role.equals(Role.REVIEWER)) &&
                (isA(object, (WTUser)user, Role.PROMOTER) ||
                        isA(object, (WTUser)user, Role.SUBMITTER))  ) {
            if (logger.isTraceEnabled())
                logger.trace("Exit hasAugmentRoleAccess as TRUE (looking for Reviewer and current user is Promoter/Submitter)");
            return true;
        }

        // -- if the role being augmented is Reviewer and the current user is a Promoter or Submitter === allow it
        if (  (role.equals(Role.SUBMITTER)) &&
                (isA(object, (WTUser)user, Role.PROMOTER))  ) {
            if (logger.isTraceEnabled())
                logger.trace("Exit hasAugmentRoleAccess as TRUE (looking for Submitter and current user is Promoter)");
            return true;
        }

        if (logger.isTraceEnabled())
            logger.trace("Exit hasAugmentRoleAccess as FALSE");

        return false;

    }

    /**
     * Answer a vector of enabled life cycle template references valid for
     * the life cycle managed object
     *
     * findCandidateMasterReference is the preferable to use instead of this
     * method.  Using findCandidateMasterReference plus the 'getLifeCycleTemplate'
     * method on that object will get the latest iteration at the last possible
     * moment, eliminating some multi-user timing issues.
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     object  the LifeCycleManaged object used as search criteria in the retrieval of canidate LifeCycleTemplates
     * @return    Vector
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/


    public Vector findCandidateTemplates( LifeCycleManaged object )
            throws WTException, LifeCycleException {
        // -- Answer a vector of template names which accept this object

        if (logger.isTraceEnabled())
            logger.trace("Enter findCandidatetemplates(LifeCycleManaged)");

        if (object == null)
            throw new LifeCycleException(RESOURCE, lifecycleResource.NULL_OBJECT, null);

        Class targetClass = object.getClass();
        Vector references = findCandidateTemplates(targetClass);

        if (logger.isTraceEnabled())
            logger.trace("Exit findCandidatetemplates(LifeCycleManaged) - found "+references.size()+" candidates");

        return references;
    }

    /**
     * Answer a vector of enabled life cycle template references valid for
     * the class
     *
     * findCandidateMasterReference is the preferable to use instead of this
     * method.  Using findCandidateMasterReference plus the 'getLifeCycleTemplate'
     * method on that object will get the latest iteration at the last possible
     * moment, eliminating some multi-user timing issues.
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     targetClass  the class used as search criteria in the retrieval of canidate LifeCycleTemplates
     * @return    Vector
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/


    public Vector findCandidateTemplates( Class targetClass )
            throws WTException, LifeCycleException {

        if (logger.isTraceEnabled()) {
            logger.trace("Enter findCandidatetemplates(Class)");
        }
        WTContainerRef exchange = WTContainerHelper.service.getExchangeRef();//WTContainerHelper.service.getClassicRef(); The API getClassicRef() should have been deprecated
        /* 1. Get the templates that work for this class */
        Enumeration e = findTemplateMasterByClass(targetClass, exchange);

        /* 2. Build a list of names */
        Vector lctReferences = new Vector();
        while (e.hasMoreElements()) {
            LifeCycleTemplateMaster master = (LifeCycleTemplateMaster)e.nextElement();
            LifeCycleTemplate template = getLatestIteration(master);

            //-- filter out any LifeCycleTemplates that the current user doesn't have access to
            if (template !=null) {
                lctReferences.addElement(LifeCycleTemplateReference.newLifeCycleTemplateReference(template));
            }
        }

        if (logger.isTraceEnabled())
            logger.trace("Exit findCandidatetemplates(Class) - found "+lctReferences.size()+" candidates");

        return lctReferences;
    }

    /**
     * Given a particular LifeCycleTemplate, answer a Vector of all the Life
     * Cycle States used in that LifeCycle
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     aLifeCycleTemplate  the LifeCycleTemplate used to retrieve the appropriate states
     * @return    Vector
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/


    public Vector findStates( LifeCycleTemplate aLifeCycleTemplate )
            throws WTException, LifeCycleException {

        if (logger.isDebugEnabled())
            logger.debug("In findStates( LifeCycleTemplate aLifeCycleTemplate ) method");

        Vector phaseTemplates = this.getPhaseTemplates(aLifeCycleTemplate);
        Iterator itr = phaseTemplates.iterator();
        int size = phaseTemplates.size();

        if (logger.isDebugEnabled())
            logger.debug("Found " + size + " PhaseTemplate Objects");

        PhaseTemplate pt = null;
        Vector states = new Vector(size);
        while (itr.hasNext()) {
            pt = (PhaseTemplate) itr.next();
            states.addElement(pt.getPhaseState());
        }
        if (logger.isDebugEnabled())
            logger.debug("Out findStates( LifeCycleTemplate aLifeCycleTemplate ) method");

        return states;
    }

    /**
     * Given a particular LifeCycleTemplate and a State, answer whether or
     * not the State is used in the LifeCycle
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     aLifeCycleTemplate  the LifeCycleTemplate used in the lookup
     * @param     aState  the State used in the lookup
     * @return    boolean
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public boolean isState( LifeCycleTemplate aLifeCycleTemplate, State aState )
            throws WTException, LifeCycleException {

        boolean validState = false;

        PhaseTemplate pt = stateSearch (aLifeCycleTemplate, aState);
        if (pt != null)
            validState = true;

        return validState;
    }

    /**
     * Given a particular LifeCycleManged object, answer an enumeration of
     * all the predecessor States
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     object  the LifeCycleManaged object of interest
     * @return    Enumeration
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/


    public Enumeration findPredecessorStates( LifeCycleManaged object )
            throws WTException, LifeCycleException {
        Vector prevStates = new Vector();
        PhaseTemplate predecessor = null;
        // Get the current phase template
        Phase aPhase = getCurrentPhase(object);
        PhaseTemplate aPhaseTemplate = null;
        if (aPhase==null) {
            if (logger.isTraceEnabled() ) {
                logger.trace("findPredecessorStates:  Object is basic life cycle managed. Get the phase template of the object for the template of the current phase.");
            }
            aPhaseTemplate = getPhaseTemplate(object);
        }
        else
            aPhaseTemplate = (PhaseTemplate) aPhase.getPhaseTemplateId().getObject();

        while (aPhaseTemplate != null) {
            predecessor = getPredecessorPhase(aPhaseTemplate);
            if (predecessor != null) {
                prevStates.addElement (predecessor.getPhaseState());
            }
            aPhaseTemplate = predecessor;
        }
        return prevStates.elements();
    }

    /**
     * Given a particular LifeCycleTemplate, answer an enumeration of all
     * the Successor States
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     object  the LifeCycleManaged object of interest
     * @return    Enumeration
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/


    public Enumeration findSuccessorStates( LifeCycleManaged object )
            throws WTException, LifeCycleException {
        Vector nextStates = new Vector();
        PhaseTemplate successor = null;
        // Get the current phase template
        Phase aPhase = getCurrentPhase(object);
        PhaseTemplate aPhaseTemplate = null;
        if (aPhase==null) {
            if (logger.isTraceEnabled() ) {
                logger.trace("findSuccessorStates:  Object is basic life cycle managed. Get the phase template of the object for the template of the current phase.");
            }
            aPhaseTemplate = getPhaseTemplate(object);
        }
        else
            aPhaseTemplate = (PhaseTemplate) aPhase.getPhaseTemplateId().getObject();
        while (aPhaseTemplate != null) {
            successor = getSuccessorPhase(aPhaseTemplate);
            if (successor != null) {
                nextStates.addElement(successor.getPhaseState());
            }
            aPhaseTemplate = successor;
        }
        return nextStates.elements();
    }

    /**
     * Enable/Disable the Life Cycle Template Master
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     aTemplate  the template to set the enabled flat on
     * @param     enable  specifies whether or not the template is enabled
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public void setEnabled( LifeCycleTemplate aTemplate, boolean enable )
            throws WTException, LifeCycleException {

        LifeCycleTemplateMaster aMaster = (LifeCycleTemplateMaster)((LifeCycleTemplate)aTemplate).getMaster();
        setEnabled(aMaster, enable);

    }

    /**
     * Enable/Disable the Life Cycle Template Master
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     aMaster  the lifecycle template master to set the enabled flag on
     * @param     enable  sets the value of the enabled flag to true or false
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public void setEnabled( LifeCycleTemplateMaster aMaster, boolean enable )
            throws WTException, LifeCycleException {
        LifeCycleTemplateMaster lctaMaster = aMaster;
        lctaMaster = (LifeCycleTemplateMaster)PersistenceServerHelper.manager.restore(lctaMaster);

        //SPR # 2068906 : Disabling of the Lifecycle Template configured in property wt.lifecycle.defaultLifeCycle should not be allowed by the system.
        try {
            WTProperties properties = WTProperties.getLocalProperties();
            String defaultLCTemplateName = properties.getProperty("wt.lifecycle.defaultLifeCycle");
            String targetLCName = lctaMaster.getName();
            if(targetLCName.equalsIgnoreCase(defaultLCTemplateName) && !enable){
                //throw new LifeCycleException(WTMessage.getLocalizedMessage(RESOURCE,lifecycleResource.CANT_DISABLE_LCT,null));
                //To get the proper error message in browser locale, used different approach of error throwing
                throw new WTException(RESOURCE, lifecycleResource.CANT_DISABLE_LCT, null);
            }
        } catch (IOException ioe) {
            if(logger.isDebugEnabled()){
                logger.debug(ioe.getLocalizedMessage(), ioe);
            }
            throw new LifeCycleException(ioe);
        }

        if ( ( (enable) && (lctaMaster.isEnabled()) ) ||   // If it's alaready enabled, do nothing
                ( (!enable) && (!lctaMaster.isEnabled()) )  )  { //If it's already disabled, do nothing
            if ( logger.isTraceEnabled() )
                logger.trace("The Life Cycle Template Master's enable attribute is already set to " + lctaMaster.isEnabled());
        }
        else if (!AccessControlHelper.manager.hasAccess(getLatestIteration(lctaMaster), AccessPermission.MODIFY)) {
            Object[] param = { IdentityFactory.getDisplayIdentity(getLatestIteration(lctaMaster)) };
            AccessControlHelper.manager.emitAccessEvent (
                    AccessControlEvent.NOT_AUTHORIZED, getLatestIteration(lctaMaster), AccessPermission.MODIFY,
                    new WTMessage (RESOURCE, lifecycleResource.MODIFY_NOT_ALLOWED, param));
            throw new LifeCycleException(RESOURCE, lifecycleResource.MODIFY_NOT_ALLOWED, param);
        }
        else {
            Transaction trx = new Transaction();
            try {
                trx.start();
                if (enable)
                    dispatchVetoableEvent( LifeCycleServiceEvent.ENABLE_LIFECYCLE, lctaMaster );
                else
                    dispatchVetoableEvent( LifeCycleServiceEvent.DISABLE_LIFECYCLE, lctaMaster );

                lctaMaster.setEnabled(enable);
                PersistenceHelper.manager.modify(lctaMaster);
                trx.commit();
                trx = null;
            }
            catch (WTPropertyVetoException veto) {
                if(logger.isDebugEnabled()){
                    logger.debug(veto.getLocalizedMessage(), veto);
                }
                throw new LifeCycleException(veto);
            }
            finally {
                if (trx != null)
                    trx.rollback();
            }
        }

    }

    /**
     * Answer a vector of life cycle template references valid for the life
     * cycle managed object
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     object  the LifeCycleManaged object used as search criteria in the retrieval of canidate LifeCycleTemplates
     * @return    Vector
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/


    public Vector findCandidateMasterReferences( LifeCycleManaged object )
            throws WTException, LifeCycleException {

        // -- Answer a vector of template names which accept this object

        if (logger.isTraceEnabled())
            logger.trace("Enter findCandidateMasterReferences(LifeCycleManaged)");

        if (object == null)
            throw new LifeCycleException(RESOURCE, lifecycleResource.NULL_OBJECT, null);

        Class targetClass = object.getClass();
        Vector references = findCandidateMasterReferences(targetClass);

        if (logger.isTraceEnabled())
            logger.trace("Exit findCandidateMasterReferences(LifeCycleManaged) - found "+references.size()+" candidates");

        return references;
    }

    /**
     * Answer a vector of life cycle template references valid for the class
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     targetClass  the class used as search criteria in the retrieval of canidate LifeCycleTemplates
     * @return    Vector
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/


    public Vector findCandidateMasterReferences( Class targetClass )
            throws WTException, LifeCycleException {

        if (logger.isTraceEnabled())
            logger.trace("Enter findCandidateMasterReferences(Class)");
        WTContainerRef exchange = WTContainerHelper.service.getExchangeRef();//WTContainerHelper.service.getClassicRef(); The API getClassicRef() should have been deprecated
        /* 1. Get the templates that work for this class */
        Enumeration e = findTemplateMasterByClass(targetClass, exchange);

        /* 2. Build a list of names */
        Vector lctmReferences = new Vector();
        while (e.hasMoreElements()) {
            LifeCycleTemplateMaster master = (LifeCycleTemplateMaster)e.nextElement();
            //-- filter out any LifeCycleTemplateMasters whose only iteration the current user won't have access to
            LifeCycleTemplate template = getLatestIteration(master);
            if (template !=null) {
                lctmReferences.addElement(LifeCycleTemplateMasterReference.newLifeCycleTemplateMasterReference(master));
            }

        }

        if (logger.isTraceEnabled())
            logger.trace("Exit findCandidateMasterReferences(Class) - found "+lctmReferences.size()+" candidates");

        return lctmReferences;
    }

    /**
     * Given a String representation of the LifeCycleTemplateMaster name,
     * answer the LifeCycleTemplateMasterReference
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     aMasterName  the name of the LifeCycleTemplate to retrieve
     * @return    LifeCycleTemplateMaster
     * @exception wt.lifecycle.LifeCycleException
     * @exception wt.util.WTException
     **/

    public LifeCycleTemplateMaster getLifeCycleTemplateMaster( String aMasterName )
            throws LifeCycleException, WTException {

        if (logger.isTraceEnabled())
            logger.trace("Enter getLifeCycleTemplateMaster:"+aMasterName);

        LifeCycleTemplateMaster aMaster = null;
        LifeCycleTemplate template = getLifeCycleTemplate(aMasterName);
        if (template != null) {
            aMaster = (LifeCycleTemplateMaster)((LifeCycleTemplate)template).getMaster();
        }

        if (logger.isTraceEnabled()) {
            logger.trace("Exit getLifeCycleTemplate");
            if (aMaster == null)
                logger.trace("Not Found:"+aMasterName);
            else
                logger.trace("Found:"+aMaster.getName());
        }

        return aMaster;
    }

    /**
     * Given a String representation of the LifeCycleTemplater name, find
     * the latest iteration or working copy of the LifeCycleTemplate.  Return
     * a LifeCycleTemplateReference.
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     aName  the name of the LifeCycleTemplate to retrieve
     * @return    LifeCycleTemplateReference
     * @exception wt.lifecycle.LifeCycleException
     * @exception wt.util.WTException
     **/

    public LifeCycleTemplateReference getLifeCycleTemplateReference( String aName )
            throws LifeCycleException, WTException {

        LifeCycleTemplateMaster aMaster = getLifeCycleTemplateMaster(aName);

        return aMaster.getLifeCycleTemplateReference();
    }

    /**
     * Set the state of the Life Cycle Managed object and provide the option
     * to terminate the associated workflows.  If null is passed as the WfState,
     * all processes are terminated.
     *
     * User need ADMINISTRATIVE or SET_STATE permission on LifeCycleManaged object to change state. NotAuthorizedException is thrown otherwise.
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     object  The LifeCycleManaged object whose state should be updated
     * @param     state  The state to set the LifeCycleManaged object to.
     * @param     terminAssocRunningProcesses  a flag that determines whether or not to terminate the wf processes associated with this phase that are OPEN_RUNNING
     * @return    LifeCycleManaged
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public LifeCycleManaged setLifeCycleState( LifeCycleManaged object, State state, boolean terminAssocRunningProcesses )
            throws WTException, LifeCycleException {
        return setLifeCycleState(object, state, terminAssocRunningProcesses, null);
    }

    /**
     * Set the state of the Life Cycle Managed object.
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     object  The LifeCycleManaged object whose state should be updated
     * @param     state  The state to set the LifeCycleManaged object to.
     * @return    LifeCycleManaged
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public LifeCycleManaged setLifeCycleState( LifeCycleManaged object, State state )
            throws WTException, LifeCycleException {
        LifeCycleManaged lcmobject = object;
        if (logger.isTraceEnabled())
            logger.trace("Enter setLifeCycleState");

        Transaction trx = new Transaction();
        try {
            trx.start();

            // 1. Make sure the user has authority to do this
            _checkStateChangePermissions(lcmobject, true);

            // 2. Set the state of the object to the one specified
            lcmobject=setState(lcmobject, state);

            trx.commit();
            trx = null;
        }
        finally {
            if (trx != null)
                trx.rollback();
        }

        if (logger.isTraceEnabled())
            logger.trace("Exit setLifeCycleState");

        return lcmobject;
    }

    /**
     * Given a Life Cycle Managed object, return the Workflow processes associated
     * with the current phase.  If null is specified as the Wf State, all
     * processes are retrieved.
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     object  the Life Cycle Managed object
     * @param     state  the Workflow state
     * @return    Vector
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/


    public Vector findAssociatedProcesses( LifeCycleManaged object, WfState state )
            throws WTException, LifeCycleException {
        if (logger.isTraceEnabled())
            logger.trace("=> findAssociatedProcesses: " + getOid (object) + " " + state.toString() );
        Phase aPhase = getPhase (object);
        if (aPhase == null) {
            return new Vector ();
        }
        Vector vector = new Vector();
        WfProcess aWfProcess = null;
        ObjectIdentifier wfOid = (ObjectIdentifier) aPhase.getWfProcessId().getKey();
        if (wfOid != null) {
            aWfProcess = (WfProcess) PersistenceHelper.manager.refresh (wfOid);
        }
        if ((aWfProcess != null) &&
                ((state == null) || (aWfProcess.getState().equals (state)))) {
            if ( logger.isTraceEnabled() )
                logger.trace("   phase process = " + aWfProcess.getName() + ", state = " +aWfProcess.getState());
            vector.addElement(aWfProcess);
        }
        if (aPhase.getGate() != null) {
            wfOid = (ObjectIdentifier)aPhase.getGate().getWfProcessId().getKey();
            if (wfOid != null) {
                aWfProcess = (WfProcess)PersistenceHelper.manager.refresh(wfOid);
            }
            if ((aWfProcess != null) &&
                    ((state == null) || (aWfProcess.getState().equals(state))) ) {
                if ( logger.isTraceEnabled() )
                    logger.trace("   gate process = " + aWfProcess.getName() + ", state = " + aWfProcess.getState());
                vector.addElement(aWfProcess);
            }
        }
        if ( logger.isTraceEnabled() )
            logger.trace("   findAssociatedProcesses - OUT: " + vector.size());
        return vector;
    }

    /**
     * Produces a copy of the LifeCycleTemplate object and persists it with
     * the name passed as argument. If the name argument is "null", the name
     * of the copied LifeCycleTemplate object  is prefixed with 'copy of'.
     *  If the folder location is not specified, the object will be persisted
     * in the orginal LifeCycleTemplates's folder location.
     *
     * Note:  The 'Copy Of' prefix is pulled from a Resource Bundle for localization
     * purposes.
     *
     *
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     lifeCycleTemplate  the LifeCycleTemplate object that should be copied
     * @param     copyName  the name of the new LifeCycleTemplate
     * @param     folderLocation  the folder location of the new LifeCycleTemplate
     * @return    LifeCycleTemplate
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    @SuppressWarnings("deprecation")
    public LifeCycleTemplate copyTemplate( LifeCycleTemplate lifeCycleTemplate, String copyName, String folderLocation )
            throws WTException, LifeCycleException {
        if (logger.isTraceEnabled())
            logger.trace("Enter copyTemplate");

        LifeCycleTemplate newLifeCycleTemplate = null;


        // - Before doing anything, check to make sure the user will have permission
        if (!AccessControlHelper.manager.hasAccess(lifeCycleTemplate, AccessPermission.CREATE)) {
            AccessControlHelper.manager.emitAccessEvent (
                    AccessControlEvent.NOT_AUTHORIZED, null, AccessPermission.CREATE,
                    new WTMessage (RESOURCE, lifecycleResource.CREATE_LCT_NOT_ALLOWED, null));
            throw new LifeCycleException(RESOURCE, lifecycleResource.CREATE_LCT_NOT_ALLOWED, null);
        }

        MethodContext mc = MethodContext.getContext();
        try {
            newLifeCycleTemplate = LifeCycleTemplate.newLifeCycleTemplate();
            if ((copyName != null) && (copyName.length() > 0))
                newLifeCycleTemplate.setName(copyName);
            else
                newLifeCycleTemplate.setName(WTMessage.getLocalizedMessage(RESOURCE,lifecycleResource.COPY_OF,null) +
                        " " +
                        lifeCycleTemplate.getName());
            newLifeCycleTemplate.setDescription(lifeCycleTemplate.getDescription());
            newLifeCycleTemplate.setSupportedClass(lifeCycleTemplate.getSupportedClass());
            newLifeCycleTemplate.setEnabled(lifeCycleTemplate.isEnabled());
            newLifeCycleTemplate.setBasic(lifeCycleTemplate.isBasic());

            if ((folderLocation != null) && (folderLocation.length() > 0))
                FolderHelper.assignLocation(newLifeCycleTemplate, folderLocation);
            else
                FolderHelper.assignLocation(newLifeCycleTemplate, FolderHelper.getFolder(lifeCycleTemplate));

            mc.put(BYPASS_DEFAULT_TRANSITIONS, Boolean.TRUE);
            newLifeCycleTemplate = (LifeCycleTemplate)PersistenceHelper.manager.save(newLifeCycleTemplate);
            copyObjectsRelatedToLifeCycleTemplate(lifeCycleTemplate, newLifeCycleTemplate);
        }
        catch (WTPropertyVetoException wtpve) {
            if(logger.isDebugEnabled()){
                logger.debug(wtpve.getLocalizedMessage(), wtpve);
            }
            throw new LifeCycleException(wtpve);
        }
        finally {
            mc.remove("bypassDefaultTransitions");
        }

        if (logger.isTraceEnabled())
            logger.trace("Exit copyTemplate");

        return (LifeCycleTemplate)PersistenceHelper.manager.refresh(newLifeCycleTemplate);

    }

    /**
     * Answer a vector of all life cycle templates.  The latest iteration
     * of each life cycle template will be returned.  In this particular
     * context, the definition of 'latest iteration' is either the current
     * user's working copy, if one exists, or the latest iteration in the
     * vault.
     *
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @return    Vector
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/


    public Vector findAllTemplates()
            throws WTException, LifeCycleException {
        if (logger.isTraceEnabled())
            logger.trace("Enter findAllTemplates()");

        Vector lastTemps = findAllTemplates(null);
        if (logger.isTraceEnabled())
            logger.trace("Exit findAllTemplates() - found "+lastTemps.size());

        return lastTemps;
    }

    /**
     * Given a LifeCycleTemplateMaster, return the latest iteration (LifeCycleTemplate)
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     master  the lifecycle master of interest
     * @return    LifeCycleTemplate
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/


    public LifeCycleTemplate getLatestIteration( LifeCycleTemplateMaster master )
            throws WTException, LifeCycleException {

        LifeCycleTemplate lct = null;

        try {
            // Check the cache first
            // Clone the cached LifecycleTemplate's Vector to create a thread local QueryResult
            QueryResult tmp = (QueryResult)getLifeCycleTemplateCache().get(PersistenceHelper.getObjectIdentifier(master));
            QueryResult lctQueryResult = null;
            if (tmp != null && tmp.size() > 0)
                lctQueryResult = new QueryResult( new ObjectVector( (Vector)tmp.getObjectVectorIfc().getVector().clone() ) );

            if (lctQueryResult != null) {
                lctQueryResult.reset();
                if (logger.isTraceEnabled())
                    logger.trace ("LifeCycleTemplateCache:  " +master.getName()+ " found in cache."  );
            }
            else {
                if (logger.isTraceEnabled())
                    logger.trace ("LifeCycleTemplateCache: " +master.getName()+ " not found in cache, checking db....");
                //--If not found in the cache, go get it from the database
                lctQueryResult = VersionControlHelper.service.allIterationsOf(master);
                getLifeCycleTemplateCache().put(PersistenceHelper.getObjectIdentifier(master), lctQueryResult);
                // reset query result so that can be used later
                lctQueryResult.reset();
                if (logger.isTraceEnabled())
                    logger.trace("LifeCycleTemplateCache:  Added " +master.getName()  );
            }
            //SPR 1071958 - removing processing of config spec as allIterationOf returns an ordered
            //enumeration of objects with the latest as the first.

            if (lctQueryResult != null && lctQueryResult.hasMoreElements()) {
                lct = (LifeCycleTemplate)lctQueryResult.nextElement();
                if(lct.getCheckoutInfo().getState() == WorkInProgressState.CHECKED_IN ){
                    return lct;
                }
                else if(lct.getCheckoutInfo().getState() == WorkInProgressState.CHECKED_OUT){
                    return lct;
                }
                else{
                    while(lctQueryResult.hasMoreElements()){
                        lct = (LifeCycleTemplate)lctQueryResult.nextElement();
                        if(lct.getCheckoutInfo().getState() == WorkInProgressState.CHECKED_OUT)
                            break;
                    }
                }
            }

            if (!AccessControlHelper.manager.hasAccess(lct, wt.access.AccessPermission.READ))
                return null;

        }
        catch (WTException wte)  {
            if(logger.isDebugEnabled()){
                logger.debug(wte.getLocalizedMessage(), wte);
            }
            throw new WTRuntimeException (wte);
        }

        return lct;
    }

    /**
     * Given a LifeCycleTemplateMasterReference, return the latest iteration
     * (LifeCycleTemplateReference)
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     master  the lifecycle template master of interest
     * @return    LifeCycleTemplateReference
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public LifeCycleTemplateReference getLatestIteration( LifeCycleTemplateMasterReference master )
            throws WTException, LifeCycleException {

        return LifeCycleTemplateReference.newLifeCycleTemplateReference(getLatestIteration((LifeCycleTemplateMaster)master.getReadOnlyObject()));
    }

    /**
     * Given a LifeCycleTemplate, return a vector of all the PhaseTemplate
     * objects
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     template  the lifecycle template to retrieve the phase templates for
     * @return    Vector
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/


    public Vector getPhaseTemplates( LifeCycleTemplate template )
            throws WTException, LifeCycleException {
        if (logger.isTraceEnabled())
            logger.trace (" getPhaseTemplates : IN..." + template);
        Vector results = new Vector();
        int size = 0;

        //-Check the cache first
        results = (Vector)getPhaseTemplateCache().get(PersistenceHelper.getObjectIdentifier(template));
        if (logger.isTraceEnabled())
            logger.trace (" phase templates from cache : results :: "+ results);
        if (results != null) {
            if (logger.isTraceEnabled())
                logger.trace ("PhaseTemplateCache:  " +template.getName()+ " found in cache.");
        }
        else {
            if (logger.isTraceEnabled())
                logger.trace ("PhaseTemplateCache: " +template.getName()+ " not found in cache, checking db....");
            //--If not found in the cache, go get it from the database
            results = new Vector();
            PhaseTemplate pt = getInitialPhase(template);
            if (logger.isTraceEnabled())
                logger.trace ("PhaseTemplate - pt :: "+ pt);
            if (pt != null) {
                results.addElement(pt);
                size++;
            }
            while (!LifeCycleHelper.isFinalPhase(pt)) {
                pt = getSuccessorPhase(pt);
                if (logger.isTraceEnabled())
                    logger.trace ("successor phase : pt :: "+ pt);
                results.addElement(pt);
                size++;
            }
            if (logger.isTraceEnabled())
                logger.trace("Found "+size+" PhaseTemplate Objects");
            if (size > 0) {
                getPhaseTemplateCache().put(PersistenceHelper.getObjectIdentifier(template), results);
                if (logger.isTraceEnabled())
                    logger.trace("PhaseTemplateCache:  Added " +template.getName()+ " with " +size+ "Phase Templates");
            }
        }
        if (logger.isTraceEnabled())
            logger.trace (" getPhaseTemplates : OUT... results :: "+ results);
        return results;

    }

    /**
     * Given a LifeCycleManaged object, return a reference to the current
     * WfProcess.  If the LifeCycleManaged object is in the phase, the Phase
     * WF is returned.  If the LifeCycleManaged object is at the gate, the
     * Gate WF is returned.  If there is no workflow, a null is returned.
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     object  the object whoose current workflow should be returned
     * @return    ObjectReference
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public ObjectReference getCurrentWorkflow( LifeCycleManaged object )
            throws WTException, LifeCycleException {
        if (object.isLifeCycleBasic()) {
            if (logger.isTraceEnabled() ) {
                logger.trace("getCurrentWorkflow: object is basic lifecycle managed. Return null");
            }
            return null;
        }

        ObjectReference process = null;
        Phase phase = getCurrentPhase(object);

        if (object.isLifeCycleAtGate())
            process = phase.getGate().getWfProcessId();
        else
            process = phase.getWfProcessId();

        return process;
    }

    /**
     * Given a LifeCycleManaged object, return the current state of the object
     * as a link to the WfProcess (ProcessManager)
     *
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @deprecated at 5.0
     *
     * @param     object  the object to build the statesLink for.
     * @return    String
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public String getStateLink( LifeCycleManaged object )
            throws WTException, LifeCycleException {
        String label = object.getLifeCycleState().getDisplay();
        try {
            WfProcess process = (WfProcess) LifeCycleHelper.service.getCurrentWorkflow (object).getObject();
            Properties urlParameter = new Properties();
            urlParameter.put ("action", "ProcessManager");
            urlParameter.put ("oid", new ReferenceFactory().getReferenceString (process));
            String refString = GatewayURL.buildAuthenticatedURL (URLCLASSNAME, URLMETHODNAME, urlParameter).toString();
            refString = HtmlUtil.createLink (refString, null, label);
            return refString;
        }
        catch (Exception e) {
            if(logger.isDebugEnabled()){
                logger.debug(e.getLocalizedMessage(), e);
            }
            return label;
        }
    }

    /**
     * Given a LifeCycleManaged object, the current State of the Object and
     * the RoleHolder (the phase object), change the role participants to
     * reflect those in the RoleHolder2
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     object  The LifeCycleManaged object that the role/participant mapping is being added to
     * @return    Phase
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    @SuppressWarnings({ "deprecation"})
    public Phase augmentRoles( LifeCycleManaged object )
            throws WTException, LifeCycleException {

        LifeCycleManaged lcmobject=object;
        if (logger.isTraceEnabled())
            logger.trace("Enter augmentRoles");
        if (lcmobject.isLifeCycleBasic()) {
            if (logger.isTraceEnabled())
                logger.trace("augmentRoles: Object is basic lifecycle managed. Return null.");
            return null;
        }

        // need to refresh the object to prevent stale object exceptions on buildAdHocAcl
        lcmobject = (LifeCycleManaged)PersistenceServerHelper.manager.restore(lcmobject);

        // - check to make sure the object passed in is the latest iteration
        @SuppressWarnings("unused")
        String action = WTMessage.getLocalizedMessage(
                RESOURCE,
                AUGMENT,
                null);

        //But must make sure the reteam is on the latest iteration
        if ( lcmobject instanceof Iterated && !(VersionControlHelper.isLatestIteration((Iterated)lcmobject)) ) {
            lcmobject=(LifeCycleManaged)VersionControlHelper.getLatestIteration((Iterated)lcmobject);
        }

        Transaction trx = new Transaction();
        //Return the phase of the object that was passed in as the parameter.
        Phase currentPhase=null;
        if (lcmobject instanceof Workable ){
            if (WorkInProgressHelper.isWorkingCopy((Workable)lcmobject)) {
                //Current phase is associated with the original copy of the object.
                LifeCycleManaged temp_object = (LifeCycleManaged)WorkInProgressHelper.service.originalCopyOf((Workable)lcmobject);
                currentPhase = getCurrentPhase(temp_object);
            }else {
                currentPhase = getCurrentPhase(lcmobject);
            }
        }
        else {
            currentPhase = getCurrentPhase(lcmobject);
        }

        Phase objectPhase = null;
        try {
            trx.start();
            //Teams can be shared, must reteam all objects that share this team.
            Enumeration enumer=findTeamsObjects((Team)lcmobject.getTeamId().getObject());
            while(enumer.hasMoreElements()) {
                lcmobject=(LifeCycleManaged)enumer.nextElement();
                if(lcmobject.getState().equals(State.DROPPED)) {
                    // If life cycle is dropped, we do not need to update acl.
                    continue;
                }
                else if (lcmobject instanceof Workable) {
                    if (WorkInProgressHelper.isWorkingCopy((Workable)lcmobject)) {
                        //Current phase is associated with the original copy of the object.
                        LifeCycleManaged temp_object = (LifeCycleManaged)WorkInProgressHelper.service.originalCopyOf((Workable)lcmobject);
                        objectPhase = getCurrentPhase(temp_object);
                    }else {
                        objectPhase = getCurrentPhase(lcmobject);
                    }
                }
                else if (lcmobject instanceof RevisionControlled && !((RevisionControlled)lcmobject).isLatestIteration()) {
                    //We only want to update the latest iteration.
                    continue;
                }
                else {
                    objectPhase = getCurrentPhase(lcmobject);
                }


                /* record history */
                saveHistory(lcmobject,objectPhase,AUGMENT);

                /* build the AdHocAcls */
                buildAdHocAcl(lcmobject,objectPhase);

                //--Dispatch the augment event
                dispatchVetoableEvent( LifeCycleServiceEvent.AUGMENT, lcmobject );
            }


            trx.commit();
            trx = null;
        }
        catch (WTPropertyVetoException veto) {
            if(logger.isDebugEnabled()){
                logger.debug(veto.getLocalizedMessage(), veto);
            }
            throw new LifeCycleException(veto);
        }
        catch (WTException wex) {
            if(logger.isDebugEnabled()){
                logger.debug(wex.getLocalizedMessage(), wex);
            }
            throw new LifeCycleException(wex);
        }
        finally {
            if (trx != null)
                trx.rollback();

            if (logger.isTraceEnabled())
                logger.trace("Removing the AUGMENT_LC_ROLES_EVENT from MethodContext.");

            MethodContext.getContext().remove("AUGMENT_LC_ROLES_EVENT");
        }

        if (logger.isTraceEnabled())
            logger.trace("Exit augmentRoles");

        return (Phase)PersistenceServerHelper.manager.restore(currentPhase);

    }

    @Override
    public WTCollection augmentRoles(Set<LifeCycleManaged> lcmObject)
            throws WTException,  LifeCycleException {

        //check for Basic life cycle
        //Restore all objects
        //Get the current copy and check for
        WTCollection lcmObjectCollection = new WTArrayList(1);
        if (logger.isTraceEnabled())
            logger.trace("Enter augmentRoles(Set<LifeCycleManaged> lcmObject)");

        if (lcmObject.isEmpty()) return lcmObjectCollection;

        LifeCycleManaged lcmobject =null;
        Transaction trx = new Transaction();
        Vector objVector=null;
        Phase objectPhase = null;
        WTKeyedMap phaseMap = new WTKeyedHashMap();
        Iterator iterator=null;

        try {
            trx.start();
            iterator=lcmObject.iterator();
            while(iterator.hasNext()){
                lcmobject =(LifeCycleManaged) iterator.next();
                if(!lcmobject.isLifeCycleBasic()){
                    Enumeration enumer =findTeamsObjects((Team)lcmobject.getTeamId().getObject());;
                    while(enumer.hasMoreElements()) {
                        lcmobject=(LifeCycleManaged)enumer.nextElement();
                        if(lcmobject.getState().equals(State.DROPPED)) {
                            // If life cycle is dropped, we do not need to update acl.
                            continue;
                        }
                        else if (lcmobject instanceof Workable) {
                            if (WorkInProgressHelper.isWorkingCopy((Workable)lcmobject)) {
                                //Current phase is associated with the original copy of the object.
                                LifeCycleManaged temp_object = (LifeCycleManaged)WorkInProgressHelper.service.originalCopyOf((Workable)lcmobject);
                                objectPhase = getCurrentPhase(temp_object);
                            }else {
                                objectPhase = getCurrentPhase(lcmobject);
                            }
                        }
                        else if (lcmobject instanceof RevisionControlled && !((RevisionControlled)lcmobject).isLatestIteration()) {
                            //We only want to update the latest iteration.
                            continue;
                        }
                        else {
                            objectPhase = getCurrentPhase(lcmobject);
                        }
                        lcmObjectCollection.add(lcmobject);
                        phaseMap.put(lcmobject, objectPhase);
                        if (logger.isDebugEnabled()){
                            logger.debug("Put In Phase map ::Key ::"+lcmobject+"Value::"+objectPhase);
                        }
                    }

                }
            }
            this.saveHistory((WTList)lcmObjectCollection, phaseMap, AUGMENT);
            this.applyLifeCyclePermissions(lcmObjectCollection, true);
            this.dispatchVetoableMultiObjectEvent( LifeCycleServiceEvent.AUGMENT, lcmObjectCollection);
            trx.commit();
            trx = null;
        }
        catch (WTPropertyVetoException veto) {
            if(logger.isDebugEnabled()){
                logger.debug(veto.getLocalizedMessage(), veto);
            }
            throw new LifeCycleException(veto);
        }
        catch (WTException wex) {
            if(logger.isDebugEnabled()){
                logger.debug(wex.getLocalizedMessage(), wex);
            }
            throw new LifeCycleException(wex);
        }
        finally {
            if (trx != null)
                trx.rollback();

            if (logger.isTraceEnabled())
                logger.trace("Removing the AUGMENT_LC_ROLES_EVENT from MethodContext.");

            MethodContext.getContext().remove("AUGMENT_LC_ROLES_EVENT");
        }

        if (logger.isTraceEnabled())
            logger.trace("Exit augmentRoles(Set<LifeCycleManaged> lcmObject)");

        return lcmObjectCollection;
    }


    /**
     * This operation determines the current state of the object and returns
     * the successor state for the object.  That is, the state the object
     * will be in when promoted.
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     lcmObject  The Life Cycle Managed object used to get the next state.
     * @return    State
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public State getSuccessorState( LifeCycleManaged lcmObject )
            throws WTException, LifeCycleException {

        Phase currentPhase = getCurrentPhase(lcmObject);
        PhaseTemplate currentPhaseTemplate = null;
        if (currentPhase == null) {
            if (logger.isTraceEnabled() ) {
                logger.trace("getSuccessorState:  Object is basic life cycle managed. Get the phase template of the object for the template of the current phase.");
            }
            currentPhaseTemplate = getPhaseTemplate(lcmObject);
        }
        else
            currentPhaseTemplate = (PhaseTemplate)currentPhase.getPhaseTemplateId().getObject();

        PhaseTemplate successor = null;
        if(!currentPhaseTemplate.isFinalPhase())
            successor=getSuccessorPhase(currentPhaseTemplate);
        else
            return null;
        return successor.getPhaseState();
    }

    /**
     * This operation determines the current state of the object and returns
     * the predecessor state for the object.  That is, the state the object
     * will be in when demoted
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     lcmObject  The Life Cycle Managed object used to get the next state.
     * @return    State
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public State getPredecessorState( LifeCycleManaged lcmObject )
            throws WTException, LifeCycleException {

        Phase currentPhase=getCurrentPhase(lcmObject);
        PhaseTemplate currentPhaseTemplate = null;
        if (currentPhase == null) {
            if (logger.isTraceEnabled()) {
                logger.trace("getPredecessorState:  Object is basic life cycle managed. Get the phase template of the object for the template of the current phase.");
            }
            currentPhaseTemplate = getPhaseTemplate(lcmObject);
        }
        else
            currentPhaseTemplate = (PhaseTemplate)currentPhase.getPhaseTemplateId().getObject();
        PhaseTemplate predecessor;
        if (!currentPhaseTemplate.equals(getInitialPhase(lcmObject)))
            predecessor = getPredecessorPhase(currentPhaseTemplate);
        else
            return null;

        return predecessor.getPhaseState();
    }

    /**
     * Determines if a given user is entitled to create a Life Cycle Templates.
     *  Returns 'true' if the user is an Org Administrator or an Exhange
     * Administrator.
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     user  the user to test for lifecycle creation validation
     * @return    boolean
     * @exception wt.util.WTException
     **/

    public boolean canCreateLifeCycleTemplate( WTUser user )
            throws WTException {
        WTContainerRef exchange = WTContainerHelper.service.getExchangeRef();//WTContainerHelper.service.getClassicRef(); The API getClassicRef() should have been deprecated
        return canCreateLifeCycleTemplate(user, exchange);
    }

    /**
     * Given a team, rebuild all the ad hoc acls for objects associated with
     * the team.
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     team  The team being updated.
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/


    public void augmentRoles( Team team )
            throws WTException, LifeCycleException {
        if (logger.isTraceEnabled())
            logger.trace("Enter augmentRoles");

        // - check to make sure the object passed in is the latest iteration
        @SuppressWarnings("unused")
        String action = WTMessage.getLocalizedMessage(
                RESOURCE,
                AUGMENT,
                null);

        Transaction trx = new Transaction();
        LifeCycleManaged object=null;
        Phase objectPhase = null;
        try {
            trx.start();
            //Must reteam all objects that share this team.
            Enumeration enumer=findTeamsObjects(team);
            while(enumer.hasMoreElements()) {
                object=(LifeCycleManaged)enumer.nextElement();

                if (object.isLifeCycleBasic()) {
                    if (logger.isTraceEnabled() )
                        logger.trace("augmentRoles: Object is basic lifecycle managed. Do nothing.");
                    continue;
                }

                if(object.getState().equals(State.DROPPED)) {
                    // If life cycle is dropped, we do not need to update acl.
                    continue;
                }
                else if (object instanceof Workable ){
                    if ( WorkInProgressHelper.isWorkingCopy((Workable)object)) {
                        //Current phase is associated with the original copy of the object.
                        LifeCycleManaged temp_object = (LifeCycleManaged)WorkInProgressHelper.service.originalCopyOf((Workable)object);
                        objectPhase = getCurrentPhase(temp_object);
                    }else {
                        objectPhase = getCurrentPhase(object);
                    }
                }
                else if (object instanceof RevisionControlled && !((RevisionControlled)object).isLatestIteration()) {
                    //We only want to update the latest iteration.
                    continue;
                }
                else {
                    objectPhase = getCurrentPhase(object);
                }

                /* build the AdHocAcls */
                buildAdHocAcl(object,objectPhase);
            }


            trx.commit();
            trx = null;
        }
        catch (WTException wex) {
            if(logger.isDebugEnabled()){
                logger.debug(wex.getLocalizedMessage(), wex);
            }
            throw new LifeCycleException(wex);
        }
        finally {
            if (trx != null)
                trx.rollback();
        }

        if (logger.isTraceEnabled())
            logger.trace("Exit augmentRoles");
    }

    /**
     * Given a String representation of the LifeCycleTemplate name and a
     * WTContainerRef, answer the LifeCycleTemplate.  If no template is found,
     * return <code>null/code>.
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     aTemplateName  the name of the LifeCycleTemplate to retrieve
     * @param     context  the container to search for the lifecycle template
     * @return    LifeCycleTemplate
     * @exception wt.lifecycle.LifeCycleException
     * @exception wt.util.WTException
     **/

    public LifeCycleTemplate getLifeCycleTemplate( String aTemplateName, WTContainerRef context )
            throws LifeCycleException, WTException {
        if (logger.isTraceEnabled()) {
            logger.trace("Enter getLifeCycleTemplate: " +
                    aTemplateName + " - in container: " +
                    context.getName());
        }
        LifeCycleTemplate aTemplate = getLCT(aTemplateName, context);


        if (logger.isTraceEnabled()) {
            logger.trace("Exit getLifeCycleTemplate");
            if (aTemplate == null)
                logger.trace("Not Found:"+aTemplateName);
            else
                logger.trace("Found:"+aTemplate.getName());
        }
        return aTemplate;
    }

    /**
     * Given a String representation of the LifeCycleTemplater name and a
     * WTContainerRef, find the latest iteration or working copy of the LifeCycleTemplate.
     *  Return a LifeCycleTemplateReference.
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     aName  the name of the LifeCycleTemplate to retrieve
     * @param     context  the container to search for the lifecycle template master
     * @return    LifeCycleTemplateReference
     * @exception wt.lifecycle.LifeCycleException
     * @exception wt.util.WTException
     **/

    public LifeCycleTemplateReference getLifeCycleTemplateReference( String aName, WTContainerRef context )
            throws LifeCycleException, WTException {


        LifeCycleTemplateMaster aMaster = null;
        if (context == null) {
            aMaster = getLifeCycleTemplateMaster(aName, WTContainerHelper.service.getExchangeRef());
        }
        else {
            aMaster = getLifeCycleTemplateMaster(aName, context);
        }
        if (aMaster != null)
            return aMaster.getLifeCycleTemplateReference();
        else
            return null;
    }

    /**
     * Answer a vector of all life cycle templates for the WTContainerRef
     * passed.  The latest iteration of each life cycle template will be
     * returned.  In this particular context, the definition of 'latest iteration'
     * is either the current user's working copy, if one exists, or the latest
     * iteration in the vault.
     *
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     context  the container to search for lifecycle templates
     * @return    Vector
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/


    public Vector findAllTemplates( WTContainerRef context )
            throws WTException, LifeCycleException {
        if (logger.isTraceEnabled())
            logger.trace("Enter findAllTemplates(WTContainerRef)");

        Vector lastTemps = findAllTemplates (context, false);

        if (logger.isTraceEnabled())
            logger.trace("Exit findAllTemplates() - found "+lastTemps.size());

        return lastTemps;

    }

    /**
     * Given a String representation of the LifeCycleTemplateMaster name
     *  and a WTContainerRef, answer the LifeCycleTemplateMasterReference
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     aMasterName  the name of the LifeCycleTemplate to retrieve
     * @param     context  the container to search for the lifecycle template master
     * @return    LifeCycleTemplateMaster
     * @exception wt.lifecycle.LifeCycleException
     * @exception wt.util.WTException
     **/

    public LifeCycleTemplateMaster getLifeCycleTemplateMaster( String aMasterName, WTContainerRef context )
            throws LifeCycleException, WTException {
        if (logger.isTraceEnabled()) {
            logger.trace("Enter getLifeCycleTemplateMaster:" + aMasterName);
        }

        LifeCycleTemplateMaster aMaster = null;
        LifeCycleTemplate template = getLifeCycleTemplate(aMasterName, context);
        if (template != null) {
            aMaster = (LifeCycleTemplateMaster)((LifeCycleTemplate)template).getMaster();
        }

        if ( logger.isTraceEnabled() ) {
            logger.trace("Exit getLifeCycleTemplate");
            if (aMaster == null)
                logger.trace("Not Found:"+aMasterName);
            else
                logger.trace("Found:"+aMaster.getName());
        }

        return aMaster;
    }

    /**
     * Reassign a life cycle managed object to a new life cycle in a certain
     *  WTContainerRef.
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     object  the LifeCycleManaged object that should be assigned to a new life cycle
     * @param     lctRef  a reference to a LifeCycleTemplate, the LifeCycleTemplate that the object should be reassigned to
     * @param     context  the container where the objects associated workflow processes will be created
     * @return    LifeCycleManaged
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public LifeCycleManaged reassign( LifeCycleManaged object, LifeCycleTemplateReference lctRef, WTContainerRef context )
            throws WTException, LifeCycleException {

        if (logger.isTraceEnabled())
            logger.trace("=> reassign: " + getOid (object) +
                    ", template = " + lctRef + ", container = " + context);
        return reassign(object, lctRef, context, null);
    }

    /**
     * Store or update a LifeCycleTemplate. This method accepts and processes
     * a batch container of persistence assertions.  If a WTContainerRef
     * is passed, and it is different that that of this templates master;
     * then a new master is created in the passed WTContainer, and this template
     * becomes the first iteration.
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     aTran  a TransactionContainer that contains a set of LifeCycleTemplate, PhaseTemplate, AdHocAclSpec, Criterion and Transition assertions that need to be applied against one or more LifeCycleTemplate objects
     * @param     context  the container the lifecycle template is being saved in
     * @return    TransactionResult
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public TransactionResult saveLifeCycleTemplate( TransactionContainer aTran, WTContainerRef context )
            throws WTException, LifeCycleException {
        return LifeCycleDefinitionHandler.processLifeCycleTemplateTransaction(aTran);
    }

    /**
     * Answer a vector of life cycle template references valid for the target
     * class in the container.
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     targetClass  the class used as search criteria in the retrieval of canidate LifeCycleTemplates
     * @param     context  the container to search for lifecycle template masters
     * @return    Vector
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    @SuppressWarnings({ "deprecation"})
    public Vector findCandidateMasterReferences( Class targetClass, WTContainerRef context )
            throws WTException, LifeCycleException {
        if (logger.isTraceEnabled())
            logger.trace("Enter findCandidateMasterReferences" +
                    "(Class, container)");
        WTContainer container = null;
        /* 1. Get the templates that work for this class */
        Enumeration e = null;
        if (context == null) {
            e = findTemplateMasterByClass(targetClass, WTContainerHelper.service.getExchangeRef());
        }
        else {
            e = findTemplateMasterByClass(targetClass, context);
            container = context.getContainer();
        }



        /* 2. Build a list of names */
        Vector lctmReferences = new Vector();
        while (e.hasMoreElements()) {
            LifeCycleTemplateMaster master = (LifeCycleTemplateMaster)e.nextElement();
            //-- filter out any LifeCycleTemplateMasters whose only iteration
            //--the current user won't have access to
            LifeCycleTemplate template = getLatestIteration(master);
            if (template !=null) {
                lctmReferences.addElement(LifeCycleTemplateMasterReference.newLifeCycleTemplateMasterReference(master));
            }

        }

        if (logger.isTraceEnabled())
            logger.trace("Exit findCandidateMasterReferences" +
                    "(Class, context) - found " +
                    lctmReferences.size() + " candidates");

        return lctmReferences;

    }

    /**
     * Answer a vector of all life cycle template masters for the WTContainerRef
     * passed.  The latest iteration of each life cycle template will be
     * returned.  In this particular context, the definition of 'latest iteration'
     * is either the current user's working copy, if one exists, or the latest
     * iteration in the vault.
     *
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     context  the container to search for lifecycle templates
     * @return    QueryResult
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    @SuppressWarnings("deprecation")
    public QueryResult findAllTemplateMasters( WTContainerRef context )
            throws WTException, LifeCycleException {

        if (logger.isTraceEnabled())
            logger.trace("=> findAllTemplateMasters: " + context );

        QuerySpec qs = new QuerySpec(LifeCycleTemplateMaster.class);
        qs.appendOrderBy(LifeCycleTemplateMaster.class,
                LifeCycleTemplateMaster.NAME,
                false);
        LookupSpec ls = new LookupSpec(qs, context);
        //- This should find all template masters, in all containers
        //- looking up from the container passed?
        //-
        try {
            ls.setFirstMatchOnly(false);
        }
        catch (WTPropertyVetoException wpve) {
            if(logger.isDebugEnabled()){
                logger.debug(wpve.getLocalizedMessage(), wpve);
            }
            throw new WTException (wpve);
        }
        QueryResult qR=WTContainerHelper.service.lookup(ls);
        if(logger.isTraceEnabled())
            logger.trace("=> findAllTemplateMasters: - OUT: ");
        return qR;
    }

    /**
     * Set/reset the rouing attribute on the Life Cycle Template Master.
     * This attribute denotes whether or not the template master can be used
     * to route other objects
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     aTemplate  the template to set the routing statis on
     * @param     routing  sets the routing flag to true or false
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public void setRouting( LifeCycleTemplate aTemplate, boolean routing )
            throws WTException, LifeCycleException {

        LifeCycleTemplateMaster aMaster = (LifeCycleTemplateMaster)((LifeCycleTemplate)aTemplate).getMaster();
        setRouting(aMaster, routing);
    }

    /**
     * Set/reset the routing attribute of the Life Cycle Template Master.
     * This attribute denotes whether or not the template master can be used
     * to route other objects
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     aMaster  the lifecycle template master to set the routing status on
     * @param     routing  sets the routing flag to true or false
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public void setRouting( LifeCycleTemplateMaster aMaster, boolean routing )
            throws WTException, LifeCycleException {
        LifeCycleTemplateMaster lctmaMaster = aMaster;
        lctmaMaster = (LifeCycleTemplateMaster)PersistenceServerHelper.manager.restore(lctmaMaster);

        if ( ( (routing) && (lctmaMaster.isRouting()) ) ||   // If it's alaready enabled, do nothing
                ( (!routing) && (!lctmaMaster.isRouting()) )  )  { //If it's already disabled, do nothing
            if ( logger.isDebugEnabled() )
                logger.debug("The Life Cycle Template Master's routing attribute is already set to " + lctmaMaster.isRouting());
        }
        else if (!AccessControlHelper.manager.hasAccess(getLatestIteration(lctmaMaster), AccessPermission.MODIFY)) {
            Object[] param = { IdentityFactory.getDisplayIdentity(getLatestIteration(lctmaMaster)) };
            AccessControlHelper.manager.emitAccessEvent (
                    AccessControlEvent.NOT_AUTHORIZED, getLatestIteration(lctmaMaster), AccessPermission.MODIFY,
                    new WTMessage (RESOURCE, lifecycleResource.CREATE_LCT_NOT_ALLOWED, param));
            throw new LifeCycleException(RESOURCE, lifecycleResource.MODIFY_NOT_ALLOWED, param);
        }
        else {
            Transaction trx = new Transaction();
            try {
                trx.start();
                lctmaMaster.setRouting(routing);
                PersistenceHelper.manager.modify(lctmaMaster);
                trx.commit();
                trx = null;
            }
            finally {
                if (trx != null)
                    trx.rollback();
            }
        }


    }

    /**
     * Return an Enumeration of all lifecycle templates for the WTContainerRef
     * passed. The latest iteration of each life cycle template will be returned.
     *  In this particular context, the definition of 'latest iteration'
     * is either the current user's working copy, if one exists, or the latest
     * iteration in the vault.
     *
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     context  the container to search for lifecycle templates
     * @return    Vector
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public Vector findRoutingTemplates( WTContainerRef context )
            throws WTException, LifeCycleException {

        return findAllTemplates(context, true);
    }

    /**
     * Answer a vector of all life cycle templates for the WTContainerRef
     * passed.  If routingOnly is true, returns only those templates whose
     * routing attribute is true.  If keepFiltered is true, returns templates
     * that have been hidden in the container context, otherwise only those
     * templates that are visible in the container context are returned.
     *  The latest iteration of each life cycle template will be returned.
     *  In this particular context, the definition of 'latest iteration'
     * is either the current user's working copy, if one exists, or the latest
     * iteration in the vault.
     *
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     context  the container to search for lifecycle templates
     * @param     routingOnly  specifies whether only the lifecycle templates marked as routing should be returned or it all enabled lifecycle templates should be returned
     * @param     keepFiltered  Indicates whether or not filtered templates are to be returned.  If true, return all templates, otherwise return only those templates that are visible in the container context.
     * @return    Vector
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    @SuppressWarnings("deprecation")
    public Vector findAllTemplates( WTContainerRef context, boolean routingOnly, boolean keepFiltered )
            throws WTException, LifeCycleException {
        if (logger.isTraceEnabled())
            logger.trace("=> findAllTemplates: " + context + ", routingOnly = " + routingOnly);
        EnumeratorVector lastTemps = new EnumeratorVector ();
        // 1. Retrieve all Enabled LifeCycleTemplates
        QuerySpec qs = new QuerySpec(LifeCycleTemplateMaster.class);
        if (routingOnly) {
            qs.appendWhere ( new SearchCondition ( LifeCycleTemplateMaster.class,
                    LifeCycleTemplateMaster.ROUTING,
                    SearchCondition.IS_TRUE), 0);
        }
        qs.appendOrderBy(LifeCycleTemplateMaster.class,
                LifeCycleTemplateMaster.NAME,
                false);
        LookupSpec ls = new LookupSpec(qs, context);
        //- This should find all template masters, in all containers
        //- looking up from the container passed?
        //-
        try {
            if (routingOnly)  //Routing should display only the first match found.
                ls.setFilterOverrides(true);
            else
                ls.setFirstMatchOnly(false);

            //  Set to return filtered templates if so requested
            ls.setOverrideFilterableVisibility(keepFiltered);
        }
        catch (WTPropertyVetoException wpve) {
            if(logger.isDebugEnabled()){
                logger.debug(wpve.getLocalizedMessage(), wpve);
            }
            throw new WTException (wpve);
        }
        QueryResult qr = WTContainerHelper.service.lookup(ls);

        //SPR#1271466: we comment SortedEnumeration and write code for case sensitive sorting

        //SortedEnumeration enumer = null;
        Enumeration enumer = null;
        //QueryCollationKeyFactory collation_key = new QueryCollationKeyFactory(getLocale(), "name" );
        if( qr != null ) {
            //enumer = new SortedEnumeration( qr.getEnumeration(), collation_key );
            enumer = qr.getEnumeration();
            TreeMap treeTemp = new TreeMap();
            while (enumer.hasMoreElements ()) {
                LifeCycleTemplateMaster master = (LifeCycleTemplateMaster)enumer.nextElement();
                if (master != null) {
                    treeTemp.put(master.getName()+":"+master.getContainerName(),master);
                }
            }

            Map treeTempMap = (Map)treeTemp;

            for (Iterator it = treeTempMap.values().iterator(); it.hasNext();) {
                LifeCycleTemplateMaster master = (LifeCycleTemplateMaster)it.next();
                Enumeration latestEnum = ConfigHelper.service.filteredIterationsOf (master, new LatestConfigSpec ());
                if (latestEnum.hasMoreElements ()) {
                    //lastTemps.addElement (latestEnum.nextElement ());
                    LifeCycleTemplate template= (LifeCycleTemplate)latestEnum.nextElement ();
                    WTContainer container =template.getContainer();
                    Cabinet cabinet = (Cabinet)template.getCabinet().getObject();
                    lastTemps.addElement (template);
                }
            }
        }

        if (logger.isTraceEnabled())
            logger.trace("    findAllTemplates - OUT: " + lastTemps.size());
        return lastTemps;
    }

    /**
     * Answer a vector of all life cycle templates for the WTContainerRef
     * passed.  If routingOnly is true, returns only those templates whose
     * routing attribute is true. The latest iteration of each life cycle
     * template will be returned.  In this particular context, the definition
     * of 'latest iteration' is either the current user's working copy, if
     * one exists, or the latest iteration in the vault.  This API will call
     * findAllTemplates(WTContainerRef context, boolean routingOnly, boolean
     * keepFiltered) with a value of false for the keepFiltered argument.
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     context  the container to search for lifecycle templates
     * @param     routingOnly  specifies whether only the lifecycle templates marked as routing should be returned or it all enabled lifecycle templates should be returned
     * @return    Vector
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public Vector findAllTemplates( WTContainerRef context, boolean routingOnly )
            throws WTException, LifeCycleException {
        return findAllTemplates(context,routingOnly, false);
    }

    /**
     * Determines if a given user is entitled to create a Life Cycle Templates
     * in the given container.  Returns 'true' if the user is an Org Administrator
     * or an Exhange Administrator.
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     user  the user to validate creation privileges against
     * @param     context  the container to validate access against
     * @return    boolean
     * @exception wt.util.WTException
     **/

    public boolean canCreateLifeCycleTemplate( WTUser user, WTContainerRef context )
            throws WTException {
        if(WTContainerHelper.service.isAdministrator(context, (WTPrincipal) user)){
            return true;
        }else{
            /*
          Check if the user belongs to the "LifeCycleAdministrators" group.
             */
            Enumeration strGroupNames = user.parentGroupNames();
            while( strGroupNames.hasMoreElements() ){
                String tempStrObj = (String)strGroupNames.nextElement();
                if( tempStrObj.equals("LifeCycleAdministrators") )
                    return true;
            }//end of for
        }//end of if-else
        return false;
    }

    /**
     * Produces a copy of the LifeCycleTemplate object and persists it with
     * the name passed as argument. If the name argument is "null", the name
     * of the copied LifeCycleTemplate object  is prefixed with 'copy of'.
     *  If the folder location is not specified, the object will be persisted
     * in the orginal LifeCycleTemplates's folder location.  If the context
     * is null, the current container will be used.
     *
     * Note:  The 'Copy Of' prefix is pulled from a Resource Bundle for localization
     * purposes.
     *
     *
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     lifeCycleTemplate  the LifeCycleTemplate object that should be copied
     * @param     copyName  the name of the new LifeCycleTemplate
     * @param     folderLocation  the folder location of the new LifeCycleTemplate
     * @param     context  the container where the copy should be stored
     * @return    LifeCycleTemplate
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/
    @Override
    @SuppressWarnings("deprecation")
    public LifeCycleTemplate copyTemplate(LifeCycleTemplate lifeCycleTemplate, String copyName, String folderLocation,
            WTContainerRef context) throws LifeCycleException, WTException {
        return copyTemplate(lifeCycleTemplate, copyName, folderLocation, context, true);
    }


    /**
     * @see wt.lifecycle.LifeCycleService#copyTemplate(wt.lifecycle.LifeCycleTemplate, java.lang.String, java.lang.String, wt.inf.container.WTContainerRef, boolean)
     */
    @Override
    @SuppressWarnings("deprecation")
    public LifeCycleTemplate copyTemplate( LifeCycleTemplate lifeCycleTemplate, String copyName, String folderLocation, WTContainerRef context, boolean checkPermissions )
            throws WTException, LifeCycleException {
        if (logger.isTraceEnabled()) {
            logger.trace("Enter copyTemplate");
        }


        LifeCycleTemplate newLifeCycleTemplate = null;




        MethodContext mc = MethodContext.getContext();
        try {
            newLifeCycleTemplate = LifeCycleTemplate.newLifeCycleTemplate();
            if ((copyName != null) && (copyName.length() > 0))
                newLifeCycleTemplate.setName(copyName);
            else
                newLifeCycleTemplate.setName(WTMessage.getLocalizedMessage(RESOURCE,lifecycleResource.COPY_OF,null) +
                        " " +
                        lifeCycleTemplate.getName());
            newLifeCycleTemplate.setDescription(lifeCycleTemplate.getDescription());
            newLifeCycleTemplate.setSupportedClass(lifeCycleTemplate.getSupportedClass());
            newLifeCycleTemplate.setEnabled(lifeCycleTemplate.isEnabled());
            newLifeCycleTemplate.setContainerReference(context);
            newLifeCycleTemplate.setBasic(lifeCycleTemplate.isBasic());

            Folder personal=FolderHelper.service.getPersonalCabinet(null);
            if ((folderLocation != null) && (folderLocation.length() > 0)) {
                if (folderLocation.equals(personal.getFolderPath()))
                    FolderHelper.assignLocation(newLifeCycleTemplate, personal);
                else
                    FolderHelper.assignLocation(newLifeCycleTemplate, folderLocation, context);
            }
            else {
                if (WTContainerHelper.isClassicRef(context))
                    FolderHelper.assignLocation(newLifeCycleTemplate, FolderHelper.getFolder(lifeCycleTemplate));
                else
                    FolderHelper.assignLocation(newLifeCycleTemplate, personal);
            }

            // - Before saving, check to make sure
            // - the user will have permission
            if (!AccessControlHelper.manager.hasAccess(newLifeCycleTemplate,
                    AccessPermission.CREATE)) {
                AccessControlHelper.manager.emitAccessEvent (
                        AccessControlEvent.NOT_AUTHORIZED, null, AccessPermission.CREATE,
                        new WTMessage (RESOURCE, lifecycleResource.CREATE_LCT_NOT_ALLOWED, null));
                throw new LifeCycleException(RESOURCE, lifecycleResource.CREATE_LCT_NOT_ALLOWED, null);
            }

            mc.put(BYPASS_DEFAULT_TRANSITIONS, Boolean.TRUE);
            newLifeCycleTemplate = (LifeCycleTemplate)PersistenceHelper.manager.save(newLifeCycleTemplate);
            copyObjectsRelatedToLifeCycleTemplate(lifeCycleTemplate, newLifeCycleTemplate);
        }
        catch (WTPropertyVetoException wtpve) {
            if(logger.isDebugEnabled()){
                logger.debug(wtpve.getLocalizedMessage(),wtpve);
            }
            throw new LifeCycleException(wtpve);
        }
        finally {
            mc.remove("bypassDefaultTransitions");
        }

        if (logger.isTraceEnabled())
            logger.trace("Exit copyTemplate");

        return (LifeCycleTemplate)PersistenceHelper.manager.refresh(newLifeCycleTemplate);

    }

    /**
     * Navigate the transition of the current state of the LifeCycleManagedObject
     * using the passed transition.  Return a set of States
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     lcmObject  LifeCycleManagedObject
     * @param     name  Transition to navigate
     * @param     successor  get Successors
     * @return    Set
     * @exception wt.util.WTException
     **/

    public Set navigate( LifeCycleManaged lcmObject, Transition name, boolean successor )
            throws WTException {

        State state = lcmObject.getState().getState();
        LifeCycleTemplateReference lctRef = lcmObject.getLifeCycleTemplate();
        LifeCycleTemplate lct=null;
        
        if (logger.isTraceEnabled())
            logger.trace("=> navigate( LifeCycleManaged lcmObject, Transition name, boolean successor ): lcmObject = "
                    + lcmObject + ", Transition = " + name);

        return navigate(lctRef, state, name, true);
    }

    
    /**
     * Reassign all objects in a WTList to a lifecycle.
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     list  the WtList of LifeCycleManaged objects that should be assigned to a new life cycle
     * @param     lctRef  a reference to a LifeCycleTemplate, the LifeCycleTemplate that the object should be reassigned to
     * @param     context  The container the object resides in.   This may be null.
     * @param     preserveState  If this is set to true, the existing state of objects will be preserved if the state is contained in the lifecycle template.  Otherwise, the object will be set to the initial state of the lifecycle.
     * @return    WTList
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public WTList reassign( WTList list, LifeCycleTemplateReference lctRef, WTContainerRef context, boolean preserveState )
            throws WTException, LifeCycleException {

        if (logger.isTraceEnabled())
            logger.trace("=> reassign: WTCollection, template = " + lctRef + ", container = " + context);

        return reassign(list, lctRef, context, preserveState, null);
    }

    /**
     * Reassign the life cycle managed objects in a WTList to a new life
     * cycle in a certain  WTContainerRef.
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     list  the WTList of LifeCycleManaged objects that should be assigned to a new life cycle
     * @param     lctRef  a reference to a LifeCycleTemplate, the LifeCycleTemplate that the object should be reassigned to
     * @param     context  The container which the object resides in.
     * @param     state  The state the objects in the lifecycle should be assigned when reassigned to the lifecycle.
     * @return    WTList
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public WTList reassign( WTList list, LifeCycleTemplateReference lctRef, WTContainerRef context, State state )
            throws WTException, LifeCycleException {

        if (logger.isTraceEnabled())
            logger.trace("=> reassign: WTCollection, template = " + lctRef + ", container = " + context + ", state= " + state);
        return reassign(list, lctRef, context, state, null);
    }

    /**
     * Set the state of the Life Cycle Managed objects and provide the option
     * to terminate the associated workflows.  If null is passed as the WfState,
     * all processes are terminated.
     *
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     list  The LifeCycleManaged objects whose state should be updated
     * @param     state  The state to set the LifeCycleManaged object to.
     * @param     terminAssocRunningProcesses  a flag that determines whether or not to terminate the wf processes associated with this phase that are OPEN_RUNNING
     * @return    WTList
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public WTList setLifeCycleState( WTList list, State state, boolean terminAssocRunningProcesses )
            throws WTException, LifeCycleException {
        if (logger.isTraceEnabled())
            logger.trace("=> setLifeCycleStates: WTCollection, state = " + state + ", terminate processes = " + terminAssocRunningProcesses);
        Transaction trx = new Transaction();
        try {
            trx.start();
            // 1. Make sure the user has authority to do this
            AccessControlHelper.manager.checkAccess(list, AccessPermission.ADMINISTRATIVE);
            if (terminAssocRunningProcesses)
                WfEngineHelper.service.terminateObjectsRunningWorkflows(list);

            setState(list, state);

            trx.commit();
            trx = null;
        }
        finally {
            if (trx != null)
                trx.rollback();
        }
        if (logger.isTraceEnabled())
            logger.trace("   setLifeCycleStates - OUT");

        return (WTList) CollectionsHelper.manager.refresh(list);

    }

    /**
     * Navigate the transition from the passed state using the passed transition.
     *  Return a set of States
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     lctRef  reference to the LifeCycleTemplate.
     * @param     state  State of the LifeCycleTemplate.
     * @param     transition  Transtion to navigate
     * @param     successor  get Successors
     * @return    Set
     * @exception wt.util.WTException
     **/

    public Set navigate( LifeCycleTemplateReference lctRef, State state, Transition transition, boolean successor )
            throws WTException {

        LifeCycleTemplate lct = (LifeCycleTemplate)lctRef.getObject();
        PhaseTemplate phaseTemplate = stateSearch(lct, state);
        if(phaseTemplate == null) {
            return new HashSet();
        }
        QueryResult result = PersistenceServerHelper.manager.expand(
                (Persistable) phaseTemplate,
                PhaseSuccession.SUCCESSOR_ROLE,
                PhaseSuccession.class,
                false);
        HashSet returnSet = new HashSet();
        if (result.size() != 0) {
            while (result.hasMoreElements()) {
                PhaseSuccession phaseSuccession = (PhaseSuccession)result.nextElement();
                if (transition == null || transition.equals(phaseSuccession.getName())) {
                    returnSet.add(((PhaseTemplate)phaseSuccession.getRoleBObject()).getPhaseState());
                }
            }
        }
        else {
            //Empty set
            return java.util.Collections.EMPTY_SET;
        }
        return returnSet;
    }

    /**
     * Determines the allowable states the session principal can set the
     * objects in the collection to.  The return type is a map with the lifecycle
     * managed objects assigned as keys and the value is a HashSet containing
     * the allowable states the user can assign to the object.
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     lcms  a collection of lifecycle managed objects
     * @return    WTKeyedMap
     * @exception wt.util.WTException
     **/


    public WTKeyedMap findSetStateCandidates( WTCollection lcms )
            throws WTException {


        WTKeyedMap ptStateMap = new WTKeyedHashMap();
        HashSet transitionSet = new HashSet();
        boolean firstTime = true;
        Iterator iter = lcms.persistableIterator();
        Transition ssTrans = Transition.toTransition("SET_STATE");
        WTKeyedHashMap returnMap = new WTKeyedHashMap();
        java.util.Hashtable lcTable= new java.util.Hashtable();

        while( iter.hasNext() ){
            LifeCycleManaged lcmo = (LifeCycleManaged)iter.next();


            if (AccessControlHelper.manager.hasAccess(lcmo, AccessPermission.ADMINISTRATIVE)) {
                LifeCycleTemplate lcTemplate = (LifeCycleTemplate)lcmo.getLifeCycleTemplate().getObject();

                if(!lcTable.containsKey(lcTemplate)){
                //    QuerySpec qs = new QuerySpec(wt.lifecycle.PhaseTemplate.class, wt.lifecycle.PhaseLink.class);
                //    QueryResult results = PersistenceServerHelper.manager.expand((Persistable) lcTemplate,PhaseLink.PHASE_ROLE,qs,true);
                  Enumeration results = getPhaseTemplates(lcTemplate).elements();
                  java.util.HashSet vstates = new java.util.HashSet();
                    while (results.hasMoreElements()) {
                        PhaseTemplate pt = (PhaseTemplate)results.nextElement();
                        State state = pt.getPhaseState();
                        vstates.add(state);
                    }
                    lcTable.put(lcTemplate, vstates);
                    returnMap.put(lcmo, vstates);
                }
                else{
                    java.util.HashSet vstates = new java.util.HashSet();
                    vstates= (java.util.HashSet)lcTable.get(lcTemplate);
                    returnMap.put(lcmo, vstates);
                }
            }
            else if (AccessControlHelper.manager.hasAccess(lcmo, AccessPermission.SET_STATE)){


                Set currentStateMap = new HashSet( );
                State state = lcmo.getState().getState();
                currentStateMap.add(state);
                ptStateMap.put(lcmo, currentStateMap);

            }
        }
        if (!ptStateMap.isEmpty()) {
            WTKeyedHashMap ssMap = (WTKeyedHashMap)LifeCycleHelper.service.navigate(ptStateMap, ssTrans, true);
            for (Iterator i = ssMap.wtKeySet().persistableIterator(); i.hasNext(); ) {
                WTObject p = (WTObject)i.next();
                WTKeyedHashMap transitionMap = (WTKeyedHashMap)ssMap.get(p);
                Iterator transitionIterator = transitionMap.wtKeySet().persistableIterator();
                WTArrayList transitionList = (WTArrayList)transitionMap.get(transitionIterator.next());
                Set states = new HashSet();
                Iterator tListIter = transitionList.persistableIterator();
                if (tListIter != null) {
                    while (tListIter.hasNext()) {
                        PhaseSuccession ps = (PhaseSuccession)tListIter.next();
                        PhaseTemplate pt = (PhaseTemplate)ps.getRoleBObject();
                        states.add(pt.getPhaseState());
                    }
                    returnMap.put(p, states);
                }
            }
        }
        return (returnMap);

    }

    /**
     * Navigate the PhaseSuccessors for the Transition for all objects in
     * the WTCollection.  Calls single-object navigate.  Use multi-object
     * instead.
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     c  a collection of lifecycle managed objects
     * @param     transition  the transition to navigate
     * @param     successor  boolean value to indicate if the navigate should be to a successor state
     * @return    Map
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/


    public Map navigate( WTCollection c, Transition transition, boolean successor )
            throws WTException, LifeCycleException {

        Iterator i = c.persistableIterator();

        HashMap map = new HashMap();
        LifeCycleTemplateReference lctRef = null;
        LifeCycleTemplate lct = null;
        
        while (i.hasNext()) {
            WTObject wtobject = (WTObject)i.next();
            if (!(wtobject instanceof LifeCycleManaged)) {
                Object[] param = { wtobject.getClass().toString() };
                throw new LifeCycleException( RESOURCE, lifecycleResource.INVALID_LCM_OBJECT, param );
            }

            LifeCycleManaged lcm = (LifeCycleManaged)wtobject;
            lctRef = lcm.getLifeCycleTemplate();

            Set set = navigate(lcm, transition, successor);
            map.put(lctRef, set);

        }
        return map;
    }

    /**
     * returns an ArrayList of LifeCycleSignatures for a LifeCycleHistory
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     history  the LifeCycleHistory of interest
     * @return    ArrayList
     * @exception wt.util.WTException
     **/


    public ArrayList getSignatures( LifeCycleHistory history )
            throws WTException {

        if (logger.isTraceEnabled())
            logger.trace("Entering getSignatrures(LifeCycleHistory): " + history);

        ArrayList list = new ArrayList();
        try {
            QueryResult results = PersistenceServerHelper.manager.expand(
                    history,
                    SignatureHistory.SIGNATURE_ROLE,
                    SignatureHistory.class,
                    true);
            while (results.hasMoreElements()) {
                list.add(results.nextElement());
            }
        }
        catch (WTException e) {
            if(logger.isDebugEnabled()){
                logger.debug(e.getLocalizedMessage(), e);
            }
            throw e;
        }

        if (logger.isTraceEnabled())
            logger.trace("Exiting getSignatrures(LifeCycleHistory), found " + list.size() + " signatures.");

        return list;

    }

    /**
     * returns an ArrayList of Criterion for a LifeCycleHistory
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     history  the LifeCycleHistory of interest
     * @return    ArrayList
     * @exception wt.util.WTException
     **/


    public ArrayList getCriterion( LifeCycleHistory history )
            throws WTException {

        ArrayList list = new ArrayList();
        try {
            QueryResult results = results = PersistenceServerHelper.manager.expand(
                    history,
                    CriterionHistory.CRITERION_ROLE,
                    CriterionHistory.class,
                    true);
            while (results.hasMoreElements()) {
                list.add(results.nextElement());
            }
        }
        catch (WTException e) {
            if(logger.isDebugEnabled()){
                logger.debug(e.getLocalizedMessage(), e);
            }
            throw e;
        }

        if (logger.isTraceEnabled())
            logger.trace("Exiting getSignatrures(LifeCycleHistory), found " + list.size() + " signatures.");

        return list;
    }

    /**
     * This API will check for ADMINISTRATIVE and SET_STATE permissions on object.
     * @param object - Lifecycle managed object permissions to check on
     * @param throwException - Throw an exception if permission are not defined.
     * @return true, if any of ADMINISTRATIVE and SET_STATE permission is defined. false, if both permissions are not defined and throwException is set to false.
     * @throws WTException
     * @throws NotAuthorizedException
     */
    private boolean _checkStateChangePermissions(LifeCycleManaged object, boolean throwException) throws WTException, NotAuthorizedException {
           // If doesnot have set_state permissions and doesnot have administrative permissions, throw not authorised excetion.
        if(! AccessControlHelper.manager.hasAccess(object, AccessPermission.ADMINISTRATIVE) && !AccessControlHelper.manager.hasAccess(object, AccessPermission.SET_STATE)) {
            if(throwException) {
                return AccessControlHelper.manager.checkAccess(object, AccessPermission.ADMINISTRATIVE) && AccessControlHelper.manager.hasAccess(object, AccessPermission.SET_STATE);
            }
            else
                return false;
        }

        return true;

    }

    /**
     * Set the state of the Life Cycle Managed object.
     *
     * User need ADMINISTRATIVE or SET_STATE permission on LifeCycleManaged object to change state. NotAuthorizedException is thrown otherwise.
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     object  The LifeCycleManaged object whose state should be updated
     * @param     state  The state to set the LifeCycleManaged object to.
     * @param     terminAssocRunningProcesses  a flag that determines whether or not to terminate the wf processes associated with this phase that are OPEN_RUNNING
     * @param     timestamp  An optional parameter that allows specification of the created and modified timestamps for the history objects.
     * @return    LifeCycleManaged
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public LifeCycleManaged setLifeCycleState( LifeCycleManaged object, State state, boolean terminAssocRunningProcesses, Timestamp timestamp )
            throws WTException, LifeCycleException {

        if (logger.isTraceEnabled())
            logger.trace("=> setLifeCycleState: " + getOid (object) +
                    ", state = " + state + ", terminate processes = " + terminAssocRunningProcesses + ", timestamp - " + timestamp);

        _checkStateChangePermissions(object, true);

        WTArrayList aList = new WTArrayList();
        WTArrayList tList = new WTArrayList();
        aList.add(object);
        WTKeyedHashMap setStateMap = new WTKeyedHashMap();
        setStateMap.put(object, state);
        if (terminAssocRunningProcesses) {
            WTContainerRef contRef = null;
            if(object instanceof WTContained){
                contRef = ((WTContained)object).getContainerReference();
            }else{
                //The object can be non-wtcontained.
                contRef = WTContainerHelper.service.getExchangeRef(); //WTContainerHelper.service.getClassicRef(); The API getClassicRef() should have been deprecated
            }
            Enumeration fapProcesses = WfEngineHelper.service.getAssociatedProcesses((Persistable)object, WfState.OPEN_RUNNING, contRef );
            while (fapProcesses.hasMoreElements()) {
                tList.add(fapProcesses.nextElement());
            }
            //terminateProcesses(fapProcesses);
            terminateProcesses(tList);
        }
        // setLifeCycleState ensures proper access
        setLifeCycleState(aList, setStateMap, tList);
        return object;
    }

    /**
     * Navigates the PhaseTemplate->PhaseSuccession using param transition.
     *  Returns a WTKeyedMap where the keys are the keys passed in param
     * c and the values WTKeyedHashMap where the keys are PhaseTemplates
     * and the values are sets of inflated PhaseSuccessions.
     * <p>
     * Usage:
     * <p>
     * <code>
     * WTKeyedHashMap map=new WTKeyedHashMap();
     * Set set = new Set[)
     * state=State.toState("DESIGN")
     * set.add(state)
     * map.put(lifecycleManagedObject, set)
     * WTKeyedHashSet returnMap = LifeCycleHelper.service.navigate(map, Transition.toTransition("SET_STATE"),
     * true)
     * </code>
     *
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     c  A WTKeyedMap that contains as its keys LifecycleManagedObject or LifeCycleTemplates and the values are a set of states to navigate.
     * @param     transition  the name of the transition to navigate
     * @param     successor  specifies whether or not to return the successor state or the predessor.
     * @return    Map
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public Map navigate( WTKeyedMap c, Transition transition, boolean successor )
            throws WTException, LifeCycleException {
        if (logger.isTraceEnabled())
            logger.trace("=> Start navigate( WTKeyedMap c, Transition transition, boolean successor ) :: " +  transition);
        // Iterator over LifeCycleTemplates
        Iterator lcti = c.wtKeySet().persistableIterator();
        // Iterate over states
        Iterator vi = c.values().iterator();
        // The map to return.  This map is LCT->States->PhaseSuccessions
        WTKeyedHashMap returnMap = new WTKeyedHashMap();
        // phaseTemplates->phaseSuccessions
        HashMap ptToPs = new HashMap();
        HashMap aLctMap = new HashMap();
        LifeCycleTemplate lct = null;
        WTObject wtObject = null;
        //created psetFinal which will store unique phase templates which is used to find PhaseSucession in find query
        WTHashSet ptSetFinal = new WTHashSet();
        //created map whose key phase template and value if wtobject i.e. either lifecycle template or lifecycle managed object
        HashMap objectPhastemplateMap = new HashMap();

        while (lcti.hasNext()) {
            wtObject = (WTObject)lcti.next();
            if (wtObject instanceof LifeCycleTemplate) {
                lct = (LifeCycleTemplate)wtObject;
            }
            else if (wtObject instanceof LifeCycleManaged) {
                LifeCycleManaged lcmObject = (LifeCycleManaged)wtObject;
                State state = lcmObject.getState().getState();
                LifeCycleTemplateReference lctRef = lcmObject
                        .getLifeCycleTemplate();
                lct = (LifeCycleTemplate)lctRef.getObject();

            }
            else {
                Object[] param = { wtObject.getClass().toString() };
                throw new LifeCycleException( RESOURCE, lifecycleResource.INVALID_LCM_OBJECT, param );
            }
            //lct = (LifeCycleTemplate)((wt.fc.ObjectReference)lcti.next()).getObject();
            // States are the value
            Set stateSet = (Set)vi.next();
            WTHashSet ptSet = new WTHashSet();
            ArrayList existingPtSets = new ArrayList();
            Iterator pti = stateSet.iterator();
            //stateSearch is optimized through the lct cache
            while (pti.hasNext()) {
                State state = (State)pti.next();
                PhaseTemplate pt = stateSearch(lct, state);
                if (pt != null) {
                    ptSet.add(pt);
                    //Added Phasetemplate
                    ptSetFinal.add(pt);
                    if(!objectPhastemplateMap.containsKey(pt)){
                        WTArrayList list = new WTArrayList();
                        list.add(wtObject);
                        objectPhastemplateMap.put(pt, list);

                    }else
                    {
                        WTArrayList list = (WTArrayList)objectPhastemplateMap.get(pt);
                        list.add(wtObject);
                        objectPhastemplateMap.put(pt, list);

                    }

                    //If phase template found then return map will alwyas contain values as following.
                    //{wt.part.WTPart:110327={wt.lifecycle.PhaseTemplate:110033=[wt.lifecycle.PhaseSuccession:110055]}}
                    //If PhaseSucession is not present then returnMap is {wt.part.WTPart:110327={wt.lifecycle.PhaseTemplate:110033=[]}}
                    WTKeyedHashMap emptyTransitionMap = new WTKeyedHashMap();
                    emptyTransitionMap.put(pt, new WTArrayList());
                    returnMap.put(wtObject, emptyTransitionMap);

                }
            }

            existingPtSets = new ArrayList();

            // Add the phasetemplate set to the existingPtSets lct->setofphasetemplates
            existingPtSets.add(ptSet);
            aLctMap.put(lct, existingPtSets);
            WTArrayList ptList = new WTArrayList(ptSet);
        }


        NavigateSpec navigateSpec = PersistenceHelper.buildNavigateSpec(ptSetFinal, PhaseSuccession.SUCCESSOR_ROLE,
                wt.lifecycle.PhaseSuccession.class, false);
        if (transition != null)
            navigateSpec.appendWhere(new SearchCondition(PhaseSuccession.class, PhaseSuccession.NAME, SearchCondition.EQUAL, transition), new int[] { 1 });
        SourceLinkMapResultProcessor resultProcessor =
                new SourceLinkMapResultProcessor(ptSetFinal, PhaseSuccession.SUCCESSOR_ROLE, wt.lifecycle.PhaseSuccession.class);
        resultProcessor = (SourceLinkMapResultProcessor) PersistenceHelper.manager.find(navigateSpec, resultProcessor);

        Map targetMap = resultProcessor.getTargetMap();
        if (targetMap != null) {
            Iterator itrPhasesucession= targetMap.keySet().iterator();
            while(itrPhasesucession.hasNext()){
                ObjectReference objref = (ObjectReference)itrPhasesucession.next();
                if (logger.isTraceEnabled())
                    logger.trace("The key is: " + objref);

                PhaseTemplate  ptTemplate= (PhaseTemplate)objref.getObject();
                WTArrayList linkList = (WTArrayList) targetMap.get(objref);
                WTArrayList objectArrayList=(WTArrayList) objectPhastemplateMap.get(ptTemplate);
                if(linkList!=null){


                    if (logger.isTraceEnabled())
                        logger.trace("Value: " + linkList);

                    Iterator objIterator= objectArrayList.iterator();
                    while(objIterator.hasNext()){
                        ObjectReference objRef= (ObjectReference)objIterator.next();
                        WTObject object = (WTObject) objRef.getObject();

                        WTKeyedHashMap emptyTransitionMap = new WTKeyedHashMap();
                        emptyTransitionMap.put(ptTemplate, linkList);

                        WTKeyedHashMap stateTransitionMap = new WTKeyedHashMap (emptyTransitionMap);
                        returnMap.put(object,stateTransitionMap);
                    }

                }

            }



        }


        if (logger.isTraceEnabled()) {
            Iterator it1 = returnMap.wtKeySet().persistableIterator();

            while (it1.hasNext()) {
                WTObject key1 = (WTObject)it1.next();
                if (key1 instanceof LifeCycleTemplate) {
                    lct = (LifeCycleTemplate)key1;
                }
                else if (key1 instanceof LifeCycleManaged) {
                    LifeCycleManaged lcmObject = (LifeCycleManaged)key1;
                    State state = lcmObject.getState().getState();
                    LifeCycleTemplateReference lRef = lcmObject.getLifeCycleTemplate();
                    lct = (LifeCycleTemplate)lRef.getObject();
                }
                if (logger.isTraceEnabled())
                {
                    if(key1!=null)
                        logger.trace("key1 is "+key1);
                    logger.trace("-Lifecycle is "+lct.getName());
                }
                WTKeyedHashMap states = (WTKeyedHashMap)returnMap.get(key1);
                Iterator it2 = states.wtKeySet().persistableIterator();
                while (it2.hasNext()) {
                    PhaseTemplate pt = (PhaseTemplate)it2.next();
                    if (logger.isTraceEnabled())
                    {
                        logger.trace("--State is "+pt.getName());
                    }
                    WTArrayList transitions = (WTArrayList)states.get(pt);
                    if (transitions != null) {
                        Iterator it3 = transitions.persistableIterator();
                        while (it3.hasNext()) {
                            PhaseSuccession ps = (PhaseSuccession)it3.next();
                            if (logger.isTraceEnabled())
                            {
                                logger.trace("----Transition is "+ps.getName());
                                logger.trace("Succession state is "+((PhaseTemplate)ps.getRoleBObject()).getPhaseState());
                            }
                        }
                    }
                }
            }
        }

        if (logger.isTraceEnabled())
            logger.trace("=> End navigate( WTKeyedMap c, Transition transition, boolean successor ) :: " +  transition);
        return returnMap;
    }

    /**
     * Given a WTSet of objects, returns a WTKeyedMap whose keys are those
     * elements of the argument set that are LifeCycleManaged and whose values
     * are the keys' corresponding SeriesRangeSelector values for their current
     * states, if applicable.  If a key's current state does not have a SeriesRangeSelector,
     * it is mapped to null.
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     lcms  set of objects.  Those that are not wt.lifecycle.LifeCycleManaged are ignored (and are excluded from the result).
     * @return    WTKeyedMap
     * @exception wt.util.WTException
     **/

    public WTKeyedMap getSeriesSelectors( WTSet lcms )
            throws WTException {
        Iterator lcti = lcms.persistableIterator();
        // The map to return.  This map is LCT->States->PhaseSuccessions
        WTKeyedHashMap selectorMap = new WTKeyedHashMap();

        wt.fc.ObjectReference oRef = null;
        LifeCycleTemplate lct = null;
        WTObject wtObject = null;
        while (lcti.hasNext()) {
            wtObject = (WTObject)lcti.next();
            //wtObject = (WTObject)((wt.fc.ObjectReference)lcti.next()).getObject();
            LifeCycleManaged lcmObject = null;
            if (wtObject instanceof LifeCycleManaged) {
                lcmObject = (LifeCycleManaged)wtObject;
            }
            else {
                Object[] param = { wtObject.getClass().toString() };
                throw new LifeCycleException( RESOURCE, lifecycleResource.INVALID_LCM_OBJECT, param );
            }

            boolean enforce = SessionServerHelper.manager.setAccessEnforced(false);

            try
            {

                LifeCycleTemplateReference lctRef = lcmObject.getLifeCycleTemplate();
                if (lctRef != null) {
                    lct = (LifeCycleTemplate)lctRef.getObject();
                    State state = lcmObject.getState().getState();
                    PhaseTemplate pt = stateSearch(lct, state);
                    if(pt!=null)
                    {
                        SeriesRangeSelector srs = pt.getSeriesSelector();
                        selectorMap.put(lcmObject, srs);
                    }
                    else
                    {
                        selectorMap.put(lcmObject, null);
                    }
                }
                else
                    selectorMap.put(lcmObject, null);

            }
            finally {
                SessionServerHelper.manager.setAccessEnforced(enforce);
            }
        }
        return selectorMap;
    }

    /**
     * Creates all default transitions for all life cycle templates in the
     * specirfied collection, according to the directives specified in the
     * <code>wt.properties</code> system configuration.  It is the caller's
     * responsibility to ensure that the invocation of this method will not
     * result in transition duplication, which will result in an exception's
     * being thrown.  In general, the only way to ensure this is to invoke
     * this method only on life cycle templates that have no transitions
     * defined (not counting <code>NEXT</code> transitions, which are for
     * internal usage and may not be specified for default initialization).
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     lifeCycleTemplates  a collection of lifecycle templates to create transitions for
     * @param     isUpgrade  True if called from an upgrade from a system without transitions.  This handles the possiblility of duplicate states.
     * @exception wt.util.WTException
     **/

    public void createDefaultTransitions( WTCollection lifeCycleTemplates, boolean isUpgrade )
            throws WTException {
        if (lifeCycleTemplates.isEmpty()) return;
        WTCollection defaultTransitions = new WTHashSet() {
            // For debugging purposes; should not be serialized to client.
            public String toString() {
                if (isEmpty()) return "[]";
                try {
                    StringBuffer buf = new StringBuffer("[");
                    Iterator e = persistableIterator();
                    for (int i = 0; i < size() - 1; i++) {
                        PhaseSuccession ps = (PhaseSuccession)e.next();
                        buf.append(ps.getPredecessor().getPhaseState() + ":" + ps.getName() + ":" + ps.getSuccessor().getPhaseState() + ",");
                    }
                    PhaseSuccession ps = (PhaseSuccession)e.next();
                    buf.append(ps.getPredecessor().getPhaseState() + ":" + ps.getName() + ":" + ps.getSuccessor().getPhaseState() + "]");
                    return buf.toString();
                } catch (WTException wte) {
                    if(logger.isDebugEnabled()){
                        logger.debug(wte.getLocalizedMessage(), wte);
                    }
                    throw new WTRuntimeException(wte);
                }
            }
        };
        for (Iterator i = getPhaseTemplatesForInitialization(lifeCycleTemplates).iterator(); i.hasNext(); ) {
            WTList phaseTemplates = isUpgrade ? uniquePhaseTemplates((WTList)i.next()) : (WTList)i.next();

            HashMap ptMap = new HashMap((int)(phaseTemplates.size() / 0.75) + 2, 0.75f);
            ArrayList states = new ArrayList(phaseTemplates.size());
            for (Iterator j = phaseTemplates.persistableIterator(); j.hasNext(); ) {
                PhaseTemplate pt = (PhaseTemplate)j.next();
                ptMap.put(pt.getPhaseState(), pt);
                states.add(pt.getPhaseState());
            }

            for (int j = 0; j < states.size(); j++) {
                Map transitions = LifeCycleHelper.getDefaultTransitions(states, j);
                for (Iterator k = transitions.keySet().iterator(); k.hasNext(); ) {
                    Transition t = (Transition)k.next();
                    for (Iterator m = ((Set)transitions.get(t)).iterator(); m.hasNext(); ) {
                        PhaseSuccession ps = PhaseSuccession.newPhaseSuccession((PhaseTemplate)ptMap.get(states.get(j)), (PhaseTemplate)ptMap.get(m.next()));
                        try {
                            ps.setName(t);
                        } catch (WTPropertyVetoException wtpve) {
                            if(logger.isDebugEnabled()){
                                logger.debug(wtpve.getLocalizedMessage(), wtpve);
                            }
                            throw new WTException(wtpve);
                        }
                        defaultTransitions.add(ps);
                    }
                }
            }
        }

        PersistenceServerHelper.manager.insert(defaultTransitions);
    }

    /**
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     targetClass
     * @param     context
     * @param     routing
     * @param     enabled
     * @param     superclassIncluded
     * @return    Vector
     * @exception wt.util.WTException
     **/

    public Vector findAllTemplates( Class targetClass, WTContainerRef context, boolean routing, boolean enabled, boolean superclassIncluded )
            throws WTException {

        EnumeratorVector lastTemps = new EnumeratorVector();
        try {
            Vector templates = findAllTemplates(context, routing, enabled);
            if (targetClass != null) {
                String targetClassStr = targetClass.getName();
                Enumeration results = templates.elements();
                while (results.hasMoreElements()) {

                    LifeCycleTemplate lcTemplate = (LifeCycleTemplate) results.nextElement();
                    LifeCycleTemplateMaster aMaster = (LifeCycleTemplateMaster) lcTemplate.getMasterReference().getObject();
                    String candidateClassStr = aMaster.getSupportedClass();

                    // Check if object is an instance of template class
                    boolean match = TypedUtility.isInstanceOf(targetClassStr, candidateClassStr);
                    try {
                        // For WorkPackage don't look at templates with class above WorkPackage (attribute "superclassIncluded" is deprecated)
                        if(WorkPackageClassProxyFoundation.isWorkPackageClass(targetClass)) 
                            match = match && WorkPackageClassProxyFoundation.isWorkPackageClass(Class.forName(candidateClassStr));
                    } catch (ClassNotFoundException e) {
                    }
                    if (match) {
                        if (enabled && lcTemplate.isEnabled()) {
                            lastTemps.add(lcTemplate);
                        } else {
                            if (!enabled) {
                                lastTemps.add(lcTemplate);
                            }
                        }
                    }
                }

            } else {
                lastTemps.addAll(templates);
            }
        } catch (WTException wex) {
            if(logger.isDebugEnabled()){
                logger.debug(wex.getLocalizedMessage(), wex);
            }
            throw new LifeCycleException(wex);
        }

        return lastTemps;
    }

    /**
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     targetClass  String representation of Class
     * @param     context
     * @param     routing
     * @param     enabled
     * @param     superclassIncluded
     * @return    Vector
     * @exception wt.util.WTException
     **/

    public Vector findAllTemplates( String targetClass, WTContainerRef context, boolean routing, boolean enabled, boolean superclassIncluded )
                    throws WTException {
        if (logger.isTraceEnabled())
            logger.trace("Enter findAllTemplates");

        if (logger.isDebugEnabled()) {
            logger.debug("targetClass:" + targetClass);
            logger.debug("context:" + context);
            logger.debug("routing:" + routing);
            logger.debug("enabled:" + enabled);
            logger.debug("superclassIncluded:" + superclassIncluded);
        }
        String baseClassStr = targetClass;
        TypeIdentifier targetIdentifier = TypedUtility.getTypeIdentifier(targetClass); 
        baseClassStr=targetIdentifier.getTypename(); // e.g. wt.part.WTPart
        
        if (logger.isDebugEnabled())
            logger.debug("baseClassStr:" + baseClassStr);

        EnumeratorVector lastTemps = new EnumeratorVector();
        try {
            // Get the lifecycle templates (true value is to filter LC having same name)
            Vector templates = findLifeCycleTemplates(context, routing, enabled, true);
            if (targetClass != null) {

                Enumeration results = templates.elements();
                while (results.hasMoreElements()) {

                    LifeCycleTemplate lcTemplate = (LifeCycleTemplate) results.nextElement();
                    LifeCycleTemplateMaster aMaster = (LifeCycleTemplateMaster) lcTemplate.getMasterReference()
                            .getObject();
                    String candidateClassStr = aMaster.getSupportedClass();
                    if (logger.isDebugEnabled())
                        logger.debug("candidateClassStr:" + candidateClassStr);
                    if (!superclassIncluded) {
                        if (baseClassStr.equals(candidateClassStr)) {
                            if (enabled && lcTemplate.isEnabled())
                                lastTemps.add(lcTemplate);
                            else {
                                if (!enabled)
                                    lastTemps.add(lcTemplate);
                            }
                        }

                    }
                    else {
                        boolean isTypeInstanceOf = false;
                        TypeIdentifier targetClassIdentifier = TypedUtility.getTypeIdentifier(targetClass);
                        TypeIdentifier supportedClassIdentifier = TypedUtility.getTypeIdentifier(candidateClassStr);
                        isTypeInstanceOf = targetClassIdentifier.isDescendedFrom(supportedClassIdentifier);
                        if (logger.isDebugEnabled()) {
                            logger.debug("targetClassIdentifier::" + targetClassIdentifier);
                            logger.debug("supportedClassIdentifier::" + supportedClassIdentifier);
                            logger.debug("isTypeInstanceOf::" + isTypeInstanceOf);
                        }
                        if (isTypeInstanceOf) {

                            if (enabled && lcTemplate.isEnabled())
                                lastTemps.add(lcTemplate);
                            else {
                                if (!enabled)
                                    lastTemps.add(lcTemplate);
                            }

                        }
                        else {
                            TypeIdentifier tempIdentifier =  TypedUtility.getTypeIdentifier(targetClass);
                            while (tempIdentifier!=null) {
                                String tempStr = tempIdentifier.getTypename();
                                if (logger.isDebugEnabled())
                                    logger.debug("tempStr::" + tempStr);
                                if (tempStr.contains(candidateClassStr)) {
                                    if (enabled && lcTemplate.isEnabled()) {
                                        if (!lastTemps.contains(lcTemplate))
                                            lastTemps.add(lcTemplate);
                                    }
                                    else {
                                        if (!enabled) {
                                            if (!lastTemps.contains(lcTemplate))
                                                lastTemps.add(lcTemplate);
                                        }
                                    }
                                }
                                tempIdentifier = TypedUtility.getSupertype(tempIdentifier);
                            }

                        }
                    }
                }

            }
            else {
                lastTemps.addAll(templates);
            }
        } catch (WTException wex) {
            if (logger.isDebugEnabled()) {
                logger.debug(wex.getLocalizedMessage(), wex);
            }
            throw new LifeCycleException(wex);
        }
        if (logger.isTraceEnabled())
            logger.trace("Exit findAllTemplates");
        return lastTemps;
    }

    /**
     * Store or update a LifeCycleTemplate. This method accepts and processes
     * a batch container of persistence assertions.  If a WTContainerRef
     * is passed, and it is different that that of this templates master;
     * then a new master is created in the passed WTContainer, and this template
     * becomes the first iteration.
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     aTran  a TransactionContainer that contains a set of LifeCycleTemplate, PhaseTemplate, AdHocAclSpec, Criterion and Transition assertions and transitions that need to be applied against one or more LifeCycleTemplate objects
     * @param     context  the container the template is being saved in
     * @param     bypassDefaultTransitions  specifies whether or not the default transitions should be created.  if set to true, the transitions must be specified in the transaction container
     * @return    TransactionResult
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public TransactionResult saveLifeCycleTemplate( TransactionContainer aTran, WTContainerRef context, boolean bypassDefaultTransitions )
            throws WTException, LifeCycleException {
        MethodContext mc = MethodContext.getContext();
        if (bypassDefaultTransitions) mc.put(BYPASS_DEFAULT_TRANSITIONS, Boolean.TRUE);
        try {
            return saveLifeCycleTemplate(aTran, context);
        } finally {
            if (bypassDefaultTransitions) mc.remove("bypassDefaultTransitions");
        }
    }

    /**
     * For a given Set of promotables return the intersection of thier common
     * Transitions.
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     promotables
     * @return    Set
     * @exception wt.util.WTException
     **/


    public Set findTransitions( WTSet promotables )
            throws WTException {

        WTKeyedMap ptStateMap = new WTKeyedHashMap();
        HashSet returnSet = new HashSet();
        @SuppressWarnings("unused")
        HashSet transitionSet = new HashSet();
        boolean firstTime = true;
        Iterator iter = promotables.persistableIterator ();
        while( iter.hasNext() ){
            Promotable p = (Promotable)iter.next();
            Set currentStateMap = new HashSet( );
            if ( p instanceof LifeCycleManaged) {
                @SuppressWarnings("unused")
                LifeCycleManaged lcmObject = (LifeCycleManaged)p;
                State state = p.getState().getState();
                currentStateMap.add(state);
                ptStateMap.put(p, currentStateMap);
            }
        }

        WTKeyedHashMap allStatesMap = (WTKeyedHashMap)navigate(ptStateMap, null, true);

        for (Iterator i = allStatesMap.wtKeySet().persistableIterator(); i.hasNext(); ) {
            Promotable p = (Promotable)i.next();
            WTKeyedHashMap transitionMap = (WTKeyedHashMap)allStatesMap.get(p);
            Iterator transitionIterator = transitionMap.wtKeySet().persistableIterator();
            WTArrayList transitionList = (WTArrayList)transitionMap.get(transitionIterator.next());
            Set states = new HashSet();
            Iterator tListIter = transitionList.persistableIterator();
            if (tListIter != null) {
                while (tListIter.hasNext()) {
                    PhaseSuccession ps = (PhaseSuccession)tListIter.next();
                    PhaseTemplate pt = (PhaseTemplate)ps.getRoleBObject();
                    states.add(pt.getPhaseState());
                }
                if (states != null) {
                    if (firstTime) {
                        returnSet.addAll(states);

                    } else {
                        returnSet.retainAll(states);
                    }
                    firstTime = false;
                }
            }
        }
        return (returnSet);
    }

    /**
     * For a given Set of Promotables, return the intersection of common
     * Transitions.  Note:  This will either return a Set of 1 namely the
     * passed in transition of an empty set.
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     promotables
     * @param     transition
     * @return    Set
     * @exception wt.util.WTException
     **/


    public Set findTransitions( WTSet promotables, Transition transition )
            throws WTException {

        WTKeyedMap ptStateMap = new WTKeyedHashMap();
        HashSet returnSet = new HashSet();
        WTHashSet transitionSet = new WTHashSet();
        boolean firstTime = true;
        Iterator iter = promotables.persistableIterator ();

        while( iter.hasNext() ){
            Set currentStateMap = new HashSet( );
            Promotable p = (Promotable)iter.next();
            if ( p instanceof LifeCycleManaged) {
                LifeCycleManaged lcmObject = (LifeCycleManaged)p;
                State state = p.getState().getState();
                currentStateMap.add(state);
                ptStateMap.put(p, currentStateMap);
            }
        }

        WTKeyedHashMap allStatesMap = (WTKeyedHashMap)navigate(ptStateMap, transition, true);

        for (Iterator i = allStatesMap.wtKeySet().persistableIterator(); i.hasNext(); ) {
            Promotable p = (Promotable)i.next();
            WTKeyedHashMap transitionMap = (WTKeyedHashMap)allStatesMap.get(p);
            Iterator transitionIterator = (transitionMap.wtKeySet() != null ) ? transitionMap.wtKeySet().persistableIterator() : null;
            WTArrayList transitionList = (transitionIterator != null ) ? (WTArrayList)transitionMap.get(transitionIterator.next()) : null;

            if ( transitionList != null )
            {
                Set states = new HashSet ();
                Iterator tListIter = transitionList.persistableIterator ();
                if (tListIter != null)
                {
                    while (tListIter.hasNext ())
                    {
                        PhaseSuccession ps = (PhaseSuccession)tListIter.next ();
                        PhaseTemplate pt = (PhaseTemplate)ps.getRoleBObject ();
                        states.add (pt.getPhaseState ());
                    }
                    if (states != null)
                    {
                        if (firstTime)
                        {
                            returnSet.addAll (states);

                        } else
                        {
                            returnSet.retainAll (states);
                        }
                        firstTime = false;
                    }
                }
            }
        }

        return (returnSet);
    }

    private WTArrayList setLifeCycleStatePWC( WTArrayList list, Map stateMap )
            throws WTException, LifeCycleException {

        if (logger.isTraceEnabled())
            logger.trace("Enter setLifeCycleStatePWC");                      
        
        WTKeyedMap phaseTemplateMaps = validateSetState(list, null, stateMap);
        doSetState(list, phaseTemplateMaps, true);
        
        if (logger.isTraceEnabled())
            logger.trace("Exit setLifeCycleStatePWC");

        //return (WTArrayList) CollectionsHelper.manager.refresh(list);
        return (WTArrayList) PersistenceHelper.manager.save(list);
        
    }

    
    /**
     * Set the state of the Life Cycle Managed objects in the WTList list.
     *  Set state values are in the Map stateMap where the key is the LCMO
     * in list and the value is a State.  Also this method will terminate
     * any workflow processes accociated in WTList terminateList.
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     list  The LifeCycleManaged objects whose state should be updated
     * @param     stateMap  The state to set the LifeCycleManaged object to.  Key=LCMO, value State
     * @param     terminateList  The LifeCycleManaged objects whose workflow processes should be terminated.
     * @return    WTList
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/


    public WTList setLifeCycleState( WTList list, Map stateMap, WTList terminateList )
            throws WTException, LifeCycleException {

        if (logger.isTraceEnabled())
            logger.trace("Enter setState(WTList, map, list)");                      
        WTKeyedMap states = findSetStateCandidates(list);

        WTKeyedHashMap setStateMap = new WTKeyedHashMap();
        WTArrayList aList = new WTArrayList();
        WTArrayList actualTerminateList = new WTArrayList();
        Iterator l = list.persistableIterator();
        while (l.hasNext()) {
            LifeCycleManaged lcmo = (LifeCycleManaged)l.next();
            State setToState = (State)stateMap.get(lcmo);
            HashSet fcssSet = (HashSet)states.get(lcmo);
            if (fcssSet != null && fcssSet.contains(setToState)) {
                if(SETSTATECHECK)
                {
                    State currentState = lcmo.getLifeCycleState();
                    if(!currentState.equals(setToState))
                    {
                        setStateMap.put(lcmo, setToState);
                        aList.add(lcmo);
                        if((terminateList!=null)&&(terminateList.size()>0))
                        {
                            if(terminateList.contains(lcmo))
                            {
                                actualTerminateList.add(lcmo);
                            }
                        }
                    }
                }
                else
                {
                    setStateMap.put(lcmo, setToState);
                    aList.add(lcmo);
                }
            }
        }
        /*
      if (terminateList != null && terminateList.size() > 0){
          //SPR 1777574 - START
          Iterator lt = terminateList.persistableIterator();
          //While loop terminates WfProcess object from terminateList as terminateObjectsRunningWorkflows does not terminates those.
          while (lt.hasNext()) {
                Object tObj=lt.next();
                if(tObj instanceof WfProcess){
                    WfProcess aWfProcess = (WfProcess)tObj;
                    if (logger.isTraceEnabled())
                        logger.trace("Terminating " +aWfProcess.getName() + " workflow.  Workflow state was " + aWfProcess.getState().toString());
                    WfEngineServerHelper.service.queueStateChange(aWfProcess, WfTransition.TERMINATE, false, true);
                }
          }
          //This statement terminates processes for object from terminateList
          WfEngineHelper.service.terminateObjectsRunningWorkflows(terminateList);
          //SPR 1777574 - END
      }
         */

        if(SETSTATECHECK)
        {
            WfEngineHelper.service.terminateObjectsRunningWorkflows(actualTerminateList);
        }
        else
        {
            if((terminateList!=null)&&(terminateList.size()>0))
            {
                WfEngineHelper.service.terminateObjectsRunningWorkflows(terminateList);
            }
        }


        WTKeyedMap phaseTemplateMaps = validateSetState(aList, null, setStateMap);
        doSetState(aList, phaseTemplateMaps, false);
        if (logger.isTraceEnabled())
            logger.trace("Exit setState");

        return (WTList) CollectionsHelper.manager.refresh(aList);
    }

    /**
     * Determines the allowable states the session principal can set the
     * objects in the collection to.  The return type is a map with the lifecycle
     * managed objects assigned as keys and the value is a HashSet containing
     * the allowable states the user can assign to the object. If the ordered
     * parameter is set to true then states in the Collection are ordered
     * from left to right as defined in the Lifecycle template. If the ordered
     * parameter is set to false then there is no specific order in which
     * the Collection is populated.
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     lcms  a collection of lifecycle managed objects
     * @param     ordered  If the ordered parameter is set to true then states in the collection are ordered from left to right as defined in the Lifecycle template  If the ordered parameter is set to false then there is no specific order in which the Collection is populated.
     * @return    WTKeyedMap
     * @exception wt.util.WTException
     **/


    public WTKeyedMap findSetStateCandidates( WTCollection lcms, boolean ordered )
            throws WTException {
        if(logger.isTraceEnabled()){
            logger.trace("StandardLifeCycleService.findSetStateCandidates(WTCollection, boolean)==> IN");
        }
        if(!ordered){
            if(logger.isTraceEnabled()){
                logger.trace("StandardLifeCycleService.findSetStateCandidates(WTCollection, boolean)==> OUT");
            }
            return findSetStateCandidates(lcms);
        }
        if(logger.isDebugEnabled())
            logger.debug("StandardLifeCycleService.findSetStateCandidates(WTCollection, boolean)==> Orderd list of states");

        WTKeyedMap ptStateMap = new WTKeyedHashMap();
        @SuppressWarnings("unused")
        HashSet transitionSet = new HashSet();
        @SuppressWarnings("unused")
        boolean firstTime = true;
        Iterator iter = lcms.persistableIterator();
        Transition ssTrans = Transition.toTransition("SET_STATE");
        WTKeyedHashMap returnMap = new WTKeyedHashMap();
        java.util.Hashtable lcTable= new java.util.Hashtable();

        while( iter.hasNext() ){
            LifeCycleManaged lcmo = (LifeCycleManaged)iter.next();

            if (AccessControlHelper.manager.hasAccess(lcmo, AccessPermission.ADMINISTRATIVE)) {
                LifeCycleTemplate lcTemplate = (LifeCycleTemplate)lcmo.getLifeCycleTemplate().getObject();

                if(!lcTable.containsKey(lcTemplate)){
                    Enumeration results = getPhaseTemplates(lcTemplate).elements();
                    java.util.ArrayList vstates = new java.util.ArrayList();
                    while (results.hasMoreElements()) {
                        PhaseTemplate pt = (PhaseTemplate)results.nextElement();
                        State state = pt.getPhaseState();
                        vstates.add(state);
                    }
                    lcTable.put(lcTemplate, vstates);
                    returnMap.put(lcmo, vstates);
                }
                else{
                    java.util.ArrayList vstates = new java.util.ArrayList();
                    vstates= (java.util.ArrayList)lcTable.get(lcTemplate);
                    returnMap.put(lcmo, vstates);
                }
            }
            else if (AccessControlHelper.manager.hasAccess(lcmo, AccessPermission.SET_STATE)){

                Set currentStateMap = new HashSet( );
                State state = lcmo.getState().getState();
                currentStateMap.add(state);
                ptStateMap.put(lcmo, currentStateMap);

            }
        }
        if (!ptStateMap.isEmpty()) {
            WTKeyedHashMap ssMap = (WTKeyedHashMap)LifeCycleHelper.service.navigate(ptStateMap, ssTrans, true);
            for (Iterator i = ssMap.wtKeySet().persistableIterator(); i.hasNext(); ) {
                WTObject obj = (WTObject)i.next();
                LifeCycleManaged lcm = (LifeCycleManaged)obj;
                Vector orderedListOfPhases = getPhaseTemplates((LifeCycleTemplate)lcm.getLifeCycleTemplate().getObject());

                WTKeyedHashMap transitionMap = (WTKeyedHashMap)ssMap.get(obj);
                Iterator transitionIterator = transitionMap.wtKeySet().persistableIterator();
                WTArrayList transitionList = (WTArrayList)transitionMap.get(transitionIterator.next());
                Set states = new HashSet();
                Iterator tListIter = transitionList.persistableIterator();
                if (tListIter != null) {
                    while (tListIter.hasNext()) {
                        PhaseSuccession ps = (PhaseSuccession)tListIter.next();
                        PhaseTemplate pt = (PhaseTemplate)ps.getRoleBObject();
                        states.add(pt.getPhaseState());
                    }
                    ArrayList returnAl = new ArrayList();
                    int noOfPhases = orderedListOfPhases.size();
                    if(!states.isEmpty()){
                        for( int count=0; count < noOfPhases; count++){
                            State stateObj = ((PhaseTemplate)orderedListOfPhases.get(count)).getPhaseState();
                            if( states.contains(stateObj) ){
                                returnAl.add(stateObj);
                            }
                        }
                    }
                    returnMap.put(obj, returnAl);
                }
            }
        }
        if(logger.isTraceEnabled()){
            logger.trace("StandardLifeCycleService.findSetStateCandidates(WTCollection, boolean)==> OUT");
        }
        return (returnMap);
    }

    /**
     * Reassign lifecycle for a list of LifeCycleManaged object.
     * Takes the Reassignment Options from the reassign lifecycle UI.
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     options
     * @return    int
     * @exception wt.util.WTException
     **/


    public int reassignMultipleLC( HashMap options )
            throws WTException {

        LifeCycleTemplate lte=null;
        LifeCycleTemplateReference ltref=null;
        State state=null;
        boolean preserveState=false;
        int successcount = 0;


        //All the objects are LifeCycleManaged.
        WTList objList = new WTArrayList((List)options.get("SelectedObjects"));

        //Make sure the user has administrative authority to do nulti object reassignment.
        AccessControlHelper.manager.checkAccess(objList, AccessPermission.ADMINISTRATIVE);

        WTContainerRef cref = (WTContainerRef)options.get("ContainerRef");
        String LCOption=(String) options.get("LifecycleOption");
        String STOption=(String) options.get("StateOption");
        String comments = (String) options.get("Comments"); //fetch comments

        if (logger.isTraceEnabled())
            logger.trace("=> reassignLC- Options : Lifecycle= " +LCOption+ " ,State= "+STOption+ " ,Container= "+cref);

        //Setting the Multiple reassignement attribute to true
        isMultipleReassign=true;

        if(STOption.equals("STATE_SELECT_NEW")){
            String st= (String)options.get("State");
            state = State.toState(st);
        }else if(STOption.equals("STATE_PRESERVE")){
            preserveState=true;
        }else if(STOption.equals("STATE_INITIAL")){
            preserveState=false;
        }

        if(LCOption.equals("LIFECYCLE_SELECT_NEW")){

            lte= (LifeCycleTemplate)options.get("LCTemplate");
            ltref=lte.getLifeCycleTemplateReference();

            for(int objcount = 0 ; objcount < objList.size(); objcount++ )
            {
                String typeId = TypeIdentifierUtility.getTypeIdentifier(objList.get(objcount)).getTypename();
                if(objList.size() > 1){

                    try{
                        WTArrayList tempList = new WTArrayList();
                        tempList.add(objList.get(objcount));
                        if (state==null){
                            reassign(tempList, ltref, cref, preserveState, comments);
                        }else{
                            reassign(tempList, ltref, cref, state, comments);
                        }
                        successcount++;

                    }catch(Exception e){
                        // There are more than one objects being reassigned So continue reassigning
                        // all objects if one or more of them leads to exception
                        if (logger.isTraceEnabled())
                            logger.trace(" Unable to reassign Object of Type " + typeId + ". Reason = " + e);
                        if(logger.isDebugEnabled()){
                            logger.debug(e.getLocalizedMessage(), e);
                        }

                    }
                }
                else{
                    if (state==null){
                        reassign(objList, ltref, cref, preserveState, comments);
                    }else{
                        reassign(objList, ltref, cref, state, comments);
                    }
                    successcount++;
                }
            }
        }else if(LCOption.equals("LIFECYCLE_CURRENT_ITERATION")){
            Iterator iterator = objList.persistableIterator();
            while (iterator.hasNext()) {
                LifeCycleManaged wtobj = (LifeCycleManaged)iterator.next();
                String typeId = TypeIdentifierUtility.getTypeIdentifier(wtobj).getTypename();
                ltref = wtobj.getLifeCycleTemplate();
                @SuppressWarnings("unused")
                State currState=wtobj.getLifeCycleState();

                WTArrayList tempList = new WTArrayList();
                tempList.add(wtobj);

                if(objList.size() > 1){

                    try{
                        // Change the reassign() API which reassign the list of objects instead of single object. The
                        // previous API use to check for MODIFY permission instead of ADMINISTRATIVE permission.

                        //"reassign()" method will get the latest iteration before reassigning
                        //reassign(wtobj, ltref, cref, comments);

                        /*
                         * SPR:1426092:>Implement this part of code because, "getReadOnlyObject()" in "validateLifeCycleTemplate"
                         * doesn't fetches data from database and therefore doesn't reflect actual status. Considering optimization
                         * aspect, we first check template in lifecycle's cache and if it is not available there ONLY than it will dig in database
                         */
                        lte = LifeCycleHelper.service.getLifeCycleTemplate(ltref.getName(), cref);
                        if(lte!=null)
                        {
                            lte = (LifeCycleTemplate)ltref.getReadOnlyObject();
                        }
                        else
                        {
                            lte = (LifeCycleTemplate)ltref.getObject();
                        }
                        if (!lte.isEnabled())
                        {
                            throw new LifeCycleException(RESOURCE, lifecycleResource.SELECTED_LCT_NOT_ENABLED, null);
                        }
                        // Fix Finish

                        reassign(tempList, ltref, cref, preserveState, comments);
                        // Preserve State is already handled in reassign API.
                        //if (preserveState){
                        //  setState(wtobj, currState);
                        //}
                        successcount++;
                    }
                    catch(Exception e){
                        // There are more than one objects being reassigned So continue reassigning
                        // all objects if one or more of them leads to exception
                        if ( logger.isDebugEnabled() )
                            logger.debug(" Unable to reassign Object of Type " + typeId + ". Reason = " + e);
                    }

                }
                else{

                    /*
                     * SPR:1426092:>Implement this part of code because, "getReadOnlyObject()" in "validateLifeCycleTemplate"
                     * doesn't fetches data from database and therefore doesn't reflect actual status. Considering optimization
                     * aspect, we first check template in lifecycle's cache and if it is not available there ONLY than it will dig in database
                     */
                    lte = LifeCycleHelper.service.getLifeCycleTemplate(ltref.getName(), cref);
                    if(lte!=null)
                    {
                        lte = (LifeCycleTemplate)ltref.getReadOnlyObject();
                    }
                    else
                    {
                        lte = (LifeCycleTemplate)ltref.getObject();
                    }
                    if (!lte.isEnabled())
                    {
                        throw new LifeCycleException(RESOURCE, lifecycleResource.SELECTED_LCT_NOT_ENABLED, null);
                    }
                    // Fix Finish

                    reassign(tempList, ltref, cref, preserveState, comments);
                    // Preserve State is already handled in reassign API.
                    //if (preserveState){
                    //  setState(wtobj, currState);
                    //}
                    successcount++;
                }

            }
        }else if(LCOption.equals("LIFECYCLE_INIT_RULE")){

            for(int objcount = 0 ; objcount < objList.size(); objcount++ )
            {
                //SPR 2134721
                Object obj = objList.getPersistable(objcount);
                //directly getting rules as check for objects is already done
                String typeId = TypeIdentifierUtility.getTypeIdentifier(obj).getTypename();
                InitRuleFacade ruleFacade = new InitRuleFacade();
                lte = (LifeCycleTemplate)ruleFacade.getValue(RuleConstants.ATTR_LIFECYCLE_ID, obj, cref);

                if(objList.size() > 1){

                    try{
                        if(lte == null) {
                            String params[] = {typeId, cref.getName()};
                            throw new LifeCycleException(RESOURCE, lifecycleResource.NO_LIFECYCLE_INIT_RULE, params);
                        }else{
                            WTArrayList tempList = new WTArrayList();
                            tempList.add(objList.get(objcount));
                            ltref=lte.getLifeCycleTemplateReference();
                            reassign(tempList, ltref, cref, preserveState, comments);
                            successcount++;
                        }
                    }catch(Exception e){
                        // There are more than one objects being reassigned So continue reassigning
                        // all objects if one or more of them leads to exception
                        if (logger.isTraceEnabled())
                            logger.trace(" Unable to reassign Object of Type " + typeId + ". Reason = " + e);
                        if(logger.isDebugEnabled()){
                            logger.debug(e.getLocalizedMessage(), e);
                        }
                    }
                }else{
                    if(lte == null) {
                        String params[] = {typeId, cref.getName()};
                        throw new LifeCycleException(RESOURCE, lifecycleResource.NO_LIFECYCLE_INIT_RULE, params);
                    }else{
                        ltref=lte.getLifeCycleTemplateReference();
                        reassign(objList, ltref, cref, preserveState, comments);
                        successcount++;
                    }
                }
            }
        }

        //Setting the Multiple reassignement attribute to false again
        isMultipleReassign=false;
        if (logger.isTraceEnabled())
        {
            logger.trace("No of reassignment successfull = " + successcount);
        }
        return successcount;

    }

    /**
     * Answer a vector of enabled life cycle template references valid for
     * the life cycle managed object and container context.
     *
     *
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     targetClass  the LifeCycleManaged class used as search criteria in the retrieval of canidate LifeCycleTemplates
     * @param     containerRef
     * @return    Vector
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/


    public Vector findCandidateTemplates( Class targetClass, WTContainerRef containerRef )
            throws WTException, LifeCycleException {
        if (logger.isTraceEnabled()) {
            logger.trace("Enter findCandidatetemplates(object, containerRef)");
        }
        /* 1. Get the templates that work for this class */
        Enumeration e = findTemplateMasterByClass(targetClass, containerRef);

        /* 2. Build a list of names */
        Vector lctReferences = new Vector();
        while (e.hasMoreElements()) {
            LifeCycleTemplateMaster master = (LifeCycleTemplateMaster)e.nextElement();
            LifeCycleTemplate template = getLatestIteration(master);

            //-- filter out any LifeCycleTemplates that the current user doesn't have access to
            if (template !=null) {
                lctReferences.addElement(LifeCycleTemplateReference.newLifeCycleTemplateReference(template));
            }
        }

        if (logger.isTraceEnabled())
            logger.trace("Exit findCandidatetemplates(Class) - found "+lctReferences.size()+" candidates");

        return lctReferences;
    }

    /**
     * Given a collection of LifeCycleManaged Objects , returns a HashMap
     * containing Key as LifecycleManaged object and value as ArrayList holding
     * corresponding LifecycleHistory objects
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     lcmObjList  Collection of LifecycleManaged objects
     * @return    HashMap
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/


    public HashMap getHistoryForIterations( ArrayList lcmObjList )
            throws WTException, LifeCycleException {

        HashMap<BigDecimal,ArrayList> returnMap = new HashMap<BigDecimal,ArrayList>();
        String objRefId = "." + ObjectReference.KEY + "." + ObjectIdentifier.ID;
        //Class[] classes = {ObjectHistory.class,LifeCycleHistory.class};
        QuerySpec qs = new QuerySpec();
        long[] oids = getLCMOids(lcmObjList);

        ClassAttribute ca2 = new ClassAttribute(LifeCycleHistory.class,WTAttributeNameIfc.ID_NAME);
        ClassAttribute ca1 = new ClassAttribute(ObjectHistory.class,WTAttributeNameIfc.ROLEA_OBJECT_ID);
        //qs.appendSelect(ca1,true);

        int ohIndx = qs.appendClassList(ObjectHistory.class,true);
        int lhIndx = qs.appendClassList(LifeCycleHistory.class,true);

        SearchCondition sc = new SearchCondition(
                LifeCycleHistory.class,
                "thePersistInfo.theObjectIdentifier.id",
                ObjectHistory.class,
                ObjectHistory.ROLE_BOBJECT_REF + objRefId);

        qs.appendWhere(sc, new int[]{lhIndx, ohIndx});
        qs.appendAnd();

        SearchCondition srch = new SearchCondition(ObjectHistory.class,WTAttributeNameIfc.ROLEA_OBJECT_ID,oids);

        qs.appendWhere(srch, new int[] {ohIndx});
        OrderBy orderByObj = new OrderBy(ca2, true);//descending
        qs.appendOrderBy(orderByObj,new int[]{lhIndx});

        QueryResult results = PersistenceServerHelper.manager.query(qs);

        if(logger.isTraceEnabled()){//logger.isTraceEnabled()
            logger.trace("getHistoryForIterations()==> Query is " + qs );
            logger.trace("results size is :: " + results.size() );
        }

        while (results.hasMoreElements()){
            Object[] rowData = (Object[])results.nextElement();
            ObjectHistory ohObj= (ObjectHistory)rowData[0]; //oid of LCM
            LifeCycleHistory lhObj = (LifeCycleHistory)rowData[1]; //oid of Lifecycle History
            BigDecimal ohIdObj = new BigDecimal(((ObjectIdentifier)ohObj.getRoleAObjectId()).getId());
            ArrayList mapValue = (ArrayList)returnMap.get(ohIdObj);
            if(mapValue==null){
                mapValue = new ArrayList();
                returnMap.put(ohIdObj, mapValue);
            }
            mapValue.add(lhObj);
        }

        return returnMap;
    }

    /**
     * Reassign a life cycle managed object to a new life cycle in a certain
     *  WTContainerRef.
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     object  the LifeCycleManaged object that should be assigned to a new life cycle
     * @param     lctRef  a reference to a LifeCycleTemplate, the LifeCycleTemplate that the object should be reassigned to
     * @param     context  the container where the objects associated workflow processes will be created
     * @param     comments  Notes or comments for the lifecycle operation. Can be null.
     * @return    LifeCycleManaged
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public LifeCycleManaged reassign( LifeCycleManaged object, LifeCycleTemplateReference lctRef, WTContainerRef context, String comments )
            throws WTException, LifeCycleException {
        LifeCycleManaged lcmobject = object;
        LifeCycleTemplateReference lctrlctRef = lctRef;
        if (logger.isTraceEnabled())
            logger.trace("=> reassign: " + getOid (lcmobject) +
                    ", template = " + lctrlctRef +
                    ", container = " + context +
                    ", comments = " + comments);

        //First make sure the template is valid and the latest iteration
        LifeCycleTemplate template = validateLifeCycleTemplate(lctrlctRef, true);
        if (template != null) {
            if (logger.isTraceEnabled())
                logger.trace("LifeCyleTemplate is not latest iteration, retrieved latest and using it");
            lctRef = LifeCycleTemplateReference.newLifeCycleTemplateReference(template);
        }

        validateReassign(lcmobject, lctrlctRef);

        lcmobject = doReassign (lcmobject, lctrlctRef, context, comments);
        lcmobject = (LifeCycleManaged)PersistenceServerHelper.manager.restore(lcmobject);
        if (logger.isTraceEnabled())
            logger.trace("   reassign - OUT");
        return lcmobject;
    }

    /**
     * Reassign the life cycle managed objects in a WTList to a new life
     * cycle in a certain  WTContainerRef.
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     list  the WTList of LifeCycleManaged objects that should be assigned to a new life cycle
     * @param     lctRef  a reference to a LifeCycleTemplate, the LifeCycleTemplate that the object should be reassigned to
     * @param     context  The container which the object resides in.
     * @param     state  The state the objects in the lifecycle should be assigned when reassigned to the lifecycle.
     * @param     comments  Notes or comments for lifecycle operation. Can be null.
     * @return    WTList
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public WTList reassign( WTList list, LifeCycleTemplateReference lctRef, WTContainerRef context, State state, String comments )
            throws WTException, LifeCycleException {
        LifeCycleTemplateReference lctreffRef = lctRef;
        if (logger.isTraceEnabled())
            logger.trace("=> reassign: WTCollection, template = " + lctreffRef +
                    ", container = " + context +
                    ", state= " + state +
                    ", comments " + comments);

        //First make sure throws iteration is the latest and is valid.
        LifeCycleTemplate template = validateLifeCycleTemplate(lctreffRef, true);
        if (template != null) {
            if (logger.isTraceEnabled())
                logger.trace("LifeCyleTemplate is not latest iteration, retrieved latest and using it");
            lctreffRef = LifeCycleTemplateReference.newLifeCycleTemplateReference(template);
        }

        validateReassign(list, lctreffRef, state);

        doReassign (list, lctreffRef, context, state, false /*presesrveState*/, comments, false );

        if (logger.isTraceEnabled())
            logger.trace("   reassign - OUT");

        return (WTList) CollectionsHelper.manager.refresh(list);
    }

    private WTList reassignPWC( WTList list, LifeCycleTemplateReference lctRef, WTContainerRef context, State state )
            throws WTException, LifeCycleException {
        if (logger.isTraceEnabled())
            logger.trace("=> reassignPWC: WTCollection, template = " + lctRef +
                    ", container = " + context +
                    ", state= " + state);

        doReassign (list, lctRef, context, state, false, "", true);

        if (logger.isTraceEnabled())
            logger.trace("   reassignPWC - OUT");

        return (WTList) PersistenceHelper.manager.save(list);
        //return (WTList) CollectionsHelper.manager.refresh(list);
    }

    /**
     * Reassign all objects in a WTList to a lifecycle.
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     list  the WtList of LifeCycleManaged objects that should be assigned to a new life cycle
     * @param     lctRef  a reference to a LifeCycleTemplate, the LifeCycleTemplate that the object should be reassigned to
     * @param     context  The container the object resides in.   This may be null.
     * @param     preserveState  If this is set to true, the existing state of objects will be preserved if the state is contained in the lifecycle template.  Otherwise, the object will be set to the initial state of the lifecycle.
     * @param     comments  Notes or comments for lifecycle operation. Can be null.
     * @return    WTList
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public WTList reassign( WTList list, LifeCycleTemplateReference lctRef, WTContainerRef context, boolean preserveState, String comments )
            throws WTException, LifeCycleException {
        LifeCycleTemplateReference lctreffRef= lctRef;
        if (logger.isTraceEnabled())
            logger.trace("=> reassign: WTCollection, template = " + lctreffRef +
                    ", container = " + context +
                    ", comments = " + comments);

        //First make sure the template is valid and latest iteration
        LifeCycleTemplate template=validateLifeCycleTemplate(lctreffRef, true);
        if (template != null) {
            if (logger.isTraceEnabled())
                logger.trace("LifeCyleTemplate is not latest iteration, retrieved" +
                        " latest and using it");
            lctreffRef = LifeCycleTemplateReference.newLifeCycleTemplateReference(template);
        }

        validateReassign(list, lctreffRef);

        doReassign (list, lctreffRef, context, null /* state */, preserveState, comments, false);
        if (logger.isTraceEnabled())
            logger.trace("   reassign - OUT");

        return (WTList) CollectionsHelper.manager.refresh(list);
    }

    /**
     * To find the LifeCycle Templates based on the supported class and context.
     * If there are more than one lifecycle template having same name and
     * different context then it returns the lifecycle template lower in
     * hierarchical context.
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     context
     * @param     routing
     * @param     enabled
     * @param     filtered
     * @return    Vector
     * @exception wt.util.WTException
     **/

    @SuppressWarnings({ "deprecation"})
    public Vector findLifeCycleTemplates( WTContainerRef context, boolean routing, boolean enabled, boolean filtered )
            throws WTException {

        EnumeratorVector lastTemps = new EnumeratorVector();
        Vector result = new Vector();
        try {

            if (logger.isTraceEnabled())
                logger.trace("=> findAllTemplates: " + context + ", routingOnly = " + routing);
            // 1. Retrieve all Enabled LifeCycleTemplates
            QuerySpec qs = new QuerySpec(LifeCycleTemplateMaster.class);

            if(enabled)  {
                qs.appendWhere ( new SearchCondition ( LifeCycleTemplateMaster.class,
                        LifeCycleTemplateMaster.ENABLED,
                        SearchCondition.IS_TRUE), new int[]{0});
            }
            if (routing) {
                if(enabled)
                    qs.appendAnd();
                qs.appendWhere ( new SearchCondition ( LifeCycleTemplateMaster.class,
                        LifeCycleTemplateMaster.ROUTING,
                        SearchCondition.IS_TRUE), new int[]{0});
            }

            qs.appendOrderBy(LifeCycleTemplateMaster.class,
                    LifeCycleTemplateMaster.NAME,
                    false);
            LookupSpec ls = new LookupSpec(qs, context);
            //- This should find all template masters, in all containers
            //- looking up from the container passed?
            //-
            try {
                // true value is to filter LC having same name
                ls.setFilterOverrides(true);
                //  Set to return filtered templates if so requested
                // ls.setOverrideFilterableVisibility(filtered);
                //SPR#1370992 :- Members are able to view the hidden lifecycle templates on Re-assign lifecycle page.
                ls.setOverrideFilterableVisibility(false);
            }
            catch (WTPropertyVetoException wpve) {
                if(logger.isDebugEnabled()){
                    logger.debug(wpve.getLocalizedMessage(), wpve);
                }
                throw new WTException (wpve);
            }
            QueryResult qr = WTContainerHelper.service.lookup(ls);

            //SortedEnumeration enumer = null;
            Enumeration enumer = null;
            if( qr != null ) {
                enumer = qr.getEnumeration();
                TreeMap treeTemp = new TreeMap();
                while (enumer.hasMoreElements ()) {
                    LifeCycleTemplateMaster master = (LifeCycleTemplateMaster)enumer.nextElement();
                    if (master != null) {
                        treeTemp.put(master.getName()+":"+master.getContainerName(),master);
                    }
                }

                Map treeTempMap = (Map)treeTemp;

                for (Iterator it = treeTempMap.values().iterator(); it.hasNext();) {
                    LifeCycleTemplateMaster master = (LifeCycleTemplateMaster)it.next();

                    /*
                  Enumeration latestEnum = ConfigHelper.service.filteredIterationsOf (master, new LatestConfigSpec ());
                  if (latestEnum.hasMoreElements ()) {
                      lastTemps.addElement (latestEnum.nextElement ());
                  }
                     */

                    //SPR#1991148
                    QueryResult results = VersionControlHelper.service.allIterationsOf(master);
                    if (results != null && results.hasMoreElements()) {
                        LifeCycleTemplate template = (LifeCycleTemplate)results.nextElement();
                        if(template.getCheckoutInfo().getState() == WorkInProgressState.CHECKED_IN ){
                            lastTemps.addElement (template);
                        }
                        else if(template.getCheckoutInfo().getState() == WorkInProgressState.CHECKED_OUT){
                            lastTemps.addElement (template);
                        }
                        else{
                            while(results.hasMoreElements()){
                                template = (LifeCycleTemplate)results.nextElement();
                                if(template.getCheckoutInfo().getState() == WorkInProgressState.CHECKED_OUT)
                                {
                                    lastTemps.addElement (template);
                                    break;
                                }
                            }
                        }
                    }
                }
            }

            return lastTemps;

        } catch (WTException wex) {
            if(logger.isDebugEnabled()){
                logger.debug(wex.getLocalizedMessage(), wex);
            }
            throw new LifeCycleException(wex);
        }

    }

    /**
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     lcTemplateMasterRef
     * @return    LifeCycleTemplateMaster
     * @exception wt.util.WTException
     **/

    public LifeCycleTemplateMaster getLCTemplateMaster( ObjectReference lcTemplateMasterRef )
            throws WTException {

        LifeCycleTemplateMasterCache cache = (LifeCycleTemplateMasterCache)getLifeCycleTemplateMasterCache();
        return(cache.getLCTMaster(lcTemplateMasterRef));
    }

    /**
     * Associate a life cycle managed object with a life cycle. This includes
     * assigning an initial state to the object.
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     object  the Persistable object that the caller wants assigned to a life cycle
     * @return    Persistable
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public Persistable assignToLifeCycle( Persistable object )
            throws WTException, LifeCycleException {
        return assignToLifeCycle (object, null);
    }

    /**
     * Submit the object for review.  This initiates the appropriate workflow
     * for the life cycle gate.
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     object  the LifeCycleManaged object that should be submitted for review
     * @return    LifeCycleManaged
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public LifeCycleManaged doSubmit( LifeCycleManaged object )
            throws WTException, LifeCycleException {
        LifeCycleManaged lcmobject = object;
        if (logger.isTraceEnabled()){
            logger.trace(">>In StandardLifeCycleService...doSubmit() method");
            logger.trace("=> doSubmit: " + getOid(lcmobject));
        }
        // -- Set the object as atGate and send associated notifications.
        /* 1. Set atGate flag to true & update the object.
         *    (Use update to avoid event propagation)
         */
        Phase aPhase = null;
        Transaction trx = new Transaction();
        try {
            trx.start();

            /* 1. get the Current phase of the object */
            aPhase = getCurrentPhase(lcmobject);

            /* 2. Update the cookie to say 'atGate' (using partial update)  */
            PersistenceServerHelper.manager.lock (lcmobject, true);
            lcmobject = (LifeCycleManaged)PersistenceServerHelper.manager.restore(lcmobject);
            LifeCycleState lcs = setState((LifeCycleManaged)lcmobject,lcmobject.getLifeCycleState(),true);
            PersistenceServerHelper.manager.update(lcmobject,LifeCycleManaged.STATE,lcs);

            /* 3. Save history */
            saveHistory(lcmobject,aPhase,SUBMIT);

            /* 4. Dispatch the submit event */
            dispatchVetoableEvent( LifeCycleServiceEvent.SUBMIT, lcmobject );

            // 5. Trigger WF processing
            if (aPhase == null && lcmobject.isLifeCycleBasic()){
                if (logger.isTraceEnabled())
                    logger.trace("  Object is basic life cycle managed. Do nothing to initiate workflow.");
            }else{
                aPhase = initiateGateWorkflow((PhaseTemplate)aPhase.getPhaseTemplateId().getObject(), aPhase, lcmobject);
                PersistenceServerHelper.manager.update(aPhase, false);
            }
            trx.commit();
            trx = null;
        }
        catch (WTPropertyVetoException veto) {

            if(logger.isDebugEnabled()){
                logger.debug(veto.getLocalizedMessage(), veto);
            }
            throw new LifeCycleException(veto);
        }
        catch (PersistenceException dbError) {

            if(logger.isDebugEnabled()){
                logger.debug(dbError.getLocalizedMessage(), dbError);
            }
            throw new LifeCycleException(dbError);
        }
        catch (WTException wex) {

            if(logger.isDebugEnabled()){
                logger.debug(wex.getLocalizedMessage(), wex);
            }
            throw new LifeCycleException(wex);
        }
        finally {
            if (trx != null)
                trx.rollback();
        }
        // 6. Mark the work item complete.
        WorkflowHelper.service.markWorkItemComplete(lcmobject, SessionHelper.manager.getPrincipal(), SUBMIT_TASK);

        if (logger.isTraceEnabled())
            logger.trace(">>Out StandardLifeCycleService...doSubmit() method");
        return lcmobject;
    }

    /**
     * Transition the object to its next phase, updating its state, initiating
     * the appropriate workflow and recording history.
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     object  the LifeCycleManaged object to be promoted
     * @param     signature  the LifeCycleSignature object to be used to record information about the promote
     * @return    LifeCycleManaged
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public LifeCycleManaged doPromote( LifeCycleManaged object, LifeCycleSignature signature )
            throws WTException, LifeCycleException {
        LifeCycleManaged lcmobject=object;
        LifeCycleSignature lcssignature=signature;
        if (logger.isTraceEnabled())
            logger.trace("Enter doPromote "+getOid(lcmobject));

        // -- Record signature & advance the object to the next phase

        // -- Note: In a final phase, a promote is a not permitted
        // --       The only valid actions are demote or drop

        Transaction trx = new Transaction();
        boolean finalPhase = false;

        //If promoter does not have read access to the folder the object resides in,
        //ad hoc access will be removed during cleanup phase and the promote will fail.
        //Set user to administrator to make sure that the promote is able to complete.
        WTPrincipal administrator = SessionHelper.manager.getAdministrator ();
        WTPrincipal previous = SessionContext.setEffectivePrincipal (administrator);
        try {
            try {
                trx.start();

                /* 1. Get the template associated with this phase */
                Phase aPhase = getCurrentPhase(lcmobject);

                if(isLifeHistoryAssociated((LifeCycleManaged)lcmobject))
                {
                    Phase oldPhase=getPhase((LifeCycleManaged)lcmobject);
                    saveHistory((LifeCycleManaged)lcmobject,oldPhase,EXIT_PHASE,(Timestamp)null, null);
                }

                PhaseTemplate currentPT = null;
                if (aPhase==null && lcmobject.isLifeCycleBasic()){
                    if(logger.isDebugEnabled())
                        logger.debug("  Object is basic life cycle managed. Get the phase template of the object for the template of the current phase.");

                    currentPT=getPhaseTemplate(lcmobject);

                }else
                    currentPT=(PhaseTemplate)aPhase.getPhaseTemplateId().getObject();

                /* 2. Ask the template for its successor(s).
                 *    Note: getSuccessor will object if current is a final phase.
                 *          A final phase has no where to go.
                 */
                PhaseTemplate nextPT = getSuccessorPhase(currentPT);

                /* 3. Record the promote action */
                lcssignature = vote(lcmobject,lcssignature);

                /* 4. Log the history event */
                LifeCycleHistory h = saveHistory(lcmobject,aPhase,PROMOTE);

                /* 5. Move signatures to history & delete the current phase */
                cleanupCurrentPhase(lcmobject,aPhase,h);

                administrator = SessionHelper.manager.getAdministrator ();
                previous = SessionContext.setEffectivePrincipal (administrator);

                /* 6. Do the promote & record history */
                lcmobject = doStateTransition (lcmobject, nextPT, ENTER_PHASE, null, null);

                /* 7. Dispatch the state change event */
                dispatchVetoableEvent( LifeCycleServiceEvent.STATE_CHANGE, lcmobject );

                /* 8. Dispatch the promote event */
                dispatchVetoableEvent( LifeCycleServiceEvent.PROMOTE, lcmobject );

                /* 9. Contribute to Summary Event */
                /* This is done in the doStateTransition */

                trx.commit();
                trx = null;

            }
            catch (WTPropertyVetoException veto) {
                if(logger.isDebugEnabled()){
                    logger.debug(veto.getLocalizedMessage(), veto);
                }
                throw new LifeCycleException(veto);}
            catch (WTException wex) {
                if(logger.isDebugEnabled()){
                    logger.debug(wex.getLocalizedMessage(), wex);
                }
                throw new LifeCycleException(wex);}
            finally {
                if (trx != null) {
                    trx.rollback();
                }
            }

            // 9.  If found, mark the associated work item as complete
            markWorkItemAsComplete(lcssignature, lcmobject);

            if (logger.isTraceEnabled())
                logger.trace("Exit doPromote");

            return lcmobject;
        }
        finally
        {
            SessionContext.setEffectivePrincipal(previous);
        }


    }

    /**
     * Transition the object to its previous phase, updating its state, initiating
     * the appropriate workflow and recording history.
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     object  the LifeCycleManaged object to be used in the demote
     * @param     signature  the LifeCycleSignature object to be used to record information about the demote
     * @return    LifeCycleManaged
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public LifeCycleManaged doDemote( LifeCycleManaged object, LifeCycleSignature signature )
            throws WTException, LifeCycleException {
        LifeCycleManaged lcmobject= object;
        LifeCycleSignature lcmsignature = signature;
        if (logger.isTraceEnabled()){
            logger.trace(">>In StandardLifeCycleService...doDemote(LifeCycleManaged object, LifeCycleSignature signature ) method");
            logger.trace("Enter doDemote "+getOid(lcmobject));
        }

        // -- Record signature & return the object to the previous phase

        // -- Can't do it if the object is in its initial phase.

        Transaction trx = new Transaction();
        try {
            trx.start();

            /* 1. Get the template associated with this phase */
            Phase aPhase = getCurrentPhase(lcmobject);
            if(isLifeHistoryAssociated(lcmobject))
            {
                Phase oldPhase=getPhase(lcmobject);
                saveHistory(lcmobject,oldPhase,EXIT_PHASE,(Timestamp)null, null);
            }
            PhaseTemplate currentPT = null;
            if (aPhase==null && lcmobject.isLifeCycleBasic()){
                if(logger.isDebugEnabled())
                    logger.debug("  Object is basic life cycle managed. Get the phase template of the object for the template of the current phase.");

                currentPT=getPhaseTemplate(lcmobject);

            }else
                currentPT=(PhaseTemplate)aPhase.getPhaseTemplateId().getObject();


            /* 2. Ask the template for its predecessor.
             *    Note: getPredecessor will throw an exception if the current phase
             *          is the initial phase.
             */
            PhaseTemplate previousPT = null;
            previousPT = getPredecessorPhase(currentPT);

            /* 3. Record the demote action */
            lcmsignature = vote(lcmobject,lcmsignature);

            /* 4. Log the history event */
            LifeCycleHistory h = saveHistory(object,aPhase,DEMOTE);

            /* 5. Move signatures to history & delete the current phase */
            cleanupCurrentPhase(lcmobject,aPhase,h);

            /* 6. Do the demote & record history */
            lcmobject = doStateTransition (lcmobject, previousPT, ENTER_PHASE, null, null);

            /* 7. Dispatch the state change event */
            dispatchVetoableEvent( LifeCycleServiceEvent.STATE_CHANGE, lcmobject );

            /* 8. Dispatch the demote event */
            dispatchVetoableEvent( LifeCycleServiceEvent.DEMOTE, lcmobject );

            /* 9. Contribute to Summary Event */
            /* This is done in the doStateTransition */

            trx.commit();
            trx = null;

        }
        catch (WTPropertyVetoException veto) {

            if(logger.isDebugEnabled()){
                logger.debug(veto.getLocalizedMessage(), veto);
            }
            throw new LifeCycleException(veto);
        }
        catch (WTException wex) {

            if(logger.isDebugEnabled()){
                logger.debug(wex.getLocalizedMessage(), wex);
            }
            throw new LifeCycleException(wex);
        }
        finally {
            if (trx != null) {
                trx.rollback();
            }
        }

        // 9.  If found, mark the associated work item as complete
        markWorkItemAsComplete(lcmsignature, lcmobject);

        if (logger.isTraceEnabled())
            logger.trace(">>Out StandardLifeCycleService...doDemote(LifeCycleManaged object, LifeCycleSignature signature ) method");

        return lcmobject;

    }

    /**
     * Transition the object from the gate back to the phase, initating the
     * appropriate workflow and recording history.
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     object  the LifeCycleManaged object to be used in the demote
     * @param     signature  the LifeCycleSignature object to be used to record information about the demote
     * @return    LifeCycleManaged
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public LifeCycleManaged doDeny( LifeCycleManaged object, LifeCycleSignature signature )
            throws WTException, LifeCycleException {
        LifeCycleManaged lcmobject = object;
        LifeCycleSignature lcmsignature=signature;
        if (logger.isTraceEnabled())
            logger.trace("Enter doDeny");
        /* 1. Set atGate flag to false & update the object */
        Phase aPhase = null;
        Transaction trx = new Transaction();
        try {
            trx.start();

            /* 1a.  Set isAtGate flag to be false (using partial update) */
            PersistenceServerHelper.manager.lock (lcmobject, true);
            lcmobject = (LifeCycleManaged)PersistenceServerHelper.manager.restore(lcmobject);
            LifeCycleState lcs = setState((LifeCycleManaged)lcmobject,lcmobject.getLifeCycleState(),false);
            PersistenceServerHelper.manager.update(lcmobject,LifeCycleManaged.STATE,lcs);

            /* 1.  Get the phase and the phase template associated with this object */
            aPhase = getCurrentPhase(lcmobject);
            PhaseTemplate currentPT = null;
            if (aPhase==null && lcmobject.isLifeCycleBasic()){
                if (logger.isTraceEnabled())
                    logger.trace("  Object is basic life cycle managed. Get the phase template of the object for the template of the current phase.");
                currentPT=getPhaseTemplate(lcmobject);
            }else
                currentPT=(PhaseTemplate)aPhase.getPhaseTemplateId().getObject();

            /* 2.  Record the deny action */
            lcmsignature = vote(lcmobject,lcmsignature);

            /* 3. Create the 'Deny' history */
            LifeCycleHistory aHistory = saveHistory(lcmobject,aPhase,DENY);

            /* 4. Move or remove artifacts of this phase */
            removePhaseData(lcmobject,aPhase,aHistory);

            /* 5. Link the template gate criteria to the phase */
            cloneCriteria(aPhase,currentPT);

            /* 6. Dispatch the deny event */
            dispatchVetoableEvent( LifeCycleServiceEvent.DENY, lcmobject );

            /* 7. Trigger WfProcessing */
            if (aPhase == null && lcmobject.isLifeCycleBasic()){
                if (logger.isTraceEnabled())
                    logger.trace("  Object is basic life cycle managed. Do nothing to initiatePhaseWorkflow.");
            }else{
                PhaseTemplate phaseTemplate = (PhaseTemplate) aPhase.getPhaseTemplateId().getObject();
                aPhase = initiatePhaseWorkflow (phaseTemplate, aPhase, lcmobject, null);
                PersistenceServerHelper.manager.update(aPhase, false);
            }
            trx.commit();
            trx = null;

        }
        catch (WTPropertyVetoException veto) {

            if(logger.isDebugEnabled()){
                logger.debug(veto.getLocalizedMessage(), veto);
            }
            throw new LifeCycleException(veto);
        }
        catch (PersistenceException dbError) {

            if(logger.isDebugEnabled()){
                logger.debug(dbError.getLocalizedMessage(), dbError);
            }
            throw new LifeCycleException(dbError);
        }
        catch (WTException wex) {

            if(logger.isDebugEnabled()){
                logger.debug(wex.getLocalizedMessage(), wex);
            }
            throw new LifeCycleException(wex);
        }
        finally {
            if (trx != null)
                trx.rollback();
        }

        // 8.  If found, mark the associated work items as complete
        markWorkItemAsComplete(lcmsignature, lcmobject);

        if (logger.isTraceEnabled())
            logger.trace(">>Out StandardLifeCycleService...doDeny(LifeCycleManaged object, LifeCycleSignature signature) method");

        return lcmobject;

    }

    /**
     * Remove the object from the life cycle and set its state to DROPPED.
     *  Also, terminate the associated workflow(s).
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     object  the LifeCycleManaged object to be used in the demote
     * @param     signature  the LifeCycleSignature object to be used to record information about the demote
     * @return    LifeCycleManaged
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public LifeCycleManaged doDrop( LifeCycleManaged object, LifeCycleSignature signature )
            throws WTException, LifeCycleException {
        LifeCycleManaged lcmobject = object;
        LifeCycleSignature lcssignature = signature;
        /* 1. Record signature & set state to DROPPED  */
        Transaction trx = new Transaction();
        //  boolean finalPhase = false;
        Phase aPhase = null;

        try {

            trx.start();
            LifeCycleState oldState = lcmobject.getState();
            if(isLifeHistoryAssociated(lcmobject))
            {
                Phase oldPhase=getPhase(lcmobject);
                saveHistory(lcmobject,oldPhase,EXIT_PHASE,(Timestamp)null, null);
            }
            // 1. Record the drop action
            lcssignature = vote(lcmobject,lcssignature);

            // 2. Log history
            aPhase = getCurrentPhase(lcmobject);
            LifeCycleHistory aHistory = saveHistory(lcmobject,aPhase,DROP);

            if (aPhase == null && lcmobject.isLifeCycleBasic()){
                if(logger.isDebugEnabled())
                    logger.debug("  Object is basic life cycle managed. Do nothing to teminate workflow and cleanup CurrentPhase.");
            }else{
                // 3a. If found, mark the associated work item as complete - if it's not found, this method ignores the exception
                markWorkItemAsComplete(lcssignature, lcmobject);

                // 3b.  Terminate the associated WF phase/gate processes
                WfEngineHelper.service.terminateObjectsRunningWorkflows((Persistable) lcmobject);

                // 4. Move signatures to history & delete the current phase
                cleanupCurrentPhase(lcmobject,aPhase,aHistory);
            }
            // 5. Do the drop - set the state and update the cookie (using partial update)
            PersistenceServerHelper.manager.lock (lcmobject, true);
            lcmobject = (LifeCycleManaged)PersistenceServerHelper.manager.restore(lcmobject);
            LifeCycleState lcs = setState((LifeCycleManaged)lcmobject,State.DROPPED,false);
            PersistenceServerHelper.manager.update(lcmobject,LifeCycleManaged.STATE,lcs);

            // 6. Dispatch the state change event
            dispatchVetoableEvent( LifeCycleServiceEvent.STATE_CHANGE, lcmobject );

            // 7. Dispatch the drop event
            dispatchVetoableEvent( LifeCycleServiceEvent.DROP, lcmobject );

            // 8. Contribute to Summary Event
            if (lcmobject instanceof Notifiable)
                ChangeLifecycleStateSummaryEvent.getSummaryEvent().contribute((Notifiable)lcmobject, oldState, lcs);

            trx.commit();
            trx = null;

        }
        catch (WTPropertyVetoException veto) {
            if(logger.isDebugEnabled()){
                logger.debug(veto.getLocalizedMessage(), veto);
            }
            throw new LifeCycleException(veto);}
        catch (WTException wex) {
            if(logger.isDebugEnabled()){
                logger.debug(wex.getLocalizedMessage(), wex);
            }
            throw new LifeCycleException(wex);}
        finally {
            if (trx != null) {
                trx.rollback();
            }
        }

        if (logger.isTraceEnabled())
            logger.trace("Exit doDrop");

        return lcmobject;

    }

    /**
     * Re-assign the object to a new life cycle. Transfer current phase information
     * to history.
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     object  the LifeCycleManaged object to be reassigned
     * @param     lctRef
     * @return    LifeCycleManaged
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public LifeCycleManaged doReassign( LifeCycleManaged object, LifeCycleTemplateReference lctRef )
            throws WTException, LifeCycleException {
        return doReassign (object, lctRef, null, null);
    }

    /**
     * Perform pre-submit validations
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     object  the LifeCycleManaged object to be submitted
     * @return    LifeCycleManaged
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    @SuppressWarnings("deprecation")
    public LifeCycleManaged validateSubmit( LifeCycleManaged object )
            throws WTException, LifeCycleException {

        // -- Customization point
        if (logger.isTraceEnabled())
            logger.trace(">>In StandardLifeCycleService...validateSubmit(LifeCycleManaged object) method");
        LifeCycleException lcExcep=null;
        boolean enforce = SessionServerHelper.manager.setAccessEnforced(false);
        try {

            // - check to make sure the object passed in is the latest iteration
            String action = WTMessage.getLocalizedMessage(
                    RESOURCE,
                    SUBMIT,
                    null);
            validateIsLatestIteration(object, action);

            // -- Object must not be at the gate
            if (object.isLifeCycleAtGate()) {
                lcExcep=new LifeCycleException(RESOURCE,lifecycleResource.SUBMIT_FROM_GATE,null);
                if(logger.isDebugEnabled()){
                    logger.debug(lcExcep.getLocalizedMessage(), lcExcep);
                }
                throw lcExcep;
            }

            // -- Working copies may not be submitted
            if (isWorkingCopy(object, false)) {
                lcExcep= new LifeCycleException(RESOURCE,lifecycleResource.WORKING_COPY_SUBMIT,null);
                if(logger.isDebugEnabled()){
                    logger.debug(lcExcep.getLocalizedMessage(), lcExcep);
                }
                throw lcExcep;

            }

            // -- Checked out objects may not be submitted
            if (isCheckedOut(object)) {
                Object[] param = { action };
                lcExcep=new LifeCycleException(RESOURCE,lifecycleResource.CHECKED_OUT_OBJECT,param);
                if(logger.isDebugEnabled()){
                    logger.debug(lcExcep.getLocalizedMessage(), lcExcep);
                }
                throw lcExcep;
            }

            // -- Objects in the personal cabinet cannot be submitted
            if (object instanceof FolderEntry)
                if (FolderHelper.inPersonalCabinet((CabinetBased)object)) {
                    lcExcep=new LifeCycleException(RESOURCE,lifecycleResource.PERSONAL_CABINET_SUBMIT, null);
                    if(logger.isDebugEnabled()){
                        logger.debug(lcExcep.getLocalizedMessage(), lcExcep);
                    }
                    throw lcExcep;
                }
        }
        finally {
            SessionServerHelper.manager.setAccessEnforced(enforce);
        }
        if (logger.isTraceEnabled())
            logger.trace(">>Out StandardLifeCycleService...validateSubmit(LifeCycleManaged object) method");
        return object;

    }

    /**
     * Perform pre-promote validations
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     object  the LifeCycleManaged object to be promoted
     * @param     signature  the LifeCycleSignature object to be used to record information about the promote
     * @return    LifeCycleSignature
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public LifeCycleSignature validatePromote( LifeCycleManaged object, LifeCycleSignature signature )
            throws WTException, LifeCycleException {

        // -- Customization point
        LifeCycleException lcExcep=null;
        if (logger.isTraceEnabled())
            logger.trace(">>Out StandardLifeCycleService...validatePromote(LifeCycleManaged object, LifeCycleSignature signature) method");
        // - check to make sure the object passed in is the latest iteration
        String action = WTMessage.getLocalizedMessage(
                RESOURCE,
                PROMOTE,
                null);
        validateIsLatestIteration(object, action);

        // -- Must have been submitted.
        // -- Notes:
        // --    In theory this can never happen but it currently
        // --    can occur if user is a promoter for multiple phases
        // --    and accesses via a notifiction message from a previous phase.
        // --    (True fix is to prevent old notification URLs to be usable
        // --    against objects in a different state)
        if ( !(object.isLifeCycleAtGate()) ) {
            Object[] param = { IdentityFactory.getDisplayIdentity(object),PROMOTE };
            lcExcep=new LifeCycleException(RESOURCE,lifecycleResource.NOT_SUBMITTED,param);
            throw lcExcep;
        }

        // -- Promote from final phase is no-op
        if (logger.isTraceEnabled())
            logger.trace(" -- Promote from final phase is no-op");
        if (isInFinalPhase(object))
        {
            lcExcep=new LifeCycleException(RESOURCE,lifecycleResource.PROMOTE_FROM_FINAL_PHASE,null);
            throw lcExcep;
        }

        // -- Checked out objects may not be promoted/demoted/dropped
        if (logger.isTraceEnabled())
            logger.trace(" -- Checked out objects may not be promoted/demoted/dropped");
        if (isCheckedOut(object)) {
            Object[] param = { action };
            lcExcep=new LifeCycleException(RESOURCE,lifecycleResource.CHECKED_OUT_OBJECT,param);
            throw lcExcep;
        }
        if (logger.isTraceEnabled())
            logger.trace(">>Out StandardLifeCycleService...validatePromote(LifeCycleManaged object, LifeCycleSignature signature) method");
        return signature;

    }

    /**
     * Perform pre-demote validations
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     object  the LilfeCycleManaged object to be demoted
     * @param     signature  the LifeCycleSignature object used to record information about the demote
     * @return    LifeCycleSignature
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public LifeCycleSignature validateDemote( LifeCycleManaged object, LifeCycleSignature signature )
            throws WTException, LifeCycleException {

        // -- Customization point

        // - check to make sure the object passed in is the latest iteration
        if (logger.isTraceEnabled())
            logger.trace(">>In StandardLifeCycleService...validateDemote(LifeCycleManaged object, LifeCycleSignature signature) method");
        LifeCycleException lcExcep=null;
        String action = WTMessage.getLocalizedMessage(
                RESOURCE,
                DEMOTE,
                null);
        validateIsLatestIteration(object, action);

        // -- Must have been submitted.
        // -- Notes:
        // --    In theory this can never happen but it currently
        // --    can occur if user is a promoter for multiple phases
        // --    and accesses via a notifiction message from a previous phase.
        // --    (True fix is to prevent old notification URLs to be usable
        // --    against objects in a different state)
        if ( !(object.isLifeCycleAtGate()) ) {
            Object[] param = { IdentityFactory.getDisplayIdentity(object),PROMOTE };
            lcExcep=new LifeCycleException(RESOURCE,lifecycleResource.NOT_SUBMITTED,param);
            if(logger.isDebugEnabled()){
                logger.debug(lcExcep.getLocalizedMessage(), lcExcep);
            }
            throw lcExcep;
        }

        // -- Demote from initial phase is not allowed
        if (isInInitialPhase(object))
        {
            lcExcep= new LifeCycleException(RESOURCE,lifecycleResource.DEMOTE_FROM_INITIAL_PHASE,null);
            if(logger.isDebugEnabled()){
                logger.debug(lcExcep.getLocalizedMessage(), lcExcep);
            }
            throw lcExcep;
        }

        // -- Checked out objects may not be promoted/demoted/dropped
        if (isCheckedOut(object)) {
            Object[] param = { action };
            lcExcep= new LifeCycleException(RESOURCE,lifecycleResource.CHECKED_OUT_OBJECT,param);
            if(logger.isDebugEnabled()){
                logger.debug(lcExcep.getLocalizedMessage(), lcExcep);
            }
            throw lcExcep;
        }
        if (logger.isTraceEnabled())
            logger.trace(">>In StandardLifeCycleService...validateDemote(LifeCycleManaged object, LifeCycleSignature signature) method");
        return signature;

    }

    /**
     * Perform pre-deny validations
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     object  the LilfeCycleManaged object to be demoted
     * @param     signature  the LifeCycleSignature object used to record information about the demote
     * @return    LifeCycleSignature
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public LifeCycleSignature validateDeny( LifeCycleManaged object, LifeCycleSignature signature )
            throws WTException, LifeCycleException {


        // -- Customization point
        if (logger.isTraceEnabled())
            logger.trace(">>In StandardLifeCycleService...validateDeny(LifeCycleManaged object, LifeCycleSignature signature) method");

        LifeCycleException lcExcep=null;
        // - check to make sure the object passed in is the latest iteration
        String action = WTMessage.getLocalizedMessage(
                RESOURCE,
                DENY,
                null);
        validateIsLatestIteration(object, action);

        // -- Must have been submitted.
        // -- Notes:
        // --    In theory this can never happen but it currently
        // --    can occur if user is a promoter for multiple phases
        // --    and accesses via a notifiction message from a previous phase.
        // --    (True fix is to prevent old notification URLs to be usable
        // --    against objects in a different state)
        if ( !(object.isLifeCycleAtGate()) ) {
            Object[] param = { IdentityFactory.getDisplayIdentity(object),PROMOTE };
            lcExcep=new LifeCycleException(RESOURCE,lifecycleResource.NOT_SUBMITTED,param);

            if(logger.isDebugEnabled()){
                logger.debug(lcExcep.getLocalizedMessage(), lcExcep);
            }
            throw lcExcep;
        }

        // -- Checked out objects may not be promoted/demoted/dropped
        if (isCheckedOut(object)) {
            Object[] param = { action };
            lcExcep= new LifeCycleException(RESOURCE,lifecycleResource.CHECKED_OUT_OBJECT,param);

            if(logger.isDebugEnabled()){
                logger.debug(lcExcep.getLocalizedMessage(), lcExcep);
            }
            throw lcExcep;
        }
        if (logger.isTraceEnabled())
            logger.trace(">>Out StandardLifeCycleService...validateDeny(LifeCycleManaged object, LifeCycleSignature signature) method");
        return signature;
    }

    /**
     * Perform pre-drop validations
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     object  the LifeCycleManaged object that should be voted on
     * @param     signature  the LifeCycleSignature object used to record information about the vote
     * @return    LifeCycleSignature
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public LifeCycleSignature validateDrop( LifeCycleManaged object, LifeCycleSignature signature )
            throws WTException, LifeCycleException {

        // -- Customization point
        if (logger.isTraceEnabled())
            logger.trace(">>In StandardLifeCycleService...validateDrop() method");
        LifeCycleException lcExcep=null;
        // - check to make sure the object passed in is the latest iteration
        String action = WTMessage.getLocalizedMessage(
                RESOURCE,
                DROP,
                null);
        validateIsLatestIteration(object, action);


        // -- Must have been submitted.
        // -- Notes:
        // --    In theory this can never happen but it currently
        // --    can occur if user is a promoter for multiple phases
        // --    and accesses via a notifiction message from a previous phase.
        // --    (True fix is to prevent old notification URLs to be usable
        // --    against objects in a different state)
        if ( !(object.isLifeCycleAtGate()) ) {
            Object[] param = { IdentityFactory.getDisplayIdentity(object),PROMOTE };
            lcExcep=new LifeCycleException(RESOURCE,lifecycleResource.NOT_SUBMITTED,param);
            if(logger.isDebugEnabled()){
                logger.debug(lcExcep.getLocalizedMessage(), lcExcep);
            }
            throw lcExcep;
        }

        // -- Checked out objects may not be promoted/demoted/dropped
        if (isCheckedOut(object)) {
            Object[] param = { action };
            lcExcep=new LifeCycleException(RESOURCE,lifecycleResource.CHECKED_OUT_OBJECT,param);
            if(logger.isDebugEnabled()){
                logger.debug(lcExcep.getLocalizedMessage(), lcExcep);
            }
            throw lcExcep;
        }

        if (logger.isTraceEnabled())
            logger.trace(">>Out StandardLifeCycleService...validateDrop() method");
        return signature;

    }

    /**
     * Perform pre-vote validations
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     object  the LifeCycleManaged object that should be voted on
     * @param     signature  the LifeCycleSignature object used to record information about the vote
     * @return    LifeCycleSignature
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public LifeCycleSignature validateVote( LifeCycleManaged object, LifeCycleSignature signature )
            throws WTException, LifeCycleException {

        // -- Customization point

        // - check to make sure the object passed in is the latest iteration
        if (logger.isTraceEnabled())
            logger.trace(">>In StandardLifeCycleService...validateVote(LifeCycleManaged object, LifeCycleSignature signature) method");
        LifeCycleException lcExcep=null;
        String action = WTMessage.getLocalizedMessage(
                RESOURCE,
                VOTE,
                null);
        validateIsLatestIteration(object, action);

        if (signature == null)
        {
            lcExcep=new LifeCycleException(RESOURCE,lifecycleResource.NULL_SIGNATURE,null);

            if(logger.isDebugEnabled()){
                logger.debug(lcExcep.getLocalizedMessage(), lcExcep);
            }
            throw lcExcep;
        }

        if (signature.getSignerName() == null)
        {
            lcExcep= new LifeCycleException(RESOURCE,lifecycleResource.NO_SIGNER,null);

            if(logger.isDebugEnabled()){
                logger.debug(lcExcep.getLocalizedMessage(), lcExcep);
            }
            throw lcExcep;
        }
        if (logger.isTraceEnabled())
            logger.trace(">>Out StandardLifeCycleService...validateVote(LifeCycleManaged object, LifeCycleSignature signature) method");
        return signature;

    }

    /**
     * Perform pre-reassign validations
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     object  the LifeCycleManaged object that should be reassigned
     * @param     lctRef
     * @return    LifeCycleManaged
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public LifeCycleManaged validateReassign( LifeCycleManaged object, LifeCycleTemplateReference lctRef )
            throws WTException, LifeCycleException {

        if (logger.isTraceEnabled())
            logger.trace(">>In StandardLifeCycleService...validateReassign(LifeCycleManaged object, LifeCycleTemplateReference lctRef) method");
        LifeCycleException lcExcep=null;

        // -- Customization point


        // - check to make sure the object passed in is the latest iteration
        String action = WTMessage.getLocalizedMessage(
                RESOURCE,
                REASSIGN,
                null,this.getLocale());
        validateIsLatestIteration(object, action);

        //--- Access control check for Reassign
        AccessControlHelper.manager.checkAccess(object, AccessPermission.MODIFY);

        // --- Validate the Life Cycle Template is not null and doesn't contain a null
        if (lctRef == null) {
            lcExcep=new LifeCycleException(RESOURCE, lifecycleResource.NULL_TEMPLATE, null);

            if(logger.isDebugEnabled()){
                logger.debug(lcExcep.getLocalizedMessage(), lcExcep);
            }
            throw lcExcep;
        }
        else {
            if (lctRef.getKey() == null) {
                lcExcep=new LifeCycleException(RESOURCE, lifecycleResource.NULL_TEMPLATE, null);

                if(logger.isDebugEnabled()){
                    logger.debug(lcExcep.getLocalizedMessage(), lcExcep);
                }
                throw lcExcep;
            }
        }

        // -- Working copies may not be reassigned
        if (isWorkingCopy(object, false)) {
            throw new LifeCycleException(RESOURCE,lifecycleResource.WORKING_COPY_SUBMIT,null);
        }

        // -- Checked out objects may not be reassigned
        if (isCheckedOut(object)) {
            Object[] param = { action };
            throw new LifeCycleException(RESOURCE,lifecycleResource.CHECKED_OUT_OBJECT,param);
        }

        if (logger.isTraceEnabled())
            logger.trace(">>Out StandardLifeCycleService...validateReassign(LifeCycleManaged object, LifeCycleTemplateReference lctRef) method");

        return object;

    }

    /**
     * Create a history entry based on a life cycle event. This method is
     * invoked for each of:
     * <p>
     * <PRE>
     * 1. StandardLifeCycleService.ENTER_PHASE
     *    #  Default: History event recorded
     * 2. StandardLifeCycleService.SUBMIT
     *    # Default: History event recorded
     * 3. StandardLifeCycleService.PROMOTE
     *    # Default: History event recorded
     * 4. StandardLifeCycleService.VOTE
     *    # Default: Signature created but no history event recorded
     * 5. StandardLifeCycleService.DEMOTE
     *    # Default: History event recorded
     * 6. StandardLifeCycleService.DROP
     *    # Default: History event recorded
     * 7. StandardLifeCycleService.DENY
     *    # Default: History event recorded
     * 8. StandardLifeCycleService.RETEAM
     *    # Default: History event recorded
     * 9. StandardLifeCycleService.REASSIGN
     *    # Default: History event recorded
     * </PRE>
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     object  the LifeCycleManaged object that the history is associated to
     * @param     aPhase  the Phase object that the history will be associated to
     * @param     event  the name of the event that History is associated to
     * @return    LifeCycleHistory
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public LifeCycleHistory saveHistory( LifeCycleManaged object, Phase aPhase, String event )
            throws WTException, LifeCycleException {

        if (logger.isTraceEnabled()) {
            logger.trace(">>In StandardLifeCycleService...saveHistory(LifeCycleManaged object, Phase aPhase, String event) method");
            logger.trace("Enter saveHistory on"+event+"for "+getOid(object));
            logger.trace("ENABLE_HISTORY="+ENABLE_HISTORY);
        }

        // -- do nothing if history is not turned on

        return saveHistory(object, aPhase, event, (String)null);

    }

    /**
     * Answer the phase name of the current phase for the specified life
     * cycle managed object
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     object  the LifeCycleManaged object used as search criteria in the retrieval of the name of the phase
     * @return    String
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public String getPhaseName( LifeCycleManaged object )
            throws WTException, LifeCycleException {

        Phase aPhase = getCurrentPhase(object);
        if (aPhase == null && object.isLifeCycleBasic()){
            if (logger.isTraceEnabled())
                logger.trace("  getPhaseName: Object is basic life cycle managed. Return null.");
            return getPhaseTemplate(object).getName();
        }else if(aPhase != null){
            return aPhase.getName();
        }else{
            return null;
        }
    }

    /**
     * Answer an enumeration of LifeCycleManaged objects current in the specified
     * life cycle. Caution - this could be a large result set.
     *
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @deprecated at 5.0 - Use the whereUsed methods instead.
     *
     * @param     templateName  the name of the LifeCycleTemplate used as search criteria in the retrieval of LifeCycleManaged objects associated to the LifeCycleTemplate name
     * @return    Enumeration
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public Enumeration getRunningInstances( String templateName )
            throws WTException, LifeCycleException {

        QuerySpec qs = new QuerySpec(LifeCycleManaged.class);
        SearchCondition sc1 = new SearchCondition(
                LifeCycleManaged.class,
                LifeCycleManaged.LIFE_CYCLE_NAME,
                SearchCondition.EQUAL,
                templateName,
                true);

        // -- Retrieve LifeCycleManaged objects
        return (PersistenceServerHelper.manager.query(qs));

    }

    /**
     * Submit the object for review.  This executes doSubmit.  This method
     * should be used by the Workflow robot to complete a Submit.
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     object  the LifeCycleManaged object that should be submitted for approval
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public void submit( WTObject object )
            throws WTException, LifeCycleException {
        WTObject wtoobject = object;
        LifeCycleException lcExcep=null;
        if ( logger.isTraceEnabled())
            logger.trace("Enter submit (for use by robots only)"+getOid(wtoobject));

        // 1.  Validate the robotable input
        if (wtoobject == null) {
            lcExcep=new LifeCycleException(RESOURCE,lifecycleResource.NULL_OBJECT,null);
            if(logger.isDebugEnabled()){
                logger.debug(lcExcep.getLocalizedMessage(), lcExcep);
            }
            throw lcExcep;
        }
        if ( !(wtoobject instanceof LifeCycleManaged) ) {
            String action = WTMessage.getLocalizedMessage(
                    RESOURCE,
                    SUBMIT,
                    null);
            Object[] param = { action };
            lcExcep=new LifeCycleException(RESOURCE,lifecycleResource.OBJECT_NOT_LCMD,param);
            if(logger.isDebugEnabled()){
                logger.debug(lcExcep.getLocalizedMessage(), lcExcep);
            }
            throw lcExcep;
        }

        // -- Validate the submit before doing it
        wtoobject = (WTObject)validateSubmit((LifeCycleManaged)wtoobject);

        // 2.  If okay, do the submit
        wtoobject = (WTObject)doSubmit((LifeCycleManaged)wtoobject);
        if(logger.isDebugEnabled())
            logger.debug("Exit submit");

        if (logger.isTraceEnabled())
            logger.trace(">>Out StandardLifeCycleService...submit(WTObject) method");


    }

    /**
     * Promote an object to the next phase.  This executes doPromote.  This
     * method should be used by the Workflow robot to promote the object
     * to the next phase.
     *
     * If the object is not already at the gate, the Submit robotable method
     * is first executed.
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     object  the LifeCycleManaged object that should be promoted
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public void promote( WTObject object )
            throws WTException, LifeCycleException {
        WTObject wtoobject=object;
        LifeCycleException lcExcep=null;
        if (logger.isTraceEnabled())
            logger.trace("Enter promote (for use by robots only)"+getOid(wtoobject));

        // 1.  Validate the robotable input
        if (wtoobject == null) {
            lcExcep=new LifeCycleException(RESOURCE,lifecycleResource.NULL_OBJECT,null);
            throw lcExcep;
        }

        if ( !(wtoobject instanceof LifeCycleManaged) ) {
            String action = WTMessage.getLocalizedMessage(
                    RESOURCE,
                    PROMOTE,
                    null);
            Object[] param = { action };
            lcExcep= new LifeCycleException(RESOURCE,lifecycleResource.OBJECT_NOT_LCMD,param);
            throw lcExcep;
        }

        // 1b.  If the object isn't already at the gate, submit it.
        if (!((LifeCycleManaged)wtoobject).isLifeCycleAtGate()) {
            if (logger.isTraceEnabled())
                logger.trace("In the Promote Robot, completing the Submit because the object isn't at the gate");
            submit(wtoobject);
            wtoobject = (WTObject)PersistenceServerHelper.manager.restore(wtoobject);
        }

        // 2. Validate promote
        LifeCycleSignature signature = createRobotLifeCycleSignature(wtoobject, Role.toRole("PROMOTER"));
        signature = validatePromote((LifeCycleManaged)wtoobject,signature);

        // 3.  If okay, do the promote
        wtoobject = (WTObject)doPromote((LifeCycleManaged)wtoobject, signature);
        if(logger.isDebugEnabled())
            logger.debug("Exit promote");

        if (logger.isTraceEnabled())
            logger.trace(">>Out StandardLifeCycleService...promote(WTObject object ) method");


    }

    /**
     * Demote the object to the previous phase.  This executes the doDemote
     * method.  This method should be used by the Workflow robot.
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     object  the LifeCycleManaged object that should be demoted.
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public void demote( WTObject object )
            throws WTException, LifeCycleException {
        WTObject wtoobject = object;
        if (logger.isTraceEnabled())
            logger.trace("Enter demote (for use by robots only)"+getOid(wtoobject));
        LifeCycleException lcExcep=null;

        // 1.  Validate the robotable input
        if (wtoobject == null) {
            throw new LifeCycleException(RESOURCE,lifecycleResource.NULL_OBJECT,null);
        }

        if ( !(wtoobject instanceof LifeCycleManaged) ) {
            String action = WTMessage.getLocalizedMessage(
                    RESOURCE,
                    DEMOTE,
                    null);
            Object[] param = { action };
            throw new LifeCycleException(RESOURCE,lifecycleResource.OBJECT_NOT_LCMD,param);
        }

        // 1. Validate demote
        LifeCycleSignature signature = createRobotLifeCycleSignature(wtoobject, Role.toRole("PROMOTER"));
        signature = validateDemote((LifeCycleManaged)wtoobject,signature);

        // 2.  If okay, do the demote
        wtoobject = (WTObject)doDemote((LifeCycleManaged)wtoobject, signature);

        if (logger.isTraceEnabled())
            logger.trace("Exit demote");


    }

    /**
     * Return the object to the submitter, removing it from the gate.  This
     * process executes the doDeny method.  This method should be used by
     * the Workflow robot.
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     object  the LifeCycleManaged object that should be denied
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public void deny( WTObject object )
            throws WTException, LifeCycleException {
        WTObject wtoobject= object;
        if ( logger.isTraceEnabled() )
            logger.trace("Enter deny (for use by robots only)"+getOid(wtoobject));
        LifeCycleException lcExcep=null;

        // 1.  Validate the robotable input
        if (wtoobject == null) {
            throw new LifeCycleException(RESOURCE,lifecycleResource.NULL_OBJECT,null);
        }

        if ( !(wtoobject instanceof LifeCycleManaged) ) {
            String action = WTMessage.getLocalizedMessage(
                    RESOURCE,
                    DENY,
                    null);
            Object[] param = { action };
            lcExcep=new LifeCycleException(RESOURCE,lifecycleResource.OBJECT_NOT_LCMD,param);
            if(logger.isDebugEnabled()){
                logger.debug(lcExcep.getLocalizedMessage(), lcExcep);
            }
            throw lcExcep;
        }

        // 2. Validate deny
        LifeCycleSignature signature = createRobotLifeCycleSignature(wtoobject, Role.toRole("PROMOTER"));
        signature = validateDeny((LifeCycleManaged)wtoobject,signature);

        // 3.  If okay, do the deny
        wtoobject = (WTObject)doDeny((LifeCycleManaged)wtoobject, signature);

        if (logger.isTraceEnabled())
            logger.trace("Exit deny");


    }

    /**
     * Transition the object to an end state.  This process executes the
     * doDrop.  This method should be used by the Workflow robot.
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     object  the LifeCycleManaged object that should be moved to a final/dropped state
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public void drop( WTObject object )
            throws WTException, LifeCycleException {
        WTObject wtoobject= object;
        if (logger.isTraceEnabled())
            logger.trace("Enter drop (for use by robots only)"+getOid(object));

        // 1.  Validate the robotable input
        if (wtoobject == null) {
            throw new LifeCycleException(RESOURCE,lifecycleResource.NULL_OBJECT,null);
        }

        if ( !(wtoobject instanceof LifeCycleManaged) ) {
            String action = WTMessage.getLocalizedMessage(
                    RESOURCE,
                    DROP,
                    null);
            Object[] param = { action };
            throw new LifeCycleException(RESOURCE,lifecycleResource.OBJECT_NOT_LCMD,param);
        }

        // 2 Validate drop
        LifeCycleSignature signature = createRobotLifeCycleSignature(wtoobject, Role.toRole("PROMOTER"));
        signature = validateDrop((LifeCycleManaged)wtoobject,signature);

        // 3.  If okay, do the drop
        wtoobject = (WTObject)doDrop((LifeCycleManaged)wtoobject, signature);



        if (logger.isTraceEnabled())
            logger.trace("Exit drop");


    }

    /**
     * Transition the object to an different state.  This process executes
     * the validateSetState.  This method should be used by the Workflow
     * SetState robot.
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     object  the LifeCycleManaged object
     * @param     aState  The state to set the LifeCycleManaged object to.
     * @return    LifeCycleManaged
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public LifeCycleManaged setState( LifeCycleManaged object, State aState )
            throws WTException, LifeCycleException {
        LifeCycleManaged lcmobject= object;
        if ( logger.isTraceEnabled() )
            logger.trace("Enter setState:" + getOid(lcmobject));

        PhaseTemplate aPhaseTemplate = null;

        aPhaseTemplate = validateSetState(lcmobject, aState);
        lcmobject=doSetState(lcmobject, aPhaseTemplate);

        if (logger.isTraceEnabled())
            logger.trace("Exit setState");

        return lcmobject;

    }

    /**
     * Transition the object to an different state.  This process executes
     * the validateSetState.  This method should be used by the Workflow
     * SetState robot.
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     object  the LifeCycleManagedObject.
     * @param     aStateOrdinal  The ordianal value of the state to set the LifeCycleManaged object to.
     * @return    LifeCycleManaged
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public LifeCycleManaged setState( LifeCycleManaged object, int aStateOrdinal )
            throws WTException, LifeCycleException {
        LifeCycleManaged lcmobject= object;
        int intaStateOrdinal = aStateOrdinal;
        if ( logger.isTraceEnabled() )
            logger.trace("Enter setState:" + getOid(lcmobject));

        PhaseTemplate aPhaseTemplate = null;
        intaStateOrdinal = intaStateOrdinal -1;

        aPhaseTemplate = validateSetState(lcmobject, intaStateOrdinal);
        lcmobject=doSetState(lcmobject, aPhaseTemplate);

        if (logger.isTraceEnabled())
            logger.trace("Exit setState");

        return lcmobject;
    }

    /**
     * Used by setState, checks that the state the Workflow SetState robot
     * is tying to set the object to is valid.
     *
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     object  The LifeCycleManagedObject
     * @param     aState  The state to set the LifeCycleManagedObject to, this state must be validated.
     * @return    PhaseTemplate
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    @SuppressWarnings("deprecation")
    public PhaseTemplate validateSetState( LifeCycleManaged object, State aState )
            throws WTException, LifeCycleException {

        PhaseTemplate pt =null;
        LifeCycleException lcExcep=null;

        if (logger.isTraceEnabled())
        {
            logger.trace(">>In StandardLifeCycleService...validateSetState(LifeCycleManaged object, State aState) method");
            logger.trace("--getOid:" + getOid(object));
        }

        try{


            //Validate the state
            pt = validateState(object, aState);

            //setState is prohibited on the working copy
            if (isWorkingCopy(object, true)) {
                lcExcep=new LifeCycleException(RESOURCE,lifecycleResource.WORKING_COPY_SET_STATE,null);
                if(logger.isDebugEnabled()){
                    logger.debug(lcExcep.getLocalizedMessage(), lcExcep);
                }
                throw lcExcep;
            }


            // -- Checked out objects may not be promoted/demoted/dropped/setstate
            if (isCheckedOut(object)) {
                String action = WTMessage.getLocalizedMessage(RESOURCE,SET_STATE,null);
                Object[] param = { action };
                lcExcep= new LifeCycleException(RESOURCE,lifecycleResource.CHECKED_OUT_OBJECT,param);
                if(logger.isDebugEnabled()){
                    logger.debug(lcExcep.getLocalizedMessage(), lcExcep);
                }
                throw lcExcep;
            }

            // -- Objects in the personal cabinet cannot have a set state performed on them.
            if (object instanceof FolderEntry)
                if (FolderHelper.inPersonalCabinet((CabinetBased)object)) {
                    lcExcep= new LifeCycleException(RESOURCE,lifecycleResource.PERSONAL_CABINET_SET_STATE, null);
                    if(logger.isDebugEnabled()){
                        logger.debug(lcExcep.getLocalizedMessage(), lcExcep);
                    }
                    throw lcExcep;
                }

        }
        catch (PersistenceException dbError) {
            if(logger.isDebugEnabled()){
                logger.debug(dbError.getLocalizedMessage(), dbError);
            }
            throw new LifeCycleException(dbError);}


        if (logger.isTraceEnabled())
            logger.trace(">>Out StandardLifeCycleService...validateSetState(LifeCycleManaged object, State aState) method");

        return pt;

    }

    /**
     * Used by setState, checks that the state the Workflow SetState robot
     * is tying to set the object to is valid.
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     object  The LifeCycleManagedObject.
     * @param     aStateOrdinal  The state ordinal value to set the LifeCycleManagedObject to, this state must be validated.
     * @return    PhaseTemplate
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    @SuppressWarnings("deprecation")
    public PhaseTemplate validateSetState( LifeCycleManaged object, int aStateOrdinal )
            throws WTException, LifeCycleException {

        PhaseTemplate pt =null;

        if (logger.isTraceEnabled())
            logger.trace("Enter validateSetState:" + getOid(object));

        try{

            pt = validateState(object, aStateOrdinal);

            //setState is prohibited on the working copy
            if (isWorkingCopy(object, true)) {
                throw new LifeCycleException(RESOURCE,lifecycleResource.WORKING_COPY_SET_STATE,null);
            }

            // -- Checked out objects may not be promoted/demoted/dropped/setstate
            if (isCheckedOut(object)) {
                String action = WTMessage.getLocalizedMessage(RESOURCE,SET_STATE,null);
                Object[] param = { action };
                throw new LifeCycleException(RESOURCE,lifecycleResource.CHECKED_OUT_OBJECT,param);
            }

            // -- Objects in the personal cabinet cannot have a set state performed on them.
            if (object instanceof FolderEntry)
                if (FolderHelper.inPersonalCabinet((CabinetBased)object)) {
                    throw new LifeCycleException(RESOURCE,lifecycleResource.PERSONAL_CABINET_SET_STATE, null);
                }

        }
        catch (PersistenceException dbError) {
            if(logger.isDebugEnabled()){
                logger.debug(dbError.getLocalizedMessage(), dbError);
            }
            throw new LifeCycleException(dbError);}

        if (logger.isTraceEnabled())
            logger.trace("Exit validateSetState:" + getOid(object));

        return pt;

    }

    /**
     * Sets the state of the object.  Used by the Workflow SetState robot.
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     object  The LifeCycleManagedObject
     * @param     aPhaseTemplate  The phasetemplate to set the lifecyclemanagedobject to indicated by the state from setState.
     * @return    LifeCycleManaged
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public LifeCycleManaged doSetState( LifeCycleManaged object, PhaseTemplate aPhaseTemplate )
            throws WTException, LifeCycleException {
        return doSetState(object, aPhaseTemplate, null);
    }

    /**
     * Given a LifeCycleTemplate, return a QueryResult containing all LifeCycleManaged
     * objects that use it
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     aTemplate
     * @return    QueryResult
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    @SuppressWarnings("deprecation")
    public QueryResult whereUsed( LifeCycleTemplate aTemplate )
            throws WTException, LifeCycleException {

        if (logger.isTraceEnabled())
            logger.trace("Enter whereUsed by LifeCycleTemplate: " + aTemplate.getName() + " " + PersistenceHelper.getObjectIdentifier(aTemplate).toString());

        QuerySpec qs = new QuerySpec(LifeCycleManaged.class);
        SearchCondition sc1 = new SearchCondition(
                LifeCycleManaged.class,
                LifeCycleManaged.STATE + "." + LifeCycleState.LIFE_CYCLE_ID + "." + LifeCycleTemplateReference.KEY,
                SearchCondition.EQUAL,
                PersistenceHelper.getObjectIdentifier(aTemplate) );
        qs.appendWhere(sc1);

        QueryResult results = PersistenceServerHelper.manager.query(qs);

        if (logger.isTraceEnabled())
            logger.trace("Found "+results.size()+" LifeCycleManaged Objects");

        if (logger.isTraceEnabled())
            logger.trace("Exit whereUsed");

        return (results);
    }

    /**
     * Given a LifeCycleTemplateMaster, return a QueryResult containing all
     * LifeCycleManaged objects that use any iteration of it
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     aMaster
     * @return    QueryResult
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    @SuppressWarnings({ "deprecation"})
    public QueryResult whereUsed( LifeCycleTemplateMaster aMaster )
            throws WTException, LifeCycleException {

        if (logger.isTraceEnabled())
            logger.trace("Enter whereUsed by LifeCycleTemplateMaster: " + aMaster.getName() + " " + PersistenceHelper.getObjectIdentifier(aMaster).toString());

        Class[] classes = { LifeCycleManaged.class, LifeCycleTemplate.class};
        QuerySpec qs = new QuerySpec (classes);

        int lcmdPos = 0;
        int lctPos = 1;

        //Set which classes are selectable
        qs.setSelect(lcmdPos, true);
        qs.setSelect(lctPos, false);

        SearchCondition sc = new SearchCondition(
                LifeCycleManaged.class,
                LifeCycleManaged.STATE + "." + LifeCycleState.LIFE_CYCLE_ID + "." + LifeCycleTemplateReference.KEY + "." + ObjectIdentifier.ID,
                LifeCycleTemplate.class,
                "thePersistInfo.theObjectIdentifier.id");
        qs.appendWhere((sc), lcmdPos, lctPos);
        qs.appendAnd();
        SearchCondition sc2 = new SearchCondition(
                LifeCycleTemplate.class,
                LifeCycleTemplate.MASTER_REFERENCE + "." + LifeCycleTemplateMasterReference.KEY,
                SearchCondition.EQUAL,
                PersistenceHelper.getObjectIdentifier(aMaster));
        qs.appendWhere((sc2), lctPos, -1);
        QueryResult jqResults = PersistenceHelper.manager.find(qs);


        ObjectVector ov = new ObjectVector();
        while (jqResults.hasMoreElements()) {
            Persistable[] jq = (Persistable[])jqResults.nextElement();
            LifeCycleManaged lcmd = (LifeCycleManaged)jq[0];
            ov.addElement(lcmd);
        }
        QueryResult results = new QueryResult(ov);

        if (logger.isTraceEnabled())
            logger.trace("Found "+results.size()+" LifeCycleManaged Objects");

        if (logger.isTraceEnabled())
            logger.trace("Exit whereUsed");

        return (results);

    }

    /**
     * Used to Validate the WTObject from the robot and pass onto setState.
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     object  The WTObject containing the LifeCycleManaged object.
     * @param     aState  The state to set the LifeCycle to.
     * @return    WTObject
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public WTObject setState( WTObject object, State aState )
            throws WTException, LifeCycleException {


        if (logger.isTraceEnabled())
            logger.trace("Enter setState (for use by robots only)"+getOid(object));

        // 1.  Validate the robotable input
        if (object == null) {
            throw new LifeCycleException(RESOURCE,lifecycleResource.NULL_OBJECT,null);
        }

        if ( !(object instanceof LifeCycleManaged) ) {
            String action = WTMessage.getLocalizedMessage(
                    RESOURCE,
                    DEMOTE,
                    null);
            Object[] param = { action };
            throw new LifeCycleException(RESOURCE,lifecycleResource.OBJECT_NOT_LCMD,param);
        }


        return (WTObject)setState((LifeCycleManaged) object, aState);


    }

    /**
     * Used to Validate the WTObject from the robot and pass onto setState.
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     object  The WTObject containing the LifeCycleManaged object.
     * @param     aStateOrdinal  A ordinal value which corresponds to a state in the LifeCycle.
     * @return    WTObject
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public WTObject setState( WTObject object, Integer aStateOrdinal )
            throws WTException, LifeCycleException {


        if (logger.isTraceEnabled())
            logger.trace("Enter setState (for use by robots only)"+getOid(object));

        // 1.  Validate the robotable input
        if (object == null) {
            throw new LifeCycleException(RESOURCE,lifecycleResource.NULL_OBJECT,null);
        }

        if ( !(object instanceof LifeCycleManaged) ) {
            String action = WTMessage.getLocalizedMessage(
                    RESOURCE,
                    DENY,
                    null);
            Object[] param = { action };
            throw new LifeCycleException(RESOURCE,lifecycleResource.OBJECT_NOT_LCMD,param);
        }

        int intOrdinal = aStateOrdinal.intValue();

        return (WTObject)setState((LifeCycleManaged) object, intOrdinal);


    }

    /**
     * Given a WfProcessTemplateMaster, return a QueryResult containing all
     * PhaseTemplate objects that use it.
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     master
     * @return    QueryResult
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    @SuppressWarnings("deprecation")
    public QueryResult whereUsed( WfProcessTemplateMaster master )
            throws WTException, LifeCycleException {

        if (logger.isTraceEnabled())
            logger.trace("Enter whereUsed by WfProcessTemplateMaster: " + master.getName() + " " + PersistenceHelper.getObjectIdentifier(master).toString());

        QuerySpec qs = new QuerySpec(PhaseTemplate.class);
        qs.appendOpenParen();
        SearchCondition sc = new SearchCondition(
                PhaseTemplate.class,
                PhaseTemplate.PHASE_WORKFLOW_ID_REFERENCE+ "." + WfProcessTemplateMasterReference.KEY,
                SearchCondition.EQUAL,
                PersistenceHelper.getObjectIdentifier(master));
        qs.appendWhere(sc);
        qs.appendCloseParen();

        qs.appendOr();

        qs.appendOpenParen();
        SearchCondition sc1 = new SearchCondition(
                PhaseTemplate.class,
                PhaseTemplate.GATE_WORKFLOW_ID_REFERENCE+ "." + WfProcessTemplateMasterReference.KEY,
                SearchCondition.EQUAL,
                PersistenceHelper.getObjectIdentifier(master));
        qs.appendWhere(sc1);
        qs.appendCloseParen();

        QueryResult results = PersistenceServerHelper.manager.query(qs);

        if (logger.isTraceEnabled())
            logger.trace("Found "+results.size()+" PhaseTemplate Objects");

        if (logger.isTraceEnabled())
            logger.trace("Exit whereUsed");

        return (results);
    }

    /**
     * Given a WfProcessTemplate, return a QueryResult containing all PhaseTemplate
     * objects that use it
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     template
     * @return    QueryResult
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    @SuppressWarnings("deprecation")
    public QueryResult whereUsed( WfProcessTemplate template )
            throws WTException, LifeCycleException {

        if (logger.isTraceEnabled())
            logger.trace("Enter whereUsed by WfProcessTemplate: " + IdentityFactory.getDisplayIdentifier(template) + " " + PersistenceHelper.getObjectIdentifier(template).toString());

        QuerySpec qs = new QuerySpec(PhaseTemplate.class);
        qs.appendOpenParen();
        SearchCondition sc = new SearchCondition(
                PhaseTemplate.class,
                PhaseTemplate.PHASE_WORKFLOW_ID_REFERENCE+ "." + WfProcessTemplateMasterReference.KEY,
                SearchCondition.EQUAL,
                PersistenceHelper.getObjectIdentifier(template));
        qs.appendWhere(sc);
        qs.appendCloseParen();

        qs.appendOr();

        qs.appendOpenParen();
        SearchCondition sc1 = new SearchCondition(
                PhaseTemplate.class,
                PhaseTemplate.GATE_WORKFLOW_ID_REFERENCE+ "." + WfProcessTemplateMasterReference.KEY,
                SearchCondition.EQUAL,
                PersistenceHelper.getObjectIdentifier(template));
        qs.appendWhere(sc1);
        qs.appendCloseParen();

        QueryResult results = PersistenceServerHelper.manager.query(qs);

        if (logger.isTraceEnabled())
        {
            logger.trace("Found "+results.size()+" PhaseTemplate Objects");
            logger.trace("Exit whereUsed");
        }

        return (results);

    }

    /**
     * Transition the objects in the collection to a different state.  This
     * process executes the validateSetState.  This method should be used
     * by the Workflow SetState robot.
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     list  a collection of lifecycle managed objects
     * @param     aState  The state to set the LifeCycleManaged object to.
     * @return    WTList
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public WTList setState( WTList list, State aState )
            throws WTException, LifeCycleException {

        if (logger.isTraceEnabled())
            logger.trace("Enter setState(WTList), state= " + aState);

        WTKeyedMap phaseTemplateMaps = validateSetState(list, aState, null);
        doSetState(list, phaseTemplateMaps, false);

        if (logger.isTraceEnabled())
            logger.trace("Exit setState");

        return (WTList) CollectionsHelper.manager.refresh(list);
    }

    /**
     * Transition the objects in the collection to a different state.  This
     * process executes the validateSetState.  This method should be used
     * by the Workflow SetState robot.
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     list  a collection of lifecycle managed objects
     * @param     map  The state to set the LifeCycleManaged object to.  Key= LCMO.  Value = State.
     * @return    WTList
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/


    public WTList setState( WTList list, Map map )
            throws WTException, LifeCycleException {
        if(logger.isTraceEnabled())
            logger.trace("Enter setState(WTList, map)");

        WTKeyedMap phaseTemplateMaps = validateSetState(list, null, map);
        doSetState(list, phaseTemplateMaps, false);
        if(logger.isTraceEnabled())
            logger.trace("Exit setState");

        return (WTList) CollectionsHelper.manager.refresh(list);
    }

    /**
     * To repair the lifecyclehistory table when the disconnected user is
     * repaired. Change the old user reference in the history with the new
     * user reference.
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     newActorName
     * @param     oldActorName
     * @exception wt.lifecycle.LifeCycleException
     **/

    @SuppressWarnings("deprecation")
    public void updateHistory( String newActorName, String oldActorName )
            throws LifeCycleException {

        if(REPAIR_HISTORY) {
            Transaction trx = new Transaction();
            WTArrayList lcHistoryList = new WTArrayList();

            try {
                trx.start();
                SearchCondition sc = new SearchCondition(LifeCycleHistory.class,
                        wt.lifecycle.LifeCycleHistory.ACTOR_NAME,
                        SearchCondition.EQUAL,
                        oldActorName,
                        true);
                QuerySpec historyQuerySpec = new QuerySpec(LifeCycleHistory.class);
                historyQuerySpec.appendWhere(sc);

                QueryResult results = PersistenceServerHelper.manager.query(historyQuerySpec);

                Enumeration qResult = results.getEnumeration();
                while(qResult.hasMoreElements()) {
                    LifeCycleHistory lifeCycleHistory = (LifeCycleHistory) qResult.nextElement();
                    lifeCycleHistory.setActorName(newActorName);
                    lcHistoryList.add(lifeCycleHistory);
                }

                PersistenceServerHelper.manager.update(lcHistoryList);
                if(logger.isTraceEnabled())
                    logger.trace("LifeCycleHistory table updated.");
                trx.commit();
                trx = null;
            }catch (WTPropertyVetoException wpvex) {
                if(logger.isDebugEnabled()){
                    logger.debug(wpvex.getLocalizedMessage(), wpvex);
                }
                throw new LifeCycleException(wpvex);
            }catch (WTException wex) {
                if(logger.isDebugEnabled()){
                    logger.debug(wex.getLocalizedMessage(), wex);
                }
                throw new LifeCycleException(wex);
            }
            finally {
                if (trx != null)
                    trx.rollback();
            }
        } // if repair_history

    }

    /**
     * Create a history entry based on a life cycle event. This method is
     * invoked for each of:
     * <p>
     * <PRE>
     * 1. StandardLifeCycleService.ENTER_PHASE
     *    #  Default: History event recorded
     * 2. StandardLifeCycleService.SUBMIT
     *    # Default: History event recorded
     * 3. StandardLifeCycleService.PROMOTE
     *    # Default: History event recorded
     * 4. StandardLifeCycleService.VOTE
     *    # Default: Signature created but no history event recorded
     * 5. StandardLifeCycleService.DEMOTE
     *    # Default: History event recorded
     * 6. StandardLifeCycleService.DROP
     *    # Default: History event recorded
     * 7. StandardLifeCycleService.DENY
     *    # Default: History event recorded
     * 8. StandardLifeCycleService.RETEAM
     *    # Default: History event recorded
     * 9. StandardLifeCycleService.REASSIGN
     *    # Default: History event recorded
     * </PRE>
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     object  the LifeCycleManaged object that the history is associated to
     * @param     aPhase  the Phase object that the history will be associated to
     * @param     event  the name of the event that History is associated to
     * @param     comments  Notes or comments for lifecycle operation.
     * @return    LifeCycleHistory
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public LifeCycleHistory saveHistory( LifeCycleManaged object, Phase aPhase, String event, String comments )
            throws WTException, LifeCycleException {

        if (logger.isTraceEnabled()) {
            logger.trace("Enter saveHistory on"+event+"for "+getOid(object) +
                    " comments = " + comments );
            logger.trace("ENABLE_HISTORY="+ENABLE_HISTORY);
        }

        // -- do nothing if history is not turned on

        return saveHistory(object, aPhase, event, (Timestamp)null, comments);
    }

    private Persistable assignToLifeCycle (Persistable object, WTContainerRef context_ref)
            throws WTException, LifeCycleException {
        Persistable pobject = object;
        if (logger.isTraceEnabled())
            logger.trace("=> assignToLifeCycle: " + getOid(object) + ", container = " + getOid (context_ref));
        PhaseTemplate aPhaseTemplate = null;

        //Validate is done from each method that calls this method, so validate is removed here
        //Callers of the method should validate lifecycle template before calling this API

        /* 1. Get the initial phase template for the specified LifeCycleTemplate */
        aPhaseTemplate = getPhaseTemplate((LifeCycleManaged)pobject);
        /* 2. Put the object into its intial Phase & record history */

        if(isLifeHistoryAssociated((LifeCycleManaged)pobject))
        {
            Phase oldPhase=getPhase((LifeCycleManaged)pobject);
            saveHistory((LifeCycleManaged)pobject,oldPhase,EXIT_PHASE,(Timestamp)null, null);
        }

        pobject = doStateTransition ((LifeCycleManaged)pobject, aPhaseTemplate, ENTER_PHASE, context_ref, null);

        if (logger.isTraceEnabled())
            logger.trace("   assignToLifeCycle - OUT");
        return pobject;
    }

    private void assignToLifeCycle(WTList collection, WTContainerRef context, boolean persist, boolean saveExithistory, boolean pwc)
            throws WTException, LifeCycleException {

        if (logger.isTraceEnabled())
            logger.trace("===> Enter assignToLifeCycle(WTCollection): " + collection.size());

        //Validate is done from each method that calls this method, so validate is removed here
        //Callers of the method should validate lifecycle template before calling this API

        // 1.  Get make a map of the phase templates for the objects.
        WTKeyedMap phaseTemplateMap = getPhaseTemplateMaps(collection);

        if(!persist && saveExithistory && !pwc)
            saveEXITHistory(collection,EXIT_PHASE);

        //2.  Put the object into its initial Phase, create the team and record history
        doStateTransition(collection, ENTER_PHASE, phaseTemplateMap, context, persist, true, pwc);

        if (logger.isTraceEnabled())
            logger.trace("===> Exit assignToLifeCycle(WTCollection): " + collection.size());
    }

    private WTKeyedMap  getPhaseTemplateMaps(WTCollection collection)
            throws WTException {

        if (logger.isTraceEnabled())
            logger.trace("Enter getPhaseTemplateMaps(WTCollection)");

        Iterator iterator = collection.persistableIterator();
        LifeCycleManaged object;
        WTKeyedMap map = new WTKeyedHashMap(collection.size());
        while (iterator.hasNext()) {
            object = (LifeCycleManaged)iterator.next();
            //These are cached, so theoretically, I should not have to do a multi-object naviagate for the collection.
            map.put(object, getPhaseTemplate(object));
        }

        if (logger.isTraceEnabled())
            logger.trace("Exit getPhaseTemplateMaps(WTCollection)");

        return map;
    }

    private LifeCycleManaged doReassign (LifeCycleManaged object, LifeCycleTemplateReference lctRef, WTContainerRef context_ref, String comments)
            throws WTException, LifeCycleException {
        LifeCycleManaged lcmobject = object;
        if (logger.isTraceEnabled())
            logger.trace("=> doReassign: " + getOid(lcmobject) +
                    ", LCT = " + lctRef.getName() + ", container = " + getOid (context_ref));

        // rchaudhari: SPR 2199508: Verify that passed lifecycle is not working copy and not in personal cabinet.
       if (object.getLifeCycleTemplate()!=null && isWorkingCopyOrInPersonalCabinet(object.getLifeCycleTemplate())) {
            Object[] params = {object.getLifeCycleName()};
            throw new WTException(RESOURCE, lifecycleResource.CHECKED_OUT_OBJECT, params);
        }
       Transaction trx = new Transaction();

        try {
            trx.start();
            Phase aPhase = getPhase(lcmobject);

            if(this.isLifeHistoryAssociated(lcmobject))
            {
                Phase oldPhase=this.getPhase(lcmobject);
                saveHistory(lcmobject,oldPhase,EXIT_PHASE,(Timestamp)null, null);
            }

            // 1. Log history
            LifeCycleHistory aHistory = saveHistory(lcmobject, aPhase, REASSIGN, comments);

            if (!lcmobject.isLifeCycleBasic()){ // if basic, getPhase returns null. If not, throw exception later.
                // refresh object
                lcmobject = (LifeCycleManaged) PersistenceServerHelper.manager.restore((Persistable) lcmobject);

                //Prj 14216762: If called through reassignMultipleLC then get the creator of the workflows.
                if(isMultipleReassign){
                    WTList list =new WTArrayList();
                    list.add(lcmobject);
                    objectWFCreatorMap= getObjWFCreatorMap(list);
                }

                // 2a.  Terminate the associated WF phase/gate processes
                WfEngineHelper.service.terminateObjectsRunningWorkflows((Persistable) lcmobject);

                // 2b. Cleanup current phase
                cleanupCurrentPhase(lcmobject,aPhase,aHistory);

                // 2c. Refresh object since step 2a may trigger an update
                lcmobject = (LifeCycleManaged) PersistenceServerHelper.manager.restore((Persistable) lcmobject);

                if (lctRef.isBasic() && !lcmobject.isLifeCycleBasic()) {
                    lcmobject = resetNonBasicAttributes(lcmobject);
                }
            }

            // 3.  Set the template information in the cookie to be the first phase of the appropriate LC and then assign it to the lifecycle
            LifeCycleState oldStatelcs =getOldStateValue(object);

            LifeCycleState lcs = setState((LifeCycleManaged)lcmobject,lctRef,null,false);
            lcmobject.setState(lcs);

            PersistenceServerHelper.manager.update(lcmobject, false);
            lcmobject = (LifeCycleManaged)PersistenceServerHelper.manager.restore(lcmobject);

            if (lcmobject instanceof Notifiable)
                ChangeLifecycleStateSummaryEvent.getSummaryEvent().contribute((Notifiable)lcmobject, oldStatelcs, lcs);

            trx.commit();
            trx = null;
        }
        catch (PersistenceException dbError) {
            throw new LifeCycleException(dbError);
        }
        catch (WTPropertyVetoException pve) {
            throw new LifeCycleException(pve);
        }
        catch (WTException wex) {
            throw new LifeCycleException(wex);}
        finally {
            if (trx != null) {
                trx.rollback();
            }
        }
        trx = new Transaction();
        try {
            trx.start();
            lcmobject = (LifeCycleManaged) assignToLifeCycle (lcmobject, context_ref);

            // 4. Dispatch the reassign event
            dispatchVetoableEvent( LifeCycleServiceEvent.REASSIGN, lcmobject );
            trx.commit();
            trx = null;
        }
        catch (PersistenceException dbError) {
            throw new LifeCycleException(dbError);
        }
        catch (WTPropertyVetoException pve) {
            throw new LifeCycleException(pve);
        }
        catch (WTException wex) {
            throw new LifeCycleException(wex);}
        finally {
            if (trx != null) {
                trx.rollback();
            }
        }
        if (logger.isTraceEnabled())
            logger.trace("   doReassign - OUT");
        return lcmobject;
    }

    /**
     * Override the method from StandardManager to provide LifeCycleServices with
     * custom startup for event subscription. When subscribing create an anonymous inner
     * class adapter per subscription to handle each specific event being subscribed to.
     * <p>
     *
     * @exception wt.services.ManagerException
     **/

    protected void performStartupProcess()
            throws ManagerException {

        SessionContext previous = SessionContext.newContext ();
        try {
            /* 1. Register events to listen for */
            registerAsListener();

            // -- If this is an install, there is no adminsitrator user available
            try {
                SessionHelper.manager.setAdministrator();
            }
            catch (UserNotFoundException wex) {
                logger.error ("LifeCycle Service: failed to set Administrator (ok if installation)");
                return;
            }

        }
        catch (WTException wex) {
            throw new ManagerException (this, wex, "Could not initialize LifeCycle service.");
        }
        finally {
            SessionContext.setContext (previous);
        }
    }

    /**
     * This API identifies if given lifecycle template is working copy or is in personal cabinet.
     * @param lct is lifeCycle object
     * @return boolean tru, if lifecycle template is in personal cabinet or it is working copy. flase, otherwise.
     */
    private boolean isWorkingCopyOrInPersonalCabinet(final LifeCycleTemplateReference lctRef)
    {
        LifeCycleTemplate lct = null;
        boolean accessEnforced = SessionServerHelper.manager.setAccessEnforced(false);
        try {
           
            LifeCycleTemplateReference ref = LifeCycleTemplateReference.newLifeCycleTemplateReference(lctRef);
            lct = (LifeCycleTemplate) ref.getObject();
        } catch(Throwable e){
            throw new RuntimeException(e);
        }finally {
            SessionServerHelper.manager.setAccessEnforced(accessEnforced);
        }
        WorkInProgressState state =  lct.getCheckoutInfo().getState();
        if (logger.isTraceEnabled())
            logger.trace("isWorkingCopyOrInPersonalCabinet:, name="
                    + lct.getName()
                    + ", state="+state);
            if (WorkInProgressState.CHECKED_IN.equals(state)){
                Cabinet currCabinet = (Cabinet) lct
                        .getCabinetReference().getObject();

                if(currCabinet.isPersonalCabinet()) {
                    if (logger.isTraceEnabled())
                        logger.trace("  isWorkingCopyOrInPersonalCabinet: lifecycle template is in personal cabinet.");
                    return true;
                }

              }
            else if(WorkInProgressHelper.isWorkingCopy(lct))
                  return true;

        return false;
    }
    /**
     * Register as a listener for dispatched events. This method registers for:
     * <pre>
     * 1. PRE_STORE
     * 2. POST_STORE
     * 3. CLEANUP_LINK
     * 4. PRE_DELETE
     * 5. PRE_CHANGE_IDENTITY
     * </pre>
     *
     * @exception wt.services.ManagerException
     **/
    protected void registerAsListener()
            throws ManagerException {

        // -- Register PRE_STORE
        getManagerService().addEventListener(
                new ServiceEventListenerAdapter(this.getConceptualClassname()) {

                    public void notifyVetoableMultiObjectEvent(Object event) throws WTException {

                        WTCollection evtCollection = (WTCollection) ((KeyedEvent) event).getEventTarget();
                        WTCollection lcmCollection = (WTCollection) evtCollection.subCollection(LifeCycleManaged.class, true);
                        if (lcmCollection.size() > 0)
                        {
                        // SPR 2199508 : Change Object use the incorrect checkout lifecycle.
                        Iterator iterator = lcmCollection.persistableIterator();
                        while(iterator.hasNext()) {
                            Persistable target = (Persistable) iterator.next();
                            if (target instanceof LifeCycleManaged ){
                                LifeCycleManaged curItem = (LifeCycleManaged) target;
                                      if (curItem.getLifeCycleTemplate() != null && isWorkingCopyOrInPersonalCabinet(curItem.getLifeCycleTemplate())) {
                                          Object[] params = {curItem.getLifeCycleName()};
                                          throw new WTException(RESOURCE, lifecycleResource.CHECKED_OUT_OBJECT, params);
                                      }
                            }
                        }
                        processPreStoreEvent(lcmCollection);
                       }
                    }
                },
                PersistenceManagerEvent.generateEventKey( PersistenceManagerEvent.PRE_STORE ));

        // -- Register POST_STORE
        getManagerService().addEventListener(new ServiceEventListenerAdapter(this.getConceptualClassname()) {

            public void notifyVetoableMultiObjectEvent(Object event) throws WTException {
                WTCollection evtCollection = (WTCollection) ((KeyedEvent) event).getEventTarget();
                WTCollection lcmCollection = (WTCollection) evtCollection.subCollection(LifeCycleManaged.class, true);

                WTArrayList persistableLCMList = new WTArrayList(lcmCollection);

                boolean enforce = SessionServerHelper.manager.setAccessEnforced(false);
                try {
                    Iterator iterator = persistableLCMList.persistableIterator();
                    WTList lcmList = new WTArrayList();

                    while (iterator.hasNext()) {
                        Persistable target = (Persistable) iterator.next();
                        if (target instanceof LifeCycleManaged && shouldBeManaged(target, false)) {
                            lcmList.connect(target, persistableLCMList);
                        }
                    }
                    if (lcmList.size() > 0)
                        processPostStoreEvent(lcmList);
                } finally {
                    SessionServerHelper.manager.setAccessEnforced(enforce);
                }
                processPostLCTMStoreEvent(evtCollection.subCollection(LifeCycleTemplateMaster.class, true));
            }
        }, PersistenceManagerEvent.generateEventKey(PersistenceManagerEvent.POST_STORE));

        // -- Register CLEANUP_LINK
        getManagerService().addEventListener(
                new ServiceEventListenerAdapter(this.getConceptualClassname()) {

                    public void notifyVetoableMultiObjectEvent(Object event) throws WTException {
                        WTKeyedMap evtMap = (WTKeyedMap) ((KeyedEvent) event).getEventTarget();
                        int size = (int)(evtMap.values().size()/.75 + 1);
                        Map  historyLinks = new HashMap(size),
                                currentPhaseLinks = new HashMap(size),
                                phaseLinks = new HashMap(size),
                                adHocLinks = new HashMap(size),
                                criterionLinks = new HashMap(size);
                        Object link=null;
                        List list;

                        for (Iterator i = evtMap.wtKeySet().referenceIterator(); i.hasNext();) {

                            WTReference target = (WTReference) i.next();

                            if (LifeCycleManaged.class.isAssignableFrom(target.getReferencedClass())) {
                                WTCollection collection = (WTCollection)evtMap.get(target);

                                if (!CollectionsHelper.isInflated(collection)) {
                                    CollectionsHelper.inflate(collection);
                                }

                                Persistable links[] = new Persistable[collection.size()];
                                collection.toArray(links);
                                list = new ArrayList();
                                List list2 = new ArrayList();
                                for (int j = 0; j < links.length; j++) {
                                    link = links[j];
                                    if (link instanceof CurrentPhase)
                                        list.add(link);
                                    if (link instanceof ObjectHistory)
                                        list2.add(link);
                                }
                                currentPhaseLinks.put(target, list);
                                historyLinks.put(target,list2);
                            }
                        }
                        if (!historyLinks.isEmpty() || !currentPhaseLinks.isEmpty()) {
                            processCleanupLinkEvent(historyLinks, currentPhaseLinks);
                        }
                    }


                    @SuppressWarnings("deprecation")
                    public void notifyVetoableEvent( Object event ) throws WTException {

                        PersistenceManagerEvent pmEvent  = (PersistenceManagerEvent) event;
                        Persistable             target   = pmEvent.getTarget();
                        Link                 link     = pmEvent.getAssociatedLink();

                        if ( (target instanceof LifeCycleTemplate) && (link instanceof PhaseLink) )
                            processCleanupPhaseLinkEvent((PhaseLink)link);
                        else if ( (target instanceof PhaseTemplate) && (link instanceof AdHocAclLink) )
                            processCleanupAdHocAclLinkEvent((AdHocAclLink)link);
                        else if ( (target instanceof PhaseTemplate) && (link instanceof DefaultCriterion) )
                            processCleanupDefaultCriterionEvent((DefaultCriterion)link);

                    }

                },
                PersistenceManagerEvent.generateEventKey( PersistenceManagerEvent.CLEANUP_LINK));

        // -- Register PRE_DELETE
        getManagerService().addEventListener(
                new ServiceEventListenerAdapter(this.getConceptualClassname()) {

                    @SuppressWarnings("deprecation")
                    public void notifyVetoableEvent( Object event )
                            throws WTException {

                        PersistenceManagerEvent pmEvent  = (PersistenceManagerEvent) event;
                        Persistable             target   = pmEvent.getTarget();
                        // commented as part of SPR 1420347
                        //        if ((target instanceof LifeCycleTemplate) && (target.getPersistInfo().getObjectIdentifier().getId() ==
                        //                (getLatestIteration((LifeCycleTemplateMaster)((LifeCycleTemplate)target).getMaster())).getPersistInfo().getObjectIdentifier().getId())) {
                        //Should only be allowed to delete the latest iteration
                        if ((target instanceof LifeCycleTemplate) && deleteLCIteration(target)){
                            int count = 0;
                            QueryResult qr =  whereUsed((LifeCycleTemplate)target);
                            String listOfObjects = getStringOfObjectIdentities(qr);
                            if (qr.size() > 0) {
                                Object[] params = { ((LifeCycleTemplate)target).getName(), ""+qr.size(), listOfObjects };
                                throw new WTException(StandardLifeCycleService.this.RESOURCE, lifecycleResource.DELETE_LCT_IS_IN_USE, params);
                            }
                        }

                        else if (target instanceof LifeCycleTemplate) {
                            //--If any iteration of the master is in use, prohibit the delete

                            String str=(String)MethodContext.getContext().get(target.getIdentity());

                            int count = 0;
                            QueryResult qr=null;

                            if(str!=null&& str.equalsIgnoreCase("DELETELI"))
                                qr =  whereUsed((LifeCycleTemplate)target);
                            else
                                qr =  whereUsed((LifeCycleTemplateMaster)((LifeCycleTemplate)target).getMaster());


                            String listOfObjects = getStringOfObjectIdentities(qr);
                            if (qr.size() > 0) {
                                Object[] params = { ((LifeCycleTemplate)target).getName(), ""+qr.size(), listOfObjects };
                                throw new WTException(StandardLifeCycleService.this.RESOURCE, lifecycleResource.DELETE_LCT_IS_IN_USE, params);
                            }
                        }
                        else if (target instanceof WfProcessTemplateMaster) {
                            //--If the wfpt master is in use, prohibit the delete
                            int count = 0;
                            QueryResult qr =  whereUsed((WfProcessTemplateMaster)target);
                            String listOfObjects = getStringOfPhaseTemplates(qr);
                            if (qr.size() > 0) {
                                Object[] params = { IdentityFactory.getDisplayIdentity((WfProcessTemplateMaster)target), ""+qr.size(), listOfObjects };
                                throw new WTException(StandardLifeCycleService.this.RESOURCE, lifecycleResource.DELETE_WF_IS_IN_USE, params);
                            }
                        }
                        else if (target instanceof WfProcessTemplate) {
                            //--If the wfpt is in use, prohibit the delete
                            int count = 0;
                            QueryResult qr =  whereUsed((WfProcessTemplate)target);
                            String listOfObjects = getStringOfPhaseTemplates(qr);
                            if (qr.size() > 0) {
                                Object[] params = { IdentityFactory.getDisplayIdentity((WfProcessTemplate)target), ""+qr.size(), listOfObjects };
                                throw new WTException(StandardLifeCycleService.this.RESOURCE, lifecycleResource.DELETE_WF_IS_IN_USE, params);
                            }
                        }
                        else if (target instanceof AdHocAclSpec) {
                            //--If a AdHocAclSpec is deleted, remove that object from the AdHocAclSpecCache
                            PhaseTemplate pt = getPhaseTemplate((AdHocAclSpec)target);
                            if (pt != null) {
                                if (logger.isTraceEnabled())
                                    logger.trace("AdHocAclSpecCache:  Removing " +pt.getName());
                                getAdHocAclSpecCache().remove(PersistenceHelper.getObjectIdentifier(pt));
                            }
                        }
                        else if (target instanceof Criterion) {
                            //--If a Criteria object is deleted, remove that object from the CriterionCache
                            PhaseTemplate pt = getPhaseTemplate((Criterion)target);
                            if (pt != null) {
                                if (logger.isTraceEnabled())
                                    logger.trace("CriterionCache:  Removing " +pt.getName());
                                getCriterionCache().remove(PersistenceHelper.getObjectIdentifier(pt));
                            }
                        }
                        else if (target instanceof WfProcess) {
                            //--If a WfProcess object is deleted, remove any existing references to that object
                            QueryResult qr = whereUsed((WfProcess)target);
                            boolean debugEnabled = logger.isDebugEnabled();
                            while (qr.hasMoreElements()) {
                                Phase phase = (Phase)qr.nextElement();
                                if (logger.isTraceEnabled())
                                    logger.trace("Removing " +IdentityFactory.getDisplayIdentifier((WfProcess)target)+ " from " +IdentityFactory.getDisplayIdentity(getLifeCycleManaged(phase)));
                                try {
                                    if ( (phase.getWfProcessId().getObject()!=null) &&
                                            (PersistenceHelper.getObjectIdentifier(target).equals(PersistenceHelper.getObjectIdentifier(phase.getWfProcessId().getObject()))) )
                                        phase.setWfProcessId(ObjectReference.newObjectReference());
                                }
                                catch (WTPropertyVetoException wtpve) {
                                    throw new WTException(wtpve);
                                }
                                try {
                                    if ( (phase.getGate()!= null) &&
                                            (phase.getGate().getWfProcessId().getObject() != null) &&
                                            (PersistenceHelper.getObjectIdentifier(target).equals(PersistenceHelper.getObjectIdentifier(phase.getGate().getWfProcessId().getObject()))))
                                        phase.getGate().setWfProcessId(ObjectReference.newObjectReference());
                                }
                                catch (WTPropertyVetoException wtpve) {
                                    throw new WTException(wtpve);
                                }
                                PersistenceServerHelper.manager.update(phase);
                            }
                        }

                        // If either the PhaseTemplate or the LifeCycleTemplate changes, the LCT should be removed from the InitialPhaseCache
                        // If either the PhaseTemplate or the LifeCycleTemplate changes, the LCT should be removed from the PhaseTemplateCache
                        if (target instanceof PhaseTemplate)
                            target = getLifeCycleTemplate((PhaseTemplate)target);
                        if (target instanceof LifeCycleTemplate) {
                            if (logger.isTraceEnabled())
                                logger.trace("InitialPhaseCache:  Removing " +((LifeCycleTemplate)target).getName());
                            getInitialPhaseCache().remove(PersistenceHelper.getObjectIdentifier((LifeCycleTemplate)target));

                            if (logger.isTraceEnabled())
                                logger.trace("PhaseTemplateCache:  Removing " +((LifeCycleTemplate)target).getName());
                            getPhaseTemplateCache().remove(PersistenceHelper.getObjectIdentifier((LifeCycleTemplate)target));
                        }

                        // If a LifeCycleTemplate or LifeCycleTemplateMaster is deleted, remove the corresponding Master object from the LifeCycleTemplateCache
                        // If a LifeCycleTemplate or LifeCycleTemplateMaster is deleted, remove that object from the LifeCycleTemplateNameCache
                        if (target instanceof LifeCycleTemplateMaster)
                        {
                            getLifeCycleTemplateMasterCache().remove(ObjectReference.newObjectReference(target));
                            target = getLatestIteration((LifeCycleTemplateMaster) target);
                        }
                        if (target instanceof LifeCycleTemplate) {
                            if (logger.isTraceEnabled())
                                logger.trace("LifeCycleTemplateCache:  Removing " +((LifeCycleTemplate)target).getName());
                            getLifeCycleTemplateCache().remove(PersistenceHelper.getObjectIdentifier(((LifeCycleTemplate)target).getMaster()));
                            if (!target.equals(MethodContext.getContext().remove(UNDO_CHECK_OUT_KEY))) {
                                if (logger.isTraceEnabled())
                                    logger.trace("LifeCycleTemplateNameCache:  Removing " +((LifeCycleTemplate)target).getName());
                                LifeCycleNameKey key=new LifeCycleNameKey(((LifeCycleTemplate)target).getName(), ((LifeCycleTemplate)target).getContainerReference());
                                getLifeCycleTemplateNameCache().remove(key);
                            }

                        }
                    }
                },
                PersistenceManagerEvent.generateEventKey( PersistenceManagerEvent.PRE_DELETE ));

        // -- Register PRE_CHECKIN
        getManagerService().addEventListener(
                new ServiceEventListenerAdapter(this.getConceptualClassname()) {

                    public void notifyVetoableEvent( Object event )
                            throws WTException {

                        WorkInProgressServiceEvent wipEvent = (WorkInProgressServiceEvent) event;
                        Workable             target   = wipEvent.getOriginalCopy();
                        Workable             working  = wipEvent.getWorkingCopy();

                        //Theoretically this should never happen so leave it single object.
                        if ( (target instanceof LifeCycleManaged) && ( ((LifeCycleManaged)target).isLifeCycleAtGate()) ) {
                            throw new LifeCycleException(StandardLifeCycleService.this.RESOURCE, lifecycleResource.PROHIBIT_MODIFY_AT_GATE, null);
                        }

                    }
                },
                WorkInProgressServiceEvent.generateEventKey( WorkInProgressServiceEvent.PRE_CHECKIN ));

        // -- Register PRE_COMMIT_SESSION_ITERATION
        getManagerService().addEventListener(
                new ServiceEventListenerAdapter(this.getConceptualClassname()) {

                    public void notifyVetoableEvent( Object event )
                            throws WTException {

                        SessionIterationEvent sessionEvent = (SessionIterationEvent) event;
                        SessionEditedIteration    target   = (SessionEditedIteration)
                                ((SessionEditedIteration)
                                        sessionEvent.getEventTarget()).getIterationInfo().getPredecessor().getObject();


                        if ( (target instanceof LifeCycleManaged) && ( ((LifeCycleManaged)target).isLifeCycleAtGate()) ) {
                            throw new LifeCycleException(StandardLifeCycleService.this.RESOURCE, lifecycleResource.PROHIBIT_MODIFY_AT_GATE, null);
                        }
                    }
                },
                SessionIterationEvent.generateEventKey( SessionIterationEvent.PRE_COMMIT_SESSION_ITERATION ));

        // -- Register PRE_CHECKOUT
        getManagerService().addEventListener(
                new ServiceEventListenerAdapter(this.getConceptualClassname()) {

                    public void notifyVetoableMultiObjectEvent(Object event) throws WTException {
                        WTCollection evtCollection = (WTCollection) ((KeyedEvent) event).getEventTarget();
                        WTCollection lcmObjects = evtCollection.subCollection(LifeCycleManaged.class, true);
                        validateAtGate(lcmObjects);
                    }
                },
                WorkInProgressServiceEvent.generateEventKey( WorkInProgressServiceEvent.PRE_CHECKOUT ));


        // -- Register PRE_SB_CHECKOUT_EVENT
        getManagerService().addEventListener(
                new ServiceEventListenerAdapter(this.getConceptualClassname()) {

                    public void notifyVetoableMultiObjectEvent( Object event )
                            throws WTException {

                        SandboxServiceCheckoutEvent  sCoEvent = (SandboxServiceCheckoutEvent )event;
                        WTCollection collection =  sCoEvent.getOriginalCopies().subCollection( LifeCycleManaged.class, true );
                        validateAtGate(collection);
                    }
                },
                SandboxServiceCheckoutEvent.generateEventKey( SandboxServiceCheckoutEvent.class,SandboxServiceCheckoutEvent.PRE_SB_CHECKOUT_EVENT ));

        // -- Register .PRE_SB_CHECKIN_EVENT
        getManagerService().addEventListener(
                new ServiceEventListenerAdapter(this.getConceptualClassname()) {

                    public void notifyVetoableMultiObjectEvent( Object event )
                            throws WTException {
                        Transaction.getGlobalMap().put(SB_CHECKIN_KEY, Boolean.valueOf(true));
                    }
                },
                SandboxServiceCheckinEvent.generateEventKey( SandboxServiceCheckinEvent.class,SandboxServiceCheckinEvent.PRE_SB_CHECKIN_EVENT ));

        // -- Register .POST_SB_CHECKIN_EVENT
        getManagerService().addEventListener(
                new ServiceEventListenerAdapter(this.getConceptualClassname()) {
                    public void notifyVetoableMultiObjectEvent( Object event )
                            throws WTException {
                        if (Transaction.getGlobalMap().containsKey(SB_CHECKIN_KEY))
                            Transaction.getGlobalMap().remove(SB_CHECKIN_KEY);
                    }
                },
                SandboxServiceCheckinEvent.generateEventKey( SandboxServiceCheckinEvent.class,SandboxServiceCheckinEvent.POST_SB_CHECKIN_EVENT ));


        // -- Register .PRE_SB_ABANDONED_EVENT
        getManagerService().addEventListener(
                new ServiceEventListenerAdapter(this.getConceptualClassname()) {

                    public void notifyVetoableMultiObjectEvent( Object event )
                            throws WTException {
                        if (logger.isTraceEnabled())
                        {
                            logger.trace("StandardLifecycleService Listening to a PRE_SB_ABANDONED_EVENT");
                        }
                        Transaction.getGlobalMap().put(SB_CHECKIN_KEY, Boolean.valueOf(true));
                    }
                },
                SandboxServiceCheckinEvent.generateEventKey( SandboxServiceAbandonedEvent.class,SandboxServiceAbandonedEvent.PRE_SB_ABANDONED_EVENT  ));

        // -- Register .POST_SB_ABANDONED_EVENT
        getManagerService().addEventListener(
                new ServiceEventListenerAdapter(this.getConceptualClassname()) {
                    public void notifyVetoableMultiObjectEvent( Object event )
                            throws WTException {
                        if (logger.isTraceEnabled())
                        {
                            logger.trace("StandardLifecycleService Listening to a POST_SB_ABANDONED_EVENT");
                        }
                        if (Transaction.getGlobalMap().containsKey(SB_CHECKIN_KEY))
                            Transaction.getGlobalMap().remove(SB_CHECKIN_KEY);
                    }
                },
                SandboxServiceCheckinEvent.generateEventKey( SandboxServiceAbandonedEvent.class,SandboxServiceAbandonedEvent.POST_SB_ABANDONED_EVENT  ));




        // -- Register PRE_MERGE
        getManagerService().addEventListener(
                new ServiceEventListenerAdapter(this.getConceptualClassname()) {
                    public void notifyVetoableMultiObjectEvent( Object event )
                            throws WTException {
                        // Store the target of the SB checkin in the MethodContext so when
                        // the check to see if the object should be managed is done it can ignore
                        // if it is found here.
                        VersionControlServiceEvent vcEvent = (VersionControlServiceEvent) event;
                        WTCollection targets = (WTCollection) vcEvent.getTargetCollection();
                        Transaction.getGlobalMap().put(MERGE_TARGET_KEY, targets);
                    }
                },
                VersionControlServiceEvent.generateEventKey( VersionControlServiceEvent.class, VersionControlServiceEvent.PRE_MERGE ));

        // -- Register POST_MERGE
        getManagerService().addEventListener(
                new ServiceEventListenerAdapter(this.getConceptualClassname()) {

                    public void notifyVetoableMultiObjectEvent( Object event )
                            throws WTException {
                        if (Transaction.getGlobalMap().containsKey(MERGE_TARGET_KEY))
                            Transaction.getGlobalMap().remove(MERGE_TARGET_KEY);
                    }
                },
                VersionControlServiceEvent.generateEventKey( VersionControlServiceEvent.class, VersionControlServiceEvent.POST_MERGE ));

        // -- Register PRE_CREATE_SESSION_ITERATION
        getManagerService().addEventListener(
                new ServiceEventListenerAdapter(this.getConceptualClassname()) {

                    public void notifyVetoableEvent( Object event )
                            throws WTException {

                        SessionIterationEvent sessionEvent = (SessionIterationEvent) event;
                        SessionEditedIteration    target   = (SessionEditedIteration) sessionEvent.getEventTarget();


                        if ( (target instanceof LifeCycleManaged) && ( ((LifeCycleManaged)target).isLifeCycleAtGate()) ) {
                            throw new LifeCycleException(StandardLifeCycleService.this.RESOURCE, lifecycleResource.PROHIBIT_MODIFY_AT_GATE, null);
                        }
                    }
                },
                SessionIterationEvent.generateEventKey( SessionIterationEvent.PRE_CREATE_SESSION_ITERATION ));

        // -- Register POST_CHECKOUT
        getManagerService().addEventListener(
                new ServiceEventListenerAdapter(this.getConceptualClassname()) {

                    public void notifyVetoableEvent( Object event )
                            throws WTException {

                        WorkInProgressServiceEvent wipEvent = (WorkInProgressServiceEvent) event;
                        Workable             original = wipEvent.getOriginalCopy();
                        Workable             working = wipEvent.getWorkingCopy();


                        if ( original instanceof LifeCycleTemplate ) {
                            copyObjectsRelatedToLifeCycleTemplate((LifeCycleTemplate) original, (LifeCycleTemplate) working);
                        }
                        if (working instanceof LifeCycleTemplate) {
                            //--If a LifeCycleTemplate is checkedout, remove the corresponding Master object from the cache
                            if (logger.isTraceEnabled())
                                logger.trace("LifeCycleTemplateCache:  Removing " +((LifeCycleTemplate)working).getName());
                            getLifeCycleTemplateCache().remove(PersistenceHelper.getObjectIdentifier(((LifeCycleTemplate)working).getMaster()));

                            //-- If a LifeCycleTemplate is checkedout, remove that object from the LifeCycleTemplateNameCache
                            if (logger.isTraceEnabled())
                                logger.trace("LifeCycleTemplateNameCache:  Removing " +((LifeCycleTemplate)working).getName());
                            LifeCycleNameKey key=new LifeCycleNameKey(((LifeCycleTemplate)working).getName(), ((LifeCycleTemplate)working).getContainerReference());
                            getLifeCycleTemplateNameCache().remove(key);
                        }

                    }
                },
                WorkInProgressServiceEvent.generateEventKey( WorkInProgressServiceEvent.POST_CHECKOUT ));

        // -- Register PRE_MODIFY
        getManagerService().addEventListener(
                new ServiceEventListenerAdapter(this.getConceptualClassname()) {

                    public void notifyVetoableEvent( Object event )
                            throws WTException {

                        PersistenceManagerEvent pmEvent  = (PersistenceManagerEvent) event;
                        Persistable             target   = pmEvent.getTarget();

                        //1959913: Try to clear LifeCycleTemplateMaster cache
                        Persistable tempTarget = target;
                        if (tempTarget instanceof LifeCycleTemplateMaster) {
                            getLifeCycleTemplateMasterCache().remove(ObjectReference.newObjectReference(tempTarget));
                            if (logger.isTraceEnabled())
                            {
                                logger.trace("LifeCycleTemplateNameCache:  Removing All Entries ");
                            }
                            getLifeCycleTemplateNameCache().removeAllEntry();
                        }


                        if ( (target instanceof LifeCycleManaged) && ( ((LifeCycleManaged)target).isLifeCycleAtGate()) ) {
                            Object o = MethodContext.getContext().get(DISABLE_PROHIBIT_CHANGE_AT_GATE_VETO);
                            if(o == null || !o.equals("true"))
                                throw new LifeCycleException(StandardLifeCycleService.this.RESOURCE, lifecycleResource.PROHIBIT_MODIFY_AT_GATE, null);
                        }
                        else if ( (target instanceof LifeCycleManaged) && ((LifeCycleManaged) target).getLifeCycleTemplate() == null ) {

                            throw new LifeCycleException(StandardLifeCycleService.this.RESOURCE, lifecycleResource.NULL_LIFECYCCLE_TEMPLATEREF, null);

                        }
                        else if (target instanceof LifeCycleTemplate) {
                            LifeCycleTemplate lct = (LifeCycleTemplate)target;
                            QueryResult qr = whereUsed(lct);
                            if (qr.size() > 0 ) {
                                String listOfObjects = getStringOfObjectIdentities(qr);
                                Object[] params = { lct.getName(), ""+qr.size(), listOfObjects };
                                throw new LifeCycleException(StandardLifeCycleService.this.RESOURCE, lifecycleResource.PROHIBIT_MODIFY_LCT_IN_USE, params);
                            }
                        }
                        else if (target instanceof AdHocAclSpec) {
                            //-- If a AdHocAclSpec is updated, remove that object from the AdHocAclSpecCache
                            PhaseTemplate pt = getPhaseTemplate((AdHocAclSpec)target);
                            if (pt != null) {
                                if (logger.isTraceEnabled())
                                    logger.trace("AdHocAclSpecCache:  Removing " +
                                            pt.getName());
                                getAdHocAclSpecCache().remove(PersistenceHelper.getObjectIdentifier(pt));
                            }
                        }
                        else if (target instanceof Criterion) {
                            //-- If a Criteria object is updated, remove that object from the CriterionCache
                            PhaseTemplate pt = getPhaseTemplate((Criterion)target);
                            if (pt != null) {
                                if (logger.isTraceEnabled())
                                    logger.trace("CriterionCache:  Removing " +pt.getName());
                                getCriterionCache().remove(PersistenceHelper.getObjectIdentifier(pt));
                            }
                        }

                    }
                },
                PersistenceManagerEvent.generateEventKey( PersistenceManagerEvent.PRE_MODIFY ));
        /*
         * Listen for INFLATE_RESULT event on objects.  Then
         * inflate the object reference to the lifecycle in the query results.
         */
        getManagerService().addEventListener(
                new ServiceEventListenerAdapter( this.getConceptualClassname() ) {

                    public void notifyVetoableEvent( Object event )
                            throws WTException {

                        PersistenceManagerEvent pm_event = (PersistenceManagerEvent) event;
                        QueryResult results = (QueryResult) pm_event.getQueryResult();
                        Vector display_attributes = (Vector) pm_event.getDisplayAttributes();

                        if (StandardPersistenceManager.requiresInflate("wt.lifecycle",display_attributes)) {

                            while ( results.hasMoreElements() ) {
                                Object o = results.nextElement();
                                if (o instanceof LifeCycleManaged) {
                                    LifeCycleTemplateReference lct = ((LifeCycleManaged) o).getState().getLifeCycleId();
                                    if (lct != null)
                                        lct.inflate();
                                }
                            }
                            results.reset();
                        }
                    }
                },
                PersistenceManagerEvent.generateEventKey( PersistenceManagerEvent.INFLATE_RESULT ));

        // -- Register RETEAM
        getManagerService().addEventListener(
                new ServiceEventListenerAdapter(this.getConceptualClassname()) {

                    public void notifyVetoableEvent( Object event )
                            throws WTException {

                        TeamServiceEvent teamEvent  = (TeamServiceEvent) event;
                        TeamManaged            target = (TeamManaged)teamEvent.getTarget();
                        if (target instanceof LifeCycleManaged)
                            processReteam((LifeCycleManaged)target );
                    }
                },
                TeamServiceEvent.generateEventKey( TeamServiceEvent.RETEAM ));

        // -- Register POST_ROLLBACK
        getManagerService().addEventListener(
                new ServiceEventListenerAdapter(this.getConceptualClassname()) {

                    public void notifyVetoableEvent( Object event )
                            throws WTException {

                        VersionControlServiceEvent vcEvent  = (VersionControlServiceEvent) event;
                        Iterated          target  = (Iterated)vcEvent.getIteration();
                        //Commented For the SPR 2131449
                        /*if ( target instanceof LifeCycleManaged )
                    processRollback((LifeCycleManaged)target );*/
                    }
                },
                VersionControlServiceEvent.generateEventKey( VersionControlServiceEvent.POST_ROLLBACK ));

        // -- Register POST_CHANGE_DOMAIN
        getManagerService().addEventListener(
                new ServiceEventListenerAdapter(this.getConceptualClassname()) {

                    public void notifyVetoableEvent( Object event )
                            throws WTException {

                        AdministrativeDomainManagerEvent adEvent  = (AdministrativeDomainManagerEvent) event;
                        Object             target   = adEvent.getEventTarget();
                        if (target instanceof LifeCycleTemplate) {

                            validateLifeCycleTemplateObjects((LifeCycleTemplate)target);

                            // Clear the LifeCycleTemplateMaster.
                            Persistable lcMaster = ((LifeCycleTemplate) target).getMasterReference().getObject();
                            if(lcMaster != null) {
                                logger.debug("LifeCycleTemplateMasterCache:  Removing " +((LifeCycleTemplate)target).getName());
                                getLifeCycleTemplateMasterCache().remove(ObjectReference.newObjectReference(lcMaster));
                            }
                        }
                    }
                },
                AdministrativeDomainManagerEvent.generateEventKey( AdministrativeDomainManagerEvent.POST_CHANGE_DOMAIN ));

        // -- Register POST_MODIFY
        getManagerService().addEventListener(
                new ServiceEventListenerAdapter(this.getConceptualClassname()) {

                    public void notifyVetoableEvent( Object event )
                            throws WTException {

                        PersistenceManagerEvent pmEvent  = (PersistenceManagerEvent) event;
                        Persistable             target   = pmEvent.getTarget();

                        // If either the PhaseTemplate or the LifeCycleTemplate changes, the LCT should be removed from InitialPhaseTemplateCache
                        // If either the PhaseTemplate or the LifeCycleTemplate changes, the LCT should be removed from PhaseTemplateCache
                        if (target instanceof PhaseTemplate)
                            target = getLifeCycleTemplate((PhaseTemplate)target);
                        if (target instanceof LifeCycleTemplate) {
                            if (logger.isTraceEnabled())
                                logger.trace("InitialPhaseCache:  Removing " +((LifeCycleTemplate)target).getName());
                            getInitialPhaseCache().remove(PersistenceHelper.getObjectIdentifier((LifeCycleTemplate)target));
                            if (logger.isTraceEnabled())
                                logger.trace("PhaseTemplateCache:  Removing " +((LifeCycleTemplate)target).getName());
                            getPhaseTemplateCache().remove(PersistenceHelper.getObjectIdentifier((LifeCycleTemplate)target));


                        }

                        // If a LifeCycleTemplate or LifeCycleTemplateMaster is updated, remove the corresponding Master object from the LifeCycleTemplateCache
                        // If a LifeCycleTemplate or LifeCycleTemplateMaster is updated, remove that object from the LifeCycleTemplateNameCache
                        if (target instanceof LifeCycleTemplateMaster) {
                            getLifeCycleTemplateMasterCache().remove(ObjectReference.newObjectReference(target));
                            getLifeCycleTemplateMasterCache().put(ObjectReference.newObjectReference(target), target);
                            target = getLatestIteration((LifeCycleTemplateMaster) target);
                        }
                        if (target instanceof LifeCycleTemplate) {
                            if (logger.isTraceEnabled())
                                logger.trace("LifeCycleTemplateCache:  Removing " +((LifeCycleTemplate)target).getName());
                            getLifeCycleTemplateCache().remove(PersistenceHelper.getObjectIdentifier(((LifeCycleTemplate)target).getMaster()));
                            if (logger.isTraceEnabled())
                                logger.trace("LifeCycleTemplateNameCache:  Removing " +((LifeCycleTemplate)target).getName());
                            LifeCycleNameKey key=new LifeCycleNameKey(((LifeCycleTemplate)target).getName(), ((LifeCycleTemplate)target).getContainerReference());
                            getLifeCycleTemplateNameCache().remove(key);
                        }

                    }
                },
                PersistenceManagerEvent.generateEventKey( PersistenceManagerEvent.POST_MODIFY ));

        // -- Register POST_CHECKIN
        getManagerService().addEventListener(
                new ServiceEventListenerAdapter(this.getConceptualClassname()) {

                    public void notifyVetoableEvent( Object event )
                            throws WTException {

                        WorkInProgressServiceEvent wipEvent = (WorkInProgressServiceEvent) event;
                        Workable             original = wipEvent.getOriginalCopy();
                        Workable             working = wipEvent.getWorkingCopy();

                        if (working instanceof LifeCycleTemplate) {
                            // If a LifeCycleTemplate is checkedIN, remove the corresponding Master object from the cache
                            if (logger.isTraceEnabled())
                                logger.trace("LifeCycleTemplateCache:  Removing " +((LifeCycleTemplate)working).getName());
                            getLifeCycleTemplateCache().remove(PersistenceHelper.getObjectIdentifier(((LifeCycleTemplate)working).getMaster()));

                            // If a LifeCycleTemplate is checkedin, remove that object from the LifeCycleTemplateNameCache
                            if (logger.isTraceEnabled())
                                logger.trace("LifeCycleTemplateNameCache:  Removing " +((LifeCycleTemplate)working).getName());
                            LifeCycleNameKey key=new LifeCycleNameKey(((LifeCycleTemplate)working).getName(), ((LifeCycleTemplate)working).getContainerReference());
                            getLifeCycleTemplateNameCache().remove(key);


                        }
                    }
                },
                WorkInProgressServiceEvent.generateEventKey( WorkInProgressServiceEvent.POST_CHECKIN ));


        getManagerService().addEventListener(
                new ServiceEventListenerAdapter(this.getConceptualClassname()) {
                    public void notifyVetoableEvent( Object event )
                            throws WTException {
                        WorkInProgressServiceEvent wipEvent =
                                (WorkInProgressServiceEvent) event;
                        Iterated workingCopy = wipEvent.getWorkingCopy();
                        Persistable target = wipEvent.getWorkingCopy();
                        LifeCycleTemplate lct = null;

                        if (target instanceof LifeCycleTemplate) {

                            if( (target instanceof Workable) && (WorkInProgressHelper.isWorkingCopy((Workable)target ))) {
                                try {
                                    lct = getLatestIteration((LifeCycleTemplateMaster)((LifeCycleTemplate)target).getMaster());
                                } catch (LifeCycleException lce) {
                                    throw lce;
                                } catch (WTException wte) {
                                    throw wte;
                                }
                            }
                            //Put the template in the context so we can bypass this in the LC Service.
                            MethodContext.getContext().put(UNDO_CHECK_OUT_KEY, workingCopy);
                            // If a LifeCycleTemplate is checkedin, remove that object from the LifeCycleTemplateNameCache
                            if (logger.isTraceEnabled())
                                logger.trace("LifeCycleTemplateNameCache:  Removing " +((LifeCycleTemplate)workingCopy).getName());
                            LifeCycleNameKey key=new LifeCycleNameKey(((LifeCycleTemplate)workingCopy).getName(), ((LifeCycleTemplate)workingCopy).getContainerReference());
                            getLifeCycleTemplateNameCache().remove(key);
                        }
                    }
                }, WorkInProgressServiceEvent.generateEventKey(
                        WorkInProgressServiceEvent.PRE_UNDO_CHECKOUT));


        // -- Register PRE_NEW_VERSION
        // set lifecycle state to null on new version.
        getManagerService().addEventListener(
                new ServiceEventListenerAdapter(this.getConceptualClassname()) {

                    public void notifyVetoableEvent( Object event )
                            throws WTException {

                        VersionControlServiceEvent vcEvent   = (VersionControlServiceEvent) event;
                        Iterated                   iteration = vcEvent.getIteration();

                        if (iteration instanceof LifeCycleManaged ) {

                            if (logger.isTraceEnabled())
                                logger.trace("LifeCycleService PRE_NEW_VERSION Listener Setting newLifeCycleState() on " + PersistenceHelper.getObjectIdentifier(iteration));

                            try {

                                ((LifeCycleManaged)iteration).setState(LifeCycleState.newLifeCycleState());

                            }
                            catch (WTPropertyVetoException wtpve ) {
                                if(logger.isDebugEnabled()){
                                    logger.debug(wtpve.getLocalizedMessage(), wtpve);
                                }
                                throw new WTException (wtpve);
                            }
                        }
                    }
                },
                VersionControlServiceEvent.generateEventKey( VersionControlServiceEvent.PRE_NEW_VERSION ));

//        Listener for state change
        getManagerService().addEventListener(new ServiceEventListenerAdapter(this.getConceptualClassname()) {
            public void notifyVetoableMultiObjectEvent(Object event) throws WTException {
                if (logger.isTraceEnabled()) {
                    logger.trace("...caught event: " + ((KeyedEvent) event).getEventType());
                }
                LifeCycleServiceEvent lcEvent = (LifeCycleServiceEvent) event;
                WTCollection lcmObjs = (WTCollection) lcEvent.getEventTarget();
                lcmObjs = lcmObjs.subCollection(Workable.class);
                WTKeyedMap stateMap = new WTKeyedHashMap();
                WTArrayList list = new WTArrayList();
                boolean saveEnforce = SessionServerHelper.manager.setAccessEnforced(false);   
                try
                {
                    WTValuedMap workingToOriginalMap = WorkInProgressHelper.service.getWorkingToOriginalMap(lcmObjs);
                    for(Iterator it = workingToOriginalMap.wtKeySet().persistableIterator(); it.hasNext(); ) {
                        Workable working = (Workable) it.next();
                        if(working.getCheckoutInfo().getState().equals(WorkInProgressState.PRIVATE_WORKING)) {
                            list.add(working);
                            LifeCycleManaged lcm = (LifeCycleManaged)((ObjectReference)workingToOriginalMap.get(working)).getObject();
                            stateMap.put(working, lcm.getState().getState());
                        }
                    }                
                    setLifeCycleStatePWC( list, stateMap );
                }
                finally
                {
                    SessionServerHelper.manager.setAccessEnforced(saveEnforce);
                }
            }
        }, LifeCycleServiceEvent.generateEventKey(LifeCycleServiceEvent.STATE_CHANGE));

        getManagerService().addEventListener(new ServiceEventListenerAdapter(this.getConceptualClassname()) {
            public void notifyVetoableMultiObjectEvent(Object event) throws WTException {
                if (logger.isTraceEnabled()) {
                    logger.trace("...caught event: " + ((KeyedEvent) event).getEventType());
                }
                LifeCycleServiceEvent lcEvent = (LifeCycleServiceEvent) event;
                WTCollection lcmObjs = (WTCollection) lcEvent.getEventTarget();
                lcmObjs = lcmObjs.subCollection(Workable.class);
                LifeCycleTemplateReference lctRef = null;
                State state = null;
                WTKeyedMap stateMap = new WTKeyedHashMap();
                WTArrayList list = new WTArrayList();
                boolean saveEnforce = SessionServerHelper.manager.setAccessEnforced(false);   
                try
                {
                    WTValuedMap workingToOriginalMap = WorkInProgressHelper.service.getWorkingToOriginalMap(lcmObjs);
                    for(Iterator it = workingToOriginalMap.wtKeySet().persistableIterator(); it.hasNext(); ) {
                        Workable working = (Workable) it.next();
                        if(working.getCheckoutInfo().getState().equals(WorkInProgressState.PRIVATE_WORKING)) {
                            list.add(working);

                            if(state == null || lctRef == null)
                            {
                                LifeCycleManaged lcm = (LifeCycleManaged)((ObjectReference)workingToOriginalMap.get(working)).getObject();
                                lctRef = lcm.getLifeCycleTemplate();
                                state = lcm.getState().getState();
                            }
                        }
                    }        
                    if (!list.isEmpty() && lctRef != null)
                        reassignPWC(list, lctRef, ((LifeCycleTemplate)lctRef.getObject()).getContainerReference(), state);
                }
                finally
                {
                    SessionServerHelper.manager.setAccessEnforced(saveEnforce);
                }
            }
        }, LifeCycleServiceEvent.generateEventKey(LifeCycleServiceEvent.REASSIGN));

    }

    /**
     * Do pre-store processing on life cycle managed objects.
     * <p>
     * This initializes the State cookie.
     *
     * @param target  the life cycle managed object
     * @exception wt.util.WTException
     **/
    protected void processPreStoreEvent (WTCollection collection)
            throws WTException {
        WTCollection wtccollection = collection;
        if ( logger.isTraceEnabled() )
            logger.trace("===> Entering processPreStoreEvent(WTCollection): " + wtccollection.size());

        if (logger.isTraceEnabled())
            logger.trace("===> Performing state assignment for Revised objects");
        //Assign revise transition specified state for any revised objects.


        if(!isIgnoreResiveTransition())
        {
            processReviseTransition(wtccollection);
        }
        if (logger.isTraceEnabled())
            logger.trace("===> Calling shouldBeManaged on collection");
        //Check to see if they should be managed.  Those that shouldn't are removed from the collection.
        wtccollection=shouldBeManaged(wtccollection, true);


        if (logger.isTraceEnabled())
            logger.trace("===> initializing state cookies of collection");
        //Initialize the state cookie for the objects.
        initializeStateCookie(wtccollection);

        Iterator iterator = wtccollection.persistableIterator();
        //if there are any objects left in the collection, update them.
        if (iterator.hasNext()) {
            applyLifeCyclePermissions(wtccollection, false);
        }

        if (logger.isTraceEnabled())
            logger.trace("===> Exiting processPreStoreEvent(WTCollection): " + collection.size());

    }

    /**
     * Do post-store processing on life cycle managed objects.
     * <p>
     * This hooks the object to an initial phase.
     *
     * @param target  the life cycle managed object
     * @exception wt.util.WTException
     **/

    protected void processPostStoreEvent (WTList collection) throws WTException {
        if (logger.isTraceEnabled())
            logger.trace("Entering processPostStoreEvent(WTCollection): " + collection.size());

        //Note:  shouldBeManaged(LCM'd) is called from registerAsListener

        assignToLifeCycle(collection, null, false, false, false);

        if (logger.isTraceEnabled())
            logger.trace("Exiting processPostStoreEvent(WTCollection): " + collection.size());
    }

    /**
     * Do post-store processing on new life cycle templates.
     * <p>
     * This initializes default transitions.
     *
     * @param target  the life cycle managed object
     * @exception wt.util.WTException
     **/
    protected void processPostLCTMStoreEvent (final WTCollection lctms) throws WTException {
        if (lctms.isEmpty()) return;
        Boolean bypassDefaultTransitions = (Boolean)MethodContext.getContext().get(BYPASS_DEFAULT_TRANSITIONS);
        if (bypassDefaultTransitions != null && bypassDefaultTransitions.booleanValue()) return;
        Transaction.addTransactionListener(new TransactionCommitListener() {
            public void finishTransaction() throws WTException {
                final String OID = "thePersistInfo.theObjectIdentifier.id";
                final String ROLE_A = "roleAObjectRef.key.id";
                final String ROLE_B = "roleBObjectRef.key.id";

                QuerySpec qs = new QuerySpec();
                qs.setAdvancedQueryEnabled(true);
                int lctIdx = qs.appendClassList(LifeCycleTemplate.class, true);
                int ltmIdx = qs.appendClassList(LifeCycleTemplateMaster.class, false);
                qs.appendWhere(new SearchCondition(LifeCycleTemplateMaster.class, OID, LifeCycleTemplate.class, "masterReference.key.id"), new int[] { ltmIdx, lctIdx });
                qs.appendAnd();
                qs.appendWhere(new SearchCondition(LifeCycleTemplateMaster.class, OID, lctms.toIdArray()), new int[] { ltmIdx } );

                // Include only templates that have not been otherwise initialized
                // with transitions (other than NEXT).
                qs.appendAnd();
                qs.appendWhere(LifeCycleHelper.noTransition(qs.getFromClause(), lctIdx), new int[] { lctIdx });

                QueryResult qr = PersistenceHelper.manager.find(qs);
                WTCollection lcts = new WTHashSet(qr.size());
                lcts.addAll(qr);
                createDefaultTransitions(lcts, false);
            }
            public void beforeCompletion() { }
            public void notifyCommit() { }
            public void notifyRollback() { }
        });
    }

    /**
     * Do cleanup link processing on life cycle managed objects.
     * <p>
     * This removes "roleB" objects from CurrentPhase & ObjectHistory links
     *
     * @exception wt.util.WTException
     **/
    protected void processCleanupLinkEvent (Map history, Map criteria)
            throws WTException {

        if (logger.isTraceEnabled())
            logger.trace("Enter processCleanupLinkEvent: objects");
        if (history.size() > 0)
            cleanupObjectHistory(history);

        removePhaseData(criteria);

        if (logger.isTraceEnabled())
            logger.trace("Exit processCleanupLinkEvent:");
    }

    /**
     * Do cleanup link processing on Phase objects.
     * <p>
     * This removes "roleB" objects from Phase links
     *
     * @exception wt.util.WTException
     **/
    protected void processCleanupPhaseLinkEvent (PhaseLink link)
            throws WTException {

        if (logger.isTraceEnabled())
            logger.trace("Enter processCleanupPhaseLinkEvent");

        PhaseTemplate aPhaseTemplate = (PhaseTemplate)link.getRoleBObject();
        PersistenceServerHelper.manager.remove(aPhaseTemplate);

        if (logger.isTraceEnabled())
            logger.trace("Exit processCleanupPhaseLinkEvent");
    }

    /**
     * Do cleanup link processing on AdHocAclSpec objects.
     * <p>
     * This removes "roleB" objects from CurrentPhase & ObjectHistory links
     *
     * @exception wt.util.WTException
     **/
    protected void processCleanupAdHocAclLinkEvent (AdHocAclLink link)
            throws WTException {

        if (logger.isTraceEnabled())
            logger.trace("Enter processCleanupAdHocAclLinkEvent");

        AdHocAclSpec ahas = (AdHocAclSpec)link.getRoleBObject();
        PersistenceServerHelper.manager.remove(ahas);

        if (logger.isTraceEnabled())
            logger.trace("Exit processCleanupAdHocAclLinkEvent");
    }

    /**
     * Do cleanup link processing on Criterion objects.
     * <p>
     * This removes "roleB" objects from DefaultCriterion links
     *
     * @exception wt.util.WTException
     **/
    protected void processCleanupDefaultCriterionEvent (DefaultCriterion link)
            throws WTException {

        if (logger.isTraceEnabled())
            logger.trace("Enter processCleanupDefaultCriterionEvent");

        Criterion aCriterion = (Criterion)link.getRoleBObject();
        PersistenceServerHelper.manager.remove(aCriterion);

        if (logger.isTraceEnabled())
            logger.trace("Exit processCleanupDefaultCriterionEvent");
    }

    /**
     * On PRE_CHECKIN event, ensure there are no Life Cycle Managed objects using this Life Cycle Template
     *
     * @exception wt.util.WTException
     **/
    protected void validateCheckinTemplateNotInUse (LifeCycleTemplate lct)
            throws WTException {

        if (logger.isTraceEnabled())
            logger.trace("Enter validateCheckinTemplateNotInUse "+PersistenceHelper.getObjectIdentifier(lct));

        int count = 0;

        QueryResult qr =  whereUsed(lct);
        String listOfObjects = getStringOfObjectIdentities(qr);
        if (qr.size() > 0) {
            Object[] params = { lct.getName(), ""+qr.size(), listOfObjects };
            throw new WTException(RESOURCE, lifecycleResource.CHECKIN_LCT_IS_IN_USE, params);
        }

        if (logger.isTraceEnabled())
            logger.trace("Exit validateCheckinTemplateNotInUse");
    }

    /**
     * On PRE_DELETE event, ensure there are no Life Cycle Managed objects using this Life Cycle Template
     *
     * @exception wt.util.WTException
     **/
    protected void validatePreDeleteTemplateNotInUse (LifeCycleTemplate lct)
            throws WTException {

        if (logger.isTraceEnabled())
            logger.trace("Enter validatePreDeleteTemplateNotInUse "+PersistenceHelper.getObjectIdentifier(lct));

        int count = 0;

        QueryResult qr =  whereUsed(lct);
        String listOfObjects = getStringOfObjectIdentities(qr);
        if (qr.size() > 0) {
            Object[] params = { lct.getName(), ""+qr.size(), listOfObjects };
            throw new WTException(RESOURCE, lifecycleResource.DELETE_LCT_IS_IN_USE, params);
        }

        if (logger.isTraceEnabled())
            logger.trace("Exit validatePreDeleteTemplateNotInUse");
    }

    /**
     * On PostCheckout event, copy all the objects related the Life Cycle Template from the original to the working
     *
     * @exception wt.util.WTException
     **/
    protected void copyObjectsRelatedToLifeCycleTemplate(LifeCycleTemplate original, LifeCycleTemplate working)
            throws WTException {
        if (logger.isTraceEnabled())
            logger.trace("=> copyObjectsRelatedToLifeCycleTemplate: " + getOid(original) + ", template = " + working.getName ());
        //the previous Working copy PhaseTemplate that was created
        PhaseTemplate prevPt = null;
        PhaseTemplate pt = getInitialPhase(original);
        while (pt != null) {
            prevPt = copyPhaseTemplateAndRelatedObjects (pt, prevPt, working);
            //Get the next PT to process
            pt = getSuccessorPhase (pt);
        }
        // Copy all PhaseSuccessions once the phase templates themselves have been copied.
        copyTransitions(original, working);
        if (logger.isTraceEnabled())
            logger.trace("   copyObjectsRelatedToLifeCycleTemplate - OUT");
    }

    /**
     * For each PhaseTemplate found, copy that object and all related objects.
     *
     * @exception wt.util.WTException
     **/
    protected PhaseTemplate copyPhaseTemplateAndRelatedObjects (PhaseTemplate originalPt, PhaseTemplate prevWorkingPt, LifeCycleTemplate workingLct)
            throws WTException {

        if (logger.isTraceEnabled())
            logger.trace("Enter copyPhaseTemplateAndRelatedObjects " + originalPt.getName());


        //1. Create PhaseTemplate
        PhaseTemplate workingPt = (PhaseTemplate)((WTObject)originalPt).duplicate();
        workingPt = (PhaseTemplate)PersistenceHelper.manager.store(workingPt);
        workingPt = (PhaseTemplate)PersistenceServerHelper.manager.restore(workingPt);

        //2. Create Phase Link
        PhaseLink pl = PhaseLink.newPhaseLink(workingLct, workingPt);
        pl = (PhaseLink)PersistenceHelper.manager.store(pl);

        //3. Create Initial Phase Link
        if (prevWorkingPt == null) {
            try {
                workingLct.setPhaseTemplateId(ObjectReference.newObjectReference(workingPt));
                PersistenceServerHelper.manager.update(workingLct, false);
            }
            catch (WTPropertyVetoException wtpve) {
                if(logger.isDebugEnabled()){
                    logger.debug(wtpve.getLocalizedMessage(), wtpve);
                }
                throw new WTException(wtpve);
            }
        }

        //4. Create AdHocAclSpecs (and links to the phase template) if the
        //AdHocAclSpec objects retrieved from originalPt do not have null or
        //empty rolePermissions attribute values
        QueryResult results = PersistenceServerHelper.manager.expand(
                originalPt,
                AdHocAclLink.ACL_SPEC_ROLE,
                wt.lifecycle.AdHocAclLink.class,
                true);
        if (logger.isTraceEnabled())
            logger.trace("Found "+results.size()+" AdHocAclSpec Objects");

        AdHocAclSpec originalAhas = null;
        AdHocAclSpec workingAhas = null;
        while (results.hasMoreElements()) {
            originalAhas = (AdHocAclSpec)results.nextElement();
            if (originalAhas.getRoles().hasMoreElements()) {
                workingAhas = (AdHocAclSpec)((WTObject)originalAhas.duplicate());
                workingAhas = (AdHocAclSpec)PersistenceHelper.manager.store(workingAhas);

                AdHocAclLink workingAhal = AdHocAclLink.newAdHocAclLink(workingPt, workingAhas);
                workingAhal = (AdHocAclLink)PersistenceHelper.manager.store(workingAhal);
            }
        }

        //5. Create the Criterion (and links to the phase template)
        QueryResult qr = PersistenceServerHelper.manager.expand(
                originalPt,
                DefaultCriterion.CRITERIA_ROLE,
                wt.lifecycle.DefaultCriterion.class,
                true);
        if (logger.isTraceEnabled())
            logger.trace("Found "+qr.size()+" Criterion Objects");

        Criterion originalCrit = null;
        Criterion workingCrit = null;
        while (qr.hasMoreElements()) {
            originalCrit = (Criterion)qr.nextElement();
            workingCrit = (Criterion)((WTObject)originalCrit.duplicate());
            workingCrit = (Criterion)PersistenceHelper.manager.store(workingCrit);

            DefaultCriterion workingDefaultCrit = DefaultCriterion.newDefaultCriterion(workingPt, workingCrit);
            workingDefaultCrit = (DefaultCriterion)PersistenceHelper.manager.store(workingDefaultCrit);
        }

        if (logger.isTraceEnabled())
            logger.trace("Exit copyPhaseTemplateAndRelatedObjects");

        return workingPt;
    }

    /**
     * Copies all PhaseSuccession objects between the phase templates of the
     * source and destination life cycle templates.
     */
    protected void copyTransitions(LifeCycleTemplate src, LifeCycleTemplate dest) throws WTException {
        WTValuedMap phaseCopyMap = getPhaseCopyMap(src, dest);
        WTCollection srcTransitions = getTransitions(src);
        WTCollection destTransitions = new WTHashSet(srcTransitions.size());
        for (Iterator i = srcTransitions.persistableIterator(); i.hasNext(); ) {
            PhaseSuccession srcTransition = (PhaseSuccession)i.next();
            PhaseSuccession destTransition = new PhaseSuccession();
            destTransition.setRoleAObjectRef((WTReference)phaseCopyMap.getReference(srcTransition.getRoleAObjectId()));
            destTransition.setRoleBObjectRef((WTReference)phaseCopyMap.getReference(srcTransition.getRoleBObjectId()));
            try {
                destTransition.setName(srcTransition.getName());
            } catch (WTPropertyVetoException wtpve) {
                if(logger.isDebugEnabled()){
                    logger.debug(wtpve.getLocalizedMessage(), wtpve);
                }
                throw new WTException(wtpve);
            }
            destTransitions.add(destTransition);
        }
        PersistenceServerHelper.manager.insert(destTransitions);
    }

    /**
     * Returns a non-inflated map of the phase templates of the source life
     * cycle template to their counterparts (phase templates having matching
     * states) of the destination life cycle template.
     */
    private WTValuedMap getPhaseCopyMap(LifeCycleTemplate src, LifeCycleTemplate dest) throws WTException {
        final String OID = "thePersistInfo.theObjectIdentifier.id";
        final String ROLE_A = "roleAObjectRef.key.id";
        final String ROLE_B = "roleBObjectRef.key.id";

        QuerySpec qs = new QuerySpec();
        int sltIdx = qs.appendClassList(LifeCycleTemplate.class, false);
        int splIdx = qs.appendClassList(PhaseLink.class, false);
        int sptIdx = qs.appendClassList(PhaseTemplate.class, false);
        int dptIdx = qs.appendClassList(PhaseTemplate.class, false);
        int dplIdx = qs.appendClassList(PhaseLink.class, false);
        int dltIdx = qs.appendClassList(LifeCycleTemplate.class, false);

        qs.appendSelect(new ClassAttribute(PhaseTemplate.class, OID), new int[] { sptIdx }, false);
        qs.appendSelect(new ClassAttribute(PhaseTemplate.class, OID), new int[] { dptIdx }, false);

        qs.appendWhere(new SearchCondition(LifeCycleTemplate.class, OID, PhaseLink.class, ROLE_A), new int[] { sltIdx, splIdx });
        qs.appendAnd();
        qs.appendWhere(new SearchCondition(PhaseLink.class, ROLE_B, PhaseTemplate.class, OID), new int[] { splIdx, sptIdx });
        qs.appendAnd();
        qs.appendWhere(new SearchCondition(PhaseTemplate.class, PhaseTemplate.PHASE_STATE, PhaseTemplate.class, PhaseTemplate.PHASE_STATE), new int[] { sptIdx, dptIdx });
        qs.appendAnd();
        qs.appendWhere(new SearchCondition(PhaseTemplate.class, OID, PhaseLink.class, ROLE_B), new int[] { dptIdx, dplIdx });
        qs.appendAnd();
        qs.appendWhere(new SearchCondition(PhaseLink.class, ROLE_A, LifeCycleTemplate.class, OID), new int[] { dplIdx, dltIdx });
        qs.appendAnd();
        qs.appendWhere(new SearchCondition(LifeCycleTemplate.class, OID, SearchCondition.EQUAL, src.getPersistInfo().getObjectIdentifier().getId()), new int[] { sltIdx });
        qs.appendAnd();
        qs.appendWhere(new SearchCondition(LifeCycleTemplate.class, OID, SearchCondition.EQUAL, dest.getPersistInfo().getObjectIdentifier().getId()), new int[] { dltIdx });

        QueryResult qr = PersistenceServerHelper.manager.query(qs);
        WTValuedHashMap result = new WTValuedHashMap(qr.size());
        while (qr.hasMoreElements()) {
            Object[] pair = (Object[])qr.nextElement();
            result.put(new ObjectIdentifier(PhaseTemplate.class, ((BigDecimal)pair[0]).longValue()), new ObjectIdentifier(PhaseTemplate.class, ((BigDecimal)pair[1]).longValue()));
        }
        return result;
    }

    /**
     * Returns an inflated collection of the phase succession links associated
     * with the phase templates of the argument life cycle template.
     */
    private WTCollection getTransitions(LifeCycleTemplate lct) throws WTException {
        final String OID = "thePersistInfo.theObjectIdentifier.id";
        final String ROLE_A = "roleAObjectRef.key.id";
        final String ROLE_B = "roleBObjectRef.key.id";

        QuerySpec sqs = new QuerySpec();
        int lctIdx = sqs.appendClassList(LifeCycleTemplate.class, false);
        int phlIdx = sqs.appendClassList(PhaseLink.class, false);
        sqs.appendSelect(new ClassAttribute(PhaseLink.class, ROLE_B), new int[] { phlIdx }, false);
        sqs.appendWhere(new SearchCondition(LifeCycleTemplate.class, OID, PhaseLink.class, ROLE_A), new int[] { lctIdx, phlIdx });
        sqs.appendAnd();
        sqs.appendWhere(new SearchCondition(LifeCycleTemplate.class, OID, SearchCondition.EQUAL, lct.getPersistInfo().getObjectIdentifier().getId()), new int[] { lctIdx });
        SubSelectExpression sse = new SubSelectExpression(sqs);

        QuerySpec qs = new QuerySpec(PhaseSuccession.class);
        qs.setAdvancedQueryEnabled(true);
        qs.appendWhere(new SearchCondition(new ClassAttribute(PhaseSuccession.class, ROLE_A), SearchCondition.IN, sse), new int[] { 0 });
        qs.appendOr();
        qs.appendWhere(new SearchCondition(new ClassAttribute(PhaseSuccession.class, ROLE_B), SearchCondition.IN, sse), new int[] { 0 });

        QueryResult qr = PersistenceServerHelper.manager.query(qs);
        WTHashSet transitions = new WTHashSet(qr.size());
        transitions.addAll(qr);
        return transitions;
    }

    /**
     * On RETEAM, complete the appropriate life cycle processing
     * <p>
     *
     * @exception wt.util.WTException
     **/
    protected void processReteam(LifeCycleManaged object)
            throws WTException {

        if (logger.isTraceEnabled())
            logger.trace("Enter processTeam:"+getOid(object));

        Phase aPhase = getCurrentPhase(object);

        // 1. Log History
        saveHistory(object,aPhase,RETEAM);

        // 2. Rebuild the AdHocAcl
        buildAdHocAcl(object, aPhase);

        // 3. Add LC roles to the team
        PhaseTemplate aPhaseTemplate = getPhaseTemplate(object);
        TeamHelper.service.addLCRoles(aPhaseTemplate, object);

        // 4. Add the workflow roles
        WfEngineServerHelper.service.doReteamProcess(object.getTeamId());

        if (logger.isTraceEnabled())
            logger.trace("Exit processReteam");
    }


    /**
     * On POST_ROLLBACK, complete the appropriate life cycle processing
     * <p>
     *
     * @exception wt.util.WTException
     **/
    protected void processRollback(LifeCycleManaged object)
            throws WTException {

        if (logger.isTraceEnabled())
            logger.trace("Enter processRollback:"+getOid(object) + wt.vc.VersionControlHelper.getIterationIdentifier((wt.vc.Iterated)object).getValue());


        Transaction trx = new Transaction();
        try {
            trx.start();

            //1.  Find all the links to the history objects.
            QueryResult results = PersistenceServerHelper.manager.expand(
                    (Persistable)object,
                    ObjectHistory.HISTORY_ROLE,
                    wt.lifecycle.ObjectHistory.class,
                    false);
            if (logger.isTraceEnabled())
                logger.trace("Found "+results.size()+" ObjectHistory link Objects");


            //2.  Delete the links to the existing history object (they will delete the history objects)
            while (results.hasMoreElements()) {
                ObjectHistory oh = (ObjectHistory)results.nextElement();
                PersistenceServerHelper.manager.remove(oh);
            }

            //3.  SetState to the state of the current iteration.
            //Objects stored in personal cabinetes cannot do set state.  Fix needed for SPR 905394

            //This call is commented for SPR 1952684

            /*if (!isPersonalCabinet(object)) {
             setState(object, object.getLifeCycleState());
         }*/

            trx.commit();
            trx = null;
        }
        finally {
            if (trx != null)
                trx.rollback();
        }


        if (logger.isTraceEnabled())
            logger.trace("Exit processRollback");
    }
    /**
     * Checks if the Objects has Personal Cabinet
     * @param object
     * @return True if objects has Personal Cabinet
     */
    private boolean isPersonalCabinet(LifeCycleManaged object) {
        if (object instanceof CabinetBased) {
            if(((Cabinet)((CabinetBased)object).getCabinetReference().getObject()).isPersonalCabinet()) {
                return true;
            }
        }
        return false;
    }
    /**
     * On Revise, clear out the cookie information
     * <p>
     *
     * @exception wt.util.WTException
     **/
    protected void processPreRevise(LifeCycleManaged object)
            throws WTException {

        if (logger.isTraceEnabled())
            logger.trace("Enter processPreRevise:"+getOid(object));

        try {
            setState(object,null,false);
            setTemplate(object,null);
        }
        catch (WTPropertyVetoException wte) {
            if(logger.isDebugEnabled()){
                logger.debug(wte.getLocalizedMessage(), wte);
            }
            throw new WTException(wte);
        }

        if (logger.isTraceEnabled())
            logger.trace("Exit processPreRevise");
    }

    /*****************************
     * Runtime Object Management *
     *****************************/

    private void cloneCriteria(Phase aPhase, PhaseTemplate aPhaseTemplate)
            throws WTException {

        // -- Copy template defined criteria and create a set of links from the phase

        if (logger.isTraceEnabled())
            logger.trace("Enter cloneCriteria");

        // -- If a basic lcm object, nothing to do
        if (aPhase == null) //basic
            return;
        // -- If a final phase, nothing to do
        if (LifeCycleHelper.isFinalPhase(aPhaseTemplate))
            return;

        /* 1. Get the criteria defined by the template */
        Vector cri = getPhaseCriteria(aPhaseTemplate);
        Enumeration e = cri.elements();

        /* 2. Create criteria duplicates and link them to the phase.
         *    This is necessary because the criteria object holds
         *    a satisfied flag which is updated per phase and potentially
         *    transferred to history.
         */
        Criterion srcCri = null;
        Criterion targetCri = null;
        Transaction trx = new Transaction();
        try {
            trx.start();
            while (e.hasMoreElements()) {
                srcCri = (Criterion)e.nextElement();
                targetCri = (Criterion)srcCri.duplicate();
                PersistenceServerHelper.manager.insert(targetCri);
                CriterionLink cl = CriterionLink.newCriterionLink(aPhase,targetCri);
                PersistenceServerHelper.manager.insert(cl);
            }
            trx.commit();
            trx = null;
        }
        catch (PersistenceException dbError) {
            if(logger.isDebugEnabled()){
                logger.debug(dbError.getLocalizedMessage(), dbError);
            }
            throw new WTException(dbError);
        }
        finally {
            if (trx !=null)
                trx.rollback();
        }
        if (logger.isTraceEnabled())
            logger.trace("Exit cloneCriteria");

    }

    private void cloneCriteria(WTCollection collection, WTKeyedMap phaseMap, WTKeyedMap phaseTemplateMap)
            throws WTException {

        // -- Copy template defined criteria and create a set of links from the phase

        if (logger.isTraceEnabled())
            logger.trace("Enter cloneCriteria(WTKeyedMap, WTKeyedMap): " + collection.size());

        WTCollection criteriaCollection = new WTArrayList();
        WTCollection criteriaLinks = new WTArrayList();
        Criterion srcCri = null;
        Criterion targetCri = null;

        WTSet set = phaseMap.wtKeySet();
        LifeCycleManaged object;
        PhaseTemplate aPhaseTemplate;
        Phase aPhase;
        Enumeration e;
        CriterionLink cl;
        Iterator iterator = set.persistableIterator();
        while (iterator.hasNext()) {
            Object object2 = iterator.next();
            object = (LifeCycleManaged)object2;

            //object = (LifeCycleManaged)iterator.next();
            aPhaseTemplate = (PhaseTemplate) phaseTemplateMap.get(object);
            aPhase = null;
            if (phaseMap.get(object) != null)
                aPhase = (Phase) phaseMap.get(object);

            // -- If a final phase, nothing to do
            if (aPhase != null && !LifeCycleHelper.isFinalPhase(aPhaseTemplate)) {
                /* 1. Get the criteria defined by the template */
                Vector cri = getPhaseCriteria(aPhaseTemplate);
                e = cri.elements();
                /* 2. Create criteria duplicates and link them to the phase.
                 *    This is necessary because the criteria object holds
                 *    a satisfied flag which is updated per phase and potentially
                 *    transferred to history.
                 */


                while (e.hasMoreElements()) {
                    srcCri = (Criterion)e.nextElement();
                    targetCri = (Criterion)srcCri.duplicate();
                    criteriaCollection.add(targetCri);
                    cl = CriterionLink.newCriterionLink(aPhase,targetCri);
                    criteriaLinks.add(cl);
                }
            }

        }

        Transaction trx = new Transaction();
        try {
            trx.start();
            if (criteriaCollection.size() > 0)
                PersistenceHelper.manager.store(criteriaCollection);
            if (criteriaLinks.size() > 0)
                PersistenceHelper.manager.store(criteriaLinks);
            trx.commit();
            trx = null;
        }
        catch (PersistenceException dbError) {
            if(logger.isDebugEnabled()){
                logger.debug(dbError.getLocalizedMessage(), dbError);
            }
            throw new WTException(dbError);
        }
        finally {
            if (trx !=null)
                trx.rollback();
        }

        if (logger.isTraceEnabled())
            logger.trace("Exit cloneCriteria(WTCollection): " + collection.size());

    }

    private void initializeStateCookie(WTCollection collection)
            throws LifeCycleException, WTException {

        // -- Initialize the state cookies
        if (logger.isTraceEnabled())
            logger.trace("===> Enter initializeStateCookie(WTCollection)");

        Iterator iterator = collection.persistableIterator();
        // Initialize stat cookie of each individually.  This should not be querying db,
        // so we should not have to try to improve this by creating a LifeCycleState that
        // can be reused whereever possible.
        while (iterator.hasNext()) {
            LifeCycleManaged object = (LifeCycleManaged) iterator.next();
            object = initializeStateCookie(object);
        }

        if (logger.isTraceEnabled())
            logger.trace("===> Exit initializeStateCookie(WTCollection)");

    }

    private LifeCycleManaged initializeStateCookie(LifeCycleManaged object)
            throws LifeCycleException {

        // -- Initialize the state cookie

        if (logger.isTraceEnabled())
            logger.trace("Enter initializeStateCookie:"+getOid(object));

        try {

            // -- If the LifeCycle Template is not already set, find the default.
            if (object.getLifeCycleTemplate() == null) {
                /*
            SPR#1337703: As per this spr, we are now throwing exception instead of assigning "Default" LC
            based on property
                 */
                if(USE_DEFAULT_LC)
                {
                    LifeCycleTemplate aTemplate = findDefaultTemplate(object);
                    setTemplate(object,aTemplate);
                }
                else
                {
                    throw (new LifeCycleException( RESOURCE, lifecycleResource.NO_VALID_LIFECYCLE, null ));
                }
            }
            else {
                MethodContext mc = MethodContext.getContext();
                boolean useLatest =  ! (object.equals(mc.get(ArchiveHelperConstants.IXB_RESTORE_CONTEXT_KEY)));
                LifeCycleTemplate template=validateLifeCycleTemplate(object.getLifeCycleTemplate(), useLatest,object);
                if (template != null) {
                    object.getState().setLifeCycleId(LifeCycleTemplateReference.newLifeCycleTemplateReference(template));
                    if (logger.isTraceEnabled())
                        logger.trace("Applied latest iteration of lifecycle template");
                }
            }

            // -- Initialize the the life cycle state
            if (!(isCookieInitialized(object))) {
                //Get the read only object -- we are not updating so this should be ok.
                PhaseTemplate pt = getPhaseTemplate(object);
                setState(object,getAssignedState(pt),false);
            }
        }
        catch (WTPropertyVetoException veto) {
            if(logger.isDebugEnabled()){
                logger.debug(veto.getLocalizedMessage(), veto);
            }
            throw new LifeCycleException(veto);
        }
        catch (LifeCycleException lex) {
            if(logger.isDebugEnabled()){
                logger.debug(lex.getLocalizedMessage(), lex);
            }
            throw lex;
        }
        catch (WTException wex) {
            if(logger.isDebugEnabled()){
                logger.debug(wex.getLocalizedMessage(), wex);
            }
            throw new LifeCycleException(wex);
        }

        if (logger.isTraceEnabled())
            logger.trace("Exit initializeStateCookie" + ((LifeCycleTemplate)object.getLifeCycleTemplate().getObject()).getName() + object.getLifeCycleState().toString());

        return object;
    }

    private Phase createPhaseInstance(LifeCycleManaged object,
            PhaseTemplate aPhaseTemplate)
                    throws WTException {

        if (logger.isTraceEnabled())
            logger.trace("Enter createPhaseInstance");
        if ( logger.isDebugEnabled() )
            logger.debug("=> createPhaseInstance: aPhaseTemplate::" + aPhaseTemplate.getName());

        // -- Create a Phase and all its components.
        // --
        // -- This method creates a Phase instance and all of its
        // -- component parts.  It then attaches it to the LifeCycleManaged
        // -- object via the CurrentPhase relationship.  It is the responsibility
        // -- of the subcomponent builder methods to persist the subcomponent in
        // -- a self-contained transaction.

        Phase aPhase = null;
        Transaction trx = new Transaction();
        try {
            trx.start();

            // 1.  Create and populate the phase object
            if (logger.isTraceEnabled())
                logger.trace(" The LifeCycleManagedPhase map contains " + lifeCycleManagedPhaseMap.toString());

            if((object instanceof Iterated )&&(VersionControlHelper.isLatestIteration((Iterated)object)))
            {
                aPhase = (Phase)lifeCycleManagedPhaseMap.get(object);
            }

            if ( logger.isDebugEnabled() )
            {
                if(aPhase!=null)
                    logger.debug("=> createPhaseInstance: aPhase::" + aPhase.getName());
                else
                    logger.debug("=> createPhaseInstance: aPhase is null");
            }
            if (aPhase == null && object.isLifeCycleBasic()) {
                if (logger.isTraceEnabled() ) {
                    logger.trace("createPhaseInstance: object is basic lifecycle managed. Do nothing");
                }
            }
            else if (aPhase == null) {
                if (logger.isTraceEnabled())
                    logger.trace("Phase object not found in map - creating it");
                aPhase = createPhase(object, aPhaseTemplate);
                if(aPhase!=null)
                    logger.debug("=> aPhase::" + aPhase.getName());
            }
            else {
                if (logger.isTraceEnabled())
                    logger.trace("Phase object found in map.  Using and removing it");

                if(!((aPhase.getName()).equalsIgnoreCase(aPhaseTemplate.getName())))
                {
                    aPhase = createPhase(object, aPhaseTemplate);
                }
                lifeCycleManagedPhaseMap.remove(object);
            }

            trx.commit();
            trx = null;
        }
        catch (WTPropertyVetoException veto) {
            if(logger.isDebugEnabled()){
                logger.debug(veto.getLocalizedMessage(), veto);
            }
            throw new LifeCycleException(veto);
        }
        catch (PersistenceException dbError) {
            if(logger.isDebugEnabled()){
                logger.debug(dbError.getLocalizedMessage(), dbError);
            }
            throw new LifeCycleException(dbError);
        }
        catch (WTException wex) {
            if(logger.isDebugEnabled()){
                logger.debug(wex.getLocalizedMessage(), wex);
            }
            throw new LifeCycleException(wex);
        }
        finally {
            if (trx != null)
                trx.rollback();
        }
        if (logger.isTraceEnabled())
            logger.trace(">>Out StandardLifeCycleService...createPhaseInstance(LifeCycleManaged,PhaseTemplate ) method");

        return aPhase;
    }



    /*******************
     * Setters/Getters *
     *******************/


    private Vector getPhaseCriteria(Phase aPhase)
            throws WTException {

        // -- Answer a vector of criterion for this phase

        Vector criVector = new Vector();

        // -- Navigate to from the phase to criteria
        QueryResult results = PersistenceServerHelper.manager.expand(
                aPhase,
                CriterionLink.CRITERIA_ROLE,
                CriterionLink.class,
                true);
        if (logger.isTraceEnabled())
            logger.trace("Phase criteria FOUND " + results.size() + " Criterion OBJECTS");

        return (buildCriteriaVector(results));
    }


    private Vector getPhaseCriteria(PhaseTemplate aPhaseTemplate)
            throws WTException {

        // -- Answer a vector of Criterion for this phase template

        Vector criVector = new Vector();
        QueryResult results = null;

        synchronized( getCriterionCache() ){
            //-- Check the cache first
            results = (QueryResult)getCriterionCache().get(PersistenceHelper.getObjectIdentifier(aPhaseTemplate));
            if (results != null) {
                results.reset();
                if (logger.isTraceEnabled())
                    logger.trace ("CriterionCache:  " +aPhaseTemplate.getName()+ " found in cache.");
            }
            else {
                if (logger.isTraceEnabled())
                    logger.trace ("CriterionCache: " +aPhaseTemplate.getName()+ " not found in cache, checking db....");
                //--If not found in the cache, go get it from the database
                results = PersistenceServerHelper.manager.expand(
                        aPhaseTemplate,
                        DefaultCriterion.CRITERIA_ROLE,
                        DefaultCriterion.class,
                        true);
                getCriterionCache().put(PersistenceHelper.getObjectIdentifier(aPhaseTemplate), results);
                if (logger.isTraceEnabled()) {
                    logger.trace("CriterionCache:  Added " +aPhaseTemplate.getName() );
                }
            }

            if (logger.isTraceEnabled())
                logger.trace("Template criteria FOUND " + results.size() + " Criterion OBJECTS");

            return (buildCriteriaVector(results));
        }
    }

    private Vector buildCriteriaVector(QueryResult results)
            throws WTException {

        // Vector criVector = (Vector)results.getObjectVector();
        Vector criVector = new Vector();
        Criterion cri = null;
        while (results.hasMoreElements()){
            cri = (Criterion)(results.nextElement());
            criVector.addElement(cri);
        }

        return criVector;
    }

    private void checkResolveContainerTeamRoles( String event ){
        boolean isAugment = false;
        boolean valid = false;

        isAugment =  isAugmentEvent(event);
        if(isAugment){
            MethodContext.getContext().put("AUGMENT_LC_ROLES_EVENT", "AUGMENT_LC_ROLES_EVENT");
            return;
        }

        valid = isEventValid(event);
        if(valid){
            MethodContext.getContext().put("LC_STATE_TRANSITION", "LC_STATE_TRANSITION");
        }

        if( !ALLOW_RERESOLUTION_LC_ROLES && valid ){
            MethodContext.getContext().put("DO_NOT_RESOLVE_CONT_ROLES", "DO_NOT_RESOLVE_CONT_ROLES");
        }
    }

    private boolean isEventValid( String event ){
        boolean flag = false;
        if( (event.equals(PROMOTE))       ||
                (event.equals(SET_STATE))     ||
                (event.equals(DEMOTE))
                )
        {
            flag = true;
        }

        return flag;
    }

    private boolean isAugmentEvent( String event ){
        if( event.equals(AUGMENT) )
            return true;
        else
            return false;
    }

    private LifeCycleHistory saveHistory( LifeCycleManaged object, Phase aPhase, String event, Timestamp timestamp, String comments )
            throws WTException, LifeCycleException {
        String strcomments = comments;
        if (logger.isTraceEnabled()) {
            logger.trace("Enter saveHistory on"+event+"for "+getOid(object));
            logger.trace("ENABLE_HISTORY="+ENABLE_HISTORY);
            logger.trace("Timestamp: " + timestamp);
        }

        //caputre decision to resole container team roles on the basis of event into methodcontext.
        checkResolveContainerTeamRoles(event);

        // -- do nothing if history is not turned on

        LifeCycleHistory h = null;

        if (  ENABLE_HISTORY                &&
                ( (event.equals(ENTER_PHASE))   ||
                        (event.equals(SUBMIT))        ||
                        (event.equals(PROMOTE))       ||
                        (event.equals(RETEAM))        ||
                        (event.equals(REASSIGN))      ||
                        (event.equals(DENY))          ||
                        (event.equals(DROP))          ||
                        (event.equals(DEMOTE))        ||
                        (event.equals(SET_STATE))     ||
                        (event.equals(AUGMENT))       ||
                        (event.equals(EXIT_PHASE))
                        )
                )
        {

            if(isSkipLifecycleHistoryCreation())
            {
                return h;
            }
            MethodContext m_context = MethodContext.getContext();

            if(strcomments!=null){
                if(event.equals(REASSIGN))
                    m_context.put("comment", strcomments);
            }
            if(event.equals(ENTER_PHASE))
                strcomments=(String)m_context.get("comment");

            if(event.equals(EXIT_PHASE))
                strcomments=(String)m_context.get("comment");

            h = buildHistory(object,aPhase,event, strcomments);
            Transaction trx = new Transaction();
            try {
                trx.start();

                // -- Save thei history record
                if (timestamp == null)
                    PersistenceServerHelper.manager.insert(h);
                else
                    PersistenceServerHelper.manager.insert(h, timestamp, timestamp);

                // --Link the object to its history
                ObjectHistory oh = ObjectHistory.newObjectHistory(object,h);
                if (timestamp == null)
                    PersistenceServerHelper.manager.insert(oh);
                else
                    PersistenceServerHelper.manager.insert(oh, timestamp, timestamp);

                trx.commit();
                trx = null;
            }
            catch (WTException wex) {
                if(logger.isDebugEnabled()){
                    logger.debug(wex.getLocalizedMessage(), wex);
                }
                throw new LifeCycleException(wex);
            }
            finally {
                if (trx != null)
                    trx.rollback();
            }
        }

        if (logger.isTraceEnabled())
            logger.trace("Exit saveHistory");

        return h;
    }

    private LifeCycleManaged doSetState( LifeCycleManaged object, PhaseTemplate aPhaseTemplate, Timestamp timestamp )
            throws WTException, LifeCycleException {
        LifeCycleManaged lcmobject = object;
        if (logger.isTraceEnabled())
            logger.trace("=> doSetState:" + getOid(lcmobject) + ", phase template = " + aPhaseTemplate);
        if (aPhaseTemplate == null) {
            return lcmobject;
        }
        Transaction trx = new Transaction();
        // This key is added to map in lifecycle attr handler.
        Object listenerFromMap = Transaction.getSharedMap().get(TRX_LISTENER_KEY);
        try {
            trx.start();
            PersistenceServerHelper.manager.lock (lcmobject, true);
            lcmobject = (LifeCycleManaged)PersistenceServerHelper.manager.restore(lcmobject);
            Phase aPhase = getPhase (lcmobject);
            setPhase (lcmobject, aPhase);
            // 1. Log the history event
            if(this.isLifeHistoryAssociated(lcmobject))
            {
                Phase oldPhase=this.getPhase(lcmobject);
                saveHistory(lcmobject,oldPhase,EXIT_PHASE,timestamp, null);
            }
            LifeCycleHistory h = saveHistory(lcmobject,aPhase,SET_STATE, timestamp, null);
            // 2 Move signatures to history & delete the current phase
            cleanupCurrentPhase(lcmobject,aPhase,h);
            // 3. do the state transition
            lcmobject = doStateTransition ((LifeCycleManaged) lcmobject, aPhaseTemplate, ENTER_PHASE, null, timestamp);
            if(SKIP_EMIT_EVENT_WHILE_PACKAGE_IMPORT && listenerFromMap != null) {
                logger.debug("Do not emit set state and state change events during high fidelity package import and proprty is set to true.");
            } else {
                // Dispatch the set state event. Do not raise such events in case of package import.
                //4.  Dispatch the setState event
                dispatchVetoableEvent( LifeCycleServiceEvent.SET_STATE, lcmobject );
                //5.  Dispatch the state_change event (Emit a second event for the Synchronization robot to detect.)
                dispatchVetoableEvent( LifeCycleServiceEvent.STATE_CHANGE, lcmobject );
            }
            //6.  Contribute to Summary Event
            /* This is done in the doStateTransition */

            trx.commit();
            trx = null;
        }
        catch (WTPropertyVetoException wtpve) {
            if(logger.isDebugEnabled()){
                logger.debug(wtpve.getLocalizedMessage(), wtpve);
            }
            throw new LifeCycleException(wtpve);
        }
        catch (PersistenceException dbError) {
            if(logger.isDebugEnabled()){
                logger.debug(dbError.getLocalizedMessage(), dbError);
            }
            throw new LifeCycleException(dbError);
        }
        catch (WTException wex) {
            if(logger.isDebugEnabled()){
                logger.debug(wex.getLocalizedMessage(), wex);
            }
            throw new LifeCycleException(wex);
        }
        finally {
            if (trx != null) {
                trx.rollback();
            }
        }
        if ( logger.isTraceEnabled())
            logger.trace("   doSetState - OUT: " + getOid(lcmobject));
        return lcmobject;
    }

    private LifeCycleManaged setState( LifeCycleManaged object, State aState, Timestamp timestamp )
            throws WTException, LifeCycleException {
        LifeCycleManaged lcmobject = object;
        if (logger.isTraceEnabled())
            logger.trace("Enter setState:" + getOid(lcmobject) + " timestamp: " + timestamp);

        PhaseTemplate aPhaseTemplate = null;

        aPhaseTemplate = validateSetState(lcmobject, aState);
        lcmobject=doSetState(lcmobject, aPhaseTemplate, timestamp);

        if (logger.isTraceEnabled())
            logger.trace("Exit setState");

        return lcmobject;

    }

    private LifeCycleState setState(LifeCycleManaged object,
            LifeCycleTemplateReference lctRef,
            State aState,
            boolean atGate )
                    throws WTException,WTPropertyVetoException {
        State staState = aState;
        LifeCycleState lcState=null;

        // -- Set the LifeCycleState cookie

        // -- Replace existing life cycle state or instantiate new
        if ((lcState = object.getState()) == null) {
            lcState = LifeCycleState.newLifeCycleState();
        }

        lcState.setLifeCycleId(lctRef);
        if (staState == null) {
            PhaseTemplate pt = getInitialPhase((LifeCycleTemplate)lctRef.getObject());
            staState = getAssignedState(pt);
        }
        lcState.setState(staState);
        lcState.setAtGate(atGate);

        return lcState;
    }

    private LifeCycleState getOldStateValue(LifeCycleManaged object)throws WTException,WTPropertyVetoException
    {
        LifeCycleTemplateReference oldTemplateRef=object.getLifeCycleTemplate();
        LifeCycleTemplate oldTemplate=(LifeCycleTemplate)oldTemplateRef.getObject();
        LifeCycleState oldState=LifeCycleState.newLifeCycleState();;

        ObjectReference ref = oldTemplate.getPhaseTemplateId();
        PhaseTemplate phase = (PhaseTemplate)(ref.getObject());

        oldState.setLifeCycleId(oldTemplateRef);
        oldState.setState(phase.getPhaseState());
        oldState.setAtGate(false);

        return oldState;
    }
    private void setStates(WTList list,
            Map phaseTemplateMap,
            boolean atGate, boolean isLCSet, boolean pwc )
                    throws WTException,WTPropertyVetoException {

        if (logger.isTraceEnabled())
            logger.trace("Enterine setStates(WTList, Map, boolean)");

        LifeCycleState lcState=null;

        // --if the state is to be preserved, get the phase template for the state.
        PhaseTemplate pt=null;

        //Now iterate through the list and set the state on each object.
        Iterator iterator = list.persistableIterator();
        while (iterator.hasNext()) {
            LifeCycleManaged object = (LifeCycleManaged)iterator.next();
            /*if (object instanceof RevisionControlled && ((RevisionControlled)object).isLatestIteration())
          {
             wt.enterprise.RevisionControlled revisionControlled = (wt.enterprise.RevisionControlled)object;
             VersionControlHelper.setIterationModifier(revisionControlled,SessionHelper.manager.getPrincipalReference());

          }*///SPR#1841655 :- Lifecycle State change is currently marking model as modified including updating Modified By timestamp and user. This should not occur.


            //Get the assigned state
            PhaseTemplate nextPhaseTemplate = (PhaseTemplate)phaseTemplateMap.get(object);
            State assignedState = getAssignedState(nextPhaseTemplate);

            // -- Replace existing life cycle state or instantiate new
            if ((lcState = object.getState()) == null) {
                lcState = LifeCycleState.newLifeCycleState();
            }
            //This method is called from the multiobject doSetState
            // So contribute to the summary event for each object
            // until there is a multi-object version of the event


            LifeCycleState oldLCState = LifeCycleState.newLifeCycleState();
            if(!pwc && isLCSet)
            {
                object = (LifeCycleManaged) PersistenceHelper.manager.refresh(object);//SPR 1647136
            }
            State oState = object.getLifeCycleState();
            oldLCState.setState(oState);

            lcState.setState(assignedState);
            lcState.setAtGate(atGate);
            object.setState(lcState);
            if (!pwc && object instanceof Notifiable)
                ChangeLifecycleStateSummaryEvent.getSummaryEvent().contribute((Notifiable)object, oldLCState, lcState);
        }
    }

    private void setStates(WTList list,
            LifeCycleTemplateReference lctRef,
            State aState,
            boolean preserveState,
            boolean atGate)
                    throws WTException,WTPropertyVetoException {
        LifeCycleState lcState=null;

        // --if the state is to be preserved, get the phase template for the state.
        PhaseTemplate pt=null;

        //Now iterate through the list and set the state on each object.
        Iterator iterator = list.persistableIterator();
        while (iterator.hasNext()) {
            State staState = aState;
            LifeCycleManaged object = (LifeCycleManaged)iterator.next();
            if (!object.isLifeCycleBasic() && lctRef.isBasic()) {
                object = resetNonBasicAttributes(object);
            }

            //Need to preserve the state of the object
            if (preserveState){
                pt= stateSearch((LifeCycleTemplate)lctRef.getReadOnlyObject(), object.getLifeCycleState());
            }
            // -- Set the LifeCycleState cookie

            // -- Replace existing life cycle state or instantiate new
            if ((lcState = object.getState()) == null) {
                lcState = LifeCycleState.newLifeCycleState();
            }

            lcState.setLifeCycleId(lctRef);

            if (staState == null) {
                //If the phase template is null, assign to the initial phase
                if (pt ==null)
                    pt = getInitialPhase((LifeCycleTemplate)lctRef.getObject());
                staState = getAssignedState(pt);
            }
            lcState.setState(staState);
            lcState.setAtGate(atGate);
            object.setState(lcState);

        }
    }

    private PhaseTemplate getInitialPhase(LifeCycleManaged object)
            throws LifeCycleException {

        // -- Answer the initial PhaseTemplate for this object
        if (logger.isTraceEnabled())
            logger.trace("Enter getInitialPhase:"+getOid(object));

        /* 1. Find a life cycle template for this object */
        LifeCycleTemplate aTemplate = (LifeCycleTemplate)object.getLifeCycleTemplate().getReadOnlyObject();

        /* 2. Use the object reference to instantiate the initial phase template */
        PhaseTemplate initialPhase = getInitialPhase(aTemplate);

        if (logger.isTraceEnabled())
            logger.trace("Exit getInitialPhase:"+initialPhase.getName());

        return initialPhase;
    }

    private PhaseTemplate getInitialPhase(LifeCycleTemplate template)
            throws LifeCycleException {

        if (logger.isTraceEnabled())
            logger.trace("Enter getInitialPhase:"+template.getName());

        PhaseTemplate initialPhase = null;
        State initialState = null;

        //-- Check the cache first
        initialPhase = (PhaseTemplate)getInitialPhaseCache().get(PersistenceHelper.getObjectIdentifier(template));
        if (initialPhase != null) {
            initialState = getAssignedState(initialPhase);
            if (logger.isTraceEnabled())
                logger.trace ("InitialPhaseCache:  " +template.getName()+ " found in cache.  State = " +initialState.toString());
        }
        else {
            if (logger.isTraceEnabled())
                logger.trace ("InitialPhaseCache: " +template.getName()+ " not found in cache, checking db....");
            //--If not found in the cache, go get it from the database
            ObjectReference ref = template.getPhaseTemplateId();
            initialPhase = (PhaseTemplate)(ref.getObject());
            initialState = getAssignedState(initialPhase);
            getInitialPhaseCache().put(PersistenceHelper.getObjectIdentifier(template), initialPhase);
            if (logger.isTraceEnabled()) {
                logger.trace("InitialPhaseCache:  Added " +template.getName() + " + " +initialState.toString());
            }
        }

        if (logger.isTraceEnabled())
            logger.trace("Exit getInitialPhase "+initialPhase.getName());

        return initialPhase;
    }

    private PhaseTemplate getPhaseTemplate(LifeCycleManaged object)
            throws LifeCycleException {
        if (logger.isTraceEnabled())
            logger.trace("getPhaseTemplate : IN... ");
        //Depending on the state defined in the cookie, returns either the first phase template or the phasetemplate of the state noted
        PhaseTemplate aPhaseTemplate = null;

        State aState = ((LifeCycleManaged)object).getState().getState();
        if (aState != null && !aState.equals(State.DROPPED)) {
            try {
                aPhaseTemplate = validateState((LifeCycleManaged)object, aState);
            }
            catch (WTException wte) {
                if (logger.isTraceEnabled()){
                    logger.trace(" getPhaseTemplate : Exception ::- ");
                    wte.printStackTrace();
                }
                Object[] param = { IdentityFactory.getDisplayIdentity(object), aState.getDisplay(), ((LifeCycleManaged)object).getLifeCycleTemplate().getName() };
                throw new LifeCycleException (RESOURCE, lifecycleResource.INVALID_STATE_ON_CREATE, param);
            }
        }
        else
            aPhaseTemplate = getInitialPhase((LifeCycleManaged)object);

        if (logger.isTraceEnabled())
            logger.trace("getPhaseTemplate : OUT... " + aPhaseTemplate);
        return aPhaseTemplate;
    }

    private PhaseTemplate getPhaseTemplate(AdHocAclSpec ahas)
            throws LifeCycleException, WTException {

        PhaseTemplate pt = null;

        QueryResult results = PersistenceServerHelper.manager.expand(
                ahas,
                AdHocAclLink.PHASE_TEMPLATE_ROLE,
                wt.lifecycle.AdHocAclLink.class,
                true);
        if (logger.isTraceEnabled())
            logger.trace("Found "+results.size()+" PhaseTemplate Objects");

        if (results.hasMoreElements()) {
            pt = (PhaseTemplate)results.nextElement();
        }

        return pt;
    }

    private PhaseTemplate getPhaseTemplate(Criterion criterion)
            throws LifeCycleException, WTException {

        PhaseTemplate pt = null;

        QueryResult results = PersistenceServerHelper.manager.expand(
                criterion,
                DefaultCriterion.PHASE_TEMPLATE_ROLE,
                wt.lifecycle.DefaultCriterion.class,
                true);
        if (logger.isTraceEnabled())
            logger.trace("Found "+results.size()+" PhaseTemplate Objects");

        if (results.hasMoreElements()) {
            pt = (PhaseTemplate)results.nextElement();
        }

        return pt;
    }

    private Phase setCurrentPhase(LifeCycleManaged object, Phase phase)
            throws LifeCycleException, WTException {

        // --Persist the phase
        PersistenceServerHelper.manager.insert(phase);

        // -- Link the phase to the object
        CurrentPhase cp = null;
        if (object instanceof Iterated)
            cp = IteratedCurrentPhaseLink.newIteratedCurrentPhaseLink(phase,(IteratedLifeCycleManaged)object);
        else
            cp = CurrentPhaseLink.newCurrentPhaseLink(phase,object);
        PersistenceServerHelper.manager.insert(cp);

        // -- Maintain the phase on the LifeCycleManaged object to save a call to the db
        if (logger.isTraceEnabled())
            logger.trace("**Putting the Phase object on the cookie of the LifeCycleManaged object");
        try {
            object.getState().setPhase(phase);
        }
        catch (WTPropertyVetoException wtpve) {
            if(logger.isDebugEnabled()){
                logger.debug(wtpve.getLocalizedMessage(), wtpve);
            }
            throw new WTException(wtpve);
        }

        return phase;
    }

    private void setCurrentPhase(WTCollection collection, WTKeyedMap phaseMap)
            throws LifeCycleException, WTException {

        if (logger.isTraceEnabled())
            logger.trace("===> Enter setCurrentPhase(WTCollection, WTKeyedMap): " + collection.size());

        Transaction trx = new Transaction();
        try {
            trx.start();
            // 1. Save all the phases
            if (phaseMap.values().size() > 0) {
                PersistenceServerHelper.manager.insert(new WTArrayList(phaseMap.values()));

                //2.  Iterate through the collection and create and save the links.
                WTCollection links = new WTArrayList();
                CurrentPhase cp=null;
                Iterator iterator = collection.persistableIterator();
                LifeCycleManaged object;
                Phase phase;

                while (iterator.hasNext()) {
                    object = (LifeCycleManaged)iterator.next();
                    // 1. Link the phase to the object

                    phase = null;
                    if (phaseMap.get(object) != null)
                        phase = (Phase)phaseMap.get(object);
                    if (phase != null) {
                        if (object instanceof Iterated)
                            cp = IteratedCurrentPhaseLink.newIteratedCurrentPhaseLink(phase,(IteratedLifeCycleManaged)object);
                        else
                            cp = CurrentPhaseLink.newCurrentPhaseLink(phase,object);
                        links.add(cp);
                        //2. -- Maintain the phase on the LifeCycleManaged object to save a call to the db
                        if (logger.isTraceEnabled())
                            logger.trace("**Putting the Phase object on the cookie of the LifeCycleManaged object");
                        try {
                            object.getState().setPhase(phase);
                        }
                        catch (WTPropertyVetoException wtpve) {
                            if(logger.isDebugEnabled()){
                                logger.debug(wtpve.getLocalizedMessage(), wtpve);
                            }
                            throw new WTException(wtpve);
                        }
                    }
                }
                // 3.  Save the links\
                if (links.size() > 0)
                    PersistenceServerHelper.manager.insert(links);

            }
            trx.commit();
            trx=null;
        }
        finally {
            if (trx != null)
                trx.rollback();
        }


        if (logger.isTraceEnabled())
            logger.trace("===> Exit setCurrentPhase(WTCollection, WTKeyedMap): " + collection.size());
    }

    private State getAssignedState(PhaseTemplate aPhaseTemplate)
            throws LifeCycleException {

        // -- Get the State object associated with the phase
        if (logger.isTraceEnabled())
            logger.trace(">>In StandardLifeCycleService...getAssignedState(PhaseTemplate) method");
        LifeCycleException lcExcp=null;
        if (aPhaseTemplate == null) {
            lcExcp= new LifeCycleException( RESOURCE, lifecycleResource.NULL_OBJECT, null );
            if(logger.isDebugEnabled()){
                logger.debug(lcExcp.getLocalizedMessage(), lcExcp);
            }
            throw lcExcp;
        }

        State assignedState = aPhaseTemplate.getPhaseState();
        if (assignedState == null) {
            lcExcp=new LifeCycleException(RESOURCE, lifecycleResource.NO_STATE, null );
            if(logger.isDebugEnabled()){
                logger.debug(lcExcp.getLocalizedMessage(), lcExcp);
            }
            throw lcExcp;
        }
        if (logger.isTraceEnabled())
            logger.trace("--assignedState: "+assignedState);
        return assignedState;
    }
    private boolean isCookieInitialized(LifeCycleManaged object)
            throws WTException {

        // -- Determine if the state cookie has been completely initialized

        boolean answer = true;
        LifeCycleState lcState = object.getState();
        if (lcState == null)  {
            // -- Uninitialized
            answer = false;
        }
        else {
            // -- Partial initialization
            if (lcState.getState() == null)
                answer = false;
        }

        return answer;
    }

    private LifeCycleState setState(LifeCycleManaged object,
            State aState,
            boolean atGate )
                    throws WTException,WTPropertyVetoException {

        LifeCycleState lcState=null;

        // -- Set the LifeCycleState cookie

        // -- Replace existing life cycle state or instantiate new
        if ((lcState = object.getState()) == null) {
            lcState = LifeCycleState.newLifeCycleState();
        }

        lcState.setState(aState);
        lcState.setAtGate(atGate);

        return lcState;
    }

    private void setTemplate(LifeCycleManaged object, LifeCycleTemplate aTemplate)
            throws WTException,WTPropertyVetoException {

        // Empty out the entire LifeCycle cookie - this is done to make sure the state corresponds to the LCT
        LifeCycleState lcState = LifeCycleState.newLifeCycleState();

        // Set the State cookie
        lcState.setLifeCycleId(LifeCycleTemplateReference.newLifeCycleTemplateReference(aTemplate));
        object.setState(lcState);
    }

    /**
     * Answer the next phase in the Life Cycle.  Returns 'null' if not found.
     */
    private PhaseTemplate getSuccessorPhase(PhaseTemplate current) throws WTException {
        if (logger.isTraceEnabled())
            logger.trace("   getSuccessorPhase: IN... :: " + current);
        // -- Navigate from the current phase to the successor
        QuerySpec qs = new QuerySpec(PhaseTemplate.class, PhaseSuccession.class);
        qs.appendWhere(new SearchCondition(PhaseSuccession.class, PhaseSuccession.NAME, SearchCondition.EQUAL, Transition.NEXT), new int[] { 1 });
        if (logger.isTraceEnabled())
            logger.trace("   query spec :: " + qs);
        QueryResult qr = PersistenceHelper.manager.navigate( (Persistable)current, PhaseSuccession.SUCCESSOR_ROLE, qs, true );
        // -- Note: Linear - currently supporting only 1 successor
        if (logger.isTraceEnabled())
            logger.trace("   getSuccessorPhase : qr.size() :: " + qr.size());
        PhaseTemplate returnVal = null;
        if (qr.hasMoreElements()) {
            returnVal = (PhaseTemplate)qr.nextElement();
            if (logger.isTraceEnabled())
                logger.trace("   getSuccessorPhase : OUT... returnVal :: " + returnVal);
        }

        return (returnVal);
        //throw new LifeCycleException( RESOURCE, lifecycleResource.NO_SUCCESSOR, null );
    }

    /**
     * Answer the next phase in the Life Cycle or null if
     * current is the initial phase (no predecessor).
     */
    private PhaseTemplate getPredecessorPhase (PhaseTemplate current) throws WTException {
        // -- Navigate from the current phase to the successor
        QuerySpec qs = new QuerySpec(PhaseTemplate.class, PhaseSuccession.class);
        qs.appendWhere(new SearchCondition(PhaseSuccession.class, PhaseSuccession.NAME, SearchCondition.EQUAL, Transition.NEXT), new int[] { 1 });
        QueryResult qr = PersistenceHelper.manager.navigate( (Persistable)current, PhaseSuccession.PREDECESSOR_ROLE, qs, true );
        // -- Note: Linear - currently supporting only 1 successor
        if (logger.isTraceEnabled())
            logger.trace("   getPredessorPhase: " + qr.size());
        PhaseTemplate returnVal = null;
        if (qr.hasMoreElements()) {
            returnVal = (PhaseTemplate)qr.nextElement();
        }

        return (returnVal);
        //throw new LifeCycleException( RESOURCE, lifecycleResource.NO_PREDECESSOR, null );
    }



    /**
     * Detects if the view+variations are different between the given ViewManageable objects.
     * @param vm1
     * @param vm2
     * @return boolean
     */
    private boolean areViewVariationsDifferent(ViewManageable vm1, ViewManageable vm2) {
        boolean different = false;
        if (vm1.getView() != null) {
            different = !vm1.getView().equals(vm2.getView());
        }
        else {
            different = (vm2.getView() != null);
        }
        return different || areVariationsDifferent(vm1.getVariation1(), vm1.getVariation2(), vm2.getVariation1(), vm2.getVariation2());
    }


    /**
     * Detects if the given set of variations are different.
     * @param variation11
     * @param variation21
     * @param variation12
     * @param variation22
     * @return boolean
     */
    private static boolean areVariationsDifferent(Variation1 variation11, Variation2 variation21, Variation1 variation12, Variation2 variation22) {
        boolean different = false;
        if (variation11 != null) {
            different |= !variation11.equals(variation12);
        }
        else {
            different |= (variation12 != null);
        }
        if (variation21 != null) {
            different |= !variation21.equals(variation22);
        }
        else {
            different |= (variation22 != null);
        }
        return different;
    }


    /**
     * Set the LifeCycleState based on LifeCycle REVISE transition for revised objects.
     * This method assumes that it's only called within a Transaction block, currently as
     * part of a persist transaction.
     */
    private void processReviseTransition(WTCollection collection) throws WTException, LifeCycleException {
        if (logger.isTraceEnabled())
            logger.trace("===> Enter processReviseTransition(WTCollection)");

        /* 1. Find all revised objects in the collection */
        WTCollection revisedCollection = findRevisedObjects(collection);

        if (logger.isTraceEnabled())
            logger.trace("    revisedObjects size = " + revisedCollection.size());
        try {
            WTKeyedMap newVersionStateMap = new WTKeyedHashMap();

            WTKeyedHashMap combineMap = new WTKeyedHashMap();
            WTKeyedHashMap combineMapStatus = new WTKeyedHashMap();
            HashMap<LifeCycleManaged,LifeCycleManaged> newOldVersionMap = new HashMap<LifeCycleManaged,LifeCycleManaged>();
            //LifeCycleManaged oldVersion = null;
            for (Iterator lcmoIterator = revisedCollection.persistableIterator(); lcmoIterator.hasNext(); ) {
                LifeCycleManaged lcm = (LifeCycleManaged) lcmoIterator.next();
                LifeCycleManaged oldVersion = null;
                /* 2. Get Predecessor object and predecessor state */
                LifeCycleManaged predecessor = (LifeCycleManaged) ((Iterated)lcm).getIterationInfo().getPredecessor().getObject();

                State predState = predecessor.getState().getState();
                if (lcm.getLifeCycleTemplate() == null) {
                    // Set default lifecycle template just in case.
                    LifeCycleTemplate aTemplate = findDefaultTemplate(lcm);
                    setTemplate(lcm,aTemplate);
                    if (logger.isTraceEnabled())
                        logger.trace("    LifeCycleTemplate not set.  Applying default LifeCycleTemplate");
                }


                Set set = new HashSet();
                set.add(predState);
                newVersionStateMap.put(lcm, set);

                if(lcm instanceof Versioned)    {



                    boolean specialCheck=false;
                    if((lcm instanceof ViewManageable)&&(predecessor instanceof ViewManageable))
                    {
                        //To check, if "lcm" is a result of New View Version action
                        if (areViewVariationsDifferent((ViewManageable)lcm, (ViewManageable)predecessor))
                        {
                            specialCheck=true;
                            if(logger.isDebugEnabled())
                                logger.debug("object is a result of New View Version");
                        }
                    }
                    if(lcm instanceof OneOffVersioned)
                    {
                        //To check, if "lcm" is a result of One Off Version action
                        if(VersionControlHelper.isAOneOff((OneOffVersioned)lcm))
                        {
                            specialCheck=true;
                            if(logger.isDebugEnabled())
                                logger.debug("object is a result of One Off Version");
                        }
                    }
                    Persistable tempobj = null;
                    if(logger.isDebugEnabled())
                        logger.debug("Try to get latest iteration in current branch");
                    WTCollection tempCollection = new WTArrayList();
                    tempCollection.add((Versioned) predecessor);
                    WTValuedMap tempResult = VersionControlHelper.service.getLatestRevisions(tempCollection);
                    for (Iterator tempIterator = tempResult.values().iterator(); tempIterator.hasNext(); ) {
                        Object tempObject = (Object) tempIterator.next();
                        if(tempObject instanceof WTReference)
                        {
                            tempobj = (Persistable)((WTReference)tempObject).getObject();
                        }
                    }
                    if(logger.isDebugEnabled())
                        logger.debug("Latest iteration in current branch is "+tempobj);




                    // Check for latest Version Revision Transition
                    //QueryResult qr = VersionControlHelper.service.allVersionsOf((Versioned) lcm);
                    //Enumeration lcmVersions = qr.getEnumeration();
                    if(tempobj!=null)   {
                        // First Element of the QueryResult is the Latest Version

                        // If the object is a result of New View Version then the specialcheck is true so assigned the oldVersion here.
                        oldVersion = (LifeCycleManaged)tempobj;
                        newOldVersionMap.put(lcm, oldVersion);
                        if(!specialCheck)
                        {
                            if(logger.isDebugEnabled())
                                logger.debug("It is not special case therefore check source and latest both");

                            // Get the Latest Iteration of the Latest Version
                            LifeCycleManaged latestIter = (LifeCycleManaged)tempobj;

                            // Get the state of the iteration
                            State latestState = latestIter.getState().getState();
                            Set latestSet = new HashSet();
                            latestSet.add(latestState);

                            combineMap.put(latestIter, latestSet);
                            combineMapStatus.put(latestIter, "REVISETRANSITION_LATEST");

                            if(!((predecessor.getIdentity()).equalsIgnoreCase(latestIter.getIdentity())))
                            {
                                combineMap.put(predecessor, set);
                                combineMapStatus.put(predecessor, "REVISETRANSITION_CURRENT");
                            }
                        }
                        else
                        {
                            if(logger.isDebugEnabled())
                                logger.debug("It is special case therefore just need to check source only");

                            combineMap.put(predecessor, set);
                            combineMapStatus.put(predecessor, "REVISETRANSITION_CURRENT");

                        }
                    }
                } // if(lcm instanceof Versioned)
            }

            WTKeyedHashMap finalResultMap = (WTKeyedHashMap) navigateForReviseAction(combineMap, Transition.REVISE, true);

            String currentTransitionFlagStatus = searchTransition(finalResultMap, combineMapStatus);

            if(logger.isDebugEnabled())
                logger.debug("currentTransitionFlagStatus::"+currentTransitionFlagStatus);

            if(currentTransitionFlagStatus!=null)
            {
                if(currentTransitionFlagStatus.equalsIgnoreCase("REVISETRANSITION_LATEST"))
                {

                    throw new WTException(RESOURCE, lifecycleResource.NO_REVISETRANSITION_LATEST, null );
                }
                else if(currentTransitionFlagStatus.equalsIgnoreCase("REVISETRANSITION_CURRENT"))
                {
                    throw new WTException(RESOURCE, lifecycleResource.NO_REVISETRANSITION_CURRENT, null );
                }
            }


            /* 3. navigate for the predecessor states */
            WTKeyedHashMap resultMap = (WTKeyedHashMap) navigate(newVersionStateMap, Transition.REVISE, true);

            ArrayList underflow = new ArrayList();
            ArrayList overflow = new ArrayList();

            for (Iterator lcmoIterator = resultMap.wtKeySet().persistableIterator(); lcmoIterator.hasNext(); ) {
                LifeCycleManaged newVersion = (LifeCycleManaged) lcmoIterator.next();

                /* Retrieve predecessor state, there can only 1 predecessor state, no more, no less */
                State predState = (State) ((Set) newVersionStateMap.get(newVersion)).iterator().next();

                LifeCycleTemplate oirLifecycleTemplate= (LifeCycleTemplate) newVersion.getLifeCycleTemplate().getObject();

                /* 4. If previous state exists in new Template, set state to transition specified state.
               Otherwise default to the existing behavior when a state isn't set */
                PhaseTemplate pt = stateSearch((LifeCycleTemplate) newVersion.getLifeCycleTemplate().getObject(),predState);
                if (pt != null) {
                    if (logger.isTraceEnabled()) logger.trace("    PhaseTemplate exists in revised objects Lifecycle: " + pt.getName());

                    PhaseTemplate oldPt = null;
                    LifeCycleManaged oldVersion = newOldVersionMap.get(newVersion);

                    if(oldVersion != null)
                    {
                        oldPt = stateSearch((LifeCycleTemplate) oldVersion.getLifeCycleTemplate().getObject(),predState);
                    }
                    WTHashSet ptSet = new WTHashSet();


                    WTKeyedHashMap statesMap = new WTKeyedHashMap();
                    WTKeyedHashMap emptyTransitionMap = new WTKeyedHashMap();
                    if((oldPt!=null)&&(!pt.toString().equals(oldPt.toString()))){
                        ptSet.add(pt);
                        logger.trace("    One PhaseSuccession found");
                        LifeCycleTemplate currentObjectLifecycleTemplate= (LifeCycleTemplate) oldVersion.getLifeCycleTemplate().getObject();
                        NavigateSpec navigateSpec = PersistenceHelper.buildNavigateSpec(ptSet, PhaseSuccession.SUCCESSOR_ROLE, wt.lifecycle.PhaseSuccession.class, false);
                        navigateSpec.appendWhere(new SearchCondition(PhaseSuccession.class, PhaseSuccession.NAME, SearchCondition.EQUAL, Transition.REVISE), new int[] { 1 });
                        SourceLinkMapResultProcessor resultProcessor = new SourceLinkMapResultProcessor(ptSet, PhaseSuccession.SUCCESSOR_ROLE, wt.lifecycle.PhaseSuccession.class);
                        resultProcessor = (SourceLinkMapResultProcessor) PersistenceHelper.manager.find(navigateSpec, resultProcessor);
                        Map targetMap = resultProcessor.getTargetMap();
                        if (targetMap != null)
                            statesMap = new WTKeyedHashMap(targetMap);
                        else if(targetMap ==null &&  !(oirLifecycleTemplate.equals(currentObjectLifecycleTemplate))){
                            logger.trace("   targetMap is null " );
                            continue;
                        }
                    }
                    else
                    {
                        statesMap = (WTKeyedHashMap)resultMap.get(newVersion);
                    }
                    Iterator stateIterator = statesMap.wtKeySet().persistableIterator();

                    WTArrayList list = (WTArrayList) statesMap.get(stateIterator.next());

                    if (list != null && list.size() == 1 ) {
                        if (logger.isTraceEnabled()) logger.trace("    One PhaseSuccession found");
                        PhaseSuccession ps = (PhaseSuccession) list.getPersistable(0);
                        State state = ps.getSuccessor().getPhaseState();
                        if (logger.isTraceEnabled()) logger.trace("        Successor state is: " + state);
                        /* Only setting the state cookie since this is on an object not yet persisted */
                        if (!(isCookieInitialized(newVersion))) {
                            setState(newVersion, state, false);
                        }
                    }
                    else if ((list == null) || (list.size() == 0)) {
                        underflow.add(newVersion);
                        underflow.add(predState);
                    }
                    else if (list.size() > 1) {
                        overflow.add(newVersion);
                        overflow.add(predState);
                        overflow.add(list);
                    }
                }
            }
            if (underflow.size() > 0) {
                Object[] param = { Transition.REVISE.getDisplay(),
                        ((LifeCycleManaged)underflow.get(0)).getLifeCycleTemplate().getName(),
                        ((State)underflow.get(1))};
                throw new WTException( RESOURCE, lifecycleResource.NO_DEFINED_TRANSITIONS, param );
            }
            if ( overflow.size() > 0) {
                LifeCycleManaged lcm = (LifeCycleManaged)overflow.get(0);
                State state = (State)overflow.get(1);
                WTArrayList dest_states = (WTArrayList)overflow.get(2);

                // Build a StringBuffer containing the list of states that are targets of the transition
                StringBuffer dest_states_buf = new StringBuffer();
                for ( int cnt = 0; cnt < dest_states.size(); cnt++) {
                    PhaseSuccession ps = (PhaseSuccession) dest_states.getPersistable(cnt);
                    State succState = ps.getSuccessor().getPhaseState();
                    dest_states_buf.append(succState);
                    if ( cnt < (dest_states.size()-1) ) {
                        dest_states_buf.append(", ");
                    }
                }
                Object[] param = { Transition.REVISE.getDisplay(),
                        lcm.getLifeCycleTemplate().getName(),
                        state,
                        dest_states_buf.toString()};
                throw new WTException( RESOURCE, lifecycleResource.INVALID_MULTIPLE_TRANSITIONS, param );
            }
        }
        catch (WTPropertyVetoException wtpve) {
            if(logger.isDebugEnabled()){
                logger.debug(wtpve.getLocalizedMessage(), wtpve);
            }
            throw new WTException (wtpve);
        }

        if (logger.isTraceEnabled())
            logger.trace("===> Exit processReviseTransition(WTCollection) - revisedObjects count = " + revisedCollection.size());
    }

    /****************
     * Find methods *
     ****************/
    /**
     * Answer an enumeration of templates which accepts the
     * specified class in this container.
     */
    private Enumeration findTemplateMasterByClass (Class targetClass, WTContainerRef context) throws LifeCycleException {
        if (logger.isTraceEnabled())
            logger.trace("=> findTemplateMasterByClass: " + targetClass.getName());
        LifeCycleTemplateMaster aMaster = null;
        Vector candidates = new Vector();
        
        Map templateMasterCache = null;
        String className = targetClass.getName();
        String key = className+context.getObjectId();
        MethodContext m_context = MethodContext.getContext();
        //get cache from method context
        if (m_context.containsKey(LC_MASTER_CACHE))
        	templateMasterCache = (HashMap) m_context.get(LC_MASTER_CACHE);
        else
        	templateMasterCache = new HashMap();

        if (templateMasterCache.containsKey(key))
        	return (Enumeration) templateMasterCache.get(key);
        
        try {
            /* 1. Retrieve all LifeCycleTemplates */
            QueryResult qr = null;
            WhereExpression expr = null;
            LookupSpec ls = null;
            QuerySpec qs = new QuerySpec(LifeCycleTemplateMaster.class);
            SearchCondition enabled = new SearchCondition(
                    LifeCycleTemplateMaster.class,
                    LifeCycleTemplateMaster.ENABLED,
                    SearchCondition.IS_TRUE);
            qs.appendWhere(enabled);
            qs.appendOrderBy(LifeCycleTemplateMaster.class,
                    LifeCycleTemplateMaster.NAME,
                    false);
            ls = new LookupSpec(qs, context);
            try {
                //- This should find all template masters
                //- in all containers looking up from the container passed?
                //-
                ls.setFirstMatchOnly(false);
                //- This should filter the masters by name so that we
                //- only get one master per name - whether found in this
                //- container or a parent container.
                ls.setFilterOverrides(true);
            }
            catch (WTPropertyVetoException wpve) {
                if(logger.isDebugEnabled()){
                    logger.debug(wpve.getLocalizedMessage(), wpve);
                }
                throw new WTException (wpve);
            }
            qr = WTContainerHelper.service.lookup(ls);
            SortedEnumeration enumer = null;
            QueryCollationKeyFactory collation_key = new QueryCollationKeyFactory(getLocale(), "name" );
            if( qr != null ) {
                enumer = new SortedEnumeration( qr.getEnumeration(), collation_key );
            }
            /* 2. Filter the list based on class and superclass */
            String targetClassStr = targetClass.getName();
            while (enumer.hasMoreElements()) {
                aMaster = (LifeCycleTemplateMaster) enumer.nextElement();
                String candidateClassStr = aMaster.getSupportedClass();
                if (TypedUtility.isInstanceOf (targetClassStr, candidateClassStr)) {
                    candidates.addElement(aMaster);
                }
            }
        }
        catch (WTException wex) {
            if(logger.isDebugEnabled()){
                logger.debug(wex.getLocalizedMessage(), wex);
            }
            throw new LifeCycleException(wex);
        }
        /* 3.  If no candidates found, return the default life cycle */
        if (candidates.isEmpty()) {
            aMaster = findDefaultMaster();
            if (aMaster.isEnabled()) {
                candidates.addElement(aMaster);
            }
        }
        if (logger.isTraceEnabled())
            logger.trace("   findTemplateMasterByClass - OUT: " + candidates.size ());
        
        //update cache in method context
        templateMasterCache.put(key, candidates.elements());
        m_context.put(LC_MASTER_CACHE, templateMasterCache);
        
        return candidates.elements();
    }

    /**
     * Answer an enumeration of templates which accepts the
     * specified class in this container.
     */
    private LifeCycleTemplateMaster findTemplateMasterByName (String name, WTContainerRef context)
            throws LifeCycleException {
        if (logger.isTraceEnabled())
            logger.trace("=> findTemplateMasterByName: " + name);
        LifeCycleTemplateMaster aMaster = null;

        try {
            /* 1. Retrieve all LifeCycleTemplates */
            QueryResult qr = null;
            WhereExpression expr = null;
            LookupSpec ls = null;
            QuerySpec qs = new QuerySpec(LifeCycleTemplateMaster.class);
            SearchCondition enabled = new SearchCondition(
                    LifeCycleTemplateMaster.class,
                    LifeCycleTemplateMaster.ENABLED,
                    SearchCondition.IS_TRUE);
            SearchCondition byName = new SearchCondition(
                    LifeCycleTemplateMaster.class,
                    LifeCycleTemplateMaster.NAME,
                    SearchCondition.EQUAL,
                    name);
            qs.appendWhere(byName);
            qs.appendAnd();
            qs.appendWhere(enabled);
            qs.appendOrderBy(LifeCycleTemplateMaster.class,
                    LifeCycleTemplateMaster.NAME,
                    false);
            ls = new LookupSpec(qs, context);
            try {
                //- This should find all masters
                //- in all containers looking up from the container passed?
                //-
                ls.setFirstMatchOnly(false);

                //- This should filter the masters by name so that we
                //- only get one masters per name - whether found in this
                //- container or a parent container.
                ls.setFilterOverrides(true);
            }
            catch (WTPropertyVetoException wpve) {
                throw new WTException (wpve);
            }
            qr = WTContainerHelper.service.lookup(ls);
            if (qr.hasMoreElements()) {
                aMaster = (LifeCycleTemplateMaster)qr.nextElement();
            }
        }
        catch (WTException wex) {
            if(logger.isDebugEnabled()){
                logger.debug(wex.getLocalizedMessage(), wex);
            }
            throw new LifeCycleException(wex);
        }
        catch (java.util.NoSuchElementException nsee) {
            if(logger.isDebugEnabled()){
                logger.debug(nsee.getLocalizedMessage(), nsee);
            }
        }
        if (logger.isTraceEnabled())
            logger.trace("   findTemplateMasterByName - OUT: " + name);

        return aMaster;
    }


    //R4 TODO:  This method is only used by a deprecated method.  Delete this method when the findCandidateTemplate method is deleted
    private LifeCycleTemplate findDefaultTemplate()
            throws LifeCycleException {

        // -- Answer the system default life cycle (wt.properties.defaultLifeCycle)

        LifeCycleTemplate defaultTemplate = null;
        try {
            defaultTemplate = getLifeCycleTemplate(DEFAULT_LIFECYCLE);
        }
        catch(WTException wte) {
            if(logger.isDebugEnabled()){
                logger.debug(wte.getLocalizedMessage(), wte);
            }
            throw new LifeCycleException(wte);
        }

        if (defaultTemplate == null) {

            LifeCycleException lcExcep=new LifeCycleException( RESOURCE, lifecycleResource.NO_DEFAULT, null );
            if(logger.isDebugEnabled()){
                logger.debug(lcExcep.getLocalizedMessage(), lcExcep);
            }
            throw lcExcep;
        }
        return defaultTemplate;
    }

    private LifeCycleTemplate findDefaultTemplate(LifeCycleManaged object)
            throws LifeCycleException {

        // -- Answer the system default life cycle (wt.properties.defaultLifeCycle)

        LifeCycleTemplate defaultTemplate = null;
        try {
            WTContainerRef context = null;
            if (object instanceof WTContained) {
                context = ((WTContained)object).getContainerReference();
            }
            if (context == null) {
                try {
                    context = WTContainerHelper.service.getExchangeRef();//WTContainerHelper.service.getClassicRef(); The API getClassicRef() should have been deprecated
                } catch (ClassicContainerNotFoundException e) {
                    context = WTContainerHelper.service.getExchangeContainer().getContainerReference() ;
                }
            }

            defaultTemplate = getLCT(DEFAULT_LIFECYCLE, context);
            //defaultTemplate = getLifeCycleTemplate(DEFAULT_LIFECYCLE);
        }
        catch(WTException wte) {
            if(logger.isDebugEnabled()){
                logger.debug(wte.getLocalizedMessage(), wte);
            }
            throw new LifeCycleException(wte);
        }

        if (defaultTemplate == null) {

            LifeCycleException lcExcep=new LifeCycleException( RESOURCE, lifecycleResource.NO_DEFAULT, null );
            if(logger.isDebugEnabled()){
                logger.debug(lcExcep.getLocalizedMessage(), lcExcep);
            }
            throw lcExcep;
        }
        return defaultTemplate;
    }


    private LifeCycleTemplateMaster findDefaultMaster()
            throws LifeCycleException {

        // -- Answer the system default life cycle (wt.properties.defaultLifeCycle)

        LifeCycleTemplateMaster defaultMaster = null;
        try {
            defaultMaster = getLifeCycleTemplateMaster(DEFAULT_LIFECYCLE);
        }
        catch(WTException wte) {
            if(logger.isDebugEnabled()){
                logger.debug(wte.getLocalizedMessage(), wte);
            }
            throw new LifeCycleException(wte);
        }

        if (defaultMaster == null) {
            LifeCycleException lcExcep=new LifeCycleException( RESOURCE, lifecycleResource.NO_DEFAULT, null );
            if(logger.isDebugEnabled()){
                logger.debug(lcExcep.getLocalizedMessage(), lcExcep);
            }
            throw lcExcep;
        }
        return defaultMaster;
    }

 // SPR 2199508 :Change Object use the incorrect checkout lifecycle.
    public LifeCycleTemplate getLifecycleTemplate(String aTemplateName,
            WTContainerRef context, boolean ignoreCheckedOutTemplate)
            throws LifeCycleException, WTException {
        if (logger.isTraceEnabled()) {
            logger.trace("Entering getLifecycleTemplate(String, WTContainerRef,boolean)");
            logger.trace("Template Name :" + aTemplateName + ", Context is :"
                    + (context==null?null:context.getName()) + ", ignoreCheckedOutTemplate="+ignoreCheckedOutTemplate);
        }
        LifeCycleTemplate template = getLifeCycleTemplate(aTemplateName, context);
        if(template == null) {
            logger.trace("Lifecycle template from cache is null, i.e. no template presents with this name, return null");
            return null;
        }
        if (!ignoreCheckedOutTemplate)
            return template;
        else if (isWorkingCopyOrInPersonalCabinet(template.getLifeCycleTemplateReference())) {
            if (logger.isTraceEnabled()) {
                logger.trace("Lifecycle template from cache is in personal cabinet so look for valid template.");
            }
            LifeCycleTemplateMaster aMaster = findTemplateMasterByName(
                    aTemplateName, context);
            if(aMaster == null)
                return null;
            QueryResult lctQueryResult = VersionControlHelper.service
                    .allIterationsOf(aMaster);

            if(lctQueryResult.size() == 1) {
                LifeCycleTemplate lct = (LifeCycleTemplate) lctQueryResult.nextElement();
                if(isWorkingCopyOrInPersonalCabinet(lct.getLifeCycleTemplateReference())) {
                    if(context.equals(context.getParentRef()))
                        return null;
                    else
                        return getLifecycleTemplate(aTemplateName, context.getParentRef(), ignoreCheckedOutTemplate);
                } else
                    return lct;
            } else {
                return getLifeCycleTemplate(aTemplateName, context);
            }
        } else {
            if (logger.isTraceEnabled())
                logger.trace("Lifecycle template from cache is not in personal cabinet so continue with same template. "+template);
            return template;
        }
    }

    private void applyLifeCyclePermissions(WTCollection collection, boolean persist)
            throws WTException {

        if (logger.isTraceEnabled())
            logger.trace("Entering applyLifeCyclePermissions(WTCollection)");

        Phase aPhase; PhaseTemplate aPhaseTemplate;
        Iterator iterator=collection.persistableIterator();
        int size=(int)(collection.size()/.75 + 1);
        WTList needsTeamCreated = new WTArrayList(size);  //Stores objects that need to be have team created.
        WTList needsTeamUpdated = new WTArrayList(size);  //Stores objects that need to have team updated.
        WTCollection nonTeamList = new WTArrayList( collection );
        WTKeyedMap phaseTemplateMap = new WTKeyedHashMap(size);  //Stores the phase templates.
        LifeCycleManaged object=null;
        while (iterator.hasNext()) {
            object=(LifeCycleManaged)iterator.next();

            LifeCycleTemplateReference lctRef= object.getLifeCycleTemplate();
            LifeCycleTemplate lct = (LifeCycleTemplate)lctRef.getReadOnlyObject();

            if (lct.isBasic()){
                try {
                    //Ensure the team template is null.
                    object.setTeamTemplateId(null);
                }
                catch (WTPropertyVetoException e) {
                    if(logger.isDebugEnabled()){
                        logger.debug(e.getLocalizedMessage(), e);
                    }
                    throw new WTException(e);
                }
                if (logger.isTraceEnabled() )
                    logger.trace("  Object is basic life cycle managed. Do not need to apply permissions.");
            }
            else {
                // 1.  Get the phase template for the object.
                aPhaseTemplate = getPhaseTemplate(object);
                phaseTemplateMap.put(object, aPhaseTemplate);

                // 6. TODO: For now create the team or add the lc roles.  This will need to be changed to be multi-object

                if (object.getTeamId() ==  null) {
                    needsTeamCreated.connect(object,collection);
                }
                else {
                    needsTeamUpdated.connect(object, collection);
                }
            }

        }

        boolean saveEnforced = SessionServerHelper.manager.setAccessEnforced( false );
        try {
            if (needsTeamCreated.size() > 0 ) {
                if(logger.isDebugEnabled())
                    System.out.println("needsTeamCreated.size() :: "+ needsTeamCreated.size());

                //Create separate buckets to determine which objects will have the same role resolutions and create the teams.
                List list = createSubcollectionsByKey(needsTeamCreated);
                List membershipList = TeamServerHelper.service.createTeams(list,phaseTemplateMap);
                // This is not ideal since we need to iterator over them, but there is no removeAll(Collection) API
                // It is likely iterating as WTReferences so this is relatively light-weight
                Iterator iter = needsTeamCreated.iterator();
                while ( iter.hasNext() ) {
                    nonTeamList.remove(iter.next());
                }
                if (persist)
                    PersistenceServerHelper.manager.update(needsTeamCreated,false);
                buildAdHocAcl(list, membershipList, phaseTemplateMap);
            }

            if (needsTeamUpdated.size() > 0 ) {
                if(logger.isDebugEnabled())
                    System.out.println("needsTeamUpdated.size() :: "+ needsTeamUpdated.size());
                /*if(!ALLOW_RERESOLUTION_LC_ROLES)
                  MethodContext.getContext().put("LC_STATE_TRANSITION_SETUPPARTICIPANT", "LC_STATE_TRANSITION_SETUPPARTICIPANT");*/
                //First resolve the roles and get the maps.
                List membershipList = TeamServerHelper.service.resolveLCRoles(needsTeamUpdated, phaseTemplateMap);
                List list = new ArrayList(needsTeamUpdated.size());
                //Now create a list of WTLists
                iterator = needsTeamUpdated.persistableIterator();
                while (iterator.hasNext()) {
                    // Remove the item from the list of non-updated items as well as the TeamUpdate list
                    LifeCycleManaged lcm = (LifeCycleManaged)iterator.next();
                    nonTeamList.remove(lcm);
                    WTList aList = new WTArrayList(1);
                    aList.add(lcm);
                    list.add(aList);
                }
                //Now build the ad hoc acls.
                if (persist)
                    PersistenceServerHelper.manager.update(needsTeamUpdated, false);

                buildAdHocAcl(list, membershipList, phaseTemplateMap);
            }
            if (nonTeamList.size() > 0 && persist) {
                if(logger.isDebugEnabled())
                    System.out.println("nonTeamList.size() :: "+ nonTeamList.size());

                PersistenceServerHelper.manager.update(nonTeamList,false);
            }

        }
        finally {
            SessionServerHelper.manager.setAccessEnforced( saveEnforced );
        }



        if (logger.isTraceEnabled())
            logger.trace("Exiting applyLifeCyclePermissions(WTCollection)");

    }

    private LifeCycleTemplateReference cacheTemplateReference(Map map, LifeCycleManaged lifeCycleManagedObject)
    {
        LifeCycleTemplateReference ref = lifeCycleManagedObject.getState().getLifeCycleId();

        if(!map.containsKey(ref.getObjectId()))
        {
            ref.inflate();
            map.put(ref.getObjectId(), ref);
        }
        return (LifeCycleTemplateReference) map.get(ref.getObjectId());
    }

    private WTKeyedMap createPhases(WTCollection collection, WTKeyedMap phaseTemplates)
            throws WTException, WTPropertyVetoException {

        if (logger.isTraceEnabled())
            logger.trace("Entering createPhase(WTCollection)");

        Phase aPhase; PhaseTemplate aPhaseTemplate;
        Iterator iterator=collection.persistableIterator();
        int size=(int)(collection.size()/.75 + 1);
        WTKeyedMap phaseMap = new WTKeyedHashMap(size);  //Map of the objects to their phase
        Map map = new HashMap();
        LifeCycleManaged lifeCycleManaged;

        //Create a phase for each object and set it in the lifecycle phase map.
        while (iterator.hasNext()) {
            lifeCycleManaged=(LifeCycleManaged)iterator.next();
            LifeCycleTemplateReference cachedRef = cacheTemplateReference(map, lifeCycleManaged);
            lifeCycleManaged.getState().setLifeCycleId(cachedRef);

            // 1.  Get the phase template for the object.
            aPhaseTemplate = (PhaseTemplate)phaseTemplates.get(lifeCycleManaged);

            if (lifeCycleManaged.isLifeCycleBasic()) {
                if (logger.isTraceEnabled() ) {
                    logger.trace("createPhase:   Object is basic lifecycle managed.  Noc creating phase for this object");
                }
            }
            else {
                // 2. Create the current phase based on the PhaseTemplate */
                aPhase = Phase.newPhase();

                // 3.  -- Set the name
                aPhase.setName(aPhaseTemplate.getName());

                // 4. -- Set a back-pointer reference to the phase template
                ObjectReference oRef = ObjectReference.newObjectReference(aPhaseTemplate);
                aPhase.setPhaseTemplateId(oRef);

                // 5. -- Set the Object's LifeCycleState's Phase
                if (lifeCycleManaged.getState().getPhase() == null)
                    lifeCycleManaged.getState().setPhase(aPhase);

                // 8. Add to the lifeCycleManagedPhaseMap
                lifeCycleManagedPhaseMap.put(lifeCycleManaged, aPhase);

                // 9. Add to the return map;
                phaseMap.put(lifeCycleManaged, aPhase);
            }

        }

        if (logger.isTraceEnabled())
            logger.trace("Exiting createPhase(WTCollection)");

        return phaseMap;
    }

    private Phase createPhase(LifeCycleManaged object,
            PhaseTemplate aPhaseTemplate)
                    throws WTException, WTPropertyVetoException {

        if (logger.isTraceEnabled())
            logger.trace("Enter createPhase");

        if (object.isLifeCycleBasic()) {
            if (logger.isTraceEnabled() ) {
                logger.trace("createPhase:   Object is basic lifecycle managed.  Returning null");
            }
            return null;
        }

        // 1. Create the current phase based on the PhaseTemplate */
        Phase aPhase = Phase.newPhase();

        // 2.  -- Set the name
        aPhase.setName(aPhaseTemplate.getName());

        // 3. -- Set a back-pointer reference to the phase template
        ObjectReference oRef = ObjectReference.newObjectReference(aPhaseTemplate);
        aPhase.setPhaseTemplateId(oRef);

        // 4. -- Set the Object's LifeCycleState's Phase
        if (object.getState().getPhase() == null)
            object.getState().setPhase(aPhase);

        // 5. -- If team is created, add the lc roles.
        /*
         * This step is completely redundant as step 6 not only add the acls
         * but also RESOLVES LC ROLES. Hence commenting it as it is severly
         * affecting performance
     if (object.getTeamId() != null) {
         if (logger.isTraceEnabled())
            logger.trace("Adding LifeCycle Roles for new Phase");
         TeamHelper.service.addLCRoles(aPhaseTemplate, object);
      }
         */

        // 6. Build an adhoc ACL for phase participants and attach to the object.
        buildAdHocAcl(object,aPhase);

        if (logger.isTraceEnabled())
            logger.trace("Exit createPhase");

        return aPhase;
    }

    private void doStateTransition (WTList collection, String historyEvent, WTKeyedMap phaseTemplateMap, WTContainerRef context,  boolean persist, boolean isLCSet, boolean pwc)
            throws LifeCycleException, WTException {

        if (logger.isTraceEnabled()) {
            logger.trace ("Entering doStateTransition(WTCollection, historyEvent): " + collection.size());
            logger.trace("historyEvent is: " + historyEvent);
            logger.trace("Persist changes? " + persist);
        }

        //1.  Iterate through all the objects to validate they are persistent.
        validatePersistence(collection);

        Transaction trx = new Transaction();
        try {
            trx.start();
            if (persist) {
                //If this is a post store, this work was done in the pre store.
                setStates(collection, phaseTemplateMap, false, isLCSet, pwc);

                // 2.  apply the permissions.
                if (!pwc)
                    applyLifeCyclePermissions(collection, persist);
            }

            {
                // get all phases for the given collection of PBOs
                // This is worth while creating objects iteration using loader (store new iteration with different state)
                WTKeyedMap currentPhaseMap = getPhases(collection);
                if(currentPhaseMap.size() >0 ) {
                	if (logger.isTraceEnabled()) {
                		logger.trace("Cleaning phases for following objects - "+currentPhaseMap.keySet());
                	}
                    deleteCurrentPhases(collection, currentPhaseMap);
                }

            }

            /* 3. Attach LifeCycle info to the collection */

            //I should be saving this in the method context and retrieving?
            WTKeyedMap phaseMap = createPhases(collection, phaseTemplateMap);

            // 4. Trigger WF processing and save references to the wf that was initiated
            if(!isSkipPhaseWorkflowInitiation() && !pwc)
            {
                initiatePhaseWorkflow (phaseTemplateMap, phaseMap, collection);
            }

            // 5. Persist the phase
            setCurrentPhase(collection, phaseMap);

            // 6. Link the template gate criteria to the phase
            cloneCriteria(collection, phaseMap,phaseTemplateMap);

            if (!pwc)
            {
                /* 7. Log the history event */
                saveHistory(collection,phaseMap,historyEvent);
            }


            trx.commit();
            trx=null;
        }
        catch (WTPropertyVetoException wtpve) {
            if(logger.isDebugEnabled()){
                logger.debug(wtpve.getLocalizedMessage(), wtpve);
            }
            throw new LifeCycleException (wtpve);
        }
        finally {
            if(MethodContext.getContext().containsKey("DO_NOT_RESOLVE_CONT_ROLES"))
            {
                if ( logger.isDebugEnabled() )
                    logger.debug ("Remove the DO_NOT_RESOLVE_CONT_ROLES entry form method context");
                MethodContext.getContext().remove("DO_NOT_RESOLVE_CONT_ROLES");
            }

            if (trx != null)
                trx.rollback();
        }

        if (logger.isTraceEnabled())
            logger.trace ("Exiting doStateTransition(WTCollection, historyEvent): " + collection.size());
    }

    public WTList saveHistory( WTList list, WTKeyedMap phaseMap, String event )
            throws WTException, LifeCycleException {

        if (logger.isTraceEnabled()) {
            logger.trace("Enter saveHistory(WTCollection, WTKeyedMap, String): " + list.size());
            logger.trace("ENABLE_HISTORY="+ENABLE_HISTORY);
        }

        return saveHistory(list, phaseMap, event, null);
    }

    private WTList saveHistory( WTList list, WTKeyedMap phaseMap, String event, String comments )
            throws WTException, LifeCycleException {
        String stcomments = comments;
        if (logger.isTraceEnabled()) {
            logger.trace("Enter saveHistory(WTCollection, WTKeyedMap, String): " + list.size());
            logger.trace("ENABLE_HISTORY="+ENABLE_HISTORY);
        }

        //caputre decision to resole container team roles on the basis of event into methodcontext.
        checkResolveContainerTeamRoles(event);

        //-- do nothing if history is not turned on

        LifeCycleHistory h = null;

        WTList historyCollection = new WTArrayList(list.size());
        if (  ENABLE_HISTORY                &&
                ( (event.equals(ENTER_PHASE))   ||
                        (event.equals(SUBMIT))        ||
                        (event.equals(PROMOTE))       ||
                        (event.equals(RETEAM))        ||
                        (event.equals(REASSIGN))      ||
                        (event.equals(DENY))          ||
                        (event.equals(DROP))          ||
                        (event.equals(DEMOTE))        ||
                        (event.equals(SET_STATE))     ||
                        (event.equals(AUGMENT))      ||
                        (event.equals(EXIT_PHASE))
                        )
                )
        {

            if(isSkipLifecycleHistoryCreation())
            {
                return historyCollection;
            }

            WTCollection historyLinks = new WTArrayList(list.size());
            Phase aPhase;
            LifeCycleManaged object;

            MethodContext m_context = MethodContext.getContext();
            if(event.equals(REASSIGN)){
                if(stcomments != null){
                    m_context.put("comment", stcomments);
                }
            }
            if(event.equals(ENTER_PHASE))
                stcomments=(String)m_context.get("comment");

            WTHashSet lcmSet = new WTHashSet();
            Object ixbStoreObjects = m_context.get(wt.facade.ixb.IxbHndHelperConstants.IXB_STORE_OBJ_CONTEXT_KEY);
            if(ixbStoreObjects instanceof Persistable) {
                lcmSet.add((Persistable) ixbStoreObjects);
            }
            else if(ixbStoreObjects instanceof WTCollection) {
                lcmSet.addAll((WTCollection) ixbStoreObjects);
            }

            Iterator iterator = list.persistableIterator();
            while (iterator.hasNext()) {
                object = (LifeCycleManaged)iterator.next();

                if (lcmSet.contains(object))
                    continue;

                aPhase = null;
                if (phaseMap.get(object) != null)
                    aPhase = (Phase)phaseMap.get(object);
                h = buildHistory(object,aPhase,event, stcomments);
                historyCollection.add(h);

                // --Link the object to its history
                ObjectHistory oh = ObjectHistory.newObjectHistory(object,h);
                historyLinks.add(oh);
            }

            Transaction trx = new Transaction();
            try {
                trx.start();
                PersistenceHelper.manager.store(historyCollection);
                PersistenceHelper.manager.store(historyLinks);
                trx.commit();
                trx=null;
            }
            catch (WTException wex) {
                if(logger.isDebugEnabled()){
                    logger.debug(wex.getLocalizedMessage(), wex);
                }
                throw new LifeCycleException(wex);
            }
            finally {
                if (trx != null)
                    trx.rollback();
            }
        }

        if (logger.isTraceEnabled())
            logger.trace("Exit saveHistory(WTCollection, String): " + list.size());

        return historyCollection;

    }

    private LifeCycleManaged doStateTransition (LifeCycleManaged object,
            PhaseTemplate nextPhaseTemplate,
            String historyEvent,
            WTContainerRef context_ref,
            Timestamp timestamp)
                    throws LifeCycleException,WTException {
        LifeCycleManaged lcmobject = object;
        Phase aPhase = null;
        LifeCycleState oldState = lcmobject.getState();
        if (logger.isTraceEnabled())
            logger.trace("=> doStateTransition: " + getOid(object));
        // --  Transition the object to the phase specified by the PhaseTemplate.
        // --  This method is used whenever a state change occurs, including
        // --  assigning the initial state to a "new" LifeCycleManaged object.
        /* 1. Make sure the object is persistent */
        if (!(PersistenceHelper.isPersistent((Persistable)lcmobject))) {
            WTException wtExp =new WTException( RESOURCE, lifecycleResource.NOT_PERSISTENT, null );
            if(logger.isDebugEnabled()){
                logger.debug(wtExp.getLocalizedMessage(), wtExp);
            }
            throw wtExp;
        }

        /* 2. Determine the state to assign */
        State assignedState = getAssignedState(nextPhaseTemplate);
        /* 3. Associate a LifeCycleState to the object based on the state assignment,
         *    and update the object.
         *    Note: Use update instead of modify to avoid event propagation
         */
        Transaction trx = new Transaction();
        try {
            trx.start();
            LifeCycleState lcs = null;
            // -- change state (using partial update)
            PersistenceServerHelper.manager.lock (lcmobject, true);
            lcmobject = (LifeCycleManaged)PersistenceServerHelper.manager.restore(lcmobject, false, true);
            lcs = setState(lcmobject,assignedState,false);
            PersistenceServerHelper.manager.update(lcmobject,wt.lifecycle.LifeCycleManaged.STATE,lcs);

            if (!lcmobject.isLifeCycleBasic()) {
                /* 4. Attach LifeCycle info to the object */
                aPhase = createPhaseInstance(lcmobject,nextPhaseTemplate);
                // 5. Trigger WF processing and save references to the wf that was initiated
                if(!isSkipPhaseWorkflowInitiation())
                {
                    aPhase = initiatePhaseWorkflow (nextPhaseTemplate, aPhase, lcmobject, context_ref);
                }
                // 6. Persist the phase
                aPhase = setCurrentPhase(lcmobject, aPhase);
                // 7. Link the template gate criteria to the phase
                cloneCriteria(aPhase,nextPhaseTemplate);
                // 8. Contribute to the Summary Event

                if (lcmobject instanceof Notifiable)
                    ChangeLifecycleStateSummaryEvent.getSummaryEvent().contribute((Notifiable)lcmobject, oldState, lcs);
            }
            else {
                if (logger.isTraceEnabled() ) {
                    logger.trace("doStateTransition : object is basic lifecycle managed. Just create history and ignore workflow and team processing");
                }
            }
            /* 8. Log the history event */
            saveHistory(lcmobject,aPhase,historyEvent,timestamp, null);
            trx.commit();
            trx = null;
        }
        catch (WTPropertyVetoException veto) {
            throw new LifeCycleException(veto);
        }
        catch (PersistenceException pex) {
            throw new LifeCycleException(pex);
        }
        catch (WTException error) {
            throw new LifeCycleException(error);
        }
        finally {
            if (trx != null)
                trx.rollback();
        }

        if (logger.isTraceEnabled())
            logger.trace("Exit doStateTransition to:"+assignedState.toString());

        return (LifeCycleManaged)PersistenceServerHelper.manager.restore(lcmobject);
    }

    private boolean validatePersistence(WTCollection collection) throws WTException {
        if (logger.isTraceEnabled())
            logger.trace("Entering validatePersistence(collection)");
        //TODO:  Change to through mutli-object exception
        boolean persistent=true;

        Iterator iterator=collection.persistableIterator();
        LifeCycleManaged object;
        while (iterator.hasNext()) {
            object = (LifeCycleManaged) iterator.next();
            if (!(PersistenceHelper.isPersistent((Persistable)object))) {
                persistent = false;
                throw new WTException( RESOURCE, lifecycleResource.NOT_PERSISTENT, null );
            }
        }

        if (logger.isTraceEnabled())
            logger.trace("Exiting validatePersistence(collection)");

        return persistent;
    }

    private Vector getPhaseSignatures(LifeCycleManaged object,
            WTUser user,
            QuerySpec select)
                    throws WTException {

        if (logger.isTraceEnabled())
            logger.trace("Enter getPhaseSignatures by object, user and querySpec");

        // -- Answer a vector of LifeCycleSignatures for this phase

        Vector lcsVector = new Vector();
        String pName = getPhaseName(object);
        if(pName == null){
            logger.debug("As phase name is null , returning empty vector of signatures.");
            return lcsVector;
        }
        QueryResult results = null;

        try {
            SearchCondition sc2 = LifeCycleSignature.getSearchCondition(pName);
            select.appendWhere(sc2);

            // -- Append search condition based on user id
            if (user != null) {
                SearchCondition sc3 = LifeCycleSignature.getSearchCondition(user);
                select.appendAnd();
                select.appendWhere(sc3);
            }

            /*
             * The new subselect is as follows...
             * (not exists (select 1 from SignatureHistory B0 where B0.idA3B5 = A0.idA2A2 ));
             */
            QuerySpec subSelect = new QuerySpec();
            subSelect.getFromClause().setAliasPrefix("B");
            int altIndex = subSelect.appendClassList(SignatureHistory.class, false);
            subSelect.appendSelect(new ConstantExpression(Integer.valueOf(1)), true);

            TableExpression[] tables = new TableExpression[2];
            String[] aliases = new String[2];

            tables[0] = select.getFromClause().getTableExpressionAt(0); //Lifecycle signature
            aliases[0] = select.getFromClause().getAliasAt(0); //Lifecycle signature
            tables[1] = subSelect.getFromClause().getTableExpressionAt(altIndex); //signature history
            aliases[1] = subSelect.getFromClause().getAliasAt(altIndex); //signature history

            subSelect.appendWhere(new SearchCondition(LifeCycleSignature.class,
                    WTAttributeNameIfc.ID_NAME, SignatureHistory.class,
                    "roleBObjectRef.key.id"), tables, aliases);

            if(logger.isTraceEnabled())
                logger.trace("getPhaseSignatures(LifeCycleManaged object, " +
                        "WTUser user, QuerySpec select) ==> " +
                        " The subSelect is --> \n" + subSelect);

            select.appendAnd();
            select.appendWhere(new NegatedExpression(new ExistsExpression(subSelect)));

            // -- Retrieve LifeCycleSignature objects
            select.setAdvancedQueryEnabled(true);

            if(logger.isTraceEnabled())
                logger.trace("getPhaseSignatures(LifeCycleManaged object, " +
                        "WTUser user, QuerySpec select) ==> " +
                        " The main query is --> \n" + select);

            results = PersistenceServerHelper.manager.query(select);
        }
        catch (WTPropertyVetoException wtpve) {
            throw new WTException (wtpve);
        }

        if (logger.isTraceEnabled())
            logger.trace("FOUND " + results.size() + " Signature OBJECTS");

        LifeCycleSignature lcs = null;
        while (results.hasMoreElements()){
            lcs = (LifeCycleSignature)(results.nextElement());
            lcsVector.addElement(lcs);
        }

        if (logger.isTraceEnabled())
            logger.trace("Exit getPhaseSignatures by object, user and querySpec");

        return lcsVector;
    }

    private QueryResult getPhaseSignatures(LifeCycleManaged object, Phase aPhase)
            throws WTException {

        // -- Answer a result of LifeCycleSignatures for this object & phase

        if (logger.isTraceEnabled())
            logger.trace("Enter getPhaseSignatures by object and phase");

        QueryResult results;

        // SELECT A0.*
        // FROM LifeCycleSignature A0
        // WHERE (A0.ida2a2 NOT IN (SELECT DISTINCT B0.idA3B5
        //                           FROM SignatureHistory B0 ) )
        try {
            QuerySpec select = new QuerySpec(LifeCycleSignature.class);

            // -- Append search on object
            // SPR 1707113 - By pass the call to access control.
            boolean enforced = SessionServerHelper.manager.setAccessEnforced(false);
            SearchCondition sc1 = null;
            try  {
                sc1 = LifeCycleSignature.getSearchCondition(object);
            }    finally     {
                // restore the access control state
                SessionServerHelper.manager.setAccessEnforced(enforced);
            }
            select.appendWhere(sc1);

            // -- Append search on phase
            String pName = null;
            if(aPhase!=null){
                pName = aPhase.getName();
            }else{
                //object is basic.
                pName = getPhaseTemplate(object).getName();
            }
            select.appendAnd();
            SearchCondition sc2 = LifeCycleSignature.getSearchCondition(pName);
            select.appendWhere(sc2);

            /*
             * The new subselect is as follows...
             * (not exists (select 1 from SignatureHistory B0 where B0.idA3B5 = A0.idA2A2 ));
             */
            QuerySpec subSelect = new QuerySpec();
            subSelect.getFromClause().setAliasPrefix("B");
            int altIndex = subSelect.appendClassList(SignatureHistory.class, false);
            subSelect.appendSelect(new ConstantExpression(Integer.valueOf(1)), true);

            TableExpression[] tables = new TableExpression[2];
            String[] aliases = new String[2];

            tables[0] = select.getFromClause().getTableExpressionAt(0); //Lifecycle signature
            aliases[0] = select.getFromClause().getAliasAt(0); //Lifecycle signature
            tables[1] = subSelect.getFromClause().getTableExpressionAt(altIndex); //signature history
            aliases[1] = subSelect.getFromClause().getAliasAt(altIndex); //signature history

            subSelect.appendWhere(new SearchCondition(LifeCycleSignature.class,
                    WTAttributeNameIfc.ID_NAME, SignatureHistory.class,
                    "roleBObjectRef.key.id"), tables, aliases);

            if(logger.isTraceEnabled())
                logger.trace("getPhaseSignatures(LifeCycleManaged object, Phase aPhase) ==> " +
                        " The subselect is --> \n" + subSelect);
            select.appendAnd();
            select.appendWhere(new NegatedExpression(new ExistsExpression(subSelect)));

            // -- Retrieve LifeCycleSignature objects
            select.setAdvancedQueryEnabled(true);
            if(logger.isTraceEnabled())
                logger.trace("getPhaseSignatures(LifeCycleManaged object, Phase aPhase) ==> " +
                        " The final query is --> \n" + select);

            results = PersistenceServerHelper.manager.query(select);
        }
        catch (WTPropertyVetoException wtpve) {
            throw new WTException (wtpve);
        }

        if (logger.isTraceEnabled())
            logger.trace("FOUND " + results.size() + " Signature OBJECTS");

        if (logger.isTraceEnabled())
            logger.trace("Exit getPhaseSignatures by object and phase");


        return results;
    }

    private Map getPhaseSignatures(WTList objects, WTKeyedMap phaseMap)
            throws WTException {

        // -- Answer a result of LifeCycleSignatures for the objects & phases

        if (logger.isTraceEnabled()){
            logger.trace("Enter getPhaseSignatures by objects and phases, objects:"+objects.size() +" phaseMap:"+phaseMap.size());
        }

        QueryResult results=null;
        Map<String,WTList> phaseToObjectsMap = new HashMap<>();
        // below arrlistPhaseToObjMap will/may contain multiple Phase-To-Objects Maps as key=phasename, value=objects
        // each map can consists maximum of ((total objs count + number of keys) < DBProperties.QUERY_BIND_LIMIT )
        ArrayList <Map<String,WTList>> arrlistPhaseToObjMap= new ArrayList<>();
        for (int i=0;i < objects.size();i++) {
            LifeCycleManaged lcmObject = (LifeCycleManaged)objects.getPersistable(i);
             if(lcmObject.isLifeCycleBasic())
                 continue;
             Phase phaseValue=(Phase)phaseMap.get(lcmObject);
             if (logger.isTraceEnabled()){ logger.trace("phaseValue = "+phaseValue + "\t lcmObject = " + lcmObject);  }
             if( phaseValue != null) {
            	 String pName = phaseValue.getName();
                 if(!phaseToObjectsMap.containsKey(pName)){
                     phaseToObjectsMap.put(pName, new WTArrayList());
                 }
                 WTList list= phaseToObjectsMap.get(pName);
                 if (lcmObject instanceof Iterated){
                     Enumeration result = VersionControlHelper.service.iterationsOf((Iterated)lcmObject);
                     while (result.hasMoreElements()) {
                        LifeCycleManaged lcObj = (LifeCycleManaged)result.nextElement();
                        list.add(lcObj);
                     }
                 }else{
                     list.add(lcmObject);
                 }
             }
        }
        if (logger.isTraceEnabled()){
            logger.trace("phaseToObjectsMap:"+phaseToObjectsMap.size());
        }
        Map resultMap = null;
        try {
            int cnt=0;
            Iterator<Map.Entry<String,WTList>> mapItr = phaseToObjectsMap.entrySet().iterator();
            final int bindLimit = DBProperties.QUERY_BIND_LIMIT;
            final int phaseCnt=1;
            int totalParameterCnt=0;
            // below logic distributes data in phaseToObjectsMap and puts to arrlistPhaseToObjMap
            //Consider Data State:phaseToObjectsMap->"Inwork:500,Released:5000,Cancelled:400 objects
            //Below loop will break down into chunk of 2100 of Arraylist of Map and Map has key as Phase Name
            //arrlistPhaseToObjMap -->Array of  elements and each element is Map where key is phase name and value is list of objetcs
            //like {[InWork:500,Released:1598],[Released:2099],[Released:1303,Cancelled:400]}
            //In this loop, phaseName is counted as 1 paramter so phaseCnt = 1 value is considered for Phase name
            if (logger.isTraceEnabled()){
                logger.trace("DBProperties.QUERY_BIND_LIMIT:"+bindLimit);
            }
            while(mapItr.hasNext())
            {
                 Map.Entry<String, WTList> entry = mapItr.next();
                 String phaseName=entry.getKey();
                 WTList objList=entry.getValue();
                 long listSize=objList.size();
                 if (logger.isTraceEnabled()){
                     logger.trace("totalParameterCnt"+totalParameterCnt);
                     logger.trace("listSize"+listSize);
                     logger.trace("phaseCnt"+phaseCnt);
                 }
                 if(totalParameterCnt+listSize+phaseCnt <= bindLimit){
                     if (logger.isTraceEnabled()){
                         logger.trace("totalParameterCnt+listSize+phaseCnt < bindLimit");
                     }
                     putEntryIntoArrayList(arrlistPhaseToObjMap,phaseName,objList);
                     totalParameterCnt += (listSize+phaseCnt);
                     if(totalParameterCnt==bindLimit){
                         if (logger.isTraceEnabled()){
                             logger.trace("totalParameterCnt==bindLimit");
                         }
                         totalParameterCnt=0;
                     }
                 }
                 else{
                     if (logger.isTraceEnabled()){
                         logger.trace("totalParameterCnt+listSize+phaseCnt > bindLimit");
                     }
                     int fromIndex=0, uptoIndex=0;
                     Map<String,WTList> phaseToObjMap = new HashMap();
                     int loopCnt= (int) Math.ceil((double)listSize/bindLimit);
                     for (int j = 0; j < loopCnt;j++) {
                         uptoIndex= fromIndex + bindLimit - totalParameterCnt-phaseCnt;
                         if (logger.isTraceEnabled()){
                             logger.trace("fromIndex:"+fromIndex+" uptoIndex:"+uptoIndex);
                         }
                         if(uptoIndex>objList.size()){
                             uptoIndex=objList.size();
                             if (logger.isTraceEnabled()){
                                 logger.trace("uptoIndex > objList.size(), new uptoIndex:"+uptoIndex);
                             }    
                         }
                         WTList subList= (WTList)objList.subList(fromIndex, uptoIndex);
                         putEntryIntoArrayList(arrlistPhaseToObjMap,phaseName,subList);
                         totalParameterCnt += (subList.size()+phaseCnt);
                         if(totalParameterCnt==bindLimit){
                             if (logger.isTraceEnabled()){
                                 logger.trace("totalParameterCnt==bindLimit");
                             }
                             totalParameterCnt=0;
                         }
                         fromIndex = uptoIndex;
                     }
                 }
            }
            // now the arrlistPhaseToObjMap has data in all maps distributed in chunks of maximum number of parameters = DBProperties.QUERY_BIND_LIMIT
            Iterator itr= arrlistPhaseToObjMap.iterator();
            // iterating to generate final query
            while(itr.hasNext()){
                int count=0;
                // SELECT A0.*
                // FROM LifeCycleSignature A0
                // WHERE (A0.ida2a2 NOT IN (SELECT DISTINCT B0.idA3B5
                //                           FROM SignatureHistory B0 ) )
                QuerySpec select = new QuerySpec(LifeCycleSignature.class);
                Map<String,WTList> map =(Map<String,WTList>)itr.next();
                Iterator<Map.Entry<String,WTList>> phaseToObjMapItr = map.entrySet().iterator();
                if(phaseToObjMapItr.hasNext())
                {
                    while(phaseToObjMapItr.hasNext()){
                         Map.Entry<String,WTList> entry =phaseToObjMapItr.next();
                         String phaseName= entry.getKey();
                         WTList list = entry.getValue();
                         long allIds[] = getLongArray(list);
                         select.appendOpenParen();
                         SearchCondition sc = new SearchCondition(LifeCycleSignature.class,"signedObject.key.id",allIds);
                         select.appendWhere(sc);
                         select.appendAnd();
                         SearchCondition sc2 = LifeCycleSignature.getSearchCondition(phaseName);
                         select.appendWhere(sc2);
                         select.appendCloseParen();
                         if(phaseToObjMapItr.hasNext()){
                             select.appendOr();
                         }
                         count++;
                    }
                }
                /*
                * The new subselect is as follows...
                * (not exists (select 1 from SignatureHistory B0 where B0.idA3B5 = A0.idA2A2 ));
                */
               QuerySpec subSelect = new QuerySpec();
               subSelect.getFromClause().setAliasPrefix("B");
               int altIndex = subSelect.appendClassList(SignatureHistory.class, false);
               subSelect.appendSelect(new ConstantExpression(Integer.valueOf(1)), true);

               TableExpression[] tables = new TableExpression[2];
               String[] aliases = new String[2];

               tables[0] = select.getFromClause().getTableExpressionAt(0); //Lifecycle signature
               aliases[0] = select.getFromClause().getAliasAt(0); //Lifecycle signature
               tables[1] = subSelect.getFromClause().getTableExpressionAt(altIndex); //signature history
               aliases[1] = subSelect.getFromClause().getAliasAt(altIndex); //signature history

               subSelect.appendWhere(new SearchCondition(LifeCycleSignature.class,
                       WTAttributeNameIfc.ID_NAME, SignatureHistory.class,
                       "roleBObjectRef.key.id"), tables, aliases);

               if(logger.isTraceEnabled())
                   logger.trace("getPhaseSignatures(LifeCycleManaged object, Phase aPhase) ==> " +
                           " The subselect is --> \n" + subSelect);

               select.appendAnd();
               select.appendWhere(new NegatedExpression(new ExistsExpression(subSelect)));

               // -- Retrieve LifeCycleSignature objects
               select.setAdvancedQueryEnabled(true);
               if(logger.isTraceEnabled())
                   logger.trace("getPhaseSignatures(LifeCycleManaged object, Phase aPhase) ==> " +
                           " The final query is --> \n" + select);
               //Final Query
               /*
                * SELECT A0.*
                  FROM LifeCycleSignature A0
                  WHERE ((A0.idA3signedObject IN (340326,339874)) AND (A0.phaseName = 'Under Review')) 
                  OR ((A0.idA3signedObject IN (340327,339882)) AND (A0.phaseName = 'In Work')) 
                  AND NOT (EXISTS (SELECT 1 FROM SignatureHistory B0 WHERE ((A0.idA2A2 = B0.idA3B5))))
                */
               if (count > 0)
                   results = PersistenceServerHelper.manager.query(select);

               if (results != null) {
                   if (results.hasMoreElements())
                       resultMap = new HashMap((int)(results.size()/.75 + 1));
                   //Now put the results into a return map.
                   while (results.hasMoreElements()) {
                       LifeCycleSignature signature = (LifeCycleSignature)results.nextElement();
                       ObjectIdentifier oid = (ObjectIdentifier)signature.getSignedObject().getKey();
                       List list = null;
                       if (resultMap.get(oid) == null) {
                           list = new ArrayList();
                           resultMap.put(oid,list);
                       }
                       else
                           list = (List)resultMap.get(oid);
                       list.add(signature);
                   }
               }
            }
        }
        catch (WTPropertyVetoException wtpve) {
            throw new WTException (wtpve);
        }

        if (logger.isTraceEnabled())
            logger.trace("Exit getPhaseSignatures by objects and phases");
        return resultMap;
    }

    /**
     * Checks the Arraylist arrlistCnt for a map that has<br> 
     * <strong>"total parameter count < DBProperties.QUERY_BIND_LIMIT",</strong> considering the map key as a parameter itself.<br>
     * Returns <strong>null</strong> if there is no such map.<br>
     * e.g. for a map entry in (say) a LIST1 as [{ key1:[500 elements] , key2:[100 elements] }] , the count for 1st element (i.e. 1st map) in LIST1 is ((500+1)+(100+1) = 602)
     * @param arrlistCnt list of map
     * @return Map or null
     */
    private Map<String,WTList> getLatestIndexMap(ArrayList <Map<String,WTList>> arrlistCnt){
        if (logger.isTraceEnabled())
            logger.trace("IN: getLatestIndexMap, arrlistCnt.size:"+arrlistCnt.size());
        Iterator itr= arrlistCnt.iterator();
        while(itr.hasNext()){
            if (logger.isTraceEnabled())
                logger.trace("IN: arrlistCnt loop");
            Map<String,WTList> map =(Map<String,WTList>)itr.next();
            Iterator<Map.Entry<String,WTList>> mapItr = map.entrySet().iterator();
            int cnt=0;
            while(mapItr.hasNext())
            { 
                Map.Entry<String,WTList> entry =mapItr.next();
                WTList list = entry.getValue();
                cnt += list.size();
                cnt++;//key
            }
            if(cnt<DBProperties.QUERY_BIND_LIMIT){
                if (logger.isTraceEnabled())
                    logger.trace("cnt < QUERY_BIND_LIMIT, map found! cnt:"+cnt);    
                return map;
            }
        }
        return null;
    }

    /**
     * Returns a long array containing non duplicate IDs of all object passed as list.
     * @param list
     * @return long array
     */
    private long[] getLongArray(WTList list){
        if (logger.isTraceEnabled())
            logger.trace("IN:getLongArray ==> list"+list.size());
        WTHashSet noDupIds = new WTHashSet(list);
        long allObjectIdsInLong[] = new long[noDupIds.size()];
        Iterator itr= noDupIds.iterator();
        int cnt=0;
        while(itr.hasNext()) {
            ObjectReference  lcObj = (ObjectReference)itr.next();
            allObjectIdsInLong[cnt] = lcObj.getObjectId().getId();
            cnt++;
        }
        if (logger.isTraceEnabled())
            logger.trace("OUT:getLongArray ==> allObjectIdsInLong"+allObjectIdsInLong.length);
        return allObjectIdsInLong;
    }

    /**
     * puts the objList into suitable map from arrlistPhaseToObjMap (as phaseName:objList), found by calling {@link #getLatestIndexMap}
     * @param arrlistPhaseToObjMap
     * @param phaseName
     * @param objList
     */
    private void putEntryIntoArrayList(ArrayList <Map<String,WTList>> arrlistPhaseToObjMap,String phaseName,WTList objList){
        if (logger.isTraceEnabled())
            logger.trace("IN:putEntryIntoArrayList ==> arrlistPhaseToObjMap"+arrlistPhaseToObjMap.size()+" objList:"+objList.size()+" phaseName"+phaseName);
        Map<String,WTList> map = getLatestIndexMap(arrlistPhaseToObjMap);
        if(map!=null)
            map.put(phaseName, objList);
        else{
            HashMap<String,WTList> mapVal= new HashMap<>();
            mapVal.put(phaseName, objList);
            arrlistPhaseToObjMap.add(mapVal);
        }
        if (logger.isTraceEnabled())
            logger.trace("OUT:putEntryIntoArrayList, arrlistPhaseToObjMap:"+arrlistPhaseToObjMap.size());
    }

    /**
     * In a collection, find a list of all objects that are the result of a
     * Revise, New View Version, New One-Off Version action.  Ignore Sandbox
     * created One-Off versions
     **/
    private WTCollection findRevisedObjects(WTCollection collection) throws WTException {
        if (logger.isTraceEnabled())
            logger.trace("Enter findRevisedObjects - original collection = " + collection.size());

        WTArrayList revisedObjects = new WTArrayList();

        // Check if the Iterated objects have predecessors and if so, are they on the same branch
        // If they aren't, then the objects are relevant for further analysis
        for (Iterator iterator = collection.subCollection(Iterated.class).persistableIterator(); iterator.hasNext(); ) {
            Iterated object = (Iterated) iterator.next();
            if (VersionControlHelper.hasPredecessor(object)) {
                Iterated predecessor = (Iterated) object.getIterationInfo().getPredecessor().getObject();
                if (!VersionControlHelper.inSameBranch(object, predecessor)) {
                    revisedObjects.addElement(object);
                }
            }
        }
        // check for SessionEditedIteration objects
        for (Iterator iterator = revisedObjects.subCollection(SessionEditedIteration.class).persistableIterator(); iterator.hasNext(); ) {
            SessionEditedIteration object = (SessionEditedIteration) iterator.next();
            if (SessionIterationHelper.isSessionIteration(object)) {
                iterator.remove();
            }
        }
        for (Iterator iterator = revisedObjects.subCollection(Workable.class).persistableIterator(); iterator.hasNext(); ) {
            Workable object = (Workable) iterator.next();
            if (WorkInProgressHelper.isWorkingCopy(object)) {
                // checked out workable objects can be discarded
                iterator.remove();
            }
        }
        for (Iterator iterator = revisedObjects.subCollection(OneOffVersioned.class).persistableIterator(); iterator.hasNext(); ) {
            // check if this is a sandbox object
            OneOffVersioned object = (OneOffVersioned) iterator.next();
            if (object instanceof WTContained) {
                Class objContainerClass = ((WTContained) object).getContainerReference().getReferencedClass();
                Iterated predecessor = (Iterated) ((Iterated)object).getIterationInfo().getPredecessor().getObject();
                Class predContainerClass = ((WTContained) predecessor).getContainerReference().getReferencedClass();
                if ( (Project2.class.isAssignableFrom(objContainerClass) && !Project2.class.isAssignableFrom(predContainerClass))
                        || (Project2.class.isAssignableFrom(predContainerClass) && !Project2.class.isAssignableFrom(objContainerClass)) ) {
                    iterator.remove();
                }
            }
        }
        if (logger.isTraceEnabled())
            logger.trace("Exit findRevisedObjects - revisedObjects = " + revisedObjects.size());
        return revisedObjects;
    }

    /*****************
     * Cleanup methods
     *****************/

    private void cleanupCurrentPhase(LifeCycleManaged object,
            Phase current,
            LifeCycleHistory aHistory)
                    throws WTException {

        // -- Move signatures to history & delete the current phase artifacts

        if (logger.isTraceEnabled())
            logger.trace("Enter cleanupCurrentPhase");

        Transaction trx = new Transaction();
        try {
            trx.start();

            /* 1. Move or remove artifacts of this phase */
            removePhaseData(object,current,aHistory);

            /* 2. Delete the phase */
            deleteCurrentPhase(object,current);

            trx.commit();
            trx = null;
        }
        finally {
            if (trx != null)
                trx.rollback();
        }

        if (logger.isTraceEnabled())
            logger.trace("Exit cleanupCurrentPhase");
    }

    private void cleanupCurrentPhases(WTList objects,
            WTList aHistoryList)
                    throws WTException {

        // -- Move signatures to history & delete the current phase artifacts

        if (logger.isTraceEnabled())
            logger.trace("Enter cleanupCurrentPhases");

        Transaction trx = new Transaction();
        try {
            trx.start();

            //first of all, get the objects phases
            WTKeyedMap phaseMap = getPhases(objects);

            /* 1. Move or remove artifacts of this phase */
            removePhaseData(objects,phaseMap,aHistoryList);

            /* 2. Delete the phase */
            deleteCurrentPhases(objects, phaseMap);

            trx.commit();
            trx = null;
        }
        finally {
            if (trx != null)
                trx.rollback();
        }

        if (logger.isTraceEnabled())
            logger.trace("Exit cleanupCurrentPhase");
    }


    private void removePhaseData(LifeCycleManaged object,
            Phase current,
            LifeCycleHistory aHistory)
                    throws WTException {

        // -- Move or remove signatures to history
        // -- Delete the associated work items

        if (logger.isTraceEnabled())
            logger.trace(">>In StandardLifeCycleService...removePhaseData() method");

        /* 1. Move or delete the artifacts of this phase */
        Transaction trx = new Transaction();
        try {
            trx.start();

            /* 1a. Move signature objects to history or delete them */
            cleanupSignatures(object,current,aHistory);

            /* 1b. Move criteria to history or delete them */
            if (current != null) //object is basic, no need to delete criteria
                cleanupCriteria(current,aHistory);

            trx.commit();
            trx = null;
        }
        catch(Exception e)
        {
            if(logger.isDebugEnabled()){
                logger.debug(e.getLocalizedMessage(), e);
            }
        }
        finally {
            if (trx != null)
                trx.rollback();
        }

        if (logger.isTraceEnabled())
            logger.trace(">>In StandardLifeCycleService...removePhaseData() method");
    }

    private void removePhaseData(WTList objects,
            WTKeyedMap phaseMap,
            WTList histories)
                    throws WTException {

        // -- Move or remove signatures to history
        // -- Delete the associated work items

        if (logger.isTraceEnabled())
            logger.trace("Enter removePhaseData");

        /* 1. Move or delete the artifacts of this phase */
        Transaction trx = new Transaction();
        try {
            trx.start();

            /* 1a. Move signature objects to history or delete them */
            cleanupSignatures(objects,phaseMap,histories);

            /* 1b. Move criteria to history or delete them */
            cleanupCriteria(objects,phaseMap,histories);

            trx.commit();
            trx = null;
        }
        finally {
            if (trx != null)
                trx.rollback();
        }

        if (logger.isTraceEnabled())
            logger.trace("Exit removePhaseData");
    }

    private void removePhaseData(Map map)
            throws WTException {

        // -- Remove the phase, criterion and links

        if (logger.isTraceEnabled())
            logger.trace("Enter removePhaseData");

        //First create search conditions for the phase, links and criterion
        long[] phOids=getOidsOfPhases(map);
        if (phOids.length==0)
            return;
        Transaction trx = new Transaction();
        try {
            trx.start();  //where ida2a2 in [oids of phases]
            SearchCondition phases = new SearchCondition(Phase.class,
                    WTAttributeNameIfc.ID_NAME,
                    phOids);

            // where ida3a5 in [oids of phases]
            SearchCondition links = new SearchCondition(CriterionLink.class,
                    WTAttributeNameIfc.ROLEA_OBJECT_ID,
                    phOids);

            // select * from criterion where ida2a2 in (
            // select ida3b5 from criterionlink where ida3a5 in [oids of phases]
            QuerySpec qs = new QuerySpec();
            int index = qs.appendClassList(CriterionLink.class, false);
            qs.appendSelectAttribute(WTAttributeNameIfc.ROLEB_OBJECT_ID, index, false);
            qs.appendWhere(links, new int[]{index});

            ClassAttribute ca = new ClassAttribute(Criterion.class, WTAttributeNameIfc.ID_NAME);
            SearchCondition criterion = new SearchCondition(ca,
                    SearchCondition.IN,
                    new SubSelectExpression(qs));

            //Now delete the objects -- must do in order of criterion, links, phases
            //first criterion
            DeleteBatchSpec dbs = new DeleteBatchSpec(new ClassTableExpression(Criterion.class),
                    criterion);
            PersistenceServerHelper.manager.execute(dbs);
            //removed for performance SPR 1282742 - for Rolex
            /*second links
         dbs = new DeleteBatchSpec(new ClassTableExpression(CriterionLink.class),
                                   links);
         PersistenceServerHelper.manager.execute(dbs);
             */
            //last phases
            dbs = new DeleteBatchSpec(new ClassTableExpression(Phase.class),
                    phases);
            PersistenceServerHelper.manager.execute(dbs);

            //we must also be sure to remove the objects from the phase map.
            Object[] objects = map.keySet().toArray();
            for (int i=0; i < objects.length; i++) {
                WTReference objRef = (WTReference) objects[i];
                Persistable obj = (Persistable)objRef.getObject();
                if(obj instanceof LifeCycleManaged)
                {
                    lifeCycleManagedPhaseMap.remove((LifeCycleManaged)obj);
                }
            }


            trx.commit();
            trx = null;
        }
        catch (WTPropertyVetoException e) {
            throw new WTException (e);
        }
        finally {
            if (trx != null)
                trx.rollback();
        }

        if (logger.isTraceEnabled())
            logger.trace("Exit removePhaseData");
    }

    private void cleanupSignatures(WTList objects,WTKeyedMap phaseMap,WTList histories) throws WTException {
        // -- Move signatures to history or delete them

        if (logger.isTraceEnabled()) {
            logger.trace("Enter cleanupSignatures");
        }

        /* 1. Get the signatures for this phase */
        Map signatureMap = getPhaseSignatures(objects,phaseMap);
        WTCollection links = new WTHashSet(); //Don't know the size

        Transaction trx = new Transaction ();
        try {
            trx.start();
            /* 2. Decide what to do with them */
            if (ENABLE_HISTORY && RETAIN_SIGNATURES) {
                //We need to create the links.
                for (int i=0; i < objects.size(); i++) {
                    LifeCycleManaged object = (LifeCycleManaged)objects.getPersistable(i);
                    LifeCycleHistory history = (LifeCycleHistory)histories.getPersistable(i);
                    //get all the signatures for the object and create the link
                    if (signatureMap != null && signatureMap.get(PersistenceHelper.getObjectIdentifier(object)) != null){
                        List list = (List)signatureMap.get(PersistenceHelper.getObjectIdentifier(object));
                        for (int j=0; j<list.size(); j++) {
                            SignatureHistory sh =
                                    SignatureHistory.newSignatureHistory(history,
                                            (LifeCycleSignature)list.get(j));
                            links.add(sh);
                        }
                    }
                }

                // Now save the links
                PersistenceServerHelper.manager.insert(links);
            }
            else {
                WTSet set = new WTHashSet(); //Don't know the size
                if(signatureMap!=null)
                {
                Object[] signatures = signatureMap.values().toArray();
                for (int i=0; i < signatures.length;i++) {
                    List list = (List) signatures[i];
                    for (int j=0; j< list.size(); j++) {
                        set.add(list.get(j));
                    }
                }
                PersistenceServerHelper.manager.remove(set);
                }
            }
            trx.commit();
            trx=null;
        }
        catch (PersistenceException dbError) {
            throw new WTException(dbError);
        }
        finally {
            if (trx !=null)
                trx.rollback();
        }

        if (logger.isTraceEnabled())
            logger.trace("Exit cleanupSignatures");
    }

    private void cleanupSignatures(LifeCycleManaged object,
            Phase currentPhase,
            LifeCycleHistory aHistory)
                    throws WTException {

        // -- Move signatures to history or delete them

        if (logger.isTraceEnabled()) {
            logger.trace("Enter cleanupSignatures:");
            if (aHistory != null)
                logger.trace(aHistory.getAction());
        }

        /* 1. Get the signatures for this phase */
        Enumeration results = getPhaseSignatures(object,currentPhase);

        /* 2. Decide what to do with them */
        boolean deleteFlag = true;
        if (ENABLE_HISTORY    &&
                RETAIN_SIGNATURES &&
                (aHistory != null)) deleteFlag=false;

        /* 3. Move it or lose it */
        LifeCycleSignature sig = null;
        Transaction trx = new Transaction();
        try {
            trx.start();
            while (results.hasMoreElements()) {
                sig = (LifeCycleSignature)results.nextElement();
                logOrDelete(sig,aHistory,deleteFlag);
            }
            trx.commit();
            trx = null;
        }
        catch (PersistenceException dbError) {
            throw new WTException(dbError);
        }
        finally {
            if (trx !=null)
                trx.rollback();
        }

        if (logger.isTraceEnabled())
            logger.trace("Exit cleanupSignatures");
    }
    private void cleanupCriteria(Phase aPhase, LifeCycleHistory aHistory)
            throws WTException {

        // -- Create CriterionHistory link objects or delete criteria

        if (aPhase==null)  //Object is basic, not criteria to clean up.
            return;
        if (logger.isTraceEnabled()) {
            logger.trace("Enter cleanupCriteria:");
            if (aHistory != null)
                logger.trace(aHistory.getAction());
        }

        /* 1. Get the criteria held by the phase */
        // -- Navigate to from the phase to criteria
        QueryResult results = PersistenceServerHelper.manager.expand(
                aPhase,
                CriterionLink.CRITERIA_ROLE,
                CriterionLink.class,
                true);

        /* 2. Decide what to do */
        boolean deleteFlag = true;
        if (ENABLE_HISTORY  &&
                RETAIN_CRITERIA &&
                (aHistory != null)) deleteFlag=false;

        /* 3. Move it or lose it */
        Criterion cri = null;
        Transaction trx = new Transaction();
        try {
            trx.start();
            while (results.hasMoreElements()) {
                cri = (Criterion)results.nextElement();
                logOrDelete(cri,aHistory,deleteFlag);
            }

            /* 4. Get rid of the Criterion Links always */
            CriterionLink cl = null;
            results = PersistenceServerHelper.manager.expand(
                    aPhase,
                    CriterionLink.CRITERIA_ROLE,
                    CriterionLink.class,
                    false);
            while (results.hasMoreElements()) {
                cl = (CriterionLink)results.nextElement();
                PersistenceServerHelper.manager.remove(cl);
            }

            trx.commit();
            trx = null;
        }
        catch (PersistenceException dbError) {
            throw new WTException(dbError);
        }
        finally {
            if (trx !=null)
                trx.rollback();
        }
        if (logger.isTraceEnabled())
            logger.trace("Exit cleanupCriteria");
    }

    private Map createPhaseCriteriaMap(Object[] phases) throws WTException {
        Map map = new HashMap((int)(phases.length/.75 + 1));
        Map phaseMap = new HashMap((int)(phases.length/.75 + 1));
        long oids[] = new long[phases.length];
        if (oids.length == 0)
            return map;
        for (int i=0; i < phases.length; i++) {
            Phase phase=(Phase)phases[i];
            oids[i] = PersistenceHelper.getObjectIdentifier(phase).getId();
            //Store the phases in a map so we can retrieve it later
            phaseMap.put(PersistenceHelper.getObjectIdentifier(phase),phase);
        }

        //First get all the criterion;
        QuerySpec qs = new QuerySpec();
        qs.appendClassList(Criterion.class, true);
        qs.setAdvancedQueryEnabled(true);
        // select * from criterion where ida2a2 in
        // (select ida3b5 from criterionlink where ida3a5 in (phaseOids));
        QuerySpec subselect = new QuerySpec();
        int ssIdx = subselect.appendClassList(CriterionLink.class, false);
        subselect.appendSelectAttribute(WTAttributeNameIfc.ROLEB_OBJECT_ID, ssIdx, false);
        SearchCondition linkSC = new SearchCondition(CriterionLink.class,
                WTAttributeNameIfc.ROLEA_OBJECT_ID,
                oids);
        subselect.appendSearchCondition(linkSC);
        ClassAttribute ca = new ClassAttribute(Criterion.class, WTAttributeNameIfc.ID_NAME);
        qs.appendSearchCondition(new SearchCondition(ca,
                SearchCondition.IN,
                new SubSelectExpression(subselect)));

        QueryResult results = PersistenceHelper.manager.find(qs);

        //Put the results in a map so we can find them
        Map criterionMap = new HashMap((int)(results.size()/.75+1));
        while (results.hasMoreElements()) {
            Object[] object = (Object[])results.nextElement();
            Criterion criterion = (Criterion)object[0];
            criterionMap.put(PersistenceHelper.getObjectIdentifier(criterion),criterion);
        }

        //Now get all the criteria links;
        qs = new QuerySpec();
        int idx = qs.appendClassList(CriterionLink.class, true);
        qs.appendSearchCondition(linkSC);
        results = PersistenceHelper.manager.find(qs);
        while (results.hasMoreElements()) {
            //Put the criteria and links in a list and map them to the phase;
            Object[] link = (Object[])results.nextElement();
            CriterionLink cLink = (CriterionLink)link[0];
            ObjectIdentifier phOI = (ObjectIdentifier)cLink.getRoleAObjectRef().getKey();
            ObjectIdentifier cOI = (ObjectIdentifier)cLink.getRoleBObjectRef().getKey();
            Phase phase = (Phase)phaseMap.get(phOI);
            Criterion criterion = (Criterion)criterionMap.get(cOI);
            List list = null;
            if (map.get(phase) == null) {
                list = new ArrayList();
                map.put(phase, list);
            }
            else
                list = (List)map.get(phase);
            list.add(criterion);
            list.add(cLink);
        }

        return map;
    }

    private void cleanupCriteria(WTList objects, WTKeyedMap phaseMap, WTList histories)
            throws WTException {

        // -- Create CriterionHistory link objects or delete criteria

        if (logger.isTraceEnabled()) {
            logger.trace("Enter cleanupCriteria:");
        }

        //create map of phase to criteria
        Map phaseCriteriaMap = createPhaseCriteriaMap(phaseMap.values().toArray());
        WTSet criterionLinks = new WTHashSet(); //Don't know the size
        WTSet historyLinks = new WTHashSet(); //Don't know the size
        Transaction trx = new Transaction();
        try {
            trx.start();
            if (ENABLE_HISTORY  && RETAIN_CRITERIA ) {
                for (int i=0;i<objects.size();i++) {
                    LifeCycleManaged object=(LifeCycleManaged)objects.getPersistable(i);
                    LifeCycleHistory history = (LifeCycleHistory)histories.getPersistable(i);
                    if (phaseCriteriaMap.get(object) != null) {
                        List list = (List)phaseCriteriaMap.get(object);
                        for (int j=0;j<list.size();j++) {
                            Criterion criterion = (Criterion)list.get(j++);
                            historyLinks.add(CriterionHistory.newCriterionHistory(history,criterion));
                            criterionLinks.add((CriterionLink)list.get(j));
                        }
                    }
                }
                //Now save the historyLinks and delete the criterionLinks
                PersistenceServerHelper.manager.insert(historyLinks);
                PersistenceServerHelper.manager.remove(criterionLinks);
            }
            else { //Need to delete everything
                    WTSet set = new WTHashSet(); //We don't know the size;
                      for (int i=0;i<objects.size();i++) {
                           LifeCycleManaged object=(LifeCycleManaged)objects.getPersistable(i);
                           if(phaseMap.get(object)!=null)
                           {
                               Phase objectCurrentPhase=(Phase)phaseMap.get(object);
                               List list = (List)phaseCriteriaMap.get(objectCurrentPhase);
                              if(list!=null && !list.isEmpty())
                              {
                               for (int j=0;j<list.size();j++) {
                                   set.add((WTObject)list.get(j));
                               }
                              }
                           }
                      }
                      if(!set.isEmpty())
                      {
                      PersistenceServerHelper.manager.remove(set);
                      }
                }
            trx.commit();
            trx = null;
        }
        catch (PersistenceException dbError) {
            throw new WTException(dbError);
        }
        finally {
            if (trx !=null)
                trx.rollback();
        }
        if (logger.isTraceEnabled())
            logger.trace("Exit cleanupCriteria");
    }

    private void cleanupObjectHistory(Map map)
            throws WTException {

        // -- Remove ObjectHistory artifacts

        if (logger.isTraceEnabled())
            logger.trace("Enter cleanupObjectHistory: Map");

        Transaction trx = new Transaction();
        try {
            trx.start();
            //First get count of objects
            int mycount=findNumberOfTargets(map);
            //get an array of ida values for the oids of the lifecyclehistory
            long[] lchOids = getOidsOfLinks(map, mycount);

            long[] lcmOids = getOidsOfObjects(map);

            /***********
             * delete the signature history and links
             * There may be signatures even though there is no history,
             * so this needs to be done regardless.  this can occur
             * when the object is iterated.
             **********/
            deleteSignatures(lcmOids);



            //now delete the lifecycle history
            if (lchOids.length != 0) {
                //delete the criterion,links
                deleteCriterion(lchOids);

                ClassTableExpression historyCTE = new ClassTableExpression(LifeCycleHistory.class);
                SearchCondition lch = new SearchCondition(LifeCycleHistory.class,
                        WTAttributeNameIfc.ID_NAME,
                        lchOids);
                DeleteBatchSpec deleteBatchSpec = new DeleteBatchSpec(historyCTE, lch);
                PersistenceServerHelper.manager.execute(deleteBatchSpec);
            }

            trx.commit();
            trx = null;
        }
        catch (WTPropertyVetoException wtpve) {
            throw new WTException(wtpve);
        }
        finally {
            if (trx != null)
                trx.rollback();
        }

        if (logger.isTraceEnabled())
            logger.trace("Exit cleanupObjectHistory");
    }

    private int findNumberOfTargets(Map map) throws WTException {
        int mycount=0;
        Object[] objects = map.keySet().toArray();
        for (int i=0; i < objects.length; i++) {
            mycount=mycount + ((List)map.get(objects[i])).size();
        }
        return mycount;
    }

    private long[] getOidsOfLinks(Map map, int mycount) throws WTException {
        long[] lchOids = new long[mycount];
        Object[] objects = map.keySet().toArray();
        int current=0;
        for (int i=0; i < objects.length; i++) {
            List links = (List)map.get(objects[i]);
            for (int j=0; j < links.size(); j++) {
                ObjectHistory oh = (ObjectHistory)links.get(j);
                long aOid=((ObjectIdentifier)oh.getRoleBObjectId()).getId();
                lchOids[current++]=aOid;
            }
        }
        return lchOids;
    }

    private long[] getOidsOfPhases(Map map) throws WTException {
        int linkCount = findNumberOfTargets(map);
        int current = 0;
        long[] phOids = new long[linkCount];
        Object[] objects = map.keySet().toArray();
        for (int i=0; i < objects.length; i++) {
            List links = (List)map.get(objects[i]);
            for (int j=0; j < links.size(); j++) {
                CurrentPhase cpl = (CurrentPhase)links.get(j);
                long aOid=((ObjectIdentifier)cpl.getRoleAObjectId()).getId();
                phOids[current++]=aOid;
            }
        }
        return phOids;
    }

    private long[] getOidsOfObjects(Map map) throws WTException {
        long[] lchOids = new long[map.size()];
        Object[] objects = map.keySet().toArray();
        int current=0;
        for (int i=0; i < objects.length; i++) {
            ObjectReference ref = (ObjectReference)objects[i];
            ObjectIdentifier oid = ref.getObjectId();
            lchOids[current++]=oid.getId();
        }
        return lchOids;
    }

    private long[] getLCMOids(ArrayList _lcmObjs) throws WTException {
        Object[] objs = _lcmObjs.toArray();
        long oids[] = new long [objs.length];

        for (int i = 0; i < objs.length; i++) {
            if(objs[i] instanceof Persistable)
            {
                Persistable managed = (Persistable)objs[i];
                oids[i] = PersistenceHelper.getObjectIdentifier(managed).getId();
            }
        }
        return oids;
    }

    private long[] getLHOids(HashSet setOfAllLHOids){
        Object[] objs = setOfAllLHOids.toArray();
        long[] lhOids = new long[objs.length];
        for(int i = 0 ; i < objs.length ; i++){
            lhOids[i] = ((BigDecimal)objs[i]).longValueExact();
        }

        return lhOids;
    }
    private static void deleteSignatures( long[] lcmOids)
            throws WTException {
        if (logger.isTraceEnabled())
            logger.trace("Entering deleteSignatures");

        Transaction trx = new Transaction();
        try {
            trx.start();
            SearchCondition sc = new SearchCondition(LifeCycleSignature.class,
                    Signable.SIGNED_OBJECT + "." + ObjectReference.KEY + ".id",
                    lcmOids);
            ClassTableExpression cte = new ClassTableExpression(LifeCycleSignature.class);

            //Now delete the signatures  This should include linked and non linked signatures
            DeleteBatchSpec deleteBatchSpec = new DeleteBatchSpec(cte, sc);
            PersistenceServerHelper.manager.execute(deleteBatchSpec);

            trx.commit();
            trx=null;
        }
        catch (WTPropertyVetoException wtpve) {
            if(logger.isDebugEnabled()){
                logger.debug(wtpve.getLocalizedMessage(), wtpve);
            }
            throw new WTException (wtpve);
        }
        finally {
            if (trx!=null)
                trx.rollback();
        }


        if (logger.isTraceEnabled())
            logger.trace("Exiting deleteSignatures");
    }

    private static void deleteCriterion(long[] lchOids)
            throws WTException {
        if (logger.isTraceEnabled())
            logger.trace("Entering deleteCriterion");
        if (lchOids.length == 0)
            return;
        Transaction trx = new Transaction();
        try {
            trx.start();
            // create a search condition to find all the links
            // where ida3a5 in [oids of lifecyclehistory]
            SearchCondition links = new SearchCondition(CriterionHistory.class,
                    WTAttributeNameIfc.ROLEA_OBJECT_ID,
                    lchOids);

            // find criterion
            // where ida2a2 in (select ida3b5 from CriterionHistory where ida3a5 in [oids of lifecyclehistory])
            QuerySpec qs = new QuerySpec();
            int index=qs.appendClassList(CriterionHistory.class, false);
            qs.appendSelectAttribute(WTAttributeNameIfc.ROLEB_OBJECT_ID, index, false);
            qs.appendSearchCondition(links);
            ClassAttribute criterion = new ClassAttribute(Criterion.class, WTAttributeNameIfc.ID_NAME);
            // where ida2a2 in (select ida3b5 from criterionhistory where ida3a5 in [oids of lch])
            SearchCondition sc = new SearchCondition(criterion,
                    SearchCondition.IN,
                    new SubSelectExpression(qs));
            ClassTableExpression cte = new ClassTableExpression(Criterion.class);

            //Now delete the signatures
            DeleteBatchSpec deleteBatchSpec = new DeleteBatchSpec(cte, sc);
            PersistenceServerHelper.manager.execute(deleteBatchSpec);

            trx.commit();
            trx.rollback();
        }
        catch (WTPropertyVetoException wtpve) {
            throw new WTException (wtpve);
        }
        finally {
            if (trx!=null)
                trx.rollback();
        }


        if (logger.isTraceEnabled())
            logger.trace("Exiting deleteCriterion");
    }

    private void deleteCurrentPhase(LifeCycleManaged object,Phase current)
            throws WTException {

        if (logger.isTraceEnabled())
            logger.trace("Enter deleteCurrentPhase");

        if (current == null) //object is basic, not need to clean up phase
            return;

        // -- remove the Current Phase from the LifeCycleManaged object
        if (logger.isTraceEnabled())
            logger.trace("**About to delete the Phase object - clearing the transient phase attribute");
        try {
            object.getState().setPhase(null);
        }
        catch (WTPropertyVetoException e) {
            throw new WTException (e);
        }

        // -- CurentPhase delete - should only be one
        QueryResult results = PersistenceServerHelper.manager.expand(
                object,
                CurrentPhase.PHASE_ROLE,
                wt.lifecycle.CurrentPhase.class,
                false);

        if (logger.isTraceEnabled())
            logger.trace("delete "+results.size()+" CurrentPhase OBJECTS");

        Transaction trx = new Transaction();
        try {
            trx.start();

            CurrentPhase cp = null;
            while (results.hasMoreElements()) {
                cp = (CurrentPhase)results.nextElement();
                PersistenceServerHelper.manager.remove(cp);
            }

            // -- Phase delete
            lifeCycleManagedPhaseMap.remove(object);
            PersistenceServerHelper.manager.remove(current);


            trx.commit();
            trx = null;
        }
        finally {
            if (trx != null)
                trx.rollback();
        }

        if (logger.isTraceEnabled())
            logger.trace("Exit deleteCurrentPhase");
    }

    private void deleteCurrentPhases(WTList objects,WTKeyedMap phaseMap)
            throws WTException {

        if (logger.isTraceEnabled())
            logger.trace(">>In StandardLifeCycleService...deleteCurrentPhases(WTList ,WTList ) method");

        // -- remove the Current Phase from the LifeCycleManaged object
        if (logger.isTraceEnabled())
            logger.trace("**About to delete the Phase object - clearing the transient phase attribute");

        Iterator iterator = phaseMap.wtKeySet().persistableIterator();
        long phaseOids[] = new long[phaseMap.size()];
        int iterated=0;  //used to track how many are iterated to determine which link(s) need to be deleted
        int count=0;
        WTSet phases = new WTHashSet((int)(phaseMap.size()/.75+1));
        while (iterator.hasNext()){
            LifeCycleManaged object = (LifeCycleManaged)iterator.next();
            //set the phase to null
            try {
                object.getState().setPhase(null);
            }
            catch (WTPropertyVetoException e) {
                if(logger.isDebugEnabled()){
                    logger.debug(e.getLocalizedMessage(), e);
                }
                throw new WTException (e);
            }
            //remove the object from the phaseMap
            lifeCycleManagedPhaseMap.remove(object);
            if (logger.isTraceEnabled())
                logger.trace("-- remove the object from the phaseMap - lifeCycleManagedPhaseMap-"+object);

            if (object instanceof Iterated)
                iterated++;

            Object phObject = phaseMap.get(object);
            phases.add(phObject);
            if (phObject instanceof ObjectIdentifier)
                phaseOids[count++]=((ObjectIdentifier)phObject).getId();
            else if (phObject instanceof Phase)
                phaseOids[count++]=PersistenceHelper.getObjectIdentifier((Phase)phObject).getId();

        }
        DeleteBatchSpec iDbs=null;
        DeleteBatchSpec niDbs=null;

        try {
            // Now determine which phase link type(s) need to be removed and
            // create the search condition to use to delete them.
            boolean iteratedOnly = (iterated==phaseMap.size());
            boolean noIterated = (iterated==0);

            if (phaseOids.length > 0 && (iteratedOnly || (!iteratedOnly && !noIterated))) {
                //delete from iterated current phase link where ida3a5 in phaseOids
                SearchCondition sc = new SearchCondition(IteratedCurrentPhaseLink.class,
                        WTAttributeNameIfc.ROLEA_OBJECT_ID,
                        phaseOids);
                ClassTableExpression cte = new ClassTableExpression(IteratedCurrentPhaseLink.class);
                iDbs = new DeleteBatchSpec(cte, sc);
            }
            if (phaseOids.length > 0 && (noIterated || (!iteratedOnly && !noIterated))) {
                //delete from iterated current phase link where ida3a5 in phaseOids
                SearchCondition sc = new SearchCondition(CurrentPhaseLink.class,
                        WTAttributeNameIfc.ROLEA_OBJECT_ID,
                        phaseOids);
                ClassTableExpression cte = new ClassTableExpression(CurrentPhaseLink.class);
                niDbs = new DeleteBatchSpec(cte, sc);
            }
        }
        catch (WTPropertyVetoException wtpve) {
            if(logger.isDebugEnabled()){
                logger.debug(wtpve.getLocalizedMessage(), wtpve);
            }
            throw new WTException(wtpve);
        }

        Transaction trx = new Transaction();
        try {
            trx.start();
            // delete the IteratedCurrentPhaseLinks
            if (iDbs != null)
                PersistenceServerHelper.manager.execute(iDbs);
            // delete the CurrentPhaseLinks
            if (niDbs != null)
                PersistenceServerHelper.manager.execute(niDbs);

            //now delete the phases
            PersistenceServerHelper.manager.remove(phases);


            trx.commit();
            trx = null;
        }
        catch(Exception e)
        {
            if(logger.isDebugEnabled()){
                logger.debug(e.getLocalizedMessage(), e);
            }
        }
        finally {
            if (trx != null)
                trx.rollback();
        }

        if (logger.isTraceEnabled())
            logger.trace(">>Out StandardLifeCycleService...deleteCurrentPhases(WTList ,WTList ) method");
    }


    // -- =================
    // -- WORKFLOW INTEGRATION
    // -- =================
    private Phase initiateGateWorkflow(PhaseTemplate aPhaseTemplate, Phase aPhase, LifeCycleManaged object) throws WTException {
        if (!object.isLifeCycleBasic()) {
            try {
                Gate aGate = aPhase.getGate ();
                if (aGate == null) {
                    aGate = Gate.newGate ();
                }
                WfProcessDefinition aDefinition = null;
                if (!aPhaseTemplate.isFinalPhase ()) {
                    aDefinition = (WfProcessDefinition)aPhaseTemplate.getGateWorkflowId ();
                }
                if (aDefinition == null) {
                    aGate.setWfProcessId (ObjectReference.newObjectReference ());
                }
                else {
                    WfProcess aWfProcess = initiateWorkflow ((WfProcessDefinition) aDefinition, aPhase, object, null);
                    aGate.setWfProcessId (ObjectReference.newObjectReference (aWfProcess));
                }
                aPhase.setGate (aGate);
            }
            catch (WTPropertyVetoException wtpve) {
                throw new LifeCycleException (wtpve);
            }
        }
        return aPhase;
    }

    private Phase initiatePhaseWorkflow (PhaseTemplate aPhaseTemplate,
            Phase aPhase,
            LifeCycleManaged object,
            WTContainerRef context_ref) throws WTException {
        if (!object.isLifeCycleBasic()) {
            try {
                WfProcessDefinition aDefinition = aPhaseTemplate.getPhaseWorkflowId ();
                WfProcess aWfProcess = initiateWorkflow (aDefinition, aPhase, object, context_ref);
                if (aWfProcess == null) {
                    aPhase.setWfProcessId (ObjectReference.newObjectReference ());
                }
                else {
                    aPhase.setWfProcessId (ObjectReference.newObjectReference (aWfProcess));
                }
                Gate aGate = aPhase.getGate ();
                if (aGate != null) {
                    aGate.setWfProcessId (ObjectReference.newObjectReference ());
                    aPhase.setGate (aGate);
                }
            }
            catch (WTPropertyVetoException wtpve) {
                throw new LifeCycleException (wtpve);
            }
        }

        return aPhase;
    }

    @Override
    public void initiatePhaseWorkflow (WTKeyedMap phaseTemplateMap,
            WTKeyedMap phaseMap,
            WTCollection collection) throws WTException {

        if (logger.isTraceEnabled())
            logger.trace("Entering initiatePhaseWorkflow(Map, Map, WTCollection)");

        /*
         * Use WTValuedHashMap because both key and value are Persistable
         * TODO: Change to getInitialCapacity at build 21
         */
        WTValuedHashMap objToWfDefMap = new WTValuedHashMap(collection.size());
        WTKeyedHashMap objToWfNameMap = new WTKeyedHashMap(collection.size());

        LifeCycleManaged object;
        Iterator iterator = collection.persistableIterator();
        while (iterator.hasNext()) {
            object = (LifeCycleManaged)iterator.next();
            if (!object.isLifeCycleBasic()) {
                PhaseTemplate aPhaseTemplate = (PhaseTemplate) phaseTemplateMap.get(object);
                WfProcessDefinition aDefinition = aPhaseTemplate.getPhaseWorkflowId();
                // Don't bother with a null definition.  When assigning to phase map.get()
                // will return null and we can handle this there
                if (aDefinition != null) {
                    aDefinition = (WfProcessDefinition) PersistenceHelper.manager.refresh(aDefinition);
                    objToWfDefMap.put(object, aDefinition);
                    String pName = constructProcessName(aDefinition, object);
                    objToWfNameMap.put(object,pName);
                }
            }
        }

        WTValuedMap objToWfProcessMap = initiateWorkflow((WTValuedMap)objToWfDefMap, objToWfNameMap, collection);

        try {
            iterator = collection.persistableIterator();
            while (iterator.hasNext()) {
                object = (LifeCycleManaged) iterator.next();
                if (!object.isLifeCycleBasic()) {
                    WfProcess aWfProcess = (WfProcess) objToWfProcessMap.getPersistable(object);
                    Phase aPhase = (Phase) phaseMap.get(object);
                    if (aWfProcess == null)
                    {
                        aPhase.setWfProcessId(ObjectReference.newObjectReference());
                    }
                    else {
                        aPhase.setWfProcessId(ObjectReference.newObjectReference (aWfProcess));
                    }
                    Gate aGate = aPhase.getGate();
                    if (aGate != null) {
                        aGate.setWfProcessId(ObjectReference.newObjectReference());
                        aPhase.setGate(aGate);
                    }
                }

            }
        } catch (WTPropertyVetoException wtpve) {
            throw new LifeCycleException (wtpve);
        }
        if (logger.isTraceEnabled())
            logger.trace("Exiting initiatePhaseWorkflow(Map, Map, WTCollection)");

    }

    private WTValuedMap initiateWorkflow (WTValuedMap objToWfDefMap, WTKeyedMap objToWfNameMap, WTCollection collection) throws WTException {
        if (logger.isTraceEnabled())
            logger.trace("=> initiateWorkflow - IN: collection size = " + collection.size() + ", objToWfDefMap size = " + objToWfDefMap.size());
        WTPrincipal administrator = SessionHelper.manager.getAdministrator();
        WTPrincipal previous = SessionContext.setEffectivePrincipal (administrator);
        try {
            //Setting the object and workflow-initiator map in method context, for it to be accessed
            //before creating the processes.
            if(isMultipleReassign && objectWFCreatorMap!=null){
                MethodContext.getContext().put("ReassignMultipleLC",objectWFCreatorMap);
            }
            WTValuedMap objToWfProcessMap = WfEngineHelper.service.createProcesses(objToWfDefMap, objToWfNameMap, collection, true, WORKFLOW_PRIORITY);
            if (objToWfProcessMap.values().size() > 0) {
                if (logger.isTraceEnabled())
                    logger.trace("   initiateworkflow: startProcesses");
                WfEngineHelper.service.startProcesses((WTCollection) objToWfProcessMap.values());
            }
            else {   // This mirrors the legacy behavior of startProcessImmediate if only a single object is in the collection
                for (Iterator setIterator=objToWfProcessMap.entrySet().iterator();setIterator.hasNext(); ) {
                    WTValuedEntry  entry=(WTValuedEntry)setIterator.next();
                    Persistable object = (Persistable) entry.getKeyAsPersistable();
                    WfProcess aWfProcess = (WfProcess) entry.getValueAsPersistable();
                    ProcessData aProcessData = aWfProcess.getContext();
                    String className = object.getClass().getName();
                    if ((START_WF_PROCESS_IMMEDIATE.indexOf(className) >= 0)) {
                        if (logger.isTraceEnabled())
                            logger.trace("   initiateWorkflow: startProcessImmediate");
                        WfEngineHelper.service.startProcessImmediate(aWfProcess, aProcessData, WORKFLOW_PRIORITY);
                    }
                    else {
                        if (logger.isTraceEnabled())
                            logger.trace("   initiateWorkflow: startProcesses");
                        WfEngineHelper.service.startProcesses((WTCollection) objToWfProcessMap.values());
                    }
                }
            }
            if (logger.isTraceEnabled())
                logger.trace("   initiateWorkflow - OUT: objToWfProcessMap size= " + objToWfProcessMap.size());
            return objToWfProcessMap;
        }
        finally {
            SessionContext.setEffectivePrincipal (previous);
        }
    }

    private WfProcess initiateWorkflow (WfProcessDefinition aDefinition,Phase aPhase,LifeCycleManaged object,WTContainerRef context_ref)
            throws WTException {
        WTContainerRef wtccontext_ref = context_ref;
        if (logger.isTraceEnabled())
        {
            logger.trace ("=> initiateWorkflow: " + getOid (object) + ", container = " + getOid (wtccontext_ref));
            logger.trace(">>In StandardLifeCycleService...initiateWorkflow(,WfProcessDefinition, Phase, LifeCycleManaged, WTContainerRef ) method");
        }
        if (wtccontext_ref == null) {
            if (object instanceof WTContained) {
                wtccontext_ref = ((WTContained) object).getContainerReference ();
            }
            if (wtccontext_ref == null) {
                wtccontext_ref = WTContainerHelper.service.getExchangeRef();//WTContainerHelper.service.getClassicRef(); The API getClassicRef() should have been deprecated
            }
        }
        if (aDefinition == null) {
            if (logger.isTraceEnabled())
                logger.trace ("   initiateWorkflow - OUT: null process definition");
            return null;
        }
        WTPrincipal administrator = SessionHelper.manager.getAdministrator ();
        WTPrincipal previous = SessionContext.setEffectivePrincipal (administrator);
        try {
            WfProcessTemplate aWfProcessTemplate = null;
            //Setting the object and workflow-initiator map in method context, for it to be accessed
            //before creating the process.
            if(isMultipleReassign && objectWFCreatorMap!=null){
                MethodContext.getContext().put("ReassignMultipleLC",objectWFCreatorMap);
            }
            //Changed this call to pass the whole LCMO instead of just the
            //TeamRef.  The engine needs for whole LCMO for PBO based Workflow
            //Folders.
            WfProcess aWfProcess = WfEngineHelper.service.createProcess (aDefinition, object, wtccontext_ref);
            // concatenate process name with the related object's identity
            String pName = constructProcessName (aDefinition, object);
            // note - save not needed; the process start will re-persist the process instance
            aWfProcess.setName (pName);
            // -- setup the process team template + team reference
            aWfProcess.setTeamTemplateId(object.getTeamTemplateId());
            ProcessData aProcessData = aWfProcess.getContext ();
            aProcessData.setValue (PRIMARY_BUSINESS_OBJECT, object);
            //-- get the current object's class name and strip off the 'class ' prefix
            String className = object.getClass ().getName ();
            if ((START_WF_PROCESS_IMMEDIATE.indexOf (className) >= 0)) {
                if (logger.isTraceEnabled())
                    logger.trace ("   Initiating startProcessImmediate");
                WfEngineHelper.service.startProcessImmediate (aWfProcess, aProcessData, WORKFLOW_PRIORITY);
            }
            else {
                if (logger.isTraceEnabled())
                    logger.trace ("   Initiating startProcess");
                WfEngineHelper.service.startProcess (aWfProcess, aProcessData, WORKFLOW_PRIORITY);
            }
            if (logger.isTraceEnabled()){
                logger.trace ("   initiateWorkflow - OUT: " + getOid (aWfProcess) + ", container = " + aWfProcess.getContainerReference ());
                logger.trace(">>Out StandardLifeCycleService...initiateWorkflow(,WfProcessDefinition, Phase, LifeCycleManaged, WTContainerRef ) method");
            }
            return aWfProcess;
        }
        catch (WTPropertyVetoException pve) {
            if(logger.isDebugEnabled()){
                logger.debug(pve.getLocalizedMessage(), pve);
            }
            throw new WTException(pve);
        }
        finally {
            SessionContext.setEffectivePrincipal (previous);
        }
    }

    private LifeCycleSignature createRobotLifeCycleSignature(WTObject object, Role role) throws WTException {

        boolean approved = true;
        String signatureText = WTMessage.getLocalizedMessage(
                RESOURCE,
                lifecycleResource.ROBOT_SIGNATURE_TEXT,
                null);
        LifeCycleSignature lifeCycleSignature = createLifeCycleSignature(object,
                SessionHelper.manager.getPrincipal(),
                signatureText,
                role,
                approved);

        return lifeCycleSignature;
    }

    public QueryResult whereUsed( WfProcess process)
            throws WTException, LifeCycleException {

        if (logger.isTraceEnabled())
            logger.trace("Enter whereUsed by WfProcess: " + process.getName() + " " + PersistenceHelper.getObjectIdentifier(process).toString());

        QuerySpec qs = new QuerySpec(Phase.class);
        qs.appendOpenParen();
        SearchCondition sc = new SearchCondition(
                Phase.class,
                Phase.WF_PROCESS_ID+ "." + ObjectReference.KEY,
                SearchCondition.EQUAL,
                PersistenceHelper.getObjectIdentifier(process));
        qs.appendWhere(sc);
        qs.appendCloseParen();

        qs.appendOr();

        qs.appendOpenParen();
        SearchCondition sc1 = new SearchCondition(
                Phase.class,
                Phase.GATE+ "." +Gate.WF_PROCESS_ID+ "." +ObjectReference.KEY,
                SearchCondition.EQUAL,
                PersistenceHelper.getObjectIdentifier(process));
        qs.appendWhere(sc1);
        qs.appendCloseParen();

        QueryResult results = PersistenceServerHelper.manager.query(qs);

        if (logger.isTraceEnabled())
            logger.trace("Found "+results.size()+" Phase Objects");

        if (logger.isTraceEnabled())
            logger.trace("Exit whereUsed");

        return (results);
    }

    /*
     ** Constructs a process name by concatenating process name, "_", and the
     ** object's identity to a maximum number of characters.  This keeps us from
     ** seeing a lot of processes all named the same (e.g. 'Submit').
     */
    private String constructProcessName(WfProcessDefinition aPT, LifeCycleManaged obj)
            throws WTException {

        String pName = aPT.getName()+"_"+IdentityFactory.getDisplayIdentifier(obj);
        if (logger.isTraceEnabled())
            logger.trace("Process name :: " + pName); //Submit_0000000282 -TESTPART A.1 (Design)

        // SPR 1996267: The code below is to construct the process name for CAPA Workflows.
        try
        {
            Class dummyCapaRequest= obj.getClass();
            if(dummyCapaRequest.toString().equals("class com.ptc.qualitymanagement.capa.request.CAPAChangeRequest"))
            {
                java.lang.reflect.Method mm=dummyCapaRequest.getMethod("getRequestKey", new Class[] {});
                String objName= (String) mm.invoke(obj, new Object[0]);
                pName= aPT.getName()+" - "+ objName ;
            }
            else if(dummyCapaRequest.toString().equals("class com.ptc.qualitymanagement.capa.plan.CAPAChangeActivity")){
                java.lang.reflect.Method mm=dummyCapaRequest.getMethod("getActionPlanRef", new Class[] {});
                String objName= (String) mm.invoke(obj, new Object[0]);
                pName= aPT.getName()+" - "+ objName ;
            }
        }catch (Exception e){
            logger.error("StandardLifeCycleService: Unable to get the key for CAPARequest or CAPAPlan \n");
        }

        // check for name length overflow and adjust if necessary
        ClassInfo class_info = WTIntrospector.getClassInfo(wt.workflow.engine.WfExecutionObject.class);
        int length = ((Integer) (class_info.getReadPropertyDescriptor(wt.workflow.engine.WfExecutionObject.NAME)).getValue(wt.introspection.WTIntrospector.UPPER_LIMIT)).intValue();

        if ( !PersistenceHelper.checkStoredLength(pName, length)) {
            // shorten name to max length
            pName = PersistenceHelper.truncateStoredLength(pName, length);
        }
        return pName;
    }

    private void terminateProcesses(Enumeration enumer) throws WTException {
        if (logger.isTraceEnabled())
            logger.trace("End terminateWorkflows");
        final boolean debugEnabled = logger.isDebugEnabled();
        while (enumer.hasMoreElements()) {
            WfProcess aWfProcess = (WfProcess)enumer.nextElement();
            if (logger.isTraceEnabled())
                logger.trace("Terminating " +aWfProcess.getName() + " workflow.  Workflow state was " + aWfProcess.getState().toString());
            WfEngineServerHelper.service.queueStateChange(aWfProcess, WfTransition.TERMINATE, false, true);
        }
        if (logger.isTraceEnabled())
            logger.trace("End terminateWorkflows");
    }

    private void terminateProcesses(List processList) throws WTException {
        if (logger.isTraceEnabled())
            logger.trace("End terminateWorkflows");
        final boolean debugEnabled = logger.isDebugEnabled();
        WfProcess aWfProcess=null;
        for(Iterator itr=processList.iterator();itr.hasNext();)
        {
            Object objRef=itr.next();
            if(objRef instanceof WfProcessReference)
            {
                WfProcessReference aWfProcessRef = (WfProcessReference)objRef;
                aWfProcess = (WfProcess)aWfProcessRef.getObject();
            }else if(objRef instanceof WfProcess)
            {
                aWfProcess=(WfProcess)objRef;
            }

            if (logger.isTraceEnabled())
                logger.trace("Terminating " +aWfProcess.getName() + " workflow.  Workflow state was " + aWfProcess.getState().toString());
            WfEngineServerHelper.service.queueStateChange(aWfProcess, WfTransition.TERMINATE, false, true);
        }
        if (logger.isTraceEnabled())
            logger.trace("End terminateWorkflows");
    }



    //-----------------------
    //  Phase related processing
    //-----------------------
    private LifeCycleManaged getLifeCycleManaged(Phase phase )
            throws WTException,LifeCycleException {

        if (logger.isTraceEnabled())
            logger.trace("Enter getLifeCycleManaged");

        LifeCycleManaged lcmd = null;

        QueryResult results = PersistenceServerHelper.manager.expand(
                phase,
                CurrentPhase.LIFE_CYCLE_MANAGED_ROLE,
                wt.lifecycle.CurrentPhase.class,
                true);

        if (logger.isTraceEnabled())
            logger.trace("Found "+results.size()+" LifeCycleManaged OBJECTS");

        // in theory, should only find 1 object
        if (results.hasMoreElements()) {
            lcmd = (LifeCycleManaged)results.nextElement();
        }

        if (logger.isTraceEnabled())
            logger.trace("Exit getLifeCycleManaged");

        return (lcmd);
    }


    //-----------------------
    //  State related methods
    //-----------------------

    private PhaseTemplate validateState( LifeCycleManaged object, State aState )
            throws WTException,LifeCycleException {

        if (logger.isTraceEnabled()){
            logger.trace("StandardLifeCycleService : validateState(LifeCycleManaged object, State aState ) IN ...");
            logger.trace("object :: "+ object);
            logger.trace("aState :: "+ aState);
        }

        LifeCycleTemplate aTemplate = null;
        PhaseTemplate pt =null;
        boolean foundit = false;
        boolean origEnforce= false;
        LifeCycleException lcExcep=null;

        try{
            origEnforce = SessionServerHelper.manager.setAccessEnforced(false);
            aTemplate = (LifeCycleTemplate)object.getLifeCycleTemplate().getObject();
        }
        finally{
            SessionServerHelper.manager.setAccessEnforced(origEnforce);
        }
        pt = stateSearch(aTemplate,aState);
        if (logger.isTraceEnabled()){
            logger.trace("searched state - pt :: "+ pt);
        }
        if (pt == null) {
            Object[] param = { IdentityFactory.getDisplayIdentity(object), aState.getDisplay(), aTemplate.getName() };
            lcExcep=new LifeCycleException(RESOURCE,lifecycleResource.INVALID_STATE, param);

            if(logger.isDebugEnabled()){
                logger.debug(lcExcep.getLocalizedMessage(), lcExcep);
            }
            throw lcExcep;
        }
        if (logger.isTraceEnabled())
            logger.trace("StandardLifeCycleService : validateState(LifeCycleManaged object, State aState ) OUT... " + pt);
        return pt;
    }

    /******
     * This API validates the state of each object in the collection and puts it's nextPhaseTemplate
     * in a map to return to the caller.
     *
     * @param collection  a collection of lifecycle managed objects
     * @param aState      a state to apply to all objects in a collection
     * @param map         a map that contains all the states in a collection
     *
     * if aState is not null, all objects will be set to that state, otherwise
     * the map will be used.
     */

    private WTKeyedMap validateState( WTCollection collection, State aState, Map stateMap )
            throws WTException,LifeCycleException {

        WTKeyedMap map = new WTKeyedHashMap((int)(collection.size()/.75+1));
        LifeCycleTemplate aTemplate = null;
        PhaseTemplate pt =null;
        WTCollection invalidObjects = new WTArrayList();
        WTCollection templates = new WTArrayList();
        //Iterate through each of the objects and validate the state
        Iterator iterator=collection.persistableIterator();
        boolean origEnforce = false;
        while (iterator.hasNext()) {
            LifeCycleManaged object = (LifeCycleManaged)iterator.next();
            try{
                origEnforce = SessionServerHelper.manager.setAccessEnforced(false);
                aTemplate = (LifeCycleTemplate)object.getLifeCycleTemplate().getObject();
            }
            finally{
                SessionServerHelper.manager.setAccessEnforced(origEnforce);
            }
            if (aState != null)
                pt = stateSearch(aTemplate,aState);
            else
                pt = stateSearch(aTemplate, (State)stateMap.get(object));
            if (pt == null) {
                invalidObjects.add(object);
                templates.add(aTemplate);
            }
            else {
                map.put(object, pt);
            }
        }

        if (invalidObjects.size() > 0) {
            WTMessage[] messages = WTMessage.getMessages(RESOURCE, lifecycleResource.INVALID_STATE,
                    new Object[] {IdentityFactory.getDisplayIdentities(invalidObjects), aState, IdentityFactory.getDisplayIdentities(templates) });
            throw new WTException (messages);
        }

        return map;
    }

    private PhaseTemplate validateState( LifeCycleManaged object, int aStateOrdinal)
            throws WTException,LifeCycleException {

        LifeCycleTemplate aTemplate = null;
        PhaseTemplate pt = null;
        int i = 0;

        aTemplate = getLifeCycleTemplate(object);
        pt = getInitialPhase(aTemplate);
        for (i = 0; i < aStateOrdinal; i++)
        { pt = getSuccessorPhase(pt);}

        if (i != aStateOrdinal) {
            Object[] param = { IdentityFactory.getDisplayIdentity(object), Integer.toBinaryString(aStateOrdinal), aTemplate.getName() };
            throw new LifeCycleException(RESOURCE,lifecycleResource.INVALID_STATE, param);
        }

        return pt;
    }

    private PhaseTemplate stateSearch(LifeCycleTemplate aTemplate, State aState)
            throws QueryException, WTException{
        if (logger.isTraceEnabled())
            logger.trace (" stateSearch : IN...  aTemplate :: " + aTemplate  + " :  aState :: "+ aState );
        // Shital: 2083411 - aState is null in case of airbus change request.
        if(aState == null)
            return null;
        boolean foundit = false;
        PhaseTemplate pt = null;
        Enumeration results = getPhaseTemplates(aTemplate).elements();
        while(results.hasMoreElements()){
            pt = (PhaseTemplate)results.nextElement();
            if (logger.isTraceEnabled()){
                logger.trace (" pt.getPhaseState().toString() :: "+ pt.getPhaseState().toString() );
                logger.trace (" aState.toString() :: "+ aState.toString() );
            }
            if (pt.getPhaseState().toString().equals(aState.toString())){
                foundit = true;
                break;
            }
        }
        if (logger.isTraceEnabled())
            logger.trace (" foundit :: " + foundit);

        if (foundit)
            return pt;
        else
            return null;

    }


    /*********************
     * Adhoc ACL methods *
     *********************/
    private void buildAdHocAcl(List objects, List membershipList, Map phaseTemplates) throws WTException {

        if (logger.isTraceEnabled())
            logger.trace("Entering buildAdHocAcl(List, List, Map");
        Object object;
        List specs = new ArrayList(objects.size());

        //First create the list of adHocAclSpecs
        AdHocAclSpec emptyAdhocacl = AdHocAclSpec.newAdHocAclSpec();
        for (int i=0;i < objects.size();i++) {
            WTCollection aCollection = (WTCollection)objects.get(i);
            Iterator iterator = aCollection.persistableIterator();
            if (iterator.hasNext()) {
                object = (Object)iterator.next();
                PhaseTemplate template = (PhaseTemplate)phaseTemplates.get(object);
                AdHocAclSpec adhoc = getAdHocAclSpec(template);
                if(adhoc != null)
                {
                    specs.add(adhoc);
                }
                /**
                 * SPR # 1426087 : Ad hoc accesses granted through Life Cycle are retained when the state
                 * of an object is changed and target state does not have any role.
                 */
                else
                    specs.add(emptyAdhocacl);
            }
        }

        if(!specs.isEmpty()){
            //Now set the permissions - need to bypass access to do so.
            boolean saveEnforced = SessionServerHelper.manager.setAccessEnforced( false );
            try {
                AccessControlServerHelper.manager.setPermissions(objects, specs,
                        membershipList, AdHocAccessKey.WNC_LIFECYCLE);
            }
            finally {
                SessionServerHelper.manager.setAccessEnforced( saveEnforced );
            }
        }
    }

    private void buildAdHocAcl(LifeCycleManaged object,
            Phase aPhase) throws WTException {

        if (logger.isTraceEnabled())
            logger.trace("Enter the buildAdHocAcl(LifeCycleManaged,Phase) method");
        if(aPhase!=null && aPhase.getPhaseTemplateId()!=null)
        {
            PhaseTemplate pt = (PhaseTemplate)aPhase.getPhaseTemplateId().getObject();
            buildAdHocAcl(object, pt);
        }
        if (logger.isTraceEnabled())
            logger.trace("Exit the buildAdHocAcl(LifeCycleManaged,Phase) method");
    }

    private void buildAdHocAcl(LifeCycleManaged object,
            PhaseTemplate pt) throws WTException {

        if (logger.isTraceEnabled())
            logger.trace("Enter the buildAdHocAcl(LifeCycleManaged,PhaseTemplate) method");

        WTCollection collection = new WTArrayList(1);
        collection.add(object);
        applyLifeCyclePermissions(collection, true);

        if (logger.isTraceEnabled())
            logger.trace("Exit the buildAdHocAcl(LifeCycleManaged,PhaseTemplate) method");

    }

    /*********************
     *   Caching methods *
     *********************/

    private AdHocAclSpec getAdHocAclSpec (PhaseTemplate pt) throws WTException {
        if (logger.isTraceEnabled())
            logger.trace("Entering getAdHocAclSpec");
        AdHocAclSpec ahas = null;
        boolean saveEnforced = SessionServerHelper.manager.setAccessEnforced( false );
        try {
            //-Check the cache first
            ahas = (AdHocAclSpec)getAdHocAclSpecCache().get(PersistenceHelper.getObjectIdentifier(pt));
            if (ahas != null) {
                if (logger.isTraceEnabled())
                    logger.trace ("AdHocAclSpecCache:  " +pt.getName()+ " found in cache.  AdHocAclSpec = " +ahas.toString());
            }
            else {
                if (logger.isTraceEnabled())
                    logger.trace ("AdHocAclSpecCache: " +pt.getName()+ " not found in cache, checking db....");

                //--If not found in the cache, go get it from the database
                QueryResult results = PersistenceServerHelper.manager.expand(
                        pt,
                        AdHocAclLink.ACL_SPEC_ROLE,
                        AdHocAclLink.class,
                        true);
                if (logger.isTraceEnabled())
                    logger.trace("Found " + results.size() + " AdHocAclSpec objects");

                if (results.hasMoreElements())    // In theory, there should only be 1 AdHocAclSpec per PhaseTemplate
                    ahas = (AdHocAclSpec) results.nextElement();
                if (ahas != null) {
                    getAdHocAclSpecCache().put(PersistenceHelper.getObjectIdentifier(pt), ahas);
                    if (logger.isTraceEnabled())
                        logger.trace("AdHocAclSpecCache:  Added " +pt.getName() + " + " +ahas.toString());
                }
            }
        }
        finally {
            SessionServerHelper.manager.setAccessEnforced( saveEnforced );
        }


        if (logger.isTraceEnabled())
            logger.trace("Exiting getAdHocAclSpec");
        return ahas;
    }

    protected InitialPhaseCache getInitialPhaseCache() {
        if (initialPhaseCache == null) {
            try {
                initialPhaseCache = new InitialPhaseCache ();
            }
            catch (RemoteException e) {
                // -- Fatal - throw as method server exception.
                if(logger.isDebugEnabled()){
                    logger.debug(e.getLocalizedMessage(), e);
                }
                throw new MethodServerException ("Unable to create InitialPhaseCache", e);
            }
        }
        return initialPhaseCache;
    }

    protected LifeCycleTemplateCache getLifeCycleTemplateCache() {
        if (lifeCycleTemplateCache == null) {
            try {
                lifeCycleTemplateCache = new LifeCycleTemplateCache ();
            }
            catch (RemoteException e) {
                // -- Fatal - throw as method server exception.
                if(logger.isDebugEnabled()){
                    logger.debug(e.getLocalizedMessage(), e);
                }
                throw new MethodServerException ("Unable to create LifeCycleTemplateCache", e);
            }
        }
        return lifeCycleTemplateCache;
    }
    protected AdHocAclSpecCache getAdHocAclSpecCache() {
        if (adHocAclSpecCache == null) {
            try {
                adHocAclSpecCache = new AdHocAclSpecCache ();
            }
            catch (RemoteException e) {
                // -- Fatal - throw as method server exception.
                if(logger.isDebugEnabled()){
                    logger.debug(e.getLocalizedMessage(), e);
                }
                throw new MethodServerException ("Unable to create AdHocAclSpecCache", e);
            }
        }
        return adHocAclSpecCache;
    }
    protected CriterionCache getCriterionCache() {
        if (criterionCache == null) {
            try {
                criterionCache = new CriterionCache ();
            }
            catch (RemoteException e) {
                if(logger.isDebugEnabled()){
                    logger.debug(e.getLocalizedMessage(), e);
                }
                // -- Fatal - throw as method server exception.
                throw new MethodServerException ("Unable to create CriterionCache", e);
            }
        }
        return criterionCache;
    }
    protected static LifeCycleTemplateNameCache getLifeCycleTemplateNameCache() {
        if (lifeCycleTemplateNameCache == null) {
            createLifeCycleTemplateNameCache();
        }
        return lifeCycleTemplateNameCache;
    }

    private static synchronized void createLifeCycleTemplateNameCache() {
        if (lifeCycleTemplateNameCache == null) {
            try {
                lifeCycleTemplateNameCache = new LifeCycleTemplateNameCache();
            }
            catch (RemoteException e) {
                if(logger.isDebugEnabled()){
                    logger.debug(e.getLocalizedMessage(), e);
                }
                //  -- Fatal - throw as method server exception.
                throw new MethodServerException("Unable to create LifeCycleTemplateNameCache", e);
            }
        }
    }

    protected LifeCycleTemplateMasterCache getLifeCycleTemplateMasterCache()
    {
        if (lifeCycleTemplateMasterCache == null) {
            try {
                lifeCycleTemplateMasterCache = new LifeCycleTemplateMasterCache ();
            }
            catch (RemoteException e) {
                // -- Fatal - throw as method server exception.
                throw new MethodServerException ("Unable to create LifeCycleTemplateMasterCache", e);
            }
        }
        return lifeCycleTemplateMasterCache;
    }

    protected PhaseTemplateCache getPhaseTemplateCache() {
        if (phaseTemplateCache == null) {
            try {
                phaseTemplateCache = new PhaseTemplateCache ();
            }
            catch (RemoteException e) {
                if(logger.isDebugEnabled()){
                    logger.debug(e.getLocalizedMessage(), e);
                }
                // -- Fatal - throw as method server exception.
                throw new MethodServerException ("Unable to create PhaseTemplateCache", e);
            }
        }
        return phaseTemplateCache;
    }

    /*************
     * Utilities *
     *************/

    private boolean isInitialPhase( PhaseTemplate currentPT ) throws WTException {
        // Return 'true' if it has no predecessor
        return (getPredecessorPhase(currentPT) == null);
    }

    private String getStringOfObjectIdentities(QueryResult qr )
            throws WTException,LifeCycleException {

        String listOfObjects = " ";
        int count = 0;

        while (qr.hasMoreElements()) {
            Persistable obj = (Persistable)qr.nextElement();
            count = count + 1;
            if (count > 1)
                listOfObjects += WTMessage.getLocalizedMessage(RESOURCE,lifecycleResource.IDENTITY_STRING_DELIMITER,null);
            listOfObjects += IdentityFactory.getDisplayIdentity(obj);
        }

        return listOfObjects;
    }
    private String getStringOfPhaseTemplates(QueryResult qr )
            throws WTException,LifeCycleException {

        String listOfObjects = " ";
        int count = 0;

        while (qr.hasMoreElements()) {
            PhaseTemplate pt = (PhaseTemplate)qr.nextElement();
            count = count + 1;
            if (count > 1)
                listOfObjects += WTMessage.getLocalizedMessage(RESOURCE,lifecycleResource.IDENTITY_STRING_DELIMITER,null);
            listOfObjects += IdentityFactory.getDisplayIdentifier(getLifeCycleTemplate(pt)) + ": " + (pt.getPhaseState()).getDisplay();
        }

        return listOfObjects;
    }


    private boolean userIsARolePlayer( WTRoleHolder2 roleHolder, WTUser user, Role role )
            throws WTException,LifeCycleException {

        if (logger.isTraceEnabled())
            logger.trace("Enter userIsARolePlayer:"+user.getName()+" is a "+role.toString());

        boolean answer = false;

        /* 1. Look first for user designated for the role
         *
         *    The Phase's role principal map holds a vector of principal
         *    references keyed by role name.
         */
        WTPrincipalReference uRef = WTPrincipalReference.newWTPrincipalReference(user);
        Vector vp = new Vector();
        Enumeration principals=roleHolder.getPrincipalTarget(role);
        while(principals.hasMoreElements()) {
            vp.addElement(principals.nextElement());
        }
        if (vp != null) {
            if (vp.contains(uRef)) {
                answer = true;
            }

            /* 2. Not designated as user, need to search groups */
            else {
                answer = isGroupMember(user,vp);
            }
        }

        if (logger.isTraceEnabled())
            logger.trace("Exit userIsARolePlayer:"+answer);

        return answer;
    }

    private boolean isGroupMember(WTUser user,Vector vp)
            throws WTException {

        // -- Vector is assumed to hold a set of WTPrincipalReferences

        boolean answer = false;

        /* 1. Find the group components of the vector and test membership */
        Enumeration e = vp.elements();
        WTPrincipalReference pRef = null;
        WTPrincipal p = null;
        while (e.hasMoreElements()) {
            pRef = (WTPrincipalReference)e.nextElement();
            p = (WTPrincipal)pRef.getObject();
            if (p instanceof WTGroup) {
                if (((WTGroup)p).isMember(user)) {
                    answer = true;
                    break;
                }
            }
        }

        return answer;
    }


    /**
     * Determine if a Persistable object should be life cycle managed
     * <pre>
     * 1. Working copies are not managed
     * </pre>
     * @param object  the life cycle managed object
     * @param calledFromPreStore  boolean flag to identify calling method
     * @return boolean
     * @exception wt.util.WTException
     **/
    private WTCollection shouldBeManaged(WTCollection collection, boolean calledFromPreStore)
            throws WTException {

        if (logger.isTraceEnabled())
            logger.trace("===> Entering shouldBeManaged(WTCollection): " + collection.size());

        /******************
         *
         * Create a returnCollection for all the objects that should be managed.
         */
        WTCollection returnCollection = new WTArrayList(collection.size());

        // -- SB checkins are not managed
        Boolean sbCiContext = (Boolean) Transaction.getGlobalMap().get(SB_CHECKIN_KEY);
        WTCollection sbCheckinObjects = null;

        if ((sbCiContext != null) && (sbCiContext.booleanValue()))
            sbCheckinObjects = (WTCollection) Transaction.getGlobalMap().get(MERGE_TARGET_KEY);

        if ((sbCheckinObjects != null) && sbCheckinObjects.containsAll(collection.persistableCollection()) && collection.containsAll(sbCheckinObjects.persistableCollection())) {
            if (logger.isTraceEnabled())
                logger.trace("These objects are not lifecycle managed.  They are sandbox checkins.");
            return returnCollection;
        }

        Iterator iterator=collection.persistableIterator();
        Persistable object;
        final boolean debugEnabled = logger.isDebugEnabled();
        while (iterator.hasNext()) {
            object=(Persistable)iterator.next();
            if (logger.isTraceEnabled())
                logger.trace("===> Calling shouldBeManaged for object: " + object + ", class:" +  object.getClass().getName());
            if (!shouldBeManaged(object, calledFromPreStore)) {
                if (logger.isTraceEnabled())
                    logger.trace("===> Object is not managed.  Removing from collection");
            }
            else {
                if (logger.isTraceEnabled())
                    logger.trace("===> Object is managed, keeeping it.");
                returnCollection.connect(object,collection);
            }
        }

        if (logger.isTraceEnabled())  {
            logger.trace("===> Exiting shouldBeManage(WTCollection): " + returnCollection.size());
            logger.trace("Original collection: " + collection.size());
        }

        return returnCollection;
    }

    private boolean shouldBeManaged(Persistable object, boolean calledFromPreStore)
            throws WTException {

        boolean answer = false;
        if (object instanceof LifeCycleManaged) {
            answer = true;
        }
        // -- Working copies and/or first iterations in a version and/or SB checkins are not managed
        Boolean sbCiContext = (Boolean) Transaction.getGlobalMap().get(SB_CHECKIN_KEY);
        WTCollection sbCheckinObjects = null;

        if ((sbCiContext != null) && (sbCiContext.booleanValue()))
            sbCheckinObjects = (WTCollection) Transaction.getGlobalMap().get(MERGE_TARGET_KEY);

        if ((sbCheckinObjects != null) && sbCheckinObjects.contains(object)) {
            if (logger.isTraceEnabled())
                logger.trace("This objects is not lifecycle managed.  It is a sandbox checkin.");
            answer = false;
        }
        else if (isWorkingCopy(object,false)) {
            if (logger.isTraceEnabled())
                logger.trace("This object is not lifecycle managed.  It is a working copy.");
            answer = false;
        }
        //code after
        else if(calledFromPreStore) {
            if (object instanceof Iterated && !isFirstIteration(object)) {
                if (logger.isTraceEnabled())
                    logger.trace("This object is not lifecycle managed.  It is not a first iteration.");
                if(calledFromPreStore && isApplyACLToNonLatestIter())
                {
                    if (logger.isTraceEnabled())
                        logger.trace("ApplyACLToNonLatestIter flag is set true in this transaction map");
                }
                else
                {
                    answer = false;
                }
            }
        } else if(!calledFromPreStore) {
            if (object instanceof Iterated && !((Iterated)object).isLatestIteration()) {
                if (logger.isTraceEnabled())
                    logger.trace("This object is not lifecycle managed.  It is not a latest iteration.");
                answer = false;
            }
            else if(object instanceof Iterated && !isFirstIteration(object))
            {
            
            	if( isApplyACLToNonLatestIter())
    			{
    				if (logger.isTraceEnabled())
    					logger.trace("ApplyACLToNonLatestIter flag is set true in this transaction map");
    			}
    			else
    			{
    				answer = false;
    			}
            	
            }
            
        }
       
        return answer;
    }


    private boolean isWorkingCopy(Persistable object, boolean ignorePWC)
            throws WTException {

        boolean answer = false;
        if (logger.isTraceEnabled())
            logger.trace(">>In StandardLifeCycleService...isWorkingCopy(Persistable) method");
        if (object instanceof Workable) {
            if (logger.isTraceEnabled())
                logger.trace("--InstanceOf Workable");
            if ((ignorePWC && WorkInProgressHelper.isReservedWorkingCopy((Workable)object)) ||
                (!ignorePWC && WorkInProgressHelper.isWorkingCopy((Workable)object))) {
                answer = true;
            }
        }
        else if (object instanceof SessionEditedIteration) {
            if (logger.isTraceEnabled())
                logger.trace("--InstanceOf SessionEditedIteration");
            if (SessionIterationHelper.isSessionIteration((SessionEditedIteration)object)) {
                answer = true;
            }
        }
        if (logger.isTraceEnabled()){
            logger.trace("--answer"+answer);
            logger.trace(">>out StandardLifeCycleService...isWorkingCopy(Persistable) method");
        }
        return answer;
    }

    private WTCollection isWorkingCopy(WTCollection collection, boolean ignorePWC)
            throws WTException {

        WTCollection workingCopies = new WTHashSet((int)(collection.size()/.75 + 1));
        if (logger.isTraceEnabled())
            logger.trace(">>In StandardLifeCycleService...isWorkingCopy(WTCollection) method");
        Iterator iterator = collection.persistableIterator();
        while (iterator.hasNext()) {
            Persistable object = (Persistable)iterator.next();
            if (isWorkingCopy(object, ignorePWC))
                workingCopies.add(object);
        }
        if (logger.isTraceEnabled())
            logger.trace(">>Out StandardLifeCycleService...isWorkingCopy(WTCollection) method--"+workingCopies.size());
        return workingCopies;
    }

    private boolean isFirstIteration(Persistable object)
            throws WTException {

        boolean answer = false;
        if (object instanceof Iterated) {
            if (VersionControlHelper.service.isFirstIteration((Iterated)object)) {
                answer = true;
            }
        }
        return answer;
    }

    /*
     * A true first iteration on a control branch is an iteration that is
     * FIRST as well as LAST on that branch.
     */
    private boolean isTrueFirstIteration(Persistable object)
            throws WTException {

        boolean answer = false;
        boolean isLast = true;
        if (object instanceof Iterated) {
            Iterated lastIteration = VersionControlHelper.getLatestIteration((Iterated)object, false);
            if(lastIteration != null){
                Persistable lastObj = (Persistable)lastIteration;
                isLast = lastObj.equals(object);
            }
            if (VersionControlHelper.service.isFirstIteration((Iterated)object) && isLast) {
                answer = true;
            }
        }
        return answer;
    }

    private boolean isCheckedOut(Persistable object)
            throws WTException {

        boolean answer = false;
        if (object instanceof Workable) {
            answer=LockHelper.isLocked((Workable)object);
        }
        if (logger.isTraceEnabled())
            logger.trace(">> In StandardLifeCycleService...isCheckedOut() method--"+answer);
        return answer;
    }

    /**
     * TO handle the scenario where in LC is created and not checked in
     * @param lctr
     * @param useLatest
     * @param object
     * @return
     * @throws WTException
     */
    private LifeCycleTemplate validateLifeCycleTemplate(LifeCycleTemplateReference lctr, boolean useLatest,LifeCycleManaged object)throws WTException{

        LifeCycleTemplate lct = null;

        try{
            lct = validateLifeCycleTemplate(lctr,useLatest);
        }catch(WTRuntimeException wte){
            Throwable t = wte.getNestedThrowable();
            if(logger.isDebugEnabled()){
                logger.debug(wte.getLocalizedMessage(), wte);
            }
            if (t instanceof WTRuntimeException) {
                wte = (WTRuntimeException)t;
                t = wte.getNestedThrowable();
            }

            if (!(t instanceof NotAuthorizedException)) {
                throw new WTException(t);
            }
            else {

                /*
               SPR#1337703: As per this spr, we are now throwing exception instead of assigning "Default" LC based on property
                 */
                if(USE_DEFAULT_LC)
                {
                    WTContainerRef context = null;
                    if (object instanceof WTContained) {
                        context = ((WTContained)object).getContainerReference();
                    }
                    lct = getLifeCycleTemplate(DEFAULT_LIFECYCLE,context);
                }
                else
                {
                    throw (new LifeCycleException( RESOURCE, lifecycleResource.NO_VALID_LIFECYCLE, null ));
                }
            }

        }
        return lct;
    }

    private LifeCycleTemplate validateLifeCycleTemplate(LifeCycleTemplateReference lctr, boolean useLatest)
            throws WTException {

        LifeCycleTemplate template = null;

        //---Ensures the Life Cycle Template is Enabled and the Latest Iteration
        LifeCycleTemplate lct = (LifeCycleTemplate)lctr.getReadOnlyObject();

        if (logger.isTraceEnabled()) {
            logger.trace("The assigned Life Cycle Template is " + lctr.getName() + " " + PersistenceHelper.getObjectIdentifier(lctr.getObject()));
            if (isWorkingCopy( lct, false))
                logger.trace("----Warning:  This Life Cycle Template is a Working Copy!!");
        }

        WTPrincipal administrator = SessionHelper.manager.getAdministrator ();
        WTPrincipal previous = SessionContext.setEffectivePrincipal (administrator);
        LifeCycleTemplateMaster currLCTMaster = null;
        try{
            ObjectReference currMasterRef = lct.getMasterReference();
            ObjectIdentifier currMasterObjId = (ObjectIdentifier)currMasterRef.getKey();
            LifeCycleTemplateMasterReference masterRef =
                    LifeCycleTemplateMasterReference.newLifeCycleTemplateMasterReference(currMasterObjId);
            currLCTMaster = (LifeCycleTemplateMaster)masterRef.getReadOnlyObject();//get readonly
        }finally{
            SessionContext.setEffectivePrincipal(previous);
        }

        if (!currLCTMaster.isEnabled())
            throw new LifeCycleException(RESOURCE, lifecycleResource.SELECTED_LCT_NOT_ENABLED, null);

        //We want to assign the newest instead of throwing exception
        if ( useLatest && (!VersionControlHelper.isLatestIteration(lct)) && (!isWorkingCopy(lct, false)) ){
            ObjectReference masterObjRef = (ObjectReference)lct.getMasterReference();
            ObjectIdentifier masterObjId = (ObjectIdentifier)masterObjRef.getKey();
            LifeCycleTemplateMasterReference lctMasterRef = LifeCycleTemplateMasterReference.newLifeCycleTemplateMasterReference(masterObjId);
            template=(LifeCycleTemplate)getLatestIteration(lctMasterRef).getReadOnlyObject();
        }

        return template;

    }

    private void validateIsLatestIteration(LifeCycleManaged object, String action)
            throws WTException {

        if (logger.isTraceEnabled())
            logger.trace(">>In StandardLifeCycleService...validateIsLatestIteration(LifeCycleManaged object, String action) method");
        if (object instanceof Iterated){
            // refresh to a temp copy of the object and check to see if the latest iteration
            if (logger.isTraceEnabled())
                logger.trace("refresh to a temp copy of the object and check to see if the latest iteration");
            LifeCycleManaged myObject = (LifeCycleManaged)PersistenceServerHelper.manager.restore(object);
            if ( !(VersionControlHelper.isLatestIteration((Iterated)myObject)) ) {
                Object[] param = { action };
                LifeCycleException lcExcep=new LifeCycleException(RESOURCE, lifecycleResource.OBJECT_NOT_LATEST_ITERATION, param);
                if(logger.isDebugEnabled()){
                    logger.debug(lcExcep.getLocalizedMessage(), lcExcep);
                }
                throw lcExcep;
            }
        }
        if (logger.isTraceEnabled())
            logger.trace(">>Out StandardLifeCycleService...validateIsLatestIteration(LifeCycleManaged object, String action) method");
        return;
    }

    private void markWorkItemAsComplete (LifeCycleSignature signature, LifeCycleManaged object) throws WTException {
        WTPrincipal principal = OrganizationServicesHelper.manager.getUser(signature.getSignerName());
        Role role = Role.toRole(signature.getRoleName());
        if (logger.isTraceEnabled()){
            logger.trace(">>In StandardLifeCycleService...markWorkItemAsComplete() method");
            logger.trace("--principal:"+principal);
            logger.trace("--role:"+role);
        }
        if (principal != null) {
            WorkflowHelper.service.markWorkItemComplete((Persistable)object,principal,PROMOTE_TASK);
        }
    }

    /*****************************
     * Runtime object management *
     *****************************/

    private Vector replaceCriteria(Phase aPhase, Vector criteria)
            throws WTException {

        Vector answer = new Vector();
        Transaction trx = new Transaction();
        try {
            trx.start();
            for (Enumeration e = criteria.elements();e.hasMoreElements();) {
                Criterion c = (Criterion)e.nextElement();
                if (PersistenceHelper.isPersistent((Persistable)c)) {
                    PersistenceServerHelper.manager.update(c);
                }
                else {
                    PersistenceServerHelper.manager.insert(c);
                    CriterionLink cl = CriterionLink.newCriterionLink(aPhase,c);
                    PersistenceServerHelper.manager.insert(cl);
                }
                answer.addElement(c);
            }
            trx.commit();
            trx = null;
        }
        catch (PersistenceException dbError) {
            if(logger.isDebugEnabled()){
                logger.debug(dbError.getLocalizedMessage(), dbError);
            }
            throw new LifeCycleException(dbError);
        }
        catch (WTException wex) {
            if(logger.isDebugEnabled()){
                logger.debug(wex.getLocalizedMessage(), wex);
            }
            throw wex;
        }
        finally {
            if (trx != null)
                trx.rollback();
        }

        return answer;
    }


    /*******************
     * History support *
     *******************/

    private LifeCycleHistory buildHistory(LifeCycleManaged object,
            Phase aPhase,
            String historyEvent,
            String comments)
                    throws WTException {

        // -- Answer a history object for the specified LifeCycle event
        String phaseName;
        if (logger.isTraceEnabled())
            logger.trace(">>In StandardLifeCycleService...buildHistory() method");
        LifeCycleHistory aHistory = LifeCycleHistory.newLifeCycleHistory();
        try {
            if (aPhase == null)
                phaseName = getPhaseTemplate(object).getName();
            else
                phaseName =  aPhase.getName();

            aHistory.setAction(historyEvent);
            WTPrincipal p = SessionHelper.manager.getPrincipal();
            //Must ensure the name fits in the field.
            String pName=p.getName();
            ClassInfo class_info = WTIntrospector.getClassInfo(wt.lifecycle.LifeCycleHistory.class);
            int length = ((Integer) (class_info.getReadPropertyDescriptor(wt.lifecycle.LifeCycleHistory.ACTOR_NAME)).getValue(wt.introspection.WTIntrospector.UPPER_LIMIT)).intValue();
            if ( !PersistenceHelper.checkStoredLength(pName, length)) {
                // shorten name to max length
                pName = PersistenceHelper.truncateStoredLength(pName, length);
            }
            aHistory.setActorName(pName);
            WTPrincipalReference ref = new WTPrincipalReference();
            ref.setObject(p);
            aHistory.setActorReference(ref);
            aHistory.setState(object.getLifeCycleState());
            aHistory.setLifeCycleName(object.getLifeCycleTemplate().getIdentity());
            aHistory.setPhaseName(phaseName);
            if (logger.isTraceEnabled()){
                logger.trace("::pName::"+pName);
                logger.trace("::State::"+object.getLifeCycleState());
                logger.trace("::Lifecycle Name::"+object.getLifeCycleTemplate().getIdentity());
                logger.trace("::Phase Name::"+phaseName);
                logger.trace("::ActorReference::"+ref);
            }
            if( comments!=null ){
                aHistory.setComments(comments);
            }
            try{
                if (object.getTeamTemplateIdentity() == null)
                    aHistory.setTeamTemplateIdentity(" ");
                else
                    aHistory.setTeamTemplateIdentity(object.getTeamTemplateIdentity());
            }
            //       -- If the user does not have perission to view the TeamTemplate this
            // -- we fail.  In cases where they are granting access to the external
            // -- participants we should simply treat this like there is no team template.
            catch( Exception wte )
            {
                if(logger.isDebugEnabled()){
                    logger.debug(wte.getLocalizedMessage(), wte);
                }
                aHistory.setTeamTemplateIdentity(" ");
            }


        }
        catch (WTPropertyVetoException veto) {
            if(logger.isDebugEnabled()){
                logger.debug(veto.getLocalizedMessage(), veto);
            }
            throw new WTException(veto);
        }
        if (logger.isTraceEnabled())
            logger.trace(">>Out StandardLifeCycleService...buildHistory() method");
        return aHistory;
    }

    private void logOrDelete( LifeCycleSignature aSignature,
            LifeCycleHistory aHistory,
            boolean deleting)
                    throws WTException {

        // -- Create SignatureHistory link objects or delete the signature
        // -- Note: Assumed to be in a transaction

        if (logger.isTraceEnabled())
        {
            logger.trace(">>In StandardLifeCycleService...logOrDelete(LifeCycleSignature ,LifeCycleHistory ,boolean) method");
            logger.trace("Enter logOrDelete:Signature of "+aSignature.getSignerName()+
                    " Delete="+deleting);
        }

        if (deleting) {
            if (logger.isTraceEnabled())
                logger.trace("Delete SignatureHistory link objects");
            PersistenceServerHelper.manager.remove(aSignature);
        }
        else {
            if (logger.isTraceEnabled())
                logger.trace("Create SignatureHistory link objects");
            SignatureHistory sh = SignatureHistory.newSignatureHistory(aHistory,aSignature);
            PersistenceServerHelper.manager.insert(sh);
        }

        if (logger.isTraceEnabled())
            logger.trace(">>Out StandardLifeCycleService...logOrDelete(LifeCycleSignature ,LifeCycleHistory ,boolean) method");

    }

    private void logOrDelete(  Criterion aCriterion,
            LifeCycleHistory aHistory,
            boolean deleting)
                    throws WTException {

        // -- Create CriterionHistory link object or delete the criterion
        // -- Note: Assumed to be in a transaction

        if (logger.isTraceEnabled())
        {
            logger.trace(">>In StandardLifeCycleService...logOrDelete(Criterion ,LifeCycleHistory ,boolean) method");
            logger.trace("Enter logOrDelete:Criterion="+aCriterion.getAssertion()+
                    " Delete="+deleting);
        }

        if (deleting) {
            if (logger.isTraceEnabled())
                logger.trace("Delete CriterionHistory link objects");
            PersistenceServerHelper.manager.remove(aCriterion);
        }
        else {
            if (logger.isTraceEnabled())
                logger.trace("Create CriterionHistory link objects");
            CriterionHistory ch = CriterionHistory.newCriterionHistory(aHistory,aCriterion);
            PersistenceServerHelper.manager.insert(ch);
        }

        if (logger.isTraceEnabled())
            logger.trace(">>Out StandardLifeCycleService...logOrDelete(Criterion ,LifeCycleHistory ,boolean) method");

    }

    // -- =========================
    // -- Support for Augment Roles
    // -- =========================

    private boolean roleContentsChanged(Role aRole, RoleHolder2 prevRoleHolder, RoleHolder2 newRoleHolder)
            throws WTException {

        Enumeration prevPrincipals = prevRoleHolder.getPrincipalTarget(aRole);
        Enumeration newPrincipals = newRoleHolder.getPrincipalTarget(aRole);
        int prevPrincipalsCount = 0;
        int newPrincipalsCount = 0;
        Vector prevP = new Vector();
        Vector newP = new Vector();
        WTPrincipalReference princ = null;

        // -- build vectors for use later and count the number of entries
        while (prevPrincipals.hasMoreElements()) {
            princ =  (WTPrincipalReference) prevPrincipals.nextElement();
            prevP.addElement(princ);
            prevPrincipalsCount++;
        }
        while (newPrincipals.hasMoreElements()) {
            princ =  (WTPrincipalReference) newPrincipals.nextElement();
            prevP.addElement(princ);
            newPrincipalsCount++;
        }

        // -- if the number of entries do not match - you have a change!!
        if (prevPrincipalsCount != newPrincipalsCount)
            return true;

        // -- for each prevPrincipal, look to see if that exists in the newPrincipal group.
        while (prevPrincipals.hasMoreElements()) {
            princ = (WTPrincipalReference) prevPrincipals.nextElement();
            if (!(newP.contains(princ)))
                return true;
        }

        // -- for each newPrincipal, look to see if that exists in the prevPrincipal group.
        while (newPrincipals.hasMoreElements()) {
            princ = (WTPrincipalReference) newPrincipals.nextElement();
            if (!(prevP.contains(princ)))
                return true;
        }

        return false;
    }

    // -- =================
    // -- DEBUG METHODS
    // -- =================

    private LifeCycleTemplate getLifeCycleTemplate(PhaseTemplate pt) throws WTException{
        QueryResult results = PersistenceServerHelper.manager.expand(
                pt,
                PhaseLink.TEMPLATE_ROLE,
                wt.lifecycle.PhaseLink.class,
                true);
        if (logger.isTraceEnabled())
            logger.trace("   getLifeCycleTemplate: found " + results.size() + " LifeCycleTemplate Objects");
        if (!results.hasMoreElements()) {
            return null;
        }
        return (LifeCycleTemplate)results.nextElement();
    }

    private Locale getLocale () throws WTException {
        return SessionHelper.manager.getLocale();
    }

    /**
     * Search for a <code>LifeCycleTemplate</code> with the given name.
     * Look in the classis container.
     */
    private LifeCycleTemplate getLCT(String aTemplateName) throws WTException {
        WTContainerRef context = WTContainerHelper.service.getExchangeRef();//WTContainerHelper.service.getClassicRef(); The API getClassicRef() should have been deprecated
        return getLCT(aTemplateName, context);
    }

    /**
     * Search the specified <code>WTContainer</code> for a
     * <code>LifeCycleTemplate</code> with the given name.
     * The specified <code>WTContainer</code> can be <code>null</code>
     * in which case the global-context is searched.  If a template
     * is not found, <code>null</code> is returned.
     */

    private LifeCycleTemplate getLCT(String aTemplateName,
            WTContainerRef context) throws WTException {
        LifeCycleTemplateNameCache cache = getLifeCycleTemplateNameCache();
        LifeCycleNameKey lkey = new LifeCycleNameKey(aTemplateName, context);
        LifeCycleTemplate aTemplate = (LifeCycleTemplate )cache.get(lkey);
        if (aTemplate != null) {
            return aTemplate;
        }

        LifeCycleTemplateMaster aMaster = findTemplateMasterByName(aTemplateName,
                context);

        if (aMaster != null)
            aTemplate = getLatestIteration(aMaster);
        if (aTemplate != null)
            cache.putEntry(lkey, aTemplate);

        return aTemplate;
    }


    /**
     * This method finds all the Life Cycle Managed objects associated
     * with the team so that the acls can get rebuilt for shared objects.
     */
    private Enumeration findTeamsObjects(Team team) throws WTException {
        QuerySpec qs=new QuerySpec(LifeCycleManaged.class);
        qs.appendWhere(new SearchCondition(LifeCycleManaged.class,
                TeamManaged.TEAM_ID + "." +  ObjectReference.KEY,
                SearchCondition.EQUAL,
                PersistenceHelper.getObjectIdentifier(team)));
        QueryResult results=PersistenceServerHelper.manager.query(qs);
        Vector objects=new Vector();
        while (results.hasMoreElements()) {
            LifeCycleManaged lcm=(LifeCycleManaged)results.nextElement();
            if (lcm instanceof Iterated){
                // Only want the latest iteration of objects.
                lcm = (LifeCycleManaged)PersistenceServerHelper.manager.restore(lcm);
                if ( (VersionControlHelper.isLatestIteration((Iterated)lcm)) ) {
                    objects.addElement(lcm);
                }
            }
            else {
                objects.addElement(lcm);
            }
        }
        return objects.elements();
    }
    private static boolean validateLifeCycleTemplateObjects(LifeCycleTemplate template) throws WTException {
        Enumeration phaseTemplates=LifeCycleHelper.service.getPhaseTemplates((LifeCycleTemplate)template).elements();
        boolean goodToGo=true;
        while (phaseTemplates.hasMoreElements()) {
            PhaseTemplate phaseTemplate =(PhaseTemplate)phaseTemplates.nextElement();
            goodToGo=(validatePhaseTemplateWorklfows(phaseTemplate, (LifeCycleTemplate)(template)) && goodToGo);
            QueryResult results = PersistenceServerHelper.manager.expand(phaseTemplate,
                    AdHocAclLink.ACL_SPEC_ROLE,
                    wt.lifecycle.AdHocAclLink.class,
                    true);
        }
        return goodToGo;
    }

    private static boolean validatePhaseTemplateWorklfows(PhaseTemplate phaseTemplate, LifeCycleTemplate template) throws WTException {
        try {
            WTContainerRef org_container = ((LifeCycleTemplate)template).getContainerReference();
            if (org_container == null) {
                return true;
            }
            String templateOrg = (org_container==null)?null:org_container.getContainer().getName();
            boolean goodToGo=true;
            WfProcessDefinition def=phaseTemplate.getGateWorkflowId();
            boolean saveRequired=false;
            if (def != null && mismatchedOrgs(def, templateOrg))  {
                saveRequired=true;
            }
            //first to the phase workflow
            def=phaseTemplate.getPhaseWorkflowId();
            if (def != null && mismatchedOrgs(def, templateOrg))  {
                WfProcessTemplateMaster master = (WfProcessTemplateMaster)WfDefinerHelper.service.getProcessDefinition(def.getName(), org_container);
                if ( master != null) {
                    saveRequired=true;
                    if (def instanceof WfProcessTemplateMaster)
                        phaseTemplate.setPhaseWorkflowId(master);
                    else
                        phaseTemplate.setPhaseWorkflowId(WfDefinerHelper.service.getLatestIteration(master));
                }
                else goodToGo=false;
            }

            //next do the gate workflowWfProcessTemplateMaster master = (WfProcessTemplateMaster)WfDefinerHelper.service.getProcessDefinition(def.getName(), organization);
            def=phaseTemplate.getGateWorkflowId();
            if (def != null && mismatchedOrgs(def, templateOrg))  {
                WfProcessTemplateMaster master = (WfProcessTemplateMaster)WfDefinerHelper.service.getProcessDefinition(def.getName(), org_container);
                if ( master != null) {
                    saveRequired=true;
                    if (def instanceof WfProcessTemplateMaster)
                        phaseTemplate.setGateWorkflowId(master);
                    else
                        phaseTemplate.setGateWorkflowId(WfDefinerHelper.service.getLatestIteration(master));
                }
                else goodToGo=false;
            }
            if (saveRequired) {
                PersistenceServerHelper.manager.update(phaseTemplate);
            }


            return goodToGo;
        }
        catch (WTPropertyVetoException e) {
            if(logger.isDebugEnabled()){
                logger.debug(e.getLocalizedMessage(), e);
            }
            throw new WTException (e);
        }

    }

    private static boolean mismatchedOrgs(WfProcessDefinition def, String templateOrg) throws WTException {
        String processOrg =null;
        boolean mismatched=false;
        WTContainerRef org_container;
        if (def instanceof WfProcessTemplate) {
            org_container=((WfProcessTemplate)def).getContainerReference();
            processOrg=(org_container==null)?null:org_container.getContainer().getName();
        }
        else {
            Enumeration enumer = ConfigHelper.service.filteredIterationsOf ((WfProcessTemplateMaster)def, new LatestConfigSpec ());
            if (enumer.hasMoreElements ()) {
                org_container=((WfProcessTemplate)enumer.nextElement()).getContainerReference();
                processOrg=(org_container==null)?null:org_container.getContainer().getName();
            }
        }

        if ((templateOrg==null && processOrg != null) || !templateOrg.equals(processOrg))
            mismatched=true;
        return mismatched;
    }


    private static WTContainerRef getOrgContainer(WTContained object)
            throws WTException  {
        WTContainerRef org_container = null;
        if (object != null) {
            org_container = null;//WTContainerHelper.service.getOrgContainer(object);
        }
        return org_container;
    }

    /**
     * Answer the CurrentPhase link for the object
     */
    private Phase getPhase (LifeCycleManaged object) throws WTException {
        if (logger.isTraceEnabled())
        {
            logger.trace(">>In StandardLifeCycleService...getPhase() method");
            logger.trace("=> getPhase: " + getOid (object));
        }

        if (object.isLifeCycleBasic()) {
            if (logger.isTraceEnabled() )
                logger.trace("Object is basic, returning null");
            return null;
        }
        // -- First, check to see if the LifeCycleManaged object has the phase object
        Phase aPhase = object.getState().getPhase();
        if (aPhase != null) {
            if (logger.isTraceEnabled())
                logger.trace("   getPhase - OUT: " + aPhase);
            return aPhase;
        }
        // -- If not, navigate from the object to obtain CurrentPhase link
        QueryResult results = PersistenceServerHelper.manager.expand(
                object,
                CurrentPhase.PHASE_ROLE,
                wt.lifecycle.CurrentPhase.class,
                true);
        if (!results.hasMoreElements ()) {
            if (logger.isTraceEnabled())
                logger.trace("   getPhase - OUT: phase not found, returning null");
            return null;
        }
        aPhase = (Phase) results.nextElement();
        if (logger.isTraceEnabled())
        {
            logger.trace("   getPhase - OUT: " + aPhase);
            logger.trace(">>Out StandardLifeCycleService...getPhase() method");
        }
        return aPhase;
    }

    public WTKeyedMap getCurrentPhases (WTList objects) throws WTException {
        /*
         * This API is a duplicate of getPhases except call to new addIteratedPhaseIdsToMap
         */
        if (logger.isTraceEnabled())
            logger.trace("=> getCurrentPhases: " + objects.size());

        // To be most efficient we need to perform the minimal number of db hits
        // as possible.  To do this, we need to retrieve from the map if possible
        // otherwise return only the required info - to do this, a separate query will
        // be done for iterated and non iterated.
        int size = (int)(objects.size()/.75+1);
        WTKeyedMap map = new WTKeyedHashMap(size);
        Map iterated = new HashMap(size);
        Map nonIterated = new HashMap(size);
        // Separate objects into appropriate buckets.
        putObjectsIntoSearchBuckets(objects, map, iterated, nonIterated);
        long[] phaseOids;
        if(objects.size() == 0)
            phaseOids = new long[1];
        else
            phaseOids = new long[objects.size()];
        // query for and add objects to the map for iterated
        int cnt = addIteratedPhaseIdsToMap(map, iterated, phaseOids, 0, false);
        // query for and add objects to the map for non iterated
        addNonIteratedPhaseIdsToMap(map, nonIterated,phaseOids, cnt);
        //Now query for the phases and add them to the map
        findPhasesAndAddToMap(phaseOids, map);

        if (logger.isTraceEnabled())
            logger.trace("Exiting getCurrentPhases -- map.size is " + map.size());
        return map;
    }

    private WTKeyedMap getPhases (WTList objects) throws WTException {
        if (logger.isTraceEnabled())
            logger.trace("=> getPhases: " );

        // To be most efficient we need to perform the minimal number of db hits
        // as possible.  To do this, we need to retrieve from the map if possible
        // otherwise return only the required info - to do this, a separate query will
        // be done for iterated and non iterated.
        int size = (int)(objects.size()/.75+1);
        WTKeyedMap map = new WTKeyedHashMap(size);
        Map iterated = new HashMap(size);
        Map nonIterated = new HashMap(size);
        // Separate objects into appropriate buckets.
        putObjectsIntoSearchBuckets(objects, map, iterated, nonIterated);
        long[] phaseOids;
        if(objects.size() == 0)
            phaseOids = new long[1];
        else
            phaseOids = new long[objects.size()];
        // query for and add objects to the map for iterated
        int cnt = addIteratedPhaseIdsToMap(map, iterated, phaseOids, 0);
        // query for and add objects to the map for non iterated
        addNonIteratedPhaseIdsToMap(map, nonIterated,phaseOids, cnt);
        //Now query for the phases and add them to the map
        findPhasesAndAddToMap(phaseOids, map);

        if (logger.isTraceEnabled())
            logger.trace("Exiting getPhases -- map.size is " + map.size());
        return map;
    }

    private void findPhasesAndAddToMap(long[] phaseOids, Map map) throws WTException {

        try {
            if (logger.isTraceEnabled())
                logger.trace("=> findPhasesAndAddToMap -- phaseOids.size is " + phaseOids.length + " Values:: " +phaseOids );

            QuerySpec qs = new QuerySpec();
            int idx = qs.appendClassList(Phase.class, true);
            qs.appendSearchCondition(new SearchCondition(Phase.class,
                    WTAttributeNameIfc.ID_NAME,
                    phaseOids));
            QueryResult results = PersistenceHelper.manager.find(qs);
            while(results.hasMoreElements()) {
                Phase phase = (Phase)(((Object[])results.nextElement())[0]);
                LifeCycleManaged object = (LifeCycleManaged)map.remove(PersistenceHelper.getObjectIdentifier(phase));
                if (logger.isTraceEnabled())
                    logger.trace("=> removed the entry :: "+ phase +" from map" );

                map.put(object,phase);

                if (logger.isTraceEnabled())
                    logger.trace("Added new entry key :: "+ object +" value:: "+ phase +" into the phasemap");
            }
        }
        catch (WTException e) {
            if(logger.isDebugEnabled()){
                logger.debug(e.getLocalizedMessage(), e);
            }
            throw  e;
        }
    }

    private long[] addNonIteratedPhaseIdsToMap (WTKeyedMap map, Map nonIterated, long[] phaseOids, int count) throws WTException {
        if (logger.isTraceEnabled()) {
            logger.trace("Entering addNonIteratedPhaseToMap");
            logger.trace("\t number currently in map: " + map.size());
            logger.trace("\t number iterated objects: " + nonIterated.size());       }

        if (nonIterated.isEmpty())
            return phaseOids;

        //select ida3a5, ida3b5 from currentphaselink where ida3b5 in (oids of LCM'd);

        // first get the long values for the oids of the LCM'd
        Object[] lcmd = nonIterated.keySet().toArray();
        long lcmOids[] = new long[lcmd.length];
        for (int i=0; i< lcmd.length; i++) {
            lcmOids[i] = ((Long)lcmd[i]).longValue();
        }

        // Query for the phase oid and branch id oids in the IteratedCurrentPhaseLinks
        // select ida3a5, branchida3b5 from iteratedcurrentphaselink
        QuerySpec qs = new QuerySpec();
        int index = qs.appendClassList(CurrentPhaseLink.class, false);
        qs.appendSelectAttribute(WTAttributeNameIfc.ROLEA_OBJECT_ID, index, false);
        qs.appendSelectAttribute(WTAttributeNameIfc.ROLEB_OBJECT_ID, index, false);

        //where branchida3b5 in [ida3b5 oids of control branch}
        //ClassAttribute icpl = new ClassAttribute(IteratedCurrentPhaseLink.class,
        //                                     WTAttributeNameIfc.ROLEB_VERSION_ID);
        qs.appendSearchCondition(new SearchCondition(CurrentPhaseLink.class,
                WTAttributeNameIfc.ROLEB_OBJECT_ID,
                lcmOids));

        QueryResult results = PersistenceHelper.manager.find(qs);
        while (results.hasMoreElements()) {
            Object[] oid = (Object[])results.nextElement();
            long phaseOid = ((java.math.BigDecimal)oid[0]).longValue();
            long lcmOid = ((java.math.BigDecimal)oid[1]).longValue();
            LifeCycleManaged object = (LifeCycleManaged)nonIterated.get(Long.valueOf(lcmOid));

            ObjectIdentifier phaseIdentifier = ObjectIdentifier.newObjectIdentifier(Phase.class, phaseOid);

            //Put the objectidentifier in the map so we can get the object when we get the phase
            if (logger.isTraceEnabled())
                logger.trace("addNonIteratedPhaseIdsToMap Added key:: "+ phaseIdentifier +" value:: "+ object +" into the phasemap");


            map.put(phaseIdentifier, object);
            phaseOids[count++] = phaseOid;
        }

        if (logger.isTraceEnabled()) {
            logger.trace("Exiting addIteratedPhaseToMap");
            logger.trace("\t number in map: " + map.size());
        }
        return phaseOids;
    }

    private int addIteratedPhaseIdsToMap (WTKeyedMap map, Map iterated, long[] phaseOids, int count, boolean queryForCurrentPhase) throws WTException {
        if (logger.isTraceEnabled()) {
            logger.trace("Entering addIteratedPhaseToMap");
            logger.trace("\t number currently in map: " + map.size());
            logger.trace("\t number iterated objects: " + iterated.size());
            logger.trace("\t queryForCurrentPhase: "+queryForCurrentPhase);
        }

        if (iterated.isEmpty())
            return count;

        //select ida3a5, branchida3b5 from  iteratedcurrentphaselink where branchida3b5 in
        //(select branchiditerationinfo from iterated where ida2a2 in (oids of Iterated)));

        // first get the long values for the branch id of iterated;
        // This will represent the 'select brandiditerationinfo from iterated...'
        Object[] masters = iterated.keySet().toArray();
        long masterOids[] = new long[masters.length];
        for (int i=0; i< masters.length; i++) {
            masterOids[i] = ((Long)masters[i]).longValue();
        }

        // Query for the phase oid and branch id oids in the IteratedCurrentPhaseLinks
        // select ida3a5, branchida3b5 from iteratedcurrentphaselink
        QuerySpec qs = new QuerySpec();
        int index = qs.appendClassList(IteratedCurrentPhaseLink.class, false);
        qs.appendSelectAttribute(WTAttributeNameIfc.ROLEA_OBJECT_ID, index, false);
        qs.appendSelectAttribute(WTAttributeNameIfc.ROLEB_VERSION_ID, index, false);

        //where branchida3b5 in [ida3b5 oids of control branch]
        //ClassAttribute icpl = new ClassAttribute(IteratedCurrentPhaseLink.class,
        //                                     WTAttributeNameIfc.ROLEB_VERSION_ID);
        qs.appendSearchCondition(new SearchCondition(IteratedCurrentPhaseLink.class,
                WTAttributeNameIfc.ROLEB_VERSION_ID,
                masterOids));

        QueryResult results = PersistenceHelper.manager.find(qs);
        while (results.hasMoreElements()) {
            Object[] oid = (Object[])results.nextElement();
            long phaseOid = ((java.math.BigDecimal)oid[0]).longValue();
            long branchId = ((java.math.BigDecimal)oid[1]).longValue();
            LifeCycleManaged object = (LifeCycleManaged)iterated.get(Long.valueOf(branchId));
            if(queryForCurrentPhase) {
                Phase p = getCurrentPhase(object);
                if(p!=null)
                {
                    long pOid = p.getPersistInfo().getObjectIdentifier().getId();
                    if(pOid == phaseOid && map.get(ObjectIdentifier.newObjectIdentifier(Phase.class, phaseOid)) == null)
                    {
                        ObjectIdentifier phaseIdentifier=ObjectIdentifier.newObjectIdentifier(Phase.class, phaseOid);
                        map.put(phaseIdentifier, object);
                        if (logger.isTraceEnabled())
                            logger.trace(" addIteratedPhaseIdsToMap Added key:: "+ phaseIdentifier +" value:: "+ object +" into the phasemap after query for current phase");

                        phaseOids[count] = phaseOid;
                        count++;
                    }
                }
            } else {
                ObjectIdentifier phaseIdentifier=ObjectIdentifier.newObjectIdentifier(Phase.class, phaseOid);
                if(map.get(phaseIdentifier) == null)
                {
                    map.put(phaseIdentifier, object);
                    if (logger.isTraceEnabled())
                        logger.trace(" addIteratedPhaseIdsToMap Added key:: "+ phaseIdentifier +" value:: "+ object +" into the phasemap without querying current phase");
                    phaseOids[count] = phaseOid;
                    count++;
                }
            }
        }

        if (logger.isTraceEnabled()) {
            logger.trace("Exiting addIteratedPhaseToMap");
            logger.trace("\t number in map: " + map.size());
            logger.trace("\t Return count value : " + count);
        }
        return count;
    }

    private int addIteratedPhaseIdsToMap (WTKeyedMap map, Map iterated, long[] phaseOids, int count) throws WTException {
        return addIteratedPhaseIdsToMap(map, iterated, phaseOids, count, true);
    }

    private void putObjectsIntoSearchBuckets(WTList objects, WTKeyedMap map, Map iterated, Map nonIterated) throws WTException {
        if (logger.isTraceEnabled())
            logger.trace("Entering putObjectsIntoSearchBuckets");
        // If the phase is found in the cache, immediately add it to the map, otherwise
        // put into maps based on whether or not it's iterated.
        Iterator iterator = objects.persistableIterator();
        while (iterator.hasNext()) {
            LifeCycleManaged object = (LifeCycleManaged)iterator.next();
            Phase aPhase = object.getState().getPhase();
            if (aPhase != null) {
                if (logger.isTraceEnabled())
                    logger.trace("Added key:: "+ object +" value:: "+ aPhase +" into the phasemap");
                map.put(object,aPhase);
            }
            else {
                if (!object.isLifeCycleBasic()) {
                    Long oid= null;
                    if (object instanceof Iterated) {
                        oid = Long.valueOf(((Iterated)object).getBranchIdentifier());
                        iterated.put(oid,object);
                    }
                    else  {
                        oid = Long.valueOf(PersistenceHelper.getObjectIdentifier(object).getId());
                        nonIterated.put(oid, object);
                    }
                }
            }
        }

        if (logger.isTraceEnabled())
            logger.trace("Entering putObjectsIntoSearchBuckets");
    }

    private void setPhase (LifeCycleManaged object, Phase phase) throws WTException {
        if (logger.isTraceEnabled())
        {
            logger.trace(">>In StandardLifeCycleService...setPhase() method");
            logger.trace("=> setPhase: " + getOid (object));
        }
        try {
            object.getState().setPhase (phase);
        }
        catch (WTPropertyVetoException wtpve) {
            if(logger.isDebugEnabled()){
                logger.debug(wtpve.getLocalizedMessage(), wtpve);
            }
            throw new WTException(wtpve);
        }
        if (logger.isTraceEnabled())
            logger.trace(">>Out StandardLifeCycleService...setPhase() method");
    }

    private ObjectIdentifier getOid (Object obj) {
        if (obj == null) {
            return null;
        }
        if (obj instanceof ObjectReference) {
            return (ObjectIdentifier) ((ObjectReference) obj).getKey ();
        }
        if (obj instanceof Persistable) {
            return PersistenceHelper.getObjectIdentifier ((Persistable) obj);
        }
        return null;
    }

    private class MultiObjectKey {
        private long lifeCycleTemplate;
        private long teamTemplate;
        private long container;
        public MultiObjectKey(LifeCycleManaged object) {
            LifeCycleTemplateReference lctr=object.getLifeCycleTemplate();
            TeamTemplateReference ttr=object.getTeamTemplateId();
            WTContainerRef cr=null;
            if (object instanceof WTContained) {
                cr = ((WTContained)object).getContainerReference();
            }
            if (lctr==null)
                lifeCycleTemplate=0;
            else
                lifeCycleTemplate = getOid(lctr).getId();
            if (ttr ==null)
                teamTemplate=0;
            else
                teamTemplate = getOid(ttr).getId();
            if (cr == null)
                container=0;
            else
                container = getOid(cr).getId();

        }
        private long getLifeCycleId() {
            return lifeCycleTemplate;
        }
        private long getTeamTemplateId() {
            return teamTemplate;
        }
        private long getWTContainerId() {
            return container;
        }

        public boolean equals (Object object) {

            if (logger.isTraceEnabled())
                logger.trace("Entering equals: " + object);
            if (!(object instanceof MultiObjectKey))
                return false;
            MultiObjectKey key = (MultiObjectKey)object;
            return key.getLifeCycleId()==(lifeCycleTemplate) &&
                    key.getTeamTemplateId()==(teamTemplate) &&
                    key.getWTContainerId()==(container);
        }

        public int hashCode() {
            int containerHash=-1;
            if (container != 0)
                containerHash = (int)(containerHash^(containerHash>>>32));
            int lifeCycleHash = (int)(lifeCycleTemplate^(lifeCycleTemplate>>>32));
            int teamTemplateHash = (int)(teamTemplate^(teamTemplate>>>32));
            return lifeCycleHash ^ teamTemplateHash ^ containerHash;
        }
    }

    private List createSubcollectionsByKey(WTCollection collection) throws WTException {

        if (logger.isTraceEnabled())
            logger.trace("Entering createSubCollectionByKey");

        Iterator iterator = collection.persistableIterator();
        Persistable managed=null;
        Map map=new HashMap();
        while (iterator.hasNext()) {
            managed=(Persistable)iterator.next();
            addToMapCollection(map, managed, collection);
        }

        if (logger.isTraceEnabled())
            logger.trace("map.size(): " + map.size());

        List returnList=new ArrayList();
        iterator=map.values().iterator();
        while (iterator.hasNext()) {
            List list=(List)iterator.next();
            WTCollection sub=new WTArrayList(list.size());
            for (int i=0;i<list.size(); i++){
                Persistable myObject=(Persistable)list.get(i);
                sub.connect(myObject,collection);
            }
            returnList.add(sub);
        }

        if (logger.isTraceEnabled())
            logger.trace("Exiting createSubCollectionByKey");

        return returnList;
    }

    private void addToMapCollection(Map map, Persistable object, WTCollection collection) {
        MultiObjectKey key = new MultiObjectKey((LifeCycleManaged)object);
        List list;
        if (map.get(key) == null)
            list = new ArrayList();
        else
            list = (List)map.get(key);
        list.add((Persistable)object);
        map.put(key, list);
    }

    private void validateReassign( WTCollection objects, LifeCycleTemplateReference lctRef, State state )
            throws WTException, LifeCycleException {

        if (logger.isTraceEnabled())
            logger.trace("Enter validateReassign on collection of objects");

        //First validate the everything but the state
        validateReassign (objects, lctRef);

        //Then validate the specified state is in the lifecycle template.
        if (state != null) {
            LifeCycleTemplate template = (LifeCycleTemplate)lctRef.getReadOnlyObject();
            PhaseTemplate pt = stateSearch(template,state);
            if (pt == null) {
                Object[] param = {state.getDisplay(), template.getName() };
                throw new LifeCycleException(RESOURCE,lifecycleResource.INVALID_LIFECYCLE_STATE, param);
            }
        }


    }

    private void doReassign (WTList list, LifeCycleTemplateReference lctRef, WTContainerRef context_ref, State state, boolean preserveState, String comments, boolean pwc)
            throws WTException, LifeCycleException {

        if (logger.isTraceEnabled())
            logger.trace("=> doReassign: WTCollection, LCT = " + lctRef.getName() + ", container = " + getOid (context_ref)
                    + ", state= " + state + ", preserveState= " + preserveState);

        // rchaudhari: SPR 2199508: Verify that passed lifecycle is not working copy and not in personal cabinet.
          if (lctRef!=null && isWorkingCopyOrInPersonalCabinet(lctRef)) {
              Object[] params = {lctRef.getName()};
              throw new WTException(RESOURCE, lifecycleResource.CHECKED_OUT_OBJECT, params);
          }

           Transaction trx = new Transaction();

        try {
            trx.start();
            // 1. Log history
            WTList aHistoryList = null;
            if (!pwc)
            {
                WTKeyedMap  phases = new WTKeyedHashMap(1);
                saveEXITHistory(list,EXIT_PHASE);
                aHistoryList = saveHistory(list ,phases, REASSIGN, comments);
            }


            //Prj 14216762: If called through reassignMultipleLC then get the creator of the workflows.
            if(isMultipleReassign){
                objectWFCreatorMap= getObjWFCreatorMap(list);
            }

            // 2a.  Terminate the associated WF phase/gate processes
            if (!pwc)
                WfEngineHelper.service.terminateObjectsRunningWorkflows(list);

            if (!pwc)
                cleanupCurrentPhases(list, aHistoryList);

            // 3.  Set the template information in the cookie to be the first phase of the appropriate LC and then assign it to the lifecycle
            setStates(list,lctRef,state,preserveState,false);
            assignToLifeCycle (list, context_ref, true, true, pwc);

            // 4. Dispatch the reassign event
            if (!pwc)
                dispatchVetoableMultiObjectEvent( LifeCycleServiceEvent.REASSIGN, list );
            trx.commit();
            trx = null;
        }
        catch (PersistenceException dbError) {
            if(logger.isDebugEnabled()){
                logger.debug(dbError.getLocalizedMessage(), dbError);
            }
            throw new LifeCycleException(dbError);
        }
        catch (WTPropertyVetoException pve) {
            if(logger.isDebugEnabled()){
                logger.debug(pve.getLocalizedMessage(), pve);
            }
            throw new LifeCycleException(pve);
        }
        catch (WTException wex) {
            if(logger.isDebugEnabled()){
                logger.debug(wex.getLocalizedMessage(), wex);
            }
            throw new LifeCycleException(wex);}
        finally {
            if (trx != null) {
                trx.rollback();
            }
        }
        if (logger.isTraceEnabled())
            logger.trace("   doReassign - OUT");
    }

    /********
     * This API gives a map of pbo and the process initiator
     * of the workflow attached with the PBO's lifecycle.
     * Used in reassignMultipleLC() method.
     */
    private HashMap getObjWFCreatorMap(WTList list){
        HashMap objCreateMap= new HashMap();
        try{
            Iterator obj = list.persistableIterator();
            while (obj.hasNext()){
                WTObject object= (WTObject)obj.next();
                Enumeration enumr= WfEngineHelper.service.getAssociatedProcesses (object, WfState.OPEN_RUNNING, null);
                java.sql.Timestamp createTime=null;
                WTPrincipalReference creator=null;
                while (enumr.hasMoreElements()) {
                    WfProcess aWfProcess = (WfProcess)enumr.nextElement();
                    Timestamp procTime=aWfProcess.getCreateTimestamp();
                    if(createTime ==null ){
                        createTime=procTime;
                        creator=aWfProcess.getCreator();
                    }else{
                        int i=createTime.compareTo(procTime);
                        if(i>0){
                            createTime=procTime;
                            creator=aWfProcess.getCreator();
                        }
                    }
                }
                objCreateMap.put(object,creator);
            }
        }
        catch(WTException ex){
            if(logger.isDebugEnabled()){
                logger.debug(ex.getLocalizedMessage(), ex);
            }
            if(logger.isTraceEnabled()){
                logger.trace("getObjWFCreatorMap(): Cannot resolve process initiator");
            }
        }
        return objCreateMap;
    }

    /********
     * This API validates whether or not all objects in the collection are
     * not at the gate.  If some objects are, a multi-object exception
     * will be thrown.
     */
    private void validateAtGate(WTCollection lcmObjects) throws WTException {
        Iterator iterator = lcmObjects.persistableIterator();
        WTCollection collection = new WTHashSet();

        while (iterator.hasNext()) {
            LifeCycleManaged target = (LifeCycleManaged)iterator.next();
            if (logger.isTraceEnabled())
                logger.trace("===> validateAtGate: " + target);
            if ( (target instanceof LifeCycleManaged) && ( ((LifeCycleManaged)target).isLifeCycleAtGate() == true) ) {
                collection.add(target);
            }
            if (collection.size() > 0) {
                WTMessage[] messages = WTMessage.getMessages(RESOURCE, lifecycleResource.MULTI_OBJECT_PROHIBIT_MODIFY_AT_GATE,
                        IdentityFactory.getDisplayIdentities(collection));
                throw new WTException (messages);
            }
        }
    }

    /********
     * This API validates whether or not all objects in the collection are
     * are in a state where they can be assigned.  If not, a multi-object exception
     * will be thrown.
     */
    private void validateReassign(WTCollection lcmObjects, LifeCycleTemplateReference lctRef) throws WTException {
        if (logger.isTraceEnabled())
            logger.trace("Entering validateReassign(WTCollection, lctRef");

        String action = WTMessage.getLocalizedMessage( RESOURCE, REASSIGN, null,this.getLocale());

        //Check to make sure the object passed in is the latest iteration
        validateIsLatestIteration(lcmObjects, action);

        //Access control check for reassign
        AccessControlHelper.manager.checkAccess(lcmObjects, AccessPermission.ADMINISTRATIVE);

        //Validate the LifeCycleTemplate is not null and doesn't contain a null
        if (lctRef == null) {
            throw new LifeCycleException(RESOURCE, lifecycleResource.NULL_TEMPLATE, null);
        }
        else if (lctRef.getKey() == null) {
            throw new LifeCycleException(RESOURCE, lifecycleResource.NULL_TEMPLATE, null);
        }

        //Now determine which objects are working copies or checked out
        Iterator iterator = lcmObjects.persistableIterator();
        WTCollection workingCopies = new WTHashSet();
        WTCollection checkedOut = new WTHashSet();

        while (iterator.hasNext())  {
            LifeCycleManaged object = (LifeCycleManaged)iterator.next();
            if (isWorkingCopy(object, false))
                workingCopies.add(object);
            if (isCheckedOut(object))
                checkedOut.add(object);
        }

        if (workingCopies.size() > 0) {
            WTMessage[] messages = WTMessage.getMessages(RESOURCE, lifecycleResource.MULTI_OBJECT_WORKING_COPY_SUBMIT,
                    IdentityFactory.getDisplayIdentities(workingCopies));
            throw new WTException (messages);
        }

        if (checkedOut.size() > 0) {
            WTMessage[] messages = WTMessage.getMessages(RESOURCE, lifecycleResource.CHECKED_OUT_OBJECT,
                    new Object[] {action});
            throw new WTException (messages);
        }

        if (logger.isTraceEnabled())
            logger.trace("Exiting validateReassign(WTCollection, lctRef");
    }

    private void validateIsLatestIteration(WTCollection objects, String action)
            throws WTException {

        Iterator iterator = objects.persistableIterator();
        WTCollection collection = new WTHashSet();
        boolean debugEnabled = logger.isDebugEnabled();
        while (iterator.hasNext()) {
            LifeCycleManaged target = (LifeCycleManaged)iterator.next();
            if (logger.isTraceEnabled())
                logger.trace("===> latestIteration: " + target);

            if(target instanceof  Iterated)
            {
                if ( !(VersionControlHelper.isLatestIteration((Iterated)target))) {
                    collection.add(target);
                }
                if (collection.size() > 0) {
                    WTMessage[] messages = WTMessage.getMessages(RESOURCE, lifecycleResource.MULTI_OBJECT_NOT_LATEST_ITERATION,
                            new Object[] {action, IdentityFactory.getDisplayIdentities(collection)});
                    throw new WTException (messages);
                }
            }
        }
    }

    private WTKeyedMap validateSetState( WTCollection collection, State aState, Map stateMap )
            throws WTException, LifeCycleException {

        PhaseTemplate pt =null;

        if (logger.isTraceEnabled())
            logger.trace("Enter validateSetState(WTCollection, State, map)");

        WTKeyedMap map = null;
        try {


            //Validate the state
            map = validateState(collection, aState, stateMap);

            //setState is prohibited on the working copy
            WTCollection invalidObjects = isWorkingCopy(collection.subCollection(wt.vc.wip.Workable.class), true);
            if (invalidObjects.size() > 0) {
                WTMessage[] messages = WTMessage.getMessages(RESOURCE, lifecycleResource.MULTI_OBJECT_WORKING_COPY_SET_STATE,
                        new Object[] {IdentityFactory.getDisplayIdentities(invalidObjects)});
                throw new WTException (messages);
            }


            // -- Checked out objects may not have the state set.
            invalidObjects = WorkInProgressHelper.getCheckedOut(collection.subCollection(wt.vc.wip.Workable.class));
            if (invalidObjects.size() > 0) {
            	Locale locale=SessionHelper.getLocale();
                String action = WTMessage.getLocalizedMessage(RESOURCE,SET_STATE,null,locale);
                WTMessage[] messages = WTMessage.getMessages(RESOURCE, lifecycleResource.MULTI_OBJECT_CHECKED_OUT,
                        new Object[] {action, IdentityFactory.getDisplayIdentities(invalidObjects)});
                throw new WTException (messages);
            }


            // -- Objects stored in a personal object may not have the state set.
            invalidObjects = new WTHashSet();
            for (Iterator iterator = collection.persistableIterator(); iterator.hasNext();) {
                LifeCycleManaged object = (LifeCycleManaged)iterator.next();
                if (object instanceof FolderEntry &&
                    (!(object instanceof Workable) ||
                     !WorkInProgressHelper.isPrivateWorkingCopy((Workable)object))) {
                    if (FolderHelper.inPersonalCabinet((CabinetBased)object)) {
                        invalidObjects.add(object);
                    }
                }
                if (invalidObjects.size() > 0) {
                    WTMessage[] messages = WTMessage.getMessages(RESOURCE, lifecycleResource.MULTI_OBJECT_PERSONAL_CABINET_SET_STATE,
                            new Object[] {IdentityFactory.getDisplayIdentities(invalidObjects)});
                    throw new WTException (messages);
                }
            }
        }
        catch (PersistenceException dbError) {
            if(logger.isDebugEnabled()){
                logger.debug(dbError.getLocalizedMessage(), dbError);
            }
            throw new LifeCycleException(dbError);
        }


        if (logger.isTraceEnabled())
            logger.trace("Exit validateSetState(WTCollection, state)");

        return map;
    }

    private void doSetState( WTList list, WTKeyedMap phaseTemplateMap, boolean pwc )
            throws WTException, LifeCycleException {
        WTList wtlislist=list;
        if (logger.isTraceEnabled())
            logger.trace("=> doSetState(WTCollection, templateMap)");

        int size = wtlislist.size();
        if( size <= 0 ){
            if (logger.isTraceEnabled()){
                logger.trace("=> Exit doSetState(WTCollection, templateMap). No. of objs = " + size);
            }
            return;
        }

        Transaction trx = new Transaction();
        // This key is added to map in lifecycle attr handler.
        Object listenerFromMap = Transaction.getSharedMap().get(TRX_LISTENER_KEY);

        try {
            trx.start();
            wtlislist = (WTList) CollectionsHelper.manager.refresh(wtlislist, RefreshSpec.LOCK_AND_REFRESH);

            // 1. Log the history event
            WTKeyedMap  phases = new WTKeyedHashMap(1);

            if (!pwc)
            {
                saveEXITHistory(list,EXIT_PHASE);

                WTList aHistoryList = saveHistory(wtlislist ,phases, SET_STATE);

            // 2 Move signatures to history & delete the current phase
                cleanupCurrentPhases(wtlislist, aHistoryList);
            }

            // 3. do the state transition
            doStateTransition(wtlislist, ENTER_PHASE, phaseTemplateMap, (WTContainerRef)null, true, false, pwc);

            if(SKIP_EMIT_EVENT_WHILE_PACKAGE_IMPORT && listenerFromMap != null) {
                logger.debug("Do not emit multiobject set state and state change events during high fidelity package import and proprty is set to true.");
            } else if (!pwc){
                //4.  Dispatch the setState event
                dispatchVetoableMultiObjectEvent( LifeCycleServiceEvent.SET_STATE, wtlislist );
                //5.  Dispatch the state_change event (Emit a second event for the Synchronization robot to detect.)
                dispatchVetoableMultiObjectEvent( LifeCycleServiceEvent.STATE_CHANGE, wtlislist );
            }
            //6.  Contribute to Summary Event
            /* This is done in doStateTransition */
            trx.commit();
            trx = null;
        }
        catch (WTPropertyVetoException wtpve) {
            if(logger.isDebugEnabled()){
                logger.debug(wtpve.getLocalizedMessage(), wtpve);
            }
            throw new LifeCycleException(wtpve);
        }
        catch (PersistenceException dbError) {
            if(logger.isDebugEnabled()){
                logger.debug(dbError.getLocalizedMessage(), dbError);
            }
            throw new LifeCycleException(dbError);
        }
        catch (WTException wex) {
            if(logger.isDebugEnabled()){
                logger.debug(wex.getLocalizedMessage(), wex);
            }
            throw new LifeCycleException(wex);
        }
        finally {
            if (trx != null) {
                trx.rollback();
            }
        }
        if (logger.isTraceEnabled())
            logger.trace("   doSetState - OUT: " );
    }

    private void saveHistory(WTList wtlislist, String event)throws WTException
    {
        Iterator itr=wtlislist.persistableIterator();

        while(itr.hasNext())
        {
            LifeCycleManaged object = (LifeCycleManaged)itr.next();
            if(this.isLifeHistoryAssociated(object))
            {
                Phase oldPhase=this.getPhase(object);
                saveHistory(object,oldPhase,event,(Timestamp)null, null);
            }

        }

    }

    private void saveEXITHistory(WTList wtlislist, String event)throws WTException
    {
    	 if(isSkipLifecycleHistoryCreation())
    	 {
    		 return;
    	 }
    	 
        WTKeyedMap phaseMap = new WTKeyedHashMap();
        if(ENABLE_HISTORY)
        {
            Iterator itr=wtlislist.persistableIterator();
            while(itr.hasNext())
            {
                LifeCycleManaged object = (LifeCycleManaged)itr.next();
                Phase oldPhase=this.getPhase(object);
                phaseMap.put(object, oldPhase);
            }
            this.saveHistory(wtlislist, phaseMap, event);
        }
    }

    /***
     * Remove the attributes that are not basic as the object no longer uses acls or teams
     */
    private LifeCycleManaged resetNonBasicAttributes(LifeCycleManaged object) throws WTException  {
        LifeCycleManaged lcmobject=object;
        try {
            SessionContext previous = SessionContext.newContext ();
            try {
                SessionHelper.manager.setAdministrator();
                lcmobject = (LifeCycleManaged)AccessControlHelper.manager.removePermissions(lcmobject, AdHocAccessKey.WNC_LIFECYCLE);
            }
            finally {
                SessionContext.setContext (previous);
            }
            lcmobject.setTeamId(null);
            lcmobject.setTeamTemplateId(null);
        }
        catch (WTPropertyVetoException e) {
            if(logger.isDebugEnabled()){
                logger.debug(e.getLocalizedMessage(), e);
            }
            throw new WTException(e);
        }
        return lcmobject;
    }

    /**
     * Returns a Set of properly ordered WTList instances containing the
     * PhaseTemplate instances of the argument collection of life cycle templates.
     * "Properly ordered" means that each phase template is arranged according to its
     * canonical (NEXT) successor relationship.
     */
    private Set getPhaseTemplatesForInitialization(WTCollection lcts) throws WTException {
        int succIdx = 0, predIdx = 1;
        CompoundQuerySpec cqs = new CompoundQuerySpec();
        try {
            cqs.setSetOperator(SetOperator.UNION_ALL);
        } catch (WTPropertyVetoException wtpve) {
            if(logger.isDebugEnabled()){
                logger.debug(wtpve.getLocalizedMessage(), wtpve);
            }
            throw new WTException(wtpve);
        }
        cqs.addComponent(newInitialPhasesSpec(lcts));
        cqs.addComponent(newSuccessorPhasesSpec(lcts));

        QueryResult qr = PersistenceServerHelper.manager.query(cqs);
        WTValuedHashMap initialPhases = new WTValuedHashMap(lcts.size()), successorPhases = new WTValuedHashMap(qr.size() - lcts.size());
        while (qr.hasMoreElements()) {
            Object[] elems = (Object[])qr.nextElement();
            WTReference predecessor = (WTReference)elems[predIdx];
            if (elems[predIdx] == null) initialPhases.put((Persistable)elems[succIdx], elems[succIdx]);
            else {
                // Prevent a cycle in this map, which would cause the method server's
                // heap to be blown when the list of successors is calculated.
                if (successorPhases.containsKey(predecessor)) {
                    // Include the offending query result data in the exception for
                    // debugging.
                    StringBuffer buf = new StringBuffer("[");
                    for (qr.reset(); qr.hasMoreElements(); ) {
                        elems = (Object[])qr.nextElement();
                        buf.append(elems[predIdx] + "-->" + elems[succIdx]);
                        if (qr.hasMoreElements()) buf.append(",");
                    }
                    buf.append("]");
                    throw new WTException(buf.toString());
                }
                successorPhases.put(predecessor, elems[succIdx]);
            }
        }

        HashSet phaseLists = new HashSet((int)(lcts.size() / 0.75) + 2, 0.75f);
        for (Iterator i = lcts.persistableIterator(); i.hasNext(); ) {
            LifeCycleTemplate lct = (LifeCycleTemplate)i.next();
            LinkedList phases = new LinkedList();
            for (PhaseTemplate pt = (PhaseTemplate)initialPhases.getPersistable(lct.getPhaseTemplateId()); pt != null; pt = (PhaseTemplate)successorPhases.getPersistable(pt)) phases.add(pt);
            phaseLists.add(new WTArrayList(phases) {
                // For debugging purposes; should not be serialized to client.
                public String toString() {
                    if (isEmpty()) return "[]";
                    try {
                        StringBuffer buf = new StringBuffer("[");
                        for (int i = 0; i < size() - 1; i++) buf.append(((PhaseTemplate)getPersistable(i)).getPhaseState() + ",");
                        buf.append(((PhaseTemplate)getPersistable(size() - 1)).getPhaseState() + "]");
                        return buf.toString();
                    } catch (WTException wte) {
                        if(logger.isDebugEnabled()){
                            logger.debug(wte.getLocalizedMessage(), wte);
                        }
                        throw new WTRuntimeException(wte);
                    }
                }
            });
        }

        return phaseLists;
    }

    /**
     * Returns a query spec selecting the initial phase template of each of the
     * argument life cycle templates, NULL, and NULL.  The NULLs are to make the
     * SELECTed columns UNION-compatible with the query spec returned by
     * newSuccessorPhaseSpec().
     */
    private QuerySpec newInitialPhasesSpec(WTCollection lcts) throws WTException {
        final String OID = "thePersistInfo.theObjectIdentifier.id";
        WTCollection phaseTemplates = new WTHashSet(lcts.size());
        for (Iterator i = lcts.persistableIterator(); i.hasNext(); ) phaseTemplates.add(((LifeCycleTemplate)i.next()).getPhaseTemplateId());
        QuerySpec qs = new QuerySpec(PhaseTemplate.class);
        qs.appendSelect(KeywordExpression.NULL, false);
        qs.appendSelect(KeywordExpression.NULL, false);
        qs.appendWhere(new SearchCondition(PhaseTemplate.class, OID, phaseTemplates.toIdArray()), new int[] { 0 });
        return qs;
    }

    /**
     * Returns a query spec selecting the all non-initial phase templates of each
     * of the argument life cycle templates and a reference to each such phase
     * template's predecessor.  The query actually SELECTs the classname and OID
     * columns, so it is UNION-compatible with the query spec returned by
     * newInitialPhaseSpec().  However, these columns are combined into a single
     * WTReference object in the query result.
     */
    private QuerySpec newSuccessorPhasesSpec(WTCollection lcts) throws WTException {
        final String OID = "thePersistInfo.theObjectIdentifier.id";
        QuerySpec qs = new QuerySpec();
        int lctIdx = qs.appendClassList(LifeCycleTemplate.class, false);
        int phlIdx = qs.appendClassList(PhaseLink.class, false);
        int phtIdx = qs.appendClassList(PhaseTemplate.class, false);
        int phsIdx = qs.appendClassList(PhaseSuccession.class, false);
        int sptIdx = qs.appendClassList(PhaseTemplate.class, true);
        qs.appendSelectReference(new ClassAttribute(PhaseSuccession.class, "roleAObjectRef.key.classname"), new ClassAttribute(PhaseSuccession.class, "roleAObjectRef.key.id"), phsIdx, phsIdx, true);
        qs.appendWhere(new SearchCondition(LifeCycleTemplate.class, OID, PhaseLink.class, "roleAObjectRef.key.id"), new int[] { lctIdx, phlIdx });
        qs.appendAnd();
        qs.appendWhere(new SearchCondition(PhaseLink.class, "roleBObjectRef.key.id", PhaseTemplate.class, OID), new int[] { phlIdx, phtIdx });
        qs.appendAnd();
        qs.appendWhere(new SearchCondition(PhaseTemplate.class, OID, PhaseSuccession.class, "roleAObjectRef.key.id"), new int[] { phtIdx, phsIdx });
        qs.appendAnd();
        qs.appendWhere(new SearchCondition(PhaseSuccession.class, "roleBObjectRef.key.id", PhaseTemplate.class, OID), new int[] { phsIdx, sptIdx });
        qs.appendAnd();
        qs.appendWhere(new SearchCondition(PhaseSuccession.class, PhaseSuccession.NAME, SearchCondition.EQUAL, Transition.NEXT), new int[] { phsIdx });
        qs.appendAnd();
        qs.appendWhere(new SearchCondition(LifeCycleTemplate.class, OID, lcts.toIdArray()), new int[] { lctIdx });
        return qs;
    }
    /**
     * Returns a WTList of the state-unique elements of the argument WTList of
     * PhaseTemplates in the order encountered in the argument list.
     */
    private WTList uniquePhaseTemplates(WTList phaseTemplates) throws WTException{
        WTArrayList uniquePhaseTemplates = new WTArrayList(phaseTemplates.size());
        HashSet states = new HashSet((int)(phaseTemplates.size() / 0.75), 0.75f);
        for (Iterator i = phaseTemplates.persistableIterator(); i.hasNext(); ) {
            PhaseTemplate pt = (PhaseTemplate)i.next();
            if (states.add(pt.getPhaseState())) uniquePhaseTemplates.add(pt);
        }
        return uniquePhaseTemplates;
    }
    /**
     * Method added to accomplish Undo C/O fucntionality by getting the working if its a
     * checked out copy.
     * @param target
     * @return boolean
     * @throws LifeCycleException
     * @throws WTException
     */
    private boolean deleteLCIteration(Persistable target)throws LifeCycleException, WTException
    {
        Workable chckoutCopy = null;
        Workable workingCopy = null;
        boolean  success = false;
        LifeCycleTemplate lct =null;

        if( (target instanceof Workable) && (WorkInProgressHelper.isWorkingCopy((Workable)target ))) {
            try {
                lct = getLatestIteration((LifeCycleTemplateMaster)((LifeCycleTemplate)target).getMaster());

                if(WorkInProgressHelper.isCheckedOut( lct))
                {
                    workingCopy = CheckInOutTaskLogic.getWorkingCopy((Workable)lct);
                    lct = (LifeCycleTemplate) workingCopy;

                    if(workingCopy!=null){

                        if (target.getPersistInfo().getObjectIdentifier().getId() == lct.getPersistInfo().getObjectIdentifier().getId()) {
                            success=true;
                        }
                    }
                }
            } catch (LifeCycleException lce) {
                if(logger.isDebugEnabled()){
                    logger.debug(lce.getLocalizedMessage(), lce);
                }
                throw lce;
            } catch (WTException wte) {
                if(logger.isDebugEnabled()){
                    logger.debug(wte.getLocalizedMessage(), wte);
                }
                throw wte;
            }
        }

        return success;
    }

    // Return true if there is revise transition defined in the Lifecycle template.
    private String searchTransition(WTKeyedHashMap latestResultMap, WTKeyedHashMap combineMapStatus) {

        String result_str = "";
        Iterator iter1 = combineMapStatus.keySet().iterator();
        while(iter1.hasNext())
        {
            Object tempObj = iter1.next();
            WTKeyedHashMap reviseTrans = (WTKeyedHashMap) latestResultMap.get(tempObj);
            String object_status = (String) combineMapStatus.get(tempObj);
            if(reviseTrans!=null)
            {
                Set reviseSet = reviseTrans.keySet();
                if(reviseSet == null)
                    return object_status;
                Iterator iter =reviseSet.iterator();
                if(iter.hasNext())  {
                    WTArrayList reviseTransition = (WTArrayList) reviseTrans.get(iter.next());
                    if(reviseTransition.isEmpty())
                        return object_status;
                }
            }
        }
        return result_str;
    }

    /**
     * Answer a vector of signatures for all roles for the object for the
     * passed lifecycle history object
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     object  the LifeCycleHistory object used as search criteria in the retrieval of Signature objects
     * @return    Vector
     * @exception wt.util.WTException
     **/

    public Vector getLifecycleVotingHistory(String objRef) throws WTException {
        if(logger.isDebugEnabled())
            logger.debug("Enter getLifecycleVotingHistory : objRef :: " + objRef );
        Vector lcsVector = new Vector();
        if (objRef != null && ! objRef.equals("0")) {
            ReferenceFactory rf=new ReferenceFactory();
            LifeCycleHistory object = (LifeCycleHistory) rf.getReference(objRef).getObject();

            // -- For each history object found, retrieve the signatures
            QuerySpec qs = new QuerySpec(wt.lifecycle.LifeCycleSignature.class,
                    wt.lifecycle.SignatureHistory.class);
            qs.appendOrderBy(wt.lifecycle.LifeCycleSignature.class,
                    WTAttributeNameIfc.CREATE_STAMP_NAME, true);
            QueryResult results = PersistenceHelper.manager.navigate(object,
                    SignatureHistory.SIGNATURE_ROLE, qs, true);

            if (logger.isDebugEnabled())
                logger.debug("Found " + results.size()
                        + " LifeCycleSignature objects");

            // -- Add the signature objects to the vector
            while (results.hasMoreElements()) {
                lcsVector.addElement((LifeCycleSignature) (results
                        .nextElement()));
            }
        }
        if(logger.isDebugEnabled())
            logger.debug("Exit getLifecycleVotingHistory :: lcsVector.size :: "+lcsVector.size());
        return lcsVector;
    }

    private boolean isLifeHistoryAssociated(LifeCycleManaged object)throws WTException
    {
        boolean isHistory=false;
        QueryResult qr=this.getHistory(object);

        if(qr.size()>0)
            isHistory=true;

        return isHistory;

    }

    /**
     * this method is used to get  the history of lifecyclemanaged object in the order specified.
     *
     */

    public QueryResult getHistory( LifeCycleManaged object,boolean order )
            throws WTException, LifeCycleException {

        // -- Answer the LifeCycleHistory objects for the object
        if (logger.isTraceEnabled())
            logger.trace(">>In StandardLifeCycleService...getHistory( LifeCycleManaged object,boolean order ) method");
        QueryResult results = null;

        // --  Navigate from the object to obtain LifeCycleHistory objects via the link
        if (object instanceof Iterated) {

            String objRefId = "." + ObjectReference.KEY + "." + ObjectIdentifier.ID;

            Class[] classes = { Iterated.class, ObjectHistory.class, LifeCycleHistory.class };
            QuerySpec qs = new QuerySpec(classes);

            int lcmPos = 0;
            int ohPos = 1;
            int lchPos = 2;

            //Set which classes are selectable
            qs.setSelect(ohPos, false);
            qs.setSelect(lcmPos, false);

            SearchCondition sc = new SearchCondition(
                    LifeCycleHistory.class,
                    "thePersistInfo.theObjectIdentifier.id",
                    ObjectHistory.class,
                    ObjectHistory.ROLE_BOBJECT_REF + objRefId);
            qs.appendWhere(sc,lchPos,ohPos);
            qs.appendAnd();
            SearchCondition sc2 = new SearchCondition(
                    Iterated.class,
                    "thePersistInfo.theObjectIdentifier.id",
                    ObjectHistory.class,
                    ObjectHistory.ROLE_AOBJECT_REF + objRefId);
            qs.appendWhere(sc2,lcmPos,ohPos);
            qs.appendAnd();
            SearchCondition sc3 = new SearchCondition(
                    Iterated.class,
                    Iterated.ITERATION_INFO + "." + VersionForeignKey.BRANCH_ID,
                    SearchCondition.EQUAL,
                    VersionControlHelper.getBranchIdentifier((Iterated)object));
            qs.appendWhere(sc3,lcmPos,-1);
            //Force the chronological sort by using ida2a2 instead of CREATE_TIME_STAMP.
            //Oracle DATE attributes does not support sorting to milli-second.
            qs.appendOrderBy( wt.lifecycle.LifeCycleHistory.class,
                    WTAttributeNameIfc.CREATE_STAMP_NAME,
                    false);
            qs.appendOrderBy( wt.lifecycle.LifeCycleHistory.class,
                    WTAttributeNameIfc.ID_NAME,
                    false);

            QueryResult jqResults = PersistenceHelper.manager.find(qs);
            if (logger.isTraceEnabled())
                logger.trace("FOUND " + jqResults.size() + " rows.");

            ObjectVector ov = new ObjectVector();
            while (jqResults.hasMoreElements()) {
                Persistable[] jq = (Persistable[])jqResults.nextElement();
                LifeCycleHistory lch = (LifeCycleHistory)jq[0];
                ov.addElement(lch);
            }
            results = new QueryResult(ov);
        }
        else {
            // --  Navigate from the object to obtain LifeCycleHistory objects via the link
            QuerySpec qs = new QuerySpec (wt.lifecycle.LifeCycleHistory.class,
                    wt.lifecycle.ObjectHistory.class);
            //Force the chronological sort by using ida2a2 instead of CREATE_TIME_STAMP.
            //Oracle DATE attributes does not support sorting to milli-second.
            qs.appendOrderBy( wt.lifecycle.LifeCycleHistory.class,
                    WTAttributeNameIfc.CREATE_STAMP_NAME,
                    order);
            qs.appendOrderBy( wt.lifecycle.LifeCycleHistory.class,
                    WTAttributeNameIfc.ID_NAME,
                    order);
            results = PersistenceServerHelper.manager.expand(
                    object,
                    ObjectHistory.HISTORY_ROLE,
                    qs,
                    true);
        }
        if (logger.isTraceEnabled())
            logger.trace(">>Out StandardLifeCycleService...getHistory( LifeCycleManaged object ) method");
        return results;

    }

    public Vector getShortClasses(WTContainerRef context) throws WTException {

        Method method = null;
        Object serviceObject = null;
        Object object = null;
        Object[] args = { context };

        try {
            serviceObject = Class
                    .forName("com.ptc.netmarkets.lifecycle.NmLifeCycleHelper")
                    .getField("service").get(object);
            if (serviceObject == null) {
                System.err
                .println("Error initializing NmLifeCycleHelper.class service object");
            }
            method = Class.forName(
                    "com.ptc.netmarkets.lifecycle.NmLifeCycleService")
                    .getMethod("getShortClasses",
                            new Class[] { WTContainerRef.class });
            if (method == null) {
                System.err
                .println("Error initializing NmLifeCycleService.class method getShortClasses");
            }

            if (method == null)
                throw new WTException("Method not initialized");

            return (Vector) method.invoke(serviceObject, args);
        } catch (Exception e) {
            throw new WTException(e, "Can't invoke " + method);
        }

    }

    public Hashtable getClassesHashtable() throws WTException {

        Method method = null;
        Object serviceObject = null;
        Object object = null;
        Object[] args = {};


        try {
            serviceObject = Class
                    .forName("com.ptc.netmarkets.lifecycle.NmLifeCycleHelper")
                    .getField("service").get(object);
            if (serviceObject == null) {
                System.err
                .println("Error initializing NmLifeCycleHelper.class service object");
            }
            method = Class.forName(
                    "com.ptc.netmarkets.lifecycle.NmLifeCycleService")
                    .getMethod("getClassesHashtable", new Class[] {});
            if (method == null) {
                System.err
                .println("Error initializing NmLifeCycleService.class method getShortClasses");
            }

            if (method == null)
                throw new WTException("Method not initialized");

            return (Hashtable) method.invoke(serviceObject, args);
        } catch (Exception e) {
            throw new WTException(e, "Can't invoke " + method);
        }

    }

    private  Map getTransactionMap()
            throws WTException {

        return (Transaction.getCurrentTransaction().isShared() ?
                Transaction.getSharedMap() :
                    Transaction.getGlobalMap());
    }


    private boolean isIgnoreResiveTransition() throws WTException
    {
        boolean ignoreReviseTransaction=false;
        Map transactionMap=getTransactionMap();
        if(transactionMap.containsKey(LifeCycleHelper.IGNORE_REVISE_TRANSITION))
        {
            if(transactionMap.get(LifeCycleHelper.IGNORE_REVISE_TRANSITION) instanceof Boolean)
            {
                ignoreReviseTransaction= (Boolean)transactionMap.get(LifeCycleHelper.IGNORE_REVISE_TRANSITION);
            }
        }
        return ignoreReviseTransaction;
    }

    private boolean isApplyACLToNonLatestIter() throws WTException
    {
        if (logger.isTraceEnabled()) {
            logger.trace("======> StandardLifeCycleService.isApplyACLToNonLatestIter IN :---> ");
        }

        boolean applyACLToNonLatestIter=false;
        Map transactionMap=getTransactionMap();
        if(transactionMap.containsKey(LifeCycleHelper.APPLY_ACL_TO_NON_LATEST_ITERATION))
        {
            if(transactionMap.get(LifeCycleHelper.APPLY_ACL_TO_NON_LATEST_ITERATION) instanceof Boolean)
            {
                applyACLToNonLatestIter= (Boolean)transactionMap.get(LifeCycleHelper.APPLY_ACL_TO_NON_LATEST_ITERATION);
            }
        }

        if (logger.isTraceEnabled()) {
            logger.trace("======> StandardLifeCycleService.isApplyACLToNonLatestIter OUT applyACLToNonLatestIter :---> "+applyACLToNonLatestIter);
        }
        return applyACLToNonLatestIter;
    }

    private boolean isSkipPhaseWorkflowInitiation() throws WTException
    {
        if (logger.isTraceEnabled()) {
            logger.trace("======> StandardLifeCycleService.isSkipPhaseWorkflowInitiation IN :---> ");
        }

        boolean skipPhaseWorkflowInitiation=false;
        Map transactionMap=getTransactionMap();
        if(transactionMap.containsKey(LifeCycleHelper.SKIP_PHASE_WORKFLOW_INITIATION))
        {
            if(transactionMap.get(LifeCycleHelper.SKIP_PHASE_WORKFLOW_INITIATION) instanceof Boolean)
            {
                skipPhaseWorkflowInitiation= (Boolean)transactionMap.get(LifeCycleHelper.SKIP_PHASE_WORKFLOW_INITIATION);
            }
        }
        if (logger.isTraceEnabled()) {
            logger.trace("======> StandardLifeCycleService.isSkipPhaseWorkflowInitiation OUT skipPhaseWorkflowInitiation :---> "+skipPhaseWorkflowInitiation);
        }

        return skipPhaseWorkflowInitiation;
    }

    private boolean isSkipLifecycleHistoryCreation() throws WTException
    {
        if (logger.isTraceEnabled()) {
            logger.trace("======> StandardLifeCycleService.isSkipLifecycleHistoryCreation IN :---> ");
        }

        boolean skipLifecycleHistoryCreation=false;
        Map transactionMap=getTransactionMap();
        if(transactionMap.containsKey(LifeCycleHelper.SKIP_LIFECYCLEHISTORY_CREATION))
        {
            if(transactionMap.get(LifeCycleHelper.SKIP_LIFECYCLEHISTORY_CREATION) instanceof Boolean)
            {
                skipLifecycleHistoryCreation= (Boolean)transactionMap.get(LifeCycleHelper.SKIP_LIFECYCLEHISTORY_CREATION);
            }
        }

        if (logger.isTraceEnabled()) {
            logger.trace("======> StandardLifeCycleService.isSkipLifecycleHistoryCreation OUT skipLifecycleHistoryCreation :---> "+skipLifecycleHistoryCreation);
        }
        return skipLifecycleHistoryCreation;
    }

    /**
     * Navigates the PhaseTemplate->PhaseSuccession using param transition.
     *  Returns a WTKeyedMap where the keys are the keys passed in param
     * c and the values State object
     *
     *
     * <BR><BR><B>Supported API: </B>true
     *
     * @param     c  A WTKeyedMap that contains as its keys LifecycleManagedObject
     *
     * @return    Map key is lifecycle managed object and value is State object. If not bound the state then value becomes null
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/


    public Map findReviseTransistion( WTKeyedMap c ) throws WTException, LifeCycleException {

        Transition transition = Transition.REVISE;

        if (logger.isTraceEnabled())
            logger.trace("=> Start findReviseTransistion( WTKeyedMap c) :: "
                    + c.size());
        // Iterator over LifeCycleTemplates
        Iterator lcti = c.wtKeySet().persistableIterator();
        // Iterate over states
        Iterator vi = c.values().iterator();
        // The map to return. This map is LCT->States->PhaseSuccessions
        WTKeyedHashMap returnMap = new WTKeyedHashMap();
        // phaseTemplates->(phaseSuccessions->State)
        WTKeyedHashMap objectStateMap = new WTKeyedHashMap();
        LifeCycleTemplate OIRlct = null;
        LifeCycleTemplate lct = null;

        returnMap = (WTKeyedHashMap) navigateForReviseAction(c, Transition.REVISE, true);

        Iterator returnMapItr = returnMap.wtKeySet().persistableIterator();

        while (returnMapItr.hasNext()) {
            WTObject lcmObj = (WTObject) returnMapItr.next();
            State stateLoop = null;
            boolean objectReviseStateFound=false;
            if (logger.isTraceEnabled()) {
                if (lcmObj instanceof LifeCycleTemplate) {
                    lct = (LifeCycleTemplate) lcmObj;
                } else if (lcmObj instanceof LifeCycleManaged) {
                    LifeCycleManaged lcmObject = (LifeCycleManaged) lcmObj;
                    State state = lcmObject.getState().getState();
                    LifeCycleTemplateReference lRef = lcmObject
                            .getLifeCycleTemplate();
                    lct = (LifeCycleTemplate) lRef.getObject();
                }
                if (lcmObj != null)
                    logger.trace("wtobject is " + lcmObj);
                logger.trace("-Lifecycle is " + lct.getName());
            }


            OIRlct= lct;
            WTKeyedHashMap states = (WTKeyedHashMap) returnMap.get(lcmObj);
            Iterator phaseTemplateItr = states.wtKeySet().persistableIterator();

            while (phaseTemplateItr.hasNext()) {
                PhaseTemplate pt = (PhaseTemplate) phaseTemplateItr.next();
                if (logger.isTraceEnabled()) {
                    logger.trace("--State is " + pt.getName());
                }
                if(lcmObj instanceof LifeCycleManaged)
                {
                    
                    if(lcmObj instanceof WTContained){
                    WTContained obj = (WTContained)lcmObj;
                    
                    InitRuleFacade ruleFacade = new InitRuleFacade();
                    OIRlct = (LifeCycleTemplate) ruleFacade.getValue(
                            RuleConstants.ATTR_LIFECYCLE_ID, lcmObj,
                            obj.getContainerReference());
                    }
                    
                    if (OIRlct == null) {
                        if (logger.isTraceEnabled())
                            logger.trace("--OIR template is not exist or disabled ");

                        if (USE_DEFAULT_LC)
                        {
                            LifeCycleTemplate aTemplate = findDefaultTemplate((LifeCycleManaged) lcmObj);
                            OIRlct = aTemplate;

                            if (logger.isTraceEnabled())
                                logger.trace("--USE_DEFAULT_LC " + OIRlct);
                        }
                    }

                    PhaseTemplate oirPhTemplate=stateSearch(OIRlct,((LifeCycleManaged)lcmObj).getState().getState());

                    if (logger.isTraceEnabled()) {
                        logger.trace("--Object current state " +((LifeCycleManaged)lcmObj).getState().getState());
                        logger.trace("--oirPhTemplate " +oirPhTemplate);
                    }

                    if(oirPhTemplate==null)
                    {
                        /**
                         * current object state is not available in lifecycle template referred in object OIR.
                         * Hence after revise the object should be in first state of lifecycle template referred in object OIR.
                         * If there are no revise transition defined for first state revise is not allowed.null is returned.
                         */
                        WTArrayList transitions = (WTArrayList) states.get(pt);
                        if (transitions != null && transitions.size()>0) {

                            if (logger.isTraceEnabled()) {
                                logger.trace("transition found for phasetemplate:"+pt.getName());
                            }
                            objectStateMap.put(lcmObj, pt.getPhaseState());
                        }
                        else
                        {
                            if (logger.isTraceEnabled()) {
                                logger.trace("transition not found for phasetemplate:"+pt.getName());
                            }
                            objectStateMap.put(lcmObj,null);
                        }
                        objectReviseStateFound=true;
                    }
                }

                if(!objectReviseStateFound)
                {

                    WTArrayList transitions = (WTArrayList) states.get(pt);
                    if (transitions != null) {
                        Iterator transitionsItr = transitions.persistableIterator();
                        while (transitionsItr.hasNext()) {
                            PhaseSuccession ps = (PhaseSuccession) transitionsItr.next();
                            stateLoop = ps.getSuccessor().getPhaseState();
                            if (logger.isTraceEnabled()) {
                                logger.trace("----Transition is " + ps.getName());
                                logger.trace("Succession state is "
                                        + ((PhaseTemplate) ps.getRoleBObject())
                                        .getPhaseState());
                            }
                        }
                    }

                    if (logger.isTraceEnabled()) {
                        logger.trace("--Added key as :: " + lcmObj
                                + " Value as::" + stateLoop);
                    }
                    objectStateMap.put(lcmObj, stateLoop);
                }
            }
        }


        if (logger.isTraceEnabled())
            logger.trace("=> End findReviseTransistion( WTKeyedMap c) :: "
                    + objectStateMap.size());

        return objectStateMap;
    }


    /**
     * Navigates the PhaseTemplate->PhaseSuccession using param transition.
     *  Returns a WTKeyedMap where the keys are the keys passed in param
     * c and the values WTKeyedHashMap where the keys are PhaseTemplates
     * and the values are sets of inflated PhaseSuccessions.
     * <p>
     * Usage:
     * <p>
     * <code>
     * WTKeyedHashMap map=new WTKeyedHashMap();
     * Set set = new Set[)
     * state=State.toState("DESIGN")
     * set.add(state)
     * map.put(lifecycleManagedObject, set)
     * WTKeyedHashSet returnMap = LifeCycleHelper.service.navigate(map, Transition.toTransition("SET_STATE"),
     * true)
     * </code>
     *
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     c  A WTKeyedMap that contains as its keys LifecycleManagedObject or LifeCycleTemplates and the values are a set of states to navigate.
     * @param     transition  the name of the transition to navigate
     * @param     successor  specifies whether or not to return the successor state or the predessor.
     * @return    Map
     * @exception wt.util.WTException
     * @exception wt.lifecycle.LifeCycleException
     **/

    public Map navigateForReviseAction( WTKeyedMap c, Transition transition, boolean successor )
            throws WTException, LifeCycleException {
        if (logger.isTraceEnabled())
            logger.trace("=> Start navigateForReviseAction( WTKeyedMap c, Transition transition, boolean successor ) :: " +  transition);
        // Iterator over LifeCycleTemplates
        
        if (POPULATEIBAATTRIBUTESFORREVISE && transition.equals(Transition.REVISE)) {
            refreshIBAs(c);         
        }
        
        Iterator lcti = c.wtKeySet().persistableIterator();
        // Iterate over states
        Iterator vi = c.values().iterator();
        // The map to return.  This map is LCT->States->PhaseSuccessions
        WTKeyedHashMap returnMap = new WTKeyedHashMap();
        // phaseTemplates->phaseSuccessions
        HashMap ptToPs = new HashMap();
        HashMap aLctMap = new HashMap();
        LifeCycleTemplate lct = null;
        WTObject wtObject = null;
        //created psetFinal which will store unique phase templates which is used to find PhaseSucession in find query
        WTHashSet ptSetFinal = new WTHashSet();
        //created map whose key phase template and value if wtobject i.e. either lifecycle template or lifecycle managed object
        HashMap objectPhastemplateMap = new HashMap();

        WTKeyedMap copyMap = new WTKeyedHashMap();

        while (lcti.hasNext()) {
            wtObject = (WTObject)lcti.next();
            if (wtObject instanceof LifeCycleTemplate) {
                lct = (LifeCycleTemplate)wtObject;
            }
            else if (wtObject instanceof LifeCycleManaged) {
                LifeCycleManaged lcmObject = (LifeCycleManaged)wtObject;
                State state = lcmObject.getState().getState();
                LifeCycleTemplateReference lctRef = lcmObject
                        .getLifeCycleTemplate();
                lct = (LifeCycleTemplate)lctRef.getObject();

                if (transition.equals(Transition.REVISE)) {

                    if (logger.isTraceEnabled())
                        logger.trace("lcmObject Lifecycle Template :: "
                                + lcmObject.getLifeCycleTemplate());

                    if(lcmObject instanceof WTContained){
                        WTContained obj = (WTContained)lcmObject;
                        WTContainerRef contRef = obj.getContainerReference();
                       

                        InitRuleFacade ruleFacade = new InitRuleFacade();
                        lct = (LifeCycleTemplate) ruleFacade.getValue(
                                RuleConstants.ATTR_LIFECYCLE_ID, lcmObject,
                                contRef);
                    }
                    //Added condition based upon anaylisis for SPR 2168107
                    if(lct==null){
                        if (logger.isTraceEnabled())
                            logger.trace("For Lifecycle manged instance : "+ lcmObject+ " OIR is not defined");
                        lct = (LifeCycleTemplate)lctRef.getObject();
                        logger.trace("Hence Lifecycle Template is used from object :: "
                                + lct);
                    }else{
                        if (logger.isTraceEnabled())
                            logger.trace("OIR Lifecycle Template Latest iteration is  :: "
                                    + lct);
                    }

                }
            }
            else {
                Object[] param = { wtObject.getClass().toString() };
                throw new LifeCycleException( RESOURCE, lifecycleResource.INVALID_LCM_OBJECT, param );
            }
            //lct = (LifeCycleTemplate)((wt.fc.ObjectReference)lcti.next()).getObject();
            // States are the value
            Set stateSet = (Set)vi.next();
            WTHashSet ptSet = new WTHashSet();
            ArrayList existingPtSets = new ArrayList();
            Iterator pti = stateSet.iterator();
            //stateSearch is optimized through the lct cache
            while (pti.hasNext()) {
                State state = (State)pti.next();
                PhaseTemplate pt = stateSearch(lct, state);
                if (pt != null) {
                    ptSet.add(pt);
                    //Added Phasetemplate
                    ptSetFinal.add(pt);
                    if(!objectPhastemplateMap.containsKey(pt)){
                        WTArrayList list = new WTArrayList();
                        list.add(wtObject);
                        objectPhastemplateMap.put(pt, list);

                    }else
                    {
                        WTArrayList list = (WTArrayList)objectPhastemplateMap.get(pt);
                        list.add(wtObject);
                        objectPhastemplateMap.put(pt, list);

                    }

                    //If phase template found then return map will alwyas contain values as following.
                    //{wt.part.WTPart:110327={wt.lifecycle.PhaseTemplate:110033=[wt.lifecycle.PhaseSuccession:110055]}}
                    //If PhaseSucession is not present then returnMap is {wt.part.WTPart:110327={wt.lifecycle.PhaseTemplate:110033=[]}}
                    WTKeyedHashMap emptyTransitionMap = new WTKeyedHashMap();
                    emptyTransitionMap.put(pt, new WTArrayList());
                    returnMap.put(wtObject, emptyTransitionMap);

                }
            }

            if(transition.equals(Transition.REVISE) && ptSet.size()==0){
                if (logger.isTraceEnabled())
                    logger.trace("Phase Size :: " + ptSet.size());
                PhaseTemplate pt = this.getInitialPhase(lct);
                if (pt != null) {
                    ptSet.add(pt);
                    ptSetFinal.add(pt);
                    if(!objectPhastemplateMap.containsKey(pt)){
                        WTArrayList list = new WTArrayList();
                        list.add(wtObject);
                        objectPhastemplateMap.put(pt, list);

                    }else
                    {
                        WTArrayList list = (WTArrayList)objectPhastemplateMap.get(pt);
                        list.add(wtObject);
                        objectPhastemplateMap.put(pt, list);

                    }

                    //If phase template found then return map will alwyas contain values as following.
                    //{wt.part.WTPart:110327={wt.lifecycle.PhaseTemplate:110033=[wt.lifecycle.PhaseSuccession:110055]}}
                    //If PhaseSucession is not present then returnMap is {wt.part.WTPart:110327={wt.lifecycle.PhaseTemplate:110033=[]}}
                    WTKeyedHashMap emptyTransitionMap = new WTKeyedHashMap();
                    emptyTransitionMap.put(pt, new WTArrayList());
                    returnMap.put(wtObject, emptyTransitionMap);

                }
            }
            existingPtSets = new ArrayList();

            // Add the phasetemplate set to the existingPtSets lct->setofphasetemplates
            existingPtSets.add(ptSet);
            aLctMap.put(lct, existingPtSets);
            WTArrayList ptList = new WTArrayList(ptSet);
        }


        NavigateSpec navigateSpec = PersistenceHelper.buildNavigateSpec(ptSetFinal, PhaseSuccession.SUCCESSOR_ROLE,
                wt.lifecycle.PhaseSuccession.class, false);
        if (transition != null)
            navigateSpec.appendWhere(new SearchCondition(PhaseSuccession.class, PhaseSuccession.NAME, SearchCondition.EQUAL, transition), new int[] { 1 });
        SourceLinkMapResultProcessor resultProcessor =
                new SourceLinkMapResultProcessor(ptSetFinal, PhaseSuccession.SUCCESSOR_ROLE, wt.lifecycle.PhaseSuccession.class);
        resultProcessor = (SourceLinkMapResultProcessor) PersistenceHelper.manager.find(navigateSpec, resultProcessor);

        Map targetMap = resultProcessor.getTargetMap();
        if (targetMap != null) {
            Iterator itrPhasesucession= targetMap.keySet().iterator();
            while(itrPhasesucession.hasNext()){
                ObjectReference objref = (ObjectReference)itrPhasesucession.next();
                if (logger.isTraceEnabled())
                    logger.trace("The key is: " + objref);

                PhaseTemplate  ptTemplate= (PhaseTemplate)objref.getObject();
                WTArrayList linkList = (WTArrayList) targetMap.get(objref);
                WTArrayList objectArrayList=(WTArrayList) objectPhastemplateMap.get(ptTemplate);
                if(linkList!=null){


                    if (logger.isTraceEnabled())
                        logger.trace("Value: " + linkList);

                    Iterator objIterator= objectArrayList.iterator();
                    while(objIterator.hasNext()){
                        ObjectReference objRef= (ObjectReference)objIterator.next();
                        WTObject object = (WTObject) objRef.getObject();

                        WTKeyedHashMap emptyTransitionMap = new WTKeyedHashMap();
                        emptyTransitionMap.put(ptTemplate, linkList);

                        WTKeyedHashMap stateTransitionMap = new WTKeyedHashMap (emptyTransitionMap);
                        returnMap.put(object,stateTransitionMap);
                    }

                }

            }

        }


        if (logger.isTraceEnabled()) {
            Iterator it1 = returnMap.wtKeySet().persistableIterator();

            while (it1.hasNext()) {
                WTObject key1 = (WTObject)it1.next();
                if (key1 instanceof LifeCycleTemplate) {
                    lct = (LifeCycleTemplate)key1;
                }
                else if (key1 instanceof LifeCycleManaged) {
                    LifeCycleManaged lcmObject = (LifeCycleManaged)key1;
                    State state = lcmObject.getState().getState();
                    LifeCycleTemplateReference lRef = lcmObject.getLifeCycleTemplate();
                    lct = (LifeCycleTemplate)lRef.getObject();
                }
                if (logger.isTraceEnabled())
                {
                    if(key1!=null)
                        logger.trace("key1 is "+key1);
                    logger.trace("-Lifecycle is "+lct.getName());
                }
                WTKeyedHashMap states = (WTKeyedHashMap)returnMap.get(key1);
                Iterator it2 = states.wtKeySet().persistableIterator();
                while (it2.hasNext()) {
                    PhaseTemplate pt = (PhaseTemplate)it2.next();
                    if (logger.isTraceEnabled())
                    {
                        logger.trace("--State is "+pt.getName());
                    }
                    WTArrayList transitions = (WTArrayList)states.get(pt);
                    if (transitions != null) {
                        Iterator it3 = transitions.persistableIterator();
                        while (it3.hasNext()) {
                            PhaseSuccession ps = (PhaseSuccession)it3.next();
                            if (logger.isTraceEnabled())
                            {
                                logger.trace("----Transition is "+ps.getName());
                                logger.trace("Succession state is "+((PhaseTemplate)ps.getRoleBObject()).getPhaseState());
                            }
                        }
                    }
                }
            }
        }

        if (logger.isTraceEnabled())
            logger.trace("=> End navigateForReviseAction( WTKeyedMap c, Transition transition, boolean successor ) :: " +  transition);
        return returnMap;
    }

	

    private void refreshIBAs(WTKeyedMap c) throws WTException, LifeCycleException {
        WTObject wtObject = null;
        WTCollection collection = new WTArrayList();
             
        Iterator keyItr =  c.wtKeySet().persistableIterator();
     
        while (keyItr.hasNext()) {
            wtObject = (WTObject) keyItr.next();
            if (wtObject != null && wtObject instanceof IBAHolder && PersistenceHelper.isPersistent(wtObject))
                collection.add(wtObject);
        }

        try{
            if (logger.isTraceEnabled())
                logger.trace("=> In refreshIBAAttributes collection size:: " +  collection.size());

            if(collection!=null && !collection.isEmpty())
                IBAValueHelper.service.refreshAttributeContainerWithoutConstraints( (WTCollection) collection);

            if (logger.isTraceEnabled())
                logger.trace("=> out refreshIBAAttributes Returned collection size:: " +  collection.size());

        }catch(RemoteException e){
            throw new WTException(e);
        }

        if (logger.isTraceEnabled()) {
            logger.trace("=> Input collection size:: " +  c.size());       
        }

       
    }

    /**
     *  Returns a list of selected lifecycle templates objects
     */
    public List getSelectedTemplates(String selectedTemplates){
        LOGGER.debug("StandardLifeCycleService.getSelectedTemplates : IN..." + selectedTemplates);
        List list=new ArrayList();
        LifeCycleTemplate template=null;
        if(selectedTemplates != null){
            StringTokenizer st=new StringTokenizer(selectedTemplates,",");
            while (st.hasMoreTokens()) {
                String strOid=st.nextToken();
                strOid=strOid.trim();
                LOGGER.debug(strOid);
                try{
                    ReferenceFactory rf=new ReferenceFactory();
                    WTReference wfTempRef=rf.getReference(strOid);
                    WTObject template_obj=(WTObject) wfTempRef.getObject();
                    if(template_obj instanceof LifeCycleTemplate)
                        template=(LifeCycleTemplate) wfTempRef.getObject();
                }catch (Exception e) {
                    LOGGER.error(e);
                }
                if(template != null)
                    list.add(template);
            }
        }
        LOGGER.debug("StandardLifeCycleService.getSelectedTemplates : OUT...");
        return list;
    }
    

    /**
     * To repair the lifecyclehistory table when the disconnected user is
     * repaired. Change the old user reference in the history with the new
     * user reference.
     *
     * <BR><BR><B>Supported API: </B>false
     *
     * @param     newActorUser
     * @param     oldActorUser
     * @exception wt.lifecycle.LifeCycleException
     **/

    @SuppressWarnings("deprecation")
    public void updateHistory( WTUser newActorUser, WTUser oldActorUser )
            throws LifeCycleException {

        if(REPAIR_HISTORY) {
            Transaction trx = new Transaction();
            WTArrayList lcHistoryList = new WTArrayList();

            try {
                trx.start();
                SearchCondition sc = new SearchCondition(LifeCycleHistory.class,
                        wt.lifecycle.LifeCycleHistory.ACTOR_NAME,
                        SearchCondition.EQUAL,
                        oldActorUser.getName(),
                        true);
                QuerySpec historyQuerySpec = new QuerySpec(LifeCycleHistory.class);
                historyQuerySpec.appendWhere(sc);

                QueryResult results = PersistenceServerHelper.manager.query(historyQuerySpec);

                Enumeration qResult = results.getEnumeration();
                while(qResult.hasMoreElements()) {
                    LifeCycleHistory lifeCycleHistory = (LifeCycleHistory) qResult.nextElement();
                    lifeCycleHistory.setActorName(newActorUser.getName());
                    WTPrincipalReference ref = new WTPrincipalReference();
                    ref.setObject(newActorUser);
                    lifeCycleHistory.setActorReference(ref);
                    lcHistoryList.add(lifeCycleHistory);
                }

                PersistenceServerHelper.manager.update(lcHistoryList);
                if(logger.isTraceEnabled())
                    logger.trace("LifeCycleHistory table updated.");
                trx.commit();
                trx = null;
            }catch (WTPropertyVetoException wpvex) {
                if(logger.isDebugEnabled()){
                    logger.debug(wpvex.getLocalizedMessage(), wpvex);
                }
                throw new LifeCycleException(wpvex);
            }catch (WTException wex) {
                if(logger.isDebugEnabled()){
                    logger.debug(wex.getLocalizedMessage(), wex);
                }
                throw new LifeCycleException(wex);
            }
            finally {
                if (trx != null)
                    trx.rollback();
            }
        } // if repair_history

    }

   



}

