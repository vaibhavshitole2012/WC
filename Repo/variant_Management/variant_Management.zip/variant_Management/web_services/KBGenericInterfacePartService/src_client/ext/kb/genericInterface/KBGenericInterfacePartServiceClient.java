package ext.kb.genericInterface;

// import the classes generated when compiling your client
import com.ptc.jws.client.handler.*;

public class KBGenericInterfacePartServiceClient
{
    public static void main ( String [] args ) throws java.lang.Exception
    {
        // depending on your security requirements you may need to specify credentials up
        // front, or on the command-line where most policies will prompt for them
        //Credentials.setUsername ( "demo" );
        //Credentials.setPassword ( "demo" );
        // TODO implement your client
        /*
        KBGenericInterfacePartServiceImplService service = new KBGenericInterfacePartServiceImplService();
        KBGenericInterfacePartServiceImpl port = service.getKBGenericInterfacePartServiceImplPort ();
        //invoke an action
        //port.methodName ( <arguments> );
        */
    }
}