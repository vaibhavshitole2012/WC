package ext.kb.ws;

import java.beans.PropertyVetoException;
import java.io.File;
import java.io.IOException;
import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.xml.bind.JAXBException;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;


import wt.configurablelink.ConfigurableLinkHelper;
import wt.configurablelink.ConfigurableRevisionLink;
import wt.content.ApplicationData;
import wt.content.ContentHelper;
import wt.content.ContentRoleType;
import wt.content.FormatContentHolder;
import wt.doc.WTDocument;
import wt.doc.WTDocumentMaster;
import wt.enterprise.EnterpriseHelper;
import wt.fc.ObjectNoLongerExistsException;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.fc.collections.WTHashSet;
import wt.folder.Folder;
import wt.folder.FolderHelper;
import wt.iba.definition.litedefinition.AttributeDefDefaultView;
import wt.iba.value.IBAHolder;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerRef;
import wt.inf.library.WTLibrary;
import wt.lifecycle.LifeCycleException;
import wt.lifecycle.LifeCycleHelper;
import wt.lifecycle.State;
import wt.log4j.LogR;
import wt.org.WTOrganization;
import wt.org.WTPrincipalReference;
import wt.part.WTPart;
import wt.pdmlink.PDMLinkProduct;
import wt.pds.StatementSpec;
import wt.pom.PersistenceException;
import wt.pom.Transaction;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.series.MultilevelSeries;
import wt.series.SeriesException;
import wt.type.TypeDefinitionReference;
import wt.type.TypedUtilityServiceHelper;
import wt.util.WTException;
import wt.util.WTProperties;
import wt.util.WTPropertyVetoException;
import wt.vc.IterationIdentifier;
import wt.vc.VersionControlException;
import wt.vc.VersionControlHelper;
import wt.vc.VersionIdentifier;
import wt.vc.wip.NonLatestCheckoutException;
import wt.vc.wip.WorkInProgressException;
import wt.vc.wip.WorkInProgressHelper;
import wt.vc.Versioned;
import com.ptc.core.lwc.server.PersistableAdapter;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.TypeIdentifierHelper;
import com.ptc.core.meta.common.impl.WCTypeIdentifier;
import com.ptc.generic.iba.AttributeService;
import com.ptc.jws.servlet.JaxWsWebService;
import com.ptc.wpcfg.utilities.PrincipalHelper;

import ext.kb.project.ProjectHelper;
import ext.kb.service.WebServiceHelper;
import ext.kb.util.DBUtils;
import ext.kb.util.DocumentVariantHelper;
import ext.kb.util.IBAHelper;
import ext.kb.util.KBConstants;
import ext.kb.util.KBTypeIdProvider;
import ext.kb.util.KBUtils;
import ext.kb.util.MaterialHelper;
import ext.kb.util.NamingHelper;
import ext.kb.util.ObjectRevisionHelper;

@WebService()
public class KBUpdateDocumentService extends JaxWsWebService {
	private static final Logger LOGGER = LogR.getLogger(KBUpdateDocumentService.class.getName());
	private static final Logger logWriter = LogR.getLogger("ext.kb.ws.KBUpdateDocumentService_Log");

	@WebMethod(operationName = "updateDocument")
	public List<String> updateDocument(@WebParam(name = "docID") String docID,
			@WebParam(name = "ibas") HashMap<String, String> ibas, @WebParam(name = "name") String name,
			@WebParam(name = "number") String number,
			@WebParam(name = "responsibleDepartment") String responsibleDepartment,
			@WebParam(name = "primaryContentPath") String primaryContentPath,
			@WebParam(name = "contentFileName") String contentFileName,
			@WebParam(name = "contentLocation") String contentLocation,
			@WebParam(name = "creatorName") String creatorName,
			@WebParam(name = "revisionIdentifier") String revisionIdentifier,
			@WebParam(name = "targetState") String targetState,
			@WebParam(name = "checkinComment") String checkinComment,
			@WebParam(name = "masterSystem") String masterSystem,
			@WebParam(name = "secondaryContent") String secondaryContent[][],
			@WebParam(name = "additionalLanguages") String additionalLanguages[][],
			@WebParam(name = "Old_CID") String Old_CID)
			throws WTException, JAXBException, ParseException, PropertyVetoException, IOException

	{
		WTDocument resDoc = null;
		WTDocument latestDocIteration = null;
		WTDocument workingCopyDoc = null;
		WTDocumentMaster parentMaster = null;
		Transaction trx = null;
		Timestamp oldCadimTransferDate;
		List<String> result = new ArrayList<String>();
		int counter = 0;
		WTProperties properties = WTProperties.getServerProperties();
		String defaultDomain = properties.getProperty("KBDefaultExternalDomain", "CADIM DOMAIN");
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
		final String RELEASED = "1050";
		Timestamp transferDate = new Timestamp(dateFormat.parse(ibas.get("KB_CADIM_TRANSFER_DATE")).getTime());

		try {

			trx = new Transaction();
			trx.start();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			Date date = new Date();
			String formatedDate = sdf.format(date);
			logWriter.info("Processing Update request on " + formatedDate + " for document where number is " + number
					+ " and name is " + name + " responsibleDepartment = " + responsibleDepartment
					+ " primaryContentPath = " + primaryContentPath + " defaultUnit = " + creatorName + " creatorName "
					+ creatorName + "  Old_CID " + Old_CID);
			String C_ID = ibas.get("KB_CADIM_CID");
			
			// to get translation ID from ibas
			String translationID = "";
			String namingPartValue = "";
			if (ibas.keySet().contains(KBConstants.TRANSLATION_ID_IBA)) {
				translationID = ibas.get(KBConstants.TRANSLATION_ID_IBA);
				LOGGER.debug("TranslationID is : " + translationID);
				// Getting Description 1 EN value using NamingEntry and translation ID
				if (translationID != null && !translationID.equalsIgnoreCase("")) {
					LOGGER.debug("translationID has been obtained. Translation ID is :" + translationID);
					WTPart namingPart = NamingHelper.getNamingEntryByNumber(translationID);
					LOGGER.debug("Naming catalog part obtained is :" + namingPart);
					if (namingPart != null) {
						namingPartValue = namingPart.getName();
						LOGGER.debug("Naming catalog part name is :" + namingPartValue);
					}
				}
			}
			

			if (Old_CID != null) {
				QuerySpec newQS = WebServiceHelper.findDocumentByNumberAndCadim(docID, Old_CID);
				QueryResult newQR = PersistenceHelper.manager.find((StatementSpec) newQS);
				
				int size = newQR.size();
				LOGGER.debug("size: " + size);
				if (size > 0) {
					Persistable newObj[] = (Persistable[]) newQR.nextElement();
					resDoc = (WTDocument) newObj[0];
					
					WTDocument latestDocRevision = (WTDocument) ObjectRevisionHelper
							.getLatestVersionByPersistable(resDoc);
					latestDocIteration = (WTDocument) VersionControlHelper.getLatestIteration(latestDocRevision);
					LOGGER.debug("Revision is " + latestDocIteration.getVersionIdentifier().getValue());
					logWriter.info("Revision is " + latestDocIteration.getVersionIdentifier().getValue());
					String docRevInfo = latestDocIteration.getVersionIdentifier().getValue();
					oldCadimTransferDate = IBAHelper.readIBA(latestDocIteration, "KB_CADIM_TRANSFER_DATE");
					LOGGER.debug("Document found with KB_CADIM_TRANSFER_DATE " + oldCadimTransferDate);
					logWriter.info("Document found with KB_CADIM_TRANSFER_DATE " + oldCadimTransferDate);
					if (oldCadimTransferDate.after(transferDate)) {
						LOGGER.debug("Trigger date is earlier that CADIM Update date Skipping the trigger");
						logWriter.info("Trigger date is earlier that CADIM Update date Skipping the trigger");
						throw new WTException("Trigger date " + transferDate + "is earlier that CADIM Update date "
								+ oldCadimTransferDate + " for doc version "
								+ latestDocIteration.getVersionIdentifier().getValue() + " and Iteration  "
								+ latestDocIteration.getIterationIdentifier().getValue() + " Skipping the trigger");
					}
					LOGGER.debug("revisionIdentifier " + revisionIdentifier);
					logWriter.info("revisionIdentifier " + revisionIdentifier);
					LOGGER.debug("docRevInfo " + docRevInfo);
					logWriter.info("docRevInfo " + docRevInfo);
					if (!revisionIdentifier.equalsIgnoreCase(docRevInfo)) {
						LOGGER.debug("Revision is " + latestDocIteration.getVersionIdentifier().getValue());
						logWriter.info("Revision is " + latestDocIteration.getVersionIdentifier().getValue());
						// latestDocIteration = (WTDocument)
						// VersionControlHelper.service.newVersion(latestDocIteration);
						latestDocIteration.getMaster().setSeries("wt.series.HarvardSeries.KB_Revision");
						MultilevelSeries multilevelseries = MultilevelSeries
								.newMultilevelSeries("wt.series.HarvardSeries.KB_Revision", revisionIdentifier);
						VersionIdentifier versionidentifier = VersionIdentifier.newVersionIdentifier(multilevelseries);
						IterationIdentifier iterationIdentifier = (IterationIdentifier) IterationIdentifier
								.newIterationIdentifier("0");
						latestDocIteration = (WTDocument) VersionControlHelper.service.newVersion(latestDocIteration,
								versionidentifier, iterationIdentifier);
						logWriter.info("New Revision Created by ==" + creatorName);
						LOGGER.debug("Created by ==" + creatorName);
						if (creatorName != null) {
							WTPrincipalReference principalReference = PrincipalHelper.getPrincipal(creatorName);
							if (principalReference != null) {
								VersionControlHelper.assignIterationCreator(latestDocIteration, principalReference);
								logWriter.info("After assigning creator name==" + creatorName);
							} else {
								WTPrincipalReference principalReference1 = PrincipalHelper
										.getPrincipal("INTERFACE_SAP");
								VersionControlHelper.assignIterationCreator(latestDocIteration, principalReference1);
								logWriter.info("After assigning creator name INTERFACE_SAP");
							}
						}
						latestDocIteration = (WTDocument) PersistenceHelper.manager.save(latestDocIteration);
						latestDocIteration = (WTDocument) PersistenceHelper.manager.refresh(latestDocIteration);
						latestDocIteration = (WTDocument) IBAHelper.setIba(latestDocIteration, "KB_CADIM_CID", C_ID);
						PersistenceServerHelper.manager.update(latestDocIteration);
						parentMaster = (WTDocumentMaster) latestDocIteration.getMaster();
						LOGGER.debug("containerName name ===" + latestDocIteration.getContainerName());
						logWriter.info("containerName name ===" + latestDocIteration.getContainerName());
						LOGGER.debug(" Document domain before \"" + latestDocIteration.getDomainRef().getName()
								+ "\" domain");
						logWriter.info(" Document domain before \"" + latestDocIteration.getDomainRef().getName()
								+ "\" domain");
						// WebServiceHelper.setCadimDomain(latestDocIteration,
						// defaultDomain,latestDocIteration.getContainerName());
						LOGGER.debug(" Document domain After \"" + latestDocIteration.getDomainRef().getName()
								+ "\" domain");
						logWriter.info(" Document domain After \"" + latestDocIteration.getDomainRef().getName()
								+ "\" domain");
						docRevInfo = latestDocIteration.getVersionIdentifier().getValue();
						LOGGER.debug("After new revision Revision is " + docRevInfo);
					}
				} else {
					throw new WTException(" Document with number " + docID + " and CID " + Old_CID + " not found");
				}
			}

			// if (Old_CID == null) {
			else {

				LOGGER.debug("KB_CADIM_CID is ===" + C_ID);
				logWriter.info("OLD CID is null");
				QuerySpec resQS = WebServiceHelper.findDocumentByNumberAndCadim(docID, C_ID);
				QueryResult resQR = PersistenceHelper.manager.find((StatementSpec) resQS);
				LOGGER.debug("resQR: " + resQR);
				int size = resQR.size();
				LOGGER.debug("size: " + size);
				LOGGER.debug("OLD_CID ===" + Old_CID);
				LOGGER.debug("Old_CID == null ===" + (Old_CID != null));

				if (size > 0) {
					Persistable resObj[] = (Persistable[]) resQR.nextElement();
					logWriter.info("resObj: " + resObj);

					logWriter.info("resObj: " + resObj[0]);
					resDoc = (WTDocument) resObj[0];
					logWriter.info("resDoc: " + resDoc);
					WTDocument latestDocRevision = (WTDocument) ObjectRevisionHelper
							.getLatestVersionByPersistable(resDoc);
					latestDocIteration = (WTDocument) VersionControlHelper.getLatestIteration(latestDocRevision);
					oldCadimTransferDate = IBAHelper.readIBA(latestDocIteration, "KB_CADIM_TRANSFER_DATE");
					LOGGER.debug("Part found with KB_CADIM_TRANSFER_DATE " + oldCadimTransferDate);
					logWriter.info("Part found with KB_CADIM_TRANSFER_DATE " + oldCadimTransferDate);
					if (oldCadimTransferDate.after(transferDate)) {
						LOGGER.debug("Trigger date is earlier that CADIM Update date Skipping the trigger");
						logWriter.info("Trigger date is earlier that CADIM Update date Skipping the trigger");
						throw new WTException("Trigger date " + transferDate + "is earlier that CADIM Update date "
								+ oldCadimTransferDate + " for doc version "
								+ latestDocIteration.getVersionIdentifier().getValue() + " and Iteration  "
								+ latestDocIteration.getIterationIdentifier().getValue() + " Skipping the trigger");
					}
					String docRevInfo = latestDocIteration.getVersionIdentifier().getValue();
					LOGGER.debug("revisionIdentifier " + revisionIdentifier);
					logWriter.info("revisionIdentifier " + revisionIdentifier);
					LOGGER.debug("docRevInfo " + docRevInfo);
					logWriter.info("docRevInfo " + docRevInfo);
					boolean isNextRev = false;
					LOGGER.debug("Is numeric : "+StringUtils.isNumeric(docRevInfo)+" "+StringUtils.isNumeric(revisionIdentifier));
					if(StringUtils.isNumeric(docRevInfo) && StringUtils.isNumeric(revisionIdentifier)){
						LOGGER.debug("Both Revisions are numeric");
						int intDocRevInfo = Integer.parseInt(docRevInfo);
						int intRevisionIdentifier = Integer.parseInt(revisionIdentifier);
						
						if(intDocRevInfo<intRevisionIdentifier){
							isNextRev = true;
						}
					}else if(!StringUtils.isNumeric(docRevInfo) && !StringUtils.isNumeric(revisionIdentifier)){
						LOGGER.debug("Both Revisions are not numeric");
						if(revisionIdentifier.compareTo(docRevInfo)>0){
							isNextRev = true;
						}
					}
					LOGGER.debug("isNextRev : "+isNextRev);
					if (isNextRev && !revisionIdentifier.equalsIgnoreCase(docRevInfo)) {
						LOGGER.debug("Revision is " + latestDocIteration.getVersionIdentifier().getValue());
						logWriter.info("Revision is " + latestDocIteration.getVersionIdentifier().getValue());
						latestDocIteration.getMaster().setSeries("wt.series.HarvardSeries.KB_Revision");
						MultilevelSeries multilevelseries = MultilevelSeries
								.newMultilevelSeries("wt.series.HarvardSeries.KB_Revision", revisionIdentifier);
						VersionIdentifier versionidentifier = VersionIdentifier.newVersionIdentifier(multilevelseries);
						IterationIdentifier iterationIdentifier = (IterationIdentifier) IterationIdentifier
								.newIterationIdentifier("0");
						latestDocIteration = (WTDocument) VersionControlHelper.service.newVersion(latestDocIteration,
								versionidentifier, iterationIdentifier);
						logWriter.info("New Revision Created by ==" + creatorName);
						LOGGER.debug("Created by ==" + creatorName);
						if (creatorName != null) {
							WTPrincipalReference principalReference = PrincipalHelper.getPrincipal(creatorName);
							if (principalReference != null) {
								VersionControlHelper.assignIterationCreator(latestDocIteration, principalReference);
								logWriter.info("After assigning creator name==" + creatorName);
							} else {
								WTPrincipalReference principalReference1 = PrincipalHelper
										.getPrincipal("INTERFACE_SAP");
								VersionControlHelper.assignIterationCreator(latestDocIteration, principalReference1);
								logWriter.info("After assigning creator name INTERFACE_SAP");
							}
						}
						latestDocIteration = (WTDocument) PersistenceHelper.manager.save(latestDocIteration);
						latestDocIteration = (WTDocument) PersistenceHelper.manager.refresh(latestDocIteration);
						latestDocIteration = (WTDocument) IBAHelper.setIba(latestDocIteration, "KB_CADIM_CID", C_ID);
						PersistenceServerHelper.manager.update(latestDocIteration);
						parentMaster = (WTDocumentMaster) latestDocIteration.getMaster();
						docRevInfo = latestDocIteration.getVersionIdentifier().getValue();
						LOGGER.debug("After new revision Revision is " + docRevInfo);
					}else{
						QueryResult qr = VersionControlHelper.service.allVersionsOf(latestDocIteration.getMaster());
						LOGGER.debug("Query Size : "+qr.size());
						while(qr.hasMoreElements()){
							WTDocument doc = (WTDocument)qr.nextElement();
							
							String ver = doc.getVersionIdentifier().getValue();
							if(ver.equalsIgnoreCase(revisionIdentifier)){
								latestDocIteration = (WTDocument) ObjectRevisionHelper.getLatestIterationOfVersion(doc, true);
								break;
							}
						}
					}
				} else {
					throw new WTException(" Document with number " + docID + " and CID " + C_ID + " not found");
				}
			}

			LOGGER.debug("latestPartIteration111: " + latestDocIteration);
			logWriter.info("latestPartIteration111: " + latestDocIteration);
			if(latestDocIteration!=null){
				LOGGER.debug("Latest Doc version : "+latestDocIteration.getVersionIdentifier().getValue()+"."+latestDocIteration.getIterationIdentifier().getValue());
			}
			boolean docCheckedOut = WorkInProgressHelper.isCheckedOut(latestDocIteration);
			LOGGER.debug("docCheckedOut: " + docCheckedOut);
			logWriter.info("docCheckedOut: " + docCheckedOut);
			if (!docCheckedOut) {
				LOGGER.debug("latestPartIteration: " + latestDocIteration);
				logWriter.info("latestPartIteration: " + latestDocIteration);
				LOGGER.debug("parentMaster: " + parentMaster);
				logWriter.info("parentMaster: " + parentMaster);

				LOGGER.debug("number: " + number);
				logWriter.info("number: " + number);

				LOGGER.debug("name: " + name);
				logWriter.info("name: " + name);
				LOGGER.debug("Revision is " + latestDocIteration.getVersionIdentifier().getValue());
				logWriter.info("Revision is " + latestDocIteration.getVersionIdentifier().getValue());
				LOGGER.debug("Iteration is " + latestDocIteration.getIterationIdentifier().getValue());
				logWriter.info("Iteration is " + latestDocIteration.getIterationIdentifier().getValue());

				LOGGER.debug("b4 set name number ");
				logWriter.info("b4 set name number ");
				String orgName = latestDocIteration.getOrganizationName();
				LOGGER.debug("Org name is ===" + orgName);
				logWriter.info("Org name is ===" + orgName);
				String docName = latestDocIteration.getName();
				LOGGER.debug("DocName is ===" + docName);
				logWriter.info("DocName is ===" + docName);
				String docNumber = latestDocIteration.getNumber();
				LOGGER.debug("DocNumber is ===" + docNumber);
				logWriter.info("DocNumber is ===" + docNumber);
				WTOrganization wtorg = MaterialHelper.getWTOrganization(orgName);
				TypeIdentifier targetType = wt.type.TypedUtilityServiceHelper.service
						.getTypeIdentifier(latestDocIteration);
				LOGGER.debug("targetType " + targetType);
				logWriter.info("targetType " + targetType);
				PersistableAdapter persistanceAdapter = new PersistableAdapter((Persistable) latestDocIteration,
						((WCTypeIdentifier) targetType).getLeafName(), null, null);
				LOGGER.debug("persistanceAdapter " + persistanceAdapter);
				logWriter.info("persistanceAdapter " + persistanceAdapter);
				WorkInProgressHelper.service.checkout(latestDocIteration,
						WorkInProgressHelper.service.getCheckoutFolder(),
						"Checked out to synchronize update from CADIM");
				LOGGER.debug("After checkout");
				logWriter.info("After checkout");
				workingCopyDoc = (WTDocument) WorkInProgressHelper.service.workingCopyOf(latestDocIteration);
				LOGGER.debug("workingCopyDoc" + workingCopyDoc);
				logWriter.info("workingCopyDoc" + workingCopyDoc);
				PersistableAdapter workingDocAdapter = new PersistableAdapter((Persistable) workingCopyDoc,
						((WCTypeIdentifier) targetType).getLeafName(), null, null);
				LOGGER.debug("workingDocAdapter" + workingDocAdapter);
				logWriter.info("workingDocAdapter" + workingDocAdapter);
				persistanceAdapter.load(ibas.keySet());
				workingDocAdapter.load(ibas.keySet());

				for (Entry<String, String> attEntry : ibas.entrySet()) {
					AttributeDefDefaultView attributeDefinition = IBAHelper
							.getAttributeDefDefaultView(attEntry.getKey());
					LOGGER.debug("Attribute Definition ==" + attributeDefinition);
					logWriter.info("Attribute Definition ==" + attributeDefinition);
					LOGGER.debug("Attribute name is" + attEntry.getKey());
					logWriter.info("Attribute name is" + attEntry.getKey());
					
					// setting description 1 EN from translation ID - start
					if (KBConstants.DESCRIPTION_EN.equalsIgnoreCase(attEntry.getKey())) {
						attEntry.setValue(namingPartValue);
						LOGGER.debug("Setting attribute KB_DESCRIPTION_EN value as : " + namingPartValue);
					}
					// setting description 1 EN from translation ID - stop
					
					if (attEntry.getValue() != null && !attEntry.getValue().equals("")) {

						LOGGER.debug(" Attribute Value is not null it is " + attEntry.getValue());
						logWriter.info(" Attribute Value is not null it is " + attEntry.getValue());
						AttributeDefDefaultView attributeDefDefaultView = IBAHelper
								.getAttributeDefDefaultView(attEntry.getKey());
						Object attrValue = WebServiceHelper.parseAttributeValue(attributeDefDefaultView,
								attEntry.getValue());
						LOGGER.debug("Attribute name is" + attEntry.getKey() + " Attribute Value is " + attrValue);
						logWriter.info("Attribute name is" + attEntry.getKey() + " Attribute Value is " + attrValue);
						workingDocAdapter.set(attEntry.getKey(), attrValue);
						if(attEntry.getKey().equals(KBConstants.KBLANGUAGE_IBA))
						{
							String [] langStr = attrValue.toString().split("/");
							LOGGER.debug("langStr "+langStr);
							workingDocAdapter.set(attEntry.getKey(), langStr);
						}
					}
				}

				workingDocAdapter.apply();
				PersistenceHelper.manager.save(workingCopyDoc);
				workingCopyDoc = (WTDocument) WorkInProgressHelper.service.checkin(workingCopyDoc, checkinComment);
				workingCopyDoc = (WTDocument) PersistenceHelper.manager.refresh(workingCopyDoc);
				LOGGER.debug("After check in ");
				LOGGER.debug("containerName name ===" + workingCopyDoc.getContainerName());
				logWriter.info("containerName name ===" + workingCopyDoc.getContainerName());
				LOGGER.debug(" part domain before \"" + workingCopyDoc.getDomainRef().getName() + "\" domain");
				logWriter.info(" part domain before \"" + workingCopyDoc.getDomainRef().getName() + "\" domain");
				LOGGER.debug(" part domain After \"" + workingCopyDoc.getDomainRef().getName() + "\" domain");
				logWriter.info(" part domain After \"" + workingCopyDoc.getDomainRef().getName() + "\" domain");

				LOGGER.debug("Created by ==" + creatorName);
				logWriter.info("Created by ==" + creatorName);
				if (creatorName != null) {
					WTPrincipalReference principalReference = PrincipalHelper.getPrincipal(creatorName);
					if (principalReference != null) {
						LOGGER.debug("Setting Modified By " + principalReference.getDisplayName());
						logWriter.info("Setting Modified By " + principalReference.getDisplayName());
						VersionControlHelper.setIterationModifier(workingCopyDoc, principalReference);
						LOGGER.debug("After Setting Modified By for version "
								+ workingCopyDoc.getVersionInfo().getIdentifier().getValue() + " and iteration "
								+ workingCopyDoc.getIterationInfo().getIdentifier().getValue());
						logWriter.info("After Setting Modified By for version "
								+ workingCopyDoc.getVersionInfo().getIdentifier().getValue() + " and iteration "
								+ workingCopyDoc.getIterationInfo().getIdentifier().getValue());
					} else {
						WTPrincipalReference principalReference1 = PrincipalHelper.getPrincipal("INTERFACE_SAP");
						VersionControlHelper.setIterationModifier(workingCopyDoc, principalReference1);
					}
				}

				PersistenceHelper.manager.save(workingCopyDoc);
				LOGGER.debug(" After saving the working copy ");
				logWriter.info(" After saving the working copy ");

				if (primaryContentPath != null) {
					ApplicationData content = ApplicationData.newApplicationData(latestDocIteration);
					final QueryResult existingContent = ContentHelper.service.getContentsByRole(
							(FormatContentHolder) latestDocIteration, ContentRoleType.toContentRoleType("PRIMARY"),
							false);

					LOGGER.debug("existing content " + existingContent.size());
					logWriter.info("existing content " + existingContent.size());
					if (existingContent.size() > 0) {

						ApplicationData appData = null;

						appData = (ApplicationData) existingContent.nextElement();
				
						WebServiceHelper.deleteContent(workingCopyDoc, ContentRoleType.toContentRoleType("PRIMARY"));

						File contentFile = new File(primaryContentPath);
						boolean uploadPrimary = WebServiceHelper.uploadDocContent(workingCopyDoc, contentFile,
								ContentRoleType.toContentRoleType("PRIMARY"));

						// }
					} else {
						File contentFile = new File(primaryContentPath);
						boolean uploadPrimary = WebServiceHelper.uploadDocContent(workingCopyDoc, contentFile,
								ContentRoleType.toContentRoleType("PRIMARY"));
					}
				}

				logWriter.info("secondaryContent.length " + secondaryContent.length);
				WebServiceHelper.deleteContent(workingCopyDoc, ContentRoleType.toContentRoleType("SECONDARY"));
				if (secondaryContent.length > 0) {
					for (int i = 0; i < secondaryContent.length; i++) {
						File secContentFile = new File(secondaryContent[i][0]);
						String description = secondaryContent[i][3];
						boolean uploadSecondary = WebServiceHelper.uploadDocContentwithDescription(workingCopyDoc,
								secContentFile, ContentRoleType.toContentRoleType("SECONDARY"), description);
						LOGGER.debug("doc after refresh " + workingCopyDoc);
						logWriter.info("doc after refresh " + workingCopyDoc);
					}
				}
				logWriter.info("targetState " + targetState);
				if (targetState != null && !targetState.equals("1060") && !targetState.equalsIgnoreCase(workingCopyDoc.getLifeCycleState().toString())) {
					LifeCycleHelper.service.setLifeCycleState(workingCopyDoc, State.toState(targetState));
					logWriter.info("targetState is " + targetState + " for version "
							+ workingCopyDoc.getVersionInfo().getIdentifier().getValue() + " and iteration "
							+ workingCopyDoc.getIterationInfo().getIdentifier().getValue());
					List<WTDocument> variantDocumentList = new ArrayList();
					variantDocumentList = DBUtils.navigateBetweenObjects(WTDocument.class,
							ConfigurableRevisionLink.class, latestDocIteration,
							ConfigurableRevisionLink.ROLE_BOBJECT_ROLE);
					/*if (variantDocumentList.size() > 0) {

						for (WTDocument variantDoc : variantDocumentList) {
							variantDoc = (WTDocument) VersionControlHelper.getLatestIteration(variantDoc);
							LOGGER.debug(
									"VariantDoc number " + variantDoc.getNumber() + " and name " + variantDoc.getName()
											+ " and  version " + variantDoc.getVersionIdentifier().getValue()
											+ " Iteration " + variantDoc.getIterationIdentifier().getValue());
							logWriter.info(
									"VariantDoc number " + variantDoc.getNumber() + " and name " + variantDoc.getName()
											+ " and version " + variantDoc.getVersionIdentifier().getValue()
											+ " Iteration " + variantDoc.getIterationIdentifier().getValue());
							String variantDocCID = IBAHelper.readIBA(variantDoc, "KB_CADIM_CID");
							LOGGER.debug("variantDocCID " + variantDocCID);
							logWriter.info("Source cid " + C_ID);
							if (variantDocCID.equalsIgnoreCase(C_ID)) {
								LifeCycleHelper.service.setLifeCycleState(variantDoc, State.toState(targetState));
								logWriter.info("targetState is " + targetState + " for version "
										+ variantDoc.getVersionInfo().getIdentifier().getValue() + " and iteration "
										+ variantDoc.getIterationInfo().getIdentifier().getValue());
							}
						}
					}*/

				}
				String containerName = resDoc.getContainerName();
				LOGGER.debug("Container name==" + containerName);
				logWriter.info("Container name==" + containerName);
				String docPath = resDoc.getFolderPath();
				String docLocation = resDoc.getLocation();
				LOGGER.debug("docPath name==" + docPath);
				logWriter.info("docPath name==" + docPath);
				LOGGER.debug("docLocation name==" + docLocation);
				logWriter.info("docLocation name==" + docLocation);
				LOGGER.debug("responsibleDepartment name==" + responsibleDepartment);
				LOGGER.debug("responsibleDepartment name==" + responsibleDepartment);
				if (!responsibleDepartment.equalsIgnoreCase(containerName)) {
					WTContainer productContainer = getContainerProduct(responsibleDepartment);
					WTLibrary library = null;
					if (productContainer == null) {
						library = getLibraryContainer(responsibleDepartment);
						if (library != null) {
							LOGGER.debug("Target Container ==="+library.getName());
							logWriter.info("Target Container ===" + library.getName());
						} else {
							LOGGER.debug("Target Container not found");
							logWriter.info("Target Container not found");
						}
					} else {
						LOGGER.debug("Target Container ==="+productContainer.getName());
						logWriter.info("Target Container ===" + productContainer.getName());
					}
					
					WTContainerRef contRef = WTContainerRef.newWTContainerRef(productContainer != null ? productContainer : library);
					try {
						Folder f = FolderHelper.service.getFolder(docLocation, contRef);
						WebServiceHelper.moveDocToContainer(productContainer != null ? productContainer : library, docLocation, resDoc);
						logWriter.info("Moved document to " + responsibleDepartment + docLocation);

					} catch (WTException e) {
						String message = "Destination folder -  " + docLocation
								+ " not found moving to 20 BA - Extended";
						LOGGER.debug(message);
						logWriter.info(message);
						// Folder f =
						// FolderHelper.service.getFolder("/Default/20 Public",
						// contRef);
						WebServiceHelper.moveDocToContainer(productContainer != null ? productContainer : library, "/Default/20 BA - Extended", resDoc);
						logWriter.info("Moved document to " + responsibleDepartment + " /Default/20 BA - Extended");
					}
					
					LOGGER.debug("latestDocIteration : "+latestDocIteration.getNumber()+" "+latestDocIteration.getIterationIdentifier());
					LOGGER.debug("resDoc : "+resDoc.getNumber()+" "+resDoc.getIterationIdentifier());
					QueryResult qrLinks = PersistenceHelper.manager.navigate(latestDocIteration,
							ConfigurableRevisionLink.ROLE_BOBJECT_ROLE, ConfigurableRevisionLink.class, true);
					LOGGER.debug("Variant links from source : "+qrLinks.size());
					while (qrLinks.hasMoreElements()) {
						Object obj = qrLinks.nextElement();
						logWriter.info("Role B object : " + obj);
						LOGGER.debug("Role B object : " + obj);
						if (obj instanceof WTDocument) {
							WTDocument doc = (WTDocument)obj;
							LOGGER.debug("Variant Document number : "+doc.getNumber());
							
							if (!responsibleDepartment.equalsIgnoreCase(doc.getContainerName())) {
								try {
									
									WebServiceHelper.moveDocToContainer(productContainer != null ? productContainer : library, docLocation, doc);
									logWriter.info("Moved variant document to " + responsibleDepartment + docLocation);
									LOGGER.debug("Moved variant document to " + responsibleDepartment + docLocation);

								} catch (WTException e) {
									String message = "Destination folder -  " + docLocation
											+ " not found moving to 20 BA - Extended";
									LOGGER.debug(message);
									logWriter.info(message);
									WebServiceHelper.moveDocToContainer(productContainer != null ? productContainer : library, "/Default/20 BA - Extended", doc);
									logWriter.info("Moved document to " + responsibleDepartment + " /Default/20 BA - Extended");
								}
							}
							
							
						}
					}
					
					WTDocument doc = (WTDocument) VersionControlHelper.getLatestIteration(workingCopyDoc);
					LOGGER.debug("containerName name ===" + doc.getContainerName());
					logWriter.info("containerName name ===" + doc.getContainerName());
					logWriter.info(" Changing domain for version " + doc.getVersionInfo().getIdentifier().getValue()
							+ " and iteration " + doc.getIterationInfo().getIdentifier().getValue());
					LOGGER.debug(" part domain before \"" + doc.getDomainRef().getName() + "\" domain");
					logWriter.info(" part domain before \"" + doc.getDomainRef().getName() + "\" domain");
					LOGGER.debug(" part domain After \"" + doc.getDomainRef().getName() + "\" domain");
					logWriter.info(" part domain After \"" + doc.getDomainRef().getName() + "\" domain");

				}
				
				
				TypeIdentifier typeIdentifier = TypeIdentifierHelper.getTypeIdentifier("com.ptc.KBVariantLink");
				TypeDefinitionReference typeDefinitionReference = TypedUtilityServiceHelper.service
						.getTypeDefinitionReference(typeIdentifier.getTypename());
				
				if (masterSystem != null && masterSystem.equalsIgnoreCase("WCT")) {
					WTDocumentMaster master = (WTDocumentMaster) workingCopyDoc.getMaster();
					IBAHelper.updateIBAAttributeValueWithoutCheckout(master, "KB_MASTERSYSTEM", "WCT");
					LOGGER.debug("After setting master system");
					WTDocument doc = (WTDocument) VersionControlHelper.getLatestIteration(latestDocIteration);
					String articleLocation = doc.getLocation();
					WTContainerRef contRef = doc.getContainerReference();
					LOGGER.debug("containerName name ===" + doc.getContainerName());
					logWriter.info("containerName name ===" + doc.getContainerName());
					String presentFolder = doc.getFolderPath();
					String[] folderPath = presentFolder.split("/");
					LOGGER.debug(" presentFolder" + presentFolder);
					logWriter.info(" presentFolder " + presentFolder);
					String targetFolder = "/" + folderPath[1] + "/" + folderPath[2] + "/Data";
					LOGGER.debug(" targetFolder" + targetFolder);
					logWriter.info(" targetFolder " + targetFolder);
					WebServiceHelper.moveDocToContainer(contRef.getContainer(), targetFolder, doc);
					LOGGER.debug(" Moved " + latestDocIteration.getNumber() + " to folder " + targetFolder);
					logWriter.info(" Moved " + latestDocIteration.getNumber() + " to folder " + targetFolder);
					QueryResult allVarLinks = PersistenceHelper.manager.navigate(latestDocIteration,
							ConfigurableRevisionLink.ROLE_BOBJECT_ROLE, ConfigurableRevisionLink.class, true);
					LOGGER.debug("the document has variants going to move variants as well allLinks size "
							+ allVarLinks.size());
					logWriter.info("the document has variants going to move variants as well allLinks size "
							+ allVarLinks.size());
					WTHashSet varLinkSet = new WTHashSet();
					while (allVarLinks.hasMoreElements()) {
						Object obj = allVarLinks.nextElement();
						logWriter.info("Got: " + obj);
						LOGGER.debug("Got: " + obj);
						if (obj instanceof WTDocument) {
							WTDocument variantDoc = (WTDocument) obj;
							LOGGER.debug("variant document number is  " + variantDoc.getNumber());
							logWriter.info("variant document number is  " + variantDoc.getNumber());
							WTDocumentMaster variantDocMaster = (WTDocumentMaster) variantDoc.getMaster();
							variantDocMaster = (WTDocumentMaster) IBAHelper.setIba(variantDocMaster, "KB_MASTERSYSTEM",
									"WCT");
							PersistenceServerHelper.manager.update(variantDocMaster);
							LOGGER.debug("After setting master system for variant doc");
							String variantLocation = variantDoc.getLocation();
							WTContainerRef varContRef = variantDoc.getContainerReference();
							String varContainerName = variantDoc.getContainerName();
							String varPresentFolder = variantDoc.getFolderPath();
							String[] varFolderPath = varPresentFolder.split("/");
							LOGGER.debug(" varFolderPath" + varFolderPath);
							logWriter.info(" varFolderPath " + varFolderPath);
							String varTargetFolder = "/" + folderPath[1] + "/" + folderPath[2] + "/Data";
							LOGGER.debug(" varTargetFolder" + varTargetFolder);
							logWriter.info(" varTargetFolder " + varTargetFolder);
							WebServiceHelper.moveDocToContainer(varContRef.getContainer(), varTargetFolder, variantDoc);
							LOGGER.debug(" Moved " + variantDoc.getNumber() + " to folder " + varTargetFolder);
							logWriter.info(" Moved " + variantDoc.getNumber() + " to folder " + varTargetFolder);
						}
					}
				}

				if (KBTypeIdProvider.isDescendant(workingCopyDoc, "CERTYFICATEDOC")) {
					logWriter.info("Document is of type certificate ");
					LOGGER.debug("Document is of type certificate ");
					Timestamp validFrom = new Timestamp(dateFormat.parse(ibas.get("KB_VALID_FROM")).getTime());
					logWriter.info("validFrom " + validFrom);
					LOGGER.debug("validFrom " + validFrom);
					Timestamp validUntil = new Timestamp(dateFormat.parse(ibas.get("KB_VALID_UNTIL")).getTime());
					logWriter.info("validUntil " + validUntil);
					LOGGER.debug("validUntil " + validUntil);
					WebServiceHelper.setEffectivityForDocument(workingCopyDoc, validFrom, validUntil);
					logWriter.info("After setting effectivity ");
					LOGGER.debug("After setting effectivity ");
				}

				 // donot delete physical files from shared folder
				/*if (primaryContentPath != null) {
					File contentFolder = new File(contentLocation);
					LOGGER.debug("doc before deleting secondary content file" + contentFolder);
					WebServiceHelper.deleteDir(contentFolder);
					LOGGER.debug("doc After deleting secondary content file" + contentFolder);
				}
				if (secondaryContent.length > 0) {
					for (int i = 0; i < secondaryContent.length; i++) {
						File secContentLocationFile = new File(secondaryContent[i][2]);
						LOGGER.debug("doc before deleting secondary content file" + secContentLocationFile);
						WebServiceHelper.deleteDir(secContentLocationFile);
						LOGGER.debug("doc after deleting secondary content file");
					}
				}*/
				
				WTDocument sourceDoc = (WTDocument) VersionControlHelper.getLatestIteration(latestDocIteration);
				
				//source doc - with cid
				QueryResult allVarLinks = PersistenceHelper.manager.navigate(sourceDoc,
						ConfigurableRevisionLink.ROLE_BOBJECT_ROLE, ConfigurableRevisionLink.class, true);
				WTHashSet varLinkSet = new WTHashSet();
				List<String> varList = new ArrayList<>();  // this list will contain all variants from Windchill
				while (allVarLinks.hasMoreElements()) {
					Object obj = allVarLinks.nextElement();
					logWriter.info("Got: " + obj);
					LOGGER.debug("Got: " + obj);
					if (obj instanceof WTDocument) {
						String varNum = ((WTDocument)obj).getNumber();
						LOGGER.debug("variant document number is  " + varNum);
						logWriter.info("variant document number is  " + varNum);
						varList.add(varNum);   
						String varCID = IBAHelper.readIBA((WTDocument) obj, "KB_CADIM_CID");
						
						LOGGER.debug("variant cid " + varCID + " source cid " + ibas.get("KB_CADIM_CID"));
						logWriter.info("variant cid " + varCID + " source cid " + ibas.get("KB_CADIM_CID"));
						
						if(Old_CID != null){
							if (varCID.equalsIgnoreCase(Old_CID)){
								WTHashSet exisitngVarLinkSet = (WTHashSet) ConfigurableLinkHelper.service
										.getConfigurableLinks(sourceDoc, (WTDocument) obj, typeIdentifier);
								varLinkSet.addAll(ConfigurableLinkHelper.service.getConfigurableLinks(sourceDoc,
										(WTDocument) obj, typeIdentifier));
								LOGGER.debug("exisitngVarLinkSet size " + exisitngVarLinkSet.size());
								logWriter.info("exisitngVarLinkSet size " + exisitngVarLinkSet.size());
							}
						}else{
							if (varCID.equalsIgnoreCase(ibas.get("KB_CADIM_CID"))) {
								LOGGER.debug("Variant Document has the same CID as source doc deleting link");
								logWriter.info("Variant Document has the same CID as source doc deleting link");
								WTHashSet exisitngVarLinkSet = (WTHashSet) ConfigurableLinkHelper.service
										.getConfigurableLinks(sourceDoc, (WTDocument) obj, typeIdentifier);
								varLinkSet.addAll(ConfigurableLinkHelper.service.getConfigurableLinks(sourceDoc,
										(WTDocument) obj, typeIdentifier));
								LOGGER.debug("exisitngVarLinkSet size " + exisitngVarLinkSet.size());
								logWriter.info("exisitngVarLinkSet size " + exisitngVarLinkSet.size());
							}
						}
					}
				}
				
				
				// if the request has additionalLanguages empty, 
				// delete all configurable links for source doc in Windchill
				if (additionalLanguages.length == 0) {
					
					WTDocument variantDoc = null;
					WTDocumentMaster variantDocMaster = null;
					
					LOGGER.debug("Existing allLinks size in Windchill before delete: " + allVarLinks.size());
					logWriter.info("Existing allLinks size in Windchill before delete: " + allVarLinks.size());
					PersistenceHelper.manager.delete(varLinkSet);
				}
					
			
				if (additionalLanguages.length > 0) {
					WTDocument variantDoc = null;
					WTDocumentMaster variantDocMaster = null;
					List<String> addLangListNum = new ArrayList<>();  // this list will contain numbers from additionalLanguage component of request.
					for (int i = 0; i < additionalLanguages.length; i++) {
						logWriter.info("size of additionalLannguages from request:  " + additionalLanguages[i].length);
						LOGGER.debug("size of additionalLannguages from request:  " + additionalLanguages[i].length);
						HashMap<String, String> newAttrMap = new HashMap<String, String>();
						String documentId = IBAHelper.readIBA((IBAHolder) sourceDoc.getMaster(),
								KBConstants.KBDOCUMENT_ID_IBA);
						// if(sap_idx of source is not '000') get source with
						// sap_idx 000
						String sapIdx = AttributeService.getAttribute(sourceDoc, KBConstants.KBSAP_IDX_IBA);
						if (!("000".equals(sapIdx))) {
							sourceDoc = getSourceDocIndexZero(sourceDoc);
						}
						String langNum = documentId + "-" + additionalLanguages[i][1];
						
						addLangListNum.add(langNum);
					    variantDoc = KBUtils.findDocumentByNumber(langNum);
					   
						if (variantDoc != null) {
							/*
							 * Persistable newObj[] = (Persistable[])
							 * newQR.nextElement(); variantDoc = (WTDocument)
							 * newObj[0];
							 */
							
							WTDocument latestvariantDocRevision = (WTDocument) ObjectRevisionHelper.getLatestVersionByPersistable(variantDoc);
							WTDocument latestvariantDocIteration = (WTDocument) VersionControlHelper.getLatestIteration(latestvariantDocRevision);
							variantDoc = updateExistingVariant(creatorName, revisionIdentifier, 
									 C_ID, sourceDoc, latestvariantDocIteration, resDoc);
									
									/*WTHashSet exisitngVarLinkSet = (WTHashSet) ConfigurableLinkHelper.service
									.getConfigurableLinks(sourceDoc, variantDoc, typeIdentifier);
							LOGGER.debug("exisitngVarLinkSet size :: "+exisitngVarLinkSet.size()+" :: Variant doc ::"+variantDoc+" :: Source doc ::"+sourceDoc );
						    LOGGER.debug("Source doc :: "+sourceDoc.getNumber() + " :: Variant doc :: "+variantDoc.getNumber() );
							 	if(exisitngVarLinkSet.isEmpty()){
								
								ConfigurableRevisionLink kbVariantLink = ConfigurableRevisionLink
										.newConfigurableRevisionLink(sourceDoc, variantDoc, typeDefinitionReference);
								PersistenceHelper.manager.save(kbVariantLink);
								
							}*/

						} else {
							LOGGER.debug("Creating VARIANT LINK");
							variantDoc = createVariantAndLink(ibas, additionalLanguages, typeDefinitionReference,
									sourceDoc, i, newAttrMap, documentId, masterSystem);
						}

											
						WTDocument workingCopyVariantDoc = updateIBAandStateOnVariant(sourceDoc,typeIdentifier,typeDefinitionReference, ibas, targetState, checkinComment,
								additionalLanguages, targetType, variantDoc, i);
						// delete all primary and secondary content
						handleContentForVariant(additionalLanguages, i, workingCopyVariantDoc);
					}
					synchronizeVariantsLinksListInWindchill(varList,addLangListNum,sourceDoc,typeIdentifier,Old_CID,ibas);
				}
				System.out.println("trx===" + trx);
				
				LOGGER.debug("Documents State :: " + targetState);
				if(targetState!=null) {
				int intState=Integer.parseInt(targetState);
				if(intState>=1030) {
					LOGGER.debug("Sharing object to project");
					ProjectHelper.updateItemInRelatedSharedProjects(latestDocIteration);
					LOGGER.debug("Shared to project");
					}
				}
				
				trx.commit();
				trx = null;
				result.add("ReturnCode: 0");
				result.add("Text: Success");
				logWriter.info(result);
				return result;
			} else {
				counter = 1;
				throw new WTException(" Document with number " + docID + " and CID " + C_ID + " is checked out");
			}

		} catch (WTException e) {
			e.printStackTrace();
			if (counter == 0) {
				if (WorkInProgressHelper.isCheckedOut(latestDocIteration))
					latestDocIteration = (WTDocument) WorkInProgressHelper.service
							.undoCheckout(WorkInProgressHelper.service.workingCopyOf(latestDocIteration));
			}
			String message = "WTException during update IBA's exception is " + e;
			result.add("ReturnCode: 1");
			result.add("Text: " + message);
			logWriter.info(result);
			return result;

		} catch (WTPropertyVetoException e) {
			e.printStackTrace();
			if (WorkInProgressHelper.isCheckedOut(latestDocIteration))
				latestDocIteration = (WTDocument) WorkInProgressHelper.service
						.undoCheckout(WorkInProgressHelper.service.workingCopyOf(latestDocIteration));
			String message = "WTException during update IBA's exception is " + e;
			result.add("ReturnCode: 1");
			result.add("Text: " + message);
			logWriter.info(result);
			return result;
		} catch (Exception e) {
			e.printStackTrace();
			if (WorkInProgressHelper.isCheckedOut(latestDocIteration))
				latestDocIteration = (WTDocument) WorkInProgressHelper.service
						.undoCheckout(WorkInProgressHelper.service.workingCopyOf(latestDocIteration));
			String message = "Exception during update IBA's exception is " + e;
			result.add("ReturnCode: 1");
			result.add("Text: " + message);
			logWriter.info(result);
			return result;
		} finally {
			System.out.println("trx in finally===" + trx);
			if (trx != null) {
				trx.rollback();
			}
		}
	}

	private void synchronizeVariantsLinksListInWindchill(List varList, List addLangListNum, WTDocument doc, 
			TypeIdentifier tid, String cid, HashMap<String, String> ibas) throws WTException, WTPropertyVetoException{
		varList.removeAll(addLangListNum);
		WTDocument variant = null;
		if(varList.size() != 0){
			for (int j = 0; j < varList.size(); j++){
				String num = (String)varList.get(j);
				if(cid != null){
					QuerySpec varSpec = WebServiceHelper.findDocumentByNumberAndCadim(num, cid);
					QueryResult varQr = PersistenceHelper.manager.find((StatementSpec) varSpec);
					int size = varQr.size();
					if (size > 0) {
						Persistable newObj[] = (Persistable[]) varQr.nextElement();
						variant = (WTDocument) newObj[0];
					}
				}else{
					QuerySpec varSpec = WebServiceHelper.findDocumentByNumberAndCadim(num, ibas.get("KB_CADIM_CID"));
					QueryResult varQr = PersistenceHelper.manager.find((StatementSpec) varSpec);
					int size = varQr.size();
					if (size > 0) {
						Persistable newObj[] = (Persistable[]) varQr.nextElement();
						variant = (WTDocument) newObj[0];
					}
				}
				WTHashSet unValidlinkSet = new WTHashSet();
				if (variant != null){
					unValidlinkSet.addAll(ConfigurableLinkHelper.service.getConfigurableLinks(doc,				
						variant, tid));
				}
				if (unValidlinkSet.size() >0){
					PersistenceHelper.manager.delete(unValidlinkSet);
				}
			}
		}
	}
	

	private WTDocument createVariantAndLink(HashMap<String, String> ibas, String[][] additionalLanguages,
			 TypeDefinitionReference typeDefinitionReference, WTDocument sourceDoc, int i,
			HashMap<String, String> newAttrMap, String documentId, String masterSystem)
			throws WTException, RemoteException, WTPropertyVetoException, ObjectNoLongerExistsException {
		WTDocument variantDoc;
		WTDocumentMaster variantDocMaster;
		LOGGER.debug(" not found variant documnet with number  " + documentId + "-"
				+ additionalLanguages[i][1] + " and CID " + ibas.get("KB_CADIM_CID")
				+ " going to create new document");
		logWriter.info("not found variant documnet with number  " + documentId + "-"
				+ additionalLanguages[i][1] + " and CID " + ibas.get("KB_CADIM_CID")
				+ " going to create new document");
		newAttrMap.put("newNumber", documentId + "-" + additionalLanguages[i][1]);
		variantDoc = ext.kb.util.KBUtils.copyDocument(sourceDoc, newAttrMap,
				FolderHelper.getFolder(sourceDoc), false);
		IBAHelper.setIba((IBAHolder) variantDoc.getMaster(), KBConstants.KBDOCUMENT_ID_IBA,
				documentId);
		logWriter.info("After setting Document id " + documentId);
		LOGGER.debug("After setting Document id  " + documentId);
		variantDoc.setName(sourceDoc.getName());
		logWriter.info("After setting name " + sourceDoc.getName());
		LOGGER.debug("After setting name  " + sourceDoc.getName());
		IBAHelper.setIba((IBAHolder) variantDoc.getMaster(), KBConstants.KBSAP_IDX_IBA,
				additionalLanguages[i][1]);
		logWriter.info("After setting SAP IDX " + additionalLanguages[i][1]);
		LOGGER.debug("After setting SAP IDX  " + additionalLanguages[i][1]);
		String localization = IBAHelper.getStringIBAValue((IBAHolder) sourceDoc.getMaster(),
				KBConstants.KBLOCALIZATION_IBA);
		if (localization != null) {
			IBAHelper.setIba((IBAHolder) variantDoc.getMaster(), KBConstants.KBLOCALIZATION_IBA,
					localization);
		}
		logWriter.info("After setting Localization " + localization);
		LOGGER.debug("After setting Localization " + localization);
		IBAHelper.setIba((IBAHolder) variantDoc, KBConstants.KBLANGUAGE_IBA,
				additionalLanguages[i][0]);
		logWriter.info("After setting Language" + additionalLanguages[i][0]);
		LOGGER.debug("After setting Language " + additionalLanguages[i][0]);
		IBAHelper.setIba((IBAHolder) variantDoc, KBConstants.DESCRIPTION_EN,
				ibas.get("KB_DESCRIPTION_EN"));
		logWriter.info("After setting KB_DESCRIPTION_EN" + ibas.get("KB_DESCRIPTION_EN"));
		LOGGER.debug("After setting KB_DESCRIPTION_EN " + ibas.get("KB_DESCRIPTION_EN"));
		if (!KBTypeIdProvider.isDescendant(sourceDoc, "STANDARDDOC")) {
			logWriter.info("Source document is not standard document going to set translation id");
			LOGGER.debug("Source document is not standard document going to set translation id ");
			IBAHelper.setIba((IBAHolder) variantDoc, KBConstants.TRANSLATION_ID_IBA,
					ibas.get("KB_TRANSLATION_ID"));
			logWriter.info("After setting KB_TRANSLATION_ID" + ibas.get("KB_TRANSLATION_ID"));
			LOGGER.debug("After setting KB_TRANSLATION_ID " + ibas.get("KB_TRANSLATION_ID"));
		}
		variantDoc = WebServiceHelper.reassignRevision(sourceDoc, variantDoc);
		variantDoc = (WTDocument) EnterpriseHelper.service.saveCopy(sourceDoc, variantDoc);
		IBAHelper.setIba(variantDoc, "KB_CADIM_CID", ibas.get("KB_CADIM_CID"));
		logWriter.info("After setting CID " + ibas.get("KB_CADIM_CID"));
		LOGGER.debug("After setting CID  " + ibas.get("KB_CADIM_CID"));
		variantDocMaster = (WTDocumentMaster) IBAHelper
				.setIba((WTDocumentMaster) variantDoc.getMaster(), "KB_MASTERSYSTEM", masterSystem);
		logWriter.info("After setting Master System ");
		LOGGER.debug("After setting Masetr System  ");
		variantDoc = (WTDocument) PersistenceHelper.manager.save(variantDoc);
		variantDoc = (WTDocument) PersistenceHelper.manager.refresh(variantDoc);
		logWriter.info("Source Document is " + sourceDoc.getNumber());
		LOGGER.debug("Source Document is " + sourceDoc.getNumber());
		logWriter.info("Variant Document is " + variantDoc.getNumber());
		LOGGER.debug("Variant Document is " + variantDoc.getNumber());
				
		LOGGER.debug("Deleting COnfigurable links from variant: ");
		DocumentVariantHelper.dropAllLinks(variantDoc);
		
		
		ConfigurableRevisionLink kbVariantLink = ConfigurableRevisionLink
				.newConfigurableRevisionLink(sourceDoc, variantDoc, typeDefinitionReference);
		PersistenceHelper.manager.save(kbVariantLink);
		logWriter.info("After saving Variant link ");
		LOGGER.debug("After saving Variant link");
		return variantDoc;
	}

	private WTDocument updateExistingVariant(String creatorName, String revisionIdentifier,
	  String C_ID, WTDocument sourceDoc, WTDocument variantDoc, WTDocument resDoc)
			throws WTException, VersionControlException, WTPropertyVetoException, SeriesException,
			ObjectNoLongerExistsException, RemoteException {
		WTDocumentMaster variantDocMaster;
		variantDoc = (WTDocument) VersionControlHelper.getLatestIteration(variantDoc);
		LOGGER.debug("Variant document found with Old CID" + variantDoc);
		logWriter.info("Variant document found with Old CID" + variantDoc);
		String sourceDocRevInfo = sourceDoc.getVersionIdentifier().getValue();
		String varDocRevInfo = variantDoc.getVersionIdentifier().getValue();
		LOGGER.debug("revisionIdentifier from request" + revisionIdentifier);
		logWriter.info("revisionIdentifier from request " + revisionIdentifier);
		LOGGER.debug("sourceDocRevInfo " + sourceDocRevInfo);
		logWriter.info("sourceDocRevInfo " + sourceDocRevInfo);
		LOGGER.debug("variant Doc revision for " + variantDoc.getDisplayIdentity() + ": "
				+ varDocRevInfo);
		logWriter.info("variant Doc revision for " + variantDoc.getDisplayIdentity() + ": "
				+ varDocRevInfo);
		if (!revisionIdentifier.equalsIgnoreCase(varDocRevInfo) && KBUtils.isRevisionLower((Versioned) variantDoc, (Versioned) resDoc)) {
			LOGGER.debug("Comparing revisionIdentifier and varDocRevInfo for variant"
					+ variantDoc.getVersionIdentifier().getValue());
			logWriter.info("Comparing revisionIdentifier and varDocRevInfo for variant "
					+ variantDoc.getVersionIdentifier().getValue());
			// latestDocIteration = (WTDocument)
			// VersionControlHelper.service.newVersion(latestDocIteration);
			variantDoc.getMaster().setSeries("wt.series.HarvardSeries.KB_Revision");
			MultilevelSeries multilevelseries = MultilevelSeries
					.newMultilevelSeries("wt.series.HarvardSeries.KB_Revision", revisionIdentifier);
			VersionIdentifier versionidentifier = VersionIdentifier
					.newVersionIdentifier(multilevelseries);
			IterationIdentifier iterationIdentifier = (IterationIdentifier) IterationIdentifier
					.newIterationIdentifier("0");
			variantDoc = (WTDocument) VersionControlHelper.service.newVersion(variantDoc,
					versionidentifier, iterationIdentifier);
			logWriter.info("New Revision Created by ==" + creatorName);

			LOGGER.debug("Created by ==" + creatorName);
			if (creatorName != null) {
				WTPrincipalReference principalReference = PrincipalHelper.getPrincipal(creatorName);
				if (principalReference != null) {
					VersionControlHelper.assignIterationCreator(variantDoc, principalReference);
					logWriter.info("After assigning creator name==" + creatorName);
				} else {
					WTPrincipalReference principalReference1 = PrincipalHelper
							.getPrincipal("INTERFACE_SAP");
					VersionControlHelper.assignIterationCreator(variantDoc, principalReference1);
					logWriter.info("After assigning creator name INTERFACE_SAP");
				}
			}
			variantDoc = (WTDocument) PersistenceHelper.manager.save(variantDoc);
			variantDoc = (WTDocument) PersistenceHelper.manager.refresh(variantDoc);
			variantDoc = (WTDocument) IBAHelper.setIba(variantDoc, "KB_CADIM_CID", C_ID);
			PersistenceServerHelper.manager.update(variantDoc);
			variantDocMaster = (WTDocumentMaster) variantDoc.getMaster();
			String variantDocRevInfo = variantDoc.getVersionIdentifier().getValue();
			LOGGER.debug("After new revision Revision is " + variantDocRevInfo);
		}
		return variantDoc;
	}

	/**
	 * @param additionalLanguages
	 * @param i
	 * @param workingCopyVariantDoc
	 * @throws WTException
	 * @throws WTPropertyVetoException
	 * 
	 * handle content association to variant once created and 
	 * updated by additionalLanguages
	 */
	private void handleContentForVariant(String[][] additionalLanguages, int i,
			WTDocument workingCopyVariantDoc) throws WTException, WTPropertyVetoException {
		WebServiceHelper.deleteContent(workingCopyVariantDoc,
				ContentRoleType.toContentRoleType("PRIMARY"));
		WebServiceHelper.deleteContent(workingCopyVariantDoc,
				ContentRoleType.toContentRoleType("SECONDARY"));
		if (additionalLanguages[i][2] != null && !additionalLanguages[i][2].equals("")) {
			for (int j = 2; j <= (additionalLanguages[i].length - 1); j++) {
				boolean uploadSecondary = false;
				String additionalLanguagesLocationFilePath;
				logWriter.info("after uploading content for variant doc " + uploadSecondary);
				LOGGER.debug("after uploading content for variant doc " + uploadSecondary);
				logWriter.info("doc before deleting content file for variant doc");
				LOGGER.debug("doc before deleting content for variant doc ");
				String descVariantSecondarycontent = "";
				String[] filePathName;
				if ((additionalLanguages[i][j]).contains("|")) {
					String[] descSplit = additionalLanguages[i][j].split("\\|");
					logWriter.info(
							"before uploading content for variant doc, split location: " + descSplit);
					if (!StringUtils.isEmpty(descSplit[1])) {
						descVariantSecondarycontent = descSplit[1];
					}
					additionalLanguagesLocationFilePath = descSplit[0];
					filePathName = descSplit[0].split("/");
					logWriter.info(
							"before uploading content for variant doc filePathName: " + filePathName);
					logWriter.info("before uploading content for variant doc "
							+ additionalLanguagesLocationFilePath);
					LOGGER.debug("before uploading content for variant doc "
							+ additionalLanguagesLocationFilePath);
				} else {
					additionalLanguagesLocationFilePath = additionalLanguages[i][j];
					filePathName = additionalLanguages[i][j].split("/");
					logWriter.info("before uploading content for variant doc "
							+ additionalLanguagesLocationFilePath);
					LOGGER.debug("before uploading content for variant doc "
							+ additionalLanguagesLocationFilePath);
				}
				logWriter.info("filePathName size " + filePathName.length);
				LOGGER.debug("filePathName size " + filePathName.length);
				File additionalLanguagesLocationFile = new File(additionalLanguagesLocationFilePath);
				logWriter.info("before uploading content for variant doc "
						+ additionalLanguagesLocationFilePath);
				if (j == 2) {
					uploadSecondary = WebServiceHelper.uploadDocContent(workingCopyVariantDoc,
							additionalLanguagesLocationFile,
							ContentRoleType.toContentRoleType("PRIMARY"));
				} else {
					uploadSecondary = WebServiceHelper.uploadDocContentwithDescription(
							workingCopyVariantDoc, additionalLanguagesLocationFile,
							ContentRoleType.toContentRoleType("SECONDARY"),
							descVariantSecondarycontent);
				}
				String contentPath = "";
				for (int k = 1; k < (filePathName.length - 1); k++) {
					contentPath = contentPath + "/" + filePathName[k];
					logWriter.info("contentPath " + contentPath);
					LOGGER.debug("contentPath " + contentPath);
				}
				File secContentLocationFile = new File(contentPath);
				LOGGER.debug(
						"doc before deleting content file for variant doc" + secContentLocationFile);
				logWriter.info(
						"doc before deleting content file for variant doc" + secContentLocationFile);
				 // donot delete physical files from shared folder
				// WebServiceHelper.deleteDir(secContentLocationFile);
				LOGGER.debug("doc after deleting content file for variant doc");
				logWriter.info("doc after deleting content file for variant doc");
			}
		}
	}
	
	

	/**
	 * @param typeIdentifier 
	 * @param sourceDoc 
	 * @param tid 
	 * @param ibas
	 * @param targetState
	 * @param checkinComment
	 * @param additionalLanguages
	 * @param targetType
	 * @param variantDoc
	 * @param i
	 * @return
	 * @throws WTException
	 * @throws WorkInProgressException
	 * @throws NonLatestCheckoutException
	 * @throws WTPropertyVetoException
	 * @throws PersistenceException
	 * @throws VersionControlException
	 * @throws RemoteException
	 * @throws ParseException
	 * @throws LifeCycleException
	 * 
	 * update variant doc once processed under additionalLanguages
	 * 
	 */
	private WTDocument updateIBAandStateOnVariant(WTDocument sourceDoc, TypeIdentifier tid, TypeDefinitionReference tdr, HashMap<String, String> ibas, String targetState,
			String checkinComment, String[][] additionalLanguages, TypeIdentifier targetType,
			WTDocument variantDoc, int i)
			throws WTException, WorkInProgressException, NonLatestCheckoutException, WTPropertyVetoException,
			PersistenceException, VersionControlException, RemoteException, ParseException, LifeCycleException {
		WTHashSet exisitngVarLinkSet = (WTHashSet) ConfigurableLinkHelper.service
				.getConfigurableLinks(sourceDoc, variantDoc, tid);
		LOGGER.debug("exisitngVarLinkSet size :: "+exisitngVarLinkSet.size()+" :: Variant doc ::"+variantDoc+" :: Source doc ::"+sourceDoc );
	    LOGGER.debug("Source doc :: "+sourceDoc.getNumber() + " :: Variant doc :: "+variantDoc.getNumber() );
		/*if(exisitngVarLinkSet.isEmpty()){
			
			ConfigurableRevisionLink kbVariantLink = ConfigurableRevisionLink
					.newConfigurableRevisionLink(sourceDoc, variantDoc, tdr);
			PersistenceHelper.manager.save(kbVariantLink);
			return variantDoc;
			
		}else{*/
			WorkInProgressHelper.service.checkout(
					(WTDocument) VersionControlHelper.getLatestIteration(variantDoc),
					WorkInProgressHelper.service.getCheckoutFolder(),
					"Checked out to synchronize update from CADIM");
			WTDocument workingCopyVariantDoc = (WTDocument) WorkInProgressHelper.service
					.workingCopyOf((WTDocument) VersionControlHelper.getLatestIteration(variantDoc));
			PersistableAdapter workingVariantDocAdapter = new PersistableAdapter(
					(Persistable) workingCopyVariantDoc, ((WCTypeIdentifier) targetType).getLeafName(),
					null, null);
			PersistableAdapter sourceDocAdapter = new PersistableAdapter((Persistable) sourceDoc,
					((WCTypeIdentifier) targetType).getLeafName(), null, null);
			workingVariantDocAdapter.load(ibas.keySet());
			sourceDocAdapter.load(ibas.keySet());
	
			for (Entry<String, String> attEntry : ibas.entrySet()) {
				if (!attEntry.getKey().equalsIgnoreCase(KBConstants.KBLANGUAGE_IBA)) {
					
					setAttributesFromSource(workingVariantDocAdapter, attEntry, sourceDocAdapter);
					
				} else {
					String [] langStr = additionalLanguages[i][0].toString().split("/");
					LOGGER.debug("additionalLanguages[i][0]- "+additionalLanguages[i][0]);
					LOGGER.debug("langStr "+langStr);
					workingVariantDocAdapter.set(attEntry.getKey(), langStr);
					logWriter.info("After setting Language" + langStr);
					LOGGER.debug("After setting Language " + langStr);
				}
			}
			workingVariantDocAdapter.apply();
			PersistenceHelper.manager.save(workingCopyVariantDoc);
			workingCopyVariantDoc = (WTDocument) WorkInProgressHelper.service.checkin(workingCopyVariantDoc,
					checkinComment);
			LOGGER.debug("After check in ");
			
			if(exisitngVarLinkSet.isEmpty()){
				ConfigurableRevisionLink kbVariantLink = ConfigurableRevisionLink
						.newConfigurableRevisionLink(sourceDoc, workingCopyVariantDoc, tdr);
				PersistenceHelper.manager.save(kbVariantLink);
			}
			// check added to update state only in case of state change
			if(!targetState.equalsIgnoreCase(workingCopyVariantDoc.getLifeCycleState().toString()))
			  LifeCycleHelper.service.setLifeCycleState(workingCopyVariantDoc, State.toState(targetState));
		
			return workingCopyVariantDoc;
		
	}

	
	/**
	 * @param workingVariantDocAdapter
	 * @param attEntry
	 * Sets attribute values of variants from source if empty attribute values are received
	 * @param sourceDocAdapter 
	 */
	private void setAttributesFromSource( PersistableAdapter workingVariantDocAdapter,
			Entry<String, String> attEntry, PersistableAdapter sourceDocAdapter) throws ParseException, RemoteException, WTException, WTPropertyVetoException {
		String attValue = attEntry.getValue();
		String attKey = attEntry.getKey();
		if (attValue != null && !attValue.isEmpty()) {
			AttributeDefDefaultView attributeDefinition = IBAHelper.getAttributeDefDefaultView(attKey);
			LOGGER.debug("Attribute Definition ==" + attributeDefinition);
			AttributeDefDefaultView attributeDefDefaultView = IBAHelper.getAttributeDefDefaultView(attKey);
			Object attrValue = WebServiceHelper.parseAttributeValue(attributeDefDefaultView, attValue);
			LOGGER.debug("Attribute name is" + attKey + " Attribute Value is " + attrValue);
			logWriter.info("Attribute name is" + attKey + " Attribute Value is " + attrValue);
			workingVariantDocAdapter.set(attKey, attrValue);
		} else {
			
			try {
				if (LOGGER.isDebugEnabled()) {
					LOGGER.debug("Received empty or null attribute value for " + attKey
							+ " hence setting from source doc\nAttribute name is" + attKey + " Attribute Value is "
							+ sourceDocAdapter.get(attKey));
				}
				logWriter.info("Received empty or null attribute value for " + attKey
						+ " hence setting from source doc\nAttribute name is" + attKey + " Attribute Value is "
						+ sourceDocAdapter.get(attKey));
				workingVariantDocAdapter.set(attKey, sourceDocAdapter.get(attKey));
			}catch (Exception ex) {
				LOGGER.error("Error occured while updating the empty attributes from source to variant: ", ex);
			}

		}
	}
	
	
	private WTDocument getSourceDocIndexZero(WTDocument sourceDoc) throws WTException {
		String number = (sourceDoc.getNumber().substring(0, sourceDoc.getNumber().length() - 3) + "000");
		WTDocument returnDoc = KBUtils.findDocumentByNumber(number);
		WTDocument latestDocRevision = (WTDocument) ObjectRevisionHelper.getLatestVersionByPersistable(returnDoc);
		WTDocument latestDocIteration = (WTDocument) VersionControlHelper.getLatestIteration(latestDocRevision);
		return returnDoc;
	}
	
	
	private static WTContainer getContainerProduct(String container) {

		WTContainer cont = null;

		try {

			int[] fromIndicies = { 0, -1 };

			QuerySpec querySpec = new QuerySpec(PDMLinkProduct.class);
			querySpec.appendWhere(
					new SearchCondition(PDMLinkProduct.class, PDMLinkProduct.NAME, SearchCondition.EQUAL, container),
					fromIndicies);
			Enumeration contEnum = PersistenceHelper.manager.find((StatementSpec) querySpec);
			if (contEnum.hasMoreElements()) {
				cont = (WTContainer) contEnum.nextElement();
				System.out.println("container ===" + cont);

			}

		} catch (WTException e) {
			e.printStackTrace();
		}
		return cont;
	}
	
	private static WTLibrary getLibraryContainer(String sContainer) throws WTException {
		
		WTLibrary library = null;

		try {
			QuerySpec qs = new QuerySpec(WTLibrary.class);
			SearchCondition sc = new SearchCondition(WTLibrary.class, WTLibrary.NAME, "=", sContainer);
			qs.appendWhere(sc, new int[0]);
			QueryResult qr = PersistenceHelper.manager.find((StatementSpec) qs);
			if (qr.hasMoreElements()){
				library = (WTLibrary) qr.nextElement();
			}
		} catch (WTException e) {
			LOGGER.error(e);
		}

		return library;
	}
	
}