package ext.kb.ws;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import ext.kb.service.BOMClearanceStatusHelper;
import java.io.IOException;
import java.util.List;

import com.ptc.jws.servlet.JaxWsWebService;

@WebService()
public class KBBomClearanceStatusWebService extends JaxWsWebService {
		
	/**
	 * @param partID
	 * @return result string array depending on, if the BOM, for the part with
	 *         partID, was removed or not.
	 * @throws IOException
	 */
	@WebMethod(operationName = "isBomCleared")
	public List<String> getBomStatus(@WebParam(name = "partID") String partID) throws IOException{
		
		return BOMClearanceStatusHelper.getBomStatus(partID);
	}

}