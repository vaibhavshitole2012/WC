package ext.kb.ws;

import java.io.IOException;
import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.xml.bind.JAXBException;

import org.apache.log4j.Logger;

import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.collections.WTCollection;
import wt.fc.collections.WTHashSet;
import wt.iba.definition.StringDefinition;
import wt.iba.value.AttributeContainer;
import wt.iba.value.DefaultAttributeContainer;
import wt.iba.value.StringValue;
import wt.iba.value.service.IBAValueDBService;
import wt.inf.container.WTContainerHelper;
import wt.log4j.LogR;
import wt.org.OrganizationServicesHelper;
import wt.org.WTOrganization;
import wt.org.WTOrganizationIdentifier;
import wt.org.WTPrincipal;
import wt.ownership.Ownership;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.part._WTPart;
import wt.pds.StatementSpec;
import wt.pom.Transaction;
import wt.pom.UniquenessException;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.session.SessionHelper;
import wt.units.FloatingPointWithUnits;
import wt.units.Unit;
import wt.util.WTException;
import wt.util.WTProperties;
import wt.util.WTPropertyVetoException;
import wt.vc.Mastered;
import wt.vc.VersionControlException;
import wt.vc.VersionControlHelper;

import com.ptc.core.lwc.server.PersistableAdapter;
import com.ptc.core.meta.server.TypeIdentifierUtility;
import com.ptc.jws.servlet.JaxWsWebService;
import com.ptc.windchill.suma.axl.AXLContext;
import com.ptc.windchill.suma.axl.AXLEntry;
import com.ptc.windchill.suma.axl.AXLHelper;
import com.ptc.windchill.suma.axl.AXLPreference;
import com.ptc.windchill.suma.jca.util.SumaJcaHelper;
import com.ptc.windchill.suma.part.VendorPart;
import com.ptc.windchill.suma.part.VendorPartMaster;
import com.ptc.windchill.suma.supplier.Vendor;

import ext.kb.cost.tool.MaterialCostUpdateTool;
import ext.kb.service.WebServiceHelper;
import ext.kb.util.DBUtils;
import ext.kb.util.KBConstants;
import ext.kb.util.ObjectRevisionHelper;

@WebService()
public class KBProcurementPartService extends JaxWsWebService {
	private static final Logger LOGGER = LogR
			.getLogger(KBProcurementPartService.class.getName());
	private static final Logger logWriter = LogR.getLogger("ext.kb.ws.KBProcurementPartService_Log");

	@WebMethod(operationName = "procurementPart")
	public List<String> procurementPart(@WebParam(name = "partID") String partID,
			@WebParam(name = "part_CID") String part_CID,
			@WebParam(name = "procPartIDs") String procPartIDs[][]) throws WTException,
			WTPropertyVetoException, JAXBException, IOException

	{
		Transaction trx = null;
		List<String> result = new ArrayList<String>();
		WTPrincipal admin = null;
		WTProperties properties = WTProperties.getServerProperties();
		String defaultDomain = properties.getProperty("KBDefaultExternalDomain","CADIM DOMAIN");
		try {

			trx = new Transaction();
			trx.start();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
            Date date = new Date();
            String formatedDate = sdf.format(date);
            logWriter.info("Processing ProcurementPart request on "+formatedDate+" for part where partID is "+partID+" and cid is "+part_CID);
			QuerySpec resQS = WebServiceHelper.findPartByNumberAndCadim(partID, part_CID);
			QueryResult resQR = PersistenceHelper.manager
					.find((StatementSpec) resQS);
			System.out.println("resQR: " + resQR);
			LOGGER.debug("resQR.size()" + resQR.size());
			int size = resQR.size();
			if (size > 0) {

				Persistable resObj[] = (Persistable[]) resQR.nextElement();
				LOGGER.debug("resObj[0] " + resObj[0]);

				WTPart resPart = (WTPart) resObj[0];
				WTPart latestPartRevision = (WTPart)ObjectRevisionHelper.getLatestVersionByPersistable(resPart);
				WTPart latestPartIteration = (WTPart) VersionControlHelper
						.getLatestIteration(latestPartRevision);
				LOGGER.debug("procPartIDs.length: " + procPartIDs.length);
				logWriter.info("procPartIDs.length: " + procPartIDs.length);
				LOGGER.debug("Going to delete related procurement parts");
				deleteProcurementParts(latestPartIteration);
				LOGGER.debug("After deleting related procurement parts");
				logWriter.info("After deleting related procurement parts");
				for (int i = 0; i < procPartIDs.length; i++) {
					LOGGER.debug("Inside for procPartIDs.length =="+procPartIDs.length);
					logWriter.info("Inside for procPartIDs.length =="+procPartIDs.length);
					WTOrganizationIdentifier orgId = new WTOrganizationIdentifier();
					LOGGER.debug("orgId =="+orgId);
					logWriter.info("orgId =="+orgId);
					orgId.setUniqueIdentifier(procPartIDs[i][0]);
					logWriter.info("Vendor Org id is "+procPartIDs[i][0]);
					LOGGER.debug("After setting unique identifier");
					logWriter.info("After setting unique identifier");
					orgId.setCodingSystem("0001");
					LOGGER.debug("After setting coding System");
					logWriter.info("After setting coding System");
					WTOrganization vendOrg = OrganizationServicesHelper
							.getOrganizationByOrgId(orgId);
					LOGGER.debug("Vendor Org is "+vendOrg);
					logWriter.info("Vendor Org is "+vendOrg);
					if (vendOrg == null) {
						throw new WTException(
								"Vendor Organization with id "
										+ procPartIDs[i][0]
										+ " does not exists");
					} else {
						VendorPart procPart = MaterialCostUpdateTool
								.createVendorPart(latestPartIteration,
										vendOrg);
						LOGGER.debug("procPart is "+procPart);
						logWriter.info("procPart is "+procPart);
						
						Vendor vend = MaterialCostUpdateTool
								.getVendor(procPart);
						LOGGER.debug("vendor is "+vend);
						logWriter.info("vendor is "+vend);
						if (vend != null) {

							try {
								procPart.setOrganization(vend
										.getOrganization());
								procPart.setContainerReference(latestPartIteration
										.getContainerReference());
								LOGGER.debug("After setting org and container ref");
								logWriter.info("After setting org and container ref");
							} catch (WTPropertyVetoException e) {
								throw new RuntimeException(
										"Failed to set organization of new procurement part",
										e);
							}
							try {
								admin = SessionHelper.manager
										.setPrincipal(SessionHelper.manager
												.getAdministrator()
												.getName());
								LOGGER.debug("latestPartIteration.getNumber()" +latestPartIteration.getNumber());
								logWriter.info("latestPartIteration.getNumber()" +latestPartIteration.getNumber());
								LOGGER.debug("vend.getName()" +vend.getName());
								logWriter.info("vend.getName()" +vend.getName());
								List<VendorPart> parts = DBUtils
										.getObjectsByNameNumber(
												VendorPart.class, vend
														.getName(),
												latestPartIteration
														.getNumber());
								LOGGER.debug("parts.size" +parts.size());
								logWriter.info("parts.size" +parts.size());
								for (VendorPart vp : parts) {
									LOGGER.debug("vend.getOrganization() "+vend.getOrganization());
									logWriter.info("vp.getOrganization() "+vp.getOrganization());
									LOGGER.debug("latestPartIteration.getContainerReference() "+latestPartIteration.getContainerReference());
									LOGGER.debug("vp.getContainerReference() "+vp.getContainerReference());
									LOGGER.debug("VersionControlHelper.isLatestIteration(vp) "+VersionControlHelper.isLatestIteration(vp));
									logWriter.info("latestPartIteration.getContainerReference() "+latestPartIteration.getContainerReference());
									logWriter.info("vp.getContainerReference() "+vp.getContainerReference());
									logWriter.info("VersionControlHelper.isLatestIteration(vp) "+VersionControlHelper.isLatestIteration(vp));
									LOGGER.debug("Version is "+vp.getVersionInfo().getIdentifier().getValue()+" and iteration "+ vp.getIterationInfo().getIdentifier().getValue());
									logWriter.info("Version is "+vp.getVersionInfo().getIdentifier().getValue()+" and iteration "+ vp.getIterationInfo().getIdentifier().getValue());
									if (vend.getOrganization().equals(
											vp.getOrganization())
											&& latestPartIteration
													.getContainerReference()
													.equals(vp
															.getContainerReference())
											&& VersionControlHelper
													.isLatestIteration(vp)) {
										procPart = vp;
										LOGGER.debug("Version is "+vp.getVersionInfo().getIdentifier().getValue()+" and iteration "+ vp.getIterationInfo().getIdentifier().getValue());
										logWriter.info("Version is "+vp.getVersionInfo().getIdentifier().getValue()+" and iteration "+ vp.getIterationInfo().getIdentifier().getValue());
										break;
									}
								}
								boolean isPersisted = procPart
										.getPersistInfo().isPersisted();
								LOGGER.debug("The vendor part isPersisted==="
										+ isPersisted);
								logWriter.info("The vendor part isPersisted==="
										+ isPersisted);
								if (!isPersisted)// lookup wasn't
													// successful, storing
													// new item
								{
									LOGGER.debug("Persisting the vendor part");
									logWriter.info("Persisting the vendor part");
									PersistenceHelper.manager
											.store(procPart);
									LOGGER.debug("After Persisting the vendor part");
									logWriter.info("After Persisting the vendor part");
								}

							} catch (WTException e) {
								if (e instanceof UniquenessException
										|| e instanceof VersionControlException) {
									throw new WTException(
											e.getMessage()
													+ " \nPlease select a different vendor, this one already has the current part.");
								} else {
									throw e;
								}
							}

							if (procPartIDs[i][1].equalsIgnoreCase("PREFERRED")) {
								logWriter.info("Prcourement part is preferred Procurement Part");
								AXLContext cont = AXLHelper.service
										.getDefaultContext(vend
												.getContainerReference());
								AXLPreference pref = AXLPreference.PREFERRED;
								AXLHelper.service.addAVL(cont,
										latestPartIteration, null,
										procPart, pref);
								PersistableAdapter sourceLWC = new PersistableAdapter(
										procPart, TypeIdentifierUtility
												.getTypeIdentifier(procPart)
												.toExternalForm(), Locale.US, null);
								sourceLWC.load(KBConstants.EST_GGK_IBA,
										KBConstants.EST_GGK_UPD_DATE_IBA);
								LOGGER.debug("value of EST GGK : "
										+ FloatingPointWithUnits
												.valueOf((procPartIDs[i][2])
														.replace(",", ".")
														+ " EUR"));
								logWriter.info("value of EST GGK : "
										+ FloatingPointWithUnits
										.valueOf((procPartIDs[i][2])
												.replace(",", ".")
												+ " EUR"));

								double cost = Double.valueOf(procPartIDs[i][2].replace(",","."));
								logWriter.info("value of cost : "+ cost);
								String currency = procPartIDs[i][3];
								logWriter.info("value of currency : "+ currency);
								if (currency.lastIndexOf("_") > -1) {
									currency = currency.substring(currency.lastIndexOf("_") + 1);
								}
								LOGGER.debug("currency : " + currency);
								if (currency.equals("USD")) {
									Unit unit = new Unit(cost, "USS");
									LOGGER.debug("inside currency is USD unit : " + unit);
									FloatingPointWithUnits calculatedFloatingPoint = new FloatingPointWithUnits(unit);
									logWriter.info("value of calculatedFloatingPoint : "+ calculatedFloatingPoint);
									sourceLWC.set(KBConstants.EST_GGK_IBA,calculatedFloatingPoint);
									
								} 
								else if (currency.equals("EUR")) {
									Unit unit = new Unit(cost, "USD");
									LOGGER.debug("Inside Currency is not USD unit : " + unit);
									logWriter.info("Inside Currency is not USD unit : " + unit);
									FloatingPointWithUnits calculatedMAPFloatingPoint = new FloatingPointWithUnits(
											unit);
									LOGGER.debug("calculatedFloatingPoint : "
											+ calculatedMAPFloatingPoint);
									logWriter.info("value of calculatedFloatingPoint : "+ calculatedMAPFloatingPoint);
									sourceLWC.set(KBConstants.EST_GGK_IBA,calculatedMAPFloatingPoint);										
								}
								else {
									Unit unit = new Unit(cost, currency);
									LOGGER.debug("inside currency is not USD unit : " + unit);
									FloatingPointWithUnits calculatedFloatingPoint = new FloatingPointWithUnits(
											unit);
									LOGGER.debug("calculatedFloatingPoint : "
											+ calculatedFloatingPoint);
									logWriter.info("value of calculatedFloatingPoint : "+ calculatedFloatingPoint);
									sourceLWC.set(KBConstants.EST_GGK_IBA,calculatedFloatingPoint);										
								}
								
								LOGGER.debug("Before setting GGK Update date "+ convertDate(procPartIDs[i][4]));
								logWriter.info("Before setting GGK Update date "+ convertDate(procPartIDs[i][4]));
								sourceLWC.set(
										KBConstants.EST_GGK_UPD_DATE_IBA,
										convertDate(procPartIDs[i][4]));
								procPart = (VendorPart) sourceLWC.apply();
								IBAValueDBService ibavaluedbservice = new IBAValueDBService();
								wt.fc.PersistenceServerHelper.manager
										.update((Persistable) procPart);
								AttributeContainer attributecontainer = procPart
										.getAttributeContainer();
								Object obj = ((DefaultAttributeContainer) attributecontainer)
										.getConstraintParameter();
								AttributeContainer attributecontainer1 = ibavaluedbservice
										.updateAttributeContainer(procPart,
												obj, null, null);
								procPart.setAttributeContainer(attributecontainer1);
								
								VendorPartMaster master = (VendorPartMaster) procPart.getMaster();
								PersistableAdapter  lwcObj = new PersistableAdapter(procPart.getMaster(), TypeIdentifierUtility.getTypeIdentifier(procPart.getMaster()).toExternalForm(), Locale.US, null);
								lwcObj.load("KB_MAP_CATEGORY","KB_MAP_UPD_DATE","KB_MAP_COMMENT","KB_MAP");
								LOGGER.debug("Before setting KB_MAP_CATEGORY "+ procPartIDs[i][5]);
								logWriter.info("Before setting KB_MAP_CATEGORY "+ procPartIDs[i][5]);
								lwcObj.set("KB_MAP_CATEGORY",procPartIDs[i][5]);
								LOGGER.debug("Before setting KB_MAP_COMMENT "+ procPartIDs[i][6]);
								logWriter.info("Before setting KB_MAP_COMMENT "+ procPartIDs[i][6]);
								lwcObj.set("KB_MAP_COMMENT",procPartIDs[i][6]);
								
								if(!procPartIDs[i][7].equals(" "))
								{
								LOGGER.debug("Before setting KB_MAP_UPD_DATE "+ convertDate(procPartIDs[i][7]));
								logWriter.info("Before setting KB_MAP_UPD_DATE "+ convertDate(procPartIDs[i][7]));
								lwcObj.set("KB_MAP_UPD_DATE",convertDate(procPartIDs[i][7]));
								}
								
								if(!procPartIDs[i][8].equals(" "))
								{
								
								logWriter.info("value of MAPCost is not null");
								LOGGER.debug("value of MAPCost is not null");
								double MAPCost = Double.valueOf(procPartIDs[i][8].replace(",","."));
								logWriter.info("value of MAPCost : "+ MAPCost);
								LOGGER.debug("value of MAPCost : "+ MAPCost);
								String MAPCurrency = procPartIDs[i][9];
								logWriter.info("value of MAP currency : "+ MAPCurrency);
								LOGGER.debug("value of MAP currency : "+ MAPCurrency);
								if (MAPCurrency.lastIndexOf("_") > -1) {
									MAPCurrency = MAPCurrency.substring(MAPCurrency.lastIndexOf("_") + 1);
								}
								logWriter.info("value of currency : "+ MAPCurrency);
								LOGGER.debug("value of currency : "+ MAPCurrency);
								if (MAPCurrency.equals("USD")) {
									Unit unit = new Unit(MAPCost, "USS");
									LOGGER.debug("Inside Currency is USD unit : " + unit);
									logWriter.info("Inside Currency is USD unit : " + unit);
									FloatingPointWithUnits calculatedMAPFloatingPoint = new FloatingPointWithUnits(unit);
									logWriter.info("value of calculatedFloatingPoint : "+ calculatedMAPFloatingPoint);
									lwcObj.set("KB_MAP",calculatedMAPFloatingPoint);
									
								} 
								else if (MAPCurrency.equals("EUR")) {
									Unit unit = new Unit(MAPCost, "USD");
									LOGGER.debug("Inside Currency is not USD unit : " + unit);
									logWriter.info("Inside Currency is not USD unit : " + unit);
									FloatingPointWithUnits calculatedMAPFloatingPoint = new FloatingPointWithUnits(
											unit);
									LOGGER.debug("calculatedFloatingPoint : "
											+ calculatedMAPFloatingPoint);
									logWriter.info("value of calculatedFloatingPoint : "+ calculatedMAPFloatingPoint);
									lwcObj.set("KB_MAP",
											calculatedMAPFloatingPoint);										
								}
								else {
									Unit unit = new Unit(MAPCost, MAPCurrency);
									LOGGER.debug("Inside Currency is not USD unit : " + unit);
									logWriter.info("Inside Currency is not USD unit : " + unit);
									FloatingPointWithUnits calculatedMAPFloatingPoint = new FloatingPointWithUnits(
											unit);
									LOGGER.debug("calculatedFloatingPoint : "
											+ calculatedMAPFloatingPoint);
									logWriter.info("value of calculatedFloatingPoint : "+ calculatedMAPFloatingPoint);
									lwcObj.set("KB_MAP",
											calculatedMAPFloatingPoint);										
								}
								}
								master = (VendorPartMaster) lwcObj.apply();
								IBAValueDBService ibaValuedbServiceMaster = new IBAValueDBService();
								wt.fc.PersistenceServerHelper.manager
										.update((Persistable) master);
								AttributeContainer attributeContainerMaster = master.getAttributeContainer();
								Object masterObj = ((DefaultAttributeContainer) attributeContainerMaster)
										.getConstraintParameter();
								AttributeContainer attributeContainerMaster1 = ibaValuedbServiceMaster.updateAttributeContainer(master,masterObj, null, null);
								master.setAttributeContainer(attributeContainerMaster1);
							} 
							else if (procPartIDs[i][1].equalsIgnoreCase("DO_NOT_USE")) {
								LOGGER.debug("Setting the state to DO_NOT_USE");
								logWriter.info("Setting the state to DO_NOT_USE");
								AXLContext cont = AXLHelper.service
										.getDefaultContext(vend
												.getContainerReference());
								AXLPreference pref = AXLPreference.DO_NOT_USE;
								AXLHelper.service.addAVL(cont,
										latestPartIteration, null,
										procPart, pref);
								PersistableAdapter sourceLWC = new PersistableAdapter(
										procPart, TypeIdentifierUtility
												.getTypeIdentifier(procPart)
												.toExternalForm(), Locale.US, null);
								sourceLWC.load(KBConstants.EST_GGK_IBA,
										KBConstants.EST_GGK_UPD_DATE_IBA);
								LOGGER.debug("value of EST GGK : "
										+ FloatingPointWithUnits
												.valueOf((procPartIDs[i][2])
														.replace(",", ".")
														+ " EUR"));
								logWriter.info("value of EST GGK : "
										+ FloatingPointWithUnits
										.valueOf((procPartIDs[i][2])
												.replace(",", ".")
												+ " EUR"));

								double cost = Double.valueOf(procPartIDs[i][2].replace(",","."));
								logWriter.info("value of cost : "+ cost);
								String currency = procPartIDs[i][3];
								logWriter.info("value of currency : "+ currency);
								if (currency.lastIndexOf("_") > -1) {
									currency = currency.substring(currency.lastIndexOf("_") + 1);
								}
								LOGGER.debug("currency : " + currency);
								if (currency.equals("USD")) {
									Unit unit = new Unit(cost, "USS");
									LOGGER.debug("inside currency is USD unit : " + unit);
									FloatingPointWithUnits calculatedFloatingPoint = new FloatingPointWithUnits(unit);
									logWriter.info("value of calculatedFloatingPoint : "+ calculatedFloatingPoint);
									sourceLWC.set(KBConstants.EST_GGK_IBA,calculatedFloatingPoint);
									
								} 
								else if (currency.equals("EUR")) {
									Unit unit = new Unit(cost, "USD");
									LOGGER.debug("Inside Currency is not USD unit : " + unit);
									logWriter.info("Inside Currency is not USD unit : " + unit);
									FloatingPointWithUnits calculatedMAPFloatingPoint = new FloatingPointWithUnits(
											unit);
									LOGGER.debug("calculatedFloatingPoint : "
											+ calculatedMAPFloatingPoint);
									logWriter.info("value of calculatedFloatingPoint : "+ calculatedMAPFloatingPoint);
									sourceLWC.set(KBConstants.EST_GGK_IBA,calculatedMAPFloatingPoint);										
								}
								else {
									Unit unit = new Unit(cost, currency);
									LOGGER.debug("inside currency is not USD unit : " + unit);
									FloatingPointWithUnits calculatedFloatingPoint = new FloatingPointWithUnits(
											unit);
									LOGGER.debug("calculatedFloatingPoint : "
											+ calculatedFloatingPoint);
									logWriter.info("value of calculatedFloatingPoint : "+ calculatedFloatingPoint);
									sourceLWC.set(KBConstants.EST_GGK_IBA,calculatedFloatingPoint);										
								}
								
								LOGGER.debug("Before setting GGK Update date "+ convertDate(procPartIDs[i][4]));
								logWriter.info("Before setting GGK Update date "+ convertDate(procPartIDs[i][4]));
								sourceLWC.set(
										KBConstants.EST_GGK_UPD_DATE_IBA,
										convertDate(procPartIDs[i][4]));
								procPart = (VendorPart) sourceLWC.apply();
								IBAValueDBService ibavaluedbservice = new IBAValueDBService();
								wt.fc.PersistenceServerHelper.manager
										.update((Persistable) procPart);
								AttributeContainer attributecontainer = procPart
										.getAttributeContainer();
								Object obj = ((DefaultAttributeContainer) attributecontainer)
										.getConstraintParameter();
								AttributeContainer attributecontainer1 = ibavaluedbservice
										.updateAttributeContainer(procPart,
												obj, null, null);
								procPart.setAttributeContainer(attributecontainer1);
								
								VendorPartMaster master = (VendorPartMaster) procPart.getMaster();
								PersistableAdapter  lwcObj = new PersistableAdapter(procPart.getMaster(), TypeIdentifierUtility.getTypeIdentifier(procPart.getMaster()).toExternalForm(), Locale.US, null);
								lwcObj.load("KB_MAP_CATEGORY","KB_MAP_UPD_DATE","KB_MAP_COMMENT","KB_MAP");
								LOGGER.debug("Before setting KB_MAP_CATEGORY "+ procPartIDs[i][5]);
								logWriter.info("Before setting KB_MAP_CATEGORY "+ procPartIDs[i][5]);
								lwcObj.set("KB_MAP_CATEGORY",procPartIDs[i][5]);
								LOGGER.debug("Before setting KB_MAP_COMMENT "+ procPartIDs[i][6]);
								logWriter.info("Before setting KB_MAP_COMMENT "+ procPartIDs[i][6]);
								lwcObj.set("KB_MAP_COMMENT",procPartIDs[i][6]);
								
								if(!procPartIDs[i][7].equals(" "))
								{
								LOGGER.debug("Before setting KB_MAP_UPD_DATE "+ convertDate(procPartIDs[i][7]));
								logWriter.info("Before setting KB_MAP_UPD_DATE "+ convertDate(procPartIDs[i][7]));
								lwcObj.set("KB_MAP_UPD_DATE",convertDate(procPartIDs[i][7]));
								}
								
								if(!procPartIDs[i][8].equals(" "))
								{
								
								logWriter.info("value of MAPCost is not null");
								LOGGER.debug("value of MAPCost is not null");
								double MAPCost = Double.valueOf(procPartIDs[i][8].replace(",","."));
								logWriter.info("value of MAPCost : "+ MAPCost);
								LOGGER.debug("value of MAPCost : "+ MAPCost);
								String MAPCurrency = procPartIDs[i][9];
								logWriter.info("value of MAP currency : "+ MAPCurrency);
								LOGGER.debug("value of MAP currency : "+ MAPCurrency);
								if (MAPCurrency.lastIndexOf("_") > -1) {
									MAPCurrency = MAPCurrency.substring(MAPCurrency.lastIndexOf("_") + 1);
								}
								logWriter.info("value of currency : "+ MAPCurrency);
								LOGGER.debug("value of currency : "+ MAPCurrency);
								if (MAPCurrency.equals("USD")) {
									Unit unit = new Unit(MAPCost, "USS");
									LOGGER.debug("Inside Currency is USD unit : " + unit);
									logWriter.info("Inside Currency is USD unit : " + unit);
									FloatingPointWithUnits calculatedMAPFloatingPoint = new FloatingPointWithUnits(unit);
									logWriter.info("value of calculatedFloatingPoint : "+ calculatedMAPFloatingPoint);
									lwcObj.set("KB_MAP",calculatedMAPFloatingPoint);
									
								} 
								else if (MAPCurrency.equals("EUR")) {
									Unit unit = new Unit(MAPCost, "USD");
									LOGGER.debug("Inside Currency is not USD unit : " + unit);
									logWriter.info("Inside Currency is not USD unit : " + unit);
									FloatingPointWithUnits calculatedMAPFloatingPoint = new FloatingPointWithUnits(
											unit);
									LOGGER.debug("calculatedFloatingPoint : "
											+ calculatedMAPFloatingPoint);
									logWriter.info("value of calculatedFloatingPoint : "+ calculatedMAPFloatingPoint);
									lwcObj.set("KB_MAP",
											calculatedMAPFloatingPoint);										
								}
								else {
									Unit unit = new Unit(MAPCost, MAPCurrency);
									LOGGER.debug("Inside Currency is not USD unit : " + unit);
									logWriter.info("Inside Currency is not USD unit : " + unit);
									FloatingPointWithUnits calculatedMAPFloatingPoint = new FloatingPointWithUnits(
											unit);
									LOGGER.debug("calculatedFloatingPoint : "
											+ calculatedMAPFloatingPoint);
									logWriter.info("value of calculatedFloatingPoint : "+ calculatedMAPFloatingPoint);
									lwcObj.set("KB_MAP",
											calculatedMAPFloatingPoint);										
								}
								}
								master = (VendorPartMaster) lwcObj.apply();
								IBAValueDBService ibaValuedbServiceMaster = new IBAValueDBService();
								wt.fc.PersistenceServerHelper.manager
										.update((Persistable) master);
								AttributeContainer attributeContainerMaster = master.getAttributeContainer();
								Object masterObj = ((DefaultAttributeContainer) attributeContainerMaster)
										.getConstraintParameter();
								AttributeContainer attributeContainerMaster1 = ibaValuedbServiceMaster.updateAttributeContainer(master,masterObj, null, null);
								master.setAttributeContainer(attributeContainerMaster1);
							}else {
								AXLContext cont = AXLHelper.service
										.getDefaultContext(vend
												.getContainerReference());
								AXLPreference pref = AXLPreference.APPROVED;
								AXLHelper.service.addAVL(cont,
										latestPartIteration, null,
										procPart, pref);
							}
						}
						 LOGGER.debug("containerName name ==="+ procPart.getContainerName());
						 logWriter.info("containerName name ==="+ procPart.getContainerName());
						 LOGGER.debug( " part domain before \"" + procPart.getDomainRef().getName() + "\" domain");
				         logWriter.info( " part domain before \"" + procPart.getDomainRef().getName() + "\" domain");
				         //WebServiceHelper.setCadimDomain(procPart, defaultDomain, procPart.getContainerName());
				         LOGGER.debug( " part domain After \"" + procPart.getDomainRef().getName() + "\" domain");
				         logWriter.info( " part domain After \"" + procPart.getDomainRef().getName() + "\" domain");
					}
				}
				
				LOGGER.debug("trx===" + trx);
				trx.commit();
				trx = null;
				result.add("ReturnCode: 0");
	            result.add("Text: Success");
	            logWriter.info("result from the service is "+result);
				return result;
			} else {
				throw new WTException("Part Not found");
			}
		} catch (WTException e) {
			String message = "WTException during update IBA's exception is "
					+ e;
			result.add("ReturnCode: 1");
            result.add("Text: "+message);
            logWriter.info("result from the service is "+result);
			return result;

		} catch (WTPropertyVetoException e) {
			String message = "WTPropertyVetoException during update IBA's exception is "
					+ e;
			result.add("ReturnCode: 1");
            result.add("Text: "+message);
            logWriter.info("result from the service is "+result);
			return result;
		} finally {
			System.out.println("trx in finally===" + trx);
			if (trx != null) {
				trx.rollback();
			}
		}

	}

	
	/**
	 * deleteProcurementParts.
	 *
	 * @param WTPart
	 * @throws WTException 
	 */
	private static void deleteProcurementParts(WTPart latestPartIteration) throws WTException {
		LOGGER.debug("Inside  deleteProcurementParts " );
		WTHashSet localWTHashSet = new WTHashSet();
		AXLContext context = SumaJcaHelper
				.getDefaultSourcingContext(WTContainerHelper.service
						.getOrgContainer(latestPartIteration));
		WTCollection collection = AXLHelper.service.getAVL(
				latestPartIteration, context, null);
		
		LOGGER.debug("Number of AVLs " + collection.size());
		
		VendorPart vendorPart = null;

		for (Iterator vi = collection.iterator(); vi.hasNext();) {
			AXLEntry entry = (AXLEntry) ((ObjectReference) vi
					.next()).getObject();

			vendorPart = entry.getLatestVendorPart();
			String organizationUniqueIdentifier = vendorPart
					.getOrganizationUniqueIdentifier();
			LOGGER.debug("Deleting AVL for vendor id "
						+ organizationUniqueIdentifier);
				localWTHashSet.add(entry);
			}
		AXLHelper.service.removeAXL(localWTHashSet);
		LOGGER.debug("After Deleting AVL ");
		
	}

	
	/**
	 * Convert date.
	 *
	 * @param dateInFileBeforeConversion
	 *            the date in file before conversion
	 * @return the timestamp
	 */
	private static Timestamp convertDate(String dateInFileBeforeConversion) {
		if (dateInFileBeforeConversion == null)
			return null;

		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		try {
			Date dateInFile = (Date) dateFormat
					.parse(dateInFileBeforeConversion);
			Timestamp stamp = new Timestamp(dateInFile.getTime());
			return stamp;
		} catch (Exception exception) {
			LOGGER.trace("Error while processing " + dateInFileBeforeConversion);
		}

		return null;
	}

	}