package ext.kb.ws;

import java.lang.invoke.MethodHandles;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ptc.core.components.util.OidHelper;
import wt.org.WTPrincipal;
import wt.part.WTPart;
import wt.queue.ProcessingQueue;
import wt.queue.QueueHelper;
import wt.session.SessionContext;
import wt.session.SessionHelper;
import wt.session.SessionServerHelper;
import wt.util.WTException;

public class ShareToProjectQueueHelper {

	private static final Logger log = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());

	@SuppressWarnings("rawtypes")
	public static void addQueueEntry(ProcessingQueue queue, WTPart part) throws WTException {
		log.debug("--> addQueueEntry(queue = [{}], part = [{}])", queue, part);
		String oid = OidHelper.getNmOid(part).getHTMLId();
		Class[] argTypes = { String.class };
		Object[] args = { oid };

		WTPrincipal administrator = SessionHelper.manager.getAdministrator();
		WTPrincipal previous = SessionContext.setEffectivePrincipal(administrator);

		try {
			queue.addEntry(administrator, "execute", ShareToProjectTask.class.getName(), argTypes, args);
			log.debug("New queue entry was added to [{}]", queue.getName());
		} finally {
			SessionContext.setEffectivePrincipal(previous);
		}
		log.debug("<-- addQueueEntry()");
	}

	public static ProcessingQueue getQueue(String queueName) {
		log.debug("--> getQueue(queueName = [{}])", queueName);

		ProcessingQueue processingQueue = null;
		boolean previousAccessEnforced = SessionServerHelper.manager.setAccessEnforced(false);

		try {
			processingQueue = QueueHelper.manager.getQueue(queueName);
		} catch (WTException e) {
			log.error("Error getting queue with name [{}]", queueName, e);
		} finally {
			SessionServerHelper.manager.setAccessEnforced(previousAccessEnforced);
		}

		log.debug("<-- getProcessingQueue() = '{}'", processingQueue != null ? processingQueue.getName() : null);
		return processingQueue;
	}
}