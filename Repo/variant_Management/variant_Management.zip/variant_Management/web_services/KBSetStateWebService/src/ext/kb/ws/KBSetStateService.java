package ext.kb.ws;

import java.io.IOException;
import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.xml.bind.JAXBException;

import org.apache.log4j.Logger;

import wt.configurablelink.ConfigurableRevisionLink;
import wt.doc.WTDocument;
import wt.doc.WTDocumentMaster;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.iba.definition.StringDefinition;
import wt.iba.value.StringValue;
import wt.lifecycle.LifeCycleHelper;
import wt.lifecycle.State;
import wt.log4j.LogR;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.pds.StatementSpec;
import wt.pom.Transaction;
import wt.query.QuerySpec;
import wt.query.ClassAttribute;
import wt.query.OrderBy;
import wt.query.SearchCondition;
import wt.util.WTException;
import wt.util.WTInvalidParameterException;
import wt.util.WTPropertyVetoException;
import wt.vc.Mastered;
import wt.vc.VersionControlHelper;

import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.generic.vc.StandardVCService;
import com.ptc.jws.servlet.JaxWsWebService;

import ext.kb.project.ProjectHelper;
import ext.kb.service.WebServiceHelper;
import ext.kb.util.DBUtils;
import ext.kb.util.IBAHelper;
import ext.kb.util.KBTypeIdProvider;
import ext.kb.util.KBUtils;
import ext.kb.util.ObjectRevisionHelper;

@WebService()
public class KBSetStateService extends JaxWsWebService {
	private static final Logger LOGGER = LogR.getLogger(KBSetStateService.class.getName());
	private static final Logger logWriter = LogR.getLogger("ext.kb.ws.KBSetStateService_Log");
	@WebMethod(operationName = "setState")
	public List<String> setState(@WebParam(name = "objectType") String objectType,
			@WebParam(name = "targetState") String targetState,
			@WebParam(name = "objectID") String objectID,
			@WebParam(name = "cadimTransferDate") String cadimTransferDate,
			@WebParam(name = "C_ID") String C_ID) throws WTException,
			WTPropertyVetoException, JAXBException, IOException, ParseException

	{

		Transaction trx = null;
	    SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
		List<String> result = new ArrayList<String>();
		try {

			trx = new Transaction();
			trx.start();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
            Date date = new Date();
            Timestamp oldCadimTransferDate;
            String formatedDate = sdf.format(date);
            Timestamp transferDate = new Timestamp(dateFormat.parse(cadimTransferDate).getTime());
            logWriter.info("Processing Set State request for Object on "+formatedDate+" where objectType is "+objectType+" and targetState is "+targetState+" objectID = "+objectID+" C_ID = "+C_ID);


			if (objectType.equalsIgnoreCase("WTPart")) {

				QuerySpec partQS = WebServiceHelper.findPartByNumberAndCadim(objectID, C_ID);
				ClassAttribute attribute=new ClassAttribute(WTPart.class,"iterationInfo.identifier.iterationId");
				partQS.appendOrderBy(new OrderBy(attribute,true));
				QueryResult partQR = PersistenceHelper.manager
						.find((StatementSpec) partQS);
				if(partQR.size()>0)
				{
				Persistable resObj[] = (Persistable[]) partQR.nextElement();
				LOGGER.debug("resObj: " + resObj[0]);
				WTPart resPart = (WTPart) resObj[0];
				logWriter.info("resObj: " + resObj[0]);
				WTPart latestPartRevision = (WTPart)ObjectRevisionHelper.getLatestVersionByPersistable(resPart);
				WTPart latestPartIteration = (WTPart) VersionControlHelper
						.getLatestIteration(latestPartRevision);
				//retrieving design view part
				 latestPartIteration = (WTPart)WebServiceHelper.getDesignViewPart((WTPart)latestPartIteration);
					if(latestPartIteration == null)
						throw new WTException("Design view Part with number "+latestPartRevision.getNumber()+" not found");
				LOGGER.debug("Set State for Part "+latestPartIteration.getNumber()+" Revision is "+ latestPartIteration.getVersionIdentifier().getValue()+" and Iteration is "+latestPartIteration.getIterationIdentifier().getValue());
				logWriter.info("Set State for Part "+latestPartIteration.getNumber()+"Revision is "+ latestPartIteration.getVersionIdentifier().getValue()+" and Iteration is "+latestPartIteration.getIterationIdentifier().getValue());
				oldCadimTransferDate = IBAHelper.readIBA(latestPartIteration, "KB_CADIM_TRANSFER_DATE");
				
				LOGGER.debug("Part found with KB_CADIM_TRANSFER_DATE "+oldCadimTransferDate);
				logWriter.info("Part found with KB_CADIM_TRANSFER_DATE "+oldCadimTransferDate);
				LOGGER.debug("Trigger date is "+transferDate);
				logWriter.info("Trigger date is "+transferDate);
				
				if(oldCadimTransferDate.after(transferDate))
				{
					LOGGER.debug("Trigger date is earlier that CADIM Update date Skipping the trigger");
					logWriter.info("Trigger date is earlier that CADIM Update date Skipping the trigger");
					throw new WTException("Trigger date "+ transferDate +"is earlier that CADIM Update date "+oldCadimTransferDate+" forpart version "+latestPartIteration.getVersionIdentifier().getValue()+" and Iteration  "+latestPartIteration.getIterationIdentifier().getValue()+" Skipping the trigger");
				}
				LOGGER.debug("part ===" + resPart);
				logWriter.info("part ===" + resPart);
				
				if(!targetState.equals("1060")){
				LifeCycleHelper.service.setLifeCycleState(latestPartIteration,
						State.toState(targetState));
				}
				else{
					LOGGER.debug("Target State is 1060 going to set hasPendingChange flag to true");
					logWriter.info("Target State is 1060 going to set hasPendingChange flag to true");
					latestPartIteration.setHasPendingChange(true);
					PersistenceServerHelper.manager.update(latestPartIteration);
					LifeCycleHelper.service.setLifeCycleState(latestPartIteration,
							State.toState(targetState));
					LOGGER.debug("After setting hasPendingChange flag to true");
					logWriter.info("After setting hasPendingChange flag to true");
				}

				LOGGER.debug("part after set state ===" + resPart);
				logWriter.info("part after set state ===" + resPart);
				
				latestPartIteration = (WTPart) PersistenceHelper.manager.refresh(latestPartIteration);

				logWriter.info("Associate Object Share Condition : "
						+ (KBUtils.getStateIntegerValue(latestPartIteration) >= 1030));

				if (KBUtils.getStateIntegerValue(latestPartIteration) >= 1030) {
					ProjectHelper.updateItemInRelatedSharedProjects(latestPartIteration);
				}
				
				}
				else{
					throw new WTException("Part with number "+objectID+" and CID "+C_ID+" not found");
				}
			}

			if (objectType.equalsIgnoreCase("WTDocument")) {
				QuerySpec docQS = WebServiceHelper.findDocumentByNumberAndCadim(objectID, C_ID);
				ClassAttribute attribute=new ClassAttribute(WTDocument.class,"iterationInfo.identifier.iterationId");
				docQS.appendOrderBy(new OrderBy(attribute,true));
				QueryResult docQR = PersistenceHelper.manager
						.find((StatementSpec) docQS);
				if(docQR.size()>0)
				{
				
				Persistable resObj[] = (Persistable[]) docQR.nextElement();
				LOGGER.debug("resObj: " + resObj[0]);
				logWriter.info("resObj: " + resObj[0]);
				WTDocument resDoc = (WTDocument) resObj[0];
				LOGGER.debug("resDoc ===" + resDoc);
				logWriter.info("resDoc ===" + resDoc);
				String version = resDoc.getVersionIdentifier().getValue();
				String iteration = resDoc.getIterationIdentifier().getValue();
				//WTDocument latestDocIteration = (WTDocument) VersionControlHelper.getLatestIteration(resDoc);
				LOGGER.debug("Document Revision is "+version+" and Iteration is "+iteration);
				logWriter.info("Document Revision is "+version+" and Iteration is "+iteration);
				while(docQR.hasMoreElements())
				{
					Persistable nextObj[] = (Persistable[]) docQR.nextElement();
					LOGGER.debug("nextObj: " + nextObj[0]);
					logWriter.info("nextObj: " + nextObj[0]);
					WTDocument nextDoc = (WTDocument) nextObj[0];
					LOGGER.debug("nextDoc ===" + nextDoc);
					logWriter.info("nextDoc ===" + nextDoc);
					String nextDocVersion = nextDoc.getVersionIdentifier().getValue();
					String nextDocIteration = nextDoc.getIterationIdentifier().getValue();
					LOGGER.debug("Document Revision is "+nextDocVersion+" and Iteration is "+nextDocIteration);
					logWriter.info("Document Revision is "+nextDocVersion+" and Iteration is "+nextDocIteration);
					if(nextDocIteration.compareTo(iteration)>0)
					{
						resDoc = nextDoc;
					}
				}
				String IREV = IBAHelper.readIBA(resDoc, "KB_INTERNAL_REVISION");
				oldCadimTransferDate = IBAHelper.readIBA(resDoc, "KB_CADIM_TRANSFER_DATE");
				LOGGER.debug("Doc found with KB_CADIM_TRANSFER_DATE "+oldCadimTransferDate);
				logWriter.info("Doc found with KB_CADIM_TRANSFER_DATE "+oldCadimTransferDate);
				LOGGER.debug("Trigger date is "+transferDate);
				logWriter.info("Trigger date is "+transferDate);
				if(oldCadimTransferDate.after(transferDate))
				{
					LOGGER.debug("Trigger date is earlier that CADIM Update date Skipping the trigger");
					logWriter.info("Trigger date is earlier that CADIM Update date Skipping the trigger");
					throw new WTException("Trigger date "+ transferDate +"is earlier that CADIM Update date "+oldCadimTransferDate+" for part version "+resDoc.getVersionIdentifier().getValue()+" and Iteration  "+resDoc.getIterationIdentifier().getValue()+" Skipping the trigger");
				}
				logWriter.info("resDoc ===" + resDoc);
				LOGGER.debug("Set State for Document Revision is "+ resDoc.getVersionIdentifier().getValue()+" and Iteration is "+resDoc.getIterationIdentifier().getValue());
				logWriter.info("Set State for Document Revision is "+ resDoc.getVersionIdentifier().getValue()+" and Iteration is "+resDoc.getIterationIdentifier().getValue());
				if(!targetState.equals("1060")){
				LifeCycleHelper.service.setLifeCycleState(resDoc,
						State.toState(targetState));
				TypeIdentifier docType = wt.type.TypedUtilityServiceHelper.service.getTypeIdentifier(resDoc);
				if (docType.isDescendedFrom(KBTypeIdProvider.getType("TECHDRWDOC"))) {
				List <WTDocument> variantDocuments = DBUtils.navigateBetweenObjects(WTDocument.class, ConfigurableRevisionLink.class, resDoc,ConfigurableRevisionLink.ROLE_BOBJECT_ROLE);
				LOGGER.debug("Number of Variant Documents is "+variantDocuments.size());
				logWriter.info("Number of Variant Documents is "+variantDocuments.size());
				for (WTDocument varDoc : variantDocuments) 
				{
					String varCID = IBAHelper.readIBA(varDoc, "KB_CADIM_CID");
					if(varCID.equals(C_ID))
					{
					LOGGER.debug("Set State for Document variant "+varDoc.getNumber()+" Revision is "+ varDoc.getVersionIdentifier().getValue()+" and Iteration is "+varDoc.getIterationIdentifier().getValue());
					logWriter.info("Set State for Document variant "+varDoc.getNumber()+"Revision is "+ varDoc.getVersionIdentifier().getValue()+" and Iteration is "+varDoc.getIterationIdentifier().getValue());
					LifeCycleHelper.service.setLifeCycleState(varDoc,
							State.toState(targetState));
					}
				}
				}
				}
				else{
					LOGGER.debug("Target State is 1060 going to set hasPendingChange flag to true");
					logWriter.info("Target State is 1060 going to set hasPendingChange flag to true");
					resDoc.setHasPendingChange(true);
					PersistenceServerHelper.manager.update(resDoc);
					LOGGER.debug("After setting hasPendingChange flag to true");
					logWriter.info("After setting hasPendingChange flag to true");
					TypeIdentifier docType = wt.type.TypedUtilityServiceHelper.service.getTypeIdentifier(resDoc);
					//if (docType.isDescendedFrom(KBTypeIdProvider.getType("TECHDRWDOC")) || docType.isDescendedFrom(KBTypeIdProvider.getType("TECHDOC")) ) {
					List <WTDocument> variantDocuments = DBUtils.navigateBetweenObjects(WTDocument.class, ConfigurableRevisionLink.class, resDoc,ConfigurableRevisionLink.ROLE_BOBJECT_ROLE);
					LOGGER.debug("variantDocuments size "+variantDocuments.size());
					logWriter.info("variantDocuments size "+variantDocuments.size());
					for (WTDocument varDoc : variantDocuments) 
					{
						String varCID = IBAHelper.readIBA(varDoc, "KB_CADIM_CID");
						LOGGER.debug("variant CID "+varCID);
						logWriter.info("variant CID "+varCID);
						LOGGER.debug("source CID "+C_ID);
						logWriter.info("source CID "+C_ID);
						if(varCID.equals(C_ID))
						{
						varDoc.setHasPendingChange(true);
						PersistenceServerHelper.manager.update(varDoc);
						LOGGER.debug("After setting hasPendingChange flag to true for variant document "+varDoc.getNumber());
						logWriter.info("After setting hasPendingChange flag to true for variant document "+varDoc.getNumber());
						}
					}
					//}
				}

				LOGGER.debug("doc after set state ===" + resDoc);
				logWriter.info("doc after set state ===" + resDoc);
				
				resDoc = (WTDocument) PersistenceHelper.manager.refresh(resDoc);

				logWriter.info(
						"Associate Object Share Condition : " + (KBUtils.getStateIntegerValue(resDoc) >= 1035));

				if (KBUtils.getStateIntegerValue(resDoc) >= 1035) {
					ProjectHelper.updateItemInRelatedSharedProjects(resDoc);
				}
				
				}
				else{
					throw new WTException("Document with number "+objectID+" and CID "+C_ID+" not found");
				}
			}
			logWriter.info("trx===" + trx);
			trx.commit();
			trx = null;
			result.add("ReturnCode: 0");
            result.add("Text: Success");
            logWriter.info("result of the service call is "+result);
			return result;
		} 
		catch (WTInvalidParameterException e) {
			String message = "WTInvalidParameterException during set State exception is " + e;
			result.add("ReturnCode: 1");
            result.add("Text: "+message);
            logWriter.info("result of the service call is "+result);
			return result;

		}catch (WTException e) {
			String message = "WTException during set State exception is " + e;
			result.add("ReturnCode: 1");
            result.add("Text: "+message);
            logWriter.info("result of the service call is "+result);
			return result;

		} catch (WTPropertyVetoException e) {
			String message = "WTPropertyVetoException during set state exception is " + e;
			result.add("ReturnCode: 1");
            result.add("Text: "+message);
            logWriter.info("result of the service call is "+result);
			return result;
		} finally {
			logWriter.info("trx in finally===" + trx);
			if (trx != null) {
				trx.rollback();
			}
		}
	}

}