package ext.kb.ws;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.xml.bind.JAXBException;
import javax.xml.bind.annotation.XmlElement;

import org.apache.log4j.Logger;

import wt.configurablelink.ConfigurableRevisionLink;
import wt.doc.WTDocument;
import wt.doc.WTDocumentMaster;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.collections.WTHashSet;
import wt.fc.collections.WTSet;
import wt.folder.Folder;
import wt.folder.FolderHelper;
import wt.inf.container.WTContainer;
import wt.log4j.LogR;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.pds.StatementSpec;
import wt.pom.Transaction;
import wt.query.QuerySpec;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.vc.Iterated;
import wt.vc.VersionControlHelper;

import com.ptc.jws.servlet.JaxWsWebService;

import ext.kb.service.WebServiceHelper;
import ext.kb.util.IBAHelper;
import ext.kb.util.ObjectRevisionHelper;

@WebService()
public class KBMoveDocumentToProtectectedFolderService extends JaxWsWebService
{
	private static final Logger LOGGER = LogR.getLogger(KBMoveDocumentToProtectectedFolderService.class.getName());
	private static final Logger logWriter = LogR.getLogger("ext.kb.ws.KBMoveDocumentToProtectectedFolderService_Log");
	@WebMethod(operationName = "moveDocumentToProtectedFolder")
	public List<String> moveDocumentToProtectedFolder(@WebParam(name = "targetFolder") String targetFolder,
			@WebParam(name = "objectID") String objectID,
			@WebParam(name = "C_ID") String C_ID) throws WTException,
			WTPropertyVetoException, JAXBException, IOException			

	{

		Transaction trx = null;
		
		List<String> result = new ArrayList<String>();
		try {
			
			trx = new Transaction();
			trx.start();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
            Date date = new Date();
            String formatedDate = sdf.format(date);
            Map<String, String> FolderNameMapping = new HashMap<String, String>();
            FolderNameMapping.put("/Default/00 Protected Space/Data",   "/Default/00 Confidential/Data");
            FolderNameMapping.put("/Default/10 BA - Limited/Data",   "/Default/10 Internal/Data");
            FolderNameMapping.put("/Default/50 Public - Global/Data",   "/Default/50 Public - Global/Data");
            FolderNameMapping.put("/Default/20 BA - Extended/Data",   "/Default/20 Public/Data");
            logWriter.info("Processing MoveDocumentToProtectectedFolder request on "+formatedDate+" for object where number is "+objectID+" and CID is "+C_ID+" targetFolder = "+targetFolder);
            LOGGER.debug("Processing MoveDocumentToProtectectedFolder request on "+formatedDate+" for object where number is "+objectID+" and CID is "+C_ID+" targetFolder = "+targetFolder);
				QuerySpec docQS = WebServiceHelper.findDocumentByNumberAndCadim(objectID, C_ID);
				QueryResult docQR = PersistenceHelper.manager
						.find((StatementSpec) docQS);
				if(docQR.size()>0)
				{
				Persistable resObj[] = (Persistable[]) docQR.nextElement();
				LOGGER.debug("resObj: " + resObj[0]);
				WTDocument resDoc = (WTDocument) resObj[0];
				LOGGER.debug("resDoc ===" + resDoc);
				logWriter.info("resDoc ===" + resDoc);
				WTDocument latestDocRevision = (WTDocument)ObjectRevisionHelper.getLatestVersionByPersistable(resDoc);
				WTDocument latestDocIteration = (WTDocument) VersionControlHelper
						.getLatestIteration(latestDocRevision);
				WTContainer docContainer = latestDocIteration.getContainer();
				LOGGER.debug("container name ===" + docContainer.getName());
				logWriter.info("container name ===" + docContainer.getName());
				Folder folder = null;
				logWriter.info( " folder path" + targetFolder);
				LOGGER.debug( " folder path" + targetFolder);
				boolean folderExists = WebServiceHelper.folderExistsInContainer(docContainer, targetFolder, latestDocIteration);
				logWriter.info( " folderExists " + folderExists);
				LOGGER.debug( " folderExists " + folderExists);
				if(!folderExists)
				{
					String oldFolderPath = FolderNameMapping.get(targetFolder);
					logWriter.info( " oldFolderPath " + oldFolderPath);
					LOGGER.debug( " oldFolderPath " + oldFolderPath);
					if(oldFolderPath != null)
					{
						boolean oldFolderExists = WebServiceHelper.folderExistsInContainer(docContainer, oldFolderPath, latestDocIteration);
						logWriter.info( " oldFolderPath " + oldFolderPath);
						LOGGER.debug( " oldFolderPath " + oldFolderPath);
						if(oldFolderExists)
						{
							WebServiceHelper.moveDocToContainer(docContainer, oldFolderPath, latestDocIteration);
							moveVariantsToContainer(docContainer, oldFolderPath, latestDocIteration);
						}
						else
						{
							WebServiceHelper.moveDocToContainer(docContainer, "/Default", latestDocIteration);
							moveVariantsToContainer(docContainer, "/Default", latestDocIteration);
						}
					}
					else
					{
						WebServiceHelper.moveDocToContainer(docContainer, "/Default", latestDocIteration);
						moveVariantsToContainer(docContainer, "/Default", latestDocIteration);
					}
				}
				else
				{
					WebServiceHelper.moveDocToContainer(docContainer, targetFolder, latestDocIteration);
					moveVariantsToContainer(docContainer, targetFolder, latestDocIteration);
				}
				}
				else{
					throw new WTException("Document with number "+objectID+" and CID "+C_ID+" not found");
				}
				trx.commit();
				trx = null;
				result.add("ReturnCode: 0");
	            result.add("Text: Success");
	            logWriter.info("result from the service is "+result);
				return result;
				} catch (WTException e) {
				String message = "WTException during Delete exception is " + e;
				result.add("ReturnCode: 1");
	            result.add("Text: "+message);
	            logWriter.info("result from the service is "+result);
				return result;

		} catch (WTPropertyVetoException e) {
			String message = "WTPropertyVetoException during Delete exception is " + e;
			result.add("ReturnCode: 1");
            result.add("Text: "+message);
            logWriter.info("result from the service is "+result);
			return result;
		}finally {
			LOGGER.debug("trx in finally===" + trx);
			if (trx != null) {
				trx.rollback();
			}
		}
	}
	private void moveVariantsToContainer(WTContainer docContainer, String folderPath, WTDocument latestDocIteration) throws WTException {
		
		LOGGER.debug("latestDocIteration : "+latestDocIteration.getNumber()+" "+latestDocIteration.getIterationIdentifier());
		
		QueryResult qrLinks = PersistenceHelper.manager.navigate(latestDocIteration,
				ConfigurableRevisionLink.ROLE_BOBJECT_ROLE, ConfigurableRevisionLink.class, true);
		LOGGER.debug("Variant links from source : "+qrLinks.size());
		while (qrLinks.hasMoreElements()) {
			Object obj = qrLinks.nextElement();
			
			LOGGER.debug("Role B object : " + obj);
			if (obj instanceof WTDocument) {
				WTDocument doc = (WTDocument)obj;
				WTDocument docRevision = (WTDocument)ObjectRevisionHelper.getLatestVersionByPersistable(doc);
				WTDocument docIteration = (WTDocument) VersionControlHelper
						.getLatestIteration(docRevision);
				LOGGER.debug("Moving Variant Document  : "+doc.getNumber()+" to folder "+folderPath+" to Container : "+docContainer);
				WebServiceHelper.moveDocToContainer(docContainer, folderPath, docIteration);
			}
		}
		
	}
}