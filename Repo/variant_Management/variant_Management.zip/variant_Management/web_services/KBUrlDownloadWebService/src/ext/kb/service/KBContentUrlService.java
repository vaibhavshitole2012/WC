package ext.kb.service;

import java.beans.PropertyVetoException;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.attribute.PosixFilePermission;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import org.apache.log4j.Logger;

import com.ptc.windchill.enterprise.wvs.saveWVSObject.utils.SaveWVSObjectHelper;
import com.ptc.wvs.server.util.PublishUtils;

import ext.kb.service.KBContentHelper;
import ext.kb.util.IBAHelper;
import wt.content.ApplicationData;
import wt.content.ContentHelper;
import wt.content.ContentHolder;
import wt.content.ContentItem;
import wt.content.ContentRoleType;
import wt.content.ContentServerHelper;
import wt.doc.WTDocument;
import wt.doc.WTDocumentMaster;
import wt.fc.ObjectIdentifier;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.fc.WTReference;
import wt.httpgw.URLFactory;
import wt.log4j.LogR;
import wt.org.WTPrincipal;
import wt.representation.Representable;
import wt.representation.Representation;
import wt.session.SessionHelper;
import wt.util.WTContext;
import wt.util.WTException;
import wt.util.WTProperties;
import wt.util.WTRuntimeException;

/**
 * This service exposes a static method {@link getContentUrls} that is called
 * from a Web service running on the same method server. <br>
 * 
 */
public class KBContentUrlService {
	protected static final Logger log = LogR.getLogger(KBContentUrlService.class.getName());
	public static final String ALLOWED_FILE_TYPES = "FileTypes";
	public static final Map<String, Set<String>> activityNameToFileTypeMapping;
	static 
	{
		activityNameToFileTypeMapping = new HashMap<String, Set<String>>();
		Set<String> allowedFileTypesSet = new HashSet<String>();
		allowedFileTypesSet.add("DOC");
		allowedFileTypesSet.add("doc");
		allowedFileTypesSet.add("docx");
		allowedFileTypesSet.add("DOCX");
		allowedFileTypesSet.add("ppt");
		allowedFileTypesSet.add("PPT");
		allowedFileTypesSet.add("pptx");
		allowedFileTypesSet.add("PPTX");		
		allowedFileTypesSet.add("xls");
		allowedFileTypesSet.add("xlsx");
		allowedFileTypesSet.add("XLS");
		allowedFileTypesSet.add("XLSX");
		allowedFileTypesSet.add("eps");
		allowedFileTypesSet.add("EPS");
		allowedFileTypesSet.add("PS");
		allowedFileTypesSet.add("ps");
		allowedFileTypesSet.add("VSD");
		allowedFileTypesSet.add("vsd");
		allowedFileTypesSet.add("MPP");
		allowedFileTypesSet.add("mpp");
		allowedFileTypesSet.add("pdf");
		allowedFileTypesSet.add("PDF");
		allowedFileTypesSet.add("dxf");
		allowedFileTypesSet.add("DXF");
		allowedFileTypesSet.add("stp");
		allowedFileTypesSet.add("STP");
		allowedFileTypesSet.add("tiff");
		allowedFileTypesSet.add("tif");
		allowedFileTypesSet.add("TIFF");
		allowedFileTypesSet.add("TIF");
		allowedFileTypesSet.add("JT");
		allowedFileTypesSet.add("jt");
		allowedFileTypesSet.add("cgm");
		allowedFileTypesSet.add("CGM");
		allowedFileTypesSet.add("zip");
		allowedFileTypesSet.add("ZIP");
		allowedFileTypesSet.add("jar");
		allowedFileTypesSet.add("JAR");
		allowedFileTypesSet.add("DWG");
		allowedFileTypesSet.add("dwg");
		
		activityNameToFileTypeMapping.put(ALLOWED_FILE_TYPES,allowedFileTypesSet);
	}

    /**
     * Retrieves the content URLs for the given object id.
     * 
     * @param oid: wt.epm.EPMDocument:123456
     * @return a list of URLs:
     *         <ol>
     *         <li>Primary content</li>
     *         <li>default representation</li>
     *         <li>attachments</li>
     *         </ol>
     * @throws WTException
     * @throws WTRuntimeException
     * @throws IOException
     * @throws PropertyVetoException
     * @throws WTKContentUploadException
     * @throws WTKContentException
     */
    public static List<String> getContentUrls(String oid, String user, String content,String mastersystem) throws WTRuntimeException,
            WTException, PropertyVetoException, IOException {
    	

    	
        log.debug("KBContentUrlService.getContentUrls called with OID " + oid);
        authenticate3(user);
        List<String> result = new ArrayList<>();
        try {
        final ContentHolder holder = obtainHolder(oid);
        if (holder == null) {
            return null;
        }
        
  
        
        if(content.equalsIgnoreCase("REPRESENTATION"))
        {
        if (holder instanceof Representable) {
                String defRepUrl = fetchDefaultRepresentationUrl((Representable)holder,oid);
                log.debug("Representation defRepUrl ::>>"+defRepUrl);
                result.add(0, defRepUrl == null ? "" : defRepUrl);
              
            }
        }
        else
        {
        	
        	if (holder instanceof Representable) {
                String defRepUrl = fetchDefaultRepresentationUrl((Representable)holder,oid);
                log.debug("defRepUrl ::>>"+defRepUrl);
                //result.add(0, defRepUrl == null ? "" : defRepUrl);
             
            }
			final String primaryUrl = fetchPrimaryContentUrl(holder,oid); 
            log.debug("primaryUrl ::>>"+primaryUrl);
        	result.add(0, primaryUrl == null ? "" : primaryUrl);         
	        final List<String> attUrls = fetchAttachmentUrls(holder,oid);
	        for (int i = 0; i < attUrls.size(); i++) {
	        	log.debug("attUrls.get(i) ::>>"+attUrls.get(i));
	            result.add(1 + i, attUrls.get(i) == null ? "" :attUrls.get(i));
        }
	        if(mastersystem.equalsIgnoreCase("CADIM")){
	        WTProperties propertiess = WTProperties.getLocalProperties();
	    	String value = propertiess.getProperty("CADIM_TRANSFER_LOCATION");
	        log.debug("CADIM_TRANSFER_LOCATION: " + value);
	       writeContentFileToServer(new File(value), oid);
	        log.debug("After Writing Content FIle to server " + value);
	        }
        }
        log.debug("result size ::>>"+result.size());
        if(result.isEmpty()) {
        	result.add("No content attached to document");
        }
        }catch(WTRuntimeException | WTException | PropertyVetoException | IOException e) {
        	if(!result.isEmpty()){
        		result.clear();
        	}
        	result.add("Return Code :1");
        	result.add(e.getLocalizedMessage());
        
        }
         
        return result;
    }

    private static List<String> fetchAttachmentUrls(ContentHolder holder,String oid) throws WTException,
            PropertyVetoException, IOException {
        List<String> result = new ArrayList<>();
    	WTProperties props = WTProperties.getLocalProperties();
    	String WINDCHILL_SERVER = props.getProperty("wt.rmi.server.hostname");
    	String PORT = props.getProperty("wt.webserver.port");
    	String WEB_APP = props.getProperty("wt.webapp.name");
    	
    	log.debug("WINDCHILL_SERVER===" + WINDCHILL_SERVER);
    	log.debug("PORT===" + PORT);
    	log.debug("WEB_APP===" + WEB_APP);

        final Set<ApplicationData> appDatas = KBContentHelper.retrieveAttachmentContainer(holder);
        Iterator<ApplicationData> iterator = appDatas.iterator();

        while (iterator.hasNext()) {
            ApplicationData appData = iterator.next();
            if (appData == null) {
                log.debug("Secondary content for holder <" + holder + "> not found.");
                continue;
            }

            log.debug("Content Role is "+appData.getRole());
            if (!ContentRoleType.SECONDARY.equals(appData.getRole())) {
                log.debug("Not secondary content but <" + appData.getRole() + ">. Skipped.");
                continue;
            }

            String fileType="";
            ObjectIdentifier coid = appData.getPersistInfo().getObjectIdentifier();
            String fileName = appData.getFileName();
            log.debug("fileName " + fileName);
            fileName=fileName.replaceAll("[^\\p{Alnum}+{\\-}+{\\.}+{\\_}]", "_");
            log.debug("filename ::>>"+fileName);
            if(fileName != null)
            {
            	fileType = com.ptc.ddl.util.FileHelper.getExtension(fileName);
            	log.debug("fileType " + fileType);
            }
            String description = appData.getDescription();
			if(activityNameToFileTypeMapping.get(ALLOWED_FILE_TYPES).contains(fileType) && !("RAW".equals(description)))
			{
				log.debug("coid " + coid);
				log.debug("coid.toString() " + coid.toString());
				String[] splitCoid = coid.toString().split(":");
				int size = splitCoid.length;
				log.debug("splitCoid.length " + size);
				String intCoid = splitCoid[size -1];
				log.debug("intCoid " + intCoid);
				String url = "http://"+WINDCHILL_SERVER+":"+PORT+"/"+WEB_APP+"/ptc1/download/KB_File_Download?coid="+intCoid+"|"+fileName+"|"+fileType;
				log.debug("Found attachment content url: " + url);
				result.add(url);
			}
        }

        log.debug("secondary attachments " + result.size());
        return result;
    }

    private static String fetchDefaultRepresentationUrl(Representable holder,String oid) throws WTException,
            PropertyVetoException, IOException {
        log.debug("fetchDefaultRepresentationUrl for holder " + holder);

        final List<Representation> representations = KBContentHelper.retrieveRepresentations(holder);
        if (representations == null) {
            log.error("Failed to retrieve representations for holder " + holder);
            return null;
        }

        //URL result = null;
        String result = "";
    	WTProperties props = WTProperties.getLocalProperties();
    	String WINDCHILL_SERVER = props.getProperty("wt.rmi.server.hostname");
    	String PORT = props.getProperty("wt.webserver.port");
    	String WEB_APP = props.getProperty("wt.webapp.name");
    	
    	log.debug("WINDCHILL_SERVER===" + WINDCHILL_SERVER);
    	log.debug("PORT===" + PORT);
    	log.debug("WEB_APP===" + WEB_APP);
    	
        for (final Representation rep : representations) {
        	log.error("Inside representation Loop ");
        	String fileType="";
        	
            if (rep.isDefaultRepresentation()) {
            	log.debug("Default rep found "+rep.getName());
                ApplicationData appData = retrieveApplicationData(rep);
                log.debug("Default rep found app data ==="+appData);
                
                ObjectIdentifier coid = appData.getPersistInfo().getObjectIdentifier();
                String fileName = appData.getFileName();
                
                log.debug("fileName " + fileName);
                fileName=fileName.replaceAll("[^\\p{Alnum}+{\\-}+{\\.}+{\\_}]", "_");
                log.debug("filename ::>>"+fileName);
                if(fileName != null)
                {
                	fileType = com.ptc.ddl.util.FileHelper.getExtension(fileName);
                	log.debug("fileType " + fileType);
                }
				if(activityNameToFileTypeMapping.get(ALLOWED_FILE_TYPES).contains(fileType))
				{
					log.debug("coid " + coid);
					log.debug("coid.toString() " + coid.toString());
					//final URL url = ContentHelper.getDownloadURL(holder, appData);
					//result = getSaveAsURL(coid.toString(),"","");
					log.debug("coid== "+coid);
					log.debug("coid.toString() " + coid.toString());
					String[] splitCoid = coid.toString().split(":");
					int size = splitCoid.length;
					log.debug("splitCoid.length " + size);
					String intCoid = splitCoid[size -1];
					log.debug("intCoid " + intCoid);
					result = "http://"+WINDCHILL_SERVER+":"+PORT+"/"+WEB_APP+"/ptc1/download/KB_File_Download?coid="+intCoid+"|"+fileName+"|"+fileType;

					//result = ContentHelper.getDownloadURL(holder, appData);
					break;
				}
            }
        }
        return result;
    }

    private static ApplicationData retrieveApplicationData(Representation rep) throws WTException,
            PropertyVetoException {
        ContentHolder repHolder = ContentHelper.service.getContents(rep);
        Vector<?> repItems = ContentHelper.getContentListAll(repHolder);

        for (Object repItem : repItems) {
            if (repItem == null) {
                log.debug("Secondary content not found.");
                continue;
            }
            if (!(repItem instanceof ApplicationData)) {
                log.debug(repItem.getClass().getName());
                continue;
            }

            final ApplicationData appData = (ApplicationData) repItem;

            if (!ContentRoleType.SECONDARY.equals(appData.getRole())) {
                log.debug("Not secondary content but <"
                    + appData.getRole()
                    + ">. Skipped.");
                continue;
            }

            return appData;
        }
        return null;
    }

    private static String fetchPrimaryContentUrl(ContentHolder holder,String oid) throws WTException,
            PropertyVetoException, IOException {
        final ApplicationData appData = KBContentHelper.retrievePrimaryContentContainer(holder);
        String fileType="";
		String testUrl="";
    	WTProperties props = WTProperties.getLocalProperties();
    	String WINDCHILL_SERVER = props.getProperty("wt.rmi.server.hostname");
    	String PORT = props.getProperty("wt.webserver.port");
    	String WEB_APP = props.getProperty("wt.webapp.name");
    	
    	log.debug("WINDCHILL_SERVER===" + WINDCHILL_SERVER);
    	log.debug("PORT===" + PORT);
    	log.debug("WEB_APP===" + WEB_APP);

        if (appData == null) {
            log.debug("Primary content for holder <" + holder + "> not found.");
            return null;
        }

        ObjectIdentifier coid = appData.getPersistInfo().getObjectIdentifier();
        String fileName = appData.getFileName();
        log.debug("fileName " + fileName);
        fileName=fileName.replaceAll("[^\\p{Alnum}+{\\-}+{\\.}+{\\_}]", "_");
        log.debug("filename ::>>"+fileName);
        if(fileName != null)
        {
        	fileType = com.ptc.ddl.util.FileHelper.getExtension(fileName);
        	log.debug("fileType " + fileType);
        }
        if(activityNameToFileTypeMapping.get(ALLOWED_FILE_TYPES).contains(fileType))
		{
        	log.debug("coid== "+coid);
			log.debug("coid.toString() " + coid.toString());
			String[] splitCoid = coid.toString().split(":");
			int size = splitCoid.length;
			log.debug("splitCoid.length " + size);
			String intCoid = splitCoid[size -1];
			log.debug("intCoid " + intCoid);
			testUrl = "http://"+WINDCHILL_SERVER+":"+PORT+"/"+WEB_APP+"/ptc1/download/KB_File_Download?coid="+intCoid+"|"+fileName+"|"+fileType;
			log.debug("Found primary content url: " + testUrl);
		}
			return testUrl;
		
    }

    private static ContentHolder obtainHolder(String oid) throws WTRuntimeException, WTException {
        String vrid = "OR:" + oid.trim();
        final WTReference reference = new ReferenceFactory().getReference(vrid);
        if (reference == null) {
            log.error("Cannot find WTReference form OID " + oid);
            return null;
        }

        final Persistable persistable = reference.getObject();
        if (persistable == null) {
            log.error("Cannot find Persistble form OID " + oid);
            return null;
        }

        if (persistable instanceof ContentHolder) {
            return (ContentHolder) persistable;
        }
        log.error("Not a ContentHolder: " + persistable);
        return null;
    }
	
    private static String getSaveAsURL(String coid, String fileName, String fileType) throws WTException {
		URLFactory urlFactory = new URLFactory();
		
		//Persistable p = PublishUtils.getObjectFromRef("wt.content.ApplicationData:" + coid);
		Persistable p = PublishUtils.getObjectFromRef(coid);
		if(p instanceof ApplicationData){
			log.debug("p instanceof ApplicationData ");
			ApplicationData appData = (ApplicationData)p;
			if(fileName == null || fileName.equals(""))
				fileName = appData.getFileName();
			if((fileType == null || fileType.equals("")) && fileName != null)
				fileType = com.ptc.ddl.util.FileHelper.getExtension(fileName);
			log.debug("fileName== "+fileName);
			System.out.println("fileName== "+fileName);
			log.debug("fileType==== "+fileType);
			System.out.println("fileType== "+fileType);
		}
		
		HashMap<String, String> saveAsParams = new HashMap<String, String>();
		saveAsParams.put("oid", PublishUtils.getRefFromObject(p));
		saveAsParams.put("fileType", fileType);
		saveAsParams.put("annotations", "true");
		String url = urlFactory.getHREF(SaveWVSObjectHelper.getSaveWVSObjectGatewayURL() + "/" + fileName, saveAsParams, true);
		return url;
	}
    
    private static void writeContentFileToServer(File dirPath, String oid) throws WTException, PropertyVetoException, IOException{
    	ObjectIdentifier docOID = ObjectIdentifier.newObjectIdentifier(oid);
    	String fileType="";
    	log.debug("docOID== "+docOID);
    	WTDocument doc = (WTDocument)PersistenceHelper.manager.refresh(docOID);
    	WTDocumentMaster docMaster = (WTDocumentMaster) doc.getMaster();
		String Cadim_CID = IBAHelper.readIBA(doc, "KB_CADIM_CID");
		String SAP_IDX = IBAHelper.readIBA(docMaster, "KB_SAP_IDX");
    	log.debug("doc== "+doc);
    	log.debug("Cadim_CID== "+Cadim_CID);
    	log.debug("SAP_IDX== "+SAP_IDX);
    	Set<PosixFilePermission> permission = new HashSet<PosixFilePermission>();
    	permission.add(PosixFilePermission.OWNER_READ);
    	permission.add(PosixFilePermission.OWNER_WRITE);
    	permission.add(PosixFilePermission.OWNER_EXECUTE);
    	permission.add(PosixFilePermission.GROUP_READ);
    	permission.add(PosixFilePermission.GROUP_WRITE);
    	permission.add(PosixFilePermission.GROUP_EXECUTE);
    	permission.add(PosixFilePermission.OTHERS_READ);
    	permission.add(PosixFilePermission.OTHERS_WRITE);
    	permission.add(PosixFilePermission.OTHERS_EXECUTE);
    	File subFolder = new File(dirPath, Cadim_CID+"_"+SAP_IDX);
    	    	
    	if(!subFolder.exists())
    	{
        if (!subFolder.mkdir()) {
            throw new IOException("Failed to create directory " + subFolder);
        }
        Files.setPosixFilePermissions(subFolder.toPath(),permission);
    	}
    	doc = (WTDocument) ContentHelper.service.getContents(doc);
    	ContentItem ci = doc.getPrimary();
    	log.debug("getPrimary== "+ci);
    	if(ci instanceof ApplicationData)
    	{
    		String fileName = ((ApplicationData) ci).getFileName();
            log.debug("fileName " + fileName);
            if(fileName != null)
            {
            	fileType = com.ptc.ddl.util.FileHelper.getExtension(fileName);
            	log.debug("fileType " + fileType);
            }
            if(activityNameToFileTypeMapping.get(ALLOWED_FILE_TYPES).contains(fileType))
    		{
            	log.debug(((ApplicationData)ci).getFileName());
            	String filename1=((ApplicationData)ci).getFileName();
            	log.debug("filename1::>>"+filename1);
            	
            	filename1=filename1.replaceAll("[^\\p{Alnum}+{\\-}+{\\.}+{\\_}]", "_");
				
				log.debug("String str::>>"+filename1);
				ContentServerHelper.service.writeContentStream((ApplicationData) ci, new File(subFolder,filename1).getCanonicalPath());
            	
            	Files.setPosixFilePermissions(new File(subFolder,filename1).toPath(), permission);
            	
            	log.debug("After writing content stream ");
    		}
    	}
    	final QueryResult queryResult = ContentHelper.service.getContentsByRole(doc,ContentRoleType.SECONDARY);
    	log.debug("queryResult.size== "+queryResult.size());
    	 while (queryResult.hasMoreElements()) {
             Object nextElement = queryResult.nextElement();
             if (nextElement instanceof ApplicationData) {
            	 String fileName = ((ApplicationData) nextElement).getFileName();
            	
                 log.debug("fileName " + fileName);
                 if(fileName != null)
                 {
                 	fileType = com.ptc.ddl.util.FileHelper.getExtension(fileName);
                 	log.debug("fileType " + fileType);
                 }
                 if(activityNameToFileTypeMapping.get(ALLOWED_FILE_TYPES).contains(fileType))
         		{
            	 	//ContentServerHelper.service.writeContentStream((ApplicationData) nextElement, new File(subFolder,((ApplicationData) nextElement).getFileName()).getCanonicalPath());
                	 String filename1=((ApplicationData)nextElement).getFileName();
                 	log.debug("filename1::>>"+filename1);
                 	
                	filename1=filename1.replaceAll("[^\\p{Alnum}+{\\-}+{\\.}+{\\_}]", "_");
                 	log.debug("filename1 ::>>"+filename1);
                	 ContentServerHelper.service.writeContentStream((ApplicationData) nextElement, new File(subFolder,filename1).getCanonicalPath());
                	 log.debug("After writing content stream ");
         		}
             	}
             else {
                 log.debug("Content is not an instance of Application data: " + nextElement);
             }
         }
    	
    }


    /**
     * Authenticates to method server with a given user name. It is not for
     * remote access to Windchill.
     *
     * @param username a Windchill user name
     * @throws WTException
     */
    private static void authenticate3(String username) throws WTException {
        log.debug("Authenticating with " + username);

        WTContext.getContext().setLocale(Locale.UK);

        try {
            WTPrincipal newPrincipal = SessionHelper.manager.setPrincipal(username);
            log.trace("newPrincipal:" + newPrincipal);
            WTPrincipal newPrincipal2 = SessionHelper.manager.getPrincipal();
            log.trace("newPrincipal2:" + newPrincipal2);

        } catch (WTException e1) {
            log.error(e1);
        }

    }
    
   
}
