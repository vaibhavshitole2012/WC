package ext.kb.builder.table;

import org.junit.Test;

import com.ptc.core.htmlcomp.tableview.ConfigurableTable;

import ext.kb.tableview.AdditionalInventoriesChangeSummaryTableViews;

public class AdditionalInventoriesChangeSummaryTableBuilderTest {

	@Test
	public void testBuildConfigurableTable() throws Exception {
		ConfigurableTable table = new AdditionalInventoriesChangeSummaryTableBuilder().buildConfigurableTable("");
		if (!AdditionalInventoriesChangeSummaryTableViews.class.getName().equals(table.getClass().getName()))
			throw new RuntimeException("Table view is not correct");
	}

}
