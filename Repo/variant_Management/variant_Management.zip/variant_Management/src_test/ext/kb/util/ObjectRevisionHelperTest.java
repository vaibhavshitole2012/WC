package ext.kb.util;

import org.junit.Test;

import static org.junit.Assert.*;

public class ObjectRevisionHelperTest {

    @Test
    public void getCompareResult() {
    assertEquals(0, ObjectRevisionHelper.getCompareResult("1", "1"));
    assertEquals(0, ObjectRevisionHelper.getCompareResult("11", "11"));
    assertEquals(0, ObjectRevisionHelper.getCompareResult("10", "10"));

    assertTrue(ObjectRevisionHelper.getCompareResult("2", "1") > 0);
    assertTrue(ObjectRevisionHelper.getCompareResult("2", "1") > 0);
    assertTrue(ObjectRevisionHelper.getCompareResult("5", "4") > 0);
    assertTrue(ObjectRevisionHelper.getCompareResult("10", "7") > 0);
    assertTrue(ObjectRevisionHelper.getCompareResult("11", "10") > 0);

    assertTrue(ObjectRevisionHelper.getCompareResult("6", "10") < 0);
    assertTrue(ObjectRevisionHelper.getCompareResult("2", "8") < 0);
    assertTrue(ObjectRevisionHelper.getCompareResult("5", "34") < 0);
    assertTrue(ObjectRevisionHelper.getCompareResult("10", "12") < 0);
    assertTrue(ObjectRevisionHelper.getCompareResult("9", "10") < 0);
    }


}