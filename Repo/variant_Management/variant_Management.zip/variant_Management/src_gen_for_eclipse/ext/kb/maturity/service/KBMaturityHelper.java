package ext.kb.maturity.service;


public class KBMaturityHelper {

    
    public static final ext.kb.maturity.service.KBMaturityService service = wt.services.ServiceFactory.getService(ext.kb.maturity.service.KBMaturityService.class);

}
