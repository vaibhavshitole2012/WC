package com.ptc.generic;

/**
 * Faked.
 * <p>Created on 19.06.2018 11:50:11
 * @author ext-wangc
 *
 */
public class genericResource {

	public static final String CANNOT_LOAD_PROPERTIES = "CANNOT_LOAD_PROPERTIES";
	public static final String NO_INTEGER = "NO_INTEGER";

}
