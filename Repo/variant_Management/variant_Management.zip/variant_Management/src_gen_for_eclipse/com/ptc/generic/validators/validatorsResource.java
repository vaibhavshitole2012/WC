package com.ptc.generic.validators;

/**
 * Faked

 * Created on 19.06.2018 11:41:43
 * @author ext-wangc
 *
 */
public class validatorsResource {

	public static final String INVALID_NO_ACCESS_RIGHT = "INVALID_NO_ACCESS_RIGHT";
	public static final String INVALID_IS_CHECKED_OUT = "INVALID_IS_CHECKED_OUT";
	public static final String INVALID_GROUP_NOT_EXISTANT = "INVALID_GROUP_NOT_EXISTANT";
	public static final String INVALID_GROUP_IS_EMPTY = "INVALID_GROUP_IS_EMPTY";
	public static final String ERROR_EXCEPTION_THROWN = "ERROR_EXCEPTION_THROWN";
	public static final String INVALID_APP_CONTAINER = "INVALID_APP_CONTAINER";
	public static final String INVALID_PARAMETER_WAS_NULL = "INVALID_PARAMETER_WAS_NULL";
	public static final String INVALID_IS_NOT_LATEST = "INVALID_IS_NOT_LATEST";
	public static final String INVALID_LIFECYCLE_STATE = "INVALID_LIFECYCLE_STATE";
	public static final String INVALID_LIFECYCLE = "INVALID_LIFECYCLE";
	public static final String INVALID_NOT_MEMBER_OF_GROUP = "INVALID_NOT_MEMBER_OF_GROUP";
	public static final String VALIDATION_OK    = "VALIDATION_OK    ";
	public static final String VALIDATION_NOTOK = "VALIDATION_NOTOK ";
	public static final String INVALID_OBJECT   = "INVALID_OBJECT   ";

}
