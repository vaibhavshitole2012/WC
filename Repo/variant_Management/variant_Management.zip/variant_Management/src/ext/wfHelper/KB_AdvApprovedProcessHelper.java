package ext.wfHelper;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;

import wt.epm.EPMDocument;

import com.ptc.generic.iba.AttributeService;
import com.ptc.windchill.enterprise.history.MaturityHistoryInfo;

import ext.kb.util.IBAHelper;
import ext.kb.util.KBConstants;
import ext.kb.util.KBUtils;
import ext.kb.workflow.EPMDocumentMaturityHistoryInfoResolver;

/**
 * Class handle actions related to KB_AdvApproved workflow.
 * 
 * @author pboguski
 * 
 */
@Deprecated // R1 customization
public class KB_AdvApprovedProcessHelper {

	/** The logger. */
	private static Logger logger = Logger.getLogger(KB_AdvApprovedProcessHelper.class.getName());
	
	/** Internal name of KB_VERIFIED_BY attribute. */

	/** Internal name of KB_VERIFIED_DATE attribute. */

	/**
	 * Update DesignCADDoc attributes value. The initiator and the actual date
	 * for the promotion (set state) of the objects will be used for the IBAs
	 * KB_VERIFIED_BY and KB_VERIFIED_DATE.
	 * 
	 * @param pbo
	 *            DesignCADDoc object (worklfow primary business object)
	 * @return error message or null in case of no errors
	 */
	public static String updateDrawings(EPMDocument pbo) {

		if (!KBUtils.isDrawing(pbo)) {
			logger.log(Level.FINEST, "EPMDocument: name=" + pbo.getName() + " , number=" + pbo.getNumber()
					+ ", is not Drawing. Processing ended.");
			return null;
		}

		// The initiator and the actual date for the promotion (set state) of
		// the objects will be used for the IBAs KB_VERIFIED_BY and
		// KB_VERIFIED_DATE.
		String veriviedBy = null;
		String veriviedDate = null;
		MaturityHistoryInfo maturityHistoryInfo = null;
		try {
			maturityHistoryInfo = EPMDocumentMaturityHistoryInfoResolver.latestMaturityHistoryInfo(pbo);
		} catch (Exception e) {
			logger.info("Exception occured: " + e);
			return "Error: " + e.getMessage();
		}

		if (maturityHistoryInfo != null) {

			String maturityHistoryInfoLCState = maturityHistoryInfo.getLifecycleStateStr();

			if (!KBConstants.APPROVED_STATE.equals(maturityHistoryInfoLCState)) {
				String errorMsg = "Latest set state, for EPMDocument: name=" + pbo.getName() + ", number="
						+ pbo.getNumber() + ", state should be " + KBConstants.APPROVED_STATE + " but it is "
						+ maturityHistoryInfoLCState;
				logger.log(Level.SEVERE, errorMsg);
				return errorMsg;
			}

			veriviedBy = maturityHistoryInfo.getPromotedBy();

			if (maturityHistoryInfo.getPromotedDate() != null && maturityHistoryInfo.getPromotedDate().size() != 0) {
				Timestamp promoteDate = maturityHistoryInfo.getPromotedDate().get(0);
				String dateFormat = AttributeService.getAttribute(pbo, KBConstants.KB_DATE_FORMAT_IBA);
				SimpleDateFormat format = null;
				if (dateFormat != null && !dateFormat.equals("")) {
					format = new SimpleDateFormat(dateFormat);
				} else {
					format = new SimpleDateFormat(KBConstants.WORKFLOWDATEFORMAT);
				}
				veriviedDate = format.format(promoteDate);
			} else {
				String errorMsg = "Unable to find promotion date for EPMDocument: name=" + pbo.getName() + ", number="
						+ pbo.getNumber();
				logger.log(Level.SEVERE, errorMsg);
				return errorMsg;
			}

		} else {
			String errorMsg = "Data related to set state was not found for EPMDocument: name=" + pbo.getName()
					+ ", number=" + pbo.getNumber();
			logger.log(Level.SEVERE, errorMsg);
			return errorMsg;
		}

		try {
			// setting IBA's should be skipped for users from list in
			// preferences
			if (KBUtils.isSpecialUser(maturityHistoryInfo.getPromotedBy())) {
				logger.info("Setting IBA'a KB_VERIFIED_BY and KB_VERIFIED_DATE omitted for user "
						+ maturityHistoryInfo.getPromotedBy());
				return null;
			}

			IBAHelper.updateIBAAttributeValueWithoutCheckout(pbo, KBConstants.KB_VERIFIED_DATE_IBA, veriviedDate);
			logger.info("EPMDocument: name=" + pbo.getName() + " , number=" + pbo.getNumber() + ", IBA:"
					+ KBConstants.KB_VERIFIED_BY_IBA + " set. Value=" + veriviedDate);

			String veriviedByKb = KBUtils.getUserIdFormWindchillId(veriviedBy);
			if (veriviedByKb == null) {
				String errorMsg = "ID for user=" + veriviedBy + " not found";
				logger.log(Level.SEVERE, errorMsg);
				return errorMsg;
			}
			IBAHelper.updateIBAAttributeValueWithoutCheckout(pbo, KBConstants.KB_VERIFIED_BY_IBA, veriviedByKb);
			logger.info("EPMDocument: name=" + pbo.getName() + " , number=" + pbo.getNumber() + " , IBA:"
					+ KBConstants.KB_VERIFIED_BY_IBA + " set. Value=" + veriviedByKb);

		} catch (Exception e) {
			logger.info("Exception: " + e);
			return "Error: " + e.getMessage();
		}

		return null;
	}

}
