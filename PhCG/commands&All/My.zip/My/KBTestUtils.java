/**
 * 
 */
package ext.kb.test;

import org.apache.log4j.Logger;

import com.ptc.windchill.cadx.common.util.CADDocUtilities;

import ext.kb.processors.ConvertToCadProcessor;
import ext.kb.util.KBTypeIdProvider;
import wt.doc.DocumentType;
import wt.doc.WTDocument;
import wt.epm.EPMApplicationType;
import wt.epm.EPMContextHelper;
import wt.epm.EPMDocument;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.collections.WTArrayList;
import wt.fc.collections.WTList;
import wt.folder.Cabinet;
import wt.folder.FolderHelper;
import wt.log4j.LogR;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.session.SessionHelper;
import wt.type.TypedUtility;
import wt.util.WTException;
import wt.util.WTInvalidParameterException;
import wt.util.WTPropertyVetoException;

/**
 * @author bankowskie
 *
 */
public class KBTestUtils {
	
	private KBTestUtils() {}

	private static final Logger LOG = LogR.getLogger(KBTestUtils.class.getName());


	
	public static WTDocument findDocumentByNumber(String number) {
		try {
			QuerySpec spec = new QuerySpec(WTDocument.class);
			SearchCondition condition = new SearchCondition(WTDocument.class, WTDocument.NUMBER, SearchCondition.EQUAL, number);
			spec.appendSearchCondition(condition);
			QueryResult find = PersistenceHelper.manager.find(spec);
			return (WTDocument) find.nextElement();
		} catch (WTException e) {
			LOG.error("Unable to find WTDocument ", e);
		}
		return null;
	}

	public static WTDocument createWTDocument() {
		WTDocument result = null;
		try {
			String number = "TD" + System.currentTimeMillis();
			WTDocument wtd = WTDocument.newWTDocument(number,number, DocumentType.getDocumentTypeDefault());
			wtd.setTypeDefinitionReference(TypedUtility.getTypeDefinitionReference(KBTypeIdProvider.getType("TECHDRWDOC").getLeafName()));
			Cabinet personalCabinet = FolderHelper.service.getPersonalCabinet(SessionHelper.getPrincipal());
			WTList documentsList = new WTArrayList();
			documentsList.add(wtd);
			FolderHelper.assignLocation(documentsList, personalCabinet);
			result =  (WTDocument) PersistenceHelper.manager.store(wtd);
		} catch (WTException | WTPropertyVetoException e) {
			LOG.error("Unable to create WTDocument ", e);
		}
		return result;
	}
	
	public static EPMDocument createEPMDocument() {
		EPMDocument newEpmDoc = null;
		try {
			EPMDocument template = getCadTemplate();
			String number = "KD" + System.currentTimeMillis();
			EPMContextHelper.setApplication(EPMApplicationType.toEPMApplicationType("EPM"));
			Cabinet cabinet = (Cabinet) FolderHelper.service.getPersonalCabinet(SessionHelper.getPrincipal());
			newEpmDoc = CADDocUtilities.newCopyEPMDocument(template, number, number, cabinet, number+".drw");
			CADDocUtilities.saveNewEPMDocument(newEpmDoc, template, false, null, null);
		} catch (WTInvalidParameterException | WTPropertyVetoException | WTException e) {
			LOG.error("Unable to create EPMDocument ", e);
		}
		
		return newEpmDoc;
	}
	
	private static EPMDocument getCadTemplate() {
		EPMDocument cadTemplate = null;
		try {
			QuerySpec spec = new QuerySpec(EPMDocument.class);
			SearchCondition condition = new SearchCondition(EPMDocument.class, EPMDocument.NUMBER, SearchCondition.EQUAL, "CREO2_DRAWING_TEMP");
			spec.appendSearchCondition(condition);
			QueryResult result = PersistenceHelper.manager.find(spec);
			cadTemplate = (EPMDocument) result.nextElement();
		} catch (WTException e) {
			LOG.error("Unable to get CAD Template ", e);
		}
		return cadTemplate;
		
	}
}	
