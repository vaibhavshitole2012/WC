/*     */ package ext.starkey.reports;
/*     */ 
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.time.LocalDateTime;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import java.util.ArrayList;
/*     */ import wt.fc.PersistenceHelper;
/*     */ import wt.fc.QueryResult;
/*     */ import wt.part.WTPart;
/*     */ import wt.part.WTPartHelper;
/*     */ import wt.part.WTPartMaster;
/*     */ import wt.part.WTPartUsageLink;
/*     */ import wt.query.QueryException;
/*     */ import wt.query.QuerySpec;
/*     */ import wt.query.SearchCondition;
/*     */ import wt.query.WhereExpression;
/*     */ import wt.util.WTException;
/*     */ import wt.vc.Mastered;
/*     */ import wt.vc.VersionControlHelper;
/*     */ import wt.vc.config.LatestConfigSpec;
/*     */ 
/*     */ 
/*     */ public class MultiLevelBom
/*     */ {
/*     */   public static void main(String[] paramArrayOfString) throws IOException {
/*  27 */     String[] arrayOfString = paramArrayOfString[0].split(",");
/*  28 */     FileWriter fileWriter = createFile(paramArrayOfString[1]);
/*  29 */     for (String str : arrayOfString) {
/*     */       
/*  31 */       ArrayList<WTPart> arrayList = findParts(str);
/*  32 */       if (!arrayList.isEmpty()) {
/*     */ 
/*     */         
/*  35 */         for (WTPart wTPart : arrayList)
/*     */         {
/*  37 */           getBOMStructure(wTPart, 0, fileWriter);
/*     */         }
/*  39 */         fileWriter.flush();
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  44 */     fileWriter.flush();
/*  45 */     fileWriter.close();
/*     */   }
/*     */ 
/*     */   
/*     */   private static ArrayList<WTPart> findParts(String paramString) {
/*  50 */     ArrayList<WTPart> arrayList = new ArrayList();
/*     */     try {
/*  52 */       QuerySpec querySpec = new QuerySpec(WTPart.class);
/*  53 */       SearchCondition searchCondition1 = new SearchCondition(WTPart.class, "master>number", "LIKE", paramString + "%");
/*  54 */       querySpec.appendWhere((WhereExpression)searchCondition1);
/*  55 */       SearchCondition searchCondition2 = new SearchCondition(WTPart.class, "iterationInfo.latest", "TRUE");
/*  56 */       querySpec.appendAnd();
/*  57 */       querySpec.appendWhere((WhereExpression)searchCondition2);
/*  58 */       QueryResult queryResult = PersistenceHelper.manager.find(querySpec);
/*  59 */       queryResult = (new LatestConfigSpec()).process(queryResult);
/*  60 */       while (queryResult.hasMoreElements())
/*     */       {
/*  62 */         arrayList.add((WTPart)queryResult.nextElement());
/*     */       }
/*     */     }
/*  65 */     catch (QueryException queryException) {
/*     */       
/*  67 */       queryException.printStackTrace();
/*  68 */     } catch (WTException wTException) {
/*     */       
/*  70 */       wTException.printStackTrace();
/*     */     } 
/*  72 */     return arrayList;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void getBOMStructure(WTPart paramWTPart, int paramInt, FileWriter paramFileWriter) throws IOException {
/*  77 */     String str = "";
/*  78 */     if (paramInt == 0) {
/*     */       
/*  80 */       System.out.println("Getting sub components for part " + paramWTPart.getNumber());
/*  81 */       paramFileWriter.write("\n\n" + paramInt + "~" + paramWTPart.getNumber());
/*     */     } 
/*     */     try {
/*  84 */       QueryResult queryResult = WTPartHelper.service.getUsesWTPartMasters(paramWTPart);
/*  85 */       if (queryResult.size() > 0) {
/*     */         
/*  87 */         WTPart wTPart = null;
/*     */         
/*  89 */         paramInt++;
/*  90 */         while (queryResult.hasMoreElements())
/*     */         {
/*  92 */           WTPartUsageLink wTPartUsageLink = (WTPartUsageLink)queryResult.nextElement();
/*     */           
/*  94 */           WTPartMaster wTPartMaster = wTPartUsageLink.getUses();
/*  95 */           QueryResult queryResult1 = VersionControlHelper.service.allIterationsOf((Mastered)wTPartMaster);
/*     */           
/*  97 */           if (queryResult1.hasMoreElements())
/*     */           {
/*  99 */             wTPart = (WTPart)queryResult1.nextElement();
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 110 */           str = "\n" + paramInt + "~" + paramWTPart.getNumber() + "~" + paramWTPart.getVersionDisplayIdentifier().toString() + "~" + wTPart.getNumber() + "~" + wTPart.getName() + "~" + wTPart.getVersionDisplayIdentifier().toString() + "~" + wTPart.getIterationDisplayIdentifier().toString() + "~" + wTPartUsageLink.getQuantity().getAmount() + "~" + wTPartUsageLink.getQuantity().getUnit();
/* 111 */           paramFileWriter.write(str);
/* 112 */           QueryResult queryResult2 = WTPartHelper.service.getUsesWTPartMasters(wTPart);
/* 113 */           if (queryResult2.size() > 0)
/*     */           {
/* 115 */             getBOMStructure(wTPart, paramInt, paramFileWriter);
/*     */           }
/*     */         }
/*     */       
/*     */       } 
/* 120 */     } catch (WTException wTException) {
/*     */       
/* 122 */       wTException.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static FileWriter createFile(String paramString) throws IOException {
/* 128 */     DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyyMMdd");
/* 129 */     LocalDateTime localDateTime = LocalDateTime.now();
/* 130 */     paramString = paramString + dateTimeFormatter.format(localDateTime) + ".txt";
/* 131 */     return new FileWriter(paramString, true);
/*     */   }
/*     */ }


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\starkey\reports\MultiLevelBom.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */