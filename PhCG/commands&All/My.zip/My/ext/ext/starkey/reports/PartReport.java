/*     */ package ext.starkey.reports;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Scanner;
/*     */ import java.util.TreeMap;
/*     */ import org.apache.log4j.Logger;
/*     */ import wt.fc.PersistenceHelper;
/*     */ import wt.fc.QueryResult;
/*     */ import wt.log4j.LogR;
/*     */ import wt.part.WTPart;
/*     */ import wt.query.QueryException;
/*     */ import wt.query.QuerySpec;
/*     */ import wt.query.SearchCondition;
/*     */ import wt.query.WhereExpression;
/*     */ import wt.util.WTException;
/*     */ import wt.vc.config.LatestConfigSpec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PartReport
/*     */ {
/*  35 */   private static ReportHelper reporter = new ReportHelper();
/*  36 */   private static final Logger log = LogR.getLogger(PartReport.class.getName());
/*     */ 
/*     */   
/*     */   public static void main(String[] paramArrayOfString) {
/*  40 */     if (paramArrayOfString.length != 2 || paramArrayOfString[1].contains(".")) {
/*     */       
/*  42 */       System.out.println("Correct Usage:\n\twindchill ext.starkey.reports.PartReport <INPUT_FILE_NAME_WITH_LOCATION> <OUTPUT_FILE_NAME_WITH_LOCATION_WITHOUT_EXTENSION>");
/*  43 */       System.exit(0);
/*     */     } 
/*     */     try {
/*  46 */       Map<String, ArrayList<WTPart>> map = findParts(readInput(paramArrayOfString[0]));
/*  47 */       writeSearchInfo(paramArrayOfString[1], map);
/*  48 */     } catch (IOException iOException) {
/*     */       
/*  50 */       iOException.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static ArrayList<String> readInput(String paramString) throws IOException {
/*  57 */     log.debug("Reading the Input File");
/*  58 */     System.out.println("Reading the Input File");
/*  59 */     ArrayList<String> arrayList = new ArrayList();
/*  60 */     File file = new File(paramString);
/*  61 */     Scanner scanner = new Scanner(file);
/*  62 */     while (scanner.hasNextLine()) {
/*     */       
/*  64 */       String str = scanner.nextLine().trim();
/*  65 */       if (!arrayList.contains(str))
/*     */       {
/*  67 */         arrayList.add(str);
/*     */       }
/*     */     } 
/*  70 */     scanner.close();
/*  71 */     System.out.println("Read Complete");
/*  72 */     return arrayList;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Map<String, ArrayList<WTPart>> findParts(ArrayList<String> paramArrayList) {
/*  77 */     log.debug("Finding the input Parts");
/*  78 */     System.out.println("Finding the input Parts");
/*  79 */     TreeMap<Object, Object> treeMap = new TreeMap<>();
/*     */     
/*  81 */     for (String str : paramArrayList) {
/*     */       
/*  83 */       log.debug("Finding Part " + str);
/*     */       
/*     */       try {
/*  86 */         QuerySpec querySpec = new QuerySpec(WTPart.class);
/*  87 */         SearchCondition searchCondition = new SearchCondition(WTPart.class, "master>number", "=", str);
/*  88 */         querySpec.appendWhere((WhereExpression)searchCondition, new int[] { 0, 1 });
/*  89 */         QueryResult queryResult = PersistenceHelper.manager.find(querySpec);
/*  90 */         if (queryResult.size() == 0) {
/*     */           
/*  92 */           log.debug("No Part Found with Base Search");
/*  93 */           if (str.contains("-")) {
/*     */             
/*  95 */             log.debug("Searching without the dash");
/*  96 */             QuerySpec querySpec1 = new QuerySpec(WTPart.class);
/*  97 */             SearchCondition searchCondition1 = new SearchCondition(WTPart.class, "master>number", "LIKE", str.substring(0, str.indexOf("-") + 1) + "%");
/*  98 */             querySpec1.appendWhere((WhereExpression)searchCondition1, new int[] { 0, 1 });
/*  99 */             queryResult = PersistenceHelper.manager.find(querySpec1);
/*     */           } 
/*     */         } 
/* 102 */         LatestConfigSpec latestConfigSpec = new LatestConfigSpec();
/* 103 */         queryResult = latestConfigSpec.process(queryResult);
/* 104 */         if (queryResult.size() == 0) {
/*     */           
/* 106 */           log.debug("2 search level did not not find anything");
/* 107 */           treeMap.put(str, null); continue;
/*     */         } 
/* 109 */         if (queryResult.size() > 0)
/*     */         {
/* 111 */           ArrayList<WTPart> arrayList = new ArrayList();
/* 112 */           log.debug("Found Parts");
/* 113 */           while (queryResult.hasMoreElements()) {
/*     */             
/* 115 */             WTPart wTPart = (WTPart)queryResult.nextElement();
/* 116 */             arrayList.add(wTPart);
/*     */           } 
/* 118 */           treeMap.put(str, arrayList);
/*     */         }
/*     */       
/*     */       }
/* 122 */       catch (QueryException queryException) {
/*     */         
/* 124 */         queryException.printStackTrace();
/* 125 */       } catch (WTException wTException) {
/*     */         
/* 127 */         wTException.printStackTrace();
/*     */       } 
/*     */     } 
/* 130 */     System.out.println("Find Part Complete");
/* 131 */     return (Map)treeMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void writeSearchInfo(String paramString, Map<String, ArrayList<WTPart>> paramMap) throws IOException {
/* 138 */     log.debug("Writing Search Result");
/* 139 */     System.out.println("Writing Search Result");
/* 140 */     FileWriter fileWriter = reporter.openFile(paramString);
/* 141 */     String str = "";
/*     */     
/* 143 */     if (paramMap.size() > 0) {
/*     */ 
/*     */       
/* 146 */       Iterator<String> iterator = paramMap.keySet().iterator();
/* 147 */       while (iterator.hasNext()) {
/*     */         
/* 149 */         String str1 = iterator.next();
/* 150 */         //ArrayList arrayList = paramMap.get(str1);
				ArrayList<WTPart> arrayList = paramMap.get(str1);
/* 151 */         if (arrayList != null)
/*     */         {
/* 153 */           for (WTPart wTPart : arrayList) {
/*     */             
/* 155 */             str = str1 + "~" + wTPart.getNumber() + "~" + wTPart.getName() + "~" + wTPart.getVersionDisplayIdentifier() + "~" + wTPart.getState().toString();
/* 156 */             reporter.writeLine(fileWriter, str);
/*     */           } 
/*     */         }
/* 159 */         if (arrayList == null) {
/*     */           
/* 161 */           str = str1 + "~Not Found";
/* 162 */           reporter.writeLine(fileWriter, str);
/*     */         } 
/*     */       } 
/*     */     } 
/* 166 */     reporter.closeFile(fileWriter);
/* 167 */     System.out.println("Write report complete");
/*     */   }
/*     */ }


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\starkey\reports\PartReport.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */