/*    */ package ext.starkey.reports;
/*    */ 
/*    */ import java.io.FileWriter;
/*    */ import java.io.IOException;
/*    */ import java.time.LocalDateTime;
/*    */ import java.time.format.DateTimeFormatter;
/*    */ import org.apache.log4j.Logger;
/*    */ import wt.log4j.LogR;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReportHelper
/*    */ {
/* 14 */   private static final Logger log = LogR.getLogger(ReportHelper.class.getName());
/*    */ 
/*    */   
/*    */   public FileWriter openFile(String paramString) throws IOException {
/* 18 */     log.debug("Creating File");
/* 19 */     DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyyMMdd");
/* 20 */     LocalDateTime localDateTime = LocalDateTime.now();
/* 21 */     paramString = paramString + dateTimeFormatter.format(localDateTime) + ".txt";
/* 22 */     return new FileWriter(paramString, true);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean closeFile(FileWriter paramFileWriter) {
/* 27 */     log.debug("Closing the file");
/* 28 */     boolean bool = true;
/*    */     try {
/* 30 */       paramFileWriter.close();
/* 31 */     } catch (IOException iOException) {
/*    */       
/* 33 */       iOException.printStackTrace();
/* 34 */       bool = false;
/*    */     } 
/* 36 */     return bool;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean writeLine(FileWriter paramFileWriter, String paramString) {
/* 41 */     boolean bool = true;
/* 42 */     log.debug("Writing line");
/*    */     try {
/* 44 */       paramFileWriter.write("\n" + paramString);
/* 45 */     } catch (IOException iOException) {
/*    */       
/* 47 */       iOException.printStackTrace();
/* 48 */       bool = false;
/*    */     } 
/* 50 */     return bool;
/*    */   }
/*    */ }
