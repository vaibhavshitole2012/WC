/*     */ package ext.starkey.change.validator;
/*     */ 
/*     */ import com.ptc.core.ui.validation.DefaultUIComponentValidator;
/*     */ import com.ptc.core.ui.validation.UIValidationCriteria;
/*     */ import com.ptc.core.ui.validation.UIValidationFeedbackMsg;
/*     */ import com.ptc.core.ui.validation.UIValidationKey;
/*     */ import com.ptc.core.ui.validation.UIValidationResult;
/*     */ import com.ptc.core.ui.validation.UIValidationResultSet;
/*     */ import com.ptc.core.ui.validation.UIValidationStatus;
/*     */ import com.ptc.windchill.enterprise.change2.validators.ChangeMgmtCreateWizardsValidator;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import org.apache.log4j.Logger;
/*     */ import wt.change2.WTChangeRequest2;
/*     */ import wt.log4j.LogR;
/*     */ import wt.util.WTException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChangeRequestSubmitValidator
/*     */   extends DefaultUIComponentValidator
/*     */ {
/*  40 */   private static final Logger logger = LogR.getLogger(ChangeRequestSubmitValidator.class.getName());
/*  41 */   private ChangeMgmtCreateWizardsValidator defaultValidator = new ChangeMgmtCreateWizardsValidator();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UIValidationResultSet performFullPreValidation(UIValidationKey paramUIValidationKey, UIValidationCriteria paramUIValidationCriteria, Locale paramLocale) throws WTException {
/*  51 */     logger.trace("Performing Full Prevalidation");
/*  52 */     UIValidationResultSet uIValidationResultSet = this.defaultValidator.performFullPreValidation(paramUIValidationKey, paramUIValidationCriteria, paramLocale);
/*  53 */     logger.trace("UI Validation key is ==>" + paramUIValidationKey.toString());
/*  54 */     return uIValidationResultSet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UIValidationResultSet performLimitedPreValidation(UIValidationKey paramUIValidationKey, UIValidationCriteria paramUIValidationCriteria, Locale paramLocale) throws WTException {
/*  64 */     logger.trace("Performing limited Prevalidation");
/*  65 */     return this.defaultValidator.performLimitedPreValidation(paramUIValidationKey, paramUIValidationCriteria, paramLocale);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UIValidationResult validateSelectedAction(UIValidationKey paramUIValidationKey, UIValidationCriteria paramUIValidationCriteria, Locale paramLocale) throws WTException {
/*  76 */     logger.trace("Performing validate selected action");
/*  77 */     return this.defaultValidator.validateSelectedAction(paramUIValidationKey, paramUIValidationCriteria, paramLocale);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UIValidationResult validateFormSubmission(UIValidationKey paramUIValidationKey, UIValidationCriteria paramUIValidationCriteria, Locale paramLocale) throws WTException {
/*  95 */     System.out.println("Validating Form Submission");
/*  96 */     boolean bool = false;
/*  97 */     boolean bool1 = false;
/*  98 */     UIValidationResult uIValidationResult = UIValidationResult.newInstance(paramUIValidationKey, UIValidationStatus.PERMITTED);
/*     */     
/* 100 */     Map map = paramUIValidationCriteria.getFormData();
/* 101 */     Iterator<String> iterator = map.keySet().iterator();
/* 102 */     while (iterator.hasNext()) {
/*     */       
/* 104 */       String str = iterator.next();
/*     */ 
/*     */       
/* 107 */       if (str.contains("wt.part.WTPart")) {
/*     */         
/* 109 */         System.out.println("Has a Part " + str);
/* 110 */         bool = true;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*     */     try {
/* 116 */       bool1 = paramUIValidationCriteria.getObjectClassBeingCreated().isAssignableFrom(WTChangeRequest2.class);
/* 117 */     } catch (NullPointerException nullPointerException) {
/* 118 */       bool1 = false;
/* 119 */       logger.debug("Originating source is not change request");
/*     */     } 
/*     */     
/* 122 */     if (bool1) {
/*     */       
/* 124 */       logger.trace("Working on a Change Request");
/* 125 */       if (bool) {
/*     */         
/* 127 */         logger.trace("found a part");
/* 128 */         List list = paramUIValidationCriteria.getAddedItemsByName("attachments.list.editable");
/* 129 */         if (list.size() == 0) {
/*     */           
/* 131 */           uIValidationResult = UIValidationResult.newInstance(paramUIValidationKey, UIValidationStatus.DENIED);
/* 132 */           UIValidationFeedbackMsg uIValidationFeedbackMsg = new UIValidationFeedbackMsg();
/* 133 */           uIValidationFeedbackMsg.setMessageText("Please Upload an Attachment to submit change request form.");
/* 134 */           uIValidationResult.addFeedbackMsg(uIValidationFeedbackMsg);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 139 */     return uIValidationResult;
/*     */   }
/*     */ }


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\starkey\change\validator\ChangeRequestSubmitValidator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */