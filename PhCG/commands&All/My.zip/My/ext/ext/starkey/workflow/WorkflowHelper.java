/*     */ package ext.starkey.workflow;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import org.apache.log4j.Level;
/*     */ import org.apache.log4j.Logger;
/*     */ import wt.change2.WTChangeRequest2;
/*     */ import wt.fc.Persistable;
/*     */ import wt.fc.PersistenceHelper;
/*     */ import wt.log4j.LogR;
/*     */ import wt.org.WTPrincipalReference;
/*     */ import wt.project.Role;
/*     */ import wt.team.Team;
/*     */ import wt.util.WTException;
/*     */ import wt.workflow.definer.WfAssignedActivityTemplate;
/*     */ import wt.workflow.definer.WfTemplateObject;
/*     */ import wt.workflow.definer.WfTemplateObjectReference;
/*     */ import wt.workflow.work.WfActorRoleAssignee;
/*     */ import wt.workflow.work.WfAssignedActivity;
/*     */ import wt.workflow.work.WfPrincipalAssignee;
/*     */ import wt.workflow.work.WfRoleAssignee;
/*     */ 
/*     */ public class WorkflowHelper
/*     */ {
/*  25 */   static final Logger logger = setupLogging("ext.starkey.workflow.WorkflowHelper");
/*     */ 
/*     */   
/*     */   private static Logger setupLogging(String paramString) {
/*  29 */     Logger logger = LogR.getLogger(paramString);
/*  30 */     logger.setLevel(Level.toLevel("ERROR"));
/*  31 */     return logger;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ArrayList<Role> getAllApproverRoles() {
/*  40 */     ArrayList<Role> arrayList = new ArrayList();
/*  41 */     arrayList.add(Role.toRole("ADDITIONAL_APPROVER"));
/*  42 */     arrayList.add(Role.toRole("CHANGE_ADMINISTRATOR"));
/*  43 */     arrayList.add(Role.toRole("CLINICAL_PRODUCT_RESEARCH"));
/*  44 */     arrayList.add(Role.toRole("COMPONENT_ENGINEERING"));
/*  45 */     arrayList.add(Role.toRole("CUSTOMER_SERVICE"));
/*  46 */     arrayList.add(Role.toRole("DESIGN_FOR_MANUFACTURING"));
/*  47 */     arrayList.add(Role.toRole("EA_ENGINEERING"));
/*  48 */     arrayList.add(Role.toRole("EA_SUPPORT"));
/*  49 */     arrayList.add(Role.toRole("ENGINEERING_CHINA"));
/*  50 */     arrayList.add(Role.toRole("FIRMWARE_ENGINEERING"));
/*  51 */     arrayList.add(Role.toRole("FLEX_CIRCUIT_ENGINEERING"));
/*  52 */     arrayList.add(Role.toRole("INJECTION_MOLD_LAB"));
/*  53 */     arrayList.add(Role.toRole("MANUFACTURING_FACILITY_TRAINER"));
/*  54 */     arrayList.add(Role.toRole("MANUFACTURING_SUPPORT"));
/*  55 */     arrayList.add(Role.toRole("MARKETING"));
/*  56 */     arrayList.add(Role.toRole("MATERIALS_MANAGEMENT"));
/*  57 */     arrayList.add(Role.toRole("MECHANICAL_ENGINEERING"));
/*  58 */     arrayList.add(Role.toRole("MICROELECTRONIC_DESIGN_MED"));
/*  59 */     arrayList.add(Role.toRole("MICROELECTRONIC_PACKAGING_MEP"));
/*  60 */     arrayList.add(Role.toRole("MODELING_EARMOLD"));
/*  61 */     arrayList.add(Role.toRole("NEW_PRODUCT_INTRODUCTION"));
/*  62 */     arrayList.add(Role.toRole("PROCESS_ENGINEERING"));
/*  63 */     arrayList.add(Role.toRole("PRODUCT_MANAGEMENT"));
/*  64 */     arrayList.add(Role.toRole("PRODUCTION_MANAGEMENT"));
/*  65 */     arrayList.add(Role.toRole("PROGRAM_MANAGER"));
/*  66 */     arrayList.add(Role.toRole("PROJECT_MANAGER"));
/*  67 */     arrayList.add(Role.toRole("QUALITY_ENGINEERING"));
/*  68 */     arrayList.add(Role.toRole("REGULATORY"));
/*  69 */     arrayList.add(Role.toRole("SALES"));
/*  70 */     arrayList.add(Role.toRole("SHIPPING_RECEIVING"));
/*  71 */     arrayList.add(Role.toRole("SOFTWARE_TESTING"));
/*  72 */     arrayList.add(Role.toRole("SYSTEMS_ENGINEERING"));
/*  73 */     arrayList.add(Role.toRole("TECHNICAL_DOCUMENTATION"));
/*  74 */     arrayList.add(Role.toRole("TEST_ENGINEERING"));
/*  75 */     arrayList.add(Role.toRole("WAIVERS"));
/*  76 */     arrayList.add(Role.toRole("WIRELESS_DESIGN_ENGINEERING"));
/*  77 */     arrayList.add(Role.toRole("WIRELESS_SYSTEM_ENGINEERING"));
/*  78 */     arrayList.add(Role.toRole("WIRELESS_TEST_ENGINEERING"));
/*  79 */     return arrayList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static WfAssignedActivity setupApproverRoles(WTChangeRequest2 paramWTChangeRequest2, WfAssignedActivity paramWfAssignedActivity) throws WTException {
/*  91 */     logger.debug("-->setupApproverRoles() changeRequest: " + paramWTChangeRequest2.getNumber());
/*  92 */     WfAssignedActivityTemplate wfAssignedActivityTemplate = (WfAssignedActivityTemplate)paramWfAssignedActivity.getTemplate().getObject();
/*     */     
/*  94 */     Enumeration<WfActorRoleAssignee> enumeration = wfAssignedActivityTemplate.getActorRoleAssignees();
/*  95 */     while (enumeration.hasMoreElements()) {
/*     */       
/*  97 */       WfActorRoleAssignee wfActorRoleAssignee = enumeration.nextElement();
/*  98 */       logger.debug("-->removeActorRoleAssignee() wfActorRoleAssignee: " + wfActorRoleAssignee);
/*  99 */       wfAssignedActivityTemplate.removeActorRoleAssignee(wfActorRoleAssignee);
/*     */     } 
/* 101 */     Enumeration enumeration1 = wfAssignedActivityTemplate.getPrincipalAssignees();
/* 102 */     while (enumeration1.hasMoreElements()) {
/*     */       
/* 104 */       WfPrincipalAssignee wfPrincipalAssignee = (WfPrincipalAssignee)enumeration.nextElement();
/* 105 */       logger.debug("-->removePrincipalAssignee() wfPrincipalAssignee: " + wfPrincipalAssignee);
/* 106 */       wfAssignedActivityTemplate.removePrincipalAssignee(wfPrincipalAssignee);
/*     */     } 
/* 108 */     Enumeration enumeration2 = wfAssignedActivityTemplate.getRoleAssignees();
/* 109 */     while (enumeration2.hasMoreElements()) {
/*     */       
/* 111 */       WfRoleAssignee wfRoleAssignee = (WfRoleAssignee)enumeration.nextElement();
/* 112 */       logger.debug("-->removeRoleAssignee() wfRoleAssignee: " + wfRoleAssignee);
/* 113 */       wfAssignedActivityTemplate.removeRoleAssignee(wfRoleAssignee);
/*     */     } 
/*     */     
/* 116 */     ArrayList<Role> arrayList = getAllApproverRoles();
/* 117 */     Team team = (Team)paramWTChangeRequest2.getTeamId().getObject();
/* 118 */     logger.debug("-->setupApproverRoles() requestTeam: " + team.getName());
/* 119 */     for (byte b = 0; b < arrayList.size(); b++) {
/*     */ 
/*     */       
/* 122 */       Role role = arrayList.get(b);
/* 123 */       logger.debug("-->setupApproverRoles() thisRole: " + role);
/* 124 */       if (checkForPrincipals(team, role)) {
/*     */ 
/*     */         
/* 127 */         String str1 = "ALL";
/* 128 */         String str2 = "N:" + str1 + ".0,R:" + role.toString();
/* 129 */         logger.debug("-->addRoleAssignee() wfEncodedRole: " + str2);
/* 130 */         WfRoleAssignee wfRoleAssignee = new WfRoleAssignee(str2);
/*     */         
/*     */         try {
/* 133 */           wfRoleAssignee.setRole(role);
/* 134 */           wfRoleAssignee.setRequired(true);
/*     */         }
/* 136 */         catch (Exception exception) {
/*     */           
/* 138 */           logger.debug("-->addRoleAssignee() exception: " + exception.getMessage());
/*     */         } 
/* 140 */         wfAssignedActivityTemplate.addRoleAssignee(wfRoleAssignee);
/*     */       } 
/*     */     } 
/*     */     
/* 144 */     paramWfAssignedActivity.setTemplate(WfTemplateObjectReference.newWfTemplateObjectReference((WfTemplateObject)wfAssignedActivityTemplate));
/* 145 */     paramWfAssignedActivity = (WfAssignedActivity)PersistenceHelper.manager.save((Persistable)paramWfAssignedActivity);
/* 146 */     return paramWfAssignedActivity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean checkForPrincipals(Team paramTeam, Role paramRole) {
/*     */     Enumeration<WTPrincipalReference> enumeration;
/* 157 */     if (paramTeam == null || paramRole == null) {
/* 158 */       return false;
/*     */     }
/*     */     
/*     */     try {
/* 162 */       enumeration = paramTeam.getPrincipalTarget(paramRole);
/*     */     }
/* 164 */     catch (WTException wTException) {
/*     */       
/* 166 */       wTException.printStackTrace();
/* 167 */       return false;
/*     */     } 
/* 169 */     if (enumeration.hasMoreElements()) {
/*     */       
/* 171 */       WTPrincipalReference wTPrincipalReference = enumeration.nextElement();
/* 172 */       logger.debug("-->principalForRole() principalForRole: " + wTPrincipalReference.getName() + "=true");
/* 173 */       return true;
/*     */     } 
/* 175 */     logger.debug("-->principalForRole() thisRole: " + paramRole + "=false");
/* 176 */     return false;
/*     */   }
/*     */ }
 