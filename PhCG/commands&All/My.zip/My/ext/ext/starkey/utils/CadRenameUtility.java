/*     */ package ext.starkey.utils;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Properties;
/*     */ import java.util.StringTokenizer;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.apache.log4j.PropertyConfigurator;
/*     */ import wt.epm.EPMDocumentHelper;
/*     */ import wt.epm.EPMDocumentMaster;
/*     */ import wt.epm.EPMDocumentMasterIdentity;
/*     */ import wt.fc.IdentificationObject;
/*     */ import wt.fc.Identified;
/*     */ import wt.fc.IdentityHelper;
/*     */ import wt.fc.Persistable;
/*     */ import wt.fc.PersistenceHelper;
/*     */ import wt.fc.QueryResult;
/*     */ import wt.fc.collections.WTKeyedHashMap;
/*     */ import wt.fc.collections.WTKeyedMap;
/*     */ import wt.log4j.LogR;
/*     */ import wt.method.RemoteAccess;
/*     */ import wt.method.RemoteMethodServer;
/*     */ import wt.pds.StatementSpec;
/*     */ import wt.pom.UniquenessException;
/*     */ import wt.query.QueryException;
/*     */ import wt.query.QuerySpec;
/*     */ import wt.query.SearchCondition;
/*     */ import wt.query.WhereExpression;
/*     */ import wt.util.WTException;
/*     */ import wt.util.WTPropertyVetoException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CadRenameUtility
/*     */   implements RemoteAccess
/*     */ {
/*  49 */   private static final String CLASSNAME = CadRenameUtility.class.getName();
/*  50 */   private static final Logger LOGGER = LogR.getLogger(CLASSNAME);
/*     */ 
/*     */   
/*     */   public static void main(String[] paramArrayOfString) {
/*  54 */     configureLogger(null);
/*  55 */     if (paramArrayOfString.length != 1) {
/*     */       
/*  57 */       LOGGER.error("give input file location\nex:\twindchill ext.starkey.utils.CadRenameUtility <fileLocattion>\n");
/*  58 */       System.exit(0);
/*     */     } 
/*  60 */     String str1 = "";
/*  61 */     String str2 = "";
/*  62 */     String str3 = "";
/*  63 */     String str4 = "";
/*  64 */     String str5 = "";
/*  65 */     String str6 = "";
/*  66 */     File file = new File(paramArrayOfString[0]);
/*  67 */     FileInputStream fileInputStream = null;
/*  68 */     BufferedInputStream bufferedInputStream = null;
/*  69 */     DataInputStream dataInputStream = null;
/*     */     try {
/*  71 */       fileInputStream = new FileInputStream(file);
/*  72 */       bufferedInputStream = new BufferedInputStream(fileInputStream);
/*  73 */       dataInputStream = new DataInputStream(bufferedInputStream);
/*  74 */       byte b = 1;
/*     */       try {
/*  76 */         while (dataInputStream.available() != 0) {
/*     */           
/*  78 */           StringTokenizer stringTokenizer = new StringTokenizer(dataInputStream.readLine(), "|");
/*  79 */           if (stringTokenizer.hasMoreTokens()) {
/*     */             
/*  81 */             str1 = stringTokenizer.nextToken();
/*  82 */             str4 = stringTokenizer.nextToken();
/*  83 */             str3 = stringTokenizer.nextToken();
/*  84 */             str6 = stringTokenizer.nextToken();
/*  85 */             str2 = stringTokenizer.nextToken();
/*  86 */             str5 = stringTokenizer.nextToken();
/*     */             try {
/*  88 */               Class[] arrayOfClass = new Class[6];
/*  89 */               arrayOfClass[0] = String.class;
/*  90 */               arrayOfClass[1] = String.class;
/*  91 */               arrayOfClass[2] = String.class;
/*  92 */               arrayOfClass[3] = String.class;
/*  93 */               arrayOfClass[4] = String.class;
/*  94 */               arrayOfClass[5] = String.class;
/*  95 */               Object[] arrayOfObject = new Object[6];
/*  96 */               arrayOfObject[0] = str1;
/*  97 */               arrayOfObject[1] = str4;
/*  98 */               arrayOfObject[2] = str3;
/*  99 */               arrayOfObject[3] = str6;
/* 100 */               arrayOfObject[4] = str2;
/* 101 */               arrayOfObject[5] = str5;
/* 102 */               RemoteMethodServer remoteMethodServer = RemoteMethodServer.getDefault();
/* 103 */               System.out.println("***** Processing item number " + b + " Item Number " + str1);
/* 104 */               b++;
/* 105 */               remoteMethodServer.invoke("rename", CLASSNAME, null, arrayOfClass, arrayOfObject);
/*     */             }
/* 107 */             catch (InvocationTargetException invocationTargetException) {
/*     */ 
/*     */               
/* 110 */               LOGGER.error(invocationTargetException.getMessage());
/* 111 */               invocationTargetException.printStackTrace();
/*     */             } 
/*     */           } 
/*     */         } 
/*     */         
/* 116 */         System.out.println("read");
/* 117 */         fileInputStream.close();
/* 118 */         bufferedInputStream.close();
/* 119 */         dataInputStream.close();
/* 120 */       } catch (IOException iOException) {
/* 121 */         iOException.printStackTrace();
/*     */       }
/*     */     
/* 124 */     } catch (FileNotFoundException fileNotFoundException) {
/* 125 */       fileNotFoundException.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void rename(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6) {
/* 140 */     LOGGER.info("***** Searching " + paramString1);
/*     */     
/*     */     try {
/* 143 */       QuerySpec querySpec = new QuerySpec(EPMDocumentMaster.class);
/* 144 */       SearchCondition searchCondition = new SearchCondition(EPMDocumentMaster.class, "number", "=", paramString1, false);
/* 145 */       querySpec.appendWhere((WhereExpression)searchCondition, new int[] { 0, 1 });
/* 146 */       QueryResult queryResult = PersistenceHelper.manager.find((StatementSpec)querySpec);
/* 147 */       if (queryResult.hasMoreElements()) {
/*     */         
/* 149 */         LOGGER.info("***** " + paramString1 + " is changing");
/* 150 */         EPMDocumentMaster ePMDocumentMaster = (EPMDocumentMaster)queryResult.nextElement();
/* 151 */         EPMDocumentMasterIdentity ePMDocumentMasterIdentity = (EPMDocumentMasterIdentity)ePMDocumentMaster.getIdentificationObject();
/* 152 */         if (!paramString2.equalsIgnoreCase("No Change")) {
/*     */           
/* 154 */           LOGGER.info("***** " + paramString1 + " identified for change");
/* 155 */           ePMDocumentMasterIdentity.setNumber(paramString2);
/* 156 */           if (!paramString6.equalsIgnoreCase("No Change"))
/*     */           {
/* 158 */             ePMDocumentMasterIdentity.setName(paramString6); } 
/*     */           try {
/* 160 */             IdentityHelper.service.changeIdentity((Identified)ePMDocumentMaster, (IdentificationObject)ePMDocumentMasterIdentity);
/* 161 */           } catch (UniquenessException uniquenessException) {
/* 162 */             LOGGER.error("***** " + paramString1 + " cannot be modified as " + paramString2 + " exists");
/*     */           }
/*     */         
/*     */         }
/* 166 */         else if (paramString2.equalsIgnoreCase("No Change")) {
/*     */           
/* 168 */           if (!paramString6.equalsIgnoreCase("No Change")) {
/*     */             
/* 170 */             ePMDocumentMasterIdentity.setName(paramString6);
/* 171 */             IdentityHelper.service.changeIdentity((Identified)ePMDocumentMaster, (IdentificationObject)ePMDocumentMasterIdentity);
/*     */           } 
/*     */         } 
/* 174 */         WTKeyedHashMap wTKeyedHashMap = new WTKeyedHashMap();
/* 175 */         if (!paramString4.equalsIgnoreCase("No Change")) {
/*     */           
/* 177 */           LOGGER.info("***** Trying to change Full Name of " + paramString1);
/* 178 */           ePMDocumentMaster = (EPMDocumentMaster)PersistenceHelper.manager.refresh((Persistable)ePMDocumentMaster);
/* 179 */           wTKeyedHashMap.put((Persistable)ePMDocumentMaster, paramString4);
/*     */           try {
/* 181 */             EPMDocumentHelper.service.changeCADName((WTKeyedMap)wTKeyedHashMap);
/* 182 */             LOGGER.info("***** " + paramString1 + " modofied");
/* 183 */             wTKeyedHashMap.clear();
/* 184 */           } catch (Exception exception) {
/* 185 */             LOGGER.error("***** Cannot Modify File Name for " + paramString1);
/*     */           }
/*     */         
/*     */         } 
/*     */       } else {
/*     */         
/* 191 */         LOGGER.error("***** " + paramString1 + " Not Found");
/*     */       } 
/* 193 */     } catch (QueryException queryException) {
/*     */       
/* 195 */       LOGGER.error("***** " + paramString1 + " cannot be modified " + queryException.getMessage());
/* 196 */       queryException.printStackTrace();
/* 197 */     } catch (WTException wTException) {
/*     */       
/* 199 */       LOGGER.error("***** " + paramString1 + " cannot be modified " + wTException.getMessage());
/* 200 */       wTException.printStackTrace();
/* 201 */     } catch (WTPropertyVetoException wTPropertyVetoException) {
/*     */       
/* 203 */       LOGGER.error("***** " + paramString1 + " cannot be modified " + wTPropertyVetoException.getMessage());
/* 204 */       wTPropertyVetoException.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String configureLogger(String paramString) {
/* 215 */     String str = null;
/* 216 */     if (paramString != null) {
/* 217 */       if (paramString.toUpperCase().endsWith(".LOG")) {
/* 218 */         str = paramString.substring(0, paramString.lastIndexOf(".")) + "-" + getDate() + ".log";
/*     */       } else {
/* 220 */         str = paramString + "-" + getDate() + ".log";
/*     */       } 
/*     */     } else {
/* 223 */       File file = new File("logs");
/* 224 */       str = file.getAbsolutePath() + File.separator + "CadRename-" + getDate() + ".log";
/*     */     } 
/*     */ 
/*     */     
/* 228 */     Properties properties = new Properties();
/*     */ 
/*     */     
/* 231 */     properties.setProperty("log4j.logger.CadRename.logger", "ALL,toolLogFile");
/*     */     
/* 233 */     properties.setProperty("log4j.appender.toolLogFile.file", str);
/* 234 */     properties.setProperty("log4j.appender.toolLogFile", "wt.log4j.jmx.DailyRollingFileAppender");
/* 235 */     properties.setProperty("log4j.appender.toolLogFile.DatePattern", "'.'yyyy-MM-dd");
/* 236 */     properties.setProperty("log4j.appender.toolLogFile.layout", "org.apache.log4j.PatternLayout");
/* 237 */     properties.setProperty("log4j.appender.toolLogFile.layout.ConversionPattern", "%d{ISO8601} %-5p [%t] %c %X{user} - %m%n");
/* 238 */     properties.setProperty("log4j.appender.toolLogFile.filter.a", "org.apache.log4j.varia.LevelMatchFilter");
/* 239 */     properties.setProperty("log4j.appender.toolLogFile.filter.a.LevelToMatch", "ALL");
/* 240 */     properties.setProperty("log4j.appender.toolLogFile.filter.a.AcceptOnMatch", "true");
/*     */     
/* 242 */     PropertyConfigurator.configure(properties);
/*     */ 
/*     */     
/* 245 */     return str;
/*     */   }
/*     */   public static String getDate() {
/* 248 */     SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
/* 249 */     Date date = new Date();
/* 250 */     return simpleDateFormat.format(date);
/*     */   }
/*     */ }


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\starke\\utils\CadRenameUtility.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */