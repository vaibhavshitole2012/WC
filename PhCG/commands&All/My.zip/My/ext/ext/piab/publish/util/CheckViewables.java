/*     */ package ext.piab.publish.util;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import wt.content.ApplicationData;
/*     */ import wt.content.ContentHelper;
/*     */ import wt.content.ContentHolder;
/*     */ import wt.content.ContentRoleType;
/*     */ import wt.doc.WTDocument;
/*     */ import wt.epm.EPMDocument;
/*     */ import wt.fc.QueryResult;
/*     */ import wt.fc.WTObject;
/*     */ import wt.vc.Iterated;
/*     */ import wt.vc.VersionControlHelper;
/*     */ import wt.vc.Versioned;
/*     */ 
/*     */ 
/*     */ public class CheckViewables
/*     */ {
/*     */   private static final boolean VERBOSE = true;
/*     */   
/*     */   public static String checkForViewables(ArrayList<WTObject> items) {
/*  23 */     System.out.println("***CheckViewables.checkForViewables()");
/*  24 */     StringBuilder sb = new StringBuilder();
/*  25 */     int count = 0, epmCount = 0; try {
/*     */       int i;
/*  27 */       for (i = 0; i < items.size(); i++) {
/*  28 */         WTObject wto = items.get(i);
/*  29 */         if (wto instanceof WTDocument) {
/*  30 */           ApplicationData appData = null;
/*  31 */           Date secModDate = new Date();
/*  32 */           WTDocument wtd = (WTDocument)wto;
/*  33 */           System.out.println("Object is an instance of WTDocument : " + wtd.getNumber());
/*  34 */           Date wtdModDate = wtd.getModifyTimestamp();
/*  35 */           QueryResult qr = ContentHelper.service.getContentsByRole((ContentHolder)wtd, ContentRoleType.SECONDARY);
/*  36 */           while (qr.hasMoreElements()) {
/*  37 */             appData = (ApplicationData)qr.nextElement();
/*  38 */             secModDate = appData.getModifyTimestamp();
/*     */           } 
/*  40 */           if (appData != null) {
/*  41 */             if (wtdModDate.after(secModDate)) {
/*  42 */               System.out.println("Not a latest viewable");
/*  43 */               sb.append("[ " + wtd.getNumber() + " ] ");
/*     */             } else {
/*     */               
/*  46 */               System.out.println("Is a latest Viewable");
/*     */             } 
/*     */           } else {
/*     */             
/*  50 */             sb.append("[ " + wtd.getNumber() + " ] ");
/*  51 */             System.out.println("Does not have a Viewable");
/*     */           }
/*     */         
/*  54 */         } else if (wto instanceof EPMDocument) {
/*  55 */           ApplicationData appData = null;
/*  56 */           Date secModDate = new Date();
/*  57 */           EPMDocument epm = (EPMDocument)wto;
/*  58 */           String type = epm.getDocType().toString();
/*  59 */           System.out.println("Type : " + type + "Version " + VersionControlHelper.getVersionIdentifier((Versioned)epm).getValue() + "." + VersionControlHelper.getIterationIdentifier((Iterated)epm).getValue());
/*  60 */           if (type.equalsIgnoreCase("CADDRAWING")) {
/*  61 */             System.out.println("Object is an instance of EPMDocument : " + epm.getNumber());
/*  62 */             Date wtdModDate = epm.getModifyTimestamp();
/*  63 */             QueryResult qr = ContentHelper.service.getContentsByRole((ContentHolder)epm, ContentRoleType.SECONDARY);
/*  64 */             while (qr.hasMoreElements()) {
/*  65 */               appData = (ApplicationData)qr.nextElement();
/*  66 */               secModDate = appData.getModifyTimestamp();
/*     */             } 
/*  68 */             if (appData != null) {
/*  69 */               if (wtdModDate.after(secModDate)) {
/*  70 */                 System.out.println("Not a latest viewable");
/*  71 */                 sb.append("[ " + epm.getNumber() + " ] ");
/*     */               } else {
/*     */                 
/*  74 */                 System.out.println("Is a latest Viewable");
/*     */               } 
/*     */             } else {
/*     */               
/*  78 */               System.out.println("Does not have a Viewable");
/*  79 */               sb.append("[ " + epm.getNumber() + " ] ");
/*     */             } 
/*     */           } else {
/*     */             
/*  83 */             System.out.println("Object is not of type CAD Drawing");
/*  84 */             epmCount++;
/*     */           }
/*     */         
/*  87 */         } else if (wto instanceof wt.part.WTPart) {
/*  88 */           System.out.println("Object is neither instance of an WTDocument nor EPMDocument..");
/*  89 */           count++;
/*     */         } 
/*     */       } 
/*  92 */       i = i--;
/*  93 */       String message = sb.toString();
/*  94 */       if (!message.isEmpty()) {
/*  95 */         System.out.println("The items " + message + " dosen't have the viewables up to date ");
/*  96 */         String msg = "Viewables for Items " + message + " may be out of date or not available";
/*  97 */         return msg;
/*     */       } 
/*     */       
/* 100 */       if (count == i || epmCount == i) {
/* 101 */         System.out.println("Items are instances of neither WTDocuments nor CAD Drawings");
/* 102 */         return sb.toString();
/*     */       } 
/*     */ 
/*     */       
/* 106 */       return sb.toString();
/*     */ 
/*     */     
/*     */     }
/* 110 */     catch (Exception ex) {
/* 111 */       ex.printStackTrace();
/* 112 */       return ex.getLocalizedMessage();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\publis\\util\CheckViewables.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */