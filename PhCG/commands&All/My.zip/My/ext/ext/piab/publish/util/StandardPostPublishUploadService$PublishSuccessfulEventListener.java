/*     */ package ext.piab.publish.util;
/*     */ 
/*     */ import wt.doc.WTDocument;
/*     */ import wt.epm.EPMDocument;
/*     */ import wt.events.KeyedEvent;
/*     */ import wt.services.ServiceEventListenerAdapter;
/*     */ import wt.util.WTException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PublishSuccessfulEventListener
/*     */   extends ServiceEventListenerAdapter
/*     */ {
/*     */   public PublishSuccessfulEventListener(String manager_name) {
/* 249 */     super(manager_name);
/* 250 */     if (StandardPostPublishUploadService.access$000()) {
/* 251 */       System.out.println("####### PublishSuccessfulEventListener.PublishSuccessfulEventListener()..");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void notifyVetoableEvent(Object event) throws WTException {
/* 258 */     if (!(event instanceof KeyedEvent)) {
/*     */       return;
/*     */     }
/* 261 */     KeyedEvent keyedEvent = (KeyedEvent)event;
/*     */     
/* 263 */     if (StandardPostPublishUploadService.access$000()) {
/* 264 */       System.out.println("####### PublishSuccessfulEventListener.notifyVetoableEvent() :: Event Type : " + keyedEvent
/* 265 */           .getEventType());
/*     */     }
/*     */     
/* 268 */     Object target = keyedEvent.getEventTarget();
/* 269 */     if (target instanceof EPMDocument) {
/* 270 */       if (keyedEvent.getEventType().equals("PUBLISH_SUCCESSFUL")) {
/* 271 */         StandardPostPublishUploadService.this.processPublishSuccessfulEvent((EPMDocument)target);
/*     */       }
/* 273 */     } else if (target instanceof WTDocument) {
/* 274 */       if (keyedEvent.getEventType().equals("PUBLISH_SUCCESSFUL")) {
/* 275 */         StandardPostPublishUploadService.this.processPublishSuccessfulEvent((WTDocument)target);
/*     */       }
/*     */     }
/* 278 */     else if (StandardPostPublishUploadService.access$000()) {
/* 279 */       System.out.println("####### " + StandardPostPublishUploadService.access$100() + ".processPublishSuccessfulEvent() :: Target Object is not instance of  either EPMDocument or WTDocument");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\publis\\util\StandardPostPublishUploadService$PublishSuccessfulEventListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */