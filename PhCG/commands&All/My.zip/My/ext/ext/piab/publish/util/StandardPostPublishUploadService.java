/*     */ package ext.piab.publish.util;
/*     */ 
/*     */ import com.ptc.wvs.server.publish.PublishServiceEvent;
/*     */ import ext.piab.common.util.PropertyforPIAB;
/*     */ import ext.piab.quality.util.QualityHelper;
/*     */ import ext.piab.quality.util.UpdateContent;
/*     */ import java.io.File;
/*     */ import java.io.Serializable;
/*     */ import java.util.Vector;
/*     */ import wt.content.ApplicationData;
/*     */ import wt.content.ContentHelper;
/*     */ import wt.content.ContentHolder;
/*     */ import wt.content.ContentRoleType;
/*     */ import wt.content.ContentServerHelper;
/*     */ import wt.doc.WTDocument;
/*     */ import wt.epm.EPMDocument;
/*     */ import wt.events.KeyedEvent;
/*     */ import wt.events.KeyedEventListener;
/*     */ import wt.fc.Persistable;
/*     */ import wt.fc.PersistenceServerHelper;
/*     */ import wt.iba.value.IBAHolder;
/*     */ import wt.representation.Representable;
/*     */ import wt.representation.Representation;
/*     */ import wt.representation.StandardRepresentationService;
/*     */ import wt.services.ManagerException;
/*     */ import wt.services.ServiceEventListenerAdapter;
/*     */ import wt.services.StandardManager;
/*     */ import wt.util.WTException;
/*     */ import wt.util.WTProperties;
/*     */ import wt.viewmarkup.Viewable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardPostPublishUploadService
/*     */   extends StandardManager
/*     */   implements PostPublishUploadService, Serializable
/*     */ {
/*  53 */   private static final String CLASSNAME = StandardPostPublishUploadService.class.getName();
/*     */   private static boolean VERBOSE;
/*  55 */   protected static WTProperties wtProps = null;
/*  56 */   private static String wc_home = PropertyforPIAB.WT_HOME;
/*  57 */   private static String PDF_URL_IBA_NAME = PropertyforPIAB.PDF_URL_IBA_NAME;
/*  58 */   private static final String TEMP_DIR = PropertyforPIAB.TEMP_DIR;
/*  59 */   private static final boolean DEL_TEMP = PropertyforPIAB.DEL_TEMP;
/*     */   private KeyedEventListener listener;
/*     */   private KeyedEventListener listener1;
/*     */   
/*     */   public String getConceptualClassname() {
/*  64 */     return CLASSNAME;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static StandardPostPublishUploadService newStandardPostPublishUploadService() throws WTException {
/*  70 */     if (VERBOSE) {
/*  71 */       System.out.println("####### " + CLASSNAME + ".newStandardPostPublishUploadService()..");
/*     */     }
/*     */     
/*  74 */     StandardPostPublishUploadService instance = new StandardPostPublishUploadService();
/*  75 */     instance.initialize();
/*  76 */     return instance;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void performStartupProcess() throws ManagerException {
/*  81 */     if (VERBOSE) {
/*  82 */       System.out.println("####### " + CLASSNAME + ".performStartupProcess()..");
/*     */     }
/*     */     
/*  85 */     this.listener = (KeyedEventListener)new PublishSuccessfulEventListener(getConceptualClassname());
/*  86 */     getManagerService().addEventListener(this.listener, 
/*  87 */         PublishServiceEvent.generateEventKey("PUBLISH_SUCCESSFUL"));
/*     */     
/*  89 */     System.out.println("Upload Published PDF Service started..");
/*     */   }
/*     */ 
/*     */   
/*     */   public void processPublishSuccessfulEvent(WTDocument document) {
/*  94 */     if (VERBOSE) {
/*  95 */       System.out.println("####### WTDocument ####### " + CLASSNAME + ".processPublishSuccessfulEvent()..");
/*     */     }
/*     */     
/*  98 */     String docNumber = document.getNumber();
/*     */     
/*     */     try {
/* 101 */       File tempDir = QualityHelper.createDirectory(TEMP_DIR);
/* 102 */       String absoluteTempDirPath = tempDir.getAbsolutePath();
/* 103 */       System.out.println("Temp directory path for the file location: " + absoluteTempDirPath);
/*     */       
/* 105 */       Vector<String> pdflocations = getPDFs((Representable)document, absoluteTempDirPath);
/* 106 */       for (int i = 0; i < pdflocations.size(); i++) {
/* 107 */         String pdflocation = pdflocations.elementAt(i);
/* 108 */         File theFile = new File(pdflocation);
/* 109 */         System.out.println("####### Processing.. " + theFile.getName() + " for Document " + docNumber);
/* 110 */         theFile = PDFUtilDocumentWorker.processPdf(theFile, document);
/*     */         
/* 112 */         theFile.delete();
/* 113 */         System.out.println("####### Successfully uploaded published PDF " + theFile.getName() + " for Document " + docNumber);
/*     */         
/* 115 */         theFile = null;
/*     */       } 
/* 117 */       if (DEL_TEMP) QualityHelper.removeDirectory(tempDir); 
/* 118 */     } catch (Exception e) {
/* 119 */       System.out.println("####### Error: Uploding published PDF for Document " + docNumber);
/* 120 */       System.out.println("####### Error: " + e.getLocalizedMessage());
/* 121 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void processPublishSuccessfulEvent(EPMDocument epmdocument) {
/* 129 */     if (VERBOSE) {
/* 130 */       System.out.println("####### CADDocument ####### " + CLASSNAME + ".processPublishSuccessfulEvent()..");
/*     */     }
/*     */     
/* 133 */     String epmDocVer = null;
/* 134 */     String epmDocIteration = null;
/* 135 */     String epmDocNumber = epmdocument.getNumber();
/*     */ 
/*     */     
/*     */     try {
/* 139 */       File tempDir = QualityHelper.createDirectory(TEMP_DIR);
/* 140 */       String absoluteTempDirPath = tempDir.getAbsolutePath();
/* 141 */       System.out.println("Temp directory path for the file location: " + absoluteTempDirPath);
/*     */       
/* 143 */       ContentHolder contentholder1 = ContentHelper.service.getContents((ContentHolder)epmdocument);
/* 144 */       Vector<ApplicationData> vector2 = ContentHelper.getContentList(contentholder1);
/* 145 */       String conversionType = "PublishedDXF";
/*     */       
/* 147 */       if (VERBOSE) {
/* 148 */         System.out.println("####### " + CLASSNAME + ".processPublishSuccessfulEvent() :: No. of attachments found : " + vector2
/* 149 */             .size());
/*     */       }
/*     */       
/* 152 */       ApplicationData appDataforcategory = null;
/* 153 */       for (int i = 0; i < vector2.size(); i++) {
/* 154 */         appDataforcategory = vector2.elementAt(i);
/* 155 */         ContentRoleType appRole = appDataforcategory.getRole();
/* 156 */         String category = appDataforcategory.getCategory();
/*     */         
/* 158 */         if (VERBOSE) {
/* 159 */           System.out.println("####### " + CLASSNAME + ".processPublishSuccessfulEvent() :: Application data Category : " + category + " :: Role : " + appRole);
/*     */         }
/*     */ 
/*     */         
/* 163 */         if (appRole.toString().equals("SECONDARY") && category != null && category.equals(conversionType)) {
/* 164 */           if (VERBOSE) {
/* 165 */             System.out.println("####### " + CLASSNAME + ".processPublishSuccessfulEvent() :: Removing existing published PDF..");
/*     */           }
/* 167 */           PersistenceServerHelper.manager.remove((Persistable)appDataforcategory);
/*     */         } 
/*     */       } 
/* 170 */       Vector<String> pdflocations = getPDFs((Representable)epmdocument, absoluteTempDirPath);
/* 171 */       for (int j = 0; j < pdflocations.size(); j++) {
/* 172 */         String pdflocation = pdflocations.elementAt(j);
/* 173 */         File pdfFile = new File(pdflocation);
/* 174 */         System.out.println("####### Processing.. " + pdfFile.getName() + " for EPMDocument " + epmDocNumber);
/* 175 */         if (pdfFile.exists() && pdfFile.canWrite()) {
/* 176 */           ApplicationData appdata = UpdateContent.uploadCADDocumentContent(pdfFile, (ContentHolder)epmdocument, false);
/* 177 */           String pdfRedirectUrl = UpdateContent.genDownloadHREF((ContentHolder)epmdocument, appdata);
/* 178 */           if (VERBOSE) System.out.println("*** PDF secondary file redirect URL: " + pdfRedirectUrl); 
/* 179 */           String urlLabel = epmDocNumber + ".PDF";
/* 180 */           UpdateContent.updatePdfUrl((IBAHolder)epmdocument, pdfRedirectUrl, urlLabel, PDF_URL_IBA_NAME);
/*     */         } 
/* 182 */         pdfFile.delete();
/* 183 */         System.out.println("####### Successfully uploaded published PDF " + pdfFile.getName() + " for EPMDocument " + epmDocNumber);
/* 184 */         pdfFile = null;
/*     */       } 
/* 186 */       if (DEL_TEMP) QualityHelper.removeDirectory(tempDir); 
/* 187 */     } catch (Exception e) {
/* 188 */       System.out.println("####### Error: Uploding published PDF for EPMDocument " + epmDocNumber);
/* 189 */       System.out.println("####### Error: " + e.getLocalizedMessage());
/* 190 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector getPDFs(Representable representable, String absoluteTempDirPath) throws Exception {
/* 197 */     if (VERBOSE) {
/* 198 */       System.out.println("####### " + CLASSNAME + ".getDXFs()..");
/*     */     }
/*     */     
/* 201 */     Vector<String> pdfFileNameLocations = new Vector();
/* 202 */     String pdfFileName = null;
/* 203 */     StandardRepresentationService standardrepresentationservice = StandardRepresentationService.newStandardRepresentationService();
/* 204 */     Representation representation = standardrepresentationservice.getDefaultRepresentation(representable);
/*     */     
/* 206 */     if (representation == null) {
/* 207 */       System.out.println("Representation not found..");
/* 208 */       return pdfFileNameLocations;
/*     */     } 
/*     */     
/* 211 */     Viewable viewable = (Viewable)representation;
/* 212 */     ContentHolder contentholder1 = ContentHelper.service.getContents((ContentHolder)viewable);
/* 213 */     Vector<ApplicationData> vector2 = ContentHelper.getContentList(contentholder1);
/* 214 */     boolean pdfFound = false;
/* 215 */     for (int i = 0; i < vector2.size(); i++) {
/* 216 */       ApplicationData applicationdata = vector2.elementAt(i);
/* 217 */       String appDataFileName = applicationdata.getFileName();
/* 218 */       String conversionFormat = ".pdf";
/*     */       
/* 220 */       if (VERBOSE) {
/* 221 */         System.out.println("####### " + CLASSNAME + ".getPDFs() :: appDataFileName : " + appDataFileName);
/*     */       }
/*     */       
/* 224 */       if (appDataFileName.endsWith(conversionFormat)) {
/* 225 */         pdfFileName = absoluteTempDirPath + "/" + appDataFileName;
/* 226 */         if (VERBOSE) {
/* 227 */           System.out.println("####### " + CLASSNAME + ".getDXFs() :: File to be attached : " + pdfFileName);
/*     */         }
/* 229 */         pdfFileNameLocations.add(pdfFileName);
/* 230 */         ContentServerHelper.service.writeContentStream(applicationdata, pdfFileName);
/* 231 */         pdfFound = true;
/*     */       } 
/*     */     } 
/*     */     
/* 235 */     if (!pdfFound) {
/* 236 */       System.out.println("PDF does not exist for this CAD Document..");
/*     */     }
/* 238 */     if (VERBOSE) {
/* 239 */       System.out.println("####### " + CLASSNAME + ".getPDFs() :: number of files : " + pdfFileNameLocations.size());
/*     */     }
/* 241 */     return pdfFileNameLocations;
/*     */   }
/*     */ 
/*     */   
/*     */   class PublishSuccessfulEventListener
/*     */     extends ServiceEventListenerAdapter
/*     */   {
/*     */     public PublishSuccessfulEventListener(String manager_name) {
/* 249 */       super(manager_name);
/* 250 */       if (StandardPostPublishUploadService.VERBOSE) {
/* 251 */         System.out.println("####### PublishSuccessfulEventListener.PublishSuccessfulEventListener()..");
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void notifyVetoableEvent(Object event) throws WTException {
/* 258 */       if (!(event instanceof KeyedEvent)) {
/*     */         return;
/*     */       }
/* 261 */       KeyedEvent keyedEvent = (KeyedEvent)event;
/*     */       
/* 263 */       if (StandardPostPublishUploadService.VERBOSE) {
/* 264 */         System.out.println("####### PublishSuccessfulEventListener.notifyVetoableEvent() :: Event Type : " + keyedEvent
/* 265 */             .getEventType());
/*     */       }
/*     */       
/* 268 */       Object target = keyedEvent.getEventTarget();
/* 269 */       if (target instanceof EPMDocument) {
/* 270 */         if (keyedEvent.getEventType().equals("PUBLISH_SUCCESSFUL")) {
/* 271 */           StandardPostPublishUploadService.this.processPublishSuccessfulEvent((EPMDocument)target);
/*     */         }
/* 273 */       } else if (target instanceof WTDocument) {
/* 274 */         if (keyedEvent.getEventType().equals("PUBLISH_SUCCESSFUL")) {
/* 275 */           StandardPostPublishUploadService.this.processPublishSuccessfulEvent((WTDocument)target);
/*     */         }
/*     */       }
/* 278 */       else if (StandardPostPublishUploadService.VERBOSE) {
/* 279 */         System.out.println("####### " + StandardPostPublishUploadService.CLASSNAME + ".processPublishSuccessfulEvent() :: Target Object is not instance of  either EPMDocument or WTDocument");
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*     */     try {
/* 288 */       wtProps = WTProperties.getLocalProperties();
/* 289 */       VERBOSE = wtProps.getProperty("ext.piab.pubevent.PostPublishUploadService.Verbose", false);
/*     */     }
/* 291 */     catch (Exception e) {
/* 292 */       System.out.println("####### " + CLASSNAME + " :: Error reading property file.");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\publis\\util\StandardPostPublishUploadService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */