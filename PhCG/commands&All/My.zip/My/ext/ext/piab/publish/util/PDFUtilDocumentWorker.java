/*     */ package ext.piab.publish.util;
/*     */ 
/*     */ import com.itextpdf.text.BaseColor;
/*     */ import com.itextpdf.text.Font;
/*     */ import com.itextpdf.text.FontFactory;
/*     */ import com.itextpdf.text.Phrase;
/*     */ import com.itextpdf.text.Rectangle;
/*     */ import com.itextpdf.text.pdf.BaseFont;
/*     */ import com.itextpdf.text.pdf.PdfContentByte;
/*     */ import com.itextpdf.text.pdf.PdfGState;
/*     */ import com.itextpdf.text.pdf.PdfPCell;
/*     */ import com.itextpdf.text.pdf.PdfPTable;
/*     */ import com.itextpdf.text.pdf.PdfReader;
/*     */ import com.itextpdf.text.pdf.PdfStamper;
/*     */ import ext.piab.common.util.PropertyforPIAB;
/*     */ import ext.piab.quality.resource.QualityResource;
/*     */ import ext.piab.quality.util.UpdateContent;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.util.ArrayList;
/*     */ import wt.content.ApplicationData;
/*     */ import wt.content.ContentHelper;
/*     */ import wt.content.ContentHolder;
/*     */ import wt.content.ContentRoleType;
/*     */ import wt.doc.WTDocument;
/*     */ import wt.fc.QueryResult;
/*     */ import wt.iba.value.IBAHolder;
/*     */ import wt.util.WTException;
/*     */ import wt.util.WTMessage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PDFUtilDocumentWorker
/*     */ {
/*  46 */   private static final boolean VERBOSE = PropertyforPIAB.VERBOSE;
/*  47 */   private static final float PDF_TABLE_PORTRAIT_Y = PropertyforPIAB.PDF_TABLE_PORTRAIT_Y;
/*  48 */   private static final float PDF_TABLE_PORTRAIT_X = PropertyforPIAB.PDF_TABLE_PORTRAIT_X;
/*  49 */   private static final float PDF_TABLE_LANDSCAPE_X = PropertyforPIAB.PDF_TABLE_LANDSCAPE_X;
/*  50 */   private static final float PDF_TABLE_LANDSCAPE_Y = PropertyforPIAB.PDF_TABLE_LANDSCAPE_Y;
/*  51 */   private static final String DOC_TO_PDF_SCRIPT = PropertyforPIAB.DOC_TO_PDF_SCRIPT;
/*  52 */   private static final String WT_HOME = PropertyforPIAB.WT_HOME;
/*  53 */   private static final String TEMP_DIR = PropertyforPIAB.TEMP_DIR;
/*  54 */   private static final boolean DEL_TEMP = PropertyforPIAB.DEL_TEMP;
/*     */   private static final int SLEEP_INTERVAL = 1000;
/*  56 */   private static final int MAX_PS_GEN = PropertyforPIAB.MAX_PS_GEN;
/*  57 */   private static final String PDF_URL_IBA_NAME = PropertyforPIAB.PDF_URL_IBA_NAME;
/*  58 */   private static final String QUALITY_RESOURCE = QualityResource.class.getName();
/*     */   
/*  60 */   private static String PDF_TITLE = WTMessage.getLocalizedMessage(QUALITY_RESOURCE, "6");
/*  61 */   private static String PDF_DOC_NUM = WTMessage.getLocalizedMessage(QUALITY_RESOURCE, "7");
/*  62 */   private static String PDF_RELEASE_LEVEL = WTMessage.getLocalizedMessage(QUALITY_RESOURCE, "8");
/*  63 */   private static String PDF_REVISION = WTMessage.getLocalizedMessage(QUALITY_RESOURCE, "9");
/*     */ 
/*     */ 
/*     */   
/*     */   private static File addWatermark(File pdfFile, WTDocument wtDoc) throws Exception {
/*  68 */     if (VERBOSE) System.out.println("PDFUtil.addWatermark()"); 
/*  69 */     String pdfPath = pdfFile.getAbsolutePath();
/*  70 */     boolean portrait = true;
/*     */     
/*  72 */     if (VERBOSE && 
/*  73 */       VERBOSE) System.out.println("Processing PDF file: " + pdfPath);
/*     */     
/*  75 */     FileInputStream is = new FileInputStream(pdfFile);
/*  76 */     PdfReader reader = new PdfReader(is);
/*  77 */     int n = reader.getNumberOfPages();
/*  78 */     FileOutputStream outStream = new FileOutputStream(pdfFile);
/*  79 */     PdfStamper stamp = new PdfStamper(reader, outStream);
/*  80 */     BaseFont bf = BaseFont.createFont("Helvetica", "Cp1252", true);
/*  81 */     Font font = FontFactory.getFont("Courier");
/*  82 */     font.setStyle(1);
/*  83 */     font.setColor(BaseColor.BLACK);
/*  84 */     bf = font.getBaseFont();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  89 */     int i = 0;
/*  90 */     while (i < n) {
/*  91 */       i++;
/*  92 */       Rectangle pageSize = reader.getPageSize(i);
/*  93 */       float y = pageSize.getHeight();
/*  94 */       float x = pageSize.getWidth();
/*  95 */       if (VERBOSE) System.out.println("*** Page size: Width-X:" + x + "\t Height-Y:" + y); 
/*  96 */       if (VERBOSE) System.out.println("***Page size: getRotation:" + pageSize.getRotation() + "\tY:" + pageSize);
/*     */       
/*  98 */       if (x > y) {
/*  99 */         portrait = false;
/*     */       } else {
/* 101 */         portrait = true;
/*     */       } 
/* 103 */       PdfContentByte under = stamp.getUnderContent(i);
/* 104 */       PdfGState gstate = new PdfGState();
/* 105 */       gstate.setFillOpacity(1.0F);
/* 106 */       gstate.setStrokeOpacity(1.0F);
/* 107 */       under.saveState();
/* 108 */       under.setGState(gstate);
/* 109 */       under.beginText();
/* 110 */       under.setTextMatrix(40.0F, 40.0F);
/* 111 */       under.setFontAndSize(bf, 11.0F);
/*     */       
/* 113 */       PdfPTable table = new PdfPTable(4);
/* 114 */       PdfPCell title = new PdfPCell(new Phrase(PDF_TITLE));
/* 115 */       PdfPCell documentDesc = new PdfPCell(new Phrase(PDF_DOC_NUM));
/* 116 */       PdfPCell releaseLevelDesc = new PdfPCell(new Phrase(PDF_RELEASE_LEVEL));
/* 117 */       if (portrait) {
/* 118 */         table.setTotalWidth(418.5F);
/* 119 */         releaseLevelDesc.setMinimumHeight(20.0F);
/*     */       } else {
/* 121 */         table.setTotalWidth(419.5F);
/* 122 */         title.setMinimumHeight(18.0F);
/* 123 */         documentDesc.setMinimumHeight(18.0F);
/* 124 */         releaseLevelDesc.setMinimumHeight(18.0F);
/*     */       } 
/* 126 */       title.setColspan(1);
/* 127 */       table.addCell(title);
/* 128 */       PdfPCell titleValue = new PdfPCell(new Phrase(wtDoc.getName()));
/* 129 */       titleValue.setColspan(3);
/* 130 */       table.addCell(titleValue);
/*     */       
/* 132 */       documentDesc.setColspan(1);
/* 133 */       table.addCell(documentDesc);
/*     */       
/* 135 */       PdfPCell docNumber = new PdfPCell(new Phrase(wtDoc.getNumber()));
/* 136 */       docNumber.setColspan(1);
/* 137 */       table.addCell(docNumber);
/*     */       
/* 139 */       PdfPCell revisionDesc = new PdfPCell(new Phrase(PDF_REVISION));
/* 140 */       revisionDesc.setColspan(1);
/* 141 */       revisionDesc.setHorizontalAlignment(2);
/* 142 */       table.addCell(revisionDesc);
/* 143 */       PdfPCell revision = new PdfPCell(new Phrase(wtDoc.getVersionIdentifier().getValue() + "." + wtDoc.getIterationIdentifier().getValue()));
/* 144 */       revision.setColspan(1);
/* 145 */       table.addCell(revision);
/*     */       
/* 147 */       releaseLevelDesc.setColspan(1);
/* 148 */       table.addCell(releaseLevelDesc);
/* 149 */       PdfPCell releaseLevel = new PdfPCell(new Phrase(wtDoc.getLifeCycleState().getDisplay()));
/* 150 */       releaseLevel.setColspan(3);
/* 151 */       table.addCell(releaseLevel);
/* 152 */       if (portrait) {
/* 153 */         table.writeSelectedRows(0, -1, PDF_TABLE_PORTRAIT_X, PDF_TABLE_PORTRAIT_Y, stamp.getUnderContent(i));
/*     */       } else {
/* 155 */         table.writeSelectedRows(0, -1, PDF_TABLE_LANDSCAPE_X, PDF_TABLE_LANDSCAPE_Y, stamp.getUnderContent(i));
/*     */       } 
/* 157 */       under.endText();
/* 158 */       under.restoreState();
/* 159 */       if (VERBOSE) System.out.println("*** :Content Added"); 
/*     */     } 
/* 161 */     stamp.close();
/* 162 */     is.close();
/* 163 */     outStream.close();
/* 164 */     File pdfWaterMrkd = new File(pdfPath);
/* 165 */     if (VERBOSE) System.out.println("*** new path :" + pdfWaterMrkd.getAbsolutePath()); 
/* 166 */     return pdfWaterMrkd;
/*     */   }
/*     */   
/*     */   public static File processPdf(File pdfFile, WTDocument doc) throws Exception {
/* 170 */     if (VERBOSE) System.out.println("*** PDFUtilDocumentWorker.processPdf() ");
/*     */ 
/*     */ 
/*     */     
/* 174 */     ArrayList<Object> appreps = new ArrayList();
/*     */ 
/*     */     
/* 177 */     if (pdfFile.exists() && pdfFile.canWrite()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 188 */       ApplicationData appdata = UpdateContent.uploadContent(pdfFile, (ContentHolder)doc, false);
/* 189 */       String pdfRedirectUrl = UpdateContent.genDownloadHREF((ContentHolder)doc, appdata);
/* 190 */       if (VERBOSE) System.out.println("*** PDF secondary file redirect URL: " + pdfRedirectUrl); 
/* 191 */       String urlLabel = doc.getNumber() + ".PDF";
/* 192 */       UpdateContent.updatePdfUrl((IBAHolder)doc, pdfRedirectUrl, urlLabel, PDF_URL_IBA_NAME);
/*     */     } 
/*     */     
/* 195 */     return pdfFile;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isPDFGenerated(WTDocument wtDoc) {
/* 200 */     System.out.println("*** PDFUtility.isPDFGenerated()****");
/* 201 */     boolean pdfFileExists = false;
/*     */     
/*     */     try {
/* 204 */       String docNumber = wtDoc.getNumber();
/* 205 */       String fileName = docNumber + ".PDF";
/* 206 */       WTDocument wTDocument = wtDoc;
/* 207 */       QueryResult secondaryContent = ContentHelper.service.getContentsByRole((ContentHolder)wTDocument, ContentRoleType.SECONDARY);
/* 208 */       String fileExtension = null;
/* 209 */       ArrayList contentList = new ArrayList(secondaryContent.size());
/* 210 */       if (secondaryContent.size() == 0) {
/*     */         
/* 212 */         System.out.println("*** PDFUtility.isPDFGenerated(): WTDOCUMENT [" + wTDocument.getNumber() + "] PDF File DOES NOT EXIST ..");
/*     */         
/* 214 */         return true;
/*     */       } 
/* 216 */       while (secondaryContent.hasMoreElements())
/*     */       {
/* 218 */         ApplicationData appdata = (ApplicationData)secondaryContent.nextElement();
/* 219 */         String temp = appdata.getFileName();
/* 220 */         System.out.println("Required Secondary File Name: " + fileName);
/* 221 */         System.out.println("Existing Secondary File Name: " + temp);
/* 222 */         if (temp.equalsIgnoreCase(fileName)) {
/* 223 */           System.out.println("PDF File Exists..");
/* 224 */           pdfFileExists = true;
/*     */         }
/*     */       
/*     */       }
/*     */     
/* 229 */     } catch (WTException e) {
/*     */ 
/*     */       
/* 232 */       e.printStackTrace();
/*     */     } 
/* 234 */     return pdfFileExists;
/*     */   }
/*     */ }


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\publis\\util\PDFUtilDocumentWorker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */