/*    */ package ext.piab.publish.util;
/*    */ 
/*    */ import wt.content.ContentItem;
/*    */ import wt.content.ContentRoleType;
/*    */ import wt.doc.WTDocument;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PublishFilterWTDoc
/*    */ {
/*    */   public static Boolean doNotPublishSecondaryContent(WTDocument doc, ContentItem ci) {
/* 14 */     if (ci.getRole() != null && ci.getRole().equals(ContentRoleType.PRIMARY)) {
/* 15 */       return Boolean.TRUE;
/*    */     }
/* 17 */     return Boolean.FALSE;
/*    */   }
/*    */ }


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\publis\\util\PublishFilterWTDoc.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */