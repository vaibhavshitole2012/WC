/*     */ package ext.piab.publish.util;
/*     */ 
/*     */ import ext.piab.common.util.PropertyforPIAB;
/*     */ import ext.piab.pdf.PDFUtility;
/*     */ import java.util.ArrayList;
/*     */ import wt.content.ApplicationData;
/*     */ import wt.content.ContentHelper;
/*     */ import wt.content.ContentHolder;
/*     */ import wt.content.ContentRoleType;
/*     */ import wt.doc.WTDocument;
/*     */ import wt.epm.EPMDocument;
/*     */ import wt.fc.QueryResult;
/*     */ import wt.fc.WTObject;
/*     */ import wt.util.WTException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CopyWatermarkedPDFs
/*     */ {
/*     */   private static final boolean VERBOSE = true;
/*  23 */   private static final String LC_STATE_4 = PropertyforPIAB.LC_STATE_4;
/*     */ 
/*     */   
/*     */   public static String exportPDFs(ArrayList<WTObject> list) {
/*  27 */     System.out.println("***CopyWatermarkedPDFs.exportPDFs()");
/*  28 */     ArrayList items = new ArrayList();
/*  29 */     boolean pdfExists = true;
/*  30 */     String viewableMsg = "";
/*  31 */     String fileName = "";
/*  32 */     String fileExtension = ".PDF";
/*     */     try {
/*  34 */       viewableMsg = CheckViewables.checkForViewables(list);
/*  35 */       if (viewableMsg.isEmpty()) {
/*     */         
/*  37 */         for (int i = 0; i < list.size(); i++) {
/*  38 */           WTObject wto = list.get(i);
/*  39 */           if (wto instanceof WTDocument) {
/*  40 */             WTDocument wtDoc = (WTDocument)wto;
/*  41 */             System.out.println("***WTDocument number : " + wtDoc.getNumber());
/*  42 */             if (wtDoc.getLifeCycleState().toString().equalsIgnoreCase(LC_STATE_4)) {
/*  43 */               fileName = wtDoc.getNumber() + fileExtension;
/*  44 */               pdfExists = isPDFGenerated((ContentHolder)wtDoc, fileName);
/*  45 */               if (pdfExists) {
/*  46 */                 PDFUtility.processPdf((ContentHolder)wtDoc, fileName);
/*     */               }
/*     */             }
/*     */           
/*  50 */           } else if (wto instanceof EPMDocument) {
/*  51 */             EPMDocument epmDoc = (EPMDocument)wto;
/*  52 */             System.out.println("***CopyWatermarkedPDFs.exportPDFs() - EPMDocument found : " + epmDoc.getIdentity());
/*  53 */             String epmDocType = epmDoc.getDocType().toString();
/*  54 */             System.out.println("***CopyWatermarkedPDFs.exportPDFs() - EPMDocument type : " + epmDocType);
/*  55 */             if (epmDocType.equalsIgnoreCase("CADDRAWING") && epmDoc.getLifeCycleState().toString().equalsIgnoreCase(LC_STATE_4)) {
/*  56 */               if (epmDoc.getNumber().lastIndexOf('.') > 0) {
/*  57 */                 String str = epmDoc.getNumber().substring(0, epmDoc.getNumber().lastIndexOf('.'));
/*  58 */                 fileName = str + fileExtension;
/*     */               } else {
/*     */                 
/*  61 */                 fileName = epmDoc.getNumber() + fileExtension;
/*     */               } 
/*  63 */               System.out.println("***CopyWatermarkedPDFs.exportPDFs - fileName : " + fileName);
/*  64 */               pdfExists = isPDFGenerated((ContentHolder)epmDoc, fileName);
/*  65 */               if (pdfExists) {
/*  66 */                 PDFUtility.processPdf((ContentHolder)epmDoc, fileName);
/*     */               }
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } else {
/*     */         
/*  73 */         System.out.println("**Viewables for change items are out of date..");
/*     */       }
/*     */     
/*  76 */     } catch (Exception ex) {
/*  77 */       ex.printStackTrace();
/*  78 */       return ex.getLocalizedMessage();
/*     */     } 
/*  80 */     return viewableMsg;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isPDFGenerated(ContentHolder ch, String fileName) {
/*  87 */     System.out.println("*** CopyWatermarkedPDFs.isPDFGenerated()****");
/*  88 */     boolean pdfFileExists = false;
/*     */     try {
/*  90 */       ContentHolder holder = ch;
/*  91 */       QueryResult secondaryContent = ContentHelper.service.getContentsByRole(holder, ContentRoleType.SECONDARY);
/*  92 */       String fileExtension = null;
/*  93 */       ArrayList contentList = new ArrayList(secondaryContent.size());
/*  94 */       if (secondaryContent.size() > 0) {
/*  95 */         while (secondaryContent.hasMoreElements()) {
/*  96 */           ApplicationData appdata = (ApplicationData)secondaryContent.nextElement();
/*  97 */           String temp = appdata.getFileName();
/*  98 */           System.out.println("Required Secondary File Name: " + fileName);
/*  99 */           System.out.println("Existing Secondary File Name: " + temp);
/* 100 */           if (temp.equalsIgnoreCase(fileName)) {
/* 101 */             System.out.println("PDF File Exists..");
/* 102 */             pdfFileExists = true;
/*     */           }
/*     */         
/*     */         } 
/*     */       }
/* 107 */     } catch (WTException e) {
/* 108 */       e.printStackTrace();
/*     */     } 
/* 110 */     return pdfFileExists;
/*     */   }
/*     */ }


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\publis\\util\CopyWatermarkedPDFs.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */