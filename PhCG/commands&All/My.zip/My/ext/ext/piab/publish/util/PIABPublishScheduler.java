/*     */ package ext.piab.publish.util;
/*     */ 
/*     */ import com.ptc.wvs.server.publish.Publish;
/*     */ import com.ptc.wvs.server.schedule.ScheduleJobs;
/*     */ import java.io.Serializable;
/*     */ import wt.doc.WTDocument;
/*     */ import wt.doc.WTDocumentConfigSpec;
/*     */ import wt.epm.EPMDocument;
/*     */ import wt.epm.workspaces.EPMAsStoredConfigSpec;
/*     */ import wt.fc.Persistable;
/*     */ import wt.fc.PersistenceHelper;
/*     */ import wt.fc.QueryResult;
/*     */ import wt.part.WTPartStandardConfigSpec;
/*     */ import wt.query.QuerySpec;
/*     */ import wt.query.SearchCondition;
/*     */ import wt.query.WhereExpression;
/*     */ import wt.representation.Representable;
/*     */ import wt.representation.Representation;
/*     */ import wt.representation.RepresentationHelper;
/*     */ import wt.vc.config.ConfigSpec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PIABPublishScheduler
/*     */   extends ScheduleJobs
/*     */   implements Serializable
/*     */ {
/*     */   public static QuerySpec getLastetReleasedCADDrawings() throws Exception {
/*  33 */     System.out.println("Entering:  PIABPublishScheduler.getLastetReleasedCADDrawings");
/*     */     
/*  35 */     QuerySpec qs = new QuerySpec(EPMDocument.class);
/*     */     
/*  37 */     qs.appendWhere((WhereExpression)new SearchCondition(EPMDocument.class, "master>docType", "=", "CADDRAWING"), 0);
/*  38 */     qs.appendAnd();
/*  39 */     qs.appendWhere((WhereExpression)new SearchCondition(EPMDocument.class, "state.state", "<>", "OBSOLETED"), 0);
/*  40 */     qs.appendAnd();
/*  41 */     qs.appendWhere((WhereExpression)new SearchCondition(EPMDocument.class, "iterationInfo.latest", "TRUE"));
/*     */     
/*  43 */     System.out.println("Exiting:  PIABPublishScheduler.getLastetReleasedCADDrawings");
/*     */     
/*  45 */     return qs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void generateDXFAttachments() throws Exception {
/*  52 */     System.out.println("Entering:  PIABPublishScheduler.generateDXFAttachments");
/*     */     
/*  54 */     QueryResult qr = PersistenceHelper.manager.find(getLastetReleasedCADDrawings());
/*  55 */     System.out.println("*** epmdoc query size: " + qr.size());
/*  56 */     int i = 0;
/*  57 */     while (qr.hasMoreElements()) {
/*     */       
/*  59 */       i++;
/*  60 */       EPMDocument drawing = (EPMDocument)qr.nextElement();
/*  61 */       Representation defaultRep = getDefaultRepresentation((Representable)drawing);
/*  62 */       if (defaultRep != null) {
/*     */         
/*  64 */         System.out.println("DEFAULT REPRESENTATION EXISTS RESUBMITTING PUBLISH JOB FOR " + drawing);
/*  65 */         rePublishRepresentation(drawing, defaultRep);
/*     */         
/*     */         continue;
/*     */       } 
/*  69 */       System.out.println("NO DEFAULT REPRESENTATION EXISTS SUBMITTING PUBLISH JOB FOR " + drawing);
/*  70 */       sendPublishJob(drawing);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Representation getDefaultRepresentation(Representable rep) throws Exception {
/*  79 */     System.out.println("Entering:  PIABPublishScheduler.getDefaultRepresentation");
/*  80 */     boolean hasRep = false;
/*  81 */     Representation defaultRep = null;
/*  82 */     QueryResult reps = RepresentationHelper.service.getRepresentations(rep);
/*  83 */     while (reps.hasMoreElements() && !hasRep) {
/*  84 */       Representation representation = (Representation)reps.nextElement();
/*  85 */       String name = representation.getName();
/*  86 */       if (name.equals("default")) {
/*     */         
/*  88 */         System.out.println("FOUND DEFAULT REPRESENTATION");
/*  89 */         defaultRep = representation;
/*  90 */         hasRep = true;
/*     */       } 
/*     */     } 
/*     */     
/*  94 */     System.out.println("Exiting:  PIABPublishScheduler.getDefaultRepresentation");
/*     */     
/*  96 */     return defaultRep;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void sendPublishJob(EPMDocument epmdoc) throws Exception {
/* 102 */     System.out.println("Entering:  PIABPublishScheduler.sendPublishJob: " + epmdoc.getNumber());
/* 103 */     Publish.doPublish(false, true, (Persistable)epmdoc, 
/*     */ 
/*     */         
/* 106 */         (ConfigSpec)EPMAsStoredConfigSpec.newEPMAsStoredConfigSpec(epmdoc), 
/* 107 */         (ConfigSpec)WTPartStandardConfigSpec.newWTPartStandardConfigSpec(), true, "default", null, 1, null, 1, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 116 */     System.out.println("Exiting:  PIABPublishScheduler.sendPublishJob: " + epmdoc.getNumber());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void rePublishRepresentation(EPMDocument epmdoc, Representation localRepresentation) throws Exception {
/* 122 */     System.out.println("Entering:  PIABPublishScheduler.rePublishRepresentation: " + epmdoc.getNumber());
/*     */     
/* 124 */     Publish.republishRepresentation((Representable)epmdoc, localRepresentation);
/* 125 */     System.out.println("Exiting:  PIABPublishScheduler.rePublishRepresentation: " + epmdoc.getNumber());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void rePublishRepresentation(WTDocument wtdoc, Representation localRepresentation) throws Exception {
/* 131 */     System.out.println("Entering:  PIABPublishScheduler.rePublishRepresentation: " + wtdoc.getNumber());
/*     */     
/* 133 */     Publish.republishRepresentation((Representable)wtdoc, localRepresentation);
/* 134 */     System.out.println("Exiting:  PIABPublishScheduler.rePublishRepresentation: " + wtdoc.getNumber());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void publishDocument(WTDocument wtdoc) throws Exception {
/* 140 */     Representation defaultRep = getDefaultRepresentation((Representable)wtdoc);
/* 141 */     if (defaultRep != null) {
/*     */       
/* 143 */       System.out.println("DEFAULT REPRESENTATION EXISTS RESUBMITTING PUBLISH JOB FOR " + wtdoc);
/* 144 */       Publish.republishRepresentation((Representable)wtdoc, defaultRep);
/*     */     }
/*     */     else {
/*     */       
/* 148 */       System.out.println("NO DEFAULT REPRESENTATION EXISTS SUBMITTING PUBLISH JOB FOR " + wtdoc);
/* 149 */       Publish.doPublish(false, true, (Persistable)wtdoc, 
/*     */ 
/*     */           
/* 152 */           (ConfigSpec)WTDocumentConfigSpec.newWTDocumentConfigSpec(), null, true, "default", null, 1, null, 1, null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 161 */       System.out.println("Exiting:  PIABPublishScheduler.publishDocument: " + wtdoc.getNumber());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\publis\\util\PIABPublishScheduler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */