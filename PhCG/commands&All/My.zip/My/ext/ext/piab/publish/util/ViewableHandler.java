/*    */ package ext.piab.publish.util;
/*    */ 
/*    */ import java.util.Date;
/*    */ import wt.content.ApplicationData;
/*    */ import wt.content.ContentHelper;
/*    */ import wt.content.ContentHolder;
/*    */ import wt.content.ContentRoleType;
/*    */ import wt.doc.WTDocument;
/*    */ import wt.epm.EPMDocument;
/*    */ import wt.fc.Persistable;
/*    */ import wt.fc.QueryResult;
/*    */ import wt.maturity.MaturityHelper;
/*    */ import wt.maturity.PromotionNotice;
/*    */ import wt.vc.VersionControlHelper;
/*    */ import wt.vc.Versioned;
/*    */ 
/*    */ public class ViewableHandler {
/*    */   private static final boolean VERBOSE = true;
/*    */   
/*    */   public static String checkForViewables(PromotionNotice pn) throws Exception {
/* 21 */     System.out.println("checkForViewables for Promotion Notice : " + pn.getNumber());
/* 22 */     StringBuilder sb = new StringBuilder();
/* 23 */     Date secModDate = new Date();
/* 24 */     QueryResult qresult = MaturityHelper.service.getPromotionTargets(pn, true);
/* 25 */     while (qresult.hasMoreElements()) {
/* 26 */       Persistable pers = (Persistable)qresult.nextElement();
/* 27 */       if (pers instanceof WTDocument) {
/* 28 */         ApplicationData appData = null;
/* 29 */         WTDocument wtd = (WTDocument)pers;
/* 30 */         QueryResult qr = VersionControlHelper.service.allVersionsOf((Versioned)wtd);
/* 31 */         wtd = (WTDocument)qr.nextElement();
/* 32 */         System.out.println("Object is an instance of WTDocument : " + wtd.getNumber());
/* 33 */         Date wtdModDate = wtd.getModifyTimestamp();
/* 34 */         qr = ContentHelper.service.getContentsByRole((ContentHolder)wtd, ContentRoleType.SECONDARY);
/* 35 */         while (qr.hasMoreElements()) {
/* 36 */           appData = (ApplicationData)qr.nextElement();
/* 37 */           secModDate = appData.getModifyTimestamp();
/*    */         } 
/* 39 */         if (appData != null) {
/* 40 */           if (wtdModDate.after(secModDate)) {
/* 41 */             System.out.println("Not a latest viewable");
/* 42 */             sb.append(wtd.getName());
/*    */             continue;
/*    */           } 
/* 45 */           System.out.println("Is a latest Viewable");
/*    */           
/*    */           continue;
/*    */         } 
/* 49 */         sb.append(wtd.getName());
/* 50 */         System.out.println("Does not have a Viewable");
/*    */         continue;
/*    */       } 
/* 53 */       if (pers instanceof EPMDocument) {
/* 54 */         ApplicationData appData = null;
/* 55 */         EPMDocument epm = (EPMDocument)pers;
/* 56 */         QueryResult qr = VersionControlHelper.service.allVersionsOf((Versioned)epm);
/* 57 */         epm = (EPMDocument)qr.nextElement();
/* 58 */         System.out.println("Object is an instance of EPMDocument : " + epm.getNumber());
/* 59 */         Date wtdModDate = epm.getModifyTimestamp();
/* 60 */         qr = ContentHelper.service.getContentsByRole((ContentHolder)epm, ContentRoleType.SECONDARY);
/* 61 */         while (qr.hasMoreElements()) {
/* 62 */           appData = (ApplicationData)qr.nextElement();
/* 63 */           secModDate = appData.getModifyTimestamp();
/*    */         } 
/* 65 */         if (appData != null) {
/* 66 */           if (wtdModDate.after(secModDate)) {
/* 67 */             System.out.println("Not a latest viewable");
/* 68 */             sb.append(epm.getName());
/*    */             continue;
/*    */           } 
/* 71 */           System.out.println("Is a latest Viewable");
/*    */           
/*    */           continue;
/*    */         } 
/* 75 */         System.out.println("Does not have a Viewable");
/* 76 */         sb.append(epm.getName());
/*    */         
/*    */         continue;
/*    */       } 
/* 80 */       System.out.println("Object is neither instance of an WTDocument nor EPMDocument..");
/*    */     } 
/*    */     
/* 83 */     String message = sb.toString();
/* 84 */     if (!message.isEmpty()) {
/* 85 */       System.out.println("The objects in current Promotion Notice " + message + " dosen't have the viewables up to date ");
/* 86 */       String s = "<font color=red>Viewables for Items [ " + message + " ] may be out of date or not available</font>";
/* 87 */       return s;
/*    */     } 
/*    */     
/* 90 */     sb.append("<font color=red>Items in this current Promotion Notice have Viewables up to date</font>");
/* 91 */     return sb.toString();
/*    */   }
/*    */   
/*    */   private static final String notLatest = "";
/*    */ }


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\publis\\util\ViewableHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */