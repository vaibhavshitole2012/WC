/*     */ package ext.piab.publish.util;
/*     */ 
/*     */ import ext.piab.common.util.PropertyforPIAB;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Vector;
/*     */ import wt.change2.ChangeHelper2;
/*     */ import wt.change2.ChangeIssueIfc;
/*     */ import wt.change2.ChangeOrderIfc;
/*     */ import wt.change2.ChangeRequestIfc;
/*     */ import wt.change2.WTChangeOrder2;
/*     */ import wt.change2.WTChangeRequest2;
/*     */ import wt.change2.WTVariance;
/*     */ import wt.content.ApplicationData;
/*     */ import wt.content.ContentHelper;
/*     */ import wt.content.ContentHolder;
/*     */ import wt.content.ContentRoleType;
/*     */ import wt.content.ContentServerHelper;
/*     */ import wt.doc.WTDocument;
/*     */ import wt.epm.EPMDocument;
/*     */ import wt.fc.QueryResult;
/*     */ import wt.util.WTException;
/*     */ import wt.util.WTProperties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CopyViewables
/*     */ {
/*  42 */   private static final String CLASSNAME = CopyViewables.class.getName();
/*     */   private static boolean VERBOSE;
/*     */   private static String DOWNLOAD_LOCATION;
/*  45 */   protected static WTProperties wtProps = null;
/*  46 */   private static String wc_home = PropertyforPIAB.WT_HOME;
/*     */ 
/*     */   
/*     */   public static void exportPDFViewable(ContentHolder contentHolder1, String brandFolder1) throws WTException {
/*  50 */     String downloadFolderLocation = DOWNLOAD_LOCATION + brandFolder1;
/*  51 */     if (VERBOSE) System.out.println("*** CopyViewables.exportPDFViewable() - download location: " + downloadFolderLocation); 
/*  52 */     boolean pdfExists = true;
/*  53 */     String fileName = "";
/*  54 */     String fileExtension = ".PDF";
/*  55 */     if (contentHolder1 instanceof WTDocument)
/*  56 */     { WTDocument wtDoc = (WTDocument)contentHolder1;
/*  57 */       if (VERBOSE) System.out.println("*** CopyViewables.exportPDFViewable() - WTDocument found: " + wtDoc.getIdentity()); 
/*  58 */       fileName = wtDoc.getNumber() + fileExtension;
/*  59 */       pdfExists = isPDFGenerated((ContentHolder)wtDoc, fileName);
/*  60 */       if (!pdfExists) {
/*  61 */         throw new WTException("PDF does not exist for the document: " + wtDoc.getIdentity());
/*     */       }
/*  63 */       downloadPDFFile((ContentHolder)wtDoc, fileName, downloadFolderLocation); }
/*     */     
/*  65 */     else if (contentHolder1 instanceof EPMDocument)
/*  66 */     { EPMDocument epmDoc = (EPMDocument)contentHolder1;
/*  67 */       if (VERBOSE) System.out.println("*** CopyViewables.exportPDFViewable() - EPMDocument found: " + epmDoc.getIdentity()); 
/*  68 */       String epmDocType = epmDoc.getDocType().getStringValue();
/*  69 */       if (VERBOSE) System.out.println("*** CopyViewables.exportPDFViewable() - EPMDocument Type: " + epmDocType); 
/*  70 */       if (!epmDocType.equalsIgnoreCase("wt.epm.EPMDocumentType.CADDRAWING")) {
/*  71 */         if (VERBOSE) System.out.println("Unsupported object detected in the change items: " + epmDoc.getIdentity());
/*     */       
/*     */       } else {
/*  74 */         if (epmDoc.getNumber().lastIndexOf('.') > 0) {
/*  75 */           String str = epmDoc.getNumber().substring(0, epmDoc.getNumber().lastIndexOf('.'));
/*  76 */           fileName = str + fileExtension;
/*     */         } else {
/*  78 */           fileName = epmDoc.getNumber() + fileExtension;
/*     */         } 
/*  80 */         if (VERBOSE) System.out.println("*** CopyViewables.exportPDFViewable() - filename: " + fileName); 
/*  81 */         pdfExists = isPDFGenerated((ContentHolder)epmDoc, fileName);
/*  82 */         if (!pdfExists) {
/*  83 */           throw new WTException("PDF does not exist for the drawing: " + epmDoc.getIdentity());
/*     */         }
/*  85 */         downloadPDFFile((ContentHolder)epmDoc, fileName, downloadFolderLocation);
/*     */       }
/*     */        }
/*     */     
/*  89 */     else if (VERBOSE) { System.out.println("Unsupported object detected in the change items: " + contentHolder1.getIdentity()); }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isPDFGenerated(ContentHolder ch, String fileName) {
/*  96 */     if (VERBOSE) System.out.println("*** CopyViewables.isPDFGenerated()****"); 
/*  97 */     boolean pdfFileExists = false;
/*     */     
/*     */     try {
/* 100 */       ContentHolder holder = ch;
/* 101 */       QueryResult secondaryContent = ContentHelper.service.getContentsByRole(holder, ContentRoleType.SECONDARY);
/* 102 */       String fileExtension = null;
/* 103 */       ArrayList contentList = new ArrayList(secondaryContent.size());
/* 104 */       if (secondaryContent.size() > 0)
/*     */       {
/* 106 */         while (secondaryContent.hasMoreElements()) {
/* 107 */           ApplicationData appdata = (ApplicationData)secondaryContent.nextElement();
/* 108 */           String temp = appdata.getFileName();
/* 109 */           if (VERBOSE) System.out.println("Required Secondary File Name: " + fileName); 
/* 110 */           if (VERBOSE) System.out.println("Existing Secondary File Name: " + temp); 
/* 111 */           if (temp.equalsIgnoreCase(fileName)) {
/* 112 */             if (VERBOSE) System.out.println("PDF File Exists.."); 
/* 113 */             pdfFileExists = true;
/*     */           }
/*     */         
/*     */         }
/*     */       
/*     */       }
/* 119 */     } catch (WTException e) {
/*     */ 
/*     */       
/* 122 */       e.printStackTrace();
/*     */     } 
/* 124 */     return pdfFileExists;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void downloadPDFFile(ContentHolder ch, String fileName, String downloadFolderLocation) throws WTException {
/* 129 */     if (VERBOSE) System.out.println("*** CopyViewables.downloadPDFFile()****"); 
/* 130 */     String pdfFileName = "";
/*     */     
/*     */     try {
/* 133 */       ContentHolder holder = ch;
/* 134 */       QueryResult secondaryContent = ContentHelper.service.getContentsByRole(holder, ContentRoleType.SECONDARY);
/* 135 */       ArrayList contentList = new ArrayList(secondaryContent.size());
/* 136 */       if (secondaryContent.size() > 0)
/*     */       {
/* 138 */         while (secondaryContent.hasMoreElements()) {
/* 139 */           ApplicationData appdata = (ApplicationData)secondaryContent.nextElement();
/* 140 */           String temp = appdata.getFileName();
/* 141 */           if (VERBOSE) System.out.println("Required Secondary File Name: " + fileName); 
/* 142 */           if (VERBOSE) System.out.println("Existing Secondary File Name: " + temp); 
/* 143 */           if (temp.equalsIgnoreCase(fileName)) {
/* 144 */             pdfFileName = downloadFolderLocation + "/" + fileName;
/* 145 */             if (VERBOSE) System.out.println("Existing File: " + pdfFileName); 
/* 146 */             ContentServerHelper.service.writeContentStream(appdata, pdfFileName);
/*     */           }
/*     */         
/*     */         }
/*     */       
/*     */       }
/* 152 */     } catch (IOException ioe) {
/*     */ 
/*     */       
/* 155 */       throw new WTException("Unable to download viewable file to: " + pdfFileName);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void copyViewablesForECNByBrand(WTChangeOrder2 ECN, Vector<String> brands) throws WTException {
/* 162 */     String brand = "";
/* 163 */     for (int i = 0; i < brands.size(); i++) {
/* 164 */       brand = brands.elementAt(i);
/* 165 */       if (VERBOSE) System.out.println("***Copying Viewable Data for Brand: " + brand);
/*     */       
/* 167 */       QueryResult qres = ChangeHelper2.service.getChangeablesAfter((ChangeOrderIfc)ECN, true);
/* 168 */       if (VERBOSE) System.out.println("***size of resulting objects " + qres.size()); 
/* 169 */       while (qres.hasMoreElements()) {
/* 170 */         ContentHolder ch = (ContentHolder)qres.nextElement();
/* 171 */         if (VERBOSE) System.out.println("Copying Viewable: " + ch.getIdentity() + " to brand: " + brand); 
/* 172 */         exportPDFViewable(ch, brand);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void copyViewablesForECRByBrand(WTChangeRequest2 ECR, Vector<String> brands) throws WTException {
/* 179 */     String brand = "";
/* 180 */     for (int i = 0; i < brands.size(); i++) {
/* 181 */       brand = brands.elementAt(i);
/* 182 */       if (VERBOSE) System.out.println("***Copying Viewable Data for Brand: " + brand);
/*     */       
/* 184 */       QueryResult qres = ChangeHelper2.service.getChangeables((ChangeRequestIfc)ECR, true);
/* 185 */       if (VERBOSE) System.out.println("***size of resulting objects " + qres.size()); 
/* 186 */       while (qres.hasMoreElements()) {
/* 187 */         ContentHolder ch = (ContentHolder)qres.nextElement();
/* 188 */         if (VERBOSE) System.out.println("Copying Viewable: " + ch.getIdentity() + " to brand: " + brand); 
/* 189 */         exportPDFViewable(ch, brand);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void copyViewablesForVarianceByBrand(WTVariance VAR, Vector<String> brands) throws WTException {
/* 195 */     String brand = "";
/* 196 */     for (int i = 0; i < brands.size(); i++) {
/* 197 */       brand = brands.elementAt(i);
/* 198 */       if (VERBOSE) System.out.println("***Copying Viewable Data for Brand: " + brand);
/*     */       
/* 200 */       QueryResult qres = ChangeHelper2.service.getChangeables((ChangeIssueIfc)VAR, true);
/* 201 */       if (VERBOSE) System.out.println("***size of resulting objects " + qres.size()); 
/* 202 */       while (qres.hasMoreElements()) {
/* 203 */         ContentHolder ch = (ContentHolder)qres.nextElement();
/* 204 */         if (VERBOSE) System.out.println("Copying Viewable: " + ch.getIdentity() + " to brand: " + brand); 
/* 205 */         exportPDFViewable(ch, brand);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*     */     try {
/* 214 */       wtProps = WTProperties.getLocalProperties();
/* 215 */       VERBOSE = wtProps.getProperty("ext.piab.pubevent.PostPublishUploadService.Verbose", false);
/* 216 */       DOWNLOAD_LOCATION = wtProps.getProperty("ext.piab.starkey.viewable.folder.base", "");
/*     */     }
/* 218 */     catch (Exception e) {
/* 219 */       System.out.println("####### " + CLASSNAME + " :: Error reading property file.");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\publis\\util\CopyViewables.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */