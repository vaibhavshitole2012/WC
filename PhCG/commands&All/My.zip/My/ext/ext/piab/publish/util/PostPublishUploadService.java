package ext.piab.publish.util;

public interface PostPublishUploadService {}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\publis\\util\PostPublishUploadService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */