package ext.piab.promotion.util;

import ext.piab.common.util.LifecycleStateHelper;
import ext.piab.common.util.PropertyforPIAB;
import java.util.ArrayList;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.fc.WTObject;
import wt.maturity.MaturityHelper;
import wt.maturity.PromotionNotice;

public class PromotionTargetHandler {
  private static final boolean VERBOSE = PropertyforPIAB.VERBOSE;
  
  public static ArrayList itemsInPromotion(PromotionNotice paramPromotionNotice) throws Exception {
    if (VERBOSE)
      System.out.println("CheckViewables.itemsInPromotionNotice()"); 
    ArrayList<Persistable> arrayList = new ArrayList();
    QueryResult queryResult = MaturityHelper.service.getPromotionTargets(paramPromotionNotice);
    while (queryResult.hasMoreElements()) {
      Persistable persistable = (Persistable)queryResult.nextElement();
      arrayList.add(persistable);
    } 
    if (VERBOSE)
      System.out.println("***Size of promotion targets : " + arrayList.size()); 
    return arrayList;
  }
  
  public static void setItemsState(WTObject paramWTObject, String paramString) throws Exception {
    if (VERBOSE)
      System.out.println("***PromotionTargetHandler.setItemsState()"); 
    if (paramWTObject instanceof PromotionNotice) {
      PromotionNotice promotionNotice = (PromotionNotice)paramWTObject;
      ArrayList<WTObject> arrayList = itemsInPromotion(promotionNotice);
      for (byte b = 0; b < arrayList.size(); b++) {
        if (VERBOSE)
          System.out.println("***Set Item state to " + paramString); 
        WTObject wTObject = arrayList.get(b);
        LifecycleStateHelper.setLifecycleState((Persistable)wTObject, paramString);
      } 
    } 
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\promotio\\util\PromotionTargetHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */