package ext.piab.pdf;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfGState;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import java.beans.PropertyVetoException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Random;
import java.util.StringTokenizer;
import java.util.Vector;
import wt.content.ApplicationData;
import wt.content.ContentHelper;
import wt.content.ContentHolder;
import wt.content.ContentRoleType;
import wt.content.ContentServerHelper;
import wt.content.FormatContentHolder;
import wt.doc.WTDocument;
import wt.epm.EPMDocument;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.WTObject;
import wt.httpgw.URLFactory;
import wt.iba.definition.URLDefinition;
import wt.iba.value.IBAHolder;
import wt.iba.value.URLValue;
import wt.method.RemoteAccess;
import wt.pom.Transaction;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.query.WhereExpression;
import wt.representation.Representable;
import wt.representation.Representation;
import wt.representation.RepresentationHelper;
import wt.util.WTException;
import wt.util.WTProperties;
import wt.viewmarkup.DerivedImage;

public class PDFUtility implements RemoteAccess {
  public static final boolean VERBOSE;
  
  private static final String WTTEMP;
  
  private static final String TEMP_DIR;
  
  public static final boolean DEL_TEMP;
  
  private static final int MAX_PS_GEN;
  
  private static final int SLEEP_INTERVAL = 1000;
  
  private static final float PDF_WATERMARK_X;
  
  private static final float PDF_WATERMARK_Y;
  
  private static final String PDF_WATERMARK_STYLE;
  
  private static final String PDF_WATERMARK_FONT;
  
  private static final float PDF_WATERMARK_SIZE;
  
  private static final String PDF_WATERMARK_COLOR;
  
  public static final String PDF_URL_IBA_NAME;
  
  public static final String WT_HOME;
  
  public static final String PDF_TEXT;
  
  private static String supportedContentTypes = "PDF";
  
  public static File createDirectory(String paramString1, String paramString2) throws IOException {
    if (VERBOSE)
      System.out.println("*** PIABPDFUtility.createDirectory: 1" + paramString1 + "\t" + paramString2); 
    File file = null;
    if (paramString1 == null || paramString1.equals("")) {
      file = new File(paramString2);
    } else {
      file = File.createTempFile(paramString1, "", new File(paramString2));
    } 
    file.delete();
    file.mkdir();
    return file;
  }
  
  public static File processPdf(ContentHolder paramContentHolder, String paramString) throws Exception {
    if (VERBOSE)
      System.out.println("*** PDFUtility.processPdf: Processing PDF file: "); 
    File file1 = null;
    File file2 = null;
    String str1 = ".PDF";
    Random random = new Random();
    File file3 = createDirectory(null, TEMP_DIR + File.separator + random.nextInt(5000));
    String str2 = file3.getAbsolutePath();
    ArrayList<Object> arrayList = new ArrayList();
    if (VERBOSE)
      System.out.println("*** Created temp dir: " + str2 + "\n*** Processing ContentHolder:\t" + ((WTObject)paramContentHolder).getDisplayIdentity()); 
    file2 = getSecondaryFile(paramContentHolder, file3, paramString);
    if (file2 != null) {
      file1 = file2;
      if (file1.exists() && file1.canWrite()) {
        System.out.println("Watermark Text to be added : " + PDF_TEXT);
        file1 = addWatermark(file1, PDF_TEXT);
        arrayList = getRepresentation((Representable)paramContentHolder, file1.getName());
        if (arrayList.size() > 0) {
          if (VERBOSE)
            System.out.println("*** Updating Representation. "); 
          updateRepresentation(file1, paramContentHolder, arrayList);
        } else if (VERBOSE) {
          System.out.println("*** Represntation does not exsist. ");
        } 
        System.out.println("PDF File name : " + file1);
        String str = uploadContent(file1, paramContentHolder, false);
        if (VERBOSE)
          System.out.println("*** PDF secondary file redirect URL: " + str); 
        if (paramContentHolder instanceof WTDocument) {
          WTDocument wTDocument = (WTDocument)paramContentHolder;
          updatePdfUrl((IBAHolder)wTDocument, str, wTDocument.getNumber() + str1, PDF_URL_IBA_NAME);
        } else if (paramContentHolder instanceof EPMDocument) {
          EPMDocument ePMDocument = (EPMDocument)paramContentHolder;
          updatePdfUrl((IBAHolder)ePMDocument, str, ePMDocument.getNumber() + str1, PDF_URL_IBA_NAME);
        } 
      } 
      if (DEL_TEMP)
        removeDirectory(file3); 
      return file1;
    } 
    System.out.println("*** No Supported Docuemnt Type.");
    return null;
  }
  
  public static ArrayList<Object> getRepresentation(Representable paramRepresentable, String paramString) throws Exception, IOException, InvocationTargetException {
    Object object = null;
    ArrayList<ApplicationData> arrayList = new ArrayList();
    QueryResult queryResult = RepresentationHelper.service.getRepresentations(paramRepresentable);
    if (VERBOSE)
      System.out.println("*** Representation size: " + queryResult.size()); 
    while (queryResult.hasMoreElements()) {
      Representation representation = (Representation)queryResult.nextElement();
      if (VERBOSE)
        System.out.println("*** Representation Name: " + representation + " name: " + representation.getName()); 
      ContentRoleType contentRoleType = ContentRoleType.toContentRoleType("SECONDARY");
      QueryResult queryResult1 = ContentHelper.service.getContentsByRole((ContentHolder)representation, contentRoleType);
      while (queryResult1.hasMoreElements()) {
        ApplicationData applicationData = (ApplicationData)queryResult1.nextElement();
        String str = applicationData.getFileName();
        if (str.equalsIgnoreCase(paramString)) {
          if (VERBOSE)
            System.out.println("*** Representation exist : " + str); 
          arrayList.add(applicationData);
          arrayList.add(representation);
        } 
      } 
    } 
    return (ArrayList)arrayList;
  }
  
  public static void updateRepresentation(File paramFile, ContentHolder paramContentHolder, ArrayList<Object> paramArrayList) throws WTException, FileNotFoundException, PropertyVetoException, IOException {
    Representation representation;
    if (VERBOSE)
      System.out.println("*** PIABPDFUtility.uploadContent: " + paramFile.getAbsolutePath()); 
    if (!paramFile.exists() || !paramFile.isFile())
      throw new WTException("***** ERROR: Cannot upload,  file does not exist ****"); 
    Transaction transaction = new Transaction();
    FileInputStream fileInputStream = new FileInputStream(paramFile);
    transaction.start();
    ContentHolder contentHolder = ContentHelper.service.getContents(paramContentHolder);
    ApplicationData applicationData = new ApplicationData();
    DerivedImage derivedImage = DerivedImage.newDerivedImage("default");
    for (byte b = 0; b < paramArrayList.size(); b++) {
      if (paramArrayList.get(b) instanceof ApplicationData) {
        applicationData = (ApplicationData)paramArrayList.get(b);
      } else if (paramArrayList.get(b) instanceof Representation) {
        representation = (Representation)paramArrayList.get(b);
      } 
    } 
    if (VERBOSE)
      System.out.println("*** Uploading new PDF file " + paramFile.getAbsolutePath()); 
    if (VERBOSE)
      System.out.println("*** Application Data " + applicationData); 
    if (VERBOSE)
      System.out.println("*** Representation object " + representation); 
    applicationData = ContentServerHelper.service.updateContent((ContentHolder)representation, applicationData, fileInputStream);
    if (VERBOSE)
      System.out.println("*** New PDF file uploaded " + paramFile.getAbsolutePath()); 
    if (VERBOSE)
      System.out.println("*** " + applicationData.getFileName() + " " + applicationData.getFileSize()); 
    transaction.commit();
    fileInputStream.close();
  }
  
  public static String uploadContent(File paramFile, ContentHolder paramContentHolder, boolean paramBoolean) throws WTException, FileNotFoundException, PropertyVetoException, IOException {
    if (VERBOSE)
      System.out.println("*** PIABPDFUtility.uploadContent: " + paramFile.getAbsolutePath()); 
    if (!paramFile.exists() || !paramFile.isFile())
      throw new WTException("***** ERROR: Cannot upload,  file does not exist ****"); 
    String str = null;
    try {
      Transaction transaction = new Transaction();
      FileInputStream fileInputStream = new FileInputStream(paramFile);
      transaction.start();
      ContentHolder contentHolder = ContentHelper.service.getContents(paramContentHolder);
      ApplicationData applicationData = ApplicationData.newApplicationData(contentHolder);
      applicationData.setFileName(paramFile.getName());
      if (VERBOSE)
        System.out.println("*** " + applicationData.getFileName() + " " + applicationData.getFileSize()); 
      Vector<ApplicationData> vector = ContentHelper.getApplicationData(contentHolder);
      for (byte b = 0; b < vector.size(); b++) {
        ApplicationData applicationData1 = vector.get(b);
        if (applicationData1.getFileName().equals(paramFile.getName())) {
          if (VERBOSE)
            System.out.println("*** Secondary content already exists, replacing"); 
          applicationData = applicationData1;
        } 
      } 
      if (VERBOSE)
        System.out.println("*** Uploading new content file " + paramFile.getAbsolutePath()); 
      if (paramBoolean) {
        applicationData = ContentServerHelper.service.updatePrimary((FormatContentHolder)contentHolder, applicationData, fileInputStream);
      } else {
        applicationData.setRole(ContentRoleType.toContentRoleType("SECONDARY"));
        applicationData = ContentServerHelper.service.updateContent(contentHolder, applicationData, fileInputStream);
        if (VERBOSE)
          System.out.println("*** New content file uploaded " + paramFile.getAbsolutePath()); 
        if (VERBOSE)
          System.out.println("*** " + applicationData.getFileName() + " " + applicationData.getFileSize()); 
      } 
      transaction.commit();
      fileInputStream.close();
      str = genDownloadHREF(paramFile.getName(), applicationData, paramContentHolder);
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return str;
  }
  
  public static void updatePdfUrl(IBAHolder paramIBAHolder, String paramString1, String paramString2, String paramString3) throws Exception {
    if (VERBOSE)
      System.out.println("*** PIABPDFUtility.updatePdfUrl: " + paramString3); 
    URLDefinition uRLDefinition = null;
    if (paramString2 == null || paramString2.equals(""))
      paramString2 = paramString1.substring(paramString1.lastIndexOf('/') + 1); 
    QuerySpec querySpec = new QuerySpec(URLDefinition.class);
    querySpec.appendWhere((WhereExpression)new SearchCondition(URLDefinition.class, "name", "=", paramString3, false));
    QueryResult queryResult = PersistenceHelper.manager.find(querySpec);
    if (queryResult.size() > 0) {
      URLValue uRLValue;
      uRLDefinition = (URLDefinition)queryResult.nextElement();
      querySpec = new QuerySpec(URLValue.class);
      querySpec.appendWhere((WhereExpression)new SearchCondition(URLValue.class, "definitionReference.key", "=", PersistenceHelper.getObjectIdentifier((Persistable)uRLDefinition)), 0);
      querySpec.appendAnd();
      querySpec.appendWhere((WhereExpression)new SearchCondition(URLValue.class, "theIBAHolderReference.key", "=", PersistenceHelper.getObjectIdentifier((Persistable)paramIBAHolder)), 0);
      queryResult = PersistenceHelper.manager.find(querySpec);
      if (VERBOSE)
        System.out.println("*** PIABPDFUtility.updatePdfUrl QueryResult for IBAValue size: " + queryResult.size()); 
      if (queryResult.size() == 0) {
        if (VERBOSE)
          System.out.println("*** Attribute didn't exist on object"); 
        if (VERBOSE)
          System.out.println("*** " + uRLDefinition); 
        if (VERBOSE)
          System.out.println("*** " + paramString1); 
        if (VERBOSE)
          System.out.println("*** " + paramString2); 
        uRLValue = URLValue.newURLValue(uRLDefinition, paramIBAHolder, paramString1, paramString2);
      } else {
        if (VERBOSE) {
          System.out.println("*** Attribute already exist on object ... updating");
          System.out.println("*** URL = " + paramString1);
          System.out.println("*** LABEL = " + paramString2);
        } 
        uRLValue = (URLValue)queryResult.nextElement();
      } 
      uRLValue.setValue(paramString1);
      uRLValue.setDescription(paramString2);
      PersistenceHelper.manager.save((Persistable)uRLValue);
    } else {
      System.out.println("ATTRIBUTE DEFINITION \"" + paramString3 + "\" DOES NOT EXIST");
    } 
  }
  
  public static File addWatermark(File paramFile, String paramString) throws Exception {
    String str1 = paramFile.getAbsolutePath();
    boolean bool = true;
    if (VERBOSE) {
      System.out.println("*** PIABPDFUtility.addWatermark only");
      System.out.println("*** PIABPDFUtility.addWatermark Processing PDF file: " + str1);
    } 
    FileInputStream fileInputStream = new FileInputStream(paramFile);
    PdfReader pdfReader = new PdfReader(fileInputStream);
    int i = pdfReader.getNumberOfPages();
    FileOutputStream fileOutputStream = new FileOutputStream(paramFile);
    PdfStamper pdfStamper = new PdfStamper(pdfReader, fileOutputStream);
    BaseFont baseFont = BaseFont.createFont("Helvetica", "Cp1252", true);
    Font font = FontFactory.getFont(PDF_WATERMARK_FONT);
    String str2 = PDF_WATERMARK_COLOR;
    float f = PDF_WATERMARK_SIZE;
    System.out.println("Color : " + str2 + " \nFont : " + PDF_WATERMARK_FONT + " \nSize : " + f + "\n Style :" + PDF_WATERMARK_STYLE);
    if (str2.equalsIgnoreCase("BLUE")) {
      font.setColor(BaseColor.BLUE);
    } else if (str2.equalsIgnoreCase("BLACK")) {
      font.setColor(BaseColor.BLACK);
    } else if (str2.equalsIgnoreCase("CYAN")) {
      font.setColor(BaseColor.CYAN);
    } else if (str2.equalsIgnoreCase("DARK_GRAY")) {
      font.setColor(BaseColor.DARK_GRAY);
    } else if (str2.equalsIgnoreCase("GRAY")) {
      font.setColor(BaseColor.GRAY);
    } else if (str2.equalsIgnoreCase("GREEN")) {
      font.setColor(BaseColor.GREEN);
    } else if (str2.equalsIgnoreCase("LIGHT_GRAY")) {
      font.setColor(BaseColor.LIGHT_GRAY);
    } else if (str2.equalsIgnoreCase("MAGENTA")) {
      font.setColor(BaseColor.MAGENTA);
    } else if (str2.equalsIgnoreCase("ORANGE")) {
      font.setColor(BaseColor.ORANGE);
    } else if (str2.equalsIgnoreCase("PINK")) {
      font.setColor(BaseColor.PINK);
    } else if (str2.equalsIgnoreCase("RED")) {
      System.out.println("***RED****");
      font.setColor(BaseColor.RED);
    } else if (str2.equalsIgnoreCase("WHITE")) {
      font.setColor(BaseColor.WHITE);
    } else if (str2.equalsIgnoreCase("YELLOW")) {
      font.setColor(BaseColor.YELLOW);
    } 
    font.setStyle(PDF_WATERMARK_STYLE);
    font.setSize(f);
    baseFont = font.getBaseFont();
    byte b = 0;
    while (b < i) {
      Rectangle rectangle = pdfReader.getPageSize(++b);
      float f2 = rectangle.getHeight();
      float f1 = rectangle.getWidth();
      if (VERBOSE)
        System.out.println("*** PIABPDFUtility.addWatermark Page size: Width-X:" + f1 + "\t Height-Y:" + f2); 
      if (VERBOSE)
        System.out.println("*** PIABPDFUtility.addWatermark Page size: getRotation:" + rectangle.getRotation() + "\tY:" + rectangle); 
      PdfContentByte pdfContentByte = pdfStamper.getUnderContent(b);
      PdfGState pdfGState = new PdfGState();
      pdfGState.setFillOpacity(0.5F);
      pdfGState.setStrokeOpacity(0.5F);
      pdfContentByte.saveState();
      pdfContentByte.setGState(pdfGState);
      pdfContentByte.beginText();
      pdfContentByte.setTextMatrix(40.0F, 40.0F);
      pdfContentByte.setFontAndSize(baseFont, f);
      PdfPTable pdfPTable = new PdfPTable(1);
      pdfPTable.setTotalWidth(100.0F);
      PdfPCell pdfPCell = new PdfPCell(new Phrase(paramString));
      pdfPCell.disableBorderSide(8);
      pdfPCell.disableBorderSide(4);
      pdfPCell.disableBorderSide(1);
      pdfPCell.disableBorderSide(2);
      pdfPTable.addCell(pdfPCell);
      System.out.println("###Coordinates of  x :" + PDF_WATERMARK_X + " , y : " + PDF_WATERMARK_Y);
      pdfPTable.writeSelectedRows(0, -1, PDF_WATERMARK_X, PDF_WATERMARK_Y, pdfStamper.getUnderContent(b));
      pdfContentByte.endText();
      pdfContentByte.restoreState();
      System.out.println("*** PIABPDFUtility.addWatermark :Content Added");
    } 
    pdfStamper.close();
    fileInputStream.close();
    fileOutputStream.close();
    File file = new File(str1);
    System.out.println("*** PIABPDFUtility.addWatermark :new path :" + file.getAbsolutePath());
    return file;
  }
  
  public static void removeDirectory(File paramFile) throws Exception {
    if (VERBOSE)
      System.out.println("*** PIABPDFUtility.removeDirectory: " + paramFile.getName()); 
    File[] arrayOfFile = paramFile.listFiles();
    boolean bool = false;
    byte b1 = 0;
    if (VERBOSE)
      System.out.print("\n"); 
    for (byte b2 = 0; b2 < arrayOfFile.length; b2++) {
      File file = arrayOfFile[b2];
      if (file.isDirectory()) {
        removeDirectory(file);
      } else if (file.exists()) {
        if (VERBOSE)
          System.out.print("*** PIABPDFUtility.removeDirectory: deleting: " + file.getAbsolutePath()); 
        bool = file.delete();
        if (VERBOSE)
          System.out.println("*** PIABPDFUtility.removeDirectory: canExecute: " + file.canExecute() + "canWrite: " + file.canWrite()); 
        while (file.exists()) {
          bool = file.delete();
          Thread.currentThread();
          Thread.sleep(1000L);
          if (b1++ >= MAX_PS_GEN)
            throw new WTException("***** ERROR: File deletion exceeded allowable time limit ****"); 
        } 
        if (VERBOSE)
          System.out.print(bool ? "...DELETED\n" : "...UNABLE TO DELETE\n"); 
      } 
    } 
    if (VERBOSE)
      System.out.print("*** PIABPDFUtility.removeDirectory: deleting: " + paramFile.getAbsolutePath()); 
    bool = paramFile.delete();
    if (VERBOSE)
      System.out.print(bool ? "...DELETED\n" : "...UNABLE TO DELETE\n"); 
  }
  
  public static File getSecondaryFile(ContentHolder paramContentHolder, File paramFile, String paramString) {
    if (VERBOSE)
      System.out.println("*** PDFUtility.getSecondaryFile()"); 
    File file1 = null;
    String str = "";
    File file2 = null;
    try {
      ContentHolder contentHolder = ContentHelper.service.getContents(paramContentHolder);
      ContentRoleType contentRoleType = ContentRoleType.toContentRoleType("SECONDARY");
      QueryResult queryResult = ContentHelper.service.getContentsByRole(paramContentHolder, contentRoleType);
      if (queryResult.size() == 0)
        System.out.println("*** PDFUtility.getSecondaryFile(): [" + paramContentHolder.getIdentity() + "] Secondary Content File NOT EXIST for processing."); 
      while (queryResult.hasMoreElements()) {
        ApplicationData applicationData = (ApplicationData)queryResult.nextElement();
        str = applicationData.getFileName();
        if (paramString.equalsIgnoreCase(str)) {
          if (checkToProcess(str)) {
            file1 = new File(paramFile, str);
            ContentServerHelper.service.writeContentStream(applicationData, file1.getAbsolutePath());
            PSFilter pSFilter = new PSFilter(str.substring(str.indexOf(".") + 1));
            System.out.println("***PSFilter..." + pSFilter);
            File[] arrayOfFile = paramFile.listFiles(pSFilter);
            byte b = 0;
            while (true) {
              if (arrayOfFile.length == 0 || !arrayOfFile[0].exists() || !arrayOfFile[0].canWrite()) {
                Thread.sleep(1000L);
                if (VERBOSE)
                  System.out.print("."); 
                if (b++ >= MAX_PS_GEN)
                  throw new WTException("***** ERROR: Primary file download exceeded allowable time limit ****"); 
                arrayOfFile = paramFile.listFiles(pSFilter);
                System.out.println("**Found file ... : " + arrayOfFile);
                continue;
              } 
              file2 = arrayOfFile[0];
              System.out.println("***Secondary File is : " + file2);
            } 
          } 
          System.out.println("*** PDFUtility.getSecondaryFile(): WTDOCUMENT [" + ((WTDocument)paramContentHolder).getNumber() + "]  Secondary Content File Extension [" + str.substring(str.indexOf(".") + 1) + "] NOT SUPPORTED for processing.");
          continue;
        } 
        System.out.println("***###Secondary Content name with same as object number not found***###");
      } 
    } catch (WTException wTException) {
      wTException.printStackTrace();
    } catch (PropertyVetoException propertyVetoException) {
      propertyVetoException.printStackTrace();
    } catch (IOException iOException) {
      iOException.printStackTrace();
    } catch (InterruptedException interruptedException) {
      interruptedException.printStackTrace();
    } 
    return file2;
  }
  
  public static boolean checkToProcess(String paramString) {
    if (VERBOSE)
      System.out.println("*** PDFUtility.checkToProcess: " + paramString); 
    StringTokenizer stringTokenizer = null;
    String str = null;
    boolean bool = (new Boolean(false)).booleanValue();
    if (!paramString.isEmpty() || paramString != null) {
      str = paramString.substring(paramString.indexOf(".") + 1);
      System.out.println("***File Extension : " + str);
      stringTokenizer = new StringTokenizer(supportedContentTypes, ",");
      while (stringTokenizer.hasMoreTokens()) {
        if (stringTokenizer.nextToken().equalsIgnoreCase(str))
          bool = true; 
      } 
    } 
    System.out.println("***File Extension is supported..." + bool);
    return bool;
  }
  
  public static File executeCommand(File paramFile) {
    File file1 = null;
    File file2 = paramFile.getParentFile();
    try {
      PSFilter pSFilter = new PSFilter("pdf");
      System.out.println("***executeCommand : " + pSFilter);
      File[] arrayOfFile = file2.listFiles(pSFilter);
      System.out.println("List size : " + arrayOfFile.length);
      byte b = 0;
      while (true) {
        if (arrayOfFile.length == 0 || !arrayOfFile[0].exists() || !arrayOfFile[0].canWrite()) {
          Thread.sleep(1000L);
          if (VERBOSE)
            System.out.print("."); 
          if (b++ >= MAX_PS_GEN)
            throw new WTException("***** ERROR: PDF download exceeded allowable time limit ****"); 
          arrayOfFile = file2.listFiles(pSFilter);
          System.out.println("***File found .. " + arrayOfFile);
          continue;
        } 
        file1 = arrayOfFile[0];
        System.out.println("***PDF FIles Write Access : " + file1.canWrite());
        return file1;
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return file1;
  }
  
  public static String genDownloadHREF(String paramString, ApplicationData paramApplicationData, ContentHolder paramContentHolder) throws Exception {
    if (VERBOSE)
      System.out.println("*** PIABPDFUtility.genDownloadHREF\n*** Creating href string for " + paramContentHolder); 
    URLFactory uRLFactory = new URLFactory();
    return uRLFactory.getHREF("/servlet/AttachmentsDownloadDirectionServlet?oid=OR:" + PersistenceHelper.getObjectIdentifier((Persistable)paramContentHolder) + "&cioids=" + PersistenceHelper.getObjectIdentifier((Persistable)paramApplicationData));
  }
  
  public static synchronized File genUniqueFile(String paramString1, String paramString2, String paramString3) {
    if (VERBOSE)
      System.out.println("*** PDFUtility.genUniqueFile: " + paramString3); 
    Random random = new Random();
    File file = new File(paramString1, paramString2 + "_" + random.nextInt(5000) + "_" + paramString3);
    return file.exists() ? genUniqueFile(paramString1, paramString2, paramString3) : file;
  }
  
  static {
    try {
      WTProperties wTProperties = WTProperties.getLocalProperties();
      VERBOSE = wTProperties.getProperty("ext.piab.pdfgen.verbose", true);
      WTTEMP = wTProperties.getProperty("wt.temp");
      WT_HOME = wTProperties.getProperty("wt.home");
      PDF_TEXT = wTProperties.getProperty("ext.piab.pdf_watermark_text");
      PDF_WATERMARK_FONT = wTProperties.getProperty("ext.piab.pdf_watermark_font");
      PDF_WATERMARK_STYLE = wTProperties.getProperty("ext.piab.pdf_watermark_style");
      PDF_WATERMARK_SIZE = wTProperties.getProperty("ext.piab.pdf_watermark_size", 16);
      PDF_WATERMARK_COLOR = wTProperties.getProperty("ext.piab.pdf_watermark_color");
      PDF_WATERMARK_X = wTProperties.getProperty("ext.piab.pdf_watermark_x_position", 60);
      PDF_WATERMARK_Y = wTProperties.getProperty("ext.piab.pdf_watermark_y_position", 60);
      DEL_TEMP = wTProperties.getProperty("ext.piab.del_temp_dir", false);
      TEMP_DIR = wTProperties.getProperty("ext.piab.temp_dir", WTTEMP);
      MAX_PS_GEN = Integer.parseInt(wTProperties.getProperty("ext.piab.max_ps_gen", "300"));
      supportedContentTypes = wTProperties.getProperty("ext.piab.contentsupports", "PDF");
      PDF_URL_IBA_NAME = wTProperties.getProperty("ext.piab.pdf_iba_name", "pdfURL");
    } catch (Throwable throwable) {
      System.err.println("Error initializing ");
      throwable.printStackTrace(System.err);
      throw new ExceptionInInitializerError(throwable);
    } 
  }
  
  private static class PSFilter implements FilenameFilter {
    String ext;
    
    public PSFilter(String param1String) {
      this.ext = "." + param1String;
    }
    
    public boolean accept(File param1File, String param1String) {
      return param1String.endsWith(this.ext);
    }
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\pdf\PDFUtility.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */