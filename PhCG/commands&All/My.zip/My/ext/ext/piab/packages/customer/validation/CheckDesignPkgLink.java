package ext.piab.packages.customer.validation;

import com.ptc.windchill.wp.WorkPackage;
import ext.piab.common.util.PropertyforPIAB;
import ext.piab.packages.common.util.ProcessPackage;
import ext.piab.packages.customer.resource.CustomerResource;
import ext.piab.packages.customer.util.DesignProcessHandler;
import java.util.Enumeration;
import java.util.Vector;
import wt.method.RemoteAccess;
import wt.project.Role;
import wt.team.Team;
import wt.team.TeamHelper;
import wt.team.TeamManaged;
import wt.util.WTException;

public class CheckDesignPkgLink implements RemoteAccess {
  private static final boolean VERBOSE = PropertyforPIAB.VERBOSE;
  
  private static final String CUSTOMER_RESOURCE = CustomerResource.class.getName();
  
  public static void designpkgExist(WorkPackage paramWorkPackage, String paramString1, String paramString2) throws Exception {
    if (VERBOSE)
      System.out.println("*** CheckDesignPkgLink.designpkgExist(" + paramWorkPackage.getName() + ")"); 
    WorkPackage workPackage = DesignProcessHandler.getDesignPkg(paramString1);
    if (workPackage != null) {
      workPackage = DesignProcessHandler.exactPkg(workPackage, paramString2);
      if (workPackage == null) {
        if (VERBOSE)
          System.out.println("Design Package revision not exist"); 
        Object[] arrayOfObject = { paramString2, paramString1 };
        throw new WTException(CUSTOMER_RESOURCE, "1", arrayOfObject);
      } 
      boolean bool = ProcessPackage.isLatestPackage(workPackage);
      if (!bool) {
        if (VERBOSE)
          System.out.println("Design Package is not latest"); 
        Object[] arrayOfObject = { paramString2, paramString1 };
        throw new WTException(CUSTOMER_RESOURCE, "6", arrayOfObject);
      } 
    } else {
      if (VERBOSE)
        System.out.println("Design Package not exist"); 
      Object[] arrayOfObject = { paramString1 };
      throw new WTException(CUSTOMER_RESOURCE, "0", arrayOfObject);
    } 
  }
  
  //public static void checkIfRoleHasUsers(Vector<String>paramVector, WorkPackage paramWorkPackage) throws WTException {
  //updated by cts
  public static void checkIfRoleHasUsers(Vector<String>paramVector, WorkPackage paramWorkPackage) throws WTException {
    if (VERBOSE)
      System.out.println("***checkIfRoleHasUsers()"); 
    //str1 = "";
    StringBuilder stringBuilder = new StringBuilder();
    boolean bool = false;
    for (String str1 : paramVector) {
      Role role = Role.toRole(str1);
      Team team1 = TeamHelper.service.getTeam((TeamManaged)paramWorkPackage);
      Team team2 = team1;
      Enumeration enumeration = team2.getPrincipalTarget(role);
      if (VERBOSE)
        System.out.println("number of users: " + role.getStringValue()); 
      if (enumeration.hasMoreElements()) {
        if (VERBOSE)
          System.out.println("users exist" + role.getStringValue()); 
        bool = true;
        break;
      } 
      stringBuilder.append(str1 + ",");
      bool = false;
    } 
    String str2 = stringBuilder.toString();
    if (!bool) {
      str2 = str2.substring(0, str2.lastIndexOf(","));
      if (VERBOSE)
        System.out.println("no users"); 
      Object[] arrayOfObject = { str2 };
      throw new WTException(CUSTOMER_RESOURCE, "7", arrayOfObject);
    } 
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\packages\customer\validation\CheckDesignPkgLink.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */