package ext.piab.packages.common.resource;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("ext.piab.packages.common.resource.PackagesResource")
public final class PackagesResource extends WTListResourceBundle {
  @RBEntry("The objects with Number \n[{0}]\ninside the package [{1}]are Checked-Out.\nPlease checkin the Objects and then complete the task.!")
  public static final String CHECKED_OUT_OBJECTS = "0";
  
  @RBEntry("The objects with Number \n{0}\n inside the package {1} are Outdated Revisions of those objects.\n You have to Revise this Package to Proceed")
  public static final String OUTDATED_REVISION_1 = "1";
  
  @RBEntry("The objects with Number \n{0}\n inside the package {1} are Outdated Revisions of those objects.\n Please select the latest Revisions to Proceed")
  public static final String OUTDATED_REVISION_2 = "2";
  
  @RBEntry("wt.vc.VersionIdentifier")
  public static final String VERSION_ID_CLASS = "3";
  
  @RBEntry("Modified From Workflow")
  public static final String REV_PKG_DESC = "4";
  
  @RBEntry("RECENT_UPDATES_TABLE")
  public static final String RECENT_UPDATES_TABLE = "5";
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\packages\common\resource\PackagesResource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */