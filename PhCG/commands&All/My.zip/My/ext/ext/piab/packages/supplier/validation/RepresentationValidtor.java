package ext.piab.packages.supplier.validation;

import com.ptc.windchill.wp.WorkPackage;
import com.ptc.wvs.common.ui.VisualizationHelper;
import ext.piab.common.util.PropertyforPIAB;
import ext.piab.packages.common.util.PackageContentList;
import ext.piab.packages.supplier.resource.SupplierResource;
import wt.epm.EPMDocument;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.fc.collections.WTSet;
import wt.util.WTException;

public class RepresentationValidtor {
  private static final boolean VERBOSE = PropertyforPIAB.VERBOSE;
  
  private static final boolean CHECK_REPRESENTATION = PropertyforPIAB.CHECK_REPRESENTATION;
  
  private static final String SUPPLIER_RESOURCE = SupplierResource.class.getName();
  
  public static void hasRepresentation(WorkPackage paramWorkPackage) throws Exception {
    if (VERBOSE)
      System.out.println("***RepresentationValidtor.hasRepresentation()"); 
    StringBuilder stringBuilder = new StringBuilder();
    VisualizationHelper visualizationHelper = VisualizationHelper.newVisualizationHelper();
    if (CHECK_REPRESENTATION) {
      WTSet wTSet = PackageContentList.filterbyIncludeAll(paramWorkPackage);
      System.out.println("***Size of Package items - " + wTSet.size());
      Object[] arrayOfObject = wTSet.toArray();
      for (byte b = 0; b < arrayOfObject.length; b++) {
        ObjectReference objectReference = (ObjectReference)arrayOfObject[b];
        if (objectReference.getObject() instanceof EPMDocument) {
          EPMDocument ePMDocument = (EPMDocument)objectReference.getObject();
          QueryResult queryResult = visualizationHelper.getRepresentations((Persistable)ePMDocument);
          System.out.println("*** SIZE :" + ePMDocument.getNumber() + "--" + queryResult.size());
          if (!queryResult.hasMoreElements())
            stringBuilder.append("\nEPM: (" + ePMDocument.getNumber() + ") "); 
        } 
      } 
      String str = stringBuilder.toString();
      if (!str.isEmpty()) {
        System.out.println("***Objects in the [" + paramWorkPackage.getName() + "] have no representations");
        Object[] arrayOfObject1 = { str, paramWorkPackage.getName() };
        throw new WTException(SUPPLIER_RESOURCE, "0", arrayOfObject1);
      } 
    } 
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\packages\supplier\validation\RepresentationValidtor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */