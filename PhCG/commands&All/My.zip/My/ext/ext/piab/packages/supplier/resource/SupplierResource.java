package ext.piab.packages.supplier.resource;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("ext.piab.packages.supplier.resource.SupplierResource")
public final class SupplierResource extends WTListResourceBundle {
  @RBEntry("The EPM with Number\n[{0}]\n inside the package [{1}] does not have any representations.\n Please add representations to proceed.!")
  public static final String NO_REPRESENTATION = "0";
  
  @RBEntry("The team for the Project [{0}]  does not have [{1}] roles.\n Please add these roles to the project team to proceed.!")
  public static final String PROJECT_ROLES = "1";
  
  @RBEntry("There are no users assigned to [{0}] role in the team of project [{1}].\n Please add users to proceed.!")
  public static final String NO_USERS_IN_ROLE = "2";
  
  @RBEntry("New Package Delivery")
  public static final String DELIVERY_REC_SUBJ = "3";
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\packages\supplier\resource\SupplierResource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */