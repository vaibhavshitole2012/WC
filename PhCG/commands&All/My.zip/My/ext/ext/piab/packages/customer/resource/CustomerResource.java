package ext.piab.packages.customer.resource;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("ext.piab.packages.customer.resource.CustomerResource")
public final class CustomerResource extends WTListResourceBundle {
  @RBEntry("The Design Package with Number [{0}] does not exist.\nPlease enter the correct Design Package Number to complete the task. ")
  public static final String INCORRECT_PKG_NUMBER = "0";
  
  @RBEntry("Revision [{0}] does not exist for the Design Package [{1}]")
  public static final String INCORRECT_PKG_REVISION = "1";
  
  @RBEntry("Customer Verification")
  public static final String DESIGNPKG_CUSTVERIFY_TASKNAME = "2";
  
  @RBEntry("Customer Validation")
  public static final String DESIGNPKG_CUSTVALID_TASKNAME = "3";
  
  @RBEntry("Verified")
  public static final String DESIGNPKG_CUSTVERIFY_EVENT = "4";
  
  @RBEntry("Approve")
  public static final String DESIGNPKG_CUSTVALID_EVENT = "5";
  
  @RBEntry("Revision [{0}] is not the latest revision for the Design Package [{1}]")
  public static final String NON_LATEST_PKG = "6";
  
  @RBEntry("Please add users to any one of these roles [{0}].")
  public static final String NO_USERS = "7";
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\packages\customer\resource\CustomerResource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */