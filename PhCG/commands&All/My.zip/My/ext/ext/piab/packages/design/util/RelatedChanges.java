package ext.piab.packages.design.util;

import ext.piab.common.util.PropertyforPIAB;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import wt.change2.ChangeHelper2;
import wt.change2.Changeable2;
import wt.change2.WTChangeActivity2;
import wt.change2.WTChangeRequest2;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.org.WTPrincipal;
import wt.org.WTPrincipalReference;
import wt.project.Role;
import wt.team.Team;
import wt.team.TeamHelper;
import wt.team.TeamManaged;

public class RelatedChanges {
  private static final boolean VERBOSE = PropertyforPIAB.VERBOSE;
  
  private static final String CA_ROLES = PropertyforPIAB.CA_ROLES;
  
  private static final String LC_APPROVED = PropertyforPIAB.LCSTATE_APPROVED;
  
  private static final String LC_INANALYSIS = PropertyforPIAB.LCSTATE_IN_ANALYSIS;
  
  private static final String LC_UNDERREVIEW = PropertyforPIAB.LCSTATE_UNDERREVIEW;
  
  public static HashMap getRelatedChanges(Persistable paramPersistable, HashMap<WTPrincipal, HashMap<Object, Object>> paramHashMap) {
    if (VERBOSE)
      System.out.println("*** RelatedChanges.getRelatedChanges[" + paramPersistable.getIdentity() + "]"); 
    HashMap<Object, Object> hashMap = null;
    ArrayList<Changeable2> arrayList = null;
    try {
      Changeable2 changeable2 = (Changeable2)paramPersistable;
      QueryResult queryResult = ChangeHelper2.service.getRelevantChangeRequests(changeable2);
      if (VERBOSE)
        System.out.println("****Change Request Size: " + queryResult.size()); 
      while (queryResult.hasMoreElements()) {
        WTChangeRequest2 wTChangeRequest2 = (WTChangeRequest2)queryResult.nextElement();
        String str = wTChangeRequest2.getState().toString();
        if (VERBOSE)
          System.out.println("***" + wTChangeRequest2.getNumber() + " [" + str + "]"); 
        if (str.equalsIgnoreCase(LC_INANALYSIS) || str.equalsIgnoreCase(LC_APPROVED)) {
          WTPrincipal wTPrincipal = wTChangeRequest2.getCreator().getPrincipal();
          hashMap = (HashMap)paramHashMap.get(wTPrincipal);
          if (hashMap == null) {
            if (VERBOSE)
              System.out.println("*****Adding Object: " + changeable2); 
            hashMap = new HashMap<>();
            arrayList = new ArrayList();
            arrayList.add(changeable2);
            hashMap.put(wTChangeRequest2, arrayList);
          } else {
            arrayList = (ArrayList<Changeable2>)hashMap.get(wTChangeRequest2);
            if (arrayList == null)
              arrayList = new ArrayList<>(); 
            arrayList.add(changeable2);
            hashMap.put(wTChangeRequest2, arrayList);
          } 
          paramHashMap.put(wTPrincipal, hashMap);
        } 
      } 
      queryResult = ChangeHelper2.service.getChangingChangeActivities(changeable2);
      if (VERBOSE)
        System.out.println("***Change Activity Size: " + queryResult.size()); 
      while (queryResult.hasMoreElements()) {
        WTChangeActivity2 wTChangeActivity2 = (WTChangeActivity2)queryResult.nextElement();
        String str = wTChangeActivity2.getState().toString();
        if (VERBOSE)
          System.out.println("***Activity Number: " + wTChangeActivity2.getNumber() + " [" + str + "]"); 
        if (str.equalsIgnoreCase(LC_UNDERREVIEW) || str.equalsIgnoreCase(LC_APPROVED) || str.equalsIgnoreCase("IMPLEMENTATION")) {
          Team team = TeamHelper.service.getTeam((TeamManaged)wTChangeActivity2);
          String[] arrayOfString = CA_ROLES.split(",");
          for (byte b = 0; b < arrayOfString.length; b++) {
            if (VERBOSE)
              System.out.println("splitted role" + arrayOfString[b]); 
            Enumeration<WTPrincipalReference> enumeration = team.getPrincipalTarget(Role.toRole(arrayOfString[b]));
            while (enumeration.hasMoreElements()) {
              WTPrincipalReference wTPrincipalReference = enumeration.nextElement();
              WTPrincipal wTPrincipal = wTPrincipalReference.getPrincipal();
              hashMap = paramHashMap.get(wTPrincipal);
              if (hashMap == null) {
                hashMap = new HashMap<>();
                arrayList = new ArrayList<>();
                arrayList.add(changeable2);
                hashMap.put(wTChangeActivity2, arrayList);
              } else {
                arrayList = (ArrayList<Changeable2>)hashMap.get(wTChangeActivity2);
                if (arrayList == null)
                  arrayList = new ArrayList<>(); 
                arrayList.add(changeable2);
                hashMap.put(wTChangeActivity2, arrayList);
              } 
              paramHashMap.put(wTPrincipal, hashMap);
            } 
          } 
        } 
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
    } finally {}
    return paramHashMap;
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\packages\desig\\util\RelatedChanges.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */