package ext.piab.packages.common.util;

import com.ptc.netmarkets.wp.WPExtensionSpecsHelper;
import com.ptc.windchill.wp.AbstractWorkPackage;
import com.ptc.windchill.wp.AbstractWorkPackageMaster;
import com.ptc.windchill.wp.WPHelper;
import com.ptc.windchill.wp.WorkPackage;
import com.ptc.windchill.wp.delivery.DeliveryHelper;
import com.ptc.windchill.wp.delivery.DeliveryManifestType;
import com.ptc.windchill.wp.delivery.DeliveryOptionType;
import com.ptc.windchill.wp.delivery.DeliveryRecord;
import com.ptc.windchill.wp.delivery.DeliveryStatusType;
import com.ptc.windchill.wp.delivery.StandardDeliveryService;
import ext.piab.common.util.PropertyforPIAB;
import ext.piab.common.util.ReviseUtility;
import ext.piab.packages.common.resource.PackagesResource;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Enumeration;
import wt.content.ApplicationData;
import wt.content.ContentHelper;
import wt.content.ContentHolder;
import wt.content.ContentItem;
import wt.content.ContentServerHelper;
import wt.enterprise.RevisionControlled;
import wt.facade.persistedcollection.PersistedCollectableHolder;
import wt.facade.persistedcollection.PersistedCollectionHelper;
import wt.facade.persistedcollection.PersistedCollectionHolder;
import wt.facade.persistedcollection.PersistedCollectionRecipe;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.fc.WTObject;
import wt.fc.WTReference;
import wt.fc.collections.WTArrayList;
import wt.fc.collections.WTCollection;
import wt.fc.collections.WTSet;
import wt.fc.collections.WTValuedHashMap;
import wt.fc.collections.WTValuedMap;
import wt.iba.value.IBAHolder;
import wt.iba.value.service.IBAValueHelper;
import wt.inf.sharing.DataSharingHelper;
import wt.inf.sharing.SharedContainerMap;
import wt.lifecycle.LifeCycleHelper;
import wt.lifecycle.LifeCycleManaged;
import wt.lifecycle.State;
import wt.org.WTPrincipalReference;
import wt.ownership.Ownership;
import wt.recent.RecentlyVisitedHelper;
import wt.series.MultilevelSeries;
import wt.type.TypedUtility;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.WTPropertyVetoException;
import wt.vc.Iterated;
import wt.vc.IterationIdentifier;
import wt.vc.VersionControlHelper;
import wt.vc.VersionIdentifier;
import wt.vc.Versioned;

public class ProcessPackage {
  private static boolean VERBOSE = PropertyforPIAB.VERBOSE;
  
  private static final String SUPPLIER_PACKAGE_TYPE_NAME = PropertyforPIAB.SUPPLIER_PACKAGE_TYPE_NAME;
  
  private static final String PACKAGE_FILTERSPEC = PropertyforPIAB.PACKAGE_FILTERSPEC;
  
  private static final String DESIGN_PACKAGE_TYPE_NAME = PropertyforPIAB.DESIGN_PACKAGE_TYPE_NAME;
  
  private static final String LCSTATE_CANCELLED = PropertyforPIAB.LCSTATE_CANCELLED;
  
  private static final String PKG_RESOURCE = PackagesResource.class.getName();
  
  private static String VERSION_ID_CLASS = WTMessage.getLocalizedMessage(PKG_RESOURCE, "3");
  
  private static String REV_PKG_DESC = WTMessage.getLocalizedMessage(PKG_RESOURCE, "4");
  
  private static String RECENT_UPDATES_TABLE = WTMessage.getLocalizedMessage(PKG_RESOURCE, "5");
  
  public static WorkPackage refreshPkg(WorkPackage paramWorkPackage) throws Exception {
    if (VERBOSE)
      System.out.println("***** ProcessPackage.refreshPkg(" + paramWorkPackage.getName() + ")-locked " + paramWorkPackage.isLocked()); 
    if (paramWorkPackage.isLocked()) {
      paramWorkPackage = (WorkPackage)WPHelper.service.unLock((AbstractWorkPackage)paramWorkPackage);
      if (VERBOSE)
        System.out.println("*****Package Lock " + paramWorkPackage.isLocked()); 
      paramWorkPackage = (WorkPackage)WPHelper.service.refresh((AbstractWorkPackage)paramWorkPackage);
      paramWorkPackage = lockAndExport(paramWorkPackage);
    } else {
      paramWorkPackage = (WorkPackage)WPHelper.service.refresh((AbstractWorkPackage)paramWorkPackage);
      paramWorkPackage = (WorkPackage)PersistenceHelper.manager.refresh((Persistable)paramWorkPackage);
    } 
    if (VERBOSE)
      System.out.println("*****Package Refreshed and locked " + paramWorkPackage.isLocked()); 
    return paramWorkPackage;
  }
  
  public static WorkPackage setpkgNewVersion(WorkPackage paramWorkPackage, String paramString) throws Exception {
    if (VERBOSE)
      System.out.println("ProcessPackage.setpkgNewVersion()" + paramWorkPackage.getName()); 
    WorkPackage workPackage = null;
    if (VersionControlHelper.service.isRevisable((Versioned)paramWorkPackage, true)) {
      if (paramString != null) {
        MultilevelSeries multilevelSeries = MultilevelSeries.newMultilevelSeries(VERSION_ID_CLASS, paramString);
        VersionIdentifier versionIdentifier = VersionIdentifier.newVersionIdentifier(multilevelSeries);
        IterationIdentifier iterationIdentifier = VersionControlHelper.firstIterationId((Iterated)paramWorkPackage);
        if (VERBOSE)
          System.out.println("IterationIdentifier  value" + iterationIdentifier.getValue()); 
        workPackage = (WorkPackage)VersionControlHelper.service.newVersion((Versioned)paramWorkPackage, versionIdentifier, iterationIdentifier);
        if (VERBOSE)
          System.out.println("Finished revise-" + workPackage); 
      } else {
        workPackage = (WorkPackage)VersionControlHelper.service.newVersion((Versioned)paramWorkPackage);
        if (VERBOSE)
          System.out.println("Finished revise- " + workPackage); 
      } 
      String str = workPackage.getName() + "-DONTDELETEIBA";
      workPackage.setName(str);
      workPackage.clearNonWPAttributesForRevise();
      workPackage.setLocked(false);
      workPackage.setDescription(REV_PKG_DESC);
      if (VERBOSE)
        System.out.println(" Is Revised PACKAGE    " + workPackage.isLocked()); 
      workPackage = (WorkPackage)WPHelper.service.save((AbstractWorkPackage)workPackage);
      Ownership ownership = Ownership.newOwnership();
      WTPrincipalReference wTPrincipalReference = paramWorkPackage.getOwnership().getOwner();
      if (VERBOSE)
        System.out.println(" OWNERSHIP:" + paramWorkPackage.getOwnership().getOwner().getDisplayName()); 
      if (VERBOSE)
        System.out.println(" CREATOR:" + paramWorkPackage.getCreator().getDisplayName()); 
      workPackage = removeZip(workPackage);
      Enumeration<DeliveryRecord> enumeration = DeliveryHelper.getService().getDeliveriesForWorkPackage((AbstractWorkPackage)paramWorkPackage);
      while (enumeration.hasMoreElements()) {
        DeliveryRecord deliveryRecord1 = enumeration.nextElement();
        DeliveryRecord deliveryRecord2 = copyDeliveryToPackage(deliveryRecord1, (AbstractWorkPackage)workPackage);
        deliveryRecord2 = DeliveryHelper.getService().save(deliveryRecord2);
        copySoftAttributes((IBAHolder)deliveryRecord2, (IBAHolder)deliveryRecord1);
      } 
      workPackage = transferSeeds(paramWorkPackage, workPackage);
      workPackage = (WorkPackage)PersistenceHelper.manager.refresh((Persistable)workPackage);
      RecentlyVisitedHelper.service.addCustomStackObject((WTObject)workPackage, RECENT_UPDATES_TABLE);
      if (VERBOSE)
        System.out.println(" Revised Package is " + workPackage.getVersionInfo().getIdentifier().getValue()); 
    } else {
      throw new Exception("Package " + paramWorkPackage + " cannot be revised ");
    } 
    return workPackage;
  }
  
  private static WorkPackage transferSeeds(WorkPackage paramWorkPackage1, WorkPackage paramWorkPackage2) throws WTException {
    System.out.println("Inside Transfer seeds method --------------- ");
    WTSet wTSet1 = PersistedCollectionHelper.service.getSeeds((PersistedCollectionHolder)paramWorkPackage1);
    System.out.println("OldCollection == " + wTSet1.size());
    if (paramWorkPackage2.isLocked()) {
      if (VERBOSE)
        System.out.println("***wpkg is Locked" + paramWorkPackage2.isLocked()); 
      paramWorkPackage2 = (WorkPackage)WPHelper.service.unLock((AbstractWorkPackage)paramWorkPackage2);
    } 
    paramWorkPackage2 = (WorkPackage)PersistedCollectionHelper.service.checkout((PersistedCollectionHolder)paramWorkPackage2);
    PersistedCollectionHelper.service.addSeeds((PersistedCollectionHolder)paramWorkPackage2, (WTCollection)wTSet1);
    PersistedCollectionRecipe persistedCollectionRecipe = PersistedCollectionHelper.service.getRecipe((PersistedCollectableHolder)paramWorkPackage1);
    PersistedCollectionHelper.service.setRecipe((PersistedCollectableHolder)paramWorkPackage2, persistedCollectionRecipe);
    paramWorkPackage2 = (WorkPackage)WPHelper.service.refresh((AbstractWorkPackage)paramWorkPackage2);
    paramWorkPackage2 = (WorkPackage)PersistedCollectionHelper.service.checkin((PersistedCollectionHolder)paramWorkPackage2);
    WTSet wTSet2 = PersistedCollectionHelper.service.getSeeds((PersistedCollectionHolder)paramWorkPackage2);
    System.out.println("newCollection == " + wTSet2.size());
    return paramWorkPackage2;
  }
  
  private static void copySoftAttributes(IBAHolder paramIBAHolder1, IBAHolder paramIBAHolder2) throws WTException, WTException {
    try {
      WTValuedHashMap wTValuedHashMap = new WTValuedHashMap();
      wTValuedHashMap.put(paramIBAHolder1, paramIBAHolder2);
      IBAValueHelper.service.copyAttributes((WTValuedMap)wTValuedHashMap, false);
    } catch (RemoteException remoteException) {
      throw new WTException(remoteException);
    } 
  }
  
  private static WorkPackage removeZip(WorkPackage paramWorkPackage) throws Exception {
    paramWorkPackage = (WorkPackage)ContentHelper.service.getContents((ContentHolder)paramWorkPackage);
    ApplicationData applicationData = (ApplicationData)paramWorkPackage.getPrimary();
    if (applicationData != null)
      ContentServerHelper.service.deleteContent((ContentHolder)paramWorkPackage, (ContentItem)applicationData); 
    return paramWorkPackage;
  }
  
  private static DeliveryRecord copyDeliveryToPackage(DeliveryRecord paramDeliveryRecord, AbstractWorkPackage paramAbstractWorkPackage) throws WTPropertyVetoException, WTException {
    DeliveryRecord deliveryRecord = (DeliveryRecord)paramDeliveryRecord.duplicate();
    deliveryRecord.setMyPackage(paramAbstractWorkPackage);
    deliveryRecord.setContainerReference(paramAbstractWorkPackage.getContainerReference());
    deliveryRecord.setNumber(null);
    deliveryRecord.setTimeSent(null);
    deliveryRecord.setTimeReceived(null);
    deliveryRecord.setTimeAccepted(null);
    deliveryRecord.setSentBy(null);
    deliveryRecord.setReceivedBy(null);
    deliveryRecord.setAcceptedBy(null);
    deliveryRecord.setStatus(DeliveryStatusType.UNDELIVERED);
    deliveryRecord.setRecipientComments(null);
    deliveryRecord.setBase(null);
    deliveryRecord.setDeliveryOption(DeliveryOptionType.UNKNOWN);
    deliveryRecord.setDeliveryManifest(DeliveryManifestType.UNKNOWN);
    return deliveryRecord;
  }
  
  public static WorkPackage lockAndExport(WorkPackage paramWorkPackage) throws Exception {
    if (VERBOSE)
      System.out.println("*** ProcessPackage.lockAndExport(" + paramWorkPackage.getName() + ")"); 
    try {
      String str = null;
      if (TypedUtility.getTypeIdentifier(paramWorkPackage).toString().endsWith(SUPPLIER_PACKAGE_TYPE_NAME)) {
        if (PACKAGE_FILTERSPEC != null || PACKAGE_FILTERSPEC != "") {
          str = PACKAGE_FILTERSPEC;
        } else {
          str = "ALL";
        } 
        if (VERBOSE)
          System.out.println("***PACKAGE_FILTERSPEC [" + PACKAGE_FILTERSPEC + "]"); 
        str = PACKAGE_FILTERSPEC.replaceAll(",", "#");
        if (!str.equalsIgnoreCase("ALL")) {
          str = str + "#";
          if (VERBOSE)
            System.out.println("***docFilters ADDED # [" + str + "]"); 
        } 
        String str1 = WPExtensionSpecsHelper.makeFormatFilterSpecFromParams("Y", str);
        paramWorkPackage = (WorkPackage)WPHelper.service.lock((AbstractWorkPackage)paramWorkPackage, str1);
      } else {
        paramWorkPackage = (WorkPackage)WPHelper.service.lock((AbstractWorkPackage)paramWorkPackage, paramWorkPackage.getFilterSpec());
      } 
      if (VERBOSE)
        System.out.println("***Package is locked sucessfully!  [" + paramWorkPackage.isLocked() + "] "); 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return paramWorkPackage;
  }
  
  public static boolean cancelPredecessor(WorkPackage paramWorkPackage) throws Exception {
    if (VERBOSE)
      System.out.println("*** ProcessPackage.cancelPredecessor(" + paramWorkPackage.getName() + "-" + paramWorkPackage.getVersionIdentifier().getValue()); 
    boolean bool = false;
    try {
      QueryResult queryResult = VersionControlHelper.service.allVersionsOf((Versioned)paramWorkPackage);
      if (VERBOSE)
        System.out.println("*** Predecessor  packages Size :" + queryResult.size()); 
      while (queryResult.hasMoreElements()) {
        WorkPackage workPackage = (WorkPackage)queryResult.nextElement();
        if (VERBOSE)
          System.out.println("***Predecessor  package number" + workPackage.getNumber() + "name " + workPackage.getName() + " - " + workPackage.getVersionIdentifier().getValue()); 
        if (!workPackage.equals(paramWorkPackage)) {
          if (TypedUtility.getTypeIdentifier(workPackage).toString().endsWith(DESIGN_PACKAGE_TYPE_NAME)) {
            workPackage = (WorkPackage)LifeCycleHelper.service.setLifeCycleState((LifeCycleManaged)workPackage, State.toState(LCSTATE_CANCELLED));
            workPackage = (WorkPackage)PersistenceHelper.manager.save((Persistable)workPackage);
            if (VERBOSE)
              System.out.println("***Predecessor  package state" + workPackage.getState().toString()); 
          } 
          if (TypedUtility.getTypeIdentifier(workPackage).toString().endsWith(SUPPLIER_PACKAGE_TYPE_NAME)) {
            workPackage = (WorkPackage)LifeCycleHelper.service.setLifeCycleState((LifeCycleManaged)workPackage, State.toState(LCSTATE_CANCELLED));
            workPackage = (WorkPackage)PersistenceHelper.manager.save((Persistable)workPackage);
            if (VERBOSE)
              System.out.println("***Predecessor  package state" + workPackage.getState().toString()); 
            Enumeration<DeliveryRecord> enumeration = StandardDeliveryService.newStandardDeliveryService().getDeliveriesForWorkPackage((AbstractWorkPackage)workPackage);
            WTArrayList wTArrayList = new WTArrayList();
            while (enumeration.hasMoreElements()) {
              DeliveryRecord deliveryRecord = enumeration.nextElement();
              if (VERBOSE)
                System.out.println("*** drec " + deliveryRecord.getName() + "-" + deliveryRecord.getNumber()); 
              wTArrayList.add((Persistable)deliveryRecord);
            } 
            if (VERBOSE)
              System.out.println("*** Number of Delivery Records " + wTArrayList.size()); 
            WTCollection wTCollection = DataSharingHelper.service.getSharedContainerMaps((WTCollection)wTArrayList);
            if (VERBOSE)
              System.out.println("*** Number of Delivery Records Shared" + wTCollection.size() + "SharedContainerMaps " + wTCollection); 
            for (ObjectReference objectReference : wTCollection) {
              SharedContainerMap sharedContainerMap = (SharedContainerMap)objectReference.getObject();
              DataSharingHelper.service.removeShare(sharedContainerMap);
              if (VERBOSE)
                System.out.println("*** MAP share removed "); 
            } 
          } 
          bool = true;
        } 
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return bool;
  }
  
  public static WorkPackage replaceSeeds(WorkPackage paramWorkPackage) throws Exception {
    if (VERBOSE)
      System.out.println("***ProcessPackage.replaceSeeds()"); 
    WTSet wTSet = PackageContentList.getinitiallyselected(paramWorkPackage);
    if (wTSet != null) {
      Object[] arrayOfObject = wTSet.toArray();
      for (byte b = 0; b < arrayOfObject.length; b++) {
        ObjectReference objectReference = (ObjectReference)arrayOfObject[b];
        WTObject wTObject1 = (WTObject)objectReference.getObject();
        WTObject wTObject2 = ReviseUtility.getLatestRevision(wTObject1);
        if (VERBOSE)
          System.out.println("***Latest Iteration : " + ((RevisionControlled)wTObject2).isLatestIteration()); 
        if (!wTObject2.equals(wTObject1))
          paramWorkPackage = replace(paramWorkPackage, wTObject1, wTObject2); 
      } 
    } 
    return paramWorkPackage;
  }
  
  private static WorkPackage replace(WorkPackage paramWorkPackage, WTObject paramWTObject1, WTObject paramWTObject2) throws Exception {
    if (VERBOSE)
      System.out.println("***ProcessPackage.replace()"); 
    if (paramWorkPackage.isLocked()) {
      if (VERBOSE)
        System.out.println("***wpkg is Locked" + paramWorkPackage.isLocked()); 
      paramWorkPackage = (WorkPackage)WPHelper.service.unLock((AbstractWorkPackage)paramWorkPackage);
      paramWorkPackage = replace(paramWorkPackage, paramWTObject1, paramWTObject2);
      paramWorkPackage = lockAndExport(paramWorkPackage);
    } else {
      paramWorkPackage = (WorkPackage)PersistedCollectionHelper.service.checkout((PersistedCollectionHolder)paramWorkPackage);
      PersistedCollectionHelper.service.removeSeed((PersistedCollectionHolder)paramWorkPackage, (Persistable)paramWTObject1);
      PersistedCollectionHelper.service.addSeed((PersistedCollectionHolder)paramWorkPackage, (Persistable)paramWTObject2);
      paramWorkPackage = (WorkPackage)PersistedCollectionHelper.service.checkin((PersistedCollectionHolder)paramWorkPackage);
      paramWorkPackage = (WorkPackage)WPHelper.service.refresh((AbstractWorkPackage)paramWorkPackage);
    } 
    return paramWorkPackage;
  }
  
  public static WorkPackage addSuccessor(WorkPackage paramWorkPackage1, WorkPackage paramWorkPackage2) throws Exception {
    if (VERBOSE)
      System.out.println("***ProcessPackage.addSuccessor()"); 
    if (VERBOSE)
      System.out.println("TypeIdentifier INSIDE IF: " + TypedUtility.getTypeIdentifier(paramWorkPackage1)); 
    if (paramWorkPackage2 != null) {
      if (VERBOSE)
        System.out.println("Design Package-Number" + paramWorkPackage2.getNumber() + "Rev - " + paramWorkPackage2.getVersionIdentifier().getValue()); 
      paramWorkPackage1 = add(paramWorkPackage1, paramWorkPackage2);
      if (VERBOSE)
        System.out.println("Design Package [" + paramWorkPackage2.getNumber() + "]is added as a successor of Customer Package [" + paramWorkPackage2.getNumber() + "]"); 
    } else if (VERBOSE) {
      System.out.println(" Dessign Package does not exist.");
    } 
    return paramWorkPackage1;
  }
  
  private static WorkPackage add(WorkPackage paramWorkPackage1, WorkPackage paramWorkPackage2) throws WTException {
    ReferenceFactory referenceFactory = new ReferenceFactory();
    WTReference wTReference = referenceFactory.getReference((Persistable)paramWorkPackage2);
    ArrayList<WTReference> arrayList = new ArrayList();
    arrayList.add(wTReference);
    if (VERBOSE)
      System.out.println("collection size-" + arrayList.size()); 
    WPHelper.service.addSuccessors((AbstractWorkPackage)paramWorkPackage1, arrayList);
    return (WorkPackage)WPHelper.service.refresh((AbstractWorkPackage)paramWorkPackage1);
  }
  
  public static boolean isLatestPackage(WorkPackage paramWorkPackage) throws Exception {
    if (VERBOSE)
      System.out.println("isLatestPackage(" + paramWorkPackage.getVersionIdentifier().getValue() + ")"); 
    boolean bool = false;
    AbstractWorkPackageMaster abstractWorkPackageMaster = (AbstractWorkPackageMaster)paramWorkPackage.getMaster();
    WorkPackage workPackage = (WorkPackage)WPHelper.service.getLatestPackage(abstractWorkPackageMaster);
    if (workPackage.equals(paramWorkPackage)) {
      if (VERBOSE)
        System.out.println("Latest Package Version- " + workPackage.getVersionIdentifier().getValue()); 
      bool = true;
    } 
    return bool;
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\packages\commo\\util\ProcessPackage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */