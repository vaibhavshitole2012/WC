package ext.piab.packages.supplier.util;

import com.ptc.windchill.wp.AbstractWorkPackage;
import com.ptc.windchill.wp.WorkPackage;
import com.ptc.windchill.wp.delivery.DeliveryAddress;
import com.ptc.windchill.wp.delivery.DeliveryHelper;
import com.ptc.windchill.wp.delivery.DeliveryManifestType;
import com.ptc.windchill.wp.delivery.DeliveryMediumType;
import com.ptc.windchill.wp.delivery.DeliveryRecord;
import com.ptc.windchill.wp.delivery.DeliveryStatusType;
import com.ptc.windchill.wp.delivery.export.DeliveryExportDelegate;
import com.ptc.windchill.wp.delivery.export.DeliveryExportResult;
import com.ptc.windchill.wp.delivery.export.ExportHelper;
import ext.piab.common.util.PropertyforPIAB;
import ext.piab.common.util.RelatedContextLink;
import ext.piab.common.util.Teamhelper;
import ext.piab.packages.common.util.PackageContentList;
import ext.piab.packages.supplier.resource.SupplierResource;
import java.beans.PropertyVetoException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Vector;
import wt.content.ApplicationData;
import wt.content.ContentHolder;
import wt.content.ContentRoleType;
import wt.content.ContentServerHelper;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.WTObject;
import wt.fc.collections.WTSet;
import wt.folder.Folder;
import wt.folder.FolderHelper;
import wt.inf.container.WTContained;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerRef;
import wt.inf.sharing.DataSharingHelper;
import wt.inf.team.ContainerTeamManaged;
import wt.method.RemoteAccess;
import wt.org.OrganizationServicesHelper;
import wt.org.WTGroup;
import wt.org.WTPrincipal;
import wt.org.WTPrincipalReference;
import wt.org.WTUser;
import wt.ownership.Ownership;
import wt.pom.Transaction;
import wt.project.Role;
import wt.projmgmt.admin.Project2;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.WTPropertyVetoException;

public class DeliveryRecordHandler implements RemoteAccess {
  private static final String DEL_REC_ROLES = PropertyforPIAB.DELIVERY_RECORD_ROLES;
  
  private static final boolean VERBOSE = PropertyforPIAB.VERBOSE;
  
  private static final String SUPPLIER_RESOURCE = SupplierResource.class.getName();
  
  private static String DELIVERY_REC_SUBJ = WTMessage.getLocalizedMessage(SUPPLIER_RESOURCE, "3");
  
  protected static void setToAttributes(DeliveryRecord paramDeliveryRecord, String paramString) throws Exception {
    if (VERBOSE)
      System.out.println("*****DeliveryRecordHandler.setToAttributes()"); 
    WTPrincipal wTPrincipal = SessionHelper.manager.getPrincipal();
    WTUser wTUser = null;
    if (VERBOSE)
      System.out.println(wTPrincipal.getName() + " Class: " + wTPrincipal.getClass().getName() + " " + wTPrincipal.toString()); 
    Project2 project2 = RelatedContextLink.getProject(paramString);
    String[] arrayOfString = DEL_REC_ROLES.split(",");
    for (byte b = 0; b < arrayOfString.length; b++) {
      if (VERBOSE)
        System.out.println("splitted role" + arrayOfString[b]); 
      Role role = Role.toRole(arrayOfString[b]);
      
      //ArrayList arrayList = Teamhelper.getParticipants((ContainerTeamManaged)project2, role);
      //cts updated code
      ArrayList<WTPrincipalReference> arrayList = Teamhelper.getParticipants((ContainerTeamManaged)project2, role);
      if (arrayList != null)
        for (WTPrincipalReference wTPrincipalReference : arrayList) {
          WTPrincipal wTPrincipal1 = wTPrincipalReference.getPrincipal();
          if (wTPrincipal1 instanceof WTGroup) {
            WTGroup wTGroup = (WTGroup)wTPrincipal1;
            if (VERBOSE)
              System.out.println("******Found Group: " + wTGroup.getName()); 
            paramDeliveryRecord.setRecipientOrganizationName(wTGroup.getName());
            Enumeration<WTPrincipal> enumeration = OrganizationServicesHelper.manager.members(wTGroup);
            while (enumeration.hasMoreElements()) {
              WTPrincipal wTPrincipal2 = enumeration.nextElement();
              if (wTPrincipal2 instanceof WTUser) {
                wTUser = (WTUser)wTPrincipal2;
                if (VERBOSE)
                  System.out.println("******Group User: " + wTUser.getName()); 
              } 
            } 
          } else if (wTPrincipal1 instanceof WTUser) {
            wTUser = (WTUser)wTPrincipal1;
            if (VERBOSE)
              System.out.println("******Found User: " + wTUser.getName()); 
          } 
          if (VERBOSE)
            System.out.println("Name: " + wTUser.getName()); 
          paramDeliveryRecord.setSentTo(wTUser);
          DeliveryAddress deliveryAddress = DeliveryAddress.newDeliveryAddress();
          deliveryAddress.setEmailAddress(wTUser.getEMail());
          deliveryAddress.setName(wTUser.getFullName());
          deliveryAddress.setPostalAddress("");
          paramDeliveryRecord.setSentToAddress(deliveryAddress);
        }  
    } 
  }
  
  public static DeliveryRecord createDeliveryRecord(WorkPackage paramWorkPackage) throws Exception {
    if (VERBOSE)
      System.out.println("*****DeliveryRecordHandler.createDeliveryRecord()"); 
    DeliveryRecord deliveryRecord = DeliveryRecord.newDeliveryRecord();
    try {
      String str1 = RelatedContextLink.getProjNumber((Persistable)paramWorkPackage);
      WTSet wTSet = PackageContentList.getALLPackageContents(paramWorkPackage);
      Vector vector = new Vector((Collection<?>)wTSet);
      deliveryRecord.setMyPackage((AbstractWorkPackage)paramWorkPackage);
      deliveryRecord.setMyPackageReference(ObjectReference.newObjectReference((Persistable)paramWorkPackage));
      deliveryRecord.setContainer(paramWorkPackage.getContainer());
      deliveryRecord.setCreator(SessionHelper.manager.getPrincipalReference());
      Ownership ownership = Ownership.newOwnership(SessionHelper.manager.getPrincipal());
      deliveryRecord.setOwnership(ownership);
      DeliveryStatusType deliveryStatusType = DeliveryStatusType.DELIVERED;
      deliveryRecord.setStatus(deliveryStatusType);
      deliveryRecord.setDomainRef(paramWorkPackage.getDomainRef());
      deliveryRecord.setModifier(SessionHelper.manager.getPrincipalReference());
      deliveryRecord.setDeliveryMedium(DeliveryMediumType.EMAIL_LINK);
      deliveryRecord.setEmailNotificationSubject(DELIVERY_REC_SUBJ);
      setToAttributes(deliveryRecord, str1);
      deliveryRecord.setSentFrom((WTUser)SessionHelper.manager.getPrincipal());
      if (vector != null) {
        deliveryRecord.setContentVector(vector);
        if (VERBOSE)
          System.out.println("******Contents size" + vector.size()); 
      } 
      if (VERBOSE)
        System.out.println("****After Setting Package"); 
      deliveryRecord = (DeliveryRecord)PersistenceHelper.manager.save((Persistable)deliveryRecord);
      if (deliveryRecord != null) {
        if (VERBOSE)
          System.out.println("***Created Delivery Record Number: " + deliveryRecord.getNumber()); 
      } else {
        if (VERBOSE)
          System.out.println("Delivery Record Null - Report Error"); 
        throw new WTException("Delivery Record Null - Investigate root cause");
      } 
      deliveryRecord.setDeliveryManifest(DeliveryManifestType.INTERACTIVE);
      String str2 = deliveryRecord.getNumber() + "-" + paramWorkPackage.getNumber() + "_" + paramWorkPackage.getVersionIdentifier().getValue();
      deliveryRecord.setNumber(str2);
      deliveryRecord = (DeliveryRecord)PersistenceHelper.manager.save((Persistable)deliveryRecord);
      Project2 project2 = RelatedContextLink.getProject(str1);
      Folder folder = getFolderForProject(project2);
      shareToProject((WTObject)deliveryRecord, project2, folder);
      DeliveryHelper.getService().send(deliveryRecord);
    } catch (WTException wTException) {
      wTException.printStackTrace();
    } 
    return deliveryRecord;
  }
  
  public static void exportRecord(DeliveryRecord paramDeliveryRecord) {
    if (VERBOSE)
      System.out.println("****DeliveryRecordHandler.exportRecord()"); 
    System.out.println("Record Name: " + paramDeliveryRecord.getName());
    Transaction transaction = null;
    try {
      transaction = new Transaction();
      transaction.start();
      DeliveryExportDelegate deliveryExportDelegate = ExportHelper.getDeliveryExportDelegate(paramDeliveryRecord);
      if (VERBOSE)
        System.out.println("****getDeliveryExportDelegate***: " + deliveryExportDelegate); 
      DeliveryExportResult deliveryExportResult = deliveryExportDelegate.buildExportFiles(paramDeliveryRecord);
      if (VERBOSE)
        System.out.println("****buildExportFiles***: " + deliveryExportResult); 
      DeliveryRecord deliveryRecord = paramDeliveryRecord;
      PersistenceServerHelper.manager.lock((Persistable)deliveryRecord);
      if (VERBOSE)
        System.out.println("****ed****"); 
      Iterator<DeliveryExportResult.ExportFileInformation> iterator = deliveryExportResult.getExportFiles().iterator();
      while (iterator.hasNext()) {
        if (VERBOSE)
          System.out.println("***start Loop****"); 
        DeliveryExportResult.ExportFileInformation exportFileInformation = iterator.next();
        ApplicationData applicationData = ApplicationData.newApplicationData((ContentHolder)deliveryRecord);
        applicationData.setRole(ContentRoleType.SECONDARY);
        applicationData.setFileName(exportFileInformation.getFilename());
        FileInputStream fileInputStream = new FileInputStream(exportFileInformation.getFile());
        ContentServerHelper.service.updateContent((ContentHolder)deliveryRecord, applicationData, fileInputStream, true);
        if (VERBOSE)
          System.out.println("***End Loop***"); 
        fileInputStream.close();
      } 
      PersistenceServerHelper.manager.update((Persistable)deliveryRecord);
      if (VERBOSE)
        System.out.println("****Export Complete******"); 
      transaction.commit();
      transaction = null;
    } catch (WTException wTException) {
      wTException.printStackTrace();
      transaction.rollback();
    } catch (WTPropertyVetoException wTPropertyVetoException) {
      wTPropertyVetoException.printStackTrace();
    } catch (FileNotFoundException fileNotFoundException) {
      fileNotFoundException.printStackTrace();
    } catch (IOException iOException) {
      iOException.printStackTrace();
    } catch (PropertyVetoException propertyVetoException) {
      propertyVetoException.printStackTrace();
    } finally {
      if (transaction != null)
        transaction.rollback(); 
      transaction = null;
    } 
  }
  
  private static Folder getFolderForProject(Project2 paramProject2) throws WTException, WTPropertyVetoException {
    if (VERBOSE)
      System.out.println("****DeliveryRecordHandler.getFolderForProject()"); 
    Project2 project2 = paramProject2;
    WTContainerRef wTContainerRef = WTContainerRef.newWTContainerRef((WTContainer)project2);
   // null = null;
    return FolderHelper.service.getFolder("/Default", wTContainerRef);
  }
  
  private static void shareToProject(WTObject paramWTObject, Project2 paramProject2, Folder paramFolder) throws WTException {
    if (VERBOSE)
      System.out.println("****DeliveryRecordHandler.shareToProject()"); 
    WTContainer wTContainer = ((WTContained)paramWTObject).getContainer();
    if (!wTContainer.isSharingEnabled())
      DataSharingHelper.service.enableContainerSharing(wTContainer); 
    Project2 project2 = paramProject2;
    if (!paramProject2.isSharingEnabled())
      DataSharingHelper.service.enableContainerSharing((WTContainer)paramProject2); 
    WTContainerRef wTContainerRef = WTContainerRef.newWTContainerRef((WTContainer)project2);
    boolean bool = DataSharingHelper.service.isSharedTo((Persistable)paramWTObject, wTContainerRef);
    if (!bool)
      DataSharingHelper.service.shareVersion((Persistable)paramWTObject, wTContainerRef, paramFolder); 
    if (VERBOSE)
      System.out.println("****Sharing Complete"); 
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\packages\supplie\\util\DeliveryRecordHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */