package ext.piab.packages.customer.util;

import com.ptc.windchill.wp.WorkPackage;
import ext.piab.common.util.IBAUtil;
import ext.piab.common.util.PropertyforPIAB;
import ext.piab.common.util.UpdateIBAs;
import java.util.Locale;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.ReferenceFactory;
import wt.fc.WTReference;
import wt.httpgw.URLFactory;
import wt.iba.definition.litedefinition.AttributeDefDefaultView;
import wt.iba.value.DefaultAttributeContainer;
import wt.iba.value.IBAHolder;
import wt.iba.value.IBAValueUtility;
import wt.iba.value.litevalue.AbstractValueView;

public class UpdateCustomerAttributes {
  private static final boolean VERBOSE = PropertyforPIAB.VERBOSE;
  
  private static final String DESIGN_PACKAGE_NUMBER = PropertyforPIAB.DESIGN_PACKAGE_NUMBER;
  
  private static final String DESIGN_PACKAGE_REVISION = PropertyforPIAB.DESIGN_PACKAGE_REVISION;
  
  private static final String DESIGN_PACKAGE_URL = PropertyforPIAB.DESIGN_PACKAGE_URL;
  
  public static void updateAttributes(WorkPackage paramWorkPackage, String paramString1, String paramString2) throws Exception {
    if (VERBOSE)
      System.out.println("UpdateCustomerAttributes.updateAttributes"); 
    paramWorkPackage = updatePkgNumberAttribute(paramWorkPackage, paramString1);
    paramWorkPackage = updateRevAttribute(paramWorkPackage, paramString2);
    paramWorkPackage = updateURLAttribute(DesignProcessHandler.getDesignPkg(paramString1), paramWorkPackage);
  }
  
  public static WorkPackage updatePkgNumberAttribute(WorkPackage paramWorkPackage, String paramString) throws Exception {
    if (VERBOSE)
      System.out.println("UpdateCustomerAttributes.updatePkgNumberAttribute()"); 
    String str = getdesignpkgNumber(paramWorkPackage);
    if (VERBOSE)
      System.out.println("Value of Attribute DESIGN_PACKAGE_NUMBER entered initially is" + str); 
    if (str != paramString) {
      IBAUtil iBAUtil = new IBAUtil((IBAHolder)paramWorkPackage);
      iBAUtil.setIBAValue(DESIGN_PACKAGE_NUMBER, paramString, null);
      paramWorkPackage = (WorkPackage)iBAUtil.updateIBAPart((IBAHolder)paramWorkPackage);
      paramWorkPackage = (WorkPackage)PersistenceHelper.manager.save((Persistable)paramWorkPackage);
      if (VERBOSE)
        System.out.println("Value of Attribute DESIGN_PACKAGE_NUMBER is Updated-"); 
    } else if (VERBOSE) {
      System.out.println("Value of Attribute DESIGN_PACKAGE_NUMBER is Correct-");
    } 
    return paramWorkPackage;
  }
  
  public static WorkPackage updateURLAttribute(WorkPackage paramWorkPackage1, WorkPackage paramWorkPackage2) throws Exception {
    if (VERBOSE)
      System.out.println("UpdateCustomerAttributes.updateURLAttribute()"); 
    ReferenceFactory referenceFactory = new ReferenceFactory();
    WTReference wTReference = referenceFactory.getReference((Persistable)paramWorkPackage1);
    String str1 = referenceFactory.getReferenceString(wTReference);
    URLFactory uRLFactory = new URLFactory();
    String str2 = uRLFactory.getHREF("/app/#ptc1/tcomp/infoPage?oid=" + str1);
    String str3 = paramWorkPackage1.getName();
    UpdateIBAs.updateIBAUrl((IBAHolder)paramWorkPackage2, str2, str3, DESIGN_PACKAGE_URL);
    return paramWorkPackage2;
  }
  
  public static WorkPackage updateRevAttribute(WorkPackage paramWorkPackage, String paramString) throws Exception {
    if (VERBOSE)
      System.out.println("UpdateCustomerAttributes.updateRevAttribute()"); 
    String str = getdesignpkgRev(paramWorkPackage);
    if (VERBOSE)
      System.out.println("Value of Attribute DESIGN_PACKAGE_REVISION entered initially is" + str); 
    if (str != paramString) {
      IBAUtil iBAUtil = new IBAUtil((IBAHolder)paramWorkPackage);
      iBAUtil.setIBAValue(DESIGN_PACKAGE_REVISION, paramString, null);
      paramWorkPackage = (WorkPackage)iBAUtil.updateIBAPart((IBAHolder)paramWorkPackage);
      paramWorkPackage = (WorkPackage)PersistenceHelper.manager.save((Persistable)paramWorkPackage);
      if (VERBOSE)
        System.out.println("Value of Attribute DESIGN_PACKAGE_REVISION is Updated-"); 
    } else if (VERBOSE) {
      System.out.println("Value of Attribute DESIGN_PACKAGE_REVISION is Correct-");
    } 
    return paramWorkPackage;
  }
  
  public static String getdesignpkgNumber(WorkPackage paramWorkPackage) throws Exception {
    if (VERBOSE)
      System.out.println("***DesignProcessHandler.getdesignpkgNumber(" + paramWorkPackage.getName() + ")"); 
    return getIBAValue(paramWorkPackage, DESIGN_PACKAGE_NUMBER);
  }
  
  public static String getdesignpkgRev(WorkPackage paramWorkPackage) {
    if (VERBOSE)
      System.out.println("***DesignProcessHandler.getdesignpkgRev(" + paramWorkPackage.getName() + ")"); 
    return getIBAValue(paramWorkPackage, DESIGN_PACKAGE_REVISION);
  }
  
  public static String getdesignpkgURL(WorkPackage paramWorkPackage) {
    if (VERBOSE)
      System.out.println("***DesignProcessHandler.getdesignpkgURL(" + paramWorkPackage.getName() + ")"); 
    return getIBAValue(paramWorkPackage, DESIGN_PACKAGE_URL);
  }
  
  private static String getIBAValue(WorkPackage paramWorkPackage, String paramString) {
    if (VERBOSE)
      System.out.println("DesignProcessHandler.getIBAValue"); 
    String str = null;
    try {
      DefaultAttributeContainer defaultAttributeContainer = (DefaultAttributeContainer)paramWorkPackage.getAttributeContainer();
      if (VERBOSE)
        System.out.println("\n ***DefaultAttributeContainer-" + defaultAttributeContainer); 
      if (defaultAttributeContainer != null) {
        AbstractValueView[] arrayOfAbstractValueView = defaultAttributeContainer.getAttributeValues();
        if (VERBOSE)
          System.out.println("\n ***DefaultAttributeContainer avv[]length-" + arrayOfAbstractValueView.length); 
        AttributeDefDefaultView attributeDefDefaultView = null;
        for (byte b = 0; b < arrayOfAbstractValueView.length; b++) {
          attributeDefDefaultView = arrayOfAbstractValueView[b].getDefinition();
          String str1 = attributeDefDefaultView.getName();
          if (VERBOSE)
            System.out.println("***AttributeDefDefaultView.getName()-" + str1); 
          if (str1.equalsIgnoreCase(paramString)) {
            str = IBAValueUtility.getLocalizedIBAValueDisplayString(arrayOfAbstractValueView[b], Locale.getDefault());
            if (VERBOSE)
              System.out.println("***IBA Value is-" + str); 
          } 
        } 
      } else {
        IBAUtil iBAUtil = new IBAUtil((IBAHolder)paramWorkPackage);
        str = iBAUtil.getIBAValue((IBAHolder)paramWorkPackage, paramString);
        if (VERBOSE)
          System.out.println("*** IBA Value is-" + str); 
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return str;
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\packages\custome\\util\UpdateCustomerAttributes.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */