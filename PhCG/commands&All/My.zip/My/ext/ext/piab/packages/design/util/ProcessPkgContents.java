package ext.piab.packages.design.util;

import com.ptc.windchill.wp.WorkPackage;
import ext.piab.common.util.LifecycleStateHelper;
import ext.piab.common.util.PropertyforPIAB;
import ext.piab.common.util.PublishforPIAB;
import ext.piab.common.util.ReviseUtility;
import ext.piab.packages.common.util.PackageContentList;
import ext.piab.packages.common.util.ProcessPackage;
import java.util.HashMap;
import java.util.Iterator;
import wt.enterprise.RevisionControlled;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.WTObject;
import wt.fc.collections.WTArrayList;
import wt.lifecycle.LifeCycleManaged;
import wt.part.WTPart;

public class ProcessPkgContents {
  public static final boolean VERBOSE = PropertyforPIAB.VERBOSE;
  
  public static final String LC_STATE_4 = PropertyforPIAB.LC_STATE_4;
  
  public static final String LC_STATE_3 = PropertyforPIAB.LC_STATE_3;
  
  public static final String LC_STATE_1 = PropertyforPIAB.LC_STATE_1;
  
  public static final String LC_STATE_2 = PropertyforPIAB.LC_STATE_2;
  
  private static final String RELEASE_VERSION = PropertyforPIAB.RELEASE_VERSION;
  
  public static void setState(WorkPackage paramWorkPackage, String paramString) throws Exception {
    if (VERBOSE)
      System.out.println("***ProcessPkgContents.setState:(" + paramWorkPackage.getNumber() + "," + paramString + ")"); 
    HashMap<Object, Object> hashMap1 = new HashMap<>();
    HashMap<Object, Object> hashMap2 = new HashMap<>();
    try {
      WTArrayList wTArrayList = PackageContentList.getContentsList(paramWorkPackage);
      if (VERBOSE)
        System.out.println("pkgItemList size for Set State" + wTArrayList.size()); 
      Object[] arrayOfObject = wTArrayList.toArray();
      for (byte b = 0; b < arrayOfObject.length; b++) {
        ObjectReference objectReference = (ObjectReference)arrayOfObject[b];
        WTObject wTObject = (WTObject)objectReference.getObject();
        boolean bool = checkToProcess(wTObject, paramString);
        if (bool) {
          wTObject = (WTObject)LifecycleStateHelper.setLifecycleState((Persistable)wTObject, paramString);
          PublishforPIAB.doPublish((Persistable)wTObject);
        } 
        if (paramString.equalsIgnoreCase(LC_STATE_3)) {
          hashMap1 = RelatedSupplers.getRelatedSupplierProjects((Persistable)wTObject, hashMap1);
          hashMap2 = RelatedChanges.getRelatedChanges((Persistable)wTObject, hashMap2);
        } 
      } 
      send((Persistable)paramWorkPackage, hashMap1, true, false);
      send((Persistable)paramWorkPackage, hashMap2, false, true);
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  private static boolean checkToProcess(WTObject paramWTObject, String paramString) throws Exception {
    if (VERBOSE)
      System.out.println("***ProcessPkgContents.checkToProcess()"); 
    boolean bool = false;
    boolean bool1 = ReviseUtility.isLatestObj(paramWTObject);
    if (bool1) {
      String str = ((LifeCycleManaged)paramWTObject).getLifeCycleState().toString();
      if (paramString.equalsIgnoreCase(LC_STATE_2)) {
        if (str.equalsIgnoreCase(LC_STATE_1))
          bool = true; 
      } else if (paramString.equalsIgnoreCase(LC_STATE_3)) {
        if (str.equalsIgnoreCase(LC_STATE_1) || str.equalsIgnoreCase(LC_STATE_2))
          bool = true; 
      } else if (paramString.equalsIgnoreCase(LC_STATE_4)) {
        String str1 = ((RevisionControlled)paramWTObject).getVersionIdentifier().getValue().toString();
        if (VERBOSE)
          System.out.println("Returning set state" + str1); 
        if (!Character.isDigit(RELEASE_VERSION.charAt(0))) {
          if (VERBOSE)
            System.out.println("RELEASE_VERSION alpha" + RELEASE_VERSION.charAt(0)); 
          if (!Character.isDigit(str1.charAt(0)))
            bool = true; 
        } else if (Character.isDigit(RELEASE_VERSION.charAt(0))) {
          if (VERBOSE)
            System.out.println("RELEASE_VERSION numeric" + RELEASE_VERSION.charAt(0)); 
          if (Character.isDigit(str1.charAt(0)))
            bool = true; 
        } 
      } 
    } 
    if (VERBOSE)
      System.out.println("Returning set state" + bool); 
    return bool;
  }
  
  public static WorkPackage revisePkgData(WorkPackage paramWorkPackage) throws Exception {
    if (VERBOSE)
      System.out.println("***ProcessPkgContents.revisePkgData()"); 
    try {
      WTArrayList wTArrayList1 = PackageContentList.getContentsList(paramWorkPackage);
      ReviseUtility.reviseAll(wTArrayList1);
      WTArrayList wTArrayList2 = ReviseUtility.getBuildLinkedParts(wTArrayList1);
      if (VERBOSE)
        System.out.println("pkgItemList for revising  " + wTArrayList1.size()); 
      wTArrayList1 = ReviseUtility.getItemstoRevise(wTArrayList1, wTArrayList2);
      Iterator<ObjectReference> iterator = wTArrayList1.iterator();
      HashMap<Object, Object> hashMap1 = new HashMap<>();
      HashMap<Object, Object> hashMap2 = new HashMap<>();
      while (iterator.hasNext()) {
        ObjectReference objectReference = iterator.next();
        Persistable persistable = objectReference.getObject();
        hashMap1 = RelatedSupplers.getRelatedSupplierProjects(persistable, hashMap1);
        hashMap2 = RelatedChanges.getRelatedChanges(persistable, hashMap2);
        Iterator<ObjectReference> iterator1 = wTArrayList2.iterator();
        while (iterator1.hasNext()) {
          if (VERBOSE)
            System.out.println("***INSIDE MAPPART"); 
          ObjectReference objectReference1 = iterator1.next();
          WTPart wTPart = (WTPart)objectReference1.getObject();
          HashMap<?, ?> hashMap3 = RelatedSupplers.getRelatedSupplierProjects((Persistable)wTPart, hashMap1);
          hashMap1.putAll(hashMap3);
          HashMap<?, ?> hashMap4 = RelatedChanges.getRelatedChanges((Persistable)wTPart, hashMap2);
          hashMap2.putAll(hashMap4);
        } 
      } 
      send((Persistable)paramWorkPackage, hashMap1, true, false);
      send((Persistable)paramWorkPackage, hashMap2, false, true);
      paramWorkPackage = ProcessPackage.refreshPkg(paramWorkPackage);
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return paramWorkPackage;
  }
  
  public static void send(Persistable paramPersistable, HashMap paramHashMap, boolean paramBoolean1, boolean paramBoolean2) throws Exception {
    if (VERBOSE)
      System.out.println("***ProcessPkgContents.send"); 
    if (VERBOSE)
      System.out.println("MAP= " + paramHashMap); 
    if (paramBoolean1 && !paramHashMap.isEmpty())
      Notify.sendMail(paramPersistable, paramHashMap); 
    if (paramBoolean2 && paramHashMap != null && !paramHashMap.isEmpty())
      Notify.notifyChangeOwners(paramPersistable, paramHashMap); 
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\packages\desig\\util\ProcessPkgContents.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */