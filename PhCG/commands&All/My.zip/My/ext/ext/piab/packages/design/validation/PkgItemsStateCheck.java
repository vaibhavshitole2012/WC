package ext.piab.packages.design.validation;

import com.ptc.windchill.wp.WorkPackage;
import ext.piab.common.util.PropertyforPIAB;
import ext.piab.common.validation.ValidateObjetcs;
import ext.piab.packages.common.util.PackageContentList;
import ext.piab.packages.design.resource.DesignResource;
import java.util.Vector;
import wt.fc.Persistable;
import wt.fc.collections.WTSet;
import wt.method.RemoteAccess;
import wt.util.WTException;

public class PkgItemsStateCheck implements RemoteAccess {
  private static final boolean VERBOSE = PropertyforPIAB.VERBOSE;
  
  private static final String DESIGN_RESOURCE = DesignResource.class.getName();
  
  public static void pkgContentsState(Persistable paramPersistable, Vector<String> paramVector, boolean paramBoolean) throws Exception {
    if (VERBOSE)
      System.out.println("*** PkgItemsStateCheck.pkgContentsState"); 
    WorkPackage workPackage = null;
    WTSet wTSet = null;
    if (paramPersistable instanceof WorkPackage) {
      workPackage = (WorkPackage)paramPersistable;
      if (paramBoolean) {
        wTSet = PackageContentList.getdependents(workPackage);
      } else {
        wTSet = PackageContentList.filterbyIncludeDependents(workPackage);
      } 
    } 
    if (VERBOSE)
      System.out.println("***pkgItemList size" + wTSet.size()); 
    String str = ValidateObjetcs.incorrectLCState(wTSet.toArray(), paramVector);
    if (!str.isEmpty()) {
      if (VERBOSE)
        System.out.println("***Objects in the Package are in state other than" + paramVector); 
      Object[] arrayOfObject = { str, workPackage.getName(), paramVector };
      throw new WTException(DESIGN_RESOURCE, "0", arrayOfObject);
    } 
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\packages\design\validation\PkgItemsStateCheck.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */