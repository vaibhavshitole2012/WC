package ext.piab.packages.design.resource;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("ext.piab.packages.design.resource.DesignResource")
public final class DesignResource extends WTListResourceBundle {
  @RBEntry("The objects with Number \n[{0}]\n inside the package [{1}] are not in {2} states.\nYou have to Revise the Package [{1}] to Proceed ")
  public static final String PKG_ITEMS_STATES = "0";
  
  @RBEntry("The dependent objects with Number \n[{0}]\n inside the package [{1}] are not in {2} states.\nYou have to Revise the Package [{1}] to Proceed ")
  public static final String DEPENDENT_ITEMS_STATES = "1";
  
  @RBEntry("The task cannot proceed until the below mentioned CA and CN's for the corresponding items in this package{0}  are not in {1} State.\n [{2}]")
  public static final String CHECK_CN_CA = "2";
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\packages\design\resource\DesignResource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */