package ext.piab.packages.supplier.validation;

import ext.piab.common.util.PropertyforPIAB;
import ext.piab.common.util.RelatedContextLink;
import ext.piab.common.util.Teamhelper;
import ext.piab.packages.supplier.resource.SupplierResource;
import java.util.ArrayList;
import java.util.Vector;
import wt.inf.team.ContainerTeam;
import wt.inf.team.ContainerTeamHelper;
import wt.inf.team.ContainerTeamManaged;
import wt.method.RemoteAccess;
import wt.project.Role;
import wt.projmgmt.admin.Project2;
import wt.util.WTException;

public class ValidateSupplierProject implements RemoteAccess {
  private static final boolean VERBOSE = PropertyforPIAB.VERBOSE;
  
  private static final String DEL_REC_ROLES = PropertyforPIAB.DELIVERY_RECORD_ROLES;
  
  private static final String SUPPLIER_RESOURCE = SupplierResource.class.getName();
  
  public static void supplierExists(String paramString) throws Exception {
    if (VERBOSE)
      System.out.println("***ValidateSupplierProject.supplierExists()"); 
    if (paramString != null) {
      Project2 project2 = RelatedContextLink.getProject(paramString);
      if (project2 != null) {
        Vector<String> vector = getStringRoles(project2);
        String[] arrayOfString = DEL_REC_ROLES.split(",");
        checkRoles(project2, arrayOfString, vector);
        checkusers(project2);
      } 
    } 
  }
  
  private static void checkusers(Project2 paramProject2) throws Exception {
    if (VERBOSE)
      System.out.println("ValidateSupplierProject.checkusers"); 
    StringBuilder stringBuilder = new StringBuilder();
    Vector vector = Teamhelper.getRoles((ContainerTeamManaged)paramProject2);
    ContainerTeam containerTeam = ContainerTeamHelper.service.getContainerTeam((ContainerTeamManaged)paramProject2);
    for (Role role : vector) {
      if (DEL_REC_ROLES.contains(role.getDisplay().toUpperCase())) {
        ArrayList arrayList = containerTeam.getAllPrincipalsForTarget(role);
        System.out.println("size" + arrayList.size());
        if (arrayList.isEmpty())
          stringBuilder.append(role.getDisplay() + ","); 
      } 
    } 
    String str = stringBuilder.toString();
    if (!str.isEmpty()) {
      str = str.substring(0, str.lastIndexOf(","));
      System.out.println("No users in the mentioned role");
      Object[] arrayOfObject = { str, paramProject2.getName() };
      throw new WTException(SUPPLIER_RESOURCE, "2", arrayOfObject);
    } 
  }
  
  private static void checkRoles(Project2 paramProject2, String[] paramArrayOfString, Vector<String> paramVector) throws Exception {
    if (VERBOSE) {
      System.out.println("ValidateSupplierProject.checkRoles");
      System.out.println("to compare roles" + paramVector);
    } 
    StringBuilder stringBuilder = new StringBuilder();
    for (byte b = 0; b < paramArrayOfString.length; b++) {
      System.out.println("splitted role" + paramArrayOfString[b]);
      if (!paramVector.contains(paramArrayOfString[b]))
        stringBuilder.append(paramArrayOfString[b] + ","); 
    } 
    String str = stringBuilder.toString();
    if (!str.isEmpty()) {
      str = str.substring(0, str.lastIndexOf(","));
      System.out.println("Project does not conatin required Roles");
      Object[] arrayOfObject = { paramProject2.getName(), str };
      throw new WTException(SUPPLIER_RESOURCE, "1", arrayOfObject);
    } 
  }
  
  private static Vector<String> getStringRoles(Project2 paramProject2) throws Exception {
    Vector<String> vector = new Vector();
    if (VERBOSE)
      System.out.println("ValidateSupplierProject.getStringRoles()"); 
    Vector vector1 = Teamhelper.getRoles((ContainerTeamManaged)paramProject2);
    for (Role role : vector1)
      vector.addElement(role.getDisplay().toString().toUpperCase()); 
    return vector;
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\packages\supplier\validation\ValidateSupplierProject.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */