package ext.piab.packages.design.validation;

import com.ptc.windchill.wp.WorkPackage;
import ext.piab.common.util.PropertyforPIAB;
import ext.piab.common.validation.ErrorMesageContent;
import ext.piab.packages.common.util.PackageContentList;
import ext.piab.packages.design.resource.DesignResource;
import wt.change2.ChangeActivityIfc;
import wt.change2.ChangeHelper2;
import wt.change2.ChangeRecord2;
import wt.change2.WTChangeActivity2;
import wt.change2.WTChangeOrder2;
import wt.enterprise.RevisionControlled;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.WTObject;
import wt.fc.collections.WTArrayList;
import wt.fc.collections.WTSet;
import wt.util.WTException;

public class CheckEngChanges {
  private static final boolean VERBOSE = PropertyforPIAB.VERBOSE;
  
  private static final String LCSTATE_APPROVED = PropertyforPIAB.LCSTATE_APPROVED;
  
  private static final String LCSTATE_OPEN = PropertyforPIAB.LCSTATE_OPEN;
  
  private static final String LCSTATE_UNDERREVIEW = PropertyforPIAB.LCSTATE_UNDERREVIEW;
  
  private static final String LCSTATE_CANCELLED = PropertyforPIAB.LCSTATE_CANCELLED;
  
  private static final String LCSTATE_COMPLETED = PropertyforPIAB.LCSTATE_COMPLETED;
  
  private static final String DESIGN_RESOURCE = DesignResource.class.getName();
  
  public static void checkChangeProcesses(WorkPackage paramWorkPackage, String paramString) throws Exception {
    if (VERBOSE)
      System.out.println("***CheckEngChanges.checkChangeProcesses()"); 
    StringBuilder stringBuilder = new StringBuilder();
    WTSet wTSet = PackageContentList.filterbyInitiallySelected(paramWorkPackage);
    if (VERBOSE)
      System.out.println("*** Size of Package items -" + wTSet.size()); 
    Object[] arrayOfObject = wTSet.toArray();
    for (byte b = 0; b < arrayOfObject.length; b++) {
      ObjectReference objectReference = (ObjectReference)arrayOfObject[b];
      WTObject wTObject = (WTObject)objectReference.getObject();
      String str1 = ((RevisionControlled)wTObject).getName();
      if (VERBOSE)
        System.out.println("***Pakage Content " + str1 + " - " + ((RevisionControlled)wTObject).getVersionIdentifier().getValue()); 
      Object[] arrayOfObject1 = findChangeItems((Persistable)wTObject, paramString);
      if (VERBOSE)
        System.out.println("***Size of Change Items-" + arrayOfObject1.length); 
      for (byte b1 = 0; b1 < arrayOfObject1.length; b1++) {
        ObjectReference objectReference1 = (ObjectReference)arrayOfObject1[b1];
        WTChangeActivity2 wTChangeActivity2 = (WTChangeActivity2)objectReference1.getObject();
        QueryResult queryResult = ChangeHelper2.service.getChangeOrder((ChangeActivityIfc)wTChangeActivity2);
        WTChangeOrder2 wTChangeOrder2 = (WTChangeOrder2)queryResult.nextElement();
        stringBuilder = ErrorMesageContent.errForItemsinChange(wTObject, wTChangeActivity2, wTChangeOrder2, stringBuilder);
      } 
    } 
    String str = stringBuilder.toString();
    if (!str.isEmpty()) {
      if (VERBOSE)
        System.out.println("These contents of Design Package have CA and CN's which are not in " + paramString + " State"); 
      Object[] arrayOfObject1 = { paramWorkPackage.getName(), paramString, str };
      throw new WTException(DESIGN_RESOURCE, "2", arrayOfObject1);
    } 
  }
  
  public static Object[] findChangeItems(Persistable paramPersistable, String paramString) throws Exception {
    if (VERBOSE)
      System.out.println("*** CheckEngChanges.findChangeItems()"); 
    WTArrayList wTArrayList = new WTArrayList();
    try {
      QueryResult queryResult = PersistenceHelper.manager.navigate(paramPersistable, "roleAObject", ChangeRecord2.class, true);
      if (VERBOSE)
        System.out.println("***Change Record Size-" + queryResult.size()); 
      while (queryResult.hasMoreElements()) {
        WTChangeActivity2 wTChangeActivity2 = (WTChangeActivity2)queryResult.nextElement();
        if (VERBOSE)
          System.out.println("***Change Activity: " + wTChangeActivity2.getName() + " -State: " + wTChangeActivity2.getState()); 
        String str = wTChangeActivity2.getState().toString();
        if (paramString.equalsIgnoreCase(LCSTATE_APPROVED) && (str.equalsIgnoreCase(LCSTATE_OPEN) || str.equalsIgnoreCase(LCSTATE_UNDERREVIEW)))
          wTArrayList.add((Persistable)wTChangeActivity2); 
        if (paramString.equalsIgnoreCase(LCSTATE_COMPLETED) && !str.equalsIgnoreCase(paramString) && !str.equalsIgnoreCase(LCSTATE_CANCELLED))
          wTArrayList.add((Persistable)wTChangeActivity2); 
      } 
      if (VERBOSE)
        System.out.println("*** CA's and CN's not in :" + paramString + "State. -" + wTArrayList.size()); 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return wTArrayList.toArray();
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\packages\design\validation\CheckEngChanges.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */