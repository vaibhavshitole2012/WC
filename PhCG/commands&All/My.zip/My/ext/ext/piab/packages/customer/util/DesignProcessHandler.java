package ext.piab.packages.customer.util;

import com.ptc.windchill.wp.AbstractWorkPackageMaster;
import com.ptc.windchill.wp.WPHelper;
import com.ptc.windchill.wp.WorkPackage;
import ext.piab.common.resource.CommonResource;
import ext.piab.common.util.PropertyforPIAB;
import ext.piab.packages.customer.resource.CustomerResource;
import java.util.Vector;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.query.WhereExpression;
import wt.type.TypedUtility;
import wt.util.WTMessage;
import wt.vc.VersionControlHelper;
import wt.vc.Versioned;
import wt.workflow.definer.UserEventVector;
import wt.workflow.engine.WfProcess;
import wt.workflow.engine.WfState;
import wt.workflow.work.WfAssignedActivity;
import wt.workflow.work.WorkItem;
import wt.workflow.work.WorkflowHelper;

public class DesignProcessHandler {
  private static final boolean VERBOSE = PropertyforPIAB.VERBOSE;
  
  private static final String DESIGN_PACKAGE_TYPE_NAME = PropertyforPIAB.DESIGN_PACKAGE_TYPE_NAME;
  
  private static final boolean CUSTOMER_VERFICATION = PropertyforPIAB.CUSTOMER_VERFICATION;
  
  private static final boolean CUSTOMER_VALIDATION = PropertyforPIAB.CUSTOMER_VALIDATION;
  
  private static final String COMMON_RESOURCE = CommonResource.class.getName();
  
  private static final String CUSTOMER_RESOURCE = CustomerResource.class.getName();
  
  private static String WF_STATE = WTMessage.getLocalizedMessage(COMMON_RESOURCE, "7");
  
  private static String VERIFY_TASK_NAME = WTMessage.getLocalizedMessage(CUSTOMER_RESOURCE, "2");
  
  private static String VALIDATE_TASK_NAME = WTMessage.getLocalizedMessage(CUSTOMER_RESOURCE, "3");
  
  private static final String VERIFY_EVENT = WTMessage.getLocalizedMessage(CUSTOMER_RESOURCE, "4");
  
  private static final String VALIDATE_EVENT = WTMessage.getLocalizedMessage(CUSTOMER_RESOURCE, "5");
  
  public static WorkPackage exactPkg(WorkPackage paramWorkPackage, String paramString) throws Exception {
    if (VERBOSE)
      System.out.println("DesignProcessHandler.checkPkgRev()"); 
    WorkPackage workPackage = null;
    String str = "";
    QueryResult queryResult = VersionControlHelper.service.allVersionsOf((Versioned)paramWorkPackage);
    if (VERBOSE)
      System.out.println("All versions Size()" + queryResult.size()); 
    while (queryResult.hasMoreElements()) {
      paramWorkPackage = (WorkPackage)queryResult.nextElement();
      if (paramWorkPackage.getVersionIdentifier().getValue().equalsIgnoreCase(paramString)) {
        workPackage = paramWorkPackage;
        str = workPackage.getVersionIdentifier().getValue();
        if (VERBOSE)
          System.out.println("Returning pkg with version" + str); 
        break;
      } 
    } 
    return workPackage;
  }
  
  public static WorkPackage getDesignPkg(String paramString) throws Exception {
    if (VERBOSE)
      System.out.println("*** DesignProcessHandler.getDesignPkg()" + paramString); 
    WorkPackage workPackage = null;
    try {
      if (paramString != null) {
        QuerySpec querySpec = new QuerySpec(WorkPackage.class);
        querySpec.appendWhere((WhereExpression)new SearchCondition(WorkPackage.class, "master>number", "=", paramString));
        QueryResult queryResult = PersistenceHelper.manager.find(querySpec);
        if (VERBOSE)
          System.out.println("Package Result is-" + queryResult.size()); 
        if (queryResult.hasMoreElements()) {
          WorkPackage workPackage1 = (WorkPackage)queryResult.nextElement();
          if (TypedUtility.getTypeIdentifier(workPackage1).toString().endsWith(DESIGN_PACKAGE_TYPE_NAME))
            workPackage = (WorkPackage)WPHelper.service.getLatestPackage((AbstractWorkPackageMaster)workPackage1.getMaster()); 
        } 
      } 
      if (VERBOSE)
        System.out.println("***Package is-" + workPackage.getName() + " rev - " + workPackage.getVersionIdentifier().getValue()); 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return workPackage;
  }
  
  public static void completeDesignTask(WorkPackage paramWorkPackage, String paramString1, String paramString2) throws Exception {
    if (VERBOSE)
      System.out.println("***DesignProcessHandler.completeDesignTask()"); 
    WorkPackage workPackage = exactPkg(getDesignPkg(paramString2), paramString1);
    QueryResult<WorkItem> queryResult = WorkflowHelper.service.getUncompletedWorkItems((Persistable)workPackage, "");
    WfProcess wfProcess = null;
    String str = WF_STATE;
    WfState wfState = WfState.toWfState(str);
    while (queryResult.hasMoreElements()) {
      WorkItem workItem = queryResult.nextElement();
      ObjectReference objectReference = workItem.getSource();
      WfAssignedActivity wfAssignedActivity = (WfAssignedActivity)objectReference.getObject();
      wfProcess = wfAssignedActivity.getParentProcess();
      if (wfProcess.getState().equals(wfState)) {
        if (VERBOSE)
          System.out.println("WF Process State " + wfProcess.getState()); 
        if (CUSTOMER_VERFICATION && wfAssignedActivity.getName().equalsIgnoreCase(VERIFY_TASK_NAME)) {
          UserEventVector userEventVector = getUserEvent(wfAssignedActivity, VERIFY_EVENT);
          if (VERBOSE)
            System.out.println("Completing verification activity " + wfAssignedActivity.getName() + " with event" + userEventVector); 
          wfAssignedActivity.complete((Vector)userEventVector);
          continue;
        } 
        if (CUSTOMER_VALIDATION && wfAssignedActivity.getName().equalsIgnoreCase(VALIDATE_TASK_NAME)) {
          UserEventVector userEventVector = getUserEvent(wfAssignedActivity, VALIDATE_EVENT);
          if (VERBOSE)
            System.out.println("Completing validation activity " + wfAssignedActivity.getName() + " with event" + userEventVector); 
          wfAssignedActivity.complete((Vector)userEventVector);
        } 
      } 
    } 
  }
  
  private static UserEventVector getUserEvent(WfAssignedActivity paramWfAssignedActivity, String paramString) {
    UserEventVector userEventVector = paramWfAssignedActivity.getUserEventList();
    for (String str : userEventVector.toVector()) {
      if (!str.equalsIgnoreCase(paramString))
        userEventVector.remove(str); 
    } 
    return userEventVector;
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\packages\custome\\util\DesignProcessHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */