package ext.piab.packages.design.util;

import com.ptc.core.relcontext.server.ContextLink;
import com.ptc.windchill.wp.AbstractWorkPackage;
import com.ptc.windchill.wp.WorkPackage;
import com.ptc.windchill.wp.delivery.DeliveryHelper;
import com.ptc.windchill.wp.delivery.DeliveryRecord;
import ext.piab.common.util.PropertyforPIAB;
import ext.piab.common.util.Teamhelper;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import wt.facade.persistedcollection.PersistedCollectionHelper;
import wt.facade.persistedcollection.PersistedCollectionMembership;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.collections.WTSet;
import wt.inf.team.ContainerTeamManaged;
import wt.org.WTPrincipal;
import wt.org.WTPrincipalReference;
import wt.project.Role;
import wt.projmgmt.admin.Project2;
import wt.type.TypedUtility;

public class RelatedSupplers {
  private static final boolean VERBOSE = PropertyforPIAB.VERBOSE;
  
  private static final String SUPPLIER_PACKAGE_TYPE_NAME = PropertyforPIAB.SUPPLIER_PACKAGE_TYPE_NAME;
  
  private static final String SUPPLIER_ROLES = PropertyforPIAB.SUPPLIER_ROLES;
  
  public static HashMap getRelatedSupplierProjects(Persistable paramPersistable, HashMap<Object, Object> paramHashMap) throws Exception {
    if (paramHashMap == null)
      paramHashMap = new HashMap<>(); 
    Project2 project2 = null;
    WTPrincipal wTPrincipal = null;
    ArrayList<Persistable> arrayList = null;
    HashMap<Object, Object> hashMap = null;
    try {
      if (VERBOSE)
        System.out.println("RelatedSupplers.getRelatedSupplerProjects ()" + paramPersistable); 
      PersistedCollectionMembership persistedCollectionMembership = PersistedCollectionHelper.service.getMemberOf(paramPersistable);
      WTSet wTSet = (WTSet)persistedCollectionMembership.getDirectSet().subCollection(AbstractWorkPackage.class);
      wTSet.addAll((Collection)persistedCollectionMembership.getNestedSet().subCollection(AbstractWorkPackage.class));
      Iterator<WorkPackage> iterator = wTSet.persistableIterator();
      while (iterator.hasNext()) {
        WorkPackage workPackage = iterator.next();
        if (VERBOSE)
          System.out.println("WorkPackage is-" + workPackage + "Name is " + workPackage.getName()); 
        if (VERBOSE)
          System.out.println("WorkPackage- " + TypedUtility.getTypeIdentifier(workPackage).toString()); 
        if (TypedUtility.getTypeIdentifier(workPackage).toString().endsWith(SUPPLIER_PACKAGE_TYPE_NAME)) {
          Enumeration<DeliveryRecord> enumeration = DeliveryHelper.getService().getDeliveriesForWorkPackage((AbstractWorkPackage)workPackage);
          if (VERBOSE)
            System.out.println("***isLatest-" + workPackage.isLatestIteration()); 
          while (enumeration.hasMoreElements()) {
            DeliveryRecord deliveryRecord = enumeration.nextElement();
            if (VERBOSE)
              System.out.println("***Getting Items for Record: " + deliveryRecord.getNumber()); 
            if (deliveryRecord.isDelivered()) {
              if (VERBOSE)
                System.out.println("INSIDE Supplier- " + workPackage.getNumber()); 
              QueryResult queryResult = PersistenceHelper.manager.navigate((Persistable)workPackage.getMaster(), "context", ContextLink.class);
              if (VERBOSE)
                System.out.println("SupProjectSize- " + queryResult.size()); 
              while (queryResult.hasMoreElements()) {
                project2 = (Project2)queryResult.nextElement();
                String[] arrayOfString = SUPPLIER_ROLES.split(",");
                for (byte b = 0; b < arrayOfString.length; b++) {
                  if (VERBOSE)
                    System.out.println("splitted role" + arrayOfString[b]); 
                  ArrayList<WTPrincipalReference> arrayList1 = Teamhelper.getParticipants((ContainerTeamManaged)project2, Role.toRole(arrayOfString[b]));
                  if (!arrayList1.isEmpty())
                    for (byte b1 = 0; b1 < arrayList1.size(); b1++) {
                      WTPrincipalReference wTPrincipalReference = arrayList1.get(b1);
                      wTPrincipal = wTPrincipalReference.getPrincipal();
                      if (VERBOSE)
                        System.out.println("*****Principal: " + wTPrincipal.getName()); 
                      if (VERBOSE)
                        System.out.println("******wtobject: " + paramPersistable); 
                      hashMap = (HashMap)paramHashMap.get(wTPrincipal);
                      if (hashMap == null) {
                        hashMap = new HashMap<>();
                        arrayList = new ArrayList();
                        arrayList.add(paramPersistable);
                      } else {
                        arrayList = (ArrayList<Persistable>)hashMap.get(deliveryRecord);
                        if (arrayList == null)
                          arrayList = new ArrayList<>(); 
                        arrayList.add(paramPersistable);
                      } 
                      hashMap.put(deliveryRecord, arrayList);
                      paramHashMap.put(wTPrincipal, hashMap);
                    }  
                  if (VERBOSE)
                    System.out.println("Supplier Project-" + project2.getProjectNumber()); 
                  if (VERBOSE)
                    System.out.println("Supplier Project-" + project2.getOwner().getName()); 
                } 
              } 
            } 
          } 
        } 
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return paramHashMap;
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\packages\desig\\util\RelatedSupplers.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */