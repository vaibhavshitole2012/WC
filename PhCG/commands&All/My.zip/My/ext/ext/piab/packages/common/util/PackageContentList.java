package ext.piab.packages.common.util;

import com.ptc.windchill.wp.AbstractWorkPackage;
import com.ptc.windchill.wp.WPHelper;
import com.ptc.windchill.wp.WorkPackage;
import ext.piab.common.util.PropertyforPIAB;
import java.util.Collection;
import wt.enterprise.RevisionControlled;
import wt.fc.ObjectReference;
import wt.fc.WTObject;
import wt.fc.collections.WTArrayList;
import wt.fc.collections.WTSet;
import wt.method.RemoteAccess;

public class PackageContentList implements RemoteAccess {
  private static final boolean VERBOSE = PropertyforPIAB.VERBOSE;
  
  private static final boolean INCLUDEINITIALLYSELECTED = PropertyforPIAB.INCLUDEINITIALLYSELECTED;
  
  private static final boolean INCLUDEALLCONTENTS = PropertyforPIAB.INCLUDEALLCONTENTS;
  
  private static final boolean INCLUDEALPHA = PropertyforPIAB.INCLUDEALPHA;
  
  private static final boolean INCLUDENUMERIC = PropertyforPIAB.INCLUDENUMERIC;
  
  private static final boolean CHECK_INCLUDE_DEPENDENTS = PropertyforPIAB.CHECK_INCLUDE_DEPENDENTS;
  
  public static WTSet getALLPackageContents(WorkPackage paramWorkPackage) {
    if (VERBOSE)
      System.out.println("***PackageContentList.getALLPackageContents()"); 
    WTSet wTSet = null;
    try {
      wTSet = WPHelper.service.getAllMembers((AbstractWorkPackage)paramWorkPackage);
      if (VERBOSE)
        System.out.println("*****size: " + wTSet.size()); 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return wTSet;
  }
  
  public static WTSet getinitiallyselected(WorkPackage paramWorkPackage) {
    if (VERBOSE)
      System.out.println("***PackageContentList.getinitiallyselected"); 
    WTSet wTSet = null;
    try {
      wTSet = WPHelper.service.getAllSeeds((AbstractWorkPackage)paramWorkPackage);
      if (VERBOSE && VERBOSE)
        System.out.println("*****SIZE:" + wTSet.size()); 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return wTSet;
  }
  
  public static WTArrayList getContentsList(WorkPackage paramWorkPackage) throws Exception {
    if (VERBOSE)
      System.out.println("***PackageContentList.getContentsList()"); 
    WTArrayList wTArrayList = new WTArrayList();
    try {
      WTSet wTSet = filterbyInitiallySelected(paramWorkPackage);
      Object[] arrayOfObject = wTSet.toArray();
      for (byte b = 0; b < arrayOfObject.length; b++) {
        ObjectReference objectReference = (ObjectReference)arrayOfObject[b];
        WTObject wTObject = (WTObject)objectReference.getObject();
        String str = ((RevisionControlled)wTObject).getVersionInfo().getIdentifier().getValue();
        if (INCLUDEALPHA && !Character.isDigit(str.charAt(0)))
          wTArrayList.addElement(wTObject); 
        if (INCLUDENUMERIC && Character.isDigit(str.charAt(0)))
          wTArrayList.addElement(wTObject); 
      } 
      if (VERBOSE)
        System.out.println("*** contentsList SIZE : " + wTArrayList.size()); 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return wTArrayList;
  }
  
  public static WTSet getdependents(WorkPackage paramWorkPackage) {
    if (VERBOSE)
      System.out.println("***PackageContentList.getdependents()"); 
    WTSet wTSet = null;
    try {
      wTSet = getALLPackageContents(paramWorkPackage);
      WTSet wTSet1 = getinitiallyselected(paramWorkPackage);
      wTSet.removeAll((Collection)wTSet1);
      if (VERBOSE)
        System.out.println("***Size of only Dependents " + wTSet.size()); 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return wTSet;
  }
  
  public static WTSet filterbyInitiallySelected(WorkPackage paramWorkPackage) {
    if (VERBOSE)
      System.out.println("***PackageContentList.filterbyInitiallySelected()"); 
    WTSet wTSet = null;
    try {
      if (INCLUDEINITIALLYSELECTED) {
        wTSet = getinitiallyselected(paramWorkPackage);
      } else {
        wTSet = getALLPackageContents(paramWorkPackage);
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return wTSet;
  }
  
  public static WTSet filterbyIncludeAll(WorkPackage paramWorkPackage) {
    if (VERBOSE)
      System.out.println("***PackageContentList.filterbyIncludeAll()"); 
    WTSet wTSet = null;
    try {
      if (INCLUDEALLCONTENTS) {
        wTSet = getALLPackageContents(paramWorkPackage);
      } else {
        wTSet = getinitiallyselected(paramWorkPackage);
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return wTSet;
  }
  
  public static WTSet filterbyIncludeDependents(WorkPackage paramWorkPackage) {
    if (VERBOSE)
      System.out.println("***PackageContentList.filterbyIncludeDependents()"); 
    WTSet wTSet = null;
    try {
      if (CHECK_INCLUDE_DEPENDENTS) {
        wTSet = getALLPackageContents(paramWorkPackage);
      } else {
        wTSet = getinitiallyselected(paramWorkPackage);
      } 
      if (VERBOSE)
        System.out.println("***:Size " + wTSet.size()); 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return wTSet;
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\packages\commo\\util\PackageContentList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */