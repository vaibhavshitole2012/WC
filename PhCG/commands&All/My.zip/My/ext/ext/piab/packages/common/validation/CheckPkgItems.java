package ext.piab.packages.common.validation;

import com.ptc.windchill.wp.WorkPackage;
import ext.piab.common.util.PropertyforPIAB;
import ext.piab.common.util.ReviseUtility;
import ext.piab.common.validation.ErrorMesageContent;
import ext.piab.common.validation.ValidateObjetcs;
import ext.piab.packages.common.resource.PackagesResource;
import ext.piab.packages.common.util.PackageContentList;
import wt.enterprise.RevisionControlled;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.WTObject;
import wt.fc.collections.WTSet;
import wt.method.RemoteAccess;
import wt.util.WTException;
import wt.vc.wip.WorkInProgressHelper;
import wt.vc.wip.Workable;

public class CheckPkgItems implements RemoteAccess {
  private static final boolean VERBOSE = PropertyforPIAB.VERBOSE;
  
  private static final boolean CHECK_INCLUDE_DEPENDENTS = PropertyforPIAB.CHECK_INCLUDE_DEPENDENTS;
  
  private static final String PACKAGES_RESOURCE = PackagesResource.class.getName();
  
  public static void isCheckedOut(WorkPackage paramWorkPackage) throws Exception {
    if (VERBOSE)
      System.out.println("***CheckPkgItems.isCheckedOut()"); 
    boolean bool = false;
    StringBuilder stringBuilder = new StringBuilder();
    WTSet wTSet = PackageContentList.filterbyIncludeDependents(paramWorkPackage);
    if (wTSet != null) {
      Object[] arrayOfObject = wTSet.toArray();
      for (byte b = 0; b < arrayOfObject.length; b++) {
        ObjectReference objectReference = (ObjectReference)arrayOfObject[b];
        WTObject wTObject = (WTObject)objectReference.getObject();
        bool = WorkInProgressHelper.isCheckedOut((Workable)wTObject);
        if (bool)
          stringBuilder = ErrorMesageContent.errorMsg(wTObject, stringBuilder); 
      } 
    } 
    String str = stringBuilder.toString();
    if (!str.isEmpty()) {
      if (VERBOSE)
        System.out.println("***Objects in the Package contents is  checked out."); 
      Object[] arrayOfObject = { str, paramWorkPackage.getName() };
      throw new WTException(PACKAGES_RESOURCE, "0", arrayOfObject);
    } 
  }
  
  public static void isLatest(WorkPackage paramWorkPackage, boolean paramBoolean) throws Exception {
    if (VERBOSE)
      System.out.println("***CheckPkgItems.isLatest()"); 
    StringBuilder stringBuilder = new StringBuilder();
    WTSet wTSet = PackageContentList.filterbyIncludeDependents(paramWorkPackage);
    if (wTSet != null) {
      Object[] arrayOfObject = wTSet.toArray();
      for (byte b = 0; b < arrayOfObject.length; b++) {
        ObjectReference objectReference = (ObjectReference)arrayOfObject[b];
        WTObject wTObject1 = (WTObject)objectReference.getObject();
        WTObject wTObject2 = ReviseUtility.getLatestRevision(wTObject1);
        if (VERBOSE)
          System.out.println("***Latest Iteration : " + ((RevisionControlled)wTObject2).isLatestIteration()); 
        if (!wTObject2.equals(wTObject1) || !((RevisionControlled)wTObject2).isLatestIteration())
          stringBuilder = ErrorMesageContent.errorMsg(wTObject1, stringBuilder); 
      } 
    } 
    String str = stringBuilder.toString();
    if (!str.isEmpty()) {
      if (VERBOSE)
        System.out.println("***Objects in the Package are Outdated"); 
      Object[] arrayOfObject = { str, paramWorkPackage.getName() };
      if (paramBoolean)
        throw new WTException(PACKAGES_RESOURCE, "1", arrayOfObject); 
      throw new WTException(PACKAGES_RESOURCE, "2", arrayOfObject);
    } 
  }
  
  public static void checkLcStates(Persistable paramPersistable) throws Exception {
    if (VERBOSE)
      System.out.println("*** CheckPkgItems.checkLcStates()"); 
    if (paramPersistable instanceof WorkPackage) {
      WorkPackage workPackage = (WorkPackage)paramPersistable;
      WTSet wTSet = null;
      if (CHECK_INCLUDE_DEPENDENTS) {
        wTSet = PackageContentList.getALLPackageContents(workPackage);
      } else {
        wTSet = PackageContentList.getinitiallyselected(workPackage);
      } 
      if (VERBOSE)
        System.out.println("***Size of Package items " + wTSet.size()); 
      if (!wTSet.isEmpty())
        ValidateObjetcs.incorrectObject((Persistable)workPackage, wTSet.toArray()); 
    } 
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\packages\common\validation\CheckPkgItems.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */