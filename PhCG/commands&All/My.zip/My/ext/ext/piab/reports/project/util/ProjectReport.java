package ext.piab.reports.project.util;

import com.ptc.core.relcontext.server.ContextLink;
import com.ptc.windchill.wp.WorkPackage;
import com.ptc.windchill.wp.WorkPackageMaster;
import java.util.ArrayList;
import java.util.Iterator;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.fc.WTReference;
import wt.httpgw.URLFactory;
import wt.method.RemoteAccess;
import wt.pds.StatementSpec;
import wt.projmgmt.admin.Project2;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.query.WhereExpression;
import wt.session.SessionHelper;
import wt.type.TypedUtility;
import wt.util.WTProperties;
import wt.vc.Mastered;
import wt.vc.VersionControlHelper;

public class ProjectReport implements RemoteAccess {
  public static final String SUPPLIER_PACKAGE_TYPE_NAME;
  
  public static final String DESIGN_PACKAGE_TYPE_NAME;
  
  public static ArrayList<Project2> searchProjects(String paramString) throws Exception {
    ArrayList<Project2> arrayList = new ArrayList();
    if (paramString.startsWith("*"))
      paramString = "%" + paramString.substring(1); 
    if (paramString.endsWith("*"))
      paramString = paramString.substring(0, paramString.length() - 1) + "%"; 
    QuerySpec querySpec = new QuerySpec(Project2.class);
    SearchCondition searchCondition = new SearchCondition(Project2.class, "projectNumber", "LIKE", paramString, false);
    querySpec.appendWhere((WhereExpression)searchCondition, new int[] { 0, 1 });
    try {
      querySpec.setDescendantQuery(false);
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    QueryResult queryResult = PersistenceHelper.manager.find((StatementSpec)querySpec);
    while (queryResult.hasMoreElements())
      arrayList.add((Project2)queryResult.nextElement()); 
    return arrayList;
  }
  
  public static ArrayList getDesignPackages(Project2 paramProject2) throws Exception {
    ArrayList<String> arrayList = new ArrayList();
    QueryResult queryResult = PersistenceHelper.manager.navigate((Persistable)paramProject2, "roleBObject", ContextLink.class);
    while (queryResult.hasMoreElements()) {
      WorkPackageMaster workPackageMaster = (WorkPackageMaster)queryResult.nextElement();
      QueryResult queryResult1 = VersionControlHelper.service.allVersionsOf((Mastered)workPackageMaster);
      WorkPackage workPackage = (WorkPackage)queryResult1.nextElement();
      if (TypedUtility.getTypeIdentifier(workPackage).toString().endsWith(DESIGN_PACKAGE_TYPE_NAME)) {
        String str = generatePackageURL(workPackage);
        arrayList.add("<a href = \" " + str + "\"target= \"_blank|_self\" > " + workPackage.getNumber() + " (" + workPackage.getVersionIdentifier().getValue() + ") " + workPackage.getLifeCycleState().getDisplay() + "</a>");
      } 
    } 
    return arrayList;
  }
  
  public static ArrayList getSupplierPackages(Project2 paramProject2) throws Exception {
    ArrayList<String> arrayList = new ArrayList();
    QueryResult queryResult = PersistenceHelper.manager.navigate((Persistable)paramProject2, "roleBObject", ContextLink.class);
    while (queryResult.hasMoreElements()) {
      WorkPackageMaster workPackageMaster = (WorkPackageMaster)queryResult.nextElement();
      QueryResult queryResult1 = VersionControlHelper.service.allVersionsOf((Mastered)workPackageMaster);
      WorkPackage workPackage = (WorkPackage)queryResult1.nextElement();
      if (TypedUtility.getTypeIdentifier(workPackage).toString().endsWith(SUPPLIER_PACKAGE_TYPE_NAME)) {
        String str = generatePackageURL(workPackage);
        arrayList.add("<a href = \" " + str + "\"target= \"_blank|_self\" > " + workPackage.getNumber() + " (" + workPackage.getVersionIdentifier().getValue() + ") " + workPackage.getLifeCycleState().getDisplay() + "</a>");
      } 
    } 
    return arrayList;
  }
  
  public static ArrayList<ProjectReportBean> getReportRows(String paramString1, String paramString2) throws Exception {
    String str = SessionHelper.manager.getPrincipal().getName();
    SessionHelper.manager.setAdministrator();
    ArrayList<ProjectReportBean> arrayList = new ArrayList();
    ArrayList<Project2> arrayList1 = searchProjects(paramString1);
    Iterator<Project2> iterator = arrayList1.iterator();
    while (iterator.hasNext()) {
      ProjectReportBean projectReportBean = new ProjectReportBean();
      Project2 project2 = iterator.next();
      projectReportBean.setName(project2.getName());
      projectReportBean.setNumber(project2.getProjectNumber());
      projectReportBean.setPhase(project2.getPhase().getDisplay());
      if (paramString2.equalsIgnoreCase("Supplier Package")) {
        projectReportBean.setSupPkges(getSupplierPackages(project2));
      } else if (paramString2.equalsIgnoreCase("Design Package")) {
        projectReportBean.setDesPkges(getDesignPackages(project2));
      } 
      arrayList.add(projectReportBean);
    } 
    SessionHelper.manager.setPrincipal(str);
    return arrayList;
  }
  
  public static String generatePackageURL(WorkPackage paramWorkPackage) throws Exception {
    null = null;
    ReferenceFactory referenceFactory = new ReferenceFactory();
    WTReference wTReference = referenceFactory.getReference((Persistable)paramWorkPackage);
    String str = referenceFactory.getReferenceString(wTReference);
    URLFactory uRLFactory = new URLFactory();
    return uRLFactory.getHREF("/servlet/TypeBasedIncludeServlet?oid=" + str);
  }
  
  static {
    try {
      WTProperties wTProperties = WTProperties.getLocalProperties();
      SUPPLIER_PACKAGE_TYPE_NAME = wTProperties.getProperty("ext.piab.workflow.supplierpackagetypename", "SupplierPackage");
      DESIGN_PACKAGE_TYPE_NAME = wTProperties.getProperty("ext.piab.workflow.designpackagetypename", "DesignPackage");
    } catch (Throwable throwable) {
      System.err.println("Error initializing ");
      throwable.printStackTrace(System.err);
      throw new ExceptionInInitializerError(throwable);
    } 
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\reports\projec\\util\ProjectReport.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */