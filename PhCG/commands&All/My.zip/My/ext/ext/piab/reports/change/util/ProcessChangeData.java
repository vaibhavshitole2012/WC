package ext.piab.reports.change.util;

import com.ptc.core.relcontext.server.ContextLink;
import com.ptc.windchill.wp.AbstractWorkPackage;
import com.ptc.windchill.wp.WorkPackage;
import com.ptc.windchill.wp.WorkPackageMaster;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import wt.change2.ChangeActivityIfc;
import wt.change2.ChangeHelper2;
import wt.change2.ChangeOrderIfc;
import wt.change2.ChangeRequestIfc;
import wt.change2.WTChangeActivity2;
import wt.change2.WTChangeOrder2;
import wt.change2.WTChangeRequest2;
import wt.doc.WTDocument;
import wt.epm.EPMDocument;
import wt.facade.persistedcollection.PersistedCollectionHelper;
import wt.facade.persistedcollection.PersistedCollectionMembership;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.fc.WTObject;
import wt.fc.WTReference;
import wt.fc.collections.WTSet;
import wt.httpgw.URLFactory;
import wt.part.WTPart;
import wt.pom.PersistenceException;
import wt.projmgmt.admin.Project2;
import wt.type.TypedUtility;
import wt.util.WTException;
import wt.util.WTProperties;
import wt.vc.Mastered;
import wt.vc.VersionControlHelper;

public class ProcessChangeData {
  public static final String SUPPLIER_PACKAGE_TYPE_NAME;
  
  public static final String DESIGN_PACKAGE_TYPE_NAME;
  
  public ArrayList<ChangeReportBean> processCR(WTChangeRequest2 paramWTChangeRequest2) throws Exception {
    HashMap<Object, Object> hashMap1 = new HashMap<>();
    HashMap<Object, Object> hashMap2 = new HashMap<>();
    null = new ArrayList();
    QueryResult queryResult = ChangeHelper2.service.getChangeables((ChangeRequestIfc)paramWTChangeRequest2);
    while (queryResult.hasMoreElements()) {
      ChangeReportBean changeReportBean = setChangeDataAttributes((WTObject)queryResult.nextElement(), false);
      hashMap1.put(changeReportBean.getNumber(), changeReportBean);
    } 
    return getConsolidatedChangeItems(hashMap1, hashMap2);
  }
  
  public ArrayList<ChangeReportBean> processCN(WTChangeOrder2 paramWTChangeOrder2) throws Exception {
    HashMap<Object, Object> hashMap1 = new HashMap<>();
    HashMap<Object, Object> hashMap2 = new HashMap<>();
    null = new ArrayList();
    QueryResult queryResult = ChangeHelper2.service.getChangeActivities((ChangeOrderIfc)paramWTChangeOrder2);
    while (queryResult.hasMoreElements()) {
      WTChangeActivity2 wTChangeActivity2 = (WTChangeActivity2)queryResult.nextElement();
      QueryResult queryResult1 = ChangeHelper2.service.getChangeablesBefore((ChangeActivityIfc)wTChangeActivity2);
      while (queryResult1.hasMoreElements()) {
        ChangeReportBean changeReportBean = setChangeDataAttributes((WTObject)queryResult1.nextElement(), false);
        hashMap1.put(changeReportBean.getNumber(), changeReportBean);
      } 
      QueryResult queryResult2 = ChangeHelper2.service.getChangeablesAfter((ChangeActivityIfc)wTChangeActivity2);
      while (queryResult2.hasMoreElements()) {
        ChangeReportBean changeReportBean = setChangeDataAttributes((WTObject)queryResult2.nextElement(), true);
        hashMap2.put(changeReportBean.getNumber(), changeReportBean);
      } 
    } 
    return getConsolidatedChangeItems(hashMap1, hashMap2);
  }
  
  public ArrayList<ChangeReportBean> processCA(WTChangeActivity2 paramWTChangeActivity2) throws Exception {
    HashMap<Object, Object> hashMap1 = new HashMap<>();
    HashMap<Object, Object> hashMap2 = new HashMap<>();
    null = new ArrayList();
    QueryResult queryResult1 = ChangeHelper2.service.getChangeablesBefore((ChangeActivityIfc)paramWTChangeActivity2);
    while (queryResult1.hasMoreElements()) {
      ChangeReportBean changeReportBean = setChangeDataAttributes((WTObject)queryResult1.nextElement(), false);
      hashMap1.put(changeReportBean.getNumber(), changeReportBean);
    } 
    QueryResult queryResult2 = ChangeHelper2.service.getChangeablesAfter((ChangeActivityIfc)paramWTChangeActivity2);
    while (queryResult2.hasMoreElements()) {
      ChangeReportBean changeReportBean = setChangeDataAttributes((WTObject)queryResult2.nextElement(), true);
      hashMap2.put(changeReportBean.getNumber(), changeReportBean);
    } 
    return getConsolidatedChangeItems(hashMap1, hashMap2);
  }
  
  public ArrayList getRelatedSupplierPackages(Persistable paramPersistable) throws Exception {
    ArrayList<WorkPackage> arrayList = new ArrayList();
    try {
      PersistedCollectionMembership persistedCollectionMembership = PersistedCollectionHelper.service.getMemberOf(paramPersistable);
      WTSet wTSet = (WTSet)persistedCollectionMembership.getDirectSet().subCollection(AbstractWorkPackage.class);
      wTSet.addAll((Collection)persistedCollectionMembership.getNestedSet().subCollection(AbstractWorkPackage.class));
      Iterator<WorkPackage> iterator = wTSet.persistableIterator();
      while (iterator.hasNext()) {
        WorkPackage workPackage = iterator.next();
        if (TypedUtility.getTypeIdentifier(workPackage).toString().endsWith(SUPPLIER_PACKAGE_TYPE_NAME) && isPkgLatestVersion(workPackage))
          arrayList.add(workPackage); 
      } 
    } catch (WTException wTException) {
      wTException.printStackTrace();
    } 
    return arrayList;
  }
  
  public ArrayList getRelatedDesignPackages(Persistable paramPersistable) throws Exception {
    ArrayList<WorkPackage> arrayList = new ArrayList();
    try {
      PersistedCollectionMembership persistedCollectionMembership = PersistedCollectionHelper.service.getMemberOf(paramPersistable);
      WTSet wTSet = (WTSet)persistedCollectionMembership.getDirectSet().subCollection(AbstractWorkPackage.class);
      wTSet.addAll((Collection)persistedCollectionMembership.getNestedSet().subCollection(AbstractWorkPackage.class));
      Iterator<WorkPackage> iterator = wTSet.persistableIterator();
      while (iterator.hasNext()) {
        WorkPackage workPackage = iterator.next();
        if (TypedUtility.getTypeIdentifier(workPackage).toString().endsWith(DESIGN_PACKAGE_TYPE_NAME) && isPkgLatestVersion(workPackage))
          arrayList.add(workPackage); 
      } 
    } catch (WTException wTException) {
      wTException.printStackTrace();
    } 
    return arrayList;
  }
  
  public ArrayList getRelateddpProjects(WorkPackage paramWorkPackage) throws Exception {
    ArrayList<Project2> arrayList = new ArrayList();
    try {
      if (TypedUtility.getTypeIdentifier(paramWorkPackage).toString().endsWith(DESIGN_PACKAGE_TYPE_NAME) && isPkgLatestVersion(paramWorkPackage)) {
        QueryResult queryResult = PersistenceHelper.manager.navigate((Persistable)paramWorkPackage.getMaster(), "roleAObject", ContextLink.class, true);
        while (queryResult.hasMoreElements()) {
          Project2 project2 = (Project2)queryResult.nextElement();
          arrayList.add(project2);
        } 
      } 
    } catch (WTException wTException) {
      wTException.printStackTrace();
    } 
    return arrayList;
  }
  
  public ArrayList getRelatedspProjects(WorkPackage paramWorkPackage) throws Exception {
    ArrayList<Project2> arrayList = new ArrayList();
    try {
      if (TypedUtility.getTypeIdentifier(paramWorkPackage).toString().endsWith(SUPPLIER_PACKAGE_TYPE_NAME) && isPkgLatestVersion(paramWorkPackage)) {
        QueryResult queryResult = PersistenceHelper.manager.navigate((Persistable)paramWorkPackage.getMaster(), "roleAObject", ContextLink.class, true);
        while (queryResult.hasMoreElements()) {
          Project2 project2 = (Project2)queryResult.nextElement();
          arrayList.add(project2);
        } 
      } 
    } catch (WTException wTException) {
      wTException.printStackTrace();
    } 
    return arrayList;
  }
  
  public String getpkgdisplay(WorkPackage paramWorkPackage) throws Exception {
    StringBuilder stringBuilder = new StringBuilder();
    String str = generatePackageURL(paramWorkPackage);
    stringBuilder.append("<a href = \" " + str + "\"target= \"_blank|_self\" > " + paramWorkPackage.getNumber() + " (" + paramWorkPackage.getVersionIdentifier().getValue() + ") " + paramWorkPackage.getLifeCycleState().getDisplay() + "</a>");
    return stringBuilder.toString();
  }
  
  public String getprojdisplay(Project2 paramProject2) throws Exception {
    StringBuilder stringBuilder = new StringBuilder();
    String str = generateURL((WTObject)paramProject2);
    stringBuilder.append("<a href = \" " + str + "\"target= \"_blank|_self\" > " + paramProject2.getName() + " (" + paramProject2.getProjectNumber() + ")</a>");
    return stringBuilder.toString();
  }
  
  public ChangeReportBean setChangeDataAttributes(WTObject paramWTObject, boolean paramBoolean) throws Exception {
    ChangeReportBean changeReportBean = new ChangeReportBean();
    ArrayList arrayList1 = getRelatedSupplierPackages((Persistable)paramWTObject);
    changeReportBean.setSupplierPkgs(arrayList1);
    ArrayList arrayList2 = getRelatedDesignPackages((Persistable)paramWTObject);
    changeReportBean.setDesignPkgs(arrayList2);
    changeReportBean.setIsResulting(paramBoolean);
    if (paramWTObject instanceof EPMDocument) {
      changeReportBean.setName(((EPMDocument)paramWTObject).getName());
      changeReportBean.setNumber(((EPMDocument)paramWTObject).getNumber());
      changeReportBean.setState(((EPMDocument)paramWTObject).getLifeCycleState().getDisplay());
      changeReportBean.setRevision(((EPMDocument)paramWTObject).getVersionIdentifier().getValue() + "." + ((EPMDocument)paramWTObject).getIterationIdentifier().getValue());
    } else if (paramWTObject instanceof WTPart) {
      changeReportBean.setName(((WTPart)paramWTObject).getName());
      changeReportBean.setNumber(((WTPart)paramWTObject).getNumber());
      changeReportBean.setState(((WTPart)paramWTObject).getLifeCycleState().getDisplay());
      changeReportBean.setRevision(((WTPart)paramWTObject).getVersionIdentifier().getValue() + "." + ((WTPart)paramWTObject).getIterationIdentifier().getValue());
    } else if (paramWTObject instanceof WTDocument) {
      changeReportBean.setName(((WTDocument)paramWTObject).getName());
      changeReportBean.setNumber(((WTDocument)paramWTObject).getNumber());
      changeReportBean.setState(((WTDocument)paramWTObject).getLifeCycleState().getDisplay());
      changeReportBean.setRevision(((WTDocument)paramWTObject).getVersionIdentifier().getValue() + "." + ((WTDocument)paramWTObject).getIterationIdentifier().getValue());
    } 
    return changeReportBean;
  }
  
  public ArrayList getConsolidatedChangeItems(HashMap paramHashMap1, HashMap paramHashMap2) {
    ArrayList<ChangeReportBean> arrayList = new ArrayList();
    if (!paramHashMap1.isEmpty() && !paramHashMap2.isEmpty()) {
      Iterator<Map.Entry> iterator = paramHashMap1.entrySet().iterator();
      while (iterator.hasNext()) {
        Map.Entry entry = iterator.next();
        if (paramHashMap2.containsKey(entry.getKey())) {
          arrayList.add((ChangeReportBean)paramHashMap1.get(entry.getKey()));
          arrayList.add((ChangeReportBean)paramHashMap2.get(entry.getKey()));
          iterator.remove();
          paramHashMap1.remove(entry.getKey());
          paramHashMap2.remove(entry.getKey());
        } 
      } 
    } 
    arrayList.addAll(paramHashMap1.values());
    arrayList.addAll(paramHashMap2.values());
    return arrayList;
  }
  
  public String generatePackageURL(WorkPackage paramWorkPackage) throws Exception {
    null = null;
    ReferenceFactory referenceFactory = new ReferenceFactory();
    WTReference wTReference = referenceFactory.getReference((Persistable)paramWorkPackage);
    String str = referenceFactory.getReferenceString(wTReference);
    URLFactory uRLFactory = new URLFactory();
    return uRLFactory.getHREF("/servlet/TypeBasedIncludeServlet?oid=" + str);
  }
  
  public String generateURL(WTObject paramWTObject) throws Exception {
    null = null;
    ReferenceFactory referenceFactory = new ReferenceFactory();
    WTReference wTReference = referenceFactory.getReference((Persistable)paramWTObject);
    String str = referenceFactory.getReferenceString(wTReference);
    URLFactory uRLFactory = new URLFactory();
    return uRLFactory.getHREF("/servlet/TypeBasedIncludeServlet?oid=" + str);
  }
  
  public boolean isPkgLatestVersion(WorkPackage paramWorkPackage) throws PersistenceException, WTException {
    WorkPackageMaster workPackageMaster = (WorkPackageMaster)paramWorkPackage.getMaster();
    QueryResult queryResult = VersionControlHelper.service.allVersionsOf((Mastered)workPackageMaster);
    WorkPackage workPackage = (WorkPackage)queryResult.nextElement();
    return workPackage.getVersionIdentifier().getValue().equals(paramWorkPackage.getVersionIdentifier().getValue());
  }
  
  static {
    try {
      WTProperties wTProperties = WTProperties.getLocalProperties();
      SUPPLIER_PACKAGE_TYPE_NAME = wTProperties.getProperty("ext.piab.workflow.supplierpackagetypename", "SupplierPackage");
      DESIGN_PACKAGE_TYPE_NAME = wTProperties.getProperty("ext.piab.workflow.designpackagetypename", "DesignPackage");
    } catch (Throwable throwable) {
      System.err.println("Error initializing ");
      throwable.printStackTrace(System.err);
      throw new ExceptionInInitializerError(throwable);
    } 
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\reports\chang\\util\ProcessChangeData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */