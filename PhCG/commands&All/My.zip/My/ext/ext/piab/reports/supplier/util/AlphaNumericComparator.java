package ext.piab.reports.supplier.util;

import java.text.Collator;
import java.util.Comparator;

public class AlphaNumericComparator implements Comparator<SuppliePackageReportBean> {
  static Collator _collator = Collator.getInstance();
  
  public int compare(SuppliePackageReportBean paramSuppliePackageReportBean1, SuppliePackageReportBean paramSuppliePackageReportBean2) {
    System.out.println("*****Compare Called************");
    return paramSuppliePackageReportBean1.getDrawingNumber().equalsIgnoreCase(paramSuppliePackageReportBean2.getDrawingNumber()) ? (paramSuppliePackageReportBean1.getDrawingRevision().equalsIgnoreCase(paramSuppliePackageReportBean2.getDrawingRevision()) ? compare(paramSuppliePackageReportBean1.getIsLatestInPackage(), paramSuppliePackageReportBean2.getIsLatestInPackage()) : compare(paramSuppliePackageReportBean1.getDrawingRevision(), paramSuppliePackageReportBean2.getDrawingRevision())) : compare(paramSuppliePackageReportBean1.getDrawingNumber(), paramSuppliePackageReportBean2.getDrawingNumber());
  }
  
  public int compare(String paramString1, String paramString2) {
    for (byte b = 0; b < paramString1.length(); b++) {
      if (Character.isDigit(paramString1.charAt(b))) {
        if (paramString2.length() > b && Character.isDigit(paramString2.charAt(b))) {
          int i = _collator.compare(paramString1.substring(0, b), paramString2.substring(0, b));
          if (i == 0) {
            char c = paramString1.charAt(b);
            int j;
            for (j = b + 1; j < paramString1.length() && j - b < 9; j++) {
              c = paramString1.charAt(j);
              if (!Character.isDigit(c))
                break; 
            } 
            if (Character.isLetter(c))
              break; 
            c = paramString2.charAt(b);
            int k;
            for (k = b + 1; k < paramString2.length() && k - b < 9; k++) {
              c = paramString2.charAt(k);
              if (!Character.isDigit(c))
                break; 
            } 
            if (Character.isLetter(c))
              break; 
            i = Integer.parseInt(paramString1.substring(b, j)) - Integer.parseInt(paramString2.substring(b, k));
            if (i == 0)
              return compare((paramString1.length() > j) ? paramString1.substring(j, paramString1.length()) : "", (paramString2.length() > k) ? paramString2.substring(k, paramString2.length()) : ""); 
          } 
          return i;
        } 
        break;
      } 
    } 
    return _collator.compare(paramString1, paramString2);
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\reports\supplie\\util\AlphaNumericComparator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */