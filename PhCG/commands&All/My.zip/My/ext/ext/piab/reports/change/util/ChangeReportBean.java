package ext.piab.reports.change.util;

import java.io.Serializable;
import java.util.ArrayList;

public class ChangeReportBean implements Serializable {
  private ArrayList supPkges;
  
  private ArrayList desPkges;
  
  private String name;
  
  private String number;
  
  private String revision;
  
  private String state;
  
  private boolean isResulting;
  
  private ArrayList supProjs;
  
  private ArrayList dpProjs;
  
  public void setRevision(String paramString) {
    this.revision = paramString;
  }
  
  public String getRevision() {
    return this.revision;
  }
  
  public void setName(String paramString) {
    this.name = paramString;
  }
  
  public String getName() {
    return this.name;
  }
  
  public void setNumber(String paramString) {
    this.number = paramString;
  }
  
  public String getNumber() {
    return this.number;
  }
  
  public void setIsResulting(boolean paramBoolean) {
    this.isResulting = paramBoolean;
  }
  
  public boolean getIsResulting() {
    return this.isResulting;
  }
  
  public void setState(String paramString) {
    this.state = paramString;
  }
  
  public String getState() {
    return this.state;
  }
  
  public void setSupplierPkgs(ArrayList paramArrayList) {
    this.supPkges = paramArrayList;
  }
  
  public ArrayList getSupplierPkgs() {
    return this.supPkges;
  }
  
  public void setDesignPkgs(ArrayList paramArrayList) {
    this.desPkges = paramArrayList;
  }
  
  public ArrayList getDesignPkgs() {
    return this.desPkges;
  }
  
  public void setSupplierProjs(ArrayList paramArrayList) {
    this.supProjs = paramArrayList;
  }
  
  public ArrayList getSupplierProjs() {
    return this.supProjs;
  }
  
  public void setdesignProjs(ArrayList paramArrayList) {
    this.dpProjs = paramArrayList;
  }
  
  public ArrayList getDesignProjs() {
    return this.dpProjs;
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\reports\chang\\util\ChangeReportBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */