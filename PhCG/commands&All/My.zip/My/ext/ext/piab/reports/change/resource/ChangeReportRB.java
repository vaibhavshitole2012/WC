/*    */ package ext.piab.reports.change.resource;
/*    */ 
/*    */ import java.util.ListResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ChangeReportRB
/*    */   extends ListResourceBundle
/*    */ {
/* 16 */   static final Object[][] contents = new Object[][] { { "cm.caReport.description", "Change Analysis Report" }, { "cm.caReport.icon", "reports_24.png" }, { "cm.caReport.moreurlinfo", "width=800,height=700" }, { "cm.caReport.title", "Change Analysis Report" }, { "cm.caReport.tooltip", "Change Analysis Report" }, { "cm.cnReport.description", "Change Analysis Report" }, { "cm.cnReport.icon", "reports_24.png" }, { "cm.cnReport.moreurlinfo", "width=800,height=700" }, { "cm.cnReport.title", "Change Analysis Report" }, { "cm.cnReport.tooltip", "Change Analysis Report" }, { "cm.crReport.description", "Change Analysis Report" }, { "cm.crReport.icon", "reports_24.png" }, { "cm.crReport.moreurlinfo", "width=800,height=700" }, { "cm.crReport.title", "Change Analysis Report" }, { "cm.crReport.tooltip", "Change Analysis Report" } };
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object[][] getContents() {
/* 40 */     return contents;
/*    */   }
/*    */ }


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\reports\change\resource\ChangeReportRB.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */