package ext.piab.reports.supplier.util;

import com.ptc.windchill.wp.AbstractWorkPackage;
import com.ptc.windchill.wp.WorkPackage;
import ext.piab.common.util.PropertyforPIAB;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import wt.epm.EPMDocument;
import wt.epm.EPMDocumentMaster;
import wt.facade.persistedcollection.PersistedCollectionHelper;
import wt.facade.persistedcollection.PersistedCollectionMembership;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.fc.WTReference;
import wt.fc.collections.WTSet;
import wt.httpgw.URLFactory;
import wt.iba.definition.litedefinition.AttributeDefDefaultView;
import wt.iba.value.DefaultAttributeContainer;
import wt.iba.value.IBAHolder;
import wt.iba.value.IBAValueUtility;
import wt.iba.value.litevalue.AbstractValueView;
import wt.iba.value.service.IBAValueHelper;
import wt.method.RemoteAccess;
import wt.pds.StatementSpec;
import wt.query.QueryException;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.query.WhereExpression;
import wt.type.TypedUtility;
import wt.util.WTContext;
import wt.util.WTException;
import wt.vc.Mastered;
import wt.vc.VersionControlHelper;

public class SupplierPackageReport implements RemoteAccess {
  public static String FC_RESOURCE = "wt.fc.fcResource";
  
  public static final String SUPPLIER_PACKAGE_TYPE_NAME = PropertyforPIAB.SUPPLIER_PACKAGE_TYPE_NAME;
  
  public static final String PACKAGE_VENDORNUMBER = PropertyforPIAB.PACKAGE_VENDORNUMBER;
  
  public static ArrayList<SuppliePackageReportBean> whereUsedInSupplierPackage(String paramString) {
    System.out.println("Fetching Supplier packages for: " + paramString);
    paramString = paramString.toUpperCase();
    ArrayList<SuppliePackageReportBean> arrayList = new ArrayList();
    try {
      QuerySpec querySpec = new QuerySpec(EPMDocumentMaster.class);
      SearchCondition searchCondition = new SearchCondition(EPMDocumentMaster.class, "number", "=", paramString, false);
      querySpec.appendWhere((WhereExpression)searchCondition, new int[] { 0, 1 });
      try {
        querySpec.setDescendantQuery(false);
      } catch (Exception exception) {
        exception.printStackTrace();
      } 
      QueryResult queryResult = PersistenceHelper.manager.find((StatementSpec)querySpec);
      while (queryResult.hasMoreElements()) {
        EPMDocumentMaster ePMDocumentMaster = (EPMDocumentMaster)queryResult.nextElement();
        QueryResult queryResult1 = VersionControlHelper.service.allIterationsOf((Mastered)ePMDocumentMaster, true);
        SuppliePackageReportBean suppliePackageReportBean = null;
        String str1 = null;
        String str2 = null;
        byte b = 0;
        while (queryResult1.hasMoreElements()) {
          EPMDocument ePMDocument = (EPMDocument)queryResult1.nextElement();
          System.out.println("***Checking EPMDocument : " + ePMDocument.getIdentity());
          if (!b) {
            str1 = ePMDocument.getVersionInfo().getIdentifier().getValue() + "." + ePMDocument.getIterationInfo().getIdentifier().getValue();
            str2 = ePMDocument.getLifeCycleState().getDisplay();
          } 
          ArrayList<WorkPackage> arrayList1 = getRelatedSupplierPackages(ePMDocument);
          String str = ePMDocument.getVersionInfo().getIdentifier().getValue() + "." + ePMDocument.getIterationInfo().getIdentifier().getValue();
          b++;
          if (arrayList1 != null && arrayList1.size() > 0)
            for (byte b1 = 0; b1 < arrayList1.size(); b1++) {
              suppliePackageReportBean = new SuppliePackageReportBean();
              suppliePackageReportBean.setDrawingNumber(ePMDocument.getNumber());
              suppliePackageReportBean.setLatestRevision(str1);
              suppliePackageReportBean.setDrawingRevision(str);
              WorkPackage workPackage = arrayList1.get(b1);
              suppliePackageReportBean.setSupplierPackageNumber(workPackage.getNumber());
              suppliePackageReportBean.setSupplePackageLifeCycleState(workPackage.getLifeCycleState().getDisplay());
              ReferenceFactory referenceFactory = new ReferenceFactory();
              WTReference wTReference = referenceFactory.getReference((Persistable)workPackage);
              String str3 = referenceFactory.getReferenceString(wTReference);
              URLFactory uRLFactory = new URLFactory();
              String str4 = uRLFactory.getHREF("/servlet/TypeBasedIncludeServlet?oid=" + str3);
              suppliePackageReportBean.setPackageURL(str4);
              suppliePackageReportBean.setLatestCADState(str2);
              suppliePackageReportBean.setCADStateInPackage(ePMDocument.getLifeCycleState().getDisplay());
              if (str1.equals(str)) {
                suppliePackageReportBean.setIsLatestInPackage("Yes");
              } else {
                suppliePackageReportBean.setIsLatestInPackage("No");
              } 
              suppliePackageReportBean.setSupplierPackageNumber(workPackage.getPackageNumber() + "-" + workPackage.getVersionInfo().getIdentifier().getValue());
              String str5 = (String)((HashMap)getIBAValues((IBAHolder)workPackage)).get(PACKAGE_VENDORNUMBER);
              if (str5 != null) {
                suppliePackageReportBean.setProjectNumber(str5);
              } else {
                suppliePackageReportBean.setProjectNumber("");
              } 
              arrayList.add(suppliePackageReportBean);
              System.out.println(suppliePackageReportBean.toString());
            }  
        } 
      } 
      AlphaNumericComparator alphaNumericComparator = new AlphaNumericComparator();
      Collections.sort(arrayList, alphaNumericComparator);
      return arrayList;
    } catch (QueryException queryException) {
      queryException.printStackTrace();
    } catch (WTException wTException) {
      wTException.printStackTrace();
    } catch (RemoteException remoteException) {
      remoteException.printStackTrace();
    } 
    return null;
  }
  
  public static ArrayList<WorkPackage> getSupplierPackages(Persistable paramPersistable) throws WTException {
    System.out.println("getSupplierPackages In process of obtaining supplier packages : ");
    ArrayList<WorkPackage> arrayList = new ArrayList();
    try {
      PersistedCollectionMembership persistedCollectionMembership = PersistedCollectionHelper.service.getMemberOf(paramPersistable);
      WTSet wTSet = (WTSet)persistedCollectionMembership.getDirectSet().subCollection(AbstractWorkPackage.class);
      wTSet.addAll((Collection)persistedCollectionMembership.getNestedSet().subCollection(AbstractWorkPackage.class));
      Object[] arrayOfObject = wTSet.toArray();
      for (byte b = 0; b < arrayOfObject.length; b++) {
        ObjectReference objectReference = (ObjectReference)arrayOfObject[b];
        WorkPackage workPackage = (WorkPackage)objectReference.getObject();
        if (TypedUtility.getTypeIdentifier(workPackage).toString().endsWith(SUPPLIER_PACKAGE_TYPE_NAME))
          arrayList.add(workPackage); 
      } 
    } catch (WTException wTException) {
      wTException.printStackTrace();
    } 
    System.out.println("****Returning Supplier Package Size: " + arrayList.size());
    return arrayList;
  }
  
  public static ArrayList<WorkPackage> getRelatedSupplierPackages(EPMDocument paramEPMDocument) throws WTException {
    System.out.println("getRelatedSupplierPackages In process of obtaining supplier packages for: " + paramEPMDocument.getIdentity());
    null = new ArrayList();
    return getSupplierPackages((Persistable)paramEPMDocument);
  }
  
  public static String removeWildCard(String paramString, char paramChar) {
    String str = "";
    for (byte b = 0; b < paramString.length(); b++) {
      if (paramString.charAt(b) != paramChar)
        str = str + paramString.charAt(b); 
    } 
    return str;
  }
  
  public static Map<String, String> getIBAValues(IBAHolder paramIBAHolder) throws WTException, RemoteException {
    HashMap<Object, Object> hashMap = new HashMap<>();
    DefaultAttributeContainer defaultAttributeContainer = null;
    paramIBAHolder = IBAValueHelper.service.refreshAttributeContainer(paramIBAHolder, null, WTContext.getContext().getLocale(), null);
    defaultAttributeContainer = (DefaultAttributeContainer)paramIBAHolder.getAttributeContainer();
    AbstractValueView[] arrayOfAbstractValueView = defaultAttributeContainer.getAttributeValues();
    AttributeDefDefaultView attributeDefDefaultView = null;
    for (byte b = 0; b < arrayOfAbstractValueView.length; b++) {
      attributeDefDefaultView = arrayOfAbstractValueView[b].getDefinition();
      String str1 = attributeDefDefaultView.getName();
      String str2 = IBAValueUtility.getLocalizedIBAValueDisplayString(arrayOfAbstractValueView[b], Locale.getDefault());
      hashMap.put(str1, str2);
      System.out.println(str1 + ": " + str2);
    } 
    return (Map)hashMap;
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\reports\supplie\\util\SupplierPackageReport.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */