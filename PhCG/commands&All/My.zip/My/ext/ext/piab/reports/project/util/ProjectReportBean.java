package ext.piab.reports.project.util;

import java.util.ArrayList;

public class ProjectReportBean {
  private ArrayList supPkges;
  
  private ArrayList desPkges;
  
  private String name;
  
  private String number;
  
  private String phase;
  
  public ArrayList getSupPkges() {
    return this.supPkges;
  }
  
  public void setSupPkges(ArrayList paramArrayList) {
    this.supPkges = paramArrayList;
  }
  
  public ArrayList getDesPkges() {
    return this.desPkges;
  }
  
  public void setDesPkges(ArrayList paramArrayList) {
    this.desPkges = paramArrayList;
  }
  
  public String getName() {
    return this.name;
  }
  
  public void setName(String paramString) {
    this.name = paramString;
  }
  
  public String getNumber() {
    return this.number;
  }
  
  public void setNumber(String paramString) {
    this.number = paramString;
  }
  
  public String getPhase() {
    return this.phase;
  }
  
  public void setPhase(String paramString) {
    this.phase = paramString;
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\reports\projec\\util\ProjectReportBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */