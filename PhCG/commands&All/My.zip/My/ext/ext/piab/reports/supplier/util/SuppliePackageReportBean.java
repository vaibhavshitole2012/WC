package ext.piab.reports.supplier.util;

import java.io.Serializable;
import java.text.Collator;

public class SuppliePackageReportBean implements Serializable {
  private String drawingNumber;
  
  private String supplierPackageNumber;
  
  private String revisionInPackage;
  
  private String drawingRevision;
  
  private String latestRevision;
  
  private String isLatestInPackage;
  
  private String supplePackageLifeCycleState;
  
  private String packageURL;
  
  private String projectNumber;
  
  private String latestCADState;
  
  private String CADStateInPackage;
  
  Collator _collator = Collator.getInstance();
  
  public String getProjectNumber() {
    return this.projectNumber;
  }
  
  public void setProjectNumber(String paramString) {
    this.projectNumber = paramString;
  }
  
  public String getSupplePackageLifeCycleState() {
    return this.supplePackageLifeCycleState;
  }
  
  public void setSupplePackageLifeCycleState(String paramString) {
    this.supplePackageLifeCycleState = paramString;
  }
  
  public String getPackageURL() {
    return this.packageURL;
  }
  
  public void setPackageURL(String paramString) {
    this.packageURL = paramString;
  }
  
  public String getDrawingNumber() {
    return this.drawingNumber;
  }
  
  public void setDrawingNumber(String paramString) {
    this.drawingNumber = paramString;
  }
  
  public String getSupplierPackageNumber() {
    return this.supplierPackageNumber;
  }
  
  public void setSupplierPackageNumber(String paramString) {
    this.supplierPackageNumber = paramString;
  }
  
  public String getRevisionInPackage() {
    return this.revisionInPackage;
  }
  
  public void setRevisionInPackage(String paramString) {
    this.revisionInPackage = paramString;
  }
  
  public String getDrawingRevision() {
    return this.drawingRevision;
  }
  
  public void setDrawingRevision(String paramString) {
    this.drawingRevision = paramString;
  }
  
  public String getLatestRevision() {
    return this.latestRevision;
  }
  
  public void setLatestRevision(String paramString) {
    this.latestRevision = paramString;
  }
  
  public String getIsLatestInPackage() {
    return this.isLatestInPackage;
  }
  
  public void setIsLatestInPackage(String paramString) {
    this.isLatestInPackage = paramString;
  }
  
  public String getLatestCADState() {
    return this.latestCADState;
  }
  
  public void setLatestCADState(String paramString) {
    this.latestCADState = paramString;
  }
  
  public String getCADStateInPackage() {
    return this.CADStateInPackage;
  }
  
  public void setCADStateInPackage(String paramString) {
    this.CADStateInPackage = paramString;
  }
  
  public String toString() {
    return "Drawing Number: " + this.drawingNumber + " Drawing Revision: " + this.drawingRevision + "/nPackage State: " + this.supplePackageLifeCycleState + "/nPackage URL: " + this.packageURL + "/nDrawing Revision in Package: " + this.revisionInPackage + "/nIs Latest in Package: " + this.isLatestInPackage + "/n";
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\reports\supplie\\util\SuppliePackageReportBean.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */