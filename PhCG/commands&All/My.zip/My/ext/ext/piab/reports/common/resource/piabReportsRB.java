/*    */ package ext.piab.reports.common.resource;
/*    */ 
/*    */ import java.util.ListResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class piabReportsRB
/*    */   extends ListResourceBundle
/*    */ {
/* 16 */   static final Object[][] contents = new Object[][] { { "pReports.piabReports.description", "PIAB Reports" }, { "pReports.piabReports.icon", "reports_24.png" }, { "pReports.piabReports.moreurlinfo", "width=800,height=700" }, { "pReports.piabReports.title", "PIAB Reports" }, { "pReports.piabReports.tooltip", "PIAB Reports" } };
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Object[][] getContents() {
/* 30 */     return contents;
/*    */   }
/*    */ }


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\reports\common\resource\piabReportsRB.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */