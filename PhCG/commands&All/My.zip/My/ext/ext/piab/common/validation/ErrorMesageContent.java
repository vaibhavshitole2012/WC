package ext.piab.common.validation;

import wt.change2.WTChangeActivity2;
import wt.change2.WTChangeOrder2;
import wt.doc.WTDocument;
import wt.enterprise.RevisionControlled;
import wt.epm.EPMDocument;
import wt.fc.WTObject;
import wt.part.WTPart;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;

public class ErrorMesageContent {
  public static StringBuilder errorMsg(WTObject paramWTObject, StringBuilder paramStringBuilder) throws WTException, WTPropertyVetoException {
    if (paramWTObject instanceof WTPart)
      paramStringBuilder.append("\n WTPart: (" + ((WTPart)paramWTObject).getNumber() + ") "); 
    if (paramWTObject instanceof EPMDocument)
      paramStringBuilder.append("\n EPMDocument: (" + ((EPMDocument)paramWTObject).getNumber() + ") "); 
    if (paramWTObject instanceof WTDocument)
      paramStringBuilder.append("\n WTDocument: (" + ((WTDocument)paramWTObject).getNumber() + ") "); 
    return paramStringBuilder;
  }
  
  public static StringBuilder errForItemsinChange(WTObject paramWTObject, WTChangeActivity2 paramWTChangeActivity2, WTChangeOrder2 paramWTChangeOrder2, StringBuilder paramStringBuilder) throws WTException, WTPropertyVetoException {
    String str = ((RevisionControlled)paramWTObject).getName();
    if (paramWTObject instanceof EPMDocument)
      paramStringBuilder.append("\n[ EPM:(" + paramWTObject + ") - CA:(" + paramWTChangeActivity2.getName() + ") of the CN-(" + paramWTChangeOrder2.getName() + ") ]"); 
    if (paramWTObject instanceof WTDocument)
      paramStringBuilder.append("\n[ WTDoc:(" + str + ") - CA:(" + paramWTChangeActivity2.getName() + ") of the CN-(" + paramWTChangeOrder2.getName() + ") ]"); 
    if (paramWTObject instanceof WTPart)
      paramStringBuilder.append("\n[ WTPart:(" + str + ") - CA:(" + paramWTChangeActivity2.getName() + ") of the CN-(" + paramWTChangeOrder2.getName() + ") ]"); 
    return paramStringBuilder;
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\common\validation\ErrorMesageContent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */