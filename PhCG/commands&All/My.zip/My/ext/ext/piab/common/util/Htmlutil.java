package ext.piab.common.util;

import com.ptc.windchill.wp.WorkPackage;
import com.ptc.windchill.wp.delivery.DeliveryRecord;
import ext.piab.common.resource.HtmlResource;
import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import wt.change2.WTChangeActivity2;
import wt.change2.WTChangeOrder2;
import wt.change2.WTChangeRequest2;
import wt.doc.WTDocument;
import wt.epm.EPMDocument;
import wt.fc.Persistable;
import wt.fc.ReferenceFactory;
import wt.fc.WTReference;
import wt.httpgw.URLFactory;
import wt.lifecycle.LifeCycleManaged;
import wt.part.WTPart;
import wt.type.TypedUtility;
import wt.util.WTException;
import wt.util.WTMessage;

public class Htmlutil {
  private static final String path = PropertyforPIAB.htmlpath;
  
  private static final String DESIGN_PKG = PropertyforPIAB.DESIGN_PACKAGE_TYPE_NAME;
  
  private static final String SUPPLIER_PKG = PropertyforPIAB.SUPPLIER_PACKAGE_TYPE_NAME;
  
  private static final String COLOR = PropertyforPIAB.HTML_TABLE_COLOR;
  
  private static final String HTML_RESOURCE = HtmlResource.class.getName();
  
  private static String KEY_NAME = WTMessage.getLocalizedMessage(HTML_RESOURCE, "12");
  
  private static String KEY_STATE = WTMessage.getLocalizedMessage(HTML_RESOURCE, "13");
  
  private static String KEY_REVISION = WTMessage.getLocalizedMessage(HTML_RESOURCE, "14");
  
  private static String KEY_EVENT = WTMessage.getLocalizedMessage(HTML_RESOURCE, "15");
  
  private static String KEY_MESSAGE = WTMessage.getLocalizedMessage(HTML_RESOURCE, "16");
  
  private static String KEY_END_BODY = WTMessage.getLocalizedMessage(HTML_RESOURCE, "17");
  
  private static String KEY_NOTIFYOBJECT = WTMessage.getLocalizedMessage(HTML_RESOURCE, "18");
  
  public static String readHtml(String paramString) throws Exception {
    File file = new File(paramString);
    System.out.println("File path" + paramString);
    FileInputStream fileInputStream = null;
    BufferedInputStream bufferedInputStream = null;
    DataInputStream dataInputStream = null;
    String str = "";
    fileInputStream = new FileInputStream(file);
    bufferedInputStream = new BufferedInputStream(fileInputStream);
    dataInputStream = new DataInputStream(bufferedInputStream);
    System.out.println("START DATAINPUT reading");
    while (dataInputStream.available() != 0)
      str = str + dataInputStream.readLine(); 
    System.out.println("START " + str);
    fileInputStream.close();
    bufferedInputStream.close();
    dataInputStream.close();
    return str;
  }
  
  public static String closeBody(String paramString) {
    return paramString = paramString + "</table></body></html>";
  }
  
  public static String enterData(String paramString1, String paramString2, String paramString3) {
    return paramString1 = paramString1 + "<td bgcolor='" + COLOR + "'><font face='Arial'><a href='" + paramString2 + "'>" + paramString3 + "</a></font></td></tr>";
  }
  
  public static String buildTable(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5) {
    return paramString1 = paramString1 + "<tr><td colspan='2'><hr size='1' color='#124280'></td></tr><tr><td bgcolor='" + COLOR + "' rowspan=" + paramString2 + "><font face='Arial'><a href='" + paramString3 + "'>" + paramString4 + "</a></font></td>";
  }
  
  public static String gettempBody() throws Exception {
    String str = readHtml(path);
    return str.substring(0, str.indexOf(KEY_END_BODY));
  }
  
  public static String getDisplay(Persistable paramPersistable) {
    String str = null;
    if (paramPersistable instanceof WTChangeActivity2) {
      str = "Change Activity - " + getNumber(paramPersistable);
    } else if (paramPersistable instanceof WTChangeRequest2) {
      str = "Change Request - " + getNumber(paramPersistable);
    } else if (paramPersistable instanceof WTChangeOrder2) {
      str = "Change Notice - " + getNumber(paramPersistable);
    } else if (paramPersistable instanceof DeliveryRecord) {
      str = "Export Record - " + getNumber(paramPersistable);
    } else if (paramPersistable instanceof WorkPackage) {
      String str1 = TypedUtility.getTypeIdentifier(paramPersistable).toString();
      if (str1.endsWith(DESIGN_PKG)) {
        str1 = "Design Package - ";
      } else if (str1.endsWith(SUPPLIER_PKG)) {
        str1 = "Supplier Package - ";
      } 
      str = str1 + getNumber(paramPersistable);
    } else if (paramPersistable instanceof EPMDocument) {
      str = "CAD Part: " + getNumber(paramPersistable) + "-" + getName(paramPersistable) + " " + getVersion(paramPersistable) + " " + getState(paramPersistable);
    } else if (paramPersistable instanceof WTPart) {
      str = "WTPart: " + getNumber(paramPersistable) + "-" + getName(paramPersistable) + " " + getVersion(paramPersistable) + " " + getState(paramPersistable);
    } else if (paramPersistable instanceof WTDocument) {
      str = "WTDocument: " + getNumber(paramPersistable) + "-" + getName(paramPersistable) + " " + getVersion(paramPersistable) + " " + getState(paramPersistable);
    } 
    return str;
  }
  
  public static String getURL(Persistable paramPersistable) {
    ReferenceFactory referenceFactory = new ReferenceFactory();
    String str = null;
    try {
      WTReference wTReference = referenceFactory.getReference(paramPersistable);
      String str1 = referenceFactory.getReferenceString(wTReference);
      URLFactory uRLFactory = new URLFactory();
      str = uRLFactory.getHREF("/servlet/TypeBasedIncludeServlet?oid=" + str1);
    } catch (WTException wTException) {
      wTException.printStackTrace();
    } 
    return str;
  }
  
  public static String setEventandMessage(Persistable paramPersistable, String paramString1, String paramString2, String paramString3) {
    paramString1 = paramString1.replace(KEY_EVENT, " " + WTMessage.getLocalizedMessage(HTML_RESOURCE, paramString2));
    Object[] arrayOfObject = null;
    return paramString1 = paramString1.replace(KEY_MESSAGE, " " + WTMessage.getLocalizedMessage(HTML_RESOURCE, paramString3, arrayOfObject));
  }
  
  public static String enterValues(Persistable paramPersistable, String paramString) {
    String str = "<a href='" + getURL(paramPersistable) + "'>" + getDisplay(paramPersistable) + "</a>";
    paramString = paramString.replace(KEY_NOTIFYOBJECT, " " + str);
    paramString = paramString.replace(KEY_NAME, " " + getName(paramPersistable));
    paramString = paramString.replace(KEY_STATE, " " + getState(paramPersistable));
    return paramString.replace(KEY_REVISION, " " + getVersion(paramPersistable));
  }
  
  public static String getNumber(Persistable paramPersistable) {
    String str = null;
    if (paramPersistable instanceof WTChangeActivity2) {
      WTChangeActivity2 wTChangeActivity2 = (WTChangeActivity2)paramPersistable;
      str = wTChangeActivity2.getNumber();
    } else if (paramPersistable instanceof WTChangeRequest2) {
      WTChangeRequest2 wTChangeRequest2 = (WTChangeRequest2)paramPersistable;
      str = wTChangeRequest2.getNumber();
    } else if (paramPersistable instanceof WTChangeOrder2) {
      WTChangeOrder2 wTChangeOrder2 = (WTChangeOrder2)paramPersistable;
      str = wTChangeOrder2.getNumber();
    } else if (paramPersistable instanceof DeliveryRecord) {
      DeliveryRecord deliveryRecord = (DeliveryRecord)paramPersistable;
      str = deliveryRecord.getNumber();
    } else if (paramPersistable instanceof WorkPackage) {
      WorkPackage workPackage = (WorkPackage)paramPersistable;
      str = workPackage.getNumber();
    } else if (paramPersistable instanceof EPMDocument) {
      EPMDocument ePMDocument = (EPMDocument)paramPersistable;
      str = ePMDocument.getNumber();
    } else if (paramPersistable instanceof WTPart) {
      WTPart wTPart = (WTPart)paramPersistable;
      str = wTPart.getNumber();
    } else if (paramPersistable instanceof WTDocument) {
      WTDocument wTDocument = (WTDocument)paramPersistable;
      str = wTDocument.getNumber();
    } 
    return str;
  }
  
  public static String getName(Persistable paramPersistable) {
    String str = null;
    if (paramPersistable instanceof WTChangeActivity2) {
      WTChangeActivity2 wTChangeActivity2 = (WTChangeActivity2)paramPersistable;
      str = wTChangeActivity2.getName();
    } else if (paramPersistable instanceof WTChangeRequest2) {
      WTChangeRequest2 wTChangeRequest2 = (WTChangeRequest2)paramPersistable;
      str = wTChangeRequest2.getName();
    } else if (paramPersistable instanceof WTChangeOrder2) {
      WTChangeOrder2 wTChangeOrder2 = (WTChangeOrder2)paramPersistable;
      str = wTChangeOrder2.getName();
    } else if (paramPersistable instanceof DeliveryRecord) {
      DeliveryRecord deliveryRecord = (DeliveryRecord)paramPersistable;
      str = deliveryRecord.getName();
    } else if (paramPersistable instanceof WorkPackage) {
      WorkPackage workPackage = (WorkPackage)paramPersistable;
      str = workPackage.getName();
    } else if (paramPersistable instanceof EPMDocument) {
      EPMDocument ePMDocument = (EPMDocument)paramPersistable;
      str = ePMDocument.getName();
    } else if (paramPersistable instanceof WTPart) {
      WTPart wTPart = (WTPart)paramPersistable;
      str = wTPart.getName();
    } else if (paramPersistable instanceof WTDocument) {
      WTDocument wTDocument = (WTDocument)paramPersistable;
      str = wTDocument.getName();
    } 
    return str;
  }
  
  public static String getVersion(Persistable paramPersistable) {
    String str = null;
    if (paramPersistable instanceof WTChangeActivity2) {
      WTChangeActivity2 wTChangeActivity2 = (WTChangeActivity2)paramPersistable;
      str = wTChangeActivity2.getVersionIdentifier().getValue() + "." + wTChangeActivity2.getIterationIdentifier().getValue();
    } else if (paramPersistable instanceof WTChangeRequest2) {
      WTChangeRequest2 wTChangeRequest2 = (WTChangeRequest2)paramPersistable;
      str = wTChangeRequest2.getVersionIdentifier().getValue() + "." + wTChangeRequest2.getIterationIdentifier().getValue();
    } else if (paramPersistable instanceof WTChangeOrder2) {
      WTChangeOrder2 wTChangeOrder2 = (WTChangeOrder2)paramPersistable;
      str = wTChangeOrder2.getVersionIdentifier().getValue() + "." + wTChangeOrder2.getIterationIdentifier().getValue();
    } else if (paramPersistable instanceof WorkPackage) {
      WorkPackage workPackage = (WorkPackage)paramPersistable;
      str = workPackage.getVersionIdentifier().getValue() + "." + workPackage.getIterationIdentifier().getValue();
    } else if (paramPersistable instanceof EPMDocument) {
      EPMDocument ePMDocument = (EPMDocument)paramPersistable;
      str = ePMDocument.getVersionIdentifier().getValue() + "." + ePMDocument.getIterationIdentifier().getValue();
    } else if (paramPersistable instanceof WTPart) {
      WTPart wTPart = (WTPart)paramPersistable;
      str = wTPart.getVersionIdentifier().getValue() + "." + wTPart.getIterationIdentifier().getValue();
    } else if (paramPersistable instanceof WTDocument) {
      WTDocument wTDocument = (WTDocument)paramPersistable;
      str = wTDocument.getVersionIdentifier().getValue() + "." + wTDocument.getIterationIdentifier().getValue();
    } 
    return str;
  }
  
  public static String getState(Persistable paramPersistable) {
	  
    return ((LifeCycleManaged)paramPersistable).getLifeCycleState().getDisplay();
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\commo\\util\Htmlutil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */