package ext.piab.common.validation;

import ext.piab.common.resource.CommonResource;
import ext.piab.common.util.PropertyforPIAB;
import java.util.Vector;
import wt.enterprise.RevisionControlled;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.WTObject;
import wt.fc.collections.WTArrayList;
import wt.inf.container.WTContained;
import wt.lifecycle.LifeCycleHelper;
import wt.lifecycle.LifeCycleTemplate;
import wt.lifecycle.LifeCycleTemplateMaster;
import wt.lifecycle.LifeCycleTemplateReference;
import wt.util.WTException;
import wt.util.WTMessage;

public class ValidateObjetcs {
  private static final String COMMON_RESOURCE = CommonResource.class.getName();
  
  private static final String DOC_LC_NAME = PropertyforPIAB.DOC_LC_NAME;
  
  private static final String EPM_LC_NAME = PropertyforPIAB.EPM_LC_NAME;
  
  private static final String PART_LC_NAME = PropertyforPIAB.PART_LC_NAME;
  
  private static boolean VERBOSE = PropertyforPIAB.VERBOSE;
  
  private static String PKG_EXCEPTION = WTMessage.getLocalizedMessage(COMMON_RESOURCE, "11");
  
  private static String CR_EXCEPTION = WTMessage.getLocalizedMessage(COMMON_RESOURCE, "10");
  
  public static void incorrectObject(Persistable paramPersistable, Object[] paramArrayOfObject) throws Exception {
    if (VERBOSE)
      System.out.println("***ValidateObjetcs.incorrectObject()"); 
    String str = null;
    WTArrayList wTArrayList = new WTArrayList();
    if (paramPersistable instanceof wt.change2.WTChangeRequest2)
      str = CR_EXCEPTION; 
    if (paramPersistable instanceof com.ptc.windchill.wp.WorkPackage)
      str = PKG_EXCEPTION; 
    for (byte b = 0; b < paramArrayOfObject.length; b++) {
      ObjectReference objectReference = (ObjectReference)paramArrayOfObject[b];
      WTObject wTObject = (WTObject)objectReference.getObject();
      wTArrayList.add((Persistable)wTObject);
    } 
    incorrectLc(wTArrayList, str);
  }
  
  public static void incorrectLc(WTArrayList paramWTArrayList, String paramString) throws Exception {
    if (VERBOSE)
      System.out.println("***ValidateObjetcs.incorrectLc()"); 
    StringBuilder stringBuilder = new StringBuilder();
    Object[] arrayOfObject = paramWTArrayList.toArray();
    for (byte b = 0; b < arrayOfObject.length; b++) {
      ObjectReference objectReference = (ObjectReference)arrayOfObject[b];
      WTObject wTObject = (WTObject)objectReference.getObject();
      LifeCycleTemplate lifeCycleTemplate1 = getLCTemplate(wTObject, false);
      Vector vector = LifeCycleHelper.service.findStates(lifeCycleTemplate1);
      if (VERBOSE)
        System.out.println("current Lc name " + lifeCycleTemplate1.getName() + " currentStates " + vector + " -Size- " + vector.size()); 
      LifeCycleTemplate lifeCycleTemplate2 = getLCTemplate(wTObject, true);
      Vector<?> vector1 = LifeCycleHelper.service.findStates(lifeCycleTemplate2);
      if (VERBOSE)
        System.out.println("lcLatest Name " + lifeCycleTemplate2.getName() + "latestStates" + vector1 + " -Size- " + vector1.size()); 
      String str1 = getPIABTemplateName(wTObject);
      boolean bool = vector.containsAll(vector1);
      if (lifeCycleTemplate1.getName().toString().equalsIgnoreCase(str1) && vector1.size() == vector.size() && bool) {
        if (VERBOSE)
          System.out.println("***LC of[" + wTObject + "] follows correct LC"); 
      } else {
        stringBuilder = ErrorMesageContent.errorMsg(wTObject, stringBuilder);
      } 
    } 
    String str = stringBuilder.toString();
    if (!str.isEmpty()) {
      if (VERBOSE)
        System.out.println("***state [" + str + "] Objects in the Package does not follow PIAB LC"); 
      Object[] arrayOfObject1 = { paramString, str };
      throw new WTException(COMMON_RESOURCE, "1", arrayOfObject1);
    } 
  }
  
  private static LifeCycleTemplate getLCTemplate(WTObject paramWTObject, boolean paramBoolean) throws Exception {
    if (VERBOSE)
      System.out.println("***ValidateObjetcs.getLCTemplate()"); 
    LifeCycleTemplate lifeCycleTemplate = null;
    if (paramBoolean) {
      String str = getPIABTemplateName(paramWTObject);
      LifeCycleTemplateMaster lifeCycleTemplateMaster = LifeCycleHelper.service.getLifeCycleTemplateMaster(str, ((WTContained)paramWTObject).getContainerReference());
      lifeCycleTemplate = LifeCycleHelper.service.getLatestIteration(lifeCycleTemplateMaster);
    } else {
      LifeCycleTemplateReference lifeCycleTemplateReference = ((RevisionControlled)paramWTObject).getLifeCycleTemplate();
      lifeCycleTemplate = (LifeCycleTemplate)lifeCycleTemplateReference.getObject();
    } 
    return lifeCycleTemplate;
  }
  
  private static String getPIABTemplateName(WTObject paramWTObject) throws Exception {
    if (VERBOSE)
      System.out.println("***ValidateObjetcs.getPIABTemplateName()"); 
    String str = null;
    if (paramWTObject instanceof wt.doc.WTDocument)
      str = DOC_LC_NAME; 
    if (paramWTObject instanceof wt.epm.EPMDocument)
      str = EPM_LC_NAME; 
    if (paramWTObject instanceof wt.part.WTPart)
      str = PART_LC_NAME; 
    return str;
  }
  
  public static String incorrectLCState(Object[] paramArrayOfObject, Vector<String> paramVector) throws Exception {
    if (VERBOSE)
      System.out.println("***ValidateObjetcs.incorrectLCState()"); 
    StringBuilder stringBuilder = new StringBuilder();
    for (byte b = 0; b < paramArrayOfObject.length; b++) {
      ObjectReference objectReference = (ObjectReference)paramArrayOfObject[b];
      WTObject wTObject = (WTObject)objectReference.getObject();
      String str = ((RevisionControlled)wTObject).getState().toString();
      if (!paramVector.contains(str))
        stringBuilder = ErrorMesageContent.errorMsg(wTObject, stringBuilder); 
    } 
    return stringBuilder.toString();
  }
  
  public static Vector<String> addStings(String paramString, Vector<String> paramVector) {
    paramVector.add(paramString);
    return paramVector;
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\common\validation\ValidateObjetcs.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */