package ext.piab.common.util;

import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.iba.definition.StringDefinition;
import wt.iba.definition.URLDefinition;
import wt.iba.value.IBAHolder;
import wt.iba.value.StringValue;
import wt.iba.value.URLValue;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.query.WhereExpression;
import wt.util.WTException;

public class UpdateIBAs {
  private static final boolean VERBOSE = PropertyforPIAB.VERBOSE;
  
  public static void updateIBAUrl(IBAHolder paramIBAHolder, String paramString1, String paramString2, String paramString3) throws Exception {
    if (VERBOSE)
      System.out.println("***UpdateIBAs.updateIBAUrl: " + paramString3); 
    URLDefinition uRLDefinition = null;
    if (paramString2 == null || paramString2.equals(""))
      paramString2 = paramString1.substring(paramString1.lastIndexOf('/') + 1); 
    QuerySpec querySpec = new QuerySpec(URLDefinition.class);
    querySpec.appendWhere((WhereExpression)new SearchCondition(URLDefinition.class, "name", "=", paramString3, false));
    QueryResult queryResult = PersistenceHelper.manager.find(querySpec);
    if (queryResult.size() > 0) {
      URLValue uRLValue;
      uRLDefinition = (URLDefinition)queryResult.nextElement();
      querySpec = new QuerySpec(URLValue.class);
      querySpec.appendWhere((WhereExpression)new SearchCondition(URLValue.class, "definitionReference.key", "=", PersistenceHelper.getObjectIdentifier((Persistable)uRLDefinition)), 0);
      querySpec.appendAnd();
      querySpec.appendWhere((WhereExpression)new SearchCondition(URLValue.class, "theIBAHolderReference.key", "=", PersistenceHelper.getObjectIdentifier((Persistable)paramIBAHolder)), 0);
      queryResult = PersistenceHelper.manager.find(querySpec);
      if (VERBOSE)
        System.out.println("QueryResult for IBAValue size: " + queryResult.size()); 
      if (queryResult.size() == 0) {
        if (VERBOSE) {
          System.out.println("Attribute didn't exist on object");
          System.out.println("DEF " + uRLDefinition + " URL-" + paramString1);
          System.out.println("*** " + paramString2);
        } 
        uRLValue = URLValue.newURLValue(uRLDefinition, paramIBAHolder, paramString1, paramString2);
      } else {
        if (VERBOSE) {
          System.out.println("Attribute already exist on objectupdating");
          System.out.println("URL = " + paramString1 + "*** LABEL = " + paramString2);
        } 
        uRLValue = (URLValue)queryResult.nextElement();
      } 
      uRLValue.setValue(paramString1);
      uRLValue.setDescription(paramString2);
      PersistenceHelper.manager.save((Persistable)uRLValue);
    } else {
      System.out.println("ATTRIBUTE DEFINITION .....\"" + paramString3 + "\" DOES NOT EXIST");
    } 
  }
  
  public static void updateIBAStringValue(IBAHolder paramIBAHolder, String paramString1, String paramString2) throws Exception {
    if (VERBOSE)
      System.out.println("***UpdateIBAs.updateIBAStringValue : " + paramString2); 
    StringValue stringValue = new StringValue();
    StringDefinition stringDefinition = null;
    QuerySpec querySpec = new QuerySpec(StringDefinition.class);
    querySpec.appendWhere((WhereExpression)new SearchCondition(StringDefinition.class, "name", "=", paramString2, false));
    QueryResult queryResult = PersistenceHelper.manager.find(querySpec);
    if (VERBOSE)
      System.out.println("QueryResult for StringDefinition size: " + queryResult.size()); 
    if (queryResult.size() > 0) {
      stringDefinition = (StringDefinition)queryResult.nextElement();
      QuerySpec querySpec1 = new QuerySpec(StringValue.class);
      querySpec1.appendWhere((WhereExpression)new SearchCondition(StringValue.class, "definitionReference.key", "=", PersistenceHelper.getObjectIdentifier((Persistable)stringDefinition)), 0);
      querySpec1.appendAnd();
      querySpec1.appendWhere((WhereExpression)new SearchCondition(StringValue.class, "theIBAHolderReference.key", "=", PersistenceHelper.getObjectIdentifier((Persistable)paramIBAHolder)), 0);
      QueryResult queryResult1 = PersistenceHelper.manager.find(querySpec1);
      if (VERBOSE)
        System.out.println("QueryResult for StringValue size: " + queryResult1.size()); 
      if (queryResult1.size() == 0) {
        if (VERBOSE) {
          System.out.println("Attribute didn't exist on object");
          System.out.println("*** " + stringDefinition);
        } 
      } else {
        if (VERBOSE)
          System.out.println("*** Attribute already exist ... updating"); 
        stringValue = (StringValue)queryResult1.nextElement();
        stringValue.setValue(paramString1);
        stringValue = (StringValue)PersistenceHelper.manager.save((Persistable)stringValue);
        if (VERBOSE)
          System.out.println("Attribute already exist on object after update" + stringValue.getValue()); 
      } 
    } else {
      if (VERBOSE)
        System.out.println("ATTRIBUTE DEFINITION \"" + paramString2 + "\" DOES NOT EXIST"); 
      throw new WTException("ATTRIBUTE DEFINITION \"" + paramString2 + "\" DOES NOT EXIST");
    } 
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\commo\\util\UpdateIBAs.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */