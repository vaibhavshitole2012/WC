package ext.piab.common.service;

import java.rmi.RemoteException;
import wt.events.KeyedEvent;
import wt.services.ServiceEventListenerAdapter;
import wt.util.WTException;

class PIABListener extends ServiceEventListenerAdapter {
  public PIABListener(String paramString) {
    super(paramString);
  }
  
  public void notifyVetoableEvent(Object paramObject) throws WTException {
    notifyEvent(paramObject);
  }
  
  public void notifyEvent(Object paramObject) {
    if (!(paramObject instanceof KeyedEvent))
      return; 
    try {
      StandardPIABService.access$000(StandardPIABService.this).notifyEvent((KeyedEvent)paramObject);
    } catch (RemoteException remoteException) {
      remoteException.printStackTrace();
    } catch (WTException wTException) {
      wTException.printStackTrace();
    } 
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\common\service\StandardPIABService$PIABListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */