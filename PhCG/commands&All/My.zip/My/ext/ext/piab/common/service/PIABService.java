package ext.piab.common.service;

public interface PIABService {}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\common\service\PIABService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */