package ext.piab.common.util;

import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.ArrayList;
import wt.doc.WTDocument;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.pds.StatementSpec;
import wt.pom.PersistenceException;
import wt.pom.Transaction;
import wt.query.ClassAttribute;
import wt.query.DateExpression;
import wt.query.QuerySpec;
import wt.query.RelationalExpression;
import wt.query.SearchCondition;
import wt.query.WhereExpression;
import wt.util.WTException;
import wt.util.WTProperties;

public class ChangeRevisionLabelUtility implements RemoteAccess {
  public static String FC_RESOURCE;
  
  public static String WT_HOME;
  
  public static String FILE_SEPARATOR;
  
  public static void main(String[] paramArrayOfString) throws WTException {
    System.out.println("Test: main");
    System.out.println("Starting uitility...");
    if (paramArrayOfString == null) {
      System.out.println("Incorrect Arguments. Please use -h option for help");
    } else if (paramArrayOfString != null && paramArrayOfString.length == 1) {
      if (paramArrayOfString[0].equals("-h")) {
        System.out.println("Following arguments are required in the order specified");
        System.out.println("-d: Date in format yyyy-mm-dd");
        System.out.println("-listAll|update: Listing Only or Update");
        System.out.println("-u: Administrator userName");
        System.out.println("-p: Administrator Password");
        System.out.println("Example: java ext.piab.util.ChangeRevisionLabelUtility -d 2011-04-22 -listOnly -u userName -p password");
      } else {
        System.out.println("Incorrect Arguments. Please use -h option for help");
      } 
    } else if (paramArrayOfString != null && paramArrayOfString.length != 7) {
      System.out.println("Incorrect Arguments. Please use -h option for help");
    } else {
      try {
        Class[] arrayOfClass = { String[].class };
        Object[] arrayOfObject = { { paramArrayOfString[1], paramArrayOfString[2], paramArrayOfString[4], paramArrayOfString[6] } };
        RemoteMethodServer remoteMethodServer = RemoteMethodServer.getDefault();
        remoteMethodServer.invoke("changeRevisionLable", "ext.piab.util.ChangeRevisionLabelUtility", null, arrayOfClass, arrayOfObject);
      } catch (InvocationTargetException invocationTargetException) {
        Throwable throwable = invocationTargetException.getTargetException();
        if (throwable instanceof WTException)
          throw (WTException)throwable; 
        Object[] arrayOfObject = { "changeVersion" };
        throw new WTException(throwable, FC_RESOURCE, "0", arrayOfObject);
      } catch (RemoteException remoteException) {
        Object[] arrayOfObject = { "changeVersion" };
        throw new WTException(remoteException, FC_RESOURCE, "0", arrayOfObject);
      } 
    } 
  }
  
  public static void changeRevisionLable(String[] paramArrayOfString) {
    Transaction transaction = null;
    ArrayList<ArrayList> arrayList = getDocumentsWithAlphaLable();
    ArrayList<WTDocument> arrayList1 = arrayList.get(0);
    try {
      if (paramArrayOfString[1].equals("-listOnly")) {
        System.out.println("***listOnly");
        System.out.println("Name,Number,OldRev,Proposed NewRev");
        for (WTDocument wTDocument : arrayList1) {
          String str1 = wTDocument.getVersionIdentifier().getValue();
          String str2 = wTDocument.getIterationIdentifier().getValue();
          char c = str1.charAt(0);
          int i = c - 64;
          System.out.println(wTDocument.getName() + "," + wTDocument.getNumber() + "," + str1 + str2 + "," + i + "." + str2);
        } 
      } else if (paramArrayOfString[1].equals("-update")) {
        System.out.println("***update");
        transaction = new Transaction();
        transaction.start();
        for (WTDocument wTDocument : arrayList1) {
          String str = wTDocument.getVersionIdentifier().getValue();
          System.out.println(wTDocument.getNumber() + " Old Rev: " + str + "." + wTDocument.getIterationIdentifier().getValue());
          if (wTDocument.isLatestIteration()) {
            if (!Character.isDigit(str.charAt(0))) {
              char c = str.charAt(0);
              int i = c - 64;
              String str1 = "java wt.vc.ChangeRevisionLabelUtility -oid " + wTDocument.toString() + " -newRev " + i + " -username " + paramArrayOfString[2] + " -password " + paramArrayOfString[3];
              System.out.println("****" + str1);
            } 
            continue;
          } 
          System.out.println("Ignored: " + wTDocument.getNumber() + " Old Rev: " + str + "." + wTDocument.getIterationIdentifier().getValue());
        } 
        transaction.commit();
        transaction = null;
      } 
    } catch (PersistenceException persistenceException) {
      persistenceException.printStackTrace();
      if (transaction != null)
        transaction.rollback(); 
    } finally {
      transaction = null;
    } 
  }
  
  private static QueryResult findObjects1() throws WTException {
    System.out.println("****findObjects");
    Class<WTDocument> clazz = WTDocument.class;
    QuerySpec querySpec = new QuerySpec(clazz);
    ClassAttribute classAttribute = new ClassAttribute(clazz, "thePersistInfo.createStamp");
    Timestamp timestamp = Timestamp.valueOf("2011-04-22 00:20:00");
    querySpec.appendWhere((WhereExpression)new SearchCondition((RelationalExpression)classAttribute, ">=", (RelationalExpression)DateExpression.newExpression(timestamp)), new int[] { 0 });
    try {
      return PersistenceHelper.manager.find((StatementSpec)querySpec);
    } catch (Exception exception) {
      exception.printStackTrace();
      return null;
    } 
  }
  
  private static ArrayList getDocumentsWithAlphaLable() {
    ArrayList<WTDocument> arrayList1 = new ArrayList();
    ArrayList<WTDocument> arrayList2 = new ArrayList();
    try {
      QueryResult queryResult = findObjects1();
      System.out.println("query size returned: " + queryResult.size());
      if (queryResult != null)
        while (queryResult.hasMoreElements()) {
          Persistable persistable = (Persistable)queryResult.nextElement();
          if (persistable instanceof WTDocument) {
            WTDocument wTDocument = (WTDocument)persistable;
            String str = wTDocument.getVersionInfo().getIdentifier().getValue();
            if (str.length() > 1) {
              arrayList2.add(wTDocument);
              continue;
            } 
            if (!Character.isDigit(str.charAt(0)))
              arrayList1.add(wTDocument); 
          } 
        }  
      ArrayList<ArrayList<WTDocument>> arrayList = new ArrayList();
      arrayList.add(arrayList1);
      arrayList.add(arrayList2);
      return arrayList;
    } catch (WTException wTException) {
      wTException.printStackTrace();
      return null;
    } 
  }
  
  static {
    try {
      WTProperties wTProperties = WTProperties.getLocalProperties();
      FC_RESOURCE = "wt.fc.fcResource";
      FILE_SEPARATOR = wTProperties.getProperty("dir.sep", "\\");
      WT_HOME = wTProperties.getProperty("wt.home", "");
    } catch (Throwable throwable) {
      System.err.println("****Error During Initilization****");
      throwable.printStackTrace();
      throw new ExceptionInInitializerError(throwable);
    } 
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\commo\\util\ChangeRevisionLabelUtility.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */