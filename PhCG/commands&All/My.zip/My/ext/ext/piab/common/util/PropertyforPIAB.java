package ext.piab.common.util;

import wt.util.WTProperties;

public class PropertyforPIAB {
  public static final boolean VERBOSE;
  
  public static final String LC_STATE_1;
  
  public static final String LC_STATE_2;
  
  public static final String LC_STATE_3;
  
  public static final String LC_STATE_4;
  
  public static final String LC_STATE_5;
  
  public static final String LCSTATE_INWORK;
  
  public static final String LCSTATE_OPEN;
  
  public static final String LCSTATE_UNDERREVIEW;
  
  public static final String LCSTATE_APPROVED;
  
  public static final String LCSTATE_RELEASED;
  
  public static final String LCSTATE_RESOLVED;
  
  public static final String LCSTATE_COMPLETED;
  
  public static final String LCSTATE_CANCELLED;
  
  public static final String LCSTATE_IN_ANALYSIS;
  
  public static final String SUPPLIER_PACKAGE_TYPE_NAME;
  
  public static final String DESIGN_PACKAGE_TYPE_NAME;
  
  public static final String CUSTOMER_PACKAGE_TYPE_NAME;
  
  public static final String PACKAGE_PROJECTNUMBER;
  
  public static final String PACKAGE_VENDORNUMBER;
  
  public static final String DESIGN_PACKAGE_NUMBER;
  
  public static final String DELIVERY_RECORD_ROLES;
  
  public static final String PACKAGE_FILTERSPEC;
  
  public static final boolean INCLUDEALPHA;
  
  public static final boolean INCLUDENUMERIC;
  
  public static final boolean INCLUDEALLCONTENTS;
  
  public static final boolean INCLUDEINITIALLYSELECTED;
  
  public static final String VALIDSTATES_WTPART_ALPHA;
  
  public static final String VALIDSTATES_WTPART_NUMERIC;
  
  public static final String VALIDSTATES_EPM_ALPHA;
  
  public static final String VALIDSTATES_EPM_NUMERIC;
  
  public static final String VALIDSTATES_WTDOC_ALPHA;
  
  public static final String VALIDSTATES_WTDOC_NUMERIC;
  
  public static final String VALIDSTATES_DESIGN_PKG;
  
  public static final String VALIDSTATES_SUPPLIER_PKG;
  
  public static final boolean CHECK_INCLUDE_DEPENDENTS;
  
  public static final boolean PROJ_PHASE_CHANGE;
  
  public static final boolean CHECK_REPRESENTATION;
  
  public static final boolean IMPL_PLAN_REQ;
  
  public static final int MAX_PS_GEN;
  
  public static String supportedContentTypes;
  
  public static String htmlpath;
  
  public static final String WT_HOME;
  
  public static final String TEMP_DIR;
  
  public static final boolean DEL_TEMP;
  
  public static final String WTTEMP;
  
  public static final float PDF_TABLE_PORTRAIT_Y;
  
  public static final float PDF_TABLE_PORTRAIT_X;
  
  public static final float PDF_TABLE_LANDSCAPE_X;
  
  public static final float PDF_TABLE_LANDSCAPE_Y;
  
  public static final String DOC_TO_PDF_SCRIPT;
  
  public static final String PDF_URL_IBA_NAME;
  
  public static final boolean docCheckinEnabled;
  
  public static final String QUALITY_FORM;
  
  public static final String DOC_LC_NAME;
  
  public static final String EPM_LC_NAME;
  
  public static final String PART_LC_NAME;
  
  public static final String HTML_TABLE_COLOR;
  
  public static final String CA_ROLES;
  
  public static final String SUPPLIER_ROLES;
  
  public static final String DESIGN_ROLES;
  
  public static final String RELEASE_VERSION;
  
  public static final int COLS;
  
  public static final int ROWS;
  
  public static final String DESIGN_PACKAGE_REVISION;
  
  public static final String DESIGN_PACKAGE_URL;
  
  public static final boolean CUSTOMER_VERFICATION;
  
  public static final boolean CUSTOMER_VALIDATION;
  
  static {
    try {
      WTProperties wTProperties = WTProperties.getLocalProperties();
      VERBOSE = wTProperties.getProperty("ext.piab.workflow.verbose", true);
      RELEASE_VERSION = wTProperties.getProperty("ext.piab.object.releaseversion");
      LC_STATE_1 = wTProperties.getProperty("ext.piab.lifecyclestate.1", "INWORK");
      LC_STATE_2 = wTProperties.getProperty("ext.piab.lifecyclestate.2", "REVIEWED");
      LC_STATE_3 = wTProperties.getProperty("ext.piab.lifecyclestate.3", "PRE-RELEASED");
      LC_STATE_4 = wTProperties.getProperty("ext.piab.lifecyclestate.4", "RELEASEDFORPRODUCTION");
      LC_STATE_5 = wTProperties.getProperty("ext.piab.lifecyclestate.5", "OBSOLETED");
      LCSTATE_INWORK = wTProperties.getProperty("ext.piab.lifecyclestate.inwork", "INWORK");
      LCSTATE_OPEN = wTProperties.getProperty("ext.piab.lifecyclestate.open", "OPEN");
      LCSTATE_UNDERREVIEW = wTProperties.getProperty("ext.piab.lifecyclestate.underreview", "UNDERREVIEW");
      LCSTATE_APPROVED = wTProperties.getProperty("ext.piab.lifecyclestate.approved", "APPROVED");
      LCSTATE_RELEASED = wTProperties.getProperty("ext.piab.lifecyclestate.released", "RELEASED");
      LCSTATE_RESOLVED = wTProperties.getProperty("ext.piab.lifecyclestate.resolved", "RESOLVED");
      LCSTATE_COMPLETED = wTProperties.getProperty("ext.piab.lifecyclestate.completed", "COMPLETED");
      LCSTATE_CANCELLED = wTProperties.getProperty("ext.piab.lifecyclestate.cancelled", "CANCELLED");
      LCSTATE_IN_ANALYSIS = wTProperties.getProperty("ext.piab.lifecyclestate.inanalysis", "IN ANALYSIS");
      SUPPLIER_PACKAGE_TYPE_NAME = wTProperties.getProperty("ext.piab.workflow.supplierpackagetypename", "SupplierPackage");
      DESIGN_PACKAGE_TYPE_NAME = wTProperties.getProperty("ext.piab.workflow.designpackagetypename", "DesignPackage");
      CUSTOMER_PACKAGE_TYPE_NAME = wTProperties.getProperty("ext.piab.workflow.customerpackagetypename", "DesignPackage");
      PACKAGE_PROJECTNUMBER = wTProperties.getProperty("ext.piab.workflow.package.projectnumber");
      PACKAGE_VENDORNUMBER = wTProperties.getProperty("ext.piab.workflow.packagevendornumber");
      DESIGN_PACKAGE_NUMBER = wTProperties.getProperty("ext.piab.workflow.designpackagetypenumber");
      DELIVERY_RECORD_ROLES = wTProperties.getProperty("ext.piab.exportrecord.requiredrole", "SUPPLIER");
      PACKAGE_FILTERSPEC = wTProperties.getProperty("ext.piab.workflow.packagefilterspec");
      INCLUDEALPHA = wTProperties.getProperty("ext.piab.workflow.includealpha", true);
      INCLUDENUMERIC = wTProperties.getProperty("ext.piab.workflow.includenumeric", true);
      INCLUDEALLCONTENTS = wTProperties.getProperty("ext.piab.workflow.includeallcontents", true);
      INCLUDEINITIALLYSELECTED = wTProperties.getProperty("ext.piab.workflow.includeinitiallyselected", true);
      DOC_LC_NAME = wTProperties.getProperty("ext.piab.wtdoc.lc.name", "PIAB CAD Document Lifecycle");
      EPM_LC_NAME = wTProperties.getProperty("ext.piab.epm.lc.name", "PIAB WTDocument Lifecycle");
      PART_LC_NAME = wTProperties.getProperty("ext.piab.part.lc.name", "PIAB WTPart Lifecycle");
      VALIDSTATES_WTPART_ALPHA = wTProperties.getProperty("ext.piab.validchangeitemstates.part.alpha");
      VALIDSTATES_WTPART_NUMERIC = wTProperties.getProperty("ext.piab.validchangeitemstates.part.numeric");
      VALIDSTATES_EPM_ALPHA = wTProperties.getProperty("ext.piab.validchangeitemstates.epm.alpha");
      VALIDSTATES_EPM_NUMERIC = wTProperties.getProperty("ext.piab.validchangeitemstates.epm.numeric");
      VALIDSTATES_WTDOC_ALPHA = wTProperties.getProperty("ext.piab.validchangeitemstates.wtdoc.alpha");
      VALIDSTATES_WTDOC_NUMERIC = wTProperties.getProperty("ext.piab.validchangeitemstates.wtdoc.numeric");
      VALIDSTATES_DESIGN_PKG = wTProperties.getProperty("ext.piab.designpkgstate");
      VALIDSTATES_SUPPLIER_PKG = wTProperties.getProperty("ext.piab.supplierpkgstate");
      CHECK_INCLUDE_DEPENDENTS = wTProperties.getProperty("ext.piab.workflow.checkincludedependents", true);
      PROJ_PHASE_CHANGE = wTProperties.getProperty("ext.piab.workflow.changeprojectphases", false);
      CHECK_REPRESENTATION = wTProperties.getProperty("ext.piab.workflow.checkrepresentations", false);
      IMPL_PLAN_REQ = wTProperties.getProperty("ext.piab.workflow.implementationplanrequired", false);
      MAX_PS_GEN = Integer.parseInt(wTProperties.getProperty("ext.piab.max_ps_gen", "300"));
      supportedContentTypes = wTProperties.getProperty("ext.piab.contentsupports", "DOC");
      docCheckinEnabled = wTProperties.getProperty("ext.piab.pdf.document.checkin.enabled", false);
      WT_HOME = wTProperties.getProperty("wt.home");
      WTTEMP = wTProperties.getProperty("wt.temp");
      TEMP_DIR = wTProperties.getProperty("ext.piab.temp_dir", WTTEMP);
      DEL_TEMP = wTProperties.getProperty("ext.piab.del_temp_dir", false);
      PDF_TABLE_PORTRAIT_X = wTProperties.getProperty("ext.piab.pdf_watermark_portrait_x", 148);
      PDF_TABLE_PORTRAIT_Y = wTProperties.getProperty("ext.piab.pdf_watermark_portrait_y", 762);
      PDF_TABLE_LANDSCAPE_X = wTProperties.getProperty("ext.piab.pdf_watermark_landscape_x", 245);
      PDF_TABLE_LANDSCAPE_Y = wTProperties.getProperty("ext.piab.pdf_watermark_landscape_y", 581);
      DOC_TO_PDF_SCRIPT = wTProperties.getProperty("ext.piab.pdf.document.script");
      PDF_URL_IBA_NAME = wTProperties.getProperty("ext.piab.pdf_iba_name", "pdfURL");
      QUALITY_FORM = wTProperties.getProperty("ext.piab.qualityform.name", "com.piab.QualityForm");
      COLS = wTProperties.getProperty("ext.piab.qualityform.cols", 4);
      ROWS = wTProperties.getProperty("ext.piab.qualityform.rows", 2);
      htmlpath = wTProperties.getProperty("ext.piab.templatepath", WT_HOME + "\\codebase\\templates\\ext\\piab\\html\\piabtemplate.html");
      HTML_TABLE_COLOR = wTProperties.getProperty("ext.piab.htmltable.color", "#E3E3CF");
      CA_ROLES = wTProperties.getProperty("ext.piab.notify.ca.role", "DESIGNER");
      SUPPLIER_ROLES = wTProperties.getProperty("ext.piab.notify.supplierpkg.role", "SUPPLIER");
      DESIGN_ROLES = wTProperties.getProperty("ext.piab.notify.designpkg.role", "DESIGNER");
      DESIGN_PACKAGE_REVISION = wTProperties.getProperty("ext.piab.workflow.designpackagerevision.name", "com.piab.DesignPackageRevision");
      DESIGN_PACKAGE_URL = wTProperties.getProperty("ext.piab.workflow.designpackageurl.name", "com.piab.DesignPackageURL");
      CUSTOMER_VERFICATION = wTProperties.getProperty("ext.piab.workflow.customer.successor.design.package.verified", false);
      CUSTOMER_VALIDATION = wTProperties.getProperty("ext.piab.workflow.customer.successor.design.package.validated", false);
    } catch (Throwable throwable) {
      System.err.println("Error initializing ");
      throwable.printStackTrace(System.err);
      throw new ExceptionInInitializerError(throwable);
    } 
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\commo\\util\PropertyforPIAB.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */