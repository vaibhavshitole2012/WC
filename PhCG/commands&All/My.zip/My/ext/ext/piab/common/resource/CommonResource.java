package ext.piab.common.resource;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("ext.piab.common.resource.CommonResource")
public final class CommonResource extends WTListResourceBundle {
  @RBEntry("Please select any one of the below Routing Options")
  public static final String ROUTING_ERROR_ALERT = "0";
  
  @RBEntry("The following objects inside this {0} follow incorrect or non-latest Lifecycle.\nSelect Objetcs with Latest Lifecycle Template to proceed.\n{1}.")
  public static final String INCORRECT_LC_STATE = "1";
  
  @RBEntry("The Project with Number [{0}] does not exist.\nPlease enter the correct Number to complete the task.")
  public static final String INCORRECT_PROJ_NUMBER = "2";
  
  @RBEntry("Name")
  public static final String PUBLISH_NAME = "3";
  
  @RBEntry("Published for PIAB")
  public static final String PUBLISH_DESC = "4";
  
  @RBEntry("Created from PIAB service")
  public static final String CONTEXTLINK_DESC = "5";
  
  @RBEntry("RELATED")
  public static final String CONTEXTLINK_RELATION = "6";
  
  @RBEntry("OPEN_RUNNING")
  public static final String WF_STATE = "7";
  
  @RBEntry("PIAB Design Package Verification")
  public static final String DEL_DESIGNPROCESS_NAME = "8";
  
  @RBEntry("Define Implementation Plan")
  public static final String DEL_CN_ACTIVITY_NAME = "9";
  
  @RBEntry("Change Request")
  public static final String CR_EXCP_STRING = "10";
  
  @RBEntry("Package")
  public static final String PKG_EXCP_STRING = "11";
  
  @RBEntry("Invalid relationship for {0} and {1}.\nCannot create relationship [{2}] between [{3}] and [{4}].")
  public static final String REFERENCE_1 = "200";
  
  @RBEntry("\nReferenced document \"{0}\" to part \"{1}\"")
  public static final String REFERENCE_2 = "201";
  
  @RBEntry("State")
  public static final String REFERENCE_3 = "202";
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\common\resource\CommonResource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */