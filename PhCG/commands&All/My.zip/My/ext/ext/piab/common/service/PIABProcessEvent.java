package ext.piab.common.service;

import com.ptc.windchill.wp.WPSuccessorLink;
import com.ptc.windchill.wp.WorkPackage;
import com.ptc.windchill.wp.WorkPackageMaster;
import ext.piab.common.util.PropertyforPIAB;
import ext.piab.common.util.UpdateIBAs;
import java.rmi.RemoteException;
import wt.change2.ChangeService2Event;
import wt.events.KeyedEvent;
import wt.events.KeyedEventListener;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceManagerEvent;
import wt.fc.QueryResult;
import wt.iba.value.IBAHolder;
import wt.method.RemoteAccess;
import wt.projmgmt.admin.Project2;
import wt.projmgmt.execution.ProjectPlan;
import wt.services.ManagerService;
import wt.type.TypedUtility;
import wt.util.WTException;
import wt.vc.Mastered;
import wt.vc.VersionControlHelper;
import wt.vc.Versioned;
import wt.vc.config.ConfigHelper;
import wt.vc.config.ConfigSpec;
import wt.vc.config.LatestConfigSpec;
import wt.workflow.engine.WfEngineHelper;

public class PIABProcessEvent implements RemoteAccess {
  private static final boolean VERBOSE = PropertyforPIAB.VERBOSE;
  
  private static final String CUSTOMER_PACKAGE_TYPE_NAME = PropertyforPIAB.CUSTOMER_PACKAGE_TYPE_NAME;
  
  private static final String DESIGN_PACKAGE_TYPE_NAME = PropertyforPIAB.DESIGN_PACKAGE_TYPE_NAME;
  
  private static final String SUPPLIER_PACKAGE_TYPE_NAME = PropertyforPIAB.SUPPLIER_PACKAGE_TYPE_NAME;
  
  private static final String PACKAGE_PROJECTNUMBER = PropertyforPIAB.PACKAGE_PROJECTNUMBER;
  
  private static final String PACKAGE_VENDORNUMBER = PropertyforPIAB.PACKAGE_VENDORNUMBER;
  
  private static final String DESIGN_PACKAGE_NUMBER = PropertyforPIAB.DESIGN_PACKAGE_NUMBER;
  
  private static final String DESIGN_PACKAGE_REVISION = PropertyforPIAB.DESIGN_PACKAGE_REVISION;
  
  private static final String DESIGN_PACKAGE_URL = PropertyforPIAB.DESIGN_PACKAGE_URL;
  
  public void initialize(ManagerService paramManagerService, KeyedEventListener paramKeyedEventListener) {
    paramManagerService.addEventListener(paramKeyedEventListener, PersistenceManagerEvent.generateEventKey("PRE_STORE"));
    paramManagerService.addEventListener(paramKeyedEventListener, PersistenceManagerEvent.generateEventKey("POST_STORE"));
    paramManagerService.addEventListener(paramKeyedEventListener, PersistenceManagerEvent.generateEventKey("PRE_INSERT"));
    System.out.println("[$$$$$$$$  PIAB service started $$$$$........!]");
  }
  
  public void notifyEvent(KeyedEvent paramKeyedEvent) throws RemoteException, WTException {
    if (paramKeyedEvent instanceof PersistenceManagerEvent)
      notifyEvent((PersistenceManagerEvent)paramKeyedEvent); 
    if (paramKeyedEvent instanceof ChangeService2Event)
      notifyEvent((ChangeService2Event)paramKeyedEvent); 
  }
  
  protected void notifyEvent(PersistenceManagerEvent paramPersistenceManagerEvent) throws RemoteException, WTException {
    Persistable persistable = paramPersistenceManagerEvent.getTarget();
    WorkPackage workPackage = null;
    try {
      if (paramPersistenceManagerEvent.getEventType().equals("PRE_STORE")) {
        if (persistable instanceof WorkPackage) {
          System.out.println("\n PRE_STORE WorkPackage getConceptualClassname.......... : " + persistable.getConceptualClassname());
          workPackage = (WorkPackage)persistable;
        } else if (persistable instanceof ProjectPlan) {
          ProjectPlan projectPlan = (ProjectPlan)persistable;
          Project2 project2 = (Project2)projectPlan.getContainer();
          project2.getContainerTeamManagedInfo().setSendInvitations(false);
          System.out.println("***Set Invitation to False****");
        } 
      } else if (paramPersistenceManagerEvent.getEventType().equals("POST_STORE") && persistable instanceof WorkPackage) {
        workPackage = (WorkPackage)persistable;
        String str = workPackage.getName();
        System.out.println("\n POST_STORE TypeIdentifier INSIDE IF: " + TypedUtility.getTypeIdentifier(workPackage));
        if (str.toUpperCase().endsWith("-DONTDELETEIBA")) {
          System.out.println("\n POST_STORE TypeIdentifier INSIDE Dont Delete Iba for Revise Package: " + str);
          str = str.replace("-DONTDELETEIBA", " ");
          workPackage.setName(str);
          workPackage = (WorkPackage)PersistenceHelper.manager.save((Persistable)workPackage);
          System.out.println("\n POST_STORE TypeIdentifier INSIDE Dont Delete Iba Revertr back PackageName: " + str);
        } else {
          System.out.println("\n POST_STORE TypeIdentifier INSIDE Delete Iba for Package: " + str);
          if (TypedUtility.getTypeIdentifier(workPackage).toString().endsWith(DESIGN_PACKAGE_TYPE_NAME)) {
            UpdateIBAs.updateIBAStringValue((IBAHolder)workPackage, "-", PACKAGE_PROJECTNUMBER);
            System.out.println("\n POST_STORE TypeIdentifier AFTER Delete: Iba for Package: " + PACKAGE_PROJECTNUMBER);
          } 
          if (TypedUtility.getTypeIdentifier(workPackage).toString().endsWith(SUPPLIER_PACKAGE_TYPE_NAME)) {
            UpdateIBAs.updateIBAStringValue((IBAHolder)workPackage, "-", PACKAGE_VENDORNUMBER);
            System.out.println("\n POST_STORE TypeIdentifier AFTER Delete: Iba for Package: " + PACKAGE_VENDORNUMBER);
          } 
          if (TypedUtility.getTypeIdentifier(workPackage).toString().endsWith(CUSTOMER_PACKAGE_TYPE_NAME)) {
            UpdateIBAs.updateIBAStringValue((IBAHolder)workPackage, "-", DESIGN_PACKAGE_NUMBER);
            UpdateIBAs.updateIBAStringValue((IBAHolder)workPackage, "-", DESIGN_PACKAGE_REVISION);
            UpdateIBAs.updateIBAUrl((IBAHolder)workPackage, "-", "", DESIGN_PACKAGE_URL);
            System.out.println("\n POST_STORE TypeIdentifier AFTER Delete: Iba for Package: " + DESIGN_PACKAGE_NUMBER);
          } 
        } 
        if (TypedUtility.getTypeIdentifier(workPackage).toString().endsWith(DESIGN_PACKAGE_TYPE_NAME)) {
          QueryResult queryResult = VersionControlHelper.service.allVersionsOf((Versioned)workPackage);
          System.out.println("*** POST_STORE: Predecessor  packages Size :" + queryResult.size());
          while (queryResult.hasMoreElements()) {
            WorkPackage workPackage1 = (WorkPackage)queryResult.nextElement();
            System.out.println("*** POST_STORE: Predecessor  package number" + workPackage1.getNumber() + "name " + workPackage1.getName() + " - " + workPackage1.getVersionIdentifier().getValue());
            if (!workPackage1.equals(workPackage)) {
              WfEngineHelper.service.terminateObjectsRunningWorkflows((Persistable)workPackage1);
              System.out.println("*** POST_STORE: Predecessor wf terminated");
            } 
          } 
        } else if (persistable instanceof WPSuccessorLink) {
          WorkPackage workPackage1 = null;
          WPSuccessorLink wPSuccessorLink = (WPSuccessorLink)persistable;
          if (VERBOSE)
            System.out.println("\n POST_STORE WPSuccessorLink INSIDE WPSuccessorLink: " + wPSuccessorLink); 
          WorkPackage workPackage2 = (WorkPackage)wPSuccessorLink.getRoleAObject();
          if (VERBOSE)
            System.out.println("\n POST_STORE WPSuccessorLink INSIDE WPSuccessorLink role A : " + workPackage2.getNumber() + "version" + workPackage2.getVersionInfo().getIdentifier().getValue()); 
          WorkPackageMaster workPackageMaster = (WorkPackageMaster)wPSuccessorLink.getRoleBObject();
          LatestConfigSpec latestConfigSpec = new LatestConfigSpec();
          QueryResult queryResult = ConfigHelper.service.filteredIterationsOf((Mastered)workPackageMaster, (ConfigSpec)latestConfigSpec);
          if (VERBOSE)
            System.out.println("Error in retrieving Latest WorkPackage Size" + queryResult.size()); 
          if (queryResult.size() == 1) {
            workPackage1 = (WorkPackage)queryResult.nextElement();
            if (VERBOSE)
              System.out.println("Latest WorkPackage returned from query - Number [" + workPackage1.getNumber() + "]: Revision [" + workPackage1.getVersionIdentifier().getValue() + "]: Iteration [" + workPackage1.getIterationIdentifier().getValue() + "]"); 
          } else if (VERBOSE) {
            System.out.println("Error in retrieving Latest WorkPackage");
          } 
          if (TypedUtility.getTypeIdentifier(workPackage1).toString().endsWith(DESIGN_PACKAGE_TYPE_NAME)) {
            UpdateIBAs.updateIBAStringValue((IBAHolder)workPackage1, "-", PACKAGE_PROJECTNUMBER);
          } else if (TypedUtility.getTypeIdentifier(workPackage1).toString().endsWith(SUPPLIER_PACKAGE_TYPE_NAME)) {
            UpdateIBAs.updateIBAStringValue((IBAHolder)workPackage1, "-", PACKAGE_VENDORNUMBER);
          } else if (TypedUtility.getTypeIdentifier(workPackage1).toString().endsWith(CUSTOMER_PACKAGE_TYPE_NAME)) {
            UpdateIBAs.updateIBAStringValue((IBAHolder)workPackage1, "-", DESIGN_PACKAGE_NUMBER);
            UpdateIBAs.updateIBAStringValue((IBAHolder)workPackage, "-", DESIGN_PACKAGE_REVISION);
            UpdateIBAs.updateIBAUrl((IBAHolder)workPackage, "-", "", DESIGN_PACKAGE_URL);
          } 
        } 
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  protected void notifyEvent(ChangeService2Event paramChangeService2Event) {}
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\common\service\PIABProcessEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */