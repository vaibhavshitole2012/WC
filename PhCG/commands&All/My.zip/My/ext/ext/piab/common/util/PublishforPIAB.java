package ext.piab.common.util;

import com.ptc.windchill.wp.WorkPackage;
import com.ptc.wvs.common.ui.Publisher;
import ext.piab.common.resource.CommonResource;
import ext.piab.packages.common.util.PackageContentList;
import ext.piab.publish.util.PIABPublishScheduler;
import wt.doc.WTDocument;
import wt.epm.EPMDocument;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.fc.WTReference;
import wt.fc.collections.WTArrayList;
import wt.maturity.MaturityHelper;
import wt.maturity.PromotionNotice;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.WTPropertyVetoException;

public class PublishforPIAB {
  private static final boolean VERBOSE = PropertyforPIAB.VERBOSE;
  
  private static final String COMMOM_RESOURCE = CommonResource.class.getName();
  
  private static String description = WTMessage.getLocalizedMessage(COMMOM_RESOURCE, "4");
  
  private static String name = WTMessage.getLocalizedMessage(COMMOM_RESOURCE, "3");
  
  public static void doPublish(Persistable paramPersistable) throws WTException, WTPropertyVetoException {
    if (VERBOSE)
      System.out.println("PublishforPIAB.doPublish"); 
    ReferenceFactory referenceFactory = new ReferenceFactory();
    WTReference wTReference = referenceFactory.getReference(paramPersistable);
    String str = referenceFactory.getReferenceString(wTReference);
    int i = getPublishobjectType(paramPersistable, 0);
    if (i == 0) {
      if (VERBOSE)
        System.out.println("Do not Pusblish"); 
    } else {
      Publisher publisher = new Publisher();
      publisher.doPublish(true, true, str, "REP", true, name, description, i);
    } 
  }
  
  public static int getPublishobjectType(Persistable paramPersistable, int paramInt) throws WTException, WTPropertyVetoException {
    if (VERBOSE)
      System.out.println("PublishforPIAB.getPublishobjectType"); 
    if (paramPersistable instanceof EPMDocument) {
      paramInt = 3;
    } else if (paramPersistable instanceof wt.part.WTPart) {
      paramInt = 2;
    } 
    return paramInt;
  }
  
  public static void publishPromotionTargets(PromotionNotice paramPromotionNotice) throws Exception {
    if (VERBOSE)
      System.out.println("*** Publish Promotion Targets for Promotion Notice: (" + paramPromotionNotice.getIdentity() + ")"); 
    QueryResult queryResult = MaturityHelper.service.getPromotionTargets(paramPromotionNotice, true);
    if (VERBOSE)
      System.out.println("***Size-" + queryResult.size()); 
    while (queryResult.hasMoreElements()) {
      Persistable persistable = (Persistable)queryResult.nextElement();
      if (persistable instanceof WTDocument) {
        WTDocument wTDocument = (WTDocument)persistable;
        if (VERBOSE)
          System.out.println("*** Object is an instance of WTDocument - " + wTDocument.getIdentity()); 
        PIABPublishScheduler.publishDocument(wTDocument);
        continue;
      } 
      if (persistable instanceof EPMDocument) {
        EPMDocument ePMDocument = (EPMDocument)persistable;
        if (VERBOSE)
          System.out.println("*** Object is an instance of EPMDocument - " + ePMDocument.getIdentity()); 
        PIABPublishScheduler.sendPublishJob(ePMDocument);
        continue;
      } 
      if (VERBOSE)
        System.out.println("***Change Object is not either EPMDocument or WTDocument - Cannot publish"); 
    } 
  }
  
  public static void publishPackageItems(WorkPackage paramWorkPackage) throws Exception {
    if (VERBOSE)
      System.out.println("*** Publish Pacakge Items for Design Package: (" + paramWorkPackage.getIdentity() + ")"); 
    try {
      WTArrayList wTArrayList = PackageContentList.getContentsList(paramWorkPackage);
      Object[] arrayOfObject = wTArrayList.toArray();
      if (VERBOSE)
        System.out.println("***Size-" + arrayOfObject.length); 
      for (byte b = 0; b < arrayOfObject.length; b++) {
        ObjectReference objectReference = (ObjectReference)arrayOfObject[b];
        Persistable persistable = objectReference.getObject();
        if (persistable instanceof WTDocument) {
          WTDocument wTDocument = (WTDocument)persistable;
          if (VERBOSE)
            System.out.println("*** Object is an instance of WTDocument - " + wTDocument.getIdentity()); 
          PIABPublishScheduler.publishDocument(wTDocument);
        } else if (persistable instanceof EPMDocument) {
          EPMDocument ePMDocument = (EPMDocument)persistable;
          if (VERBOSE)
            System.out.println("*** Object is an instance of EPMDocument - " + ePMDocument.getIdentity()); 
          PIABPublishScheduler.sendPublishJob(ePMDocument);
        } else if (VERBOSE) {
          System.out.println("***Change Object is not either EPMDocument or WTDocument - Cannot publish");
        } 
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\commo\\util\PublishforPIAB.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */