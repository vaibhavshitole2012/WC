package ext.piab.common.util;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import wt.content.ApplicationData;
import wt.content.ContentHelper;
import wt.content.ContentHolder;
import wt.content.ContentRoleType;
import wt.content.ContentServerHelper;
import wt.doc.WTDocument;
import wt.epm.EPMDocument;
import wt.fc.QueryResult;
import wt.fc.WTObject;
import wt.util.WTException;
import wt.util.WTProperties;

public class PushPDFs {
  private static final String CLASSNAME = PushPDFs.class.getName();
  
  private static final boolean VERBOSE = PropertyforPIAB.VERBOSE;
  
  protected static WTProperties props = null;
  
  private static String SP_SHARED_DIR = null;
  
  public static String checkForPDFs(WTObject paramWTObject, ContentRoleType paramContentRoleType) throws Exception {
    if (VERBOSE)
      System.out.println("***PushPDFs.checkForPDFs()"); 
    boolean bool = true;
    String str1 = "";
    String str2 = ".PDF";
    try {
      if (paramWTObject instanceof WTDocument) {
        WTDocument wTDocument = (WTDocument)paramWTObject;
        if (VERBOSE)
          System.out.println("**Object is an instance of WTDocument : " + wTDocument.getNumber()); 
        str1 = wTDocument.getNumber() + str2;
        bool = isPDFGenerated((ContentHolder)wTDocument, str1);
      } else if (paramWTObject instanceof EPMDocument) {
        EPMDocument ePMDocument = (EPMDocument)paramWTObject;
        if (VERBOSE)
          System.out.println("***PushPDFs.checkForPDFs() - EPMDocument found : " + ePMDocument.getIdentity()); 
        String str = ePMDocument.getDocType().toString();
        if (VERBOSE)
          System.out.println("***PushPDFs.checkForPDFs() - EPMDocument type : " + str); 
        if (str.equalsIgnoreCase("CADDRAWING")) {
          if (ePMDocument.getNumber().lastIndexOf('.') > 0) {
            String str3 = ePMDocument.getNumber().substring(0, ePMDocument.getNumber().lastIndexOf('.'));
            str1 = str3 + str2;
          } else {
            str1 = ePMDocument.getNumber() + str2;
          } 
          if (VERBOSE)
            System.out.println("***PushPDFs.checkForPDFs - fileName : " + str1); 
          bool = isPDFGenerated((ContentHolder)ePMDocument, str1);
        } 
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
      return exception.getLocalizedMessage();
    } 
    return "";
  }
  
  public static File pushPdfs(ApplicationData paramApplicationData) throws Exception {
    if (VERBOSE)
      System.out.println("***PushPDFs.pushPdfs() - " + paramApplicationData.getFileName()); 
    String str = SP_SHARED_DIR;
    File file = ticketFolder(str);
    try {
      if (VERBOSE)
        System.out.println("Ticket folder path : " + file); 
      String str1 = paramApplicationData.getFileName();
      File file1 = new File(file, paramApplicationData.getFileName());
      ContentServerHelper.service.writeContentStream(paramApplicationData, file1.getCanonicalPath());
      if (VERBOSE)
        System.out.println("***Created secondary attachment PDF in the ticket directory" + file1.getAbsolutePath()); 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return file;
  }
  
  public static boolean isPDFGenerated(ContentHolder paramContentHolder, String paramString) {
    if (VERBOSE)
      System.out.println("*** PushPDFs.isPDFGenerated()****" + paramContentHolder.getIdentity()); 
    boolean bool = false;
    try {
      if (paramContentHolder instanceof WTDocument) {
        WTDocument wTDocument = (WTDocument)paramContentHolder;
        QueryResult queryResult = ContentHelper.service.getContentsByRole((ContentHolder)wTDocument, ContentRoleType.SECONDARY);
        if (VERBOSE)
          System.out.println("***WTDocument : " + wTDocument.getNumber() + " secondary content size : " + queryResult.size()); 
        Object object = null;
        ArrayList arrayList = new ArrayList(queryResult.size());
        if (queryResult.size() > 0)
          while (queryResult.hasMoreElements()) {
            ApplicationData applicationData = (ApplicationData)queryResult.nextElement();
            String str = applicationData.getFileName();
            if (VERBOSE)
              System.out.println("Required Secondary File Name: " + paramString); 
            if (VERBOSE)
              System.out.println("Existing Secondary File Name: " + str); 
            if (str.equalsIgnoreCase(paramString)) {
              if (VERBOSE)
                System.out.println("PDF File Exists.."); 
              bool = true;
              File file = pushPdfs(applicationData);
              CreateXmlFile.dropWTDocXmlFile(wTDocument, file, applicationData);
            } 
          }  
      } else if (paramContentHolder instanceof EPMDocument) {
        EPMDocument ePMDocument = (EPMDocument)paramContentHolder;
        QueryResult queryResult = ContentHelper.service.getContentsByRole((ContentHolder)ePMDocument, ContentRoleType.SECONDARY);
        if (VERBOSE)
          System.out.println("***EPMDocument : " + ePMDocument.getNumber() + " secondary content size : " + queryResult.size()); 
        Object object = null;
        ArrayList arrayList = new ArrayList(queryResult.size());
        if (queryResult.size() > 0)
          while (queryResult.hasMoreElements()) {
            ApplicationData applicationData = (ApplicationData)queryResult.nextElement();
            String str = applicationData.getFileName();
            if (VERBOSE)
              System.out.println("Required Secondary File Name: " + paramString); 
            if (VERBOSE)
              System.out.println("Existing Secondary File Name: " + str); 
            if (str.equalsIgnoreCase(paramString)) {
              if (VERBOSE)
                System.out.println("PDF File Exists.."); 
              bool = true;
              File file = pushPdfs(applicationData);
              CreateXmlFile.dropEPMDocXmlFile(ePMDocument, file, applicationData);
            } 
          }  
      } 
    } catch (WTException wTException) {
      wTException.printStackTrace();
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return bool;
  }
  
  public static File ticketFolder(String paramString) throws Exception {
    long l = (new Date()).getTime();
    File file = new File(paramString + File.separator + l);
    try {
      Thread.currentThread();
      Thread.sleep(1000L);
      file.mkdir();
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return file;
  }
  
  static {
    try {
      props = WTProperties.getLocalProperties();
      SP_SHARED_DIR = props.getProperty("ext.datafrond.sharepoint.shareddir");
    } catch (Exception exception) {
      System.out.println("Error reading proeprty file..");
      exception.printStackTrace();
    } 
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\commo\\util\PushPDFs.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */