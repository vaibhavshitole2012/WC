package ext.piab.common.validation;

import ext.piab.common.resource.CommonResource;
import ext.piab.common.util.PropertyforPIAB;
import ext.piab.common.util.RelatedContextLink;
import ext.piab.common.util.Teamhelper;
import wt.fc.Persistable;
import wt.method.RemoteAccess;
import wt.projmgmt.admin.Project2;
import wt.util.WTException;

public class ValidateProject implements RemoteAccess {
  private static final boolean VERBOSE = PropertyforPIAB.VERBOSE;
  
  private static final String COMMON_RESOURCE = CommonResource.class.getName();
  
  public static void projExist(Persistable paramPersistable, String paramString) throws Exception {
    if (VERBOSE)
      System.out.println("***ValidateProject.projExist()"); 
    if (paramString != null) {
      Project2 project2 = RelatedContextLink.getProject(paramString);
      if (project2 != null) {
        System.out.println("Project exist with Number-" + project2.getProjectNumber());
        RelatedContextLink.updateIBA(paramPersistable, paramString);
        Teamhelper.copyTeam(paramPersistable, paramString, true);
        RelatedContextLink.createContextLink(paramPersistable, project2);
      } else {
        System.out.println("Project does not exist");
        Object[] arrayOfObject = { paramString };
        throw new WTException(COMMON_RESOURCE, "2", arrayOfObject);
      } 
    } 
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\common\validation\ValidateProject.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */