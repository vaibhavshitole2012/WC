package ext.piab.common.service;

import java.io.Serializable;
import java.rmi.RemoteException;
import wt.events.KeyedEvent;
import wt.events.KeyedEventListener;
import wt.services.ManagerException;
import wt.services.ServiceEventListenerAdapter;
import wt.services.StandardManager;
import wt.util.WTException;

public class StandardPIABService extends StandardManager implements PIABService, Serializable {
  private static final long serialVersionUID = 1L;
  
  private static final String CLASSNAME = StandardPIABService.class.getName();
  
  private KeyedEventListener listener;
  
  private PIABProcessEvent piabProcessEvent = new PIABProcessEvent();
  
  public String getConceptualClassname() {
    return CLASSNAME;
  }
  
  public static StandardPIABService newStandardPIABService() throws WTException {
    StandardPIABService standardPIABService = new StandardPIABService();
    standardPIABService.initialize();
    return standardPIABService;
  }
  
  protected void performStartupProcess() throws ManagerException {
    this.listener = (KeyedEventListener)new PIABListener(getConceptualClassname());
    this.piabProcessEvent.initialize(getManagerService(), this.listener);
  }
  
  public PIABProcessEvent getpiabProcessEvent() {
    return this.piabProcessEvent;
  }
  
  class PIABListener extends ServiceEventListenerAdapter {
    public PIABListener(String param1String) {
      super(param1String);
    }
    
    public void notifyVetoableEvent(Object param1Object) throws WTException {
      notifyEvent(param1Object);
    }
    
    public void notifyEvent(Object param1Object) {
      if (!(param1Object instanceof KeyedEvent))
        return; 
      try {
        StandardPIABService.this.piabProcessEvent.notifyEvent((KeyedEvent)param1Object);
      } catch (RemoteException remoteException) {
        remoteException.printStackTrace();
      } catch (WTException wTException) {
        wTException.printStackTrace();
      } 
    }
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\common\service\StandardPIABService.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */