package ext.piab.common.util;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import wt.enterprise._RevisionControlled;
import wt.epm.EPMDocument;
import wt.epm.EPMDocumentHelper;
import wt.epm.ReviseOptions;
import wt.epm.build.EPMBuildRule;
import wt.epm.structure.AssociatedObjects;
import wt.epm.util.EPMFilter;
import wt.epm.util.EPMFilters;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.WTObject;
import wt.fc.collections.WTArrayList;
import wt.fc.collections.WTCollection;
import wt.fc.collections.WTHashSet;
import wt.fc.collections.WTKeyedHashMap;
import wt.fc.collections.WTKeyedMap;
import wt.fc.collections.WTValuedMap;
import wt.inf.container.WTContained;
import wt.inf.container.WTContainerHelper;
import wt.inf.container.WTContainerRef;
import wt.lifecycle.LifeCycleManaged;
import wt.lifecycle.State;
import wt.org.WTPrincipal;
import wt.part.WTPart;
import wt.pom.Transaction;
import wt.series.MultilevelSeries;
import wt.series.Series;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.vc.Iterated;
import wt.vc.IterationIdentifier;
import wt.vc.VersionControlHelper;
import wt.vc.VersionIdentifier;
import wt.vc.Versioned;

public class ReviseUtility {
  private static final boolean VERBOSE = PropertyforPIAB.VERBOSE;
  
  private static final String RELEASE_VERSION = PropertyforPIAB.RELEASE_VERSION;
  
  private static final String LC_STATE_4 = PropertyforPIAB.LC_STATE_4;
  
  public static Versioned doRevise(Versioned paramVersioned, String paramString) throws Exception {
    if (VERBOSE)
      System.out.println("ReviseUtility.doRevise" + paramVersioned); 
    if (VersionControlHelper.service.isRevisable(paramVersioned, true)) {
      WTContainerRef wTContainerRef = WTContainerHelper.getContainerRef((WTContained)paramVersioned);
      Series series = null;
      series = VersionControlHelper.getSeries(paramVersioned.getClass(), wTContainerRef);
      System.out.println("ser........:: " + series.getUniqueSeriesName());
      series.setValueWithoutValidating(paramString);
      VersionIdentifier versionIdentifier = VersionIdentifier.newVersionIdentifier((MultilevelSeries)series);
      if (paramVersioned instanceof wt.doc.WTDocument) {
        IterationIdentifier iterationIdentifier = VersionControlHelper.firstIterationId((Iterated)paramVersioned);
        paramVersioned = VersionControlHelper.service.newVersion(paramVersioned, versionIdentifier, iterationIdentifier);
        paramVersioned = (Versioned)PersistenceHelper.manager.save((Persistable)paramVersioned);
        paramVersioned = (Versioned)PersistenceHelper.manager.refresh((Persistable)paramVersioned);
      } else {
        WTKeyedHashMap wTKeyedHashMap = new WTKeyedHashMap();
        ReviseOptions reviseOptions = new ReviseOptions();
        reviseOptions.reviseParts = true;
        reviseOptions.part.versionId = versionIdentifier;
        reviseOptions.document.versionId = versionIdentifier;
        wTKeyedHashMap.put((Persistable)paramVersioned, reviseOptions);
        EPMFilters.MultiStageFilter multiStageFilter = new EPMFilters.MultiStageFilter(new EPMFilter[] { EPMFilters.IN_PDM, EPMFilters.NO_WORKING });
        ArrayList<Versioned> arrayList = new ArrayList();
        arrayList.add(paramVersioned);
        AssociatedObjects associatedObjects = new AssociatedObjects((EPMFilter)multiStageFilter);
        List list = associatedObjects.findEPMRelated(arrayList, true);
        WTObject[] arrayOfWTObject = (WTObject[])list.toArray((Object[])new WTObject[list.size()]);
        for (byte b = 0; b < arrayOfWTObject.length; b++)
          wTKeyedHashMap.put((Persistable)arrayOfWTObject[b], reviseOptions); 
        WTKeyedMap wTKeyedMap = EPMDocumentHelper.service.reviseAll((WTKeyedMap)wTKeyedHashMap);
        paramVersioned = (Versioned)wTKeyedMap.get((Persistable)paramVersioned);
      } 
    } else {
      throw new Exception("Object " + paramVersioned + " cannot be revised ");
    } 
    return paramVersioned;
  }
  
  public static WTArrayList getBuildLinkedParts(WTArrayList paramWTArrayList) throws WTException, WTPropertyVetoException {
    if (VERBOSE)
      System.out.println("ReviseUtility.getBuildLinkedParts"); 
    WTArrayList wTArrayList = new WTArrayList();
    try {
      Iterator<ObjectReference> iterator = paramWTArrayList.iterator();
      System.out.println("pkgItemList size " + paramWTArrayList.size());
      while (iterator.hasNext()) {
        ObjectReference objectReference = iterator.next();
        if (objectReference.getObject() instanceof EPMDocument) {
          EPMDocument ePMDocument = (EPMDocument)objectReference.getObject();
          QueryResult queryResult = PersistenceHelper.manager.navigate((Persistable)ePMDocument, "buildTarget", EPMBuildRule.class, true);
          System.out.println("Query size DEPENDENT PARTS: " + queryResult.size());
          while (queryResult.hasMoreElements()) {
            WTPart wTPart = (WTPart)queryResult.nextElement();
            System.out.println(" EPM " + ePMDocument + "DEPENDENT WTPART " + wTPart);
            wTArrayList.add((Persistable)wTPart);
          } 
        } 
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return wTArrayList;
  }
  
  public static WTArrayList getItemstoRevise(WTArrayList paramWTArrayList1, WTArrayList paramWTArrayList2) throws WTException, WTPropertyVetoException {
    if (VERBOSE)
      System.out.println("ReviseUtility.getItemstoRevise()"); 
    if (paramWTArrayList1.containsAll((Collection)paramWTArrayList2)) {
      System.out.println("There are  " + paramWTArrayList2.size() + "WTPARTs associated with EPM's ");
      paramWTArrayList1.removeAll((Collection)paramWTArrayList2);
    } 
    return paramWTArrayList1;
  }
  
  public static void reviseItems(WTArrayList paramWTArrayList) throws Exception {
    if (VERBOSE)
      System.out.println("ReviseUtility.reviseItems()"); 
    try {
      WTArrayList wTArrayList = getBuildLinkedParts(paramWTArrayList);
      System.out.println("pkgItemList for revising  " + paramWTArrayList.size());
      paramWTArrayList = getItemstoRevise(paramWTArrayList, wTArrayList);
      Object[] arrayOfObject = paramWTArrayList.toArray();
      for (byte b = 0; b < arrayOfObject.length; b++) {
        ObjectReference objectReference = (ObjectReference)arrayOfObject[b];
        WTObject wTObject = (WTObject)objectReference.getObject();
        wTObject = processItemstoRevise(wTObject);
        if (wTObject instanceof EPMDocument) {
          EPMDocument ePMDocument = (EPMDocument)wTObject;
          processEPMBuildTargets((Persistable)ePMDocument);
          if (VERBOSE)
            System.out.println("*** EPMDocument revised to." + ePMDocument.getVersionInfo().getIdentifier().getValue()); 
        } 
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  private static WTObject processItemstoRevise(WTObject paramWTObject) throws Exception {
    if (VERBOSE)
      System.out.println("ReviseUtility.processItemstoRevise()"); 
    try {
      String str = ((_RevisionControlled)paramWTObject).getVersionInfo().getIdentifier().getValue();
      if (VERBOSE)
        System.out.println("rivisionIdentifier" + str); 
      boolean bool = isLatestObj(paramWTObject);
      if (bool) {
        if (!Character.isDigit(RELEASE_VERSION.charAt(0))) {
          if (Character.isDigit(str.charAt(0))) {
            paramWTObject = (WTObject)doRevise((Versioned)paramWTObject, RELEASE_VERSION);
            paramWTObject = (WTObject)PersistenceHelper.manager.refresh((Persistable)paramWTObject);
          } 
        } else if (Character.isDigit(RELEASE_VERSION.charAt(0)) && !Character.isDigit(str.charAt(0))) {
          paramWTObject = (WTObject)doRevise((Versioned)paramWTObject, RELEASE_VERSION);
          paramWTObject = (WTObject)PersistenceHelper.manager.refresh((Persistable)paramWTObject);
        } 
        paramWTObject = (WTObject)LifecycleStateHelper.setLifecycleState((Persistable)paramWTObject, LC_STATE_4);
        if (VERBOSE)
          System.out.println("***processItemstoRevise: revised to" + ((_RevisionControlled)paramWTObject).getVersionIdentifier().getValue()); 
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return paramWTObject;
  }
  
  public static WTObject getLatestRevision(WTObject paramWTObject) throws Exception {
    if (VERBOSE)
      System.out.println("*** ReviseUtility.getLatestRevision()"); 
    String str = ((Versioned)paramWTObject).getVersionIdentifier().getValue() + "." + ((Versioned)paramWTObject).getIterationIdentifier().getValue();
    if (VERBOSE)
      System.out.println("***Revision of Object in the Packlage - " + str); 
    QueryResult queryResult = VersionControlHelper.service.allVersionsOf((Versioned)paramWTObject);
    if (VERBOSE)
      System.out.println("***number of Revisions - " + queryResult.size()); 
    WTObject wTObject = paramWTObject;
    while (queryResult.hasMoreElements()) {
      Timestamp timestamp1 = wTObject.getCreateTimestamp();
      if (VERBOSE)
        System.out.println("***Version of latestObj - " + ((Versioned)wTObject).getVersionIdentifier().getValue() + "." + ((Versioned)wTObject).getIterationIdentifier().getValue()); 
      WTObject wTObject1 = (WTObject)queryResult.nextElement();
      Timestamp timestamp2 = wTObject1.getCreateTimestamp();
      String str1 = ((Versioned)wTObject1).getVersionIdentifier().getValue() + "." + ((Versioned)wTObject1).getIterationIdentifier().getValue();
      if (VERBOSE)
        System.out.println("***Version of next Object - " + str1); 
      if (timestamp2.after(timestamp1))
        wTObject = wTObject1; 
    } 
    wTObject = (WTObject)VersionControlHelper.getLatestIteration((Iterated)wTObject, false);
    if (VERBOSE)
      System.out.println("***Final Latest Revision Returning is " + ((Versioned)wTObject).getVersionIdentifier().getValue() + "." + ((Versioned)wTObject).getIterationIdentifier().getValue()); 
    return wTObject;
  }
  
  public static boolean isLatestObj(WTObject paramWTObject) throws Exception {
    if (VERBOSE)
      System.out.println("***ReviseUtility.isLatestObj"); 
    boolean bool = false;
    WTObject wTObject = getLatestRevision(paramWTObject);
    if (wTObject.equals(paramWTObject))
      bool = true; 
    if (VERBOSE)
      System.out.println("Returning latest" + bool); 
    return bool;
  }
  
  private static void processEPMBuildTargets(Persistable paramPersistable) throws Exception {
    QueryResult queryResult = PersistenceHelper.manager.navigate(paramPersistable, "buildTarget", EPMBuildRule.class, true);
    System.out.println("processEPMBuildTargets:Query size REVISED PARTS: " + queryResult.size());
    while (queryResult.hasMoreElements()) {
      WTPart wTPart = (WTPart)queryResult.nextElement();
      System.out.println(" EPM " + paramPersistable + "REVISED DEPENDENT WTPART " + wTPart);
      processItemstoRevise((WTObject)wTPart);
    } 
  }
  
  public static WTCollection reviseAll(WTArrayList paramWTArrayList) throws WTException {
    Transaction transaction = null;
    WTCollection wTCollection = null;
    WTKeyedHashMap wTKeyedHashMap = new WTKeyedHashMap();
    WTHashSet wTHashSet = new WTHashSet();
    wTHashSet.addAll((Collection)paramWTArrayList);
    try {
      for (byte b = 0; b < paramWTArrayList.size(); b++) {
        ObjectReference objectReference = (ObjectReference)paramWTArrayList.get(b);
        Versioned versioned = (Versioned)objectReference.getObject();
        String str1 = "";
        MultilevelSeries multilevelSeries = versioned.getVersionIdentifier().getSeries();
        String str2 = ((_RevisionControlled)versioned).getVersionInfo().getIdentifier().getValue();
        if (VERBOSE)
          System.out.println("rivisionIdentifier" + str2); 
        boolean bool = isLatestObj((WTObject)versioned);
        VersionIdentifier versionIdentifier = VersionIdentifier.newVersionIdentifier(multilevelSeries);
        if (bool) {
          State state = ((LifeCycleManaged)versioned).getLifeCycleState();
          if (!state.equals(State.toState(LC_STATE_4))) {
            System.out.println("VersionControlHelper.service.allVersionsOf(verObject.getMaster()).size() === " + VersionControlHelper.service.allVersionsOf(versioned.getMaster()).size());
            if (VersionControlHelper.service.allVersionsOf(versioned.getMaster()).size() > 1) {
              System.out.println("Not the first revision. Hence skipping...");
            } else {
              if (!Character.isDigit(RELEASE_VERSION.charAt(0))) {
                if (Character.isDigit(str2.charAt(0))) {
                  MultilevelSeries multilevelSeries1 = versioned.getVersionIdentifier().getSeries();
                  multilevelSeries1.setValueWithoutValidating(RELEASE_VERSION);
                  versionIdentifier = VersionIdentifier.newVersionIdentifier(multilevelSeries1);
                } 
              } else if (Character.isDigit(RELEASE_VERSION.charAt(0)) && !Character.isDigit(str2.charAt(0))) {
                MultilevelSeries multilevelSeries1 = versioned.getVersionIdentifier().getSeries();
                multilevelSeries1.setValueWithoutValidating(RELEASE_VERSION);
                versionIdentifier = VersionIdentifier.newVersionIdentifier(multilevelSeries1);
              } 
              IterationIdentifier iterationIdentifier = VersionControlHelper.firstIterationId((Iterated)versioned);
              System.out.println(" verObject ==" + versioned);
              System.out.println(" versionidentifier ==" + versionIdentifier.getValue());
              System.out.println(" iterationidentifier ==" + iterationIdentifier.getValue());
              Object[] arrayOfObject1 = new Object[2];
              arrayOfObject1[0] = versionIdentifier;
              arrayOfObject1[1] = iterationIdentifier;
              Object[] arrayOfObject2 = arrayOfObject1;
              wTKeyedHashMap.put((Persistable)versioned, arrayOfObject2);
            } 
          } 
        } 
      } 
      if (wTKeyedHashMap.size() > 0) {
        transaction = new Transaction();
        transaction.start();
        WTPrincipal wTPrincipal = SessionHelper.manager.getPrincipal();
        WTValuedMap wTValuedMap = VersionControlHelper.service.newVersions((WTKeyedMap)wTKeyedHashMap, true);
        wTCollection = PersistenceHelper.manager.store(wTValuedMap.wtValues());
        transaction.commit();
        transaction = null;
      } 
    } catch (WTException wTException) {
      wTException.printStackTrace();
      throw new WTException(wTException);
    } catch (Exception exception) {
      exception.printStackTrace();
      throw new WTException(exception);
    } 
    return wTCollection;
  }
  
  public static WTCollection reviseAll1(WTArrayList paramWTArrayList) throws WTException {
    Transaction transaction = null;
    WTCollection wTCollection = null;
    WTHashSet wTHashSet = new WTHashSet();
    wTHashSet.addAll((Collection)paramWTArrayList);
    try {
      transaction = new Transaction();
      transaction.start();
      WTPrincipal wTPrincipal = SessionHelper.manager.getPrincipal();
      WTValuedMap wTValuedMap = VersionControlHelper.service.newVersions((WTCollection)wTHashSet, true);
      wTCollection = PersistenceHelper.manager.store(wTValuedMap.wtValues());
      transaction.commit();
      transaction = null;
    } catch (WTException wTException) {
      throw new WTException(wTException);
    } 
    return wTCollection;
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\commo\\util\ReviseUtility.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */