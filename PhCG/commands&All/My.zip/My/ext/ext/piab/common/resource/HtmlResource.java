package ext.piab.common.resource;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("ext.piab.common.util.HtmlResource")
public final class HtmlResource extends WTListResourceBundle {
  @RBEntry("Package Contents are Modified.")
  public static final String PKG_SUBJECT = "0";
  
  @RBEntry("Package Contents revised by Change Notice.")
  public static final String CH_SUBJECT_1 = "1";
  
  @RBEntry("Change Items are Modified.")
  public static final String CH_SUBJECT_2 = "2";
  
  @RBEntry("Delivery Record contents Modified.")
  public static final String DR_SUBJECT_1 = "3";
  
  @RBEntry("Data Modified (State Change)")
  public static final String EVENT_1 = "4";
  
  @RBEntry("Older version of Data in target objects")
  public static final String EVENT_2 = "5";
  
  @RBEntry("Lifecycle State Change")
  public static final String EVENT = "6";
  
  @RBEntry("The following Data that exist within the corresponding Changes that you own, has been modified.\n Please take action if necessary.")
  public static final String PKG_MSG_1 = "7";
  
  @RBEntry("The following Data that exist within the corresponding Export Records has been modified.\n Please take action if necessary.")
  public static final String PKG_MSG_2 = "8";
  
  @RBEntry("The following Data that exist within the corresponding packages, has been revised.\n Please take action if necessary.")
  public static final String OLD_VERSION_MSG = "9";
  
  @RBEntry("The following Data that exist within the corresponding packages,has beeen modified.\n Please take action if necessary.")
  public static final String CH_MSG_2 = "10";
  
  @RBEntry("text/html")
  public static final String CONTENT_TYPE = "11";
  
  @RBEntry("#NAME")
  public static final String KEY_NAME = "12";
  
  @RBEntry("#STATE")
  public static final String KEY_STATE = "13";
  
  @RBEntry("#REVISION")
  public static final String KEY_REVISION = "14";
  
  @RBEntry("#EVENT")
  public static final String KEY_EVENT = "15";
  
  @RBEntry("#MESSAGE")
  public static final String KEY_MESSAGE = "16";
  
  @RBEntry("#STARTINPUT")
  public static final String KEY_END_BODY = "17";
  
  @RBEntry("#NOTIFYOBJECT")
  public static final String KEY_NOTIFYOBJECT = "18";
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\common\resource\HtmlResource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */