package ext.piab.common.loaders;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.rmi.RemoteException;
import wt.facade.ixb.IxbDocument;
import wt.facade.ixb.IxbElement;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.WTObject;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerRef;
import wt.inf.library.WTLibrary;
import wt.ixb.publicforapps.ApplicationImportHandler;
import wt.ixb.publicforapps.ApplicationImportHandlerTemplate;
import wt.ixb.publicforapps.Importer;
import wt.ixb.publicforapps.IxbHelper;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.pdmlink.PDMLinkProduct;
import wt.pds.StatementSpec;
import wt.pom.Transaction;
import wt.query.QueryException;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.query.WhereExpression;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;

public class ProblemReportImportHandler extends ApplicationImportHandlerTemplate implements RemoteAccess {
  public static void main(String[] paramArrayOfString) {
    if (paramArrayOfString.length != 2) {
      System.out.println("Invalid Arguments");
      System.out.println("Usage: java ext.piab.util.ProblemReportImportHandler <PRODUCT_NAME | LIBRARY_NAME> <XML_FILE_PATH>");
    } else if ((new File(paramArrayOfString[1])).exists()) {
      WTContainerRef wTContainerRef = null;
      WTObject wTObject = getContainer(paramArrayOfString[0]);
      if (wTObject instanceof WTContainer) {
        WTContainer wTContainer = (WTContainer)wTObject;
        try {
          wTContainerRef = WTContainerRef.newWTContainerRef(wTContainer);
        } catch (WTException wTException) {
          wTException.printStackTrace();
        } 
      } 
      if (wTContainerRef == null) {
        System.out.println("No Product or Library exist with Name " + paramArrayOfString[0]);
      } else {
        boolean bool = false;
        RemoteMethodServer remoteMethodServer = RemoteMethodServer.getDefault();
        try {
          System.out.println("Import Started...");
          Class[] arrayOfClass = { String.class, WTContainerRef.class };
          Object[] arrayOfObject = { paramArrayOfString[1], wTContainerRef };
          remoteMethodServer.setUserName("wcadmin");
          remoteMethodServer.setPassword("datafrond123");
          remoteMethodServer.invoke("importPR", "ext.piab.util.ProblemReportImportHandler", null, arrayOfClass, arrayOfObject);
          System.out.println("Import Successful...");
          bool = true;
        } catch (RemoteException remoteException) {
          remoteException.printStackTrace();
        } catch (Exception exception) {
          exception.printStackTrace();
        } 
        if (!bool)
          System.out.println("Import Failed..."); 
      } 
    } else {
      System.out.println("Please Enter a Valid file Path");
    } 
  }
  
  public static void importPR(String paramString, WTContainerRef paramWTContainerRef) throws WTException {
    ProblemReportImportHandler problemReportImportHandler = new ProblemReportImportHandler();
    problemReportImportHandler.doImport(paramString, paramWTContainerRef);
  }
  
  public void doImport(String paramString, WTContainerRef paramWTContainerRef) throws WTException {
    System.out.println("*****doImport");
    System.out.println("*****Container Referene name: " + paramWTContainerRef.getName());
    System.out.println("*****Container Referene: " + paramWTContainerRef.toString());
    IxbDocument ixbDocument = null;
    Transaction transaction = null;
    try {
      FileInputStream fileInputStream = new FileInputStream(paramString);
      ixbDocument = IxbHelper.newIxbDocument(fileInputStream, false);
      Importer importer = IxbHelper.newImporter((ApplicationImportHandler)this, paramWTContainerRef, "standardX10.dtd", (IxbElement)ixbDocument, null, null);
      transaction = new Transaction();
      transaction.start();
      importer.doImport((IxbElement)ixbDocument);
      importer.finalizeImport();
      transaction.commit();
      transaction = null;
    } catch (FileNotFoundException fileNotFoundException) {
      fileNotFoundException.printStackTrace();
    } finally {
      if (transaction != null)
        transaction.rollback(); 
      transaction = null;
    } 
  }
  
  public static WTObject getContainer(String paramString) {
    try {
      QuerySpec querySpec1 = new QuerySpec(PDMLinkProduct.class);
      SearchCondition searchCondition1 = new SearchCondition(PDMLinkProduct.class, "containerInfo.name", "=", paramString, false);
      querySpec1.appendWhere((WhereExpression)searchCondition1, new int[] { 0 });
      querySpec1.setDescendantQuery(false);
      QueryResult queryResult1 = PersistenceHelper.manager.find((StatementSpec)querySpec1);
      if (queryResult1.hasMoreElements())
        return (WTObject)queryResult1.nextElement(); 
      QuerySpec querySpec2 = new QuerySpec(WTLibrary.class);
      SearchCondition searchCondition2 = new SearchCondition(WTLibrary.class, "containerInfo.name", "=", paramString, false);
      querySpec2.appendWhere((WhereExpression)searchCondition2, new int[] { 0 });
      querySpec2.setDescendantQuery(false);
      QueryResult queryResult2 = PersistenceHelper.manager.find((StatementSpec)querySpec2);
      if (queryResult2.hasMoreElements())
        return (WTObject)queryResult2.nextElement(); 
    } catch (QueryException queryException) {
      queryException.printStackTrace();
    } catch (WTPropertyVetoException wTPropertyVetoException) {
      wTPropertyVetoException.printStackTrace();
    } catch (WTException wTException) {
      wTException.printStackTrace();
    } 
    return null;
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\common\loaders\ProblemReportImportHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */