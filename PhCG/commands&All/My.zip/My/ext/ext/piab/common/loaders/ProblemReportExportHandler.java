package ext.piab.common.loaders;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.util.HashSet;
import wt.change2.WTChangeIssue;
import wt.content.ApplicationData;
import wt.content.ContentItem;
import wt.content.Streamed;
import wt.facade.ixb.IxbDocument;
import wt.facade.ixb.IxbElement;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.WTObject;
import wt.inf.container.WTContainerRef;
import wt.ixb.clientAccess.IXBJarWriter;
import wt.ixb.clientAccess.IXBStreamer;
import wt.ixb.publicforapps.ApplicationExportHandler;
import wt.ixb.publicforapps.ApplicationExportHandlerTemplate;
import wt.ixb.publicforapps.Exporter;
import wt.ixb.publicforapps.IxbHelper;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.pds.StatementSpec;
import wt.pom.Transaction;
import wt.query.QueryException;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.query.WhereExpression;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.WTProperties;
import wt.util.WTPropertyVetoException;

public class ProblemReportExportHandler extends ApplicationExportHandlerTemplate implements RemoteAccess {
  private File targetDir = null;
  
  private PrintStream log = null;
  
  private IXBJarWriter jw = null;
  
  private IXBStreamer st = null;
  
  private File resJar = null;
  
  private int fileNum = 0;
  
  private HashSet contentFileNames = new HashSet();
  
  public static final String NAME_IS_TAG = "TAG";
  
  public static final String CONTENT_SUBDIR = "CONTENTS";
  
  public static final String dtd = "standardX10.dtd";
  
  private String fileName = null;
  
  public static String WT_HOME;
  
  public long timeInMiliSec;
  
  public String exportFileName;
  
  public ProblemReportExportHandler(File paramFile, PrintStream paramPrintStream) throws WTException {
    if (!paramFile.exists())
      paramFile.mkdirs(); 
    this.targetDir = paramFile;
    this.log = paramPrintStream;
  }
  
  public static void main(String[] paramArrayOfString) {
    WTChangeIssue wTChangeIssue = null;
    if (paramArrayOfString.length != 1) {
      System.out.println("Please Enter Valid Arguments");
      System.out.println("Usage: ext.piab.util.ProblemReportExportHandler <PROBLEM_REPORT_NUMBER>");
    } else {
      wTChangeIssue = getChangeIssue(paramArrayOfString[0]);
      if (wTChangeIssue == null) {
        System.out.println("Problem Report with number [" + paramArrayOfString[0] + "] does not exist");
      } else {
        System.out.println("Export Started.....");
        System.out.println("Found Problem Report......");
        boolean bool = false;
        RemoteMethodServer remoteMethodServer = RemoteMethodServer.getDefault();
        try {
          remoteMethodServer.setUserName("wcadmin");
          remoteMethodServer.setPassword("datafrond123");
          Class[] arrayOfClass = { WTObject.class };
          Object[] arrayOfObject = { wTChangeIssue };
          remoteMethodServer.invoke("export", "ext.piab.util.ProblemReportExportHandler", null, arrayOfClass, arrayOfObject);
          System.out.println("Export Successful.....");
          bool = true;
        } catch (RemoteException remoteException) {
          remoteException.printStackTrace();
        } catch (InvocationTargetException invocationTargetException) {
          invocationTargetException.printStackTrace();
        } 
        if (!bool)
          System.out.println("Export Failed..."); 
      } 
    } 
  }
  
  public static void export(WTObject paramWTObject) {
    WTChangeIssue wTChangeIssue = (WTChangeIssue)paramWTObject;
    String str = null;
    System.out.println("Change Issue Number: " + wTChangeIssue.getName());
    File file = new File(WT_HOME + "\\resultingJar.jar");
    try {
      ProblemReportExportHandler problemReportExportHandler = new ProblemReportExportHandler(new File(WT_HOME + "\\codebase\\capa\\exports"), new PrintStream(WT_HOME + "\\codebase\\capa\\exports\\export.log"));
      problemReportExportHandler.timeInMiliSec = System.currentTimeMillis();
      problemReportExportHandler.exportFileName = wTChangeIssue.getName() + "_" + wTChangeIssue.getNumber();
      problemReportExportHandler.doExport(wTChangeIssue.getContainerReference(), null, null, null, null, null, null, "Export_NoAction", "standardX10.dtd", str, file, (WTObject)wTChangeIssue);
    } catch (FileNotFoundException fileNotFoundException) {
      fileNotFoundException.printStackTrace();
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  public static WTChangeIssue getChangeIssue(String paramString) {
    try {
      QuerySpec querySpec = new QuerySpec(WTChangeIssue.class);
      SearchCondition searchCondition = new SearchCondition(WTChangeIssue.class, "master>number", "=", paramString, false);
      querySpec.appendWhere((WhereExpression)searchCondition, new int[] { 0 });
      querySpec.setDescendantQuery(false);
      QueryResult queryResult = PersistenceHelper.manager.find((StatementSpec)querySpec);
      if (queryResult.hasMoreElements())
        return (WTChangeIssue)queryResult.nextElement(); 
    } catch (QueryException queryException) {
      queryException.printStackTrace();
    } catch (WTPropertyVetoException wTPropertyVetoException) {
      wTPropertyVetoException.printStackTrace();
    } catch (WTException wTException) {
      wTException.printStackTrace();
    } 
    return null;
  }
  
  public String storeContent(Object paramObject) throws WTException {
    String str = null;
    if (paramObject instanceof ApplicationData) {
      ApplicationData applicationData = (ApplicationData)paramObject;
      String str1 = applicationData.getFileName();
      try {
        str = computeUniqueFileName(str1);
        Streamed streamed = (Streamed)applicationData.getStreamData().getObject();
        InputStream inputStream = streamed.retrieveStream();
        this.jw.addEntry(inputStream, str);
        this.st.addUserMsg(inputStream.toString());
      } catch (IOException iOException) {
        throw new WTException(iOException);
      } 
    } else {
      System.out.println("Content Class: " + paramObject.getClass().getName());
    } 
    return str;
  }
  
  public String storeDocument(IxbElement paramIxbElement, String paramString) throws WTException {
    try {
      String str = this.exportFileName + "_" + this.timeInMiliSec + ".xml";
      setFileName(str);
      File file = new File(this.targetDir, str);
      FileOutputStream fileOutputStream = new FileOutputStream(file);
      paramIxbElement.store(fileOutputStream, "standardX10.dtd");
      this.jw.addEntry(file);
      this.st.addUserMsg(fileOutputStream.toString());
      return fileOutputStream.toString();
    } catch (IOException iOException) {
      throw new WTException(iOException);
    } 
  }
  
  public void storeLogMessage(String paramString1, String paramString2, Object[] paramArrayOfObject) throws WTException {
    WTMessage wTMessage = new WTMessage(paramString1, paramString2, paramArrayOfObject);
    String str = wTMessage.getLocalizedMessage();
    this.log.println(str);
  }
  
  public void storeLogMessage(String paramString1, String paramString2, Object[] paramArrayOfObject, int paramInt) throws WTException {
    storeLogMessage(paramString1, paramString2, paramArrayOfObject);
  }
  
  public void exportObjectContent(Object paramObject, Exporter paramExporter, ContentItem paramContentItem, String paramString) throws WTException {
    if (paramContentItem instanceof ApplicationData) {
      ApplicationData applicationData = (ApplicationData)paramContentItem;
      Streamed streamed = (Streamed)applicationData.getStreamData().getObject();
      try {
        InputStream inputStream = streamed.retrieveStream();
        this.jw.addEntry(inputStream, paramString);
        this.st.addUserMsg(inputStream.toString());
      } catch (IOException iOException) {
        throw new WTException(iOException);
      } 
    } else {
      System.out.println("Content Class: " + paramContentItem.getClass().getName());
    } 
  }
  
  private String computeUniqueFileName(String paramString) throws IOException {
    if (this.contentFileNames.contains(paramString)) {
      int i = paramString.lastIndexOf('.');
      String str1 = (i > 0) ? paramString.substring(0, i) : paramString;
      String str2 = (i > 0) ? paramString.substring(i + 1) : "";
      do {
        paramString = (i > 0) ? (str1 + '-' + this.fileNum++ + '.' + str2) : (str1 + '-' + this.fileNum++);
      } while (this.contentFileNames.contains(paramString));
    } 
    this.contentFileNames.add(paramString);
    return "CONTENTS/" + paramString;
  }
  
  public File doExport(WTContainerRef paramWTContainerRef, String[] paramArrayOfString1, String[] paramArrayOfString2, String[] paramArrayOfString3, String[] paramArrayOfString4, File paramFile1, File paramFile2, String paramString1, String paramString2, String paramString3, File paramFile3, WTObject paramWTObject) throws WTException {
    this.resJar = paramFile3;
    try {
      this.jw = new IXBJarWriter(paramFile3);
      this.st = new IXBStreamer(paramFile3, paramString3);
    } catch (IOException iOException) {
      throw new WTException(iOException);
    } 
    IxbDocument ixbDocument = null;
    if (paramFile1 != null)
      try {
        FileInputStream fileInputStream = new FileInputStream(paramFile1);
        ixbDocument = IxbHelper.newIxbDocument(fileInputStream, false);
      } catch (IOException iOException) {
        throw new WTException(iOException);
      }  
    Exporter exporter = null;
    if (paramFile2 == null) {
      exporter = IxbHelper.newExporter((ApplicationExportHandler)this, paramWTContainerRef, "standardX10.dtd", (IxbElement)ixbDocument, null, paramString1);
    } else {
      exporter = IxbHelper.newExporter((ApplicationExportHandler)this, paramWTContainerRef, "standardX10.dtd", (IxbElement)ixbDocument, paramFile2, null);
    } 
    Transaction transaction = new Transaction();
    try {
      if (paramString1 == null || !paramString1.equals("Export_NoAction"))
        transaction.start(); 
      WTObject wTObject = paramWTObject;
      exporter.doExport(wTObject);
      exporter.finalizeExport();
      if (paramString1 == null || !paramString1.equals("Export_NoAction"))
        transaction.commit(); 
      transaction = null;
    } finally {
      if (transaction != null) {
        if (paramString1 == null || !paramString1.equals("Export_NoAction"))
          transaction.rollback(); 
        transaction = null;
      } 
    } 
    try {
      this.jw.finalizeJar();
    } catch (IOException iOException) {
      throw new WTException(iOException);
    } 
    return this.resJar;
  }
  
  public void setFileName(String paramString) {
    this.fileName = paramString;
  }
  
  public String getFileName() {
    return this.fileName;
  }
  
  static {
    try {
      WTProperties wTProperties = WTProperties.getLocalProperties();
      WT_HOME = wTProperties.getProperty("wt.home");
    } catch (IOException iOException) {
      iOException.printStackTrace();
    } 
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\common\loaders\ProblemReportExportHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */