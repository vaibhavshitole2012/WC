package ext.piab.common.util;

import java.io.File;
import java.io.StringWriter;
import java.nio.charset.Charset;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import wt.content.ApplicationData;
import wt.content.ContentHelper;
import wt.content.ContentHolder;
import wt.doc.WTDocument;
import wt.epm.EPMDocument;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.httpgw.URLFactory;
import wt.vc.VersionControlHelper;
import wt.vc.Versioned;

public class CreateXmlFile {
  private static final boolean VERBOSE = PropertyforPIAB.VERBOSE;
  //added by cts for depricated api
private static final Charset Charset = null;
  
  public static void dropWTDocXmlFile(WTDocument paramWTDocument, File paramFile, ApplicationData paramApplicationData) {
    try {
      paramWTDocument = (WTDocument)ContentHelper.service.getContents((ContentHolder)paramWTDocument);
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      if (VERBOSE)
        System.out.println("***Creating metadata file...!"); 
      Document document = documentBuilder.newDocument();
      Element element1 = document.createElement("WindchillDoc");
      document.appendChild(element1);
      Element element2 = document.createElement("Number");
      element2.appendChild(document.createTextNode(paramWTDocument.getNumber()));
      element1.appendChild(element2);
      Element element3 = document.createElement("Name");
      element3.appendChild(document.createTextNode(paramWTDocument.getName()));
      element1.appendChild(element3);
      Element element4 = document.createElement("FileName");
      element4.appendChild(document.createTextNode("" + paramApplicationData.getFileName()));
      element1.appendChild(element4);
      Element element5 = document.createElement("Description");
      element5.appendChild(document.createTextNode("" + paramApplicationData.getDescription()));
      element1.appendChild(element5);
      Element element6 = document.createElement("DocumentType");
      element6.appendChild(document.createTextNode("" + paramApplicationData.getFormatName()));
      element1.appendChild(element6);
      String str1 = VersionControlHelper.getVersionIdentifier((Versioned)paramWTDocument).getValue();
      Element element7 = document.createElement("Revision");
      element7.appendChild(document.createTextNode(str1));
      element1.appendChild(element7);
      Element element8 = document.createElement("ReleaseDate");
      element8.appendChild(document.createTextNode("" + paramApplicationData.getModifyTimestamp()));
      element1.appendChild(element8);
      Element element9 = document.createElement("Context");
      element9.appendChild(document.createTextNode(paramWTDocument.getContainerName()));
      element1.appendChild(element9);
      Element element10 = document.createElement("FolderLocation");
      element10.appendChild(document.createTextNode(paramWTDocument.getLocation()));
      element1.appendChild(element10);
      String str2 = FilenameUtils.getExtension(paramApplicationData.getFileName());
      Element element11 = document.createElement("FileType");
      element11.appendChild(document.createTextNode(str2));
      element1.appendChild(element11);
      String str3 = genDownloadHREF(paramApplicationData.getFileName(), paramApplicationData, (ContentHolder)paramWTDocument);
      Element element12 = document.createElement("WindchillURL");
      element12.appendChild(document.createTextNode("" + str3));
      element1.appendChild(element12);
      TransformerFactory transformerFactory = TransformerFactory.newInstance();
      Transformer transformer = transformerFactory.newTransformer();
      DOMSource dOMSource = new DOMSource(document);
      StringWriter stringWriter = new StringWriter();
      StreamResult streamResult = new StreamResult(stringWriter);
      transformer.transform(dOMSource, streamResult);
      String str4 = streamResult.getWriter().toString();
      stringWriter.write(str4);
      File file = new File(paramFile, paramWTDocument.getNumber() + ".xml");
      // FileUtils.writeStringToFile(file, str4,Charset);
      //added by cts for depricated api
      FileUtils.writeStringToFile(file, str4,Charset);
      stringWriter.flush();
      stringWriter.close();
      if (VERBOSE)
        System.out.println("***Metadata File dropped...!"); 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  public static void dropEPMDocXmlFile(EPMDocument paramEPMDocument, File paramFile, ApplicationData paramApplicationData) {
    try {
      paramEPMDocument = (EPMDocument)ContentHelper.service.getContents((ContentHolder)paramEPMDocument);
      DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
      DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
      if (VERBOSE)
        System.out.println("***Creating metadata file...!"); 
      Document document = documentBuilder.newDocument();
      Element element1 = document.createElement("WindchillDoc");
      document.appendChild(element1);
      Element element2 = document.createElement("Number");
      element2.appendChild(document.createTextNode(paramEPMDocument.getNumber()));
      element1.appendChild(element2);
      Element element3 = document.createElement("Name");
      element3.appendChild(document.createTextNode(paramEPMDocument.getName()));
      element1.appendChild(element3);
      Element element4 = document.createElement("FileName");
      element4.appendChild(document.createTextNode("" + paramApplicationData.getFileName()));
      element1.appendChild(element4);
      Element element5 = document.createElement("Description");
      element5.appendChild(document.createTextNode("" + paramApplicationData.getDescription()));
      element1.appendChild(element5);
      Element element6 = document.createElement("DocumentType");
      element6.appendChild(document.createTextNode("" + paramApplicationData.getFormatName()));
      element1.appendChild(element6);
      String str1 = VersionControlHelper.getVersionIdentifier((Versioned)paramEPMDocument).getValue();
      Element element7 = document.createElement("Revision");
      element7.appendChild(document.createTextNode(str1));
      element1.appendChild(element7);
      Element element8 = document.createElement("ReleaseDate");
      element8.appendChild(document.createTextNode("" + paramApplicationData.getModifyTimestamp()));
      element1.appendChild(element8);
      Element element9 = document.createElement("Context");
      element9.appendChild(document.createTextNode(paramEPMDocument.getContainerName()));
      element1.appendChild(element9);
      Element element10 = document.createElement("FolderLocation");
      element10.appendChild(document.createTextNode(paramEPMDocument.getLocation()));
      element1.appendChild(element10);
      String str2 = FilenameUtils.getExtension(paramApplicationData.getFileName());
      Element element11 = document.createElement("FileType");
      element11.appendChild(document.createTextNode(str2));
      element1.appendChild(element11);
      String str3 = genDownloadHREF(paramApplicationData.getFileName(), paramApplicationData, (ContentHolder)paramEPMDocument);
      Element element12 = document.createElement("WindchillURL");
      element12.appendChild(document.createTextNode("" + str3));
      element1.appendChild(element12);
      String str4 = FilenameUtils.removeExtension(paramEPMDocument.getNumber());
      TransformerFactory transformerFactory = TransformerFactory.newInstance();
      Transformer transformer = transformerFactory.newTransformer();
      DOMSource dOMSource = new DOMSource(document);
      StringWriter stringWriter = new StringWriter();
      StreamResult streamResult = new StreamResult(stringWriter);
      transformer.transform(dOMSource, streamResult);
      String str5 = streamResult.getWriter().toString();
      stringWriter.write(str5);
      File file = new File(paramFile, paramEPMDocument.getNumber() + ".xml");
   // FileUtils.writeStringToFile(file, str4,Charset);
      //added by cts for depricated api
      FileUtils.writeStringToFile(file, str5,Charset);
      stringWriter.flush();
      stringWriter.close();
      if (VERBOSE)
        System.out.println("***Metadata File dropped...!"); 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  public static String genDownloadHREF(String paramString, ApplicationData paramApplicationData, ContentHolder paramContentHolder) throws Exception {
    if (VERBOSE)
      System.out.println("*** PIABPDFUtility.genDownloadHREF\n*** Creating href string for " + paramContentHolder); 
    URLFactory uRLFactory = new URLFactory();
    return uRLFactory.getHREF("/servlet/AttachmentsDownloadDirectionServlet?oid=OR:" + PersistenceHelper.getObjectIdentifier((Persistable)paramContentHolder) + "&cioids=" + PersistenceHelper.getObjectIdentifier((Persistable)paramApplicationData));
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\commo\\util\CreateXmlFile.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */