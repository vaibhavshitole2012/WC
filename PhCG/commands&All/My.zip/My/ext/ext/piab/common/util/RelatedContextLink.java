package ext.piab.common.util;

import com.ptc.core.relcontext.server.ContextLink;
import com.ptc.core.relcontext.server.ContextRelation;
import com.ptc.windchill.wp.WorkPackage;
import ext.piab.common.resource.CommonResource;
import java.util.Locale;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.iba.definition.litedefinition.AttributeDefDefaultView;
import wt.iba.value.DefaultAttributeContainer;
import wt.iba.value.IBAHolder;
import wt.iba.value.IBAValueUtility;
import wt.iba.value.litevalue.AbstractValueView;
import wt.inf.container.WTContainer;
import wt.method.RemoteAccess;
import wt.projmgmt.admin.Project2;
import wt.projmgmt.admin.ProjectPhase;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.query.WhereExpression;
import wt.type.TypedUtility;
import wt.util.WTMessage;

public class RelatedContextLink implements RemoteAccess {
  private static final String PACKAGE_VENDORNUMBER = PropertyforPIAB.PACKAGE_VENDORNUMBER;
  
  private static final String PACKAGE_PROJECTNUMBER = PropertyforPIAB.PACKAGE_PROJECTNUMBER;
  
  private static final String SUPPLIER_PACKAGE_TYPE_NAME = PropertyforPIAB.SUPPLIER_PACKAGE_TYPE_NAME;
  
  private static final String DESIGN_PACKAGE_TYPE_NAME = PropertyforPIAB.DESIGN_PACKAGE_TYPE_NAME;
  
  private static final boolean VERBOSE = PropertyforPIAB.VERBOSE;
  
  private static final boolean PROJ_PHASE_CHANGE = PropertyforPIAB.PROJ_PHASE_CHANGE;
  
  private static final String COMMON_RESOURCE = CommonResource.class.getName();
  
  private static String DESC = WTMessage.getLocalizedMessage(COMMON_RESOURCE, "5");
  
  private static String RELATION = WTMessage.getLocalizedMessage(COMMON_RESOURCE, "6");
  
  public static void updateProjectPhase(String paramString1, String paramString2) throws Exception {
    if (VERBOSE)
      System.out.println("*** RelatedContextLink.updateProjectPhase(" + paramString1 + "," + paramString2 + ")"); 
    try {
      if (PROJ_PHASE_CHANGE) {
        QuerySpec querySpec = new QuerySpec(Project2.class);
        querySpec.appendWhere((WhereExpression)new SearchCondition(Project2.class, "projectNumber", "=", paramString1));
        QueryResult queryResult = PersistenceHelper.manager.find(querySpec);
        if (VERBOSE)
          System.out.println("***Query result size-" + queryResult.size()); 
        if (queryResult.size() > 0) {
          Project2 project2 = (Project2)queryResult.nextElement();
          ProjectPhase projectPhase = ProjectPhase.toProjectPhase(paramString2);
          project2.setPhase(projectPhase);
          PersistenceHelper.manager.save((Persistable)project2);
          if (VERBOSE)
            System.out.println("*** Project phase updated"); 
        } 
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  public static void updateIBA(Persistable paramPersistable, String paramString) throws Exception {
    if (VERBOSE)
      System.out.println("*** RelatedContextLink.updateIBA() "); 
    try {
      String str1 = null;
      if (TypedUtility.getTypeIdentifier(paramPersistable).toString().endsWith(DESIGN_PACKAGE_TYPE_NAME))
        str1 = PACKAGE_PROJECTNUMBER; 
      if (TypedUtility.getTypeIdentifier(paramPersistable).toString().endsWith(SUPPLIER_PACKAGE_TYPE_NAME))
        str1 = PACKAGE_VENDORNUMBER; 
      String str2 = getProjNumber(paramPersistable);
      System.out.println("Value of Attribute Project number entered initially is" + str2);
      if (str2 != paramString) {
        IBAUtil iBAUtil = new IBAUtil((IBAHolder)paramPersistable);
        iBAUtil.setIBAValue(str1, paramString, null);
        WorkPackage workPackage = (WorkPackage)iBAUtil.updateIBAPart((IBAHolder)paramPersistable);
        workPackage = (WorkPackage)PersistenceHelper.manager.save((Persistable)workPackage);
        System.out.println("Value of Attribute Project number is Updated to " + paramString);
      } else if (VERBOSE) {
        System.out.println("Value of Attribute Project number is Correct.");
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  public static Project2 getProject(String paramString) throws Exception {
    if (VERBOSE)
      System.out.println("*** RelatedContextLink.getProject(" + paramString + ")"); 
    Project2 project2 = null;
    try {
      if (paramString != null) {
        QuerySpec querySpec = new QuerySpec(Project2.class);
        querySpec.appendWhere((WhereExpression)new SearchCondition(Project2.class, "projectNumber", "=", paramString));
        QueryResult queryResult = PersistenceHelper.manager.find(querySpec);
        if (VERBOSE)
          System.out.println("projResult is-" + queryResult.size()); 
        if (queryResult.size() > 0) {
          project2 = (Project2)queryResult.nextElement();
          if (VERBOSE)
            System.out.println("Inside query result ProjectName is-" + project2.getName()); 
        } 
      } 
      if (VERBOSE)
        System.out.println("***Project is: [" + project2 + "]"); 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return project2;
  }
  
  public static String getProjNumber(Persistable paramPersistable) throws Exception {
    if (VERBOSE)
      System.out.println("*** RelatedContextLink.getProjNumber()"); 
    String str = null;
    try {
      WorkPackage workPackage = null;
      if (paramPersistable instanceof WorkPackage)
        workPackage = (WorkPackage)paramPersistable; 
      DefaultAttributeContainer defaultAttributeContainer = (DefaultAttributeContainer)workPackage.getAttributeContainer();
      if (VERBOSE)
        System.out.println("***DefaultAttributeContainer- " + defaultAttributeContainer); 
      if (defaultAttributeContainer != null) {
        AbstractValueView[] arrayOfAbstractValueView = defaultAttributeContainer.getAttributeValues();
        if (VERBOSE)
          System.out.println("***DefaultAttributeContainer avv[]length- " + arrayOfAbstractValueView.length); 
        AttributeDefDefaultView attributeDefDefaultView = null;
        for (byte b = 0; b < arrayOfAbstractValueView.length; b++) {
          attributeDefDefaultView = arrayOfAbstractValueView[b].getDefinition();
          String str1 = attributeDefDefaultView.getName();
          if (VERBOSE)
            System.out.println("***AttributeDefDefaultView.getName()-" + str1); 
          if (TypedUtility.getTypeIdentifier(workPackage).toString().endsWith(DESIGN_PACKAGE_TYPE_NAME)) {
            if (str1.equalsIgnoreCase(PACKAGE_PROJECTNUMBER)) {
              str = IBAValueUtility.getLocalizedIBAValueDisplayString(arrayOfAbstractValueView[b], Locale.getDefault());
              if (VERBOSE)
                System.out.println("***PROJECTNumber is-" + str); 
            } 
          } else if (TypedUtility.getTypeIdentifier(workPackage).toString().endsWith(SUPPLIER_PACKAGE_TYPE_NAME) && str1.equalsIgnoreCase(PACKAGE_VENDORNUMBER)) {
            str = IBAValueUtility.getLocalizedIBAValueDisplayString(arrayOfAbstractValueView[b], Locale.getDefault());
            if (VERBOSE)
              System.out.println("*** VENDOR Number is-" + str); 
          } 
        } 
      } else {
        IBAUtil iBAUtil = new IBAUtil((IBAHolder)workPackage);
        if (TypedUtility.getTypeIdentifier(workPackage).toString().endsWith(DESIGN_PACKAGE_TYPE_NAME)) {
          str = iBAUtil.getIBAValue((IBAHolder)workPackage, PACKAGE_PROJECTNUMBER);
        } else if (TypedUtility.getTypeIdentifier(workPackage).toString().endsWith(SUPPLIER_PACKAGE_TYPE_NAME)) {
          str = iBAUtil.getIBAValue((IBAHolder)workPackage, PACKAGE_VENDORNUMBER);
        } 
        if (VERBOSE)
          System.out.println("***Project Number is-" + str); 
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return str;
  }
  
  public static void createContextLink(Persistable paramPersistable, Project2 paramProject2) throws Exception {
    if (VERBOSE)
      System.out.println("*** RelatedContextLink.createContextLink(" + paramProject2.getName() + ")"); 
    try {
      boolean bool = isDuplicateContext(paramPersistable, paramProject2);
      if (!bool)
        createLink(paramPersistable, paramProject2); 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  private static void createLink(Persistable paramPersistable, Project2 paramProject2) throws Exception {
    if (VERBOSE)
      System.out.println("*** RelatedContextLink.createLink()"); 
    ContextLink contextLink = new ContextLink();
    WorkPackage workPackage = null;
    if (paramPersistable instanceof WorkPackage) {
      workPackage = (WorkPackage)paramPersistable;
      contextLink.setObject((Persistable)workPackage.getMaster());
    } 
    contextLink.setContext((WTContainer)paramProject2);
    contextLink.setRelation(ContextRelation.toContextRelation(RELATION));
    contextLink.setDescription(DESC);
    contextLink = (ContextLink)PersistenceHelper.manager.store((Persistable)contextLink);
    if (VERBOSE)
      System.out.println("***Context Link created[" + contextLink + "]"); 
  }
  
  private static boolean isDuplicateContext(Persistable paramPersistable, Project2 paramProject2) throws Exception {
    if (VERBOSE)
      System.out.println("RelatedContextLink.isDuplicateContext"); 
    boolean bool = false;
    QueryResult queryResult = null;
    if (paramPersistable instanceof WorkPackage) {
      WorkPackage workPackage = (WorkPackage)paramPersistable;
      queryResult = PersistenceHelper.manager.navigate((Persistable)workPackage.getMaster(), "roleAObject", ContextLink.class, true);
    } 
    if (VERBOSE)
      System.out.println("Size for RoleA" + queryResult.size()); 
    while (queryResult.hasMoreElements()) {
      Project2 project2 = (Project2)queryResult.nextElement();
      if (VERBOSE)
        System.out.println("Role A" + project2.getName()); 
      if (paramProject2.equals(project2)) {
        bool = true;
        break;
      } 
    } 
    return bool;
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\commo\\util\RelatedContextLink.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */