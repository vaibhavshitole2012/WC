package ext.piab.common.util;

import java.rmi.RemoteException;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Locale;
import java.util.Vector;
import wt.csm.navigation.litenavigation.ClassificationStructDefaultView;
import wt.csm.navigation.service.ClassificationHelper;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.iba.constraint.AttributeConstraint;
import wt.iba.constraint.ConstraintGroup;
import wt.iba.definition.AbstractAttributeDefinition;
import wt.iba.definition.DefinitionLoader;
import wt.iba.definition.StringDefinition;
import wt.iba.definition.litedefinition.AbstractAttributeDefinizerView;
import wt.iba.definition.litedefinition.AttributeDefDefaultView;
import wt.iba.definition.litedefinition.AttributeDefNodeView;
import wt.iba.definition.litedefinition.ReferenceDefView;
import wt.iba.definition.litedefinition.UnitDefView;
import wt.iba.definition.service.IBADefinitionHelper;
import wt.iba.value.AttributeContainer;
import wt.iba.value.DefaultAttributeContainer;
import wt.iba.value.IBAHolder;
import wt.iba.value.IBAValueUtility;
import wt.iba.value.StringValue;
import wt.iba.value.litevalue.AbstractValueView;
import wt.iba.value.service.IBAValueDBService;
import wt.iba.value.service.IBAValueHelper;
import wt.iba.value.service.LoadValue;
import wt.query.QueryException;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.query.WhereExpression;
import wt.session.SessionHelper;
import wt.units.service.QuantityOfMeasureDefaultView;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;

public class IBAUtil {
  Hashtable ibaContainer;
  
  Hashtable ibaStringContainer;
  
  final String UNITS = "SI";
  
  private static final boolean VERBOSE = PropertyforPIAB.VERBOSE;
  
  public IBAUtil() {
    this.ibaContainer = new Hashtable<>();
  }
  
  public IBAUtil(IBAHolder paramIBAHolder) throws WTException, RemoteException {
    initializeIBAPart(paramIBAHolder);
    initializeIBAPartStringValue(paramIBAHolder);
  }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    Enumeration<String> enumeration = this.ibaContainer.keys();
    try {
      while (enumeration.hasMoreElements()) {
        String str = enumeration.nextElement();
        AbstractValueView abstractValueView = (AbstractValueView)((Object[])this.ibaContainer.get(str))[1];
        stringBuffer.append(str + " - " + IBAValueUtility.getLocalizedIBAValueDisplayString(abstractValueView, SessionHelper.manager.getLocale()));
        stringBuffer.append('\n');
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return stringBuffer.toString();
  }
  
  public String getIBAValue(String paramString) {
    try {
      return getIBAValue(paramString, SessionHelper.manager.getLocale());
    } catch (Exception exception) {
      exception.printStackTrace();
      return null;
    } 
  }
  
  public String getIBAValue(String paramString, Locale paramLocale) {
    try {
      if (this.ibaContainer.get(paramString) == null)
        return null; 
      AbstractValueView abstractValueView = (AbstractValueView)((Object[])this.ibaContainer.get(paramString))[1];
      return IBAValueUtility.getLocalizedIBAValueDisplayString(abstractValueView, paramLocale);
    } catch (WTException wTException) {
      wTException.printStackTrace();
      return null;
    } 
  }
  
  public String getIBAStringValue(String paramString) {
    try {
      return (this.ibaStringContainer.get(paramString) == null) ? null : (String)this.ibaStringContainer.get(paramString);
    } catch (Exception exception) {
      exception.printStackTrace();
      return null;
    } 
  }
  
  private void initializeIBAPart(IBAHolder paramIBAHolder) throws WTException, RemoteException {
    this.ibaContainer = new Hashtable<>();
    paramIBAHolder = IBAValueHelper.service.refreshAttributeContainer(paramIBAHolder, null, SessionHelper.manager.getLocale(), null);
    DefaultAttributeContainer defaultAttributeContainer = (DefaultAttributeContainer)paramIBAHolder.getAttributeContainer();
    if (defaultAttributeContainer != null) {
      AttributeDefDefaultView[] arrayOfAttributeDefDefaultView = defaultAttributeContainer.getAttributeDefinitions();
      for (byte b = 0; b < arrayOfAttributeDefDefaultView.length; b++) {
        AbstractValueView[] arrayOfAbstractValueView = defaultAttributeContainer.getAttributeValues(arrayOfAttributeDefDefaultView[b]);
        if (arrayOfAbstractValueView != null) {
          Object[] arrayOfObject = new Object[arrayOfAbstractValueView.length + 1];
          arrayOfObject[0] = arrayOfAttributeDefDefaultView[b];
          for (byte b1 = 1; b1 <= arrayOfAbstractValueView.length; b1++)
            arrayOfObject[b1] = arrayOfAbstractValueView[b1 - 1]; 
          this.ibaContainer.put(arrayOfAttributeDefDefaultView[b].getName(), arrayOfObject);
        } 
      } 
    } 
  }
  
  public Enumeration getAttributeDefinitions() {
    return this.ibaContainer.keys();
  }
  
  public String getIBAValue(IBAHolder paramIBAHolder, String paramString) {
    String str = null;
    try {
      paramIBAHolder = IBAValueHelper.service.refreshAttributeContainer(paramIBAHolder, null, SessionHelper.manager.getLocale(), null);
      DefaultAttributeContainer defaultAttributeContainer = (DefaultAttributeContainer)paramIBAHolder.getAttributeContainer();
      if (defaultAttributeContainer != null) {
        AttributeDefDefaultView[] arrayOfAttributeDefDefaultView = defaultAttributeContainer.getAttributeDefinitions();
        for (byte b = 0; b < arrayOfAttributeDefDefaultView.length; b++) {
          if (arrayOfAttributeDefDefaultView[b].getName().equals(paramString)) {
            AbstractValueView[] arrayOfAbstractValueView = defaultAttributeContainer.getAttributeValues(arrayOfAttributeDefDefaultView[b]);
            if (arrayOfAbstractValueView != null)
              for (byte b1 = 0; b1 < arrayOfAbstractValueView.length; b1++) {
                if (str == null) {
                  str = IBAValueUtility.getLocalizedIBAValueDisplayString(arrayOfAbstractValueView[b1], SessionHelper.manager.getLocale());
                } else {
                  str = str + "," + IBAValueUtility.getLocalizedIBAValueDisplayString(arrayOfAbstractValueView[b1], SessionHelper.manager.getLocale());
                } 
              }  
          } 
        } 
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return str;
  }
  
  private void initializeIBAPartStringValue(IBAHolder paramIBAHolder) throws WTException, RemoteException {
    this.ibaStringContainer = new Hashtable<>();
    Object[] arrayOfObject = new Object[2];
    paramIBAHolder = IBAValueHelper.service.refreshAttributeContainer(paramIBAHolder, null, SessionHelper.manager.getLocale(), null);
    DefaultAttributeContainer defaultAttributeContainer = (DefaultAttributeContainer)paramIBAHolder.getAttributeContainer();
    if (defaultAttributeContainer != null) {
      AttributeDefDefaultView[] arrayOfAttributeDefDefaultView = defaultAttributeContainer.getAttributeDefinitions();
      for (byte b = 0; b < arrayOfAttributeDefDefaultView.length; b++) {
        AbstractValueView[] arrayOfAbstractValueView = defaultAttributeContainer.getAttributeValues(arrayOfAttributeDefDefaultView[b]);
        if (arrayOfAbstractValueView != null) {
          arrayOfObject[0] = arrayOfAttributeDefDefaultView[b];
          arrayOfObject[1] = IBAValueUtility.getLocalizedIBAValueDisplayString(arrayOfAbstractValueView[0], SessionHelper.manager.getLocale());
          for (byte b1 = 1; b1 < arrayOfAbstractValueView.length; b1++)
            arrayOfObject[1] = arrayOfObject[1] + "," + IBAValueUtility.getLocalizedIBAValueDisplayString(arrayOfAbstractValueView[b1], SessionHelper.manager.getLocale()); 
        } 
        System.out.println("Putting : " + arrayOfAttributeDefDefaultView[b].getName() + " into : " + arrayOfObject[1]);
        this.ibaStringContainer.put(arrayOfAttributeDefDefaultView[b].getName(), arrayOfObject[1]);
      } 
    } 
  }
  
  public DefaultAttributeContainer suppressCSMConstraint(DefaultAttributeContainer paramDefaultAttributeContainer) {
    String str = "wt.part.WTPart";
    ClassificationStructDefaultView classificationStructDefaultView = null;
    try {
      classificationStructDefaultView = ClassificationHelper.service.getClassificationStructDefaultView(str);
    } catch (Exception exception) {}
    if (classificationStructDefaultView != null) {
      ReferenceDefView referenceDefView = classificationStructDefaultView.getReferenceDefView();
      Vector<ConstraintGroup> vector1 = paramDefaultAttributeContainer.getConstraintGroups();
      Vector<ConstraintGroup> vector2 = new Vector();
      try {
        for (byte b = 0; b < vector1.size(); b++) {
          ConstraintGroup constraintGroup = vector1.elementAt(b);
          if (constraintGroup != null)
            if (!constraintGroup.getConstraintGroupLabel().equals("Sourcing Factor")) {
              vector2.addElement(constraintGroup);
            } else {
              Enumeration<AttributeConstraint> enumeration = constraintGroup.getConstraints();
              ConstraintGroup constraintGroup1 = new ConstraintGroup();
              constraintGroup1.setConstraintGroupLabel(constraintGroup.getConstraintGroupLabel());
              while (enumeration.hasMoreElements()) {
                AttributeConstraint attributeConstraint = enumeration.nextElement();
                if (attributeConstraint.appliesToAttrDef((AttributeDefDefaultView)referenceDefView) && attributeConstraint.getValueConstraint() instanceof wt.iba.constraint.Immutable)
                  continue; 
                constraintGroup1.addConstraint(attributeConstraint);
              } 
              vector2.addElement(constraintGroup1);
            }  
        } 
        paramDefaultAttributeContainer.setConstraintGroups(vector2);
      } catch (WTPropertyVetoException wTPropertyVetoException) {
        wTPropertyVetoException.printStackTrace();
      } 
    } 
    return paramDefaultAttributeContainer;
  }
  
  public DefaultAttributeContainer removeCSMConstraint(DefaultAttributeContainer paramDefaultAttributeContainer) {
    Object<Object> object = (Object<Object>)paramDefaultAttributeContainer.getConstraintParameter();
    if (object == null) {
      object = (Object<Object>)new String("CSM");
    } else if (object instanceof Vector) {
      ((Vector<String>)object).addElement(new String("CSM"));
    } else {
      Vector<Object> vector = new Vector();
      vector.addElement(object);
      object = (Object<Object>)vector;
      ((Vector)object).addElement(new String("CSM"));
    } 
    try {
      paramDefaultAttributeContainer.setConstraintParameter(object);
    } catch (WTPropertyVetoException wTPropertyVetoException) {
      wTPropertyVetoException.printStackTrace();
    } 
    return paramDefaultAttributeContainer;
  }
  
  public IBAHolder updatePartAttributeContainer(IBAHolder paramIBAHolder) throws WTException, WTPropertyVetoException, RemoteException {
    paramIBAHolder = IBAValueHelper.service.refreshAttributeContainer(paramIBAHolder, null, SessionHelper.manager.getLocale(), null);
    DefaultAttributeContainer defaultAttributeContainer = (DefaultAttributeContainer)paramIBAHolder.getAttributeContainer();
    defaultAttributeContainer = suppressCSMConstraint(defaultAttributeContainer);
    Enumeration<Object[]> enumeration = this.ibaContainer.elements();
    while (enumeration.hasMoreElements()) {
      Object[] arrayOfObject = enumeration.nextElement();
      AttributeDefDefaultView attributeDefDefaultView = (AttributeDefDefaultView)arrayOfObject[0];
      for (byte b = 1; b < arrayOfObject.length; b++) {
        AbstractValueView abstractValueView = (AbstractValueView)arrayOfObject[b];
        if (abstractValueView.getState() == 1) {
          defaultAttributeContainer.deleteAttributeValues(attributeDefDefaultView);
          abstractValueView.setState(3);
          defaultAttributeContainer.addAttributeValue(abstractValueView);
        } else if (abstractValueView.getState() == 3) {
          defaultAttributeContainer.addAttributeValue(abstractValueView);
        } else if (abstractValueView.getState() == 2) {
          defaultAttributeContainer.deleteAttributeValue(abstractValueView);
        } 
      } 
    } 
    defaultAttributeContainer = removeCSMConstraint(defaultAttributeContainer);
    paramIBAHolder.setAttributeContainer((AttributeContainer)defaultAttributeContainer);
    return paramIBAHolder;
  }
  
  public IBAHolder updateIBAPart(IBAHolder paramIBAHolder) throws WTException, WTPropertyVetoException, RemoteException {
    return updatePartAttributeContainer(paramIBAHolder);
  }
  
  public static boolean updateIBAHolder(IBAHolder paramIBAHolder) {
    IBAValueDBService iBAValueDBService = new IBAValueDBService();
    boolean bool = true;
    try {
      PersistenceServerHelper.manager.update((Persistable)paramIBAHolder);
      AttributeContainer attributeContainer1 = paramIBAHolder.getAttributeContainer();
      Object object = ((DefaultAttributeContainer)attributeContainer1).getConstraintParameter();
      AttributeContainer attributeContainer2 = iBAValueDBService.updateAttributeContainer(paramIBAHolder, object, null, null);
      paramIBAHolder.setAttributeContainer(attributeContainer2);
    } catch (WTException wTException) {
      System.out.println("updateIBAHOlder: Couldn't update. " + wTException);
      bool = false;
    } 
    return bool;
  }
  
  public void setIBAValue(String paramString1, String paramString2, String paramString3) throws WTPropertyVetoException {
    if (paramString2 == null || paramString2.trim().equals("null") || paramString2.trim().equals(""))
      return; 
    AbstractValueView abstractValueView = null;
    AttributeDefDefaultView attributeDefDefaultView = null;
    Object[] arrayOfObject1 = (Object[])this.ibaContainer.get(paramString1);
    if (arrayOfObject1 != null) {
      abstractValueView = (AbstractValueView)arrayOfObject1[1];
      attributeDefDefaultView = (AttributeDefDefaultView)arrayOfObject1[0];
    } 
    if (abstractValueView == null)
      attributeDefDefaultView = getAttributeDefinition(paramString1); 
    if (attributeDefDefaultView == null)
      return; 
    if (attributeDefDefaultView instanceof UnitDefView)
      paramString2 = paramString2 + " " + getDisplayUnits((UnitDefView)attributeDefDefaultView, "SI"); 
    abstractValueView = internalCreateValue((AbstractAttributeDefinizerView)attributeDefDefaultView, paramString2, paramString3);
    if (abstractValueView == null)
      return; 
    abstractValueView.setState(1);
    Object[] arrayOfObject2 = new Object[2];
    arrayOfObject2[0] = attributeDefDefaultView;
    arrayOfObject2[1] = abstractValueView;
    this.ibaContainer.put(attributeDefDefaultView.getName(), arrayOfObject2);
  }
  
  public void setIBAValueSet(String paramString, Vector<Object[]> paramVector) throws WTPropertyVetoException, Exception {
    AbstractValueView abstractValueView = null;
    AttributeDefDefaultView attributeDefDefaultView = null;
    Object[] arrayOfObject1 = (Object[])this.ibaContainer.get(paramString);
    if (arrayOfObject1 != null) {
      abstractValueView = (AbstractValueView)arrayOfObject1[1];
      attributeDefDefaultView = (AttributeDefDefaultView)arrayOfObject1[0];
    } 
    if (abstractValueView == null)
      attributeDefDefaultView = getAttributeDefinition(paramString); 
    if (attributeDefDefaultView == null)
      return; 
    Object[] arrayOfObject2 = (Object[])this.ibaContainer.get(attributeDefDefaultView.getName());
    Object[] arrayOfObject3 = new Object[paramVector.size() + 1];
    arrayOfObject3[0] = attributeDefDefaultView;
    for (byte b = 1; b <= paramVector.size(); b++) {
      Object[] arrayOfObject = paramVector.elementAt(b - 1);
      if (attributeDefDefaultView instanceof UnitDefView)
        arrayOfObject[0] = arrayOfObject[0] + " " + getDisplayUnits((UnitDefView)attributeDefDefaultView, "SI"); 
      AbstractValueView abstractValueView1 = internalCreateValue((AbstractAttributeDefinizerView)attributeDefDefaultView, (String)arrayOfObject[0], null);
      for (byte b1 = 1; b1 < arrayOfObject2.length; b1++) {
        if (((AbstractValueView)arrayOfObject2[b1]).compareTo(abstractValueView1) == 0)
          abstractValueView1 = (AbstractValueView)arrayOfObject2[b1]; 
      } 
      if (abstractValueView1 == null)
        return; 
      abstractValueView1.setState(((Integer)arrayOfObject[1]).intValue());
      arrayOfObject3[b] = abstractValueView1;
    } 
    this.ibaContainer.put(attributeDefDefaultView.getName(), arrayOfObject3);
  }
  
  private static String getDisplayUnits(UnitDefView paramUnitDefView, String paramString) {
    QuantityOfMeasureDefaultView quantityOfMeasureDefaultView = paramUnitDefView.getQuantityOfMeasureDefaultView();
    String str = quantityOfMeasureDefaultView.getBaseUnit();
    if (paramString != null) {
      String str1 = paramUnitDefView.getDisplayUnitString(paramString);
      if (str1 == null)
        str1 = quantityOfMeasureDefaultView.getDisplayUnitString(paramString); 
      if (str1 == null)
        str1 = quantityOfMeasureDefaultView.getDefaultDisplayUnitString(paramString); 
      if (str1 != null)
        str = str1; 
    } 
    return (str == null) ? "" : str;
  }
  
  public AttributeDefDefaultView getAttributeDefinition(String paramString) {
    AttributeDefDefaultView attributeDefDefaultView = null;
    try {
      attributeDefDefaultView = IBADefinitionHelper.service.getAttributeDefDefaultViewByPath(paramString);
      if (attributeDefDefaultView == null) {
        AbstractAttributeDefinizerView abstractAttributeDefinizerView = DefinitionLoader.getAttributeDefinition(paramString);
        if (abstractAttributeDefinizerView != null)
          attributeDefDefaultView = IBADefinitionHelper.service.getAttributeDefDefaultView((AttributeDefNodeView)abstractAttributeDefinizerView); 
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return attributeDefDefaultView;
  }
  
  public AbstractValueView internalCreateValue(AbstractAttributeDefinizerView paramAbstractAttributeDefinizerView, String paramString1, String paramString2) {
    AbstractValueView abstractValueView = null;
    if (paramAbstractAttributeDefinizerView instanceof wt.iba.definition.litedefinition.FloatDefView) {
      abstractValueView = LoadValue.newFloatValue(paramAbstractAttributeDefinizerView, paramString1, null);
    } else if (paramAbstractAttributeDefinizerView instanceof wt.iba.definition.litedefinition.StringDefView) {
      abstractValueView = LoadValue.newStringValue(paramAbstractAttributeDefinizerView, paramString1);
    } else if (paramAbstractAttributeDefinizerView instanceof wt.iba.definition.litedefinition.IntegerDefView) {
      abstractValueView = LoadValue.newIntegerValue(paramAbstractAttributeDefinizerView, paramString1);
    } else if (paramAbstractAttributeDefinizerView instanceof wt.iba.definition.litedefinition.RatioDefView) {
      abstractValueView = LoadValue.newRatioValue(paramAbstractAttributeDefinizerView, paramString1, null);
    } else if (paramAbstractAttributeDefinizerView instanceof wt.iba.definition.litedefinition.TimestampDefView) {
      abstractValueView = LoadValue.newTimestampValue(paramAbstractAttributeDefinizerView, paramString1);
    } else if (paramAbstractAttributeDefinizerView instanceof wt.iba.definition.litedefinition.BooleanDefView) {
      abstractValueView = LoadValue.newBooleanValue(paramAbstractAttributeDefinizerView, paramString1);
    } else if (paramAbstractAttributeDefinizerView instanceof wt.iba.definition.litedefinition.URLDefView) {
      abstractValueView = LoadValue.newURLValue(paramAbstractAttributeDefinizerView, paramString1, paramString2);
    } else if (paramAbstractAttributeDefinizerView instanceof ReferenceDefView) {
      abstractValueView = LoadValue.newReferenceValue(paramAbstractAttributeDefinizerView, "ClassificationNode", paramString1);
    } else if (paramAbstractAttributeDefinizerView instanceof UnitDefView) {
      abstractValueView = LoadValue.newUnitValue(paramAbstractAttributeDefinizerView, paramString1, null);
    } 
    return abstractValueView;
  }
  
  public static String getIBAHierarchyID(String paramString) {
    String str = null;
    try {
      QuerySpec querySpec = new QuerySpec(AbstractAttributeDefinition.class);
      querySpec.appendSearchCondition(new SearchCondition(AbstractAttributeDefinition.class, "name", "=", paramString));
      QueryResult queryResult = PersistenceHelper.manager.find(querySpec);
      if (queryResult != null && queryResult.size() != 0) {
        AbstractAttributeDefinition abstractAttributeDefinition = (AbstractAttributeDefinition)queryResult.nextElement();
        str = abstractAttributeDefinition.getHierarchyID();
      } 
    } catch (QueryException queryException) {
      queryException.printStackTrace();
    } catch (WTException wTException) {
      wTException.printStackTrace();
    } 
    return str;
  }
  
  public static String getIBAName(String paramString) {
    String str = null;
    try {
      QuerySpec querySpec = new QuerySpec(AbstractAttributeDefinition.class);
      querySpec.appendSearchCondition(new SearchCondition(AbstractAttributeDefinition.class, "hierarchyID", "=", paramString));
      QueryResult queryResult = PersistenceHelper.manager.find(querySpec);
      if (queryResult != null && queryResult.size() != 0) {
        AbstractAttributeDefinition abstractAttributeDefinition = (AbstractAttributeDefinition)queryResult.nextElement();
        str = abstractAttributeDefinition.getName();
      } 
    } catch (QueryException queryException) {
      queryException.printStackTrace();
    } catch (WTException wTException) {
      wTException.printStackTrace();
    } 
    return str;
  }
  
public static void updateIBAStringValue(IBAHolder paramIBAHolder, String paramString1, String paramString2) throws Exception {
    if (VERBOSE)
      System.out.println("*** IBAUtil.updateIBAStringValue - Setting " + paramString1 + " == " + paramString2); 
    StringDefinition stringDefinition = null;
    QuerySpec querySpec = new QuerySpec(StringDefinition.class);
    querySpec.appendWhere((WhereExpression)new SearchCondition(StringDefinition.class, "name", "=", paramString1, false));
    //   querySpec.appendWhere(new SearchCondition(StringDefinition.class, "name", "=", paramString1,false));
    QueryResult queryResult = PersistenceHelper.manager.find(querySpec);
    if (queryResult.size() > 0) {
      StringValue stringValue;
      stringDefinition = (StringDefinition)queryResult.nextElement();
      querySpec = new QuerySpec(StringValue.class);
      querySpec.appendWhere((WhereExpression)new SearchCondition(StringValue.class, "definitionReference.key", "=", PersistenceHelper.getObjectIdentifier((Persistable)stringDefinition)), 0);
      querySpec.appendAnd();
      querySpec.appendWhere((WhereExpression)new SearchCondition(StringValue.class, "theIBAHolderReference.key", "=", PersistenceHelper.getObjectIdentifier((Persistable)paramIBAHolder)), 0);
      queryResult = PersistenceHelper.manager.find(querySpec);
      if (VERBOSE)
        System.out.println("*** UpdateContent.updateEPMDocumentIBAStringValue QueryResult for IBAValue size: " + queryResult.size()); 
      if (queryResult.size() == 0) {
        if (VERBOSE)
          System.out.println("*** Attribute didn't exist on object"); 
        stringValue = StringValue.newStringValue(stringDefinition, paramIBAHolder, paramString2);
      } else {
        if (VERBOSE) {
          if (VERBOSE)
            System.out.println("*** Attribute already exist on object ... updating"); 
          if (VERBOSE)
            System.out.println("*** IBAValue = " + paramString2); 
        } 
        stringValue = (StringValue)queryResult.nextElement();
      } 
      stringValue.setValue(paramString2);
      PersistenceHelper.manager.save((Persistable)stringValue);
    } else if (VERBOSE) {
      System.out.println("ATTRIBUTE DEFINITION \"" + paramString1 + "\" DOES NOT EXIST");
    } 
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\commo\\util\IBAUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */