package ext.piab.common.util;

import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.WTObject;
import wt.lifecycle.LifeCycleHelper;
import wt.lifecycle.LifeCycleManaged;
import wt.lifecycle.State;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;

public class LifecycleStateHelper {
  private static final boolean VERBOSE = PropertyforPIAB.VERBOSE;
  
  public static Persistable setLifecycleState(Persistable paramPersistable, String paramString) throws WTException, WTPropertyVetoException {
    if (VERBOSE)
      System.out.println("***LifecycleStateHelper.setLifecycleState[" + paramString + "]"); 
    State state = State.toState(paramString);
    WTObject wTObject = (WTObject)LifeCycleHelper.service.setLifeCycleState((LifeCycleManaged)paramPersistable, state);
    wTObject = (WTObject)PersistenceHelper.manager.refresh((Persistable)wTObject);
    if (VERBOSE)
      System.out.println("***State set[" + state + "]"); 
    return (Persistable)wTObject;
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\commo\\util\LifecycleStateHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */