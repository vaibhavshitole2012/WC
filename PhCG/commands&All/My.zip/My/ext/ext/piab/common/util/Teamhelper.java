package ext.piab.common.util;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Vector;
import wt.fc.Persistable;
import wt.inf.team.ContainerTeam;
import wt.inf.team.ContainerTeamHelper;
import wt.inf.team.ContainerTeamManaged;
import wt.org.WTPrincipal;
import wt.org.WTPrincipalReference;
import wt.project.Role;
import wt.projmgmt.admin.Project2;
import wt.team.Team;
import wt.team.TeamHelper;
import wt.team.TeamManaged;
import wt.team.WTRoleHolder2;
import wt.util.WTException;

public class Teamhelper {
  private static final boolean VERBOSE = PropertyforPIAB.VERBOSE;
  
  public static Vector getRoles(ContainerTeamManaged paramContainerTeamManaged) throws Exception {
    if (VERBOSE)
      System.out.println("Teamhelper.getRoles()"); 
    ContainerTeam containerTeam = getTeam(paramContainerTeamManaged);
    Vector vector = containerTeam.getRoles();
    if (VERBOSE)
      System.out.println("size-" + vector.size() + " roles-" + vector); 
    return vector;
  }
  
  public static ArrayList getParticipants(ContainerTeamManaged paramContainerTeamManaged, Role paramRole) {
    if (VERBOSE)
      System.out.println("*** Teamhelper.getParticipants"); 
    ArrayList arrayList = new ArrayList();
    try {
      ContainerTeam containerTeam = getTeam(paramContainerTeamManaged);
      arrayList = containerTeam.getAllPrincipalsForTarget(paramRole);
      if (VERBOSE)
        System.out.println("Users Role [" + paramRole.getFullDisplay() + " ] IS [" + arrayList + "] "); 
    } catch (WTException wTException) {
      wTException.printStackTrace();
    } 
    return arrayList;
  }
  
  private static ContainerTeam getTeam(ContainerTeamManaged paramContainerTeamManaged) {
    if (VERBOSE)
      System.out.println("*** Teamhelper.getTeam()"); 
    ContainerTeam containerTeam = null;
    try {
      containerTeam = ContainerTeamHelper.service.getContainerTeam(paramContainerTeamManaged);
      if (VERBOSE)
        System.out.println("CONTAINER ROLES = " + containerTeam.getRoles()); 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return containerTeam;
  }
  
  public static void copyTeam(Persistable paramPersistable, String paramString, boolean paramBoolean) throws Exception {
    if (VERBOSE)
      System.out.println("*** Teamhelper.copyTeam()"); 
    try {
      Project2 project2 = RelatedContextLink.getProject(paramString);
      if (project2 != null) {
        Team team = TeamHelper.service.getTeam((TeamManaged)paramPersistable);
        
        Vector<Role> vector = getRoles((ContainerTeamManaged)project2);
        for (byte b = 0; b < vector.size(); b++) {
          Role role = vector.elementAt(b);
          ArrayList arrayList = getParticipants((ContainerTeamManaged)project2, role);
          if (paramBoolean) {
            copyUsers(team, role, arrayList);
          } else if (team.getRoles().contains(role)) {
            copyUsers(team, role, arrayList);
          } 
        } 
      } else if (VERBOSE) {
        System.out.println("The project does not exists");
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  public static void copyUsers(Team paramTeam, Role paramRole, ArrayList<WTPrincipalReference> paramArrayList) throws Exception {
    if (VERBOSE)
      System.out.println("*** Teamhelper.copyUsers"); 
    if (!paramArrayList.isEmpty()) {
      for (byte b = 0; b < paramArrayList.size(); b++) {
        WTPrincipalReference wTPrincipalReference = paramArrayList.get(b);
        WTPrincipal wTPrincipal = wTPrincipalReference.getPrincipal();
        if (VERBOSE)
          System.out.println("Setting User For Role [" + paramRole.getFullDisplay() + " ]   IS  [" + wTPrincipal.getName() + "] "); 
        paramTeam.addPrincipal(paramRole, wTPrincipal);
      } 
    } else {
      if (VERBOSE)
        System.out.println("ELSE:......Setting User For Role [" + paramRole.getFullDisplay() + " ]   IS  [" + paramArrayList + "] "); 
      paramTeam.addPrincipal(paramRole, null);
    } 
  }
  
  public static Role assignRole(Persistable paramPersistable, String paramString1, String paramString2) throws Exception {
    if (VERBOSE)
      System.out.println("***Teamhelper.assignRole(" + paramString1 + "," + paramString2 + ")"); 
    Role role = null;
    try {
      Team team = TeamHelper.service.getTeam((TeamManaged)paramPersistable);
      if (VERBOSE)
        System.out.println("Team " + team.getName()); 
      if (!team.getRoles().isEmpty()) {
        role = getassigneeRole((WTRoleHolder2)team, role, paramString1);
        HashMap hashMap = TeamHelper.service.findAllParticipantsByRole((WTRoleHolder2)team);
        if (VERBOSE)
          System.out.println("Map " + hashMap); 
        Role role1 = Role.toRole(paramString2.toUpperCase());
        ArrayList arrayList = (ArrayList)hashMap.get(role);
        copyUsers(team, role1, arrayList);
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return role;
  }
  
  private static Role getassigneeRole(WTRoleHolder2 paramWTRoleHolder2, Role paramRole, String paramString) {
    if (VERBOSE)
      System.out.println("***Teamhelper.getassigneeRole()"); 
    Vector<Role> vector = new Vector();
    try {
      vector = paramWTRoleHolder2.getRoles();
      //for (Role paramRole : vector) {
      //added by cts
      for (Role paramRole1 : vector) {
        if (VERBOSE)
          System.out.println("***Role " + paramRole1.getDisplay()); 
        
        if (paramRole1.getDisplay().equalsIgnoreCase(paramString)) {
          if (VERBOSE)
            System.out.println("***Returning Role" + paramRole1.getDisplay()); 
        //added by cts
          paramRole=paramRole1;
          break;
          
        } 
      } 
    } catch (WTException wTException) {
      wTException.printStackTrace();
    } 
    return paramRole;
  }
  
  public static void manageChangeTeam(Persistable paramPersistable1, Persistable paramPersistable2) throws Exception {
    if (VERBOSE)
      System.out.println("***Teamhelper.manageChangeTeam()"); 
    Vector<Role> vector = new Vector();
    try {
      Team team1 = TeamHelper.service.getTeam((TeamManaged)paramPersistable1);
      Team team2 = TeamHelper.service.getTeam((TeamManaged)paramPersistable2);
      vector = TeamHelper.service.findRoles((WTRoleHolder2)team2);
      for (Role role : vector) {
        team2 = removeUsers(role, team2);
        team2 = addNewUsers(team1, team2, role);
      } 
    } catch (WTException wTException) {
      wTException.printStackTrace();
    } 
  }
  
  public static Team addNewUsers(Team paramTeam1, Team paramTeam2, Role paramRole) throws Exception {
    if (VERBOSE)
      System.out.println("Teamhelper.addNewUsers() to role" + paramRole.getDisplay()); 
    Enumeration<WTPrincipalReference> enumeration = paramTeam1.getPrincipalTarget(paramRole);
    while (enumeration.hasMoreElements()) {
      WTPrincipalReference wTPrincipalReference = enumeration.nextElement();
      WTPrincipal wTPrincipal = wTPrincipalReference.getPrincipal();
      paramTeam2.addPrincipal(paramRole, wTPrincipal);
    } 
    return paramTeam2;
  }
  
  private static Team removeUsers(Role paramRole, Team paramTeam) throws Exception {
    if (VERBOSE)
      System.out.println("Teamhelper.removeUsers() from role" + paramRole.getDisplay()); 
    Enumeration<WTPrincipalReference> enumeration = paramTeam.getPrincipalTarget(paramRole);
    while (enumeration.hasMoreElements()) {
      WTPrincipalReference wTPrincipalReference = enumeration.nextElement();
      WTPrincipal wTPrincipal = wTPrincipalReference.getPrincipal();
      paramTeam.deletePrincipalTarget(paramRole, wTPrincipal);
    } 
    return paramTeam;
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\commo\\util\Teamhelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */