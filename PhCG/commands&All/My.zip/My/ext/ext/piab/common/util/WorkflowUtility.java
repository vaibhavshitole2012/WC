package ext.piab.common.util;

import com.ptc.windchill.wp.WorkPackage;
import ext.piab.common.resource.CommonResource;
import java.util.Enumeration;
import wt.change2.WTChangeOrder2;
import wt.doc.WTDocument;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.query.WhereExpression;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.vc.VersionControlHelper;
import wt.vc.Versioned;
import wt.workflow.engine.WfEngineHelper;
import wt.workflow.engine.WfProcess;
import wt.workflow.engine.WfState;
import wt.workflow.work.WfAssignedActivity;
import wt.workflow.work.WorkItem;
import wt.workflow.work.WorkflowHelper;

public class WorkflowUtility {
  private static final boolean VERBOSE = PropertyforPIAB.VERBOSE;
  
  private static final String COMMON_RESOURCE = CommonResource.class.getName();
  
  private static String WF_STATE = WTMessage.getLocalizedMessage(COMMON_RESOURCE, "7");
  
  private static String DEL_DESIGNPROCESS_NAME = WTMessage.getLocalizedMessage(COMMON_RESOURCE, "8");
  
  private static String DEL_CN_ACTIVITY_NAME = WTMessage.getLocalizedMessage(COMMON_RESOURCE, "9");
  
  public static void deleteNewWorkflowProcess(Persistable paramPersistable, ObjectReference paramObjectReference) throws Exception {
    if (VERBOSE)
      System.out.println("WorkflowUtility.deleteNewWorkflowProcess()"); 
    try {
      WfProcess wfProcess = (WfProcess)paramObjectReference.getObject();
      if (VERBOSE)
        System.out.println("Current Process: " + wfProcess.toString()); 
      String str = WF_STATE;
      WfState wfState = WfState.toWfState(str);
      Enumeration<WfProcess> enumeration = WfEngineHelper.service.getAssociatedProcesses(paramPersistable, wfState);
      byte b = 1;
      while (enumeration.hasMoreElements()) {
        if (VERBOSE)
          System.out.println("Count: " + b++); 
        WfProcess wfProcess1 = enumeration.nextElement();
        String str1 = wfProcess1.getName();
        if (VERBOSE)
          System.out.println("Process Name: " + str1); 
        if (!wfProcess1.equals(wfProcess)) {
          if (VERBOSE)
            System.out.println("Deleting: " + wfProcess1.toString()); 
          WfEngineHelper.service.deleteProcess(wfProcess1);
        } 
      } 
    } catch (Exception exception) {
      throw new WTException(exception, "Unable to delete Process.");
    } 
  }
  
  public static void terminateworkflow(WorkPackage paramWorkPackage) throws WTException {
    if (VERBOSE)
      System.out.println("WorkflowUtility.terminateworkflow()"); 
    try {
      if (VERBOSE)
        System.out.println("terminate unneccesary workflow for: " + paramWorkPackage.getName()); 
      String str = WF_STATE;
      WfState wfState = WfState.toWfState(str);
      Enumeration<WfProcess> enumeration = WfEngineHelper.service.getAssociatedProcesses((Persistable)paramWorkPackage, wfState);
      while (enumeration.hasMoreElements()) {
        WfProcess wfProcess = enumeration.nextElement();
        if (VERBOSE)
          System.out.println(" Revised Package Process " + wfProcess.getName()); 
        String str1 = wfProcess.getName();
        if (str1.startsWith(DEL_DESIGNPROCESS_NAME))
          WfEngineHelper.service.deleteProcess(wfProcess); 
      } 
    } catch (Exception exception) {
      throw new WTException(exception, "Unable to delete Verification Process.");
    } 
  }

	@SuppressWarnings("rawtypes")
	public static void deleteWfProcess( WTChangeOrder2 ECN , boolean deleteProcess) throws Exception{
 try{
	   if (VERBOSE)System.out.println( "***WorkflowUtility.deleteWorkFlow()"+ ECN.getName());
	   Enumeration items = WorkflowHelper.service.getUncompletedWorkItems(ECN,"");
	   WfProcess process = null;
     while (items.hasMoreElements()){
		   WorkItem workItem = (WorkItem) items.nextElement();
		   ObjectReference or = workItem.getSource();
		   WfAssignedActivity activity = (WfAssignedActivity) or.getObject();
		   process = activity.getParentProcess();
		   if (VERBOSE) System.out.println( "*** WF Parent Process Name " + process.getName());
		   if (VERBOSE) System.out.println( "***  WF Process State " +process.getState());
		   String activityName= activity.getName();
		   if (VERBOSE) System.out.println( "*** WF AssignedActivity Name " + activityName);
		   if(!deleteProcess){
			   if (VERBOSE)System.out.println( "***Deleting Activity "+ activityName);
			   activity.deleteActivity();
		   }else{
			   if(activityName.endsWith(DEL_CN_ACTIVITY_NAME)){
				   if (VERBOSE)System.out.println( "***WfProcess "+ process.getName()+" deleting...");
					   WfEngineHelper.service.deleteProcess(process);
					   break;
				   }
				}
			}
	   }catch(Exception e)
	   	{
		   e.printStackTrace(); 
	   	}
 }/*
  public static void deleteWfProcess(WTChangeOrder2 paramWTChangeOrder2, boolean paramBoolean) throws Exception {
    try {
      if (VERBOSE)
        System.out.println("***WorkflowUtility.deleteWorkFlow()" + paramWTChangeOrder2.getName()); 
      QueryResult<WorkItem> queryResult = WorkflowHelper.service.getUncompletedWorkItems((Persistable)paramWTChangeOrder2, "");
      WfProcess wfProcess = null;
      while (queryResult.hasMoreElements()) {
        WorkItem workItem = queryResult.nextElement();
        ObjectReference objectReference = workItem.getSource();
        WfAssignedActivity wfAssignedActivity = (WfAssignedActivity)objectReference.getObject();
        wfProcess = wfAssignedActivity.getParentProcess();
        if (VERBOSE)
          System.out.println("*** WF Parent Process Name " + wfProcess.getName()); 
        if (VERBOSE)
          System.out.println("***  WF Process State " + wfProcess.getState()); 
        String str = wfAssignedActivity.getName();
        if (VERBOSE)
          System.out.println("*** WF AssignedActivity Name " + str); 
        if (!paramBoolean) {
          if (VERBOSE)
            System.out.println("***Deleting Activity " + str); 
          wfAssignedActivity.deleteActivity();
          continue;
        } 
        if (str.endsWith(DEL_CN_ACTIVITY_NAME)) {
          if (VERBOSE)
            System.out.println("***WfProcess " + wfProcess.getName() + " deleting..."); 
          WfEngineHelper.service.deleteProcess(wfProcess);
          break;
        } 
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  */
  public static WTDocument getDocumentByNumberAndRevision(String paramString1, String paramString2) throws Exception {
    if (VERBOSE)
      System.out.println("*** WorkflowUtility.getDocumentByNumber()" + paramString1); 
    WTDocument wTDocument = null;
    try {
      if (paramString1 != null && paramString2 != null) {
        QuerySpec querySpec = new QuerySpec(WTDocument.class);
        querySpec.appendWhere((WhereExpression)new SearchCondition(WTDocument.class, "master>number", "=", paramString1));
        QueryResult queryResult = PersistenceHelper.manager.find(querySpec);
        if (VERBOSE)
          System.out.println("Number of Documents matching criteria " + queryResult.size()); 
        if (queryResult.hasMoreElements()) {
          wTDocument = (WTDocument)queryResult.nextElement();
          if (VERBOSE)
            System.out.println("Getting All versions for the Document: " + wTDocument.getIdentity()); 
          QueryResult queryResult1 = VersionControlHelper.service.allVersionsOf((Versioned)wTDocument);
          if (VERBOSE)
            System.out.println("All Document versions Size()" + queryResult1.size()); 
          while (queryResult1.hasMoreElements()) {
            wTDocument = (WTDocument)queryResult1.nextElement();
            if (wTDocument.getVersionIdentifier().getValue().equalsIgnoreCase(paramString2)) {
              if (VERBOSE)
                System.out.println("obtained document matching revision: " + paramString2); 
              if (wTDocument.isLatestIteration()) {
                if (VERBOSE)
                  System.out.println("Returning latest revision of the document: " + wTDocument); 
                return wTDocument;
              } 
            } 
          } 
        } 
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
      if (VERBOSE)
        System.out.println("***Error finding document number: " + paramString1 + " and revision: " + paramString2 + "  ****"); 
    } 
    if (VERBOSE)
      System.out.println("***Error finding document number: " + paramString1 + " and revision: " + paramString2 + "  ****"); 
    return null;
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\commo\\util\WorkflowUtility.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */