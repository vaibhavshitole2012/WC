package ext.piab.quality.util;

import java.io.File;
import java.io.FilenameFilter;

class PSFilter implements FilenameFilter {
  String ext;
  
  public PSFilter(String paramString) {
    this.ext = "." + paramString;
  }
  
  public boolean accept(File paramFile, String paramString) {
    return paramString.endsWith(this.ext);
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\qualit\\util\QualityUtil$PSFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */