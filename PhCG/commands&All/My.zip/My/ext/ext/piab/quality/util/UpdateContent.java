package ext.piab.quality.util;

import ext.piab.common.util.PropertyforPIAB;
import ext.piab.quality.resource.QualityResource;
import java.beans.PropertyVetoException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import wt.content.ApplicationData;
import wt.content.ContentHelper;
import wt.content.ContentHolder;
import wt.content.ContentItem;
import wt.content.ContentRoleType;
import wt.content.ContentServerHelper;
import wt.content.FormatContentHolder;
import wt.doc.WTDocument;
import wt.epm.EPMDocument;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.httpgw.URLFactory;
import wt.iba.definition.URLDefinition;
import wt.iba.value.IBAHolder;
import wt.iba.value.URLValue;
import wt.org.WTPrincipal;
import wt.pom.Transaction;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.query.WhereExpression;
import wt.representation.Representation;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.viewmarkup.DerivedImage;

public class UpdateContent {
  private static final boolean VERBOSE = PropertyforPIAB.VERBOSE;
  
  private static final String QUALITY_RESOURCE = QualityResource.class.getName();
  
  private static String SEC_ROLE_TYPE = WTMessage.getLocalizedMessage(QUALITY_RESOURCE, "5");
  
  public static void updatePdfUrl(IBAHolder paramIBAHolder, String paramString1, String paramString2, String paramString3) throws Exception {
    if (VERBOSE)
      System.out.println("*** UpdateContent.updatePdfUrl: " + paramString3); 
    URLDefinition uRLDefinition = null;
    if (paramString2 == null || paramString2.equals(""))
      paramString2 = paramString1.substring(paramString1.lastIndexOf('/') + 1); 
    QuerySpec querySpec = new QuerySpec(URLDefinition.class);
    querySpec.appendWhere((WhereExpression)new SearchCondition(URLDefinition.class, "name", "=", paramString3, false));
    QueryResult queryResult = PersistenceHelper.manager.find(querySpec);
    if (queryResult.size() > 0) {
      URLValue uRLValue;
      uRLDefinition = (URLDefinition)queryResult.nextElement();
      querySpec = new QuerySpec(URLValue.class);
      querySpec.appendWhere((WhereExpression)new SearchCondition(URLValue.class, "definitionReference.key", "=", PersistenceHelper.getObjectIdentifier((Persistable)uRLDefinition)), 0);
      querySpec.appendAnd();
      querySpec.appendWhere((WhereExpression)new SearchCondition(URLValue.class, "theIBAHolderReference.key", "=", PersistenceHelper.getObjectIdentifier((Persistable)paramIBAHolder)), 0);
      queryResult = PersistenceHelper.manager.find(querySpec);
      if (VERBOSE)
        System.out.println("*** PIABPDFUtility.updatePdfUrl QueryResult for IBAValue size: " + queryResult.size()); 
      if (queryResult.size() == 0) {
        if (VERBOSE)
          System.out.println("*** Attribute didn't exist on object"); 
        if (VERBOSE)
          System.out.println("*** " + uRLDefinition); 
        if (VERBOSE)
          System.out.println("*** " + paramString1); 
        if (VERBOSE)
          System.out.println("*** " + paramString2); 
        uRLValue = URLValue.newURLValue(uRLDefinition, paramIBAHolder, paramString1, paramString2);
      } else {
        if (VERBOSE) {
          if (VERBOSE)
            System.out.println("*** Attribute already exist on object ... updating"); 
          if (VERBOSE)
            System.out.println("*** URL = " + paramString1); 
          if (VERBOSE)
            System.out.println("*** LABEL = " + paramString2); 
        } 
        uRLValue = (URLValue)queryResult.nextElement();
      } 
      uRLValue.setValue(paramString1);
      uRLValue.setDescription(paramString2);
      PersistenceHelper.manager.save((Persistable)uRLValue);
    } else if (VERBOSE) {
      System.out.println("ATTRIBUTE DEFINITION \"" + paramString3 + "\" DOES NOT EXIST");
    } 
  }
  
  public static void updateRepresentation(File paramFile, ContentHolder paramContentHolder, ArrayList<Object> paramArrayList) throws WTException, FileNotFoundException, PropertyVetoException, IOException {
    Representation representation;
    if (VERBOSE)
      System.out.println("*** UpdateContent.updateRepresentation " + paramFile.getAbsolutePath()); 
    if (!paramFile.exists() || !paramFile.isFile())
      throw new WTException("***** ERROR: Cannot upload,  file does not exist ****"); 
    Transaction transaction = new Transaction();
    FileInputStream fileInputStream = new FileInputStream(paramFile);
    transaction.start();
    ApplicationData applicationData = new ApplicationData();
    DerivedImage derivedImage = DerivedImage.newDerivedImage("default");
    for (byte b = 0; b < paramArrayList.size(); b++) {
      if (paramArrayList.get(b) instanceof ApplicationData) {
        applicationData = (ApplicationData)paramArrayList.get(b);
      } else if (paramArrayList.get(b) instanceof Representation) {
        representation = (Representation)paramArrayList.get(b);
      } 
    } 
    if (VERBOSE)
      System.out.println("*** Uploading new PDF file " + paramFile.getAbsolutePath()); 
    if (VERBOSE)
      System.out.println("*** Application Data " + applicationData); 
    if (VERBOSE)
      System.out.println("*** Representation object " + representation); 
    applicationData = ContentServerHelper.service.updateContent((ContentHolder)representation, applicationData, fileInputStream);
    if (VERBOSE)
      System.out.println("*** New PDF file uploaded " + paramFile.getAbsolutePath()); 
    if (VERBOSE)
      System.out.println("*** " + applicationData.getFileName() + " " + applicationData.getFileSize()); 
    transaction.commit();
    fileInputStream.close();
  }
  
  public static ApplicationData uploadContent(File paramFile, ContentHolder paramContentHolder, boolean paramBoolean) throws WTException, FileNotFoundException, PropertyVetoException, IOException {
    if (VERBOSE)
      System.out.println("*** UpdateContent.uploadContent: " + paramFile.getAbsolutePath()); 
    if (!paramFile.exists() || !paramFile.isFile())
      throw new WTException("***** ERROR: Cannot upload,  file does not exist ****"); 
    ApplicationData applicationData = null;
    WTPrincipal wTPrincipal = SessionHelper.manager.getPrincipal();
    SessionHelper.manager.setAdministrator();
    try {
      WTDocument wTDocument = (WTDocument)paramContentHolder;
      String str = wTDocument.getVersionIdentifier().getValue();
      Transaction transaction = new Transaction();
      FileInputStream fileInputStream = new FileInputStream(paramFile);
      transaction.start();
      applicationData = ApplicationData.newApplicationData(paramContentHolder);
      if (VERBOSE)
        System.out.println("*** Uploading new content file " + paramFile.getAbsolutePath()); 
      if (paramBoolean) {
        applicationData.setFileName(paramFile.getName());
        applicationData = ContentServerHelper.service.updatePrimary((FormatContentHolder)paramContentHolder, applicationData, fileInputStream);
      } else {
        String str1 = paramFile.getName().substring(0, paramFile.getName().lastIndexOf('.'));
        String str2 = paramFile.getName().replaceAll(str1, wTDocument.getNumber());
        if (VERBOSE)
          System.out.println(str1 + " - File renamed - " + str2); 
        applicationData.setFileName(str2);
        if (VERBOSE)
          System.out.println("*** " + applicationData.getFileName() + " " + applicationData.getFileSize()); 
        QueryResult queryResult = ContentHelper.service.getContentsByRole(paramContentHolder, ContentRoleType.toContentRoleType(SEC_ROLE_TYPE));
        while (queryResult.hasMoreElements()) {
          ApplicationData applicationData1 = (ApplicationData)queryResult.nextElement();
          if (VERBOSE)
            System.out.println("*** existing data name" + applicationData1.getFileName()); 
          if (applicationData1.getFileName().equalsIgnoreCase(str2)) {
            if (VERBOSE)
              System.out.println("*** Secondary content already exists, deleting"); 
            ContentServerHelper.service.deleteContent((ContentHolder)wTDocument, (ContentItem)applicationData1);
          } 
        } 
        applicationData.setRole(ContentRoleType.toContentRoleType(SEC_ROLE_TYPE));
        applicationData = ContentServerHelper.service.updateContent(paramContentHolder, applicationData, fileInputStream);
        if (VERBOSE)
          System.out.println("*** New content file uploaded " + paramFile.getAbsolutePath()); 
        if (VERBOSE)
          System.out.println("*** " + applicationData.getFileName() + " " + applicationData.getFileSize()); 
      } 
      transaction.commit();
      fileInputStream.close();
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    SessionHelper.manager.setPrincipal(wTPrincipal.getName());
    return applicationData;
  }
  
  public static ApplicationData uploadCADDocumentContent(File paramFile, ContentHolder paramContentHolder, boolean paramBoolean) throws WTException, FileNotFoundException, PropertyVetoException, IOException {
    if (VERBOSE)
      System.out.println("*** UpdateContent.uploadContent: " + paramFile.getAbsolutePath()); 
    if (!paramFile.exists() || !paramFile.isFile())
      throw new WTException("***** ERROR: Cannot upload,  file does not exist ****"); 
    ApplicationData applicationData = null;
    WTPrincipal wTPrincipal = SessionHelper.manager.getPrincipal();
    SessionHelper.manager.setAdministrator();
    String str = "PublishedPDF";
    try {
      EPMDocument ePMDocument = (EPMDocument)paramContentHolder;
      Transaction transaction = new Transaction();
      FileInputStream fileInputStream = new FileInputStream(paramFile);
      transaction.start();
      applicationData = ApplicationData.newApplicationData(paramContentHolder);
      if (VERBOSE)
        System.out.println("*** Uploading new content file " + paramFile.getAbsolutePath()); 
      if (paramBoolean) {
        applicationData.setFileName(paramFile.getName());
        applicationData = ContentServerHelper.service.updatePrimary((FormatContentHolder)paramContentHolder, applicationData, fileInputStream);
      } else {
        String str1 = paramFile.getName().substring(0, paramFile.getName().lastIndexOf('.'));
        String str2 = str1 + ".PDF";
        if (VERBOSE)
          System.out.println(str1 + " - File renamed - " + str2); 
        applicationData.setFileName(str2);
        if (VERBOSE)
          System.out.println("*** " + applicationData.getFileName() + " " + applicationData.getFileSize()); 
        QueryResult queryResult = ContentHelper.service.getContentsByRole(paramContentHolder, ContentRoleType.toContentRoleType(SEC_ROLE_TYPE));
        while (queryResult.hasMoreElements()) {
          ApplicationData applicationData1 = (ApplicationData)queryResult.nextElement();
          if (VERBOSE)
            System.out.println("*** existing data name" + applicationData1.getFileName()); 
          if (applicationData1.getFileName().equalsIgnoreCase(str2)) {
            if (VERBOSE)
              System.out.println("*** Secondary content already exists, deleting"); 
            ContentServerHelper.service.deleteContent((ContentHolder)ePMDocument, (ContentItem)applicationData1);
          } 
        } 
        applicationData.setRole(ContentRoleType.toContentRoleType(SEC_ROLE_TYPE));
        applicationData.setCategory(str);
        applicationData = ContentServerHelper.service.updateContent(paramContentHolder, applicationData, fileInputStream);
        if (VERBOSE)
          System.out.println("*** New content file uploaded " + paramFile.getAbsolutePath()); 
        if (VERBOSE)
          System.out.println("*** " + applicationData.getFileName() + " " + applicationData.getFileSize()); 
      } 
      transaction.commit();
      fileInputStream.close();
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    SessionHelper.manager.setPrincipal(wTPrincipal.getName());
    return applicationData;
  }
  
  public static String genDownloadHREF(ContentHolder paramContentHolder, ApplicationData paramApplicationData) throws Exception {
    if (VERBOSE)
      System.out.println("*** UpdateContent.genDownloadHREF\n*** Creating href string for " + paramContentHolder); 
    URLFactory uRLFactory = new URLFactory();
    return uRLFactory.getHREF("/servlet/AttachmentsDownloadDirectionServlet?oid=OR:" + PersistenceHelper.getObjectIdentifier((Persistable)paramContentHolder) + "&cioids=" + PersistenceHelper.getObjectIdentifier((Persistable)paramApplicationData));
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\qualit\\util\UpdateContent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */