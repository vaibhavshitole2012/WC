package ext.piab.quality.util;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfGState;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import ext.piab.common.util.PropertyforPIAB;
import ext.piab.quality.resource.QualityResource;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import wt.content.ApplicationData;
import wt.content.ContentHolder;
import wt.doc.WTDocument;
import wt.iba.value.IBAHolder;
import wt.representation.Representable;
import wt.util.WTException;
import wt.util.WTMessage;

public class PDFUtil {
  private static final boolean VERBOSE = PropertyforPIAB.VERBOSE;
  
  private static final float PDF_TABLE_PORTRAIT_Y = PropertyforPIAB.PDF_TABLE_PORTRAIT_Y;
  
  private static final float PDF_TABLE_PORTRAIT_X = PropertyforPIAB.PDF_TABLE_PORTRAIT_X;
  
  private static final float PDF_TABLE_LANDSCAPE_X = PropertyforPIAB.PDF_TABLE_LANDSCAPE_X;
  
  private static final float PDF_TABLE_LANDSCAPE_Y = PropertyforPIAB.PDF_TABLE_LANDSCAPE_Y;
  
  private static final String DOC_TO_PDF_SCRIPT = PropertyforPIAB.DOC_TO_PDF_SCRIPT;
  
  private static final String WT_HOME = PropertyforPIAB.WT_HOME;
  
  private static final String TEMP_DIR = PropertyforPIAB.TEMP_DIR;
  
  private static final boolean DEL_TEMP = PropertyforPIAB.DEL_TEMP;
  
  private static final int SLEEP_INTERVAL = 1000;
  
  private static final int MAX_PS_GEN = PropertyforPIAB.MAX_PS_GEN;
  
  private static final String PDF_URL_IBA_NAME = PropertyforPIAB.PDF_URL_IBA_NAME;
  
  private static final String QUALITY_RESOURCE = QualityResource.class.getName();
  
  private static String PDF_TITLE = WTMessage.getLocalizedMessage(QUALITY_RESOURCE, "6");
  
  private static String PDF_DOC_NUM = WTMessage.getLocalizedMessage(QUALITY_RESOURCE, "7");
  
  private static String PDF_RELEASE_LEVEL = WTMessage.getLocalizedMessage(QUALITY_RESOURCE, "8");
  
  private static String PDF_REVISION = WTMessage.getLocalizedMessage(QUALITY_RESOURCE, "9");
  
  private static File addWatermark(File paramFile, WTDocument paramWTDocument) throws Exception {
    if (VERBOSE)
      System.out.println("PDFUtil.addWatermark()"); 
    String str = paramFile.getAbsolutePath();
    boolean bool = true;
    if (VERBOSE && VERBOSE)
      System.out.println("Processing PDF file: " + str); 
    FileInputStream fileInputStream = new FileInputStream(paramFile);
    PdfReader pdfReader = new PdfReader(fileInputStream);
    int i = pdfReader.getNumberOfPages();
    FileOutputStream fileOutputStream = new FileOutputStream(paramFile);
    PdfStamper pdfStamper = new PdfStamper(pdfReader, fileOutputStream);
    BaseFont baseFont = BaseFont.createFont("Helvetica", "Cp1252", true);
    Font font = FontFactory.getFont("Courier");
    font.setStyle(1);
    font.setColor(BaseColor.BLACK);
    baseFont = font.getBaseFont();
    byte b = 0;
    while (b < i) {
      Rectangle rectangle = pdfReader.getPageSize(++b);
      float f2 = rectangle.getHeight();
      float f1 = rectangle.getWidth();
      if (VERBOSE)
        System.out.println("*** Page size: Width-X:" + f1 + "\t Height-Y:" + f2); 
      if (VERBOSE)
        System.out.println("***Page size: getRotation:" + rectangle.getRotation() + "\tY:" + rectangle); 
      if (f1 > f2) {
        bool = false;
      } else {
        bool = true;
      } 
      PdfContentByte pdfContentByte = pdfStamper.getUnderContent(b);
      PdfGState pdfGState = new PdfGState();
      pdfGState.setFillOpacity(1.0F);
      pdfGState.setStrokeOpacity(1.0F);
      pdfContentByte.saveState();
      pdfContentByte.setGState(pdfGState);
      pdfContentByte.beginText();
      pdfContentByte.setTextMatrix(40.0F, 40.0F);
      pdfContentByte.setFontAndSize(baseFont, 11.0F);
      PdfPTable pdfPTable = new PdfPTable(4);
      PdfPCell pdfPCell1 = new PdfPCell(new Phrase(PDF_TITLE));
      PdfPCell pdfPCell2 = new PdfPCell(new Phrase(PDF_DOC_NUM));
      PdfPCell pdfPCell3 = new PdfPCell(new Phrase(PDF_RELEASE_LEVEL));
      if (bool) {
        pdfPTable.setTotalWidth(418.5F);
        pdfPCell3.setMinimumHeight(20.0F);
      } else {
        pdfPTable.setTotalWidth(419.5F);
        pdfPCell1.setMinimumHeight(18.0F);
        pdfPCell2.setMinimumHeight(18.0F);
        pdfPCell3.setMinimumHeight(18.0F);
      } 
      pdfPCell1.setColspan(1);
      pdfPTable.addCell(pdfPCell1);
      PdfPCell pdfPCell4 = new PdfPCell(new Phrase(paramWTDocument.getName()));
      pdfPCell4.setColspan(3);
      pdfPTable.addCell(pdfPCell4);
      pdfPCell2.setColspan(1);
      pdfPTable.addCell(pdfPCell2);
      PdfPCell pdfPCell5 = new PdfPCell(new Phrase(paramWTDocument.getNumber()));
      pdfPCell5.setColspan(1);
      pdfPTable.addCell(pdfPCell5);
      PdfPCell pdfPCell6 = new PdfPCell(new Phrase(PDF_REVISION));
      pdfPCell6.setColspan(1);
      pdfPCell6.setHorizontalAlignment(2);
      pdfPTable.addCell(pdfPCell6);
      PdfPCell pdfPCell7 = new PdfPCell(new Phrase(paramWTDocument.getVersionIdentifier().getValue() + "." + paramWTDocument.getIterationIdentifier().getValue()));
      pdfPCell7.setColspan(1);
      pdfPTable.addCell(pdfPCell7);
      pdfPCell3.setColspan(1);
      pdfPTable.addCell(pdfPCell3);
      PdfPCell pdfPCell8 = new PdfPCell(new Phrase(paramWTDocument.getLifeCycleState().getDisplay()));
      pdfPCell8.setColspan(3);
      pdfPTable.addCell(pdfPCell8);
      if (bool) {
        pdfPTable.writeSelectedRows(0, -1, PDF_TABLE_PORTRAIT_X, PDF_TABLE_PORTRAIT_Y, pdfStamper.getUnderContent(b));
      } else {
        pdfPTable.writeSelectedRows(0, -1, PDF_TABLE_LANDSCAPE_X, PDF_TABLE_LANDSCAPE_Y, pdfStamper.getUnderContent(b));
      } 
      pdfContentByte.endText();
      pdfContentByte.restoreState();
      if (VERBOSE)
        System.out.println("*** :Content Added"); 
    } 
    pdfStamper.close();
    fileInputStream.close();
    fileOutputStream.close();
    File file = new File(str);
    if (VERBOSE)
      System.out.println("*** new path :" + file.getAbsolutePath()); 
    return file;
  }
  
  private static String convertPath(String paramString) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("\"");
    for (byte b = 0; b < paramString.length(); b++) {
      char c = paramString.charAt(b);
      if (c == '\\')
        stringBuilder.append('\\'); 
      stringBuilder.append(c);
    } 
    stringBuilder.append("\"");
    return stringBuilder.toString();
  }
  
  public static File processPdf(WTDocument paramWTDocument) throws Exception {
    if (VERBOSE)
      System.out.println("*** PDFUtil.processPdf() "); 
    File file1 = null;
    File file2 = null;
    File file3 = QualityHelper.createDirectory(TEMP_DIR);
    ArrayList<Object> arrayList = new ArrayList();
    file2 = DownloadContent.getPrimaryFile((ContentHolder)paramWTDocument, file3);
    if (file2 != null) {
      file1 = executeCommand(file2);
      if (file1.exists() && file1.canWrite()) {
        file1 = addWatermark(file1, paramWTDocument);
        arrayList = DownloadContent.getRepresentation((Representable)paramWTDocument, file1.getName());
        if (arrayList.size() > 0) {
          if (VERBOSE)
            System.out.println("*** Updating Representation. "); 
          UpdateContent.updateRepresentation(file1, (ContentHolder)paramWTDocument, arrayList);
        } else if (VERBOSE) {
          System.out.println("*** Represntation does not exsist. ");
        } 
        ApplicationData applicationData = UpdateContent.uploadContent(file1, (ContentHolder)paramWTDocument, false);
        String str = UpdateContent.genDownloadHREF((ContentHolder)paramWTDocument, applicationData);
        if (VERBOSE)
          System.out.println("*** PDF secondary file redirect URL: " + str); 
        UpdateContent.updatePdfUrl((IBAHolder)paramWTDocument, str, file1.getName(), PDF_URL_IBA_NAME);
      } 
      if (DEL_TEMP)
        QualityHelper.removeDirectory(file3); 
      return file1;
    } 
    if (VERBOSE)
      System.out.println("*** No Supported Docuemnt Type."); 
    return null;
  }
  
  private static void convertToPDF(File paramFile) {
    if (VERBOSE)
      System.out.println("******PDFUtil.convertToPDF" + DOC_TO_PDF_SCRIPT); 
    String str1 = convertPath(paramFile.getAbsolutePath());
    String str2 = convertPath(paramFile.getParent() + "\\" + paramFile.getName().substring(0, paramFile.getName().lastIndexOf('.')) + ".pdf");
    if (VERBOSE)
      System.out.println("Input File Path: " + paramFile.getAbsolutePath()); 
    if (VERBOSE)
      System.out.println("Output file Path: " + str2); 
    try {
      Runtime runtime = Runtime.getRuntime();
      String str = System.getenv("windir") + "\\system32\\wscript.exe " + WT_HOME + "\\codebase\\" + DOC_TO_PDF_SCRIPT + " " + str1 + " /o:" + str2;
      if (VERBOSE)
        System.out.println("VB Command: " + str); 
      System.out.println("VB Command: " + str);
      runtime.exec(str);
      if (VERBOSE)
        System.out.println("Conversion Completed...."); 
    } catch (Exception exception) {
      if (VERBOSE)
        System.out.println("Error during Conversion from Doc to PDF...."); 
      exception.printStackTrace();
    } 
  }
  
  private static File executeCommand(File paramFile) {
    if (VERBOSE)
      System.out.println("******PDFUtil.executeCommand()"); 
    File file1 = null;
    File file2 = paramFile.getParentFile();
    convertToPDF(paramFile);
    try {
      File[] arrayOfFile = QualityUtil.getFilteredFiles(file2, "pdf");
      byte b = 0;
      while (true) {
        if (arrayOfFile.length == 0 || !arrayOfFile[0].exists() || !arrayOfFile[0].canWrite()) {
          Thread.sleep(1000L);
          if (VERBOSE)
            System.out.print("."); 
          if (b++ >= MAX_PS_GEN)
            throw new WTException("***** ERROR: PDF download exceeded allowable time limit ****"); 
          arrayOfFile = QualityUtil.getFilteredFiles(file2, "pdf");
          continue;
        } 
        return arrayOfFile[0];
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return file1;
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\qualit\\util\PDFUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */