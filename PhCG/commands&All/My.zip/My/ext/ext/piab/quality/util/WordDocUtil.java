package ext.piab.quality.util;

import ext.piab.common.util.PropertyforPIAB;
import ext.piab.quality.resource.QualityResource;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import org.apache.poi.xwpf.usermodel.ParagraphAlignment;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;
import wt.content.ContentHolder;
import wt.doc.WTDocument;
import wt.method.RemoteAccess;
import wt.util.WTException;
import wt.util.WTMessage;

public class WordDocUtil implements RemoteAccess {
  private static final String TEMP_DIR = PropertyforPIAB.TEMP_DIR;
  
  private static final boolean VERBOSE = PropertyforPIAB.VERBOSE;
  
  private static final boolean DEL_TEMP = PropertyforPIAB.DEL_TEMP;
  
  private static final String QUALITY_RESOURCE = QualityResource.class.getName();
  
  private static final int COLS = PropertyforPIAB.COLS;
  
  private static final int ROWS = PropertyforPIAB.ROWS;
  
  private static String HEADING_NAME = WTMessage.getLocalizedMessage(QUALITY_RESOURCE, "10");
  
  private static String HEADING_NUMBER = WTMessage.getLocalizedMessage(QUALITY_RESOURCE, "11");
  
  private static String HEADING_REV = WTMessage.getLocalizedMessage(QUALITY_RESOURCE, "12");
  
  private static String HEADING_STATE = WTMessage.getLocalizedMessage(QUALITY_RESOURCE, "13");
  
  public static File doOperation(ContentHolder paramContentHolder) throws Exception {
    if (VERBOSE)
      System.out.println("$$$$ WordDocUtil.doOperation"); 
    File file1 = QualityHelper.createDirectory(TEMP_DIR);
    File file2 = null;
    if (VERBOSE)
      System.out.println("$$$$ tempDir" + file1.getAbsolutePath()); 
    try {
      file2 = DownloadContent.getPrimaryFile(paramContentHolder, file1);
      WTDocument wTDocument = (WTDocument)paramContentHolder;
      if (file2.exists()) {
        file2 = docWrite(file2, wTDocument);
        UpdateContent.uploadContent(file2, (ContentHolder)wTDocument, false);
      } 
      if (DEL_TEMP)
        QualityHelper.removeDirectory(file1); 
    } catch (WTException wTException) {
      wTException.printStackTrace();
    } 
    return file2;
  }
  
  private static File docWrite(File paramFile, WTDocument paramWTDocument) throws IOException {
    if (VERBOSE)
      System.out.println("$$$$ WordDocUtil.docWrite"); 
    XWPFDocument xWPFDocument = null;
    if (paramFile.exists()) {
      FileInputStream fileInputStream = new FileInputStream(paramFile);
      xWPFDocument = new XWPFDocument(fileInputStream);
    } else if (VERBOSE) {
      System.out.println("The Document does not exist");
    } 
    xWPFDocument = createParagraph(xWPFDocument, "WTDocument-Information Table");
    int i = ROWS;
    int j = COLS;
    XWPFTable xWPFTable = xWPFDocument.createTable(i, j);
    for (byte b = 0; b < i; b++) {
      boolean bool = false;
      XWPFTableRow xWPFTableRow = xWPFTable.getRow(b);
      for (byte b1 = 0; b1 < j; b1++) {
        if (b == 0)
          bool = true; 
        String str = getTextValues(b1, bool, paramWTDocument);
        createCols(xWPFTableRow, b1, str);
      } 
    } 
    FileOutputStream fileOutputStream = null;
    try {
      fileOutputStream = new FileOutputStream(paramFile);
    } catch (FileNotFoundException fileNotFoundException) {
      fileNotFoundException.printStackTrace();
    } 
    try {
      xWPFDocument.write(fileOutputStream);
      fileOutputStream.close();
    } catch (FileNotFoundException fileNotFoundException) {
      fileNotFoundException.printStackTrace();
    } catch (IOException iOException) {
      iOException.printStackTrace();
    } 
    return paramFile;
  }
  
  private static XWPFDocument createParagraph(XWPFDocument paramXWPFDocument, String paramString) {
    if (VERBOSE)
      System.out.println("$$$WordDocUtil.createParagraph()"); 
    XWPFParagraph xWPFParagraph = paramXWPFDocument.createParagraph();
    xWPFParagraph.setAlignment(ParagraphAlignment.LEFT);
    XWPFRun xWPFRun = xWPFParagraph.createRun();
    xWPFRun.addBreak();
    xWPFRun.setBold(true);
    xWPFRun.setText(paramString);
    xWPFRun.addBreak();
    return paramXWPFDocument;
  }
  
  private static void createCols(XWPFTableRow paramXWPFTableRow, int paramInt, String paramString) {
    if (VERBOSE)
      System.out.println("$$$WordDocUtil.createCols()"); 
    XWPFParagraph xWPFParagraph = paramXWPFTableRow.getCell(paramInt).addParagraph();
    xWPFParagraph.setAlignment(ParagraphAlignment.LEFT);
    xWPFParagraph.createRun().setBold(true);
    xWPFParagraph.createRun().setText(paramString);
  }
  
  private static String getTextValues(int paramInt, boolean paramBoolean, WTDocument paramWTDocument) {
    String str = "";
    if (paramBoolean) {
      if (paramInt == 0)
        str = HEADING_NAME; 
      if (paramInt == 1)
        str = HEADING_NUMBER; 
      if (paramInt == 2)
        str = HEADING_REV; 
      if (paramInt == 3)
        str = HEADING_STATE; 
    } else {
      if (paramInt == 0)
        str = paramWTDocument.getName(); 
      if (paramInt == 1)
        str = paramWTDocument.getNumber(); 
      if (paramInt == 2)
        str = paramWTDocument.getVersionIdentifier().getValue().toString() + "." + paramWTDocument.getIterationIdentifier().getValue().toString(); 
      if (paramInt == 3)
        str = paramWTDocument.getState().toString(); 
    } 
    return str;
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\qualit\\util\WordDocUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */