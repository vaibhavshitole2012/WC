package ext.piab.quality.resource;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("quality.resource.QualityResource")
public final class QualityResource extends WTListResourceBundle {
  @RBEntry("There is no Primary content attached to the Document.\nPlease add Primary Content to Proceed !")
  public static final String NO_PRIMARY = "0";
  
  @RBEntry("The Primary content attached to the WTDocument is not a Supported Document type.\nThe only supported document types are [{0}].")
  public static final String UNSUPPORTED_CONTENT = "1";
  
  @RBEntry("[{0}] must be assgined to proceed")
  public static final String UNASSIGNED_ROLE = "2";
  
  @RBEntry("pri")
  public static final String PRI_FOLDER_NAME = "3";
  
  @RBEntry("PRIMARY")
  public static final String PRI_ROLE_TYPE = "4";
  
  @RBEntry("SECONDARY")
  public static final String SEC_ROLE_TYPE = "5";
  
  @RBEntry("Title:")
  public static final String PDF_TITLE = "6";
  
  @RBEntry("Document #:")
  public static final String PDF_DOC_NUM = "7";
  
  @RBEntry("Release Level:")
  public static final String PDF_RELEASE_LEVEL = "8";
  
  @RBEntry("Revision:")
  public static final String PDF_REVISION = "9";
  
  @RBEntry("Name")
  public static final String HEADING_NAME = "10";
  
  @RBEntry("Number")
  public static final String HEADING_NUMBER = "11";
  
  @RBEntry("Revision")
  public static final String HEADING_REV = "12";
  
  @RBEntry("State")
  public static final String HEADING_STATE = "13";
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\quality\resource\QualityResource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */