package ext.piab.quality.util;

import ext.piab.common.util.PropertyforPIAB;
import java.io.File;
import java.io.FilenameFilter;
import wt.content.ContentHolder;
import wt.doc.WTDocument;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.query.WhereExpression;
import wt.session.SessionHelper;
import wt.type.TypedUtility;
import wt.util.WTException;

public class QualityUtil implements RemoteAccess {
  private static final String SERVER_CLASS = QualityUtil.class.getName();
  
  private static final boolean VERBOSE = PropertyforPIAB.VERBOSE;
  
  private static final String QUALITY_FORM = PropertyforPIAB.QUALITY_FORM;
  
  private static boolean connected = false;
  
  private static String docNumber = null;
  
  private static String docRevision = null;
  
  private static String wcUserName = null;
  
  private static String wcUserPassword = null;
  
  public static void main(String[] paramArrayOfString) {
    try {
      if (VERBOSE)
        System.out.println("Args[] :  [" + paramArrayOfString.length + "]"); 
      if (paramArrayOfString != null && paramArrayOfString.length > 0)
        for (byte b = 0; b < paramArrayOfString.length; b++) {
          if (b == 0)
            docNumber = paramArrayOfString[0]; 
          if (b == 1)
            docRevision = paramArrayOfString[1]; 
          if (b == 2)
            wcUserName = paramArrayOfString[2]; 
          if (b == 3)
            wcUserPassword = paramArrayOfString[3]; 
        }  
      if (VERBOSE)
        System.out.println("Parameter :docNumber Args[0] [" + docNumber + "]"); 
      if (VERBOSE)
        System.out.println("Parameter :docRevision Args[1] [" + docRevision + "]"); 
      if (VERBOSE)
        System.out.println("Parameter :wcUserName Args[2] [" + wcUserName + "]"); 
      if (VERBOSE)
        System.out.println("Parameter :wcUserPassword Args[3] [" + wcUserPassword + "]"); 
      if (wcUserName != null && wcUserPassword != null)
        connected = logonToServer(wcUserName, wcUserPassword); 
      if (docNumber != null) {
        processRemotely(docNumber, docRevision);
      } else {
        System.out.println("Parameter : Document Number is Empty [" + docNumber + "]");
      } 
      System.exit(0);
    } catch (Exception exception) {
      System.out.println("Exception is ...   " + exception);
      System.exit(-1);
    } 
  }
  
  public static void processRemotely(String paramString1, String paramString2) throws WTException {
    try {
      Class[] arrayOfClass = { String.class, String.class };
      Object[] arrayOfObject = { paramString1, paramString2 };
      RemoteMethodServer.getDefault().invoke("processRepresentation", SERVER_CLASS, null, arrayOfClass, arrayOfObject);
    } catch (Exception exception) {
      if (exception instanceof WTException)
        throw (WTException)exception; 
      throw new WTException(exception);
    } 
  }
  
  public static boolean logonToServer(String paramString1, String paramString2) throws Exception {
    if (!connected) {
      if (VERBOSE)
        System.out.println("Login to Remote method server >> User :  [" + paramString1 + "], Password : [" + paramString2 + "]"); 
      RemoteMethodServer remoteMethodServer = RemoteMethodServer.getDefault();
      remoteMethodServer.setUserName(paramString1);
      remoteMethodServer.setPassword(paramString2);
      SessionHelper.manager.getPrincipal();
      connected = true;
    } 
    return connected;
  }
  
  public static WTDocument getWTDoc(String paramString1, String paramString2) throws Exception {
    if (VERBOSE)
      System.out.println("QualityUtil.getWTDoc()"); 
    QuerySpec querySpec = new QuerySpec(WTDocument.class);
    querySpec.appendWhere((WhereExpression)new SearchCondition(WTDocument.class, "master>number", "=", paramString1));
    QueryResult queryResult = PersistenceHelper.manager.find(querySpec);
    if (VERBOSE)
      System.out.println("$$$$ Query size wtdocuments " + queryResult.size()); 
    WTDocument wTDocument = null;
    while (queryResult.hasMoreElements()) {
      wTDocument = (WTDocument)queryResult.nextElement();
      String str = wTDocument.getVersionIdentifier().getValue().toString() + "." + wTDocument.getIterationIdentifier().getValue().toString();
      if (str.equalsIgnoreCase(paramString2)) {
        if (VERBOSE)
          System.out.println("$$$$ Latest WTDocument " + wTDocument.getName() + "Revision -" + wTDocument.getVersionIdentifier().getValue().toString()); 
        break;
      } 
    } 
    return wTDocument;
  }
  
  public static File processRepresentation(String paramString1, String paramString2) {
    if (VERBOSE)
      System.out.println("QualityUtil.processRepresentation()"); 
    WTDocument wTDocument = null;
    File file = null;
    try {
      wTDocument = getWTDoc(paramString1, paramString2);
      if (wTDocument != null) {
        if (VERBOSE)
          System.out.println("processing WTDocument: " + paramString1); 
        if (TypedUtility.getTypeIdentifier(wTDocument).toString().endsWith(QUALITY_FORM)) {
          file = WordDocUtil.doOperation((ContentHolder)wTDocument);
        } else {
          file = PDFUtil.processPdf(wTDocument);
        } 
      } else {
        System.out.println("******:Cannot process for WTDocument : " + paramString1);
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return file;
  }
  
  public static File[] getFilteredFiles(File paramFile, String paramString) {
    PSFilter pSFilter = new PSFilter(paramString);
    return paramFile.listFiles(pSFilter);
  }
  
  private static class PSFilter implements FilenameFilter {
    String ext;
    
    public PSFilter(String param1String) {
      this.ext = "." + param1String;
    }
    
    public boolean accept(File param1File, String param1String) {
      return param1String.endsWith(this.ext);
    }
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\qualit\\util\QualityUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */