package ext.piab.quality.validation;

import ext.piab.common.util.PropertyforPIAB;
import ext.piab.quality.resource.QualityResource;
import java.util.Enumeration;
import java.util.StringTokenizer;
import wt.content.ApplicationData;
import wt.content.ContentHelper;
import wt.content.ContentHolder;
import wt.content.ContentRoleType;
import wt.doc.WTDocument;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.project.Role;
import wt.team.Team;
import wt.team.TeamHelper;
import wt.team.TeamManaged;
import wt.util.WTException;

public class ValidateContent {
  private static boolean VERBOSE = PropertyforPIAB.VERBOSE;
  
  private static final String supportedContentTypes = PropertyforPIAB.supportedContentTypes;
  
  private static final String QUALITY_RESOURCE = QualityResource.class.getName();
  
  private static final String docTypes = PropertyforPIAB.supportedContentTypes;
  
  public static void checkPrimary(Persistable paramPersistable) throws Exception {
    if (VERBOSE)
      System.out.println("***ValidateContent.checkPrimary"); 
    WTDocument wTDocument = (WTDocument)paramPersistable;
    ContentRoleType contentRoleType = ContentRoleType.toContentRoleType("PRIMARY");
    QueryResult queryResult = ContentHelper.service.getContentsByRole((ContentHolder)wTDocument, contentRoleType);
    if (queryResult.size() == 0)
      throw new WTException(QUALITY_RESOURCE, "0", null); 
    ApplicationData applicationData = (ApplicationData)queryResult.nextElement();
    String str = applicationData.getFileName();
    if (str.isEmpty() || !checkToProcess(str)) {
      Object[] arrayOfObject = { docTypes };
      throw new WTException(QUALITY_RESOURCE, "1", arrayOfObject);
    } 
  }
  
  public static void checkIfRoleHasUsers(String paramString, WTDocument paramWTDocument) throws WTException {
    if (VERBOSE)
      System.out.println("***ValidateContent.checkIfRoleHasUsers()"); 
    Role role = Role.toRole(paramString);
    Team team1 = TeamHelper.service.getTeam((TeamManaged)paramWTDocument);
    Team team2 = team1;
    Enumeration enumeration = team2.getPrincipalTarget(role);
    if (VERBOSE)
      System.out.println("number of users: " + role.getStringValue()); 
    if (enumeration.hasMoreElements()) {
      if (VERBOSE)
        System.out.println("users exist" + role.getStringValue()); 
    } else {
      Object[] arrayOfObject = { role };
      throw new WTException(QUALITY_RESOURCE, "2", arrayOfObject);
    } 
  }
  
  public static boolean isSecondaryGenerated(ContentHolder paramContentHolder) {
    if (VERBOSE)
      System.out.println("***ValidateContent.isSecondaryGenerated()"); 
    WTDocument wTDocument = (WTDocument)paramContentHolder;
    boolean bool = false;
    try {
      String str = wTDocument.getVersionIdentifier().getValue();
      QueryResult queryResult = ContentHelper.service.getContentsByRole(paramContentHolder, ContentRoleType.SECONDARY);
      while (queryResult.hasMoreElements()) {
        ApplicationData applicationData = (ApplicationData)queryResult.nextElement();
        String str1 = applicationData.getFileName();
        if (VERBOSE)
          System.out.println("revision- " + str + " - Secondary File Name: " + str1); 
        if (str1.startsWith(wTDocument.getNumber() + "-" + str)) {
          bool = true;
          break;
        } 
      } 
    } catch (WTException wTException) {
      wTException.printStackTrace();
    } 
    return bool;
  }
  
  public static boolean checkToProcess(String paramString) {
    if (VERBOSE)
      System.out.println("*** PDFUtility.checkToProcess: " + paramString); 
    StringTokenizer stringTokenizer = null;
    String str = null;
    boolean bool = (new Boolean(false)).booleanValue();
    if (!paramString.isEmpty() || paramString != null) {
      str = paramString.substring(paramString.lastIndexOf(".") + 1);
      stringTokenizer = new StringTokenizer(supportedContentTypes, ",");
      while (stringTokenizer.hasMoreTokens()) {
        if (stringTokenizer.nextToken().equalsIgnoreCase(str))
          bool = true; 
      } 
    } 
    return bool;
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\quality\validation\ValidateContent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */