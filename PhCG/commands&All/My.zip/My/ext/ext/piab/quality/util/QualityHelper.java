package ext.piab.quality.util;

import ext.piab.common.util.LifecycleStateHelper;
import ext.piab.common.util.PropertyforPIAB;
import ext.piab.common.util.Teamhelper;
import ext.piab.quality.resource.QualityResource;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Random;
import java.util.Set;
import java.util.Vector;
import wt.content.ApplicationData;
import wt.content.ContentHelper;
import wt.content.ContentHolder;
import wt.content.ContentItem;
import wt.content.ContentRoleType;
import wt.content.ContentServerHelper;
import wt.doc.WTDocument;
import wt.doc.WTDocumentDependencyLink;
import wt.doc.WTDocumentHelper;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.fc.WTObject;
import wt.fc.WTReference;
import wt.inf.container.WTContained;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerHelper;
import wt.inf.container.WTContainerRef;
import wt.inf.team.ContainerTeam;
import wt.inf.team.ContainerTeamHelper;
import wt.inf.team.ContainerTeamManaged;
import wt.lifecycle.LifeCycleHelper;
import wt.lifecycle.LifeCycleManaged;
import wt.org.WTPrincipal;
import wt.org.WTPrincipalReference;
import wt.project.Role;
import wt.series.MultilevelSeries;
import wt.series.Series;
import wt.team.Team;
import wt.team.TeamHelper;
import wt.team.TeamManaged;
import wt.team.WTRoleHolder2;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.WTProperties;
import wt.util.WTPropertyVetoException;
import wt.vc.Iterated;
import wt.vc.IterationIdentifier;
import wt.vc.VersionControlHelper;
import wt.vc.VersionIdentifier;
import wt.vc.Versioned;
import wt.vc.wip.CheckoutLink;
import wt.vc.wip.WorkInProgressHelper;
import wt.vc.wip.Workable;
import wt.workflow.engine.WfEngineHelper;

public class QualityHelper {
  private static boolean VERBOSE = PropertyforPIAB.VERBOSE;
  
  public static final int SLEEP_INTERVAL = 1000;
  
  private static final int MAX_PS_GEN = PropertyforPIAB.MAX_PS_GEN;
  
  private static final String RELEASE_VERSION = PropertyforPIAB.RELEASE_VERSION;
  
  private static final String LC_RELEASED = PropertyforPIAB.LCSTATE_RELEASED;
  
  private static final String QUALITY_RESOURCE = QualityResource.class.getName();
  
  private static final String RESOURCE = "com.ptc.windchill.pdmlink.change.server.impl.implResource";
  
  private static final String LIFECYCLE_RESOURCE = "wt.lifecycle.lifecycleResource";
  
  protected static WTProperties wtProps = null;
  
  private static String wc_home = null;
  
  private static final String CLASSNAME = QualityHelper.class.getName();
  
  private static String SEC_ROLE_TYPE = WTMessage.getLocalizedMessage(QUALITY_RESOURCE, "5");
  
  public static void copyContainerTeamRolesAndUsersforQuality(WTDocument paramWTDocument, Vector<String> paramVector) {
    ArrayList arrayList = new ArrayList();
    try {
      WTContainer wTContainer = WTContainerHelper.getContainer((WTContained)paramWTDocument);
      if (VERBOSE)
        System.out.println("Obtained Container = " + wTContainer.getIdentity()); 
      ContainerTeam containerTeam = ContainerTeamHelper.service.getContainerTeam((ContainerTeamManaged)wTContainer);
      Team team1 = TeamHelper.service.getTeam((TeamManaged)paramWTDocument);
      Team team2 = team1;
      Vector vector = team2.getRoles();
      for (byte b = 0; b < paramVector.size(); b++) {
        String str = paramVector.elementAt(b);
        if (VERBOSE)
          System.out.println("Copying Role = " + str); 
        Role role = Role.toRole(str);
        arrayList = containerTeam.getAllPrincipalsForTarget(role);
        if (VERBOSE)
          System.out.println("Obtained list of users from Container Team users.size = " + arrayList.size()); 
        addPartcipantsToRole(role, arrayList, team1, paramWTDocument);
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    System.out.println("Copied to Users into Roles from Container Team to Document Team");
  }
  
  public static void addPartcipantsToRole(Role paramRole, ArrayList<WTPrincipalReference> paramArrayList, Team paramTeam, WTDocument paramWTDocument) {
    for (byte b = 0; b < paramArrayList.size(); b++) {
      WTPrincipalReference wTPrincipalReference = paramArrayList.get(b);
      try {
        WTPrincipal wTPrincipal = wTPrincipalReference.getPrincipal();
        if (VERBOSE)
          System.out.println("Adding Principal : " + wTPrincipal.getIdentity() + " to role: " + paramRole.getStringValue()); 
        TeamHelper.service.addRolePrincipalMap(paramRole, wTPrincipal, (WTRoleHolder2)paramTeam);
      } catch (Exception exception) {
        exception.printStackTrace();
      } 
    } 
    try {
      LifeCycleHelper.service.augmentRoles((LifeCycleManaged)paramWTDocument);
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  public static boolean checkIfRoleHasUsers(Role paramRole, WTDocument paramWTDocument) {
    boolean bool = false;
    try {
      Team team1 = TeamHelper.service.getTeam((TeamManaged)paramWTDocument);
      Team team2 = team1;
      Enumeration enumeration = team2.getPrincipalTarget(paramRole);
      if (VERBOSE)
        System.out.println("Checking number of users in role: " + paramRole.getStringValue()); 
      if (enumeration.hasMoreElements()) {
        if (VERBOSE)
          System.out.println("One or more users exist in role: " + paramRole.getStringValue()); 
        bool = true;
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    if (VERBOSE)
      System.out.println("Return Vaule = " + bool); 
    return bool;
  }
  
  public static Persistable getObject(String paramString) throws WTException {
    return (new ReferenceFactory()).getReference(paramString).getObject();
  }
  
  public static void carryOverDependencylink(WTObject paramWTObject) throws WTException, WTPropertyVetoException {
    WTDocument wTDocument1 = (WTDocument)paramWTObject;
    if (VERBOSE)
      System.out.println(" doc == " + wTDocument1.getIdentity()); 
    QueryResult queryResult = VersionControlHelper.service.allVersionsFrom((Versioned)wTDocument1);
    WTDocument wTDocument2 = (WTDocument)queryResult.nextElement();
    if (VERBOSE)
      System.out.println(" currentRev == " + wTDocument2.getIdentity()); 
    if (queryResult.hasMoreElements()) {
      WTDocument wTDocument = (WTDocument)queryResult.nextElement();
      QueryResult queryResult1 = WTDocumentHelper.service.getHasDependentWTDocuments(wTDocument, true);
      while (queryResult1.hasMoreElements()) {
        boolean bool = false;
        WTDocument wTDocument3 = (WTDocument)queryResult1.nextElement();
        wTDocument3 = (WTDocument)VersionControlHelper.getLatestIteration((Iterated)wTDocument3);
        if (VERBOSE)
          System.out.println(" depended Doc == " + wTDocument3.getIdentity() + " " + wTDocument3.getIterationDisplayIdentifier().toString() + " checkedout " + WorkInProgressHelper.isCheckedOut((Workable)wTDocument3)); 
        if (VERBOSE)
          System.out.println(" Is working copy? == " + WorkInProgressHelper.isWorkingCopy((Workable)wTDocument3)); 
        if (WorkInProgressHelper.isCheckedOut((Workable)wTDocument3)) {
          bool = true;
          if (!WorkInProgressHelper.isWorkingCopy((Workable)wTDocument3))
            wTDocument3 = (WTDocument)WorkInProgressHelper.service.workingCopyOf((Workable)wTDocument3); 
        } else {
          CheckoutLink checkoutLink = WorkInProgressHelper.service.checkout((Workable)wTDocument3, WorkInProgressHelper.service.getCheckoutFolder(), "");
          wTDocument3 = (WTDocument)checkoutLink.getWorkingCopy();
        } 
        QueryResult queryResult2 = WTDocumentHelper.service.getDependsOnWTDocuments(wTDocument3, false);
        HashMap hashMap = processWTDocumentDependencyLink(queryResult2);
        Set set = hashMap.keySet();
        if (VERBOSE)
          System.out.println(" dependDoc 23 == " + wTDocument3.getIdentity()); 
        if (!set.contains(wTDocument3)) {
          if (VERBOSE)
            System.out.println(" Not in the current list, system is attending to delete them..."); 
          WTDocumentDependencyLink wTDocumentDependencyLink1 = WTDocumentHelper.service.createDependencyLink(wTDocument3, wTDocument2, "");
          wTDocumentDependencyLink1 = (WTDocumentDependencyLink)PersistenceHelper.manager.refresh((Persistable)wTDocumentDependencyLink1);
          WTDocumentDependencyLink wTDocumentDependencyLink2 = (WTDocumentDependencyLink)hashMap.get(wTDocument);
          if (wTDocumentDependencyLink2 != null) {
            if (VERBOSE)
              System.out.println(" Deleting the old link... "); 
            WTDocumentHelper.service.removeDependencyLink(wTDocumentDependencyLink2);
          } else if (VERBOSE) {
            System.out.println(" No Link exists with old revision... ");
          } 
        } 
        if (!bool)
          WorkInProgressHelper.service.checkin((Workable)wTDocument3, " System Checkin after Reference Document link carry over."); 
      } 
    } 
  }
  
  public static HashMap processWTDocumentDependencyLink(QueryResult paramQueryResult) throws WTException {
    HashMap<Object, Object> hashMap = new HashMap<>();
    while (paramQueryResult.hasMoreElements()) {
      WTDocumentDependencyLink wTDocumentDependencyLink = (WTDocumentDependencyLink)paramQueryResult.nextElement();
      WTDocument wTDocument = wTDocumentDependencyLink.getDependsOn();
      hashMap.put(wTDocument, wTDocumentDependencyLink);
    } 
    return hashMap;
  }
  
  public static void copyContainerTeamRolesAndUsers(WTDocument paramWTDocument, Vector<String> paramVector) {
    if (VERBOSE)
      System.out.println("QualityHelper.copyContainerTeamRolesAndUsers()"); 
    try {
      WTContainer wTContainer = WTContainerHelper.getContainer((WTContained)paramWTDocument);
      Team team = TeamHelper.service.getTeam((TeamManaged)paramWTDocument);
      for (byte b = 0; b < paramVector.size(); b++) {
        String str = paramVector.elementAt(b);
        if (VERBOSE)
          System.out.println("Copying Role = " + str); 
        Role role = Role.toRole(str);
        ArrayList arrayList = Teamhelper.getParticipants((ContainerTeamManaged)wTContainer, role);
        Teamhelper.copyUsers(team, role, arrayList);
        if (VERBOSE)
          System.out.println("Obtained list of users from Container Team users.size = " + arrayList.size()); 
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    System.out.println("Copied to Users into Roles from Container Team to Document Team");
  }
  
  public static void removePreviousAttach(WTDocument paramWTDocument) {
    if (VERBOSE)
      System.out.println("QualityHelper.removePreviousAttach()"); 
    try {
      String str1 = "";
      String str2 = paramWTDocument.getNumber() + "-";
      if (VERBOSE)
        System.out.println("existAttachname- " + str2); 
      QueryResult queryResult = ContentHelper.service.getContentsByRole((ContentHolder)paramWTDocument, ContentRoleType.toContentRoleType(SEC_ROLE_TYPE));
      while (queryResult.hasMoreElements()) {
        ApplicationData applicationData = (ApplicationData)queryResult.nextElement();
        str1 = applicationData.getFileName();
        if (VERBOSE)
          System.out.println("current file name - " + str1); 
        if (str1.startsWith(str2)) {
          if (VERBOSE)
            System.out.println("deleting file- " + str1); 
          ContentServerHelper.service.deleteContent((ContentHolder)paramWTDocument, (ContentItem)applicationData);
        } 
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  public static WTDocument docRevise(WTDocument paramWTDocument) throws Exception {
    if (VERBOSE)
      System.out.println("QualityHelper.docRevise " + paramWTDocument); 
    if (VersionControlHelper.service.isRevisable((Versioned)paramWTDocument, true)) {
      WTContainerRef wTContainerRef = WTContainerHelper.getContainerRef((WTContained)paramWTDocument);
      Series series = null;
      series = VersionControlHelper.getSeries(paramWTDocument.getClass(), wTContainerRef);
      System.out.println("ser........:: " + series.getUniqueSeriesName());
      series.setValueWithoutValidating(RELEASE_VERSION);
      VersionIdentifier versionIdentifier = VersionIdentifier.newVersionIdentifier((MultilevelSeries)series);
      IterationIdentifier iterationIdentifier = VersionControlHelper.firstIterationId((Iterated)paramWTDocument);
      paramWTDocument = (WTDocument)VersionControlHelper.service.newVersion((Versioned)paramWTDocument, versionIdentifier, iterationIdentifier);
      paramWTDocument = (WTDocument)PersistenceHelper.manager.save((Persistable)paramWTDocument);
      paramWTDocument = (WTDocument)PersistenceHelper.manager.refresh((Persistable)paramWTDocument);
      System.out.println("Document revised to :" + paramWTDocument.getVersionIdentifier().getValue());
      return paramWTDocument;
    } 
    throw new Exception("Object " + paramWTDocument + " cannot be revised ");
  }
  
  public static File createDirectory(String paramString) throws IOException {
    if (VERBOSE)
      System.out.println("*** QualityHelper.createDirectory: 1"); 
    Random random = new Random();
    File file = new File(paramString + "//" + random.nextInt(5000));
    file.mkdir();
    return file;
  }
  
  public static WTDocument releaseDoc(WTDocument paramWTDocument) throws Exception {
    if (VERBOSE)
      System.out.println("***QualityHelper.releaseDoc()"); 
    String str1 = paramWTDocument.getVersionIdentifier().getValue();
    if (!Character.isDigit(RELEASE_VERSION.charAt(0))) {
      if (Character.isDigit(str1.charAt(0))) {
        paramWTDocument = docRevise(paramWTDocument);
        if (VERBOSE)
          System.out.println("*WF Revised Document has been Revised " + paramWTDocument.getName() + "REV- " + paramWTDocument.getVersionIdentifier().getValue()); 
        WfEngineHelper.service.terminateObjectsRunningWorkflows((Persistable)paramWTDocument);
      } 
    } else if (Character.isDigit(RELEASE_VERSION.charAt(0)) && !Character.isDigit(str1.charAt(0))) {
      paramWTDocument = docRevise(paramWTDocument);
      if (VERBOSE)
        System.out.println("*WF Revised Document has been Revised " + paramWTDocument.getName() + "REV- " + paramWTDocument.getVersionIdentifier().getValue()); 
      WfEngineHelper.service.terminateObjectsRunningWorkflows((Persistable)paramWTDocument);
    } 
    paramWTDocument = (WTDocument)LifecycleStateHelper.setLifecycleState((Persistable)paramWTDocument, LC_RELEASED);
    String str2 = paramWTDocument.getNumber();
    String str3 = paramWTDocument.getVersionIdentifier().getValue().toString() + "." + paramWTDocument.getIterationIdentifier().getValue().toString();
    QualityUtil.processRepresentation(str2, str3);
    return paramWTDocument;
  }
  
  public static void removeDirectory(File paramFile) throws Exception {
    if (VERBOSE)
      System.out.println("*** QualityHelper.removeDirectory: " + paramFile.getName()); 
    File[] arrayOfFile = paramFile.listFiles();
    boolean bool = false;
    byte b1 = 0;
    if (VERBOSE)
      System.out.print("\n"); 
    for (byte b2 = 0; b2 < arrayOfFile.length; b2++) {
      File file = arrayOfFile[b2];
      if (file.isDirectory()) {
        removeDirectory(file);
      } else if (file.exists()) {
        if (VERBOSE)
          System.out.print("***deleting: " + file.getAbsolutePath()); 
        bool = file.delete();
        if (VERBOSE)
          System.out.println("***canExecute: " + file.canExecute() + "canWrite: " + file.canWrite()); 
        while (file.exists()) {
          bool = file.delete();
          Thread.currentThread();
          Thread.sleep(1000L);
          if (b1++ >= MAX_PS_GEN)
            throw new WTException("***** ERROR: File deletion exceeded allowable time limit ****"); 
        } 
        if (VERBOSE)
          System.out.print(bool ? "...DELETED\n" : "...UNABLE TO DELETE\n"); 
      } 
    } 
    if (VERBOSE)
      System.out.print("*** deleting: " + paramFile.getAbsolutePath()); 
    bool = paramFile.delete();
    if (VERBOSE)
      System.out.print(bool ? "...DELETED\n" : "...UNABLE TO DELETE\n"); 
  }
  
  public static void main(String[] paramArrayOfString) {
    try {
      String str = "wt.doc.WTDocument:47881771";
      if (VERBOSE)
        System.out.println("Copy Team"); 
      WTReference wTReference = (new ReferenceFactory()).getReference(str);
      Persistable persistable = ObjectReference.newObjectReference((ObjectReference)wTReference).getObject();
      WTDocument wTDocument = (WTDocument)persistable;
      if (VERBOSE)
        System.out.println("Obtained Document: " + wTDocument.getIdentity()); 
      Vector<String> vector = new Vector();
      vector.add(0, new String("QUALITY MANAGER"));
      vector.add(1, new String("MANAGEMENT APPROVER"));
      copyContainerTeamRolesAndUsers(wTDocument, vector);
      if (VERBOSE)
        System.out.println("Copy Roles complete"); 
    } catch (WTException wTException) {
      wTException.printStackTrace();
    } finally {
      System.exit(0);
    } 
  }
  
  static {
    try {
      wtProps = WTProperties.getLocalProperties();
      wc_home = wtProps.getProperty("wt.home");
    } catch (Exception exception) {
      System.out.println("####### " + CLASSNAME + " :: Error reading property file.");
    } 
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\qualit\\util\QualityHelper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */