package ext.piab.quality.util;

import ext.piab.common.util.PropertyforPIAB;
import ext.piab.quality.resource.QualityResource;
import ext.piab.quality.validation.ValidateContent;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import wt.content.ApplicationData;
import wt.content.ContentHelper;
import wt.content.ContentHolder;
import wt.content.ContentRoleType;
import wt.content.ContentServerHelper;
import wt.doc.WTDocument;
import wt.fc.QueryResult;
import wt.representation.Representable;
import wt.representation.Representation;
import wt.representation.RepresentationHelper;
import wt.util.WTException;
import wt.util.WTMessage;

public class DownloadContent {
  private static final boolean VERBOSE = PropertyforPIAB.VERBOSE;
  
  private static final int SLEEP_INTERVAL = 1000;
  
  private static final int MAX_PS_GEN = PropertyforPIAB.MAX_PS_GEN;
  
  private static final String QUALITY_RESOURCE = QualityResource.class.getName();
  
  private static String PRI_FOLDER_NAME = WTMessage.getLocalizedMessage(QUALITY_RESOURCE, "3");
  
  private static String PRI_ROLE_TYPE = WTMessage.getLocalizedMessage(QUALITY_RESOURCE, "4");
  
  private static String SEC_ROLE_TYPE = WTMessage.getLocalizedMessage(QUALITY_RESOURCE, "5");
  
  public static File getPrimaryFile(ContentHolder paramContentHolder, File paramFile) {
    if (VERBOSE)
      System.out.println("***DownloadContent.getPrimaryFile()"); 
    String str = "";
    File file1 = null;
    File file2 = null;
    paramFile = new File(paramFile + "//" + PRI_FOLDER_NAME);
    paramFile.mkdir();
    try {
      ContentRoleType contentRoleType = ContentRoleType.toContentRoleType(PRI_ROLE_TYPE);
      QueryResult queryResult = ContentHelper.service.getContentsByRole(paramContentHolder, contentRoleType);
      if (queryResult.size() == 0)
        System.out.println("***Primary Content File NOT EXIST for processing."); 
      while (queryResult.hasMoreElements()) {
        ApplicationData applicationData = (ApplicationData)queryResult.nextElement();
        str = applicationData.getFileName();
        if (!str.isEmpty() || str != null) {
          if (ValidateContent.checkToProcess(str)) {
            file1 = new File(paramFile, str);
            ContentServerHelper.service.writeContentStream(applicationData, file1.getAbsolutePath());
            File[] arrayOfFile = QualityUtil.getFilteredFiles(paramFile, str.substring(str.lastIndexOf(".") + 1));
            byte b = 0;
            while (true) {
              if (arrayOfFile.length == 0 || !arrayOfFile[0].exists() || !arrayOfFile[0].canWrite()) {
                Thread.sleep(1000L);
                if (VERBOSE)
                  System.out.print("."); 
                if (b++ >= MAX_PS_GEN)
                  throw new WTException("***** ERROR: Primary file download exceeded allowable time limit ****"); 
                arrayOfFile = QualityUtil.getFilteredFiles(paramFile, str.substring(str.lastIndexOf(".") + 1));
                continue;
              } 
              file2 = arrayOfFile[0];
            } 
          } 
          System.out.println("*** WTDOCUMENT [" + ((WTDocument)paramContentHolder).getNumber() + "]  Primary Content File Extension [" + str.substring(str.lastIndexOf(".") + 1) + "] NOT SUPPORTED for processing.");
        } 
      } 
    } catch (WTException wTException) {
      wTException.printStackTrace();
    } catch (IOException iOException) {
      iOException.printStackTrace();
    } catch (InterruptedException interruptedException) {
      interruptedException.printStackTrace();
    } 
    return file2;
  }
  
  public static ArrayList<Object> getRepresentation(Representable paramRepresentable, String paramString) throws Exception, IOException, InvocationTargetException {
    if (VERBOSE)
      System.out.println("DownloadContent.getRepresentation"); 
    ArrayList<ApplicationData> arrayList = new ArrayList();
    QueryResult queryResult = RepresentationHelper.service.getRepresentations(paramRepresentable);
    if (VERBOSE)
      System.out.println("*** Representation size: " + queryResult.size()); 
    while (queryResult.hasMoreElements()) {
      Representation representation = (Representation)queryResult.nextElement();
      if (VERBOSE)
        System.out.println("*** Representation Name: " + representation + " name: " + representation.getName()); 
      ContentRoleType contentRoleType = ContentRoleType.toContentRoleType(SEC_ROLE_TYPE);
      QueryResult queryResult1 = ContentHelper.service.getContentsByRole((ContentHolder)representation, contentRoleType);
      while (queryResult1.hasMoreElements()) {
        ApplicationData applicationData = (ApplicationData)queryResult1.nextElement();
        String str = applicationData.getFileName();
        if (str.equalsIgnoreCase(paramString)) {
          if (VERBOSE)
            System.out.println("*** Representation exist : " + str); 
          arrayList.add(applicationData);
          arrayList.add(representation);
        } 
      } 
    } 
    return (ArrayList)arrayList;
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\qualit\\util\DownloadContent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */