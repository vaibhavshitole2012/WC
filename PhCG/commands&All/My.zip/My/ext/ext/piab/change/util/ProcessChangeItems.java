package ext.piab.change.util;

import ext.piab.common.util.LifecycleStateHelper;
import ext.piab.common.util.PropertyforPIAB;
import ext.piab.common.util.ReviseUtility;
import java.util.Vector;
import wt.change2.ChangeActivityIfc;
import wt.change2.ChangeHelper2;
import wt.change2.ChangeItem;
import wt.change2.ChangeItemIfc;
import wt.change2.ChangeOrderIfc;
import wt.change2.ChangeRecord2;
import wt.change2.ChangeRequestIfc;
import wt.change2.Changeable2;
import wt.change2.WTChangeActivity2;
import wt.change2.WTChangeOrder2;
import wt.change2.WTChangeRequest2;
import wt.enterprise.RevisionControlled;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.WTObject;
import wt.fc.collections.WTArrayList;
import wt.util.WTException;
import wt.vc.VersionControlHelper;
import wt.vc.Versioned;
import wt.vc.wip.WorkInProgressHelper;
import wt.vc.wip.Workable;

public class ProcessChangeItems {
  private static final boolean VERBOSE = PropertyforPIAB.VERBOSE;
  
  private static final String RELEASE_VERSION = PropertyforPIAB.RELEASE_VERSION;
  
  public static void deleteObsoleteItems(WTChangeOrder2 paramWTChangeOrder2, WTChangeActivity2 paramWTChangeActivity2) throws Exception {
    if (VERBOSE)
      System.out.println("***ProcessChangeItems.deleteObsoleteItems()"); 
    try {
      QueryResult queryResult = ChangeHelper2.service.getChangeablesAfter((ChangeOrderIfc)paramWTChangeOrder2);
      if (VERBOSE)
        System.out.println("***QueryResult Size " + queryResult.size()); 
      while (queryResult.hasMoreElements()) {
        Changeable2 changeable2 = (Changeable2)queryResult.nextElement();
        ChangeHelper2.service.unattachChangeable(changeable2, (ChangeItem)paramWTChangeActivity2, ChangeRecord2.class, "roleBObject");
        ChangeHelper2.service.saveChangeActivity((ChangeOrderIfc)paramWTChangeOrder2, (ChangeActivityIfc)paramWTChangeActivity2);
        if (VERBOSE)
          System.out.println("*** Resulting Data Association Removed "); 
        PersistenceHelper.manager.delete((Persistable)changeable2);
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  public static Vector replaceResultingObjs(WTChangeOrder2 paramWTChangeOrder2) {
    if (VERBOSE)
      System.out.println("***ProcessChangeItems.replaceResultingObjs()"); 
    Vector<WTObject> vector = new Vector();
    WTChangeActivity2 wTChangeActivity2 = WTChangeUtility.getDefaultTask(paramWTChangeOrder2);
    try {
      QueryResult queryResult = ChangeHelper2.service.getChangeablesAfter((ChangeOrderIfc)paramWTChangeOrder2);
      if (VERBOSE)
        System.out.println("***size of resulting objs " + queryResult.size()); 
      while (queryResult.hasMoreElements()) {
        WTObject wTObject = (WTObject)queryResult.nextElement();
        String str = ((RevisionControlled)wTObject).getVersionInfo().getIdentifier().getValue();
        if (VERBOSE)
          System.out.println("***version of current change obj " + ((RevisionControlled)wTObject).getName() + " Rev- " + str); 
        if (!Character.isDigit(RELEASE_VERSION.charAt(0))) {
          if (Character.isDigit(str.charAt(0))) {
            replace(vector, wTChangeActivity2, wTObject, str);
            continue;
          } 
          if (VERBOSE)
            System.out.println("Current obj " + ((RevisionControlled)wTObject).getName() + " rivision " + str); 
          continue;
        } 
        if (Character.isDigit(str.charAt(0))) {
          if (!Character.isDigit(str.charAt(0))) {
            replace(vector, wTChangeActivity2, wTObject, str);
            continue;
          } 
          if (VERBOSE)
            System.out.println("Current obj " + ((RevisionControlled)wTObject).getName() + " rivision " + str); 
        } 
      } 
      if (VERBOSE)
        System.out.println("***Resulting Objects are replaced successfully"); 
    } catch (Exception exception) {
      if (VERBOSE)
        System.out.println("*** Exception while replacing Resulting Objects of " + wTChangeActivity2.getName()); 
    } 
    return vector;
  }
  
  private static void replace(Vector<WTObject> paramVector, WTChangeActivity2 paramWTChangeActivity2, WTObject paramWTObject, String paramString) throws Exception {
    if (VERBOSE)
      System.out.println("***ProcessChangeItems.replace()"); 
    QueryResult queryResult = VersionControlHelper.service.allVersionsOf((Versioned)paramWTObject);
    if (VERBOSE)
      System.out.println("*** Revisions of resulting obj " + queryResult.size()); 
    while (queryResult.hasMoreElements()) {
      WTObject wTObject = (WTObject)queryResult.nextElement();
      String str = ((RevisionControlled)wTObject).getVersionInfo().getIdentifier().getValue();
      if (VERBOSE)
        System.out.println("***New Object " + ((RevisionControlled)wTObject).getName() + " New Revision " + str); 
      if (str.equalsIgnoreCase(RELEASE_VERSION)) {
        if (VERBOSE)
          System.out.println("***Replacing Object" + ((RevisionControlled)paramWTObject).getName() + " Revision " + paramString); 
        ChangeHelper2.service.unattachChangeable((Changeable2)paramWTObject, (ChangeItem)paramWTChangeActivity2, ChangeRecord2.class, "roleBObject");
        paramVector.add(wTObject);
        ChangeHelper2.service.storeAssociations(ChangeRecord2.class, (ChangeItemIfc)paramWTChangeActivity2, paramVector);
        if (VERBOSE)
          System.out.println("***NEW Resulting Object" + ((RevisionControlled)wTObject).getName() + " Revision " + str); 
        break;
      } 
    } 
  }
  
  public static WTArrayList reviseResData(WTChangeOrder2 paramWTChangeOrder2) throws Exception {
    if (VERBOSE)
      System.out.println("***ProcessChangeItems.reviseResData()"); 
    WTArrayList wTArrayList = new WTArrayList();
    try {
      wTArrayList = WTChangeUtility.addObjectstoArray((Persistable)paramWTChangeOrder2, true);
      ReviseUtility.reviseAll(wTArrayList);
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return wTArrayList;
  }
  
  public static void setchangeItemsState(WTChangeOrder2 paramWTChangeOrder2, String paramString) throws Exception {
    if (VERBOSE)
      System.out.println("***ProcessChangeItems.setchangeItemsState()"); 
    Changeable2 changeable2 = null;
    QueryResult queryResult = ChangeHelper2.service.getChangeablesAfter((ChangeOrderIfc)paramWTChangeOrder2);
    if (VERBOSE)
      System.out.println("***QueryResult Size  " + queryResult.size()); 
    while (queryResult.hasMoreElements()) {
      changeable2 = (Changeable2)queryResult.nextElement();
      String str = ((RevisionControlled)changeable2).getVersionIdentifier().getValue();
      if (VERBOSE)
        System.out.println("***Changing life cycle state of " + changeable2 + "--" + str + " with state" + paramString); 
      changeable2 = (Changeable2)LifecycleStateHelper.setLifecycleState((Persistable)changeable2, paramString);
    } 
  }
  
  public static void setchangeItemsState(WTChangeActivity2 paramWTChangeActivity2, String paramString) throws Exception {
    if (VERBOSE)
      System.out.println("***ProcessChangeItems.setchangeItemsState()"); 
    Changeable2 changeable2 = null;
    QueryResult queryResult = ChangeHelper2.service.getChangeablesAfter((ChangeActivityIfc)paramWTChangeActivity2, true);
    if (VERBOSE)
      System.out.println("***QueryResult Size  " + queryResult.size()); 
    while (queryResult.hasMoreElements()) {
      changeable2 = (Changeable2)queryResult.nextElement();
      String str = ((RevisionControlled)changeable2).getVersionIdentifier().getValue();
      if (VERBOSE)
        System.out.println("***Changing life cycle state of " + changeable2 + "--" + str + " with state" + paramString); 
      changeable2 = (Changeable2)LifecycleStateHelper.setLifecycleState((Persistable)changeable2, paramString);
    } 
  }
  
  public static Vector replaceNewResultingObjs(WTChangeOrder2 paramWTChangeOrder2) {
    if (VERBOSE)
      System.out.println("***ProcessChangeItems.replaceNewResultingObjs()"); 
    Vector<WTObject> vector = new Vector();
    WTArrayList wTArrayList = getChangeActivities(paramWTChangeOrder2);
    if (VERBOSE)
      System.out.println("***ProcessChangeItems.getChangeActivities for ECN = " + paramWTChangeOrder2.getIdentity()); 
    Object[] arrayOfObject = wTArrayList.toArray();
    for (byte b = 0; b < arrayOfObject.length; b++) {
      ObjectReference objectReference = (ObjectReference)arrayOfObject[b];
      WTChangeActivity2 wTChangeActivity2 = (WTChangeActivity2)objectReference.getObject();
      if (VERBOSE)
        System.out.println("***ProcessChangeItems.replaceNewResultingObjs for Change Activity: " + wTChangeActivity2.getIdentity()); 
      try {
        QueryResult queryResult = ChangeHelper2.service.getChangeablesAfter((ChangeActivityIfc)wTChangeActivity2);
        if (VERBOSE)
          System.out.println("***size of resulting objs " + queryResult.size()); 
        while (queryResult.hasMoreElements()) {
          WTObject wTObject = (WTObject)queryResult.nextElement();
          String str = ((RevisionControlled)wTObject).getVersionInfo().getIdentifier().getValue();
          if (VERBOSE)
            System.out.println("***version of current change obj " + ((RevisionControlled)wTObject).getName() + " Rev- " + str); 
          if (!Character.isDigit(RELEASE_VERSION.charAt(0))) {
            if (Character.isDigit(str.charAt(0))) {
              replace(vector, wTChangeActivity2, wTObject, str);
              continue;
            } 
            if (VERBOSE)
              System.out.println("Current obj " + ((RevisionControlled)wTObject).getName() + " rivision " + str); 
            continue;
          } 
          if (Character.isDigit(str.charAt(0))) {
            if (!Character.isDigit(str.charAt(0))) {
              replace(vector, wTChangeActivity2, wTObject, str);
              continue;
            } 
            if (VERBOSE)
              System.out.println("Current obj " + ((RevisionControlled)wTObject).getName() + " rivision " + str); 
          } 
        } 
        if (VERBOSE)
          System.out.println("***Resulting Objects are replaced successfully for Change Activity: " + wTChangeActivity2.getIdentity()); 
      } catch (Exception exception) {
        if (VERBOSE)
          System.out.println("*** Exception while replacing Resulting Objects of: " + wTChangeActivity2.getIdentity()); 
      } 
    } 
    return vector;
  }
  
  public static WTArrayList getChangeActivities(WTChangeOrder2 paramWTChangeOrder2) {
    if (VERBOSE)
      System.out.println("***ProcessChangeItems.getChangeActivities(" + paramWTChangeOrder2.getName() + ")"); 
    WTArrayList wTArrayList = new WTArrayList();
    try {
      QueryResult queryResult = ChangeHelper2.service.getChangeActivities((ChangeOrderIfc)paramWTChangeOrder2);
      if (VERBOSE)
        System.out.println("***activity size for changeNotice [" + paramWTChangeOrder2 + "] are [" + queryResult.size() + "]"); 
      while (queryResult.hasMoreElements()) {
        WTChangeActivity2 wTChangeActivity2 = (WTChangeActivity2)queryResult.nextElement();
        wTArrayList.add((Persistable)wTChangeActivity2);
      } 
    } catch (Exception exception) {
      if (VERBOSE)
        System.out.println("***Exception while getting Change activities of " + paramWTChangeOrder2.getNumber()); 
    } 
    if (VERBOSE)
      System.out.println("***Returning  Activities - " + wTArrayList); 
    return wTArrayList;
  }
  
  public static void checkIfResultingObjectsCheckedOut(WTChangeRequest2 paramWTChangeRequest2) throws Exception {
    if (VERBOSE)
      System.out.println("***ProcessChangeItems.checkIfResultingObjectsCheckedOut()"); 
    boolean bool = false;
    String str = "***One of the Items in the Change Request is checked out.";
    QueryResult queryResult = ChangeHelper2.service.getChangeables((ChangeRequestIfc)paramWTChangeRequest2, true);
    while (queryResult.hasMoreElements()) {
      WTObject wTObject = (WTObject)queryResult.nextElement();
      bool = WorkInProgressHelper.isCheckedOut((Workable)wTObject);
      if (bool) {
        if (VERBOSE)
          System.out.println(str); 
        throw new WTException(str);
      } 
    } 
  }
  
  public static void checkIfResultingObjectsCheckedOut(WTChangeOrder2 paramWTChangeOrder2) throws Exception {
    if (VERBOSE)
      System.out.println("***ProcessChangeItems.checkIfResultingObjectsCheckedOut()"); 
    boolean bool = false;
    String str = "***One of the Items in the Change Notice is checked out.";
    QueryResult queryResult = ChangeHelper2.service.getChangeablesAfter((ChangeOrderIfc)paramWTChangeOrder2, true);
    while (queryResult.hasMoreElements()) {
      WTObject wTObject = (WTObject)queryResult.nextElement();
      bool = WorkInProgressHelper.isCheckedOut((Workable)wTObject);
      if (bool) {
        if (VERBOSE)
          System.out.println(str); 
        throw new WTException(str);
      } 
    } 
  }
  
  public static void checkIfResultingObjectsCheckedOut(WTChangeActivity2 paramWTChangeActivity2) throws Exception {
    if (VERBOSE)
      System.out.println("***ProcessChangeItems.checkIfResultingObjectsCheckedOut()"); 
    boolean bool = false;
    String str = "***One of the Items in the Change Notice is checked out.";
    QueryResult queryResult = ChangeHelper2.service.getChangeablesAfter((ChangeActivityIfc)paramWTChangeActivity2, true);
    while (queryResult.hasMoreElements()) {
      WTObject wTObject = (WTObject)queryResult.nextElement();
      bool = WorkInProgressHelper.isCheckedOut((Workable)wTObject);
      if (bool) {
        if (VERBOSE)
          System.out.println(str); 
        throw new WTException(str);
      } 
    } 
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\chang\\util\ProcessChangeItems.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */