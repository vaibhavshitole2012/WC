/*    */ package ext.piab.change.validation;
/*    */ import ext.piab.change.resource.ChangeResource;
/*    */ import ext.piab.common.util.PropertyforPIAB;
/*    */ import java.util.Enumeration;
/*    */ import wt.access.AccessControlHelper;
/*    */ import wt.access.AccessPermission;
/*    */ import wt.change2.ChangeHelper2;
/*    */ import wt.change2.ChangeRequestIfc;
/*    */ import wt.change2.Changeable2;
/*    */ import wt.change2.WTChangeRequest2;
/*    */ import wt.fc.Persistable;
/*    */ import wt.fc.QueryResult;
/*    */ import wt.fc.collections.WTArrayList;
/*    */ import wt.fc.collections.WTCollection;
/*    */ import wt.org.WTPrincipal;
/*    */ import wt.org.WTPrincipalReference;
/*    */ import wt.project.Role;
/*    */ import wt.session.SessionServerHelper;
/*    */ import wt.team.Team;
/*    */ import wt.team.TeamException;
/*    */ import wt.team.TeamHelper;
/*    */ import wt.team.TeamManaged;
/*    */ import wt.util.WTException;
/*    */ 
/*    */ public class ChangeRequestValidations {
/* 26 */   private static final String CHANGE_RESOURCE = ChangeResource.class.getName();
/* 27 */   private static final boolean VERBOSE = PropertyforPIAB.VERBOSE;
/*    */ 
/*    */ 
/*    */   
/*    */   public static void checkAccess(WTChangeRequest2 request) throws WTException {
/* 32 */     if (VERBOSE) System.out.println("*** ChangeRequestValidations.checkAccess ");
/*    */     
/*    */     try {
/* 35 */       boolean hasModifyAccess = false;
/* 36 */       boolean hasModifContentAccess = false;
/* 37 */       WTArrayList list = new WTArrayList();
/* 38 */       Changeable2 chObj = null;
/* 39 */       QueryResult queryRes = ChangeHelper2.service.getChangeables((ChangeRequestIfc)request);
/* 40 */       if (VERBOSE) System.out.println("*** Query Result.Size " + queryRes.size()); 
/* 41 */       while (queryRes.hasMoreElements()) {
/*    */         
/* 43 */         chObj = (Changeable2)queryRes.nextElement();
/* 44 */         list.add((Persistable)chObj);
/*    */       } 
/* 46 */       boolean isAccess = SessionServerHelper.manager.isAccessEnforced();
/* 47 */       if (!isAccess)
/* 48 */         SessionServerHelper.manager.setAccessEnforced(true); 
/* 49 */       Team changeTeam = TeamHelper.service.getTeam((TeamManaged)request);
/* 50 */       Role role = Role.toRole("ENGINEERING MANAGER");
/* 51 */       if (VERBOSE) System.out.println("Role: " + role.getDisplay()); 
/* 52 */       Enumeration<WTPrincipalReference> enu = changeTeam.getPrincipalTarget(role);
/* 53 */       while (enu.hasMoreElements()) {
/*    */         
/* 55 */         hasModifyAccess = false;
/* 56 */         hasModifContentAccess = false;
/* 57 */         WTPrincipalReference priRef = enu.nextElement();
/* 58 */         WTPrincipal principal = priRef.getPrincipal();
/* 59 */         if (VERBOSE) System.out.println("*****Principal: " + principal.getName()); 
/* 60 */         hasModifyAccess = AccessControlHelper.manager.hasAccess(principal, (WTCollection)list, AccessPermission.MODIFY);
/* 61 */         hasModifContentAccess = AccessControlHelper.manager.hasAccess(principal, chObj, AccessPermission.MODIFY_CONTENT);
/* 62 */         if (VERBOSE) System.out.println("****Hasmodify: " + hasModifyAccess + " Hasmodifycontent: " + hasModifContentAccess); 
/* 63 */         if (hasModifyAccess && hasModifContentAccess) {
/*    */           
/* 65 */           if (VERBOSE) System.out.println(principal.getName() + " [" + principal + "] has Modify and Modify Content Access"); 
/*    */           break;
/*    */         } 
/*    */       } 
/* 69 */       SessionServerHelper.manager.setAccessEnforced(isAccess);
/* 70 */       if (!hasModifyAccess || !hasModifContentAccess)
/*    */       {
/* 72 */         Object[] aObj = { role.getDisplay() };
/* 73 */         throw new WTException(CHANGE_RESOURCE, "10", aObj);
/*    */       }
/*    */     
/* 76 */     } catch (TeamException e) {
/*    */ 
/*    */       
/* 79 */       e.printStackTrace();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\change\validation\ChangeRequestValidations.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */