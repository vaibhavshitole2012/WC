package ext.piab.change.variance;

import ext.piab.common.util.PropertyforPIAB;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import wt.fc.ReferenceFactory;
import wt.fc.WTObject;
import wt.iba.definition.litedefinition.AttributeDefDefaultView;
import wt.iba.value.DefaultAttributeContainer;
import wt.iba.value.IBAHolder;
import wt.iba.value.IBAValueUtility;
import wt.iba.value.ReferenceValue;
import wt.iba.value.litevalue.AbstractValueView;
import wt.iba.value.litevalue.ReferenceValueDefaultView;
import wt.iba.value.litevalue.TimestampValueDefaultView;
import wt.iba.value.service.IBAValueHelper;
import wt.session.SessionHelper;
import wt.workflow.work.WfAssignedActivity;

public class VarianceWorkflowUtil {
  private static final boolean VERBOSE = PropertyforPIAB.VERBOSE;
  
  public static void setActivityDeadline(WTObject paramWTObject1, WTObject paramWTObject2, int paramInt) throws Exception {
    if (VERBOSE)
      System.out.println("***VarianceWorkflowUtil.setActivityDeadline()"); 
    WfAssignedActivity wfAssignedActivity = (WfAssignedActivity)paramWTObject1;
    long l = (paramInt * 24 * 60 * 60 * 1000);
    String str = getIBAValue((IBAHolder)paramWTObject2, "END_DATE");
    if (VERBOSE)
      System.out.println("End Date -- " + str); 
    if (str != null && !str.trim().equals("")) {
      SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.SSS");
      Date date = simpleDateFormat.parse(str);
      long l1 = date.getTime();
      Timestamp timestamp = new Timestamp(l1);
      if (VERBOSE)
        System.out.println("***deadLine = " + timestamp.toLocaleString()); 
      wfAssignedActivity.changeDeadline(timestamp);
      wfAssignedActivity.setAlertTime(l1 - l);
      if (VERBOSE)
        System.out.println("###Deadline is set == " + wfAssignedActivity.getDeadline()); 
    } 
  }
  
  public static String getIBAValue(IBAHolder paramIBAHolder, String paramString) {
    String str = null;
    try {
      paramIBAHolder = IBAValueHelper.service.refreshAttributeContainer(paramIBAHolder, null, SessionHelper.manager.getLocale(), null);
      DefaultAttributeContainer defaultAttributeContainer = (DefaultAttributeContainer)paramIBAHolder.getAttributeContainer();
      if (defaultAttributeContainer != null) {
        AttributeDefDefaultView[] arrayOfAttributeDefDefaultView = defaultAttributeContainer.getAttributeDefinitions();
        for (byte b = 0; b < arrayOfAttributeDefDefaultView.length; b++) {
          if (arrayOfAttributeDefDefaultView[b].getName().equals(paramString)) {
            AbstractValueView[] arrayOfAbstractValueView = defaultAttributeContainer.getAttributeValues(arrayOfAttributeDefDefaultView[b]);
            if (arrayOfAbstractValueView != null)
              for (byte b1 = 0; b1 < arrayOfAbstractValueView.length; b1++) {
                System.out.println(" ***Inside the get IBA Value method " + (arrayOfAbstractValueView[b1] instanceof TimestampValueDefaultView) + " && " + arrayOfAbstractValueView[b1].toString());
                if (arrayOfAbstractValueView[b1] instanceof TimestampValueDefaultView) {
                  str = ((TimestampValueDefaultView)arrayOfAbstractValueView[b1]).getValue().toString();
                  System.out.println(" ****Time stamp of the attribute is -- " + str);
                } else if (arrayOfAbstractValueView[b1] instanceof ReferenceValueDefaultView) {
                  String str1 = ((ReferenceValueDefaultView)arrayOfAbstractValueView[b1]).getObjectID().toString();
                  ReferenceValue referenceValue = (ReferenceValue)(new ReferenceFactory()).getReference(str1).getObject();
                  str = referenceValue.getValueObject().toString();
                } else if (str == null) {
                  str = IBAValueUtility.getLocalizedIBAValueDisplayString(arrayOfAbstractValueView[b1], SessionHelper.manager.getLocale());
                } else {
                  str = str + "," + IBAValueUtility.getLocalizedIBAValueDisplayString(arrayOfAbstractValueView[b1], SessionHelper.manager.getLocale());
                } 
              }  
          } 
        } 
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return str;
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\change\variance\VarianceWorkflowUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */