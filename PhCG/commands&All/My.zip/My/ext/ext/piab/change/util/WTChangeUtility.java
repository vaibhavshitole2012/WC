package ext.piab.change.util;

import com.ptc.windchill.enterprise.change2.ChangeManagementClientHelper;
import com.ptc.windchill.wp.AbstractWorkPackage;
import com.ptc.windchill.wp.WorkPackage;
import ext.piab.change.request.ChangeRequestHandler;
import ext.piab.common.util.PropertyforPIAB;
import java.util.Collection;
import java.util.HashMap;
import java.util.Vector;
import wt.change2.ChangeHelper2;
import wt.change2.ChangeOrderIfc;
import wt.change2.ChangeRequestIfc;
import wt.change2.Changeable2;
import wt.change2.WTChangeActivity2;
import wt.change2.WTChangeOrder2;
import wt.change2.WTChangeRequest2;
import wt.enterprise.RevisionControlled;
import wt.facade.persistedcollection.PersistedCollectionHelper;
import wt.facade.persistedcollection.PersistedCollectionMembership;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.fc.WTObject;
import wt.fc.collections.WTArrayList;
import wt.fc.collections.WTSet;
import wt.type.TypedUtility;

public class WTChangeUtility {
  private static final boolean VERBOSE = PropertyforPIAB.VERBOSE;
  
  private static final String DESIGN_PACKAGE_TYPE_NAME = PropertyforPIAB.DESIGN_PACKAGE_TYPE_NAME;
  
  private static final String LCSTATE_COMPLETED = PropertyforPIAB.LCSTATE_COMPLETED;
  
  private static final String VALIDSTATES_DESIGN_PKG = PropertyforPIAB.VALIDSTATES_DESIGN_PKG;
  
  public static void oldVersioninPkg(WTChangeOrder2 paramWTChangeOrder2) {
    if (VERBOSE)
      System.out.println("WTChangeUtility.oldVersioninPkg()"); 
    HashMap hashMap = new HashMap();
    try {
      QueryResult queryResult = ChangeHelper2.service.getChangeablesBefore((ChangeOrderIfc)paramWTChangeOrder2);
      while (queryResult.hasMoreElements()) {
        Changeable2 changeable2 = (Changeable2)queryResult.nextElement();
        String str = ((RevisionControlled)changeable2).getVersionIdentifier().getValue();
        if (VERBOSE)
          System.out.println("***This is the Older revision of " + changeable2 + "-" + str); 
        hashMap = PackageOwners.getRelatedPackages((Persistable)changeable2, hashMap);
      } 
      if (!hashMap.isEmpty()) {
        if (VERBOSE)
          System.out.println("***Sending e-mail to corresponding roles"); 
        if (VERBOSE)
          System.out.println("Project MAP- " + hashMap); 
        NotifyPackageOwners.sendMail(hashMap, (Persistable)paramWTChangeOrder2);
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  public static Vector<Changeable2> isDesignPkg(WTChangeOrder2 paramWTChangeOrder2) throws Exception {
    if (VERBOSE)
      System.out.println("*** WTChangeUtility.isDesignPkg()"); 
    Vector<Changeable2> vector1 = new Vector();
    Vector<Changeable2> vector2 = new Vector();
    try {
      QueryResult queryResult = ChangeHelper2.service.getChangeablesAfter((ChangeOrderIfc)paramWTChangeOrder2);
      if (VERBOSE)
        System.out.println("***Size- " + queryResult.size()); 
      while (queryResult.hasMoreElements()) {
        Changeable2 changeable2 = (Changeable2)queryResult.nextElement();
        String str = ((RevisionControlled)changeable2).getVersionInfo().getIdentifier().getValue();
        vector2.add(changeable2);
        PersistedCollectionMembership persistedCollectionMembership = PersistedCollectionHelper.service.getMemberOf((Persistable)changeable2);
        WTSet wTSet = (WTSet)persistedCollectionMembership.getDirectSet().subCollection(AbstractWorkPackage.class);
        wTSet.addAll((Collection)persistedCollectionMembership.getNestedSet().subCollection(AbstractWorkPackage.class));
        Object[] arrayOfObject = wTSet.toArray();
        if (arrayOfObject.length > 0) {
          for (byte b = 0; b < arrayOfObject.length; b++) {
            ObjectReference objectReference = (ObjectReference)arrayOfObject[b];
            WorkPackage workPackage = (WorkPackage)objectReference.getObject();
            if (VERBOSE)
              System.out.println("***Package : " + workPackage.getName()); 
            String str1 = workPackage.getLifeCycleState().toString();
            String str2 = TypedUtility.getTypeIdentifier(workPackage).toString();
            if (VERBOSE)
              System.out.println("***Design Package State :" + str1); 
            if (VALIDSTATES_DESIGN_PKG.contains(str1))
              if (str2.endsWith(DESIGN_PACKAGE_TYPE_NAME)) {
                if (VERBOSE)
                  System.out.println("***Design Package :" + workPackage.getNumber() + "-REV" + workPackage.getVersionIdentifier().getValue()); 
              } else {
                vector1.add(changeable2);
                if (VERBOSE)
                  System.out.println("*** Change Object" + changeable2 + "--" + str + "is not associated with any Package."); 
              }  
          } 
          continue;
        } 
        vector1.add(changeable2);
        System.out.println("*** WTChangeUtility.isDesignPkg: Change Object" + changeable2 + "--" + str + " is not associated with any Package.");
      } 
      if (!vector1.isEmpty()) {
        vector2.removeAllElements();
        if (VERBOSE)
          System.out.println("***items in design package-" + vector2.size()); 
      } else if (VERBOSE) {
        System.out.println("***Returning items from design package-" + vector2.size());
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return vector2;
  }
  
  public static Vector<WTChangeActivity2> incompleteTasks(WTChangeOrder2 paramWTChangeOrder2) {
    if (VERBOSE)
      System.out.println("*** WTChangeUtility.incompleteTasks()"); 
    Vector<WTChangeActivity2> vector = new Vector();
    try {
      QueryResult queryResult = ChangeHelper2.service.getChangeActivities((ChangeOrderIfc)paramWTChangeOrder2);
      if (VERBOSE)
        System.out.println("***activity size for changeNotice [" + paramWTChangeOrder2.getName() + "] is [" + queryResult.size() + "]"); 
      WTChangeActivity2 wTChangeActivity2 = getDefaultTask(paramWTChangeOrder2);
      while (queryResult.hasMoreElements()) {
        WTChangeActivity2 wTChangeActivity21 = (WTChangeActivity2)queryResult.nextElement();
        String str = wTChangeActivity21.getState().toString();
        if (!wTChangeActivity21.equals(wTChangeActivity2) && !str.equalsIgnoreCase(LCSTATE_COMPLETED))
          vector.add(wTChangeActivity21); 
      } 
    } catch (Exception exception) {
      if (VERBOSE)
        System.out.println("***Exception while getting Change activities of " + paramWTChangeOrder2.getNumber()); 
    } 
    if (VERBOSE)
      System.out.println("***Returning number of incomplete Tasks for the changeNotice -" + vector.size()); 
    return vector;
  }
  
  public static WTChangeActivity2 getDefaultTask(WTChangeOrder2 paramWTChangeOrder2) {
    if (VERBOSE)
      System.out.println("*** WTChangeUtility.getDefaultTsk()"); 
    WTChangeActivity2 wTChangeActivity2 = null;
    try {
      QueryResult queryResult = ChangeHelper2.service.getChangeActivities((ChangeOrderIfc)paramWTChangeOrder2);
      if (VERBOSE)
        System.out.println("***activity size for changeNotice [" + paramWTChangeOrder2.getName() + "] is [" + queryResult.size() + "]"); 
      WTChangeRequest2 wTChangeRequest2 = ChangeRequestHandler.getChangeRequest(paramWTChangeOrder2);
      while (queryResult.hasMoreElements()) {
        wTChangeActivity2 = (WTChangeActivity2)queryResult.nextElement();
        String str = ChangeManagementClientHelper.defaultChangeTask_getName(wTChangeRequest2);
        if (VERBOSE)
          System.out.println("***default task name: " + str); 
        if (VERBOSE)
          System.out.println("***ECA task name: " + wTChangeActivity2.getName()); 
        if (wTChangeActivity2.getName().trim().equalsIgnoreCase(str.trim())) {
          if (VERBOSE)
            System.out.println("***This the default task " + str); 
          break;
        } 
      } 
    } catch (Exception exception) {
      if (VERBOSE)
        System.out.println("*** Exception while getting Change activities of " + paramWTChangeOrder2.getNumber()); 
    } 
    return wTChangeActivity2;
  }
  
  public static WTArrayList addObjectstoArray(Persistable paramPersistable, boolean paramBoolean) throws Exception {
    if (VERBOSE)
      System.out.println("*** WTChangeUtility.addObjectstoArray()"); 
    WTArrayList wTArrayList = new WTArrayList();
    QueryResult queryResult = null;
    try {
      if (paramPersistable instanceof WTChangeOrder2 && paramBoolean) {
        WTChangeOrder2 wTChangeOrder2 = (WTChangeOrder2)paramPersistable;
        queryResult = ChangeHelper2.service.getChangeablesAfter((ChangeOrderIfc)wTChangeOrder2);
        if (VERBOSE)
          System.out.println("***getChangeablesAfter size- " + queryResult.size()); 
      } else if (paramPersistable instanceof WTChangeOrder2 && !paramBoolean) {
        WTChangeOrder2 wTChangeOrder2 = (WTChangeOrder2)paramPersistable;
        queryResult = ChangeHelper2.service.getChangeablesBefore((ChangeOrderIfc)wTChangeOrder2);
        if (VERBOSE)
          System.out.println("***getChangeablesBefore size- " + queryResult.size()); 
      } else if (paramPersistable instanceof WTChangeRequest2) {
        queryResult = ChangeHelper2.service.getChangeables((ChangeRequestIfc)paramPersistable);
        if (VERBOSE)
          System.out.println("***getChangeables items- " + queryResult.size()); 
      } 
      while (queryResult.hasMoreElements()) {
        WTObject wTObject = (WTObject)queryResult.nextElement();
        wTArrayList.add((Persistable)wTObject);
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return wTArrayList;
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\chang\\util\WTChangeUtility.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */