/*     */ package ext.piab.change.validation;
/*     */ 
/*     */ import ext.piab.change.resource.ChangeResource;
/*     */ import ext.piab.change.util.WTChangeUtility;
/*     */ import ext.piab.change.variance.VarianceValidation;
/*     */ import ext.piab.common.util.PropertyforPIAB;
/*     */ import ext.piab.common.validation.ValidateObjetcs;
/*     */ import ext.piab.publish.util.PIABPublishScheduler;
/*     */ import java.util.Vector;
/*     */ import wt.change2.ChangeActivityIfc;
/*     */ import wt.change2.ChangeHelper2;
/*     */ import wt.change2.ChangeOrderIfc;
/*     */ import wt.change2.ChangeRequestIfc;
/*     */ import wt.change2.Changeable2;
/*     */ import wt.change2.WTChangeActivity2;
/*     */ import wt.change2.WTChangeOrder2;
/*     */ import wt.change2.WTChangeRequest2;
/*     */ import wt.change2.WTVariance;
/*     */ import wt.doc.WTDocument;
/*     */ import wt.enterprise.RevisionControlled;
/*     */ import wt.epm.EPMDocument;
/*     */ import wt.fc.Persistable;
/*     */ import wt.fc.PersistenceHelper;
/*     */ import wt.fc.QueryResult;
/*     */ import wt.fc.WTObject;
/*     */ import wt.fc.collections.WTArrayList;
/*     */ import wt.lifecycle.LifeCycleHelper;
/*     */ import wt.lifecycle.LifeCycleManaged;
/*     */ import wt.lifecycle.State;
/*     */ import wt.util.WTException;
/*     */ import wt.vc.VersionControlHelper;
/*     */ import wt.vc.Versioned;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ValidateAffectedItems
/*     */ {
/*  41 */   private static final boolean VERBOSE = PropertyforPIAB.VERBOSE;
/*  42 */   private static final String LCSTATE_RESOLVED = PropertyforPIAB.LCSTATE_RESOLVED;
/*  43 */   private static final String LCSTATE_CANCELLED = PropertyforPIAB.LCSTATE_CANCELLED;
/*  44 */   private static final String VALIDSTATES_WTPART_ALPHA = PropertyforPIAB.VALIDSTATES_WTPART_ALPHA;
/*  45 */   private static final String VALIDSTATES_WTPART_NUMERIC = PropertyforPIAB.VALIDSTATES_WTPART_NUMERIC;
/*  46 */   private static final String VALIDSTATES_EPM_ALPHA = PropertyforPIAB.VALIDSTATES_EPM_ALPHA;
/*  47 */   private static final String VALIDSTATES_EPM_NUMERIC = PropertyforPIAB.VALIDSTATES_EPM_NUMERIC;
/*  48 */   private static final String VALIDSTATES_WTDOC_ALPHA = PropertyforPIAB.VALIDSTATES_WTDOC_ALPHA;
/*  49 */   private static final String VALIDSTATES_WTDOC_NUMERIC = PropertyforPIAB.VALIDSTATES_WTDOC_NUMERIC;
/*  50 */   private static final String CHANGE_RESOURCE = ChangeResource.class.getName();
/*  51 */   private static final String LC_STATE_3 = PropertyforPIAB.LC_STATE_3;
/*  52 */   private static final String LC_STATE_4 = PropertyforPIAB.LC_STATE_4;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void checkItemsCR(WTChangeRequest2 eCR) throws Exception {
/*  61 */     if (VERBOSE) System.out.println("*** ValidateAffectedItems.checkItemsCR(" + eCR.getName() + ")");
/*     */     
/*  63 */     QueryResult qresult = checkAffectedExist(eCR);
/*  64 */     StringBuilder strBuilder = new StringBuilder();
/*  65 */     while (qresult.hasMoreElements()) {
/*  66 */       Changeable2 chObj = (Changeable2)qresult.nextElement();
/*  67 */       QueryResult qres = ChangeHelper2.service.getRelevantChangeRequests(chObj);
/*  68 */       while (qres.hasMoreElements()) {
/*  69 */         WTChangeRequest2 ecr = (WTChangeRequest2)qres.nextElement();
/*  70 */         if (ecr.equals(eCR)) {
/*  71 */           if (VERBOSE) System.out.println("***[" + ecr.getName() + "]is the current Change Request");  continue;
/*     */         } 
/*  73 */         if (ecr.getLifeCycleState().toString().equalsIgnoreCase(LCSTATE_CANCELLED) || ecr
/*  74 */           .getLifeCycleState().toString().equalsIgnoreCase(LCSTATE_RESOLVED)) {
/*  75 */           if (VERBOSE) System.out.println("***The Change Request [" + ecr + "]is not in any Unresolved State");  continue;
/*     */         } 
/*  77 */         strBuilder = BuildErrorMessage.itemInCR(chObj, ecr, strBuilder);
/*     */       } 
/*     */     } 
/*     */     
/*  81 */     String message = strBuilder.toString();
/*  82 */     if (!message.isEmpty()) {
/*  83 */       if (VERBOSE) System.out.println("***Change Items in current Change Request have these Change Requests " + message + " which are unresolved"); 
/*  84 */       Object[] aobj1 = { message };
/*  85 */       throw new WTException(CHANGE_RESOURCE, "0", aobj1);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static QueryResult checkAffectedExist(WTChangeRequest2 eCR) throws Exception {
/*  95 */     if (VERBOSE) System.out.println("*** ValidateAffectedItems.checkAffectedExist(" + eCR.getName() + ")"); 
/*  96 */     QueryResult qresult = null;
/*  97 */     qresult = ChangeHelper2.service.getChangeables((ChangeRequestIfc)eCR);
/*  98 */     if (VERBOSE) System.out.println("***Size-" + qresult.size()); 
/*  99 */     if (!qresult.hasMoreElements()) {
/* 100 */       if (VERBOSE) System.out.println("***No Affected Data for the Change Request" + eCR.getName()); 
/* 101 */       Object[] aobj1 = { eCR.getName() };
/* 102 */       throw new WTException(CHANGE_RESOURCE, "1", aobj1);
/*     */     } 
/* 104 */     return qresult;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void checkItemsState(WTChangeRequest2 eCR) throws Exception {
/* 114 */     if (VERBOSE) System.out.println("*** ValidateAffectedItems.checkItemsState(" + eCR.getName() + ")"); 
/* 115 */     QueryResult qresullt = ChangeHelper2.service.getChangeables((ChangeRequestIfc)eCR);
/* 116 */     if (VERBOSE) System.out.println("***Size-" + qresullt.size()); 
/* 117 */     StringBuilder strBuilder = new StringBuilder();
/* 118 */     String rivisionIdentifier = null;
/* 119 */     String validStates = null;
/* 120 */     while (qresullt.hasMoreElements()) {
/* 121 */       Changeable2 chObj = (Changeable2)qresullt.nextElement();
/* 122 */       WTObject wpo = (WTObject)chObj;
/* 123 */       rivisionIdentifier = ((RevisionControlled)wpo).getVersionInfo().getIdentifier().getValue();
/* 124 */       if (Character.isDigit(rivisionIdentifier.charAt(0))) {
/* 125 */         validStates = getValidStates(wpo, true);
/* 126 */         if (!validStates.isEmpty()) {
/* 127 */           if (validStates.contains(((RevisionControlled)wpo).getLifeCycleState().toString())) {
/* 128 */             if (VERBOSE) System.out.println("***state of[" + wpo + "]--" + ((RevisionControlled)wpo).getState());  continue;
/*     */           } 
/* 130 */           strBuilder = BuildErrorMessage.itemsInValidStaes(wpo, validStates, strBuilder);
/*     */         }  continue;
/*     */       } 
/* 133 */       if (!Character.isDigit(rivisionIdentifier.charAt(0))) {
/* 134 */         validStates = getValidStates(wpo, false);
/* 135 */         if (!validStates.isEmpty()) {
/* 136 */           if (validStates.contains(((RevisionControlled)wpo).getLifeCycleState().toString())) {
/* 137 */             if (VERBOSE) System.out.println("***state of[" + wpo + "]--" + ((RevisionControlled)wpo).getState());  continue;
/*     */           } 
/* 139 */           strBuilder = BuildErrorMessage.itemsInValidStaes(wpo, validStates, strBuilder);
/*     */         } 
/*     */       } 
/*     */     } 
/* 143 */     String message = strBuilder.toString();
/* 144 */     if (!message.isEmpty()) {
/* 145 */       Object[] aobj1 = { message };
/* 146 */       throw new WTException(CHANGE_RESOURCE, "2", aobj1);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static QueryResult checkAffectedExist(WTChangeOrder2 eCN) throws Exception {
/* 156 */     if (VERBOSE) System.out.println("*** ValidateAffectedItems.checkAffectedExist(" + eCN.getName() + ")"); 
/* 157 */     QueryResult qresult = null;
/* 158 */     qresult = ChangeHelper2.service.getChangeablesBefore((ChangeOrderIfc)eCN, true);
/* 159 */     if (VERBOSE) System.out.println("***Size-" + qresult.size()); 
/* 160 */     if (!qresult.hasMoreElements()) {
/* 161 */       if (VERBOSE) System.out.println("***No Affected Data for the Change Notice" + eCN.getName()); 
/* 162 */       Object[] aobj1 = { eCN.getName() };
/* 163 */       throw new WTException(CHANGE_RESOURCE, "13", aobj1);
/*     */     } 
/* 165 */     return qresult;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void checkLcStates(Persistable pers, boolean resultant) throws Exception {
/* 173 */     if (VERBOSE) System.out.println("*** ValidateAffectedItems.checkLcStates"); 
/* 174 */     if (pers instanceof WTChangeOrder2) {
/* 175 */       WTArrayList list = WTChangeUtility.addObjectstoArray(pers, resultant);
/* 176 */       if (!list.isEmpty()) {
/* 177 */         ValidateObjetcs.incorrectObject(pers, list.toArray());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getValidStates(WTObject wpo, boolean numeric) {
/* 187 */     if (VERBOSE) System.out.println("*** ValidateAffectedItems.getValidStates()"); 
/* 188 */     String validStates = null;
/* 189 */     if (numeric) {
/* 190 */       if (wpo instanceof EPMDocument) {
/* 191 */         validStates = VALIDSTATES_EPM_NUMERIC;
/*     */       }
/* 193 */       if (wpo instanceof wt.part.WTPart) {
/* 194 */         validStates = VALIDSTATES_WTPART_NUMERIC;
/*     */       }
/* 196 */       if (wpo instanceof WTDocument) {
/* 197 */         validStates = VALIDSTATES_WTDOC_NUMERIC;
/*     */       }
/*     */     } else {
/* 200 */       if (wpo instanceof EPMDocument) {
/* 201 */         validStates = VALIDSTATES_EPM_ALPHA;
/*     */       }
/* 203 */       if (wpo instanceof wt.part.WTPart) {
/* 204 */         validStates = VALIDSTATES_WTPART_ALPHA;
/*     */       }
/* 206 */       if (wpo instanceof WTDocument)
/* 207 */         validStates = VALIDSTATES_WTDOC_ALPHA; 
/*     */     } 
/* 209 */     if (VERBOSE) System.out.println("Valid States are " + validStates); 
/* 210 */     return validStates;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void checkLcStates(Persistable pers) throws Exception {
/* 219 */     if (VERBOSE) System.out.println("*** ValidateAffectedItems.checkLcStates"); 
/* 220 */     if (pers instanceof WTChangeRequest2) {
/* 221 */       WTArrayList list = WTChangeUtility.addObjectstoArray(pers, false);
/* 222 */       if (!list.isEmpty()) {
/* 223 */         ValidateObjetcs.incorrectObject(pers, list.toArray());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setChangeItemsState(WTChangeRequest2 eCR, String state) throws Exception {
/* 233 */     if (VERBOSE) System.out.println("*** ValidateAffectedItems.setItemsState(" + eCR.getName() + ")"); 
/* 234 */     QueryResult qresult = ChangeHelper2.service.getChangeables((ChangeRequestIfc)eCR);
/* 235 */     if (VERBOSE) System.out.println("***Size-" + qresult.size()); 
/* 236 */     while (qresult.hasMoreElements()) {
/* 237 */       Changeable2 chObj = (Changeable2)qresult.nextElement();
/* 238 */       LifeCycleManaged lm = (LifeCycleManaged)chObj;
/* 239 */       lm = LifeCycleHelper.service.setLifeCycleState(lm, State.toState(state), true);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setAffectedItemsState(Persistable pers, String state) throws Exception {
/* 249 */     if (VERBOSE) System.out.println("*** setAffectedItemsState.setItemsState(" + pers.getIdentity() + ")"); 
/* 250 */     QueryResult qresult = null;
/*     */     try {
/* 252 */       if (pers instanceof WTChangeOrder2) {
/* 253 */         WTChangeOrder2 eCN = (WTChangeOrder2)pers;
/* 254 */         qresult = ChangeHelper2.service.getChangeablesBefore((ChangeOrderIfc)eCN, true);
/* 255 */         if (VERBOSE) System.out.println("***Size-" + qresult.size());
/*     */       
/* 257 */       } else if (pers instanceof WTChangeActivity2) {
/* 258 */         WTChangeActivity2 eCA = (WTChangeActivity2)pers;
/* 259 */         qresult = ChangeHelper2.service.getChangeablesBefore((ChangeActivityIfc)eCA, true);
/* 260 */         if (VERBOSE) System.out.println("***Size-" + qresult.size()); 
/*     */       } 
/* 262 */       while (qresult.hasMoreElements()) {
/* 263 */         Changeable2 chObj = (Changeable2)qresult.nextElement();
/* 264 */         LifeCycleManaged lm = (LifeCycleManaged)chObj;
/* 265 */         lm = LifeCycleHelper.service.setLifeCycleState(lm, State.toState(state), true);
/*     */       }
/*     */     
/* 268 */     } catch (Exception ex) {
/* 269 */       ex.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void publishAffectedItems(WTChangeRequest2 eCR) throws Exception {
/* 278 */     if (VERBOSE) System.out.println("*** publishAffectedItems for ECR: (" + eCR.getName() + ")"); 
/* 279 */     QueryResult qresult = ChangeHelper2.service.getChangeables((ChangeRequestIfc)eCR, true);
/* 280 */     if (VERBOSE) System.out.println("***Size-" + qresult.size()); 
/* 281 */     while (qresult.hasMoreElements()) {
/* 282 */       Changeable2 chObj = (Changeable2)qresult.nextElement();
/* 283 */       if (chObj instanceof WTDocument) {
/* 284 */         WTDocument doc = (WTDocument)chObj;
/* 285 */         if (VERBOSE) System.out.println("***Change Object is an instance of WTDocument - " + doc.getIdentity()); 
/* 286 */         PIABPublishScheduler.publishDocument(doc); continue;
/* 287 */       }  if (chObj instanceof EPMDocument) {
/* 288 */         EPMDocument epmDoc = (EPMDocument)chObj;
/* 289 */         if (VERBOSE) System.out.println("***Change Object is an instance of EPMDocument - " + epmDoc.getIdentity()); 
/* 290 */         PIABPublishScheduler.sendPublishJob(epmDoc); continue;
/*     */       } 
/* 292 */       if (VERBOSE) System.out.println("***Change Object is not either EPMDocument or WTDocument - Cannot publish");
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void publishAffectedItems(WTChangeOrder2 eCN) throws Exception {
/* 302 */     if (VERBOSE) System.out.println("*** publishAffectedItems for ECN: (" + eCN.getName() + ")"); 
/* 303 */     QueryResult qresult = ChangeHelper2.service.getChangeablesBefore((ChangeOrderIfc)eCN, true);
/* 304 */     if (VERBOSE) System.out.println("***Size-" + qresult.size()); 
/* 305 */     while (qresult.hasMoreElements()) {
/* 306 */       Changeable2 chObj = (Changeable2)qresult.nextElement();
/* 307 */       if (chObj instanceof WTDocument) {
/* 308 */         WTDocument doc = (WTDocument)chObj;
/* 309 */         if (VERBOSE) System.out.println("***Change Object is an instance of WTDocument - " + doc.getIdentity()); 
/* 310 */         PIABPublishScheduler.publishDocument(doc); continue;
/* 311 */       }  if (chObj instanceof EPMDocument) {
/* 312 */         EPMDocument epmDoc = (EPMDocument)chObj;
/* 313 */         if (VERBOSE) System.out.println("***Change Object is an instance of EPMDocument - " + epmDoc.getIdentity()); 
/* 314 */         PIABPublishScheduler.sendPublishJob(epmDoc); continue;
/*     */       } 
/* 316 */       if (VERBOSE) System.out.println("***Change Object is not either EPMDocument or WTDocument - Cannot publish");
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void checkAffectedRevisions(WTChangeOrder2 eCN) throws Exception {
/* 328 */     if (VERBOSE) System.out.println("***ValidateAffectedItems.checkAffectedRevisisons()"); 
/* 329 */     StringBuilder sb = new StringBuilder();
/* 330 */     StringBuilder strBuilder = new StringBuilder();
/* 331 */     QueryResult qres = null;
/* 332 */     String validStates = null;
/* 333 */     qres = ChangeHelper2.service.getChangeablesBefore((ChangeOrderIfc)eCN, true);
/* 334 */     while (qres.hasMoreElements()) {
/* 335 */       WTObject wto = (WTObject)qres.nextElement();
/* 336 */       System.out.println("***Revision of object is : " + VersionControlHelper.getVersionIdentifier((Versioned)wto).getValue().toString());
/* 337 */       String revision = ((RevisionControlled)wto).getVersionInfo().getIdentifier().getValue();
/* 338 */       if (Character.isDigit(revision.charAt(0))) {
/* 339 */         System.out.println("***Object Revision is numeric");
/* 340 */         validStates = getValidStates(wto, true);
/* 341 */         if (!validStates.isEmpty()) {
/* 342 */           if (validStates.contains(((RevisionControlled)wto).getLifeCycleState().toString())) {
/* 343 */             if (VERBOSE) System.out.println("***State of [" + wto + " --] " + ((RevisionControlled)wto).getLifeCycleState()); 
/*     */             continue;
/*     */           } 
/* 346 */           strBuilder = BuildErrorMessage.itemsInValidStaes(wto, validStates, strBuilder);
/*     */         } 
/*     */         continue;
/*     */       } 
/* 350 */       if (!Character.isDigit(revision.charAt(0))) {
/* 351 */         System.out.println("***Object Revision is not numeric");
/* 352 */         sb.append(wto.getIdentity());
/*     */       } 
/*     */     } 
/* 355 */     String message = strBuilder.toString();
/* 356 */     if (!message.isEmpty()) {
/* 357 */       if (VERBOSE) System.out.println("***Change Items in current Change Notice have incorrect states " + message); 
/* 358 */       Object[] aobj1 = { message };
/* 359 */       throw new WTException(CHANGE_RESOURCE, "2", aobj1);
/*     */     } 
/*     */     
/* 362 */     message = sb.toString();
/* 363 */     if (!message.isEmpty()) {
/* 364 */       if (VERBOSE) System.out.println("***Change Items in current Change Notice have alpha revisions :" + message); 
/* 365 */       Object[] aobj1 = { message };
/* 366 */       throw new WTException(CHANGE_RESOURCE, "14", aobj1);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void checkIfVarianceExists(WTObject wto, Vector states, boolean notTheseStates) throws Exception {
/* 376 */     if (VERBOSE) System.out.println("**ValidateAffectedItems.checkIfVarianceExists()  " + wto.getIdentity()); 
/* 377 */     StringBuilder sb = new StringBuilder();
/* 378 */     StringBuilder strBuilder = new StringBuilder();
/* 379 */     String validStates = states.toString();
/* 380 */     QueryResult qres = ChangeHelper2.service.getReportedAgainstChangeIssue((Changeable2)wto);
/* 381 */     if (VERBOSE) System.out.println("***Size of relevant Variances : " + qres.size()); 
/* 382 */     while (qres.hasMoreElements()) {
/* 383 */       WTObject wtObj = (WTObject)qres.nextElement();
/* 384 */       if (wtObj instanceof WTVariance) {
/* 385 */         WTVariance var2 = (WTVariance)wtObj;
/* 386 */         if (notTheseStates) {
/* 387 */           if (!validStates.contains(var2.getLifeCycleState().toString())) {
/* 388 */             if (VERBOSE) System.out.println("###The variance " + var2.getName() + " is in " + var2.getLifeCycleState().toString() + " State"); 
/* 389 */             sb = VarianceValidation.itemsInVar((Changeable2)wto, var2, sb);
/*     */           } 
/*     */           continue;
/*     */         } 
/* 393 */         if (validStates.contains(var2.getLifeCycleState().toString())) {
/* 394 */           if (VERBOSE) System.out.println("***The variance " + var2.getName() + " is in " + var2.getLifeCycleState().toString() + " State..."); 
/* 395 */           strBuilder = VarianceValidation.itemsInVar((Changeable2)wto, var2, strBuilder);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 400 */     String message = sb.toString();
/* 401 */     if (!message.isEmpty()) {
/* 402 */       if (VERBOSE) System.out.println("***Change Items in current Change Notice have these variances " + message + " which are not Rejected or Resolved"); 
/* 403 */       Object[] aobj1 = { message };
/* 404 */       throw new WTException(CHANGE_RESOURCE, "15", aobj1);
/*     */     } 
/*     */     
/* 407 */     message = strBuilder.toString();
/* 408 */     if (!message.isEmpty()) {
/* 409 */       if (VERBOSE) System.out.println("***Change Items in current Change Notice have these variances " + message + " which are unresolved"); 
/* 410 */       Object[] aobj1 = { message };
/* 411 */       throw new WTException(CHANGE_RESOURCE, "16", aobj1);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void checkCNItemsState(WTChangeOrder2 eCN) throws Exception {
/* 420 */     if (VERBOSE) System.out.println("*** ValidateAffectedItems.checkCNItemsState(" + eCN.getName() + ")"); 
/* 421 */     QueryResult qresullt = ChangeHelper2.service.getChangeablesBefore((ChangeOrderIfc)eCN, true);
/* 422 */     if (VERBOSE) System.out.println("***Size-" + qresullt.size()); 
/* 423 */     StringBuilder strBuilder = new StringBuilder();
/* 424 */     StringBuilder sb = new StringBuilder();
/* 425 */     String rivisionIdentifier = null;
/* 426 */     String validStates = null;
/* 427 */     while (qresullt.hasMoreElements()) {
/* 428 */       Changeable2 chObj = (Changeable2)qresullt.nextElement();
/* 429 */       WTObject wpo = (WTObject)chObj;
/* 430 */       rivisionIdentifier = ((RevisionControlled)wpo).getVersionInfo().getIdentifier().getValue();
/* 431 */       if (Character.isDigit(rivisionIdentifier.charAt(0))) {
/* 432 */         validStates = getValidStates(wpo, true);
/* 433 */         if (!validStates.isEmpty()) {
/* 434 */           if (validStates.contains(((RevisionControlled)wpo).getLifeCycleState().toString())) {
/* 435 */             if (VERBOSE) System.out.println("***state of[" + wpo + "]--" + ((RevisionControlled)wpo).getState()); 
/*     */             continue;
/*     */           } 
/* 438 */           sb = BuildErrorMessage.itemsInValidStaes(wpo, validStates, sb);
/*     */         } 
/*     */         continue;
/*     */       } 
/* 442 */       if (!Character.isDigit(rivisionIdentifier.charAt(0)))
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 449 */         strBuilder.append(wpo.getIdentity());
/*     */       }
/*     */     } 
/*     */     
/* 453 */     String message = sb.toString();
/* 454 */     if (!message.isEmpty()) {
/* 455 */       System.out.println("***Change Notice is having objects with invalid states : " + message);
/* 456 */       Object[] aobj1 = { message };
/* 457 */       throw new WTException(CHANGE_RESOURCE, "2", aobj1);
/*     */     } 
/*     */     
/* 460 */     message = strBuilder.toString();
/* 461 */     if (!message.isEmpty()) {
/* 462 */       System.out.println("***Change Notice is having objects with alpha versions : " + message);
/* 463 */       Object[] aobj1 = { message };
/* 464 */       throw new WTException(CHANGE_RESOURCE, "14", aobj1);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void checkForNumericRevisions(Persistable pers) throws Exception {
/* 469 */     if (VERBOSE) System.out.println("***ValidateResultingItems.checkForNumericRevisions()"); 
/* 470 */     QueryResult qres = null;
/* 471 */     boolean isNumeric = false;
/* 472 */     StringBuilder sb = new StringBuilder();
/*     */     
/* 474 */     if (pers instanceof WTChangeRequest2) {
/* 475 */       WTChangeRequest2 eCR = (WTChangeRequest2)pers;
/* 476 */       qres = ChangeHelper2.service.getChangeables((ChangeRequestIfc)eCR, true);
/*     */     } 
/* 478 */     while (qres.hasMoreElements()) {
/* 479 */       WTObject wto = (WTObject)qres.nextElement();
/* 480 */       System.out.println("***Revision of object is : " + VersionControlHelper.getVersionIdentifier((Versioned)wto).getValue().toString());
/* 481 */       String revision = ((RevisionControlled)wto).getVersionInfo().getIdentifier().getValue();
/* 482 */       if (Character.isDigit(revision.charAt(0))) {
/* 483 */         if (VERBOSE) System.out.println("***Object Revision is numeric"); 
/* 484 */         if (VERBOSE) System.out.println("***Setting state to " + LC_STATE_3); 
/* 485 */         State lcState = State.toState(LC_STATE_3);
/* 486 */         wto = (WTObject)LifeCycleHelper.service.setLifeCycleState((LifeCycleManaged)wto, lcState);
/* 487 */         System.out.println("The Object set to state as :" + lcState + "---" + wto.getDisplayIdentity());
/* 488 */         wto = (WTObject)PersistenceHelper.manager.refresh((Persistable)wto); continue;
/*     */       } 
/* 490 */       if (!Character.isDigit(revision.charAt(0))) {
/* 491 */         if (VERBOSE) System.out.println("***Object Revision is not numeric"); 
/* 492 */         if (VERBOSE) System.out.println("***Setting state to " + LC_STATE_4); 
/* 493 */         State lcState = State.toState(LC_STATE_4);
/* 494 */         System.out.println("The Object set to state as :" + lcState);
/* 495 */         wto = (WTObject)LifeCycleHelper.service.setLifeCycleState((LifeCycleManaged)wto, lcState);
/* 496 */         wto = (WTObject)PersistenceHelper.manager.refresh((Persistable)wto);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\change\validation\ValidateAffectedItems.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */