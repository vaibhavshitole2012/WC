/*     */ package ext.piab.change.validation;
/*     */ 
/*     */ import com.ptc.core.foundation.type.server.impl.TypeHelper;
/*     */ import com.ptc.core.meta.common.TypeIdentifier;
/*     */ import com.ptc.core.meta.common.TypeIdentifierHelper;
/*     */ import com.ptc.windchill.wp.AbstractWorkPackage;
/*     */ import com.ptc.windchill.wp.WorkPackage;
/*     */ import ext.piab.change.resource.ChangeResource;
/*     */ import ext.piab.change.util.WTChangeUtility;
/*     */ import ext.piab.common.util.PropertyforPIAB;
/*     */ import ext.piab.common.validation.ValidateObjetcs;
/*     */ import ext.piab.publish.util.PIABPublishScheduler;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.Vector;
/*     */ import wt.change2.ChangeActivityIfc;
/*     */ import wt.change2.ChangeHelper2;
/*     */ import wt.change2.ChangeOrderIfc;
/*     */ import wt.change2.Changeable2;
/*     */ import wt.change2.WTChangeActivity2;
/*     */ import wt.change2.WTChangeOrder2;
/*     */ import wt.change2.WTVariance;
/*     */ import wt.doc.WTDocument;
/*     */ import wt.enterprise.RevisionControlled;
/*     */ import wt.epm.EPMDocument;
/*     */ import wt.facade.persistedcollection.PersistedCollectionHelper;
/*     */ import wt.facade.persistedcollection.PersistedCollectionMembership;
/*     */ import wt.fc.Persistable;
/*     */ import wt.fc.PersistenceHelper;
/*     */ import wt.fc.QueryResult;
/*     */ import wt.fc.WTObject;
/*     */ import wt.fc.collections.WTArrayList;
/*     */ import wt.fc.collections.WTSet;
/*     */ import wt.lifecycle.LifeCycleHelper;
/*     */ import wt.lifecycle.LifeCycleManaged;
/*     */ import wt.lifecycle.State;
/*     */ import wt.part.WTPart;
/*     */ import wt.session.SessionHelper;
/*     */ import wt.type.TypedUtility;
/*     */ import wt.util.WTException;
/*     */ import wt.vc.VersionControlHelper;
/*     */ import wt.vc.Versioned;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ValidateResultingItems
/*     */ {
/*  50 */   private static final boolean VERBOSE = PropertyforPIAB.VERBOSE;
/*  51 */   private static final String LC_STATE_3 = PropertyforPIAB.LC_STATE_3;
/*  52 */   private static final String LC_STATE_4 = PropertyforPIAB.LC_STATE_4;
/*  53 */   private static final String VALIDSTATES_SUPPLIER_PKG = PropertyforPIAB.VALIDSTATES_SUPPLIER_PKG;
/*  54 */   private static final String SUPPLIER_PACKAGE_TYPE_NAME = PropertyforPIAB.SUPPLIER_PACKAGE_TYPE_NAME;
/*  55 */   private static final String CHANGE_RESOURCE = ChangeResource.class.getName();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void checkResultingData(Persistable pers) throws Exception {
/*  64 */     if (VERBOSE) System.out.println("*** ValidateResultingItems.checkResultingData()"); 
/*  65 */     QueryResult qresult = null;
/*  66 */     String exception = null;
/*  67 */     if (pers instanceof WTChangeOrder2) {
/*  68 */       WTChangeOrder2 ECN = (WTChangeOrder2)pers;
/*  69 */       exception = "Change Notice [" + ECN.getName() + "]";
/*  70 */       qresult = ChangeHelper2.service.getChangeablesAfter((ChangeOrderIfc)ECN);
/*  71 */     } else if (pers instanceof WTChangeActivity2) {
/*  72 */       WTChangeActivity2 ECA = (WTChangeActivity2)pers;
/*  73 */       exception = "Change Activity [" + ECA.getName() + "]";
/*  74 */       qresult = ChangeHelper2.service.getChangeablesAfter((ChangeActivityIfc)ECA);
/*     */     } 
/*  76 */     if (VERBOSE) System.out.println("***Size of Resulting items-" + qresult.size()); 
/*  77 */     if (!qresult.hasMoreElements()) {
/*  78 */       if (VERBOSE) System.out.println("***There are no Resulting Objects in this Change Item. Add Resulting Objects to Proceed"); 
/*  79 */       Object[] aobj1 = { exception };
/*  80 */       throw new WTException(CHANGE_RESOURCE, "6", aobj1);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void isInSupplierPackage(WTChangeOrder2 changeNotice) throws Exception {
/*  93 */     if (VERBOSE) System.out.println("*** ValidateResultingItems.isInSupplierPackage()"); 
/*  94 */     Vector<WTObject> itemsInSupplierPackage = findItemsInSupplierPackages(changeNotice, true);
/*  95 */     if (itemsInSupplierPackage != null && itemsInSupplierPackage.size() > 0) {
/*  96 */       if (VERBOSE) System.out.println("**** Found Items in Supplier Package"); 
/*  97 */       StringBuilder str = new StringBuilder();
/*  98 */       for (int i = 0; i < itemsInSupplierPackage.size(); i++) {
/*  99 */         WTObject obj = itemsInSupplierPackage.get(i);
/* 100 */         if (obj instanceof WTPart) {
/* 101 */           WTPart p = (WTPart)obj;
/* 102 */           str.append("\n" + p.getNumber() + " " + p.getVersionInfo().getIdentifier().getValue());
/* 103 */         }  if (obj instanceof EPMDocument) {
/* 104 */           EPMDocument epm = (EPMDocument)obj;
/* 105 */           str.append("\n" + epm.getNumber() + " " + epm.getVersionInfo().getIdentifier().getValue());
/* 106 */         }  if (obj instanceof WTDocument) {
/* 107 */           WTDocument doc = (WTDocument)obj;
/* 108 */           str.append("\n" + doc.getNumber() + " " + doc.getVersionInfo().getIdentifier().getValue());
/*     */         } 
/* 110 */       }  String message = str.toString();
/* 111 */       Object[] aobj1 = { message };
/* 112 */       throw new WTException(CHANGE_RESOURCE, "7", aobj1);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Vector findItemsInSupplierPackages(WTChangeOrder2 changeNotice, boolean flag) throws Exception {
/* 125 */     if (VERBOSE) System.out.println("*** ValidateResultingItems.findItemsInSupplierPackages()"); 
/* 126 */     Vector<Changeable2> objects = new Vector();
/*     */     
/*     */     try {
/* 129 */       QueryResult qresult = ChangeHelper2.service.getChangeablesAfter((ChangeOrderIfc)changeNotice);
/* 130 */       if (VERBOSE) System.out.println("***QueryResult Size-" + qresult.size()); 
/* 131 */       while (qresult.hasMoreElements()) {
/* 132 */         Changeable2 chObj = (Changeable2)qresult.nextElement();
/* 133 */         String revision = ((RevisionControlled)chObj).getVersionInfo().getIdentifier().getValue();
/* 134 */         PersistedCollectionMembership persistedcollectionmembership1 = PersistedCollectionHelper.service.getMemberOf((Persistable)chObj);
/* 135 */         Object obj = persistedcollectionmembership1.getDirectSet().subCollection(AbstractWorkPackage.class);
/* 136 */         ((WTSet)obj).addAll((Collection)persistedcollectionmembership1.getNestedSet().subCollection(AbstractWorkPackage.class));
/* 137 */         Iterator<WorkPackage> iterator = ((WTSet)obj).persistableIterator();
/* 138 */         while (iterator.hasNext()) {
/* 139 */           WorkPackage pkg = iterator.next();
/* 140 */           String pkgState = pkg.getLifeCycleState().toString();
/* 141 */           String pkgType = TypedUtility.getTypeIdentifier(pkg).toString();
/* 142 */           if (VERBOSE) System.out.println("***WorkPackage.- " + pkg.getName()); 
/* 143 */           if (pkgType.endsWith(SUPPLIER_PACKAGE_TYPE_NAME) && VALIDSTATES_SUPPLIER_PKG.contains(pkgState)) {
/* 144 */             objects.add(chObj);
/* 145 */             if (VERBOSE) System.out.println("***Package is Supplier Package:" + pkg.getName());  continue;
/*     */           } 
/* 147 */           if (VERBOSE) System.out.println("***Change Object" + chObj + "-" + revision + "is not associated with any Package.");
/*     */         
/*     */         } 
/*     */       } 
/*     */       
/* 152 */       if (flag) {
/* 153 */         qresult = ChangeHelper2.service.getChangeablesBefore((ChangeOrderIfc)changeNotice);
/* 154 */         if (VERBOSE) System.out.println("***Changeables Before Size-" + qresult.size()); 
/* 155 */         while (qresult.hasMoreElements()) {
/* 156 */           Changeable2 chObj = (Changeable2)qresult.nextElement();
/* 157 */           String revision = ((RevisionControlled)chObj).getVersionInfo().getIdentifier().getValue();
/* 158 */           PersistedCollectionMembership persistedcollectionmembership1 = PersistedCollectionHelper.service.getMemberOf((Persistable)chObj);
/* 159 */           Object obj = persistedcollectionmembership1.getDirectSet().subCollection(AbstractWorkPackage.class);
/* 160 */           ((WTSet)obj).addAll((Collection)persistedcollectionmembership1.getNestedSet().subCollection(AbstractWorkPackage.class));
/* 161 */           Iterator<WorkPackage> iterator = ((WTSet)obj).persistableIterator();
/* 162 */           while (iterator.hasNext()) {
/* 163 */             WorkPackage pkg = iterator.next();
/* 164 */             String pkgState = pkg.getLifeCycleState().toString();
/* 165 */             String pkgType = TypedUtility.getTypeIdentifier(pkg).toString();
/* 166 */             if (VERBOSE) System.out.println("***Changeables Before Package : " + pkg.getName()); 
/* 167 */             if (pkgType.endsWith(SUPPLIER_PACKAGE_TYPE_NAME) && VALIDSTATES_SUPPLIER_PKG.contains(pkgState)) {
/* 168 */               objects.add(chObj);
/* 169 */               if (VERBOSE) System.out.println("***Changeables Before Package is Supplier Package :" + pkg.getName());  continue;
/*     */             } 
/* 171 */             if (VERBOSE) System.out.println("*** Changeables Before Change Object" + chObj + "--" + revision + " is not associated with any Package.");
/*     */           
/*     */           } 
/*     */         } 
/*     */       } 
/* 176 */       return objects;
/* 177 */     } catch (Exception e) {
/* 178 */       e.printStackTrace();
/*     */       
/* 180 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void waitOnDesignpkg(Persistable pers, Vector<String> states) throws Exception {
/* 185 */     if (VERBOSE) System.out.println("ValidateResultingItems.waitOnDesignpkg()"); 
/* 186 */     WTChangeOrder2 order = null;
/* 187 */     if (pers instanceof WTChangeOrder2) {
/* 188 */       order = (WTChangeOrder2)pers;
/*     */     }
/* 190 */     WTArrayList objs = WTChangeUtility.addObjectstoArray((Persistable)order, true);
/* 191 */     String message = ValidateObjetcs.incorrectLCState(objs.toArray(), states);
/* 192 */     if (!message.isEmpty()) {
/* 193 */       if (VERBOSE) System.out.println("***The lifecycle states of following objects is other than" + states); 
/* 194 */       Object[] aobj1 = { states, message };
/* 195 */       throw new WTException(CHANGE_RESOURCE, "9", aobj1);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void publishResultingItems(Persistable pers) throws Exception {
/* 204 */     if (VERBOSE) System.out.println("*** publishResultingItems for ECN: (" + pers.getIdentity() + ")"); 
/* 205 */     QueryResult qresult = null;
/* 206 */     if (pers instanceof WTChangeOrder2) {
/* 207 */       WTChangeOrder2 eCN = (WTChangeOrder2)pers;
/* 208 */       qresult = ChangeHelper2.service.getChangeablesAfter((ChangeOrderIfc)eCN, true);
/* 209 */       if (VERBOSE) System.out.println("***Size-" + qresult.size());
/*     */     
/* 211 */     } else if (pers instanceof WTChangeActivity2) {
/* 212 */       WTChangeActivity2 eCA = (WTChangeActivity2)pers;
/* 213 */       qresult = ChangeHelper2.service.getChangeablesAfter((ChangeActivityIfc)eCA, true);
/* 214 */       if (VERBOSE) System.out.println("***Size-" + qresult.size()); 
/*     */     } 
/* 216 */     while (qresult.hasMoreElements()) {
/* 217 */       Changeable2 chObj = (Changeable2)qresult.nextElement();
/* 218 */       if (chObj instanceof WTDocument) {
/* 219 */         WTDocument doc = (WTDocument)chObj;
/* 220 */         if (VERBOSE) System.out.println("***Change Object is an instance of WTDocument - " + doc.getIdentity()); 
/* 221 */         PIABPublishScheduler.publishDocument(doc); continue;
/* 222 */       }  if (chObj instanceof EPMDocument) {
/* 223 */         EPMDocument epmDoc = (EPMDocument)chObj;
/* 224 */         if (VERBOSE) System.out.println("***Change Object is an instance of EPMDocument - " + epmDoc.getIdentity()); 
/* 225 */         PIABPublishScheduler.sendPublishJob(epmDoc); continue;
/*     */       } 
/* 227 */       if (VERBOSE) System.out.println("***Change Object is not either EPMDocument or WTDocument - Cannot publish");
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void checkForNumericRevisions(Persistable pers) throws Exception {
/* 237 */     if (VERBOSE) System.out.println("***ValidateResultingItems.checkForNumericRevisions()"); 
/* 238 */     QueryResult qres = null;
/* 239 */     boolean isNumeric = false;
/* 240 */     StringBuilder sb = new StringBuilder();
/*     */     
/* 242 */     if (pers instanceof WTChangeOrder2) {
/* 243 */       WTChangeOrder2 eCN = (WTChangeOrder2)pers;
/* 244 */       qres = ChangeHelper2.service.getChangeablesAfter((ChangeOrderIfc)eCN, true);
/*     */     } 
/* 246 */     while (qres.hasMoreElements()) {
/* 247 */       WTObject wto = (WTObject)qres.nextElement();
/* 248 */       System.out.println("***Revision of object is : " + VersionControlHelper.getVersionIdentifier((Versioned)wto).getValue().toString());
/* 249 */       String revision = ((RevisionControlled)wto).getVersionInfo().getIdentifier().getValue();
/* 250 */       if (Character.isDigit(revision.charAt(0))) {
/* 251 */         if (VERBOSE) System.out.println("***Object Revision is numeric"); 
/* 252 */         sb = checkIfWaiverExists(wto);
/* 253 */         System.out.println("The object is numeric the the waiver details as :" + sb); continue;
/*     */       } 
/* 255 */       if (!Character.isDigit(revision.charAt(0))) {
/* 256 */         if (VERBOSE) System.out.println("***Object Revision is not numeric"); 
/* 257 */         if (VERBOSE) System.out.println("***Setting state to " + LC_STATE_4); 
/* 258 */         State lcState = State.toState(LC_STATE_4);
/* 259 */         System.out.println("The Object set to state as :" + lcState);
/* 260 */         wto = (WTObject)LifeCycleHelper.service.setLifeCycleState((LifeCycleManaged)wto, lcState);
/* 261 */         wto = (WTObject)PersistenceHelper.manager.refresh((Persistable)wto);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static StringBuilder checkIfWaiverExists(WTObject wto) throws Exception {
/* 271 */     if (VERBOSE) System.out.println("**ValidateResultingItems.checkIfVarianceExists() " + wto.getIdentity()); 
/* 272 */     StringBuilder sb = new StringBuilder();
/* 273 */     boolean hasWaiver = false;
/* 274 */     QueryResult qres = null;
/*     */     try {
/* 276 */       qres = ChangeHelper2.service.getReportedAgainstChangeIssue((Changeable2)wto);
/* 277 */       if (VERBOSE) System.out.println("***Size of relevant Variances : " + qres.size()); 
/* 278 */       if (qres.size() > 0) {
/* 279 */         while (qres.hasMoreElements()) {
/* 280 */           WTObject wtObj = (WTObject)qres.nextElement();
/* 281 */           if (wtObj instanceof WTVariance) {
/* 282 */             WTVariance var2 = (WTVariance)wtObj;
/* 283 */             System.out.println("The variance name :" + var2.getName());
/* 284 */             TypeIdentifier typeId = TypeIdentifierHelper.getType(var2);
/* 285 */             System.out.println("The type of variance and name :" + typeId.getTypename());
/* 286 */             String varType = TypeHelper.getLocalizedTypeString(typeId, SessionHelper.getLocale());
/* 287 */             if (varType.equalsIgnoreCase("WAIVER")) {
/* 288 */               if (VERBOSE) System.out.println("The change object : " + wto.getIdentity() + " is having a Waiver : " + var2.getIdentity()); 
/* 289 */               if (VERBOSE) System.out.println("***Setting state to " + LC_STATE_4); 
/* 290 */               State state = State.toState(LC_STATE_4);
/* 291 */               System.out.println("The Object set to state as :" + state);
/* 292 */               wto = (WTObject)LifeCycleHelper.service.setLifeCycleState((LifeCycleManaged)wto, state);
/* 293 */               System.out.println("The Object set to state as :" + state + "---" + wto.getDisplayIdentity());
/* 294 */               wto = (WTObject)PersistenceHelper.manager.refresh((Persistable)wto);
/*     */               continue;
/*     */             } 
/* 297 */             if (VERBOSE) System.out.println("The change object : " + wto.getIdentity() + " does not have a waiver.."); 
/* 298 */             if (VERBOSE) System.out.println("***Setting state to " + LC_STATE_3); 
/* 299 */             State lcState = State.toState(LC_STATE_3);
/* 300 */             wto = (WTObject)LifeCycleHelper.service.setLifeCycleState((LifeCycleManaged)wto, lcState);
/* 301 */             System.out.println("The Object set to state as :" + lcState + "---" + wto.getDisplayIdentity());
/* 302 */             wto = (WTObject)PersistenceHelper.manager.refresh((Persistable)wto);
/*     */           } 
/*     */         } 
/*     */       } else {
/*     */         
/* 307 */         if (VERBOSE) System.out.println("The change object : " + wto.getIdentity() + " does not have any variance.."); 
/* 308 */         if (VERBOSE) System.out.println("***Setting state to " + LC_STATE_3); 
/* 309 */         State lcState = State.toState(LC_STATE_3);
/* 310 */         wto = (WTObject)LifeCycleHelper.service.setLifeCycleState((LifeCycleManaged)wto, lcState);
/* 311 */         System.out.println("The Object set to state as :" + lcState + "---" + wto.getDisplayIdentity());
/* 312 */         wto = (WTObject)PersistenceHelper.manager.refresh((Persistable)wto);
/*     */       }
/*     */     
/* 315 */     } catch (Exception ex) {
/* 316 */       ex.printStackTrace();
/*     */     } 
/* 318 */     return sb;
/*     */   }
/*     */ }


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\change\validation\ValidateResultingItems.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */