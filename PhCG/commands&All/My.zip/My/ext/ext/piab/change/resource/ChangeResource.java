package ext.piab.change.resource;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("ext.piab.change.resource.ChangeResource")
public final class ChangeResource extends WTListResourceBundle {
  @RBEntry("Items in the current Change Request have these unresolved Change Requests - \n{0}")
  public static final String UNRESOLVED_CR = "0";
  
  @RBEntry("There are no Affected Objects attached to the Change Request - {0}")
  public static final String NO_ITEMS_IN_CR = "1";
  
  @RBEntry("Please verify if the below objects are in the mentioned states - \n{0}")
  public static final String CHECK_LC_STATE = "2";
  
  @RBEntry("Lifecycle state of {0} is greater than {1}.")
  public static final String INCORRECT_CN_CA_STATE = "3";
  
  @RBEntry("Content missing. Please attach the content.")
  public static final String MISSING_CONTENT = "4";
  
  @RBEntry("File Attachment with name {0} is missing. Please attach the content")
  public static final String MISSING_FILENAME_CONTENT = "5";
  
  @RBEntry("There are no Resulting Objects in this {0}.\nAdd Resulting Objects to Proceed")
  public static final String NO_RES_OBJETCS = "6";
  
  @RBEntry("Following items are in Supplier Package(s).Please select the Update Supplier Package Option to proceed.\n{0}")
  public static final String ITEMS_IN_SUPPLIER_PKG = "7";
  
  @RBEntry("Please select atleast one check box for Implementation Plan.")
  public static final String IMPL_PLAN_REQD = "8";
  
  @RBEntry("The task cannot proceed until the below mentioned Resulting objects are not promoted to {0} state by their respective Design Package process - \n [{1}]\nTry completing this task after sometime.")
  public static final String SYNC_ITEMS = "9";
  
  @RBEntry("At least one of the users/group in {0} role should have modify access on all the affected items in Change Request.")
  public static final String NO_Modify_Access = "10";
  
  @RBEntry("The {0} selected {1} routing option. Please select {1} option to proceed.\nTo proceed with {2} option {3} the check box for {4}.")
  public static final String DESIGN_CHANGES_REQUIRED = "11";
  
  @RBEntry("Change items in the current Change Request have these unresolved Variances - \n{0}")
  public static final String ITEMS_IN_VARIANCE = "12";
  
  @RBEntry("There are no users assigned under these roles - \n{0}")
  public static final String NO_USERS = "13";
  
  @RBEntry("Change Items in the current Change Notice do not have Numeric Revisions - \n{0}.")
  public static final String INCORRECT_REVISION = "14";
  
  @RBEntry("Change items in the current Change Notice have these Variances neither in REJECTED nor RESOLVED states - \n{0}")
  public static final String ECN_ITEMS_IN_VARIANCE = "15";
  
  @RBEntry("Change items in the current Change Notice have these unresolved Variances - \n{0}")
  public static final String ECN_ITEMS_UNRESOLVED_VARIANCE = "16";
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\change\resource\ChangeResource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */