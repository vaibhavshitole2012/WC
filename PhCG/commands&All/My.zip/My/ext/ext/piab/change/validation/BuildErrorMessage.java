/*    */ package ext.piab.change.validation;
/*    */ 
/*    */ import wt.change2.Changeable2;
/*    */ import wt.change2.WTChangeRequest2;
/*    */ import wt.doc.WTDocument;
/*    */ import wt.enterprise.RevisionControlled;
/*    */ import wt.epm.EPMDocument;
/*    */ import wt.fc.WTObject;
/*    */ import wt.part.WTPart;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BuildErrorMessage
/*    */ {
/*    */   public static StringBuilder itemInCR(Changeable2 chObj, WTChangeRequest2 ecr, StringBuilder strBuilder) throws Exception {
/* 17 */     if (chObj instanceof EPMDocument) {
/* 18 */       strBuilder.append("\n[ EPM: (" + ((RevisionControlled)chObj).getName() + ") -ECR: (" + ecr.getNumber() + ") ]");
/*    */     }
/* 20 */     if (chObj instanceof WTPart) {
/* 21 */       strBuilder.append("\n[ WTPart: (" + ((RevisionControlled)chObj).getName() + ") -ECR: (" + ecr.getNumber() + ") ]");
/*    */     }
/* 23 */     if (chObj instanceof WTDocument) {
/* 24 */       strBuilder.append("\n[ WTDoc: (" + ((RevisionControlled)chObj).getName() + ") -ECR: (" + ecr.getNumber() + ") ]");
/*    */     }
/* 26 */     return strBuilder;
/*    */   }
/*    */ 
/*    */   
/*    */   public static StringBuilder itemsInValidStaes(WTObject wpo, String validStates, StringBuilder strBuilder) throws Exception {
/* 31 */     if (wpo instanceof WTPart) {
/* 32 */       WTPart part = (WTPart)wpo;
/* 33 */       strBuilder.append("\n[ WTPart: (" + part.getNumber() + ") -" + validStates + "]");
/* 34 */     }  if (wpo instanceof EPMDocument) {
/* 35 */       EPMDocument epm = (EPMDocument)wpo;
/* 36 */       strBuilder.append("\n[ EPM: (" + epm.getNumber() + ") -" + validStates + "]");
/*    */     } 
/* 38 */     if (wpo instanceof WTDocument) {
/* 39 */       WTDocument doc = (WTDocument)wpo;
/* 40 */       strBuilder.append("\n[ WTDoc: (" + doc.getNumber() + ") -" + validStates + "]");
/*    */     } 
/* 42 */     return strBuilder;
/*    */   }
/*    */ }


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\change\validation\BuildErrorMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */