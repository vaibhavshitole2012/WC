package ext.piab.change.util;

import ext.piab.change.resource.ChangeResource;
import ext.piab.change.variance.VarianceValidation;
import ext.piab.common.util.PropertyforPIAB;
import java.util.Enumeration;
import java.util.Vector;
import wt.change2.ChangeHelper2;
import wt.change2.ChangeOrderIfc;
import wt.change2.Changeable2;
import wt.change2.WTChangeOrder2;
import wt.change2.WTVariance;
import wt.fc.QueryResult;
import wt.fc.WTObject;
import wt.org.WTPrincipalReference;
import wt.project.Role;
import wt.team.Team;
import wt.team.TeamHelper;
import wt.team.TeamManaged;
import wt.util.WTException;

public class ChangeProcessUtility {
  private static final String CHANGE_RESOURCE = ChangeResource.class.getName();
  
  private static final boolean VERBOSE = PropertyforPIAB.VERBOSE;
  
  public static void checkIfRolesHaveUsers(WTObject paramWTObject, Vector<String> paramVector) throws Exception {
    if (VERBOSE)
      System.out.println("***ChangeProcessUtility.checkIfRolesHaveUsers()"); 
    StringBuilder stringBuilder = new StringBuilder();
    Vector<Role> vector1 = new Vector();
    TeamManaged teamManaged = (TeamManaged)paramWTObject;
    Team team = TeamHelper.service.getTeam(teamManaged);
    Vector<Role> vector2 = team.getRoles();
    byte b;
    for (b = 0; b < paramVector.size(); b++) {
      if (VERBOSE)
        System.out.println("Role : " + paramVector.elementAt(b)); 
      String str1 = paramVector.elementAt(b);
      for (byte b1 = 0; b1 < vector2.size(); b1++) {
        Role role = vector2.elementAt(b1);
        String str2 = role.getFullDisplay();
        if (str2.equalsIgnoreCase(str1)) {
          if (VERBOSE)
            System.out.println("***Got the RB role is " + str2); 
          vector1.add(role);
          break;
        } 
      } 
    } 
    for (b = 0; b < vector1.size(); b++) {
      Role role = vector1.elementAt(b);
      Enumeration<WTPrincipalReference> enumeration = team.getPrincipalTarget(role);
      if (enumeration.hasMoreElements()) {
        if (VERBOSE)
          System.out.println("***Role  - " + role.getFullDisplay() + " has users assigned"); 
        while (enumeration.hasMoreElements()) {
          WTPrincipalReference wTPrincipalReference = enumeration.nextElement();
          System.out.println("***User assigned for role - " + role.getFullDisplay() + " is " + wTPrincipalReference.getName());
        } 
      } else {
        if (VERBOSE)
          System.out.println("***Role - " + role.getFullDisplay() + " has no users assigned"); 
        stringBuilder.append("Role - " + role.getFullDisplay() + "\n");
      } 
    } 
    String str = stringBuilder.toString();
    if (!str.isEmpty()) {
      Object[] arrayOfObject = { str };
      throw new WTException(CHANGE_RESOURCE, "13", arrayOfObject);
    } 
  }
  
  public static void checkIfVarianceExists(WTObject paramWTObject, Vector<String> paramVector, boolean paramBoolean) throws Exception {
    if (VERBOSE)
      System.out.println("**ChangeProcessUtility.checkIfVarExists()  " + paramWTObject.getIdentity()); 
    StringBuilder stringBuilder1 = new StringBuilder();
    StringBuilder stringBuilder2 = new StringBuilder();
    QueryResult queryResult = ChangeHelper2.service.getReportedAgainstChangeIssue((Changeable2)paramWTObject);
    if (VERBOSE)
      System.out.println("***Size of relevant Variances : " + queryResult.size()); 
    while (queryResult.hasMoreElements()) {
      WTObject wTObject = (WTObject)queryResult.nextElement();
      if (wTObject instanceof WTVariance) {
        WTVariance wTVariance = (WTVariance)wTObject;
        for (byte b = 0; b < paramVector.size(); b++) {
          String str1 = paramVector.elementAt(b);
          if (VERBOSE)
            System.out.println("***Checking if the Variance " + wTVariance.getNumber() + " is in " + str1 + " State"); 
          if (paramBoolean) {
            if (!wTVariance.getLifeCycleState().toString().equalsIgnoreCase(str1)) {
              if (VERBOSE)
                System.out.println("***The variance " + wTVariance.getName() + " is in " + str1 + " State..."); 
              stringBuilder1 = VarianceValidation.itemsInVar((Changeable2)paramWTObject, wTVariance, stringBuilder1);
            } 
          } else if (wTVariance.getLifeCycleState().toString().equalsIgnoreCase(str1)) {
            if (VERBOSE)
              System.out.println("***The variance " + wTVariance.getName() + " is in " + str1 + " State..."); 
            stringBuilder2 = VarianceValidation.itemsInVar((Changeable2)paramWTObject, wTVariance, stringBuilder2);
          } 
        } 
      } 
    } 
    String str = stringBuilder1.toString();
    if (!str.isEmpty()) {
      if (VERBOSE)
        System.out.println("***Change Items in current Change Notice have these variances " + str + " which are not closed or rejected"); 
      Object[] arrayOfObject = { str };
      throw new WTException(CHANGE_RESOURCE, "15", arrayOfObject);
    } 
    str = stringBuilder2.toString();
    if (!str.isEmpty()) {
      if (VERBOSE)
        System.out.println("***Change Items in current Change Notice have these variances " + str + " which are unresolved"); 
      Object[] arrayOfObject = { str };
      throw new WTException(CHANGE_RESOURCE, "16", arrayOfObject);
    } 
  }
  
  public static Vector getAllCNItems(WTChangeOrder2 paramWTChangeOrder2) throws Exception {
    if (VERBOSE)
      System.out.println("***ChangeProcessUtility.getAllCNObjects() " + paramWTChangeOrder2.getNumber()); 
    QueryResult queryResult1 = ChangeHelper2.service.getChangeablesBefore((ChangeOrderIfc)paramWTChangeOrder2);
    if (VERBOSE)
      System.out.println("**Size of Affected Items " + queryResult1.size() + " for CN : " + paramWTChangeOrder2.getNumber()); 
    Vector<Changeable2> vector = new Vector();
    while (queryResult1.hasMoreElements()) {
      Changeable2 changeable2 = (Changeable2)queryResult1.nextElement();
      vector.add(changeable2);
      if (VERBOSE)
        System.out.println("**Added Changeable : " + changeable2.getIdentity()); 
    } 
    QueryResult queryResult2 = ChangeHelper2.service.getChangeablesAfter((ChangeOrderIfc)paramWTChangeOrder2);
    if (VERBOSE)
      System.out.println("**Size of Resulting Items " + queryResult2.size() + " for CN : " + paramWTChangeOrder2.getNumber()); 
    while (queryResult2.hasMoreElements()) {
      Changeable2 changeable2 = (Changeable2)queryResult2.nextElement();
      vector.add(changeable2);
      if (VERBOSE)
        System.out.println("**Added Changeable : " + changeable2.getIdentity()); 
    } 
    if (VERBOSE)
      System.out.println("**Size of all the Itmes of ECN are : " + vector.size()); 
    return vector;
  }
  
  public static void checkIfVarExists(Vector<Changeable2> paramVector, String paramString, boolean paramBoolean) throws Exception {
    if (VERBOSE)
      System.out.println("**ChangeProcessUtility.checkIfVarExists()  "); 
    StringBuilder stringBuilder1 = new StringBuilder();
    StringBuilder stringBuilder2 = new StringBuilder();
    for (byte b = 0; b < paramVector.size(); b++) {
      Changeable2 changeable2 = paramVector.elementAt(b);
      QueryResult queryResult = ChangeHelper2.service.getReportedAgainstChangeIssue(changeable2);
      while (queryResult.hasMoreElements()) {
        WTObject wTObject = (WTObject)queryResult.nextElement();
        if (wTObject instanceof WTVariance) {
          WTVariance wTVariance = (WTVariance)wTObject;
          if (VERBOSE)
            System.out.println("**Variance found : " + wTVariance.getNumber()); 
          String str1 = wTVariance.getLifeCycleState().toString();
          if (VERBOSE)
            System.out.println("***the Variance " + wTVariance.getNumber() + " is in " + str1 + " State"); 
          if (paramBoolean) {
            if (!paramString.contains(str1)) {
              if (VERBOSE)
                System.out.println("***The variance " + wTVariance.getName() + " is in not in this state :" + paramString); 
              stringBuilder1 = VarianceValidation.itemsInVar(changeable2, wTVariance, stringBuilder1);
            } 
            continue;
          } 
          if (paramString.contains(str1)) {
            if (VERBOSE)
              System.out.println("***The variance " + wTVariance.getName() + " is in " + paramString + " States"); 
            stringBuilder2 = VarianceValidation.itemsInVar(changeable2, wTVariance, stringBuilder2);
          } 
        } 
      } 
    } 
    String str = stringBuilder1.toString();
    if (!str.isEmpty()) {
      if (VERBOSE)
        System.out.println("***Change Items in current Change Notice have these variances " + str + " which are in these states : " + paramString); 
      Object[] arrayOfObject = { str };
      throw new WTException(CHANGE_RESOURCE, "15", arrayOfObject);
    } 
    str = stringBuilder2.toString();
    if (!str.isEmpty()) {
      if (VERBOSE)
        System.out.println("***Change Items in current Change Notice have these variances " + str + " which are unresolved"); 
      Object[] arrayOfObject = { str };
      throw new WTException(CHANGE_RESOURCE, "16", arrayOfObject);
    } 
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\chang\\util\ChangeProcessUtility.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */