package ext.piab.change.variance;

import ext.piab.common.util.PropertyforPIAB;
import ext.piab.common.util.Teamhelper;
import java.util.ArrayList;
import java.util.Enumeration;
import wt.change2.ChangeHelper2;
import wt.change2.ChangeIssueIfc;
import wt.change2.Changeable2;
import wt.change2.WTVariance;
import wt.fc.QueryResult;
import wt.fc.WTObject;
import wt.org.WTGroup;
import wt.org.WTPrincipal;
import wt.org.WTPrincipalReference;
import wt.project.Role;
import wt.team.Team;
import wt.team.TeamHelper;
import wt.team.TeamManaged;

public class VarianceHandler {
  private static boolean VERBOSE = PropertyforPIAB.VERBOSE;
  
  public static void assignGroupUsers(WTObject paramWTObject, String paramString1, String paramString2) throws Exception {
    if (VERBOSE)
      System.out.println("***VarianceHandler.assignGroupUsers()"); 
    ArrayList<WTPrincipalReference> arrayList = new ArrayList();
    try {
      TeamManaged teamManaged = (TeamManaged)paramWTObject;
      Team team = TeamHelper.service.getTeam(teamManaged);
      Teamhelper teamhelper = new Teamhelper();
      Role role = Role.toRole(paramString1.toUpperCase());
      WTGroup wTGroup = WTGroup.newWTGroup(paramString2);
      Enumeration<WTPrincipal> enumeration = wTGroup.members();
      while (enumeration.hasMoreElements()) {
        WTPrincipal wTPrincipal = enumeration.nextElement();
        WTPrincipalReference wTPrincipalReference = WTPrincipalReference.newWTPrincipalReference(wTPrincipal);
        arrayList.add(wTPrincipalReference);
      } 
      if (VERBOSE)
        System.out.println("***Users size : " + arrayList.size()); 
      Teamhelper.copyUsers(team, role, arrayList);
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  public static ArrayList itemsInVariance(WTVariance paramWTVariance) throws Exception {
    if (VERBOSE)
      System.out.println("***VarianceHandler.itemsInVariance()"); 
    ArrayList<Changeable2> arrayList = new ArrayList();
    QueryResult queryResult = ChangeHelper2.service.getChangeables((ChangeIssueIfc)paramWTVariance);
    System.out.println("**No.of items in Variance are : " + queryResult.size());
    while (queryResult.hasMoreElements()) {
      Changeable2 changeable2 = (Changeable2)queryResult.nextElement();
      arrayList.add(changeable2);
    } 
    return arrayList;
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\change\variance\VarianceHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */