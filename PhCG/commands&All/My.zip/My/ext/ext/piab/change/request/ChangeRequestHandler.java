package ext.piab.change.request;

import com.ptc.core.foundation.type.server.impl.TypeHelper;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.TypeIdentifierHelper;
import ext.piab.change.resource.ChangeResource;
import ext.piab.change.util.NotifyPackageOwners;
import ext.piab.change.util.PackageOwners;
import ext.piab.change.variance.VarianceValidation;
import ext.piab.common.util.LifecycleStateHelper;
import ext.piab.common.util.PropertyforPIAB;
import java.io.File;
import java.io.FileInputStream;
import java.util.HashMap;
import wt.change2.ChangeHelper2;
import wt.change2.ChangeRequestIfc;
import wt.change2.Changeable2;
import wt.change2.WTChangeOrder2;
import wt.change2.WTChangeRequest2;
import wt.change2.WTVariance;
import wt.content.ApplicationData;
import wt.content.ContentHelper;
import wt.content.ContentHolder;
import wt.content.ContentRoleType;
import wt.content.ContentServerHelper;
import wt.enterprise.RevisionControlled;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.WTObject;
import wt.org.WTPrincipal;
import wt.pom.Transaction;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.vc.VersionControlHelper;
import wt.vc.Versioned;

public class ChangeRequestHandler {
  private static final String LCSTATE_CANCELLED = PropertyforPIAB.LCSTATE_CANCELLED;
  
  private static final String LCSTATE_RESOLVED = PropertyforPIAB.LCSTATE_RESOLVED;
  
  private static final String LCSTATE_APPROVED = PropertyforPIAB.LCSTATE_APPROVED;
  
  private static final String CHANGE_RESOURCE = ChangeResource.class.getName();
  
  private static final boolean VERBOSE = PropertyforPIAB.VERBOSE;
  
  public static void changeReqState(WTChangeRequest2 paramWTChangeRequest2, String paramString) throws Exception {
    if (VERBOSE)
      System.out.println("*** ChangeRequestHandler.changeReqState:(" + paramWTChangeRequest2.getName() + "," + paramString + ")"); 
    paramWTChangeRequest2 = (WTChangeRequest2)LifecycleStateHelper.setLifecycleState((Persistable)paramWTChangeRequest2, paramString);
    if (VERBOSE)
      System.out.println("***Changed life cycle state of " + paramWTChangeRequest2.getName() + " with state as " + paramWTChangeRequest2.getState()); 
    HashMap hashMap = new HashMap();
    Changeable2 changeable2 = null;
    if (paramString.equalsIgnoreCase(LCSTATE_CANCELLED) || paramString.equalsIgnoreCase(LCSTATE_RESOLVED)) {
      QueryResult queryResult = ChangeHelper2.service.getChangeables((ChangeRequestIfc)paramWTChangeRequest2);
      if (VERBOSE)
        System.out.println("*** Query Result.Size " + queryResult.size()); 
      while (queryResult.hasMoreElements()) {
        changeable2 = (Changeable2)queryResult.nextElement();
        if (VERBOSE)
          System.out.println("*** Sending Mail for change Object" + changeable2); 
        hashMap = PackageOwners.getRelatedPackages((Persistable)changeable2, hashMap);
      } 
      if (!hashMap.isEmpty()) {
        if (VERBOSE)
          System.out.println("Project MAP-" + hashMap); 
        NotifyPackageOwners.emailMsg(hashMap, (Persistable)paramWTChangeRequest2);
      } 
    } 
  }
  
  public static WTChangeRequest2 getChangeRequest(WTChangeOrder2 paramWTChangeOrder2) {
    if (VERBOSE)
      System.out.println("ChangeRequestHandler.getChangeRequest(" + paramWTChangeOrder2.getName() + ")"); 
    WTChangeRequest2 wTChangeRequest2 = null;
    try {
      wTChangeRequest2 = (WTChangeRequest2)ChangeHelper2.service.findChangeRequest(paramWTChangeOrder2);
    } catch (Exception exception) {
      exception.printStackTrace();
      if (VERBOSE)
        System.out.println("Exception while getting change request of Change Notice " + paramWTChangeOrder2.getNumber()); 
    } 
    if (VERBOSE)
      System.out.println("ChangeRequest" + wTChangeRequest2.getName() + "for order" + paramWTChangeOrder2.getName()); 
    return wTChangeRequest2;
  }
  
  public static void copyAttachments(WTChangeRequest2 paramWTChangeRequest2, WTChangeOrder2 paramWTChangeOrder2) throws Exception {
    if (VERBOSE)
      System.out.println("ChangeRequestHandler.copyAttachments(ECR : " + paramWTChangeRequest2.getName() + " to ECN : " + paramWTChangeOrder2.getName() + ")"); 
    WTPrincipal wTPrincipal = SessionHelper.manager.getPrincipal();
    SessionHelper.manager.setAdministrator();
    File file = null;
    FileInputStream fileInputStream = null;
    try {
      QueryResult queryResult = ContentHelper.service.getContentsByRole((ContentHolder)paramWTChangeRequest2, ContentRoleType.SECONDARY, false);
      while (queryResult.hasMoreElements()) {
        ApplicationData applicationData1 = (ApplicationData)queryResult.nextElement();
        System.out.println("ECN content : " + applicationData1.getFileName());
        ApplicationData applicationData2 = ApplicationData.newApplicationData((ContentHolder)paramWTChangeOrder2);
        applicationData2 = (ApplicationData)applicationData1.duplicate();
        PersistenceHelper.manager.save((Persistable)applicationData2);
        file = (File) ContentServerHelper.service.getStoredItemFile(applicationData2);
        fileInputStream = new FileInputStream(file);
        Transaction transaction = new Transaction();
        transaction.start();
        applicationData2.setRole(ContentRoleType.toContentRoleType("SECONDARY"));
        ContentServerHelper.service.updateContent((ContentHolder)paramWTChangeOrder2, applicationData2, fileInputStream);
        transaction.commit();
        System.out.println("ECN updated with content : " + applicationData2.getFileName());
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
      if (VERBOSE)
        System.out.println("Exception while propagatig attchments from ECR to ECN"); 
    } 
    SessionHelper.manager.setPrincipal(wTPrincipal.getName());
  }
  
  public static void checkForNumericRevision(WTChangeRequest2 paramWTChangeRequest2) throws Exception {
    if (VERBOSE)
      System.out.println("***ChangeRequestHandler.isNumericVersion : " + paramWTChangeRequest2.getIdentity()); 
    StringBuilder stringBuilder = new StringBuilder();
    QueryResult queryResult = ChangeHelper2.service.getChangeables((ChangeRequestIfc)paramWTChangeRequest2);
    if (VERBOSE)
      System.out.println("Size of Change Items : " + queryResult.size()); 
    while (queryResult.hasMoreElements()) {
      WTObject wTObject = (WTObject)queryResult.nextElement();
      System.out.println("***Revision of object is : " + VersionControlHelper.getVersionIdentifier((Versioned)wTObject).getValue().toString());
      String str1 = ((RevisionControlled)wTObject).getVersionInfo().getIdentifier().getValue();
      if (!Character.isDigit(str1.charAt(0))) {
        if (VERBOSE)
          System.out.println("***Object Revision is not numeric"); 
        continue;
      } 
      if (VERBOSE)
        System.out.println("***Object Revision is numeric"); 
      stringBuilder = checkIfWaiverExists(wTObject);
    } 
    String str = stringBuilder.toString();
    if (!str.isEmpty()) {
      if (VERBOSE)
        System.out.println("***Change Items in current Change Request have these variances " + str + " which are unresolved"); 
      Object[] arrayOfObject = { str };
      throw new WTException(CHANGE_RESOURCE, "12", arrayOfObject);
    } 
  }
  
  public static StringBuilder checkIfWaiverExists(WTObject paramWTObject) throws Exception {
    if (VERBOSE)
      System.out.println("**ChangeRequestHandler.checkIfVarianceExists()  " + paramWTObject.getIdentity()); 
    StringBuilder stringBuilder = new StringBuilder();
    QueryResult queryResult = ChangeHelper2.service.getReportedAgainstChangeIssue((Changeable2)paramWTObject);
    if (VERBOSE)
      System.out.println("***Size of relevant Variances : " + queryResult.size()); 
    while (queryResult.hasMoreElements()) {
      WTObject wTObject = (WTObject)queryResult.nextElement();
      if (wTObject instanceof WTVariance) {
        WTVariance wTVariance = (WTVariance)wTObject;
        TypeIdentifier typeIdentifier = TypeIdentifierHelper.getType(wTVariance);
        String str = TypeHelper.getLocalizedTypeString(typeIdentifier, SessionHelper.getLocale());
        if (str.equalsIgnoreCase("WAIVER") && wTVariance.getLifeCycleState().toString().equalsIgnoreCase(LCSTATE_APPROVED)) {
          if (VERBOSE)
            System.out.println("***The variance " + wTVariance.getName() + " is in Approved State..."); 
          stringBuilder = VarianceValidation.itemsInVar((Changeable2)paramWTObject, wTVariance, stringBuilder);
          continue;
        } 
        if (VERBOSE)
          System.out.println("***The variance " + wTVariance.getName() + " is not in Approved State..."); 
      } 
    } 
    if (VERBOSE)
      System.out.println("###Msg : " + stringBuilder); 
    return stringBuilder;
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\change\request\ChangeRequestHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */