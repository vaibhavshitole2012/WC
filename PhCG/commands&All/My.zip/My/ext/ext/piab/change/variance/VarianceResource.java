package ext.piab.change.variance;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

@RBUUID("ext.piab.change.variance.VarianceResource")
public final class VarianceResource extends WTListResourceBundle {
  @RBEntry("There are no affected objects to the Variance - {0}")
  public static final String NO_ITEMS_IN_VARIANCE = "1";
  
  @RBEntry("Items in the current Variance have these unresolved Variances - \n{0}")
  public static final String UNRESOLVED_VAR = "2";
  
  @RBEntry("Please verify if the below objects are in the mentioned states - \n{0}")
  public static final String CHECK_LC_STATE = "3";
  
  @RBEntry("There are no users assigned for these roles - \n{0}")
  public static final String NO_USERS_EXIST = "4";
  
  @RBEntry("Please enter the End Date of Variance \n{0}\n greater than Today's date")
  public static final String CHECK_FINISH_DATE = "5";
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\change\variance\VarianceResource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */