package ext.piab.change.util;

import ext.piab.common.util.PropertyforPIAB;
import java.sql.Timestamp;
import java.util.Calendar;
import wt.change2.WTChangeOrder2;
import wt.change2.WTChangeRequest2;
import wt.change2.WTVariance;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.WTObject;
import wt.pom.Transaction;
import wt.util.WTContext;
import wt.util.WTException;

public class ResolveChanges {
  private static final boolean VERBOSE = PropertyforPIAB.VERBOSE;
  
  public static void setResolutionDate(WTObject paramWTObject) {
    if (VERBOSE)
      System.out.println("***ResolveChanges.setResolutionDate()"); 
    Timestamp timestamp = new Timestamp(getServerTimeStamp());
    Transaction transaction = new Transaction();
    try {
      transaction.start();
      if (paramWTObject instanceof WTChangeRequest2) {
        WTChangeRequest2 wTChangeRequest2 = (WTChangeRequest2)paramWTObject;
        wTChangeRequest2.setResolutionDate(timestamp);
        PersistenceHelper.manager.save((Persistable)wTChangeRequest2);
      } else if (paramWTObject instanceof WTChangeOrder2) {
        WTChangeOrder2 wTChangeOrder2 = (WTChangeOrder2)paramWTObject;
        wTChangeOrder2.setResolutionDate(timestamp);
        PersistenceHelper.manager.save((Persistable)wTChangeOrder2);
      } else if (paramWTObject instanceof WTVariance) {
        WTVariance wTVariance = (WTVariance)paramWTObject;
        wTVariance.setResolutionDate(timestamp);
        PersistenceHelper.manager.save((Persistable)wTVariance);
      } 
      transaction.commit();
      transaction = null;
    } catch (WTException wTException) {
      wTException.printStackTrace();
      transaction.rollback();
      transaction = null;
    } finally {
      if (transaction != null) {
        transaction.rollback();
        transaction = null;
      } 
    } 
  }
  
  public static long getServerTimeStamp() {
    if (VERBOSE)
      System.out.println("***ResolveChanges.getServerTimeStamp"); 
    WTContext wTContext = WTContext.getContext();
    Calendar calendar = Calendar.getInstance(wTContext.getTimeZone(), wTContext.getLocale());
    return calendar.getTimeInMillis();
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\chang\\util\ResolveChanges.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */