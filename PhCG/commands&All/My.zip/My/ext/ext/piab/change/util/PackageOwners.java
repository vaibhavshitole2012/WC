package ext.piab.change.util;

import com.ptc.windchill.wp.AbstractWorkPackage;
import com.ptc.windchill.wp.WorkPackage;
import ext.piab.common.util.PropertyforPIAB;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.HashMap;
import wt.facade.persistedcollection.PersistedCollectionHelper;
import wt.facade.persistedcollection.PersistedCollectionMembership;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.collections.WTSet;
import wt.org.WTPrincipal;
import wt.org.WTPrincipalReference;
import wt.project.Role;
import wt.team.Team;
import wt.team.TeamHelper;
import wt.team.TeamManaged;
import wt.type.TypedUtility;

public class PackageOwners {
  private static final boolean VERBOSE = PropertyforPIAB.VERBOSE;
  
  private static final String DESIGN_PACKAGE_TYPE_NAME = PropertyforPIAB.DESIGN_PACKAGE_TYPE_NAME;
  
  private static final String VALIDSTATES_DESIGN_PKG = PropertyforPIAB.VALIDSTATES_DESIGN_PKG;
  
  private static final String SUPPLIER_PACKAGE_TYPE_NAME = PropertyforPIAB.SUPPLIER_PACKAGE_TYPE_NAME;
  
  private static final String VALIDSTATES_SUPPLIER_PKG = PropertyforPIAB.VALIDSTATES_SUPPLIER_PKG;
  
  private static final String DESIGN_ROLES = PropertyforPIAB.DESIGN_ROLES;
  
  private static final String SUPPLIER_ROLES = PropertyforPIAB.SUPPLIER_ROLES;
  
  public static HashMap getRelatedPackages(Persistable paramPersistable, HashMap<WTPrincipal, HashMap<Object, Object>> paramHashMap) throws Exception {
    if (VERBOSE)
      System.out.println("*** PackageOwners.getRelatedPackages()"); 
    HashMap<Object, Object> hashMap = null;
    ArrayList<Persistable> arrayList = null;
    try {
      PersistedCollectionMembership persistedCollectionMembership = PersistedCollectionHelper.service.getMemberOf(paramPersistable);
      WTSet wTSet = (WTSet)persistedCollectionMembership.getDirectSet().subCollection(AbstractWorkPackage.class);
      wTSet.addAll((Collection)persistedCollectionMembership.getNestedSet().subCollection(AbstractWorkPackage.class));
      Object[] arrayOfObject = wTSet.toArray();
      for (byte b = 0; b < arrayOfObject.length; b++) {
        ObjectReference objectReference = (ObjectReference)arrayOfObject[b];
        WorkPackage workPackage = (WorkPackage)objectReference.getObject();
        String str1 = workPackage.getLifeCycleState().toString();
        String str2 = TypedUtility.getTypeIdentifier(workPackage).toString();
        if (VERBOSE)
          System.out.println("***WorkPackage-" + str1); 
        if ((str2.endsWith(DESIGN_PACKAGE_TYPE_NAME) && VALIDSTATES_DESIGN_PKG.contains(str1)) || (str2.endsWith(SUPPLIER_PACKAGE_TYPE_NAME) && VALIDSTATES_SUPPLIER_PKG.contains(str1))) {
          if (VERBOSE)
            System.out.println("Inside If Workpackage Number...... " + workPackage.getNumber()); 
          Team team = TeamHelper.service.getTeam((TeamManaged)workPackage);
          String str = null;
          if (TypedUtility.getTypeIdentifier(workPackage).toString().endsWith(DESIGN_PACKAGE_TYPE_NAME)) {
            str = DESIGN_ROLES;
          } else if (TypedUtility.getTypeIdentifier(workPackage).toString().endsWith(SUPPLIER_PACKAGE_TYPE_NAME)) {
            str = SUPPLIER_ROLES;
          } 
          String[] arrayOfString = str.split(",");
          for (byte b1 = 0; b1 < arrayOfString.length; b1++) {
            if (VERBOSE)
              System.out.println("splitted role" + arrayOfString[b1]); 
            Role role = Role.toRole(arrayOfString[b1]);
            Enumeration<WTPrincipalReference> enumeration = team.getPrincipalTarget(role);
            while (enumeration.hasMoreElements()) {
              WTPrincipalReference wTPrincipalReference = enumeration.nextElement();
              WTPrincipal wTPrincipal = wTPrincipalReference.getPrincipal();
              hashMap = (HashMap)paramHashMap.get(wTPrincipal);
              if (hashMap == null) {
                hashMap = new HashMap<>();
                arrayList = new ArrayList();
                arrayList.add(paramPersistable);
                hashMap.put(workPackage, arrayList);
              } else {
                arrayList = (ArrayList<Persistable>)hashMap.get(workPackage);
                if (arrayList == null)
                  arrayList = new ArrayList<>(); 
                arrayList.add(paramPersistable);
                hashMap.put(workPackage, arrayList);
              } 
              paramHashMap.put(wTPrincipal, hashMap);
            } 
          } 
        } 
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return paramHashMap;
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\chang\\util\PackageOwners.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */