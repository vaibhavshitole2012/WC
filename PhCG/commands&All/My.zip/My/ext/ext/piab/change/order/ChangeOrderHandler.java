package ext.piab.change.order;

import com.ptc.core.foundation.type.server.impl.TypeHelper;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.TypeIdentifierHelper;
import com.ptc.windchill.enterprise.change2.ChangeManagementClientHelper;
import ext.piab.change.activity.ChangeActivityHandler;
import ext.piab.change.util.NotifyPackageOwners;
import ext.piab.change.util.PackageOwners;
import ext.piab.change.util.WTChangeUtility;
import ext.piab.common.util.LifecycleStateHelper;
import ext.piab.common.util.PropertyforPIAB;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;
import wt.change2.ChangeHelper2;
import wt.change2.ChangeNoticeComplexity;
import wt.change2.ChangeOrderIfc;
import wt.change2.ChangeRequestIfc;
import wt.change2.Changeable2;
import wt.change2.Complexity;
import wt.change2.WTChangeOrder2;
import wt.change2.WTChangeRequest2;
import wt.change2.WTVariance;
import wt.enterprise.RevisionControlled;
import wt.enterprise._RevisionControlled;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.fc.WTObject;
import wt.fc.collections.WTArrayList;
import wt.httpgw.URLFactory;
import wt.inf.container.WTContainer;
import wt.lifecycle.LifeCycleHelper;
import wt.lifecycle.LifeCycleManaged;
import wt.lifecycle.State;
import wt.session.SessionHelper;
import wt.util.WTException;

public class ChangeOrderHandler {
  private static final String LCSTATE_CANCELLED = PropertyforPIAB.LCSTATE_CANCELLED;
  
  private static final String LCSTATE_RELEASED = PropertyforPIAB.LCSTATE_RELEASED;
  
  private static final String LC_STATE_1 = PropertyforPIAB.LC_STATE_1;
  
  private static final boolean VERBOSE = PropertyforPIAB.VERBOSE;
  
  public static void changeNoticeState(WTChangeOrder2 paramWTChangeOrder2, String paramString) throws Exception {
    if (VERBOSE)
      System.out.println("*** ChangeOrderHandler.changeNoticeState(" + paramWTChangeOrder2.getName() + "," + paramString + ")"); 
    paramWTChangeOrder2 = (WTChangeOrder2)LifecycleStateHelper.setLifecycleState((Persistable)paramWTChangeOrder2, paramString);
    if (VERBOSE)
      System.out.println("***Changed life cycle state of " + paramWTChangeOrder2 + " with state as " + paramWTChangeOrder2.getLifeCycleState().toString()); 
    if (paramString.equalsIgnoreCase(LCSTATE_CANCELLED) || paramString.equalsIgnoreCase(LCSTATE_RELEASED)) {
      QueryResult queryResult = ChangeHelper2.service.getChangeablesAfter((ChangeOrderIfc)paramWTChangeOrder2);
      //HashMap<Object, Object> hashMap = new HashMap<>();
      HashMap hashMap = new HashMap();
      while (queryResult.hasMoreElements()) {
        Changeable2 changeable2 = (Changeable2)queryResult.nextElement();
        hashMap = PackageOwners.getRelatedPackages((Persistable)changeable2, hashMap);
        if (VERBOSE)
          System.out.println("***changeObj: [" + changeable2 + "] Version is  [" + ((RevisionControlled)changeable2).getVersionIdentifier().getValue() + "]"); 
        if (paramString.toUpperCase().equalsIgnoreCase(LCSTATE_CANCELLED)) {
          changeable2 = (Changeable2)LifeCycleHelper.service.setLifeCycleState((LifeCycleManaged)changeable2, State.toState(LC_STATE_1));
          if (VERBOSE)
            System.out.println("Changed life cycle state of " + changeable2 + "--" + ((_RevisionControlled)changeable2).getVersionIdentifier().getValue() + " with state as " + ((RevisionControlled)changeable2).getState().toString()); 
        } 
      } 
      if (!hashMap.isEmpty()) {
        if (VERBOSE)
          System.out.println("Package MAP...... " + hashMap); 
        NotifyPackageOwners.emailMsg(hashMap, (Persistable)paramWTChangeOrder2);
      } 
    } 
  }
  
  public static void createECN(WTChangeRequest2 paramWTChangeRequest2) throws Exception {
    if (VERBOSE)
      System.out.println("*** ChangeOrderHandler.createECN(" + paramWTChangeRequest2.getName() + ")"); 
    WTContainer wTContainer = paramWTChangeRequest2.getContainer();
    WTChangeOrder2 wTChangeOrder2 = WTChangeOrder2.newWTChangeOrder2(paramWTChangeRequest2.getName());
    wTChangeOrder2 = setComplexity(wTChangeOrder2, paramWTChangeRequest2.getComplexity());
    wTChangeOrder2.setContainer(wTContainer);
    //wTChangeOrder2 = (WTChangeOrder2)ChangeHelper2.service.saveChangeOrder((ChangeRequestIfc)paramWTChangeRequest2, (ChangeOrderIfc)wTChangeOrder2);
    //changed by cts for deprecated API
    wTChangeOrder2 = (WTChangeOrder2)ChangeHelper2.service.saveChangeOrder((ChangeRequestIfc)paramWTChangeRequest2, (ChangeOrderIfc)wTChangeOrder2, false);

    wTChangeOrder2 = (WTChangeOrder2)PersistenceHelper.manager.refresh((Persistable)wTChangeOrder2);
    if (VERBOSE)
      System.out.println("*** created ECN [" + wTChangeOrder2.getNumber() + "]in container [" + wTContainer.getName() + "]"); 
    WTArrayList wTArrayList = WTChangeUtility.addObjectstoArray((Persistable)paramWTChangeRequest2, false);
    String str = ChangeManagementClientHelper.defaultChangeTask_getName(paramWTChangeRequest2);
    ChangeActivityHandler.createECA(wTChangeOrder2, wTArrayList, str.trim());
  }
  
  private static WTChangeOrder2 setComplexity(WTChangeOrder2 paramWTChangeOrder2, Complexity paramComplexity) {
    if (VERBOSE)
      System.out.println("*** ChangeOrderHandler.setComplexity()"); 
    try {
      if (paramComplexity.getStringValue().equals("wt.change2.Complexity.SIMPLE")) {
        paramWTChangeOrder2.setChangeNoticeComplexity(ChangeNoticeComplexity.SIMPLE);
      } else if (paramComplexity.getStringValue().equals("wt.change2.Complexity.COMPLEX")) {
        paramWTChangeOrder2.setChangeNoticeComplexity(ChangeNoticeComplexity.COMPLEX);
      } else {
        paramWTChangeOrder2.setChangeNoticeComplexity(ChangeNoticeComplexity.BASIC);
      } 
      if (VERBOSE)
        System.out.println("22222" + paramWTChangeOrder2.getChangeNoticeComplexity().getStringValue()); 
      if (VERBOSE)
        System.out.println("33333" + paramWTChangeOrder2.getChangeNoticeComplexity().getDisplay()); 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    return paramWTChangeOrder2;
  }
  
  public static String getVarianceReportLink(WTObject paramWTObject, String paramString) throws WTException, Exception {
    if (VERBOSE)
      System.out.println("***ChangeOrderHandler.getVarianceReportLink " + paramWTObject.getDisplayIdentity()); 
    String str1 = "";
    WTChangeOrder2 wTChangeOrder2 = (WTChangeOrder2)paramWTObject;
    QueryResult queryResult1 = ChangeHelper2.service.getChangeablesBefore((ChangeOrderIfc)wTChangeOrder2);
    if (VERBOSE)
      System.out.println("**Size of Affected Items : " + queryResult1.size()); 
    QueryResult queryResult2 = ChangeHelper2.service.getChangeablesAfter((ChangeOrderIfc)wTChangeOrder2);
    if (VERBOSE)
      System.out.println("**Size of Resulting Items : " + queryResult2.size()); 
    HashMap<Object, Object> hashMap = new HashMap<>();
    String str2 = "";
    while (queryResult1.hasMoreElements()) {
      Changeable2 changeable2 = (Changeable2)queryResult1.nextElement();
      QueryResult queryResult = ChangeHelper2.service.getReportedAgainstChangeIssue(changeable2);
      Vector<WTVariance> vector = new Vector();
      while (queryResult.hasMoreElements()) {
        WTObject wTObject = (WTObject)queryResult.nextElement();
        if (wTObject instanceof WTVariance) {
          WTVariance wTVariance = (WTVariance)wTObject;
          str2 = wTVariance.getLifeCycleState().toString();
          if (paramString.contains(str2)) {
            if (VERBOSE)
              System.out.println("**Variance found : " + wTVariance.getNumber() + " state " + str2 + " for affected item : " + changeable2.getIdentity()); 
            vector.add(wTVariance);
          } 
        } 
      } 
      if (vector.size() > 0)
        hashMap.put(changeable2, vector); 
    } 
    while (queryResult2.hasMoreElements()) {
      Changeable2 changeable2 = (Changeable2)queryResult2.nextElement();
      QueryResult queryResult = ChangeHelper2.service.getReportedAgainstChangeIssue(changeable2);
      Vector<WTVariance> vector = new Vector();
      while (queryResult.hasMoreElements()) {
        WTObject wTObject = (WTObject)queryResult.nextElement();
        if (wTObject instanceof WTVariance) {
          WTVariance wTVariance = (WTVariance)wTObject;
          str2 = wTVariance.getLifeCycleState().toString();
          if (paramString.contains(str2)) {
            if (VERBOSE)
              System.out.println("**Variance found : " + wTVariance.getNumber() + " state " + str2 + " for resulting item : " + changeable2.getIdentity()); 
            vector.add(wTVariance);
          } 
        } 
      } 
      if (vector.size() > 0)
        hashMap.put(changeable2, vector); 
    } 
    if (hashMap.size() > 0)
      str1 = getVarianceReportTable(hashMap); 
    return str1;
  }
  
  public static String getVarianceReportTable(HashMap paramHashMap) throws Exception {
    StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append("<TABLE BORDER='1' CELLPADDING='10'>");
    stringBuffer.append("<TR ALIGN='CENTER'>");
    stringBuffer.append("<TH>Item</TH><TH>Variance</TH><TH>Type</TH>");
    stringBuffer.append("</TR>");
    Iterator<WTObject> iterator = paramHashMap.keySet().iterator();
    while (iterator.hasNext()) {
      stringBuffer.append("<TR ALIGN='CENTER'>");
      WTObject wTObject = iterator.next();
      Vector<WTVariance> vector = (Vector)paramHashMap.get(wTObject);
      System.out.println("**Temp size:" + vector.size());
      stringBuffer.append("<TD rowspan='" + vector.size() + "'>" + wTObject.getDisplayIdentity() + "</TD>");
      for (byte b = 0; b < vector.size(); b++) {
        WTVariance wTVariance = vector.get(b);
        HashMap<Object, Object> hashMap = new HashMap<>();
        String str1 = "&nbsp;";
        try {
          hashMap.put("oid", (new ReferenceFactory()).getReferenceString((Persistable)wTVariance));
          String str = (new URLFactory()).getHREF("app/#ptc1/tcomp/infoPage", hashMap);
          str1 = "<A href='" + str + "'>" + wTVariance.getNumber() + "</A>";
        } catch (Exception exception) {
          exception.printStackTrace();
        } 
        stringBuffer.append("<TD>" + str1 + "</TD>");
        TypeIdentifier typeIdentifier = TypeIdentifierHelper.getType(wTVariance);
        String str2 = TypeHelper.getLocalizedTypeString(typeIdentifier, SessionHelper.getLocale());
        System.out.println("Type: " + str2);
        stringBuffer.append("<TD>" + str2 + "</TD>");
        stringBuffer.append("</TR>");
      } 
      if (vector.size() == 0)
        stringBuffer.append("</TR>"); 
    } 
    stringBuffer.append("</TABLE>");
    stringBuffer.append("<br/>");
    System.out.println(stringBuffer.toString());
    return stringBuffer.toString();
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\change\order\ChangeOrderHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */