package ext.piab.change.variance;

import com.ptc.core.foundation.type.server.impl.TypeHelper;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.TypeIdentifierHelper;
import ext.piab.common.util.IBAUtil;
import ext.piab.common.util.PropertyforPIAB;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.Vector;
import wt.change2.ChangeHelper2;
import wt.change2.ChangeIssueIfc;
import wt.change2.Changeable2;
import wt.change2.WTVariance;
import wt.doc.WTDocument;
import wt.enterprise.RevisionControlled;
import wt.epm.EPMDocument;
import wt.fc.QueryResult;
import wt.fc.WTObject;
import wt.iba.value.IBAHolder;
import wt.org.WTPrincipalReference;
import wt.part.WTPart;
import wt.project.Role;
import wt.session.SessionHelper;
import wt.team.Team;
import wt.team.TeamHelper;
import wt.team.TeamManaged;
import wt.util.WTException;

public class VarianceValidation {
  private static boolean VERBOSE = PropertyforPIAB.VERBOSE;
  
  private static final String VARIANCE_RESOURCE = VarianceResource.class.getName();
  
  private static final String LCSTATE_REJECTED = "REJECTED";
  
  private static final String LCSTATE_OPEN = PropertyforPIAB.LCSTATE_OPEN;
  
  private static final String LCSTATE_APPROVED = PropertyforPIAB.LCSTATE_APPROVED;
  
  private static final String LCSTATE_UNDERREVIEW = PropertyforPIAB.LCSTATE_UNDERREVIEW;
  
  private static final String LC_STATE_3 = PropertyforPIAB.LC_STATE_3;
  
  private static final String LC_STATE_4 = PropertyforPIAB.LC_STATE_4;
  
  public static StringBuilder itemsInVar(Changeable2 paramChangeable2, WTVariance paramWTVariance, StringBuilder paramStringBuilder) throws Exception {
    TypeIdentifier typeIdentifier = TypeIdentifierHelper.getType(paramWTVariance);
    String str = TypeHelper.getLocalizedTypeString(typeIdentifier, SessionHelper.getLocale());
    if (paramChangeable2 instanceof EPMDocument)
      paramStringBuilder.append("\n[ EPM: (" + ((RevisionControlled)paramChangeable2).getName() + ") -" + str + ": (" + paramWTVariance.getNumber() + ") ]"); 
    if (paramChangeable2 instanceof WTPart)
      paramStringBuilder.append("\n[ WTPart: (" + ((RevisionControlled)paramChangeable2).getName() + ") -" + str + ": (" + paramWTVariance.getNumber() + ") ]"); 
    if (paramChangeable2 instanceof WTDocument)
      paramStringBuilder.append("\n[ WTDoc: (" + ((RevisionControlled)paramChangeable2).getName() + ") -" + str + ": (" + paramWTVariance.getNumber() + ") ]"); 
    return paramStringBuilder;
  }
  
  public static StringBuilder itemsInValidStates(WTObject paramWTObject, String paramString, StringBuilder paramStringBuilder) throws Exception {
    if (paramWTObject instanceof WTPart) {
      WTPart wTPart = (WTPart)paramWTObject;
      paramStringBuilder.append("\n[ WTPart: (" + wTPart.getNumber() + ") -" + paramString + "]");
    } 
    if (paramWTObject instanceof EPMDocument) {
      EPMDocument ePMDocument = (EPMDocument)paramWTObject;
      paramStringBuilder.append("\n[ EPM: (" + ePMDocument.getNumber() + ") -" + paramString + "]");
    } 
    if (paramWTObject instanceof WTDocument) {
      WTDocument wTDocument = (WTDocument)paramWTObject;
      paramStringBuilder.append("\n[ WTDoc: (" + wTDocument.getNumber() + ") -" + paramString + "]");
    } 
    return paramStringBuilder;
  }
  
  public static void checkItems(WTVariance paramWTVariance) throws Exception {
    if (VERBOSE)
      System.out.println("***VarianceHandler.checkItems()"); 
    QueryResult queryResult = checkAffectedExist(paramWTVariance);
    StringBuilder stringBuilder = new StringBuilder();
    while (queryResult.hasMoreElements()) {
      Changeable2 changeable2 = (Changeable2)queryResult.nextElement();
      QueryResult queryResult1 = ChangeHelper2.service.getReportedAgainstChangeIssue(changeable2);
      if (VERBOSE)
        System.out.println("***Size of relevant Variances : " + queryResult1.size()); 
      while (queryResult1.hasMoreElements()) {
        WTObject wTObject = (WTObject)queryResult1.nextElement();
        if (wTObject instanceof WTVariance) {
          WTVariance wTVariance = (WTVariance)wTObject;
          if (wTVariance.equals(paramWTVariance)) {
            if (VERBOSE)
              System.out.println("***" + wTVariance.getName() + " is the current Variance"); 
            continue;
          } 
          if (wTVariance.getLifeCycleState().toString().equalsIgnoreCase(LCSTATE_OPEN) || wTVariance.getLifeCycleState().toString().equalsIgnoreCase(LCSTATE_APPROVED) || wTVariance.getLifeCycleState().toString().equalsIgnoreCase(LCSTATE_UNDERREVIEW)) {
            stringBuilder = itemsInVar(changeable2, wTVariance, stringBuilder);
            if (VERBOSE)
              System.out.println("***The variance " + wTVariance.getName() + " is in these Unresolved variances"); 
            continue;
          } 
          if (VERBOSE)
            System.out.println("***The variance " + wTVariance.getName() + " not in any other Unresolved variances"); 
        } 
      } 
    } 
    String str = stringBuilder.toString();
    if (!str.isEmpty()) {
      if (VERBOSE)
        System.out.println("***Change Items in current Variance have these variances " + str + " which are unresolved"); 
      Object[] arrayOfObject = { str };
      throw new WTException(VARIANCE_RESOURCE, "2", arrayOfObject);
    } 
  }
  
  public static QueryResult checkAffectedExist(WTVariance paramWTVariance) throws Exception {
    if (VERBOSE)
      System.out.println("***VarianceHandler.checkAffectedExist()"); 
    QueryResult queryResult = ChangeHelper2.service.getChangeables((ChangeIssueIfc)paramWTVariance);
    System.out.println("***Changeables size : " + queryResult.size());
    if (!queryResult.hasMoreElements()) {
      if (VERBOSE)
        System.out.println("***No Affected Data for the Variance " + paramWTVariance.getName()); 
      Object[] arrayOfObject = { paramWTVariance.getName() };
      throw new WTException(VARIANCE_RESOURCE, "1", arrayOfObject);
    } 
    return queryResult;
  }
  
  public static void checkItemsState(WTVariance paramWTVariance) throws Exception {
    if (VERBOSE)
      System.out.println("***VarianceHandler.checkItemsState()"); 
    QueryResult queryResult = ChangeHelper2.service.getChangeables((ChangeIssueIfc)paramWTVariance);
    if (VERBOSE)
      System.out.println("***Size of items in Variance : " + queryResult.size()); 
    StringBuilder stringBuilder = new StringBuilder();
    String str = LC_STATE_3 + "," + LC_STATE_4;
    if (VERBOSE)
      System.out.println("***Valid States are : " + str); 
    while (queryResult.hasMoreElements()) {
      Changeable2 changeable2 = (Changeable2)queryResult.nextElement();
      if (changeable2 instanceof WTPart) {
        WTPart wTPart = (WTPart)changeable2;
        if (wTPart.getLifeCycleState().toString().equalsIgnoreCase(LC_STATE_3) || wTPart.getLifeCycleState().toString().equalsIgnoreCase(LC_STATE_4)) {
          if (VERBOSE)
            System.out.println("***State of [ " + wTPart.getNumber() + " ] is a valid state"); 
        } else {
          stringBuilder = itemsInValidStates((WTObject)wTPart, str, stringBuilder);
        } 
      } else if (changeable2 instanceof WTDocument) {
        WTDocument wTDocument = (WTDocument)changeable2;
        if (wTDocument.getLifeCycleState().toString().equalsIgnoreCase(LC_STATE_3) || wTDocument.getLifeCycleState().toString().equalsIgnoreCase(LC_STATE_4)) {
          if (VERBOSE)
            System.out.println("***State of [ " + wTDocument.getNumber() + " ] is a valid state"); 
        } else {
          stringBuilder = itemsInValidStates((WTObject)wTDocument, str, stringBuilder);
        } 
      } else if (changeable2 instanceof EPMDocument) {
        EPMDocument ePMDocument = (EPMDocument)changeable2;
        if (ePMDocument.getLifeCycleState().toString().equalsIgnoreCase(LC_STATE_3) || ePMDocument.getLifeCycleState().toString().equalsIgnoreCase(LC_STATE_4)) {
          if (VERBOSE)
            System.out.println("***State of [ " + ePMDocument.getNumber() + " ] is a valid state"); 
        } else {
          stringBuilder = itemsInValidStates((WTObject)ePMDocument, str, stringBuilder);
        } 
      } 
      String str1 = stringBuilder.toString();
      if (!str1.isEmpty()) {
        Object[] arrayOfObject = { str1 };
        throw new WTException(VARIANCE_RESOURCE, "3", arrayOfObject);
      } 
    } 
  }
  
  public static void checkIfRolesHaveUsers(WTObject paramWTObject, Vector<String> paramVector) throws Exception {
    if (VERBOSE)
      System.out.println("***VarianceHandler.checkIfUserExists()"); 
    StringBuilder stringBuilder = new StringBuilder();
    Vector<Role> vector1 = new Vector();
    TeamManaged teamManaged = (TeamManaged)paramWTObject;
    Team team = TeamHelper.service.getTeam(teamManaged);
    Vector<Role> vector2 = team.getRoles();
    byte b;
    for (b = 0; b < paramVector.size(); b++) {
      if (VERBOSE)
        System.out.println("Role : " + paramVector.elementAt(b)); 
      String str1 = paramVector.elementAt(b);
      for (byte b1 = 0; b1 < vector2.size(); b1++) {
        Role role = vector2.elementAt(b1);
        String str2 = role.getFullDisplay();
        if (str2.equalsIgnoreCase(str1)) {
          if (VERBOSE)
            System.out.println("***Got the RB role is " + str2); 
          vector1.add(role);
          break;
        } 
      } 
    } 
    for (b = 0; b < vector1.size(); b++) {
      Role role = vector1.elementAt(b);
      Enumeration<WTPrincipalReference> enumeration = team.getPrincipalTarget(role);
      if (enumeration.hasMoreElements()) {
        if (VERBOSE)
          System.out.println("***Role  - " + role.getFullDisplay() + " has users assigned"); 
        while (enumeration.hasMoreElements()) {
          WTPrincipalReference wTPrincipalReference = enumeration.nextElement();
          System.out.println("***User assigned for role - " + role.getFullDisplay() + " is " + wTPrincipalReference.getName());
        } 
      } else {
        if (VERBOSE)
          System.out.println("***Role - " + role.getFullDisplay() + " has no users assigned"); 
        stringBuilder.append("Role - " + role.getFullDisplay());
      } 
    } 
    String str = stringBuilder.toString();
    if (!str.isEmpty()) {
      Object[] arrayOfObject = { str };
      throw new WTException(VARIANCE_RESOURCE, "4", arrayOfObject);
    } 
  }
  
  public static void checkEndDate(WTVariance paramWTVariance, String paramString) throws Exception {
    if (VERBOSE)
      System.out.println("***VarianceValidation.checkFinishDate() - " + paramString); 
    IBAUtil iBAUtil = new IBAUtil((IBAHolder)paramWTVariance);
    String str1 = iBAUtil.getIBAValue(paramString);
    StringBuilder stringBuilder = new StringBuilder();
    if (str1 != null) {
      if (VERBOSE)
        System.out.println("***End date is : " + str1); 
      Date date1 = new Date(str1);
      SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
      Date date2 = simpleDateFormat.parse(simpleDateFormat.format(new Date()));
      if (date1.after(date2) || date1.equals(date2)) {
        if (VERBOSE)
          System.out.println("***End Date :" + date1 + " is greater thatn today's date : " + date2); 
      } else {
        if (VERBOSE)
          System.out.println("***End Date : " + date1 + " is less than today's date : " + date2); 
        stringBuilder.append(date1);
      } 
    } else {
      if (VERBOSE)
        System.out.println("***End Date not entered.. Please Enter it"); 
      stringBuilder.append(" ");
    } 
    String str2 = stringBuilder.toString();
    if (!str2.isEmpty()) {
      Object[] arrayOfObject = { str2 };
      throw new WTException(VARIANCE_RESOURCE, "5", arrayOfObject);
    } 
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\change\variance\VarianceValidation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */