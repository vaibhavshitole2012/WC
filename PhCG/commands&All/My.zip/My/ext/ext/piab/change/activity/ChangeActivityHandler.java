package ext.piab.change.activity;

import ext.piab.common.util.IBAUtil;
import ext.piab.common.util.PropertyforPIAB;
import ext.piab.common.util.Teamhelper;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;
import wt.change2.AffectedActivityData;
import wt.change2.ChangeActivity2;
import wt.change2.ChangeActivityIfc;
import wt.change2.ChangeHelper2;
import wt.change2.ChangeOrderIfc;
import wt.change2.Changeable2;
import wt.change2.ExecutionMode;
import wt.change2.WTChangeActivity2;
import wt.change2.WTChangeOrder2;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.collections.WTArrayList;
import wt.iba.value.IBAHolder;
import wt.lifecycle.LifeCycleHelper;
import wt.lifecycle.LifeCycleManaged;
import wt.lifecycle.State;
import wt.org.WTPrincipal;
import wt.org.WTPrincipalReference;
import wt.project.Role;
import wt.team.Team;
import wt.team.TeamHelper;
import wt.team.TeamManaged;
import wt.util.WTProperties;
import wt.workflow.engine.WfEngineHelper;

public class ChangeActivityHandler {
  private static final String LCSTATE_CANCELLED = PropertyforPIAB.LCSTATE_CANCELLED;
  
  private static final boolean VERBOSE = PropertyforPIAB.VERBOSE;
  
  public static final String DEPARTMENT;
  
  public static void createECA(WTChangeOrder2 paramWTChangeOrder2, WTArrayList paramWTArrayList, String paramString) throws Exception {
    if (VERBOSE)
      System.out.println("***ChangeActivityHandler.createECA  [" + paramString + "]"); 
    WTChangeActivity2 wTChangeActivity2 = WTChangeActivity2.newWTChangeActivity2();
    wTChangeActivity2.setName(paramString);
    wTChangeActivity2.setContainer(paramWTChangeOrder2.getContainer());
    wTChangeActivity2 = (WTChangeActivity2)ChangeHelper2.service.saveChangeActivity((ChangeOrderIfc)paramWTChangeOrder2, (ChangeActivityIfc)wTChangeActivity2);
    wTChangeActivity2 = (WTChangeActivity2)PersistenceHelper.manager.refresh((Persistable)wTChangeActivity2);
    if (paramWTArrayList.size() > 0)
      createAffectedActivityDataLink(wTChangeActivity2, paramWTArrayList); 
  }
  
  public static void createMultipleECAs(WTChangeOrder2 paramWTChangeOrder2, HashMap paramHashMap) throws Exception {
    if (VERBOSE)
      System.out.println("***ChangeActivityHandler.createECAs for [" + paramHashMap.toString() + "]"); 
    Iterator<String> iterator = paramHashMap.keySet().iterator();
    String str1 = "";
    String str2 = "";
    String str3 = "";
    while (iterator.hasNext()) {
      str1 = iterator.next();
      str3 = (String)paramHashMap.get(str1);
      WTChangeActivity2 wTChangeActivity2 = WTChangeActivity2.newWTChangeActivity2();
      wTChangeActivity2.setName(str3);
      wTChangeActivity2.setReviewRequired(false);
      wTChangeActivity2.setExecutionMode(ExecutionMode.AUTOMATIC);
      wTChangeActivity2.setContainer(paramWTChangeOrder2.getContainer());
      wTChangeActivity2 = (WTChangeActivity2)ChangeHelper2.service.saveChangeActivity((ChangeOrderIfc)paramWTChangeOrder2, (ChangeActivityIfc)wTChangeActivity2);
      wTChangeActivity2 = (WTChangeActivity2)PersistenceHelper.manager.refresh((Persistable)wTChangeActivity2);
      IBAUtil iBAUtil = new IBAUtil((IBAHolder)wTChangeActivity2);
      iBAUtil.setIBAValue(DEPARTMENT, str1, null);
      wTChangeActivity2 = (WTChangeActivity2)iBAUtil.updateIBAPart((IBAHolder)wTChangeActivity2);
      wTChangeActivity2 = (WTChangeActivity2)PersistenceHelper.manager.save((Persistable)wTChangeActivity2);
      assignECARoleAssignee(paramWTChangeOrder2, wTChangeActivity2, str1);
    } 
  }
  
  public static void createECAAssignRoles(WTChangeOrder2 paramWTChangeOrder2, String paramString1, String paramString2, String paramString3, String paramString4, boolean paramBoolean1, boolean paramBoolean2) throws Exception {
    Teamhelper teamhelper = new Teamhelper();
    WTChangeActivity2 wTChangeActivity2 = WTChangeActivity2.newWTChangeActivity2();
    wTChangeActivity2.setName(paramString1);
    wTChangeActivity2.setReviewRequired(paramBoolean2);
    wTChangeActivity2.setExecutionMode(ExecutionMode.AUTOMATIC);
    wTChangeActivity2.setContainer(paramWTChangeOrder2.getContainer());
    wTChangeActivity2 = (WTChangeActivity2)ChangeHelper2.service.saveChangeActivity((ChangeOrderIfc)paramWTChangeOrder2, (ChangeActivityIfc)wTChangeActivity2);
    wTChangeActivity2 = (WTChangeActivity2)PersistenceHelper.manager.refresh((Persistable)wTChangeActivity2);
    IBAUtil iBAUtil = new IBAUtil((IBAHolder)wTChangeActivity2);
    iBAUtil.setIBAValue(DEPARTMENT, paramString2, null);
    wTChangeActivity2 = (WTChangeActivity2)iBAUtil.updateIBAPart((IBAHolder)wTChangeActivity2);
    wTChangeActivity2 = (WTChangeActivity2)PersistenceHelper.manager.save((Persistable)wTChangeActivity2);
    assignECARolesAssigneeReviewer(paramWTChangeOrder2, wTChangeActivity2, paramString3, paramString4, paramBoolean1, paramBoolean2);
  }
  
  public static void assignECARolesAssigneeReviewer(WTChangeOrder2 paramWTChangeOrder2, WTChangeActivity2 paramWTChangeActivity2, String paramString1, String paramString2, boolean paramBoolean1, boolean paramBoolean2) throws Exception {
    if (paramBoolean1 || paramBoolean2) {
      Team team1 = TeamHelper.service.getTeam((TeamManaged)paramWTChangeOrder2);
      Team team2 = TeamHelper.service.getTeam((TeamManaged)paramWTChangeActivity2);
      if (paramBoolean1) {
        Role role1 = Role.toRole(paramString1.toUpperCase());
        Enumeration<WTPrincipalReference> enumeration = team1.getPrincipalTarget(role1);
        Role role2 = Role.toRole("ASSIGNEE");
        if (enumeration.hasMoreElements())
          while (enumeration.hasMoreElements()) {
            WTPrincipalReference wTPrincipalReference = enumeration.nextElement();
            if (wTPrincipalReference != null) {
              WTPrincipal wTPrincipal = wTPrincipalReference.getPrincipal();
              if (VERBOSE)
                System.out.println("Setting User For Role [" + role2.getFullDisplay() + " ]   IS  [" + wTPrincipal.getName() + "] "); 
              team2.addPrincipal(role2, wTPrincipal);
            } 
          }  
      } 
      if (paramBoolean2) {
        Role role1 = Role.toRole(paramString2.toUpperCase());
        Enumeration<WTPrincipalReference> enumeration = team1.getPrincipalTarget(role1);
        Role role2 = Role.toRole("REVIEWER");
        if (enumeration.hasMoreElements())
          while (enumeration.hasMoreElements()) {
            WTPrincipalReference wTPrincipalReference = enumeration.nextElement();
            if (wTPrincipalReference != null) {
              WTPrincipal wTPrincipal = wTPrincipalReference.getPrincipal();
              if (VERBOSE)
                System.out.println("Setting User For Role [" + role2.getFullDisplay() + " ]   IS  [" + wTPrincipal.getName() + "] "); 
              team2.addPrincipal(role2, wTPrincipal);
            } 
          }  
      } 
    } 
  }
  
  public static void assignECARoleAssignee(WTChangeOrder2 paramWTChangeOrder2, WTChangeActivity2 paramWTChangeActivity2, String paramString) throws Exception {
    Teamhelper.manageChangeTeam((Persistable)paramWTChangeOrder2, (Persistable)paramWTChangeActivity2);
    Teamhelper teamhelper = new Teamhelper();
    System.out.println("****Assign Roles : ECA: " + paramWTChangeActivity2.getIdentity());
    if (paramString.equalsIgnoreCase("DesignEngineering")) {
      Teamhelper.assignRole((Persistable)paramWTChangeActivity2, "Design Engineer", "Assignee");
    } else if (paramString.equalsIgnoreCase("EngineeringProgramManagement")) {
      Teamhelper.assignRole((Persistable)paramWTChangeActivity2, "Design Engineer", "Assignee");
    } else if (paramString.equalsIgnoreCase("Purchasing")) {
      Teamhelper.assignRole((Persistable)paramWTChangeActivity2, "Purchasing", "Assignee");
    } else if (paramString.equalsIgnoreCase("Manufacturing")) {
      Teamhelper.assignRole((Persistable)paramWTChangeActivity2, "Manufacturing Manager", "Assignee");
    } else if (paramString.equalsIgnoreCase("Quality")) {
      Teamhelper.assignRole((Persistable)paramWTChangeActivity2, "Quality Manager", "Assignee");
    } else if (paramString.equalsIgnoreCase("Inventory")) {
      Teamhelper.assignRole((Persistable)paramWTChangeActivity2, "Inventory", "Assignee");
    } else if (paramString.equalsIgnoreCase("Finance")) {
      Teamhelper.assignRole((Persistable)paramWTChangeActivity2, "Finance", "Assignee");
    } else if (paramString.equalsIgnoreCase("ProductManagementMarketing")) {
      Teamhelper.assignRole((Persistable)paramWTChangeActivity2, "marketing", "Assignee");
    } else if (paramString.equalsIgnoreCase("Regulatory")) {
      Teamhelper.assignRole((Persistable)paramWTChangeActivity2, "Legal", "Assignee");
    } else if (paramString.equalsIgnoreCase("Advocacy")) {
      Teamhelper.assignRole((Persistable)paramWTChangeActivity2, "Advocacy", "Assignee");
    } else if (paramString.equalsIgnoreCase("ConsumerServices")) {
      Teamhelper.assignRole((Persistable)paramWTChangeActivity2, "Consumer Services", "Assignee");
    } else if (paramString.equalsIgnoreCase("Fashion")) {
      Teamhelper.assignRole((Persistable)paramWTChangeActivity2, "Fashion", "Assignee");
    } else if (paramString.equalsIgnoreCase("Forecasting")) {
      Teamhelper.assignRole((Persistable)paramWTChangeActivity2, "Planner", "Assignee");
    } else {
      Teamhelper.assignRole((Persistable)paramWTChangeActivity2, "Change Administrator", "Assignee");
    } 
  }
  
  public static AffectedActivityData createAffectedActivityDataLink(WTChangeActivity2 paramWTChangeActivity2, WTArrayList paramWTArrayList) throws Exception {
    if (VERBOSE)
      System.out.println("***ChangeActivityHandler.createAffectedActivityDataLink()"); 
    AffectedActivityData affectedActivityData = null;
    Object[] arrayOfObject = paramWTArrayList.toArray();
    for (byte b = 0; b < arrayOfObject.length; b++) {
      ObjectReference objectReference = (ObjectReference)arrayOfObject[b];
      Changeable2 changeable2 = (Changeable2)objectReference.getObject();
      if (VERBOSE)
        System.out.println("***create Link with part  [" + changeable2 + "] for CA" + paramWTChangeActivity2.getName()); 
      affectedActivityData = AffectedActivityData.newAffectedActivityData(changeable2, (ChangeActivity2)paramWTChangeActivity2);
      Vector<AffectedActivityData> vector = new Vector();
      vector.add(affectedActivityData);
      ChangeHelper2.service.saveAffectedActivityData(vector);
      if (VERBOSE)
        System.out.println("*** Link Created"); 
    } 
    return affectedActivityData;
  }
  
  public static void changeActState(WTChangeOrder2 paramWTChangeOrder2, String paramString) throws Exception {
    if (VERBOSE)
      System.out.println("***ChangeActivityHandler.changeActState(" + paramWTChangeOrder2.getName() + "," + paramString + ")"); 
    WTChangeActivity2 wTChangeActivity2 = null;
    WTArrayList wTArrayList = getChangeActivities(paramWTChangeOrder2);
    Object[] arrayOfObject = wTArrayList.toArray();
    for (byte b = 0; b < arrayOfObject.length; b++) {
      ObjectReference objectReference = (ObjectReference)arrayOfObject[b];
      wTChangeActivity2 = (WTChangeActivity2)objectReference.getObject();
      paramString = paramString.toUpperCase();
      boolean bool = false;
      if (paramString.equalsIgnoreCase(LCSTATE_CANCELLED))
        bool = true; 
      wTChangeActivity2 = (WTChangeActivity2)LifeCycleHelper.service.setLifeCycleState((LifeCycleManaged)wTChangeActivity2, State.toState(paramString), bool);
      if (VERBOSE)
        System.out.println("***Changed life cycle state of " + wTChangeActivity2 + " with state as " + wTChangeActivity2.getState()); 
    } 
  }
  
  public static WTArrayList getChangeActivities(WTChangeOrder2 paramWTChangeOrder2) {
    if (VERBOSE)
      System.out.println("***ChangeActivityHandler.getChangeActivities(" + paramWTChangeOrder2.getName() + ")"); 
    WTArrayList wTArrayList = new WTArrayList();
    try {
      QueryResult queryResult = ChangeHelper2.service.getChangeActivities((ChangeOrderIfc)paramWTChangeOrder2);
      if (VERBOSE)
        System.out.println("***activity size for changeNotice [" + paramWTChangeOrder2 + "] are [" + queryResult.size() + "]"); 
      while (queryResult.hasMoreElements()) {
        WTChangeActivity2 wTChangeActivity2 = (WTChangeActivity2)queryResult.nextElement();
        wTArrayList.add((Persistable)wTChangeActivity2);
      } 
    } catch (Exception exception) {
      if (VERBOSE)
        System.out.println("***Exception while getting Change activities of " + paramWTChangeOrder2.getNumber()); 
    } 
    if (VERBOSE)
      System.out.println("***Returning  Activities - " + wTArrayList); 
    return wTArrayList;
  }
  
  public static void createImplTasks(WTChangeOrder2 paramWTChangeOrder2, Vector<String> paramVector1, Vector<String> paramVector2) throws Exception {
    if (VERBOSE)
      System.out.println("***ChangeActivityHandler.createImplTasks(" + paramVector1.size() + "," + paramVector2 + ")"); 
    try {
      WTArrayList wTArrayList1 = getChangeActivities(paramWTChangeOrder2);
      paramVector1 = getTasktoCreate(wTArrayList1, paramVector1, paramVector2);
      Iterator<String> iterator = paramVector1.iterator();
      WTArrayList wTArrayList2 = new WTArrayList();
      while (iterator.hasNext()) {
        String str = iterator.next();
        createECA(paramWTChangeOrder2, wTArrayList2, str);
      } 
      if (VERBOSE)
        System.out.println("***Implementation Plan Created "); 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  private static Vector<String> getTasktoCreate(WTArrayList paramWTArrayList, Vector<String> paramVector1, Vector<String> paramVector2) {
    if (VERBOSE)
      System.out.println("***ChangeActivityHandler.getTasktoCreate()"); 
    Object[] arrayOfObject = paramWTArrayList.toArray();
    for (byte b = 0; b < arrayOfObject.length; b++) {
      ObjectReference objectReference = (ObjectReference)arrayOfObject[b];
      WTChangeActivity2 wTChangeActivity2 = (WTChangeActivity2)objectReference.getObject();
      String str = wTChangeActivity2.getName();
      if (VERBOSE)
        System.out.println("***Existing ECA Name: " + str); 
      if (paramVector1.contains(str))
        paramVector1.remove(str); 
      if (paramVector2.contains(str))
        deleteItem((Persistable)wTChangeActivity2); 
    } 
    if (VERBOSE)
      System.out.println("***CA to be created- " + paramVector1.size() + " NAMES " + paramVector1); 
    return paramVector1;
  }
  
  private static void deleteItem(Persistable paramPersistable) {
    if (VERBOSE)
      System.out.println("***ChangeActivityHandler.deleteItem()"); 
    try {
      if (paramPersistable instanceof WTChangeActivity2) {
        WTChangeActivity2 wTChangeActivity2 = (WTChangeActivity2)paramPersistable;
        if (VERBOSE)
          System.out.println("*** Removing ECA : " + wTChangeActivity2.getName()); 
        WfEngineHelper.service.terminateObjectsRunningWorkflows((Persistable)wTChangeActivity2);
        ChangeHelper2.service.deleteChangeActivity((ChangeActivityIfc)wTChangeActivity2);
      } 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  public static WTArrayList getObsoleteCA(WTChangeOrder2 paramWTChangeOrder2, String paramString) throws Exception {
    if (VERBOSE)
      System.out.println("***ChangeActivityHandler.getObsoleteCA()"); 
    WTArrayList wTArrayList = new WTArrayList();
    QueryResult queryResult = ChangeHelper2.service.getChangeActivities((ChangeOrderIfc)paramWTChangeOrder2);
    while (queryResult.hasMoreElements()) {
      WTChangeActivity2 wTChangeActivity2 = (WTChangeActivity2)queryResult.nextElement();
      String str1 = wTChangeActivity2.getName();
      IBAUtil iBAUtil = new IBAUtil((IBAHolder)wTChangeActivity2);
      String str2 = iBAUtil.getIBAValue(paramString);
      if (str2 != null) {
        if (VERBOSE)
          System.out.println("***If Obsolescence : " + str2); 
        if (str2.equalsIgnoreCase("TRUE")) {
          if (VERBOSE)
            System.out.println("***Change Task " + wTChangeActivity2.getName() + " Obsolescense is set to TRUE"); 
          wTArrayList.add((Persistable)wTChangeActivity2);
        } 
      } 
    } 
    return wTArrayList;
  }
  
  static {
    try {
      WTProperties wTProperties = WTProperties.getLocalProperties();
      DEPARTMENT = wTProperties.getProperty("ext.piab.workflow.change.department", "Department");
    } catch (Throwable throwable) {
      System.err.println("Error initializing ");
      throwable.printStackTrace(System.err);
      throw new ExceptionInInitializerError(throwable);
    } 
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\change\activity\ChangeActivityHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */