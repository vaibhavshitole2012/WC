package ext.piab.change.util;

import com.ptc.windchill.wp.WorkPackage;
import ext.piab.common.resource.HtmlResource;
import ext.piab.common.util.Htmlutil;
import ext.piab.common.util.PropertyforPIAB;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import wt.fc.Persistable;
import wt.fc.WTObject;
import wt.lifecycle.LifeCycleManaged;
import wt.mail.EMailMessage;
import wt.org.OrganizationServicesHelper;
import wt.org.WTGroup;
import wt.org.WTPrincipal;
import wt.util.WTException;
import wt.util.WTMessage;

public class NotifyPackageOwners {
  private static final String HTML_RESOURCE = HtmlResource.class.getName();
  
  private static final boolean VERBOSE = PropertyforPIAB.VERBOSE;
  
  private static String CONTENT_TYPE = WTMessage.getLocalizedMessage(HTML_RESOURCE, "11");
  
  public static void emailMsg(HashMap paramHashMap, Persistable paramPersistable) throws Exception {
    if (VERBOSE)
      System.out.println("***NotifyPackageOwners.emailMsg()"); 
    Set set = null;
    Iterator<WTPrincipal> iterator = null;
    WTObject wTObject = null;
    set = paramHashMap.keySet();
    iterator = set.iterator();
    while (iterator.hasNext()) {
      try {
        EMailMessage eMailMessage = EMailMessage.newEMailMessage();
        WTPrincipal wTPrincipal = iterator.next();
        HashMap hashMap = (HashMap)paramHashMap.get(wTPrincipal);
        if (VERBOSE)
          System.out.println("*****Packages for Principal [" + wTPrincipal.getName() + "] " + hashMap); 
        if (wTPrincipal instanceof WTGroup) {
          Enumeration<WTPrincipal> enumeration = OrganizationServicesHelper.manager.members((WTGroup)wTPrincipal);
          while (enumeration.hasMoreElements()) {
            WTPrincipal wTPrincipal1 = enumeration.nextElement();
            if (wTPrincipal1 instanceof wt.org.WTUser)
              eMailMessage.addRecipient(wTPrincipal); 
          } 
        } else if (wTPrincipal instanceof wt.org.WTUser) {
          eMailMessage.addRecipient(wTPrincipal);
        } 
        eMailMessage.setSubject(HTML_RESOURCE, "0", null);
        String str = Htmlutil.gettempBody();
        str = Htmlutil.enterValues(paramPersistable, str);
        str = Htmlutil.setEventandMessage(paramPersistable, str, "4", "10");
        Set<WTObject> set1 = hashMap.keySet();
        for (WTObject wTObject1 : set1) {
          ArrayList arrayList = (ArrayList)hashMap.get(wTObject1);
          String str1 = Integer.toString(arrayList.size());
          str = Htmlutil.buildTable(str, str1, Htmlutil.getURL((Persistable)wTObject1), Htmlutil.getDisplay((Persistable)wTObject1), ((LifeCycleManaged)wTObject1).getLifeCycleState().getDisplay());
          Object[] arrayOfObject = arrayList.toArray();
          for (byte b = 0; b < arrayOfObject.length; b++) {
            wTObject = (WTObject)arrayOfObject[b];
            if (b > 0)
              str = str + "<tr>"; 
            str = Htmlutil.enterData(str, Htmlutil.getURL((Persistable)wTObject), Htmlutil.getDisplay((Persistable)wTObject));
          } 
        } 
        str = Htmlutil.closeBody(str);
        eMailMessage.addPart(str, CONTENT_TYPE);
        try {
          eMailMessage.send(true);
        } catch (Exception exception) {
          exception.printStackTrace();
        } 
      } catch (WTException wTException) {
        wTException.printStackTrace();
      } 
    } 
  }
  
  public static void sendMail(HashMap paramHashMap, Persistable paramPersistable) throws Exception {
    if (VERBOSE)
      System.out.println("***NotifyPackageOwners.sendMail()"); 
    Set set = null;
    Iterator<WTPrincipal> iterator = null;
    WTObject wTObject = null;
    set = paramHashMap.keySet();
    iterator = set.iterator();
    while (iterator.hasNext()) {
      try {
        EMailMessage eMailMessage = EMailMessage.newEMailMessage();
        WTPrincipal wTPrincipal = iterator.next();
        HashMap hashMap = (HashMap)paramHashMap.get(wTPrincipal);
        if (VERBOSE)
          System.out.println("*****Packages for Principal [" + wTPrincipal.getName() + "] " + hashMap); 
        if (wTPrincipal instanceof WTGroup) {
          Enumeration<WTPrincipal> enumeration = OrganizationServicesHelper.manager.members((WTGroup)wTPrincipal);
          while (enumeration.hasMoreElements()) {
            WTPrincipal wTPrincipal1 = enumeration.nextElement();
            if (wTPrincipal1 instanceof wt.org.WTUser)
              eMailMessage.addRecipient(wTPrincipal); 
          } 
        } else if (wTPrincipal instanceof wt.org.WTUser) {
          eMailMessage.addRecipient(wTPrincipal);
        } 
        eMailMessage.setSubject(HTML_RESOURCE, "1", null);
        String str = Htmlutil.gettempBody();
        str = Htmlutil.enterValues(paramPersistable, str);
        str = Htmlutil.setEventandMessage(paramPersistable, str, "5", "9");
        Set<WorkPackage> set1 = hashMap.keySet();
        for (WorkPackage workPackage : set1) {
          ArrayList arrayList = (ArrayList)hashMap.get(workPackage);
          String str1 = Integer.toString(arrayList.size());
          str = Htmlutil.buildTable(str, str1, Htmlutil.getURL((Persistable)workPackage), Htmlutil.getDisplay((Persistable)workPackage), workPackage.getLifeCycleState().getDisplay());
          Object[] arrayOfObject = arrayList.toArray();
          for (byte b = 0; b < arrayOfObject.length; b++) {
            wTObject = (WTObject)arrayOfObject[b];
            if (b > 0)
              str = str + "<tr>"; 
            str = Htmlutil.enterData(str, Htmlutil.getURL((Persistable)wTObject), Htmlutil.getDisplay((Persistable)wTObject));
          } 
        } 
        str = Htmlutil.closeBody(str);
        eMailMessage.addPart(str, CONTENT_TYPE);
        try {
          eMailMessage.send(true);
        } catch (Exception exception) {
          exception.printStackTrace();
        } 
      } catch (WTException wTException) {
        wTException.printStackTrace();
      } 
    } 
  }
}


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\chang\\util\NotifyPackageOwners.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */