/*     */ package ext.piab.change.validation;
/*     */ 
/*     */ import ext.piab.change.resource.ChangeResource;
/*     */ import ext.piab.common.util.PropertyforPIAB;
/*     */ import java.util.Iterator;
/*     */ import java.util.Vector;
/*     */ import wt.change2.ChangeHelper2;
/*     */ import wt.change2.ChangeOrderIfc;
/*     */ import wt.change2.WTChangeActivity2;
/*     */ import wt.change2.WTChangeOrder2;
/*     */ import wt.content.ApplicationData;
/*     */ import wt.content.ContentHelper;
/*     */ import wt.content.ContentHolder;
/*     */ import wt.fc.Persistable;
/*     */ import wt.fc.QueryResult;
/*     */ import wt.fc.WTObject;
/*     */ import wt.util.WTException;
/*     */ 
/*     */ public class ValidateChange
/*     */ {
/*  21 */   private static final boolean VERBOSE = PropertyforPIAB.VERBOSE;
/*  22 */   private static final String LCSTATE_APPROVED = PropertyforPIAB.LCSTATE_APPROVED;
/*  23 */   private static final String LCSTATE_CANCELLED = PropertyforPIAB.LCSTATE_CANCELLED;
/*  24 */   private static final String LCSTATE_COMPLETED = PropertyforPIAB.LCSTATE_COMPLETED;
/*  25 */   private static final String LCSTATE_OPEN = PropertyforPIAB.LCSTATE_OPEN;
/*  26 */   private static final String LCSTATE_UNDERREVIEW = PropertyforPIAB.LCSTATE_UNDERREVIEW;
/*  27 */   private static final String CHANGE_RESOURCE = ChangeResource.class.getName();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void checkNoticeState(WTChangeOrder2 ECN, String state) throws Exception {
/*  35 */     if (VERBOSE) System.out.println("*** ValidateChange.checkNoticeState(" + ECN.getName() + "," + state + ")"); 
/*  36 */     StringBuilder strBuilder = new StringBuilder();
/*  37 */     boolean correctStates = isCorrectState((Persistable)ECN, state, false);
/*  38 */     if (correctStates) {
/*  39 */       if (VERBOSE) System.out.println("***state of[" + ECN + "]--" + ECN.getLifeCycleState()); 
/*     */     } else {
/*  41 */       strBuilder.append("\nChangeNotice: [" + ECN.getNumber() + "]");
/*     */     } 
/*  43 */     String message = strBuilder.toString();
/*  44 */     if (!message.isEmpty()) {
/*  45 */       if (VERBOSE) System.out.println("***LC state of [" + message + "]is greater than [" + state + "]"); 
/*  46 */       Object[] aobj1 = { message, state };
/*  47 */       throw new WTException(CHANGE_RESOURCE, "3", aobj1);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String checkActivityState(Persistable pers, String state) throws Exception {
/*  57 */     if (VERBOSE) System.out.println("*** ValidateChange.checkActivityState(" + pers + "," + state + ")"); 
/*  58 */     StringBuilder stringBuilder = new StringBuilder();
/*  59 */     boolean correctStates = false;
/*  60 */     WTChangeOrder2 ecn = (WTChangeOrder2)pers;
/*  61 */     QueryResult qresult = ChangeHelper2.service.getChangeActivities((ChangeOrderIfc)ecn);
/*  62 */     if (VERBOSE) System.out.println("***Size of QueryResult activities-" + qresult.size()); 
/*  63 */     while (qresult.hasMoreElements()) {
/*  64 */       WTChangeActivity2 act = (WTChangeActivity2)qresult.nextElement();
/*  65 */       correctStates = isCorrectState((Persistable)act, state, false);
/*  66 */       if (correctStates) {
/*  67 */         if (VERBOSE) System.out.println("***state of[" + act + "]-" + act.getLifeCycleState());  continue;
/*     */       } 
/*  69 */       stringBuilder.append("\nChangeActivity: [" + act.getNumber() + "]");
/*     */     } 
/*  71 */     String message = stringBuilder.toString();
/*  72 */     if (!message.isEmpty()) {
/*  73 */       if (VERBOSE) System.out.println("***LC state of [" + message + "]is greater than [" + state + "]"); 
/*  74 */       Object[] aobj1 = { message, state };
/*  75 */       throw new WTException(CHANGE_RESOURCE, "3", aobj1);
/*     */     } 
/*  77 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isCorrectState(Persistable pers, String state, boolean correctStates) {
/*  84 */     if (VERBOSE) System.out.println("*** ValidateChange.isCorrectState(" + pers + "," + state + "," + correctStates + ")"); 
/*  85 */     String lcState = null;
/*  86 */     if (pers instanceof WTChangeOrder2) {
/*  87 */       WTChangeOrder2 ECN = (WTChangeOrder2)pers;
/*  88 */       lcState = ECN.getLifeCycleState().getStringValue().toUpperCase();
/*  89 */       if (state.equalsIgnoreCase(LCSTATE_APPROVED)) {
/*  90 */         correctStates = (lcState.endsWith(state) || lcState.endsWith(LCSTATE_OPEN) || lcState.endsWith(LCSTATE_UNDERREVIEW));
/*  91 */       } else if (state.equalsIgnoreCase(LCSTATE_COMPLETED)) {
/*  92 */         correctStates = !lcState.endsWith(LCSTATE_CANCELLED);
/*     */       } 
/*  94 */     } else if (pers instanceof WTChangeActivity2) {
/*  95 */       WTChangeActivity2 act = (WTChangeActivity2)pers;
/*  96 */       lcState = act.getLifeCycleState().getStringValue().toUpperCase();
/*  97 */       if (state.equalsIgnoreCase(LCSTATE_APPROVED)) {
/*  98 */         correctStates = (lcState.endsWith(state) || lcState.endsWith(LCSTATE_OPEN) || lcState.endsWith(LCSTATE_UNDERREVIEW));
/*  99 */       } else if (state.equalsIgnoreCase(LCSTATE_COMPLETED)) {
/* 100 */         correctStates = !lcState.endsWith(LCSTATE_CANCELLED);
/*     */       } 
/*     */     } 
/* 103 */     return correctStates;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void validateContent(WTObject pbo, String fileName, boolean custVerified, boolean custValidated) throws Exception {
/* 112 */     if (VERBOSE) System.out.println("*** ValidateChange.validateContent(" + pbo + "," + fileName + "," + custVerified + "," + custVerified + ")"); 
/* 113 */     Vector<ApplicationData> contentList = getContentList(pbo);
/* 114 */     if (VERBOSE) System.out.println("***Size: " + contentList.size()); 
/* 115 */     if (VERBOSE) System.out.println("***List : " + contentList); 
/* 116 */     if (custVerified && custValidated) {
/* 117 */       if (contentList.size() <= 1) {
/* 118 */         throw new WTException(CHANGE_RESOURCE, "4", null);
/*     */       }
/* 120 */     } else if (custVerified || custValidated) {
/* 121 */       if (contentList.size() <= 0) {
/* 122 */         throw new WTException(CHANGE_RESOURCE, "4", null);
/*     */       }
/*     */     } else {
/* 125 */       throw new WTException(CHANGE_RESOURCE, "4", null);
/*     */     } 
/* 127 */     boolean flag = false;
/* 128 */     Iterator<ApplicationData> it = contentList.iterator();
/* 129 */     while (it.hasNext()) {
/* 130 */       ApplicationData part_ad = it.next();
/* 131 */       if (fileName.equalsIgnoreCase(part_ad.getFileName())) {
/* 132 */         flag = true; break;
/*     */       } 
/*     */     } 
/* 135 */     if (!flag) {
/* 136 */       Object[] aobj1 = { fileName };
/* 137 */       throw new WTException(CHANGE_RESOURCE, "5", aobj1);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Vector<ApplicationData> getContentList(WTObject pbo) throws Exception {
/* 147 */     if (VERBOSE) System.out.println("*** ValidateChange.getContentList()");
/*     */     
/* 149 */     Vector<ApplicationData> contentList = new Vector<>();
/*     */     
/*     */     try {
/* 152 */       if (pbo instanceof WTChangeOrder2) {
/* 153 */         ContentHolder contentHolder = ContentHelper.service.getContents((ContentHolder)pbo);
/* 154 */         contentList = ContentHelper.getContentList(contentHolder);
/*     */       } 
/* 156 */     } catch (WTException e) {
/* 157 */       e.printStackTrace();
/*     */     } 
/* 159 */     return contentList;
/*     */   }
/*     */ }


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\piab\change\validation\ValidateChange.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */