/*     */ package ext.datafrond.erpconnector;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Serializable;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Date;
/*     */ import java.util.Properties;
/*     */ import wt.fc.Persistable;
/*     */ import wt.fc.PersistenceHelper;
/*     */ import wt.fc.QueryResult;
/*     */ import wt.method.RemoteAccess;
/*     */ import wt.method.RemoteMethodServer;
/*     */ import wt.org.WTPrincipal;
/*     */ import wt.org.WTUser;
/*     */ import wt.query.QuerySpec;
/*     */ import wt.query.SearchCondition;
/*     */ import wt.query.WhereExpression;
/*     */ import wt.queue.ScheduleQueue;
/*     */ import wt.queue.ScheduleQueueEntry;
/*     */ import wt.services.applicationcontext.implementation.ServiceProperties;
/*     */ import wt.session.SessionHelper;
/*     */ import wt.util.WTException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ESIPollingQueueScheduler
/*     */   implements Serializable, RemoteAccess
/*     */ {
/*  39 */   static Properties sqProperties = new Properties();
/*     */ 
/*     */   
/*     */   private static long scheduledTime;
/*     */ 
/*     */   
/*     */   public static String setInterval(String intervalValue) {
/*  46 */     String interval = null;
/*     */     
/*     */     try {
/*  49 */       long min_Interval = Long.parseLong(intervalValue);
/*  50 */       long sq_Interval = min_Interval * 60L * 1000L;
/*  51 */       interval = Long.toString(sq_Interval);
/*  52 */       System.out.println("Queue Interval : " + interval);
/*     */     }
/*  54 */     catch (Throwable throwable) {
/*  55 */       throwable.printStackTrace();
/*     */     } 
/*  57 */     return interval;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) throws WTException {
/*     */     try {
/*  75 */       RemoteMethodServer remotemethodserver = RemoteMethodServer.getDefault();
/*     */ 
/*     */       
/*  78 */       String CLASSNAME = ESIPollingQueueScheduler.class.getName();
/*  79 */       Class[] argTypes = new Class[0];
/*  80 */       Object[] argValues = new Object[0];
/*     */       
/*  82 */       String SERVER_CLASS = "ext.datafrond.erpconnector.ESIPollingQueueScheduler.getName()";
/*  83 */       RemoteMethodServer.getDefault().invoke("executeTaskScheduler", CLASSNAME, null, argTypes, argValues);
/*     */     }
/*  85 */     catch (IOException ioe) {
/*  86 */       ioe.printStackTrace();
/*  87 */     } catch (Exception e) {
/*  88 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   public static void executeTaskScheduler() throws Exception {
/*  92 */     ScheduleQueue queue = null;
/*  93 */     int[] fromIndicies = { 0, 1 };
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  99 */       queue = getQueue();
/* 100 */       System.out.println("The Queue Found:" + queue.getName() + " in state :" + queue.getQueueState());
/* 101 */       QuerySpec queryspec = new QuerySpec(ScheduleQueueEntry.class);
/* 102 */       SearchCondition condition = new SearchCondition(ScheduleQueueEntry.class, "queueRef.key", "=", PersistenceHelper.getObjectIdentifier((Persistable)queue));
/* 103 */       queryspec.appendWhere((WhereExpression)condition, fromIndicies);
/* 104 */       condition = new SearchCondition(ScheduleQueueEntry.class, "statusInfo.code", "=", "READY");
/* 105 */       queryspec.appendAnd();
/* 106 */       queryspec.appendWhere((WhereExpression)condition, fromIndicies);
/* 107 */       QueryResult queueResult = PersistenceHelper.manager.find(queryspec);
/* 108 */       if (queueResult != null && queueResult.size() > 0) {
/* 109 */         ScheduleQueueEntry entry = (ScheduleQueueEntry)queueResult.nextElement();
/* 110 */         System.out.println("Queue Entry already exists. Delete the existing queue entry: " + entry.getIdentity() + " and rerun the command.");
/*     */       } else {
/* 112 */         createQueueEntry();
/*     */       } 
/* 114 */     } catch (Exception e) {
/* 115 */       System.out.println("Exception in executeTaskScheduler().");
/* 116 */       throw e;
/*     */     } 
/*     */   }
/*     */   public static void callPollingEvent() throws Exception {
/*     */     try {
/* 121 */       System.out.println("Task for the Schedule Queue");
/* 122 */       ESITransactionStateUpdate.updateESITransactionStatus();
/* 123 */       createQueueEntry();
/*     */       return;
/* 125 */     } catch (Exception e) {
/* 126 */       e.printStackTrace();
/* 127 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void createQueueEntry() throws Exception {
/*     */     try {
/* 134 */       sqProperties = (Properties)ServiceProperties.getServiceProperties("WTServiceProviderFromProperties");
/* 135 */       ScheduleQueue queue = getQueue();
/* 136 */       WTUser adminUser = (WTUser)SessionHelper.manager.getPrincipal();
/* 137 */       Class[] argTypes = new Class[0];
/* 138 */       Object[] argValues = new Object[0];
/* 139 */       long currentTime = (new Date()).getTime();
/* 140 */       scheduledTime = Long.parseLong(setInterval(sqProperties.getProperty("ext.datafrond.erpconnector.ESIPollingQueueInterval")));
/* 141 */       Timestamp timestamp = new Timestamp(System.currentTimeMillis() + scheduledTime);
/* 142 */       queue.addEntry((WTPrincipal)adminUser, "callPollingEvent", "ext.datafrond.erpconnector.ESIPollingQueueScheduler", argTypes, argValues, timestamp);
/* 143 */     } catch (Exception ex) {
/* 144 */       ex.printStackTrace();
/* 145 */       throw ex;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static ScheduleQueue getQueue() throws WTException, Exception {
/* 150 */     ScheduleQueue queue = null;
/*     */ 
/*     */     
/*     */     try {
/* 154 */       sqProperties = (Properties)ServiceProperties.getServiceProperties("WTServiceProviderFromProperties");
/*     */       
/* 156 */       String queueName = sqProperties.getProperty("ext.datafrond.erpconnector.ESIPollingQueue");
/* 157 */       System.out.println("Queue Name is : " + queueName);
/* 158 */       int[] fromIndicies = { 0, 1 };
/*     */ 
/*     */       
/* 161 */       QuerySpec spec = new QuerySpec(ScheduleQueue.class);
/* 162 */       spec.appendWhere((WhereExpression)new SearchCondition(ScheduleQueue.class, "name", "LIKE", queueName), fromIndicies);
/* 163 */       QueryResult result = PersistenceHelper.manager.find(spec);
/* 164 */       if (result == null || result.size() < 1) {
/* 165 */         System.out.println("ERROR : No Scheduler in Windchill. Make schedule queue first, with the name " + queueName + ".");
/*     */       } else {
/*     */         
/* 168 */         queue = (ScheduleQueue)result.nextElement();
/*     */       }
/*     */     
/*     */     }
/* 172 */     catch (Exception e) {
/* 173 */       System.out.println(e);
/*     */     } 
/*     */     
/* 176 */     return queue;
/*     */   }
/*     */ }


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\datafrond\erpconnector\ESIPollingQueueScheduler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */