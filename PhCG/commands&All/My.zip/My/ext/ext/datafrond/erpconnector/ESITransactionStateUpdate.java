/*     */ package ext.datafrond.erpconnector;
/*     */ 
/*     */ import com.ptc.windchill.esi.tgt.ESITarget;
/*     */ import com.ptc.windchill.esi.txn.ESIRelease;
/*     */ import com.ptc.windchill.esi.txn.ESIReleaseTransactionLink;
/*     */ import com.ptc.windchill.esi.txn.ESIReleaseUtility;
/*     */ import com.ptc.windchill.esi.txn.ESITransaction;
/*     */ import com.ptc.windchill.esi.txn.ESITransactionMessage;
/*     */ import com.ptc.windchill.esi.txn.ESITransactionRelease;
/*     */ import com.ptc.windchill.esi.txn.ESITransactionStatusType;
/*     */ import com.ptc.windchill.esi.txn.ReleaseActivity;
/*     */ import com.ptc.windchill.esi.txn.ReleaseActivityMessage;
/*     */ import com.ptc.windchill.esi.txn.ReleaseStatusType;
/*     */ import java.io.File;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import wt.fc.Persistable;
/*     */ import wt.fc.PersistenceHelper;
/*     */ import wt.fc.PersistenceServerHelper;
/*     */ import wt.fc.QueryResult;
/*     */ import wt.query.QuerySpec;
/*     */ import wt.query.SearchCondition;
/*     */ import wt.query.WhereExpression;
/*     */ import wt.util.WTException;
/*     */ import wt.util.WTProperties;
/*     */ import wt.util.WTPropertyVetoException;
/*     */ 
/*     */ public class ESITransactionStateUpdate
/*     */ {
/*     */   public static void updateESITransactionStatus() throws Exception {
/*  33 */     ArrayList<ESITarget> esiTargets = searchESITarget();
/*  34 */     String path = "";
/*  35 */     for (int i = 0; i < esiTargets.size(); i++) {
/*  36 */       path = ((ESITarget)esiTargets.get(i)).getSoftAttribute("Path");
/*  37 */       System.out.println("Distribution Target Path: " + path);
/*  38 */       path = path.replace(File.separatorChar, '#');
/*  39 */       String[] splitPath = path.split("#");
/*  40 */       path = "";
/*  41 */       for (int j = 1; j < splitPath.length; j++)
/*  42 */         path = path + splitPath[j - 1] + File.separator; 
/*  43 */       path = path + "out";
/*  44 */       System.out.println("AX Status Polling Directory: " + path);
/*  45 */       updateStatus(path);
/*     */     } 
/*     */   }
/*     */   public static final String sucMsg = "Item has been SUCCESSFULLY Published to ERP System";
/*     */   private static ESITransaction searchESITransaction(int esiTxNum) {
/*  50 */     ESITransaction esiTX = null;
/*     */     try {
/*  52 */       QuerySpec qs = new QuerySpec(ESITransaction.class);
/*  53 */       SearchCondition sc = new SearchCondition(ESITransaction.class, "idNumber", "=", esiTxNum);
/*  54 */       qs.appendWhere((WhereExpression)sc, new int[] { 0 });
/*  55 */       QueryResult qr = PersistenceHelper.manager.find(qs);
/*  56 */       while (qr.hasMoreElements()) {
/*  57 */         esiTX = (ESITransaction)qr.nextElement();
/*     */       }
/*  59 */     } catch (Exception ex) {
/*  60 */       ex.printStackTrace();
/*     */     } 
/*  62 */     return esiTX;
/*     */   }
/*     */   
/*     */   private static Collection removeSupercededTxns(Collection collection) {
/*  66 */     Iterator<ESITransaction> iterator = collection.iterator();
/*  67 */     ArrayList<ESITransaction> arraylist = new ArrayList(collection.size());
/*     */ 
/*     */     
/*  70 */     while (iterator.hasNext()) {
/*     */ 
/*     */ 
/*     */       
/*  74 */       ESITransaction esitransaction = iterator.next();
/*  75 */       if (!esitransaction.isSuperceded())
/*     */       {
/*  77 */         arraylist.add(esitransaction);
/*     */       }
/*     */     } 
/*  80 */     return arraylist;
/*     */   }
/*     */   
/*     */   private static ESIRelease getESIRelease(ESITransaction esiTx) {
/*  84 */     ESIRelease esiRelease = null;
/*     */     try {
/*  86 */       QueryResult queryresult = PersistenceHelper.manager.navigate((Persistable)esiTx, "release", ESIReleaseTransactionLink.class, true);
/*  87 */       if (queryresult.hasMoreElements())
/*     */       {
/*  89 */         esiRelease = (ESIRelease)queryresult.nextElement();
/*     */       }
/*     */     }
/*  92 */     catch (Exception ex) {
/*  93 */       ex.printStackTrace();
/*     */     } 
/*  95 */     return esiRelease;
/*     */   }
/*     */ 
/*     */   
/*     */   private static void updateStatus(String path) throws Exception {
/* 100 */     WTProperties properties = WTProperties.getLocalProperties();
/* 101 */     String xsdPath = properties.getProperty("ext.datafrond.erpconnector.XSDValidatorFilePath");
/* 102 */     boolean isValid = false;
/* 103 */     ArrayList<String> dataList = new ArrayList<>();
/* 104 */     File dir = new File(path);
/* 105 */     String[] children = dir.list();
/* 106 */     if (children == null) {
/* 107 */       System.out.println("problem in child");
/*     */     } else {
/* 109 */       for (int i = 0; i < children.length; i++) {
/* 110 */         if (children[i].endsWith(".xml")) {
/* 111 */           String sFile = path + File.separator + children[i];
/* 112 */           isValid = XSDValidator.validateXMLSchema(xsdPath, sFile);
/* 113 */           System.out.println("** XSDValidator validateXML..." + isValid);
/* 114 */           if (isValid) {
/* 115 */             ERPPublishStatusMessage smg = ReadXMLFile.getTransactionStatus(sFile);
/* 116 */             System.out.println("ERPPublishStatusMessage Before Persisting in Windchill : " + smg.toString());
/* 117 */             if (smg.getTransactionId() != 0) {
/*     */               try {
/* 119 */                 ESITransaction esiTX = searchESITransaction(smg.getTransactionId());
/*     */                 
/* 121 */                 ESITransactionMessage oldEsiTXMsg = esiTX.getMessage();
/* 122 */                 ESIRelease release = getESIRelease(esiTX);
/* 123 */                 String releaseMsg = "";
/* 124 */                 String releaseStatus = "";
/* 125 */                 boolean releaseFlag = true;
/*     */                 
/* 127 */                 if (smg.getTransactionStatus().equalsIgnoreCase("published")) {
/* 128 */                   releaseStatus = "succeeded";
/* 129 */                   releaseMsg = "Item has been SUCCESSFULLY Published to ERP System";
/* 130 */                   releaseFlag = true;
/*     */                 } else {
/*     */                   
/* 133 */                   releaseStatus = "failed";
/* 134 */                   releaseMsg = smg.getTransactionMessage();
/* 135 */                   releaseFlag = false;
/*     */                 } 
/* 137 */                 System.out.println("The Transcation message is :::::" + smg.getTransactionMessage());
/* 138 */                 esiTX.setStatus(ESITransactionStatusType.toESITransactionStatusType(releaseStatus));
/* 139 */                 release.setStatus(ReleaseStatusType.toReleaseStatusType(releaseStatus));
/* 140 */                 ESITransactionMessage esiTXMsg = ESITransactionMessage.newESITransactionMessage(releaseMsg);
/*     */                 
/* 142 */                 QueryResult queryresult = PersistenceServerHelper.manager.expand((Persistable)esiTX, "release", ESITransactionRelease.class, true);
/* 143 */                 while (queryresult.hasMoreElements()) {
/* 144 */                   ReleaseActivity ra = (ReleaseActivity)queryresult.nextElement();
/* 145 */                   ra.setStatus(ReleaseStatusType.toReleaseStatusType(releaseStatus));
/* 146 */                   ra.setReleaseStamp(new Timestamp(System.currentTimeMillis()));
/*     */                   
/* 148 */                   ReleaseActivityMessage raMsg = ReleaseActivityMessage.newReleaseActivityMessage(releaseMsg);
/* 149 */                   PersistenceHelper.manager.save((Persistable)raMsg);
/* 150 */                   ra.setMessage(raMsg);
/* 151 */                   PersistenceHelper.manager.save((Persistable)ra);
/*     */                 } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/* 158 */                 PersistenceHelper.manager.save((Persistable)esiTXMsg);
/* 159 */                 esiTX.setMessage(esiTXMsg);
/* 160 */                 PersistenceHelper.manager.save((Persistable)esiTX);
/* 161 */                 release.setEndTimeStamp(new Timestamp(System.currentTimeMillis()));
/* 162 */                 PersistenceHelper.manager.save((Persistable)release);
/* 163 */                 if (oldEsiTXMsg != null) {
/* 164 */                   PersistenceHelper.manager.delete((Persistable)oldEsiTXMsg);
/*     */                 }
/* 166 */                 System.out.println("After Updating Transaction Status in Windchill : " + esiTX.getStatus() + " message = " + esiTX.getMessage().getText());
/*     */ 
/*     */                 
/* 169 */                 System.out.println("Before Calling Post Release Event for Transaction: " + smg.toString());
/* 170 */                 ESIReleaseUtility eru = new ESIReleaseUtility();
/* 171 */                 Collection c = removeSupercededTxns(release.getTransactions());
/* 172 */                 ESIReleaseUtility.postEvent((Persistable)esiTX, (Persistable)release, releaseFlag, releaseMsg, c);
/* 173 */                 System.out.println("After Calling Post Release Event for Transaction: " + smg.toString());
/*     */                 
/* 175 */                 deletefile(sFile);
/*     */               }
/* 177 */               catch (WTPropertyVetoException wtpve) {
/* 178 */                 System.out.println("Error with Updating Transaction Status in Windchill : " + smg.toString());
/* 179 */                 wtpve.printStackTrace();
/*     */               }
/* 181 */               catch (WTException wte) {
/* 182 */                 System.out.println("Error with Updating Transaction Status in Windchill : " + smg.toString());
/* 183 */                 wte.printStackTrace();
/*     */               }
/*     */             
/*     */             } else {
/*     */               
/* 188 */               System.out.println(sFile + " Error with Parsing ERP Status XML File!!!");
/* 189 */               dataList.add(sFile + "# ESI Polling Queue Error with Missing Transcation Number in Processing ESI Result File " + sFile);
/*     */             } 
/*     */           } else {
/*     */             
/* 193 */             System.out.println("*** ESLE Loop malformed exception");
/* 194 */             dataList.add(sFile + "#ESI Polling Queue Error with Malformed exception in Processing ESI Result File " + sFile);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 199 */     if (!dataList.isEmpty()) {
/* 200 */       System.out.println("*** Started Sending email..");
/* 201 */       SendESIMail.sendMail(dataList);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static ArrayList<ESITarget> searchESITarget() {
/* 206 */     ArrayList<ESITarget> esiTargets = new ArrayList<>();
/* 207 */     ESITarget esiTarget = null;
/*     */     try {
/* 209 */       QuerySpec qs = new QuerySpec(ESITarget.class);
/* 210 */       QueryResult qr = PersistenceHelper.manager.find(qs);
/* 211 */       while (qr.hasMoreElements()) {
/* 212 */         esiTarget = (ESITarget)qr.nextElement();
/* 213 */         esiTargets.add(esiTarget);
/*     */       } 
/* 215 */     } catch (Exception ex) {
/* 216 */       ex.printStackTrace();
/*     */     } 
/* 218 */     return esiTargets;
/*     */   }
/*     */   
/*     */   private static void deletefile(String file) {
/* 222 */     File f1 = new File(file);
/* 223 */     boolean success = f1.delete();
/* 224 */     if (!success) {
/* 225 */       System.out.println("Deletion failed.");
/* 226 */       System.exit(0);
/*     */     } else {
/* 228 */       System.out.println("File deleted.");
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void main(String[] args) throws Exception {
/* 233 */     updateESITransactionStatus();
/*     */   }
/*     */ }


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\datafrond\erpconnector\ESITransactionStateUpdate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */