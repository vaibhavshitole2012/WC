/*    */ package ext.datafrond.erpconnector;
/*    */ 
/*    */ import com.infoengine.object.factory.Att;
/*    */ import com.infoengine.object.factory.Element;
/*    */ import com.ptc.core.lwc.server.LWCNormalizedObject;
/*    */ import com.ptc.windchill.esi.esipart.ESIWTPartRenderer;
/*    */ import com.ptc.windchill.esi.rnd.ESIRendererException;
/*    */ import java.util.Collection;
/*    */ import wt.eff.Eff;
/*    */ import wt.fc.Persistable;
/*    */ import wt.part.WTPart;
/*    */ 
/*    */ 
/*    */ public class CustESIWTPartRenderer
/*    */   extends ESIWTPartRenderer
/*    */ {
/*    */   protected Element adjustPartElement(Element elem, String group, WTPart part, Eff[] effs, Collection targets) throws ESIRendererException {
/*    */     try {
/* 19 */       LWCNormalizedObject obj = new LWCNormalizedObject((Persistable)part, null, null, null);
/*    */ 
/*    */ 
/*    */       
/* 23 */       Att partSubType = elem.getAtt("PartSubType");
/* 24 */       if (partSubType != null && (
/* 25 */         partSubType.getValue() == null || partSubType.getValue().toString().trim().equals(""))) {
/* 26 */         String fullDisplayIdentity = part.getDisplayIdentity().toString();
/* 27 */         int num = fullDisplayIdentity.indexOf('-');
/* 28 */         String subTypeDisplayName = fullDisplayIdentity.substring(0, num - 1);
/* 29 */         partSubType.setValue(subTypeDisplayName);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/*    */       }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     }
/* 58 */     catch (Exception e) {
/* 59 */       e.printStackTrace();
/*    */     } 
/* 61 */     return elem;
/*    */   }
/*    */ }


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\datafrond\erpconnector\CustESIWTPartRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */