/*    */ package ext.datafrond.erpconnector;
/*    */ 
/*    */ import java.io.File;
/*    */ import javax.xml.parsers.DocumentBuilder;
/*    */ import javax.xml.parsers.DocumentBuilderFactory;
/*    */ import org.w3c.dom.Document;
/*    */ import org.w3c.dom.Element;
/*    */ import org.w3c.dom.Node;
/*    */ import org.w3c.dom.NodeList;
/*    */ 
/*    */ public class ReadXMLFile
/*    */ {
/*    */   public static ERPPublishStatusMessage getTransactionStatus(String sFile) {
/* 14 */     int id = 0;
/* 15 */     String status = "";
/* 16 */     String message = "";
/* 17 */     ERPPublishStatusMessage smg = new ERPPublishStatusMessage();
/*    */     try {
/* 19 */       File fXmlFile = new File(sFile);
/* 20 */       DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
/* 21 */       DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
/* 22 */       Document doc = dBuilder.parse(fXmlFile);
/* 23 */       doc.getDocumentElement().normalize();
/* 24 */       NodeList nList = doc.getElementsByTagName("wcReleaseTable");
/*    */       
/* 26 */       for (int temp = 0; temp < nList.getLength(); temp++) {
/* 27 */         Node nNode = nList.item(temp);
/* 28 */         if (nNode.getNodeType() == 1) {
/* 29 */           Element eElement = (Element)nNode;
/* 30 */           NodeList nlList = eElement.getElementsByTagName("TransactionId").item(0).getChildNodes();
/* 31 */           Node nValue = nlList.item(0);
/* 32 */           id = Integer.parseInt(nValue.getNodeValue());
/* 33 */           smg.setTransactionId(id);
/* 34 */           nlList = eElement.getElementsByTagName("TransactionStatus").item(0).getChildNodes();
/* 35 */           nValue = nlList.item(0);
/* 36 */           status = nValue.getNodeValue();
/* 37 */           smg.setTransactionStatus(status);
/* 38 */           System.out.println("ERPPublishStatusMessage Reading from File: " + smg.toString());
/*    */           
/* 40 */           nlList = eElement.getElementsByTagName("TransactionMessage").item(0).getChildNodes();
/* 41 */           nValue = nlList.item(0);
/* 42 */           message = nValue.getNodeValue();
/* 43 */           smg.setTransactionMessage(message);
/* 44 */           System.out.println("ERPPublishStatusMessage  Reading from File: " + smg.toString());
/*    */         } 
/*    */       } 
/* 47 */     } catch (Exception e) {
/* 48 */       e.printStackTrace();
/*    */     } 
/* 50 */     return smg;
/*    */   }
/*    */ }


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\datafrond\erpconnector\ReadXMLFile.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */