/*    */ package ext.datafrond.erpconnector;
/*    */ 
/*    */ import com.ptc.windchill.esi.tgt.ESITarget;
/*    */ import com.ptc.windchill.esi.tgt.ESITargetAssignmentValidator;
/*    */ import wt.doc.WTDocument;
/*    */ import wt.epm.EPMDocument;
/*    */ import wt.fc.Persistable;
/*    */ import wt.util.WTException;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ValidateTarget
/*    */   extends ESITargetAssignmentValidator
/*    */ {
/*    */   public static boolean isTargetValidForAutoAssignment(Persistable obj, ESITarget target) throws WTException {
/* 16 */     System.out.println("this is being called");
/* 17 */     if (obj.getClass().isAssignableFrom(WTDocument.class)) {
/*    */       
/* 19 */       System.out.println("This is from customer VAlIDATE ***********");
/*    */       
/* 21 */       return false;
/*    */     } 
/*    */     
/* 24 */     if (obj.getClass().isAssignableFrom(EPMDocument.class)) {
/*    */       
/* 26 */       System.out.println("This is from customer VAlIDATE ***********");
/*    */       
/* 28 */       return false;
/*    */     } 
/*    */ 
/*    */     
/* 32 */     return ESITargetAssignmentValidator.isTargetValidForAutoAssignment(obj, target);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean isTargetValid(Persistable obj, ESITarget target) throws WTException {
/* 39 */     return ESITargetAssignmentValidator.isTargetValid(obj, target);
/*    */   }
/*    */ }


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\datafrond\erpconnector\ValidateTarget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */