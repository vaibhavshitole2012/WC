/*    */ package ext.datafrond.erpconnector;
/*    */ 
/*    */ public class ERPPublishStatusMessage
/*    */ {
/*  5 */   private int transactionId = 0;
/*  6 */   private String transactionStatus = "";
/*  7 */   private String transactionMessage = "";
/*    */   
/*  9 */   public void setTransactionId(int id) { this.transactionId = id; }
/* 10 */   public void setTransactionStatus(String status) { this.transactionStatus = status; } public void setTransactionMessage(String message) {
/* 11 */     this.transactionMessage = message;
/*    */   }
/* 13 */   public int getTransactionId() { return this.transactionId; }
/* 14 */   public String getTransactionStatus() { return this.transactionStatus; } public String getTransactionMessage() {
/* 15 */     return this.transactionMessage;
/*    */   } public String toString() {
/* 17 */     return "transactionId =  " + this.transactionId + " transactionStatus = " + this.transactionStatus + " transactionMessage = " + this.transactionMessage;
/*    */   }
/*    */ }


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\datafrond\erpconnector\ERPPublishStatusMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */