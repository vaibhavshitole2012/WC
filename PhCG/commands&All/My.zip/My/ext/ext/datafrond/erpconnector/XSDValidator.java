/*    */ package ext.datafrond.erpconnector;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import javax.xml.transform.stream.StreamSource;
/*    */ import javax.xml.validation.Schema;
/*    */ import javax.xml.validation.SchemaFactory;
/*    */ import javax.xml.validation.Validator;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XSDValidator
/*    */ {
/*    */   public static boolean validateXMLSchema(String xsdPath, String xmlPath) {
/*    */     try {
/* 33 */       SchemaFactory factory = SchemaFactory.newInstance("http://www.w3.org/2001/XMLSchema");
/* 34 */       Schema schema = factory.newSchema(new File(xsdPath));
/* 35 */       Validator validator = schema.newValidator();
/* 36 */       validator.validate(new StreamSource(new File(xmlPath)));
/* 37 */     } catch (IOException e) {
/* 38 */       System.out.println("Exception: " + e.getMessage());
/* 39 */       return false;
/* 40 */     } catch (SAXException e1) {
/* 41 */       System.out.println("SAX Exception: " + e1.getMessage());
/* 42 */       return false;
/*    */     } 
/* 44 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\datafrond\erpconnector\XSDValidator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */