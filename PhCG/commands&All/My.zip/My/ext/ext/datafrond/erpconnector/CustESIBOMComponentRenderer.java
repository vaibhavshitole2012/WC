/*    */ package ext.datafrond.erpconnector;
/*    */ 
/*    */ import com.infoengine.object.factory.Att;
/*    */ import com.infoengine.object.factory.Element;
/*    */ import com.ptc.windchill.esi.bom.ESIBOMComponentRenderer;
/*    */ import com.ptc.windchill.esi.rnd.ESIRendererException;
/*    */ import java.util.Collection;
/*    */ import wt.fc.QueryResult;
/*    */ import wt.part.PartUsageInfo;
/*    */ import wt.part.WTPart;
/*    */ import wt.part.WTPartMaster;
/*    */ import wt.vc.Mastered;
/*    */ import wt.vc.VersionControlHelper;
/*    */ 
/*    */ public class CustESIBOMComponentRenderer
/*    */   extends ESIBOMComponentRenderer {
/*    */   protected Element adjustElement(Element elem, String group, PartUsageInfo pui, Collection targets) throws ESIRendererException {
/*    */     try {
/* 19 */       WTPart AssemblyPart = getRoot();
/* 20 */       WTPartMaster partMaster = pui.getPartMaster();
/* 21 */       WTPart wtPart = null;
/* 22 */       QueryResult results = VersionControlHelper.service.allIterationsOf((Mastered)partMaster);
/* 23 */       if (results.hasMoreElements()) {
/* 24 */         wtPart = (WTPart)results.nextElement();
/*    */       }
/*    */ 
/*    */       
/* 28 */       Att assmName = elem.getAtt("AssemblyPartName");
/* 29 */       if (assmName != null && (
/* 30 */         assmName.getValue() == null || assmName.getValue().toString().trim().equals(""))) {
/* 31 */         assmName.setValue(AssemblyPart.getName());
/*    */       }
/*    */ 
/*    */       
/* 35 */       Att assmVersion = elem.getAtt("AssemblyVersion");
/* 36 */       if (assmVersion != null && (
/* 37 */         assmVersion.getValue() == null || assmVersion.getValue().toString().trim().equals(""))) {
/* 38 */         String assmVer = AssemblyPart.getVersionIdentifier().getValue();
/* 39 */         assmVersion.setValue(assmVer);
/*    */       } 
/*    */ 
/*    */       
/* 43 */       Att assmState = elem.getAtt("AssemblyState");
/* 44 */       if (assmState != null && (
/* 45 */         assmState.getValue() == null || assmState.getValue().toString().trim().equals(""))) {
/* 46 */         String assmSt = AssemblyPart.getState().toString();
/* 47 */         assmState.setValue(assmSt);
/*    */       } 
/*    */ 
/*    */       
/* 51 */       Att partVersion = elem.getAtt("PartVersion");
/* 52 */       if (partVersion != null && (
/* 53 */         partVersion.getValue() == null || partVersion.getValue().toString().trim().equals(""))) {
/* 54 */         String partVer = wtPart.getVersionIdentifier().getValue();
/* 55 */         partVersion.setValue(partVer);
/*    */       } 
/*    */ 
/*    */       
/* 59 */       Att partState = elem.getAtt("PartState");
/* 60 */       if (partState != null && (
/* 61 */         partState.getValue() == null || partState.getValue().toString().trim().equals(""))) {
/* 62 */         String partSt = wtPart.getState().toString();
/* 63 */         partState.setValue(partSt);
/*    */       }
/*    */     
/*    */     }
/* 67 */     catch (Exception e) {
/* 68 */       e.printStackTrace();
/*    */     } 
/*    */     
/* 71 */     return elem;
/*    */   }
/*    */ }


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\datafrond\erpconnector\CustESIBOMComponentRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */