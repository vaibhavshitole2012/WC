/*    */ package ext.datafrond.erpconnector;
/*    */ 
/*    */ import com.sun.mail.smtp.SMTPMessage;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.Properties;
/*    */ import javax.mail.Address;
/*    */ import javax.mail.Message;
/*    */ import javax.mail.MessagingException;
/*    */ import javax.mail.Session;
/*    */ import javax.mail.Transport;
/*    */ import javax.mail.internet.InternetAddress;
/*    */ import wt.util.WTProperties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SendESIMail
/*    */ {
/*    */   public static void sendMail(ArrayList<String> data) throws Exception {
/* 26 */     WTProperties properties = WTProperties.getLocalProperties();
/* 27 */     String ESI_TO_MAIL = properties.getProperty("ext.datafrond.erpconnector.mailto");
/* 28 */     String ESI_FROM_MAIL = properties.getProperty("ext.datafrond.erpconnector.mailfrom");
/* 29 */     String WC_MAIL_HOST = properties.getProperty("wt.mail.mailhost");
/*    */     
/* 31 */     System.out.println("Sending mail to : " + ESI_TO_MAIL);
/* 32 */     Properties props = System.getProperties();
/* 33 */     props.put(WC_MAIL_HOST, "localhost");
/* 34 */     Session session = Session.getDefaultInstance(props, null);
/*    */     try {
/* 36 */       SMTPMessage message = new SMTPMessage(session);
/* 37 */       message.setFrom((Address)new InternetAddress(ESI_FROM_MAIL));
/* 38 */       message.addRecipient(Message.RecipientType.TO, (Address)new InternetAddress(ESI_TO_MAIL));
/* 39 */       message.setSubject("ESI Polling Queue Error in Processing ESI Result File..!");
/* 40 */       StringBuilder strBuilder = new StringBuilder();
/* 41 */       strBuilder.append("<h2>ESI Polling Queue Error in Processing ESI Result File.. </h2>");
/* 42 */       strBuilder.append("<br/>");
/* 43 */       strBuilder.append("<table align ='center' border ='1' cellpadding='10'>");
/* 44 */       strBuilder.append("<tr align='center'><th>FILE NAME</th><th>MESSAGE</th></tr>");
/* 45 */       for (Iterator<String> iter = data.iterator(); iter.hasNext(); ) {
/* 46 */         String var = iter.next();
/* 47 */         String[] splitPath = var.split("#");
/* 48 */         strBuilder.append("<tr align='center'>");
/* 49 */         for (int i = 0; i < splitPath.length; i++) {
/* 50 */           strBuilder.append("<td>" + splitPath[i] + "</td>");
/*    */         }
/* 52 */         strBuilder.append("</tr>");
/* 53 */         Thread.currentThread(); Thread.sleep(1000L);
/*    */       } 
/* 55 */       strBuilder.append("</table>");
/* 56 */       strBuilder.append("<b>Thanks,<br/>" + ESI_FROM_MAIL + "</b>");
/* 57 */       message.setContent(strBuilder.toString(), "text/html");
/* 58 */       System.out.println("Sending mail from : " + ESI_FROM_MAIL);
/* 59 */       Transport.send((Message)message);
/* 60 */       System.out.println("Sent message successfully....");
/*    */     }
/* 62 */     catch (MessagingException mex) {
/* 63 */       mex.printStackTrace();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\912210\OneDrive - Cognizant\Desktop\!\ext\datafrond\erpconnector\SendESIMail.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */