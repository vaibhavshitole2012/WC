package ext.kb.util;

import java.beans.PropertyVetoException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.ptc.core.lwc.common.BaseDefinitionService;
import com.ptc.core.lwc.common.view.EnumerationDefinitionReadView;
import com.ptc.core.lwc.common.view.EnumerationEntryReadView;
import com.ptc.core.lwc.server.LWCMasterEnumerationDefinition;
import com.ptc.core.lwc.server.cache.db.DBServiceHelper;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.impl.WCTypeIdentifier;
import com.ptc.core.meta.type.mgmt.server.impl.WTTypeDefinition;
import com.ptc.core.meta.type.mgmt.server.impl.WTTypeDefinitionMaster;
import com.ptc.generic.iba.AttributeService;
import com.ptc.netmarkets.wp.collection.AddToPackageHelper;
import com.ptc.windchill.enterprise.attachments.server.AttachmentsHelper;

import wt.access.NotAuthorizedException;
import wt.configurablelink.ConfigurableLinkHelper;
import wt.configurablelink.ConfigurableRevisionLink;
import wt.content.ApplicationData;
import wt.content.ContentHolder;
import wt.content.ContentItem;
import wt.content.ContentRoleType;
import wt.content.ContentServerHelper;
import wt.content.FormatContentHolder;
import wt.doc.DepartmentList;
import wt.doc.DocumentType;
import wt.doc.WTDocument;
import wt.doc.WTDocumentMaster;
import wt.doc._DepartmentList;
import wt.doc._DocumentType;
import wt.enterprise.EnterpriseHelper;
import wt.epm.EPMDocument;
import wt.epm.EPMDocumentMaster;
import wt.epm.EPMDocumentMasterIdentity;
import wt.fc.IdentityHelper;
import wt.fc.ObjectIdentifier;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.fc.WTObject;
import wt.fc.collections.WTArrayList;
import wt.fc.collections.WTCollection;
import wt.fc.collections.WTHashSet;
import wt.fc.collections.WTKeyedMap;
import wt.fc.collections.WTList;
import wt.folder.Folder;
import wt.folder.FolderHelper;
import wt.iba.definition.IBADefinitionException;
import wt.iba.definition.StringDefinition;
import wt.iba.definition.litedefinition.AttributeDefDefaultView;
import wt.iba.value.AbstractValue;
import wt.iba.value.DefaultAttributeContainer;
import wt.iba.value.IBAHolder;
import wt.iba.value.StringValue;
import wt.iba.value.litevalue.AbstractValueView;
import wt.inf.container.WTContainer;
import wt.inf.container.WTContainerRef;
import wt.log4j.LogR;
import wt.org.WTOrganization;
import wt.org.WTPrincipal;
import wt.org.WTPrincipalReference;
import wt.org.WTUser;
import wt.part.WTPart;
import wt.part.WTPartDescribeLink;
import wt.pds.StatementSpec;
import wt.pom.Transaction;
import wt.preference.PreferenceHelper;
import wt.query.ClassAttribute;
import wt.query.ConstantExpression;
import wt.query.OrderBy;
import wt.query.QueryException;
import wt.query.QuerySpec;
import wt.query.RelationalExpression;
import wt.query.SQLFunction;
import wt.query.SearchCondition;
import wt.query.SubSelectExpression;
import wt.query.TableColumn;
import wt.services.ServiceFactory;
import wt.session.SessionContext;
import wt.session.SessionHelper;
import wt.type.TypeDefinitionReference;
import wt.type.Typed;
import wt.type.TypedUtility;
import wt.type.TypedUtilityServiceHelper;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.vc.Iterated;
import wt.vc.IterationInfo;
import wt.vc.VersionControlException;
import wt.vc.VersionControlHelper;
import wt.vc.Versioned;
import wt.vc.struct.StructHelper;
import wt.vc.wip.WorkInProgressState;

public class KBDocumentUtils {

	private static final String KBCADDOC = "KBCADDOC";
	private static final String KBDOC = "KBDOC";
	private static final String CLASSNAME = KBDocumentUtils.class.getName();
	protected static final Logger LOGGER = LogR.getLogger(CLASSNAME);

	public static QueryResult checkWtDocumentUniquenessViolation(String number, Map<String, Object> masterAttributes,
			Map<String, Object> objAttributes) throws IBADefinitionException, NotAuthorizedException,
	ClassNotFoundException, RemoteException, WTException {
		QuerySpec querySpec = new QuerySpec();
		querySpec.setAdvancedQueryEnabled(true);

		int documentIndex = querySpec.appendClassList(WTDocument.class, true);
		int documentMasterIndex = querySpec.appendClassList(WTDocumentMaster.class, false);

		querySpec.appendWhere(DBUtils.joinToMaster(WTDocument.class, WTDocumentMaster.class),
				new int[]{documentIndex, documentMasterIndex});
		querySpec.appendAnd();
		querySpec.appendWhere(new SearchCondition(new ClassAttribute(WTDocument.class, WTDocument.NUMBER),
				SearchCondition.LIKE, new ConstantExpression((Object) (number + "%"))), new int[]{documentIndex});

		appendAttributes(querySpec, masterAttributes, WTDocumentMaster.class, documentMasterIndex);
		appendAttributes(querySpec, objAttributes, WTDocument.class, documentIndex);

		return PersistenceServerHelper.manager.query(querySpec);

	}

	private static void appendAttributes(QuerySpec querySpec, Map<String, Object> attributes, Class attributeHolder,
			int index) throws IBADefinitionException, NotAuthorizedException, ClassNotFoundException, RemoteException,
	WTException {
		if (attributes != null) {
			Iterator<Entry<String, Object>> attr = attributes.entrySet().iterator();
			while (attr.hasNext()) {
				Entry<String, Object> attribute = attr.next();
				if (attribute.getValue() != null) {
					querySpec.appendAnd();
					querySpec = DBUtils.addIbaEqualsCondition(querySpec, attribute.getKey(), attribute.getValue(),
							attributeHolder, index);
				}
			}
		}
	}

	public static void addNotCheckoutCondition(Class queriedClass, QuerySpec query, int fromIndex)
			throws QueryException {
		query.appendWhere(new SearchCondition(new ClassAttribute(queriedClass, "checkoutInfo.state"),
				SearchCondition.NOT_EQUAL, new ConstantExpression(WorkInProgressState.CHECKED_OUT)),
				new int[]{fromIndex});
	}

	public static Long getNewSapIndex(Class mainClass, Class masterClass, String documentId,
			WCTypeIdentifier mainTypeId) throws IBADefinitionException, NotAuthorizedException, ClassNotFoundException,
	RemoteException, WTException {
		QuerySpec querySpec = getBaseQuery(mainClass, false, masterClass, documentId, mainTypeId);

		querySpec.appendAnd();
		int sapIndexDefinitionIndex = querySpec.appendClassList(StringDefinition.class, false);
		int sapIndexValueIndex = querySpec.appendClassList(wt.iba.value.StringValue.class, false);

		SQLFunction maxSapIndexToNumberFunction = SQLFunction.newSQLFunction(SQLFunction.TO_NUMBER,
				new TableColumn(querySpec.getFromClause().getAliasAt(sapIndexValueIndex), "value"));
		SQLFunction maxSapIndexFunction = SQLFunction.newSQLFunction("MAX", maxSapIndexToNumberFunction);

		querySpec.appendSelect(maxSapIndexFunction, new int[]{sapIndexDefinitionIndex}, false);

		querySpec.appendWhere(
				new SearchCondition(new ClassAttribute(masterClass, DBUtils.PERS_OBJ_ID), SearchCondition.EQUAL,
						new ClassAttribute(wt.iba.value.StringValue.class,
								StringValue.IBAHOLDER_REFERENCE + DBUtils.KEY_ID)),
				new int[]{querySpec.getFromClause().getPosition(masterClass), sapIndexValueIndex});
		querySpec.appendAnd();
		querySpec.appendWhere(
				new SearchCondition(
						new ClassAttribute(wt.iba.value.StringValue.class,
								StringValue.DEFINITION_REFERENCE + DBUtils.KEY_ID),
						SearchCondition.EQUAL, new ClassAttribute(StringDefinition.class, DBUtils.PERS_OBJ_ID)),
				new int[]{sapIndexValueIndex, sapIndexDefinitionIndex});
		querySpec.appendAnd();
		querySpec.appendWhere(
				new SearchCondition(new ClassAttribute(StringDefinition.class, StringDefinition.NAME),
						SearchCondition.EQUAL, new ConstantExpression((Object) KBConstants.KBSAP_IDX_IBA)),
				new int[]{sapIndexDefinitionIndex});

		QueryResult result = PersistenceServerHelper.manager.query(querySpec);

		if (result.hasMoreElements()) {
			Object[] sapIndexArray = (Object[]) result.nextElement();
			Object bigDecimalObject = sapIndexArray[0];

			if (bigDecimalObject != null) {
				Long sapIndex = ((BigDecimal) sapIndexArray[0]).longValue();

				return sapIndex + 1;
			}
		}

		return 0L;
	}

	/**
	 * Returns the latest value of the given IBA of a WTDocument with the given
	 * documentnumber
	 *
	 * @param number Document Number of WTDoc on which we are looking for the IBA
	 * @param iba    The IBA we are looking for.
	 * @return
	 * @throws IBADefinitionException
	 * @throws NotAuthorizedException
	 * @throws ClassNotFoundException
	 * @throws RemoteException
	 * @throws WTException
	 * @deprecated Saving KB_LANGUAGE on WTDoc logic has been changed, use
	 * AttributeService.getAttribute instead.
	 */
	@Deprecated
	public static String getLatestIBAValue(String number, Object iba) throws IBADefinitionException,
	NotAuthorizedException, ClassNotFoundException, RemoteException, WTException {

		Class mainClass = WTDocument.class;
		Class masterClass = WTDocumentMaster.class;

		QuerySpec querySpec = new QuerySpec();
		querySpec.setAdvancedQueryEnabled(true);

		int mainClassIndex = querySpec.appendClassList(mainClass, false);
		int masterClassIndex = querySpec.appendClassList(masterClass, false);
		int stringDefinitionIndex = querySpec.addClassList(StringDefinition.class, false);
		int stringValueIndex = querySpec.addClassList(StringValue.class, false);

		ClassAttribute ca = new ClassAttribute(StringValue.class, StringValue.VALUE);
		querySpec.appendSelect(ca, new int[]{stringValueIndex}, false);

		querySpec.appendWhere(
				new SearchCondition(new ClassAttribute(mainClass, WTDocument.MASTER_REFERENCE + DBUtils.KEY_ID),
						SearchCondition.EQUAL, new ClassAttribute(masterClass, DBUtils.PERS_OBJ_ID)),
				new int[]{mainClassIndex, masterClassIndex});
		querySpec.appendAnd();
		querySpec.appendWhere(
				new SearchCondition(
						new ClassAttribute(wt.iba.value.StringValue.class,
								StringValue.IBAHOLDER_REFERENCE + DBUtils.KEY_ID),
						SearchCondition.EQUAL, new ClassAttribute(mainClass, DBUtils.PERS_OBJ_ID)),
				new int[]{stringValueIndex, mainClassIndex});
		querySpec.appendAnd();
		querySpec
		.appendWhere(
				new SearchCondition(new ClassAttribute(StringDefinition.class, DBUtils.PERS_OBJ_ID),
						SearchCondition.EQUAL,
						new ClassAttribute(StringValue.class,
								StringValue.DEFINITION_REFERENCE + DBUtils.KEY_ID)),
				new int[]{stringDefinitionIndex, stringValueIndex});
		querySpec.appendAnd();
		querySpec.appendWhere(
				new SearchCondition(new ClassAttribute(StringDefinition.class, StringDefinition.NAME),
						SearchCondition.EQUAL, new ConstantExpression(iba)),
				new int[]{stringDefinitionIndex});
		querySpec.appendAnd();
		querySpec.appendWhere(new SearchCondition(new ClassAttribute(mainClass, WTDocument.NUMBER),
				SearchCondition.EQUAL, new ConstantExpression((Object) number)), new int[]{mainClassIndex});
		querySpec.appendAnd();

		// Stringvalue.ida3a5 is not null (means the current value):
		querySpec.appendWhere(
				new SearchCondition(StringValue.class, StringValue.CONTEXT_REFERENCE + DBUtils.KEY_ID, false),
				new int[]{stringValueIndex});

		OrderBy orderByCreateTimestamp = new OrderBy(
				new ClassAttribute(StringValue.class, StringValue.CREATE_TIMESTAMP), true);
		// ORDER BY Stringvalue.createstampa2 desc
		querySpec.appendOrderBy(orderByCreateTimestamp, new int[]{stringValueIndex});

		QueryResult queryResult = PersistenceServerHelper.manager.query(querySpec);

		if (queryResult.hasMoreElements()) {
			Object[] resultArray = (Object[]) queryResult.nextElement();
			Object result = resultArray[0];
			if (result instanceof String) {
				return (String) result;
			} else {
				return String.valueOf(result);
			}
		}
		return "";
	}

	public static void saveLangOnWTDocWithoutCheckout(Persistable doc, HashSet<String> newValues)
			throws RemoteException, WTException, ClassNotFoundException {
		AttributeDefDefaultView attributeDefDefaultView = IBAHelper
				.getAttributeDefDefaultView(KBConstants.KBLANGUAGE_IBA);
		DefaultAttributeContainer attributeContainer = IBAHelper.getRefreshableAttributeContainer((IBAHolder) doc,
				true);
		AbstractValueView[] abstractValueViews = attributeContainer.getAttributeValues(attributeDefDefaultView);
		for (int i = 0; i < abstractValueViews.length; i++) {
			AbstractValue abstractValue = (AbstractValue) PersistenceHelper.manager
					.refresh(abstractValueViews[i].getObjectID());
			PersistenceHelper.manager.delete(abstractValue);
		}
		doc = PersistenceHelper.manager.refresh(doc);
		for (String l : newValues) {
			IBAHelper.addIBAAttributeValueWithoutCheckout(doc, KBConstants.KBLANGUAGE_IBA, l);
		}

		PersistenceServerHelper.manager.update(doc);
	}

	public static void saveLangOnEPMDocWithoutCheckout(EPMDocument epmDocument, HashSet<String> newValues)
			throws RemoteException, WTException, ClassNotFoundException {
		AttributeDefDefaultView attributeDefDefaultView = IBAHelper
				.getAttributeDefDefaultView(KBConstants.KBLANGUAGE_IBA);
		DefaultAttributeContainer attributeContainer = IBAHelper
				.getRefreshableAttributeContainer(epmDocument, true);
		AbstractValueView[] abstractValueViews = attributeContainer.getAttributeValues(attributeDefDefaultView);
		for (int i = 0; i < abstractValueViews.length; i++) {
			AbstractValue abstractValue = (AbstractValue) PersistenceHelper.manager
					.refresh(abstractValueViews[i].getObjectID());
			PersistenceHelper.manager.delete(abstractValue);
		}
		epmDocument = (EPMDocument) PersistenceHelper.manager.refresh(epmDocument);
		for (String l : newValues) {
			IBAHelper.addIBAAttributeValueWithoutCheckout(epmDocument, KBConstants.KBLANGUAGE_IBA, l);
		}
		PersistenceServerHelper.manager.update(epmDocument);
	}

	public static void saveDrwVarOnWTDocWithoutCheckout(WTDocument doc, String newValue)
			throws RemoteException, WTException, ClassNotFoundException {
		AttributeDefDefaultView attributeDefDefaultView = IBAHelper
				.getAttributeDefDefaultView(KBConstants.KB_DRAWING_VARIANT_IBA);
		DefaultAttributeContainer attributeContainer = IBAHelper.getRefreshableAttributeContainer(doc,
				true);
		AbstractValueView[] abstractValueViews = attributeContainer.getAttributeValues(attributeDefDefaultView);
		for (int i = 0; i < abstractValueViews.length; i++) {
			AbstractValue abstractValue = (AbstractValue) PersistenceHelper.manager
					.refresh(abstractValueViews[i].getObjectID());
			PersistenceHelper.manager.delete(abstractValue);
		}
		doc = (WTDocument) PersistenceHelper.manager.refresh(doc);
		IBAHelper.addIBAAttributeValueWithoutCheckout(doc, KBConstants.KB_DRAWING_VARIANT_IBA, newValue);

		PersistenceServerHelper.manager.update(doc);
	}

	public static void saveCustVarOnWTDocWithoutCheckout(WTDocument doc, String newValue)
			throws RemoteException, WTException, ClassNotFoundException {
		AttributeDefDefaultView attributeDefDefaultView = IBAHelper
				.getAttributeDefDefaultView(KBConstants.KB_DOCVAR_CUSTOMER_IBA);
		DefaultAttributeContainer attributeContainer = IBAHelper.getRefreshableAttributeContainer(doc,
				true);
		AbstractValueView[] abstractValueViews = attributeContainer.getAttributeValues(attributeDefDefaultView);
		for (int i = 0; i < abstractValueViews.length; i++) {
			AbstractValue abstractValue = (AbstractValue) PersistenceHelper.manager
					.refresh(abstractValueViews[i].getObjectID());
			PersistenceHelper.manager.delete(abstractValue);
		}
		doc = (WTDocument) PersistenceHelper.manager.refresh(doc);
		IBAHelper.addIBAAttributeValueWithoutCheckout(doc, KBConstants.KB_DOCVAR_CUSTOMER_IBA, newValue);

		PersistenceServerHelper.manager.update(doc);
	}

	public static void saveCustVarDescOnWTDocWithoutCheckout(WTDocument doc, String newValue)
			throws RemoteException, WTException, ClassNotFoundException {
		AttributeDefDefaultView attributeDefDefaultView = IBAHelper
				.getAttributeDefDefaultView(KBConstants.KB_DOCVAR_CUSTOMER_DESCRIPTION_IBA);
		DefaultAttributeContainer attributeContainer = IBAHelper.getRefreshableAttributeContainer(doc,
				true);
		AbstractValueView[] abstractValueViews = attributeContainer.getAttributeValues(attributeDefDefaultView);
		for (int i = 0; i < abstractValueViews.length; i++) {
			AbstractValue abstractValue = (AbstractValue) PersistenceHelper.manager
					.refresh(abstractValueViews[i].getObjectID());
			PersistenceHelper.manager.delete(abstractValue);
		}
		doc = (WTDocument) PersistenceHelper.manager.refresh(doc);
		IBAHelper.addIBAAttributeValueWithoutCheckout(doc, KBConstants.KB_DOCVAR_CUSTOMER_DESCRIPTION_IBA, newValue);

		PersistenceServerHelper.manager.update(doc);
	}

	public static QuerySpec getBaseQuery(Class mainClass, boolean selectMain, Class masterClass, String documentId,
			WCTypeIdentifier mainTypeId) throws WTException, ClassNotFoundException, RemoteException {
		TypeIdentifier[] subtypes = TypedUtilityServiceHelper.service.getSubtypes(mainTypeId, false, false, null);

		QuerySpec querySpec = new QuerySpec();
		querySpec.setAdvancedQueryEnabled(true);

		int documentIndex = querySpec.appendClassList(mainClass, selectMain);
		int documentMasterIndex = querySpec.appendClassList(masterClass, false);
		int typeDefinitionIndex = querySpec.addClassList(WTTypeDefinition.class, false);
		querySpec.appendWhere(
				new SearchCondition(new ClassAttribute(mainClass, Typed.TYPE_DEFINITION_REFERENCE + DBUtils.KEY_ID),
						SearchCondition.EQUAL, new ClassAttribute(WTTypeDefinition.class, DBUtils.PERS_OBJ_ID)),
				new int[]{0, typeDefinitionIndex});
		if (subtypes.length > 0) {
			querySpec.appendAnd();
			querySpec.appendOpenParen();

			for (int i = 0; i < subtypes.length; i++) {
				querySpec = addTypenameCondition(querySpec, subtypes[i].getTypename(), typeDefinitionIndex);

				if (i + 1 != subtypes.length) {
					querySpec.appendOr();
				}
			}
			querySpec.appendCloseParen();
		}

		querySpec.appendAnd();
		querySpec.appendWhere(DBUtils.joinToMaster(mainClass, masterClass),
				new int[]{documentIndex, documentMasterIndex});
		querySpec.appendAnd();
		querySpec = DBUtils.addIbaEqualsCondition(querySpec, KBConstants.KBDOCUMENT_ID_IBA, documentId, masterClass,
				documentMasterIndex);
		return querySpec;
	}

	public static String getNewWtDocumentSapIndex(String documentId) throws IBADefinitionException,
	NotAuthorizedException, ClassNotFoundException, RemoteException, WTException {
		return KBUtils.fillWithZeros(getNewSapIndex(WTDocument.class, WTDocumentMaster.class, documentId,
				KBTypeIdProvider.getType(KBDOC)));
	}

	public static String getNewEpmDocumentSapIndex(String documentId) throws IBADefinitionException,
	NotAuthorizedException, ClassNotFoundException, RemoteException, WTException {
		return KBUtils.fillWithZeros(getNewSapIndex(EPMDocument.class, EPMDocumentMaster.class, documentId,
				KBTypeIdProvider.getType(KBCADDOC)));
	}

	public static String getHvacDocumentId() throws WTException {
		return "H" + EnterpriseHelper.getNumber("{GEN:wt.enterprise.SequenceGenerator:HVAC_DOC:7:0}");

	}

	public static boolean isNewVersion(Object paramObject) throws WTException {
		if (!(paramObject instanceof Versioned)) {
			return false;
		}
		Versioned localVersioned1 = (Versioned) paramObject;
		IterationInfo localIterationInfo = localVersioned1.getIterationInfo();
		if (localVersioned1.getIterationInfo() == null) {
			return false;
		}
		ObjectReference localObjectReference = localIterationInfo.getPredecessor();
		if (localObjectReference == null) {
			return false;
		}

		Versioned localVersioned2 = (Versioned) localObjectReference.getObject();
		return localVersioned2 == null;

	}

	public static String getDocumentId(Persistable persistable) throws WTException, RemoteException {
		String documentId = AttributeService.getAttribute(persistable, KBConstants.KBDOCUMENT_ID_IBA);
		String number = null;
		if (persistable instanceof EPMDocumentMaster) {
			number = ((EPMDocumentMaster) persistable).getNumber();
		} else if (persistable instanceof WTDocumentMaster) {
			number = ((WTDocumentMaster) persistable).getNumber();
		}

		if (documentId == null || !documentId.startsWith(number)) {
			documentId = number;
			if (documentId == null || documentId.equalsIgnoreCase("(Generated)") || documentId.startsWith("TEMP")) {
				documentId = getHvacDocumentId();
			}
		}
		return documentId;
	}

	public static void checkEpmDocumentUniquenessViolation(ObjectIdentifier oid, String documentId, String language,
			String revision, String project) throws IBADefinitionException, NotAuthorizedException,
	ClassNotFoundException, RemoteException, WTException {
		WCTypeIdentifier typeIdentifier = KBTypeIdProvider.getType(KBCADDOC);
		TypeIdentifier[] subtypes = TypedUtilityServiceHelper.service.getSubtypes(typeIdentifier, false, false, null);

		Set<String> languages = new HashSet<String>();
		Collections.addAll(languages, language.split("\\/"));

		QuerySpec querySpec = new QuerySpec();
		querySpec.setAdvancedQueryEnabled(true);

		int documentIndex = querySpec.appendClassList(EPMDocument.class, true);
		int partMasterIndex = querySpec.appendClassList(EPMDocumentMaster.class, false);
		int typeDefinitionIndex = querySpec.addClassList(WTTypeDefinition.class, false);
		querySpec.appendWhere(
				new SearchCondition(
						new ClassAttribute(EPMDocument.class, Typed.TYPE_DEFINITION_REFERENCE + DBUtils.KEY_ID),
						SearchCondition.EQUAL, new ClassAttribute(WTTypeDefinition.class, DBUtils.PERS_OBJ_ID)),
				new int[]{0, typeDefinitionIndex});
		querySpec.appendAnd();
		querySpec.appendOpenParen();
		querySpec = addTypenameCondition(querySpec, typeIdentifier.getTypename(), typeDefinitionIndex);
		querySpec.appendOr();

		for (int i = 0; i < subtypes.length; i++) {
			querySpec = addTypenameCondition(querySpec, subtypes[i].getTypename(), typeDefinitionIndex);

			if (i + 1 != subtypes.length) {
				querySpec.appendOr();
			}
		}

		querySpec.appendCloseParen();

		querySpec.appendAnd();
		querySpec.appendWhere(DBUtils.joinToMaster(EPMDocument.class, EPMDocumentMaster.class),
				new int[]{0, partMasterIndex});
		querySpec.appendAnd();

		SearchCondition sc = new SearchCondition(EPMDocument.class, DBUtils.VERSION_ID, SearchCondition.EQUAL,
				revision);
		querySpec.appendWhere(sc, new int[]{documentIndex});
		querySpec.appendAnd();

		querySpec.appendOpenParen();
		querySpec = DBUtils.addIbaEqualsCondition(querySpec, KBConstants.KBDOCUMENT_ID_IBA, documentId,
				EPMDocumentMaster.class, partMasterIndex);
		querySpec.appendCloseParen();

		QueryResult result = PersistenceServerHelper.manager.query(querySpec);

		while (result.hasMoreElements()) {
			Object o = result.nextElement();
			EPMDocument epmDocument = null;
			if (o instanceof EPMDocument) {
				epmDocument = (EPMDocument) o;
			} else {
				Persistable[] array = (Persistable[]) o;
				epmDocument = (EPMDocument) array[0];
			}
			if (!oid.equals(epmDocument.getPersistInfo().getObjectIdentifier())) {
				String epmDocumentLanguage = AttributeService.getAttribute(epmDocument, KBConstants.KBLANGUAGE_IBA);
				Set<String> docLanguages = new HashSet<String>();
				Collections.addAll(docLanguages, epmDocumentLanguage.split("\\/"));
				String projectId = AttributeService.getAttribute(epmDocument, KBConstants.PROJECT_ID);

				if (languages.equals(docLanguages) && KBUtils.stringEquals(project, projectId)) {
					throw new WTException(
							"There is already an object with the same combination of Document ID-Language(s)-Revison-Project!");
				}
			}
		}
	}

	public static QuerySpec addTypenameCondition(QuerySpec querySpec, String typename, int typeDefinitionIndex)
			throws QueryException {

		querySpec
		.appendWhere(
				new SearchCondition(
						new ClassAttribute(WTTypeDefinition.class,
								WTTypeDefinition.MASTER + ">" + WTTypeDefinitionMaster.INT_HID),
						SearchCondition.EQUAL, new ConstantExpression((Object) typename)),
				new int[]{typeDefinitionIndex});

		return querySpec;
	}

	public static ClassAttribute getClassAttributeForQuery(Class queriedClass, String attributeQueryName, String alias)
			throws QueryException {
		ClassAttribute classAttribute = new ClassAttribute(queriedClass, attributeQueryName);
		classAttribute.setFromAlias(new String[]{alias}, 0);
		return classAttribute;
	}

	public static WTDocument findLatestVersionOfOriginalKBDocument(String documentId, String sapIndex)
			throws IBADefinitionException, NotAuthorizedException, ClassNotFoundException, RemoteException, WTException,
			WTPropertyVetoException {
		WCTypeIdentifier typeIdentifier = KBTypeIdProvider.getType(KBDOC);

		// MAX VERSION
		QuerySpec maxVersionQuery = getMaxVersionQuery(WTDocument.class, "B", "maxVersion");

		// MAIN QUERY
		QuerySpec querySpec = getBaseQuery(WTDocument.class, true, WTDocumentMaster.class, documentId, typeIdentifier);

		int documentIndex = querySpec.getFromClause().getPosition(WTDocument.class);
		int documentMasterIndex = querySpec.getFromClause().getPosition(WTDocumentMaster.class);
		int maxVersionSubIndex = querySpec.appendFrom(new SubSelectExpression(maxVersionQuery));

		String mainQueryAlias = querySpec.getFromClause().getAliasAt(documentIndex);
		String maxVersionAlias = querySpec.getFromClause().getAliasAt(maxVersionSubIndex);
		querySpec.appendAnd();
		connectOnColumns(getClassAttributeForQuery(WTDocument.class, WTPart.NUMBER, mainQueryAlias), documentIndex,
				querySpec, getClassAttributeForQuery(WTDocument.class, WTPart.NUMBER, maxVersionAlias),
				maxVersionSubIndex);
		querySpec.appendAnd();
		connectOnColumns(getClassAttributeForQuery(WTDocument.class, DBUtils.VERSION_ID, mainQueryAlias), documentIndex,
				querySpec, new TableColumn(maxVersionAlias, "maxVersion"), maxVersionSubIndex);

		querySpec.appendAnd();
		querySpec = DBUtils.addIbaEqualsCondition(querySpec, KBConstants.KBSAP_IDX_IBA, sapIndex,
				WTDocumentMaster.class, documentMasterIndex);
		querySpec.appendAnd();
		querySpec.appendWhere(new SearchCondition(new ClassAttribute(WTDocument.class, Iterated.LATEST_ITERATION),
				SearchCondition.IS_TRUE), new int[]{documentIndex});
		querySpec.appendAnd();
		addNotCheckoutCondition(WTDocument.class, querySpec, documentIndex);

		QueryResult result = PersistenceServerHelper.manager.query(querySpec);

		if (result.hasMoreElements()) {
			Object[] resultTable = (Object[]) result.nextElement();
			return (WTDocument) resultTable[0];
		} else {
			return null;
		}
	}

	public static QuerySpec connectOnColumns(RelationalExpression columnOneExpression, int columnOneIndex,
			QuerySpec query, RelationalExpression columnTwoExpression, int columnTwoIndex) throws QueryException {
		query.appendWhere(new SearchCondition(columnOneExpression, SearchCondition.EQUAL, columnTwoExpression),
				new int[]{columnOneIndex, columnTwoIndex});
		return query;
	}

	public static QuerySpec getMaxVersionQuery(Class queriedClass, String fromAlias, String maxFunctionAlias)
			throws WTPropertyVetoException, WTException {
		ClassAttribute numberAttribute = new ClassAttribute(queriedClass, WTPart.NUMBER);
		ClassAttribute sortVersionAttribute = new ClassAttribute(queriedClass, DBUtils.VERSION_ID);

		QuerySpec versionQuery = new QuerySpec();
		versionQuery.setAdvancedQueryEnabled(true);
		int queriedIndex = versionQuery.appendClassList(queriedClass, false);

		versionQuery.getFromClause().setAliasPrefix(fromAlias);

		SQLFunction maxVersionFunction = SQLFunction.newSQLFunction("MAX", sortVersionAttribute);
		maxVersionFunction.setColumnAlias(maxFunctionAlias);

		versionQuery.appendSelect(maxVersionFunction, new int[]{queriedIndex}, false);
		versionQuery.appendSelect(numberAttribute, new int[]{queriedIndex}, false);

		versionQuery.appendGroupBy(numberAttribute, new int[]{queriedIndex}, false);

		return versionQuery;
	}

	public static List<String> getLanguages(Persistable persistable) {
		List<String> languageList = null;
		Object language = AttributeService.getAttribute(persistable, KBConstants.KBLANGUAGE_IBA);
		LOGGER.debug("language Value = " + language);
		if (language != null) {
			if (language instanceof String) {
				languageList = new ArrayList<String>();
				languageList.add((String) language);
			} else {
				Object[] languageArray = (Object[]) language;
				languageList = Arrays.asList(Arrays.copyOf(languageArray, languageArray.length, String[].class));
			}
		}
		return languageList;
	}

	public static WTDocument createTechnicalDrawing(String number, String name, WTOrganization organization,
			WTContainer container, Folder folder, String documentId, List spracheList) throws Exception {
		LOGGER.debug("Entering createTechnicalDrawing...");

		DocumentType documentType = _DocumentType.getDocumentTypeDefault();
		WTDocument document = WTDocument.newWTDocument(number, name, documentType);
		document.setTypeDefinitionReference(
				TypedUtility.getTypeDefinitionReference(KBTypeIdProvider.getType("TECHDRWDOC").getLeafName()));

		DepartmentList docDepartmentList = _DepartmentList.getDepartmentListDefault();
		document.setDepartment(docDepartmentList);

		if (organization != null) {
			document.setOrganization(organization);
		}

		if (container != null) {
			WTContainerRef wtContainerRef = WTContainerRef.newWTContainerRef(container);
			document.setContainerReference(wtContainerRef);
		}

		if (folder != null) {
			WTList documentsList = new WTArrayList();
			documentsList.add(document);
			FolderHelper.assignLocation(documentsList, folder);
		}

		LOGGER.debug("Setting description to auto_gen");
		document.setDescription("auto_gen");

		document = (WTDocument) PersistenceHelper.manager.store(document);

		Long sheetNumber = 1L;
		WTDocumentMaster master = (WTDocumentMaster) document.getMaster();
		AttributeService.setAttribute(master, KBConstants.KBDOCUMENT_ID_IBA, documentId);
		AttributeService.setAttribute(master, KBConstants.SHEET_NO_IBA, sheetNumber);
		AttributeService.setAttribute(document, KBConstants.KBLANGUAGE_IBA, spracheList);

		PersistenceServerHelper.manager.update(master);

		return document;
	}

	public static void changeEpmDocumentMasterIdentity(EPMDocumentMaster documentMaster, String name, String number)
			throws WTException {
		try {
			EPMDocumentMasterIdentity localEPMDocumentMasterIdentity = (EPMDocumentMasterIdentity) documentMaster
					.getIdentificationObject();
			localEPMDocumentMasterIdentity.setName(name);
			localEPMDocumentMasterIdentity.setNumber(number);
			documentMaster = (EPMDocumentMaster) IdentityHelper.service.changeIdentity(documentMaster,
					localEPMDocumentMasterIdentity);

		} catch (WTPropertyVetoException localWTPropertyVetoException) {
			throw new WTException(localWTPropertyVetoException);
		}
	}

	public static void checkDesignCadLanguageFormat(String language) throws WTException {
		if (language == null) {
			// throw new WTException("Language format is empty!");
			return;
		}

		Map<String, EnumerationEntryReadView> valuesToReadViewsMap = getGlobalEnumeration("KB_LANGUAGES");

		Set<String> enumerationValues = valuesToReadViewsMap.keySet();

		Set<String> languageSet = new HashSet<>();
		Collections.addAll(languageSet, language.split("\\/"));

		if (!enumerationValues.containsAll(languageSet)) {
			throw new WTException("Language format is incorrect!");
		}
	}

	public static Map<String, EnumerationEntryReadView> getGlobalEnumeration(String enumerationName)
			throws WTException {
		LWCMasterEnumerationDefinition masterDefinition = DBServiceHelper.ENUM_DEF_DB_SERVICE
				.getEnumerationDefinition(enumerationName);
		if (masterDefinition == null) {
			return new HashMap<String, EnumerationEntryReadView>();
		}
		String identity = PersistenceHelper.getObjectIdentifier(masterDefinition).getStringValue();
		identity = identity.substring(identity.lastIndexOf(":") + 1, identity.length());
		EnumerationDefinitionReadView enumerationDefinitionReadView = ServiceFactory
				.getService(BaseDefinitionService.class).getEnumDefView(Long.valueOf(identity));
		return enumerationDefinitionReadView.getAllEnumerationEntries();
	}

	public static TreeMap<String, String> getSelectableEnumerationKeysAndValues(String enumerationName)
			throws WTException {
		TreeMap<String, String> data = new TreeMap<String, String>();
		Map<String, EnumerationEntryReadView> enumeration = getGlobalEnumeration(enumerationName);
		for (Map.Entry<String, EnumerationEntryReadView> entry : enumeration.entrySet()) {
			String key = entry.getKey();
			String value = entry.getValue().getPropertyValueByName("displayName").getValueAsString();
			String selectable = entry.getValue().getPropertyValueByName("selectable").getValueAsString();
			if ("true".equals(selectable)) {
				data.put(key, value);
			}
		}
		return data;
	}

	public static TreeMap<String, String> getEnumerationKeysAndValues(String enumerationName) throws WTException {
		TreeMap<String, String> data = new TreeMap<String, String>();
		Map<String, EnumerationEntryReadView> enumeration = getGlobalEnumeration(enumerationName);
		for (Map.Entry<String, EnumerationEntryReadView> entry : enumeration.entrySet()) {
			String key = entry.getKey();
			String value = entry.getValue().getPropertyValueByName("displayName").getValueAsString();
			data.put(key, value);
		}
		return data;
	}

	public static String getPackageProfile(Object packageOid, Object oid) {
		String profile = "PROFILE_CUSTOMER_DOCUMENTATION";
		try {
			WTUser user = (WTUser) SessionHelper.manager.getPrincipal();
			String defaultProfileValue = (String) PreferenceHelper.service.getValue(user,
					"KB_DEFAULT_CONTENTTYPE_COLLECTOR_PROFILE", "WINDCHILL");
			if (packageOid == null) {
				packageOid = oid;
			}
			if (packageOid == null) {
				return defaultProfileValue;
			}
			Object technicalPackage = AddToPackageHelper.getWPFromParameter((String) packageOid);
			if (technicalPackage == null) {
				return defaultProfileValue;
			}
			String foundProfile = AttributeService.getAttribute(technicalPackage, "KB_PACKAGE_PROFILE");
			if (foundProfile == null) {
				return defaultProfileValue;
			}
			return foundProfile;
		} catch (WTException e) {
			LOGGER.error("Unable to find default profile value ", e);
		}
		return profile;
	}

	public static List<String> getPackageLanguages(Object packageOid, Object oid) {
		List<String> langs = new ArrayList<>();
		// langs.add("EN");
		try {
			if (packageOid == null || KBUtils.isEmpty((String) packageOid)) {
				packageOid = oid;
			}
			if (packageOid == null) {
				return langs;
			}
			Object technicalPackage = AddToPackageHelper.getWPFromParameter((String) packageOid);
			if (technicalPackage == null) {
				return langs;
			}
			String foundLangs = AttributeService.getAttribute(technicalPackage, "KB_PACKAGE_LANGUAGE");
			if (foundLangs == null) {
				return langs;
			}
			langs.clear();
			langs.addAll(Arrays.asList(foundLangs.split("/")));
		} catch (WTException e) {
			LOGGER.error("Unable to query for languages", e);
		}
		return langs;
	}

	public static String getPackageOid(Object packageOid) {
		String result = "";
		try {
			if (packageOid == null || KBUtils.isEmpty((String) packageOid)) {
				return result;
			}
			Persistable technicalPackage = (Persistable) AddToPackageHelper.getWPFromParameter((String) packageOid);
			if (technicalPackage != null) {
				result = technicalPackage.getPersistInfo().getObjectIdentifier().toString();
			}

		} catch (WTException e) {
			e.printStackTrace();
		}
		return result;
	}

	public static boolean isKBTechnicalPackage() {
		boolean isTechPackage = false;
		SessionContext.getContext().get("packageNumber");

		return isTechPackage;
	}

	public static boolean hasSapIndex(String documentId) {
		return documentId.matches(".*(-[0-9][0-9][0-9])$");
	}

	public static boolean hasSapIndex(WTDocument document) {
		Object attribute = AttributeService.getAttribute(document, KBConstants.KBSAP_IDX_IBA);
		return attribute != null;
	}

	public static String getNewWtDocumentSapIndexCertificate(String documentId) throws IBADefinitionException,
	NotAuthorizedException, ClassNotFoundException, RemoteException, WTException {
		return KBUtils.fillWithZeros(getNewSapIndex(WTDocument.class, WTDocumentMaster.class, documentId,
				KBTypeIdProvider.getType("CERTYFICATEDOC")));
	}

	public static String getNewWtDocumentSapIndexStandard(String documentId) throws IBADefinitionException,
	NotAuthorizedException, ClassNotFoundException, RemoteException, WTException {
		return KBUtils.fillWithZeros(getNewSapIndex(WTDocument.class, WTDocumentMaster.class, documentId,
				KBTypeIdProvider.getType("STANDARDDOC")));
	}

	public static String getNewEPMDocumentSapIndexCadDRW(String documentId) throws IBADefinitionException,
	NotAuthorizedException, ClassNotFoundException, RemoteException, WTException {
		return KBUtils.fillWithZeros(getNewSapIndex(EPMDocument.class, EPMDocumentMaster.class, documentId,
				KBTypeIdProvider.getType("KBCADDRW")));
	}

	public static void setDocContentTypeForDrawingBaseOnWeldingBonding(WTObject kbDrw)
			throws RemoteException, WTPropertyVetoException, WTException, ClassNotFoundException {
		LOGGER.debug("setDocContentTypeForDrawing - start");
		if (kbDrw instanceof WTDocument) {
			LOGGER.debug("TECHDRWDOC:" + kbDrw);
		} else {
			LOGGER.debug("KBCADDRW:" + kbDrw);
		}

		String bonding = AttributeService.getAttribute(kbDrw, KBConstants.KB_BOND_CLASS_IBA);
		String welding = AttributeService.getAttribute(kbDrw, KBConstants.KB_WELD_CLASS_IBA);
		LOGGER.debug("bonding >" + bonding + "<");
		LOGGER.debug("welding >" + welding + "<");

		boolean isWeldingPresent = false;
		boolean isBondingPresent = false;

		if (!KBUtils.isEmpty(welding) && !welding.equals("0") && !welding.equals("-")) {
			isWeldingPresent = true;
		}

		if (!KBUtils.isEmpty(bonding) && !bonding.equals("0") && !bonding.equals("-")) {
			isBondingPresent = true;
		}

		if (isWeldingPresent && isBondingPresent) {
			IBAHelper.updateIBAAttributeValueWithoutCheckout(kbDrw, KBConstants.DOC_CONTENT_TYPE, "740");
			LOGGER.debug("For CAD Drawing: " + getDocumentNumber(kbDrw)
			+ " KB_DOC_CONTENT_TYPE = 740 (display name = BONDING- AND WELDING DRAWING) is set");
		} else if (isWeldingPresent) {
			IBAHelper.updateIBAAttributeValueWithoutCheckout(kbDrw, KBConstants.DOC_CONTENT_TYPE, "314");
			LOGGER.debug("For the CAD Drawing: " + getDocumentNumber(kbDrw)
			+ " KB_DOC_CONTENT_TYPE = 314 (display name = WELDING DRAWING) is set");
		} else if (isBondingPresent) {
			IBAHelper.updateIBAAttributeValueWithoutCheckout(kbDrw, KBConstants.DOC_CONTENT_TYPE, "739");
			LOGGER.debug("For the CAD Drawing: " + getDocumentNumber(kbDrw)
			+ " KB_DOC_CONTENT_TYPE = 739 (display name = ASSEMBLY AND BONDING DRAWING) is set");
		} else {
			LOGGER.debug(
					"Welding Bonding class is not set, User has to choose the appropriate document type on his own. the system will not overwrite the type automatically");
		}

		LOGGER.debug("setDocContentTypeForDrawing - stop");
	}

	private static String getDocumentNumber(WTObject kbDrw) {
		if (kbDrw instanceof WTDocument) {
			return ((WTDocument) kbDrw).getNumber();
		} else {
			return ((EPMDocument) kbDrw).getNumber();
		}
	}

	/**
	 * Method builds language expression where all languages are separated by
	 * "/" and leading languages is on first position.
	 *
	 * @param docLangIBA     Object from Document Language IBA.
	 * @param docLeadLangIBA Object from Document Language IBA.
	 * @return docLangExpression Built language expression.
	 */
	public static String buildLanguageExpression(Object docLangIBA, Object docLeadLangIBA) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("buildLanguageExpression(Object docLangIBA, Object docLeadLangIBA)");
			LOGGER.debug("docLangIBA: " + docLangIBA);
			LOGGER.debug("docLeadLangIBA: " + docLeadLangIBA);
		}
		String docLangExpression = "";
		List<String> docLangList = new ArrayList<>();
		if (docLangIBA instanceof Object[]) {
			for (Object lang : (Object[]) docLangIBA) {
				docLangList.add((String) lang);
			}
		} else {
			if (docLangIBA instanceof String) {
				docLangList.add((String) docLangIBA);
			} else {
				docLangList = (List<String>) docLangIBA;
			}
		}
		if (CollectionUtils.isEmpty(docLangList)) {
			return docLangExpression;
		}
		java.util.Collections.sort(docLangList, String.CASE_INSENSITIVE_ORDER);
		if (docLeadLangIBA != null && !docLeadLangIBA.equals("") && docLangList.contains(docLeadLangIBA)) {
			docLangExpression += ((String) docLeadLangIBA) + "/";
		}
		for (String langComponent : docLangList) {
			if (!langComponent.equals(docLeadLangIBA)) {
				docLangExpression += langComponent + "/";
			}
		}
		docLangExpression = docLangExpression.substring(0, docLangExpression.length() - 1);
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("exiting buildLanguageExpression()");
			LOGGER.debug("returning: " + docLangExpression);
		}
		return docLangExpression;
	}

	/**
	 * Method sets attribute with given name in given list of WTDocuments
	 *
	 * @param documents      Object to query variants from
	 * @param attributeName  Attribute name which should be set
	 * @param attributeValue Attribute value to set
	 * @throws WTPropertyVetoException
	 * @throws RemoteException
	 */
	public static void setAttributeStringValue(List<WTDocument> documents, String attributeName, String attributeValue)
			throws RemoteException, WTPropertyVetoException {
		for (WTDocument document : documents) {
			try {
				IBAHelper.setIba(document, attributeName, attributeValue);
			} catch (WTException e) {
				LOGGER.debug("Problem with adding " + attributeName + "value:" + attributeValue + "for document: "
						+ document.getNumber());
				LOGGER.debug("returning error: " + e);
			}
		}
	}

	/**
	 * Method checks is given language expression is unique among given
	 * variants.
	 *
	 * @param variants          List where language expression will be searched.
	 * @param docLangExpression Language expression which be looking for is unique.
	 * @return isVariantLangExpressionUnique Boolean value
	 */
	public static boolean isLangExpressionUniqueAmongVariantsInState(List<WTDocument> variants,
			String docLangExpression, String state) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("isLangExpressionUnique(TDocument sourceDoc, String docLangExpression)");
			LOGGER.debug("variants: " + variants);
			LOGGER.debug("docLangExpression: " + docLangExpression);
		}
		boolean isLangExpressionUnique = true;
		for (WTDocument variant : variants) {
			String variantState = variant.getState().toString();
			if (variantState.equals(state)) {
				Object variantDocLangIBA = IBAHelper.readIBA(variant, KBConstants.KBLANGUAGE_IBA);
				Object variantDocLeadLangIBA = IBAHelper.readIBA(variant, KBConstants.KB_LEADING_LANGUAGE);
				String variantDocLangExpression = KBDocumentUtils.buildLanguageExpression(variantDocLangIBA,
						variantDocLeadLangIBA);
				if (variantDocLangExpression.equals(docLangExpression)) {
					LOGGER.debug("Found same language expression on variant: " + variant);
					isLangExpressionUnique = false;
					break;
				}
			}
		}
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("exiting isLangExpressionUnique()");
			LOGGER.debug("returning: " + isLangExpressionUnique);
		}
		return isLangExpressionUnique;
	}

	public static ArrayList<String> removeDuplicates(List<String> listWithDuplicates) {
		Set<String> dedupedValuesFromList = new LinkedHashSet<>(listWithDuplicates);
		ArrayList<String> dedupedList = new ArrayList<>();
		dedupedList.addAll(dedupedValuesFromList);
		return dedupedList;
	}

	public static boolean isTechDrawing(Object candidate) {
		return KBTypeIdProvider.isDescendant(candidate, "TECHDRWDOC");
	}

	public static boolean isCadDocOrCadDrawing(Object candidate) {
		if (KBTypeIdProvider.isDescendant(candidate, KBCADDOC)
				|| KBTypeIdProvider.isDescendant(candidate, "KBCADDRW")) {
			return true;
		}
		return false;
	}

	public static boolean isTechDocument(Object candidate) {
		return KBTypeIdProvider.isDescendant(candidate, "TECHDOC");
	}

	public static boolean isDocumentWithGivenIdExistent(WTDocument requestedDocument) throws WTException {
		String docId = AttributeService.getAttribute(requestedDocument.getMaster(), KBConstants.KBDOCUMENT_ID_IBA);
		QuerySpec qs = new QuerySpec(WTDocument.class);
		qs.appendWhere(new SearchCondition(WTDocument.class, WTDocument.NUMBER, SearchCondition.LIKE, docId + "%"));
		QueryResult qr = PersistenceHelper.manager.find((StatementSpec) qs);
		while (qr.hasMoreElements()) {
			WTDocument document = (WTDocument) qr.nextElement();
			if (document.equals(requestedDocument)) {
				continue;
			}
			String retrievedId = AttributeService.getAttribute(document.getMaster(), KBConstants.KBDOCUMENT_ID_IBA);
			if (docId.equals(retrievedId)) {
				return true;
			}
		}
		return false;
	}

	public static boolean isKbDocOrRefDoc(WTDocument targetDocument) {
		boolean isKbDoc = KBTypeIdProvider.isDescendant(targetDocument, KBDOC);
		boolean isRefDoc = KBTypeIdProvider.isDescendant(targetDocument, "REFDOC");
		return isKbDoc || isRefDoc;
	}

	public static void updateDocumentLanguagesIBA(WTDocument document, String availableLangs, String langsInWork) {
		try {
			document = (WTDocument) PersistenceHelper.manager.refresh(document);
			LOGGER.debug("document: " + document.getNumber());
			LOGGER.debug("availableLangs: " + availableLangs);
			LOGGER.debug("langsInWork: " + langsInWork);
			if (!KBUtils.isEmpty(availableLangs)) {
				IBAHelper
				.updateIBAAttributeValueWithoutCheckout(document, KBConstants.KB_ALL_LANGUAGES, availableLangs);
			}
			if (!KBUtils.isEmpty(langsInWork)) {
				IBAHelper.updateIBAAttributeValueWithoutCheckout(document, KBConstants.KBLANGINWORK_IBA, langsInWork);
			} else {
				document = (WTDocument) IBAHelper.deleteIBAValues(document, KBConstants.KBLANGINWORK_IBA);
				IBAHelper.updateIBAHolder(document);
			}
		} catch (Exception e) {
			LOGGER.error("Unable to update IBAs: ", e);
		}
	}

	public static Object getDocumentLanguage(WTDocument doc, String languageType) {
		Object language = null;
		if (doc != null) {
			language = IBAHelper.readIBA(doc, languageType);
		}
		return language != null ? language : StringUtils.EMPTY;
	}

	public static void setCreatorAndModifier(Persistable document, WTPrincipal user)
			throws VersionControlException, WTPropertyVetoException, WTException {
		ReferenceFactory referenceFactory = new ReferenceFactory();
		VersionControlHelper.assignIterationCreator((Iterated) document,
				(WTPrincipalReference) referenceFactory.getReference(user));
		VersionControlHelper.setIterationModifier((Iterated) document,
				(WTPrincipalReference) referenceFactory.getReference(user));
	}

	public static void convertToType(WTDocument document, String typeName) {
		try {
			LOGGER.debug("Trying to convert document " + document + " to type: " + typeName);
			TypeDefinitionReference ref = TypedUtility.getTypeDefinitionReference(typeName);
			LOGGER.debug("Got data type def. reference: " + ref);
			document.setTypeDefinitionReference(ref);
			LOGGER.debug("Set reference " + ref + " to document " + document + ", persisting into system");
			PersistenceServerHelper.manager.update(document);
		} catch (WTException | WTPropertyVetoException e) {
			LOGGER.debug("An error has occured while trying to convert " + document + " to type: " + typeName);
		}
	}

	public static void createAttachment(ContentHolder doc, File file, String fileName)
			throws WTException, PropertyVetoException {
		Transaction trx = new Transaction();
		try (FileInputStream fis = new FileInputStream(file)) {
			trx.start();
			ApplicationData content = ApplicationData.newApplicationData(doc);
			content.setFileName(fileName);
			content.setUploadedFromPath(file.getPath());
			content.setRole(ContentRoleType.toContentRoleType("SECONDARY"));
			content.setFileSize(file.length());
			content = ContentServerHelper.service.updateContent(doc, content, fis);
			ContentServerHelper.service.updateHolderFormat((FormatContentHolder) doc);
			doc = (ContentHolder) PersistenceHelper.manager.refresh(doc, true, true);
			trx.commit();
			trx = null;
			LOGGER.debug("Attachment created sucesfully for " + doc + "FileName:" + content.getFileName());
		} catch (IOException e) {
			LOGGER.debug("problem with creating attachment: " + e);

		} finally {
			if (trx != null) {
				trx.rollback();
			}
		}
	}

	public static void updatePrimaryContent(ContentHolder doc, File file, String fileName)
			throws WTException, PropertyVetoException {
		Transaction trx = new Transaction();
		try (FileInputStream fis = new FileInputStream(file)) {
			trx.start();
			ApplicationData content = ApplicationData.newApplicationData(doc);
			content.setFileName(fileName);
			content.setUploadedFromPath(file.getPath());
			content.setRole(ContentRoleType.PRIMARY);
			content.setFileSize(file.length());
			FormatContentHolder formatContentHolder =
					(FormatContentHolder) wt.content.ContentHelper.service.getContents(doc);
			ContentItem contentItem = wt.content.ContentHelper.getPrimary(formatContentHolder);
			if (contentItem != null) {
				ContentServerHelper.service.deleteContent(doc, contentItem);
			}
			content = ContentServerHelper.service.updatePrimary((FormatContentHolder) doc, content, fis);
			ContentServerHelper.service.updateHolderFormat((FormatContentHolder) doc);
			doc = (ContentHolder) PersistenceHelper.manager.refresh(doc, true, true);
			trx.commit();
			trx = null;
			LOGGER.debug("Attachment created sucesfully for " + doc + "FileName:" + content.getFileName());
		} catch (IOException e) {
			LOGGER.debug("problem with creating attachment: " + e);

		} finally {
			if (trx != null) {
				trx.rollback();
			}
		}
	}

	public static boolean isAlreadyAttachedDocument(ApplicationData applicationData, WTDocument document)
			throws WTException {
		QueryResult attachments = AttachmentsHelper.service.getAttachments(document, ContentRoleType.SECONDARY);
		while (attachments.hasMoreElements()) {
			Object nextElement = attachments.nextElement();
			if (nextElement instanceof ApplicationData) {
				ApplicationData apPDatta = (ApplicationData) nextElement;
				String fileName = apPDatta.getFileName();
				if (fileName.equalsIgnoreCase(applicationData.getFileName())) {
					return true;
				}
			}
		}
		return false;
	}

	public static void updateDocumentLangInWork(WTDocument document)
			throws RemoteException, WTPropertyVetoException, WTException {
		ObjectReference predecessorRef = VersionControlHelper.getPredecessor(document);
		Persistable predecessor = predecessorRef.getObject();
		Object langInWork = AttributeService.getAttribute(document, KBConstants.KBLANGINWORK_IBA);
		Object lang = AttributeService.getAttribute(document, KBConstants.KBLANGUAGE_IBA);
		Object predecessorLang = AttributeService.getAttribute(predecessor, KBConstants.KBLANGUAGE_IBA);
		List<String> langsSets = langInWork == null ? Collections.EMPTY_LIST
				: Arrays.asList(((String) langInWork).split(" "));

		List<String> langs = Collections.EMPTY_LIST;
		if (lang != null) {
			if (lang instanceof String) {
				langs = Arrays.asList((String) lang);
			} else if (lang instanceof Object[]) {
				Object[] array = (Object[]) lang;
				langs = Arrays.asList(Arrays.copyOf(array, array.length, String[].class));
			}
		}

		List<String> predLangs = Collections.EMPTY_LIST;
		if (predecessorLang != null) {
			if (predecessorLang instanceof String) {
				predLangs = Arrays.asList((String) predecessorLang);
			} else if (predecessorLang instanceof Object[]) {
				Object[] array = (Object[]) predecessorLang;
				predLangs = Arrays.asList(Arrays.copyOf(array, array.length, String[].class));
			}
		}

		List<String> langsToRemove = new ArrayList<>(predLangs);
		List<String> langsToAdd = new ArrayList<>(langs);
		langsToRemove.removeAll(langs);
		langsToAdd.removeAll(predLangs);
		for (String langSet : langsSets) {
			List<String> langsFromSet = Arrays.asList(langSet.split("/"));
			if (langsFromSet.containsAll(predLangs) && predLangs.containsAll(langsFromSet)) {
				List<String> newLangInWork = new ArrayList<>(langsFromSet);
				newLangInWork.removeAll(langsToRemove);
				newLangInWork.addAll(langsToAdd);
				String newLangExpression = getUpdatedLangInWork(newLangInWork);
				if (StringUtils.isNotEmpty(newLangExpression)) {
					newLangExpression = newLangExpression.substring(0, newLangExpression.length() - 1);
				}
				langInWork = ((String) langInWork).replaceAll(langSet, newLangExpression);
				break;
			}
		}
		if (DocumentVariantHelper.isSourceDocument(document)) {
			KBDocumentUtils.setAttributeStringValue(DocumentVariantHelper.getVariants(document),
					KBConstants.KBLANGINWORK_IBA, (String) langInWork);
		} else {
			KBDocumentUtils.setAttributeStringValue(
					DocumentVariantHelper.getSourcesFromVariant((WTDocument) predecessor), KBConstants.KBLANGINWORK_IBA,
					(String) langInWork);
			KBDocumentUtils.setAttributeStringValue(DocumentVariantHelper.getOtherVariants((WTDocument) predecessor),
					KBConstants.KBLANGINWORK_IBA, (String) langInWork);
		}
		AttributeService.updateAttribute(document, KBConstants.KBLANGINWORK_IBA, langInWork);
	}

	private static String getUpdatedLangInWork(List<String> newLangInWork) {
		String newLangExpression = StringUtils.EMPTY;
		for (String laang : newLangInWork) {
			newLangExpression += laang + "/";
		}
		return newLangExpression;
	}

	public static WTDocument findRelatedNeutralData(EPMDocument epm) {
		WTDocument neutralData = null;
		try {
			String number = epm.getNumber();

			QuerySpec spec = new QuerySpec(WTDocument.class);
			SearchCondition condition = new SearchCondition(WTDocument.class, WTDocument.NUMBER, SearchCondition.EQUAL,
					number);
			spec.appendWhere(condition);
			QueryResult result = PersistenceHelper.manager.find(spec);
			if (result.hasMoreElements()) {
				neutralData = (WTDocument) result.nextElement();
			}
		} catch (WTException e) {
			LOGGER.error("Unable to query for neutral data for epmdocument" + epm.getIdentity());
		}
		return neutralData;
	}

	public static ArrayList<WTDocument> findAllRelatedNeutralData(EPMDocument epm) {
		WTDocument neutralData = null;
		ArrayList<WTDocument> list = new ArrayList<>();
		try {
			String number = epm.getNumber();

			QuerySpec spec = new QuerySpec(WTDocument.class);
			SearchCondition condition = new SearchCondition(WTDocument.class, WTDocument.NUMBER, SearchCondition.EQUAL,
					number);
			spec.appendWhere(condition);
			QueryResult result = PersistenceHelper.manager.find(spec);
			while (result.hasMoreElements()) {
				neutralData = (WTDocument) result.nextElement();
				list.add(neutralData);
			}
		} catch (WTException e) {
			LOGGER.error("Unable to query for neutral data for epmdocument" + epm.getIdentity());
		}
		return list;
	}

	public static Set<WTDocument> findDescribedByDocuments(WTPart part) throws WTException {
		Set<WTDocument> documents = new HashSet<>();
		WTCollection parts = new WTArrayList();
		parts.add(part);
		WTKeyedMap partToDocs = StructHelper.service.navigateDescribedBys(parts, WTPartDescribeLink.class, true);
		WTList list = (WTList) partToDocs.get(part);
		if (list != null) {
			list.persistableCollection().forEach(s -> documents.add((WTDocument) s));
		}
		return documents;
	}

	public static void deleteVariantLink(Object localObject) throws WTException {
		try {
			QueryResult allVarLinks = PersistenceHelper.manager.navigate((Persistable) localObject,
					ConfigurableRevisionLink.ROLE_BOBJECT_ROLE, ConfigurableRevisionLink.class, true);
			LOGGER.debug("deleteVariantLink allVarLinks size :: "+allVarLinks.size());
			WCTypeIdentifier variantlinktype = KBTypeIdProvider.getType("KBVARIANTLINK");
			WTHashSet varLinkSet=new WTHashSet();
			while(allVarLinks.hasMoreElements()) {
				LOGGER.debug("Inside allVarLinks1");
				varLinkSet.addAll(ConfigurableLinkHelper.service.getConfigurableLinks((Persistable) localObject,
						(Persistable) allVarLinks.nextElement(), variantlinktype));


			}
			LOGGER.debug("allVarLinks1 size :: "+varLinkSet.size());
			PersistenceHelper.manager.delete(varLinkSet);
		} catch(WTException e) {
			LOGGER.error(e.getLocalizedMessage());
		}
	}

}
