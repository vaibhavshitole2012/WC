package com.philips.cplm.core.doc.masterlist.monitor;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.xssf.usermodel.XSSFColor;

import com.philips.cplm.core.doc.datautility.DataUtilityHelper;
import com.philips.cplm.core.doc.masterlist.resource.PhilipsMasterListResource;
import com.philips.cplm.core.object.utilities.PhilipsRenameObjectUtils;
import com.philips.cplm.properties.PhilipsPropertiesHelper;
import com.philips.cplm.reports.RecentReleasedStandardPartsReportHelper;
import com.philips.cplm.utilities.CPLMIBAHelper;
import com.philips.cplm.utilities.SoftTypes;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.TypeIdentifierHelper;
import com.ptc.windchill.enterprise.history.HistoryTablesCommands;
import com.ptc.windchill.enterprise.history.SaveAsHistoryInfo;

import wt.change2.ChangeReviewItemLink;
import wt.change2.WTChangeReview;
import wt.configurablelink.ConfigurableLinkHelper;
import wt.configurablelink.ConfigurableMastersLink;
import wt.doc.WTDocument;
import wt.doc.WTDocumentMaster;
import wt.enterprise.MadeFromLink;
import wt.fc.BinaryLink;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.fc.WTObject;
import wt.fc.collections.CollectionsHelper;
import wt.filter.NavigationCriteria;
import wt.filter.NavigationCriteriaHelper;
import wt.filter.NavigationFilter2;
import wt.lifecycle.State;
import wt.org.WTGroup;
import wt.org.WTPrincipal;
import wt.org.WTPrincipalReference;
import wt.org.WTUser;
import wt.ownership.Ownership;
import wt.part.WTPart;
import wt.pdmlink.PDMLinkProduct;
import wt.project.Role;
import wt.session.SessionServerHelper;
import wt.team.Team;
import wt.team.TeamHelper;
import wt.util.WTContext;
import wt.util.WTException;
import wt.vc.Mastered;
import wt.vc.VersionControlHelper;
import wt.vc.config.ConfigHelper;
import wt.vc.config.ConfigSpec;
import wt.vc.wip.Workable;
import wt.workflow.engine.WfProcess;
import wt.workflow.engine.WfState;
import wt.workflow.notebook.Bookmark;
import wt.workflow.notebook.Notebook;
import wt.workflow.notebook.NotebookHelper;
import wt.workflow.work.WfAssignedActivity;
import wt.workflow.work.WorkItem;
import wt.workflow.work.WorkflowHelper;

/**
 * This class contains all the helper methods needed to generate excel report
 * data
 *
 * @author 725858
 *
 */
public class MasterListMonitorReportHelper {

	private static final Logger LOG = Logger.getLogger(MasterListMonitorReportHelper.class);

	/**
	 * This method builds rows and values
	 *
	 * @param relationshipHolderArray
	 * @return
	 * @throws Exception
	 */
	public List<RowInfoHolder> buildValues(List<MLRelationshipHolder> relationshipHolderArray) throws Exception {
		LOG.debug("ENTER method buildValues");
		HashMap<State, XSSFColor> colorMap = getBackgroundColor(); // Get color
		// mapping
		List<WTDocument> gates = getGates(relationshipHolderArray); // Get list
		// of unique
		// gates
		HashMap<WTDocument, RowInfoHolder> ccdToRowInfoHolder = new HashMap<WTDocument, RowInfoHolder>();
		for (MLRelationshipHolder relationshipHolder : relationshipHolderArray) {
			if (relationshipHolder.getCddDoc() == null) {
				continue;
			}
			RowInfoHolder rih = ccdToRowInfoHolder.get(relationshipHolder.getCddDoc());
			if (LOG.isDebugEnabled()) {
				LOG.debug("The row info holder is: " + rih);
			}

			if (rih == null) { // Process only if the row is empty

				LOG.debug("Creating a new row");
				rih = new RowInfoHolder();
				ccdToRowInfoHolder.put(relationshipHolder.getCddDoc(), rih); //

				WTDocument cddDoc = relationshipHolder.getCddDoc();

				// the
				// template
				String templateNumber = null;
				String templateVersion = null;
				String templateName = null;
				String templateIdLink = null;

				WTDocument template = getSaveAsObject(cddDoc);
				if(null!=template){
					templateNumber = template.getNumber();
					templateVersion = VersionControlHelper.getIterationDisplayIdentifier(template)
							.getLocalizedMessage(WTContext.getContext().getLocale());
					templateName = template.getName();
					templateIdLink = DataUtilityHelper.getInfoPageLink(template).getActionUrlExternal().toString();
				}
				CellInfoHolder cih = new CellInfoHolder();
				cih = new CellInfoHolder();
				cih.setValue(templateNumber); // Assign template number
				cih.setLink(templateIdLink);
				cih.setAlignment(HorizontalAlignment.LEFT);
				rih.addCellInfoHolder(cih);

				cih = new CellInfoHolder();
				cih.setValue(templateVersion); // Assign template version
				cih.setAlignment(HorizontalAlignment.LEFT);
				rih.addCellInfoHolder(cih);

				// Added for US298647 : update the value if CDD out of Sync.
				cih = new CellInfoHolder();
				if (isOutOfSync(cddDoc)) {
					cih.setValue("X");
					cih.setAlignment(HorizontalAlignment.CENTER);
					rih.setHeader(true);
				} else {
					cih.setValue("");
				}
				rih.addCellInfoHolder(cih);

				cih = new CellInfoHolder();
				cih.setValue(templateName); // Assign template name
				cih.setAlignment(HorizontalAlignment.LEFT);
				rih.addCellInfoHolder(cih);
				cih = new CellInfoHolder();
				cih.setValue(cddDoc.getNumber()); // Assign cdd number
				cih.setLink(DataUtilityHelper.getInfoPageLink(cddDoc).getActionUrlExternal().toString());
				cih.setAlignment(HorizontalAlignment.LEFT);
				rih.addCellInfoHolder(cih);

				cih = new CellInfoHolder();
				cih.setValue(VersionControlHelper.getIterationDisplayIdentifier(cddDoc)
						.getLocalizedMessage(WTContext.getContext().getLocale())); // Assign
						// cdd
				// version
				cih.setAlignment(HorizontalAlignment.LEFT);
				rih.addCellInfoHolder(cih);

				cih = new CellInfoHolder();
				cih.setValue(cddDoc.getName()); // Assign cdd name
				cih.setAlignment(HorizontalAlignment.LEFT);
				rih.addCellInfoHolder(cih);

				LOG.debug("Getting Rationale");
				// This section is for getting Rationale. Since rationale is
				// unique per gate, we are appending gate name with rationale
				StringBuilder value = new StringBuilder();
				Map<ConfigurableMastersLink, WTDocument> linktogate = getGatesAndLink(relationshipHolderArray, cddDoc);
				Iterator<ConfigurableMastersLink> iterator = linktogate.keySet().iterator();
				String delim = "";
				while (iterator.hasNext()) {
					ConfigurableMastersLink link = iterator.next();
					WTDocument gate = linktogate.get(link);
					String attrValue = (String) DataUtilityHelper.getAtributeValue(link,
							MasterListReportConstants.JUSTIFICATION_ID);
					if (StringUtils.isNotEmpty(attrValue) && !"-".equals(attrValue)) {
						value.append(delim + gate.getName() + "-" + attrValue);
						delim = "\n";
					}
				}

				String attrValue = value.toString();
				cih = new CellInfoHolder();
				cih.setValue(attrValue); // Assigning rationale
				cih.setWrapText(true);
				cih.setAlignment(HorizontalAlignment.LEFT);
				rih.addCellInfoHolder(cih);

				int gateIndex = MasterListReportConstants.GATE_START_INDEX; // This
				// is
				// important
				// this
				// is
				// where
				// the
				// dynamic
				// gate
				// columns
				// will
				// start
				for (WTDocument gate : gates) {
					cih = new CellInfoHolder();

					MLRelationshipHolder mrhg = getRelationshipHolderByGate(relationshipHolderArray, gate);
					String attrValue1 = (String) DataUtilityHelper.getAtributeValue(mrhg.getMlToGateLink(),
							MasterListReportConstants.APPLICABLE_ID);
					if (MasterListReportConstants.EXCLUDED.equals(attrValue1)) {
						cih.setBackgroundColor(MasterListReportConstants.GREY);
					} else {
						cih.setBackgroundColor(colorMap.get(gate.getLifeCycleState()));
					}
					rih.addCellInfoHolder(gateIndex++, cih); // Creating a
					// placeholder
				}

				cih = new CellInfoHolder();
				cih.setValue(DataUtilityHelper.getBoolenDisplay(
						(boolean) DataUtilityHelper.getAtributeValue(cddDoc, MasterListReportConstants.DMR_VAL))); // Assign
				// DMR
				cih.setAlignment(HorizontalAlignment.LEFT);
				rih.addCellInfoHolder(cih);

				attrValue = (String) DataUtilityHelper.getAtributeValue(cddDoc, MasterListReportConstants.DES_CAT);
				LOG.debug("The design category internal value is: " + attrValue);
				attrValue = DataUtilityHelper.getEnumDisplayValue(attrValue, MasterListReportConstants.DESIGN_CATEGORY_ATTR);
				cih = new CellInfoHolder();
				cih.setValue(attrValue); // Assign Design Category
				cih.setAlignment(HorizontalAlignment.LEFT);
				rih.addCellInfoHolder(cih);

				attrValue = (String) DataUtilityHelper.getAtributeValue(cddDoc, MasterListReportConstants.CONT_BY);
				attrValue = DataUtilityHelper.getEnumDisplayValue(attrValue, MasterListReportConstants.CONTROLLED_BY_ATTR);
				cih = new CellInfoHolder();
				cih.setValue(attrValue); // Assign Controlled By
				cih.setAlignment(HorizontalAlignment.LEFT);
				rih.addCellInfoHolder(cih);

				cih = new CellInfoHolder();
				Object rmf = DataUtilityHelper.getAtributeValue(cddDoc, MasterListReportConstants.RISK_MGMT_FILE);
				if (rmf != null) {
					cih.setValue(DataUtilityHelper.getBoolenDisplay((boolean) rmf)); // Assign
					// Risk
					// Management
					// File
				}
				cih.setAlignment(HorizontalAlignment.LEFT);
				rih.addCellInfoHolder(cih);

				cih = new CellInfoHolder();

				attrValue = (String) DataUtilityHelper.getAtributeValue(cddDoc, MasterListReportConstants.DMR_GROUP_VAL);
				attrValue = DataUtilityHelper.getEnumDisplayValue(attrValue, MasterListReportConstants.DMR_GROUP_NUMBER_ATTR);
				cih.setValue(attrValue); // Assign DMR Group
				cih.setAlignment(HorizontalAlignment.LEFT);
				rih.addCellInfoHolder(cih);

				List<WTPart> parts = DataUtilityHelper.getArchElement(cddDoc);
				StringBuffer numberBuffer = new StringBuffer();
				StringBuffer nameBuffer = new StringBuffer();

				delim = "";

				for (WTPart part : parts) {
					numberBuffer.append(delim + part.getNumber());
					nameBuffer.append(delim + part.getName());
					delim = "\n";
				}

				cih = new CellInfoHolder();
				// Assign Arch element number
				cih.setValue(numberBuffer.toString());
				cih.setWrapText(true);
				cih.setAlignment(HorizontalAlignment.LEFT);
				rih.addCellInfoHolder(cih);

				cih = new CellInfoHolder();
				// Assign Arch element name
				cih.setValue(nameBuffer.toString());
				cih.setWrapText(true);
				cih.setAlignment(HorizontalAlignment.LEFT);
				rih.addCellInfoHolder(cih);

				cih = new CellInfoHolder();
				// attrValue = (String) DataUtilityHelper.getAtributeValue(cddDoc, MasterListReportConstants.AUTHOR_ATTR);
				// cih.setValue(DataUtilityHelper.getRoleUsers(cddDoc, attrValue));
				// Assign Author

				cih.setValue(DataUtilityHelper.getAuthorColVal(MasterListReportConstants.AUTHOR_ATTR, cddDoc));
				cih.setAlignment(HorizontalAlignment.LEFT);
				rih.addCellInfoHolder(cih);

				cih = new CellInfoHolder();
				// Assign State
				cih.setValue(cddDoc.getLifeCycleState().getDisplay());
				cih.setAlignment(HorizontalAlignment.LEFT);
				rih.addCellInfoHolder(cih);

				// Logic for displaying state
				String stateDisplay = null;
				State docState = cddDoc.getLifeCycleState();
				if (PhilipsPropertiesHelper.RELEASED_STATE.equals(docState) || PhilipsPropertiesHelper.CANCELLED_STATE.equals(docState)) {
					stateDisplay = "";
				} else if (PhilipsPropertiesHelper.UNDERREVIEW_STATE.equals(docState) || PhilipsPropertiesHelper.INREVIEW_STATE.equals(docState)) {
					stateDisplay = MasterListReportConstants.IN_REVIEW;
				} else if (PhilipsPropertiesHelper.INWORK_STATE.equals(docState) || PhilipsPropertiesHelper.REWORK_STATE.equals(docState)) {
					QueryResult associatedChangeReviews = PersistenceHelper.manager.navigate(cddDoc, "theChangeReview", ChangeReviewItemLink.class);
					if (associatedChangeReviews.size() > 0) {
						WTChangeReview changeReview = (WTChangeReview) associatedChangeReviews.nextElement();
						State reviewState = changeReview.getLifeCycleState();
						if ((PhilipsPropertiesHelper.OPEN_STATE.equals(reviewState) || PhilipsPropertiesHelper.UPDATE_STATE.equals(reviewState)
								|| PhilipsPropertiesHelper.UNDERREVIEW_STATE.equals(reviewState))
								|| PhilipsPropertiesHelper.INREVIEW_STATE.equals(reviewState)) {
							stateDisplay = MasterListReportConstants.IN_REVIEW;
						}
					}

				} else {
					stateDisplay = MasterListReportConstants.UNDER_APPROVAL;
				}

				cih = new CellInfoHolder();
				cih.setValue(stateDisplay);
				cih.setAlignment(HorizontalAlignment.LEFT);
				rih.addCellInfoHolder(cih);

				/*
				 * R4.0 US1101471 - Code updated to capture the Additional Approver (Content) business roles and users associated to it in the Approver
				 * (Content) tab itself.
				 */
				attrValue = "";
				Object attrValue1 = DataUtilityHelper.getAtributeValue(cddDoc, MasterListReportConstants.CONTENT_APPROVER_ATTR);
				Object attrValue2 = DataUtilityHelper.getAtributeValue(cddDoc, MasterListReportConstants.ADDITIONAL_CONTENT_APPROVER);

				Team team = null;
				if (!PhilipsPropertiesHelper.RELEASED_STATE.equals(docState)) {
					team = TeamHelper.service.getTeam(cddDoc);
				}

				QueryResult workItems = WorkflowHelper.service.getWorkItems(cddDoc);
				cih = new CellInfoHolder();
				if (attrValue1 != null) {
					if (attrValue1 instanceof String) {
						attrValue1 = new Object[] {attrValue1};
					}
				} else {
					attrValue1 = new Object[] {};
				}

				if (attrValue2!=null) {
					if (attrValue2 instanceof String) {
						attrValue2 = new Object[] {attrValue2};
					}
				} else {
					attrValue2 = new Object[] {};
				}

				if (team != null) {
					team = (Team) PersistenceHelper.manager.refresh(team);
					attrValue = getRoleUsersWithCompletion(cddDoc, team, workItems, MasterListReportConstants.CONTENT_APPROVAL_ACTIVITY_NAME,
							(Object[]) attrValue1, PhilipsMasterListResource.CONTENT_APPROVER);
					/*
					 * R4.0 US1101471 - Code updated to hide NO_APPROVERS text.
					 */
					LOG.debug("Approver Content attrValue: " + attrValue);
					boolean isApprovalTaskCompleted = false;
					if (attrValue.trim().isEmpty()) {
						isApprovalTaskCompleted = true;
					}else if (attrValue.contains(MasterListReportConstants.NO_APPROVERS)) {
						attrValue = attrValue.replaceAll(MasterListReportConstants.NO_APPROVERS, "");
					}
					attrValue = attrValue + "\n"
							+ getRoleUsersWithCompletion(cddDoc, team, workItems, MasterListReportConstants.ADDITIONAL_CONTENT_APPROVAL_ACTIVITY_NAME,
									(Object[]) attrValue2, PhilipsMasterListResource.ADDITIONAL_CONTENT_APPROVER);

					LOG.debug("Approver Content attrValue: " + attrValue);
					/**
					 * R4.0 US1101471 - Logic to add Done if Both Additional Approver (Content) and Approver (Content) Task gets completed and Code updated to
					 * hide NO_APPROVERS text.
					 */
					// boolean noApprovals = false;

					boolean isAdditionalApprovalTaskCompleted = false;
					if (attrValue.trim().isEmpty()) {
						isAdditionalApprovalTaskCompleted = true;
					}

					if (attrValue.contains(MasterListReportConstants.NO_APPROVERS)) {
						attrValue = attrValue.replaceAll(MasterListReportConstants.NO_APPROVERS, "");
					}

					if (attrValue.trim().isEmpty() && (isApprovalTaskCompleted || isAdditionalApprovalTaskCompleted)) {
						attrValue = "Done";
					}
				}
				cih.setValue(attrValue);
				cih.setWrapText(true);
				cih.setAlignment(HorizontalAlignment.LEFT);
				rih.addCellInfoHolder(cih);

				/*
				 * R4.0 US1101471 - Code updated to capture the Additional Approver (User) business roles and users associated to it in the Approver (User) tab
				 * itself.
				 */
				attrValue1 = DataUtilityHelper.getAtributeValue(cddDoc, MasterListReportConstants.CUSTOMER_APPROVER_ATTR);
				attrValue2 = DataUtilityHelper.getAtributeValue(cddDoc, MasterListReportConstants.ADDITIONAL_CUSTOMER_APPROVER);
				attrValue = "";

				if (attrValue1 != null) {
					if (attrValue1 instanceof String) {
						attrValue1 = new Object[] {attrValue1};
					}
				} else {
					attrValue1 = new Object[] {};
				}

				if (attrValue2!=null) {
					if (attrValue2 instanceof String) {
						attrValue2 = new Object[] {attrValue2};
					}
				} else {
					attrValue2 = new Object[] {};
				}

				if (team != null) {
					attrValue = getRoleUsersWithCompletion(cddDoc, team, workItems, MasterListReportConstants.CUSTOMER_APPROVAL_ACTIVITY_NAME,
							(Object[]) attrValue1, PhilipsMasterListResource.CUSTOMER_APPROVER);
					/*
					 * R4.0 US1101471 - Code updated to hide NO_APPROVERS text.
					 */


					boolean isApprovalTaskCompleted = false;
					if (attrValue.trim().isEmpty()) {
						isApprovalTaskCompleted = true;
					}else if (attrValue.contains(MasterListReportConstants.NO_APPROVERS)) {
						attrValue = attrValue.replaceAll(MasterListReportConstants.NO_APPROVERS, "");
					}
					attrValue = attrValue + "\n"
							+ getRoleUsersWithCompletion(cddDoc, team, workItems, MasterListReportConstants.ADDITIONAL_CUSTOMER_APPROVAL_ACTIVITY_NAME,
									(Object[]) attrValue2, PhilipsMasterListResource.ADDITIONAL_CUSTOMER_APPROVER);

					/**
					 * R4.0 US1101471 - Logic to add Done if Both Additional Approver (User) and Approver (User) Task gets completed and Code updated to hide
					 * NO_APPROVERS text.
					 */
					boolean isAdditionalApprovalTaskCompleted = false;
					if (attrValue.trim().isEmpty()) {
						isAdditionalApprovalTaskCompleted = true;
					}

					if (attrValue.contains(MasterListReportConstants.NO_APPROVERS)) {
						attrValue = attrValue.replaceAll(MasterListReportConstants.NO_APPROVERS, "");
					}

					if (attrValue.trim().isEmpty() && (isApprovalTaskCompleted || isAdditionalApprovalTaskCompleted)) {
						attrValue = "Done";
					}
				}
				cih = new CellInfoHolder();
				cih.setValue(attrValue);
				cih.setWrapText(true);
				cih.setAlignment(HorizontalAlignment.LEFT);
				rih.addCellInfoHolder(cih);

				// Logic for displaying process compliance approver
				attrValue = "";
				attrValue1 = DataUtilityHelper.getAtributeValue(cddDoc, MasterListReportConstants.PROCESS_COMPLIANCE_APPROVER_ATTR);
				if (attrValue1 != null) {
					if (attrValue1 instanceof String) {
						attrValue1 = new Object[] {attrValue1};
					}
				} else {
					attrValue1 = new Object[] {};
				}
				if (team != null) {
					attrValue = getRoleUsersWithCompletion(cddDoc, team, workItems, MasterListReportConstants.PROCESS_COMPLIANCE_ACTIVITY_NAME,
							(Object[]) attrValue1, PhilipsMasterListResource.PROCESS_COMPLIANCE_APPROVER);

					/*
					 * R4.0 US1101471 - Code updated to hide NO_APPROVERS text.
					 */
					if (MasterListReportConstants.NO_APPROVERS.equals(attrValue.trim())) {
						attrValue = "";
					}
				}

				cih = new CellInfoHolder();
				cih.setValue(attrValue);
				cih.setWrapText(true);
				cih.setAlignment(HorizontalAlignment.LEFT);
				rih.addCellInfoHolder(cih);

				cih = new CellInfoHolder();
				cih.setValue(DataUtilityHelper.getSecLabelValue(cddDoc, MasterListReportConstants.IP_SEN));
				cih.setAlignment(HorizontalAlignment.LEFT);
				rih.addCellInfoHolder(cih);

				cih = new CellInfoHolder();
				cih.setValue(DataUtilityHelper.getSecLabelValue(cddDoc, MasterListReportConstants.SGI));
				cih.setAlignment(HorizontalAlignment.LEFT);
				rih.addCellInfoHolder(cih);

				cih = new CellInfoHolder();
				cih.setValue(DataUtilityHelper.getSecLabelValue(cddDoc, MasterListReportConstants.ECCN));
				cih.setAlignment(HorizontalAlignment.LEFT);
				rih.addCellInfoHolder(cih);

				// Logic for displaying FTU
				Enumeration<Notebook> notebooks = NotebookHelper.service.getNotebooks(cddDoc);
				StringBuilder sb = new StringBuilder();
				if (notebooks != null) {
					while (notebooks.hasMoreElements()) {
						Notebook nb = notebooks.nextElement();
						Enumeration<Bookmark> bookmarks = nb.getBookmarks();
						if (bookmarks != null) {
							while (bookmarks.hasMoreElements()) {
								Bookmark bm = bookmarks.nextElement();
								if (null != bm.getDescription() && bm.getName() != null
										&& bm.getName().contains(relationshipHolder.getMlDoc().getNumber() + "-" + cddDoc.getNumber())) {

									sb.append(bm.getDescription());
								}
							}
						}
					}
				}
				cih = new CellInfoHolder();
				cih.setValue(sb);
				cih.setAlignment(HorizontalAlignment.LEFT);
				rih.addCellInfoHolder(cih);

			}
			// This section is for displaying A where CDDs are included
			int gateIndex = MasterListReportConstants.GATE_START_INDEX;
			CellInfoHolder cih = new CellInfoHolder();
			for (WTDocument gate : gates) {
				if (gate.equals(relationshipHolder.getGateDoc())) {
					ConfigurableMastersLink confMastersLink = relationshipHolder.getGateToCDDLink();
					String attrValue = (String) DataUtilityHelper.getAtributeValue(confMastersLink, MasterListReportConstants.APPLICABLE_ID);
					cih = rih.getCellInfoHolder().get(gateIndex);
					if (MasterListReportConstants.INCLUDED.equals(attrValue)) {
						cih.setValue("A");
					}
				}
				gateIndex++;
			}
		}
		return new ArrayList<RowInfoHolder>(ccdToRowInfoHolder.values());
	}

	/**
	 * This method returns state to background mapping
	 *
	 * @return
	 */
	public HashMap<State, XSSFColor> getBackgroundColor() {
		LOG.debug("ENTER method getBackgroundColor");
		HashMap<State, XSSFColor> colorMap = new HashMap<State, XSSFColor>();

		colorMap.put(PhilipsPropertiesHelper.EXECUTING_STATE, MasterListReportConstants.YELLOW);
		colorMap.put(PhilipsPropertiesHelper.READYFORREVIEW_STATE, MasterListReportConstants.YELLOW);
		colorMap.put(PhilipsPropertiesHelper.COMPLETED_STATE, MasterListReportConstants.GREEN);
		colorMap.put(PhilipsPropertiesHelper.NOTSTARTED_STATE, MasterListReportConstants.BLUE);

		return colorMap;
	}

	/**
	 * @param ml
	 * @return
	 * @throws WTException
	 */
	public RowInfoHolder createMasterListInfoHeader(WTDocument ml) throws WTException {
		RowInfoHolder rih = new RowInfoHolder();
		rih.setHeader(true);

		CellInfoHolder cih = new CellInfoHolder();
		cih = new CellInfoHolder();
		cih.setValue(MasterListReportConstants.ML_TEMPLATE_ID);
		cih.setBackgroundColor(MasterListReportConstants.TEMPLATE_HEADER_BACKGROUND);
		rih.addCellInfoHolder(cih);

		cih = new CellInfoHolder();
		cih.setValue(MasterListReportConstants.VERSION);
		cih.setWrapText(true);
		cih.setBackgroundColor(MasterListReportConstants.TEMPLATE_HEADER_BACKGROUND);
		rih.addCellInfoHolder(cih);

		// Added for US298647 : Indication that a CDD document is using outdated Template.
		cih = new CellInfoHolder();
		cih.setValue(MasterListReportConstants.OUT_OF_SYNC);
		cih.setWrapText(true);
		cih.setBackgroundColor(MasterListReportConstants.TEMPLATE_HEADER_BACKGROUND);
		rih.addCellInfoHolder(cih);

		cih = new CellInfoHolder();
		cih.setValue(MasterListReportConstants.ML_TEMPLATE_NAME);
		cih.setBackgroundColor(MasterListReportConstants.TEMPLATE_HEADER_BACKGROUND);
		rih.addCellInfoHolder(cih);

		cih = new CellInfoHolder();
		cih.setValue(MasterListReportConstants.ML_ID);
		cih.setBackgroundColor(MasterListReportConstants.CDD_HEADER_BACKGROUND);
		rih.addCellInfoHolder(cih);

		cih = new CellInfoHolder();
		cih.setValue(MasterListReportConstants.VERSION);
		cih.setBackgroundColor(MasterListReportConstants.CDD_HEADER_BACKGROUND);
		cih.setWrapText(true);
		rih.addCellInfoHolder(cih);

		cih = new CellInfoHolder();
		cih.setValue(MasterListReportConstants.ML_NAME);
		cih.setBackgroundColor(MasterListReportConstants.CDD_HEADER_BACKGROUND);
		rih.addCellInfoHolder(cih);

		cih = new CellInfoHolder();
		cih.setValue(MasterListReportConstants.STATE);
		cih.setBackgroundColor(MasterListReportConstants.CDD_HEADER_BACKGROUND);
		rih.addCellInfoHolder(cih);

		return rih;
	}

	/**
	 * @param ml
	 * @return
	 * @throws Exception
	 */
	public RowInfoHolder createMasterListInfoValue(WTDocument cddDoc) throws Exception {
		RowInfoHolder rih = new RowInfoHolder();
		String templateNumber = null;
		String templateVersion = null;
		String templateName = null;
		String templateIdLink = null;

		WTDocument firstIteration = (WTDocument) VersionControlHelper.service.getFirstIterationOf(cddDoc.getMaster());
		// Get the template
		QueryResult madeFromObject = PersistenceHelper.manager.navigate(firstIteration, MadeFromLink.ORIGINAL_ROLE, MadeFromLink.class, true);

		while (madeFromObject.hasMoreElements()) {
			WTDocument template = (WTDocument) madeFromObject.nextElement();
			templateNumber = template.getNumber();
			templateVersion = VersionControlHelper.getIterationDisplayIdentifier(template).getLocalizedMessage(WTContext.getContext().getLocale());
			templateName = template.getName();
			templateIdLink = DataUtilityHelper.getInfoPageLink(template).getActionUrlExternal().toString();
		}

		CellInfoHolder cih = new CellInfoHolder();
		cih = new CellInfoHolder();
		cih.setValue(templateNumber); // Assign template number
		cih.setLink(templateIdLink);
		cih.setAlignment(HorizontalAlignment.LEFT);
		rih.addCellInfoHolder(cih);

		cih = new CellInfoHolder();
		cih.setValue(templateVersion); // Assign template version
		cih.setAlignment(HorizontalAlignment.LEFT);
		rih.addCellInfoHolder(cih);

		// Added for US298647 : Indication that a CDD document is using outdated Template.
		cih = new CellInfoHolder();
		if (isOutOfSync(cddDoc)) {
			cih.setValue("X");
			cih.setAlignment(HorizontalAlignment.CENTER);
			rih.setHeader(true);
		} else {
			cih.setValue("");
		}
		rih.addCellInfoHolder(cih);

		cih = new CellInfoHolder();
		cih.setValue(templateName); // Assign template name
		cih.setAlignment(HorizontalAlignment.LEFT);
		rih.addCellInfoHolder(cih);

		cih = new CellInfoHolder();
		cih.setValue(cddDoc.getNumber()); // Assign cdd number
		cih.setLink(DataUtilityHelper.getInfoPageLink(cddDoc).getActionUrlExternal().toString());
		cih.setAlignment(HorizontalAlignment.LEFT);
		rih.addCellInfoHolder(cih);

		cih = new CellInfoHolder();
		cih.setValue(VersionControlHelper.getIterationDisplayIdentifier(cddDoc).getLocalizedMessage(WTContext.getContext().getLocale())); // Assign
		// cdd
		// version
		cih.setAlignment(HorizontalAlignment.LEFT);
		rih.addCellInfoHolder(cih);

		cih = new CellInfoHolder();
		cih.setValue(cddDoc.getName()); // Assign cdd name
		cih.setAlignment(HorizontalAlignment.LEFT);
		rih.addCellInfoHolder(cih);

		cih = new CellInfoHolder();
		cih.setValue(cddDoc.getLifeCycleState().getDisplay()); // Assign cdd
		// name
		cih.setAlignment(HorizontalAlignment.LEFT);
		rih.addCellInfoHolder(cih);
		return rih;
	}

	/**
	 * This method creates header for the report
	 *
	 * @param relationshipHolderArray relationshipHolderArray
	 * @return rowinfoholder
	 */
	public RowInfoHolder createHeader(List<MLRelationshipHolder> relationshipHolderArray) {

		LOG.debug("ENTER method createHeader");

		RowInfoHolder rih = new RowInfoHolder();
		rih.setHeader(true);

		CellInfoHolder cih;
		cih = new CellInfoHolder();
		cih.setValue(MasterListReportConstants.TEMPLATE_ID);
		cih.setBackgroundColor(MasterListReportConstants.TEMPLATE_HEADER_BACKGROUND);
		rih.addCellInfoHolder(cih);

		cih = new CellInfoHolder();
		cih.setValue(MasterListReportConstants.TEMPLATE_VERSION);
		cih.setWrapText(true);
		cih.setBackgroundColor(MasterListReportConstants.TEMPLATE_HEADER_BACKGROUND);
		rih.addCellInfoHolder(cih);

		// Added for US298647 : Indication that a CDD document is using outdated Template.
		cih = new CellInfoHolder();
		cih.setValue(MasterListReportConstants.OUT_OF_SYNC);
		cih.setWrapText(true);
		cih.setBackgroundColor(MasterListReportConstants.TEMPLATE_HEADER_BACKGROUND);
		rih.addCellInfoHolder(cih);

		cih = new CellInfoHolder();
		cih.setValue(MasterListReportConstants.TEMPLATE_NAME);
		cih.setBackgroundColor(MasterListReportConstants.TEMPLATE_HEADER_BACKGROUND);
		rih.addCellInfoHolder(cih);

		cih = new CellInfoHolder();
		cih.setValue(MasterListReportConstants.DOCUMENT_ID);
		cih.setBackgroundColor(MasterListReportConstants.CDD_HEADER_BACKGROUND);
		rih.addCellInfoHolder(cih);

		cih = new CellInfoHolder();
		cih.setValue(MasterListReportConstants.DOCUMENT_VERSION);
		cih.setBackgroundColor(MasterListReportConstants.CDD_HEADER_BACKGROUND);
		cih.setWrapText(true);
		rih.addCellInfoHolder(cih);

		cih = new CellInfoHolder();
		cih.setValue(MasterListReportConstants.DOCUMENT_NAME);
		cih.setBackgroundColor(MasterListReportConstants.CDD_HEADER_BACKGROUND);
		rih.addCellInfoHolder(cih);

		cih = new CellInfoHolder();
		cih.setValue(MasterListReportConstants.RATIONALE);
		cih.setBackgroundColor(MasterListReportConstants.OTHER_HEADER_BACKGROUND);
		rih.addCellInfoHolder(cih);

		LOG.debug("Creating gates header");

		List<WTDocument> gates = getGates(relationshipHolderArray); // Get
		// Unique
		// gates and
		// print
		// them out
		for (WTDocument gate : gates) {
			cih = new CellInfoHolder();
			cih.setValue(gate.getName());
			cih.setBackgroundColor(MasterListReportConstants.GATE_HEADER_BACKGROUND);
			cih.setRotation((short) 90);
			rih.addCellInfoHolder(cih);
			cih.setAlignment(HorizontalAlignment.LEFT);
		}

		cih = new CellInfoHolder();
		cih.setValue(MasterListReportConstants.DMR);
		cih.setBackgroundColor(MasterListReportConstants.OTHER_HEADER_BACKGROUND);
		rih.addCellInfoHolder(cih);

		cih = new CellInfoHolder();
		cih.setValue(MasterListReportConstants.DESIGN_CATEGORY);
		cih.setBackgroundColor(MasterListReportConstants.OTHER_HEADER_BACKGROUND);
		rih.addCellInfoHolder(cih);

		cih = new CellInfoHolder();
		cih.setValue(MasterListReportConstants.CONTROLLED_BY);
		cih.setBackgroundColor(MasterListReportConstants.OTHER_HEADER_BACKGROUND);
		rih.addCellInfoHolder(cih);

		cih = new CellInfoHolder();
		cih.setValue(MasterListReportConstants.RISK_MANAGEMENT_FILE);
		cih.setBackgroundColor(MasterListReportConstants.OTHER_HEADER_BACKGROUND);
		rih.addCellInfoHolder(cih);

		cih = new CellInfoHolder();
		cih.setValue(MasterListReportConstants.DMR_GROUP_NUMBER);
		cih.setBackgroundColor(MasterListReportConstants.OTHER_HEADER_BACKGROUND);
		rih.addCellInfoHolder(cih);

		cih = new CellInfoHolder();
		cih.setValue(MasterListReportConstants.ARCH_ELEMENT_ID);
		cih.setBackgroundColor(MasterListReportConstants.OTHER_HEADER_BACKGROUND);
		rih.addCellInfoHolder(cih);

		cih = new CellInfoHolder();
		cih.setValue(MasterListReportConstants.ARCH_ELEMENT_NAME);
		cih.setBackgroundColor(MasterListReportConstants.OTHER_HEADER_BACKGROUND);
		rih.addCellInfoHolder(cih);

		cih = new CellInfoHolder();
		cih.setValue(MasterListReportConstants.AUTHOR);
		cih.setBackgroundColor(MasterListReportConstants.OTHER_HEADER_BACKGROUND);
		rih.addCellInfoHolder(cih);

		cih = new CellInfoHolder();
		cih.setValue(MasterListReportConstants.DOCUMENT_STATE);
		cih.setBackgroundColor(MasterListReportConstants.OTHER_HEADER_BACKGROUND);
		rih.addCellInfoHolder(cih);

		cih = new CellInfoHolder();
		cih.setValue(MasterListReportConstants.PROCESS_STATE);
		cih.setBackgroundColor(MasterListReportConstants.OTHER_HEADER_BACKGROUND);
		rih.addCellInfoHolder(cih);

		cih = new CellInfoHolder();
		cih.setValue(MasterListReportConstants.CONTENT_APPROVER);
		cih.setBackgroundColor(MasterListReportConstants.OTHER_HEADER_BACKGROUND);
		rih.addCellInfoHolder(cih);

		cih = new CellInfoHolder();
		cih.setValue(MasterListReportConstants.CUSTOMER_APPROVER);
		cih.setBackgroundColor(MasterListReportConstants.OTHER_HEADER_BACKGROUND);
		rih.addCellInfoHolder(cih);

		cih = new CellInfoHolder();
		cih.setValue(MasterListReportConstants.PROCESS_COMPLIANCE_APPROVER);
		cih.setBackgroundColor(MasterListReportConstants.OTHER_HEADER_BACKGROUND);
		rih.addCellInfoHolder(cih);

		cih = new CellInfoHolder();
		cih.setValue(MasterListReportConstants.IP_SENSITIVITY);
		cih.setBackgroundColor(MasterListReportConstants.OTHER_HEADER_BACKGROUND);
		rih.addCellInfoHolder(cih);

		cih = new CellInfoHolder();
		cih.setValue(MasterListReportConstants.SGI);
		cih.setBackgroundColor(MasterListReportConstants.OTHER_HEADER_BACKGROUND);
		rih.addCellInfoHolder(cih);

		cih = new CellInfoHolder();
		cih.setValue(MasterListReportConstants.ECCN);
		cih.setBackgroundColor(MasterListReportConstants.OTHER_HEADER_BACKGROUND);
		rih.addCellInfoHolder(cih);

		cih = new CellInfoHolder();
		cih.setValue(MasterListReportConstants.FTU);
		cih.setBackgroundColor(MasterListReportConstants.OTHER_HEADER_BACKGROUND);
		rih.addCellInfoHolder(cih);
		return rih;
	}

	/**
	 * This method returns all the unique gates for a master list
	 *
	 * @param relationshipHolderArray
	 * @return
	 */
	public List<WTDocument> getGates(List<MLRelationshipHolder> relationshipHolderArray) {
		LOG.debug("ENTER method getGates");
		List<WTDocument> gates = new ArrayList<WTDocument>();
		for (MLRelationshipHolder mrh : relationshipHolderArray) {
			if (!gates.contains(mrh.getGateDoc())) {
				gates.add(mrh.getGateDoc());
			}
		}
		gates.sort((WTDocument s1, WTDocument s2) -> s1.getName().compareTo(s2.getName()));
		return gates;
	}

	/**
	 * Method to get the relationship holder by gate.
	 *
	 * @param relationshipHolderArray relationshipHolderArray
	 * @param gateDoc gateDoc
	 * @return MLRelationshipHolder
	 */
	public MLRelationshipHolder getRelationshipHolderByGate(List<MLRelationshipHolder> relationshipHolderArray, WTDocument gateDoc) {
		MLRelationshipHolder holder = null;
		for (MLRelationshipHolder mrh : relationshipHolderArray) {
			if (gateDoc.equals(mrh.getGateDoc())) {
				holder = mrh;
			}
		}
		return holder;
	}

	/**
	 * Method to get gates and links from cdd
	 *
	 * @param relationshipHolderArray relationshipHolderArray
	 * @param cdd cdd
	 * @return map of links
	 */
	public Map<ConfigurableMastersLink, WTDocument> getGatesAndLink(List<MLRelationshipHolder> relationshipHolderArray, WTDocument cdd) {
		LOG.debug("ENTER method getGatesAndLink");
		Map<ConfigurableMastersLink, WTDocument> dataMap = new HashMap<>();
		for (MLRelationshipHolder mrh : relationshipHolderArray) {
			if (cdd.equals(mrh.getCddDoc())) {
				dataMap.put(mrh.getGateToCDDLink(), mrh.getGateDoc());
			}
		}
		return dataMap;
	}

	/**
	 * This method collects all the CDDs and associated gates in flat structure so that it could be used for excel report
	 *
	 * @param mlDoc mlDoc
	 * @return list of holders
	 * @throws WTException WTException
	 */
	public List<MLRelationshipHolder> collectDocumentsAndLinks(WTDocument mlDoc) throws WTException {
		LOG.debug("ENTER method collectDocumentsAndLinks for " + mlDoc.getIdentity());

		List<MLRelationshipHolder> relationshipHolderArray = new ArrayList<MLRelationshipHolder>();
		TypeIdentifier mlToGateLinkType = TypeIdentifierHelper.getTypeIdentifier(MasterListReportConstants.CONFIGURABLE_MASTRLIST_GATE_LINK);
		ReferenceFactory ref = new ReferenceFactory();
		QueryResult mlToGateLinks =
				ConfigurableLinkHelper.service.getOtherSideObjectsFromLink(ref.getReference(mlDoc), mlToGateLinkType, BinaryLink.ROLE_BOBJECT_ROLE, false);
		while (mlToGateLinks.hasMoreElements()) {

			ConfigurableMastersLink mlToGateLink = (ConfigurableMastersLink) ((Persistable[]) mlToGateLinks.nextElement())[0];
			WTDocumentMaster docGateMaster = (WTDocumentMaster) mlToGateLink.getTraces();
			NavigationCriteria navigationCriteria = getNavigationCriteria((WTObject) mlToGateLink.getTraces());
			WTDocument gateDoc = (WTDocument) getIterationFromMaster(docGateMaster, navigationCriteria);

			LOG.debug("\tGate: " + gateDoc.getIdentity());

			TypeIdentifier cdToGateLinkType = TypeIdentifierHelper.getTypeIdentifier(MasterListReportConstants.CONFIGURABLE_GATE_DELIVERABLE_LINK);
			QueryResult queryResultLinks = ConfigurableLinkHelper.service.getOtherSideObjectsFromLink(ref.getReference(gateDoc), cdToGateLinkType,
					BinaryLink.ROLE_BOBJECT_ROLE, false);

			if (queryResultLinks.size() > 0) {
				while (queryResultLinks.hasMoreElements()) {
					ConfigurableMastersLink gateToCDDLink = (ConfigurableMastersLink) ((Persistable[]) queryResultLinks.nextElement())[0];
					WTDocumentMaster docCddMaster = (WTDocumentMaster) gateToCDDLink.getTraces();
					navigationCriteria = getNavigationCriteria(docCddMaster);
					WTDocument cddDoc = (WTDocument) getIterationFromMaster(docCddMaster, navigationCriteria);

					LOG.debug("\t\tCDD: " + cddDoc.getIdentity());

					MLRelationshipHolder relationshipHolder = new MLRelationshipHolder();
					relationshipHolder.setMlDoc(mlDoc);
					relationshipHolder.setGateDoc(gateDoc);
					relationshipHolder.setMlToGateLink(mlToGateLink);

					relationshipHolder.setCddDoc(cddDoc);
					relationshipHolder.setGateToCDDLink(gateToCDDLink);

					relationshipHolderArray.add(relationshipHolder);
				}
			} else {
				MLRelationshipHolder relationshipHolder = new MLRelationshipHolder();
				relationshipHolder.setMlDoc(mlDoc);
				relationshipHolder.setGateDoc(gateDoc);
				relationshipHolder.setMlToGateLink(mlToGateLink);
				relationshipHolderArray.add(relationshipHolder);
			}
		}
		return relationshipHolderArray;
	}

	/**
	 * Criteria builder to get child object from master
	 *
	 * @param wtObj wtObj
	 * @return navigation criteria
	 * @throws WTException WTException
	 */
	public NavigationCriteria getNavigationCriteria(WTObject wtObj) throws WTException {
		LOG.debug("ENTER method prepareNavigationCriteria");
		NavigationCriteria navigationCriteria = null;
		if (navigationCriteria == null) {
			try {
				navigationCriteria = NavigationCriteriaHelper.service.getDefaultNavigationCriteria(CollectionsHelper.singletonWTList(wtObj), null);
				LOG.debug("Got navigation criteria from NavigationCriteriaService => " + navigationCriteria);
			} catch (Exception t) {
				LOG.error("Error getting navigation criteria from NavigationCriteriaService", t);
			}
		}
		if (LOG.isDebugEnabled() && navigationCriteria != null) {
			LOG.debug("prepareNavigationCriteria:: Navigation Criteria Name: " + navigationCriteria.getName());
			LOG.debug("prepareNavigationCriteria:: Navigation Criteria Type: " + navigationCriteria.getType());
			Collection<NavigationFilter2> filters = navigationCriteria.getFilters();
			for (NavigationFilter2 filter : filters) {
				LOG.debug("prepareNavigationCriteria:: Filter: " + filter.getDisplayIdentifier().getLocalizedMessage(WTContext.getContext().getLocale()));
			}
			List<ConfigSpec> configSpecs = navigationCriteria.getConfigSpecs();
			for (ConfigSpec configSpec : configSpecs) {
				LOG.debug("prepareNavigationCriteria:: ConfigSpec: " + configSpec.toString());
			}
		}
		LOG.debug("EXIT method prepareNavigationCriteria with result:: " + navigationCriteria);
		return navigationCriteria;
	}

	/**
	 * Method to get iteration from master given a config spec
	 *
	 * @param masterObject masterObject
	 * @param navigationCriteria navigationCriteria
	 * @return wtobject
	 */
	public WTObject getIterationFromMaster(Mastered masterObject, NavigationCriteria navigationCriteria) {
		LOG.debug("getIterationFromMaster");
		WTObject result = null;

		try {
			QueryResult iters = ConfigHelper.service.filteredIterationsOf(masterObject, navigationCriteria.getConfigSpecs());
			if ((iters != null) && iters.hasMoreElements()) {
				Object iter = iters.nextElement();
				if (iter instanceof WTObject) {
					LOG.debug("getIterationFromMaster: found instance");
					result = (WTObject) iter;
				}
			}
		} catch (WTException e) {
			LOG.error(e);
		}
		return result;
	}

	/**
	 * Collect users for team and workflow roles
	 *
	 * @param team team
	 * @param workflowRole workflowRole
	 * @param businessRoles businessRoles
	 * @return map map
	 * @throws WTException WTException
	 */
	public Map<Role, ArrayList<Object>> collectUsers(Team team, String workflowRole, Object[] businessRoles) throws WTException {
		Map<Role, ArrayList<Object>> roleToUsersMap = new HashMap<>();

		Map rolePrincipalMap = team.getRolePrincipalMap();
		Role workflowRoleObj = Role.toRole(workflowRole);
		ArrayList<Object> workflowPrincipals = (ArrayList<Object>) rolePrincipalMap.get(workflowRoleObj);
		HashSet<Object> principalsWithRole = new HashSet<Object>();
		for (Object role : businessRoles) {
			Role roleObj = Role.toRole(role.toString());
			roleToUsersMap.put(roleObj, new ArrayList<Object>());
			ArrayList allPrincipals = (ArrayList) rolePrincipalMap.get(roleObj);
			if (allPrincipals != null) {
				Iterator alIterator = allPrincipals.iterator();
				while (alIterator.hasNext()) {
					WTPrincipalReference principal = (WTPrincipalReference) alIterator.next();
					// R4.0 US1101471 - added check for workflowPrincipals as array is not null.
					if (null != workflowPrincipals && workflowPrincipals.contains(principal)) {
						roleToUsersMap.get(roleObj).add(principal);
						principalsWithRole.add(principal);
					}
				}
			}
		}
		if (workflowPrincipals != null) {
			workflowPrincipals.removeAll(principalsWithRole);
			roleToUsersMap.put(workflowRoleObj, workflowPrincipals);
		}
		return roleToUsersMap;
	}

	/**
	 * Gets Completition status for User for a activity
	 *
	 * @param teamed teamed
	 * @param team team
	 * @param workItems workItems
	 * @param activityName activityName
	 * @param businessRoles businessRoles
	 * @param workflowRole workflowRole
	 * @return String of role users
	 * @throws WTException WTException
	 */
	public String getRoleUsersWithCompletion(WTDocument teamed, Team team, QueryResult workItems, String activityName, Object[] businessRoles,
			String workflowRole) throws WTException {
		LOG.debug("Number: " + teamed.getNumber());
		final String DOCUMENT_RELEASE_PROCESS_TYPE_IBA_KEY = "phiDocReleaseProcessType";
		final String CHANGE_CONTROLLED_IBA_VALUE = "ChangeNoticeControlled";
		StringBuilder sb = new StringBuilder();

		// Add code to return empty string if businessRoles is null or empty

		String subDeliverableIBAValue = CPLMIBAHelper.getIBAValuesToString(teamed, DOCUMENT_RELEASE_PROCESS_TYPE_IBA_KEY).toString();
		LOG.debug("subDeliverableIBAValue: " + subDeliverableIBAValue);
		if (subDeliverableIBAValue.equals(CHANGE_CONTROLLED_IBA_VALUE)) {
			return MasterListReportConstants.NO_APPROVERS;
		}

		Map<Role, ArrayList<Object>> rolePrincipalMap = collectUsers(team, workflowRole, businessRoles);
		LOG.debug("Size of rolePrincipalMap: " + rolePrincipalMap.size());
		LOG.debug("Size of businessRoles: " + businessRoles.length);
		if (businessRoles.length == 0 || rolePrincipalMap.size() == 0) {
			return MasterListReportConstants.NO_APPROVERS;
		}
		String linedelim = "";
		WfState state = getStatus(workItems, activityName);

		/**
		 * R4.0 US1101471 - Done word was appearing whenever Additional Approver (Content) or Approver (Content) or Additional Approver (User) or Approver
		 * (User) any one of task gets completed.
		 **/
		if (WfState.CLOSED_COMPLETED_EXECUTED.equals(state)) {
			sb.append("");
		} else {
			Iterator iterator = rolePrincipalMap.keySet().iterator();
			while (iterator.hasNext()) {
				StringBuilder subString = new StringBuilder();
				Role role = (Role) iterator.next();
				subString.append(linedelim);
				if (!role.toString().equals(workflowRole)) {
					// If the task is Approval (content) or Approval (User), the business role will be prefixed with '*' indicating that these tasks are
					// mandatory to complete.
					if(activityName.equals(MasterListReportConstants.CONTENT_APPROVAL_ACTIVITY_NAME)
							|| activityName.equals(MasterListReportConstants.CUSTOMER_APPROVAL_ACTIVITY_NAME)){
						subString.append("*"+role.getDisplay() + ": ");
					} else {
						// R4.0 US1101471 - If None role is there then continue, no need to show in report.
						if ("None".equals(role.getDisplay())) {
							continue;
						}
						subString.append(role.getDisplay() + ": ");
					}
				}
				ArrayList<WTPrincipalReference> allPrincipals = (ArrayList) rolePrincipalMap.get(role);
				String delim = "";

				for (WTPrincipalReference principalReference : allPrincipals) {
					WTPrincipal principal = (WTPrincipal) principalReference.getObject();
					if (principal instanceof WTUser) {
						WTUser user = (WTUser) principal;
						StringBuilder completionString[] = getCompletionFlag(teamed, workItems, activityName, workflowRole, user);
						if (StringUtils.isNotEmpty(completionString[0])) {
							subString.append(delim + completionString[0]);
							delim = completionString[1].toString();
						}
					} else if (principal instanceof WTGroup) {
						WTGroup wtGroup = (WTGroup) principal;
						if (teamed.getLifeCycleState().equals(PhilipsPropertiesHelper.INWORK_STATE)
								|| teamed.getLifeCycleState().equals(PhilipsPropertiesHelper.RELEASED_STATE)) {
							subString.append(delim + wtGroup.getName());
							delim = ", ";
						} else {
							List<WTUser> userList = RecentReleasedStandardPartsReportHelper.getUsersFromGroup(wtGroup);
							for (WTUser user : userList) {
								StringBuilder completionString[] = getCompletionFlag(teamed, workItems, activityName, workflowRole, user);
								if (StringUtils.isNotEmpty(completionString[0])) {
									subString.append(delim + completionString[0]);
									delim = completionString[1].toString();
								}
							}
						}
					}
				}
				// State is Null if activity is not started. Delim is not empty
				// if activity is OPEN even for single person
				if (state == null || StringUtils.isNotEmpty(delim)) {
					sb.append(subString);
					linedelim = "\n";
				}
			}
		}
		return sb.toString();
	}

	/**
	 * Gets Completition status for each User from group for a activity
	 *
	 * @param teamed teamed
	 * @param workItems workItems
	 * @param activityName activityName
	 * @param user WTUser
	 * @return completionSubString
	 * @throws WTException WTException
	 */
	private StringBuilder[] getCompletionFlag(WTDocument teamed, QueryResult workItems, String activityName, String workflowRole, WTUser user)
			throws WTException {
		if (LOG.isDebugEnabled()) {
			LOG.debug("Start getCompletionFlag for: " + teamed.getIdentity());
		}
		String completitonFlag = "";
		StringBuilder delim = new StringBuilder();
		StringBuilder subString = new StringBuilder();

		if (!(teamed.getLifeCycleState().equals(PhilipsPropertiesHelper.INWORK_STATE)
				|| teamed.getLifeCycleState().equals(PhilipsPropertiesHelper.RELEASED_STATE))) {
			if (teamed.getLifeCycleState().equals(PhilipsPropertiesHelper.REWORK_STATE)) {
				completitonFlag = MasterListReportConstants.UNDEF;
			} else {
				completitonFlag = getCompletitionStatus(workItems, activityName, workflowRole, user);
			}
		}
		if (!MasterListReportConstants.DONE.equals(completitonFlag)) {
			subString.append(delim.toString() + user.getFullName());
			subString.append(completitonFlag);
			delim.append(", ");
		}
		StringBuilder[] completionSubString = new StringBuilder[] {subString, delim};
		if (LOG.isDebugEnabled()) {
			LOG.debug("End getCompletionFlag");
		}
		return completionSubString;
	}

	/**
	 * Gets the status of workitem.
	 *
	 * @param workItems workItems
	 * @param activityName activityName
	 * @return Workflow State
	 * @throws WTException WTException
	 */
	public WfState getStatus(QueryResult workItems, String activityName) throws WTException {
		WfState state = null;
		workItems.reset();
		while (workItems.hasMoreElements()) {
			WorkItem workItem = (WorkItem) workItems.nextElement();
			WfAssignedActivity activity = (WfAssignedActivity) workItem.getSource().getObject();
			WfProcess parentProcess = activity.getParentProcess();
			WfState state1 = parentProcess.getState();
			if (!WfState.OPEN_RUNNING.equals(state1) || !activityName.equals(activity.getName())) {
				continue;
			}
			state = activity.getState();
		}
		return state;
	}

	/**
	 * Gets Completion status of workitme
	 *
	 * @param workItems workItems
	 * @param activityName activityName
	 * @param roleName roleName
	 * @param user user
	 * @return String of completion status
	 * @throws WTException WTException
	 */
	public String getCompletitionStatus(QueryResult workItems, String activityName, String roleName, WTUser user) throws WTException {
		String completitonFlag = "";
		workItems.reset();
		while (workItems.hasMoreElements()) {
			WorkItem workItem = (WorkItem) workItems.nextElement();
			Ownership ownership = workItem.getOwnership();
			WTPrincipal owner = ownership.getOwner().getPrincipal();
			if (user.equals(owner)) {
				WfAssignedActivity activity = (WfAssignedActivity) workItem.getSource().getObject();
				WfProcess parentProcess = activity.getParentProcess();
				WfState state1 = parentProcess.getState();
				if (!WfState.OPEN_RUNNING.equals(state1) || !roleName.equals(workItem.getRole().toString()) || !activityName.equals(activity.getName())) {
					continue;
				}
				if (workItem.isComplete()) {
					completitonFlag = MasterListReportConstants.DONE;
				} else {
					completitonFlag = MasterListReportConstants.OPEN;
				}
			}
		}
		return completitonFlag;
	}

	/**
	 * check if CDD is out of sync with template
	 *
	 * @param object Workable
	 * @return outOfSync boolean
	 */
	public static boolean isOutOfSync(Workable object) {
		boolean outOfSync = false;
		WTDocument doc = null;
		boolean enforced = true;
		try {
			if (object instanceof Workable
					&& (SoftTypes.isType(object, SoftTypes.PHILIPS_CONTROLLED_DELIVERABLE_DOCUMENT) ||
							SoftTypes.isType(object, SoftTypes.PHILIPS_MASTER_LIST))) {
				doc = getSaveAsObject(object);
				if (null != doc) {
					enforced = SessionServerHelper.manager.setAccessEnforced(false);
					WTDocument latestRelesedDoc = (WTDocument) PhilipsRenameObjectUtils.getLatestReleasedVersionObject(doc);
					outOfSync = !doc.getDisplayIdentity().toString().equalsIgnoreCase(latestRelesedDoc.getDisplayIdentity().toString());
					LOG.debug("Product Document Identity - " + doc.getDisplayIdentity());
					LOG.debug("Library Template Identity - " + latestRelesedDoc.getDisplayIdentity());
					SessionServerHelper.manager.setAccessEnforced(enforced);
				}
			}
		} catch (Exception e) {
			LOG.error(e);
		} finally {
			SessionServerHelper.manager.setAccessEnforced(enforced);
		}
		return outOfSync;
	}

	/**
	 * get Save As History object. Latest history object will be at the end of QueryResult.
	 * SessionServerHelper.manager.setAccessEnforced(false) is used to get QueryResult for
	 * all the participants who are having view access to CDD document, so that out of sync
	 * icon will be available for them.
	 *
	 * @param object Object
	 * @return doc WTDocument
	 *
	 */
	public static WTDocument getSaveAsObject(Object object){
		boolean enforced = true;
		WTDocument doc = null;
		if(((WTDocument)object).getContainer() instanceof PDMLinkProduct){
			try{
				enforced = SessionServerHelper.manager.setAccessEnforced(false);
				QueryResult historyQueryResult = HistoryTablesCommands.saveAsHistory((Workable) object);
				if(null != historyQueryResult){
					while (historyQueryResult.hasMoreElements()) {
						doc = (WTDocument) ((SaveAsHistoryInfo) historyQueryResult.nextElement()).getRowObject();
					}
					SessionServerHelper.manager.setAccessEnforced(enforced);
				}
			} catch (Exception e){
				LOG.error(e);
			} finally {
				SessionServerHelper.manager.setAccessEnforced(enforced);
			}
		}
		return doc;
	}

}
