package ext.kb.util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.httpgw.GatewayAuthenticator;
import wt.inf.container.WTContainer;
import wt.inf.team.ContainerTeam;
import wt.inf.team.ContainerTeamHelper;
import wt.inf.team.ContainerTeamManaged;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.org.WTPrincipal;
import wt.org.WTPrincipalReference;
import wt.pds.StatementSpec;
import wt.project.Role;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;

public class RemoveUserGroupRoleUtil implements RemoteAccess {
	
	private static final String CLASSNAME = RemoveUserGroupRoleUtil.class.getName();
	private static Logger logger = Logger.getLogger(CLASSNAME);
	static ArrayList successobjects=new ArrayList<>();
	static ArrayList failedobjects=new ArrayList<>();

	private RemoveUserGroupRoleUtil(){
		
	}
	
	public static void main(String[] args) {
		
		Class<?>[] aClass = {String.class};
		Object[] aObj = {args[0]};
		RemoteMethodServer rms = RemoteMethodServer.getDefault();
		GatewayAuthenticator auth=new GatewayAuthenticator();
		auth.setRemoteUser(args[1]);
		rms.setAuthenticator(auth);
		try {
			rms.invoke("startUserGroupRmovalProcess", "ext.kb.util.RemoveUserGroupRoleUtil", null, aClass, aObj);
		} catch (RemoteException e) {
			logger.error("error", e);
			
		} catch (InvocationTargetException e) {
			logger.error("InvocationTargetException", e);
		}
	}
	
	/**
	 * 
	 * @param inputfile
	 */
	
	
	public static void startUserGroupRmovalProcess(String inputfile){
		List usergroupdetails=readinputFile(inputfile);
		for(int i=0;i<usergroupdetails.size();i++){
			UserGroupDetails object=(UserGroupDetails) usergroupdetails.get(i);
			String context=object.getContext();
			WTContainer obj=getContainer(context);
			if(obj!=null){
				getTeamMembers(obj, object.getUserrole(), object.getParticipant());
				}
			else{
					failedobjects.add("Context "+context+" not found");
				}
			}
			 if(!successobjects.isEmpty()){
            	 String successfile=inputfile.substring(0,inputfile.lastIndexOf("."))+"_Success.log";
            	 writeContentstofile(successfile, successobjects);
            	 successobjects.clear();
             }
            if(!failedobjects.isEmpty()){
            	String failurefile=inputfile.substring(0,inputfile.lastIndexOf("."))+"_Failure.log";
            	 writeContentstofile(failurefile, failedobjects);
            	 failedobjects.clear();
            }
		}
	
	
	/**
	 * 
	 * @param product
	 * @return
	 */
	
	
	public static void getTeamMembers(WTContainer product,String rolename,String user){
		
		ArrayList userid=new ArrayList();
		WTPrincipal principal=null;
		if(!("*").equals(user)){
		 principal=getPrincipal(user);
		}			
		try {
				ContainerTeam team = ContainerTeamHelper.service.getContainerTeam((ContainerTeamManaged) product);
				List participants = team.getAllPrincipalsForTarget(Role.toRole(rolename));
				ReferenceFactory reffactory = new ReferenceFactory();
			
				if(principal!=null){
				if (participants.contains(reffactory.getReference(principal))) {
					WTPrincipalReference principalReference=(WTPrincipalReference) reffactory.getReference(principal);
					WTPrincipal user1= (WTPrincipal) reffactory.getReference(principal).getObject();
					ContainerTeamHelper.service.removeMember(team, Role.toRole(rolename), user1);
					isuserremoved(team, rolename, principalReference, user1,product);
					}
				}
				else if(("*").equals(user)){
					List<WTPrincipal> participantlist=new ArrayList<>();
					for (Object object : participants) {
						WTPrincipalReference principalReference = (WTPrincipalReference) object;
						principal=(WTPrincipal) principalReference.getObject();
						ContainerTeamHelper.service.removeMember(team, Role.toRole(rolename), principal);
						isuserremoved(team,rolename,principalReference,principal,product);
					}
				}
				
			} catch (WTException e) {
				logger.error(e.getLocalizedMessage(), e);
				failedobjects.add(e.getLocalizedMessage());
			}
	}
	
	/**
	 * This method check whether user is removed form role or not
	 * @param team
	 * @param rolename
	 * @param principalReference
	 * @param principal
	 */
	
	private static void isuserremoved(ContainerTeam team,String rolename,WTPrincipalReference principalReference,WTPrincipal principal,WTContainer product) {
		
		List participants1;
		try {
			participants1 = team.getAllPrincipalsForTarget(Role.toRole(rolename));
			if(!participants1.contains(principalReference)){
				successobjects.add(principal.getName()+" removed from role "+rolename+" in context "+product.getName());
			}
		} catch (WTException e) {
			logger.error(e.getLocalizedMessage(), e);
		}
		
	}
	
	/**
	 * This method finds WTPrincipal
	 * @param username
	 * @return
	 */

	public static WTPrincipal getPrincipal(String username){
		QuerySpec qs;
		WTPrincipal principal = null;
		try {
			qs = new QuerySpec(WTPrincipal.class);
			qs.appendWhere(new SearchCondition(WTPrincipal.class,WTPrincipal.NAME,SearchCondition.EQUAL,username));
			QueryResult qr=PersistenceHelper.manager.find(qs);
			while(qr.hasMoreElements()){
				principal=(WTPrincipal) qr.nextElement();
			}
		} catch (WTException e) {
			logger.error(e.getLocalizedMessage(), e);
			failedobjects.add(e.getLocalizedMessage());
		}
		return principal;
		
	}
	
	/**
	 * This method is used to read the excel file and store the contents in List object
	 */
	
	public static List readinputFile(String inputfile){
		List<UserGroupDetails> details = new ArrayList();
		FileInputStream excelFile=getFileinputStream(inputfile);
		
		Workbook workbook=createWorkbookforFile(excelFile);
	
		Sheet datatypeSheet = workbook.getSheetAt(0);
		Iterator<Row> iterator = datatypeSheet.iterator();
		
		while (iterator.hasNext()) {
			
			UserGroupDetails od = new UserGroupDetails();
			Row currentRow = iterator.next();
		
			Iterator<Cell> cellIterator = currentRow.iterator();
			if(currentRow.getRowNum()>0){
				
				while(cellIterator.hasNext()) {
					Cell currentCell = cellIterator.next();
					od=setObjectDetails(currentCell,od);
				}
				details.add(od);
			}
		}
		try {
				excelFile.close();
				workbook.close();
			} catch (IOException e) {
				logger.error(e.getLocalizedMessage(), e);
			}finally {
				try {
					workbook.close();
					if (excelFile != null) {
						excelFile.close();
					}
				} catch (IOException e) {

					logger.error(e.getLocalizedMessage(),e);
					
				}
			}
		return details;
	}
	
	/**
	    * Creates new file inputstream object
	    * @param fileName
	    * @return
	    */
	   public static FileInputStream getFileinputStream(String fileName){
		    FileInputStream inStream=null;
			try {
				inStream = new FileInputStream(new File(fileName));
			} catch (FileNotFoundException e) {
				logger.error(e.getLocalizedMessage(), e);
			}
		   return inStream;
	  }
	   
	   /**
	    * This method creates new workbook for file
	    * @param excelfile
	    * @return
	    */
	   
	  public static XSSFWorkbook createWorkbookforFile(FileInputStream excelfile){
		  XSSFWorkbook workbook=null;
		  try {
			workbook = new XSSFWorkbook(excelfile);
		} catch (IOException e) {
			logger.error(e.getLocalizedMessage(), e);
		}
		  return workbook;
		
	  }
	  
	  
	  /**
	   * This method sets object attribute values
	   * @param moveobjectsonly
	   * @param currentCell
	   * @param od
	   * @return
	   */
	  
	  public static UserGroupDetails setObjectDetails(Cell currentCell,UserGroupDetails od){
				if (currentCell.getColumnIndex() == 0) {
					od.setContext(currentCell.getStringCellValue());
				}else if (currentCell.getColumnIndex() == 1) {
					od.setUserrole(currentCell.getStringCellValue());
				}else if (currentCell.getColumnIndex() == 2) {
					od.setParticipant(currentCell.getStringCellValue());
				}
			
		  return od;
	  }
	  
	  /**
		 * this method finds container
		 * @param names
		 * @return
		 */
		
		public static WTContainer getContainer(String name){
			QueryResult qr=new QueryResult();
			WTContainer obj=null;
			try {
				QuerySpec qs=new QuerySpec(WTContainer.class);
						 qs.appendWhere(new SearchCondition(WTContainer.class,WTContainer.NAME,SearchCondition.EQUAL,name));
						
				
				qr=PersistenceHelper.manager.find((StatementSpec)qs);	
				while(qr.hasMoreElements()){
					obj=(WTContainer) qr.nextElement();
					
				}
			} catch (WTException e) {
				logger.error(e.getLocalizedMessage(), e);
				failedobjects.add(e.getLocalizedMessage());
			}
			return obj;
		}
		
		
		/** This method write contents to file
		 * 
		 * @param filename
		 * @param list
		 */
		
		public static void writeContentstofile(String filename,ArrayList list){
			File logFile=new File(filename);
			FileWriter filewriter=getFileWriter(logFile);
			BufferedWriter writer = new BufferedWriter(filewriter);
			try {
					for(int i=0;i<list.size();i++){
						    writer.write(list.get(i).toString()+"\n");
					} 
						    
				}
			    catch (IOException e) {
					logger.error(e.getLocalizedMessage(),e);
				}finally{
					try {
						writer.close();
					} catch (IOException e) {
						logger.error(e.getLocalizedMessage(),e);
					}
				}
			}
		
		/** This method gets file writer steam
		 * 
		 * 
		 * @param file
		 * @return
		 */
		
		 public static FileWriter getFileWriter(File file){
			 FileWriter filewriter=null;
				try {
					filewriter=new FileWriter(file);
				} catch (IOException e) {
					logger.error(e.getLocalizedMessage(), e);
				}
			   return filewriter;
		   }
}
