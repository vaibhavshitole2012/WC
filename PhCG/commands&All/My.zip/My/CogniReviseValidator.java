package ext.kc.product.tools;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import com.ptc.core.ui.validation.DefaultUIComponentValidator;
import com.ptc.core.ui.validation.UIValidationCriteria;
import com.ptc.core.ui.validation.UIValidationKey;
import com.ptc.core.ui.validation.UIValidationResult;
import com.ptc.core.ui.validation.UIValidationResultSet;
import com.ptc.core.ui.validation.UIValidationStatus;
import com.ptc.netmarkets.model.NmOid;

import wt.fc.ObjectIdentifier;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.folder.Cabinet;
import wt.org.WTPrincipal;
import wt.part.WTPart;
import wt.session.SessionHelper;
import wt.util.WTException;

public class CogniReviseValidator extends DefaultUIComponentValidator {

	public UIValidationResultSet performFullPreValidation(UIValidationKey paramUIValidationKey, UIValidationCriteria paramUIValidationCriteria, Locale paramLocale)
			throws WTException {

		UIValidationResultSet resultSet = UIValidationResultSet.newInstance();

		WTPrincipal userObject = SessionHelper.getPrincipal();
		
		//System.out.println("userObject   : "+userObject);

		String tempUserName = SessionHelper.getPrincipal().getName();
		System.out.println("tempUserName : "+tempUserName);
		Persistable persistable=paramUIValidationCriteria.getContextObject().getObject();
		System.out.println("type:"+persistable.getType());
		System.out.println("paramUIValidationCriteria.getSelectedOidForPopup();:"+paramUIValidationCriteria.getSelectedOidForPopup());
		
		/*
		 * List<?> selectedObj = paramUIValidationCriteria.getSelectedOidForPopup();
		 * if(!selectedObj.isEmpty()) { for(int i = 0; i<selectedObj.size();i++) { NmOid
		 * nmoid = (NmOid) selectedObj.get(i); ObjectIdentifier obj =
		 * nmoid.getOidObject(); ObjectReference objref =
		 * ObjectReference.newObjectReference(obj); Persistable persistables =
		 * objref.getObject();
		 * 
		 * } }
		 */

		// You can also check user is part of any group 
		if("vaibhav".equalsIgnoreCase(tempUserName) && persistable instanceof WTPart) {

			UIValidationStatus localUIValidationStatus = UIValidationStatus.HIDDEN;
			UIValidationResult  result =UIValidationResult.newInstance(paramUIValidationKey, localUIValidationStatus);
			resultSet.addResult(result);

		}else if("vaibhav".equalsIgnoreCase(tempUserName) && persistable instanceof Cabinet) {
			List<?> selectedObj = paramUIValidationCriteria.getSelectedOidForPopup();
			if(!selectedObj.isEmpty()) {
				for(int i = 0; i<selectedObj.size();i++) {
					NmOid nmoid = (NmOid) selectedObj.get(i);
					ObjectIdentifier obj =  nmoid.getOidObject();
					ObjectReference objref =  ObjectReference.newObjectReference(obj);
					Persistable persistables =  objref.getObject();
					if("vaibhav".equalsIgnoreCase(tempUserName) && persistable instanceof WTPart) {

						UIValidationStatus localUIValidationStatus = UIValidationStatus.HIDDEN;
						UIValidationResult  result =UIValidationResult.newInstance(paramUIValidationKey, localUIValidationStatus);
						resultSet.addResult(result);

					}
					
				}
			}
		}
		
		else {
			UIValidationStatus localUIValidationStatus = UIValidationStatus.ENABLED;
			resultSet.addResult(UIValidationResult.newInstance(paramUIValidationKey, localUIValidationStatus));
		}
		return resultSet;

	}
}
