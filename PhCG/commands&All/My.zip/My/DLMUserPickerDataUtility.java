package com.philips.cplm.datautility;

import java.util.Map;

import com.philips.cplm.core.doc.helper.CDDDataUtilityHelper;
import com.philips.cplm.resource.qdmResource;
import com.ptc.core.components.descriptor.ComponentDescriptor;
import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.dataUtilities.DefaultPickerDataUtility;
import com.ptc.core.components.rendering.AbstractGuiComponent;
import com.ptc.core.components.rendering.PickerRenderConfigs;
import com.ptc.core.components.rendering.guicomponents.Label;
import com.ptc.core.components.rendering.guicomponents.PickerInputComponent;
import com.ptc.core.components.rendering.guicomponents.UrlDisplayComponent;
import com.ptc.core.meta.common.TypeInstanceIdentifier;
import com.ptc.core.meta.server.TypeIdentifierUtility;
import com.ptc.core.ui.resources.ComponentMode;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import com.ptc.netmarkets.util.beans.NmURLFactoryBean;
import com.ptc.netmarkets.util.misc.NetmarketURL;
import com.ptc.netmarkets.util.misc.NmAction;

import wt.org.WTUser;
import wt.util.WTException;
import wt.util.WTMessage;

/**
 * Data utility class to render UserPicker.
 *
 */
public class DLMUserPickerDataUtility extends DefaultPickerDataUtility {


    /** The picker type constant - used to set object type returned by picker. */
    private static final String PICKER_TYPE = "wt.org.WTUser";

    /** The display field in picker input. */
    private static final String DISPLAY_FIELD = "fullName";

    /** The constant to set readable picker input */
    private static final String IS_READONLY_PICKER = "false";

    /** Constant to set set autosuggest mode in picker. */
    private static final String IS_AUTOSUGGEST_PICKER = "true";

    /** The service key used to setup autosuggest mode. */
    private static final String SUGGEST_SERVICE_KEY = "userPicker";

    /** The user prefix used to load wt_user from identifier. */
    private static final String WT_USER_OID_PREFIX = "OR:wt.org.WTUser:";

    /** The minimal value of length splitted identifier. */
    private static final int MIN_LENGTH_PARAMS = 2;

    /** The maximum value of length splitted identifier. */
    private static final int MAX_LENGTH_PARAMS = 4;

    /** The constant to set container team only */
    private static final String IS_CONTAINER_TEAM_ONLY = "TRUE";

    /**
     * Method returns component for phiTrainerUsername attribute depending of component mode.
     *
     * @param componentId - the name of component
     * @param datum - object from info page or wizard
     * @param mc - model context
     * @return result - input component or url depends of component mode
     * @throws WTException the Windchill exception
     */
    @Override
    public Object getDataValue(String componentId, Object datum, ModelContext mc) throws WTException {
        Object result = null;
        ComponentMode mode = mc.getDescriptorMode();
        if (mode == ComponentMode.CREATE || mode == ComponentMode.EDIT) {
            result = getPickerInputComponent(componentId, datum, mc);
        } else if (mode == ComponentMode.VIEW) {
            WTUser user = null;
            if (mc.getRawValue() != null) {
                user = getUser(mc.getRawValue().toString());
            }
            if (user != null) {
                NmURLFactoryBean urlFactoryBean = new NmURLFactoryBean();
                result = new UrlDisplayComponent(user.getFullName(), user.getFullName(), NetmarketURL.buildURL(urlFactoryBean, NmAction.Type.OBJECT,
                        NmAction.Command.VIEW, NmOid.newNmOid(user.getPersistInfo().getObjectIdentifier()), null));
            } else {
                result = new Label("");
            }

        }
        boolean shouldBeNonEditable = CDDDataUtilityHelper.shouldBeNonEditable(datum, mc);
        if (shouldBeNonEditable) {
            result = getAdjustedComponent(result);
        }
        return result;
    }

    /**
     * Sets attributes immutable and removes and disables buttons for multi-valued fields.
     *
     * @param component the component which is AttributeInputCompositeComponent
     * @return the adjusted component
     */
    private Object getAdjustedComponent(Object component) {
        Object result = component;
        if (component instanceof AbstractGuiComponent) {
            AbstractGuiComponent com = (AbstractGuiComponent) component;
            com.setComponentHidden(true);
            result = com;
        }
        return result;
    }

    /**
     * Method returns picker component depending of component mode.
     *
     * @param componentId - the name of component
     * @param datum - object from info page or wizard
     * @param mc - model context
     * @return Picker Input Component - input component in create or edit mode
     * @throws WTException the Windchill exception
     */
    private Object getPickerInputComponent(String componentId, Object datum, ModelContext mc) throws WTException {
    	System.out.println("Inside getPickerInputComponent");
    	
        ComponentDescriptor descriptor = mc.getDescriptor();
        Map<Object, Object> pickerConfigs = descriptor.getProperties();
        PickerRenderConfigs.setDefaultPickerProperty(pickerConfigs, PickerRenderConfigs.PICKER_ID, componentId);
        PickerRenderConfigs.setDefaultPickerProperty(pickerConfigs, PickerRenderConfigs.PICKER_TITLE, WTMessage.getLocalizedMessage(qdmResource.class.getName(), qdmResource.DELIVERY_MANAGER_PICKER_TITLE));
        PickerRenderConfigs.setDefaultPickerProperty(pickerConfigs, PickerRenderConfigs.OBJECT_TYPE, PICKER_TYPE);
        PickerRenderConfigs.setDefaultPickerProperty(pickerConfigs, PickerRenderConfigs.PICKER_ATTRIBUTES, DISPLAY_FIELD);
        PickerRenderConfigs.setDefaultPickerProperty(pickerConfigs, PickerRenderConfigs.READ_ONLY_TEXTBOX, IS_READONLY_PICKER);
        PickerRenderConfigs.setDefaultPickerProperty(pickerConfigs, PickerRenderConfigs.SHOW_SUGGESTION, IS_AUTOSUGGEST_PICKER);
        PickerRenderConfigs.setDefaultPickerProperty(pickerConfigs, PickerRenderConfigs.SUGGEST_SERVICE_KEY, SUGGEST_SERVICE_KEY);
        PickerRenderConfigs.setDefaultPickerProperty(pickerConfigs, PickerRenderConfigs.WIDTH, "20");
        NmCommandBean cb = mc.getNmCommandBean();
        pickerConfigs.put(PickerRenderConfigs.CONTAINER_REF, cb.getContainerRef().toString());
        //pickerConfigs.put(PickerRenderConfigs.CONTAINER_TEAM_MEMBERS_ONLY, IS_CONTAINER_TEAM_ONLY);
        pickerConfigs.put(PickerRenderConfigs.SHOW_ROLES, "true");
        pickerConfigs.put(PickerRenderConfigs.BASE_WHERE_CLAUSE, "(roleName='Delivery Manager')");
        
        String userName = null;
        if (mc.getDescriptorMode() == ComponentMode.EDIT && mc.getRawValue() != null) {
            WTUser user = getUser(mc.getRawValue().toString());
            userName = user.getFullName();
            TypeInstanceIdentifier tid = TypeIdentifierUtility.getTypeInstanceIdentifier(user);
            pickerConfigs.put(PickerRenderConfigs.DEFAULT_HIDDEN_VALUE, tid.toExternalForm());
        }

        PickerInputComponent o = (PickerInputComponent) super.getDataValue(componentId, datum, mc);
        if (userName != null) {
            o.setValue(userName);
        }
        return o;
    }

	/**
     * Method returns user object from String value of identifier.
     *
     * @param identifier - the String value of WTUser object
     * @return WTUser - the user object
     * @throws WTException the Windchill exception
     */
    private WTUser getUser(String identifier) throws WTException {
        StringBuilder userStringBuilder = new StringBuilder(WT_USER_OID_PREFIX);
        System.out.println("identifier:"+identifier);
        String[] strArr = identifier.split("\\|");
        String strId = null;
        if (strArr.length > MIN_LENGTH_PARAMS && strArr.length <= MAX_LENGTH_PARAMS) {
            strId = strArr[2];
            if (strId == null) {
                strId = "";
            }
            userStringBuilder.append(strId);
            NmOid nmUserOid = NmOid.newNmOid(userStringBuilder.toString());
            return (WTUser) nmUserOid.getRefObject();
        }
        return null;
    }
}
