package com.philips.cplm.resource;

import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

/**
 * The Quality Document resources
 */
@RBUUID("com.philips.cplm.resource.qdmResource")
public class qdmResource extends WTListResourceBundle {

    /** The process owner user picker title */
    @RBEntry("Process Owner User Picker")
    public static final String PROCESS_OWNER_PICKER_TITLE = "picker.process.owner.title";

    /** The trainer name user picker title */
    @RBEntry("Trainer User Picker")
    public static final String TRAINER_NAME_PICKER_TITLE = "picker.trainer.name.title";

    /** The project sponsor user picker title */
    @RBEntry("Project Sponsor Picker")
    public static final String PROJECT_SPONSOR_PICKER_TITLE = "picker.project.sponsor.title";
    
    /** The Delivery Manager user picker title */
    @RBEntry("Delivery Manager User Picker")
    public static final String DELIVERY_MANAGER_PICKER_TITLE = "picker.delivery.manager.title";
}
