package ext.kb.tool;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;

import org.apache.log4j.Logger;

import com.ptc.core.lwc.server.PersistableAdapter;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.TypeIdentifierHelper;
import com.ptc.core.meta.common.impl.WCTypeIdentifier;

import ext.kb.util.KBConstants;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.httpgw.GatewayAuthenticator;
import wt.log4j.LogR;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.part.WTPart;
import wt.pds.StatementSpec;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.query.WhereExpression;
import wt.session.SessionHelper;
import wt.type.TypeDefinitionReference;
import wt.type.TypedUtilityServiceHelper;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.vc.config.ConfigSpec;
import wt.vc.config.LatestConfigSpec;
import wt.vc.wip.WorkInProgressHelper;
import com.ptc.core.meta.common.UpdateOperationIdentifier;

public class KBChangeParTypeTool2 implements RemoteAccess {

	private static final String CLASSNAME = KBChangeParTypeTool2.class.getName();
	private static final Logger LOG = LogR.getLogger(KBChangeParTypeTool2.class.getName());

	private static final String USER_INPUT_ARGUMENT_NAME = "u";

	private static final String INPUT_ORG_NAME = "i";

	public static final String KB_NORM_ID = "KB_NORM_ID";

	public static final String KB_SUPPL_TEXT = "KB_SUPPL_TEXT";

	public static final String KB_BASIC_SIZE = "KB_BASIC_SIZE";

	public static final String KB_TYPE_DESIGNATION = "KB_TYPE_DESIGNATION";

	public static void main(String[] args) {

		String userName = args[0];
		String orgName = args[1];
		String partNum = args[2];

		System.out.println("user : " + userName + " orgName : " + orgName + "partNum: " + partNum);

		if (userName == null || orgName == null || partNum == null) {
			printUsage();
			System.exit(0);
		}

		Class[] aClass = { String.class, String.class };
		Object[] aObj = { orgName, partNum };

		if (args.length < 3 || args.length > 3) {
			System.out.println("Wrong Number of Argument Parameters.");
		}

		RemoteMethodServer rms = RemoteMethodServer.getDefault();
		GatewayAuthenticator auth = new GatewayAuthenticator();

		auth.setRemoteUser(userName);

		rms.setAuthenticator(auth);

		try {
			rms.invoke("execute", KBChangeParTypeTool2.class.getName(), null, aClass, aObj);
			System.out.println("Utility Executed successfully");
		} catch (InvocationTargetException | IOException e) {
			LOG.error(e.getLocalizedMessage(), e);
			System.out.println("Unable to invoke " + e);
		}
	}

	public static void execute(String org, String num) throws WTException, RemoteException {

		QueryResult queryResult = getPartFromOrg(org, num);


		TypeIdentifier typeIdentifier = TypeIdentifierHelper.getTypeIdentifier("com.ptc.KBAssemblyComponent");
		TypeDefinitionReference tdr = TypedUtilityServiceHelper.service.getTypeDefinitionReference(typeIdentifier.getTypename());


		if (queryResult.hasMoreElements()) {
			WTPart part = (WTPart) queryResult.nextElement();

			String orgName = part.getOrganizationName();
			String type = "wt.part.WTPart|com.ptc.KBArticle|com.ptc.KBStdSemi|com.ptc.KBCommercial";
			WCTypeIdentifier wct = (WCTypeIdentifier) TypeIdentifierHelper.getType(part);
			String pttype = wct.getTypename().toString();
			LOG.debug("type: " + pttype);

			if((orgName.equals("KB")))
			{
				String partCategory = ext.kb.util.IBAHelper.readIBA(part, KBConstants.KB_PART_CATEGORY_IBA);
				LOG.debug(partCategory);

				if((pttype.equals(type)) && (partCategory.equals("9")))
				{
					if (!WorkInProgressHelper.isCheckedOut(part)) {
						changeTypeOfPart(part, tdr);
					}else {
						LOG.debug("Object is checked out");
						LOG.debug("version: " + part.getVersionIdentifier().getValue() + " iteration: "
								+ part.getIterationInfo().toString());
					}
				}
			}
		}

	}

	private static QueryResult getPartFromOrg(String org, String part) throws WTException {

		String partNum = part;
		QuerySpec querySpec;
		querySpec = new QuerySpec(WTPart.class);
		WhereExpression searchCondition = new SearchCondition(WTPart.class, WTPart.NUMBER, SearchCondition.EQUAL,
				partNum, false);
		querySpec.appendWhere(searchCondition, new int[] { 0 });
		ConfigSpec configSpec = new LatestConfigSpec();
		querySpec = configSpec.appendSearchCriteria(querySpec);

		QueryResult result = PersistenceHelper.manager.find((StatementSpec) querySpec);

		return result;
	}

	public static WTPart changeTypeOfPart(WTPart part, TypeDefinitionReference tdr) throws RemoteException {

		LOG.debug("entering changeTypeOfPart(WTPart,String)");
		LOG.debug("part: " + part);
		LOG.debug("newTypeName: \"" + tdr + "\"");

		try {
			WTPart workingCopy = (WTPart)WorkInProgressHelper.service.checkout(part, WorkInProgressHelper.service.getCheckoutFolder(),null).getWorkingCopy();
			
			workingCopy.setTypeDefinitionReference(tdr);
			PersistenceServerHelper.manager.update(workingCopy);
			workingCopy = (WTPart) PersistenceHelper.manager.refresh(workingCopy);
			
			PersistableAdapter obj = new PersistableAdapter(workingCopy,null,SessionHelper.getLocale(),new UpdateOperationIdentifier());
			obj.load(KB_NORM_ID,KB_BASIC_SIZE,KB_SUPPL_TEXT,KBConstants.KB_PART_CATEGORY_IBA,KB_TYPE_DESIGNATION); // change for supply text and type designaion attribue
			
			String kbNormId = (String) obj.get(KB_NORM_ID);
			String kbBasicSize = (String) obj.get(KB_BASIC_SIZE);
			String kbsupply = (String) obj.get(KB_SUPPL_TEXT);
			
			LOG.debug("kbsupply "+kbsupply);
			LOG.debug("kbNormId "+kbNormId);
			LOG.debug("kbBasicSize "+kbBasicSize);
			
			obj.set(KBConstants.KB_PART_CATEGORY_IBA, "9");
			 
			if (kbsupply == null)
			{
				if(kbNormId.length()>25)
				{
					obj.set(KB_SUPPL_TEXT, kbNormId.substring(0, 25));
					//obj.set(KB_NORM_ID, null);
				}
				else {
					obj.set(KB_SUPPL_TEXT, kbNormId);
					//obj.set(KB_NORM_ID, null);
				}
			}

			if(kbBasicSize!=null)
			{
				obj.set(KB_TYPE_DESIGNATION, kbBasicSize);
				obj.set(KB_BASIC_SIZE, null);
			}
			else {
				LOG.debug("Set to null");
				obj.set(KB_TYPE_DESIGNATION, null);
			}
			
			obj.persist();
			
			part = (WTPart)WorkInProgressHelper.service.checkin(workingCopy, "Auto check-in by Part Type Change Utility");
			
		} catch (WTException exc) {
			exc.printStackTrace();
		} catch (WTPropertyVetoException exc) {
			exc.printStackTrace();
		}

		System.out.println("exiting changeTypeOfPart()");
		System.out.println("returning: " + part);

		return part;
	}

	private static void printUsage() {
		System.out.println("Usage:");
		System.out.println("windchill " + CLASSNAME + " -" + USER_INPUT_ARGUMENT_NAME + " <username> " + "-"
				+ INPUT_ORG_NAME + " <orgname>");
		System.out.println("\tu - Windchill username");
		System.out.println("\ti - Org Name");
		System.out.println();
	}

}
