package ext.kb.util;

import java.beans.PropertyVetoException;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import wt.content.ApplicationData;
import wt.content.ContentHelper;
import wt.content.ContentHolder;
import wt.content.ContentItem;
import wt.content.ContentRoleType;
import wt.content.ContentServerHelper;
import wt.doc.WTDocument;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.httpgw.GatewayAuthenticator;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.pds.StatementSpec;
import wt.pom.Transaction;
import wt.query.QueryException;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;

public class KBUpdateDocumentContentTool implements RemoteAccess {
	private static final String CONTENT_IS_NOT_UPDATED = "Content is not updated for document ";
	private static final String CLASSNAME = KBUpdateDocumentContentTool.class.getName();
	private static Logger logger = Logger.getLogger(CLASSNAME);
	static ArrayList successobjects=new ArrayList<>();
	static ArrayList failedobjects=new ArrayList<>();
	
	public static void main(String[] args){
		String filename=args[0];
		String username = args[1];		
		@SuppressWarnings("rawtypes")
		List<DocumentContentDetails> objList=readFolderLocations(filename);
		Class[] aClass = {List.class,String.class};
		Object[] aObj = {objList,filename};

		RemoteMethodServer rms = RemoteMethodServer.getDefault();
		GatewayAuthenticator auth=new GatewayAuthenticator();
		auth.setRemoteUser(username);
		rms.setAuthenticator(auth);
		try {
			rms.invoke("startUpdateContentProcess", "ext.kb.util.KBUpdateDocumentContentTool", null, aClass, aObj);
		} catch (RemoteException e) {
			logger.error("error", e);
			
		} catch (InvocationTargetException e) {
			logger.error("InvocationTargetException", e);
		
		}
	}
	
	public static void startUpdateContentProcess(List objList,String filename){
		logger.debug("Inside startUpdateContentProcess ::>>"+objList.size());
		Transaction trx=null;
	
		String docno="";
		try {
			if(objList.size()>0){
				trx=new Transaction();
				trx.start();
			for(int i=0;i<objList.size();i++){
				
				
				DocumentContentDetails object=(DocumentContentDetails) objList.get(i);
				docno=object.getDocnumber();
			QuerySpec spec=new QuerySpec();
			int docindex=spec.appendClassList(WTDocument.class, true);
			SearchCondition sc=new SearchCondition(WTDocument.class,WTDocument.NUMBER,SearchCondition.EQUAL,object.getDocnumber());
			spec.appendWhere(sc,new int[docindex]);
			spec.appendAnd();
			SearchCondition sc1=new SearchCondition(WTDocument.class,"iterationInfo.identifier.iterationId",SearchCondition.EQUAL,object.getIteration());
			spec.appendWhere(sc1,new int[docindex]);
			spec.appendAnd();
			SearchCondition sc2=new SearchCondition(WTDocument.class,"versionInfo.identifier.versionId",SearchCondition.EQUAL,object.getRevision());
			spec.appendWhere(sc2,new int[docindex]);
			QueryResult qr=PersistenceHelper.manager.find((StatementSpec)spec);
			logger.debug("Queryresult size::>>"+qr.size());
			if(qr.size()>0){
			while(qr.hasMoreElements()){
				Persistable[] obj=(Persistable[]) qr.nextElement();
				WTDocument doc=(WTDocument) obj[0];
				
				File file=new File(object.getPrimarycontent());
				doc=(WTDocument) uploadContent(doc, file);
				PersistenceServerHelper.manager.update(doc);
				
				
				logger.debug("After updating content");
				
			}
			}
			else{
				failedobjects.add("Document "+docno+" with version "+object.getRevision()+"."+object.getIteration()+" not found");
			}
			}
			}
			trx.commit();
			trx=null;
			if(!successobjects.isEmpty()){
		       	 String successfile=filename.substring(0,filename.lastIndexOf("."))+"_Success.log";
		       	 writeContentstofile(successfile, successobjects);
		       	 successobjects.clear();
		        }
		       if(!failedobjects.isEmpty()){
		       	String failurefile=filename.substring(0,filename.lastIndexOf("."))+"_Failure.log";
		       	 writeContentstofile(failurefile, failedobjects);
		       	 failedobjects.clear();
		       }
			
		} catch (QueryException e) {
			logger.error(e.getLocalizedMessage(),e);
			failedobjects.add(CONTENT_IS_NOT_UPDATED+docno+" ::"+e.getLocalizedMessage());
			e.printStackTrace();
			
		} catch (WTException e) {
			logger.error(e.getLocalizedMessage(),e);
			failedobjects.add(CONTENT_IS_NOT_UPDATED+docno+" ::"+e.getLocalizedMessage());
			e.printStackTrace();
		} finally{
			 if (trx != null) {
	                trx.rollback();
	            }
		}
	
		
	}
	
	public static ContentHolder uploadContent( ContentHolder cHolder, File file) throws WTException {
     logger.debug("Inside uploadContent");
     	ObjectReference objectReference = (ObjectReference) new ReferenceFactory()
				.getReference(cHolder.getPersistInfo().getObjectIdentifier().getStringValue());
        
	ContentItem primary = ContentHelper.service.getPrimaryContent(objectReference);
	ApplicationData app = ApplicationData.newApplicationData(cHolder);
	try {
        	if(primary==null){
        		app.setRole(ContentRoleType.PRIMARY);
        	}
        	else{
        		app.setRole(ContentRoleType.SECONDARY);
        	}
            String filePath = file.getAbsolutePath();
            app.setUploadedFromPath(filePath);           
            app=ContentServerHelper.service.updateContent(cHolder, app, filePath);
            System.out.println("App data ::>>"+app);
            successobjects.add(app.getRole().toString()+" Content updated successfully for document "+((WTDocument)cHolder).getNumber());
           
        } catch (PropertyVetoException | IOException e) {
        	logger.error(e.getLocalizedMessage(),e);
        	failedobjects.add(CONTENT_IS_NOT_UPDATED+((WTDocument)cHolder).getNumber()+" "+e.getLocalizedMessage());
            
        } 
      
        return cHolder;
    }
	
	/**
	 * This method is used to read the excel file and store the contents in List object
	 */
	public static List<DocumentContentDetails> readFolderLocations(String fileName) {
		
		
		List<DocumentContentDetails> details = new ArrayList();
		FileInputStream excelFile=getFileinputStream(fileName);
		
		Workbook workbook=createWorkbookforFile(excelFile);
	
		Sheet datatypeSheet = workbook.getSheetAt(0);
		Iterator<Row> iterator = datatypeSheet.iterator();
		
		while (iterator.hasNext()) {
			
			DocumentContentDetails od = new DocumentContentDetails();
			Row currentRow = iterator.next();
		
			Iterator<Cell> cellIterator = currentRow.iterator();
			if(currentRow.getRowNum()>0){
				
				while(cellIterator.hasNext()) {
					Cell currentCell = cellIterator.next();
					od=setObjectDetails(currentCell,od);
				}
				details.add(od);
			}
		}
	
		
		try {
				excelFile.close();
				workbook.close();
			} catch (IOException e) {
				logger.error(e.getLocalizedMessage(), e);
			}finally {
				try {
					workbook.close();
					if (excelFile != null) {
						excelFile.close();
					}
				} catch (IOException e) {

					logger.error(e.getLocalizedMessage(),e);
					
				}
			}
		

		return details;
	}
	
	/**
	    * Creates new file inputstream object
	    * @param fileName
	    * @return
	    */
	   public static FileInputStream getFileinputStream(String fileName){
		    FileInputStream inStream=null;
			try {
				inStream = new FileInputStream(new File(fileName));
			} catch (FileNotFoundException e) {
				logger.error(e.getLocalizedMessage(), e);
			}
		   return inStream;
	  }
	   
	   /**
	    * This method creates new workbook for file
	    * @param excelfile
	    * @return
	    */
	   
	  public static XSSFWorkbook createWorkbookforFile(FileInputStream excelfile){
		  XSSFWorkbook workbook=null;
		  try {
			workbook = new XSSFWorkbook(excelfile);
		} catch (IOException e) {
			logger.error(e.getLocalizedMessage(), e);
		}
		  return workbook;
		
	  }
	  
	  /**
	   * This method sets object attribute values
	   * @param moveobjectsonly
	   * @param currentCell
	   * @param od
	   * @return
	   */
	  
	  public static DocumentContentDetails setObjectDetails(Cell currentCell,DocumentContentDetails od){		  
		  switch (currentCell.getCellType()) {

          case Cell.CELL_TYPE_STRING:
              System.out.println(currentCell.getRichStringCellValue().getString());
              if (currentCell.getColumnIndex() == 0) {
  				od.setDocnumber(currentCell.getStringCellValue());
  			} 
  			if (currentCell.getColumnIndex() == 1) {
  				od.setRevision(currentCell.getStringCellValue());
  			} 
  			if (currentCell.getColumnIndex() == 2) {
  				od.setIteration(currentCell.getStringCellValue());
  			} 
  			if (currentCell.getColumnIndex() == 3) {
  				od.setPrimarycontent(currentCell.getStringCellValue());
  			}
              break;

          case Cell.CELL_TYPE_NUMERIC:
              System.out.println(currentCell.getNumericCellValue());
              int val=(int) currentCell.getNumericCellValue();
              String strval=Integer.toString(val);
              if (currentCell.getColumnIndex() == 0) {
  				od.setDocnumber(strval);
  			} 
  			if (currentCell.getColumnIndex() == 1) {
  				od.setRevision(strval);
  			} 
  			if (currentCell.getColumnIndex() == 2) {
  				od.setIteration(strval);
  			} 
  			if (currentCell.getColumnIndex() == 3) {
  				od.setPrimarycontent(strval);
  			}
               break;
		  }

			
		  return od;
	  }
	  
	  /* 
		 * @param filename
		 * @param list
		 */
		
		public static void writeContentstofile(String filename,ArrayList list){
			File logFile=new File(filename);
			FileWriter filewriter=getFileWriter(logFile);
			BufferedWriter writer = new BufferedWriter(filewriter);
			try {
					for(int i=0;i<list.size();i++){
						    writer.write(list.get(i).toString()+"\n");
					} 
						    
				}
			    catch (IOException e) {
					logger.error(e.getLocalizedMessage(),e);
				}finally{
					try {
						writer.close();
					} catch (IOException e) {
						logger.error(e.getLocalizedMessage(),e);
					}
				}
			}
		
		/** This method gets file writer stream
		 * 
		 * 
		 * @param file
		 * @return
		 */
		
		 public static FileWriter getFileWriter(File file){
			 FileWriter filewriter=null;
				try {
					filewriter=new FileWriter(file);
				} catch (IOException e) {
					logger.error(e.getLocalizedMessage(), e);
				}
			   return filewriter;
		   }

}
