package ext.kb.util;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import ext.kb.tool.helper.MethodServerLogonHelper;
import ext.kb.tool.testuser.TestUserRemover;
import ext.kb.tool.testuser.assigner.MappingReader;
import ext.kb.tool.testuser.interpreter.ContextInterpreter;
import ext.kb.tool.testuser.interpreter.DataInterpreter;
import ext.kb.tool.testuser.interpreter.GroupInterpreter;
import ext.kb.tool.testuser.interpreter.UserInterpreter;
import ext.kb.util.UpdateUtil;
import wt.fc.Identified;
import wt.fc.IdentityHelper;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.inf.container.ContainerSpec;
import wt.httpgw.GatewayAuthenticator;
import wt.log4j.LogR;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.org.OrganizationServicesHelper;
import wt.org.WTGroup;
import wt.org.WTUser;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.part.WTPartMasterIdentity;
import wt.pds.StatementSpec;
import wt.pom.PersistenceException;
import wt.pom.Transaction;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.util.WTException;
 
/**
 * This is a Utility class, which first of all read the excel input file, which
 * contains the Group Name and Member names to be removed from group. After
 * finding the Group in the system it will check whether the user is a member of
 * that group or not, if user is member of group then it will will get removed
 * from the Group.
 * 
 * IMPORTANT : Use the below command to run the utility from WT_HOME. 
 * windchill ext.kb.tool.testuser.RemoveMemberFromGroup <wcadmin> <ExcelsheetName.xlsx>
 * 
 * @author ext-shitolev vaibhav.shitole@knorr-bremse.com
 * @version 1.0
 */
public class RemoveMemberFromGroupUtil implements RemoteAccess {

	private static final String CLASSNAME = RemoveMemberFromGroupUtil.class.getName();
	private static final Logger LOG = LogR.getLogger(RemoveMemberFromGroupUtil.class.getName());

	private static final String USER_INPUT_ARGUMENT_NAME = "u";

	private static final String INPUT_FILE_INPUT_ARGUMENT_NAME = "i";

	private static final String OUTPUT_FILE_OUTPUT_ARGUMENT_NAME = "d";

	/** The failed logs file name */
	private static String FAIL_FILE_NAME = "failedLog.log";

	/** The success logs file name */
	private static String SUCCESS_FILE_NAME = "successLog.log";

	private static PrintWriter failLog = null;
	private static PrintWriter successLog = null;

	static List<String> groupColumn;
	static List<String> memberColumn;

	static String group = null;
	static String member = null;


	public static void main(String[] args) throws RemoteException {

		String user = args[0];
		String inputFile = args[1];
		String logFilePath = args[2];
		System.out.println("user : " + user + " inputFile : " + inputFile+" LogFilePath: "+logFilePath);

		if (user == null || inputFile == null) {
			printUsage();
			System.exit(0);
		}

		Class[] aClass = { String.class, String.class };
		Object[] aObj = { inputFile, logFilePath};

		if(args.length < 3 || args.length > 3){
			System.out.println("Wrong Number of Argument Parameters.");
		}

		RemoteMethodServer rms = RemoteMethodServer.getDefault();
		GatewayAuthenticator auth = new GatewayAuthenticator();

		auth.setRemoteUser(user);

		rms.setAuthenticator(auth);

		try {

			rms.invoke("execute",RemoveMemberFromGroupUtil.class.getName(), null, aClass, aObj);
			System.out.println("Utility Executed successfully");
		} catch (InvocationTargetException |IOException e) {
			LOG.error(e.getLocalizedMessage(), e);
			System.out.println("Unable to invoke " + e);
		}
	}

	/**
	 * Remote Method will perform all the operations as specified in Class level
	 * comments.
	 * 
	 * @param fileName : Excel File Name from which utility will get to know members
	 *                	 to be deleted from which group.
	 * @param LogFilePath : path where to store the success and failure log files
	 */
	public static void execute(String fileName, String logFilePath) throws IOException, WTException {
		LOG.debug("Inside Execute method");

		LOG.debug("fileName: "+fileName+" and LogFilePath: "+logFilePath);

		File failureLogFile;
		File successLogFile;

		failureLogFile = getNewFile(logFilePath, FAIL_FILE_NAME);
		successLogFile = getNewFile(logFilePath, SUCCESS_FILE_NAME);

		failLog = getWriter(failureLogFile);
		successLog = getWriter(successLogFile);

		readFromFile(fileName);

		removeUserFromGroup(groupColumn, memberColumn);
	}

	/**
	 * 
	 * @param path : Excel File Path to read.
	 */
	public static void readFromFile(String path) throws IOException {
		LOG.debug("File reading is Started");

		int i = 0;

		groupColumn = new ArrayList();
		memberColumn = new ArrayList();

		// Read all columns and store it in list
		InputStream input = new BufferedInputStream(new FileInputStream(path));
		XSSFWorkbook wb = new XSSFWorkbook(input);
		XSSFSheet sheet = wb.getSheetAt(0);
		XSSFRow row;
		XSSFCell cell;
		Iterator rows = sheet.rowIterator();

		while (rows.hasNext()) {
			row = (XSSFRow) rows.next();
			if (row.getRowNum() > 0) {
				Iterator cells = row.cellIterator();
				while (cells.hasNext()) {

					cell = (XSSFCell) cells.next();
					cell.setCellType(Cell.CELL_TYPE_STRING);
					i = cell.getColumnIndex();
					if (i == 0) {
						group = cell.getStringCellValue();
						groupColumn.add(group);
					}
					if (i == 1) {
						member = cell.getStringCellValue();
						memberColumn.add(member);
					}
				}
			}
		}

		LOG.debug("Number of Groups in sheet: " + groupColumn.size() + ", Number of Members in sheet: "
				+ memberColumn.size()+"\n File reading Ended");		
	}
	/**
	 * This method will Remove the Users from Group
	 * 
	 * @param GroupColumn
	 * @param MemberColumn
	 * 
	 */
	private static void removeUserFromGroup(List<String> groupColumn, List<String> memberColumn) throws WTException {
		LOG.debug("Inside removeUserFromGroup");

		WTGroup wtGroup = null;
		String grpName = null;
		String memberName = null;
		WTUser user = null;
		Transaction trx = null;
		try {

			trx = startTransaction();

			for (int i = 0; i < groupColumn.size(); i++) 
			{
				grpName =  groupColumn.get(i);
				grpName = grpName.replace(" ", "");

				LOG.debug("GroupName: " + grpName);
				wtGroup = findGroupByName(grpName);

				if (wtGroup==null) 
				{
					writeToFile(failLog, grpName + " Group is Not Found in the system");
				} 
				else
				{
					boolean isUserPresent = false;

					if (groupHasMember(wtGroup)) 
					{
						memberName = memberColumn.get(i);
						memberName = memberName.replace(" ", "");

						LOG.debug("Checking user " + memberName + " is a member of Group " + grpName + " or not");

						Enumeration<WTUser> memberInGroup = ((WTGroup) wtGroup).members();
						while (memberInGroup.hasMoreElements()) 
						{
							user = memberInGroup.nextElement();

							if (memberName.equals("*")) 
							{
								LOG.debug(" Removing all users from Group " + grpName);
								removeMember(wtGroup, user);
								isUserPresent = true;
							} 
							else if (memberName.contains("*") && !memberName.equals("*")) 
							{
								String name = memberName.replace("*", "");
								if (user.getName().contains(name)) 
								{
									LOG.debug(grpName + " has a member which conatins " + name+ ", so removing it from group " + grpName);
									removeMember(wtGroup, user);
									isUserPresent = true;
								}
							} 
							else if (user.getName().equals(memberName)) 
							{
								LOG.debug(memberName + " is a member is of Group " + grpName);
								removeMember(wtGroup, user);
								isUserPresent = true;
							}
						}
						if (!isUserPresent) 
						{
							writeToFile(failLog, memberName + " User Not Found in Group " + wtGroup.getName());
							isUserPresent = false;
						}

					}
				}
			}
			if (trx != null) {
				trx.commit();
				trx = null;
			}
		} finally {
			if (failLog != null) {
				failLog.flush();
				failLog.close();
			}
			if (trx != null) {
				trx.rollback();
				LOG.info("ROOLING BACK TRANSACTION.....");
			}


		}
		LOG.debug("End of removeUserFromGroup");
	}

	/**
	 * This method is used to write to file
	 * 
	 * @param pw
	 * @param lineFromFile
	 */
	public static void writeToFile(PrintWriter pw, String lineFromFile) {
		if (pw != null)
			pw.println(lineFromFile);
		LOG.debug(lineFromFile);
	}

	/**
	 * check does members associated with Group.
	 * 
	 * @param groupName
	 * 
	 * @return
	 */
	private static boolean groupHasMember(WTGroup groupName) throws WTException {
		Enumeration<WTUser> members = ((WTGroup) groupName).members();
		if (members.hasMoreElements()) {
			return true;
		} else {
			LOG.debug(groupName.getName() + " is Empty ");
			writeToFile(failLog, groupName.getName() + " is Empty ");
			return false;
		}
	}

	/**
	 * This method is used remove user from group
	 * 
	 * @param groupName
	 * @param user
	 */
	private static void removeMember(WTGroup groupName, WTUser user) throws WTException {
		try {
			groupName.removeMember(user);
			writeToFile(successLog, user.getName() + " user removed successfully from Group " + groupName.getName());
			LOG.debug(user.getName() + " user removed successfully from Group " + groupName.getName());
		} finally {
			if (successLog != null) {
				successLog.flush();
			}
		}
	}

	/**
	 * Query to check Group is available in the system
	 * 
	 * @param grpName
	 * 
	 * @return groupResult
	 */
	private static WTGroup findGroupByName(String grpName) throws WTException {
		LOG.debug("Checking Group " + grpName + " is available in the system or not");
		QuerySpec groupSpec = new QuerySpec(WTGroup.class);
		groupSpec.appendWhere(new SearchCondition(WTGroup.class, WTGroup.NAME, SearchCondition.EQUAL, grpName), null);
		QueryResult groupResult = PersistenceHelper.manager.find((StatementSpec) groupSpec);
		LOG.debug("groupResult: "+groupResult);

		if(groupResult!=null && groupResult.hasMoreElements())
			return (WTGroup)groupResult.nextElement();

		return null;
	}

	/**
	 * This method starts the transaction
	 * 
	 * @return Transaction
	 * @throws PersistenceException
	 */
	private static Transaction startTransaction() throws PersistenceException {
		Transaction trx = null;
		try {
			trx = new Transaction();
			trx.start();
		} catch (PersistenceException e) {
			LOG.error("Transaction cannot be started");
			throw e;

		}
		return trx;
	}

	private static void printUsage() {
		System.out.println("Usage:");
		System.out.println("windchill " + CLASSNAME + " -" + USER_INPUT_ARGUMENT_NAME + " <username> " + "-"
				+ INPUT_FILE_INPUT_ARGUMENT_NAME + " <intputFile>" + "-" + OUTPUT_FILE_OUTPUT_ARGUMENT_NAME
				+ " <outputFile>");
		System.out.println("\tu - Windchill username");
		System.out.println("\ti - path to file with input data");
		System.out.println("\td - path to log directory");
		System.out.println();
	}

	/**
	 * Creates a mew File at specified location.
	 * 
	 * @param logDir
	 * @param fileName
	 * 
	 * @return file
	 */
	public static File getNewFile(String logDir, String fileName) {
		LOG.debug("Creating file " + fileName+"RemoveMemberFromGroup");
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		File file = null;
		if (fileName.contains(".")) {
			String[] filenames = fileName.split("\\.");
			String filename = filenames[0];
			String extension = filenames[1];
			file = new File(logDir + File.separator + "RemoveMemberFromGroup_"+filename + "_" + timestamp.toString() + "." + extension);
		}
		return file;
	}

	/**
	 * Returns PrintWriter
	 * 
	 * @param file
	 * 
	 * @return PrintWriter
	 */
	private static PrintWriter getWriter(File file) {
		if (file != null) {
			try {
				return new PrintWriter(file);
			} catch (FileNotFoundException e) {
				LOG.error("Error while creating log file. ", e);
			}
		}
		return null;
	}
}