/**
 *
 */
package ext.kb.document.variant;

import java.beans.PropertyVetoException;
import java.io.IOException;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

import ext.kb.identity.cadname.helper.CadNameHelper;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import wt.configurablelink.ConfigurableRevisionLink;
import wt.content.ContentHelper;
import wt.content.ContentRoleType;
import wt.content.DataFormatReference;
import wt.content.FormatContentHolder;
import wt.doc.WTDocument;
import wt.enterprise.EnterpriseHelper;
import wt.enterprise.RevisionControlled;
import wt.enterprise._RevisionControlled;
import wt.epm.EPMDocument;
import wt.epm.EPMDocumentMaster;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.fc.WTReference;
import wt.fc.collections.WTHashSet;
import wt.folder.FolderEntry;
import wt.folder.FolderHelper;
import wt.iba.value.DefaultAttributeContainer;
import wt.iba.value.IBAHolder;
import wt.iba.value.service.IBAValueDBService;
import wt.log4j.LogR;
import wt.org.WTPrincipal;
import wt.representation.Representation;
import wt.session.SessionHelper;
import wt.type.TypeDefinitionReference;
import wt.type.TypedUtility;
import wt.type.TypedUtilityServiceHelper;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.WTProperties;
import wt.util.WTPropertyVetoException;
import wt.vc.wip.WorkInProgressHelper;
import wt.vc.wip.Workable;

import com.ptc.core.components.forms.FormProcessingStatus;
import com.ptc.core.components.forms.FormResult;
import com.ptc.core.components.util.FeedbackMessage;
import com.ptc.core.lwc.common.view.EnumerationEntryReadView;
import com.ptc.core.lwc.server.PersistableAdapter;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.TypeIdentifierHelper;
import com.ptc.core.meta.server.TypeIdentifierUtility;
import com.ptc.core.ui.resources.FeedbackType;
import com.ptc.generic.iba.AttributeService;
import com.ptc.windchill.cadx.common.util.CADDocUtilities;
import com.ptc.wvs.common.ui.VisualizationHelper;

import ext.kb.identity.dto.IdentityDTO;
import ext.kb.identity.service.DocumentIdentityService;
import ext.kb.piint.service.PiInterfaceService;
import ext.kb.piint.util.PiInterfaceHelper;
import ext.kb.resources.AddNewDocumentVariantRB;
import ext.kb.util.DocumentVariantHelper;
import ext.kb.util.IBAHelper;
import ext.kb.util.KBConstants;
import ext.kb.util.KBDocumentUtils;
import ext.kb.util.KBType;
import ext.kb.util.KBTypeIdProvider;
import ext.kb.util.KBUtils;
import wt.services.ServiceFactory;

/**
 * @author bankowskie
 */
public class VariantGenerator {

    private static final Logger LOG = LogR.getLogger(VariantGenerator.class.getName());

    private VariantDTO dto;
    private Persistable currentDocument;
    private FormProcessingStatus status = FormProcessingStatus.SUCCESS;
    private FeedbackType feedbackType = FeedbackType.SUCCESS;
    private String feedbackMessage = StringUtils.EMPTY;
    private int generatedVariants = 0;
    private static final List<String> VARIANT_CREATE_ALLOWED_ROLES = Arrays.asList("DOCUMENT MANAGEMENT", "DATA MANAGEMENT");
    private final String NEUTRAL_DATA_TYPENAME = "WCTYPE|wt.doc.WTDocument|com.ptc.KBDocuments|com.ptc.KBTechnicalDrawing|com.ptc.KBNeutralData";
    private final String NEUTRAL_DATA_SALES_TYPENAME = "WCTYPE|wt.doc.WTDocument|com.ptc.KBDocuments|com.ptc.KBSalesDrawing|com.ptc.KBNeutralDataSales";
    private final String TECHNICAL_DRAWING_TYPENAME = "wt.doc.WTDocument|com.ptc.KBDocuments|com.ptc.KBTechnicalDrawing";
    private final String SYSTEM_DRAWING_TYPENAME = "wt.doc.WTDocument|com.ptc.KBDocuments|com.ptc.KBSalesDrawing";
    public static final String[] supportedTypesForLeadingLanguage = new String[]{"com.ptc.KBTechnicalDocument", "com.ptc.KBTechnicalDrawing",
            "com.ptc.KBCertificate", "com.ptc.KBStandard", "com.ptc.KBNeutralData", "com.ptc.KBSalesDrawing", "com.ptc.KBSalesDocument", "com.ptc.KBProjectInput"};

    private static final String NONE_DATA_FORMAT = "NONE";

    public VariantGenerator(VariantDTO dto) {
        this.dto = dto;
    }

    public FormResult generateVariants() throws WTException {
        FormResult formResult = new FormResult();
        try {
            WTPrincipal currentPrincipal = SessionHelper.manager.getPrincipal();
            SessionHelper.manager.setPrincipal(SessionHelper.manager.getAdministrator().getName());
            for (Persistable document : dto.getDocuments()) {
                LOG.debug("Processing " + document);
                currentDocument = document;
                boolean shouldProcessDocument = shouldProcessCurrentDocument();
                formResult = getFormResult();
                if (status.equals(FormProcessingStatus.FAILURE)) {
                    return formResult;
                }
                LOG.debug("shouldProcessDocument : " + shouldProcessDocument);
                if (shouldProcessDocument) {
                    processSourceDocument();
                }
            }
            SessionHelper.manager.setPrincipal(currentPrincipal.getName());
        } catch (WTException e) {
            LOG.error("Unable to generate variant for source document: " + currentDocument, e);
            // throwing exception to display it on the gui
            throw e;
        } catch (Exception e) {
            LOG.error("Unable to generate variant for source document: " + currentDocument, e);
        }
        return formResult;
    }

    private void processSourceDocument()
            throws WTException, RemoteException, ClassNotFoundException, PropertyVetoException {
        generatedVariants++;
        WTDocument wtdocument = null;
        EPMDocument epmdocument = null;
        Persistable generatedVariant = generateDocument();
        if (generatedVariant instanceof WTDocument) {
            wtdocument = (WTDocument) generatedVariant;
            LOG.debug("generatedVariant wtdocument number :: " + wtdocument.getNumber());
        } else {
            epmdocument = (EPMDocument) generatedVariant;
            LOG.debug("generatedVariant epmdocument number :: " + epmdocument.getNumber());
        }


        DocumentVariantHelper.dropAllLinks(generatedVariant);
        DocumentVariantHelper.createAndStoreNewVariantLink(currentDocument, generatedVariant);
        DocumentVariantHelper.handleCadimCidForVariant(currentDocument, generatedVariant);
        HashSet<String> langSet = new HashSet<>(dto.getLanguages());
        KBDocumentUtils.saveLangOnWTDocWithoutCheckout(generatedVariant, langSet);
        DocumentVariantHelper.addVariantECTLinkedWithSource(currentDocument, generatedVariant);
        LOG.debug("generatedVariant number :: " + ((WTDocument) generatedVariant).getNumber());
        ReferenceFactory referencefactory = new ReferenceFactory();
        WTReference wtreference = referencefactory.getReference(generatedVariant.toString());
        Persistable obj = wtreference.getObject();
        if (obj instanceof WTDocument) {
            wtdocument = (WTDocument) obj;
            LOG.debug("obj wtdocument number :: " + wtdocument.getNumber());
        } else {
            epmdocument = (EPMDocument) obj;
            LOG.debug("obj epmdocument number :: " + epmdocument.getNumber());
        }

        LOG.debug("getObjectByOid object :: " + obj);
        PiInterfaceService service = ServiceFactory.getService(PiInterfaceService.class);
        LOG.debug("generatedVariant number :: " + ((WTDocument) obj).getNumber());
        LOG.debug("generatedVariant number :: " + ((WTDocument) obj).getNumber());
        String soid = PersistenceHelper.getObjectIdentifier(obj).getStringValue();

        LOG.debug("Event fired for OID " + soid);
        boolean interfacesActivated = false;
        WTProperties properties = null;
        try {
            properties = WTProperties.getServerProperties();
        } catch (IOException e) {
            LOG.error("Error in reading property file");
        }
        interfacesActivated = Boolean.valueOf(properties.getProperty("ext.kb.piint.activateInterfaces", "false"));

        boolean isNeutralData = KBTypeIdProvider.isDescendant(currentDocument, "NEUTRALDATA");
        LOG.debug("interfacesActivated :: " + interfacesActivated + " " + isNeutralData);
        if (interfacesActivated && isNeutralData) {
            service.performActivity(obj, PiInterfaceHelper.CREATE_ACTIVITY_NAME);
        }
        LOG.debug("interfacesActivated done:: ");
    }



    private Persistable generateDocument() throws WTException, RemoteException, PropertyVetoException {
        Persistable generatedVariant = createCopyOfCurrentSourceDocument();
        LOG.debug("generatedVariant : " + generatedVariant);
        if (generatedVariant instanceof WTDocument) {
            handleNewVariantContent(generatedVariant);
        }
        handleVariantAttributes(generatedVariant);
        return generatedVariant;
    }

    private Persistable createCopyOfCurrentSourceDocument()
            throws WTException, RemoteException, WTPropertyVetoException {
        HashMap<String, String> newAttrMap = new HashMap<>();
        IdentityDTO identity = DocumentIdentityService.calculateNewIdentityForVariants(currentDocument);
        newAttrMap.put("newNumber", identity.getNumber());
        Persistable generatedVariant = currentDocument instanceof EPMDocument
                ? ext.kb.util.KBUtils.copyEpmDocumentWithoutSave((EPMDocument) currentDocument, identity.getNumber(),
                true)
                : ext.kb.util.KBUtils.copyDocument((WTDocument) currentDocument, newAttrMap,
                FolderHelper.getFolder((FolderEntry) currentDocument), false);
        generatedVariant = DocumentVariantHelper.reassignRevision(currentDocument, generatedVariant);
        IBAHelper.setIba((IBAHolder) ((RevisionControlled) generatedVariant).getMaster(), KBConstants.KBSAP_IDX_IBA,
                identity.getSapIndex());
        KBDocumentUtils.setCreatorAndModifier(generatedVariant, dto.getCreator());
        generatedVariant = generatedVariant instanceof EPMDocument
                ? CADDocUtilities.saveNewEPMDocument((EPMDocument) generatedVariant, (EPMDocument) currentDocument,
                false, null, null)
                : EnterpriseHelper.service.saveCopy((RevisionControlled) currentDocument,
                (RevisionControlled) generatedVariant);
        generatedVariant = PersistenceHelper.manager.refresh(generatedVariant);
        if (generatedVariant instanceof EPMDocument) {
            CadNameHelper.updateCadName((EPMDocumentMaster) ((EPMDocument) generatedVariant).getMaster());
        }
        DocumentIdentityService.storeNewIdentity(generatedVariant, identity);
        if (generatedVariant instanceof WTDocument) {
            generatedVariant = convertNeutralDatas((WTDocument) generatedVariant);
        }
        return generatedVariant;
    }

    private WTDocument convertNeutralDatas(WTDocument document) {
        try {
            String typeIdentifier = TypedUtilityServiceHelper.service.getTypeIdentifier(document).toString();
            TypeDefinitionReference newTypeReference;
            if (typeIdentifier.equals(NEUTRAL_DATA_TYPENAME)) {
                newTypeReference = TypedUtility.getTypeDefinitionReference(TECHNICAL_DRAWING_TYPENAME);
            } else if (typeIdentifier.equals(NEUTRAL_DATA_SALES_TYPENAME)) {
                newTypeReference = TypedUtility.getTypeDefinitionReference(SYSTEM_DRAWING_TYPENAME);
            } else {
                return document;
            }
            document.setTypeDefinitionReference(newTypeReference);
            PersistenceServerHelper.manager.update((Persistable) document);
        } catch (WTException | WTPropertyVetoException e) {
            LOG.error("An error has occured while trying to convert " + document);
        }
        return document;
    }

    private void handleNewVariantContent(Persistable generatedVariant) throws WTException, PropertyVetoException {
        QueryResult primaryContentQr = ContentHelper.service.getContentsByRole((FormatContentHolder) generatedVariant,
                ContentRoleType.PRIMARY, false);
        QueryResult secondaryContentQr = ContentHelper.service.getContentsByRole((FormatContentHolder) generatedVariant,
                ContentRoleType.SECONDARY, false);
        WTHashSet primaryContent = new WTHashSet(primaryContentQr);
        WTHashSet secondaryContent = new WTHashSet(secondaryContentQr);
        Representation representation = new VisualizationHelper().getRepresentation(generatedVariant);
        DataFormatReference noneDataFormat = ContentHelper.service.getDataFormatForExtension(NONE_DATA_FORMAT);
        ((FormatContentHolder) generatedVariant).setFormat(noneDataFormat);
        LOG.debug("About to remove all contents, representations and formats of " + generatedVariant);
        PersistenceHelper.manager.delete(primaryContent);
        PersistenceHelper.manager.delete(secondaryContent);
        if (representation != null)
            PersistenceHelper.manager.delete(representation);
        PersistenceHelper.manager.save(generatedVariant);
        PersistenceHelper.manager.refresh(generatedVariant);
    }

    private void handleVariantAttributes(Persistable generatedVariant)
            throws RemoteException, WTPropertyVetoException, WTException {
        if (generatedVariant instanceof WTDocument) {
            handleWTDocumentIBAValues((WTDocument) generatedVariant);
            LOG.debug("Calling handleLanguagesInRelatedVariants");
            // handleLanguagesInRelatedVariants(generatedVariant);
        }
        if (generatedVariant instanceof EPMDocument)
            handleEPMDocumentIBAValues((EPMDocument) generatedVariant);
        handleVariantLanguages(generatedVariant);
        PersistenceHelper.manager.save(generatedVariant);
    }

    private void handleWTDocumentIBAValues(WTDocument generatedVariant)
            throws WTException, RemoteException, WTPropertyVetoException {
        HashMap<String, String> mapLanguages = new HashMap();
        String localization = IBAHelper.getStringIBAValue(
                (IBAHolder) ((RevisionControlled) currentDocument).getMaster(), KBConstants.KBLOCALIZATION_IBA);
        Long sheetNo = (Long) IBAHelper.getIBAValue((IBAHolder) ((RevisionControlled) currentDocument).getMaster(),
                KBConstants.SHEET_NO_IBA);
        String customerDoc = (String) IBAHelper.getIBAValue((IBAHolder) ((RevisionControlled) currentDocument),
                KBConstants.KB_GIVEN_TO_CUSTOMER_IBA);
        LOG.debug("About to assign " + localization + " LOCALIZATION attribute to generated variant: "
                + generatedVariant);
        LOG.debug("About to assign " + sheetNo + " SHEET_NO attribute to generated variant: " + generatedVariant);
        LOG.debug("About to assign " + customerDoc + " KB_GIVEN_TO_CUSTOMER attribute to generated variant: "
                + generatedVariant);
        if (localization != null)
            IBAHelper.setIba((IBAHolder) generatedVariant.getMaster(), KBConstants.KBLOCALIZATION_IBA, localization);
        if (sheetNo != null)
            IBAHelper.setIba((IBAHolder) generatedVariant.getMaster(), KBConstants.SHEET_NO_IBA, sheetNo);
        if (customerDoc != null)
            IBAHelper.setIba((IBAHolder) generatedVariant, KBConstants.KB_GIVEN_TO_CUSTOMER_IBA, customerDoc);

        String docLangInWork = IBAHelper.readIBA(currentDocument, KBConstants.KBLANGINWORK_IBA);
        LOG.debug("Found " + docLangInWork + " lang in work attribute, processing.");
        if (docLangInWork == null)
            docLangInWork = "";
        List<String> docLangInWorkList = getDocumentLangInWorkList(docLangInWork);
        ArrayList<String> docLangInWorkListWithoutDuplicates = KBDocumentUtils.removeDuplicates(docLangInWorkList);
        // boolean isNeutralData = KBTypeIdProvider.isDescendant(currentDocument, "NEUTRALDATA");
        boolean isNeutralData = KBType.isOneOfTypes(currentDocument, supportedTypesForLeadingLanguage);
        //	LOG.debug("isNeutralData : "+isNeutralData+" "+docLangInWorkListWithoutDuplicates);
        if (isNeutralData) {
            docLangInWorkListWithoutDuplicates = removeValuesForReleasedDoc(docLangInWorkListWithoutDuplicates, (WTDocument) currentDocument);
        }
        docLangInWork = buildNewDocLangInWorkExpression(docLangInWorkListWithoutDuplicates);
        LOG.debug("Generated lang in work expression " + docLangInWork + " - assigning");
        if (!isNeutralData) {
            IBAHelper.setIba((IBAHolder) currentDocument, KBConstants.KBLANGINWORK_IBA, docLangInWork);
            IBAHelper.setIba((IBAHolder) generatedVariant, KBConstants.KBLANGINWORK_IBA, docLangInWork);
        }
        if (KBType.isOneOfTypes(currentDocument, supportedTypesForLeadingLanguage)) {
            String updatedInworkIBA = "";
            String updateAvaIBA = "";
            List<String> docLangAvaList = new ArrayList();
            String docavaLang = IBAHelper.readIBA(currentDocument, KBConstants.KB_ALL_LANGUAGES);
            List<String> docinworkList = new LinkedList<>(Arrays.asList((String[]) docLangInWork.split(" ")));
            LOG.debug("docinworkList : " + docinworkList);
            StringBuilder newInWorkStringBuilder = new StringBuilder();
            StringBuilder newAvailableStringBuilder = new StringBuilder();
            HashMap<String, WTDocument> variantMap = DocumentVariantHelper.getLinkedVariantsMap((WTDocument) currentDocument);

            if (docavaLang != null && !docavaLang.equals("")) {
                docLangAvaList = Arrays.asList(docavaLang.split(" "));
            }


            Map<String, WTDocument> variantTreeMap = new TreeMap<String, WTDocument>(variantMap);
            //variantTreeMap.putAll(variantMap);

            LOG.debug("variantTreeMap : " + variantTreeMap);
            LOG.debug("dto.getLanguages() : " + dto.getLanguages() + " dto.getLeadingLanguage() : " + dto.getLeadingLanguage());
            String variantDocLangExpression = KBDocumentUtils.buildLanguageExpression(IBAHelper.readIBA(currentDocument, KBConstants.KBLANGUAGE_IBA),
                    IBAHelper.readIBA(currentDocument, KBConstants.KB_LEADING_LANGUAGE));

            String currDocState = ((_RevisionControlled) currentDocument).getState().getState().toString();
            LOG.debug("currDocState : " + currDocState);
            if (!"1035".equals(currDocState) && !"1050".equals(currDocState) && !"1080".equals(currDocState)) {

                newInWorkStringBuilder.append(variantDocLangExpression);
                LOG.debug("newInWorkStringBuilder for currdoc : " + newInWorkStringBuilder);
                LOG.debug(docinworkList.contains(variantDocLangExpression));
                if (docinworkList.contains(variantDocLangExpression)) {
                    docinworkList.remove(variantDocLangExpression);
                }
                LOG.debug("docinworkList ; " + docinworkList);

            } else if ("1035".equals(currDocState) || "1050".equals(currDocState)) {
                newAvailableStringBuilder.append(variantDocLangExpression);
                LOG.debug("newAvailableStringBuilder for currdoc : " + newAvailableStringBuilder);
                LOG.debug(docinworkList.contains(variantDocLangExpression));
                if (docinworkList.contains(variantDocLangExpression)) {
                    docinworkList.remove(variantDocLangExpression);
                }
                LOG.debug("docinworkList ; " + docinworkList);
            } else if ("1080".equals(currDocState)) {
                LOG.debug("docLangAvaList.contains(docLangExpression) varuant : " + docLangAvaList.contains(variantDocLangExpression));
                if (docLangAvaList.contains(variantDocLangExpression)) {
                    newAvailableStringBuilder.append(" " + variantDocLangExpression);
                }
            }

            for (Entry<String, WTDocument> set : variantTreeMap.entrySet()) {
                LOG.debug("For loop : " + set.getKey() + " " + variantTreeMap.get(set.getKey()));

                WTDocument doc = (WTDocument) variantTreeMap.get(set.getKey());
                //LOG.debug("Document Number "+key+" "+doc);
                Object varLang = IBAHelper.readIBA(doc, KBConstants.KBLANGUAGE_IBA);
                Object varLeadLang =  AttributeService.getAttribute(doc, KBConstants.KB_LEADING_LANGUAGE);
                String docLangExpression ="";
                
                if(varLeadLang != null && !varLeadLang.equals("")) {
                	 docLangExpression = KBDocumentUtils.buildLanguageExpression(varLang, varLeadLang);
                }
                else {
                	  docLangExpression = KBDocumentUtils.buildLanguageExpression(varLang, "");
                }
                LOG.debug("docLangExpression : " + docLangExpression);
                String varDocState = doc.getState().getState().toString();
                LOG.debug("varDocState : " + varDocState);

                if (!"1035".equals(varDocState) && !"1050".equals(varDocState) && !"1080".equals(varDocState)) {

                    newInWorkStringBuilder.append(" " + docLangExpression);
                    LOG.debug("newInWorkStringBuilder for vardoc : " + newInWorkStringBuilder);
                    LOG.debug(docinworkList.contains(docLangExpression));
                    if (docinworkList.contains(docLangExpression)) {
                        docinworkList.remove(docLangExpression);
                    }
                    LOG.debug("docinworkList ; " + docinworkList);

                } else if ("1035".equals(varDocState) || "1050".equals(varDocState)) {
                    newAvailableStringBuilder.append(" " + docLangExpression);
                    LOG.debug("newInWorkStringBuilder for vardoc : " + newInWorkStringBuilder);
                    LOG.debug(docinworkList.contains(docLangExpression));
                    if (docinworkList.contains(docLangExpression)) {
                        docinworkList.remove(docLangExpression);
                    }
                    LOG.debug("docinworkList ; " + docinworkList);
                } else if ("1080".equals(varDocState)) {
                    LOG.debug("docLangAvaList.contains(docLangExpression) varuant : " + docLangAvaList.contains(docLangExpression));
                    if (docLangAvaList.contains(docLangExpression)) {
                        newAvailableStringBuilder.append(" " + docLangExpression);
                    }
                }
	
	
	/*Set<String> set = variantTreeMap.keySet();
	LOG.debug("111111");
	Iterator<?> itr = set.iterator();
	LOG.debug("222222222");	
	while(itr.hasNext()){
		LOG.debug("Contains : "+variantTreeMap.get(itr.next()));
		
		WTDocument doc = (WTDocument) variantTreeMap.get(itr.next());
		//LOG.debug("Document Number "+key+" "+doc);
		String varLang = IBAHelper.readIBA(doc, KBConstants.KBLANGINWORK_IBA);
		LOG.debug("varLang : "+varLang);
		String varDocState = doc.getState().getState().toString();
		LOG.debug("varDocState : "+varDocState);
		
		if(!"1035".equals(varDocState) && !"1050".equals(varDocState) && !"1080".equals(varDocState)){
			
			newInWorkStringBuilder.append(" "+varLang);
			LOG.debug("newInWorkStringBuilder for vardoc : "+newInWorkStringBuilder);
			LOG.debug(docinworkList.contains(variantDocLangExpression));
			if(docinworkList.contains(varLang)){
				docinworkList.remove(varLang);
			}
			LOG.debug("docinworkList ; "+docinworkList);
			
		}else if("1035".equals(currDocState) || "1050".equals(currDocState)){
			newAvailableStringBuilder.append(" "+varLang);
			LOG.debug("newInWorkStringBuilder for vardoc : "+newInWorkStringBuilder);
			LOG.debug(docinworkList.contains(variantDocLangExpression));
			if(docinworkList.contains(varLang)){
				docinworkList.remove(varLang);
			}
			LOG.debug("docinworkList ; "+docinworkList);
		}*/

            }
            String dtoLang = KBDocumentUtils.buildLanguageExpression(dto.getLanguages(), dto.getLeadingLanguage());

            LOG.debug("dtoLang ; " + dtoLang);
            newInWorkStringBuilder.append(" " + dtoLang);
            if (docinworkList.contains(dtoLang)) {
                docinworkList.remove(dtoLang);
            }
            LOG.debug("docinworkList ; " + docinworkList);


            for (String lang : docinworkList) {
                newInWorkStringBuilder.append(" " + lang);
            }
            LOG.debug("newInWorkStringBuilder : " + newInWorkStringBuilder);
            updatedInworkIBA = newInWorkStringBuilder.toString().trim();
            updateAvaIBA = newAvailableStringBuilder.toString().trim();

            LOG.debug("updatedInworkIBA : " + updatedInworkIBA + " updateAvaIBA : " + updateAvaIBA);
            currentDocument = setLanguageValue((WTDocument) currentDocument, updatedInworkIBA, updateAvaIBA);
            variantMap.clear();
            variantMap = DocumentVariantHelper.getLinkedVariantsMap((WTDocument) currentDocument);
            LOG.debug("variantMap size ; " + variantMap.size());
            Set varSet = variantMap.keySet();

            Iterator varItr = varSet.iterator();

            while (varItr.hasNext()) {

                //String key = (String) varItr.next();
                WTDocument varDoc = (WTDocument) variantMap.get(varItr.next());
                LOG.debug("varDoc : " + varDoc);
                if (!"1080".equals(varDoc.getState().getState().toString())) {
                    setLanguageValue((WTDocument) varDoc, updatedInworkIBA, updateAvaIBA);
                }
            }

            setLanguageValue((WTDocument) generatedVariant, updatedInworkIBA, updateAvaIBA);
			/*mapLanguages = updateLanguages((WTDocument) currentDocument,docLangInWork);
			String lang = mapLanguages.get("Available_Language");
			String inwork = mapLanguages.get("InWork_Language");

			currentDocument = setLanguageValue((WTDocument) currentDocument, inwork, lang);

		//	List<WTDocument> newVariants = DocumentVariantHelper.getVariants((WTDocument) currentDocument);
			List<WTDocument> newVariants = getVariants((WTDocument)currentDocument);
			LOG.debug("newVariants size : " + newVariants.size());
			for (WTDocument variant : newVariants) {
				LOG.debug("Variant Number : " + variant.getNumber());

				variant = setLanguageValue((WTDocument) variant, inwork, lang);
				PersistenceHelper.manager.refresh(variant);
			}
			PersistenceHelper.manager.refresh(currentDocument);

			generatedVariant = setLanguageValue((WTDocument) generatedVariant, inwork, lang);*/
        }

    }

    private List<WTDocument> getVariants(WTDocument currentDocument) throws WTException {
        ArrayList<WTDocument> documents = new ArrayList<>();
        String currVer = currentDocument.getVersionIdentifier().getValue();
        QueryResult allLinks = PersistenceHelper.manager.navigate(currentDocument, ConfigurableRevisionLink.ALL_ROLES,
                ConfigurableRevisionLink.class, true);
        LOG.debug("allLinks size : " + allLinks.size());

        while (allLinks.hasMoreElements()) {
            Object obj = allLinks.nextElement();
            if (obj instanceof WTDocument) {

                WTDocument varDoc = (WTDocument) obj;
                String varVer = varDoc.getVersionIdentifier().getValue();
                if (currVer.equals(varVer)) {
                    documents.add(varDoc);
                }
            }

        }
        return documents;
    }

    public static WTDocument setLanguageValue(WTDocument doc, String inWorkLang, String allLang) throws WTException {

        PersistableAdapter objvp = new PersistableAdapter(doc,
                TypeIdentifierUtility.getTypeIdentifier(doc).toExternalForm(), Locale.US, null);
        objvp.load(KBConstants.KBLANGINWORK_IBA, KBConstants.KB_ALL_LANGUAGES);
        objvp.set(KBConstants.KBLANGINWORK_IBA, inWorkLang);
        objvp.set(KBConstants.KB_ALL_LANGUAGES, allLang);
        objvp.apply();
        IBAValueDBService ibaserv = new IBAValueDBService();
        ibaserv.updateAttributeContainer(doc,
                ((DefaultAttributeContainer) doc.getAttributeContainer()).getConstraintParameter(), null, null);

        PersistenceServerHelper.manager.update((Persistable) doc);
        PersistenceHelper.manager.refresh(doc);
        return doc;
    }

    private HashMap updateLanguages(WTDocument neutralData, String docLangInWork) throws WTException {
        HashMap languages = new HashMap();
        String currentVer = neutralData.getVersionIdentifier().getValue();
        QueryResult navQr = new QueryResult();
        navQr = PersistenceHelper.manager.navigate(neutralData, ConfigurableRevisionLink.ALL_ROLES,
                ConfigurableRevisionLink.class, true);
        String neuDataState = neutralData.getState().getState().toString();
        LOG.debug("neuDataState : " + neuDataState);
        String availableLanguage = "";
        String inworkLanguage = "";
        if ("1050".equals(neuDataState) || "1035".equals(neuDataState)) {
            String value = "";

            Object objValue = KBDocumentUtils.getDocumentLanguage(neutralData, KBConstants.KBLANGUAGE_IBA);
            if (objValue != null) {

                if (objValue instanceof String) {
                    value = (String) objValue;
                } else {
                    List lValue = Arrays.asList((Object[]) objValue);
                    for (int i = 0; i < lValue.size(); i++) {
                        LOG.debug("lValue.get(i) 1050 : " + lValue.get(i));
                        value = value + "," + lValue.get(i);
                    }
                }

            }

            if (value != null && !"".equals(value)) {
                if (value.contains(",")) {
                    String[] arrayValue = value.split(",");
                    value = "";
                    for (int i = 0; i < arrayValue.length; i++) {

                        if ("".equals(value)) {
                            value = arrayValue[i];
                        } else {
                            value = value + "/" + arrayValue[i];
                        }
                    }

                }
            }
            availableLanguage = availableLanguage + " " + value;
            LOG.debug("Value of availableLanguage for parent : " + availableLanguage);

        } else if (!"1080".equals(neuDataState)) {
            String value = "";

            Object objValue = KBDocumentUtils.getDocumentLanguage(neutralData, KBConstants.KBLANGUAGE_IBA);
            if (objValue != null) {

                if (objValue instanceof String) {
                    value = (String) objValue;
                } else {
                    List lValue = Arrays.asList((Object[]) objValue);
                    for (int i = 0; i < lValue.size(); i++) {
                        LOG.debug("lValue.get(i) 1050 : " + lValue.get(i));
                        value = value + "," + lValue.get(i);
                    }
                }

            }

            if (value != null && !"".equals(value)) {
                if (value.contains(",")) {
                    String[] arrayValue = value.split(",");
                    value = "";
                    for (int i = 0; i < arrayValue.length; i++) {

                        if ("".equals(value)) {
                            value = arrayValue[i];
                        } else {
                            value = value + "/" + arrayValue[i];
                        }
                    }

                }
            }
            inworkLanguage = inworkLanguage + " " + value;
            LOG.debug("Value of inworkLanguage in Parent Inwork : " + inworkLanguage);

        }
        LOG.debug("availableLanguage : " + availableLanguage + " inworkLanguage : " + inworkLanguage);

        int x = 1;
        int j = 1;
        LOG.debug("Variants Size : " + navQr.size());
        HashMap varMap = new HashMap();
        while (navQr.hasMoreElements()) {

            WTDocument varDoc = (WTDocument) navQr.nextElement();

            String sapIndex = IBAHelper.readIBA(varDoc, "KB_SAP_IDX");

            varMap.put(sapIndex, varDoc);

        }

        TreeMap<String, WTDocument> sorted = new TreeMap<>();

        sorted.putAll(varMap);

        for (Map.Entry<String, WTDocument> entry : sorted.entrySet()) {

            String key = entry.getKey();
            WTDocument variantDoc = entry.getValue();

            LOG.debug(key + " => " + variantDoc.getNumber());

            String state = variantDoc.getState().getState().toString();
            String varVer = variantDoc.getVersionIdentifier().getValue();
            LOG.debug("Linked Document : " + variantDoc.getNumber() + " " + state);
            if (("1050".equals(state) || "1035".equals(state)) && currentVer.equals(varVer)) {

                String value = "";

                Object objValue = KBDocumentUtils.getDocumentLanguage(variantDoc, KBConstants.KBLANGUAGE_IBA);
                if (objValue != null) {

                    if (objValue instanceof String) {
                        value = (String) objValue;
                    } else {
                        List lValue = Arrays.asList((Object[]) objValue);
                        for (int i = 0; i < lValue.size(); i++) {
                            LOG.debug("lValue.get(i) 1050 : " + lValue.get(i));
                            value = value + "," + lValue.get(i);
                        }
                    }

                }
                LOG.debug("Value released of variants : " + value);

                if (value != null && !"".equals(value)) {
                    if (value.contains(",")) {
                        String[] arrayValue = value.split(",");
                        value = "";
                        for (int i = 0; i < arrayValue.length; i++) {

                            if ("".equals(value)) {
                                value = arrayValue[i];
                            } else {
                                value = value + "/" + arrayValue[i];
                            }
                        }

                    }
                }

                availableLanguage = availableLanguage + " " + value;
                LOG.debug("availableLanguage : " + availableLanguage);

            } else if ((!"1050".equals(state) && !"1080".equals(state) && !"1035".equals(state)) && (currentVer.equals(varVer))) {

                String value = "";

                Object objValue = KBDocumentUtils.getDocumentLanguage(variantDoc, KBConstants.KBLANGUAGE_IBA);
                if (objValue != null) {

                    if (objValue instanceof String) {
                        value = (String) objValue;
                    } else {
                        List lValue = Arrays.asList((Object[]) objValue);
                        for (int i = 0; i < lValue.size(); i++) {
                            LOG.debug("lValue.get(i) : " + lValue.get(i));
                            value = value + "," + lValue.get(i);
                        }
                    }

                }
                LOG.debug("Value inwork of variants : " + value);
                if (value != null && !"".equals(value)) {
                    if (value.contains(",")) {
                        String[] arrayValue = value.split(",");
                        value = "";
                        for (int i = 0; i < arrayValue.length; i++) {
                            if ("".equals(value)) {
                                value = arrayValue[i];
                            } else {
                                value = value + "/" + arrayValue[i];
                            }

                        }

                    }

                }

                inworkLanguage = inworkLanguage + " " + value;
                LOG.debug("inworkLanguage Value inwork of variants : " + inworkLanguage);

            }

        }

        String value = "";
        List dtoValue = dto.getLanguages();

        LOG.debug("dtoValue size : " + dtoValue);

        for (int i = 0; i < dtoValue.size(); i++) {
            value += dtoValue.get(i) + "/";
        }
        value = value.substring(0, value.length() - 1);

        if (inworkLanguage != null && !"".equals(inworkLanguage)) {
            inworkLanguage = inworkLanguage + " " + value;
        } else {

            inworkLanguage = value;
        }

        LOG.debug("Language : " + availableLanguage + "-----" + inworkLanguage);

        LOG.debug("Language after substring : " + availableLanguage + " " + inworkLanguage);
        languages.put("Available_Language", availableLanguage);
        languages.put("InWork_Language", inworkLanguage);
        return languages;

    }

	/*private String updateAvailableLanguages(WTDocument currentDocument) throws WTException {
		String sourceDocAllLangsIBA = "";	
		//String availLang = IBAHelper.readIBA(currentDocument, KBConstants.KB_ALL_LANGUAGES);
		LOG.debug("availLang : "+availLang);
		if (availLang == null)
			availLang = "";
		
	//	List documentAvailableLangList = new ArrayList();
	//	documentAvailableLangList = Arrays.asList(availLang.split(" "));
		//String[] stringList = availLang.split(" ");
		String state = currentDocument.getState().getState().toString();
		//LOG.debug("documentAvailableLangList "+documentAvailableLangList+" "+state);
		if("1050".equals(state)){
			Object sourceLanguage = AttributeService.getAttribute(currentDocument, KBConstants.KBLANGUAGE_IBA);
			LOG.debug("sourceLanguage : "+sourceLanguage);
			sourceDocAllLangsIBA +=" "+String.valueOf(sourceLanguage);
			String objValue = AttributeService.getAttribute(currentDocument, KBConstants.KBLANGUAGE_IBA);
			
			if(!documentAvailableLangList.contains(objValue)){
				availLang = availLang+" "+objValue;
				LOG.debug("availLang : "+availLang);
				documentAvailableLangList = Arrays.asList(availLang.split(" "));
			}
		}
		
		QueryResult navQr = new QueryResult();
		navQr =	PersistenceHelper.manager.navigate(currentDocument,
				ConfigurableRevisionLink.ALL_ROLES, ConfigurableRevisionLink.class, true);
		int i=1;
		while(navQr.hasMoreElements()){
		
			WTDocument variantDoc = (WTDocument)navQr.nextElement();
			LOG.debug("variantDoc Number "+variantDoc.getNumber());
			state = variantDoc.getState().getState().toString();
			
			if("1050".equals(state)){
				Object variantLanguage = AttributeService.getAttribute(variantDoc, KBConstants.KBLANGUAGE_IBA);
				LOG.debug("Variant : "+variantDoc.getNumber()+" "+i+" "+variantLanguage);
				//sourceDocAllLangsIBA +=" "+String.valueOf(variantLanguage);
				LOG.debug("sourceDocAllLangsIBA : "+sourceDocAllLangsIBA);
				if(i==1 && sourceDocAllLangsIBA!=null && !"".equals(sourceDocAllLangsIBA)){
					sourceDocAllLangsIBA = sourceDocAllLangsIBA+" "+String.valueOf(variantLanguage);
					i=0;
				}else{
					sourceDocAllLangsIBA = sourceDocAllLangsIBA+"/"+String.valueOf(variantLanguage);
				}
				String objValue = AttributeService.getAttribute(variantDoc, KBConstants.KBLANGUAGE_IBA);
				
				if(!documentAvailableLangList.contains(objValue)){
					availLang = availLang+" "+objValue;
					LOG.debug("availLang : "+availLang);
					documentAvailableLangList = Arrays.asList(availLang.split(" "));
				}
			}
		}
		LOG.debug("returning documentAvailableLangList : "+sourceDocAllLangsIBA);
		return sourceDocAllLangsIBA;
		
	}*/

    public static ArrayList<String> removeValuesForReleasedDoc(ArrayList<String> docLangInWorkListWithoutDuplicates,
                                                               WTDocument currentDocument) throws WTException {

        String state = currentDocument.getState().getState().toString();
        LOG.debug("state : " + state);
        if ("1050".equals(state) || "1035".equals(state)) {
            Object varLang = AttributeService.getAttribute(currentDocument, KBConstants.KBLANGUAGE_IBA);
            Object varLeadLang = AttributeService.getAttribute(currentDocument, KBConstants.KB_LEADING_LANGUAGE);
            //String value = String.valueOf(objValue);
            String docLangExpression = KBDocumentUtils.buildLanguageExpression(varLang, varLeadLang);
            LOG.debug("removeValuesForReleasedDoc Released : " + docLangExpression + " " + docLangInWorkListWithoutDuplicates.contains(docLangExpression));
            if (docLangInWorkListWithoutDuplicates.contains(docLangExpression)) {
                docLangInWorkListWithoutDuplicates.remove(docLangExpression);
            }

        }

        QueryResult navQr = new QueryResult();
        navQr = PersistenceHelper.manager.navigate(currentDocument,
                ConfigurableRevisionLink.ALL_ROLES, ConfigurableRevisionLink.class, true);

        while (navQr.hasMoreElements()) {

            WTDocument variantDoc = (WTDocument) navQr.nextElement();

            state = variantDoc.getState().getState().toString();

            if ("1050".equals(state) || "1035".equals(state)) {
                Object objValue = AttributeService.getAttribute(variantDoc, KBConstants.KBLANGUAGE_IBA);
                Object varLeadLang = AttributeService.getAttribute(variantDoc, KBConstants.KB_LEADING_LANGUAGE);
                //String value = String.valueOf(objValue);
                String docLangExpression = KBDocumentUtils.buildLanguageExpression(objValue, varLeadLang);
                if (docLangInWorkListWithoutDuplicates.contains(docLangExpression)) {
                    docLangInWorkListWithoutDuplicates.remove(docLangExpression);
                }

            }
        }
        return docLangInWorkListWithoutDuplicates;
    }

    private void handleEPMDocumentIBAValues(EPMDocument generatedVariant)
            throws WTException, RemoteException, WTPropertyVetoException {
        String localization = IBAHelper.getStringIBAValue(
                (IBAHolder) ((RevisionControlled) currentDocument).getMaster(), KBConstants.KBLOCALIZATION_IBA);
        LOG.debug("About to assign " + localization + " LOCALIZATION attribute to generated variant: "
                + generatedVariant);
        if (localization != null)
            IBAHelper.setIba((IBAHolder) generatedVariant.getMaster(), KBConstants.KBLOCALIZATION_IBA, localization);
    }

    private void handleVariantLanguages(Persistable variant)
            throws RemoteException, WTPropertyVetoException, WTException {
        IBAHelper.setIba((IBAHolder) variant, KBConstants.KB_LEADING_LANGUAGE, dto.getLeadingLanguage());
    }

    public List<String> getDocumentLangInWorkList(String documentLangInWork) {
        LOG.debug("About to process langs in work: " + documentLangInWork);
        List<String> docLangInWorkList;
        String variantDocLangExpression = KBDocumentUtils.buildLanguageExpression(dto.getLanguages(),
                dto.getLeadingLanguage());
        LOG.debug("Found doc lang expression " + variantDocLangExpression);
        boolean doesExistsLangExpSignedWithW = documentLangInWork.contains(variantDocLangExpression + "W");
        LOG.debug("Is lang expression signed with W? " + doesExistsLangExpSignedWithW);
        if (doesExistsLangExpSignedWithW) {
            docLangInWorkList = Arrays.asList(documentLangInWork.split(" "));
            documentLangInWork = DocumentVariantHelper.handleLangInWorkSignedWithW(variantDocLangExpression,
                    docLangInWorkList);
        } else {
            documentLangInWork += " " + variantDocLangExpression;
        }
        LOG.debug("Returning langs in work: " + documentLangInWork);
        docLangInWorkList = Arrays.asList(documentLangInWork.split(" "));
        return docLangInWorkList;
    }

    public static String buildNewDocLangInWorkExpression(List<String> langInWorkList) {
        StringBuilder langInWorkBuilder = new StringBuilder();
        for (String lang : langInWorkList) {
            langInWorkBuilder.append(" " + lang);
        }
        String langInWork = langInWorkBuilder.toString().trim();
        LOG.debug("Created lang in work expression: " + langInWork);
        return langInWork;
    }

    private void handleLanguagesInRelatedVariants(Persistable variant)
            throws RemoteException, WTPropertyVetoException, WTException {
        String docLangInWork = IBAHelper.readIBA(currentDocument, KBConstants.KBLANGINWORK_IBA);
        Object docAllLangs = IBAHelper.readIBA(currentDocument, KBConstants.KB_ALL_LANGUAGES);
        List<Persistable> allNmDocVariants = DocumentVariantHelper.getAllVariants(currentDocument);
        if (docAllLangs != null)
            IBAHelper.setIba((IBAHolder) variant, KBConstants.KB_ALL_LANGUAGES, docAllLangs);
        for (Persistable foundVariant : allNmDocVariants) {
            LOG.debug("About to append " + docLangInWork + " langs in work to " + foundVariant);
            IBAHelper.setIba((IBAHolder) foundVariant, KBConstants.KBLANGINWORK_IBA, docLangInWork);
            if (docAllLangs != null)
                IBAHelper.setIba((IBAHolder) foundVariant, KBConstants.KB_ALL_LANGUAGES, docAllLangs);
        }
    }

    private boolean shouldProcessCurrentDocument() throws WTException {
        status = FormProcessingStatus.SUCCESS;
        feedbackType = FeedbackType.SUCCESS;
        feedbackMessage = StringUtils.EMPTY;
        calculateFeedbackMessage();
        /*
         * if(StringUtils.isEmpty(feedbackMessage)) { status =
         * FormProcessingStatus.SUCCESS; feedbackType = FeedbackType.SUCCESS; }
         */
        return shouldProcessDocument();
    }

    private void calculateFeedbackMessage() throws WTException {
        LOG.debug("About to calculate feedback message. ");
        boolean isCopyOfSource = DocumentVariantHelper.isExactCopy(currentDocument, dto.getLanguages(),
                dto.getLeadingLanguage());
        boolean isCopyOfVariant = DocumentVariantHelper.isVariantAlreadyPresent(currentDocument, dto.getLanguages(),
                dto.getLeadingLanguage());
        boolean isSourceReleased = KBConstants.RELEASED
                .equals(((RevisionControlled) currentDocument).getState().toString());
        boolean isNeutralData = KBTypeIdProvider.isDescendant(currentDocument, "NEUTRALDATA");
        boolean isUserInAllowedRole = KBUtils.isUserInAllowedRole(currentDocument, VARIANT_CREATE_ALLOWED_ROLES);
        boolean flag = true;
        if (!DocumentVariantHelper.shouldProcess(currentDocument))
            feedbackMessage = AddNewDocumentVariantRB.CADIM_CID_EMPTY;
        else if (currentDocument instanceof WTDocument
                && !DocumentVariantHelper.hasValidNeutralDataConstraints((WTDocument) currentDocument))
            feedbackMessage = AddNewDocumentVariantRB.INVALID_NEUTRAL_DATA;
        else if (WorkInProgressHelper.isCheckedOut((Workable) currentDocument))
            feedbackMessage = AddNewDocumentVariantRB.CHECKED_OUT_DOCUMENT;
        else if (!dto.shouldForce() && isCopyOfSource && generatedVariants == 0)
            feedbackMessage = AddNewDocumentVariantRB.DUPLICATE_VALUE_MESSAGE;
        else if (!dto.shouldForce() && isCopyOfVariant && generatedVariants == 0)
            feedbackMessage = AddNewDocumentVariantRB.VARIANT_EXISTENT_MESSAGE;
        else if (isSourceReleased && !isUserInAllowedRole && !isNeutralData)
            feedbackMessage = AddNewDocumentVariantRB.FORBIDDEN_ROLE_MESSAGE;
        else if (dto.hasDuplicateLanguages())
            feedbackMessage = AddNewDocumentVariantRB.DUPLICATE_LANGUAGES_SELECTED;
        LOG.debug("Will return: " + feedbackMessage + " from RB.");
    }

    private boolean shouldProcessDocument() throws WTException {
        LOG.debug("About to calculate processing status.");
        boolean processingStatus = false;
        boolean isCopyOfSource = DocumentVariantHelper.isExactCopy(currentDocument, dto.getLanguages(),
                dto.getLeadingLanguage());
        boolean isCopyOfVariant = DocumentVariantHelper.isVariantAlreadyPresent(currentDocument, dto.getLanguages(),
                dto.getLeadingLanguage());
        boolean isSourceReleased = KBConstants.RELEASED
                .equals(((RevisionControlled) currentDocument).getState().toString());
        boolean isNeutralData = KBTypeIdProvider.isDescendant(currentDocument, "NEUTRALDATA");
        boolean isUserInAllowedRole = KBUtils.isUserInAllowedRole(currentDocument, VARIANT_CREATE_ALLOWED_ROLES);
        TypeIdentifier targetType = wt.type.TypedUtilityServiceHelper.service.getTypeIdentifier(currentDocument);
        boolean isNotCopy = (!isCopyOfSource && !isCopyOfVariant) || dto.shouldForce();
        boolean isInValidState = !(DocumentVariantHelper.isVariantDocument(currentDocument)
                || (isSourceReleased && !isUserInAllowedRole && !isNeutralData));
        boolean hasValidType = isDocumentAppropriateType(targetType);
        LOG.debug("Is not a copy? " + isNotCopy + ", is in valid state? " + isInValidState + ", has valid type? "
                + hasValidType);
        processingStatus = isNotCopy && isInValidState && hasValidType;
        return processingStatus && StringUtils.isEmpty(feedbackMessage);
    }

    private boolean isDocumentAppropriateType(TypeIdentifier targetType) {
        return targetType.isEquivalentTypeIdentifier(TypeIdentifierHelper.getTypeIdentifier("com.ptc.KBCertificate"))
                || targetType.isEquivalentTypeIdentifier(TypeIdentifierHelper.getTypeIdentifier("com.ptc.KBStandard"))
                || targetType.isEquivalentTypeIdentifier(
                TypeIdentifierHelper.getTypeIdentifier("com.ptc.KBTechnicalDocument"))
                || targetType.isEquivalentTypeIdentifier(
                TypeIdentifierHelper.getTypeIdentifier("com.ptc.KBTechnicalDrawing"))
                || targetType.isEquivalentTypeIdentifier(
                TypeIdentifierHelper.getTypeIdentifier(KBConstants.KBSALES_DOCUMENT))
                || targetType.isEquivalentTypeIdentifier(
                TypeIdentifierHelper.getTypeIdentifier(KBConstants.KBSALES_DRAWING))
                || targetType
                .isEquivalentTypeIdentifier(TypeIdentifierHelper.getTypeIdentifier("com.ptc.DesignCADDrw")) || targetType
                .isEquivalentTypeIdentifier(TypeIdentifierHelper.getTypeIdentifier(KBConstants.PROJECT_INPUT));
    }

    private FormResult getFormResult() {
        FormResult result = new FormResult();
        result.setStatus(status);
        if (status.equals(FormProcessingStatus.FAILURE))
            result.addFeedbackMessage(packFeedbackMessage());
        return result;
    }

    private FeedbackMessage packFeedbackMessage() {
        FeedbackMessage feedback = new FeedbackMessage();
        try {
            String message = WTMessage.getLocalizedMessage(AddNewDocumentVariantRB.class.getName(), feedbackMessage);
            feedback = new FeedbackMessage(feedbackType, SessionHelper.getLocale(), message, null);
        } catch (WTException e) {
            LOG.error("Unable to generate feedback message ", e);
        }
        return feedback;
    }

    public static ArrayList<String> removeValuesForInWorkDoc(ArrayList<String> docLangAvaListWithoutDuplicates,
                                                             WTDocument currentDocument) throws WTException {
        String state = currentDocument.getState().getState().toString();
        LOG.debug("state : " + state);
        if ("1010".equals(state) || "1015".equals(state) || "1020".equals(state)) {
            Object varLang = AttributeService.getAttribute(currentDocument, KBConstants.KBLANGUAGE_IBA);
            Object varLeadLang = AttributeService.getAttribute(currentDocument, KBConstants.KB_LEADING_LANGUAGE);
            //String value = String.valueOf(objValue);
            String docLangExpression = KBDocumentUtils.buildLanguageExpression(varLang, varLeadLang);
            LOG.debug("removeValuesForInworkDoc Released : " + docLangExpression + " " + docLangAvaListWithoutDuplicates.contains(docLangExpression));
            if (docLangAvaListWithoutDuplicates.contains(docLangExpression)) {
                docLangAvaListWithoutDuplicates.remove(docLangExpression);
            }

        }

        QueryResult navQr = new QueryResult();
        navQr = PersistenceHelper.manager.navigate(currentDocument,
                ConfigurableRevisionLink.ALL_ROLES, ConfigurableRevisionLink.class, true);

        while (navQr.hasMoreElements()) {

            WTDocument variantDoc = (WTDocument) navQr.nextElement();

            state = variantDoc.getState().getState().toString();

            if ("1010".equals(state) || "1015".equals(state) || "1020".equals(state)) {
                Object objValue = AttributeService.getAttribute(variantDoc, KBConstants.KBLANGUAGE_IBA);
                Object varLeadLang = AttributeService.getAttribute(variantDoc, KBConstants.KB_LEADING_LANGUAGE);
                //String value = String.valueOf(objValue);
                String docLangExpression = KBDocumentUtils.buildLanguageExpression(objValue, varLeadLang);
                if (docLangAvaListWithoutDuplicates.contains(docLangExpression)) {
                    docLangAvaListWithoutDuplicates.remove(docLangExpression);
                }

            }
        }
        return docLangAvaListWithoutDuplicates;
    }
}
