package com.philips.cplm.core.doc.helper;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.philips.cplm.utilities.IBAUtils;

import wt.doc.WTDocument;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.org.WTPrincipal;
import wt.org.WTPrincipalReference;
import wt.project.Role;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.session.SessionHelper;
import wt.team.TeamTemplate;
import wt.util.WTException;
import wt.vc.Versioned;

/**
 * 
 * @author 932784
 *
 */
public class PhilipsBPQDocHelper {

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static Map<String, List> validateUserinTemplate(Object object, List<String> invalidFiles) throws WTException {
		WTDocument doc = (WTDocument) object;
		System.out.println("Inside validateUserinTemplate "+doc.getNumber());
		//List<String> invalidFiles = new ArrayList<>();
		Map<String, List> resultMaps = new HashMap<String, List>();
		List<WTPrincipalReference> paricipantList =  new ArrayList<>();
		WTPrincipal user=  SessionHelper.manager.getPrincipal();
		WTPrincipalReference wtRef = WTPrincipalReference.newWTPrincipalReference(user);
		System.out.println("user.getName():"+user.getName());
		Role role = null;
		
		String qualifyingQMS = IBAUtils.getIBAValueToString(doc, "phiQualifyingQMS");
		System.out.println("qualifyingQMS:"+qualifyingQMS);
		QueryResult qr = getTeamTemplate(qualifyingQMS);
		
		if(qr.size()!=0){
			while (qr.hasMoreElements()) {
				TeamTemplate teamTemplate = (TeamTemplate) qr.nextElement();
				String name = teamTemplate.getName();
				System.out.println("name: "+name);
				List rolesList = teamTemplate.getRoles(); 
				for (Object obj : rolesList) {
					role = (Role) obj;
					String roleName = role.getDisplay();
					System.out.println("role: "+roleName);
					if(roleName.equals("Business Partner Qualification Manager")){
						System.out.println("Inside Role check if");
						paricipantList = Collections.list(teamTemplate.getPrincipalTarget(role));
						if(paricipantList.size()!=0){
							System.out.println("paricipantList.contains(wtRef):"+paricipantList.contains(wtRef));
							if(!paricipantList.contains(wtRef)){
								System.out.println("Adding doc to list");
								invalidFiles.add(doc.getNumber());
								System.out.println("invalidFiles size: "+invalidFiles.size());
							}
						}
						/*else{
							System.out.println("Adding doc to list in else block");
							invalidFiles.add(doc.getNumber());
						}*/
					}
					resultMaps.put("Participant", invalidFiles);
					return resultMaps;
				}
			}
		}
		else{
			invalidFiles.add(doc.getNumber());
			//throw new WTException("The QMS team template does not exists for QMS of ,"+invalidFiles+" Contact the Business Organization Administrator (BOA) to create a QMS team template(s)");
		}
		resultMaps.put("Template", invalidFiles);
		return resultMaps;
	}
	
	@SuppressWarnings({ "unchecked" })
	public static Map<String, String> validateUserinTemplateUsingAttribute(String qualifyingQMS, WTPrincipalReference wtRefs) throws Exception {
		System.out.println("Inside validateUserinTemplateUsingAttribute "+qualifyingQMS);
		List<WTPrincipalReference> paricipantList =  new ArrayList<>();
		  
		//int flag = 0;
		Map<String, String> resultMap = new HashMap<String, String>();
		//String teamTamplateName = null;
		Role roles = null;
		System.out.println("qualifyingQMS:"+qualifyingQMS);
		QueryResult query = getTeamTemplate(qualifyingQMS);
		
		if(query.size()!=0){
			while (query.hasMoreElements()) {
				TeamTemplate teamTemplate = (TeamTemplate) query.nextElement();
				String teamTamplateName = teamTemplate.getName();
				System.out.println("name: "+teamTamplateName);
				List<?> rolesList = teamTemplate.getRoles(); 
				for (Object obj : rolesList) {
					roles = (Role) obj;
					String roleName = roles.getDisplay();
					System.out.println("role: "+roleName);
					if(roleName.equals("Business Partner Qualification Manager")){
						System.out.println("Inside Role check if");
						paricipantList = Collections.list(teamTemplate.getPrincipalTarget(roles));
						if(paricipantList.size()!=0){
							System.out.println("paricipantList.contains(wtRef):"+paricipantList.contains(wtRefs));
							if(!paricipantList.contains(wtRefs)){
								resultMap.put("Participant", teamTamplateName);
								System.out.println("Adding doc to list");
							}
						}
						/*else{
							flag = false;
							System.out.println("No Participants added in Role");
						}*/
					} 
				}
			}
		}
		else{
			resultMap.put("Template", qualifyingQMS);
			System.out.println("Template not found");
		}
		return resultMap;
	}
	
	private static QueryResult getTeamTemplate(String qualifyingQms) throws WTException {
		String qmsTrim = qualifyingQms.substring(qualifyingQms.indexOf('-')+1, qualifyingQms.length());
		String teamTamplate = "QMS-DEMO_QMS_"+qmsTrim;
		QuerySpec qs = new QuerySpec(TeamTemplate.class);
		qs.appendWhere(new SearchCondition(TeamTemplate.class, TeamTemplate.NAME, SearchCondition.EQUAL, teamTamplate),
				new int[] { 0 });
		QueryResult queryResult = PersistenceHelper.manager.find(qs);

		return queryResult;

	}

	
}