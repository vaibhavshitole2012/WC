package com.philips.cplm.resource;

import wt.util.resource.RBComment;
import wt.util.resource.RBEntry;
import wt.util.resource.RBUUID;
import wt.util.resource.WTListResourceBundle;

/**
 * The Class csmResource.
 */
@RBUUID("com.philips.cplm.resource.csmResource")
public class csmResource extends WTListResourceBundle {

    /** The Constant OLD_IDENTITY. 0 - type, 1 - number, 2 - name, 3 - org, 4 - version, 5 - view */
    @RBEntry("Old Identity: {0} - {1}, {2}, {3} {4} ({5})")
    public static final String OLD_IDENTITY = "OLD_IDENTITY";

    /** The Constant FREE_TEXT. */
    @RBEntry("{0}")
    public static final String FREE_TEXT = "FREE_TEXT";

    /** The Constant SUPPLIED_USERS_TAB_DESCRIPTION. */
    @RBEntry("Supplied Users")
    public static final String SUPPLIED_USERS_TAB_DESCRIPTION = "object.spSuppliedUsersTab.description";

    /** The Constant SUPPLIER_CONTACTS_TABLE_DESCRIPTION. */
    @RBEntry("Supplier Contacts")
    public static final String SUPPLIER_CONTACTS_TABLE_DESCRIPTION = "servicePartnerSuppliedUsersTab.philipsSPSuppliedUsers.description";

    /** The Constant CREATE_AND_ADD_DOC_ACTION_DESCRIPTION. */
    @RBEntry("Create Document")
    public static final String CREATE_AND_ADD_DOC_ACTION_DESCRIPTION = "philipsSupplier.phiCreateAndAddSupplierDoc.description";

    /** The Constant CREATE_AND_ADD_DOC_ACTION_TITLE. */
    @RBEntry("Create Document")
    public static final String CREATE_AND_ADD_DOC_ACTION_TITLE = "philipsSupplier.phiCreateAndAddSupplierDoc.title";

    /** The Constant CREATE_AND_ADD_DOC_ACTION_TOOLTIP. */
    @RBEntry("Create Document")
    public static final String CREATE_AND_ADD_DOC_ACTION_TOOLTIP = "philipsSupplier.phiCreateAndAddSupplierDoc.tooltip";

    /** The Constant CREATE_AND_ADD_DOC_ACTION_ICON. */
    @RBEntry("newdoc.gif")
    public static final String CREATE_AND_ADD_DOC_ACTION_ICON = "philipsSupplier.phiCreateAndAddSupplierDoc.icon";

    /** The Constant SUPPLIER_DOCUMENT_TABLE_DESCRIPTION. */
    @RBEntry("Supplier Documents")
    public static final String SUPPLIER_DOCUMENT_TABLE_DESCRIPTION = "philipsSupplier.csm.philips.supplied.documents.description";

    /* RBEntry for Business Partner Qualification QML List Preference */

    /** The Constant CSM_PHILIPS_PREFERENCE_ALL_QMS_GROUP_DISPLAYNAME. */
    @RBEntry("CL ALL")
    public static final String CSM_PHILIPS_PREFERENCE_ALL_QMS_GROUP_DISPLAYNAME = "CSM_PHILIPS_PREFERENCE_ALL_QMS_GROUP_DISPLAYNAME.displayName";

    /** The Constant CSM_PHILIPS_PREFERENCE_ALL_QMS_GROUP_DESCRIPTION. */
    @RBEntry("The CL ALL group. This group of QMS�s includes all of the available QMS�s at Philips.")
    public static final String CSM_PHILIPS_PREFERENCE_ALL_QMS_GROUP_DESCRIPTION = "CSM_PHILIPS_PREFERENCE_ALL_QMS_GROUP_DESCRIPTION.description";

    /** The Constant CSM_PHILIPS_PREFERENCE_PH_PC_DISPLAYNAME. */
    @RBEntry("PH")
    public static final String CSM_PHILIPS_PREFERENCE_PH_PC_DISPLAYNAME = "CSM_PHILIPS_PREFERENCE_PH_PC_DISPLAYNAME.displayName";

    /** The Constant CSM_PHILIPS_PREFERENCE_PH_PC_DESCRIPTION. */
    @RBEntry("The PH group. This group of QMS�s includes the QMS's for the PH QMS umbrella.")
    public static final String CSM_PHILIPS_PREFERENCE_PH_PC_DESCRIPTION = "CSM_PHILIPS_PREFERENCE_PH_PC_DESCRIPTION.description";

    /** The Constant CSM_BPR_COMMODITYMANAGER_IBA. */
    /*
     * this is the internal name of the attribute used in the Business Partner Request workflow to map groups to a role the reason for storing this in this
     * resource file is that in case the IBA ever changes the running workflows instances will not fail because of a hard-coded value.
     */
    @RBEntry("phiCommodityOwner")
    public static final String CSM_BPR_COMMODITYMANAGER_IBA = "CSM_BPR_COMMODITYMANAGER_IBA";

    /** The Constant CSM_BPR_COMMODITYOWNER_ROLE. */
    @RBEntry("COMMODITY_REVIEWER")
    public static final String CSM_BPR_COMMODITYOWNER_ROLE = "CSM_BPR_COMMODITYOWNER_ROLE";

    /** The Constant CSM_BPR_BPADMIN_ROLE. */
    @RBEntry("BUSINESS_PARTNER_ADMINISTRATOR")
    public static final String CSM_BPR_BPADMIN_ROLE = "CSM_BPR_BPADMIN_ROLE";

    /** The Constant CSM_BPR_BPREQUESTER_ROLE. */
    @RBEntry("BUSINESS_PARTNER_REQUESTER")
    public static final String CSM_BPR_BPREQUESTER_ROLE = "CSM_BPR_BPREQUESTER_ROLE";

    /** The Constant CSM_BPQ_BPQENGINEER_IBA. */
    @RBEntry("phiQualifyingQMS")
    public static final String CSM_BPQ_BPQENGINEER_IBA = "CSM_BPQ_BPQENGINEER_IBA";

    /** The Constant CSM_BPQ_WF_IBA. */
    @RBEntry("phiInScopeQMS")
    public static final String CSM_BPQ_WF_IBA = "CSM_BPQ_WF_IBA";

    /** The Constant CSM_BPQ_BPQENGINEER_ROLE. */
    @RBEntry("Business_Partner_Qualification_Engineer")
    public static final String CSM_BPQ_BPQENGINEER_ROLE = "CSM_BPQ_BPQENGINEER_ROLE";

    /** The Constant CSM_BPQ_BPQENGINEER_ROLE_INTERNAL_NAME. */
    @RBEntry("BUSINESS_PARTNER_QUALIFICATION_ENGINEER")
    public static final String CSM_BPQ_BPQENGINEER_ROLE_INTERNAL_NAME = "CSM_BPQ_BPQENGINEER_ROLE_INTERNAL_NAME";

    /** The Constant CSM_BPQ_QUALIFICATION_STATE_IBA. */
    @RBEntry("phiQualificationState")
    public static final String CSM_BPQ_QUALIFICATION_STATE_IBA = "CSM_BPQ_QUALIFICATION_STATE_IBA";

    /** The Constant CSM_QMS_GROUPING_CATEGORY_NAME. */
    @RBEntry("PHI_QMS_GROUPING")
    public static final String CSM_QMS_GROUPING_CATEGORY_NAME = "CSM_QMS_GROUPING_CATEGORY_NAME";

    /** The Constant CSM_BPQMANAGER_ROLE_INTERNAL_NAME. */
    @RBEntry("BUSINESS_PARTNER_QUALIFICATION_MANAGER")
    public static final String CSM_BPQMANAGER_ROLE_INTERNAL_NAME = "CSM_BPQMANAGER_ROLE_INTERNAL_NAME";

    /** The Constant CSM_AML_TABLE_QMS_STATUS_TOOLTIP. */
    @RBEntry("QMS Status")
    public static final String CSM_AML_TABLE_QMS_STATUS_TOOLTIP = "CSM_AML_TABLE_QMS_STATUS_TOOLTIP";

    /** The Constant CSM_AML_TABLE_QMS_STATUS_PASS_ICON. */
    @RBEntry("netmarkets/images/pass_16.gif")
    public static final String CSM_AML_TABLE_QMS_STATUS_PASS_ICON = "CSM_AML_TABLE_QMS_STATUS_PASS_ICON";

    /** The Constant EMPTY_ICON. */
    @RBEntry("netmarkets/images/empty.gif")
    public static final String EMPTY_ICON = "EMPTY_ICON";
    
    /** The Constant CSM_AML_TABLE_QMS_STATUS_BPQ_NOT_REQUIRED_ICON. */
    @RBEntry("netmarkets/images/not_required_16.gif")
    public static final String CSM_AML_TABLE_QMS_STATUS_BPQ_NOT_REQUIRED_ICON = "CSM_AML_TABLE_QMS_STATUS_BPQ_NOT_REQUIRED_ICON";

    /** The Constant CSM_AML_TABLE_QMS_STATUS_DO_NOT_USE_ICON. */
    @RBEntry("netmarkets/images/DoNotUse.gif")
    public static final String CSM_AML_TABLE_QMS_STATUS_DO_NOT_USE_ICON = "CSM_AML_TABLE_QMS_STATUS_DO_NOT_USE_ICON";

    /** The Constant CSM_AML_TABLE_QMS_STATUS_FAIL_ICON. */
    @RBEntry("netmarkets/images/fail_16.gif")
    public static final String CSM_AML_TABLE_QMS_STATUS_FAIL_ICON = "CSM_AML_TABLE_QMS_STATUS_FAIL_ICON";

    /** The Constant CSM_AXL_TABLE_SKIP_PART_RISK. */
    @RBEntry("netmarkets/images/no_data_16.gif")
    public static final String CSM_AXL_TABLE_SKIP_PART_RISK = "CSM_AXL_TABLE_SKIP_PART_RISK";

    /** The Constant CSM_AML_TABLE_QMS_STATUS_MANUFACTURER_IBA_NAME. */
    @RBEntry("phiQualifiedQMSManufacturer")
    public static final String CSM_AML_TABLE_QMS_STATUS_MANUFACTURER_IBA_NAME = "CSM_AML_TABLE_QMS_STATUS_MANUFACTURER_IBA_NAME";

    /** The Constant CSM_AML_TABLE_QMS_STATUS_VENDOR_IBA_NAME. */
    @RBEntry("phiQualifiedQMSVendor")
    public static final String CSM_AML_TABLE_QMS_STATUS_VENDOR_IBA_NAME = "CSM_AML_TABLE_QMS_STATUS_VENDOR_IBA_NAME";

    /** The Constant CSM_PRODUCT_IBA_NAME. */
    @RBEntry("phiEngineeringResponsibility")
    public static final String CSM_PRODUCT_IBA_NAME = "CSM_PRODUCT_IBA_NAME";

    /** The Constant CSM_SUPPLIER_IBA_NAME. */
    @RBEntry("phiQualifiedQMS")
    public static final String CSM_SUPPLIER_IBA_NAME = "CSM_SUPPLIER_IBA_NAME";

    /** The Constant CSM_BPQ_DOC_BUSINESS_PARTNER_ROLE_IBA_NAME. */
    @RBEntry("phiBusinessPartnerRole")
    public static final String CSM_BPQ_DOC_BUSINESS_PARTNER_ROLE_IBA_NAME = "CSM_BPQ_DOC_BUSINESS_PARTNER_ROLE_IBA_NAME";

    /** The Constant CSM_PHILIPS_PART_RISK_CLASS_IBA_NAME. */
    @RBEntry("phiPartRiskClass")
    public static final String CSM_PHILIPS_PART_RISK_CLASS_IBA_NAME = "CSM_PHILIPS_PART_RISK_CLASS_IBA_NAME";

    /** The Constant CSM_BPQ_DOC_RISK_CLASS_IBA_NAME. */
    @RBEntry("phiBusinessPartnerRiskClass")
    public static final String CSM_BPQ_DOC_RISK_CLASS_IBA_NAME = "CSM_BPQ_DOC_RISK_CLASS_IBA_NAME";

    /** The Constant CSM_AML_TABLE_RISK_CLASS_STATUS_TOOLTIP. */
    @RBEntry("Risk Class Status")
    public static final String CSM_AML_TABLE_RISK_CLASS_STATUS_TOOLTIP = "CSM_AML_TABLE_RISK_CLASS_STATUS_TOOLTIP";

    /** The Constant CSM_AML_TABLE_RISK_CLASS_STATUS_LABEL. */
    @RBEntry("Risk Class Status")
    public static final String CSM_AML_TABLE_RISK_CLASS_STATUS_LABEL = "CSM_AML_TABLE_RISK_CLASS_STATUS_LABEL";

    /** The Constant CSM_AML_TABLE_RISK_CLASS_MANUFACTURER_STATUS_TOOLTIP. */
    @RBEntry("Risk Class Status (Manufacturer)")
    public static final String CSM_AML_TABLE_RISK_CLASS_MANUFACTURER_STATUS_TOOLTIP = "CSM_AML_TABLE_RISK_CLASS_MANUFACTURER_STATUS_TOOLTIP";

    /** The Constant CSM_AML_TABLE_RISK_CLASS_MANUFACTURER_STATUS_LABEL. */
    @RBEntry("Risk Class Status (Manufacturer)")
    public static final String CSM_AML_TABLE_RISK_CLASS_MANUFACTURER_STATUS_LABEL = "CSM_AML_TABLE_RISK_CLASS_MANUFACTURER_STATUS_LABEL";

    /** The Constant CSM_AML_TABLE_RISK_CLASS_VENDOR_STATUS_TOOLTIP. */
    @RBEntry("Risk Class Status (Vendor)")
    public static final String CSM_AML_TABLE_RISK_CLASS_VENDOR_STATUS_TOOLTIP = "CSM_AML_TABLE_RISK_CLASS_VENDOR_STATUS_TOOLTIP";

    /** The Constant CSM_AML_TABLE_RISK_CLASS_VENDOR_STATUS_LABEL. */
    @RBEntry("Risk Class Status (Vendor)")
    public static final String CSM_AML_TABLE_RISK_CLASS_VENDOR_STATUS_LABEL = "CSM_AML_TABLE_RISK_CLASS_VENDOR_STATUS_LABEL";

    /** The Constant CSM_SUPPLIER_BUSINESS_PARTER_ROLES. */
    @RBEntry("phiSupplierBusinessPartnerRoles")
    public static final String CSM_SUPPLIER_BUSINESS_PARTER_ROLES = "CSM_SUPPLIER_BUSINESS_PARTER_ROLES";

    /** The Constant CSM_SUPPLIER_BUSINESS_PARTER_ROLES_RE_USE. */
    @RBEntry("phiBusinessPartnerRolesReUse")
    public static final String CSM_SUPPLIER_BUSINESS_PARTER_ROLES_RE_USE = "CSM_SUPPLIER_BUSINESS_PARTER_ROLES_RE_USE";

    /** The Constant CSM_MANUFACTURING_ENGINEER_ROLE_NAME. */
    @RBEntry("MANUFACTURING ENGINEER")
    public static final String CSM_MANUFACTURING_ENGINEER_ROLE_NAME = "CSM_MANUFACTURING_ENGINEER_ROLE_NAME";

    /** The Constant CSM_BOM_FILTER_AML_IBA_NAME. */
    @RBEntry("phiBOMFilterAML")
    public static final String CSM_BOM_FILTER_AML_IBA_NAME = "CSM_BOM_FILTER_AML_IBA_NAME";

    /** The Constant CSM_SUPERSEDE_NEW_NUMBER_ICON. */
    @RBEntry("netmarkets/images/cplm/supersede_new_number.png")
    public static final String CSM_SUPERSEDE_NEW_NUMBER_ICON = "part.phiSupersedeNewNumber.icon";

    /** The Constant CSM_SUPERSEDE_NEW_NUMBER_NAME. */
    @RBEntry("Supersede New Number")
    public static final String CSM_SUPERSEDE_NEW_NUMBER_NAME = "part.phiSupersedeNewNumber.displayName";

    /** The Constant CSM_SUPERSEDE_NEW_NUMBER_DESCRIPTION. */
    @RBEntry("Supersede New Number")
    public static final String CSM_SUPERSEDE_NEW_NUMBER_DESCRIPTION = "part.phiSupersedeNewNumber.description";

    /** The Constant CSM_SUPERSEDE_NEW_NUMBER_TOOLTIP. */
    @RBEntry("Supersede New Number")
    public static final String CSM_SUPERSEDE_NEW_NUMBER_TOOLTIP = "part.phiSupersedeNewNumber.tooltip";

    /** The Constant CSM_DOC_SUPPLIER_LIST_DESCRIPTION. */
    @RBEntry("Suppliers")
    public static final String CSM_DOC_SUPPLIER_LIST_DESCRIPTION = "philipsSupplier.csmPhilipsDocSupplierList.description";

    /** The Constant CSM_DOC_SUPPLIER_LIST_TOOLTIP. */
    @RBEntry("Suppliers")
    public static final String CSM_DOC_SUPPLIER_LIST_TOOLTIP = "philipsSupplier.csmPhilipsDocSupplierList.tooltip";

    /** The Constant CSM_DOC_SUPPLIER_LIST_LABEL. */
    @RBEntry("Suppliers")
    public static final String CSM_DOC_SUPPLIER_LIST_LABEL = "CSM_DOC_SUPPLIER_LIST_LABEL";

    /** The Constant CSM_DOC_SUPPLIER_LIST_LABEL. */
    @RBEntry("phiPeriodicReviewDate")
    public static final String CSM_QD_PERIODIC_REVIEW_DATE_IBA_NAME = "CSM_QD_PERIODIC_REVIEW_DATE_IBA_NAME";


    /** The Constant CSM_CONTAINER_QMS_VALUES_IBA_NAME. */
    @RBEntry("phiAvailableQMSs")
    public static final String CSM_CONTAINER_QMS_VALUES_IBA_NAME = "CSM_CONTAINER_QMS_VALUES_IBA_NAME";

    /** The Constant CSM_CONTAINER_QMS_STATES_IBA_NAME. */
    @RBEntry("phiAvailableQMSStates")
    public static final String CSM_CONTAINER_QMS_STATES_IBA_NAME = "CSM_CONTAINER_QMS_STATES_IBA_NAME";

    /** The Constant CSM_CONTAINER_REUSE_QMS_STATES_IBA_NAME. */
    @RBEntry("phiAvailableQMSStatesReUse")
    public static final String CSM_CONTAINER_REUSE_QMS_STATES_IBA_NAME = "CSM_CONTAINER_REUSE_QMS_STATES_IBA_NAME";

    /** The Constant CSM_CONTAINER_REUSE_QMS_STATES_IBA_NAME. */
    @Deprecated
    @RBEntry("phiAssignedView")
    public static final String CSM_BPQ_DOC_ASSIGNED_VIEW_IBA_NAME = "CSM_BPQ_DOC_ASSIGNED_VIEW_IBA_NAME";

    /** The Constant SQA_ADMIN_ROLE_INTERNAL_NAME. */
    @RBEntry("SQA_AUDIT_ADMINISTRATOR")
    public static final String SQA_ADMIN_ROLE_INTERNAL_NAME = "SQA_ADMIN_ROLE_INTERNAL_NAME";

    /** The Constant CSM_BPQ_BUSINESS_PARTER_SUBROLES. */
    @RBEntry("phiBusinessPartnerSubRole")
    public static final String CSM_BPQ_BUSINESS_PARTER_SUBROLES = "CSM_BPQ_BUSINESS_PARTER_SUBROLES";

    /** The Constant CODING_OFFICER_ROLE_NAME. */
    @RBEntry("CODING OFFICER")
    public static final String CODING_OFFICER_ROLE_NAME = "CODING_OFFICER_ROLE_NAME";

    /** The Constant PENDING_REPRESENTATION_ICON. */
    @RBEntry("netmarkets/images/reset.png")
    public static final String PENDING_REPRESENTATION_ICON = "PENDING_REPRESENTATION_ICON";

	/* Start Added for US215873 Change control on part common attributes (Enterprise Data) */
	@RBEntry("All")
    public static final String EDIT_MULTI_ED_TABLEVIEW_NAME="EDIT_MULTI_ED_TABLEVIEW_NAME";

    @RBEntry("Edit Multi Enterprise Data View")
    public static final String EDIT_MULTI_ED_TABLEVIEW_LABEL="EDIT_MULTI_ED_TABLEVIEW_LABEL";

    @RBEntry("Include related Parts for ED")
    public static final String ASSOCIATED_WTPART_NOED_DISPLAYNAME = "ASSOCIATED_WTPART_NOED.preferenceDisplays.displayName";

    @RBEntry("Allow user to specify which parts associated to the collected enterprise data will be by default added to the collection.")
    public static final String ASSOCIATED_WTPART_NOED_DESCRIPTION = "ASSOCIATED_WTPART_NOED.preferenceDisplays.description";

    @RBEntry("Allow user to specify which parts associated to the collected enterprise data will be by default added to the collection.")
    public static final String ASSOCIATED_WTPART_NOED_LONGDESCRIPTION = "ASSOCIATED_WTPART_NOED.preferenceDisplays.longDescription";
	/* End Added for US215873 Change control on part common attributes (Enterprise Data) */

    @RBEntry("Supplier Quality Risk Class")
    public static final String RISK_CLASS = "RISK_CLASS";

    @RBEntry("Internal/ External Indicator")
    public static final String SUPPLIER_RELATIONSHIP = "SUPPLIER_RELATIONSHIP";
	
    /** The Constant CANNOT_CREATE_BPQ_DOCUMENT. */
    @RBEntry("You are not the Business Partner Qualification Manager in {0} team template. Select your qualified QMS or contact the Business Organization Administrator (BOA) to update the {0} team template.")
    @RBComment("You are not the Business Partner Qualification Manager in {0} team template. Select your qualified QMS or contact the Business Organization Administrator (BOA) to update the {0} team template.")
    public static final String CANNOT_CREATE_BPQ_DOCUMENT = "CANNOT_CREATE_BPQ_DOCUMENT";
    
    /** The Constant QMS_TEAM_TEMPLATE_NOT_EXIST. */
    @RBEntry("The QMS team template does not exists for {0}, Contact the Business Organization Administrator (BOA) to create a QMS team template.")
    @RBComment("The QMS team template does not exists for {0}, Contact the Business Organization Administrator (BOA) to create a QMS team template.")
    public static final String QMS_TEAM_TEMPLATE_NOT_EXIST = "QMS_TEAM_TEMPLATE_NOT_EXIST";


}
