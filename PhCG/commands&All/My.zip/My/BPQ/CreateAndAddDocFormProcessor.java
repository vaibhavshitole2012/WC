package com.philips.cplm.core.components.forms;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.log4j.Logger;

import com.philips.cplm.core.doc.helper.PhilipsBPQDocHelper;
import com.philips.cplm.resource.csmResource;
import com.philips.cplm.utilities.CPLMPreferenceUtility;
import com.philips.cplm.utilities.CSMCheckQualificationStatus;
import com.philips.cplm.utilities.PhilipsUtilitiesConstantsResource;
import com.philips.cplm.utilities.attributes.PhilipsAttributes;
import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.FormProcessingStatus;
import com.ptc.core.components.forms.FormResult;
import com.ptc.core.components.util.FeedbackMessage;
import com.ptc.core.lwc.server.PersistableAdapter;
import com.ptc.core.ui.resources.FeedbackType;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import com.ptc.windchill.enterprise.doc.forms.CreateDocFormProcessor;
import com.ptc.windchill.suma.supplier.Supplier;
import com.ptc.windchill.suma.supplier.SupplierHelper;
import com.ptc.windchill.suma.supplier.SupplierIfc;

import wt.doc.WTDocument;
import wt.fc.PersistenceHelper;
import wt.fc.collections.WTArrayList;
import wt.fc.collections.WTCollection;
import wt.folder.Folder;
import wt.folder.FolderHelper;
import wt.inf.container.WTContainerRef;
import wt.inf.library.WTLibrary;
import wt.org.WTPrincipal;
import wt.org.WTPrincipalReference;
import wt.session.SessionHelper;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.WTPropertyVetoException;

/**
 * The Class CSMCreateAndAddDocFormProcessor.
 */
public class CreateAndAddDocFormProcessor extends CreateDocFormProcessor {

    /** The log. */
    private static Logger log = Logger.getLogger(CreateAndAddDocFormProcessor.class.getName());

    /** The Constant LIBRARY_CONTEXT_PREFERENCE_NAME. */
    private static final String LIBRARY_CONTEXT_PREFERENCE_NAME = "CSM_BUSINESS_PARTNER_QUALIFICATION_DOCUMENT_LIBRARY";

    /** The Constant PREFERENCE_CONTEXT. */
    private static final String PREFERENCE_CONTEXT = "WINDCHILL";

    /** The principal name. */
    private String principalName = "";
    
    //US623719: R3.8 : Changes to Business Partner Rules
    private static final String COMBOBOX = "combobox";
    private static final String BUSINESS_PARTNER_ROLE="phiBusinessPartnerRole";
    private static final String QUALITY_ASSOCIATED_BUSINESS_PARTNER="QABP";
    private static final String QUALITY_RELEVANT_BUSINESS_PARTNER="QRBP";
    private static final String QABP_SUPPLIER_ROLE="ThirdPartyAuthorizedRepresentativeImporter";
    private static final String QUALIFYING_QMS="phiQualifyingQMS";

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ptc.windchill.enterprise.doc.forms.CreateDocFormProcessor#preProcess(com.
     * ptc.netmarkets.util.beans.NmCommandBean , java.util.List)
     */
    @Override
    public FormResult preProcess(NmCommandBean paramNmCommandBean, List<ObjectBean> objectBeans) throws WTException {
        principalName = SessionHelper.manager.getPrincipal().getName();
        SessionHelper.manager.setAdministrator();
        
       //R3.8 : US623719 : Changes to Business Partner Rules : START
               
        // The supplier from which the BPQ Document is created
        Supplier supplier = (Supplier)paramNmCommandBean.getPrimaryOid().getWtRef().getObject();
        String businessClassification = CSMCheckQualificationStatus.getBusinessClassification((Supplier) supplier);

        FormResult result;
		try {
			result = validateAttributes(paramNmCommandBean,businessClassification);
			if (result.getFeedbackMessages() != null && !result.getFeedbackMessages().isEmpty()) {
	            return result;
	        }
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        //R3.8 : US623719 : Changes to Business Partner Rules :END      
        return super.preProcess(paramNmCommandBean, objectBeans);
    }

    /**
     * This method is used to validate BPQ document attribute based of supplier business classification
     * @param paramNmCommandBean nmCommandBean input object
     * @param businessClassification of the supplier on which BPQ document is being created
     * @return feedbackMessage if there is any error
     * @throws Exception 
     */
    public FormResult validateAttributes(NmCommandBean paramNmCommandBean, String businessClassification) throws Exception {
        HashMap<String, Object> beanMap = paramNmCommandBean.getParameterMap();
        String supplierRole=null;
        String qualifyingQMS = null;
        String localizedLongMessage = null;
        FormResult result = new FormResult(FormProcessingStatus.FAILURE);
        FeedbackMessage feedbackMessage = null;

        // Fetching values of Attributes : TC_ELECT_CONTENT & PRODUCT DIMENSIONS
        for (Map.Entry<String, Object> entry : beanMap.entrySet()) {
            if (entry.getKey().contains(BUSINESS_PARTNER_ROLE) && entry.getKey().endsWith(COMBOBOX)) {
                supplierRole = paramNmCommandBean.getTextParameter(entry.getKey());
            }
            if (entry.getKey().contains(QUALIFYING_QMS) && entry.getKey().endsWith(COMBOBOX)) {
				qualifyingQMS = paramNmCommandBean.getTextParameter(entry.getKey());
			}
        }
        // If business classification is QRBP only, throw error if supplierRole is QABP 
        if (supplierRole != null && supplierRole.equalsIgnoreCase(QABP_SUPPLIER_ROLE) &&
                businessClassification!=null && businessClassification.equalsIgnoreCase(QUALITY_RELEVANT_BUSINESS_PARTNER)){
            localizedLongMessage = WTMessage.getLocalizedMessage(PhilipsUtilitiesConstantsResource.class.getName(),
                    PhilipsUtilitiesConstantsResource.SUPPLIER_ROLE_QRBP_VALIDATION_ERROR);
            feedbackMessage = new FeedbackMessage(FeedbackType.FAILURE, null, null, null, localizedLongMessage);

            result.addFeedbackMessage(feedbackMessage);
            return result;
        }

        //if business classification is QABP only, throw error if supplierRole is not QABP
        if (supplierRole != null && !supplierRole.equalsIgnoreCase(QABP_SUPPLIER_ROLE) &&
                businessClassification!=null && businessClassification.equalsIgnoreCase(QUALITY_ASSOCIATED_BUSINESS_PARTNER)){
            localizedLongMessage = WTMessage.getLocalizedMessage(PhilipsUtilitiesConstantsResource.class.getName(),
                    PhilipsUtilitiesConstantsResource.SUPPLIER_ROLE_QABP_VALIDATION_ERROR);
            feedbackMessage = new FeedbackMessage(FeedbackType.FAILURE, null, null, null, localizedLongMessage);

            result.addFeedbackMessage(feedbackMessage);
            return result;
        }
        
        if (qualifyingQMS != null){
			SessionHelper.manager.setPrincipal(principalName);
			WTPrincipal user=  SessionHelper.manager.getPrincipal();
			WTPrincipalReference wtRef = WTPrincipalReference.newWTPrincipalReference(user);
			System.out.println("user.getName():"+user.getName());
			
			Map<String, String> flag = PhilipsBPQDocHelper.validateUserinTemplateUsingAttribute(qualifyingQMS,wtRef); 
			System.out.println("flag:"+flag.size());
			if(!flag.isEmpty() && flag.containsKey("Participant")){
				 Locale locale = SessionHelper.getLocale();
                 FeedbackMessage msg = new FeedbackMessage(FeedbackType.FAILURE, locale,
                         WTMessage.getLocalizedMessage(csmResource.class.getName(),
                        		 csmResource.CANNOT_CREATE_BPQ_DOCUMENT,
                                 new Object[] {flag.values()}, locale),
                         null, "");
                 result.addFeedbackMessage(msg);
                 result.setStatus(FormProcessingStatus.FAILURE);
                 return result;
			}
			else if(!flag.isEmpty() && flag.containsKey("Template")){
				 Locale locale = SessionHelper.getLocale();
                 FeedbackMessage msg = new FeedbackMessage(FeedbackType.FAILURE, locale,
                         WTMessage.getLocalizedMessage(csmResource.class.getName(),
                        		 csmResource.QMS_TEAM_TEMPLATE_NOT_EXIST,
                                 new Object[] {flag.values()}, locale),
                         null, "");
                 result.addFeedbackMessage(msg);
                 result.setStatus(FormProcessingStatus.FAILURE);
                 return result;
			}
			else{
				SessionHelper.manager.setAdministrator();
			}
		}
        return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.ptc.windchill.enterprise.doc.forms.CreateDocFormProcessor#doOperation(com
     * .ptc.netmarkets.util.beans.NmCommandBean , java.util.List)
     */
    @Override
    public FormResult doOperation(NmCommandBean cb, List<ObjectBean> objectBeans) throws WTException {
        if (log.isDebugEnabled()) {
            log.debug("doOperation::Entry");
        }
        SessionHelper.manager.setPrincipal(principalName);

        String libName = CPLMPreferenceUtility.getPreferenceValue(LIBRARY_CONTEXT_PREFERENCE_NAME, PREFERENCE_CONTEXT);
        WTLibrary library = CPLMPreferenceUtility.getLibraryByName(libName);

        SupplierIfc supplier = (SupplierIfc) cb.getPrimaryOid().getRefObject();
        if (log.isDebugEnabled()) {
            log.debug("supplier = " + supplier);
        }
        WTCollection documents = createWTCollection(objectBeans);
        if (log.isDebugEnabled()) {
            log.debug("documents = " + documents);
        }
        for (Iterator it = documents.persistableIterator(); it.hasNext();) {
            WTDocument document = (WTDocument) it.next();
            String folderPath = (String) cb.getText().get("Location");
            folderPath = folderPath.replace(libName, "Default");
            Folder folder = FolderHelper.service.getFolder(folderPath, (WTContainerRef.newWTContainerRef(library)));
            try {
                document.setContainerReference(folder.getContainerReference());
            } catch (WTPropertyVetoException e) {
                log.error("error setting the container to BPQ Lib for document: " + document.getNumber(), e);
                e.printStackTrace();
            }
        }

        FormResult formResult = super.doOperation(cb, objectBeans);
        FormResult result = new FormResult();

        // Start - US# 291151 (To Persist multi-valued attribute owning Entity)
        Object obj = objectBeans.get(0).getObject();
        WTDocument doc = (WTDocument) obj;

        ArrayList<String> selectedValuesList = new ArrayList<>();
        String[] selectedValues = null;
        int size = 0;

        if (cb.getComboBox() != null) {
            Iterator itr = cb.getComboBox().keySet().iterator();
            while (itr.hasNext()) {
                String key = (String) itr.next();
                if (key != null && key.contains(PhilipsAttributes.BPQ.OWNING_ENTITY)) {
                    selectedValuesList = (ArrayList) cb.getComboBox().get(key);
                    size = selectedValuesList.size();
                    selectedValues = new String[size];
                    for (int i = 0; i < selectedValuesList.size(); i++) {
                        selectedValues[i] = selectedValuesList.get(i);
                    }
                    break;
                }
            }
        }

        PersistableAdapter docAdapter = new PersistableAdapter(doc, null, SessionHelper.getLocale(), null);
        docAdapter.load(PhilipsAttributes.BPQ.OWNING_ENTITY);
        docAdapter.set(PhilipsAttributes.BPQ.OWNING_ENTITY, selectedValues);
        doc = (WTDocument) docAdapter.apply();
        doc = (WTDocument) PersistenceHelper.manager.modify(doc);

        // End - US# 291151 (To Persist multi-valued attribute owning Entity)

        if (FormProcessingStatus.SUCCESS == formResult.getStatus()) {
            if (log.isDebugEnabled()) {
                log.debug("Creating link between Supplier and Document");
            }
            for (Iterator it = documents.persistableIterator(); it.hasNext();) {
                WTDocument document = (WTDocument) it.next();
                SupplierHelper.service.addDocument(supplier, document);
            }
            result.setStatus(FormProcessingStatus.SUCCESS);
        } else {
            if (log.isDebugEnabled()) {
                log.debug("Can't create this object.");
            }
            result = formResult;
        }
        if (log.isDebugEnabled()) {
            log.debug("doOperation::Exit");
        }
        return result;
    }

    /**
     * Creates the wt collection.
     *
     * @param objectBeans
     *            the object beans
     * @return the WT collection
     */
    private WTCollection createWTCollection(List<ObjectBean> objectBeans) {
        if (log.isDebugEnabled()) {
            log.debug("createWTCollection::Entry");
        }
        WTCollection collection = new WTArrayList();
        for (ObjectBean bean : objectBeans) {
            collection.add(bean.getObject());
        }
        if (log.isDebugEnabled()) {
            log.debug("createWTCollection::Exit collection -" + collection);
        }
        return collection;
    }
}
