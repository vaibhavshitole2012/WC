package ext.kb.util;

import java.io.File;
import java.io.FileInputStream;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.ptc.generic.team.TeamHelper;

import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.httpgw.GatewayAuthenticator;
import wt.inf.container.WTContainer;
import wt.inf.team.ContainerTeam;
import wt.inf.team.ContainerTeamHelper;
import wt.inf.team.ContainerTeamManaged;
import wt.inf.team.ContainerTeamService;
import wt.inf.team.StandardContainerTeamService;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.pds.StatementSpec;
import wt.project.ActorRole;
import wt.project.Role;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.session.SessionHelper;
import wt.team.StandardTeamService;
import wt.team.TeamService;

public class KBSystemRoleHelperUtility implements RemoteAccess{
	
	private static HashMap<String,ArrayList<String>> addRoleMap = new HashMap<String,ArrayList<String>>();
	private static HashMap<String,ArrayList<String>> removeRoleMap = new HashMap<String,ArrayList<String>>();
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Class[] aClass = { String.class};
		Object[] aObj = { args[0]};
		
		System.out.println("args[0] : " + args[0]);
		System.out.println("args[1] : " + args[1]);
		
		if(args.length < 2 || args.length > 2){
			System.out.println("Wrong Number of Argument Parameters. \\n File Location UserName");
		}
		if(args.length == 2){
			RemoteMethodServer rms = RemoteMethodServer.getDefault();
			GatewayAuthenticator auth=new GatewayAuthenticator();
			auth.setRemoteUser(args[1]);
			rms.setAuthenticator(auth);
			try {
				rms.invoke("processSystemRoleChanges", "ext.kb.util.KBSystemRoleHelperUtility", null, aClass, aObj);
			} catch (RemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public static void processSystemRoleChanges(String fileLocation){
		System.out.println("*** In processSystemRoleChanges start");
		readInputfile(fileLocation);
		System.out.println("remove MPA" + removeRoleMap);
		System.out.println("ADD MPA" + addRoleMap);
		if(addRoleMap != null && addRoleMap.size()>0){
			processAddRecords();
		}else if(removeRoleMap != null && removeRoleMap.size()>0){
			processRemoveRecords();
		}
		System.out.println("*** In processSystemRoleChanges END");
	}

	private static void readInputfile(String fileLocation) {
		// TODO Auto-generated method stub
		System.out.println("*** In readInputfile start");
		try {
			FileInputStream ipStream = new FileInputStream(new File(fileLocation));
			XSSFWorkbook workBook = new XSSFWorkbook(ipStream);
			XSSFSheet sheet = workBook.getSheetAt(0);
			
			if(validateInputExcelFile(sheet)){
				readInputFileDataIntoMap(sheet);
			}else{
				throw new Exception("Please check Input File Format");
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("*** In readInputfile end");
	}

	private static Boolean validateInputExcelFile(XSSFSheet sheet) {
		// TODO Auto-generated method stub	
			try {
				XSSFRow headerRow = sheet.getRow(0);
				
				XSSFCell contextHeaderCell = headerRow.getCell(0);
				String contextCellValue = contextHeaderCell.getRawValue();
				
				XSSFCell roleNameHeaderCell = headerRow.getCell(1);
				String roleNameCellValue = roleNameHeaderCell.getRawValue();
				
				XSSFCell actionHeaderCell = headerRow.getCell(2);
				String actionCellValue = actionHeaderCell.getRawValue();
				
				if((contextCellValue.equalsIgnoreCase("Context")) 
						&& (roleNameCellValue.equalsIgnoreCase("RoleName"))
							&& (actionCellValue.equalsIgnoreCase("Action"))){
					return false;
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return true;	
		}
	
	private static void readInputFileDataIntoMap(XSSFSheet sheet) {
		// TODO Auto-generated method stub
		System.out.println("in Read data start");
		ArrayList<String> list = new ArrayList<>();
		
		for(int i = 1;i <= sheet.getLastRowNum();i++){
			XSSFRow row = sheet.getRow(i);
			System.out.println("sheet.getLastRowNum() : " + sheet.getLastRowNum());
			XSSFCell contextCell = row.getCell(0);
			String contextCellValue = contextCell.getStringCellValue();
			
			XSSFCell roleNameCell = row.getCell(1);
			String roleNameCellValue = roleNameCell.getStringCellValue();
			
			XSSFCell actionCell = row.getCell(2);
			String actionCellValue = actionCell.getStringCellValue();
			
			System.out.println("contextCellValue" + contextCellValue);
			System.out.println("roleNameCellValue" + roleNameCellValue);
			System.out.println("actionCellValue" + actionCellValue);
			
			if(actionCellValue.equalsIgnoreCase("add")){
				if(addRoleMap.containsKey(contextCellValue)){
					list = addRoleMap.get(contextCellValue);
					list.add(roleNameCellValue);
					addRoleMap.put(contextCellValue, list);
				}else{
					list = new ArrayList<String>();
					list.add(roleNameCellValue);
					addRoleMap.put(contextCellValue, list);
				}
			}else if(actionCellValue.equalsIgnoreCase("remove")){
				if(removeRoleMap.containsKey(contextCellValue)){
					list = removeRoleMap.get(contextCellValue);
					list.add(roleNameCellValue);
					removeRoleMap.put(contextCellValue, list);
				}else{
					list = new ArrayList<String>();
					list.add(roleNameCellValue);
					removeRoleMap.put(contextCellValue, list);
				}
			}
		}
		System.out.println("in Read data END");
	}

	private static void processAddRecords() {
		// TODO Auto-generated method stub
		ArrayList<String> valueList = new ArrayList<String>();
		Iterator<Map.Entry<String,ArrayList<String>>> itr = addRoleMap.entrySet().iterator(); 
		while(itr.hasNext()){
			HashMap.Entry<String, ArrayList<String>> entry = itr.next(); 
			String contextName = entry.getKey();
			try{
				System.out.println("contextName : " + contextName);
				QueryResult qr = findContainer(contextName);
				while(qr.hasMoreElements()){
					System.out.println("has more ele");
					valueList = entry.getValue();
					WTContainer container = (WTContainer) qr.nextElement();
					System.out.println("container Object : " + container);
					//WTContainerTemplate template = container.getContainerTemplate();
					ContainerTeam containerTeam = StandardContainerTeamService.service.getContainerTeam((ContainerTeamManaged) container);
					
					for(int i = 0;i<valueList.size();i++){	
						Role role = Role.toRole(valueList.get(i));
						System.out.println("role : " + role);
						System.out.println("SessionHelper.manager.getPrincipal() : " + SessionHelper.manager.getPrincipal());
						wt.team.TeamHelper.service.addRolePrincipalMap(role, SessionHelper.manager.getPrincipal(), containerTeam);
						PersistenceHelper.manager.save(containerTeam);
						System.out.println("After Remove API");
					}
				}
				
			}catch (Exception e) {
				// TODO: handle exception
			}
			
		}
	}
	
	private static void processRemoveRecords() {
		// TODO Auto-generated method stub
		ArrayList<String> valueList = new ArrayList<String>();
		Iterator<Map.Entry<String,ArrayList<String>>> itr = removeRoleMap.entrySet().iterator(); 
		while(itr.hasNext()){
			
			HashMap.Entry<String, ArrayList<String>> entry = itr.next(); 
			String contextName = entry.getKey();
			try {
				System.out.println("contextName : " + contextName);
				QueryResult qr = findContainer(contextName);
				while(qr.hasMoreElements()){
					System.out.println("has more ele");
					valueList = entry.getValue();
					WTContainer container = (WTContainer) qr.nextElement();
					System.out.println("container Object : " + container);
					//WTContainerTemplate template = container.getContainerTemplate();
					ContainerTeam containerTeam = StandardContainerTeamService.service.getContainerTeam((ContainerTeamManaged) container);
					Map rolePrincipalMap = containerTeam.getRolePrincipalMap();
					System.out.println("rolePrincipalMap" + rolePrincipalMap);
					Vector vector = containerTeam.getRoles();
					System.out.println("Roles : " + vector);
					
					System.out.println("containerTeam : " + containerTeam);
					for(int i = 0;i<valueList.size();i++){
						
						Role role = Role.toRole(valueList.get(i));
						//wt.team.TeamHelper.service.addRolePrincipalMap(role, SessionHelper.manager.getPrincipal(), containerTeam);
						Boolean isPresentRole = vector.contains(role);
						System.out.println("isRolePresent : " + isPresentRole);
						System.out.println("role : " + role);
						System.out.println("SessionHelper.manager.getPrincipal() : " + SessionHelper.manager.getPrincipal());
						//StandardContainerTeamService.service.addMember(containerTeam, role, SessionHelper.manager.getPrincipal());
						StandardContainerTeamService.service.removeRole(containerTeam, role);
						wt.team.TeamHelper.service.deleteRole(role,containerTeam);
						PersistenceHelper.manager.save(containerTeam);
						System.out.println("After Remove API");
					}
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	public static QueryResult findContainer(String containerName) throws Exception {
		
		System.out.println("***findContainerStart***");
        QuerySpec qs = new QuerySpec(WTContainer.class);
        SearchCondition sc = new SearchCondition(WTContainer.class, "containerInfo.name", SearchCondition.EQUAL, containerName);
        qs.appendWhere(sc, new int[] { 0 });
        System.out.println(qs.toString());
        final QueryResult qr = PersistenceHelper.manager.find((StatementSpec) qs);
        System.out.println("***findContainerEnd***");
        return  qr;
	}
}
