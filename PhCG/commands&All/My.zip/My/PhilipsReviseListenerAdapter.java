/*
 * bcwti Copyright (c) 2014 Parametric Technology Corporation (PTC). All Rights Reserved. This software is the confidential and proprietary information of PTC
 * and is subject to the terms of a software license agreement. You shall not disclose such confidential information and shall use it only in accordance with
 * the terms of the license agreement. ecwti
 */
package com.philips.cplm.core.listeners;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.Stack;
import java.util.TreeSet;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.philips.cplm.change.PhilipsChangeUtility;
import com.philips.cplm.core.doc.helper.PhilipsApproverMatrixHelper;
import com.philips.cplm.core.doc.masterlist.PhilipsCDDQueueHelper;
import com.philips.cplm.core.doc.masterlist.tailoring.ProjectTailoringConstants;
import com.philips.cplm.core.doc.masterlist.tailoring.TailoringUtility;
import com.philips.cplm.core.object.utilities.PhilipsRenameObjectUtils;
import com.philips.cplm.core.resource.listenersResource;
import com.philips.cplm.ipoint.resource.PhilipsIpointConstants;
import com.philips.cplm.periodicreview.PhilipsDocPeriodicReviewHelper;
import com.philips.cplm.properties.PhilipsPropertiesHelper;
import com.philips.cplm.reviewevidence.helper.PhilipsEvidenceHelper;
import com.philips.cplm.utilities.CPLMIBAHelper;
import com.philips.cplm.utilities.CPLMIBAUtility;
import com.philips.cplm.utilities.CPLMPreferenceUtility;
import com.philips.cplm.utilities.IBAUtils;
import com.philips.cplm.utilities.RoleProfileValidatorUtility;
import com.philips.cplm.utilities.SoftTypes;
import com.philips.cplm.utilities.UtilityHelper;
import com.ptc.core.businessfield.common.BusinessField;
import com.ptc.core.businessfield.server.businessObject.BusinessObject;
import com.ptc.core.businessfield.server.businessObject.BusinessObjectHelper;
import com.ptc.core.businessfield.server.businessObject.BusinessObjectHelperFactory;
import com.ptc.core.lwc.server.PersistableAdapter;
import com.ptc.core.meta.common.DisplayOperationIdentifier;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.TypeIdentifierHelper;
import com.ptc.core.meta.common.UpdateOperationIdentifier;
import com.ptc.windchill.cadx.editattachments.ContentCategory;
import com.ptc.windchill.cadx.editattachments.ContentCategoryHelper;
import com.ptc.windchill.esi.svc.ESIHelper;
import com.ptc.windchill.esi.tgt.ESITarget;
import com.ptc.windchill.esi.tgt.ESITargetUtility;
import com.ptc.windchill.mpml.processplan.MPMProcessPlan;
import com.ptc.windchill.mpml.processplan.operation.MPMOperation;

import wt.change2.ChangeActivityIfc;
import wt.change2.ChangeHelper2;
import wt.change2.ChangeRecord2;
import wt.change2.ChangeRecordIfc;
import wt.change2.WTChangeActivity2;
import wt.configurablelink.ConfigurableRevisionLink;
import wt.content.ApplicationData;
import wt.content.ContentHelper;
import wt.content.ContentHolder;
import wt.content.ContentRoleType;
import wt.content.ContentServerHelper;
import wt.doc.WTDocument;
import wt.doc.WTDocumentHelper;
import wt.eff.ChangeRecordPendingEff;
import wt.eff.ClientEffGroup;
import wt.eff.EffHelper;
import wt.eff.PendingEff;
import wt.epm.EPMDocument;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.fc.WTReference;
import wt.fc.collections.WTArrayList;
import wt.fc.collections.WTCollection;
import wt.iba.definition.StringDefinition;
import wt.iba.value.IBAHolder;
import wt.iba.value.StringValue;
import wt.identity.IdentityFactory;
import wt.inf.container.WTContainer;
import wt.inf.library.WTLibrary;
import wt.lifecycle.LifeCycleManaged;
import wt.lifecycle.State;
import wt.method.MethodContext;
import wt.org.WTPrincipal;
import wt.org.WTPrincipalReference;
import wt.org.WTUser;
import wt.part.WTPart;
import wt.pdmlink.PDMLinkProduct;
import wt.pds.StatementSpec;
import wt.pom.PersistenceException;
import wt.pom.Transaction;
import wt.project.Role;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.services.ServiceEventListenerAdapter;
import wt.services.ServiceFactory;
import wt.session.SessionHelper;
import wt.session.SessionServerHelper;
import wt.team.Team;
import wt.team.TeamException;
import wt.team.TeamHelper;
import wt.type.ClientTypedUtility;
import wt.type.TypedUtility;
import wt.util.WTAttributeNameIfc;
import wt.util.WTException;
import wt.util.WTMessage;
import wt.util.WTPropertyVetoException;
import wt.vc.Iterated;
import wt.vc.VersionControlHelper;
import wt.vc.VersionControlServiceEvent;
import wt.vc.Versioned;
import wt.vc.wip.WorkInProgressHelper;
import wt.part.WTPartStandardConfigSpec;
import wt.part.WTPartConfigSpec;
import wt.vc.config.ConfigHelper;
import wt.vc.views.View;
import wt.vc.views.ViewHelper;
import wt.vc.wip.Workable;
import wt.workflow.engine.WfEngineHelper;
import wt.workflow.engine.WfState;
import wt.workflow.notebook.Bookmark;
import wt.workflow.notebook.Notebook;
import wt.workflow.notebook.NotebookHelper;

/**
 * The listener interface for receiving philipsRevise events. The class that is
 * interested in processing a philipsRevise event implements this interface, and
 * the object created with that class is registered with a component using the
 * component's <code>addPhilipsReviseListener<code> method. When the
 * philipsRevise event occurs, that object's appropriate method is invoked.
 *
 * @see PhilipsReviseEvent
 */
public class PhilipsReviseListenerAdapter extends ServiceEventListenerAdapter {

    /** The Constant PHI_PERIODIC_REVIEW_DATE. */
    private static final String PHI_PERIODIC_REVIEW_DATE = "phiPeriodicReviewDate";

    /** The Constant PHI_PART_HISTORY_VERSION. */
    private static final String PHI_PART_HISTORY_VERSION = "phiPartHistoryVersion";

    /** The Constant PHI_DOCUMENT_HISTORY_VERSION. */
    private static final String PHI_DOCUMENT_HISTORY_VERSION = "phiDocumentHistoryVersion";

    /** The Constant PHI_SUPERSEDED_ON. */
    private static final String PHI_SUPERSEDED_ON = "phiSupersededOn";

    /** The Constant LOGGER. */
    private static final Logger LOGGER = Logger.getLogger(PhilipsReviseListenerAdapter.class);

    /** The Constant RESOURCE. */
    private static final String RESOURCE = "com.philips.cplm.core.resource.listenersResource";

    /** The Constant IBA_RELATED_PART_REQUEST. */
    private static final String IBA_RELATED_PART_REQUEST = "phiRelatedPartRequest";

    /** The Constant IBA_PART_REQUEST_AFFECTED_OBJECT_TYPE. */
    private static final String IBA_PART_REQUEST_AFFECTED_OBJECT_TYPE = "phiPartRequestAffectedObjectType";

    /** The Constant PART_REQUEST_AFFECTED_TYPES. */
    private static final String PART_REQUEST_AFFECTED_TYPES = "PART_REQUEST_AFFECTED_TYPES";

    /** The Constant PREFERENCE_CONTEXT. */
    private static final String PREFERENCE_CONTEXT = "WINDCHILL";

    /** The Constant CDD_TYPE. */
    private static final String CDD_TYPE = "com.philips.ControlledDeliverableDocument";

    private static final String TAILORING_REASON_ATTRIBUTE_NAME = "phiTailoringReason";

    private static final String IBA_SERVICEDESCRIPTION = "phiServiceDescription";

    private static final String IBA_SERVICEABLE = "phiserviceable";

    private static final String IBA_SERVICE_CATEGORY = "phiServiceCategory";

    private static final String IBA_CONSUMER_REPLACEABLE = "phiConsumerReplaceable";

    private static final String IBA_MATURITY = "maturity";

    private static final String IBA_USAGE_STATUS = "phUsageStatus";

    private static final String REVISE_FROM_LATEST_CONSTANT = "REVISE_FROM_LATEST_TEMPLATE";

    private static final String DELIVERY_METHOD_FOR_PREVIOUSLY_TRAINED_EMPLOYEE = "phiDeliveryMethodForPreviouslyTrainedEmployee";

    private static final String DELIVERY_METHOD_FOR_NEW_EMPLOYEE = "phiDeliveryMethodForNewEmployee";

    private static final String NAME_TRAINING_AUDIENCE = "phiNameTrainingAudience";

    private static final String NEW_TRAINING_AUDIENCE = "phiNewTrainingAudience";

    private static final String ARE_THERE_PREREQUISITES = "phiPrerequisites";

    private static final String NAME_PREREQUISITES = "phiNamePrerequisites";

    private static final String CAN_STUDENT_ADD_HISTORY_AFTER_TRAINING_IS_COMPLETED = "phiCanStudentAddHistoryAfterTrainingIsCompleted";

    private static final String CAN_STUDENT_ADD_HISTORY_AFTER_TRAINING_IS_COMPLETED_QDOC = "phiStudentAddHistory";

    /** The service. */
    /** The service. */
    private final PhilipsReviseListenerService service = ServiceFactory.getService(PhilipsReviseListenerService.class);

    /**
     * Instantiates a new philips revise listener adapter.
     *
     * @param paramString
     *            the param string
     */
    public PhilipsReviseListenerAdapter(String paramString) {
        super(paramString);
    }

    /*
     * (non-Javadoc)
     *
     * @see wt.services.ServiceEventListenerAdapter#notifyVetoableMultiObjectEvent(
     * java.lang.Object)
     */
    @SuppressWarnings("rawtypes")
    @Override
    public void notifyVetoableMultiObjectEvent(Object event) throws WTException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("notifyVetoableMultiObjectEvent::Entry " + event);
        }
        
        System.out.println("Inside notifyVetoableMultiObjectEvent");
        // if VersionControlServiceEvent
        if (event instanceof VersionControlServiceEvent) {
            final WTCollection evtCollection = (WTCollection) ((VersionControlServiceEvent) event).getEventTarget();
            final Iterator iterator = evtCollection.persistableIterator();
            List<String> addionalMessage = new ArrayList<>();
            while (iterator.hasNext()) {
                boolean stiFlag = false;
                final Object object = iterator.next();
                // Versioned object
                if (object instanceof Versioned) {
                    final Versioned revisedVersion = (Versioned) object;
                    final Versioned originalVersion = getOriginalVersion(revisedVersion);
                    final State state = getState(originalVersion);
                    // Added for R3.5.1 Production defect - Not able to create translation package
                    // for all the revisions except A revision
                    if (revisedVersion instanceof EPMDocument) {
                        EPMDocument epmDoc = (EPMDocument) revisedVersion;
                        if (epmDoc.getName().contains("Xliff") || (TypeIdentifierHelper.getType(epmDoc)
                                .isDescendedFrom(TypeIdentifierHelper.getTypeIdentifier(SoftTypes.PHILIPS_TEXTUAL_DOCUMENT))
                                && "Translated".equals(epmDoc.getContainerName()))) {
                            stiFlag = true;
                        }
                    }

                    // if the version is cancelled
                    if (!stiFlag) {
                        addionalMessage = createAdditionalMessageIfObjectIsCancelled(state, originalVersion);
                    }
                }
                TypeIdentifier typeID = TypedUtility.getTypeIdentifier(object);
                boolean isBpqDoc = typeID.isDescendedFrom(PhilipsPropertiesHelper.BUSINESSPARTNERQUALIFICATION_TYPE_ID);
                System.out.println("isBpqDoc:"+isBpqDoc);
                if(isBpqDoc ){
                	WTDocument doc = (WTDocument) object;
                	String qualifyingQMS = IBAUtils.getIBAValueToString(doc, "phiQualifyingQMS");
                	System.out.println("qualifyingQMS:"+qualifyingQMS);
                	
                	System.out.println("ContainerName:"+doc.getContainerName());
                	WTContainer container =  doc.getContainer();
                	String availableQMSs = IBAUtils.getIBAValueToString((IBAHolder) container, "phiAvailableQMSs");
                	System.out.println("availableQMSs:"+availableQMSs);
                	
                	if(!(qualifyingQMS.equals(availableQMSs))){
                		 throw new WTException(RESOURCE, listenersResource.CANNOT_REVISE_QMS_VALUE_NOT_MATCHED, new Object[] {},
                                 addionalMessage.toArray());
                	}
                	
                }
            }
            if (!addionalMessage.isEmpty()) {
                throw new WTException(RESOURCE, listenersResource.CANNOT_REVISE_CANCELED_MAIN_MSG, new Object[] {},
                        addionalMessage.toArray());
            }
        }
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("notifyVetoableMultiObjectEvent::Exit " + event);
        }
    }

    /**
     * copies CDD team from previous revision
     *
     * @param revisedDocument
     *            - Revised Document
     * @param originalDocument
     *            - Original Document
     * @return - Team
     * @throws WTException
     *             - WTException
     */
    public static Team updateCDDTeam(WTDocument revisedDocument, WTDocument originalDocument) throws WTException {
        LOGGER.debug("updateCDDTeam::Entry ");
        Team updatedCddTeam = null;
        if (originalDocument != null) {
            // get revised document cdd team
            Team cddTeam = TeamHelper.service.getTeam(revisedDocument);
            // get previous revision document cdd team
            Team cddTeamOld = TeamHelper.service.getTeam(originalDocument);
            Map<?, ?> oldCDDTeam = cddTeamOld.getRolePrincipalMap();
            // copy revised document cdd team from previous revision
            Iterator<?> allParticipantInTeam = oldCDDTeam.keySet().iterator();
            // updated to resolve cast tool violation
            HashMap<Object, Object> newParticipantToCDDTeam = new HashMap<Object, Object>();
            while (allParticipantInTeam.hasNext()) {
                Role businessRoleML = (Role) allParticipantInTeam.next();
                HashSet<WTPrincipal> participantsBusinessRole = translateAllWTPrincipalReferenceToWTPrincipal(
                        (List<?>) oldCDDTeam.get(businessRoleML));
                if (!participantsBusinessRole.isEmpty()) {

                    newParticipantToCDDTeam.put(businessRoleML, participantsBusinessRole);
                    Iterator it = newParticipantToCDDTeam.entrySet().iterator();
                    while (it.hasNext()) {
                        Map.Entry entry = (Map.Entry) it.next();
                        HashSet values = (HashSet) entry.getValue();
                        Iterator valueIt = values.iterator();
                        while (valueIt.hasNext()) {
                            WTPrincipal principal = (WTPrincipal) valueIt.next();
                            TeamHelper.service.addRolePrincipalMap((Role) entry.getKey(), principal, cddTeam);
                        }

                    }

                }
            }

            updatedCddTeam = TeamHelper.service.getTeam(revisedDocument);
            updatedCddTeam = (Team) PersistenceHelper.manager.refresh(updatedCddTeam);
        }
        LOGGER.debug("updateCDDTeam::Exit ");
        return updatedCddTeam;
    }

    private static HashSet<WTPrincipal> translateAllWTPrincipalReferenceToWTPrincipal(List<?> allParticipant)
            throws WTException {
        HashSet<WTPrincipal> allParticipantReferences = new HashSet<WTPrincipal>();

        if (null != allParticipant) {
            for (Object participant : allParticipant) {
                if (participant instanceof WTPrincipalReference) {
                    WTPrincipalReference princRef = (WTPrincipalReference) participant;
                    allParticipantReferences.add(princRef.getPrincipal());
                }
            }
        }
        return allParticipantReferences;
    }

    /**
     * Creates list of messages if object is in canceled state.
     *
     * @param stateFromObejct
     *            - lifecycle state
     * @param originalVersion
     *            - versioned object
     * @return list of messages
     * @throws WTException
     *             - session helper
     */
    private List<String> createAdditionalMessageIfObjectIsCancelled(State stateFromObejct, Versioned originalVersion)
            throws WTException {
        LOGGER.debug("createAdditionalMessageIfObjectIsInState::Entry ");
        final List<String> addionalMessage = new ArrayList<>();
        final WTPrincipal wtPrincipal = SessionHelper.manager.getPrincipal();
        WTUser user = null;
        if (wtPrincipal instanceof WTUser) {
            user = (WTUser) wtPrincipal;
        }
        if (stateFromObejct != null && stateFromObejct.equals(PhilipsPropertiesHelper.CANCELLED_STATE)
                && !RoleProfileValidatorUtility.isAdmin(user)) {
            final String objectId = IdentityFactory.getDisplayIdentity(originalVersion)
                    .getLocalizedMessage(SessionHelper.getLocale());
            final String message = WTMessage.getLocalizedMessage(RESOURCE,
                    listenersResource.CANNOT_REVISE_CANCELED_SUB_MSG, new Object[] { objectId });
            addionalMessage.add(message);
        }

        LOGGER.debug("createAdditionalMessageIfObjectIsInState::Exit ");
        return addionalMessage;
    }

    /*
     * (non-Javadoc)
     *
     * @see wt.services.ServiceEventListenerAdapter#notifyVetoableEvent(java.lang.
     * Object)
     */
    @Override
    public void notifyVetoableEvent(Object event) throws Exception {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("notifyVetoableEvent::Entry " + event);
        }
        
        System.out.println("Inside notifyVetoableEvent");

        if (event instanceof VersionControlServiceEvent) {
            final Object target = ((VersionControlServiceEvent) event).getEventTarget();
            if (((VersionControlServiceEvent) event).getEventType().equals(VersionControlServiceEvent.NEW_VERSION)) {
                if (isRevising(target)) {
                    if (target instanceof WTDocument) {
                        final String docType = TypedUtility.getTypeIdentifier(target).toExternalForm();
                        WTDocument wtDoc = (WTDocument) target;

                        // 3.5.5 Defect # 5601 : Document Author is not
                        // getting Set State access for revised version of
                        // CDD
                        copyFromPreviousCDD(docType, wtDoc);

                        /*
                         * Added for R3.5.5- US299900 Deliverable Comments: copy previous comments on
                         * CDD revision
                         */
                        if (docType.contains(SoftTypes.PHILIPS_CONTROLLED_DELIVERABLE_DOCUMENT)
                                || docType.contains(SoftTypes.PHILIPS_CONTROLLED_DOCUMENT)
                                || docType.contains(SoftTypes.PHILIPS_GATE)) {
                            updateDeliverableComments(wtDoc);
                        }

                        // Added US291708  - R3.5.5 Approver Matrix update on
                        // Revise.
                        // Added for 3.8 - update to latest approver matrix on Revise
                        PhilipsApproverMatrixHelper.updateToLatestAMOnRevise(wtDoc);

                        if (TypeIdentifierHelper.getType(wtDoc).isDescendedFrom(
                                TypeIdentifierHelper.getTypeIdentifier(SoftTypes.PHILIPS_APPROVER_MATRIX_DOCUMENT))) {
                            PhilipsApproverMatrixHelper.deleteLatestAMLinkOnRevise(wtDoc);

                        }

                        // US291706- Resetting the Periodic review dates
                        PhilipsDocPeriodicReviewHelper.resetPeriodicReviewDatesOnRevise(wtDoc);

                        /*
                         * Start - Added for US215873 Hide QMS Questionnaire for New revisions of QMS
                         * Documents
                         */

                        if (TypedUtility.getTypeIdentifier(target)
                                .isDescendedFrom(PhilipsPropertiesHelper.CONTROLLED_DELIVERABLE_DOCUMENT_ID)
                                || TypedUtility.getTypeIdentifier(target)
                                .isDescendedFrom(PhilipsPropertiesHelper.QUALITY_DOCUMENT_TYPE_ID)
                                || TypedUtility.getTypeIdentifier(target)
                                .isDescendedFrom(PhilipsPropertiesHelper.MASTERLIST_TYPE_ID)) {
                            deleteQMSAttributes(target);
                        }
                        /*
                         * End - Added for US215873 Hide QMS Questionnaire for New revisions of QMS
                         * Documents
                         */
                    } else if (target instanceof EPMDocument) {
                        EPMDocument epmDoc = (EPMDocument) target;
                        PhilipsDocPeriodicReviewHelper.resetPeriodicReviewDatesOnRevise(epmDoc);
                        // Added US291708 - R3.5.5 Approver Matrix update on
                        // Revise.
                        // Added for 3.8 - update to latest approver matrix on Revise
                        PhilipsApproverMatrixHelper.updateToLatestAMOnRevise(epmDoc);
                    }else if (target instanceof WTPart) {
                        // Added for 3.8 - update to latest approver matrix on Revise for Parts
                        PhilipsApproverMatrixHelper.updateToLatestAMOnRevise((WTPart) target);
                        // Added for 3.8 - Removing DT on Revision
                    }

                    cleanUpHistoryVersionIBAAttribue(target);
                    // clearTailoringReason(target);
                    setTemplateNumber(target);
                    clearSupersededOn(target);
                    // triggerTradeItemWorkflow(target);
                    reviseCollection(target);
                    updateCDDTemplateUpdatePushedAttribute(target);
                }
                if (target instanceof WTPart) {
                    LOGGER.debug("Inside target is WTPart");
                    removeiPointDT(target);
                }
                if (TypedUtility.getTypeIdentifier(target).isDescendedFrom(PhilipsPropertiesHelper.SCT_TYPE_ID)
                        || TypedUtility.getTypeIdentifier(target)
                        .isDescendedFrom(PhilipsPropertiesHelper.MDCT_TYPE_ID)) {
                    updateIBAAttribute(target);
                }

                removeReviewEvidenceContent(target);

                removeViewableContent(target);
                removePeriodicReviewDate(target);
                removePartRequestTrace(target);

                /*
                 * Start - Added for US215873 Change control on part common attributes
                 * (Enterprise Data)
                 */
                deleteMasterAttributeHistoryPartLink(target);

            }
            /*if (((VersionControlServiceEvent) event).getEventType().equals(VersionControlServiceEvent.NEW_VERSION)){
            	
            }*/
            resetAttribute(event);
            deletepreviousPendingEffectivities(target);
            LOGGER.debug("notifyVetoableEvent::Exit");
        }

    }

    /**
     * Method added for 3.5.5 Defect # 5601
     *
     * @param docType
     *            -docType
     * @param wtDoc
     *            -wtDoc
     * @throws WTException
     *             -WTException
     */
    private void copyFromPreviousCDD(String docType, WTDocument wtDoc) throws WTException {
        if (docType.contains(SoftTypes.PHILIPS_CONTROLLED_DELIVERABLE_DOCUMENT) && !(WorkInProgressHelper.isCheckedOut(wtDoc))) {
            Object var = MethodContext.getContext().get(REVISE_FROM_LATEST_CONSTANT);
            WTContainer container = wtDoc.getContainer();
            if (container instanceof PDMLinkProduct && !"TRUE".equals(var)) {
                if (LOGGER.isDebugEnabled()) {
                    LOGGER.debug("Copy team members from previous revision");
                }
                PhilipsCDDQueueHelper.copyTeamMembersFromPreviousRevision(wtDoc);
            }
        }
    }
    /*
     * R3.8 Removing iPoint DT on Part
     */
    private void removeiPointDT(final Object target) throws WTException {
        WTPart part = (WTPart) target;
        TypeIdentifier checkEngineeredPartType = PhilipsPropertiesHelper.ENGINEEREDPART_TYPE_ID;
        TypeIdentifier checkStandaredPartType = PhilipsPropertiesHelper.STANDARDPART_TYPE_ID;
        TypeIdentifier checkConfigurablePartType = PhilipsPropertiesHelper.CONFIGURABLEPART_TYPE_ID;
        TypeIdentifier checkSoftwarePartType = PhilipsPropertiesHelper.SOFTWAREPART_TYPE_ID;
        TypeIdentifier checkConfigurableSoftwarePartType = PhilipsPropertiesHelper.CONFIGURABLESOFTWARE_PART_TYPE_ID;
        LOGGER.debug("Getting EP and SP:" + checkEngineeredPartType + "," + checkStandaredPartType);
        TypeIdentifier tiObject = ClientTypedUtility.getTypeIdentifier(part);
        LOGGER.debug("tiObject:" + tiObject.getTypename());
        if (tiObject.getTypeInternalName().contains(checkEngineeredPartType.getTypeInternalName())
                || tiObject.getTypeInternalName().contains(checkStandaredPartType.getTypeInternalName())
                || tiObject.getTypeInternalName().contains(checkConfigurablePartType.getTypeInternalName())
                || tiObject.getTypeInternalName().contains(checkSoftwarePartType.getTypeInternalName())
                || tiObject.getTypeInternalName().contains(checkConfigurableSoftwarePartType.getTypeInternalName())
                ) {
            LOGGER.debug("If the part Object is EP or SP or CP:");
            removeiPointDTONPartRevision((WTPart) target);
        }
    }

    /**
     * US689630: Added for Removing the iPoint DT for Revised
     * Engineered/Standard/Configurable parts
     *
     * @param target
     * @throws WTException
     */
    private void removeiPointDTONPartRevision(WTPart wtPart) throws WTException {
        LOGGER.debug("Deleting DT on the Revision");
        boolean accessEnforced = SessionServerHelper.manager.setAccessEnforced(false);
        LOGGER.info("accessEnforced:" + accessEnforced);
        ESITarget esiTarget = new ESITargetUtility().getTarget(PhilipsIpointConstants.IPOINT);
        if (esiTarget != null) {
            LOGGER.info("esiTarget is not null:");
            try {
                LOGGER.debug("is the Target associated to Part:");
                LOGGER.info("removing target association of object:" + wtPart);
                LOGGER.debug("Current Part identity:" + wtPart.getDisplayIdentifier());
                WTPartStandardConfigSpec stdSpec = WTPartStandardConfigSpec.newWTPartStandardConfigSpec();
                View view = ViewHelper.service.getView(PhilipsPropertiesHelper.DESIGN_VIEW);
                stdSpec.setView(view);
                WTPartConfigSpec configSpec = WTPartConfigSpec.newWTPartConfigSpec(stdSpec);
                QueryResult qr2 = ConfigHelper.service.filteredIterationsOf( wtPart.getMaster(), configSpec);   
                WTPart part = null;
                while(qr2.hasMoreElements()){
                    part = (WTPart)qr2.nextElement();
                    if(part!=null){
                        LOGGER.debug("Design Part identity:" + part.getDisplayIdentifier());
                        ESIHelper.service.removeTargetAssignment(part, esiTarget);
                    }
                    break;
                }
                
            } catch (WTException | WTPropertyVetoException e) {
                LOGGER.error(e);
            } finally {
                SessionServerHelper.manager.setAccessEnforced(accessEnforced);
            }
        }

    }

    /*
     * US652825 - Method to delete the QMS Questionnaire attributes
     */
    private void deleteQMSAttributes(Object target) throws WTException {

        final String phiDeliveryMethodForPreviouslyTrainedEmployee = IBAUtils.getStringIBAValue((IBAHolder) target,
                DELIVERY_METHOD_FOR_PREVIOUSLY_TRAINED_EMPLOYEE);
        final String phiDeliveryMethodForNewEmployee = IBAUtils.getStringIBAValue((IBAHolder) target,
                DELIVERY_METHOD_FOR_NEW_EMPLOYEE);
        final String phiNameTrainingAudience = IBAUtils.getStringIBAValue((IBAHolder) target, NAME_TRAINING_AUDIENCE);
        final String phiNewTrainingAudience = CPLMIBAUtility.getIBAValue((IBAHolder) target, NEW_TRAINING_AUDIENCE);
        final String phiPrerequisites = CPLMIBAUtility.getIBAValue((IBAHolder) target, ARE_THERE_PREREQUISITES);
        final String phiNamePrerequisites = IBAUtils.getStringIBAValue((IBAHolder) target, NAME_PREREQUISITES);
        final String phiCanStudentAddHistoryAfterTrainingIsCompleted = CPLMIBAUtility.getIBAValue((IBAHolder) target,
                CAN_STUDENT_ADD_HISTORY_AFTER_TRAINING_IS_COMPLETED);

        final String phiCanStudentAddHistoryAfterTrainingIsCompletedQdoc = CPLMIBAUtility
                .getIBAValue((IBAHolder) target, CAN_STUDENT_ADD_HISTORY_AFTER_TRAINING_IS_COMPLETED_QDOC);

        deleteAttribute(phiDeliveryMethodForPreviouslyTrainedEmployee, DELIVERY_METHOD_FOR_PREVIOUSLY_TRAINED_EMPLOYEE,
                target);
        deleteAttribute(phiDeliveryMethodForNewEmployee, DELIVERY_METHOD_FOR_NEW_EMPLOYEE, target);
        deleteAttribute(phiNameTrainingAudience, NAME_TRAINING_AUDIENCE, target);
        deleteAttribute(phiNewTrainingAudience, NEW_TRAINING_AUDIENCE, target);
        deleteAttribute(phiPrerequisites, ARE_THERE_PREREQUISITES, target);
        deleteAttribute(phiNamePrerequisites, NAME_PREREQUISITES, target);
        if (TypedUtility.getTypeIdentifier(target).isDescendedFrom(PhilipsPropertiesHelper.MASTERLIST_TYPE_ID)) {
            deleteAttribute(phiCanStudentAddHistoryAfterTrainingIsCompleted,
                    CAN_STUDENT_ADD_HISTORY_AFTER_TRAINING_IS_COMPLETED, target);
        } else {
            deleteAttribute(phiCanStudentAddHistoryAfterTrainingIsCompletedQdoc,
                    CAN_STUDENT_ADD_HISTORY_AFTER_TRAINING_IS_COMPLETED_QDOC, target);
        }
        PersistenceHelper.manager.save((Persistable) target);
    }

    private void updateCDDTemplateUpdatePushedAttribute(Object target) throws WTException {
        if (target instanceof WTDocument) {
            WTDocument document = (WTDocument) target;
            final boolean isLibraryContainer = document.getContainer() instanceof WTLibrary;
            final String docType = TypedUtility.getTypeIdentifier(document).toExternalForm();
            if ((docType.contains(SoftTypes.PHILIPS_CONTROLLED_DELIVERABLE_DOCUMENT) && isLibraryContainer)) {
                document = (WTDocument) CPLMIBAHelper.updateIBAHolder(document, "phiTemplatePushed", false, false);
                document = (WTDocument) PersistenceHelper.manager.refresh(document);
            }
        }
    }

    private void reviseCollection(Object target) throws WTException, WTPropertyVetoException {
        if (PhilipsLifecycleSignatureListenerAdapter.isRegulatoryEvidenceType(target)) {
            final WTDocument regulatoryEvidence = (WTDocument) target;
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("Checking if RegulatoryEvidence document " + regulatoryEvidence.getPersistInfo()
                + " meets requirements to revise parents objects (Collection) ");
            }
            List<WTDocument> collectionsList = PhilipsLifecycleSignatureListenerAdapter
                    .collectParentsForRegulatoryEvidence(regulatoryEvidence);
            collectionsList = selectCollectionsOnlyWithChildrenInRegulatoryEvidenceType(collectionsList);
            collectionsList = getLatestRevisionsOfDocuments(collectionsList);
            collectionsList = PhilipsLifecycleSignatureListenerAdapter
                    .selectCollectionsWhichAreNotUnderChangeNotice(collectionsList);
            reviseParents(collectionsList);
        }
    }

    private void reviseParents(List<WTDocument> collectionList) throws WTException, WTPropertyVetoException {
        LOGGER.debug("ENTER reviseParents() method");

        if (collectionList.isEmpty()) {
            LOGGER.debug("No parents object to revise");
            LOGGER.debug("EXIT reviseParents() method");
            return;
        }

        Transaction localTransaction = new Transaction();
        final boolean oldaccess = SessionServerHelper.manager.setAccessEnforced(false);

        try {
            for (final WTDocument document : collectionList) {
                if (document.getLifeCycleState().equals(PhilipsPropertiesHelper.RELEASED_STATE)) {
                    final Versioned newVersion = VersionControlHelper.service.newVersion(document);
                    PersistenceHelper.manager.store(newVersion);
                    LOGGER.debug("Revised docuemnt");
                }
            }
            localTransaction.commit();
            localTransaction = null;
        } finally {
            SessionServerHelper.manager.setAccessEnforced(oldaccess);
            if (localTransaction != null) {
                localTransaction.rollback();
            }
        }
        LOGGER.debug("EXIT reviseParents() method");
    }

    private List<WTDocument> selectCollectionsOnlyWithChildrenInRegulatoryEvidenceType(List<WTDocument> collectionsList)
            throws WTException {
        LOGGER.debug("ENTER selectCollectionsOnlyWithChildrenInRegulatoryEvidenceType() - input size list: "
                + collectionsList.size());
        final List<WTDocument> collectionListCopy = new ArrayList<>(collectionsList);
        for (final WTDocument doc : collectionsList) {
            final QueryResult qr = WTDocumentHelper.service.getUsesWTDocumentMasters(doc);
            while (qr.hasMoreElements()) {
                final Object obj = qr.nextElement();
                if (!PhilipsLifecycleSignatureListenerAdapter.isRegulatoryEvidenceType(obj)) {
                    collectionListCopy.remove(doc);
                }
            }
        }
        LOGGER.debug("EXIT selectCollectionsOnlyWithChildrenInRegulatoryEvidenceType() - output size list: "
                + collectionListCopy.size());
        return collectionListCopy;
    }

    static List<WTDocument> getLatestRevisionsOfDocuments(List<WTDocument> documents) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("getLatestRevisions::Entry " + documents);
        }
        final Map<String, HashMap<Object, Object>> map = new HashMap<>();

        final Iterator<WTDocument> iterator = documents.iterator();
        // create map organized by part number
        while (iterator.hasNext()) {
            final WTDocument document = iterator.next();

            if (map.containsKey(document.getNumber())) {
                map.get(document.getNumber()).put(document.getVersionIdentifier().getVersionSortId(), document);
            } else {
                final HashMap<Object, Object> newmap = new HashMap<>();
                newmap.put(document.getVersionIdentifier().getVersionSortId(), document);
                map.put(document.getNumber(), newmap);
            }
        }

        // get only latest
        final Set<WTDocument> latest = new HashSet<>();
        final Iterator<String> keys = map.keySet().iterator();
        // updated to resolve cast tool violation
        final SortedSet<Object> set = new TreeSet<>();
        while (keys.hasNext()) {
            final String nextkey = keys.next();
            final HashMap<Object, Object> hmap = map.get(nextkey);
            set.addAll(hmap.keySet());
            latest.add((WTDocument) hmap.get(set.last()));// set.lastest() is
            // the latest
            // revision
        }
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("getLatestRevisions::Exit " + latest);
        }
        return new ArrayList<>(latest);

    }

    /**
     * Delete pending effectivity on MCT previous version, so users will be able to
     * update effectivity on the new version of MCT. Before deleting the
     * effectivity, make sure that it is not yet processed.
     *
     * @param target
     */
    private void deletepreviousPendingEffectivities(Object target) {

        try {
            if (target instanceof ChangeActivityIfc) {
                final ChangeActivityIfc ca = (ChangeActivityIfc) getOriginalVersion((Versioned) target);
                if (ca != null) {
                    final WTCollection changeRecords = getPartChangeRecordsOnCa(ca);
                    final Map<WTReference, List<ClientEffGroup>> map = EffHelper.service
                            .getClientEffGroups((List<WTReference>) changeRecords);
                    final Iterator changeRecordIterator = changeRecords.iterator();
                    while (changeRecordIterator.hasNext()) {
                        Boolean hasProcessed = false;
                        final WTReference next = (WTReference) changeRecordIterator.next();
                        final List<ClientEffGroup> effGroupsList = map.get(next);
                        final QueryResult pendingEffs = PersistenceHelper.manager.navigate(next.getObject(),
                                ChangeRecordPendingEff.EFF_ROLE, ChangeRecordPendingEff.class);
                        while (pendingEffs.hasMoreElements()) {
                            final PendingEff pendingEff = (PendingEff) pendingEffs.nextElement();
                            if (pendingEff.isProcessed()) {
                                LOGGER.debug("Effectivity is already processed, do not delete it");
                                hasProcessed = true;
                                break;
                            }
                        }
                        if (!hasProcessed) {
                            LOGGER.debug("Effectivity is not processed, delete it");
                            final boolean oldAccess = SessionServerHelper.manager.setAccessEnforced(false);
                            EffHelper.service.saveClientEffGroups(null, null, effGroupsList);
                            SessionServerHelper.manager.setAccessEnforced(oldAccess);
                        }

                    }

                }
            }
        } catch (final WTException e) {
            LOGGER.error("Unable to delete previous pending effectivity " + e);

        }
    }

    private WTCollection getPartChangeRecordsOnCa(ChangeActivityIfc ca) throws WTException {
        final WTCollection changeRecords = new WTArrayList();
        ChangeRecordIfc thisChangeRecord;
        QueryResult qryResultChangeRecords;
        qryResultChangeRecords = ChangeHelper2.service.getChangeablesAfter(ca, false);
        while (qryResultChangeRecords.hasMoreElements()) {
            thisChangeRecord = (ChangeRecordIfc) qryResultChangeRecords.nextElement();
            changeRecords.add(thisChangeRecord);

        }

        return changeRecords;
    }

    /**
     * Checks if is revising.
     *
     * @param target
     *            the target
     * @return true, if is revising
     * @throws PersistenceException
     *             the persistence exception
     * @throws WTException
     *             the WT exception
     */
    private boolean isRevising(Object target) throws WTException {
        LOGGER.debug("ENTER::isRevising");
        boolean result = false;
        if (target instanceof Versioned) {
            final Versioned newVer = (Versioned) target;
            Versioned lastVer = null;
            // get all the versions of revising object
            final QueryResult queryResult = VersionControlHelper.service.allVersionsOf(newVer);
            boolean previousVersion = false;
            while (queryResult.hasMoreElements()) {
                lastVer = (Versioned) queryResult.nextElement();
                if (previousVersion) {
                    if (!newVer.getVersionIdentifier().getValue().equals(lastVer.getVersionIdentifier().getValue())) {
                        result = true;
                    }
                    break;
                }
                previousVersion = true;
            }
        }
        LOGGER.debug("EXIT::isRevising::" + result);
        return result;
    }

    /**
     * Clear tailoring reason.
     *
     * @param target
     *            the target
     * @throws WTPropertyVetoException
     */
    private void clearTailoringReason(Object target) throws WTPropertyVetoException {
        final boolean isCDD = isCDD(target);
        if (isCDD) {
            boolean oldEnforce = SessionServerHelper.manager.setAccessEnforced(false);
            try {

                final PersistableAdapter object = new PersistableAdapter((Persistable) target, null,
                        Locale.getDefault(), new UpdateOperationIdentifier());
                object.load(TAILORING_REASON_ATTRIBUTE_NAME);
                object.set(TAILORING_REASON_ATTRIBUTE_NAME, null);
                object.apply();
                PersistenceHelper.manager.modify((Persistable) target);

            } catch (final WTException e) {
                e.printStackTrace();
                LOGGER.error(e);
            } finally {
                SessionServerHelper.manager.setAccessEnforced(oldEnforce);
            }
        }
    }

    /**
     * Sets the template number.
     *
     * @param target
     *            the new template number
     * @throws WTException
     *             the WT exception
     */
    private void setTemplateNumber(Object target) throws WTException {
        if (target instanceof WTDocument) {
            final WTDocument document = (WTDocument) target;
            final boolean isLibraryContainer = document.getContainer() instanceof WTLibrary;
            final String docType = TypedUtility.getTypeIdentifier(document).toExternalForm();
            if ((docType.contains(SoftTypes.PHILIPS_MASTER_LIST) || TailoringUtility.isDocumentTypeToTailor(document))
                    && isLibraryContainer) {
                String templateNumber = null;
                templateNumber = TailoringUtility.generateTemplateNumber(document);
                if (templateNumber != null) {
                    final PersistableAdapter object = new PersistableAdapter((Persistable) target, null,
                            Locale.getDefault(), new UpdateOperationIdentifier());
                    object.load(ProjectTailoringConstants.IBA_TEMPLATE_NUMBER);
                    object.set(ProjectTailoringConstants.IBA_TEMPLATE_NUMBER, templateNumber);
                    object.apply();
                    PersistenceHelper.manager.modify((Persistable) target);
                }
            }
        }
    }

    /**
     * Clear superseded on.
     *
     * @param target
     *            the target
     * @throws WTException
     *             the WT exception
     */
    private void clearSupersededOn(Object target) throws WTException {
        if (target instanceof WTDocument) {
            final WTDocument document = (WTDocument) target;
            final boolean isLibraryContainer = document.getContainer() instanceof WTLibrary;
            final boolean isLatestIteration = document.isLatestIteration();
            final String docType = TypedUtility.getTypeIdentifier(document).toExternalForm();
            if ((docType.contains(SoftTypes.PHILIPS_MASTER_LIST) || docType.contains(SoftTypes.PHILIPS_QUALITY_DOCUMENT)
                    || docType.contains(SoftTypes.PHILIPS_CONTROLLED_DELIVERABLE_DOCUMENT)) && isLibraryContainer
                    && isLatestIteration) {

                Timestamp timestamp;
                try {
                    timestamp = IBAUtils.getTimestampIBAValue(document, PHI_SUPERSEDED_ON);
                    if (timestamp != null) {
                        final PersistableAdapter object = new PersistableAdapter((Persistable) target, null,
                                Locale.getDefault(), new UpdateOperationIdentifier());
                        object.load(PHI_SUPERSEDED_ON);
                        object.set(PHI_SUPERSEDED_ON, null);
                        object.apply();
                        PersistenceHelper.manager.modify((Persistable) target);
                    }
                } catch (final Exception e) {
                    LOGGER.error(e);
                }

            }
        }
    }

    /**
     * Checks if is proper type.
     *
     * @param object
     *            the object
     * @return true, if is proper type
     */
    public boolean isCDD(Object object) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("isProperType :: Entry " + object);
        }
        boolean result = false;
        final String softTypeName = TypedUtility.getTypeIdentifier(object).toString();
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Soft type name: " + softTypeName);
            LOGGER.debug("Proper type: " + CDD_TYPE);
        }
        result = StringUtils.contains(softTypeName, CDD_TYPE);
        LOGGER.debug("isProperType :: Exit");
        return result;
    }

    /**
     * Deletes attributes if object is checked out.
     *
     * @param target
     *            - version controlled
     * @throws WTException
     *             - throws WTException
     */
    private void deleteAttributeIfObjectIsCheckedOut(Object target) throws WTException {
        if (!WorkInProgressHelper.isCheckedOut((Workable) target)
                && VersionControlHelper.hasPredecessor((Iterated) target)) {
            final String phiRelatedPartRequest = IBAUtils.getStringIBAValue((IBAHolder) target,
                    IBA_RELATED_PART_REQUEST);
            final String phiPartRequestAffectedObjectType = IBAUtils.getStringIBAValue((IBAHolder) target,
                    IBA_PART_REQUEST_AFFECTED_OBJECT_TYPE);
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("old value for " + IBA_RELATED_PART_REQUEST + ": " + phiRelatedPartRequest);
                LOGGER.debug("old value for " + IBA_PART_REQUEST_AFFECTED_OBJECT_TYPE + ": "
                        + phiPartRequestAffectedObjectType);
            }
            deleteAttribute(phiRelatedPartRequest, IBA_RELATED_PART_REQUEST, target);
            deleteAttribute(phiPartRequestAffectedObjectType, IBA_PART_REQUEST_AFFECTED_OBJECT_TYPE, target);
        }
    }

    /**
     * Reset attribute. Moved from PHResetAttributeListener.java
     *
     * @param event
     *            the event
     */
    private void resetAttribute(Object event) {
        try {
            service.resetAttribute(event);
        } catch (final Exception e) {
            LOGGER.error("Error", e);
            LOGGER.error(e);
        }
    }

    /**
     * Gets the service.
     *
     * @return the service
     */
    public PhilipsReviseListenerService getService() {
        return this.service;
    }

    /**
     * Removes the periodic review date.
     *
     * @param target
     *            the target
     * @throws WTException
     *             the WT exception
     */
    private void removePeriodicReviewDate(Object target) throws WTException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("removePeriodicReviewDate::Entry " + target);
        }
        if (target instanceof Workable) {
            final boolean isCheckedOut = WorkInProgressHelper.isCheckedOut((Workable) target);
            // do not remove review evidence attachments from checked out
            // objects

            if (!isCheckedOut && target instanceof WTDocument) {
                final WTDocument doc = (WTDocument) target;
                modifyQualityDoc(doc);
            }
        }
        LOGGER.debug("removePeriodicReviewDate::Exit");
    }

    /**
     * Removes the document history version.
     *
     * @param object
     *            the object
     * @throws WTException
     *             the WT exception
     * @throws WTPropertyVetoException
     *             the WT property veto exception
     */
    private void cleanUpHistoryVersionIBAAttribue(Object object) throws WTException, WTPropertyVetoException {
        LOGGER.debug("ENTER::removeHistoryVersion");
        if (object instanceof WTPart && isSuitableTypeOfPhilipsPart((WTPart) object)) {
            deleteStringIBAValue((WTPart) object, PHI_PART_HISTORY_VERSION);
        } else if (object instanceof WTDocument && isSuitableTypeOfPhilipsDocument((WTDocument) object)) {
            deleteStringIBAValue((WTDocument) object, PHI_DOCUMENT_HISTORY_VERSION);
        } else if (object instanceof EPMDocument && object instanceof Persistable
                && SoftTypes.isType((Persistable) object, SoftTypes.CAD_DOCUMENT)) {
            deleteStringIBAValue((EPMDocument) object, PHI_DOCUMENT_HISTORY_VERSION);
        } else {
            LOGGER.debug("Object doesn't meets the requirements to clean up History Version attribute");
        }
        LOGGER.debug("EXIT::removeHistoryVersion");
    }

    /**
     * Checks if is suitable type of philips document.
     *
     * @param doc
     *            the doc
     * @return true, if is suitable type of philips document
     */
    private boolean isSuitableTypeOfPhilipsDocument(WTDocument doc) {
        LOGGER.debug("ENTER::isSuitableTypeOfPhilipsDocument");
        final boolean result = SoftTypes.isType(doc, SoftTypes.PHILIPS_CONTROLLED_DOCUMENT)
                || SoftTypes.isType(doc, SoftTypes.PHILIPS_MASTER_LIST)
                || SoftTypes.isType(doc, SoftTypes.PHILIPS_CONTROLLED_DELIVERABLE_DOCUMENT)
                || SoftTypes.isType(doc, SoftTypes.PHILIPS_QUALITY_DOCUMENT);
        LOGGER.debug("EXIT::isSuitableTypeOfPhilipsDocument::" + result);
        return result;
    }

    /**
     * Checks if part is suitable type of philips part.
     *
     * @param part
     *            the part
     * @return true, if is relevant type of philips part
     */
    private boolean isSuitableTypeOfPhilipsPart(WTPart part) {
        LOGGER.debug("ENTER::isSuitableTypeOfPhilipsPart");
        final boolean result = SoftTypes.isType(part, SoftTypes.PHILIPS_ENGINEER_PART)
                || SoftTypes.isType(part, SoftTypes.PHILIPS_SUPPLY_CHAIN_PART)
                || SoftTypes.isType(part, SoftTypes.PHILIPS_STANDARD_PART)
                || SoftTypes.isType(part, SoftTypes.PHILIPS_STANDARD_SOFTWARE_PART);
        LOGGER.debug("EXIT::isSuitableTypeOfPhilipsPart::" + result);
        return result;
    }

    /**
     * Deletes a string IBA value.
     *
     * @param ibaHolder
     *            the IBA holder containing the IBA to be deleted
     * @param ibaName
     *            the name of the string IBA for deletion
     * @throws WTException
     *             the WT exception
     * @throws WTPropertyVetoException
     *             the WT property veto exception
     */
    public static void deleteStringIBAValue(IBAHolder ibaHolder, String ibaName)
            throws WTException, WTPropertyVetoException {
        LOGGER.debug("ENTER::deleteStringIBAValue");

        final String ibaValue = IBAUtils.getStringIBAValue(ibaHolder, ibaName);

        if (ibaValue != null && !ibaValue.isEmpty()) {
            LOGGER.debug("Trying to remove value \"" + ibaValue + "\" for the "
                    + TypeIdentifierHelper.getType(ibaHolder) + " type.");

            final QuerySpec qs = new QuerySpec();
            final int sv = qs.appendClassList(StringValue.class, true);
            final int sd = qs.appendClassList(StringDefinition.class, false);
            final SearchCondition cond1 = new SearchCondition(StringValue.class,
                    StringValue.IBAHOLDER_REFERENCE + "." + WTAttributeNameIfc.REF_OBJECT_ID, SearchCondition.EQUAL,
                    new Long(((Persistable) ibaHolder).getPersistInfo().getObjectIdentifier().idAsString()));
            final SearchCondition cond2 = new SearchCondition(StringDefinition.class, WTAttributeNameIfc.ID_NAME,
                    StringValue.class, StringValue.DEFINITION_REFERENCE + "." + WTAttributeNameIfc.REF_OBJECT_ID);
            final SearchCondition cond3 = new SearchCondition(StringDefinition.class, StringDefinition.NAME,
                    SearchCondition.EQUAL, ibaName);

            qs.appendWhere(cond1, new int[] { sv });
            qs.appendAnd();
            qs.appendWhere(cond2, new int[] { sd, sv });
            qs.appendAnd();
            qs.appendWhere(cond3, new int[] { sd });

            LOGGER.debug("Searching object:: query::\n" + qs);

            final QueryResult qr = PersistenceHelper.manager.find((StatementSpec) qs);

            if (qr.hasMoreElements()) {
                final Object obj = qr.nextElement();
                if (obj instanceof Persistable[]) {
                    if (((Persistable[]) obj)[0] instanceof StringValue) {
                        final StringValue strValue = (StringValue) ((Persistable[]) obj)[0];
                        strValue.setValue("");
                        PersistenceServerHelper.manager.update(strValue);
                        LOGGER.debug("Removed " + ibaValue + " value from the object.");
                    }
                }
            } else {
                LOGGER.debug("Cannot find proper presistable object.");
            }
        } else {
            LOGGER.debug("Value for attribute " + ibaName + " is empty. Nothing to remove.");
        }
        LOGGER.debug("EXIT::deleteStringIBAValue");
    }

    /**
     * Modify Quality Document.
     *
     * @param doc
     *            - Quality Document
     * @throws WTException
     *             - throws WTException
     */
    private void modifyQualityDoc(WTDocument doc) throws WTException {
        LOGGER.debug("modifyQualityDoc::Entry ");
        if (isQualityDocument(doc)) {
            final PersistableAdapter object = new PersistableAdapter(doc, null, Locale.getDefault(),
                    new UpdateOperationIdentifier());
            object.load(PHI_PERIODIC_REVIEW_DATE);
            final Object phiPeriodicDateObject = object.get(PHI_PERIODIC_REVIEW_DATE);
            if (phiPeriodicDateObject != null) {
                object.set(PHI_PERIODIC_REVIEW_DATE, null);
                object.apply();
                PersistenceHelper.manager.modify(doc);
            }
        }
    }

    /**
     * Method checks if document is Quality Document, Master List, Controlled
     * Delivery Document.
     *
     * @param doc
     *            - the WT Document object
     * @return true if if document is Quality Document, Master List, Controlled
     *         Delivery Document
     */
    private boolean isQualityDocument(WTDocument doc) {
        return SoftTypes.isType(doc, SoftTypes.PHILIPS_QUALITY_DOCUMENT)
                || SoftTypes.isType(doc, SoftTypes.PHILIPS_CONTROLLED_DELIVERABLE_DOCUMENT)
                || SoftTypes.isType(doc, SoftTypes.PHILIPS_MASTER_LIST);
    }

    /**
     * Removes the viewable content.
     *
     * @param target
     *            the target
     * @throws WTPropertyVetoException
     *             the WT property veto exception
     * @throws WTException
     *             the WT exception
     */
    private void removeViewableContent(Object target) throws WTPropertyVetoException, WTException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("removeViewableContent::Entry " + target);
        }
        removeContentIfTargetIsCheckedOut(target, ContentCategoryHelper.getContentCategory("VIEWABLE"));
        LOGGER.debug("removeViewableContent::Exit");
    }

    /**
     * remove review evidence attachment from new version of the revised object.
     *
     * @param target
     *            the target
     * @throws WTException
     *             the WT exception
     * @throws WTPropertyVetoException
     *             the WT property veto exception
     */
    private void removeReviewEvidenceContent(Object target) throws WTException, WTPropertyVetoException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("removeReviewEvidenceContent::Entry " + target);
        }
        // Start R4.0 US1116863 - updated as part of Wet Signature user story
        if (target instanceof Versioned && target instanceof ContentHolder && target instanceof Workable) {
            final boolean isCheckout = WorkInProgressHelper.isCheckedOut((Workable) target);
            if (!isCheckout) {
                PhilipsEvidenceHelper.removeEvidenceAttachments((ContentHolder) target);
            }
        }
        if (target instanceof Versioned && target instanceof ContentHolder && target instanceof WTChangeActivity2) {
            PhilipsEvidenceHelper.removeEvidenceAttachments((ContentHolder) target);
        }
        // End R4.0 US1116863 - updated as part of Wet Signature user story
        LOGGER.debug("removeReviewEvidenceContent::Exit");
    }

    /**
     * Removes the content.
     *
     * @param target
     *            the target
     * @param category
     *            the category
     * @throws WTException
     *             the WT exception
     * @throws WTPropertyVetoException
     *             the WT property veto exception
     */
    private void removeContentIfTargetIsCheckedOut(Object target, ContentCategory category)
            throws WTException, WTPropertyVetoException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("removeContent::Entry target " + target + ", category " + category);
        }
        if (target instanceof Versioned && target instanceof ContentHolder && target instanceof Workable) {
            final boolean isCheckout = WorkInProgressHelper.isCheckedOut((Workable) target);
            // do not remove review evidence attachments from checked out
            // objects
            if (!isCheckout) {
                final ContentHolder holder = (ContentHolder) target;
                final QueryResult result = ContentHelper.service.getContentsByRole(holder, ContentRoleType.SECONDARY);
                removeContent(result, category, holder);
            }
        }

    }

    /**
     * Remove the content.
     *
     * @param result
     *            the result
     * @param category
     *            the category
     * @param holder
     *            the holder
     * @throws WTPropertyVetoException
     *             the WT property veto exception
     * @throws WTException
     *             the WT exception
     */
    private void removeContent(QueryResult result, ContentCategory category, ContentHolder holder)
            throws WTPropertyVetoException, WTException {
        LOGGER.debug("removeContent::Entry");
        while (result.hasMoreElements()) {
            final Object content = result.nextElement();
            if (content instanceof ApplicationData) {
                final ApplicationData appdata = (ApplicationData) content;
                deleteContent(appdata, category, holder);
            }
        }
        LOGGER.debug("removeContent::Exit");
    }

    /**
     * Delete content.
     *
     * @param appdata
     *            the appdata
     * @param category
     *            the category
     * @param holder
     *            the holder
     * @throws WTPropertyVetoException
     *             the WT property veto exception
     * @throws WTException
     *             the WT exception
     */
    private void deleteContent(ApplicationData appdata, ContentCategory category, ContentHolder holder)
            throws WTPropertyVetoException, WTException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("deleteContent::Entry appdata " + appdata + ", category " + category + ", holder " + holder);
        }
        if (appdata.getCategory() != null && category != null && (appdata.getCategory().equals(category.getDisplay())
                || appdata.getCategory().equals(category.toString()))) {
            ContentServerHelper.service.deleteContent(holder, appdata);
        }
        LOGGER.debug("deleteContent::Exit");
    }

    /**
     * Gets the state.
     *
     * @param originalVersion
     *            the original version
     * @return the state
     */
    private State getState(Versioned originalVersion) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("getState::Entry originalVersion " + originalVersion);
        }
        State state = null;
        // if original is persistent. false if null or not persisted
        if (originalVersion != null && PersistenceHelper.isPersistent(originalVersion)
                && checkObjectType(originalVersion)) {
            state = ((LifeCycleManaged) originalVersion).getLifeCycleState();
        }
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("getState::Exit state " + state);
        }
        return state;
    }

    /**
     * Check if object is type of WTPart, WTDocument or EPMDocument.
     *
     * @param object
     *            the object
     * @return boolean
     */
    private boolean checkObjectType(Object object) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("checkObjectType::Entry object " + object);
        }
        boolean result = false;
        if (object instanceof WTPart || object instanceof WTDocument || object instanceof EPMDocument
                || object instanceof MPMProcessPlan || object instanceof MPMOperation) {
            result = true;
        }
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("checkObjectType::Exit result " + result);
        }
        return result;
    }

    /**
     * Gets the original version.
     *
     * @param revisedVersion
     *            the revised version
     * @return the original version
     */
    private Versioned getOriginalVersion(Versioned revisedVersion) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("getOriginalVersion::Entry revisedVersion " + revisedVersion);
        }
        final ObjectReference derivedFromRef = VersionControlHelper.getDerivedFrom(revisedVersion);
        Versioned originalVersion = null;
        if (derivedFromRef != null) {
            // get revised from version
            originalVersion = (Versioned) derivedFromRef.getObject();
        }
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("getOriginalVersion::Exit originalVersion " + originalVersion);
        }
        return originalVersion;
    }

    /**
     * Gets the affected standard part request types pref.
     *
     * @param target
     *            the target
     * @return the affected standard part request types pref
     */
    private String getAffectedStandardPartRequestTypesPref(Object target) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("getAffectedStandardPartRequestTypesPref::Entry target " + target);
        }
        String affectedStandardPartRequestTypesPref = null;
        try {
            affectedStandardPartRequestTypesPref = CPLMPreferenceUtility.getPreferenceValue(PART_REQUEST_AFFECTED_TYPES,
                    PREFERENCE_CONTEXT);
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("affectedStandardPartRequestTypesPref: " + affectedStandardPartRequestTypesPref);
            }
        } catch (final WTException e) {
            LOGGER.error("Error getting preference values from pref: " + PART_REQUEST_AFFECTED_TYPES, e);
            LOGGER.error(e);
        }
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("getAffectedStandardPartRequestTypesPref::Exit affectedStandardPartRequestTypesPref "
                    + affectedStandardPartRequestTypesPref);
        }
        return affectedStandardPartRequestTypesPref;
    }

    /**
     * Delete attribute.
     *
     * @param attributeValue
     *            the attribute value
     * @param attributeName
     *            the attribute name
     * @param target
     *            the target
     */
    private void deleteAttribute(String attributeValue, String attributeName, Object target) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("deleteAttribute::Entry attributeValue " + attributeValue + ", attributeName " + attributeName
                    + ", target " + target);
        }
        if (attributeValue != null && !"".equals(attributeValue)) {
            IBAUtils.deleteAttribute((IBAHolder) target, attributeName);
        }
        LOGGER.debug("deleteAttribute::Exit");
    }

    private void removePartRequestTrace(Object target) {
        if (target instanceof Persistable) {
            final String affectedStandardPartRequestTypesPref = getAffectedStandardPartRequestTypesPref(target);
            if (affectedStandardPartRequestTypesPref != null && PhilipsRenameObjectUtils
                    .isObjectTypeValid(affectedStandardPartRequestTypesPref, (Persistable) target)) {
                // We know from the previous check that target is either a
                // WTPart or WTDocument
                // which are Persistable, Workable, Iterated and IBAHolder.
                LOGGER.debug("A match was found, preparing to reset: " + IBA_RELATED_PART_REQUEST + " for: " + target);
                try {
                    deleteAttributeIfObjectIsCheckedOut(target);
                } catch (final WTException e) {
                    LOGGER.error("Error reseting the iba: " + IBA_RELATED_PART_REQUEST + " for: " + target, e);
                    LOGGER.error(e);
                }
            }
        }
    }

    /**
     *
     * This method is called only for SCT, IBA attributes Service
     * Description,Serviceable.On Revising the SCN the IBA attributes are copied
     * from old to new version of SCT.
     *
     *
     * @param target
     *            - event target
     * @throws WTException
     *             Exception
     *
     */
    private void updateIBAAttribute(Object target) throws WTException, WTPropertyVetoException {
        LOGGER.debug("entering updateIBAAttribute for SCT");
        final Versioned newVer = (Versioned) target;
        Versioned lastVer = null;
        if (target instanceof Versioned) {

            // get all the versions of revising object
            final QueryResult queryResult = VersionControlHelper.service.allVersionsOf(newVer);

            while (queryResult.hasMoreElements()) {
                lastVer = (Versioned) queryResult.nextElement();
                if (!newVer.getVersionIdentifier().getValue().equals(lastVer.getVersionIdentifier().getValue())) {
                    break;
                }
            }
        }

        final WTChangeActivity2 changeActivity = (WTChangeActivity2) lastVer;
        final WTChangeActivity2 changeActivityNew = (WTChangeActivity2) newVer;

        Map<WTPart, ChangeRecord2> oldDataMap = new HashMap<>();
        final QueryResult qresult = ChangeHelper2.service.getChangeablesAfter(changeActivity, false);
        final QueryResult qresultNew = ChangeHelper2.service.getChangeablesAfter(changeActivityNew, false);

        while (qresult.hasMoreElements()) {
            final Object next = qresult.nextElement();
            if (next instanceof ChangeRecord2) {

                ChangeRecord2 crObject = (ChangeRecord2) next;
                Persistable roleBObj = ((ChangeRecord2) next).getRoleBObject();
                if (roleBObj instanceof WTPart) {

                    oldDataMap.put((WTPart) roleBObj, crObject);
                }
            }
        }

        updateNewChangeRecord(qresultNew, oldDataMap);

        LOGGER.debug("leaving updateIBAAttribute for SCT");
    }

    /**
     * R4.0 - US1104790 Method to update new Change record attributes
     *
     * @param qresultNew
     *            - qresultNew
     * @param oldDataMap
     *            - oldDataMap
     * @throws WTException
     *             - WTException
     * @throws WTPropertyVetoException
     *             - WTPropertyVetoException
     */
    private void updateNewChangeRecord(QueryResult qresultNew, Map<WTPart, ChangeRecord2> oldDataMap)
            throws WTException, WTPropertyVetoException {
        LOGGER.debug("In updateNewChangeRecord for SCT");
        ChangeRecord2 record = null;
        ChangeRecord2 newChangeRecord = null;
        Object objVal;
        List<Persistable> modifiedPersistables = new ArrayList<>();
        while (qresultNew.hasMoreElements()) {
            final Object newObject = qresultNew.nextElement();
            if (newObject instanceof ChangeRecord2) {
                record = null;
                newChangeRecord = (ChangeRecord2) newObject;
                Collection<BusinessField> changeRecordBusinessField = PhilipsChangeUtility
                        .getChangeRecBusinessObjCollection();
                BusinessObjectHelper busObjHelper = BusinessObjectHelperFactory.getBusinessObjectHelper();
                Locale locale = SessionHelper.getLocale();
                Persistable roleBObj = ((ChangeRecord2) newObject).getRoleBObject();
                if (roleBObj instanceof WTPart) {
                    record = oldDataMap.get(roleBObj);
                }
                if (record == null) {
                    continue;
                }

                List<BusinessObject> changeRecOldObj = busObjHelper.newBusinessObjects(locale,
                        new DisplayOperationIdentifier(), true, record);
                busObjHelper.load(changeRecOldObj, changeRecordBusinessField);

                List<BusinessObject> changeRecNewObj = busObjHelper.newBusinessObjects(locale,
                        new UpdateOperationIdentifier(), true, newChangeRecord);
                busObjHelper.load(changeRecNewObj, changeRecordBusinessField);

                for (BusinessField businessField : changeRecordBusinessField) {
                    objVal = changeRecOldObj.get(0).get(businessField);
                    objVal = PhilipsChangeUtility.getValToBeUpdated(objVal);
                    changeRecNewObj.get(0).set(businessField, objVal);

                    LOGGER.debug("businessField....");
                    LOGGER.debug(businessField);
                    LOGGER.debug("businessField name....");
                    LOGGER.debug(businessField.getName());
                    LOGGER.debug("objVal....");
                    LOGGER.debug(objVal);
                }
                record.getPersistInfo().setVerified(true);
                modifiedPersistables.addAll(busObjHelper.apply(changeRecNewObj));
                PersistenceHelper.manager.modify(new WTArrayList(modifiedPersistables));
            }
        }
        LOGGER.debug("Out updateNewChangeRecord for SCT");
    }

    /*
     * Start - Added for US215873 Change control on part common attributes
     * (Enterprise Data)
     */
    /**
     * Delete master attribute history part link on Revise of Engineered Part,
     * Configurable Part and Standard Part.
     *
     * @param target
     *            the target
     */
    private void deleteMasterAttributeHistoryPartLink(Object target) {
        LOGGER.debug("Begin deleteMasterAttributeHistoryPartLink method ");
        WTPart part = null;
        if (target instanceof WTPart) {
            part = (WTPart) target;
        }
        boolean oldEnforce = SessionServerHelper.manager.setAccessEnforced(false);
        try {
            // first time, when part is being created, part is not yet
            // persisted, hence part will be null, created link
            if (part != null) {
                if (TypedUtility.getTypeIdentifier(part).isDescendedFrom(PhilipsPropertiesHelper.STANDARDPART_TYPE_ID)
                        || TypedUtility.getTypeIdentifier(part).isDescendedFrom(PhilipsPropertiesHelper.ENGINEEREDPART_TYPE_ID)
                        || TypedUtility.getTypeIdentifier(part).isDescendedFrom(PhilipsPropertiesHelper.CONFIGURABLEPART_TYPE_ID)
                        || TypedUtility.getTypeIdentifier(part).isDescendedFrom(PhilipsPropertiesHelper.SOFTWAREPART_TYPE_ID)
                        || TypedUtility.getTypeIdentifier(part).isDescendedFrom(PhilipsPropertiesHelper.CONFIGURABLESOFTWARE_PART_TYPE_ID)
                        ) {
                    Persistable link = UtilityHelper.getMasterAttributeHistoryPartLink(part);
                    if (link != null) {
                        LOGGER.debug("link object=" + link.toString()
                        + ((ConfigurableRevisionLink) link).getRoleAObject().toString()
                        + ((ConfigurableRevisionLink) link).getRoleBObject().toString());
                        PersistenceHelper.manager.delete(link);
                        LOGGER.debug("link deleted");
                    }
                }
            }
        } catch (WTException e) {
            e.printStackTrace();
        } finally {
            SessionServerHelper.manager.setAccessEnforced(oldEnforce);
        }

    }

    /**
     * US295206-FastTrack/Full Track##Method to retrieve the previous version
     * participants
     *
     * @param masterList:
     *            Master List document
     * @param routeTaken:
     *            routeTaken value
     * @return : Map of Role & participants
     * @throws WTException
     */
    @SuppressWarnings("unchecked")
    private static Map<Role, WTPrincipalReference> getPreviousMasterListTeam(WTDocument masterList) throws WTException {
        LOGGER.debug("getPreviousMasterListTeam::Entry:");
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Master List:" + masterList);
        }
        Map<Role, WTPrincipalReference> participants = null;
        Stack<WTDocument> actualDocument = new Stack<WTDocument>();

        actualDocument.push(masterList);
        while (!actualDocument.empty()) {
            WTDocument previousDocument = actualDocument.pop();
            // Get the predecessor of the document version
            ObjectReference previousIterationRef = VersionControlHelper.getPredecessor(previousDocument);
            if (null != previousIterationRef) {
                WTDocument previousIteration = (WTDocument) previousIterationRef.getObject();
                if (null != previousIteration) {
                    // get completed workflows
                    QueryResult wfProcessResult = WfEngineHelper.service.getAssociatedProcesses(previousIteration,
                            WfState.CLOSED_COMPLETED_EXECUTED, null);
                    
                                        
                    // if there is at least one workflow completed
                    if (wfProcessResult.hasMoreElements()) {
                        Team previousTeam = TeamHelper.service.getTeam(previousIteration);
                        participants = previousTeam.getRolePrincipalMap();

                    } else {
                        // continue with previous iteration/version
                        actualDocument.push(previousIteration);
                    }
                }
            }
        }
        LOGGER.debug("getPreviousMasterListTeam::Exit:");
        return participants;
    }

    /**
     * Added for R3.5.5- US299900 Deliverable_Comments: Method to update the CDD
     * comments upon revise of CDD.
     *
     * @param target
     *            - Controlled Deliverable Document which is being revised
     * @throws WTException
     *             Windchill Exception
     * @throws WTPropertyVetoException
     */
    private void updateDeliverableComments(WTDocument cddDocument) throws WTException {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("US299900 : Deliverable Comments are getting carry forward on " + cddDocument.getNumber()
            + " CDD revision.");
        }
        WTDocument originalDoc = (WTDocument) getOriginalVersion(cddDocument);
        Enumeration newNoteBooksObj = NotebookHelper.service.getNotebooks(cddDocument);
        if ((newNoteBooksObj != null) && (!newNoteBooksObj.hasMoreElements())) {
            Notebook newNotebook = Notebook.newNotebook("Notebook", cddDocument, cddDocument.getContainerReference());
            try {
                PersistenceHelper.manager.save(newNotebook);
                newNotebook = (Notebook) PersistenceHelper.manager.refresh(newNotebook);
                NotebookHelper.service.addNotebook(newNotebook, cddDocument, true);
                cddDocument = (WTDocument) PersistenceHelper.manager.refresh(cddDocument);
            } catch (WTException e) {
                LOGGER.error(e);
            }

            Enumeration noteBooks = NotebookHelper.service.getNotebooks(originalDoc);
            if ((noteBooks != null) && (noteBooks.hasMoreElements())) {
                Object notebookObj;
                while (noteBooks.hasMoreElements()) {
                    notebookObj = noteBooks.nextElement();
                    setDescription(notebookObj, newNotebook);
                }
            }
        }
    }

    void setDescription(Object notebookObj, Notebook newNotebook) throws WTException {
        Notebook notebook;
        Enumeration bookmarksObj;
        Bookmark bookmark;
        Bookmark newBookmark;
        if ((notebookObj instanceof Notebook)) {
            notebook = (Notebook) notebookObj;
            bookmarksObj = notebook.getBookmarks();
            while (bookmarksObj.hasMoreElements()) {
                bookmark = (Bookmark) bookmarksObj.nextElement();
                if ((bookmark instanceof Bookmark)) {
                    if (LOGGER.isDebugEnabled()) {
                        LOGGER.debug("US299900 : Revising comment for " + bookmark.getName());
                    }
                    newBookmark = Bookmark.newBookmark(bookmark.getName(), bookmark.getUrl(), newNotebook);
                    try {
                        newBookmark.setDescription(bookmark.getDescription());
                    } catch (WTPropertyVetoException e) {
                        LOGGER.error(e);
                    }
                    try {
                        PersistenceHelper.manager.save(newBookmark);
                    } catch (WTException e) {
                        LOGGER.error(e);
                    }
                }
            }
        }
    }
}
