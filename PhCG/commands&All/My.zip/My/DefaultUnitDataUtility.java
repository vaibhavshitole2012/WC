package com.philips.cplm.core.part.datautilities;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.philips.cplm.properties.PhilipsPropertiesHelper;
import com.ptc.core.components.descriptor.ModelContext;
import com.ptc.core.components.factory.dataUtilities.DefaultDataUtility;
import com.ptc.core.components.rendering.guicomponents.AttributeInputComponent;
import com.ptc.core.components.rendering.guicomponents.AttributeInputCompositeComponent;
import com.ptc.core.components.rendering.guicomponents.IconComponent;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.type.common.impl.DefaultTypeInstance;
import com.ptc.core.ui.resources.ComponentMode;
import com.ptc.netmarkets.model.NmOid;
import com.ptc.windchill.esi.svc.ESIHelper;
import com.ptc.windchill.esi.tgt.ESITarget;
import com.ptc.windchill.esi.txn.ESITransactionUtility;
import com.ptc.windchill.esi.txn.ReleaseStatusType;
import com.ptc.windchill.esi.utl.ESIException;

import wt.fc.ObjectIdentifier;
import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.QueryResult;
import wt.folder.Cabinet;
import wt.part.WTPart;
import wt.pom.PersistenceException;
import wt.session.SessionServerHelper;
import wt.type.TypedUtility;
import wt.util.WTException;
import wt.vc.Mastered;
import wt.vc.VersionControlHelper;


public class DefaultUnitDataUtility extends DefaultDataUtility {

	/** The Constant LOGGER. */
	private static final Logger LOGGER = Logger.getLogger(DefaultUnitDataUtility.class);

	//private static final String TRADE_ITEM ="WCTYPE|wt.part.WTPart|com.philips.PhilipsPart|com.philips.PhilipsTradeItem";

	//private static final String TRADE_COMPONENT ="WCTYPE|wt.part.WTPart|com.philips.PhilipsPart|com.philips.CommercialPart"; 

	private static final String[] PROPER_TYPES = {"com.philips.PhilipsTradeItem", "com.philips.CommercialPart" };


	@Override
	public Object getDataValue(String componentId, Object datum, ModelContext mc) throws WTException {
		if (LOGGER.isDebugEnabled()) {
			System.out.println(
					"DefaultUnitDataUtility.getDataValue(): componendId: " + componentId + ", object: " + datum);
		}

		boolean enforce = SessionServerHelper.manager.setAccessEnforced(true);
		Object object = super.getDataValue(componentId, datum, mc);

		try{

			if (datum instanceof DefaultTypeInstance) {
				ObjectIdentifier objectOid = mc.getNmCommandBean().getPrimaryOid().getOidObject();
				ObjectReference reference = ObjectReference.newObjectReference(objectOid);
				Persistable persistable = reference.getObject();

				AttributeInputCompositeComponent comp =  (AttributeInputCompositeComponent) object;
				System.out.println("persistable instanceof Cabinet");
				System.out.println(persistable instanceof Cabinet);

				System.out.println("mc.getDescriptorMode(): "+mc.getDescriptorMode());
				if (mc.getDescriptorMode().equals(ComponentMode.EDIT) && persistable instanceof WTPart) {
					object = disableDefaultUnit(persistable,object,componentId);
				}
				else if(mc.getDescriptorMode().equals(ComponentMode.EDIT) && persistable instanceof Cabinet){
					ArrayList<?> selectOidForPopup = mc.getNmCommandBean().getSelectedOidForPopup();
					System.out.println("selectOidForPopup: "+selectOidForPopup.size());

					if(!selectOidForPopup.isEmpty()){
						for(int i=0;i<selectOidForPopup.size();i++){
							System.out.println("inside selectOidForPopup");
							NmOid nmOid = (NmOid) selectOidForPopup.get(i);
							objectOid= nmOid.getOidObject();
							ObjectReference references = ObjectReference.newObjectReference(objectOid);
							Persistable persistables = references.getObject();
							object = disableDefaultUnit(persistables,object,componentId);
						}
					}
				}
				System.out.println("DefaultUnitDataUtility.getDataValue():Exit");

				//mc.getDescriptor().setMode(mc.getParentDescriptor().getMode());
			}
		}
		finally {
			SessionServerHelper.manager.setAccessEnforced(enforce);
		}
		return object;

	}

	private Object disableDefaultUnit(Persistable persistable, Object object, String componentId) throws PersistenceException, WTException {
		Boolean readOnly = false;
		List<ESITarget> hasReleased = null;
		WTPart part = (WTPart) persistable;
		System.out.println("current version=" + part.getDisplayIdentifier());

		Mastered master = part.getMaster();
		QueryResult result = VersionControlHelper.service.allVersionsOf(master);
		System.out.println("all versions of the part are:");
		//System.out.println("Trade:"+PhilipsPropertiesHelper.COMMERCIALPART_TYPE_NAME.equals(TypedUtility.getTypeIdentifier(version));
		while (result.hasMoreElements()) {
			WTPart version = (WTPart) result.nextElement();
			hasReleased = getAllSuccessFulDTOfPart(version);
			System.out.println("hasReleased: "+hasReleased.size());
			System.out.println("isProperType:"+isProperType(version));
			if (!isProperType(version)&& ((version.getLifeCycleState().equals(PhilipsPropertiesHelper.MANUFACTURING_RELEASED_STATE)))) {
				readOnly = true;
			}
		}
		if (readOnly == true && object instanceof AttributeInputCompositeComponent) {
			System.out.println("ReadOnly is true...");
			ArrayList<Object> attrInputList = new ArrayList<Object>();
			AttributeInputCompositeComponent inputComponent = ((AttributeInputCompositeComponent) object);
			AttributeInputComponent attributeInputComponent = inputComponent.getValueInputComponent();
			System.out.println("value is " + attributeInputComponent.getRawValue());

			//attributeInputComponent.setColumnName(comp.getColumnName());
			attributeInputComponent.setEditable(false);
			attrInputList.add(attributeInputComponent);

			IconComponent icon = new IconComponent("netmarkets/images/lock.gif");
			icon.setId(componentId);
			icon.setTooltip("Locked");
			attrInputList.add(icon);
			object = attrInputList;

		}
		return object;


	}

	/**
	 * Checks if is contained in PROPER_TYPES table.
	 *
	 * @param datum
	 *            the datum
	 * @return true, if is proper type
	 */
	public static boolean isProperType(Object datum) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("isProperType :: Entry " + datum);
		}
		boolean result = false;
		String softTypeName = TypedUtility.getTypeIdentifier(datum).toString();
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Soft type name: " + softTypeName);
			LOGGER.debug("Proper types: " + PROPER_TYPES);
		}
		for (String type : PROPER_TYPES) {
			result = StringUtils.contains(softTypeName, type);
			if (result) {
				break;
			}
		}
		LOGGER.debug("isProperType :: Exit");
		return result;
	}

	private static List<ESITarget> getAllSuccessFulDTOfPart(WTPart part) throws ESIException, WTException {

		List<ESITarget> allSuccessfullDTs = new ArrayList<ESITarget>();
		boolean oldAccess = SessionServerHelper.manager.setAccessEnforced(false);

		try {
			// Get all DTs of part
			Collection<ESITarget> partDTs = ESIHelper.service.findESITargets(part);

			if (partDTs != null && partDTs.size() > 0) {

				LOGGER.debug("Validation 4) Distribution Target Assigned : True (" + partDTs + ")");
				Iterator<ESITarget> itr = partDTs.iterator();

				while (itr.hasNext()) {
					ESITarget target = itr.next();
					TypeIdentifier targetType = TypedUtility.getTypeIdentifier(target);
					System.out.println("targetType=="+targetType);
					if (targetType.isDescendedFrom(PhilipsPropertiesHelper.DISTRIBUTION_PHILIPS_SAP_TYPE_ID)) {

						LOGGER.debug("Validation 5) Distribution Target of Type Internal Manufacturing : True ("
								+ target.getName() + ")");
						// Check DTs publishing status
						ReleaseStatusType[] releaseStatus = { ReleaseStatusType.SUCCEEDED };
						boolean hasSucceededRA = ESITransactionUtility.hasReleaseActivity(target, releaseStatus, null,
								part, null);
						// Check DTs publishing status SUCCEEDED
						if (hasSucceededRA) {
							LOGGER.debug("Validation 6) Publishing Status SUCCESS : True");
							allSuccessfullDTs.add(target);
						}
					}
				}
			}
		} finally {
			SessionServerHelper.manager.setAccessEnforced(oldAccess);
		}

		return allSuccessfullDTs;
	}
}
